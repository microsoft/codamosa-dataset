

# Generated at 2022-06-12 16:01:19.778823
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class SimpleSchema(Schema):

        a = Field(required=True)
        b = Field(required=True)

    token = Token([{"a": 1, "b": 2}, {"a": 3, "b": 4}])
    assert validate_with_positions(token=token, validator=SimpleSchema) == token.value

    token = Token([{"a": 1, "b": 2}, {"b": 4}])
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=SimpleSchema)

# Generated at 2022-06-12 16:01:24.882705
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(Exception) as excinfo:
        validate_with_positions(
            token=Token(value={"name": "Bart"}, start=(0, 0), end=(3, 4)),
            validator=Schema(
                {"name": Field(required=True), "age": Field(required=True)}
            ),
        )
    error = excinfo.value
    assert isinstance(error, ValidationError)
    assert error.messages()[0].text == "The field 'age' is required."
    assert error.messages()[0].start_position == (0, 0)
    assert error.messages()[0].end_position == (3, 4)

# Generated at 2022-06-12 16:01:35.469465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class RecurseTest(Schema):
        value = Field()

    class Test(Schema):
        value = Field(required=True)
        value_two = Field(required=True)
        value_three = RecurseTest()

    token = Token(
        keys=["value", "value_two", "value_three"],
        values=[
            Token(keys=[], values="test"),
            Token(keys=[], values={"value": "test"}),
            Token(keys=["value"], values={"value": None}),
        ],
    )

    try:
        validate_with_positions(token=token, validator=Test)
    except ValidationError as error:
        messages = list(error.messages())

# Generated at 2022-06-12 16:01:46.501048
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_text
    from typesystem import fields
    import re

    # do a bit of a hack on the unit test so we can use `assert` and get a
    # nice message.
    try:
        validate_with_positions(
            token=tokenize_text("{'name': 'James', 'age': 23}")[0],
            validator=fields.Dict(
                properties={
                    "name": fields.String(min_length=3, max_length=10),
                    "age": fields.Integer(min_value=0, max_value=150),
                }
            ),
        )
        assert 1 == 0, "Expected a ValidationError to be raised"
    except ValidationError as e:
        assert len(e.messages()) == 4
       

# Generated at 2022-06-12 16:01:54.967189
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from sources.api_v3 import Fragment, FragmentType, Tokenizer
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.exceptions import TokenizationError

    class TypeSchema(Schema):
        type = String()

    class MyFragment(Fragment):
        type: FragmentType = "my_fragment"
        type_schema: Schema = TypeSchema

    tokenizer = Tokenizer(
        {
            "my_fragment": MyFragment,
        }
    )
    token = tokenizer.tokenize(
        {
            "type": "my_fragment",
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_pos

# Generated at 2022-06-12 16:02:00.221756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, type_mapping
    from typesystem.tokenize.tokenizer import tokenize

    class Note(Schema):
        title = String(min_length=2)
        body = String()
        tags = String(max_length=5, repeated=True)
        comments = Integer(min_value=0, max_value=10)

    # A valid note.
    valid_note = tokenize("""
    title: My Note
    body: This is a note
    tags: test, blog
    comments: 5
    """)

    validate_with_positions(token=valid_note, validator=Note)

    # An invalid note.

# Generated at 2022-06-12 16:02:11.215353
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str, min_length=1)

    token = Token(
        "Person",
        {
            "name": Token(
                "Field",
                value=Token(
                    "Object",
                    {
                        "test": Token(
                            "Field",
                            value=Token(
                                "Object",
                                {
                                    "missing": Token(
                                        "Field", value=Token("Primitive", value=None),
                                    )
                                },
                            ),
                        )
                    },
                ),
            )
        },
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-12 16:02:18.636468
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.types import Object
    import pytest

    field = Integer(name="foo", min_value=0)
    schema_type = Object(properties={"foo": field})

    token = Token(value={"foo": -1})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 4

    token = Token(value={"foo": -1})

# Generated at 2022-06-12 16:02:26.254659
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Array, Integer

    schema = Array(items=Integer())

    token = Token(
        type="array",
        start=Position(line=0, char_index=0),
        end=Position(line=0, char_index=1),
        parent=None,
        index=None,
        key=None,
        values=[
            Token(
                type="array",
                start=Position(line=0, char_index=0),
                end=Position(line=0, char_index=1),
                parent=None,
                index=None,
                key=None,
                values=[Token(type="integer", value=None, start=None, end=None)],
            )
        ],
    )

    with pytest.raises(ValidationError) as error:
        validate_with_pos

# Generated at 2022-06-12 16:02:36.838763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    innerfield = Field(type="string")
    schema = Schema(
        fields={
            "a": {
                "type": "object",
                "properties": {
                    "b": {"type": "string", "required": True},
                    "c": {"type": "integer", "required": False},
                },
                "additionalProperties": True,
            },
            "x": {"type": "integer", "minimum": 2},
        }
    )
    content = """
{
  "a": {
    "b": "test",
    "c": 123
  },
  "x": 3
}
"""
    token = Token(value=json.loads(content), filename="test.json")

# Generated at 2022-06-12 16:02:52.837426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, tokenize

    source = source = '{"foo": null}'
    tokens: Token = Token.root(tokenize(source))

    from typesystem import String, Integer

    class MySchema(Schema):

        foo = String(nullable=False)
        bar = Integer(nullable=False)

    try:
        validate_with_positions(token=tokens["bar"], validator=MySchema)
    except ValidationError as exc:
        assert exc.messages()[0].start_position.line == 2
        assert exc.messages()[0].start_position.char_index == 4
        assert exc.messages()[0].code == "required"
        assert exc.messages()[0].end_position.line == 2

# Generated at 2022-06-12 16:03:00.712694
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.utils import parse
    from typesystem.tokenize.tokens import Token
    from typesystem.validators import NotEmpty

    token: Token = parse(
        """{
        "field": "jim",
        "other": ""
    }"""
    )
    validator = {"field": String(validators=[NotEmpty()]), "other": String()}
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.messages[0].code == "empty"
        assert error.messages[0].text == "Field may not be empty."
        return

    assert False, "expected ValidationError"

# Generated at 2022-06-12 16:03:11.975014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Document, Object, String

    class AddressSchema(Schema):
        street = Field(type=str, required=True)
        city = Field(type=str)
        state = Field(type=str)

    class UserSchema(Schema):
        name = Field(type=str, required=True)
        email = Field(type=str, required=True)
        address = Field(type=AddressSchema)


# Generated at 2022-06-12 16:03:20.603446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizers import TypeTokenizer
    from typesystem.tokenize.tokens import TypeTokenBase
    from typesystem.tokenize.tokenizers.json import JsonTokenizer

    class MySchema(Schema):
        foo = "string"

    MyTypeToken = TypeTokenBase()

    class MyTokenizer(TypeTokenizer):
        token_class = MyTypeToken

    json_tokenizer = JsonTokenizer()
    type_tokenizer = MyTokenizer()

    data = '{"foo": [1, 2, 3]}'
    json_tokens = json_tokenizer.tokenize(data)
    type_tokens = type_tokenizer.tokenize(json_tokens.resolve())


# Generated at 2022-06-12 16:03:30.705853
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import Lexer

    schema = Schema.of(
        {
            "name": Field(required=True),
            "email": Field(required=True, primitive_type=str),
            "age": Field(required=False, primitive_type=int),
        }
    )
    lexer = Lexer()
    token = lexer.tokenize({"name": "Eric", "age": 42})
    validate_with_positions(token=token, validator=schema)

    # expected error
    token = lexer.tokenize({"name": ""})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-12 16:03:40.244775
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.exceptions import FormatError

    schema_string = "name: string, age: integer"
    tokens, _ = tokenize(schema_string)
    token = Token({"name": "Harry", "age": "twenty-one"}, tokens)

    # Valid.
    try:
        validate_with_positions(
            token=token, validator={"name": String(), "age": Integer()}
        )
    except ValidationError:
        pytest.fail("The token should be valid.")

    # Invalid.

# Generated at 2022-06-12 16:03:50.418624
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)

    try:
        validate_with_positions(
            token=Token.new_root(value={"name": "A"}), validator=Person
        )
    except ValidationError as error:
        pass
    message = error.messages[0]
    assert (
        message.text
    ) == "The field 'age' is required."  # "The field 'age' is required. (line 1, col 7)"

    person_json = """
    {
        "name": "Ned",
        "age": 29
    }
    """

# Generated at 2022-06-12 16:03:59.762224
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.message import ValidationError
    from typesystem.tokenize.tokens import ObjectToken
    
    from .test_fields import AddressSchema, PersonSchema

    from typesystem.fields import Array
    from typesystem.tokenize.tokens import ArrayToken

    token = ArrayToken(
        [
            ObjectToken({"name": "Jane", "address": {"line_1": "123 Fake St."}}),
            ObjectToken({"name": "John", "address": {"line_1": "456 R Street"}}),
        ],
        start=None,
        end=None,
    )

    array = Array(of=PersonSchema())


# Generated at 2022-06-12 16:04:10.066648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {
        "school": {
            "students": [
                {"name": "Alice", "age": 10},
                {"name": "Bob", "age": 10},
            ]
        }
    }
    schema = Schema(
        {
            "school": {
                "students": [
                    {
                        "name": Field(required=True),
                        "age": Field(required=True),
                    }
                ]
            }
        }
    )
    schema.validate(data)
    token = Token(data)
    token.lookup("school", "students")

# Generated at 2022-06-12 16:04:21.045516
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import io
    import typesystem
    from typesystem.python import (
        String,
        Number,
        Boolean,
        Integer,
        Array,
        Object,
        PythonPrimitive,
    )
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer(
        primitive_types=[
            PythonPrimitive(type=Number),
            PythonPrimitive(type=Boolean),
            PythonPrimitive(type=Integer),
            PythonPrimitive(type=String),
        ]
    )
    primitive_types = [
        PythonPrimitive(type=Number),
        PythonPrimitive(type=Boolean),
        PythonPrimitive(type=Integer),
        PythonPrimitive(type=String),
    ]


# Generated at 2022-06-12 16:04:32.470396
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array

    class DummySchema(Schema):
        field = String()

    class DummyArray(Array):
        item = DummySchema()

    class DummyObject(Schema):
        array = DummyArray()

    # Register the 'DummyObject' schema with the given name.
    DummyObject.register("dummy-object")

    from typesystem.tokenize.tokens import Token

    token = Token.parse(
        '{"array": [{"field": "1.0"}, {"field": "2.0"}, {"field": "3.0"}]}',
        name="dummy-object",
        schema_class=DummyObject,
    )


# Generated at 2022-06-12 16:04:36.706892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize
    import json

    class Comment(typesystem.Schema):
        text = typesystem.String(format="email")

    data = '{"text": "foo@example.com"}'
    token = typesystem.tokenize.tokenize(json.loads(data))

    validate_with_positions(token=token, validator=Comment)

# Generated at 2022-06-12 16:04:41.498029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.bytelike import byte_string_to_tokens
    from typesystem.tokenize.tokens import Tokens

    from . import EmployeeSchema

    schema = EmployeeSchema()
    string = b'{"name": "", "age": "twenty-two"}'
    tokens = byte_string_to_tokens(string)
    assert isinstance(tokens, Tokens)
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=tokens, validator=schema
        )

# Generated at 2022-06-12 16:04:49.678354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import JSONLexer

    lexer = JSONLexer()

    from typesystem.schemas import Schema

    from typesystem.fields import (
        StringField,
        IntegerField,
        DateTimeField,
        BooleanField,
        NumberField,
    )

    class ChildSchema(Schema):
        name = StringField()
        active = BooleanField()

    class ParentSchema(Schema):
        children = ChildSchema.as_list()

    parent = ParentSchema.load('{"children": [{"name": "Chris"}]}')

    schema = ParentSchema()
    value = schema.validate('{"children": [{"name": "Chris"}]}')
    assert isinstance(value, dict)
    assert isinstance(value["children"], list)

# Generated at 2022-06-12 16:04:59.174876
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields

    class User(Schema):
        age = fields.Integer()

    token = Token(value={"age": "?"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User)
    assert exc_info.value.messages[0].text == "The field 'age' is required."
    assert exc_info.value.messages[0].start_position == (1, 10)
    assert exc_info.value.messages[0].end_position == (1, 11)

# Generated at 2022-06-12 16:05:03.847319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.validators import String
    from typesystem.fields import Array

    tokens = tokenize_json("[null, 1]")
    validator = Array(String())
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=validator)

    error = exc_info.value
    assert error.messages[0].start_position == error.messages[1].start_position

# Generated at 2022-06-12 16:05:15.334280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import numbler
    from numbler import Schema, Number, String, Boolean

    class Person(Schema):
        name = String()
        age = Number()

    class Car(Schema):
        owner = Person()
        worth = Number()

    class Test(Schema):
        list_of_dict = [
            {
                "num": Number(),
                "str": String(),
                "bool": Boolean(),
                "obj": Person(),
            }
        ]
        list_of_obj = [Person()]
        list_of_nested_obj = [Person(), Car()]
        dict_of_dict = {
            "one": {
                "num": Number(),
                "str": String(),
                "bool": Boolean(),
                "obj": Person(),
            }
        }

# Generated at 2022-06-12 16:05:26.108998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.base import parse_string

    token = parse_string(
        '{"foo": "bar", "bar": "baz"}', format="json", parse_comments=False
    )
    string_field = String()

    # Test a normal case:
    assert validate_with_positions(token=token, validator=string_field) == "bar"

    # Test a missing field:
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(required=True))

    assert exc_info.value.messages()[0].code == "required"
    assert exc_info.value.messages()[0].start_position == (1, 9)

# Generated at 2022-06-12 16:05:29.212395
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.typesystem.tokenize.test_tokenize import tokenize
    from tests.typesystem.validate import PersonSchema

    message = "This is a test."
    tokens = tokenize(message)
    assert validate_with_positions(token=tokens, validator=PersonSchema) == {}

# Generated at 2022-06-12 16:05:36.491433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import Tokenizer

    class MySchema(Schema):
        first_name = Field(str)
        last_name = Field(str)

    tokenizer = Tokenizer()
    tokens = tokenizer.tokenize(
        {"first_name": "joey", "last_name": "joeyjoe"}, token_class=Token
    )
    try:
        validate_with_positions(
            token=next(tokens), validator=MySchema(required=["last_name"])
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'last_name' is required."

# Generated at 2022-06-12 16:05:45.932216
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import IntegerField

    field = IntegerField(min_value=1)
    token = Token(
        "integer",
        value=0,
        start={"line": 0, "column": 0, "char_index": 0},
        end={"line": 0, "column": 1, "char_index": 1},
    )
    with pytest.raises(ValidationError) as ve:
        validate_with_positions(token=token, validator=field)
    assert ve.value.messages()[0].start_position["char_index"] == 0

# Generated at 2022-06-12 16:05:50.372351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestValidator(Field):
        def validation_error(self, value, path):
            return "error"

    validator = TestValidator()
    token = Token("foo", None)

    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=validator)
    messages = e.value.messages()
    assert len(messages) == 1
    assert messages[0].start_position.char_index == 0



# Generated at 2022-06-12 16:05:58.138847
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ValueToken

    def assert_error(
        expected_actions: str,
        expected_message: str,
        actual_error: ValidationError,
        actual_actions: str,
    ) -> None:
        assert actual_actions == expected_actions
        assert len(actual_error.messages()) == 1
        message = actual_error.messages()[0]
        assert message.start_position.token_index == 0
        assert message.start_position.char_index == 2
        assert message.end_position.token_index == 0
        assert message.end_position.char_index == 3
        assert expected_message == message.text

    from typesystem.fields import Integer

    field = Integer()
    token = ValueToken("123", 3, 3)

    assert validate_with

# Generated at 2022-06-12 16:06:04.067200
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse

    class UserSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    schema = UserSchema()

    # should raise ValidationError with start_position and end_position
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=parse("{}"), validator=schema
        )

# Generated at 2022-06-12 16:06:12.399264
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token, FilePath, Position
    from typesystem.tokenize.tokens import Dict, List

    class MySchema(Schema):
        title = String()

    value = {
        "title": "test",
        "foo": "bar",
    }


# Generated at 2022-06-12 16:06:22.695923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.parser import parse_json

    @typesystem.schema
    class Subschema(typesystem.Schema):
        id = typesystem.String(max_length=10)

    @typesystem.schema
    class Schema(typesystem.Schema):
        name = typesystem.String(required=True)
        subs = Subschema(min_length=1)

    parse = parse_json("""
    {
        "subs": [
            {
                "io": "value"
            }
        ]
    }
    """)
    token = next(parse)


# Generated at 2022-06-12 16:06:24.958182
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import Integer, Schema


# Generated at 2022-06-12 16:06:34.167438
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(start="3:1", end="3:4", value="bar")

    field = String(required=True)
    try:
        value = validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line == 3
        assert message.start_position.char_index == 1
        assert message.end_position.line == 3
        assert message.end_position.char_index == 4
        assert message.text == "The field '' is required."
        assert message.index == []
        assert message.code == "required"
    else:
        assert value == "bar"

# Generated at 2022-06-12 16:06:44.446691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokenize import tokenize

    class Error(Exception):
        pass

    class Person(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer(minimum=0, maximum=100)


# Generated at 2022-06-12 16:06:50.136468
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class DogSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    class OwnerSchema(Schema):
        name = Field(type="string", required=True)
        dog = Field(type="object", schema=DogSchema, required=True)

    input = [
        {"name": "Jill", "dog": {"name": "Bruno", "age": 2}},
        {"name": "Jill", "dog": {"name": "Fluffy", "age": "puppy"}},
        {"name": "Jill", "dog": {}},
    ]


# Generated at 2022-06-12 16:06:59.895780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.position import Position

    class Person(Schema):
        name = Field()

    input_data = {
        "name": "Jack"
    }

    person_token = Token.create(
        start=Position(
            line_index=1,
            char_index=2,
            line_source="{}",
            filename="person.json",
        ),
        value=input_data,
    )

    validate_with_positions(token=person_token, validator=Person)

# Generated at 2022-06-12 16:07:07.136911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    
    from .conftest import Person
    from .conftest import assert_field_error

    data = dict(name="", email="foo@example.com")
    token = tokenize(data)
    assert_field_error(
        validate_with_positions,
        token=token,
        validator=Person,
        message="The field 'name' is required.",
        start=0,
        end=14,
    )

# Generated at 2022-06-12 16:07:14.801136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.fields import String, Boolean, Integer

    from typesystem.schemas import Schema

    from typesystem.tokenize.tokenize import tokenize_string
    from typesystem.tokenize.tokens import StringToken, IntToken, BoolToken

    from .test_tokenize import tokens_to_json

    class ColorSchema(Schema):
        red = Integer(minimum=0, maximum=255)
        green = Integer(minimum=0, maximum=255)
        blue = Integer(minimum=0, maximum=255)

        def validate_self(self, value):
            total = value["red"] + value["green"] + value["blue"]
            if total > 255:
                raise ValidationError("The total of red, green and blue must be <= 255")


# Generated at 2022-06-12 16:07:25.010282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    class PostSchema(Object):
        title = String(required=True)
        content = String()

    token = Token(
        value={
            "title": "",
            "content": "",
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=PostSchema)
    message = exc_info.value.messages()[0]

    assert isinstance(message, Message)
    assert message.text == "The field 'title' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 5
    assert message.end_position.line == 1
    assert message.end_position.char_index == 9

# Generated at 2022-06-12 16:07:29.629769
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize.tokenizers import json_tokenizer
    from typesystem.tokenize.utils import tokenize_string

    token = tokenize_string(json_tokenizer, "{}")[0]
    validate_with_positions(token=token, validator=Integer(required=True))

# Generated at 2022-06-12 16:07:32.932134
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        username = Field(type="string")

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(data={"username": "foo"}, path=[]), validator=User
        )

# Generated at 2022-06-12 16:07:41.806869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.fields import Integer as TSInteger
    from typesystem.schemas import Object
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import (
        ObjectEndToken,
        ObjectStartToken,
        PropertyToken,
    )

    class Integer(TSInteger):
        def __init__(self, min_value, max_value, **options):
            super().__init__(**options)
            self.min_value = min_value
            self.max_value = max_value

        def validate(self, value):
            try:
                value = super().validate(value)
            except ValidationError:
                raise

# Generated at 2022-06-12 16:07:50.018939
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Tests that the function validate_with_positions works as expected.
    """
    from typesystem import fields
    from typesystem.schemas import Schema
    from typesystem.tokenize.parser import parse_input
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.utils import Position

    class Person(Schema):
        name = fields.String(required=True)

    # Test an object with a non string value
    schema = Person()
    input_text = '{"name" : []}'
    token = Object(parse_input(input_text), parent=None)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

    # Test that the message has the correct start and end positions


# Generated at 2022-06-12 16:07:57.214828
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pathlib import Path
    from typesystem.schemas import Schema

    from .utils import assert_validation_errors

    class TestValidator(Schema):
        pass

    src = Path(__file__).parent.joinpath("json-file-with-positions.json")
    validator = TestValidator(fields={"id": int, "name": str, "age": int})
    validator.validate = validate_with_positions.__get__(validator, Schema)
    with open(src) as f:
        json_file = f.read()

# Generated at 2022-06-12 16:08:07.372837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List
    import json
    import typesystem
    class User(typesystem.Schema):
        name: str
        age: int

    token = Token("", value={"name": "foo"}, type="object")
    validate_with_positions(validator=User, token=token)

    token = Token("", value={"age": "foo"}, type="object")
    try:
        validate_with_positions(validator=User, token=token)
    except typesystem.ValidationError as e:
        errors: List[typesystem.Message] = e.messages()
        assert len(errors) == 1
        assert errors[0].text == "The field 'name' is required."

# Generated at 2022-06-12 16:08:26.720349
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, String
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = String()
        surname = String(required=True)
        age = String()

    schema = Person()

    token = tokenize('{"name": "Rob"}')

    output = validate_with_positions(
        token=token, validator=Person
    )

    assert output == {
        "name": "Rob",
        "surname": "",
        "age": "",
    }

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=token, validator=Person,
        )

    # Given a value with multiple errors, the error message should
    # include the position of the first error.


# Generated at 2022-06-12 16:08:37.493522
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DictionaryToken, KeyToken, ValueToken

    class SimpleSchema(Schema):
        key1 = Field(required=True)
        key2 = Field()

    class NestedSchema(Schema):
        nested = SimpleSchema()

    root = DictionaryToken(
        children={
            "key1": KeyToken(
                value="key1", start=(0, 0), end=(0, 4), parent=root,
            ),
            "key2": KeyToken(
                value="key2", start=(0, 0), end=(0, 4), parent=root,
            ),
            "nested": KeyToken(
                value="nested", start=(1, 0), end=(1, 6), parent=root,
            ),
        },
    )

# Generated at 2022-06-12 16:08:44.489221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String
    from typesystem.tokenize.types import String as StringToken
    from typesystem.tokenize.tokens import Object

    # String
    token = StringToken(value="asdf", start=0, end=4)
    validate_with_positions(token=token, validator=String)
    token = StringToken(value=None, start=0, end=4)
    with pytest.raises(ValidationError, match="The field None is required."):
        validate_with_positions(token=token, validator=String)

    # Object

# Generated at 2022-06-12 16:08:54.610700
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, Token

    # Test field type
    field = Field.integer()
    token = FieldToken(None, "json", "foo", value=["bar"])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    error = exc_info.value
    assert error.messages()[0].start_position == Token.Position(0, 0)
    assert error.messages()[0].end_position == Token.Position(0, 3)
    assert error.messages()[0].text == "Invalid literal for int() with base 10: 'bar'"
    assert error.messages()[0].code == "invalid_type"
    assert error.messages()[1].start

# Generated at 2022-06-12 16:09:05.358859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize.tokens import Document, IntegerToken

    class TestSchema(Schema):

        id = Integer(required=True)

    token = Document(
        [IntegerToken(value="1", start=(1, 2), end=(1, 3))], start=(1, 1), end=(1, 3)
    )
    errors = validate_with_positions(token=token, validator=TestSchema)
    assert errors == {"id": 1}
    token = Document([], start=(1, 1), end=(1, 3))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)
    assert len(exc_info.value.messages) == 1
    message = exc_info

# Generated at 2022-06-12 16:09:14.667843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    with open("tests/tokens/tokens.json") as f:
        token = Token.build(json.load(f))
        token = token.field("root").field("c")
        assert validate_with_positions(token=token, validator=Field(type="string"))
        try:
            validate_with_positions(token=token, validator=Field(type="number"))
        except ValidationError as error:
            # FIXME: mypy 0.723 doesn't like this line
            message = error.messages()[0]  # type: Message
            assert message.text == "Must be a number."
            assert message.code == "type_error"
            assert message.start_position.byte_index == 224
            assert message.start_position.line_index == 8

# Generated at 2022-06-12 16:09:23.418607
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:09:32.695860
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string

    # Create a schema
    from typesystem import Integer

    schema = Schema(fields={"age": Integer()})

    # Create a token
    token = parse_string("{}")

    # Convert the token into a positional message
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        positional_message = error.messages()[0]
        assert positional_message.text == "The field 'age' is required."
        assert positional_message.code == "required"
        assert positional_message.index == ("", "age")

# Generated at 2022-06-12 16:09:37.245067
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    token, errors = parse("[[1]]")
    assert errors == []
    validate_with_positions(token=token, validator=Schema(type="array", items=int))
    validate_with_positions(token=token, validator=Field(type=int))

# Generated at 2022-06-12 16:09:43.633713
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class MySchema(Schema):
        email = String(required=True)
        age = Integer()

    from . import parse, get_token

    token = get_token(parse([{"email": "test@example.com"}, {"age": "two"}]))
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=MySchema(many=True))



# Generated at 2022-06-12 16:10:09.575897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    def get_tokenize_error(value):
        try:
            tokenize(value)
        except ValidationError as error:
            token = error.messages()[0]
            return token.start_position, token.end_position

    class TestSchema(Schema):
        name = String(required=True)
        age = Integer()

    # This should fail with a detailed error message
    value = {"name": "test"}
    try:
        TestSchema.validate(value)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line == 2

# Generated at 2022-06-12 16:10:21.486335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Ensure that the error messages returned from a custom validator contain
    positional information.

    """
    from typesystem.schemas import Object, String

    class UserSchema(Schema):
        name = String()

    schema = Object(properties={"data": UserSchema()})


# Generated at 2022-06-12 16:10:21.792107
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:10:27.898998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, Text
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.validators import MaxLength

    class TestSchema(Schema):
        name = Text(validators=[MaxLength(5)])
        age = Integer()

    schema = TestSchema()
    assert validate_with_positions(
        token=tokenize({"name": "hello world", "age": "eight"}), validator=schema
    ) == {"name": "hello world", "age": 8}

# Generated at 2022-06-12 16:10:37.501573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ConversionError
    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import Token, TokenType

    from .json_schema import fake_schema

    class DummySchema(Schema):
        pass


# Generated at 2022-06-12 16:10:43.571131
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.string import String

    class MySchema(Schema):
        text = String(required=True)

    token = Token({"text": "Hi there"}, start=0, end=0)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]

    assert message.text == "The field 'text' is required."
    assert message.code == "required"
    assert message.index == ["text"]
    assert message.start_position.char_index == 0
    assert message.end_position.char_index == 0



# Generated at 2022-06-12 16:10:54.444115
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import IntegerField

    class MySchema(Schema):
        foo = IntegerField(minimum=3)
        bar = IntegerField(minimum=4)

    import json

    token = Token.parse(json.dumps({"foo": 2, "bar": 3}))
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages) == 2
        assert error.messages[0].start_position.line_number == 1
        assert error.messages[0].end_position.line_number == 1
        assert error.messages[0].start_position.char_index == 11
        assert error.messages[0].end_position.char_

# Generated at 2022-06-12 16:11:03.211376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DataToken
    from typesystem.tokenize.lexers import JsonLexer
    from tests.utils import parse_json

    class TestSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="string")

    data = parse_json('{"name": 123}')
    tokens = JsonLexer().lex(data)
    token = DataToken(data, [], tokens)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=TestSchema)
    message = excinfo.value.messages[0]
    assert message.text == 'Expected a value of type "string" for field "name".'

# Generated at 2022-06-12 16:11:12.060092
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Document
    from typesystem.tokenize.tokens import DocumentAt
    from typesystem.tokenize.tokens import String as StringToken

    document = Document(
        [
            StringToken("name", value="Chuck Norris", start=(1, 1), end=(1, 15)),
            StringToken("email", value=None, start=(2, 1), end=(2, 8)),
        ]
    )
    schema = {"name": String(max_length=10)}
    try:
        validate_with_positions(token=document, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].start_position == DocumentAt(1, 5)


