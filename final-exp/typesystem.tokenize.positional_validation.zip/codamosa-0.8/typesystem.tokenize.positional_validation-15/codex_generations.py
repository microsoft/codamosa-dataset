

# Generated at 2022-06-12 16:01:24.209333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.simple import tokenize

    field = Field(type="integer")

    text = '{"foo": 123, "bar": "abc"}'  # type: ignore
    token = tokenize(text)

    validate_with_positions(token=token, validator=field.schema)

    # Test required field
    text = '{"foo": 123}'  # type: ignore
    token = tokenize(text)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field.schema)
    assert str(exc.value) == (
        'Error message for field "bar": The field "bar" is required.'
    )

    # Test invalid type
    text = '{"foo": 123, "bar": "abc"}'  #

# Generated at 2022-06-12 16:01:34.881539
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import NoValue
    from typesystem.fields import String

    class User(Schema):
        name = String()

    data = {
        "username": "some",
        "password": "some",
        "not_required": "some",
    }
    token = Token(data, path=["root"], key="root")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=User)

    error = error.value
    assert len(error.messages()) == 3
    first_message = error.messages()[0]  # type: Message
    assert first_message.text == 'The field "name" is required.'
    assert first_message.code == "required"
    assert first_message.index == ["name"]
    assert first

# Generated at 2022-06-12 16:01:46.083030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError as SchemaValidationError

    class ItemSchema(Schema):
        name = String()
        age = Integer()

    class RootSchema(Schema):
        items = [ItemSchema()]

    class positional_message(Message):
        def __init__(self, start_position, end_position, code, index, text):
            self.start_position = start_position
            self.end_position = end_position
            self.code = code
            self.index = index
            self.text = text

    def validate_with_positions_mock(*args, **kwargs):
        token = kwargs["token"]



# Generated at 2022-06-12 16:01:54.646800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JsonSchema
    from typesystem.tokenize import tokenize

    schema = JsonSchema({
        'type': "object",
        'properties': {
            'name': {
                'type': "string",
            },
            'age': {
                'type': "integer",
            },
        },
        'required': ["name", "age"],
    })

    token = tokenize("{}")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert [
            message.text
            for message in error.messages()
            if message.text.startswith("The field")
        ] == ["The field 'name' is required.", "The field 'age' is required."]
       

# Generated at 2022-06-12 16:01:58.112369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(required=True)
    token = Token(value="hello", start=0, end=5)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)
        assert exc.start_position == 0
        assert exc.end_position == 5

# Generated at 2022-06-12 16:02:10.519579
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        first_name = Field(str)
        last_name = Field(str)

    data = {
            "last_name": "Doe",
            }
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=Token(data), validator=Person)

    assert error.value.messages[0].start_position.line == 0
    assert error.value.messages[0].end_position.line == 0
    assert error.value.messages[0].start_position.column == 7
    assert error.value.messages[0].end_position.column == 17
    assert error.value.messages[0].start_position.char_index == 7

# Generated at 2022-06-12 16:02:16.213826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.fields import Integer

    result = validate_with_positions(
        token=parse_string("{}"), validator=Integer(name="field")
    )
    assert result == Integer().validate(None)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=parse_string("{}"), validator=Integer(name="field", required=True)
        )

    assert excinfo.value.messages[0].text == "The field 'field' is required."

# Generated at 2022-06-12 16:02:22.222760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={"name": "Georges", "age": "26", "born": "Paris", "favourite_things": []},
        start=Pos(line=1, char_index=1),
        end=Pos(line=8, char_index=1),
    )

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)
        born = Field(type=str)
        favourite_things = Field(type=list, sub_of=str)

        def validate(self, value: typing.Dict[str, typing.Any]) -> typing.Dict[str, typing.Any]:
            value = super().validate(value)

# Generated at 2022-06-12 16:02:33.385168
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.positions import Position
    import pytest

    # Make sure exceptions from doctests are raised.
    pytest.register_assert_rewrite("typesystem.tokenize")

    token = Token.parse(
        b'{"a": {"b": {"c": "foo"}}, "b": ["a", "b", "c", "d", "e"], "c": 1}'
    )
    schema = Schema({"a": {}, "b": fields.Array(fields.Text()), "c": fields.Int()})

    token = token.lookup(["b", 2])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=fields.Int())


# Generated at 2022-06-12 16:02:41.610329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, tokenize_schema

    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema


    class UserSchema(Schema):
        name = String()
        age = Integer(minimum=20)

    class GroupSchema(Schema):
        name = String(required=True)
        users = Array(items=UserSchema())

    schema = GroupSchema()
    token = tokenize_schema(schema, {"name": "group"})
    assert token.value == {"name": "group"}

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=GroupSchema())

    assert error.value.messages()[0].start_position == (2, 0)

# Generated at 2022-06-12 16:02:59.002701
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem import fields, schemas
    from typesystem.tokenize import parse  # noqa
    from typesystem.base import ValidationError
    from typesystem import helpers

    class Recipe(schemas.Schema):
        title = fields.Text(max_length=200)
        ingredients = fields.List(
            fields.Record(fields={"amount": fields.Integer(), "item": fields.Text()})
        )
        origin = fields.Record(fields={"country": fields.Text(required=True)})
        servings = fields.Integer()

    data = helpers.load_json("tests/fixtures/recipe.json")
    token = parse(data)
    try:
        recipe = Recipe.validate(token)
    except ValidationError as error:
        messages = []
       

# Generated at 2022-06-12 16:03:05.727356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import json_text

    class Invoice(Schema):
        int_field = Field(type="integer")
        string_field = Field(type="string", required=True)
        items = Field(type="array", items={"type": "integer"})

    json_string = "{int_field: 1, string_field: 'hello world'} "
    token = json_text(json_string)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Invoice)

# Generated at 2022-06-12 16:03:16.772256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    token = Token(
        {
            "name": "John",
            "favourite_colours": ["green"],
            "height": 1.83,
            "hair": {"colour": "brown"},
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:03:25.889764
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.strings import String

    schema = String(min_length=1)
    message = (
        "The field '' is required."
    )
    print(message)  # coverage
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=Token(value=None), validator=schema)
    assert exc.value.messages() == [
        Message(
            text=message,
            code="required",
            index=(),
            start_position=(1, 0),
            end_position=(1, 0),
        )
    ]

# Generated at 2022-06-12 16:03:37.321804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import ast
    from typesystem.tokenize.parser import load

    validator = Field(type="string")
    token = load(ast.parse("foo"))
    validate_with_positions(token=token, validator=validator)

    token = load(ast.parse("1"))
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=validator)

    message = e.value.messages()[0]
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0

    token = load(ast.parse("(1, 2)"))
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=validator)

   

# Generated at 2022-06-12 16:03:46.991119
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_schemas import AddressSchema

    from typesystem.tokenize.tokens import (
        OffsetPosition,
        NamedToken,
        Token,
        TokenSequence,
    )

    address = AddressSchema()
    data = {
        "street": "123 Main Street",
        "city": "New York",
        "state": "NY",
        "zip": "10001",
        "country": "USA",
    }
    start_pos = OffsetPosition(line=1, column=1, char_index=0)
    end_pos = OffsetPosition(line=1, column=26, char_index=25)
    token = NamedToken(name="address", value=data, start=start_pos, end=end_pos)


# Generated at 2022-06-12 16:03:56.932425
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Text, Token
    from typesystem.schema import Schema
    from typesystem.fields import Field

    class AgeSchema(Schema):
        age = Field(type="number", required=True)

    text = "My age is 42"
    tokens = Text.parse(text)
    token = Token(value=text, tokens=tokens)
    assert validate_with_positions(token=token, validator=AgeSchema) == {
        "age": 42
    }

    token = Token(value=text, tokens=tokens)
    try:
        validate_with_positions(token=token, validator=Field(type="string"))
    except ValidationError as error:
        message = error.messages[0]

# Generated at 2022-06-12 16:04:08.942476
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        a = Field(type="integer")
        b = Field(type="integer")

    schema = TestSchema()
    token = Token(
        {
            "a": "I am not a integer",
            "b": 10,
        },
        start="a",
        end="b",
    )

# Generated at 2022-06-12 16:04:20.065137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import tokenize_json

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=tokenize_json('{"name": "Bar"}'),
            validator=Schema({"name": Field(type=str, required=True)}),
        )
    assert excinfo.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=Position(line=1, column=1, char_index=1),
            end_position=Position(line=1, column=1, char_index=1),
        )
    ]

    # With multiple errors.

# Generated at 2022-06-12 16:04:27.098835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    message = ValidationError()
    field = Field(required=True)
    text = "Hello, world!"
    tokens = []
    key = ""
    position = Position(
        line_index=0, char_index=7, line_text="Hello, world!", filename="example.txt"
    )
    tokens.append(Token(key, "Hello", position=position))
    tokens.append(Token(key, ",", position=position))
    tokens.append(Token(key, " world", position=position))
    tokens.append(Token(key, "!", position=position))

    token = Token(key, text, position=position, tokens=tokens)


# Generated at 2022-06-12 16:04:44.594851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Dict

    from typesystem.fields import Dict

    from typesystem.tokenize.parse import parse

    token = parse('{"foo": "bar"}')
    validator = Dict()
    validate_with_positions(token=token, validator=validator)

    token = parse('{"bar": "baz"}')
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as e:
        errors = e.messages()
        assert len(errors) == 1
        message = errors[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"
        assert message.index == ("foo",)
        assert message.start_position.row_index == 1
        assert message.start_position

# Generated at 2022-06-12 16:04:51.444238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.base import ValidationError
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = String()

    person = Person.validate(
        tokenize(
            """
            name:
            """,
            filename="example.yaml",
        )
    )
    assert person["name"] == ""

# Generated at 2022-06-12 16:05:02.443716
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import scan

    from .test_tokenize import data as tokenize_data


# Generated at 2022-06-12 16:05:13.577725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base_parser import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, Text, Array

    class Todo(Schema):
        id = Integer(required=True)
        description = Text(description="A description for this todo item")
        tags = Array(items=Text())

    tokens = tokenize(
        """
        {
            "id": "123",
            "description": "Buy milk",
            "tags": [
                "personal",
                "grocery"
            ]
        }
        """
    )
    token = next(tokens)

    try:
        Todo.validate(token.value)
    except ValidationError as error:
        messages = sorted(error.messages(), key=lambda m: m.position)

# Generated at 2022-06-12 16:05:14.188211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:05:25.013147
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """ Unit test for function validate_with_positions"""

    from typesystem.fields import String

    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parser import parse

    input_ = r"""
    {
        "name": null,
        "price": "x"
    }
    """

    token = parse(lex(input_))

    schema = Schema(name=String(required=True))

# Generated at 2022-06-12 16:05:32.229981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    message_list = []
    position1 = Position(line_number=2, char_index=10)
    position2 = Position(line_number=5, char_index=5)
    position3 = Position(line_number=3, char_index=15)
    expected_message1 = Message(
        text="The field 'contents' is required.",
        code="required",
        index=["contents"],
        start_position=position1,
        end_position=position1,
    )
    expected_message2 = Message(
        text="The field 'title' is required.",
        code="required",
        index=["title"],
        start_position=position2,
        end_position=position2,
    )

# Generated at 2022-06-12 16:05:42.972874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Schema
    from typesystem.fields import String

    class NameSchema(Schema):

        first = String(required=True)
        last = String(required=True)

    class PersonSchema(Schema):

        name = NameSchema(required=True)
        age = String(required=True)

    import yaml

    yaml_str = """
    age: 18
    name:
    """
    value = yaml.load(yaml_str, Loader=yaml.SafeLoader)
    token = Token.from_object(value)

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        for message in error.messages():
            assert message.end_position.line == 4
            assert message

# Generated at 2022-06-12 16:05:53.985658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.tokenize import parse_json
    from typesystem.schemas import Schema, Record

    class SimpleSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    schema = SimpleSchema()
    schema.validate({"name": "Jane", "age": 23})

    payload = json.dumps({"name": "Jane", "age": 23})
    token = parse_json(payload)
    assert token.value == {"name": "Jane", "age": 23}

    schema = SimpleSchema()
    validate_with_positions(token=token, validator=schema)

    payload = json.dumps({"age": 23})
    token = parse_json(payload)


# Generated at 2022-06-12 16:06:02.090003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    from ptpython.repl import PythonRepl
    from ptpython.python_input import PythonInput
    from ptpython.key_binding import load_key_bindings
    from ptpython.prompt_style import PromptStyle
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import TextField
    from io import StringIO
    from contextlib import contextmanager

    class Schema(Schema):
        class Meta:
            fields = [TextField(name="text")]

    # Patch input
    @contextmanager
    def mock_input(*argv):
        argv = list(argv)
        python_input = PythonInput(python_input=lambda: argv.pop(0))

# Generated at 2022-06-12 16:06:21.616792
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import pytest

    with pytest.raises(ValidationError) as e_info:
        validate_with_positions(
            token=Token(
                start=(0, 0, 0),
                end=(0, 0, 4),
                value={},
                name="test",
                line="{}",
            ),
            validator=Schema({"foo": Field(required=True)}),
        )
    assert len(e_info.value.messages) == 1
    assert e_info.value.messages[0].index == ("test", "foo")
    assert e_info.value.messages[0].text == "The field 'foo' is required."


# Generated at 2022-06-12 16:06:30.516178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    token = tokenize('{"value": "bar"}')
    token = token.lookup("value")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=String(required=True))

    assert error.value.messages() == [
        Message(
            text="The field 'value' is required",
            code="required",
            index=("value",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-12 16:06:40.510778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class MessageSchema(Schema):
        title = Field(type=str)
        body = Field(type=str)

    token = tokenize({"title": 1})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=MessageSchema,
        )
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.index == ["title"]
    assert message.text == 'expected str type, got int.'
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 8

# Generated at 2022-06-12 16:06:48.243408
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import TokenList
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    source = '{"foo": "bar", "baz": 123}'
    tokens = tokenize(source)
    assert isinstance(tokens, TokenList)
    assert len(tokens) == 4
    assert tokens[0].value == {}
    assert tokens[1].value == "bar"
    assert tokens[2].value == 123
    assert tokens[3].value == {}


    # Test that we can access the right token, given a field index.
    class MySchema(Schema):
        foo = String()
        baz = Integer()


# Generated at 2022-06-12 16:06:56.003158
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.tokens import DocumentToken
    from typesystem.tokenize import tokenize

    document = tokenize("""
    {
        "name": "Test",
        "favorite_number": 42
    }
    """)
    token = DocumentToken(document)

    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class UserSchema(Schema):
        name = String(max_length=10)
        favorite_number = Integer(minimum=0, maximum=100)

    assert isinstance(validate_with_positions(token=token, validator=UserSchema), dict)

# Generated at 2022-06-12 16:07:07.862712
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Unit test for function validate_with_positions.
    """
    from jsonschema import Draft4Validator
    from typesystem import JsonSchemaValidator
    from typesystem.validators import String

    text = """
{
    "name": "John"
}
"""


# Generated at 2022-06-12 16:07:15.181179
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Array

    schema = Schema(
        {"name": String(), "age": Integer(), "friends": Array(items=String())}
    )

    # missing required field
    token = Token.from_dict({})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(validator=schema, token=token)

    # incorrect nested field value
    token = Token.from_dict(
        {
            "name": "Bob",
            "age": "twenty-five",
            "friends": ["Alice", "Eve"],
            "address": "Home",
        }
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(validator=schema, token=token)

    # incorrect field

# Generated at 2022-06-12 16:07:25.423273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem.tokenize.tokens import (
        Token,
        ValueToken,
        PropertyToken,
        LiteralToken,
    )

    from typesystem.fields import String


# Generated at 2022-06-12 16:07:33.917873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import StructureSchema, String

    schema = StructureSchema(
        properties={
            "username": String(min_length=3, max_length=10),
            "password": String(min_length=8, max_length=50),
        },
    )

    data = {
        "value": '{"username": "abc", "password": "abc"}',
        "start": {"line": 1, "char": 1},
        "end": {"line": 1, "char": 44},
    }

    token = Token.create(data=data, location=["root"])

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:07:42.967858
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.structures import Structure, StructureMeta
    from typesystem import types
    from typesystem.tokenize import tokenize

    from test_validate import MyBool

    class ValidateWithPositionsMeta(StructureMeta):
        def __new__(mcls, name, bases, namespace):
            structure = super().__new__(mcls, name, bases, namespace)
            tokenize(structure)
            return structure

    class ValidateWithPositions(Structure):
        __metaclass__ = ValidateWithPositionsMeta

        count = types.Integer(minimum=0, maximum=3)
        count2 = types.Integer(minimum=1, maximum=2)
        count3 = types.Integer(minimum=2, maximum=3)
        count4 = types.Integer(minimum=3, maximum=4)
       

# Generated at 2022-06-12 16:08:04.639744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.components.number import NumberToken
    from typesystem.fields import Integer

    token = NumberToken(value="x", start_position=1, end_position=2)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Integer())

    assert exc_info.value.messages[0].start_position.char_index == 1

# Generated at 2022-06-12 16:08:13.161658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Tokenizer
    from typesystem.tokenize.tokens import Object, String
    from typesystem.fields import String as StringField
    from typesystem.exceptions import ValidationError

    # String field with various error messages
    field = StringField(min_length=3, max_length=5)

    # Required
    token = Object(
        {"foo": String(start=(1, 1), end=(1, 3), value="")},
        start=(0, 1),
        end=(0, 10),
    )
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        error_message = error.messages()[0]
        assert error_message.text == "The field 'foo' is required."
        assert error

# Generated at 2022-06-12 16:08:25.637642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String
    from typesystem.tokenize.tokens import TextToken, TokenList

    token = TextToken(
        value="1",
        start=TextPosition(byte_index=0, char_index=0, line_index=0, line_start=0),
        end=TextPosition(byte_index=1, char_index=1, line_index=0, line_start=0),
    )
    tokens = TokenList([token])
    validator = String(min_length=2)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=tokens, validator=validator)
    message = error_info.value.messages[0]
    assert message.text == "Must be at least 2 characters long."

# Generated at 2022-06-12 16:08:36.244103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = Token(
        "Person",
        {"name": "John", "age": "", "location": ""},
        start=(1, 1),
        end=(3, 0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=Person(), token=token)


# Generated at 2022-06-12 16:08:45.406923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from mypy_extensions import TypedDict
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token

    from typesystem import fields
    from typesystem.schemas import Schema

    SchemaDef = TypedDict(
        "SchemaDef",
        {
            "type": str,
            "fields": typing.Optional[typing.List["SchemaDef"]],
            "items": typing.Optional["SchemaDef"],
            "properties": typing.Optional(typing.Dict[str, "SchemaDef"]),
        },
    )

    def generate(schema_def: SchemaDef) -> Schema:

        class Generate(Schema):
            pass

        for key, value in schema_def.items():
            field_cls = _get

# Generated at 2022-06-12 16:08:46.226120
# Unit test for function validate_with_positions
def test_validate_with_positions():
  pass

# Generated at 2022-06-12 16:08:55.547626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    class User(Object):
        name = String(required=True)
        age = Integer(required=True)

    schema = User()

    from typesystem.tokenize import tokenize_by_type

    token = tokenize_by_type("{}")

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)

    messages = error_info.value.messages()
    assert len(messages) == 2

    name_message, age_message = messages

    assert name_message.text == "The field 'name' is required."
    assert name_message.index == ["name"]
    assert name_message.start_position == token.child(key="name").start
    assert name_message

# Generated at 2022-06-12 16:09:06.273010
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import IntegerField, TextField, ArrayField
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import (
        Token,
        TokenType,
        TokenWithChildren,
        TokenWithValue,
    )

    class Person(Schema):
        name = TextField(required=True)
        age = IntegerField()

    class User(Schema):
        name = TextField(required=True)
        person = Person()


# Generated at 2022-06-12 16:09:15.177547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Turn off deprecation warnings.
    import os
    os.environ["PYTHONWARNINGS"] = "ignore:inspect.getargspec..deprecated"

    from pathlib import Path

    from typesystem.fields import Integer, String
    from typesystem.tokenize.json_tokenizer import tokenize_string
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema

    # Replacement for `assertRaises`
    class AssertRaisesContext:
        def __init__(
            self, expected_exception: typing.Type[BaseException], test_case
        ):
            self.expected_exception = expected_exception
            self.test_case = test_case


# Generated at 2022-06-12 16:09:23.757200
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class SchemaA(typesystem.Schema):
        a = typesystem.Integer()
        b = typesystem.String()

    class SchemaB(typesystem.Schema):
        a = typesystem.String()
        b = SchemaA()


# Generated at 2022-06-12 16:10:06.991766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def run(*, schema, data, expected_error):
        try:
            actual_data = validate_with_positions(
                token=Token(schema=schema, value=data), validator=schema
            )
        except ValidationError as error:
            actual_error = str(error)
        else:
            assert data == actual_data
            return
        assert expected_error == actual_error

    schema = Schema({"a": "integer", "b": "string??"})
    run(
        schema=schema,
        data={},
        expected_error="""\
Expected a to be of type integer
    at (1:1)""",
    )

# Generated at 2022-06-12 16:10:17.775661
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.parse import parse

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token("", parse("""{
        "name": "",
        "age": "123"
    }"""))
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:10:27.870189
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        {
            "name": "alice",
            "age": "42",
            "last_name": "foo",
            "height": (1, 83),
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 10, "char_index": 12},
    )
    try:
        Person.validate(token)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "invalid_type"
        assert message.start_position

# Generated at 2022-06-12 16:10:37.465671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize import tokenize, tokenize_syntax_error
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.errors import Position, SyntaxError

    class Person(Schema):
        name = String()
        age = Integer()

    source = b'{"name": "Joe", "age": "twenty"}'
    tokens = tokenize(source)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens, validator=Person)

    assert len(exc.value.messages) == 1
    message = exc.value.messages[0]
    assert message.text == "Expected int but got str."
    assert message.code == "type"

# Generated at 2022-06-12 16:10:43.041739
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class FooSchema(Schema):
        foo = String(required=True)
        bar = String()

    schema = FooSchema()
    errors = None
    try:
        schema.validate({})
    except ValidationError as error:
        errors = error.messages()

    assert errors is not None
    assert [e.text for e in errors] == [
        "The field 'foo' is required.",
        "The field 'bar' is required.",
    ]
    assert [e.start_position.line_number for e in errors] == [1, 1]
    assert [e.start_position.char_index for e in errors] == [6, 13]

# Generated at 2022-06-12 16:10:53.736569
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Position

    token = tokenize(
        """
        {
            "id": 1,
            "name": "foo",
            "tags": [1, "foo"]
        }
        """
    )
    token = next(token)  # type: ignore

    class TagSchema(Schema):
        value = Field(int)

    class PostSchema(Schema):
        id = Field(int)
        name = Field(str)
        tags = Field(array_items=TagSchema)

    try:
        validate_with_positions(token=token, validator=PostSchema)
    except ValidationError as error:
        assert error.messages()[0].text == 'Value is not an array.'

# Generated at 2022-06-12 16:11:01.951117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Article(Schema):
        title = Field(primitive="String")
        content = Field(primitive="String")

    token = Token(
        "Article",
        start=0,
        end=13,
        children=[
            Token(
                "title",
                start=9,
                end=14,
                children=[
                    Token("StringValue", start=14, end=14, value="hello"),
                ],
            ),
            Token(
                "content",
                start=15,
                end=23,
                children=[
                    Token("StringValue", start=23, end=23, value="world"),
                ],
            ),
        ],
    )


# Generated at 2022-06-12 16:11:11.406573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        a = Field(required=True)
        b = Field(required=True)
