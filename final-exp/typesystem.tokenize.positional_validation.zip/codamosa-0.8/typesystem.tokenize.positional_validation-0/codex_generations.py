

# Generated at 2022-06-12 16:01:18.147793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String

    schema = String(max_length=3)
    token = Token("foo", start=0, end=3)
    assert validate_with_positions(token=token, validator=schema) == "foo"

    token = Token("foobar", start=3, end=6)
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)

    # error_info.value.messages() == [Message(text='Must be less than 3 characters.', start_position=3, end_position=6)]
    assert len(error_info.value.messages()) == 1
    message = error_info.value.messages()[0]
    assert message.start_position.char_index == 3

# Generated at 2022-06-12 16:01:24.629935
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class MessageSchema(typesystem.Schema):
        name = typesystem.String()
        when = typesystem.DateTime()
        deleted = typesystem.Boolean()

    token1 = Token(type='STRING', value="Hello World")
    assert not validate_with_positions(
        token=token1, validator=MessageSchema.fields["name"]
    )

    token2 = Token(type='STRING', value="2019-11-22T13:14:15")
    assert (
        validate_with_positions(token=token2, validator=MessageSchema.fields["when"])
        == "2019-11-22 13:14:15"
    )

    token3 = Token(type='BOOLEAN', value=False)

# Generated at 2022-06-12 16:01:28.364140
# Unit test for function validate_with_positions
def test_validate_with_positions():  # noqa

    from typesystem.tokenize import tokenize_json

    schema = Schema({"name": Field(str), "age": Field(int)})
    tokens = tokenize_json({"name": "bob", "age": "missing"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=schema)
    messages = exc_info.value.messages

    assert [m.code for m in messages] == ["required"]
    assert [m.index for m in messages] == [["age"]]

# Generated at 2022-06-12 16:01:37.625046
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo": "bar"}')[0]

    # Test incorrect type
    bad_token = tokenize('{"foo": "bar"}')[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=bad_token, validator=typing.List[str]
        )
    exc_info.match(
        r"Object .* must be of <class 'list'>"
    )

    # Test missing required fields
    bad_token = tokenize('{"foo": "bar"}')[0]

# Generated at 2022-06-12 16:01:41.797511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Object, fields

    class User(Schema):
        username = fields.String(min_length=1)
        password = fields.String(min_length=2)

    token = Token("root", {}, {}, {})
    token["username"] = Token("username", "guido", {}, {})
    token["password"] = Token("password", "x", {}, {})

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].code == "min_length"
        assert error.messages()[1].code == "min_length"



# Generated at 2022-06-12 16:01:52.325470
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    schema = Person()
    schema.validate_with_positions({"name": "Barry"})

    try:
        schema.validate_with_positions({"age": "abc"})
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Invalid integer value."
        assert message.code == "invalid_type"
        assert message.index == ["age"]
        assert message.start_position == token.start
        assert message.end_position == token.end


# Generated at 2022-06-12 16:01:58.518574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def test_schema(value, expected_messages):
        field = Field(text_type)
        token = Token(value)
        try:
            validate_with_positions(token=token, validator=field)
        except ValidationError as error:
            assert error.messages() == expected_messages

    test_schema("foobar", [])
    test_schema("foobar12", [])
    test_schema("foo bar", [Message(text="' ' is not a valid character.", code="invalid_character", index=0, start_position=Token.Position(line_index=1, char_index=3), end_position=Token.Position(line_index=1, char_index=4))])



# Generated at 2022-06-12 16:02:05.480585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        name = Field(required=True)

    json = {"name": "Bob"}
    schema = MySchema()

    tokens = Token.parse(json)
    assert validate_with_positions(token=tokens, validator=schema) == json

# Generated at 2022-06-12 16:02:16.287432
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Blog(Schema):
        blog_name = Field(type=str)
        blog_title = Field(type=str)

    class Entry(Schema):
        entry_title = Field(type=str)
        entry_text = Field(type=str)
        entry_date = Field(type=str)

    class BlogEntry(Blog, Entry):
        pass


# Generated at 2022-06-12 16:02:24.782189
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenize

    tokenizer = Tokenize(
        schema={"string": "string", "number": "number", "boolean": "boolean"},
        value={"string": "str", "number": 4, "boolean": True},
    )

    assert tokenizer.errors is None

    token = tokenizer.tree.lookup(["string"])
    assert token.value == "str"

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=Field(type="number", required=True)
        )
    assert str(exc_info.value) == textwrap.dedent(
        """\
        ValidationError at string:1:6
        The field 'number' is required."""
    )  #

# Generated at 2022-06-12 16:02:37.906954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize_value

    token = tokenize_value([{"name": "", "age": 33}])
    validator = Schema.of({"name": Field(), "age": Field()})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as exc:
        assert exc.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("0", "name"),
                start_position=Position(line=1, column=3, char_index=3),
                end_position=Position(line=1, column=10, char_index=10),
            )
        ]

# Generated at 2022-06-12 16:02:44.736839
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions
    from typesystem.fields import PositiveInt
    from typesystem.tokenize import tokenize, token_to_python
    from typesystem.tokenize.tokens import Token

    schema = PositiveInt()
    tokens = tokenize("{name: John, age: 40}")
    token = token_to_python(tokens[0], Token)
    validate_with_positions(token=token, validator=schema)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 14
        assert error.messages()[0].end_position.char_index == 15

# Generated at 2022-06-12 16:02:45.431720
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:02:55.481974
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from tests.support.schemas import Person
    from typesystem.tokenize.document import Document
    from typesystem.tokenize.position import Position

    text = """
        {
          "name": "foo",
          "age": 42
        }
    """
    document = Document(text=text)
    token = document.to_token()
    validator = Person()
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=validator)

    message = error_info.value.messages[0]
    assert isinstance(message.start_position, Position)
    assert isinstance(message.end_position, Position)
    assert message.start_position.line_number == 2
    assert message.start_position.char

# Generated at 2022-06-12 16:02:59.863888
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        Index(0, 0),
        Index(1, 1),
        {"foo": {"bar": {"baz": [1, 2]}, "bam": 42}},
        {},
    )
    message = ValidationError(
        messages=[
            Message("Missing field.", "required", index=("foo", "bar")),
            Message("Missing field.", "required", index=("foo", "bam")),
        ]
    )
    try:
        validate_with_positions(token=token, validator=Schema({}))
    except ValidationError as error:
        assert error.messages() == message.messages()
    else:
        assert False



# Generated at 2022-06-12 16:03:06.289002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.errors import TokenizationError
    from typesystem.tokenize.tokens import Token, ValueToken
    from typesystem.tokenize.processors import tokenize
    from typesystem.fields import String
    from typesystem import Choice

    class TestSchema(Schema):
        field = String(max_length=3)

    class TestSchema2(Schema):
        ch = Choice(choices=["a", "b", "c"])

    value = 'field: "abcd"'
    tokens = tokenize(value)

    with pytest.raises(TokenizationError):
        validate_with_positions(
            token=tokens[0][1], validator=TestSchema().get_fields()["field"]
        )
    with pytest.raises(TokenizationError):
        validate

# Generated at 2022-06-12 16:03:17.249173
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class TestValidator(Field):
        ...

    class TestSchema(Schema):
        __fields__ = {"test": TestValidator()}

    class TestSchema2(Schema):
        __fields__ = {
            "test": TestSchema(required=True, strict=True),
            "test2": int,
        }

    TestValidator.validate = lambda self, value: value + 3
    token = Token({"test": 12, "test2": 24}, "")
    assert validate_with_positions(token=token, validator=TestSchema) == {"test": 15}

    TestValidator.validate = lambda self, value: value + 3
    token2 = Token({"test3": 12, "test2": 24}, "")

# Generated at 2022-06-12 16:03:28.628015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize import validate_with_positions

    class MySchema(Schema):
        name = String(required=True)

    schema = MySchema()
    token = Token(
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=10),
        value={"name": None},
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.index == ["name"]
        assert message.text == "The field 'name' is required."
        assert message.start_position.line == 1

# Generated at 2022-06-12 16:03:39.082298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import CharPosition, Position
    from typesystem.tokenize.tokens import Token

    import json
    import sys
    import typesystem

    if sys.version_info < (3, 8):
        import pathlib2 as pathlib
    else:
        import pathlib

    data = pathlib.Path(__file__).parent.parent / "tests" / "data"
    text = (data / "example.json").read_text()
    tokens = json.loads(text)
    token = Token.from_dict(tokens)

    field = typesystem.String()

# Generated at 2022-06-12 16:03:49.091305
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import StructureSchema
    from typesystem.fields import StringField

    class MySchema(StructureSchema):
        foo = StringField(required=True)
        bar = StringField(required=False)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(value={}, start="line:1 char:0", end="line:1 char:2"),
            validator=MySchema,
        )
    messages = exc_info.value.messages()
    assert messages[0].index == ("foo",)
    assert messages[0].start_position == "line:1 char:2"
    assert messages[0].end_position == "line:1 char:2"
    assert messages[1].index == ("bar",)


# Generated at 2022-06-12 16:04:01.343086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=import-error
    from typesystem.tokenize import lex

    schema = Field(type="string")
    tokens = lex(
        schema,
        """
        "foo"
        """,
    )
    assert validate_with_positions(token=tokens[0], validator=schema) == "foo"

    schema = Field(type="string", required=True)
    tokens = lex(
        schema,
        """
        null,
        """,
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens[0], validator=schema)
    assert exc.value.messages()[0].start_position == tokens[0].start

# Generated at 2022-06-12 16:04:11.264363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import String

    schema = Schema({"foo": String()})

    json_data = json.dumps({"foo": "bar"})
    token = Token(parsejson(json_data))

    # Test no errors
    result = validate_with_positions(token=token, validator=schema)
    assert result == {"foo": "bar"}

    # Test a single error
    token = token.update(Token(parsejson(json.dumps({"bar": "baz"}))))
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = [message.to_dict() for message in error.messages()]

# Generated at 2022-06-12 16:04:22.193905
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.schemas
    import typesystem.tokenize
    import io
    import json

    def _deserialize(
        input_: io.BytesIO, schema: typesystem.schemas.Schema
    ) -> typing.Any:
        tokenizer = typesystem.tokenize.tokenize(input_, schema)
        tokens = typesystem.tokenize.group_tokens(tokenizer, schema)
        return validate_with_positions(token=tokens[0], validator=schema)

    schema = typesystem.schemas.Schema(fields=[{"name": "x", "type": "integer"}])
    input_ = io.BytesIO(b'{"x": "string"}')

# Generated at 2022-06-12 16:04:30.583316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    Schema = create_schema(
        {
            "name": String(),
            "age": Integer(minimum=0),
        }
    )

    import json
    from typesystem.tokenize.reader import Reader

    reader = Reader(
        json.dumps(
            {
                "name": "John Doe",
                "age": "not a number",
            }
        )
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=reader.read(), validator=Schema)

    exception = exc_info.value

# Generated at 2022-06-12 16:04:34.377691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        id = Field(str)
        age = Field(int)

    user_token = Token(value={"id": "bob", "age": 20})
    validate_with_positions(token=user_token, validator=User)

# Generated at 2022-06-12 16:04:43.943719
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = Field(required=True)

    class TestField(Field):
        def validate(self, value):
            if value == "sneaky":
                raise ValidationError('{"bar": "Not allowed"}')

            return value

    token = ObjectToken(
        value={"foo": "sneaky"},
        start={"line": 1, "char": 1},
        end={"line": 2, "char": 2},
    )

    class TestValidator(Schema):
        foo = TestField(required=True)
        bar = Field(required=True)

    class TestValidatorNotRequired(Schema):
        foo = Test

# Generated at 2022-06-12 16:04:50.939863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    # no exception
    token = Token(1, (1, 5))
    validate_with_positions(token=token, validator=Field(primitive="string"))
    # not required
    token = Token(1, (1, 5))
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Field(primitive="string", required=True))
    # child, but not required
    token = Token(1, (1, 5))
    token = token.add_child(
        Token(1, (1, 5)), name="child", validator=Field(primitive="string")
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Field(primitive="object"))

# Generated at 2022-06-12 16:05:02.131000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import (
        ObjectBegin,
        ObjectEnd,
        Property,
        String,
    )
    from typesystem.tokenize.utils import make_token_stream

    source = """{
        "x": 42,
        "y": ""
    }"""

    token = ObjectBegin()

    x_token = Property(key=String("x"), value=Integer(42))
    token.add_child(x_token)

    y_token = Property(key=String("y"), value=String(""))
    token.add_child(y_token)

    token.add_child(ObjectEnd())

    validator = Integer(required=True, minimum=50)

# Generated at 2022-06-12 16:05:13.239081
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    def test(schema, data, index):
        token = Token(data, index)
        with pytest.raises(ValidationError) as excinfo:
            validate_with_positions(token=token, validator=schema)
        assert len(excinfo.value.messages) == 1
        message = excinfo.value.messages[0]
        assert message.code == "required"
        assert message.index == ["foo"]
        assert message.text == "The field 'foo' is required."
        assert message.start_position == token.lookup(["foo"]).start
        assert message.end_position == token.lookup(["foo"]).end

    schema = {"foo": Integer()}

    test(schema=schema, data={}, index="dict")

# Generated at 2022-06-12 16:05:24.144708
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        required_field = "required"
        numeric_field = 1.0

    token = Token.from_value({"required_field": "foo", "numeric_field": 0.0})

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        messages: typing.List[Message] = error.messages()
        assert messages == [
            Message(
                text="The field numeric_field must be at least 1.0.",
                code="min_value",
                index=["numeric_field"],
                start_position=token.lookup_path(["numeric_field"]).start,
                end_position=token.lookup_path(["numeric_field"]).end,
            )
        ]

# Generated at 2022-06-12 16:05:34.565644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field()


# Utility function to validate an object against a field or Schema

# Generated at 2022-06-12 16:05:43.513519
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.field_mapping import FieldMapping
    from typesystem.tokenize.tokens import Token

    class BasicSchema(Schema):
        foo = FieldMapping(child=Field(required=True))

    class NestedSchema(Schema):
        foo = BasicSchema(required=True)

    class WrapperSchema(Schema):
        foo = NestedSchema(required=True)

    tokens = WrapperSchema.tokens()
    json_data = {}

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=WrapperSchema)

    assert len(excinfo.value.messages()) == 1

    message = excinfo.value.messages()

# Generated at 2022-06-12 16:05:54.104474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import Token

    class MyField(Field):
        default_error_messages = {"required": "My {index!r} field is required."}

    def test_message_positions():
        message = validate_with_positions(
            token=Token(
                value=None,
                start=0,
                end=12,
                raw="null",
                type=0,
                children=[],
                parent=None,
            ),
            validator=MyField(),
        )
        assert message.text == "My [] field is required."
        assert message.start_position[0] == 0
        assert message.start_position[1] == 0
        assert message.end_position[0] == 0
        assert message.end_position[1] == 4



# Generated at 2022-06-12 16:06:02.169486
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import Object, Field as FieldToken

    schema = Schema(first_name=String(required=True))
    object_token = Object(
        [FieldToken("first_name", None), FieldToken("last_name", None)]
    )

    error = validate_with_positions(
        token=object_token, validator=schema
    )

    assert error.messages()[0].start_position.line == 1
    assert error.messages()[0].start_position.column == 1
    assert error.messages()[0].start_position.char_index == 0

    assert error.messages()[0].end_position.line == 1

# Generated at 2022-06-12 16:06:07.011636
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    token = Token(
        "integer", '{"foo": 1, "bar": 2}', (1, 1), (1, 23), {"foo": 1, "bar": 2}
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Integer)
    error = exc_info.value

    assert error.messages()[0].start_position == (1, 3)
    assert error.messages()[0].end_position == (1, 5)



# Generated at 2022-06-12 16:06:13.619240
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TokenList

    from .helpers import get_error_messages

    token = TokenList(
        [
            ("a", "1"),
            ("b", "2"),
            ("c", "3"),
            ("d", "4"),
            ("e", "5"),
            ("f", "6"),
        ]
    ).lookup(["b", "d"])

    class Thing(Schema):
        b = Field(type="integer", required=True)
        d = Field(type="integer", required=True)

    try:
        validate_with_positions(token=token, validator=Thing)
    except ValidationError as error:
        messages = get_error_messages(error)

    assert len(messages) == 2

# Generated at 2022-06-12 16:06:23.355440
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    from typesystem.tokenize.tests.sample_schemas import Set, SampleSchema

    tokens: typing.List[Token] = parse("world", "Hello, {{ spam }}!").tokens

    result = validate_with_positions(
        token=tokens[1],
        validator=SampleSchema.get_field("spam"),
    )
    assert result == "world"

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokens[1],
            validator=SampleSchema.get_field("spam").validators[0],
        )
    assert exc_info.value.messages[0].text == "SPAM MUST BE UPPER-CASE."

# Generated at 2022-06-12 16:06:28.549161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.lexers import Lexer
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token

    from .test_tokenize import load_yaml

    name_field = String(min_length=2, max_length=4)
    root_token: Token = next(
        Parser(lexer=Lexer()).parse(load_yaml(text="""\
---
name: Adam
age: 123
pets:
    - {name: "Spot", age: 123}
    - {name: "Rover", age: 456}
"""))
    )
    validate_with_positions(
        token=root_token,
        validator=name_field,
    )

# Generated at 2022-06-12 16:06:37.263201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.tokenize.tokens import Token, Tokens
    from typesystem.validation import ValidationError

    from .utils import MockUserSchema

    tokens = Tokens.from_json(json.loads('{"name": "", "age": ""}'))

    try:
        validate_with_positions(token=tokens, validator=MockUserSchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field name is required."
        assert message.start_position.line == 0
        assert message.start_position.char_index == 8
        assert message.end_position.line == 0
        assert message.end_position.char_index == 8

# Generated at 2022-06-12 16:06:45.584589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.parse import parse

    class ExampleSchema(Schema):
        field1 = String()
        field2 = String()

    json = {"field2": "test"}
    token = parse(json)
    try:
        validate_with_positions(token=token, validator=ExampleSchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == ("field1",)
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 1
    else:
        assert False

# Generated at 2022-06-12 16:07:10.578148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    List = typing.List
    from typesystem import fields, validators, types

    class Name(Schema):
        first = fields.String(validators=[validators.max_length(10)])
        last = fields.String()

    class Person(Schema):
        name = fields.Nested(Name)
        age = fields.Integer()

    token = Token(
        {
            "name": {"first": "Foo", "last": "Bar"},
            "age": 30,
        }
    )

    validate_with_positions(token=token, validator=Person)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person({"name": {"last": str}}))

# Generated at 2022-06-12 16:07:16.682011
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest.mock import MagicMock
    from typesystem.utils.pointer import Pointer

    field = MagicMock(spec=Field)
    field.schema = {}

    # no validation errors
    field.validate = MagicMock(return_value={"a": 1})

    token = Token(
        value={"a": 1},
        start=MagicMock(spec=Pointer),
        end=MagicMock(spec=Pointer),
    )
    assert validate_with_positions(token=token, validator=field) == {"a": 1}

    # validation error
    field.validate = MagicMock(return_value={"a": 1})

# Generated at 2022-06-12 16:07:27.194325
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String  # type: ignore
    from typesystem.tokenize import tokenize, untokenize  # type: ignore

    text = "hello world"
    tokens = tokenize(text)
    assert len(tokens) == 1
    assert tokens[0].value == text
    assert tokens[0].start.char_index == 0
    assert tokens[0].end.char_index == len(text)
    for token in tokens:
        token.children = []
    result = untokenize(tokens)
    assert result == text

    field = String(min_length=12)
    try:
        validate_with_positions(token=tokens[0], validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-12 16:07:32.647047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ObjectSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    try:
        validate_with_positions(token=Token({"name": "John"}), validator=ObjectSchema)
        assert False, "Did not raise validation error."
    except ValidationError as error:
        text, position = error.messages()[0]
        assert text == "The field 'age' is required."
        assert position.column_index == 3

# Generated at 2022-06-12 16:07:41.516486
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_fields import SimpleField


# Generated at 2022-06-12 16:07:49.821723
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, TokenType

    class PersonSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    name_token = Token(value="Sarah", type=TokenType.NAME)
    age_token = Token(value="Nineteen", type=TokenType.NAME)
    token = Token(
        value={
            "name": name_token.value,
            "age": age_token.value,
        },
        type=TokenType.RECORD,
        tokens=[name_token, age_token],
    )

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        messages = error

# Generated at 2022-06-12 16:07:55.598684
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize_json, tokenize_yaml
    from typesystem.tokenize.tokens import ObjectToken, Token
    import yaml

    yaml_input = """
    first_name: John
    last_name: Smith
    age: 40
    """
    tokens = tokenize_yaml(yaml_input)

    assert len(tokens) == 3
    assert next(tokens).value == "John"
    assert next(tokens).value == "Smith"
    assert next(tokens).value == 40
    assert list(tokens) == []

    age_field = Integer(required=True, minimum=0)

    errors = []

    def error_handler(evt):
        errors.append(evt)

    object

# Generated at 2022-06-12 16:08:05.259445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class FooSchema(Schema):
        name = Field(str, required=True)
        foo = Field(str, required=True)

    token = Token.from_dict(
        {
            "foo_dict": {
                "name": "toby",
                "foo": None,  # should raise a message as required=True
            }
        }
    )
    try:
        validate_with_positions(token=token, validator=FooSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == token.start + 1
        assert message.end_position == token.end - 1  # pylint: disable=unsubscriptable-object

# Generated at 2022-06-12 16:08:12.834685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("""
        {
            "names": [{"first": "Bob"}, {"first": "Alice"}]
        }
    """, {"names": [{"first": str}]})
    try:
        validate_with_positions(token=token, validator={"names": [{"name": str}]})
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line == 4
        assert message.start_position.char_index == 20
        assert message.end_position.line == 4
        assert message.end_position.char_index == 34

# Generated at 2022-06-12 16:08:23.384219
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array

    schema = Array([{"a": 1}, {"b": 1, "c": 2}])
    token = Token.parse({"a": 2, "b": 2, "d": 1})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    assert str(error.value) == "1 error(s) occurred:\n\n{'start': None, 'end': None, 'code': 'extra_properties', 'text': 'The field {!r} is extra.', 'index': ('d',)}\n"



# Generated at 2022-06-12 16:08:57.925527
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import (
        Boolean,
        Integer,
        Number,
        Object,
        String,
    )
    from typesystem.tokenize import tokenize

    Schema = Object.of(
        {
            "name": String(),
            "age": Integer(minimum=0),
            "likes_cheese": Boolean(),
            "weight": Number(),
        }
    )

    class Position:
        def __init__(self, index: int, line: int, column: int) -> None:
            self.index = index
            self.line = line
            self.column = column

        def __repr__(self) -> str:
            return f"<Position index={self.index!r} line={self.line!r} column={self.column!r}>"  # noqa: E501



# Generated at 2022-06-12 16:09:05.612854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import FieldError

    try:
        validate_with_positions(
            token=Token({"field": ""}),
            validator=Schema({"field": Field(required=True)}),
        )
    except ValidationError as error:
        [error.messages()[0].start_position.char_index] == [1]

        assert isinstance(error, FieldError)
        assert len(error.messages()) == 1
        assert error.messages()[0].text == 'The field "field" is required.'

# Generated at 2022-06-12 16:09:14.842965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .helpers import tokenize_tree, SearchNumberField
    from .helpers import tokenize_str, BaseToken, TreeToken

    with pytest.raises(
        ValidationError,
        match=(
            r"The field 'field' is required."
            r"\ +✘ \d+:\d+\s+\|\|.+\n"
            r"\ +╰→ \d+:\d+\s+\|\|2\n"
        ),
    ):
        validate_with_positions(
            token=tokenize_tree([BaseToken("2")]), validator=SearchNumberField()
        )

# Generated at 2022-06-12 16:09:23.547211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    class Location(Schema):
        latitude = Integer(minimum=0, maximum=90)
        longitude = Integer(minimum=0, maximum=180)

    class Contact(Schema):
        name = String()
        location = Location()

    try:
        validate_with_positions(
            token=Token('''{
                "name": "Jane Doe",
                "location": {
        ''', end=(1, 29)),
            validator=Contact,
        )
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        assert messages[0].code == "required"
        assert messages[0].text == "The field 'longitude' is required."
        assert messages[0].index == ("location", "longitude")

# Generated at 2022-06-12 16:09:34.861628
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    class MySchema(Object):
        name = String(required=True)

    from typesystem.tokenize.tokens import Token

    data = {
        "name": "Herbie"
    }
    token = Token.from_python(data)
    validate_with_positions(token=token, validator=MySchema)
    # correct code should not raise errors

    data = {
        "name2": "Herbie"
    }
    token = Token.from_python(data)

# Generated at 2022-06-12 16:09:45.956733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse_token
    from typesystem.tokenize.tokenizer import tokenize  # type: ignore
    from typesystem.schemas import (
        Map,
        Reference,
        TrimmedString,
    )  # type: ignore
    from typesystem.tokenize.positions import SourceFilePosition
    from pathlib import Path

    source = """
    person:
        name: Bill
        age: 35
        """

    position = SourceFilePosition(1, 1, Path("test"))
    tokens = tokenize(source)
    token = parse_token(tokens, position)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as e:
        messages = e.messages()


# Generated at 2022-06-12 16:09:54.849221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(name="foo", type="string", required=True)
    schema = Schema({"foo": field})

    module = types.ModuleType("_test")
    module.field = field
    module.schema = schema

    doc = dedent(
        """\
        [
          {
            "foo": "bar"
          },
          {
            "foo": "baz"
          }
        ]"""
    )
    tokens = Token.parse(doc)

    assert validate_with_positions(token=tokens, validator=field) == "bar"

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokens[0][1].lookup(["foo"]), validator=field
        )  # type: ignore

# Generated at 2022-06-12 16:10:04.176316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.types import (
        Dict,
        Integer,
        Number,
        String,
        Timestamp,
    )
    from typesystem import validation

    schema = Dict(
        {"name": String(required=True), "age": Integer(), "birthday": Timestamp()}
    )

    tokens = tokenize(data)
    token = tokens.lookup(["name"])
    with pytest.raises(validation.ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert len(exc_info.value.messages()) == 4



# Generated at 2022-06-12 16:10:11.243832
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"name": Field(required=True)})
    token = Token(
        value={"name": None, "age": None},
        start=0,
        end=0,
        tokens=[
            Token(key="name", start=0, end=0),
            Token(key="age", start=0, end=0),
        ],
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        text, = error.messages
        assert text == "The field 'name' is required."
        assert text.start_position == 0
        assert text.end_position == 0

# Generated at 2022-06-12 16:10:23.270454
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_serializable
    from typesystem.types import Dict
    from typesystem.fields import Boolean, Integer, String

    schema = Dict(
        {
            "first_name": String(),
            "last_name": String(),
            "age": Integer(),
            "likes_cats": Boolean(),
        }
    )
    text = """{
        "first_name": "Jennifer",
        "last_name": "Aniston",
        "age": 50
    }"""

    value, tokens = parse_serializable(text=text)