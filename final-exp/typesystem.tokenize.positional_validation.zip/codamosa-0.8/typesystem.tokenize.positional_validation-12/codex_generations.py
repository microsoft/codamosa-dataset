

# Generated at 2022-06-12 16:01:20.530717
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import Token, Tokenizer

    class SubDocument(Schema):
        foo = String(required=True)
        bar = Integer(required=True)

    class Document(Schema):
        subdocument = SubDocument()

    text = '{"foo": "bar"}'
    tokenizer = Tokenizer(text)
    token = tokenizer.tokenize()
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Document)

# Generated at 2022-06-12 16:01:31.376565
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex

    from .utils import Position, Range

    source = """
    name: str
    version: float
    description: str
    """

    tokens = lex(source)

# Generated at 2022-06-12 16:01:34.647333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    
    from typesystem.schemas import Schema
    from typesystem.fields import Text, Integer
    from typesystem.tokenize import tokenize

    source = """
    name: Max
    age: 34
    """.strip()

    schema = Schema(fields={"name": Text(required=True), "age": Integer()})
    token = tokenize(source=source)
    assert validate_with_positions(token=token, validator=schema) == {"name": "Max", "age": 34}

# Generated at 2022-06-12 16:01:45.776698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import Token, TokenType

    class TestSchema(Schema):  # type: ignore
        name = Field(type=str)

    json = textwrap.dedent(
        """\
        {
            "name": "John Doe",
        }
        """
    )
    token = Token.from_json_string(json, TokenType.OBJECT)
    result = validate_with_positions(token=token, validator=TestSchema)
    assert result == {"name": "John Doe"}

    json = "{}"
    token = Token.from_json_string(json, TokenType.OBJECT)

# Generated at 2022-06-12 16:01:54.393071
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import FormatToken, ObjectToken, SimpleToken

    assert validate_with_positions(
        token=FormatToken(value={"name": "Luke"}),
        validator=Schema({"name": String()}),
    ) == {"name": "Luke"}

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=FormatToken(value={"name": "Luke"}),
            validator=Schema({"age": String()}),
        )

    message = exc.value.messages()[0]
    assert message.text == "The field 'age' is required."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0
   

# Generated at 2022-06-12 16:02:00.083315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import validate
    from typesystem.schemas import Schema
    from typesystem import fields
    import json

    class Example(Schema):
        name = fields.String(required=True)
        age = fields.Integer(required=True)
        tags = fields.Array(fields.String())

    token = validate(json.dumps({"name": "Joe", "tags": ["a", "b"]}))
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Example)
    assert exc.value.messages[0].text == "The field 'age' is required."
    assert exc.value.messages[0].start_position.line == 1
    assert exc.value.messages[0].start_position.char_index

# Generated at 2022-06-12 16:02:11.126825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    schema = {"name": str, "age": int}

    # missing required field
    token = Token({"age": 10})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ["name"]

    # invalid value
    token = Token({"name": "Bob", "age": "twenty"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions

# Generated at 2022-06-12 16:02:18.544770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    import bocadillo
    from bocadillo.router import Router
    from bocadillo.params import QueryParams
    from bocadillo.types import Scope, Receive, Send

    router = Router()

    @router.get("/", params=(QueryParams(String(max_length=1))))
    async def view(query: str):
        return {"query": query}

    app = bocadillo.API()

    @app.route("/")
    async def root(req: Scope, recv: Receive, send: Send):
        url = app.url_for("view", query="foo")
        error = None
        try:
            await send(await router(url))
        except ValidationError as exc:
            error = exc

    client = app.test

# Generated at 2022-06-12 16:02:26.182860
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    token = tokenize_string("{c: 1}")
    try:
        validate_with_positions(token=token, validator=Field("b", type=str))
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        message = messages[0]
        assert message.index == ("b",)
        assert message.start_position == token.children[1].start
        assert message.end_position == token.children[1].end


    def validate_string(value):
        if not isinstance(value, str):
            raise ValueError("value must be a string.")

    token = tokenize_string("{c: 1}")

# Generated at 2022-06-12 16:02:36.514226
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize import evaluate_token

    class MySchema(Schema):
        class Meta:
            allow_unknown = False

        name = String()

    q: typing.Callable[..., typing.Any] = validate_with_positions

    source = '{"name": null}'
    token = evaluate_token(token_type="object", value=source)
    with pytest.raises(ValidationError) as excinfo:
        q(token=token, validator=MySchema)
    assert str(excinfo.value) == (
        'At position: line 1, column 19: '
        'The field "name" is required.'
    )



# Generated at 2022-06-12 16:02:46.863897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        x = Field(type="number")

    def check_error(*, error: ValidationError, expected_index: str):
        assert isinstance(error, ValidationError)
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == expected_index.split(".")
        assert message.start_position  # type: ignore
        assert message.end_position  # type: ignore

    token = Token.from_json(json.dumps({"x": None}))
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        check_error(error=error, expected_index="x")


# Generated at 2022-06-12 16:02:51.818763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(required=True)
        age = Field(required=True, type="integer")

    data: typing.Dict[str, str] = {"name": "John Doe", "age": "invalid"}
    token = tokenize(data)
    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:03:00.384241
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.types import String, Integer
    from typesystem.tokenize.parser import parse_json
    from typesystem.tokenize.tokens import TokenType

    token = parse_json("{'foo': '', 'bar': 42}")
    assert token.lookup(["foo"]).type == TokenType.STRING
    assert token.lookup(["foo"]).value == ""
    schema = {
        "foo": String(),
        "bar": Integer(),
    }

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=schema)

    error = pytest.raises(ValidationError, match="Must have at least one character").value

    assert len(error.messages()) == 1
    assert error.messages()

# Generated at 2022-06-12 16:03:11.608590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import TokenType

    schema = {
        "type": "object",
        "properties": {
            "a": {"type": "string"},
            "b": {"type": "integer"},
            "c": {"type": "object"},
        },
    }

    validator = Schema(schema=schema)

    token = tokenize("{a: 'foo', b: 'bar', c: 100}")
    assert token.type == TokenType.OBJECT
    assert token.start.line_number == 1
    assert token.start.char_index == 0
    assert token.end.line_number == 1
    assert token.end.char_index == 31

# Generated at 2022-06-12 16:03:20.394480
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JsonSchema
    from typesystem.tokenize.tokens import JsonToken

    json_schema = JsonSchema(
        properties={"foo": {"type": "string"}, "bar": {"type": "number"}}
    )
    json_token = JsonToken(
        value={"foo": "Hello", "bar": "World"}, start_char=1, end_char=30
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=json_token, validator=json_schema)

# Generated at 2022-06-12 16:03:30.537436
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, Integer, String
    from typesystem.schemas import Object
    from typesystem.tokenize import parse_string
    from typesystem.tokenize.tokens import List, Object

    class ExampleSchema(Object):

        example = Integer()
        items = List([Integer()])
        field = Object({"a": Boolean(), "b": String()})

    tokens = parse_string(
        """
        {
            "example": "1",
            "items": [], 
            "field": {}
        }
        """
    )

    validated = validate_with_positions(token=tokens, validator=ExampleSchema())


    # ValidationError:
    #     '"example" expects an integer value.'
    #     This error occured at line 3, character 6, in "

# Generated at 2022-06-12 16:03:40.095414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken, StringToken
    from typesystem.tokenize.tokens import Token

    tokens = lex("""
{
    "name": "Bob",
    "age": 10,
    "siblings": ["Alice"],
    "address": {
        "line1": "",
        "line2": null
    }
}
""")

# Generated at 2022-06-12 16:03:50.182626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=float, required=True)

        class Meta:
            strict = True

    class PersonToken(Token):
        validators = [PersonSchema]

    person = """
    name:
      first: Bob
      last: Smith
    age: 36
    """
    token = tokenize(person, token_class=PersonToken)
    try:
        validated = validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        positions = [(m.start_position, m.end_position) for m in error.messages()]

# Generated at 2022-06-12 16:03:59.567899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    errors = []
    def validate_options(input : dict) -> dict:
        errors.clear()
        try:
            return validate_with_positions(
                token=Token(input),
                validator=OptionsSchema(),
            )
        except ValidationError as error:
            errors.extend(error.messages)
            return {}
    def assert_error(error_code : str, char_index : int):
        assert errors
        error = errors.pop(0)
        assert error.code == error_code
        assert error.start_position.char_index == char_index
        assert error.end_position.char_index == error.start_position.char_index + len(error.code)

    # Check valid input
    result = validate_options({"format": "csv"})

# Generated at 2022-06-12 16:04:04.512341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleSchema(Schema):
        a = Field(required=True)  # type: ignore

    from typesystem.tokenize import tokenize

    document = tokenize("{}")
    with pytest.raises(ValidationError):
        validate_with_positions(token=document, validator=SimpleSchema)



# Generated at 2022-06-12 16:04:19.501602
# Unit test for function validate_with_positions
def test_validate_with_positions():
    
    from typesystem.tokenize.factory import create_token
    from typesystem.schemas import Schema

    class BookSchema(Schema):
        title = "string"
        pages = "integer"

    class LibrarySchema(Schema):
        books = [BookSchema]

    schema = LibrarySchema()
    data = {
        "books": [
            {"title": 1, "pages": "a"},
            {"title": "a", "pages": "b"}, 
        ]
    }
    token = create_token(data)
    messages = schema.validation_messages(token)
    for message in messages:
        message.start_position.char_index
        message.end_position.char_index
        message.start_position.line_index
        message.end_position.line_index

# Generated at 2022-06-12 16:04:26.483283
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from tests.test_schemas import User, Post
    tokenize = Tokenizer(User)
    token = tokenize.tokenize(
        {"email": "", "name": "", "location": {"lat": "", "lng": ""}, "posts": []}
    )
    validate_with_positions(token=token, validator=User)
    token = tokenize.tokenize(
        {
            "email": "",
            "name": "",
            "location": {"lat": "", "lng": ""},
            "posts": [{"subject": "", "text": "", "comments": []}],
        }
    )
    validate_with_positions(token=token, validator=Post)

# Generated at 2022-06-12 16:04:33.658599
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json

    from .test_tokenize import JSON_STRING

    from .test_field import SampleField
    from .test_schema import SampleSchema

    token = tokenize_json(JSON_STRING)
    field = SampleField()
    try:
        validate_with_positions(token=token.lookup("a"), validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                code="required",
                index=["a"],
                start_position=token.lookup("a").start,
                end_position=token.lookup("a").end,
                text="The field 'a' is required.",
            )
        ]
    else:
        assert False

    schema = SampleSchema()

# Generated at 2022-06-12 16:04:43.168804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tatsu.ast import AST
    from tatsu.semantics import ModelBuilderSemantics
    from tatsu.tool import compile, model_to_str
    from tatsu.walkers import NodeWalker
    import typesystem.tokenize.tokens

    class MySemantics(ModelBuilderSemantics):
        def new_foo(self, ast):
            return typesystem.tokenize.tokens.IntermediateNode(
                "foo", ast, [], [], end_position=ast.end_position, start_position=ast.start_position
            )

        def new_bar(self, ast):
            return typesystem.tokenize.tokens.IntermediateNode(
                "bar", ast, [], [], end_position=ast.end_position, start_position=ast.start_position
            )


# Generated at 2022-06-12 16:04:50.708605
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.tokenize import (
        HTML,
        INVALID_HTML,
        INVALID_NESTED_HTML,
        INVALID_NESTED_HTML_2,
    )
    from tests.tokenize.schemas import HTMLTag
    from tests.tokenize import parse_html

    try:
        validate_with_positions(token=parse_html(INVALID_HTML), validator=HTMLTag())
    except ValidationError as error:
        assert error.code == "required"
        assert len(error.detail) == 3
        message = error.detail[0]
        assert message.start_position.line == 4
        assert message.start_position.char_index == 4
        assert message.end_position.line == 4
        assert message.end_position.char_index == 5

   

# Generated at 2022-06-12 16:05:02.020865
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from lexical.tokens import TokenType, Token
    from lexical.source import Source
    from typesystem.schemas import Object, String
    import pytest

    class Person(Object):
        name = String(required=True)

    # Test valid case
    source = Source("{ 'name': 'Joe' }", "file_path")
    token = Token(TokenType.OBJECT, {"name": Token(TokenType.STRING, "Joe")}, source)
    validated_token = validate_with_positions(token=token, validator=Person)
    assert validated_token == {"name": "Joe"}

    # Test invalid case
    source = Source("{}", "file_path")
    token = Token(TokenType.OBJECT, {}, source)

# Generated at 2022-06-12 16:05:13.049277
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import tokenize
    from typesystem.tokenize.types import Position
    from typesystem.fields import String, Integer

    class SchemaField(Field):
        def validate(self, value):
            if len(value) < 3:
                raise ValidationError("Should be at least 3 characters long.")

    class MySchema(Schema):
        fields = {"name": String()}

    text = "My name is James."
    tokens = tokenize(text)

    token = tokenize(text)[0]

# Generated at 2022-06-12 16:05:20.230037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import StringToken
    from typesystem.schemas import Object

    class MySchema(Object):
        name = String(required=True)

    assert validate_with_positions(
        token=StringToken(
            value="foo",
            start=(1, 1, 1),
            end=(1, 4, 4),
        ),
        validator=MySchema
    ) == {"name": "foo"}



# Generated at 2022-06-12 16:05:29.164863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given
    class MyField(Field):
        pass

    class MySchema(Schema):
        a = MyField()

        @classmethod
        def validate_a(cls, value: typing.Any, context: typing.Any) -> typing.Any:
            return validate_with_positions(token=value, validator=cls.b)

        def validate_b(self, value: typing.Any, context: typing.Any) -> typing.Any:
            return validate_with_positions(token=value, validator=self.c)

        def validate_c(self, value: typing.Any, context: typing.Any) -> typing.Any:
            return validate_with_positions(token=value, validator=self.f)


# Generated at 2022-06-12 16:05:35.366903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Field(typesystem.Field):
        def validate(self, value):
            if not isinstance(value, str):
                raise typesystem.ValidationError("must be a string")
            if len(value) < 10:
                raise typesystem.ValidationError("must be at least 10 characters")
    token = typesystem.tokenize.tokenize("Hello world!")
    token = token[0]
    validate_with_positions(token=token, validator=Field())
    try:
        validate_with_positions(token=token, validator=Field())
    except typesystem.ValidationError as error:
        assert error.message == "must be at least 10 characters"
        assert error.start_position.line_index == 0
        assert error.start_position.char_index == 0
        assert error.end_position

# Generated at 2022-06-12 16:05:46.664836
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Message as Message
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.token_types import TokenTypes

    @Integer.validator
    def validate_integer(value):
        if value < 10:
            raise ValidationError(["Value must be at least 10."])

    assert validate_with_positions(
        token=Token(
            type=TokenTypes.FIELD,
            value="field",
            start=0,
            end=5,
            children=[
                Token(
                    type=TokenTypes.VALUE,
                    value=1,
                    start=8,
                    end=9,
                    children=[],
                )
            ],
        ),
        validator=Integer(),
    ) == 1


# Generated at 2022-06-12 16:05:55.289858
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.tokenize.tokens import Token, Tokenizer

    token = Tokenizer.from_yaml(
        path=__file__,
        yaml_string="""
            a:
              b:
              - key: 1
              - key: two
              - key: 3
        """
    ).root_token

    class TestSchema(Schema):

        def __init__(self, *, field: Field):
            self.field = field

        @property
        def fields(self) -> typing.Dict[str, Field]:
            return {"a": self.field}

    class TestField(Field):

        def __init__(self, *, schema: typing.Type[Schema]):
            self.field = schema


# Generated at 2022-06-12 16:05:59.503291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.tokenize import test_tokenize
    from tests.tokenize.tokens import PairNode

    class S(Schema):
        name = Field(required=True)

    tokens = test_tokenize(S, PairNode("name", "ABC"))
    validate_with_positions(token=tokens, validator=S)

# Generated at 2022-06-12 16:06:09.334906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize.tokenize import tokenize

    from typesystem.schemas import Schema
    from typesystem.fields import Dict, String, Boolean

    class TestSchema(Schema):
        foo = Dict(required=True, properties={"bar": String(), "baz": Boolean()})

    schema = TestSchema()

    token = tokenize(loads('{"foo": {"bar": "hello"}}'))
    assert validate_with_positions(token=token, validator=schema) == {
        "foo": {"bar": "hello", "baz": None}
    }


# Generated at 2022-06-12 16:06:15.457002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, Position

    def test_schema_class() -> Schema:
        class TestSchema(Schema):
            field = Field(required=True)
            field2 = Field(required=True)
        return TestSchema

    formatter = validate_with_positions
    with pytest.raises(ValidationError) as error:
        formatter(
            token=Token(
                lookup=lambda path: Token(
                    value=1, start=Position(line=1, char_index=0), end=Position(line=2, char_index=0)
                )
            ),
            validator=test_schema_class(),
        )

# Generated at 2022-06-12 16:06:24.402223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.fields import Array, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class InnerSchema(Schema):
        field = String()

    class OuterSchema(Schema):
        list_field = Array(of=InnerSchema)

    json_str = """
    {
        "list_field": [
            {
                "field": "foo",
                "extra": "field"
            }
        ]
    }
    """
    tokens = tokenize(schema_class=OuterSchema, json_str=json_str)
    token = tokens["list_field"][0]


# Generated at 2022-06-12 16:06:33.798391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import io

    class BooleanField(Field):
        pass

    class JSONSchema(Schema):
        is_required = BooleanField(required=True)
        is_not_required = BooleanField()

    token = parse('{"is_not_required": null}')
    try:
        validate_with_positions(token=token, validator=JSONSchema)
    except ValidationError as ex:
        assert len(ex.messages) == 1
        assert ex.messages[0].text == 'The field "required" is missing'
        assert ex.messages[0].start_position.line == 1
        assert ex.messages[0].start_position.char_index == 18
        assert ex.messages[0].end_position.line == 1
        assert ex.messages[0].end_

# Generated at 2022-06-12 16:06:34.965920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True  # TODO

# Generated at 2022-06-12 16:06:41.557987
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Object

    schema = Object({"count": Integer(required=True)})
    data = {"count": "invalid"}
    token = Token.parse(data)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert str(error) == (
            "The field count is required (line 1, character 16)"
        )

# Generated at 2022-06-12 16:06:48.723874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError

    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Simple(Schema):
        title = Field.serializable(0)

    token = Token(
        {
            "type": "non-empty-object",
            "keys": [
                {"key": "title", "value": {"type": "string", "value": "test"}}
            ],
            "start": {"line_index": 1, "char_index": 0},
            "end": {"line_index": 2, "char_index": 0},
        }
    )

    schema = Simple()

    value = validate_with_positions(token=token, validator=schema)
    assert value == {"title": "test"}

    token = token.look

# Generated at 2022-06-12 16:07:08.730466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.lexer import Position, TokenType
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.token_types import TokenTypeKind

    source_code = """
    {
        "name": "World",
        "age": 0,
        "missing": null
    }
    """
    Person = Schema(
        {
            "name": String(),
            "age": String(required=True),
            "missing": String(required=True),
        }
    )
    lexer = Lexer(source_code)
    parser = Parser(lexer)
    tokens = parser.parse()

    token: Token


# Generated at 2022-06-12 16:07:15.244023
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import Token
    from typesystem import fields

    token = ListToken(
        value=[
            Token(
                start={"char_index": 0, "line_number": 1, "char_on_line": 0},
                end={"char_index": 3, "line_number": 1, "char_on_line": 3},
                value=1,
                key=None,
            ),
            Token(
                start={"char_index": 7, "line_number": 2, "char_on_line": 7},
                end={"char_index": 10, "line_number": 2, "char_on_line": 10},
                value=2,
                key=None,
            ),
        ]
    )


# Generated at 2022-06-12 16:07:25.526272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Tokenizer, TokenParser
    from typesystem.types import String

    tokenizer = Tokenizer()
    schema = {"type": "string"}
    parser = TokenParser(tokenizer=tokenizer, schema=schema)
    field = String(required=True)
    root = parser.parse(text="")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=root, validator=field)

    message = exc_info.value.messages[0]
    assert message.text == "'name' is required"
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line_number == 1
    assert message.end_position.char_index

# Generated at 2022-06-12 16:07:34.015794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import InvalidToken
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String()

    person = typesystem.JSON(Person)
    token = InvalidToken(
        text="{",  # Simulate missing closing bracket
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )
    try:
        person.validate(token.value)
    except typesystem.ValidationError as error:
        expected_message = "Unexpected character '{', expecting '\"'"
        assert [message.text for message in error.messages()] == [expected_message]


# Generated at 2022-06-12 16:07:37.171508
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    from .test_fields import IntField

    from .testdata import integer_schema

    tokens = tokenize(integer_schema)
    validate_with_positions(token=tokens, validator=IntField())

# Generated at 2022-06-12 16:07:46.265825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    from pygments.token import Keyword, Name
    from typesystem.tokenize import tokenize_string
    from typesystem.tokenize.tokens import Token

    class C(Object):
        name = Field(type="string")
        body = Field(type="string")

    # This should validate o.k because it has a name and a body.
    assert validate_with_positions(
        token=tokenize_string("{ name: 'foo', body: 'bar' }"), validator=C
    )

    # This shouldn't validate because there's no body.

# Generated at 2022-06-12 16:07:54.881633
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String, Object

    class Person(Schema):
        name = String(required=True, max_length=100)
        age = Integer()

    class People(Schema):
        people = Object(
            fields={"person": Person()}, min_length=1, max_length=2
        )

    import typesystem.tokenize
    import typesystem.tokenize.tokens


# Generated at 2022-06-12 16:08:05.218524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import LiteralToken

    class Author(Schema):
        name = String()

    validate_with_positions = staticmethod(validate_with_positions)

    literal_token = LiteralToken(
        start=(0, 0), end=(3, 0), value={"name": "jane doe"}, indent=None,
    )
    try:
        author = validate_with_positions(
            token=literal_token, validator=Author
        )
    except ValidationError as error:
        assert error.messages()[0].start_position == (0, len("    ") + 1)
        assert error.messages()[6].start_position == (3, 0)


# Generated at 2022-06-12 16:08:13.552825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize import tokenize

    schema = Schema(fields={"name": Field(required=True)})
    validator = schema.compile()

    token = tokenize("{}", position_start=Position(line_index=0, char_index=0))
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ["name"]
        assert message.start_position == Position(line_index=1, char_index=3)

# Generated at 2022-06-12 16:08:25.991878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: Test parsing
    # TODO: Test parsing with custom fields
    # Test parsing with Schema
    import json
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize import parse
    from typesystem.tokenize import get_tokenizer

    def assert_schema(*, text: str, schema: typing.Type[Schema]):
        tokenizer = get_tokenizer(text)
        token = parse(tokenizer=tokenizer, schema=schema)
        validate_with_positions(token=token, validator=schema)

    text = '{"foo": 1, "bar": 2}'
    schema = JSONSchema({"type": "object", "properties": {"foo": {"type": "number"}}})

# Generated at 2022-06-12 16:08:51.621059
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}, "age": {"type": "integer"}},
        "required": ["name", "age"],
    }

    class Person(Schema):
        schema = schema

    token = Token(value={"name": "John"}, start=(1, 1), end=(1, 20))
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=Person)

    # The error message should have an index and position.
    error_messages = error_info.value.messages
    assert error_messages[0].code == "required"
    assert error_messages[0].index == ("age",)
    assert error_messages[0].start_position == Position

# Generated at 2022-06-12 16:08:55.976871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Tokenize

    class Object(Schema):
        a = Field(String)
        b = Field(Integer)
        c = Field(Integer)

    tokenize = Tokenize()
    token = tokenize.tokenize_field(
        '{"a": "foo", "c": 4, "d": 4}', Object
    )
    validate_with_positions(token=token, validator=Object)



# Generated at 2022-06-12 16:09:04.424451
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    validator = String(min_length=10)
    try:
        validate_with_positions(token=tokenize("hello"), validator=validator)
    except ValidationError as exc:
        message = exc.messages()[0]
        assert message.text == "Must be at least 10 characters."
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 0
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 5

# Generated at 2022-06-12 16:09:13.962843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.schemas import JsonSchema
    from typesystem.tokenize.jsontokens import json_parse

    json_schema = JsonSchema.from_schema(
        {
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer", "minimum": 0, "maximum": 150},
            }
        }
    )

    def validate(json_value):
        root_token = json_parse(json_value)
        return validate_with_positions(token=root_token, validator=json_schema)

    assert validate(json.dumps({"name": "Joe", "age": 30}))


# Generated at 2022-06-12 16:09:23.079383
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", required=True)
    text = """{
        "name": "John Smith"
    }"""
    token = Token.tokenize(text)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    messages = excinfo.value.messages()
    start_char_index = text.index("name") + 1
    end_char_index = start_char_index + len("name")
    message = messages[0]
    assert message.index == ("name",)
    assert message.text == "The field 'name' is required."
    assert message.start_position.line_number == 2
    assert message.start_position.char_index == start_char_index
    assert message.end_position

# Generated at 2022-06-12 16:09:34.708735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize_json
    from typesystem.tokenize.tokens import (
        ArrayToken,
        FieldToken,
        NullToken,
        NumberToken,
        ObjectToken,
        StringToken,
    )

    token = tokenize_json(
        b'{"field": {"foo": [1, 2, 3, 4], "bar": {"baz": null, "qux": "xyz"}}}'
    )
    field = Field(type="integer", min_value=0, max_value=10)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    error = exc_info.value
    assert len(error.messages()) == 1

   

# Generated at 2022-06-12 16:09:45.834782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    data = b"foo: bar, name: Boo"

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize(data),
            validator=type(
                "TestSchema",
                (Schema,),
                {
                    "name": Field(max_length=5),
                    "foo": Field(required=True),
                },
            ),
        )

    messages = exc_info.value.messages()

# Generated at 2022-06-12 16:09:53.697895
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array
    from typesystem.tokenize import Tokenizer

    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    class PersonListSchema(Schema):
        people = Array(items=PersonSchema)

    tokenizer = Tokenizer(PersonListSchema)
    tokens = tokenizer.tokenize({"people": [{"name": "John Doe", "age": 20}]})
    try:
        validate_with_positions(token=tokens[0], validator=PersonListSchema)
    except ValidationError as error:
        assert error.messages() == []

# Generated at 2022-06-12 16:10:04.757431
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import TokenParser
    from typesystem.tokenize.positions import FilePosition
    from typesystem.typing import String

    parser = TokenParser("abc")
    start = FilePosition(
        file_path="test.py", line_number=1, column_number=1, char_index=0
    )
    end = FilePosition(
        file_path="test.py", line_number=1, column_number=4, char_index=3
    )
    token = Token("abc", start, end)

    error = None
    try:
        validate_with_positions(token=token, validator=String)
    except ValidationError as e:
        error = e

    assert len(error.messages()) == 1
    message = error.messages()[0]

# Generated at 2022-06-12 16:10:12.267869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_json

    class ExampleSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")

    schema = ExampleSchema()
    json_string = """
        {
            "a": "b",
            "b": "c"
        }
    """
    token = parse_json(json_string)
    assert validate_with_positions(validator=schema, token=token) == {
        "a": "b",
        "b": "c",
    }

    json_string = """
        {
            "a": "b",
            "b": 123
        }
    """
    token = parse_json(json_string)

# Generated at 2022-06-12 16:10:50.489434
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import pprint
    from typesystem.tokenize.json import tokenize_json
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class Example(Schema):
        foo = Integer(minimum=4)

    stream = io.StringIO('{"foo": 3}')
    tokens = tokenize_json(source=stream)

    try:
        validate_with_positions(token=tokens, validator=Example)
    except ValidationError as error:
        info = {
            "messages": error.messages,
            "start_position": error.start_position,
            "end_position": error.end_position,
            "text": error.text,
        }
        output = pprint.pformat(info, indent=2)
        print(output)

# Generated at 2022-06-12 16:10:56.669364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    assert validate_with_positions(
        token=Token(value=None, start=(1, 1), end=(1, 1)),
        validator=String(required=True),
    ) is None
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(value=None, start=(1, 1), end=(1, 1)),
            validator=String(),
        )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token(
                value={"foo": "bar"}, start=(1, 1), end=(1, 12),
            ),
            validator={"foo": String(required=True)},
        )

# Generated at 2022-06-12 16:11:02.205781
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        first_name = Field(required=True)
        last_name = Field(required=True)

    class Resume(Schema):
        name = Field(required=True)
        person = Field(type=Person)

    json_data = {
        "name": "Josh",
        "person": {},
    }
    tokens = Token.from_data(json_data)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens, validator=Resume)
    assert len(error.value.messages()) == 3

# Generated at 2022-06-12 16:11:11.497617
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import DocumentToken, StringToken

    class TestValue(Field):
        def validate(self, value):
            value = super().validate(value)
            if value == "error":
                message = self.error_messages["invalid"]
                raise ValidationError([message])
            return value

    def validate_string(value):
        try:
            return validate_with_positions(
                token=value,
                validator=TestValue(
                    error_messages={"invalid": "invalid input for test case"}
                ),
            )
        except ValidationError as error:
            error.as_positioned()
            raise
