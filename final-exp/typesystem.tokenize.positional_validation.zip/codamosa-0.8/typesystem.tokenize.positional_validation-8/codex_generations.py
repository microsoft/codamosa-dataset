

# Generated at 2022-06-12 16:01:21.948783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List, Type
    import json
    import typesystem
    
    # Inference tests
    assert (validate_with_positions(token=None, validator=None)) is None
    assert (validate_with_positions(token=None, validator=List[str])) is None
    
    assert (validate_with_positions(token=None, validator=typesystem.string)) is None
    assert (validate_with_positions(token=None, validator=typesystem.Schema)) is None
    assert (validate_with_positions(token=None, validator=json.JSONDecoder)) is None

# Generated at 2022-06-12 16:01:33.320715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from _test.test_tokenize import parse_sample_token

    token = parse_sample_token(
        '{["foo",{"bar":[-1,null,"baz"]}]}'
    )  # type: ignore
    schema = Schema.of(
        {
            "foo": Field(str, required=True),
            "bar": Field([{"baz": Field(str, required=True)}]),
        }
    )


# Generated at 2022-06-12 16:01:43.852512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest.mock import patch

    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = Field(str, required=True)
        id = Field(int)

    with patch.object(Schema, "validate", side_effect=validate_with_positions):
        # This is a very contrived example, but it demonstrates using a
        # different tokenize method: JSONTokenize (which produces JSON tokens
        # rather than Python tokens).
        from typesystem.tokenize.json_tokenize import JSONTokenize

        tokenizer = JSONTokenize()
        token = tokenizer.tokenize("""{"name": "Paul", "id": 28}""")
        MySchema().validate(token.value)

# Generated at 2022-06-12 16:01:50.740141
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.tokens import TokenizeError
    from typesystem.tokenize.tokens import tokens_from_json

    def get_message(
        token,
        validator,
        expected_text,
        expected_code,
        expected_start_line,
        expected_start_col,
        expected_end_line,
        expected_end_col,
    ):
        with pytest.raises(typesystem.ValidationError) as excinfo:
            validate_with_positions(token=token, validator=validator)
            assert excinfo.value.messages[0].text == expected_text
            assert excinfo.value.messages[0].code == expected_code

# Generated at 2022-06-12 16:01:57.996931
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:02:10.209685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    # pylint: disable=missing-class-docstring
    class PostSchema(Schema):
        title = Field(type="string", max_length=100)
        likes = Field(type="integer")

    tokens = [
        Token(value=10, location="", start="1:1", end="1:2"),  # type: ignore
        Token(value="", location="", start="2:1", end="2:1"),  # type: ignore
        Token(value="Hello", location="", start="3:1", end="3:6"),  # type: ignore
    ]
    input_string = "10\n\nHello"
    tokens = tokenize(input_string, tokens=tokens)


# Generated at 2022-06-12 16:02:17.522288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.schemas import String
    from typesystem.tokenize.ast import Assignment, Variable

    validator = String(max_length=5)

    left = Variable("name")
    right = Assignment(left, "Django")
    token = Token(right)

    assert validate_with_positions(
        token=token, validator=validator
    ) == "Django"

    left = Variable("name")
    right = Assignment(left, "1234567")
    token = Token(right)
    with raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-12 16:02:18.060762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:02:25.900345
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.enums import EnumField
    from typesystem.schemas import Schema
    from tests.tokenize.tokens import TokenTest, DummyToken
    from tests.tokenize.source_positions import SourcePositionTest

    dummy_token = DummyToken(
        {
            "level1": {
                "level2": {
                    "date_of_birth": "1980-01-01",
                    "gender": "MALE",
                }
            }
        }
    )

    class Person(Schema):
        date_of_birth: typing.Date
        gender: EnumField(["MALE", "FEMALE"])

    class Level1(Schema):
        level2: Person


# Generated at 2022-06-12 16:02:36.597294
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        value={
            "name": {"type": "string"},
            "age": {"type": "number"},
        },
        start=Token.Position(line=0, column=0, char_index=0),
        end=Token.Position(line=0, column=0, char_index=100),
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field age is required."
        assert message.code == "required"
        assert message.index == [1]

# Generated at 2022-06-12 16:02:46.862889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class User(Schema):
        name = Field(str)
        email = Field(str, required=False)

    body = {"name": 1, "email": "foo@bar.com"}
    token = tokenize(body)
    try:
        user = User().validate(token.value)
    except ValidationError as error:
        assert error.messages()[0].text == (
            "The field 'name' should be of type str() but got 1 instead."
        )
        assert (
            error.messages()[0].start_position.char_index
            == token.start.char_index
        )
        assert error.messages()[0].end_position.char_index == token.end.char_index

        # Test that messages sorted by start_position

# Generated at 2022-06-12 16:02:56.072086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.exceptions import TokenizeError
    from typesystem.tokenize.tokens import (
        Field,
        List,
        Map,
        Null,
        Number,
        Object,
        String,
    )
    from typesystem.tokenize.python.compiler import PythonCompiler
    from typesystem.tokenize.python.tokens import Number as PythonNumber
    from typesystem.tokenize.python.tokens import String as PythonString
    from typesystem.tokenize.python.validators import (
        Dictionary,
        List as PythonList,
    )

    tokenizer = Tokenizer()
    compiler = PythonCompiler()


# Generated at 2022-06-12 16:03:03.676653
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema_from
    from typesystem.tokenize import tokenize_from_string
    from typesystem.tokenize.tokens import Token

    token = tokenize_from_string("""
    {
        "name": "Tom",
        "age": 27,
        "friends": []
    }
    """)  # type: Token

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="number")
        friends = Field(type="array", items=Field(type="string"))

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2

# Generated at 2022-06-12 16:03:15.158483
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, Tokenizer
    from typesystem.validators import Any, Object
    f = Field(None, format="raw", validators=[Any()])

    s = Object(fields={"field": f})

    text = '{"field": null}'
    assert s.validate(text) == {"field": None}, text

    t = Tokenizer().tokenize(text)
    assert validate_with_positions(token=t, validator=s) == {"field": None}, text

    text = '{"field": null}'
    assert s.validate(text) == {"field": None}, text

    t = Tokenizer().tokenize(text)

# Generated at 2022-06-12 16:03:21.784561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Other(Field):
        pass

    class Data(Schema):
        foo = Other()

    data = {"foo": "bar"}
    token = Token(value=data)
    try:
        validate_with_positions(token=token, validator=Data)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 2



# Generated at 2022-06-12 16:03:29.525743
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    from typesystem.fields import String

    from typesystem.schemas import Schema, fields, validate_schema

    schema_validator = validate_schema(Schema)

    schema = schema_validator(
        {
            "fields": {
                "name": fields.String(
                    required=True, min_length=2, max_length=20, description="A name"
                )
            }
        }
    )
    validator = schema.lookup("name")
    tokens = [
        Token.start_record(),
        Token("name", TokenType.FIELD, (0, 0), (0, 4)),
        Token("", TokenType.VALUE, (0, 5), (0, 5)),
        Token.end_record(),
    ]


# Generated at 2022-06-12 16:03:31.148982
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: Add a test for this function.
    pass

# Generated at 2022-06-12 16:03:40.522122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = Token(
        "foo",
        [
            Token("bar", [Token("fie", [])]),
            Token("baz", [Token("bighorn", [])]),
        ],
        start=(1, 1),
        end=(1, 3),
    )
    class Foo(Schema):
        bar = Field(type="object")
        baz = Field(type="object")
    class Bar(Schema):
        fie = Field(type="object")
    class Baz(Schema):
        bighorn = Field(type="object")

    Foo.set_children({"bar": Bar, "baz": Baz})

    # Exercise

# Generated at 2022-06-12 16:03:50.811691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, Object, String
    from typesystem.schemas import RootSchema

    from typesystem.examples import petstore_v3_0_0 as petstore

    schema = petstore.OpenAPI()

    class IntegerSchema(Schema):
        field = Integer()

    class IntegerLayout(Schema):
        field = Integer()

    class NestedSchema(Schema):
        fields = Object(properties={"nested": Integer()})

    class NestedLayout(Schema):
        fields = Object(
            properties={"nested": Integer()}, layout={"fields": {"nested": 5}}
        )

    class ListSchema(Schema):
        fields = Object(properties={"values": String()})


# Generated at 2022-06-12 16:04:00.053954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import Document

    class MyError(Exception):
        pass

    class RaisingField(Field):
        def validate(self, value):
            if value == "raise":
                raise MyError("error")
            return value

    class MySchema(Schema):
        field = RaisingField()
        field_with_default = Integer(default=0)
        field_required = String(required=True)

    with pytest.raises(MyError):
        validate_with_positions(
            token=Document(value={"field": "raise"}), validator=MySchema
        )


# Generated at 2022-06-12 16:04:14.164902
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(name="my-schema", fields={"a": {"type": "integer", "required": True}})
    token = Token(
        value={},
        position=typing.NamedTuple("Position", [("line", int), ("char_index", int)])
        (1, 1),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:04:17.559311
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"a": Field(type="string")})
    token = Token({"a": "foo"})
    validate_with_positions(token=token, validator=schema)



# Generated at 2022-06-12 16:04:23.617020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    try:
        validate_with_positions(
            token=tokenize("{}", Person()), validator=Person()
        )
    except Exception as error:
        message = str(error)
        assert (
            message
            == 'The field "name" is required.\n\n'
            '1 | {}\n'
            "      ^"
        )



# Generated at 2022-06-12 16:04:31.578896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        name = Field(str)
        age = Field(str)

    def test_user():
        token = Token(
            name="user", start={"line": 1, "char": 25}, end={"line": 3, "char": 14},
        )
        token.value = {"name": "Jane", "age": 22}
        validate_with_positions(token=token, validator=UserSchema)

    with pytest.raises(ValidationError) as exc_info:
        test_user()


# Generated at 2022-06-12 16:04:39.952117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(type="string")})

    class TestToken(Token):
        start = EndPosition(line=1, char_index=1, byte_index=0)
        end = EndPosition(line=1, char_index=2, byte_index=1)
        value = {}

    token = TestToken()
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
        assert (excinfo.start_position.line, excinfo.start_position.char_index) == (1, 1)
        assert (excinfo.end_position.line, excinfo.end_position.char_index) == (1, 2)
        assert excinfo.text == "The field 'foo' is required."
        assert exc

# Generated at 2022-06-12 16:04:46.917481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.positions import Position
    field = String()
    token = Token(
        value="foo",
        start=Position(line=1, character=0),
        end=Position(line=1, character=3)
    )

    assert validate_with_positions(token=token, validator=field) == "foo"

    field = String(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    error = exc_info.value.messages[0]
    assert error.text == "The field 'value' is required."
    assert error.start_position == Position(line=1, character=0)
    assert error.end_position == Position

# Generated at 2022-06-12 16:04:59.050082
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        a = Field(type_=str, required=True)

    def assert_error(
        token: Token, validator: typing.Union[Field, typing.Type[Schema]], code: str
    ) -> None:
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            if error.messages()[0].code != code:
                raise
        else:
            raise Exception("didn't raise ValidationError")

    token = Token(
        value={
            "a": "foo",
            "b": "bar",
        }  # type: typing.Any
    )
    assert_error(token, TestSchema, "required")


# Generated at 2022-06-12 16:05:05.405545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse_value
    from typesystem.tokenize.tokens import Line, Position, Token
    from typesystem.fields import String

    schema = String(max_length=0)

    class Error(Exception):
        @property
        def messages(self):
            return [
                Message(
                    index=[],
                    code="max_length",
                    text="Ensure this value has at most 0 characters (it has 1).",
                )
            ]

    def validate(value):
        if len(value) > 0:
            raise Error


# Generated at 2022-06-12 16:05:17.181315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema

    contents = '{"foo": "bar"}'
    ast = json.loads(contents)
    schema = JSONSchema(
        {"type": "object", "properties": {"foo": {"type": "string"}}}
    )
    token = Token(
        value=ast,
        start=typesystem.Position(char_index=0, line_number=1, column_number=1),
        end=typesystem.Position(
            char_index=len(contents), line_number=1, column_number=len(contents)
        ),
    )
    validated = validate_with_positions(
        token=token, validator=schema
    )  # Valid, should not raise
    assert validated == {"foo": "bar"}


# Generated at 2022-06-12 16:05:26.992735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.primitives import String

    document = loads(
        """{"a":"foo", "b": {"ba": 1, "bb": ["a", "b", 2, 3], "bc": {"bda": 12}}}"""
    )

    token = Token(document)
    try:
        validate_with_positions(token=token, validator=String())
        assert False
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.start_position.line == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line == 12
        assert message.end_position.char_index == 25

# Generated at 2022-06-12 16:05:48.231144
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import PositionedToken

    def getpos(line, column):
        return PositionedToken(
            "", (line, column), (line, column), None, None,
        )

    start_position = getpos(1, 1)
    a = getpos(2, 1)
    b = getpos(2, 6)
    c = getpos(1, 8)
    end_position = getpos(1, 10)

    class A(Field):
        def validate(self, value):
            if value != "a":
                raise ValidationError("Must be 'a'.")

    class B(Field):
        def validate(self, value):
            if value != "b":
                raise ValidationError("Must be 'b'.")


# Generated at 2022-06-12 16:05:52.666703
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.fields import Array, Boolean, Integer
    from typesystem.tokenize import tokenize, Token

    primitive = Array[Boolean | Integer]
    schema = {
        "type": "array",
        "items": [
            {"type": "boolean"},
            {"type": "integer"},
        ],
    }
    tokens = tokenize(source="[True, 1]")
    validate_with_positions(token=tokens[0], validator=primitive)

# Generated at 2022-06-12 16:05:58.943760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.utils import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    token = tokenize('{"a": 7}')

    class MySchema(Schema):
        a = Integer()
        b = Integer()

    try:
        validate_with_positions(validator=MySchema(), token=token)
    except ValidationError as error:
        message = error.messages[0]
        start = message.start_position.char_index
        end = message.end_position.char_index
        assert start == 4
        assert end == 4

# Generated at 2022-06-12 16:06:02.672400
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions_test

    error = validate_with_positions_test.run_test()
    token = error.messages()[0]
    expected = """The field 'hi' is required."""
    assert token.text == expected  # type: ignore

# Generated at 2022-06-12 16:06:08.689829
# Unit test for function validate_with_positions
def test_validate_with_positions():  # noqa
    from typesystem.tokenize.tokenizer import Tokenizer

    tokenizer = Tokenizer(schema={"type": "string"})
    token = tokenizer.to_tokens("")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=tokenizer.schema)
    message = exc.value.messages[0]
    assert message.text == "The field 'type' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line == 1
    assert message.end_position.char_index == -1

# Generated at 2022-06-12 16:06:20.100435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(required=True), "bar": Field(required=True)})
    token = Token(
        type="object",
        value={"foo": "hello", "bar": "goodbye"},
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=30, char_index=29),
    )
    assert validate_with_positions(token=token, validator=schema) == {
        "foo": "hello",
        "bar": "goodbye",
    }


# Generated at 2022-06-12 16:06:32.314997
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=redefined-outer-name
    import pytest

    import typesystem
    from typesystem.tokenize.python import tokenize

    # pylint: disable=redefined-outer-name

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=10)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokenize({"name": "überlänge"}), validator=Person)

# Generated at 2022-06-12 16:06:43.508293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"data": {"type": "object", "properties": {"name": {"type": "string"}}}})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token(
                value={},
                lookup=lambda *a: Token(value={}, lookup=lambda *a: Token(value={}))
            ),
            validator=schema,
        )
    messages = error.value.messages
    assert messages[0].code == "required"
    assert messages[0].text == "The field 'name' is required."
    assert messages[0].start_position.char_index == 8
    assert messages[0].end_position.char_index == 8
    assert messages[0].start_position.line_number == 1

# Generated at 2022-06-12 16:06:49.439820
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    content = """
    {
      "a": 10,
      "b": 30,
      "c": "hello",
      "d": {
        "e": {
          "f": 20
        }
      },
      "g": [
        "item",
        1,
        {
          "g": 20
        }
      ]
    }
    """

    token = tokenize(content)

    expected = {
        "a": 10,
        "b": 30,
        "c": "hello",
        "d": {"e": {"f": 20}},
        "g": ["item", 1, {"g": 20}],
    }
    assert token.value == expected

    validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-12 16:06:58.143683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestField(Field):
        def validate(self, value):
            if not isinstance(value, int):
                index = [self.name]
                message = 'Expected value "{value}" to be a integer.'
                raise ValidationError([Message(message, index)])
            
    class TestSchema(Schema):
        field = TestField()
    schema = TestSchema()

    # test error with field

# Generated at 2022-06-12 16:07:34.611662
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Schema, fields

    class Person(Schema):
        name = String(required=True)
        dob = String()
        age = Integer(required=True)

    # Verify that it works normally
    token = Token(
        name="person",
        value={"name": "John", "age": 31},
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 20},
    )
    validate_with_positions(token=token, validator=Person)

    # Verify that raises error with position information
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=Person(required=True))

# Generated at 2022-06-12 16:07:43.653706
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.builder import make_token_builder

    TokenBuilder = make_token_builder("TokenBuilder", token_type="foo")

    class Mapping(Schema):
        foo = TokenBuilder.mapping("foo")

    class Sequence(Schema):
        foo = TokenBuilder.sequence("foo")

    class NestedMapping(Schema):
        foo = TokenBuilder.mapping("foo")
        bar = TokenBuilder.mapping("bar", token_type="bar")

    class SequenceWithMapping(Schema):
        foo = TokenBuilder.sequence("foo")
        key = TokenBuilder.mapping("key", token_type="bar")

    class Sequences(Schema):
        foo = TokenBuilder.sequence("foo")
        bar = TokenBuilder.sequence("bar")


# Generated at 2022-06-12 16:07:52.913410
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.position import Position

    schema = Schema(fields={"name": String()})
    token = Token(
        value={"name": None},
        start=Position(line_number=1, char_index=1, line_start=0),
        end=Position(line_number=1, char_index=5, line_start=0),
    )
    error = validate_with_positions(token=token, validator=schema)
    assert error.messages[0].start_position.line_number == 1
    assert error.messages[0].start_position.char_index == 1
    assert error.messages[0].end_position.line_number == 1
    assert error.mess

# Generated at 2022-06-12 16:07:58.209804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Test(Schema):
        foo = Field(type=int)
    try:
        validate_with_positions(token=Token("bar", [0, 0], [0, 2]), validator=Test)
        assert False
    except ValidationError as error:
        assert [error.messages()[0].text] == ["The field 'foo' is required."]
        assert [(error.messages()[0].start_position.line_index, error.messages()[0].start_position.char_index)] == [(0, 0)]
        assert [(error.messages()[0].end_position.line_index, error.messages()[0].end_position.char_index)] == [(0, 2)]

# Generated at 2022-06-12 16:08:07.794417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    token = Token(
        {"foo": {"bar": [{"baz": 1}, {"baz": "2"}, {"bam": 3}]}}
    )  # type: Token
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Integer("foo.bar.*.baz"))
    assert excinfo.value.messages() == [
        Message(
            text="Expected an integer.",
            code="type_error.integer",
            index=("foo", "bar", 1, "baz"),
            start_position=token.value["foo"]["bar"][1]["baz"],
            end_position=token.value["foo"]["bar"][1]["baz"],
        )
    ]




# Generated at 2022-06-12 16:08:14.890543
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Tokenize

    tokenizer = Tokenize()

    text = '{"foo": {"bar": "baz"}}'

    class MySchema(Schema):
        foo = {"bar": str}

    schema = MySchema()
    token = tokenizer.tokenize(text)
    validate_with_positions(token=token, validator=schema)

    text = '{"foo": {"baz": "baz"}}'

    try:
        token = tokenizer.tokenize(text)
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'bar' is required."


# Generated at 2022-06-12 16:08:24.674161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    class ExampleSchema(Schema):
        name = String()
        age = Integer()

    Schema.validate = validate_with_positions

    data = {
        "name": "Tom",
        "age": "25\n"
    }

    try:
        ExampleSchema.validate(data)
    except ValidationError as error:
        message = error.message_at([0, "age"])
        assert message.start_position.line == 1
        assert message.start_position.column == 4
        assert message.end_position.line == 2
        assert message.end_position.column == 0

# Generated at 2022-06-12 16:08:32.194008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    # Given
    from test_types import User

    text = '{"email": "", "name": "Bob"}'
    tokens = tokenize(text)

    # When
    try:
        validate_with_positions(token=tokens, validator=User)
    except ValidationError as error:
        # Then
        message = error.messages()[0]
        assert message.start_position.char_index == 13
        assert message.end_position.char_index == 13



# Generated at 2022-06-12 16:08:41.180550
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple

    class Position(namedtuple("Position", "line_index char_index")):
        def __str__(self):
            return f"{self.line_index}:{self.char_index}"

    from typesystem.tokenize.tokens import ObjectToken, TextToken

    class TestField(Field):
        def validate(self, value):
            if not value:
                raise ValidationError("Field may not be empty.")
            return value

    object_token = ObjectToken(
        start=Position(line_index=1, char_index=0),
        end=Position(line_index=2, char_index=0),
        value={"field": "value"},
    )

# Generated at 2022-06-12 16:08:51.760356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    from typesystem.tokenize.tokenizer import tokenize_json

    from .test_tokenizer import TokenTestCase

    class ItemSchema(Schema):
        test = Field(required=True)

    class ListSchema(Schema):
        items = Field(type=ItemSchema, required=True)

    text = TokenTestCase.text
    tokens = list(tokenize_json(io.StringIO(text)))


# Generated at 2022-06-12 16:09:51.468479
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """

    :return:
    """

# Generated at 2022-06-12 16:09:57.409281
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse, Position
    from typesystem.fields import String
    from typesystem.error_messages import Messages

    validator = String(required=True)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=parse(""), validator=validator)


# Generated at 2022-06-12 16:10:04.805382
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Text
    from typesystem.tokenize import tokenize

    field = Text(format="email")
    token = tokenize('{"foo":"bar"}')[0]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert exc_info.value.messages()[0].start_position == (1, 9)
    assert exc_info.value.messages()[0].end_position == (1, 9)



# Generated at 2022-06-12 16:10:08.911404
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema, fields

    class MySchema(Schema):
        name = fields.String(required=True)

    line = "{"
    line_no = 1
    character = 1
    token = Token.parse(line, MySchema)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)
    error = exc_info.value

# Generated at 2022-06-12 16:10:16.858422
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import parse
    from typesystem.tokenize.markers import new_marker_generator
    from typesystem.tokenize.types import ArrayToken

    source_code = """
    (100, 200, 300)
    """

    marker_generator = new_marker_generator()
    token = parse(
        source_code, marker_generator, types={ArrayToken: lambda x: List[Integer]}
    )
    validate_with_positions(token=token, validator=List[Integer])
    assert True

# Generated at 2022-06-12 16:10:27.287322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = String()
        age = Integer()

    token = Token(
        {
            "name": "Django Reinhardt",
            "age": 36,
        }
    )

    validate_with_positions(token=token, validator=PersonSchema)

    token = Token(
        {
            "name": None,
            "age": 36,
        }
    )

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert str(message) == 'The field "name" is required.'
        assert message.code == "required"
        assert message.index == ("name",)
        assert message.start_position.line == 1

# Generated at 2022-06-12 16:10:32.051021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import dict_token, string_token

    field = Field(type="string")
    token = dict_token({"a": string_token("foo")}, start=1, end=3)
    assert validate_with_positions(token=token, validator=field) == "foo"

# Generated at 2022-06-12 16:10:36.566170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.typing import Field

    field = Field(name="foo", primitive_type=str)
    token = Token(
        value=["foo", "bar", "baz"],
        start={"line_number": 1, "char_index": 2},
        end={"line_number": 3, "char_index": 4},
    )
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 2}
        assert error.messages()[0].end_position == {"line_number": 3, "char_index": 4}

# Generated at 2022-06-12 16:10:43.439899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    def test(token: Token, validator, expected: typing.List[typing.Any]):
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            actual = [m.text for m in error.messages()]
            assert expected == actual


# Generated at 2022-06-12 16:10:50.188747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        field = Field(int)

    schema = TestSchema()

    token = Token("{}".format({"field": 42}))

    validate_with_positions(token=token, validator=schema)

    token = Token("{}".format({"not_a_field": 42}))

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=schema)
    assert error_info.value.messages[0].start_position.char_index == 2
    assert error_info.value.messages[0].end_position.char_index == 5

    class TestSchema(Schema):
        field = Field(int, required=True)

    schema = TestSchema()
