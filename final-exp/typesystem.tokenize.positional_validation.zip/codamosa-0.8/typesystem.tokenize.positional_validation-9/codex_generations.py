

# Generated at 2022-06-12 16:01:16.940834
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex, parse

    from .fields import Date
    from .schemas import Person
    from .test_token_stream import JSON_TEXT

    tokens = lex(JSON_TEXT)
    tree = parse(tokens)
    assert tree.value == "foo"
    assert tree.name == "STRING"

    person = Person()
    assert person.fields["birth_date"].validate(tree.value) == "foo"

    date = Date(format="%Y-%m-%d")
    assert date.validate(tree.value) == "foo"

    try:
        person.validate(tree.value)
    except ValidationError as e:
        assert len(e.messages()) == 1
        message = e.messages()[0]

# Generated at 2022-06-12 16:01:24.289651
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String

    try:
        validate_with_positions(
            token=Token(
                value={"label": 123, "category_id": "A", "max_rank": 5},
                start=Position(char_index=12),
                end=Position(char_index=16),
            ),
            validator=Schema(
                {
                    "label": String(),
                    "category_id": String(),
                    "max_rank": String(pattern=r"^\d+$"),
                }
            ),
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        m = error.messages()[0]
        assert m.index == ("max_rank",)
        assert m.text == "Enter a number."
        assert m.start_

# Generated at 2022-06-12 16:01:34.956982
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize.tokens import create_token

    token = create_token(
        {
            "foo": {
                "bar": ["baz", "qux"],
                "quux": {
                    "corge": 100,
                    "grault": [1, 2, 3, 4, 5],
                    "garply": {
                        "waldo": "fred",
                        "fred": "true",
                        "plugh": "xyzzy",
                        "thud": "false",
                    },
                },
            }
        }
    )

    # No error
    assert validate_with_positions(token=token, validator=Integer) == token.value

    # Error
    with pytest.raises(ValidationError) as error_info:
        validate_with_pos

# Generated at 2022-06-12 16:01:43.288159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Test(Schema):
        a = Field(type=int)
        b = Field(type=int)

    try:
        validate_with_positions(
            token=Token({"a": 1, "b": True}), validator=Test
        )
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 6

test_validate_with_positions()

# Generated at 2022-06-12 16:01:47.770580
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(start={"char_index": 0}, value={"name":"Bob"})
    # test a valid value
    assert validate_with_positions(token=token, validator=PersonSchema) == token.value
    # test an invalid value
    with pytest.raises(ValidationError, match="The field 'age' is required."):
        validate_with_positions(token=token, validator=PersonSchema)

# Generated at 2022-06-12 16:01:52.778508
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import toml

    from .formats import TOML

    data = """
        [person]
        name = "Dave"
        age = 16

        [pet]
        name = "Bob"
    """

    token = TOML.tokenize(data)
    try:
        validate_with_positions(token=token, validator=Schema)
    except ValidationError as error:
        for message in error.messages():
            print(message)

# Generated at 2022-06-12 16:02:02.816606
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class SimpleField(Field):
        def __init__(
            self,
            *,
            required: bool,
            min_length: int,
            max_length: int,
        ):
            self.required = required
            self.min_length = min_length
            self.max_length = max_length

        def get_validators(self):
            yield self.validate_required
            yield self.validate_length

        def validate_required(self, value: str):
            if self.required and not value:
                raise ValidationError(
                    "This field is required", code="required", index=("a",)
                )

        def validate_length(self, value: str):
            length = len(value)
            if self.min_length is not None and length < self.min_length:
                raise

# Generated at 2022-06-12 16:02:07.705425
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String

    class SimpleObject(Schema):
        name = String(required=True)

    value = {"age": 12, "name": "hi"}
    token = Token(value=value)
    validate_with_positions(token=token, validator=SimpleObject)



# Generated at 2022-06-12 16:02:17.897156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import to_tokens
    from typesystem.types import String

    class ItemSchema(Schema):
        title = String()

    json = '{"title": "Hello, world!"}'
    token = to_tokens(json)

    # Validate token tree.
    assert isinstance(validate_with_positions(token=token, validator=ItemSchema), dict)

    # Check for ValidationError for missing field.
    json = '{"title": "foo"}'
    token = to_tokens(json)
    token = token.lookup(["title"])
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=String(required=True))
    assert len(exc.value.messages)

# Generated at 2022-06-12 16:02:25.785633
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token

    token = Token(
        "abcd",
        start=Token.Position(line=1, character=1),
        end=Token.Position(line=1, character=4),
        parent=Token(
            {"hello": "world"},
            start=None,
            end=None,
            parent=Token(
                {"a": {"b": {"c": "abcd"}}}
            ),
        ),
    )
    validator = Integer(required=True, allow_null=False)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-12 16:02:39.089132
# Unit test for function validate_with_positions
def test_validate_with_positions():  # type: ignore
    from typesystem.schemas import Object
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken

    class ObjectSchema(Object):
        name = String()

    token = ObjectToken(
        value={"name": None},
        start=None,
        end=None,
        parent=None,
        children=[
            ObjectToken(
                value=None,
                start=None,
                end=None,
                parent=None,
                children=[],
                lookup=None,
            )
        ],
    )

    try:
        validate_with_positions(token=token, validator=ObjectSchema)
    except ValidationError as e:
        assert len(e.messages()) == 1

# Generated at 2022-06-12 16:02:45.980980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={
            "name": {"given_name": "Jane", "family_name": "Doe"},
            "age": 23,
            "is_active": True,
            "payload": {"attributes": [{"name": "type", "value": "motorcycle"}]},
            "nicknames": [],
        },
        start=None,
        end=None,
    )
    class PersonSchema(Schema):
        name = {"given_name": str, "family_name": str}
        nicknames = [str]
        age = int
        is_active = bool
        payload = {"attributes": [{"name": str, "value": str}]}

    validate_with_positions(token=token, validator=PersonSchema)


# Generated at 2022-06-12 16:02:48.970952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=Token("bar", start="4:4", end="4:7"),
            validator=Field(type=int, required=True),
        )
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-12 16:02:58.106546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import (
        DictionaryToken,
        ListToken,
        ObjectLookupToken,
        RootToken,
    )
    from typesystem.tokenize.typesystem_tokenizer import typesystem_tokenize

    schema = Schema(
        {
            "a": Integer(),
        }
    )
    node = {
        "a": "foo",
    }
    tokens = typesystem_tokenize(node)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=schema)

    error = exc_info.value
    assert error.messages[0].start_position.line_index == 1


# Generated at 2022-06-12 16:03:09.015865
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import ExtendableSchema
    from typesystem.tokenize.tokens import Token
    from typesystem.validators import String
    import typesystem

    class NameSchema(ExtendableSchema):
        name = typesystem.String(required=True)

    class AddressSchema(ExtendableSchema):
        street = typesystem.String(required=True)
        zipcode = typesystem.String(required=True)

    class PersonSchema(ExtendableSchema):
        name = NameSchema(required=True)
        address = AddressSchema(required=True)

    class CompanySchema(ExtendableSchema):
        name = String(required=True)
        vat_id = String(required=True)

    class PersonWithCompanySchema(ExtendableSchema):
        person

# Generated at 2022-06-12 16:03:18.462809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize

    schema = Integer(required=True)
    tokens = tokenize("")
    try:
        validate_with_positions(token=tokens[0], validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 0

    schema = Integer(required=True)
    tokens = tokenize("{}")
    try:
        validate_with_positions(token=tokens[1], validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 1



# Generated at 2022-06-12 16:03:29.252936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_tokens import test_token

    from typesystem import Integer, String
    # from typesystem.schemas import Schema
    from typesystem.error_messages import CODES

    class MySchema(Schema):
        foo = String()
        bar = Integer()

    text = '{"foo": "hi", "bar": 22}'
    token = test_token(text)
    token = token.children[0]
    assert validate_with_positions(token=token, validator=MySchema()) == {
        "foo": "hi",
        "bar": 22,
    }

    text = '{"foo": "hi"}'
    token = test_token(text)
    token = token.children[0]

# Generated at 2022-06-12 16:03:38.917727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, min_length=1)

    with pytest.raises(ValidationError) as exc_info:
        token = Token.parse("{}")
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=Position(text="{}", line=1, column=2, byte_index=1, char_index=2),
            end_position=Position(text="{}", line=1, column=2, byte_index=1, char_index=2),
        )
    ]

# Generated at 2022-06-12 16:03:46.771381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ExampleSchema(Schema):
        fields = [
            Field("name", description="The name of the widget."),
            Field("quantity", type="integer"),
        ]

    token = Token(
        raw="{name: 'foo', quantity: 100}",
        lookup=lambda path: Token(
            raw="foo", start={"line": 1, "index": 7}, end={"line": 1, "index": 10}
        ),
    )
    assert validate_with_positions(token=token, validator=ExampleSchema) == {
        "name": "foo",
        "quantity": 100,
    }

# Generated at 2022-06-12 16:03:56.316955
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(name="Test Schema", fields=[Field(name="foo", required=True)])
    token = Token("foo", {}, {}, {})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"
        assert message.index == []
        assert message.start_position.line == 0
        assert message.start_position.char_index == 0
        assert message.end_position.line == 0
        assert message.end_position.char_index == 2
    else:
        assert False, "Expected ValidationError"



# Generated at 2022-06-12 16:04:13.230575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, String
    from typesystem.tokenize.tokens import ValueToken
    from typesystem.tokenize.errors import TokenizationError

    schema = Array(items=String(min_length=2, max_length=2))
    token = ValueToken(["foo", "a"])
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert (
            error.messages()[0].text
            == "Must have exactly 2 items. Got 1 too many."
        )
        assert error.messages()[0].code == "length"
        assert error.messages()[0].index == [2]

# Generated at 2022-06-12 16:04:19.836055
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        foo = Field(required=True)

    assert validate_with_positions(
        token=Token.parse('{"foo": "bar"}'), validator=TestSchema
    ) == {"foo": "bar"}

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token.parse('{}'), validator=TestSchema
        )

# Generated at 2022-06-12 16:04:27.756570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    class Person(Schema):
        name = Integer()
        surname = Integer()

    try:
        validate_with_positions(
            token=Token(value={"name": "Bob"}), validator=Person()
        )
    except ValidationError as error:
        assert error.messages()[0].text == 'The field "surname" is required.'
        assert (
            [
                message.start_position.line_number
                for message in error.messages()
            ]
            == [1, 1]
        )
        assert (
            [
                message.start_position.char_index
                for message in error.messages()
            ]
            == [10, 10]
        )
    else:
        assert False, "Expected an error"  # pragma:

# Generated at 2022-06-12 16:04:34.401708
# Unit test for function validate_with_positions
def test_validate_with_positions():  # noqa: D103
    from typesystem.tokenize.tokens import parse_ints

    # Schema
    class MySchema(Schema):
        a_field = Field(type=["string"])
        another_field = Field(type=["integer"])

    # Error
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=parse_ints("{a_field: '1', another_field: '2'}"), validator=MySchema
        )

    # Error messages

# Generated at 2022-06-12 16:04:43.985159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import tokenize_string, tokenize_gettysburg
    from typesystem.tokenize.tokens import Token

    # Valid string
    token = tokenize_string("hello world")
    assert token.start == token.end

    # Invalid string
    token = Token(value="hello world", start=token.start, end=token.end)
    try:
        validate_with_positions(token=token, validator=String(min_length=12))
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].code == "min_length"
        assert messages[0].text == "Must be at least 12 characters long."
        assert messages[0].index == []

# Generated at 2022-06-12 16:04:50.346380
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer

    token_stream = tokenize('{"x": 5}')
    token = next(token_stream)
    assert validate_with_positions(token=token, validator=Integer()) == 5

    from typesystem import Integer

    schema = Integer(required=True)
    token_stream = tokenize('{}')
    token = next(token_stream)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position == Position(
            line_index=0, char_index=0
        )

# Generated at 2022-06-12 16:05:01.981983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.integer import Integer
    from typesystem.tokenize.parse import parse
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        age = Integer(minimum=18, maximum=120)

    code = """
        {
            "age": "age-value"
        }
        """
    tokens = list(tokenize(code))
    token = tokens[0]
    assert token.typ == "object"

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)
    messages = exc.value.messages()

    message = messages[0]
    assert (
        message.text == 'Invalid value "age-value" for field "age".'
        ' Must be an integer.'
    )
   

# Generated at 2022-06-12 16:05:12.958099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from test_tokenize import test_tokenize

    from typesystem.base import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        first_name = String(min_length=3, max_length=100)
        last_name = String(min_length=3, max_length=100)

    schema = PersonSchema()
    tokens = test_tokenize("""{
        "first_name": "John",
        "last_name": "Smith"
    }""")
    validate_with_positions(token=tokens, validator=schema)

    tokens = test_tokenize("""{
        "first_name": "John",
        "last_name": "Sm"
    }""")

# Generated at 2022-06-12 16:05:23.916385
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String

    token = Token(name="a string", type="string", value="hello", start=(1, 2), end=(1, 7))
    validator = String(min_length=3)
    validate_with_positions(token=token, validator=validator)

    token = Token(name="an integer", type="integer", value=4, start=(1, 2), end=(1, 7))
    validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-12 16:05:32.668836
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.utils import StartPosition

    tokenizer = Tokenizer(
        names=["a", "b"],
        validators=[int, int],
        delimiter=".",
    )

    # Success
    value = "10.20"
    token = tokenizer.tokenize(value)
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=tokenizer.validator) == [10, 20]

    # Failure
    value = "10.20.30"
    token = tokenizer.tokenize(value)
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_

# Generated at 2022-06-12 16:05:55.957957
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Object
    import typesystem.tokenize
    import typesystem.tokenize.tokens
    import typesystem.tokenize.parser

    class TestSchema(Object):
        a_int = Integer()

    source = """
    {
    "a": "foo",
    "b": "bar"
    }
    """

    tokens = typesystem.tokenize.tokens.parse_tokens(
        source, filename="<test_validate_with_positions>"
    )
    tree = typesystem.tokenize.parser.parse(tokens)
    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(token=tree, validator=TestSchema)

    assert len

# Generated at 2022-06-12 16:06:06.223774
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Movie(typesystem.Schema):
        name = typesystem.String()
        year = typesystem.String()
        duration = typesystem.Integer(minimum=60)

    class MovieList(typesystem.Schema):
        movies = typesystem.Array(item=Movie)


# Generated at 2022-06-12 16:06:12.894913
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:06:23.027699
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.utils import JSONSchemaError
    from typesystem.tokenize import tokenize_json

    errors = validate_with_positions(
        token=tokenize_json('{"age": "twenty"}'),
        validator=Schema(
            {
                "name": str,
                "role": str,
                "age": int,
            }
        ),
    )

    assert errors == {
        "name": "The field name is required.",
        "role": "The field role is required.",
    }


# Generated at 2022-06-12 16:06:28.348020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class AddressSchema(Schema):
        city = Field(type="string")
        postal_code = Field(type="string")

    class PersonSchema(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string", required=True)
        age = Field(type="integer")
        address = Field(type=AddressSchema)

    schema = PersonSchema(required=["first_name", "last_name"])
    string = """
        {
            "first_name": "Alice",
            "age": 12,
            "address": {
                "city": "London",
                "postal_code": "SW1 1AA"
            }
        }
    """
    from typesystem.tokenize import tokenize

    token = tokenize(string)

# Generated at 2022-06-12 16:06:37.761063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import List
    from typesystem.tokenize.tokens import Literal
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokens import String as StringToken

    class Comment(Schema):
        user = String()

    class Post(Schema):
        title = String(required=True)
        comments = List(items=Comment)


# Generated at 2022-06-12 16:06:46.740121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.exceptions import TokenizationError

    class Simple(Schema):
        name = String(max_length=25)
        age = Integer()

    try:
        validate_with_positions(
            token=tokenize("{age: 'foo', name: 'bar'}"), validator=Simple
        )
    except TokenizationError as error:
        # Unit test for function validate_with_positions
        assert error.message.start_position.line_index == 0
        assert error.message.start_position.char_index == 5
        assert error.message.end_position.line_index == 0
        assert error.message.end_position.char_index == 8

# Generated at 2022-06-12 16:06:56.960339
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.basic_types import (
        Array,
        Boolean,
        Float,
        Integer,
        Null,
        Object,
    )
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    def lookup(token, key):
        if isinstance(token, Token):
            return token.lookup([key])
        elif isinstance(token, list):
            return token[key]

    def validate(
        *,
        value: typing.Any,
        validator: typing.Union[Field, typing.Type[Schema]],
        value_type: typing.Type[Token]
    ) -> None:
        token = value_type(value=value)
        validate_with_positions(token=token, validator=validator)

   

# Generated at 2022-06-12 16:07:09.702211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Boolean
    from typesystem.tokenize.tokens import ArrayToken

    token = ArrayToken(
        [
            Boolean(value=True),
            Boolean(value=False),
            Boolean(value=True),
            Boolean(value=True),
        ],
        schema=[Boolean()],
        source="",
        start_position=None,
        end_position=None,
    )
    validate_with_positions(token=token, validator=token.schema[0])

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Boolean(required=True))
    # It has the right number of errors:
    assert len(exc_info.value.messages()) == 4
    # Each of the errors are at the

# Generated at 2022-06-12 16:07:16.177750
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Define a field that always succeeds
    field = Field()

    # Define a field that always fails
    class FailField(Field):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.validators = []

        def validate(self, value):
            raise ValidationError(messages=[Message(code="invalid")])

    # An empty dictionary should fail
    token = Token.from_data({})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=FailField())
    messages = exc.value.messages
    assert len(messages) == 1
    assert messages[0].start_position.line == 1

# Generated at 2022-06-12 16:07:53.412051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class BasicValidator(Schema):
        title = Field(type="string", required=True)
        body = Field(type="string", required=True)

    token = Token(
        type="object",
        value={"title": "This is a title", "body": "This is a body"},
        children=[
            Token(type="string", value="This is a title"),
            Token(type="string", value="This is a body"),
        ],
        start=1,
        end=2,
    )
    # This should not raise an exception
    validate_with_positions(token=token, validator=BasicValidator)

    token = Token(type="object", value={}, start=1, end=2)
    # This should raise an exception

# Generated at 2022-06-12 16:08:04.437413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Name(Schema):
        first = Field(required=True)
        last = Field(required=True)

    data = {"first": "Dan", "last": "Callahan"}
    token = Token(value=data)
    assert validate_with_positions(validator=Name, token=token) == data

    missing_data = {"first": "Dan"}
    missing_token = Token(value=missing_data)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(validator=Name, token=missing_token)


# Generated at 2022-06-12 16:08:09.447701
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("test")
    try:
        validate_with_positions(token=token, validator=Field(max_length=3))
    except ValidationError as error:
        assert error.messages[0].text == "Must be shorter than 3 characters."
        assert error.messages[0].start_position == token.start
        assert error.messages[0].end_position == token.end



# Generated at 2022-06-12 16:08:15.618435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Float, Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import (
        Char,
        Chars,
        ParseError,
        Sequence,
        StringLiteral,
    )
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.types import Array, Enum, Object, Union

    class User(Schema):
        name = String()
        age = Integer()

    user_schema = User()

    first_name = Char("f")
    last_name = Char("z")
    name = Sequence(chars=[first_name, last_name])
    age_string = StringLiteral("23")

    token_age = Char("2", start=(2, 1))
    token_age.start

# Generated at 2022-06-12 16:08:26.945817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import pytest
    from typesystem.tokenize.tokens import Token

    person = typesystem.Schema(
        name=typesystem.String(max_length=10), email=typesystem.String(max_length=10),
    )

    token = Token.parse("""
    [
        {"name": "Bugs Bunny", "email": "hello@example.com"},
    ]
    """)

    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(token=token, validator=person)

# Generated at 2022-06-12 16:08:37.726772
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        my_field1 = Field(required=True)
        my_field2 = Field(required=True)
        my_field3 = Field(required=True)

    token = Token(
        value={"my_field3": 1},
        start=Token.Position(line=1, column=3, char_index=2),
        end=Token.Position(line=1, column=4, char_index=4),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-12 16:08:44.196272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.ast import AST

    ast = AST()
    raw = b"{'name': 'Eric'}"
    ast.load_tokens(raw)
    ast.synthesize_tokens()

    class PersonSchema(Schema):
        name = Field(type="string", required=True)

    try:
        validate_with_positions(token=ast, validator=PersonSchema)
    except ValidationError as error:
        messages = list(error.messages())
        message = messages[0]
        assert message.start_position == (1, 5)
        assert message.end_position == (1, 9)
    else:
        assert False, "expected ValidationError"

# Generated at 2022-06-12 16:08:54.398836
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from attr import asdict
    from typesystem.markup import tokenize

    schema = Schema(fields={"name": Field(type="string", required=True)})
    tokens = tokenize("This is a <name>text</name>.")

    value = validate_with_positions(token=tokens[0], validator=schema)
    expected = {"name": "text"}
    assert value == expected

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens[0], validator=Field(type="date"))
    positional_message = error.value.messages[0]

# Generated at 2022-06-12 16:09:05.187459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import io
    import re
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.base import Message

    class Foo(Schema):
        bar = String()

    class Bar(Schema):
        foo = Foo()

    class Baz(Schema):
        bar = Bar()

    text = """{ "bar": { "foo": { "bar": 123 } }, "bar": 123 }"""
    stream = io.StringIO(text)
    token = Token.from_stream(stream)

    try:
        validate_with_positions(token=token, validator=Baz)
    except ValidationError as error:
        message = error.messages()

# Generated at 2022-06-12 16:09:14.544630
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import String
    from typesystem.collections import Array
    from typesystem.tokenize.tokens import ArrayToken

    class Thing(Schema):
        foo = String(min_length=1)

    class Things(Array):
        item = Thing

    data = [{"foo": "1"}, {"foo": ""}, {"foo": None}]
    token = ArrayToken(data, [])
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Things)
    assert exc.value.messages[0].start_position.line_index == 1
    assert exc.value.messages[0].start_position.char_index == 11
    assert exc.value.messages[0].end_position.line_index == 1
    assert exc

# Generated at 2022-06-12 16:10:22.435119
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_text

    class RegisterSchema(Schema):
        name = Field(type="string")
        password = Field(type="string")

    class UserSchema(Schema):
        username = Field(type="string")

    class LoginSchema(Schema):
        token = Field(type="string")

    class QuerySchema(Schema):
        register = Field(type=RegisterSchema)
        login = Field(type=LoginSchema)
        user = Field(type=UserSchema)

    text = """
        register {
            name: "John Doe",
            pass: "secret",
            age: 42
        }

        login {
            token: "some token"
        }

        user {
            username: "johndoe"
        }
        """
    token

# Generated at 2022-06-12 16:10:28.707566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Integer
    from typesystem.tokenize import tokenize

    field = Array[Integer()]
    token = tokenize(field, "[1, 2, '3']")
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=field)
    print(info.value.messages())
    assert len(info.value.messages()) == 1
    assert info.value.messages()[0].start_position.line == 1
    assert info.value.messages()[0].start_position.char_index == 9



# Generated at 2022-06-12 16:10:37.673438
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import (
        ObjectSchema,
        ArraySchema,
        String,
        Number,
        Integer,
        Boolean,
    )

    schema = ObjectSchema(
        {"name": String(), "age": Integer(), "is_cool": Boolean()}, required=["name"]
    )
    token = Token().add_object(
        {
            "name": Token(value="Bruce", start=Position(1, 1), end=Position(1, 6)),
            "age": Token(value=27, start=Position(2, 1), end=Position(2, 3)),
            "is_cool": Token(
                value=True, start=Position(2, 5), end=Position(2, 10)
            ),
        }
    )

# Generated at 2022-06-12 16:10:42.921524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, fields
    from typesystem.types import String, Number

    class Person(Schema):
        name = fields.String()
        age = fields.Number()
        # hobbies = fields.List(fields.String())

    data = {
        "name": "Bob",
        "age": "12",
    }

    # from pprint import pprint
    # pprint(tokenize(data, Person))

    try:
        validate_with_positions(token=tokenize(data, Person), validator=Person)
    except ValidationError as error:
        print("\n".join(message.text for message in error.messages()))



# Generated at 2022-06-12 16:10:53.592567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import PrimitiveToken

    start = Position(line=1, column=1, char_index=0)
    end = Position(line=1, column=1, char_index=1)

    token = Token(
        name="name",
        value=PrimitiveToken("a"),
        start=start,
        end=end,
        parent=None,
        children=[],
    )


# Generated at 2022-06-12 16:11:00.887349
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    data = {"name": 1}
    result = validate_with_positions(token=tokenize(data), validator=String())

    assert isinstance(result, Message)
    assert result.code == "invalid_type"
    assert result.index == ("name",)
    assert result.start_position.line == 1
    assert result.start_position.char_index == 23
    assert result.end_position.line == 1
    assert result.end_position.char_index == 24

# Generated at 2022-06-12 16:11:01.951708
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-12 16:11:11.366747
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.lexers import JsonLexer
    from typesystem.types import String
    from typesystem.main import validate_json

    class TestSchema(Schema):
        name = String()

    json_string = '{"name": "Jon"}'
    schema = TestSchema()
    tokens = JsonLexer().tokenize(json_string)
    validate_json(schema, tokens)

    tokens = JsonLexer().tokenize(r'{"lastname": "Doe", "age": "36"}')
    schema = TestSchema()
    try:
        validate_json(schema, tokens)
    except ValidationError as e:
        assert len(e.messages()) == 1
        message = e.messages()[0]
        assert message.code == "required"
        assert message