

# Generated at 2022-06-12 16:01:19.433117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        DictionaryToken,
        ListToken,
        PrimitiveToken,
        StringToken,
    )
    from typesystem.fields import List, String

    content = "[{a: A},"
    root_token = ListToken(start=StringToken(pos=0, value=content))
    root_token.add_child(DictionaryToken(start=StringToken(pos=1, value="{")))
    root_token.children[-1].add_child(StringToken(pos=2, value="a"))
    root_token.children[-1].add_child(StringToken(pos=4, value="A"))
    root_token.children[-1].add_child(StringToken(pos=5, value=":"))

# Generated at 2022-06-12 16:01:30.288244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.types import String, Structure

    def test(*, text: str, expected: typing.Any):

        class MyStructure(Structure):
            field = String()

        tokens = tokenize(text=text)
        token = tokens[0]

        assert validate_with_positions(token=token, validator=MyStructure) == expected
        try:
            validate_with_positions(token=token, validator=MyStructure)
        except ValidationError as error:
            text = text.split("\n")
            index = 0
            for line in text:
                yield line
                index += 1
                yield " " * (len(line) - 1) + "^" * (index == 1)
            for message in error.messages():
                start = message

# Generated at 2022-06-12 16:01:38.717235
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Integer, String
    from typesystem.schemas import Schema

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)

    class Person(Schema):
        name = String(required=True)
        age = Integer()
        addresses = Array(of=Address)

    token = Token(
        start=(0, 0),
        end=(6, 0),
        value={
            "name": "Foo",
            "age": None,
            "addresses": [
                {"street": None, "city": "New York"},
                {"street": "Foo", "city": None},
                {"street": None, "city": "Foo"},
            ],
        },
    )

# Generated at 2022-06-12 16:01:45.044498
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pathlib
    import sys
    from typesystem.tokenize.tokens import Token

    cwd = pathlib.Path(__file__).resolve().parent
    with open(cwd / "validator_fixture.json") as f:
        test_cases = json.load(f)
    for case in test_cases:
        field = getattr(sys.modules[case["module"]], case["field"])
        token = Token.parse(case["input"])
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-12 16:01:51.518603
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    from .test_schemas import User, Point
    from .test_fields import _test_field_validation

    raw_data = {
        "id": 1,
        "geometry": {
            "type": "Point",
            "coordinates": {},
        },
    }

    tokens = Token.from_python_value(raw_data)
    token = tokens.lookup(["geometry"])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Point())

    error = exc_info.value

# Generated at 2022-06-12 16:01:58.252020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Dictionary, Integer, String

    class TestSchema(Schema):
        a = Integer
        b = Integer
        c = Dictionary({
            "d": String(max_length=1),
        })

    token = Token.parse_string(
        """
        {
            "a": 1,
            "b": 2,
            "c": {
                "d": "foo"
            }
        }
        """
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)
    assert str(exc_info.value).endswith(
        "Position(row=10, col=20, char_index=50)"
    )



# Generated at 2022-06-12 16:02:10.649648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import Message

    import pytest

    from tests.utils import compile_schema

    from .helpers import list_of_scalars

    schema = compile_schema(
        "schema",
        """
        from typing import List

        from typesystem_text.schemas import TokenSchema
        from tests.fixtures.tokens import list_of_scalars

        class TestSchema(TokenSchema):
            tokens = list_of_scalars(
                min_items=2,
                of_type=int,
            )
        """,
        "TestSchema",
        {"list_of_scalars": list_of_scalars},
    )
    schema.validate(["1", "2"])

# Generated at 2022-06-12 16:02:18.039478
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import attr
    import pytest
    import typesystem
    from typesystem.tokenize.tokens import Document, Object
    from typesystem.tokenize.parser import SchemaParser

    class Person(Schema):
        name = typesystem.String(min_length=1)
        title = typesystem.String(max_length=100)

    @attr.s
    class Item:
        id = attr.ib()  # type: int
        owner = attr.ib()  # type: Person

    content = """
    {
        "id": 42,
        "owner": {
            "name": "Bob",
            "title": "CEO"
        }
    }"""
    tokenizer = SchemaParser(schema=Item)
    document = Document(content=content, tokenizer=tokenizer)

# Generated at 2022-06-12 16:02:25.872569
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer()
    code = "foo = 1 + 2\n"
    root = tokenizer.tokenize(code)

    token = root.lookup(["foo", "=", 1, "+", 2])

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=String())

    assert len(error.value.messages) == 1
    message = error.value.messages[0]
    assert isinstance(message.start_position, Position)
    assert isinstance(message.end_position, Position)
    assert message.start_position.line == 0
    assert message.start_position.column == 4
    assert message.end_position

# Generated at 2022-06-12 16:02:36.596944
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_json
    from typesystem.tokenize.tokens import ObjectToken

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    text = '{"name": "John", "age": "invalid"}'
    token = tokenize_json(text)
    assert isinstance(token, ObjectToken)

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        messages = list(error.messages())
        assert messages[0].text == "Value 'invalid' is not of type 'integer'."
        assert messages[1].text.startswith('Invalid value for "PersonSchema". ')

# Generated at 2022-06-12 16:02:53.368920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import PythonLexer
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class TestSchema(Schema):
        x = Integer(required=True)
        y = Integer()

    code = "x = 1\ny = 2\n"
    schema = TestSchema()

    root = PythonLexer.tokenize(code)
    top_level = root.lookup(0)
    x = top_level.lookup(0).lookup(1).lookup(1)
    y = top_level.lookup(1).lookup(1).lookup(1)
    assert x.value == "1"
    assert x.end.char_index == 2

# Generated at 2022-06-12 16:02:58.349019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize.json import JSONTokenizer

    json_schema = JSONSchema.load(
        {
            "properties": {
                "name": {"type": "string"},
                "age": {"minimum": 18},
                "address": {"properties": {"street": {"type": "string"}}},
            },
            "required": ["name", "address"],
        }
    )

    json_data = {"name": "Julie", "age": 17, "address": {"street": "123 Main St."}}
    json_tokenizer = JSONTokenizer(json_data)
    json_token = json_tokenizer.token()


# Generated at 2022-06-12 16:03:09.239225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.enums import Enum
    from typesystem.fields import String, Integer
    from typesystem.schemas import Encoder, Decoder

    class Animal(Enum):
        cat = "cat"
        dog = "dog"
        cow = "cow"

    # Encode
    class MyEncoder(Encoder):
        name: String
        age: Integer
        favourite_animal: Animal

    t = Token.from_data({"name": "bob", "favourite_animal": "cat"})
    with pytest.raises(ValidationError) as err:
        validate_with_positions(
            token=t, validator=MyEncoder,
        )

# Generated at 2022-06-12 16:03:19.452931
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    @Person
    def person(name, age):
        return f"{name} is {age} years old"

    text = "Harry is 30 years old"
    tokens = tokenize(text)
    assert validate_with_positions(token=tokens, validator=person) == text

    text = "Harry is years old"
    tokens = tokenize(text)
    try:
        validate_with_positions(token=tokens, validator=person)
    except ValidationError as error:
        assert error.messages() == [Message('Expected int.', code='invalid', index=[1])]
    else:
        assert False, "ValidationError expected"

# Generated at 2022-06-12 16:03:30.077383
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json

    token = tokenize_json('{"a": "foo"}')
    schema = Schema(fields={"a": Field(type="string")})

    validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Schema(fields={"a": Field()}))

    error = exc_info.value


# Generated at 2022-06-12 16:03:39.750844
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.serialize import TokenSerializer
    serializer = TokenSerializer()

    class MySchema(Schema):
        foo = fields.String(required=True)

    token = serializer.serialize(MySchema, {})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=MySchema)

    message = error.value.messages[0]
    assert message.start_position.line == 0
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 2
    assert message.end_position.line == 0
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 7

   

# Generated at 2022-06-12 16:03:44.315276
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema
    from typesystem.tokenize.tokenizer import tokenize

    tokens = tokenize("""
    {
        "first_name": "George",
        "last_name": "Washington"
    }
    """)

    user_schema = schema.Schema(
        {"first_name": schema.String(max_length=5, error_messages={"max_length": "this is a test"})},
        error_messages={"required": "this is also a test"},
    )

    assert validate_with_positions(token=tokens, validator=user_schema) == {"first_name": "George", "last_name": "Washington"}

# Generated at 2022-06-12 16:03:54.132715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position, Range
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer

    field = Integer(required=True)
    value = "123123"
    token = Token(value=value, start=Position(row=0, column=0, char_index=0), end=Position(row=0, column=7, char_index=7))
    value = validate_with_positions(token=token, validator=field)
    assert value == 123123

    value = "{}"
    token = Token(value=value, start=Position(row=0, column=0, char_index=0), end=Position(row=0, column=1, char_index=1))

# Generated at 2022-06-12 16:04:02.404633
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String

    token = Token(
        value={
            "name": "Bob",
            "location": {
                "lat": 37.8267,
                "long": -122.4233,
                "country": "USA",
            },
        },
        start=Token.SourcePosition(
            line_index=1, char_index=0, line_text="{"
        ),
        end=Token.SourcePosition(
            line_index=1, char_index=77, line_text="}"
        ),
    )
    assert validate_with_positions(token=token, validator=String()) == "{}"

    class PersonSchema(Schema):
        name = String()


# Generated at 2022-06-12 16:04:12.004306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.schemas import Schema
    from typesystem.tokenize.scanner import Scanner

    class Todo(Schema):
        title = Field(str)
        done = Field(bool)

    text = '{"title": "foo", "done": false}'
    tokens = list(Scanner(text).scan())
    assert validate_with_positions(token=tokens[0], validator=Todo) == loads(text)

    text = '{"title": "foo"}'
    tokens = list(Scanner(text).scan())
    try:
        validate_with_positions(token=tokens[0], validator=Todo)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]

# Generated at 2022-06-12 16:04:31.213303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from datetime import timedelta
    from typesystem.schemas import Object, String, Number

    class QuickSchema(Schema):
        foo = String(required=True)
        bar = String()
        baz = Number()

    token = Token(
        value={
            "foo": "spam",
            "bar": "",
            "baz": "spam",
            "ham": "spam",
        },
        start={
            "line": 1,
            "char": 0,
        },
        end={
            "line": 1,
            "char": 90,
        }
    )

    try:
        QuickSchema.validate(token.value)
    except ValidationError as error:
        assert str(error) == """
ham is a required field
baz must be a number""".strip

# Generated at 2022-06-12 16:04:39.924712
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import from_doc

    from .test_fields import User, Address, AddressConfig

    user_config = User.schema_config
    address_config = AddressConfig()
    address_config.schema_class = Address
    user_config.fields["address"] = address_config
    user_config.fields["first_name"].required = True

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            validator=user_config, token=from_doc({"last_name": "foo"})
        )

    messages = exc.value.messages()
    assert len(messages) == 2
    assert messages[0].index == ("address",)
    assert messages[0].text == "The field 'address' is required."

# Generated at 2022-06-12 16:04:43.208069
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.parse import parse_token

    token = parse_token("field: value")
    field = Field(type=str)

    validate_with_positions(token=token, validator=field)

# Generated at 2022-06-12 16:04:50.733343
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import tokenize
    from typesystem.schemas import Unicode, Integer, List
    from typesystem.fields import Field

    schema = List(
        items=List(
            items=List(
                items=[Unicode(), Unicode(), Integer(), Integer()],
                min_length=3,
                max_length=3,
            ),
            min_length=2,
            max_length=2,
        )
    )

    schema.validate([["one", "two", 3, 4], ["five", "six", 7, 8]])

    with pytest.raises(ValidationError) as exc_info:
        schema.validate([["one", "two", "three", 4], ["five", "six", 7, 8]])


# Generated at 2022-06-12 16:04:53.961991
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import tokenize
    import json
    import pytest

    class Person(Schema):
        name = Field(max_length=10)
        age = Field(type=int)

    with open("tests/person.json") as json_file:
        token = tokenize(json.load(json_file), "")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-12 16:05:03.873009
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                value={"name": " "},
                start=Position(index=0, char_index=0, line=0, column=0, line_text=""),
                end=Position(index=7, char_index=7, line=0, column=7, line_text=""),
            ),
            validator=Schema({"name": Field(str, min_length=1)}),
        )

# Generated at 2022-06-12 16:05:15.377474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    data = "abc"
    token = tokenize(data)
    initial_schema = Schema.from_fields(
        [
            Field(type="string", max_length=1),
            Field(type="string", max_length=1),
            Field(type="string", max_length=1),
        ]
    )
    try:
        validate_with_positions(token=token, validator=initial_schema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        message0 = error.messages()[0]
        assert message0.text == "Value is too long."
        assert message0.start_position.char_index == 1
        assert message0.end_

# Generated at 2022-06-12 16:05:22.664178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    >>> from typesystem.tokenize import tokens
    >>> from typesystem.fields import Integer

    >>> token = tokens.parse("123")
    >>> validate_with_positions(token=token, validator=Integer())
    123

    >>> token = tokens.parse("")
    >>> validate_with_positions(token=token, validator=Integer())  # doctest: +ELLIPSIS
    Traceback (most recent call last):
    typesystem.exceptions.ValidationError: ...
    """

# Generated at 2022-06-12 16:05:30.765210
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import types
    import json

    # Build a token
    token = json.loads('{"foo": {"bar": "baz"}}')
    token = Token(None, token)

    # Add positional information to the token

# Generated at 2022-06-12 16:05:36.512079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.json import dumps, loads
    from typesystem.tokenize.tokens import Token

    # Validate base case with no validation error
    value = {'name': 'james'}
    token = Token.create(value)
    assert validate_with_positions(token=token, validator=Person) == value

    # Validate base case with validation error
    token = Token.create({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:06:06.683942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import String, Integer, Boolean

    class Product(Schema):
        id = Integer(minimum=1)
        name = String(max_length=50)
        active = Boolean()

    def test(data, should_fail=True):
        token = Token.parse(data)
        try:
            validate_with_positions(token=token, validator=Product)
        except ValidationError as error:
            if not should_fail:
                raise error
            messages = {m.index: m for m in error.messages()}
            for field in ["name", "active"]:
                assert messages[field].text.startswith("The field")

        else:
            if should_fail:
                assert False, "should_fail expected"


# Generated at 2022-06-12 16:06:16.158111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.validation_test_schema import ValidationTestSchema
    from tests.tokenize_test import tokenize_document
    document = """
        query {
          bad: hello(name: "")
          all: hello(name: "world")
        }
    """
    token = tokenize_document(document)


# Generated at 2022-06-12 16:06:23.632871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse

    schema = Schema({
        "name": Field(str),
        "age": Field(int),
        "email": Field(str),
    })

    token = parse(
        data={
            "name": "John",
            # age not included
            "email": "john@smith.com",
        }
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

    assert len(error.value.messages) == 1

# Generated at 2022-06-12 16:06:33.306959
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"x": Field(type="string", required=True)})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                value={"x": None},
                start=Position(line_index=0, char_index=0),
                end=Position(line_index=1, char_index=0),
            ),
            validator=schema,
        )


# Generated at 2022-06-12 16:06:43.788544
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import attr
    import pytest
    import typesystem

    @attr.s
    class Item(typesystem.Schema):
        name = typesystem.String()
        price = typesystem.Integer()

    @attr.s
    class Order(typesystem.Schema):
        items = typesystem.List(Item)

    @attr.s
    class Checkout(typesystem.Schema):
        order = Order()
        payment = typesystem.String()

    body = {"order": {"items": []}, "payment": "12345"}
    token = Token.from_json(body)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Checkout)
    assert len(excinfo.value.messages()) == 2


# Generated at 2022-06-12 16:06:49.062157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Name(Schema):
        first_name = Field(str, required=True)

    class Person(Schema):
        name = Field(Name, required=True)

    tokens = tokenize({"name": {"first_name": ""}})

    try:
        validate_with_positions(token=tokens, validator=Person)
    except ValidationError as error:
        message, = error.messages()
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 16
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 17

# Generated at 2022-06-12 16:06:57.936375
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import ObjectToken

    class InputSchema(Object):
        title = String()

    token = ObjectToken(
        {
            "type": "object",
            "start": {"line": 1, "column": 1, "token": 0},
            "end": {"line": 3, "column": 3, "token": 2},
            "fields": {"title": {"value": "", "start": {"line": 2, "column": 5}}},
        },
        value={"title": ""},
    )

    try:
        validate_with_positions(token=token, validator=InputSchema())
        assert False
    except ValidationError as e:
        message = e.messages[0]
       

# Generated at 2022-06-12 16:07:10.335063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.lines import tokenize_lines
    from typesystem.schema import Schema
    from typesystem.fields import Integer

    schema = Schema(fields={"a": Integer()})

    text = "a: 1"
    lines = tokenize_lines(text)
    tokens = tokenize(lines)
    validate_with_positions(token=tokens, validator=schema)

    text = "a: not an int"
    lines = tokenize_lines(text)
    tokens = tokenize(lines)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=schema)


# Generated at 2022-06-12 16:07:16.496766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        name = Field(required=True)
        age = Field(required=True)

    class MyInnerSchema(Schema):
        name = Field(required=True)
        age = Field(required=True)

    class MySchema1(Schema):
        person = Field(MyInnerSchema)

    class MySchema2(Schema):
        person = Field(MyInnerSchema)


# Generated at 2022-06-12 16:07:22.075057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.positional import validate

    class ExampleSchema(Schema):
        name = Field(type="string", required=True)

    token = Token.parse('{"name": null}')
    with pytest.raises(ValidationError) as error:
        validate(token, ExampleSchema)
    message = error.value.messages[0]
    assert message.start_position.line == 0
    assert message.start_position.column == 7

# Generated at 2022-06-12 16:08:10.937394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import (
        Token,
        TokenType,
        check_token_type,
        tokenize,
    )
    from .utils import assert_position_raises

    schema = Schema(fields={"name": String()})

    text = '{"name": "Max"}'
    token = tokenize(text)

    check_token_type(token, TokenType.START_OBJECT)

    validate_with_positions(token=token, validator=schema)

    assert json.loads(text) == token.value


# Generated at 2022-06-12 16:08:16.780818
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(validators=[lambda x: x > 0])
    token = Token(
        value=0,
        start=Token.Position(line_number=0, line_offset=0, char_index=0),
        end=Token.Position(line_number=0, line_offset=1, char_index=1),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages() == [
        Message(
            text="Must be greater than 0.",
            code="invalid",
            index=[],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-12 16:08:27.774049
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Map, List, Scalar
    from typesystem.tokenize.parser import get_parser_class
    from typesystem import fields

    token = Map(
        [
            Map(
                [Map([Scalar("foo", "a")], start=10, end=18), Scalar("bar", 0)],
                start=0,
                end=26,
            )
        ],
        start=0,
        end=27,
    )
    parser_type = get_parser_class(fields.Schema(fields=[fields.Integer(name="foo")]))
    parser = parser_type()
    assert parser.tokenize("{") == token.value[0]
    parser_type.validate = validate_with_positions


# Generated at 2022-06-12 16:08:33.174901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    data = """
    {
        "name": "foobar",
        "age": 29
    }
    """
    token = tokenize(data)
    token = token.lookup(".0")
    validate_with_positions(token=token, validator=Person)



# Generated at 2022-06-12 16:08:41.736868
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, ObjectToken

    schema = Schema({"age": Field(int)})
    value = {"age": "moin"}
    token = ObjectToken(value, token_start=(1, 1), token_end=(1, 13))

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    error_messages = excinfo.value.messages
    assert len(error_messages) == 1
    message = error_messages[0]
    assert message.text == "Invalid integer."
    assert message.code == "type"
    assert message.index == ["age"]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 7


# Generated at 2022-06-12 16:08:52.305122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String
    from typesystem.tokenize.tokens import make_tokens
    from typesystem.tokenize.line_tokens import LineToken

    field = String(title="Identifier", description="A string.", required=True)
    tokens = make_tokens("  identifier: Foo")
    token = tokens[0]
    validate_with_positions(token=token, validator=field)

    tokens = make_tokens("  identifier: ")
    token = tokens[0]
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=field)

    messages = error_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message

# Generated at 2022-06-12 16:09:03.233385
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        Token, LiteralValueToken, ListToken, ObjectToken, PropertyToken)

    class Person(Schema):
        name = Field(str)

    token = LiteralValueToken(
        ["data", "people", 0],
        Person,
        start_index=0,
        start_line_index=1,
        start_line_char_index=0,
        end_index=40,
        end_line_index=3,
        end_line_char_index=30,
    )

# Generated at 2022-06-12 16:09:13.021177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {"a": 2, "b": 3}
    schema = {"a": {"type": "integer"}}
    token = Token.from_python(data, schema)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    messages = excinfo.value.messages
    assert messages[0].text == "The field 'b' was not expected."
    assert messages[0].code == "unexpected"
    assert messages[0].start_position.line_index == 1
    assert messages[0].start_position.char_index == 7
    assert messages[0].start_position.column_index == 7
    assert messages[0].start_position.content == "b"

# Generated at 2022-06-12 16:09:22.649073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Address(Schema):
        street = String()
        number = Integer()

    class Person(Schema):
        name = String()
        phone = String()
        address = Address()

    tokens = tokenize({"name": "Joe", "phone": "123", "address": "..."})
    error = None
    try:
        Person.validate(tokens)
    except ValidationError as e:
        error = e

    assert error is not None
    messages = error.messages()
    assert len(messages) == 2
    assert messages[0].code == "invalid"
    assert messages[0].text == "Must be a valid integer."

# Generated at 2022-06-12 16:09:27.072567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .tokenize import get_tokenizer
    from .tokenize.tokens import FieldToken, ObjectToken, Token

    from .typesystem.fields import String

    tokenizer = get_tokenizer(
        fields={
            "name": String(required=True),
            "age": String(required=True),
            "height": String(),
            "hobbies": String(),
        }
    )
    tokens = tokenizer.get_tokens(b'{"name": "John Doe"}')
    FileInfo = typing.TypedDict("FileInfo", {"path": str, "line": int, "col": int})


# Generated at 2022-06-12 16:10:58.499227
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.validators import (
        ValidationError,
        Text,
        Union,
        Integer,
        List,
        Dict,
    )
    from typesystem.tokenize.tokens import (
        ListToken,
        DictToken,
        ScalarToken,
        Token,
    )

    token = ListToken(
        value=[
            DictToken(
                value={
                    ScalarToken(value="a", start=(0, 0), end=(0, 1)): ScalarToken(
                        value=1, start=(0, 3), end=(0, 4)
                    )
                },
                start=(0, 0),
                end=(0, 7),
            )
        ],
        start=(0, 0),
        end=(0, 8),
    )


# Generated at 2022-06-12 16:11:05.761169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Any:
        def validate(self, value):
            return value

    class Required:
        def validate(self, value):
            raise ValidationError(
                [Message(text="required", code="required")]
            )

    class Length(Required):
        def __init__(self, min=None, max=None):
            self.min = min
            self.max = max

        def validate(self, value):
            required_messages = super().validate(value)
            if not value:
                return required_messages

            messages = []