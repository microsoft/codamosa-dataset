

# Generated at 2022-06-12 16:01:17.554934
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest import mock
    from typing import List

    # Test when no exception is thrown
    field = mock.Mock(spec=["validate"])
    with mock.patch("typesystem.tokenize.validate_with_positions._lookup") as lookup:
        result = validate_with_positions(token={}, validator=field)
        field.validate.assert_called_once()
        lookup.assert_not_called()
        assert result == field.validate.return_value

    # Test when an exception is thrown (but it is not a ValidationError)
    field = mock.Mock(spec=["validate"])
    field.validate.side_effect = Exception
    with pytest.raises(Exception):
        validate_with_positions(token={}, validator=field)

    # Test

# Generated at 2022-06-12 16:01:24.441043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):

        name = Field(required=True, type=str)
        age = Field(required=True, type=int)

    token = Token(
        {
            "name": "Matthias",
            "age": 38,
        },
        start_position=Position(1, 0),
        end_position=Position(4, 4),
        children=[
            Token(
                "Matthias",
                start_position=Position(2, 4),
                end_position=Position(2, 11),
                children=[],
            ),
            Token(
                38,
                start_position=Position(3, 4),
                end_position=Position(3, 5),
                children=[],
            ),
        ],
    )


# Generated at 2022-06-12 16:01:35.104156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken, StringToken
    from tests.schemas import PersonSchema
    from tests.base_classes import Person
    from tests.blob import blob

    token = ObjectToken(
        blob=blob, start=(1, 2), end=(1, 6), value={"name": "", "age": "fifty-two"}
    )
    token.children.append(StringToken(blob=blob, start=(1, 2), end=(1, 7), value=""))
    token.children.append(
        StringToken(blob=blob, start=(1, 16), end=(1, 22), value="fifty-two")
    )

    from typesystem.errors import ValidationError

    with pytest.raises(ValidationError):
        validate_with_

# Generated at 2022-06-12 16:01:45.660522
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typesystem import Integer
    from typesystem.tokenize import tokenize

    stream = StringIO('{"numbers": [1, 2, 3, 4]}')
    root = tokenize('json', stream)
    schema = Integer()
    schema.name = "number"

    assert validate_with_positions(token=root["numbers"]["number"], validator=schema)
    assert validate_with_positions(token=root["numbers"]["number"], validator=schema)
    assert validate_with_positions(token=root["numbers"]["number"], validator=schema)
    assert validate_with_positions(token=root["numbers"]["number"], validator=schema)

# Generated at 2022-06-12 16:01:51.421443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .parse_hocon_file import parse_hocon_file
    import os

    ROOT_DIR = os.path.dirname(os.path.dirname(__file__))
    TEST_CONFIG = os.path.join(ROOT_DIR, "tests/data/config.conf")

    tokens = parse_hocon_file(TEST_CONFIG)
    schema = {"name": "string"}
    validate_with_positions(token=tokens, validator=schema)



# Generated at 2022-06-12 16:01:58.402783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import make_token
    from typesystem.validators import Equals

    validator = String(validators=[Equals("foo")])
    token = make_token("foo", start_line=1, start_col=1, end_line=1, end_col=4)
    assert validate_with_positions(token=token, validator=validator) == "foo"

    token = make_token("bar", start_line=1, start_col=1, end_line=1, end_col=4)
    error = None
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as exc:
        error = exc

    msg = error.messages()[0]
   

# Generated at 2022-06-12 16:02:10.785404
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize.tokens import TokenList
    from typesystem.fields import String


# Generated at 2022-06-12 16:02:18.168960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.tokenize.utils import parse_keys, parse_value
    from typesystem.tokenize.positions import make_position, start_of_file

    schema = parse_keys(
        """
        id: Integer
        name: String?
        type: NamedType!
        """
    )

    tokens = tokenize('{ id: 42, type: User }')
    assert all(isinstance(token, Token) for token in tokens)
    token = tokens[0]

    class MySchema(Schema):
        query = schema

    try:
        validate_with_positions(
            token=token, validator=MySchema.query,
        )
    except ValidationError as error:
        assert error is not None

# Generated at 2022-06-12 16:02:25.980547
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.formatters import PyFormatTokenFormatter

    class ExampleSchema(Schema):
        name = Field(type=str)
        age = Field(type=int, required=False)
        country = Field(type=str, required=False)

    def get_error_positions(*, text: str) -> typing.List[typing.Tuple[int, int]]:
        lexer = Lexer(formatter=PyFormatTokenFormatter())
        token = lexer.lex_text(text)
        try:
            validated_data = validate_with_positions(token=token, validator=ExampleSchema)
        except ValidationError as error:
            messages = error.messages()

# Generated at 2022-06-12 16:02:34.597559
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token_types import TOK_NUMBER

    token = Token(
        value=1,
        token_type=TOK_NUMBER,
        start={
            "line_no": 1,
            "line_index": 1,
            "char_index": 1,
        },
        end={
            "line_no": 1,
            "line_index": 1,
            "char_index": 2,
        },
    )

    field = Field(name="number", type="number")

    assert validate_with_positions(token=token, validator=field) == 1



# Generated at 2022-06-12 16:02:45.113683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.exceptions import ValidationError

    from typesystem.tokenize.tokenize import get_tokens
    from typesystem.tokenize.schemas import DictSchema
    from typesystem.tokenize.errors import ErrorLevel, ErrorType, Error
    from typesystem.tokenize.fields import StringField

    raw_json = '{"foo": {"bar": "baz"}, "fizz": [1, 2], "buzz": false}'
    tokens = get_tokens(raw_json)
    schema = DictSchema(
        {"foo": DictSchema({"bar": StringField(max_length=3)}), "buzz": StringField()}
    )


# Generated at 2022-06-12 16:02:55.226072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        name = String()

    data = {
        "name": "John",
    }
    token = Token("ROOT", data)
    assert validate_with_positions(token=token, validator=TestSchema) == data

    # Error messages should include start and end line/char_index
    data = {
        "name": "",
    }
    token = Token("ROOT", data)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=TestSchema)
    message = exc.value.messages[0]

# Generated at 2022-06-12 16:03:03.060033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from .jmespath import JMESPath
    from .validators import validate_jmespath
    from .schema import jmespath_validator
    from .errors import DocumentError

    text = """{
  "first": "self",
  "last": "less",
  "age": 42,
  "active": true,
  "children": ["Foo", "Bar"],
  "address": {
    "city": "SF",
    "state": "CA"
  }
}"""


    jmespath = validate_jmespath("last")
    jmespath = validate_jmespath("first")

    try:
        validate_with_positions(token=Token(loads(text)), validator=jmespath)
    except DocumentError as error:
        assert error.message.start_

# Generated at 2022-06-12 16:03:14.463245
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.primitives
    import dataclasses

    @dataclasses.dataclass
    class Address:
        city: str
        country: str

    @dataclasses.dataclass
    class Location:
        address: Address
        coordinates: str

    @dataclasses.dataclass
    class Person:
        name: str
        age: int
        location: Location
        hobbies: typing.List[str]

    location_schema = Schema(fields={"address": Schema(fields={"city": str})})
    person_schema = Schema(fields={"location": location_schema})

    location_field = typesystem.primitives.Object(
        schema=location_schema,
        description="A location",
    )


# Generated at 2022-06-12 16:03:16.322819
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token()


if __name__ == '__main__':
    test_validate_with_positions()

# Generated at 2022-06-12 16:03:27.836483
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:03:37.032696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.schemas as schema
    import typesystem.positions as pos

    simple_json = """{ "id": 42 }"""
    token = Token.parse(simple_json)

    with pytest.raises(ValidationError) as err:
        validate_with_positions(
            token=token, validator=schema.Schema({"id": Field()}),
        )

    assert err.value.messages()[0].start_position == pos.Position(line=1, column=14)
    assert err.value.messages()[0].end_position == pos.Position(line=1, column=15)

# Generated at 2022-06-12 16:03:42.029804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Make sure that positional validation works."""
    from typesystem import parse_schema

    raw_schema = r"""
    type MyObject
      a: Int32
    """
    schema = parse_schema(raw_schema)
    token = Token(
        "MyObject",
        {
            "a": Token(
                "100",
                start_position=Token.Position(line=2, column=13, char_index=14)
            )
        },
        start_position=Token.Position(line=2, column=2, char_index=3)
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-12 16:03:51.488529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Dict, String
    from typesystem.tokenize.tokens import DictToken, StringToken

    schema = Dict(fields={"name": String()})
    token = DictToken([StringToken("name", "", start=0, end=0)])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            code="required",
            index=(),
            start_position=0,
            end_position=0,
            text="Missing keys for required fields: set()",
        )
    ]


# Generated at 2022-06-12 16:04:00.624267
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    token = Token(
        {"name": "Alice", "age": 35},
        start=tokenize.TokenInfo(0, 1, 0, 0),
        end=tokenize.TokenInfo(1, 2, 10, 11),
    )
    user = validate_with_positions(token=token, validator=User)
    assert isinstance(user, User)

    token = Token(
        {"name": "Alice"},
        start=tokenize.TokenInfo(0, 1, 0, 0),
        end=tokenize.TokenInfo(1, 2, 10, 11),
    )

# Generated at 2022-06-12 16:04:19.933014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyField(Field):
        def validate(self, value):
            if value != "my value":
                raise ValidationError(index=[], text="must be 'my value'")
            return value

    token = Token(value="my value")
    validate_with_positions(token=token, validator=MyField({}))

    token = Token(value="my other value")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MyField({}))
    message = exc_info.value.messages[0]
    assert message.text == "must be 'my value'"
    assert message.index == []
    assert message.start_position.line == 0
    assert message.start_position.char_index == 0

# Generated at 2022-06-12 16:04:25.449297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer

    tokenizer = Tokenizer(text='{"key": "test"}')
    token = next(tokenizer)

# Generated at 2022-06-12 16:04:32.945981
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    schema_string = """\
name:
  type: string
age:
  type: integer
job:
  type: string
"""
    token = Token.parse(schema_string, validator=Schema)
    try:
        validate_with_positions(token=token, validator=Schema)
    except ValidationError as error:
        assert [message.text for message in error.messages()] == [
            'The field "name" is required.',
            'The field "age" is required.',
            'The field "job" is required.',
        ]
        assert [message.code for message in error.messages()] == [
            "required",
            "required",
            "required",
        ]

# Generated at 2022-06-12 16:04:42.497773
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JsonSchema
    from typesystem.fields import Integer, String
    from typesystem.tokenize import tokenize

    schema = JsonSchema(
        properties={
            "name": String(),
            "age": Integer(),
        },
        required=["name"],
        additional_properties=False,
    )

    tokens = tokenize("{}")
    try:
        result = validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.char_index == 1  # type: ignore
        assert message.end_position.char_index == 1  # type: ignore

# Generated at 2022-06-12 16:04:50.295195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize.lex_json import lex
    from typesystem.tokenize.parse_json import parse
    from typesystem.schemas import Schema
    from typesystem.fields import Integer


    token = parse(lex(loads("[1, 2, 3]")))
    value = validate_with_positions(token=token, validator=Schema(
        fields={"0": Integer(maximum=2), "1": Integer(minimum=4)}
    ))
    assert value == [1, 2, 3]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Schema(
            fields={"0": Integer(minimum=2), "1": Integer(minimum=4)}
        ))
    assert exc_info

# Generated at 2022-06-12 16:04:57.743346
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import JsonToken
    from typesystem.schemas import Object
    from typesystem.fields import String
    schema = Object(fields={"name": String(required=True)})
    text = '{"name": "Bob"}'
    json_token = JsonToken(text=text)
    json_token.validate(schema.fields)
    validate_with_positions(token=json_token, validator=schema)

# Generated at 2022-06-12 16:05:04.721715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.position import Position
    from typesystem.fields import Text, Integer

    token = Token(
        value={
            "a": 1,
            "b": "foo",
            "c": {"x": 10, "y": 11},
        },
        start=Position(line_index=1, char_index=10),
        end=Position(line_index=4, char_index=10),
    )

    schema = Schema(
        {"a": Integer(min_value=2), "b": Text(), "d": Text(), "c": {"x": Integer()}}
    )

    validation_error = None

# Generated at 2022-06-12 16:05:16.285760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    tokenized = tokenize(
        {
            "first_name": "John",
            "last_name": "Doe",
            "age": 37,
            "experience": {
                "years": 10,
                "title": "Senior Developer",
                "comments": ["He likes to skate."],
            },
        }
    )

    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")
        age = Field(type="integer", minimum=0, maximum=99)
        experience = Field(type="object")

    class Experience(Schema):
        years = Field(type="integer")
        title = Field(type="string")
        comments = Field(type="array")


# Generated at 2022-06-12 16:05:26.719266
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    from typesystem.schemas import String
    from typesystem.tokenize.tokens import Tokenizer

    tokenizer = Tokenizer(io.StringIO("abc"))
    tokens = list(tokenizer.tokenize())
    assert validate_with_positions(token=tokens[0], validator=String()) == "abc"
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=String(min_length=10))

    message = exc_info.value.messages[0]
    assert message.text.startswith("Must be at least")
    assert message.start_position.lineno == 1
    assert message.start_position.char_index == 0

# Generated at 2022-06-12 16:05:35.342342
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value="bar",
        start=Position(line=1, column=2, char_index=1),
        end=Position(line=1, column=5, char_index=4),
    )
    field = Field(type="string", max_length=2)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == Position(
            line=1, column=2, char_index=1
        )
        assert error.messages()[0].end_position == Position(
            line=1, column=5, char_index=4
        )
    else:
        raise AssertionError("ValidationError should have been raised.")



# Generated at 2022-06-12 16:05:57.756939
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import Token, TokenizeError
    from typesystem.tokenize.tokenizers import OpenAPITokenizer
    from typesystem.tokenize.utils import tokenize_openapi


# Generated at 2022-06-12 16:06:07.573267
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.fields import String

    from .test_validate import schema

    t = Tokenizer()
    token = t.tokenize(schema, '{"foo": ""}')
    try:
        validate_with_positions(token=token, validator=String(min_length=1))
    except ValidationError as e:
        error = e
    assert error.messages() == [
        Message(
            code="min_length",
            index=["foo"],
            text="String should be at least 1 characters long.",
            start_position=Position(line=1, column=0, char_index=0),
            end_position=Position(line=1, column=0, char_index=0),
        )
    ]



# Generated at 2022-06-12 16:06:14.102750
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.positional import PositionalTokenizer

    tokenizer = PositionalTokenizer(
        tokenizer=Tokenizer(),
        start_position=typesystem.tokenize.position.Position(char_index=0, line=0)
    )

    class PersonSchema(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    try:
        PersonSchema.validate({"name": "John"})
    except ValidationError as error:
        for message in error.messages():
            print(message)

    token = tokenizer.tokenize({"name": "John", "age": "thirty"})

# Generated at 2022-06-12 16:06:22.806124
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema

    token = Token.from_mapping("{}")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Schema({"name": String()}))

    error = excinfo.value
    assert error.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=Position(line=1, char_index=1),
            end_position=Position(line=1, char_index=1),
        ),
    ]

# Generated at 2022-06-12 16:06:23.800628
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:06:31.446235
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import schema, string, integer

    schema = schema(
        {"name": string(), "age": integer()},
        format="custom",
        tokenize_func=tokenize_custom,
    )
    assert schema.validate({"name": " ", "age": "bad"}) == {
        "name": " ",
        "age": "bad",
    }
    with pytest.raises(ValidationError) as exc_info:
        schema.validate({})
    assert exc_info.value.messages()[0].start_position.char_index == 1



# Generated at 2022-06-12 16:06:42.418159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.schemas import Schema

    class Stream():
        def __init__(self, name: str, data: str) -> None:
            self.name = name
            self.data = data

        def read(self) -> str:
            return self.data

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    file_stream = Stream(
        name="tester.json",
        data="""
        {
            "name": "weyber",
            "age": "42"
        }
        """,
    )

    token = Token.create(file_stream.read())


# Generated at 2022-06-12 16:06:46.903777
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields

    class ExampleSchema(Schema):
        field = fields.String(required=True)

    token = Token(["foo"], {"field": {"bar": "hi"}}, 0, 0, 0)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=ExampleSchema)
    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].start_position.char_index == 1



# Generated at 2022-06-12 16:06:57.034345
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Tokenizer
    from typesystem.tokenize.types import IntegerToken

    tokenizer = Tokenizer()
    schema = Field(type="number")
    token: Token = tokenizer.parse(
        """
            {
                "foo": 12345
            }
        """
    )
    assert token.value == {"foo": 12345}

    validate_with_positions(token=token, validator=schema)

    error = None
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        error = e
    assert len(error.messages()) == 1
    assert error.messages()[0].start_position.char_index == 65  # type: ignore
    assert error.messages()[0].end

# Generated at 2022-06-12 16:07:09.896636
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.lexer import DefaultLexer
    from typesystem.tokenize.lexer import DefaultTokens
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.token import ValidationError

    tokens = DefaultTokens()
    class Hello(Schema):
        name = String()

    source = """
    hello:
      name: foo
    """
    schema = Hello()
    lexer = DefaultLexer(tokens=tokens)
    token = lexer.tokenize(source)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    error = excinfo.value
    positional_message = error.messages[0]
   

# Generated at 2022-06-12 16:07:48.599869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.errors import TokenizationError
    from typesystem.tokenize.tokenize import tokenize

    validator = Schema({"foo": Integer()})
    value = '{"foo": "bar"}'
    with pytest.raises(TokenizationError) as excinfo:
        validate_with_positions(token=tokenize(loads(value)), validator=validator)
    messages = excinfo.value.messages
    message = messages[0]
    assert message.text == "Invalid integer."
    assert message.code == "invalid_type"
    assert message.start_position.char_index == 8
    assert message.end_position.char_index == 11

# Generated at 2022-06-12 16:07:56.792288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Validator, Schema

    class UserSchema(Schema):
        id = Field(type="integer")
        name = Field(type="string")
        email = Field(type="string")

    @UserSchema.validator
    def requires_email_if_name(schema, data):
        if "name" in data and "email" not in data:
            yield ValidationError(["email"], "email is required")

    schema = UserSchema()

    user_to_validate = {
        "id": 1,
        "name": "johndoe",
    }

    def convert_token_to_schema(token):
        return Validator(schema)


# Generated at 2022-06-12 16:08:07.330482
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Document(Schema):
        name = Field(str)

    token = Token.parse({"name": "Barry"})
    validate_with_positions(token=token, validator=Document)

    invalid_token = Token.parse({"name": 1})  # type: ignore
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=invalid_token, validator=Document)
    assert excinfo.type is ValidationError
    message = excinfo.value.messages[0]
    assert message.text == (
        "The field 'name' must be a string, not the type <class 'int'>."
    )
    assert message.code == "type_error"
    assert message.index == ("name",)
    assert message.start_position == Position

# Generated at 2022-06-12 16:08:14.648397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields

    Token = tokenize.Token

    class MutableMapping(fields.Object):
        _fields = {"foo": fields.String()}

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                Token.OBJECT,
                {},
                "1",
                tokenize.Position(line=0, column=0, char_index=0),
                tokenize.Position(line=0, column=1, char_index=1),
            ),
            validator=MutableMapping,
        )


# Generated at 2022-06-12 16:08:26.279086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.tokenize.tokens import Token, TokenType

    schema = Schema(fields={"child": Field(required=True)})

    token = Token(
        name="root",
        token_type=TokenType.DictStart,
        value={
            "child": {
                "grandchild": {
                    "a1": "2",
                    "a2": "3",
                },
                "grandchild2": {"a1": "4"},
            }
        },
        start=Token.Position(line=0, char_index=0),
        end=Token.Position(line=0, char_index=0),
    )

    messages = None

# Generated at 2022-06-12 16:08:32.145385
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema
    from typesystem.tokenize.tokens import Tokenizer

    class SimpleSchema(Schema):
        foo = "foo"
        bar = 123

    tokenizer = Tokenizer(SimpleSchema)
    tokens = tokenizer.tokenize({"foo": "bar"})
    validate_with_positions(token=tokens, validator=SimpleSchema)

# Generated at 2022-06-12 16:08:41.110910
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "a": Field(str),
            "b": Field(str),
            "c": Field(str),
            "d": Field(str),
            "e": Field(str),
        }
    )
    token = schema.to_token(
        {
            "a": "1",
            "b": "2",
            "c": "3",
            "d": "4",
            "e": "5",
        }
    )
    token.lookup(["c"]).value = 0
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert len(excinfo.value.messages()) == 1
    message = excinfo.value.messages()[0]

# Generated at 2022-06-12 16:08:51.759938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.base import Response
    from typesystem.tokenize.tokens import TextToken
    from typesystem.json_schema import Object, String
    from .test_tokenize import parse_schema

    schema = parse_schema(
        {"id": "string", "foo": {"id": "string"}, "bar": {}}
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=schema, validator=parse_schema({"foo": String}))
    error = exc_info.value
    assert isinstance(error, Response)

# Generated at 2022-06-12 16:08:58.058818
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import combine_tokens

    schema = Schema(
        {"first_name": Field(str), "last_name": Field(str, required=True)}
    )

# Generated at 2022-06-12 16:09:09.284730
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from pytest import raises
    from typesystem.fields import String

    token = Token({"a": {"b": {"c": "foobar"}}})

    class MySchema(Schema):
        a = {"b": {"c": String()}}

    assert validate_with_positions(token=token, validator=MySchema) == {
        "a": {"b": {"c": "foobar"}}
    }

    class MySchema(Schema):
        a = {"b": {"c": String(required=True)}}

    with raises(ValidationError) as error:
        validate_with_positions(token=token, validator=MySchema)
    assert "The field 'c' is required." in str(error.value)

# Generated at 2022-06-12 16:10:21.428156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringToken

    class TestField(Field):
        def validate(self, value):
            return "test"

    token = StringToken(
        value="test", start=(1, 0), end=(1, 4), source_mark_start=None, source_mark_end=None
    )
    assert validate_with_positions(token=token, validator=TestField()) == "test"

    # Test that errors from the validator are wrapped such that the position
    # of the error is also included.
    class ExceptionField(Field):
        def validate(self, value):
            raise ValidationError("Failed validation")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=ExceptionField())
    assert error.value

# Generated at 2022-06-12 16:10:29.340109
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        name="a",
        value={"b": {"b": None}},
        start=create_position(index=0, line=1, column=1),
        end=create_position(index=8, line=1, column=9),
    )
    schema = Schema(fields={"a": {"type": "object", "fields": {"b": {"type": "string"}}}})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:10:38.111466
# Unit test for function validate_with_positions

# Generated at 2022-06-12 16:10:49.128971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.parse import parse_token
    from typesystem.tokenize.string import string_to_tokens
    from typesystem.tokenize.tokens import DictionaryToken, ListToken
    from typesystem.tokenize.tokens import StringToken

    string = '[{"name": null, "age": null}]'
    tokens = string_to_tokens(string)
    token = parse_token(tokens)
    ListToken.validate = validate_with_positions
    DictionaryToken.validate = validate_with_positions
    StringToken.validate = validate_with_positions
    field = String(required=True)

# Generated at 2022-06-12 16:10:59.978220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from jsonschema import validate, ValidationError

    schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "number"},
        },
        "required": ["name", "age"],
    }

    document = """
    {
      "name": "Polly",
      "age": 10
    }"""

    token = Token.from_json(document)
    validator = Token.from_schema(schema)
    validate_with_positions(token=token, validator=validator)
    assert token.value == loads(document)


# Generated at 2022-06-12 16:11:10.739869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import copy
    import pytest
    import jsonschema
    from typesystem.schemas import Schema
    from typesystem.fields import String
    import typesystem.tokenize.tokens
    from typesystem.tokenize.tokens import Token, StringToken

    class StringSchema(Schema):
        value = String()

    schema = StringSchema()
    string_1 = "abc"
    token = StringToken(string_1, start_position=0, end_position=3)
    assert validate_with_positions(token=token, validator=StringSchema) == string_1

    string_2 = "abc"
    token = StringToken(string_2, start_position=0, end_position=3)