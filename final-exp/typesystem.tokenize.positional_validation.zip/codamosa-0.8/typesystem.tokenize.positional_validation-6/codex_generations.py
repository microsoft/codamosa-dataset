

# Generated at 2022-06-12 16:01:19.382968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name1 = Field(required=True)
        name2 = Field(required=True)

    tokens = [
        Token(value="foo", start=0, end=3),
        Token(value="bar", start=4, end=7),
    ]
    schema = MySchema()
    error = None
    try:
        validate_with_positions(token=tokens[0], validator=schema)
    except ValidationError as e:
        error = e
    assert error is not None
    assert len(error.messages()) == 1
    message = error.messages()[0]
    assert message.code == "required"
    assert message.text == "The field 'name2' is required."
    assert message

# Generated at 2022-06-12 16:01:25.317782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token, ValueToken
    from typesystem.tokenize.types import PrimitiveTokenType

    data = {
        "alpha": {"beta": [{"gamma": 1}, {"gamma": None}]}
    }
    token = Token.from_object(data)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(validator=Integer(), token=token["alpha"]["beta"][1])
    token = token["alpha"]["beta"][1]
    assert token.type == PrimitiveTokenType.OBJECT
    assert isinstance(token, ValueToken)
    assert token.start == (4, 5)
    assert token.end == (11, 3)


# Generated at 2022-06-12 16:01:35.750251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Schema

    class MySchema(Schema):
        my_int = Integer(required=True)

    schema = MySchema()
    token = Token({"my_int": "foo"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc_info.value.messages()[0]
    assert message.text == "The field 'my_int' of type 'integer' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 11
    assert message.end_position.line == 1
    assert message.end_position.char_index == 14
    assert message.code == "required"

# Generated at 2022-06-12 16:01:46.573012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.types import TokenType
    from typesystem.tokenize.base import Tokenizer
    from typesystem.fields import Integer

    class IntField(Field):
        default_error_messages = {"invalid": "Not an integer."}
        default_validators = [validate_with_positions]

        def _validate(self, value):
            if not isinstance(value, int):
                self.fail("invalid")

    class StringField(Field):
        default_validators = [validate_with_positions]

    class CustomToken(TokenType):
        def serialize(self, value: str, **_) -> str:
            return value


# Generated at 2022-06-12 16:01:55.037022
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        path=["foo", "bar", "baz"],
        value={"spam": [1, 2]},
        start_line=3,
        start_column=4,
        end_line=5,
        end_column=6,
    )

    schema = Schema({"foo": {"bar": {"baz": [{"spam": Field(type="integer")}]}}})

    messages = validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-12 16:02:00.292921
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Object

    class Item(Schema):
        id = Field(type=int)

    class Cart(Schema):
        items = Field(type=Array[Item], required=True)

    json_data = """
    {
        "items": [
            {
                "id": "1"
            }
        ]
    }
    """
    tokens = Cart.tokenize(json_data)
    try:
        Cart.validate(tokens)
    except ValidationError as error:
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.char_index  # type: ignore
        )
        assert messages[0].text == "The field 'id' is of type int. Expected str."
        assert messages[0].start_position

# Generated at 2022-06-12 16:02:00.892978
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-12 16:02:11.772486
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Parser, Tokenizer
    from typesystem.types import String

    class NameSchema(Schema):
        first_name = String()
        last_name = String()

    class AddressSchema(Schema):
        name = NameSchema()
        country = String()

    tokenizer = Tokenizer()
    parser = Parser()
    json = """{
        "name": { "first_name": "Jane", "last_name": "" },
        "country": ""
    }"""
    token = tokenizer.tokenize_from_string(json)
    value = parser.parse(AddressSchema(), token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=value, validator=AddressSchema())
    messages = exc

# Generated at 2022-06-12 16:02:19.210814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem import Schema

    class MySchema(Schema):
        field1 = String(required=True)
        field2 = Integer(required=True)

    source = '{"field1": "", "field2": "foo"}'
    tokens = tokenize(source, schema=MySchema)
    token = tokens.lookup(["field2"])
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=MySchema.fields["field2"])
    messages = exc.value.messages
    assert len(messages) == 1
    assert messages[0].text == "A valid integer is required."

# Generated at 2022-06-12 16:02:21.227243
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"a": {"b": int}})
    token = Token.parse({"a": {"b": "1"}})
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:02:35.553347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokenize import tokenize
    
    schema = {
        "name": typesystem.String(),
        "age": typesystem.Integer(),
    }

    json_string = '{ "name": "John Doe" }'
    token = tokenize(json_string)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position.line == 1
        assert message.start_position.column == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line == 1
        assert message.end_position.column == 2
       

# Generated at 2022-06-12 16:02:42.701873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.html import make_document

    class User(Schema):
        name = Field(str)
        email = Field(str)

    document = make_document(
        "<html><body><form><input name=name value=foo><input name=email></form></body></html>"
    )
    token = document.body.form.inputs[0]
    try:
        validate_with_positions(token=token, validator=User())
        assert False, "Expected ValidationError exception"
    except ValidationError as error:
        # print(error.messages())
        assert len(error.messages()) == 2
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "The field 'email' is required."

# Generated at 2022-06-12 16:02:53.488696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"foo": Field(), "bar": Field()})
    # Required error
    token = Token("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc_info.value.messages()[0]
    assert message.code == "required"
    assert message.text == "The field 'bar' is required."
    assert message.start_position.char_index == 1
    assert message.end_position.char_index == 1
    # Type error
    token = Token("{foo: '1'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc

# Generated at 2022-06-12 16:03:01.842898
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    with open("tests/data/fixtures/data_v2.json") as f:
        json_text = f.read()

    class MySchema(typesystem.Schema):
        name = typesystem.String()

    class MyData(typesystem.Schema):
        people = typesystem.Array(item=MySchema())

    schema = MyData()
    try:
        schema.validate(json.loads(json_text))
    except typesystem.ValidationError as error:
        raise error

    # The line number is automatically added to the error message.
    assert (
        error.message()
        == "The field 'people' is required.\nLine 4, character 16"
    )

    # The column number is also available
    assert error.messages()[0].end

# Generated at 2022-06-12 16:03:13.430988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.testdata import validate
    from typesystem.tokenize.tokens import Token

    token = Token([1, 2], {"a": {"b": "foo"}})
    validator = validate.Schema
    output = validate_with_positions(token=token, validator=validator)
    assert output == [1, 2], repr(output)

    token = Token([1, 2], {"a": {"b": None}})
    validator = validate.Schema
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=validator)
    assert exc.value.messages()[0].index == ["a", "b"]

# Generated at 2022-06-12 16:03:21.529108
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Program
    @dataclasses.dataclass(frozen=True)
    class Program(Schema):
        """Program

        A program.
        """

        name: typing.Optional[str] = "Untitled"

    # Factory
    @dataclasses.dataclass(frozen=True)
    class Factory(Schema):
        """Factory

        A factory.
        """

        name: str = "Untitled"
        programs: typing.List["Program"] = dataclasses.field(default_factory=list)

    # Position
    @dataclasses.dataclass(frozen=True)
    class Position(Schema):
        """Position

        A position.
        """

        x: float = 0.0
        y: float = 0.0
        z: float = 0.0

    # Part
   

# Generated at 2022-06-12 16:03:30.773979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_path
    path = parse_path("/records/0/name")
    token = Token(path=path, start=path.start, end=path.end, value=None)
    field = Field(name="name", type="string", required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.index == ("records", 0, "name")
        assert message.start_position == path.start
        assert message.end_position == path.end



# Generated at 2022-06-12 16:03:40.281124
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.base.metadata import MetaData, merge_dict
    from typesystem.tokenize.tokens import Token
    from typesystem import fields
    from typesystem import schemas

    class PostForm(Schema):
        title = fields.String(required=True)
        body = fields.String(required=True)
        author = fields.String(required=True)

    data = {"title": 1, "body": 2, "author": 3}

    class TokenWithValue(Token):
        def __new__(cls, value, **kwargs):
            kwargs.update({"value": value})
            return super().__new__(cls, **kwargs)


# Generated at 2022-06-12 16:03:50.456891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    class Person(Schema):
        name = String(required=True)

    token = tokenize_string("name: Fo")
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=Person)

    message = e.value.messages[0]
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 7

    token = tokenize_string("name: Foo\nage:nine")

# Generated at 2022-06-12 16:03:59.759603
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, validators

    class Test(Schema):
        field = String(validators=[validators.MaxLength(3)])

    token = Token("Test", value={"field": "123456"})
    message = validate_with_positions(token=token, validator=Test).messages()[0]
    assert message.text == "Shorter than maximum length 3."  # type: ignore
    assert message.start_position.char_index == 16  # type: ignore
    assert message.end_position.char_index == 20  # type: ignore

    token = Token("Test", value={})
    message = validate_with_positions(token=token, validator=Test).messages()[0]
    assert message.text == "The field 'field' is required."  # type: ignore
    assert message

# Generated at 2022-06-12 16:04:13.825160
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokens import parse
    from typesystem.fields import String

    schema = parse("""
        - foo:
            - bar:
                - baz: string
    """)
    value = parse("""
        - foo:
            - bar:
                - baz: 123
    """)

    field = schema.items.items.items
    positional_error = None
    try:
        validate_with_positions(token=value, validator=field)
    except ValidationError as error:
        positional_error = error

    basic_error = None
    try:
        field.validate(value.value)
    except ValidationError as error:
        basic_error = error

    assert positional_error is not None
    assert basic_error is not None

# Generated at 2022-06-12 16:04:22.926586
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from dataclasses import dataclass
    from typesystem.fields import Integer

    from .utils import Tokenizer, Processor

    @dataclass
    class Article:
        id: int
        title: str

    class ArticleSchema(Schema):
        id = Integer(required=True)
        title = Integer(required=True)

    processor = Processor()
    processor.add_schema(ArticleSchema, Article)

    tokenizer = Tokenizer(processor)

    token = tokenizer.tokenize(
        """
        {
            "id": "foo",
            "title": 42
        }
    """
    )
    with pytest.raises(ValidationError) as error:
        validate_wit

# Generated at 2022-06-12 16:04:32.703975
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import pytest
    from typesystem.tokenize.json import JSONTokenizer, EOFToken
    from typesystem.tokenize.tokenize import Tokenizer, TokenType

    class Bool(Field):
        native_type = bool

    class Person(Schema):
        name = Field()
        age = Field(field_type=int)
        father = Field(field_type=Schema(name=Field(), age=Field(field_type=int)))

    def test_validate(input_: str, *, expected: str):
        with io.StringIO(input_) as fh:
            tokenizer = Tokenizer(JSONTokenizer(fh))
            root = RootToken(tokenizer)

# Generated at 2022-06-12 16:04:36.959510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields

    schema = fields.String(min_length=2)
    message = validate_with_positions(
        token=Token(value="a", start={}, end={}), validator=schema
    )
    assert message.text == "Must be longer than '1' characters."
    assert message.start_position == message.end_position == {}

# Generated at 2022-06-12 16:04:42.895997
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    schema = typesystem.Schema(fields={"foo": typesystem.Integer, "bar": typesystem.String})
    token = Token(
        value={
            "foo": "123",
            "bar": {"baz": "qux", "quux": {"corge": None}},
            "grault": "garply",
            "waldo": "fred",
            "plugh": "xyzzy",
            "thud": "",
        },
        start={"row": 0, "column": 0, "char_index": 0},
        end={"row": 0, "column": 0, "char_index": 0},
    )


# Generated at 2022-06-12 16:04:50.525830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(
        type="integer", description="An integer field.", example=42, minimum=0
    )
    field.validate(42)
    field.validate(0)
    with pytest.raises(ValidationError) as exc_info:
        field.validate(-1)
    error = exc_info.value
    token = Token(
        start=Position(line_index=0, line_number=1, char_index=0),
        end=Position(line_index=1, line_number=1, char_index=2),
        value=-1,
    )
    error_with_positions = validate_with_positions(token=token, validator=field)
    assert error.messages() == error_with_positions.messages()

# Generated at 2022-06-12 16:04:55.370234
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize, Position
    from typesystem.exceptions import ValidationError
    from typesystem.fields import Integer, String

    class Name(Schema):
        first = String()

    class Person(Schema):
        name = Name()
        age = Integer()

    json = {
        "name": {"first": "Foo"},
        "age": "not an int",
    }

    tokens = tokenize(json)
    try:
        validate_with_positions(
            token=tokens["age"], validator=Integer(name="age")
        )
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.start_position.token_index

# Generated at 2022-06-12 16:05:04.638982
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenError, StartPosition
    from pyrsistent import pmap
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.base import Message

    class User(Schema):
        name = String(required=True)


# Generated at 2022-06-12 16:05:10.346028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {"a": {"b": "foo"}}
    token = Token.from_value(data)

    class TestSchema(Schema):
        c = Field(required=True)

    assert validate_with_positions(token=token, validator=TestSchema) == {"a": {"b": "foo"}, "c": None}

# Generated at 2022-06-12 16:05:16.202891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Tokenizer
    token = Tokenizer(schema=String())('{"errors": {"foo": ["required"]}}')
    try:
        validate_with_positions(validator=String(), token=token)
    except ValidationError as error:
        assert list(error.messages()) == [
            Message(
                text="The field 'errors' is required.",
                code="required",
                index=[],
                index_type=None,
                start_position=Position(byte_index=1, char_index=1),
                end_position=Position(byte_index=2, char_index=2),
            )
        ]



# Generated at 2022-06-12 16:05:35.106875
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import ObjectToken, StringToken

    class Number(String):
        pattern = r"\d+"

    class Person(Object):
        properties = {"name": String(), "age": Number()}

    assert validate_with_positions(
        token=ObjectToken(
            value={
                "name": "John",
                "age": "Not a number",
            },
            start=tokenize.Position(line=1, col=1, char_index=0),
            end=tokenize.Position(line=3, col=18, char_index=28),
        ),
        validator=Person,
    ) == {"name": "John", "age": "Not a number"}


# Generated at 2022-06-12 16:05:43.844480
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Boolean, Integer, String
    from typesystem.validators import StringValidator

    class Schema(typesystem.Schema):
        """Schema."""

        class Meta:
            """Meta options."""

            strict = True

        name = String(max_length=1)
        lang = String(choices=["en", "de"], required=True)


# Generated at 2022-06-12 16:05:54.104303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {
        "name": "Alistair",
        "street_address": "1066 Southlake Dr",
        "age": 20,
        "links": [
            {
                "type": "home",
                "url": "https://www.meetup.com/algenra/",
            },
            {
                "type": "profile",
                "url": "https://github.com/algenra",
            },
        ],
    }
    token = Token(data)

    class Person(Schema):
        name = Field(type=str)
        street_address = Field(type=str)
        age = Field(type=int, minimum=18)

    class Link(Schema):
        type = Field(type=str, constrained_to=["home", "profile", "other",])

# Generated at 2022-06-12 16:06:02.168527
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import Document

    class ExampleField(Field):
        def validate(self, value):
            if not value.startswith("x"):
                raise ValidationError(text="Must start with x")
            return value

    class ExampleSchema(Schema):
        field = ExampleField()

    example_content = "test string with x"
    token = Document.from_string(content=example_content)

    # test that it works as expected with a simple field
    expected_message_text = "Must start with x"
    with pytest.raises(ValidationError, match=expected_message_text):
        validate_with_positions(token=token, validator=ExampleField())

    # test that it works as expected with a full schema

# Generated at 2022-06-12 16:06:11.258370
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: test field positions when error is raised
    # TODO: test error with nested array
    schema = Schema({"users": [Field(type="integer", required=True)]})
    doc = {
        "users": [1, 2, 3, 4]
    }
    token = Token.from_object(doc)

    validate_with_positions(token=token, validator=schema)

    doc = {
        "users": [1, None, 3, 4]
    }
    token = Token.from_object(doc)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 1

# Generated at 2022-06-12 16:06:21.740049
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str, required=True)

    token = Token(
        value={"name": "Joe"},
        start=Position(line=2, char_index=7),
        end=Position(line=2, char_index=20),
    )
    result = validate_with_positions(token=token, validator=Person)
    assert result == {"name": "Joe"}

    del token.value["name"]


# Generated at 2022-06-12 16:06:32.758229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Document, Key, StringToken

    class MySchema(Schema):
        foo = String()
        bar = String()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Document(
                [
                    Key("foo", value=StringToken(content="1", start=(0, 0), end=(0, 1))),
                ]
            ),
            validator=MySchema,
        )
    messages = exc_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "required"
    assert message.text == "The field 'bar' is required."
    assert message.index == ["bar"]


# Generated at 2022-06-12 16:06:43.550132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={"name": "John Doe"},
        start=Position(line=1, char_index=0),
        end=Position(line=2, char_index=0),
    )
    person = PersonSchema(name=Field(required=True))
    try:
        validate_with_positions(token=token, validator=person)
    except ValidationError as error:
        message = error.messages()[0]
        assert isinstance(message, Message)
        assert message.index == []
        assert message.text == "The field name is required."
        assert message.code == "required"
        assert message.start_position == token.start
        assert message.end_position == token.end


from typesystem.exceptions import ValidationError
from typesystem.fields import Field

# Generated at 2022-06-12 16:06:49.488299
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given
    from typesystem.tokenize.tokenize import Tokenizer

    from typesystem.fields import String, Integer
    from typesystem.schemas import Object
    from typesystem.tokenize import tokens

    tokenizer = Tokenizer()

    class Request(Schema):
        method = String(required=True)
        headers = Object(
            properties={
                "Content-Type": String(pattern=r"application/json"),
                "Content-Length": Integer(minimum=1),
            },
            required=True,
        )

    schemas = {"Request": Request}

    source = dedent(
        """\
        POST /foo HTTP/1.1
        Content-Type: application/json
        """
    )

    # When
    tokens = list(tokenizer.tokenize(source))

# Generated at 2022-06-12 16:06:58.197959
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import lexer
    from typesystem.tokenize.parser import parse

    token = parse(lexer("""
        {
            "name": "Samuel",
            "age": 32,
            "address": {
                "street": "123 Main St",
                "city": "Denver",
                "state": "CO",
                "zip": "12345"
            },
            "favorite_numbers": [1,2,3,4,5]
        }
    """))

    class AddressSchema(Schema):
        street = Field(required=True)
        city = Field(required=True)
        state = Field(required=True)
        zip = Field(required=True)

    class PersonSchema(Schema):
        name = Field(required=True)
        age = Field

# Generated at 2022-06-12 16:07:33.766563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema, types

    token = Token(value={"name": "Morty"}, children={})
    validator = schema({"name": types.String})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        messages = error.messages()
    assert len(messages) == 1
    assert messages[0].code == "required"
    assert messages[0].text == "The field 'age' is required."
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.char_index == 0
    assert messages[0].end_position.line_index == 0
    assert messages[0].end_position.char_index == 22



# Generated at 2022-06-12 16:07:40.692201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Foo(Schema):
        bar = Field(str, required=True)
        baz = Field(int, required=True)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=Token.parse("{+bar : \"string\"}"), validator=Foo
        )
    assert exc.value.messages == [
        Message(
            "The field 'baz' is required.",
            code="required",
            index=["baz"],
            start_position=(1, 0),
            end_position=(1, 0),
        )
    ]

# Generated at 2022-06-12 16:07:49.147595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Text, Object
    from typesystem.tokenize.tokenizers import JSONTokenizer

    class PersonSchema(Object):
        name = Text()

    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize('{"name": ""}', "string")
    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        assert [m.text for m in error.messages()] == [
            "The field 'name' is a required field."
        ]
        assert [m.code for m in error.messages()] == ["required"]
        assert [m.index for m in error.messages()] == [[]]

# Generated at 2022-06-12 16:07:56.147879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string

    class Person(Schema):
        name: str
        age: int

    token = parse_string('{"name": "Alice", "age": "bob"}')

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        pass
    
    assert len(error.messages()) == 2
    assert error.messages()[0] == Message(
        start_position=(0, 12, 12),
        end_position=(0, 13, 13),
        code="required",
        text="The field 'name' is required.",
        index=["name"],
    )

# Generated at 2022-06-12 16:08:06.752247
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import (
        FieldToken,
        ListToken,
        RootToken,
        Token,
        TokenType,
        ValueToken,
    )
    from typesystem.tokenize.utils import _tokenize

    Position = namedtuple("Position", "line char_index")

    class PositionedField(Field):
        def validate_value(self, value, **kwargs):
            try:
                return super(PositionedField, self).validate_value(value, **kwargs)
            except ValidationError as error:
                raise ValidationError(messages=error.messages)


# Generated at 2022-06-12 16:08:14.343018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Boolean, DateTime, AnyOf, List
    from typesystem import String

    from datetime import datetime
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token, TokenType

    class ExampleSchema(Schema):
        name = String(max_length=50)
        age = Integer(minimum=0, exclusive_maximum=99)
        is_staff = Boolean(default=False)
        created = DateTime()
        hobbies = List(AnyOf(String(pattern=r"^#[A-Z]+$"), Integer(minimum=0)))

    # no errors when valid

# Generated at 2022-06-12 16:08:26.074647
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokenizers import DEFAULT_TOKENIZER

    class Person(Schema):
        name = String(max_length=10)

    token = next(DEFAULT_TOKENIZER.parse("{'name': 'John'}"))  # type: ignore
    result = validate_with_positions(token=token, validator=Person)
    assert result == {"name": "John"}

    token = next(DEFAULT_TOKENIZER.parse("{}"))  # type: ignore
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

    error = excinfo.value
    assert error.messages()[0].start_position

# Generated at 2022-06-12 16:08:36.765125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema
    from typesystem.tokenize.tokens import DictToken, Positional

    schema = Schema(
        {"name": {"first_name": str, "last_name": str}, "age": int,}
    )
    token = DictToken(
        {"name": {"first_name": "Bob"}, "age": "twenty"},
        Positional(line_index=1, char_index=1),
        [],
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:08:46.165953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str)

    token = Token(value={"name": "Strawberry"}, start=(1, 0), end=(1, 17))

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "type"
        assert message.text == "Must be a string."
        assert message.index == (0, "name")
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 6
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 17

# Generated at 2022-06-12 16:08:55.517928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.parser import parse

    schema = Schema({"a": {"b": str}})
    token = parse('{"a": {"b": null}}', "<input>")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        positional_message = error.messages()[0]
        expected_message = Message(
            text="The field 'b' is required.",
            code="required",
            index=["a", "b"],
            start_position=token["a"]["b"].start,
            end_position=token["a"]["b"].end,
        )
        assert positional_message == expected

# Generated at 2022-06-12 16:10:00.737426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_schema_string  # noqa
    from typesystem import fields, schemas  # noqa

    transformers = [schemas.Dict, fields.String]
    schema = parse_schema_string("""{"a.b": "string"}""", transformers=transformers)

    document = {"a": {"b": 1}, "c": 1}
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token.from_data(document), validator=schema)
    message = exc_info.value.messages[0]
    assert message.text == "The field 'a.b' must be of type 'string'."
    assert message.start_position.line_index == 1
    assert message.start_position.char_

# Generated at 2022-06-12 16:10:09.784910
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, Object

    class PhoneNumber(Object):
        number = String()

    class Person(Object):
        name = String(max_length=6)
        phone = PhoneNumber.as_field()
        age = Integer(minimum=18)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token.from_object(
                {
                    "name": "John",
                    "phone": {"number": "9084234444"},
                    "age": 17,
                }
            ),
            validator=Person,
        )

    messages = exc_info.value.messages
    assert len(messages) == 2
    assert messages[0].code == "max_length"
    assert messages[0].index == ["name"]


# Generated at 2022-06-12 16:10:17.632858
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(name="a", value={}, start=[0, 0], end=[0, 0]),
            validator=Schema({"x": Field(type="integer")}),
        )
    assert excinfo.value.messages() == [
        Message(
            text="The field 'x' is required.",
            code="required",
            index=("x",),
            start_position=[0, 0],
            end_position=[0, 0],
        )
    ]

# Generated at 2022-06-12 16:10:27.809341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tokens import Location, Position, Token

    class User(Schema):
        name = Field(str)
        age = Field(str)

    user = User(
        {
            "name": "Alice",
            "age": 12,
        }
    )
    token = Token({}, {}, Location(Position(1, 1), Position(1, 2)))
    try:
        validate_with_positions(token=token, validator=user)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].text == "The field 'age' must be a string."
        assert messages[1].text == "The field 'name' must be a string."
        assert messages[0].start_position.char_index == 1

# Generated at 2022-06-12 16:10:35.335780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token.parse(
        "",
        {
            "type": "array",
            "items": {"type": "number"},
            "minItems": 2,
            "additionalItems": False,
        },
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=token.value)
    assert exc_info.value.messages()[0].start_position == Position(
        line_index=1, column_index=3, char_index=3
    )



# Generated at 2022-06-12 16:10:41.713979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    class Movie(typesystem.Schema):
        id = typesystem.Integer()
        title = typesystem.String()  # Mandatory field

    class Person(typesystem.Schema):
        id = typesystem.Integer()
        name = typesystem.String()

    class Cast(typesystem.Schema):
        cast_id = typesystem.Integer()
        movie = Movie()
        person = Person()
        role = typesystem.String()  # Mandatory field

    class MovieData(typesystem.Schema):
        movies = typesystem.Array(items=Movie(), min_items=1)
        cast = typesystem.Array(items=Cast(), min_items=1)


# Generated at 2022-06-12 16:10:52.438748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        name = Field(str)
        age = Field(int)

    def test(input, *, expected_text, expected_index):
        tokens = tokenize(input)
        try:
            validate_with_positions(token=tokens, validator=PersonSchema())
            assert False, "failed to raise ValidationError"
        except ValidationError as error:
            message = error.messages[0]
            assert message.text == expected_text
            assert message.index == expected_index

    test(
        """
        {
            name: "Paul"
        }
        """
    )


# Generated at 2022-06-12 16:11:02.238008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from string import whitespace as wspace
    from json import JSONDecoder
    from typesystem.base import ValidationError
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.streams import StringStream
    from typesystem.schemas import Schema
    from typesystem.fields import Field, String, Integer

    class MySchema(Schema):
        string_field = Field(type=String(min_length=4))
        integer_field = Field(type=Integer())

    stream = StringStream('{"string_field": "abc"}', decoder=JSONDecoder())
    tokens = tokenize(stream)
    try:
        validate_with_positions(token=tokens, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
       

# Generated at 2022-06-12 16:11:10.702111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokens

    field = String(min_length=1)

    token = tokens.create(
        [
            tokens.Value(
                value="foo",
                start_position=tokens.Position(
                    line_index=0, line_start=0, char_index=0, char_start=0,
                ),
                end_position=tokens.Position(
                    line_index=0, line_start=0, char_index=3, char_start=3,
                ),
            ),
        ],
    )

    assert validate_with_positions(token=token, validator=field) == "foo"