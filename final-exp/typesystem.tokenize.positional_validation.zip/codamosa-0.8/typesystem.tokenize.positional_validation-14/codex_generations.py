

# Generated at 2022-06-12 16:01:18.671436
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(value=dict(test="value"))
    class Schema1(Schema):
        test_field = Field(type="string")
    assert validate_with_positions(token=token, validator=Schema1) == dict(
        test_field="value"
    )
    class Schema2(Schema):
        test_field = Field(type="string", required=True)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Schema2)

# Generated at 2022-06-12 16:01:23.437202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, required=True)
        age = Field(int, required=True)

    token = Token.load(
        {
            "name": "eliot",
            "age": "101",
            "shoe": "size",
            "is_old": True,
            "parents": [{"name": "Lizzie", "age": "70"}, {"name": "Charlotte", "age": "70"}],
        }
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as exc:
        messages = [str(m) for m in exc.messages()]

# Generated at 2022-06-12 16:01:34.329213
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Foo(Schema):
        one = Field(type="string")
        two = Field(type="string")

    token = Token(
        key="foo",
        value={"one": "1", "two": "2"},
        start=Position(line_index=1, char_index=2),
        end=Position(line_index=3, char_index=4),
    )

    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=Foo)

    msg = e.value.messages[0]
    assert msg.text == "The field 'one' is required."
    assert msg.start_position.line_index == 1
    assert msg.start_position.char_index == 2

# Generated at 2022-06-12 16:01:45.391334
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import ParseResult
    from typesystem.tokenize.tokenize import tokenize_text

    class User(Schema):
        username = Field(r"\w+")
        userid = Field(r"\d+")

    class Post(Schema):
        title = Field(r"\w+")
        body = Field(r"\w+")
        author = Field(User)

    tokenized = tokenize_text('{"title": "hello", "author": {"userid": "123"}}')
    try:
        parse_result = validate_with_positions(
            token=tokenized, validator=Post  # type: ignore
        )
    except ValidationError as error:
        assert error
        messages = error.messages()
        assert len(messages) == 1
       

# Generated at 2022-06-12 16:01:52.668752
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_json

    from .test_tokenizers import JSON_SCHEMA_ADDRESS

    schema = Schema(fields={"address": JSON_SCHEMA_ADDRESS})
    json_text = """
    {
        "address": {
            "street": "",
            "city": "San Francisco",
            "state": "CA",
            "zipcode": "94105"
        }
    }
    """
    json_value = parse_json(json_text)
    error = None
    try:
        validate_with_positions(token=json_value, validator=schema)
    except ValidationError as exc:
        error = exc
    else:
        assert False, "Expected ValidationError"

    assert len(error.messages()) == 1


# Generated at 2022-06-12 16:02:02.674098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import yaml
    from typesystem.fields import String
    from typesystem.schemas import Object

    object_schema = Object(
        properties={"name": String(required=True)},
        additional_properties=False,
    )

    token = yaml.tokenize.Token(
        "map_key", yaml.Tokenizer.tokens["map_key"], "name", 0, 0, 0, 0, ""
    )


# Generated at 2022-06-12 16:02:13.083266
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    def validate_person(value):
        return validate_with_positions(
            token=Token(
                "Object",
                [
                    Token("Key", "name"),
                    Token("String", "Foo"),
                    Token("Key", "age"),
                    Token("String", "bar"),
                ],
            ),
            validator=Person,
        )

    from typesystem.exceptions import ValidationError
    import pytest

    with pytest.raises(ValidationError) as exception_info:
        validate_person({})

    messages = exception_info.value.messages()
    assert len(messages) == 1

# Generated at 2022-06-12 16:02:20.160072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"foo": {"type": "string", "required": True}})
    token = Token(
        start={"line_number": 1, "line_index": 0, "char_index": 0},
        end={"line_number": 1, "line_index": 0, "char_index": 7},
        value={"bar": "baz"},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "The field 'foo' is required."
    assert message.start_position.line_number == 1
    assert message.start_position

# Generated at 2022-06-12 16:02:30.055690
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem import types
    from typesystem.fields import Field

    class Person(Schema):
        name = types.String()

    class Book(Schema):
        author = types.Object(Person)
        title = types.String()
        price = types.Integer()

    class BookField(Field):
        def validate(self, value):
            return value

    Person.validate = validate_with_positions
    Book.validate = validate_with_positions
    BookField.validate = validate_with_positions

    document = """
    {
        "name": "Foo Bar",
        "title": "The Book of Foo",
        "price": "Ten"
    }
    """

# Generated at 2022-06-12 16:02:39.360864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import (
        Bytes,
        Dictionary,
        Integer,
        String,
        SubSchema,
    )
    from typesystem.tokenize.tokens import (
        BinaryToken,
        DictionaryToken,
        IntegerToken,
        StringToken,
    )
    from typesystem.tokenize.tokens import (
        Token,
        ValueToken,
    )

    class SubSchema(Schema):
        a = String()
        b = Integer()

    class Schema(Schema):
        a = Integer()
        b = SubSchema()
        c = Dictionary([String(), Integer()])


# Generated at 2022-06-12 16:02:53.892540
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.number import Number
    from typesystem.tokenize import tokenize_file
    from typesystem.tokenize.pygments import get_lexer

    input_string = "{" "  foo: 0,\n" "  bar: [{baz: 1}]\n" "}"
    token = tokenize_file(
        file=io.StringIO(input_string),
        lexer=get_lexer("python"),
    )
    schema = {
        "foo": Number(),
        "bar": [{"baz": Number()}],
    }

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.row == 2


# Generated at 2022-06-12 16:03:02.023860
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Object

    class Point(Schema):
        x = Field(required=True)
        y = Field(required=True)

    class Rectangle(Schema):
        top_left = Field(required=True, schema=Point)
        bottom_right = Field(required=True, schema=Point)

    JSON = """{
        "top_left": {
            "x": 0,
            "y": 0
        },
        "bottom_right": {
            "x": 10,
            "y": 10
        }
    }"""
    document = tokenize(JSON)
    resources = {
        "Point": Point,
        "Rectangle": Rectangle,
    }

# Generated at 2022-06-12 16:03:13.722031
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import Parser

    parser = Parser()
    validator = parser.parse(
        """
        x: integer
        y: integer
        z: integer
    """
    )

    with pytest.raises(ValidationError) as excinfo:
        value = validate_with_positions(
            token=parser.parse_token(
                """
                x: 7
                y: 1
            """
            ),
            validator=validator,
        )
    messages = sorted(excinfo.value.messages, key=lambda m: m.start_position.line)

# Generated at 2022-06-12 16:03:21.662968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    text = textwrap.dedent(
        """
    {
        "foo": true,
        "bar": "hello world",
        "baz": null
    }
    """
    )
    token = Token.parse(text)
    validator = String(required=True)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)

    message = error.value.messages()[0]
    assert str(message) == 'The field "foo" is required.'
    assert message.index == ["foo"]
    assert message.start_position.line_index == 3

# Generated at 2022-06-12 16:03:31.102261
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test for the function validate_with_positions()."""
    import pytest
    from typesystem.tests.test_schema import TestSchema
    
    schema = TestSchema()
    token = Token(value={"required": False, "nullable": False})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:03:40.488417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    from .utils import Tokens

    def _test_errors(token: Token, text: str, code: str) -> None:
        with pytest.raises(ValidationError) as excinfo:
            validate_with_positions(token=token, validator=Integer)
        assert excinfo.value.messages()[0].text == text
        assert excinfo.value.messages()[0].code == code

    schema = {"foo": {"bar": Integer()}}
    token = Tokens.loads(schema, [{"foo": {"bar": "123"}}])
    result = validate_with_positions(token=token, validator=schema)
    assert result == [{"foo": {"bar": 123}}]


# Generated at 2022-06-12 16:03:50.767953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import Token
    import typesystem

    RAW_TEXT = """
    {
        "name": "John Doe",
        "age": 30,
        "city": "Unknown"
    }
    """

    STRUCTURE = {
        "name": "John Doe",
        "age": 30,
        "city": "Unknown",
    }

    class ExampleSchema(Schema):
        name = typesystem.String()
        age = typesystem.Integer()
        city = typesystem.String(required=True)

    schema = ExampleSchema(strict=True)

# Generated at 2022-06-12 16:04:00.017793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    class Person(Schema):
        first_name = String(required=True)
        last_name = String(required=True)

    token = Token(
        value={
            "first_name": "Foo",
            "last_name": "Bar",
            "phone": 123,
            "email": "foo@bar.com",
        },
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=10, char_index=50),
    )
    try:
        validate_with_positions(token=token, validator=Person)
        assert False, "Should have thrown an error."
    except ValidationError as error:
        assert error.messages()[0].index == ["phone"]

# Generated at 2022-06-12 16:04:08.400619
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("""{"name":"foo"}""")[0]
    schema = typing.cast(Schema, {"name": Field(required=True)})
    try:
        return validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                code="required",
                text="The field 'name' is required.",
                index=(),
                start_position=(1, 0),
                end_position=(2, 0),
            )
        ]

# Generated at 2022-06-12 16:04:19.495214
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Author(Schema):
        name = Field(str)
        age = Field(int)

    class Book(Schema):
        title = Field(str)
        author = Field(Author)

    token = Token.from_python(
        {
            "title": "A Pirate's Life for Me",
            "author": {"name": "Hester", "age": 10},
        }
    )  # type: ignore

    try:
        validate_with_positions(token=token, validator=Book({"title": None}))
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 2


# Generated at 2022-06-12 16:04:31.068349
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class MySchema(Schema):
        username = String()
        password = String()
        age = Integer()

    data = {
        "username": "frank",
        "password": 123,
    }

    tokens = tokenize(data)
    token = Token(tokens)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema())


# Generated at 2022-06-12 16:04:39.927420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field(type="integer", required=True)
    token = Token(
        value={"foo": {"bar": {"baz": 17}, "spam": 2}, "eggs": 3},
        start=Position(line_index=1, char_index=3),
        end=Position(line_index=10, char_index=2),
    )
    assert validate_with_positions(token=token, validator=validator) == {
        "foo": {"bar": {"baz": 17}, "spam": 2},
        "eggs": 3,
    }
    token = Token.empty(start=Position(line_index=1, char_index=3), end=Position(line_index=10, char_index=2))

# Generated at 2022-06-12 16:04:48.832878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.schemas import JSONSchema
    from typesystem.tokenize.tokens import Token

    token = Token.from_dict(
        data={
            "string": "foobar",
            "nested": {
                "name": "John",
                "surname": "Smith",
                "address": {"city": "London"},
            },
        }
    )

# Generated at 2022-06-12 16:04:55.344794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from marshmallow import fields

    tokenize(
        {
            "name": "Example",
            "type": "object",
            "fields": [
                {"name": "foo", "type": "string"},
                {"name": "bar", "type": "integer"},
            ],
        }
    )

# Generated at 2022-06-12 16:05:01.767343
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from pytest import raises
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize.tokens import Token
    from typesystem.types import String
    from typesystem.tokenize.tokenize import tokenize_file

    with open("tests/test_json_schema_validate.json") as fp:
        data = fp.read()

    token = tokenize_file("tests/test_json_schema_validate.json", data)

    class SomeSchema(JSONSchema):
        answer = String(minimum_length=42, maximum_length=42)

    with raises(ValidationError):
        validate_with_positions(
            token=token, validator=SomeSchema
        )

# Generated at 2022-06-12 16:05:12.547140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringToken, ListToken

    class Test(Field):

        def validate(self, value: typing.Any) -> typing.Any:
            if value != "test":
                raise ValidationError("The value must be 'test'.")
            return value

    class Foo(Schema):

        bar = List(String)
        test = Test()

    token = ListToken([StringToken("test"), StringToken("bar")], "Foo", "bar")
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=Foo.fields["bar"])

    error = error_info.value
    assert error.messages()[0].text == "Item 1 is not valid."
    assert len(error.messages()) == 1

# Generated at 2022-06-12 16:05:23.525908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Intentionally written in the style of a doctest.
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token, TokenType

    schema = Schema({"name": String(max_length=3)})
    tokens = tokenize({"name": "hello"}, token_type=TokenType.FIELD_NAME)
    token = tokens[0]  # Token(
    # value="hello",
    # start=Position(row=0, col=0, char_index=0, line_index=1),
    # end=Position(row=0, col=5, char_index=5, line_index=1),
    # type=TokenType.FIELD_NAME,
    # )

# Generated at 2022-06-12 16:05:30.600262
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    @tokenize
    class ExampleSchema(Schema):

        name = String(min_length=3)

    schema = ExampleSchema()

    try:
        schema.validate({"name": "n"})
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "min_length"
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 2


validate_with_positions = validate_with_positions  # type: ignore

# Generated at 2022-06-12 16:05:40.820359
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String
    from typesystem.tokenize.sources import StringSource
    from pkg_resources import resource_string

    value = resource_string(__name__, "data/address.yaml").decode()
    source = StringSource(value=value, start_position=None)
    field = String(required=True)

    try:
        validate_with_positions(token=source, validator=field)
    except ValidationError as error:
        messages = error.messages()

    # This is what the parser should look like after the first pass

# Generated at 2022-06-12 16:05:48.045269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer
    schema = String(required=True) | Integer()
    with pytest.raises(ValidationError) as excinfo:
        token = Token(
            value="foo",
            start=Position(char_index=0, line_index=0, line_text="hello"),
            end=Position(char_index=3, line_index=0, line_text="hello"),
        )
        assert validate_with_positions(
            token=token, validator=schema
        ) == "foo"


# Generated at 2022-06-12 16:06:05.038631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean
    from typesystem.tokenize.tokens import PrimitiveToken

    class Person(Schema):
        name = Field(str)
        age = Field(int, required=True)

    token = PrimitiveToken("a", value={}, start=(1, 1), end=(1, 2))
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 2

    token = PrimitiveToken("a", value={"age": "one"}, start=(1, 1), end=(1, 2))

# Generated at 2022-06-12 16:06:11.840205
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Text
    from typesystem import String

    field = String(min_length=2)
    error = None

    try:
        validate_with_positions(token=Text(value="", start=0, end=0), validator=field)
    except ValidationError as error:
        pass

    assert len(error.messages) == 1
    message = error.messages[0]
    assert message.text == "The field '' is required."
    assert message.code == "required"
    assert message.index == []
    assert message.start_position == 0
    assert message.end_position == 0

# Generated at 2022-06-12 16:06:22.233718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.exceptions import TokenizationError
    from typesystem.tokenize.lexer import lex
    from typesystem.schemas import Object
    from typesystem.tokenize.parser import parse, parse_named_value
    from typesystem.fields import Integer, String
    from typesystem.tokenize.positions import Position, TokenPosition

    class TestSchema(Object):
        name = String()
        age = Integer(required=False)

    token_position = TokenPosition(source_name="test.py")
    position = Position(token_position, char_index=2)
    source = source = "name = 'A'\n"
    tokens = list(lex(source=source, position=position))
    value = parse(tokens=tokens).value

# Generated at 2022-06-12 16:06:32.955963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    class TestSchema(Schema):
        name = String(max_length=3)
        age = String(max_length=3)
        address = String(max_length=3)

    schema = TestSchema()

    with pytest.raises(ValidationError) as exc_info:
        token = tokenize('{"name": "foo", "age": "100"}', "json")
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages
    assert len(messages) == 1
    error = messages[0]
    assert error.text == "The field 'address' is required."
    assert error.index == ["address"]
    assert error.start_position.line

# Generated at 2022-06-12 16:06:43.549962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.fragment import Fragment, Position

    from typesystem.fields import (
        String,
        Integer,
        Boolean,
        Dict,
        Array,
        Object,
        String,
        Any,
    )

    source = """
    foo: bar
    bar: baz
    baz: qux
    """

    class TestSchema(Schema):
        foo = String(required=True)
        bar = String(required=True)
        baz = String(required=True)

    fragment = Fragment(
        source=source,
        position=Position(row=1, column=1, char_index=0),
        filename="example.yaml",
    )
    tokens = tokenize(fragment)


# Generated at 2022-06-12 16:06:53.361343
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import json_tokens, validate
    from typesystem import ResponseError

    # Setup
    data = "{ 'name': 'Alice', 'age': undefined }"
    tokens = list(json_tokens(data))
    person = {
        "name": "Alice",
        "age": 42,
    }
    Person = Schema(
        {"name": str, "age": int},
        strict=True, # disable undefined
    )
    # Run
    try:
        validate(Person, tokens)
    except ResponseError as error:
        assert len(error.messages) == 2
        assert error.messages[0].start_position.char_index == 10
        assert error.messages[0].code == "required"
        assert error.messages[1].start_position.char_index

# Generated at 2022-06-12 16:07:00.032255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={
            "type": "literal",
            "value": "Hello, world",
            "children": [
                {"type": "indentation", "value": "", "children": []},
                {"type": "string", "value": "Hello, world", "children": []},
            ],
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 1, "char_index": 15},
    )

    data = validate_with_positions(
        token=token,
        validator=Schema(fields={"type": Field(enum=["literal"]), "value": Field()}),
    )


# Generated at 2022-06-12 16:07:05.686674
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field(type="string", max_length=2)
    value = validate_with_positions(
        token=Token("abc", start=("abc", 1, 2, 3), end=("abc", 2, 3, 4)),
        validator=validator,
    )
    assert value == "ab"



# Generated at 2022-06-12 16:07:13.081645
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import List

    class Person(Schema):
        name = Field(str, max_length=5)
        age = Field(int, min_value=1)

    class Family(Schema):
        members = List[Person]()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token={"members": [{"name": "Bob", "age": 67}],},
            validator=Family,
        )

    message = exc_info.value.messages[0]
    assert message.text == "Must have no more than 5 characters."
    assert message.code == "max_length"
    assert message.index == ["members", 0, "name"]
    assert message.start_position.line_number == 1
    assert message.start_position

# Generated at 2022-06-12 16:07:23.996101
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import Integer, String

    field = Field(type=Integer)
    token = Token(value={"a": "hello world"}, start=(1,0), end=(1,17))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "The field 'a' is required."
    assert message.code == "required"
    assert message.start_position == (1, 0)
    assert message.end_position == (1, 17)

    field = Field(type=String, default="default string")

# Generated at 2022-06-12 16:07:45.869047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: This can be improved
    from typesystem.encode import decode

    schema = {"type": "string"}
    token = decode('{"type": "string"}')
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        # pylint: disable=protected-access
        assert message.text == "The field 'type' is required."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 0



# Generated at 2022-06-12 16:07:54.419179
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Unit test for validate_with_positions
    """
    import json
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer()

    data = '{"name": "Anna", "age": "twelve"}'
    # Generate tokens
    tokens = list(Person.tokenize(data))
    try:
        # The exception should contain the 'correct' positions of the errors
        validate_with_positions(token=tokens[1], validator=Person)
    except typesystem.ValidationError as error:
        for message in error.messages():
            print(message)
        assert json.dumps(
            [error.as_json() for error in error.messages()], indent=4
        ) == json

# Generated at 2022-06-12 16:08:04.066603
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem import fields

    tokenizer = Tokenizer(allowed_types=["string"])
    token_stream = tokenizer("1 2 3")
    token = next(token_stream)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=fields.Integer())

    error = excinfo.value
    message = error.messages()[0]
    assert message.text == "Invalid integer input."
    assert message.start_position.char_index == 0
    assert message.start_position.line_index == 0
    assert message.end_position.char_index == 1

# Generated at 2022-06-12 16:08:12.699303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token(
        "string",
        type="string",
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 6},
    )

    value = validate_with_positions(token=token, validator=field)
    assert value == "string"

    field = Field(type="string", required=True)
    token = Token(
        None,
        type="null",
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 3},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    messages = exc_info.value.messages()
    assert len

# Generated at 2022-06-12 16:08:25.141590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.utils import tokenizer, deserialize

    schema = deserialize(
        """
        title: string
        size: integer
    """
    )

    source = """
        {
            "title": "Hello",
            "size": "Not a number"
        }
    """

    token = tokenizer(source=source)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-12 16:08:35.751901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_token  # type: ignore

    class PersonSchema(Schema):
        name = Field(type="string", max_length=10)
        age = Field(type="number")

    token = parse_token(b"{\"name\": 123, \"age\": \"thirty\"}")
    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.line_index == 0
        assert error.messages()[0].start_position.char_index == 18
        assert error.messages()[0].end_position.line_number == 1

# Generated at 2022-06-12 16:08:43.127630
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import Lexer
    from typesystem.tokenize import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=True)

    token_value = {
        "_start": [0, 0],
        "name": ["name", [1, 4]],
        "age": ["age", [2, 3]],
    }
    token = Token(value=token_value, transform=lambda v: v[0])

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].text == "The field 'age' is required."

# Generated at 2022-06-12 16:08:53.823190
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        name = Field(type="string", max_length=10)
        age = Field(type="integer", minimum=18)

    data = '{"name": "John Doe", "age": 17}'
    token = tokenize(data)
    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        messages = error.messages()

        assert len(messages) == 1
        assert messages[0].code == "minimum"
        assert messages[0].index == ["age"]
        assert messages[0].text == "Must be greater than or equal to 18."

# Generated at 2022-06-12 16:09:04.692371
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_token

    token = parse_token('{"name": "John"}')
    from typesystem import Schema, fields
    from typesystem import error_messages

    class Person(Schema):
        name = fields.String(required=True)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        message = messages[0]
        assert message.text == error_messages.REQUIRED
        assert message.code == "required"
        assert message.index == ["name"]
        assert message.start_position == token.start_position.lookup(["name"])
        assert message.end_position == token.end_position

# Generated at 2022-06-12 16:09:14.173151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.fields import IntegerField
    from typesystem.schemas import Structure

    class ExampleSchema(Structure):
        a = IntegerField(min_value=0)

    token = Token(
        {"a": 1},
        {
            "a": [
                (
                    0,
                    2,
                    None,
                    None,
                    None,
                    "1",
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                    None,
                )
            ]
        },
        (1, 2),
        (3, 4),
    )

    # Test passing a value.

# Generated at 2022-06-12 16:09:40.960782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        email = Field(type="string", optional=True)

    data = {"name": "Vlad", "age": "incorrect type"}
    json_data = json.dumps(data)
    position = Token.positional(json_data)

    try:
        validate_with_positions(token=position, validator=PersonSchema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].code == "invalid_type"
        assert error.messages()[0].fields == ["age"]
        assert error.messages()[0].start_position.char_index == 20
        assert error.messages

# Generated at 2022-06-12 16:09:46.750285
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token
    from typesystem.tokenize.location import Location
    from typesystem.fields import String, Number

    token = Token(
        value={"hello": "world", "foo": {"bar": [1, 2]}},
        location=Location(filename="", line_number=20, char_index=4, column=4),
    )

    # Re-usable
    def validate(field: Field, value: typing.Any) -> None:
        validate_with_positions(token=token, validator=field)

    # Field tests
    validate(String(required=True), None)
    with pytest.raises(ValidationError):
        validate(String(required=False), None)
    validate(String(min_length=3), "hello")

# Generated at 2022-06-12 16:09:55.358660
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class A(Schema):
        a = Field(type="string")
        b = Field(type="string")

    class B(Schema):
        a = Field(type="string")

    class C(Schema):
        b = Field(type="string")

    class D(Schema):
        x = Field(type="string")

    class E(Schema):
        x = Field(type="string")

    class F(Schema):
        x = Field(type="string")

    class G(Schema):
        x = Field(type="string")

    # Test an unindexed error:

# Generated at 2022-06-12 16:10:06.023711
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    # Create a schema with a string field, and an integer field
    class MySchema(Schema):
        name = String()
        number = Integer()

    # Tokenize a string like:
    #
    # {
    #     "name": "Some text",
    #     "number": "Not a number"
    # }
    token = Token.from_string(
        """
    {
        "name": "Some text",
        "number": "Not a number"
    }
    """
    )

    # The schema should raise an error with a message, but the message should
    # be about "number"

# Generated at 2022-06-12 16:10:16.340041
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class TestField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            if not isinstance(value, int):
                raise ValidationError(self.messages["invalid_type"])
            return value

    class TestSchema(Schema):
        value1 = TestField(required=True)
        value2 = TestField(required=True)


# Generated at 2022-06-12 16:10:26.948474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Validation using `validate_with_positions` will properly preserve errors and their
    positions.
    """

    # Define a `Schema` and an invalid token.
    class MySchema(Schema):
        field = Field(str, min_length=1, max_length=10)

    invalid_token = Token(start=45, end=47, children=[])

    # Validate the invalid token against the schema.  Ensure that the errors are
    # reported with their correct positions.

# Generated at 2022-06-12 16:10:36.626186
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(required=True, type=str)

    token = Token.from_data(
        [
            {"name": "John"},
            {"name": "Joanna"},
            {"name": "Foo"},
            {"name": "Bar"},
            {"name": "Baz"},
            {"name": None},
        ]
    )
    token = token.lookup([1, "name"])

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1

        message = error.messages()[0]
        assert message.index == ["1", "name"]
        assert message.start_position == Position(line=3, char_index=13)

# Generated at 2022-06-12 16:10:43.439841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.errors import TokenizeError

    class MovieSchema(Schema):
        title = Field(type=str)
        rating = Field(
            type=int,
            required=lambda context: context.get("items") > 5,
            allow_null=True,
        )
        items = Field(type=int)

    tokens = Tokenizer(text="{title: 'Trainspotting', items: 10}")
    token = tokens.get_token()
    try:
        validate_with_positions(token=token, validator=MovieSchema)
    except TokenizeError as error:
        assert len(error.messages) == 4
        assert error.messages[0].code == "required"

# Generated at 2022-06-12 16:10:49.075624
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem_json_schema import JsonSchema  # noqa
    from typesystem.tokenize.tokenizer import Tokenizer  # noqa

    schema = JsonSchema({"required": ["title"]})
    tokenizer = Tokenizer()
    token = tokenizer.tokenize("{}", {"type": "object"})
    try:
        validate_with_positions(token=token, validator=schema)
        assert False
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 1
        assert message.end_position.char_index == 1

# Generated at 2022-06-12 16:10:59.936406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import Boolean, Integer, String
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken, ValueToken
    import typesystem
    import functools

    class Person(Schema):
        name = String()
        age = Integer(minimum=0)

    class User(Schema):
        person = Person()
        admin = Boolean()

    schema = typesystem.Schema(
        fields={"user": User()},
        array_field=User(),
        map_field=User(),
    )

    validate = functools.partial(validate_with_positions, validator=schema)
