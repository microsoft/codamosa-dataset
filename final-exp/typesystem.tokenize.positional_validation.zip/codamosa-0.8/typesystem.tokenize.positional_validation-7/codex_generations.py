

# Generated at 2022-06-12 16:01:22.990631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Position, JSONTokenizer

    class Foo(Schema):

        foo: str

    tokens = JSONTokenizer.tokenize("{}")
    errors = []
    try:
        validate_with_positions(token=tokens.next().value, validator=Foo)
    except ValidationError as e:
        for message in e.messages():
            errors.append(
                (
                    message.start_position.line_index,
                    message.start_position.char_index + 1,
                    message.text,
                )
            )

    assert errors == [(1, 1, 'The field "foo" is required.')]

    errors = []

# Generated at 2022-06-12 16:01:34.328156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(index=True)
        age = String(index=True)

    # Error messages contain token positions

# Generated at 2022-06-12 16:01:45.352543
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.json import tokenize

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)

    class Group(typesystem.Schema):
        group_name = typesystem.String(max_length=100)
        members = typesystem.Array(typesystem.Item(Person))

    # First test-case - missing 'name' field
    json_string = """
    {
      "members": [{}, {}, {}]
    }
    """
    token_tree = tokenize(json.loads(json_string))

# Generated at 2022-06-12 16:01:51.718002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer
    from typesystem.tokenize.positions import Position
    from typesystem.types import String
    from typesystem.validators import MinLength
    from typesystem.validators import MaxLength

    string_field = String(validators=[MinLength(2), MaxLength(5)])
    tokenizer = Tokenizer(string_field, start_position=Position(line_index=1))
    token = tokenizer.tokenize("abc")

# Generated at 2022-06-12 16:01:54.252703
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type=str)

    schema = PersonSchema()
    token = Token({"name": None})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert excinfo.value.messages[0].start_position == token.start

# Generated at 2022-06-12 16:02:01.583757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.examples.tokenize.cats import Cat

    source = """[ {
        "name": "Mimi",
        "favorite-foods": [ "tuna", "chicken" ]
    }, {
        "name": "Felix",
        "favorite-foods": [ "salmon" ],
        "likes-dogs": true
    }, { "name": "Garfield" } ]
    """

    cats = tokenize(source)
    print(cats.serialize(indent=4))
    cats.validate(Cat)

# Generated at 2022-06-12 16:02:12.217087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem import fields

    from typesystem.schemas import Schema

    class Comment(Schema):
        name = fields.String(required=True)
        body = fields.String(required=True)

    class CommentList(Schema):
        comments = fields.Array(items=fields.Object(Comment))

    json_data = {"comments": [{"name": "foo"}]}
    schema = CommentList()

    tokens = list(tokenize(json_data))

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=schema)


# Generated at 2022-06-12 16:02:16.582070
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer
    from typesystem.tokenize import tokenize

    token = tokenize("{}")

    class MySchema(Schema):
        age = Integer()

    validator = MySchema()
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.messages()[0].index[0] == "age"

# Generated at 2022-06-12 16:02:24.984588
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import Array, Boolean, Number, Object, String
    from typesystem import error_messages
    from typesystem.lexer.tokenize import tokenize_string
    from typesystem.tokenize import Token

    token = tokenize_string(text="[0, false, 'hello', {'foo':'bar'}, [1,2,3], null]")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token[0],
            validator=Array(
                items=[
                    Number,
                    Boolean,
                    String,
                    Object(properties={"foo": String}),
                    Array(items=[Number, Number, Number]),
                    String,
                ]
            ),
        )


# Generated at 2022-06-12 16:02:35.852686
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DocumentToken
    assert validate_with_positions(
        token=DocumentToken(
            type="DocumentToken",
            value=100,
            start=(1, 1),
            end=(1, 4),
            children=[],
        ),
        validator=Field(type=int, min_value=10),
    ) == 100
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=DocumentToken(
                type="DocumentToken",
                value=1,
                start=(1, 1),
                end=(1, 2),
                children=[],
            ),
            validator=Field(type=int, min_value=10),
        )
    messages = error.value.messages()


# Generated at 2022-06-12 16:02:46.863178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start=Message(line_index=0, char_index=0),
        end=Message(line_index=0, char_index=10),
    )
    token.look_children = lambda: [
        Token(
            value=None,
            start=Message(line_index=0, char_index=1),
            end=Message(line_index=0, char_index=10),
            name="name",
        )
    ]

    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-12 16:02:56.072136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.tokenize.nodes import List, Map, Scalar

    from .test_tokenize import mock_token

    class MockSchema:
        def validate(self, value):
            raise ValidationError(
                messages=[
                    Message(index=(), text="Error", code="error"),
                    Message(index=("a",), text="A error", code="error"),
                    Message(index=("b", 1), text="B1 error", code="error"),
                ]
            )

    schema = MockSchema()

# Generated at 2022-06-12 16:02:59.187940
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse_string

    with pytest.raises(ValidationError):
        validate_with_positions(
            token=parse_string(""), validator=Integer(required=True)
        )



# Generated at 2022-06-12 16:03:05.859189
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.test_json import test_json_schema
    from typesystem.tokenize.tokenizer import tokenize_json
    from typesystem.tokenize.utils import Context
    from typesystem.types import String
    from typesystem.validators import Required

    def make_error(text: str, *, start: int, end: int) -> Message:
        return Message(text=text, code="error-code", index=[], start_position=start, end_position=end)

    errors = [
        make_error("boom", start=0, end=1),
        make_error("sizzle", start=1, end=3),
    ]

# Generated at 2022-06-12 16:03:16.894398
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.parser import parse_json

    # Create a schema
    class Person(Schema):
        name = "string"
        age = "integer"

        @classmethod
        def validate(cls, data):
            return super().validate(data)

    # Test success
    data = parse_json(json.dumps({"name": "Bob", "age": 20}))
    Person.validate(data)

    # Test failure
    data = parse_json(json.dumps({"name": "Bob", "age": "20"}))

    with pytest.raises(ValidationError) as error_info:
        Person.validate(data)



# Generated at 2022-06-12 16:03:23.004873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import loads
    token = loads('''{
        "a": "1",
        "b": "2"
    }''')

    class Validator(Field):
        def validate(self, value, index=None):
            return value

    assert validate_with_positions(token=token, validator=Validator) == token.value

# Generated at 2022-06-12 16:03:32.559520
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields=[
        Field(name="foo", type="string", required=True),
        Field(name="bar", type="object", properties=[
            Field(name="baz", type="integer", required=True),
        ])
    ])
    data = {
        "bar": {
            "baz": "42"
        }
    }
    from typesystem.tokenize import tokenize
    token = tokenize(data)

# Generated at 2022-06-12 16:03:41.487312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array
    from typesystem.tokenize.tokenizer import tokenize

    def assert_positions(exc_info, code_lines, field, offset_column=0):
        assert isinstance(exc_info.value, ValidationError)
        for message in exc_info.value.messages():
            assert message.code == "required"
            token = tokenize(code_lines, position=message.start_position)
            assert token.text == field
            assert (
                message.start_position.char_index - offset_column
            ) == token.start.char_index
            assert message.start_position.line == token.start.line

    class User(Schema):
        name = String(max_length=10)

# Generated at 2022-06-12 16:03:43.773969
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from test_data import token, address_field

    assert validate_with_positions(token=token, validator=address_field) is None

# Generated at 2022-06-12 16:03:53.704373
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem import fields
    from typesystem.tokenize import token, tokens

    class Comment(Schema):
        name = fields.Text()
        tag = fields.Text()
        email = fields.Email()

    schema = Comment(required=["name"])


# Generated at 2022-06-12 16:04:05.238501
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class BookSchema(Schema):
        author = Field(type=str, required=True)
        title = Field(type=str, required=True)
        year = Field(type=int, required=True)

    schema = BookSchema()

    input = """
    {
        "author": "John Doe"
        "year": 2020
    }
    """
    token = Token.from_json(input)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        message = e.messages[0]
        assert message.text == "The field 'title' is required."
        assert message.end_position.line == 2
        assert message.end_position.char_index == 4
       

# Generated at 2022-06-12 16:04:13.078282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Starting with a Token instance.
    token = Token(value={})
    validator = Field(type="object", properties={"a": {"type": "string"}})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        messages = error.messages()
        assert messages == [
            Message(
                code="required",
                index=("a",),
                text="The field 'a' is required.",
                start_position=Position(line=0, col=0, char_index=0, byte_index=0),
                end_position=Position(line=0, col=0, char_index=0, byte_index=0),
            )
        ]

# Generated at 2022-06-12 16:04:23.527378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import (
        KeywordToken,
        LiteralToken,
        TextToken,
        TokenError,
    )
    from typesystem.tokenize.validators import validate_keyword, validate_text
    from typesystem.tokenize.token_types import token_types

    parser = Parser()

    literal_token = LiteralToken(
        value="abc",
        start=parser.position,
        end=parser.position,
        token_type=token_types["keyword"],
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=literal_token, validator=validate_keyword)


# Generated at 2022-06-12 16:04:31.480148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    validator = String()

    tokens = tokenize(b'{"x": "hi"}')
    message = validate_with_positions(token=tokens, validator=validator)
    assert message.start_position.char_index == 6
    assert message.start_position.line == 0
    assert message.end_position.char_index == 10
    assert message.end_position.line == 0

    tokens = tokenize(b'[{"x": "hi"}]')
    message = validate_with_positions(token=tokens, validator=validator)
    assert message.start_position.char_index == 7
    assert message.start_position.line == 0
    assert message.end_position.char_index == 11


# Generated at 2022-06-12 16:04:37.034298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from anytree import AnyNode, PostOrderIter

    from .test_tokenize import tokenize_string

    def test_validator_schema(schema_cls, **schema_kwargs) -> Schema:
        schema = schema_cls(**schema_kwargs)

        def wrap_validate(string: str) -> AnyNode:
            wrapper = AnyNode(schema=schema)
            token = tokenize_string(string)
            token.parent = wrapper
            schema.validate(token.value)
            return wrapper

        return wrap_validate

    def test_validator_field(field: Field) -> typing.Any:
        def wrap_validate(string: str) -> AnyNode:
            wrapper = AnyNode(field=field)
            token = tokenize_string(string)
            token.parent

# Generated at 2022-06-12 16:04:42.935148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from typesystem.tokenize import tokenize

    Value = namedtuple("Value", ["some", "data"])
    schema = Schema([Field("some", required=True), Field("data")])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize({"some": None, "data": "test"}), validator=schema
        )
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'some' is required."
    assert message.index == ["some"]
    assert message.start_position.line_number == 1

# Generated at 2022-06-12 16:04:50.582691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer, Token

    from . import ValidatorSchema

    class ValidatorInt(Field):
        validate_with_positions = validate_with_positions

        def __init__(self):
            super(ValidatorInt, self).__init__(components=[int])

    class TestValidatorSchema(ValidatorSchema):
        test = ValidatorInt()

    tokenizer = Tokenizer(json_schema=TestValidatorSchema().to_json_schema())
    tokens = tokenizer.tokenize('{"test": "foo"}')


# Generated at 2022-06-12 16:05:02.020971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_tokenizer import tokenize
    from .test_tokenizer import _make_tokens
    from typesystem.fields import Boolean
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.schemas import Array
    from typesystem.schemas import Nullable
    from typesystem.schemas import Literal

    tokens = tokenize("""
    {
        "a": true,
        "b": [
            "hello",
            "world",
            "!"
        ],
        "c": "foo"
    }
    """)

    tokens = _make_tokens(tokens)
    tokens = tokens[0].children[0]
    tokens = tokens.children[0]


# Generated at 2022-06-12 16:05:10.822709
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Foo(Schema):
        foo = Field(str)

    token = Token.parse("{"
                        "  'foo': 'bar',"
                        "}")

    try:
        validate_with_positions(token=token, validator=Foo)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field bar!r is required."
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 3
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 6

# Generated at 2022-06-12 16:05:21.672233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from jsonschema import validate
    from typesystem.schemas import JSONSchema

    class Address(JSONSchema):
        type: str
        street_address: str

    class Person(JSONSchema):
        name: str
        address: Address

    person = {
        "name": "Foo",
        "address": {
            "type": "home",
            "street_address": "123 Street",
        }
    }
    p = Person(person)

    try:
        validate_with_positions(token=p.token, validator=p)
    except ValidationError as error:
        assert error.message == "123 Street"
        error.normalize_messages()
        assert [e.text for e in error.errors] == [
            'The field "address" is required.',
        ]

# Generated at 2022-06-12 16:05:34.721683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import DocumentToken

    class Address(Schema):
        street = String(required=True)

    class Person(Schema):
        name = String()
        address = Address()

    class People(Schema):
        people = Address()

    invalid_data = {
        "people": [
            {"name": "Jon Doe"},
            {"name": "Jane Doe", "address": {"street": "42 Foo St."}},
            {"name": "John Smith", "address": {"street": 42}},
            {"address": {"street": "42 Bar St."}},
        ]
    }

    document = DocumentToken(invalid_data)

# Generated at 2022-06-12 16:05:43.625683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object, Property

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    # Without validate_with_positions
    person = Object(
        properties={
            "name": Property(
                start=1, end=1, value="Bob",  # type: ignore
            ),
        }
    )
    try:
        Person().validate(person)
    except ValidationError as error:
        try:
            message = error.messages()[0]
        except IndexError:
            pass
        else:
            assert message.text == "The field 'age' is required."
            assert message.start_position is None
            assert message.end_position is None

    # With validate_with_positions

# Generated at 2022-06-12 16:05:54.104080
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """ Ensure that ValidationErrors are updated with positional information.
    """
    from typesystem.schemas import Object

    class CarSchema(Object):
        fields = {
            "year": Field(types=int),
            "brand": Field(),
            "model": Field(),
        }
    
    vehicle = {
        "year": "1996",
        "brand": "Ford",
        "model": "Taurus",
    }

    from typesystem.tokenize import tokenize_object

    try:
        validate_with_positions(token=tokenize_object(vehicle), validator=CarSchema)
    except ValidationError as error:
        positional_messages = error.messages()
        assert len(positional_messages) == 1

# Generated at 2022-06-12 16:06:01.947063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.composites import Object
    from typesystem.fields import Field, String
    from typesystem.tokenize import tokenize

    validator = Object({"foo": String()})
    token = tokenize("{")
    token.end_position.char_index = 1
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    messages = exc_info.value.messages
    assert messages == [
        Message(
            text="The field 'foo' is required.",
            code="required",
            index=("foo",),
            start_position=token.end_position,
            end_position=token.end_position,
        ),
    ]



# Generated at 2022-06-12 16:06:11.126745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import JsonTokenizer
    from typing import Any, Union

    class Person(Schema):
        name: str
        age: int
        pet: Union[str, "Pet"]

    class Pet(Schema):
        name: str
        species: str
        age: int

    example = {
        "name": "jane",
        "age": 16,
        "pet": {"name": "bobby", "species": "dog", "age": 4},
    }

    error = None
    try:
        validate_with_positions(
            token=JsonTokenizer().tokenize(Any(example)), validator=Person
        )
    except ValidationError as e:
        error = e

    assert error
    assert len(error.messages()) == 1
    assert error.mess

# Generated at 2022-06-12 16:06:14.863013
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SchemaFromFile(Schema):
        file: str

    schema = SchemaFromFile()

    class FromFile(Field):
        validators = [validate_with_positions]

    class Schema(Schema):
        name: str
        file: FromFile

    schema = Schema(name="a")
    token = Token(value={}, start_position=None, end_position=None)
    assert token.validate(schema) == {"name": "a"}



# Generated at 2022-06-12 16:06:23.387202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import JsonTokenizer

    validator = {
        "key": {"type": str},
        "value": {"type": int},
    }
    token = JsonTokenizer().tokenize("{}")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(validator=validator, token=token)
    assert len(excinfo.value.messages) == 2
    assert excinfo.value.messages[0].text == "The field 'key' is required."
    assert excinfo.value.messages[0].start_position.line == 1
    assert excinfo.value.messages[0].start_position.char_index == 2

# Generated at 2022-06-12 16:06:33.168053
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"name": Field(str, required=True)})
    token = Token(
        value={"name": "Bruce"}, start={"line": 1, "column": 1}, end={"line": 1, "column": 11}
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

    assert len(error.value.messages) == 1
    message = error.value.messages[0]
    assert isinstance(message, Message)
    assert message.start_position == {"line": 1, "column": 1}
    assert message.end_position == {"line": 1, "column": 11}
    assert message.text == "The field 'name' is required."


# Generated at 2022-06-12 16:06:43.630899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import Scanner

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    def check_error(content: str, expected_index: int) -> None:
        try:
            p = Scanner(content).parse()
            validate_with_positions(token=p, validator=Person)
        except ValidationError as error:
            start = error.messages()[0].start_position.char_index
            assert start == expected_index
        else:
            assert False

    check_error(b"", 0)
    check_error(b'{"name": "foo"}', 1)

# Generated at 2022-06-12 16:06:49.533229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = {
        'int': '10',
        'string': 'foo',
        'nullable': '10',
        'list': [{'string': 'bar', 'int': '1'}, {'string': 'baz', 'int': '2'}]
    }
    token = Token('root', data)

    class Validator(Schema):
        int = Field(type=int)
        string = Field(type=str)
        nullable = Field(type=int, nullable=True)
        list = Field(type=list, items=Schema(
                                            int=Field(type=int),
                                            string=Field(type=str)))

    try:
        validate_with_positions(token=token, validator=Validator)
    except ValidationError as error:
        message = error

# Generated at 2022-06-12 16:07:10.204165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, tokenize_json

    class Person(Schema):
        name = Field(str)

    person_schema = Person()

    # failure without a token:
    with pytest.raises(ValidationError):
        person_schema.validate({})

    # failure with a token:
    with pytest.raises(ValidationError) as exc:
        tokens = tokenize(value={})
        token = next(tokens)
        validate_with_positions(token=token, validator=person_schema)
    assert exc.value.messages[0].start_position == (1, 1)
    assert exc.value.messages[0].end_position == (1, 2)

    # success with a token:

# Generated at 2022-06-12 16:07:20.115402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from typesystem.tokenize.lexers import Lexer
    from typesystem.tokenize.lexers import lexer

    source = b'{"foo": "bar"}'
    tokens = lexer(source)
    assert len(tokens) == 7

    class RootSchema(Schema):
        foo = Field(type="string")

    schema = RootSchema()
    assert validate_with_positions(token=tokens[0], validator=schema) == {}

    del source, tokens

    source = b'{"foo": 10}'
    tokens = lexer(source)
    assert len(tokens) == 5

    class RootSchema(Schema):
        foo = Field(type="string")

    schema = RootSchema()

# Generated at 2022-06-12 16:07:30.493045
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class A(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-12 16:07:35.759504
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String
    from typesystem.schemas import Schema

    token = ObjectToken(value={})
    try:
        validate_with_positions(token=token, validator=Schema({"name": String()}))
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].start_position.char_index == 2

# Generated at 2022-06-12 16:07:44.823760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_utils import ValueWithPositions
    from .test_utils import ValueWithPositionsField
    from typesystem.schemas import Schema

    class Address(ValueWithPositions):
        name: str
        street: str

    class Person(ValueWithPositions):
        name: str
        age: int
        address: Address

    class PersonSchema(Schema):
        name: ValueWithPositionsField
        age: ValueWithPositionsField
        address: ValueWithPositionsField

    person = Person(
        name=ValueWithPositions("Hank"),
        age=ValueWithPositions(34),
        address=Address(name=ValueWithPositions("Home"), street=ValueWithPositions("Street")),
    )
    result = validate_with_positions(token=person, validator=PersonSchema())
   

# Generated at 2022-06-12 16:07:52.159829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    token = Token(
        {
            "name": "Fred",
            "favorite_places": ["London"],
            "age": 20,
            "missing": None,
            "owner": {"first_name": "John", "last_name": "Smith"},
        },
        value=(0, 0),
    )

    schema = Schema(
        {
            "name": String(min_length=1),
            "age": String(min_length=1),
            "favorite_places": String(min_length=1),
            "missing": String(min_length=1),
            "owner": {"first_name": String(min_length=1), "last_name": String(min_length=1)},
        }
    )


# Generated at 2022-06-12 16:08:03.266928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import from_text, from_python

    from typesystem.schemas import Schema

    from typesystem.raw import String, Integer, Dict

    from typesystem.fields import Choice

    from typesystem.compat import Literal

    from typesystem.enums import Enum

    from datetime import datetime

    from typesystem.compat import Literal

    from typesystem.raw import String
    from typesystem.fields import Choice
    from typesystem.enums import Enum
    from typesystem.compat import Literal
    from typesystem.raw import String
    from typesystem.raw import Integer
    from typesystem.fields import Array
    from typesystem.fields import Sequence
    from typesystem.objects import Object
    from typesystem.fields import Boolean
    from typesystem.fields import Any

# Generated at 2022-06-12 16:08:12.036973
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    schema = Schema({"name": {"type": "string", "required": True}})
    token = Token(
        field="document", value={"name": "", "address": ""}, type="record",
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            index=("name",),
            code="required",
            start_position=Position(char_index=8, line_number=1),
            end_position=Position(char_index=13, line_number=1),
            text='The field "name" is required.',
        )
    ]



# Generated at 2022-06-12 16:08:24.344761
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.income import IncomeSchema, Field
    from typesystem.examples.income_tokenizer import income_tokenizer

    data = {
        "income": 10000,
        "allowances": {
            "personal": 0,
            "married": 0,
            "elderly": False,
            "dependents": 0,
        },
        "deductions": {
            "self_employed": False,
            "charity": False,
        },
    }

    tokens = income_tokenizer.tokenize(data)
    token = tokens.lookup(["allowances", "personal"])
    validator = Field(type="number")

    validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-12 16:08:34.075909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class DemoSchema(Schema):
        a = Field(required=True)

    schema = DemoSchema()
    token = Token(start="a", end="b", value=None)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'a' is required."
        assert message.code == "required"
        assert message.index == ["a"]
        assert message.start_position == "a"
        assert message.end_position == "b"



# Generated at 2022-06-12 16:08:57.081444
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import TokenizeParser
    from typesystem.tokenize.schemas import TokenizeSchema

    class MySchema(TokenizeSchema):
        foo = Field(type="integer")

    parser = TokenizeParser(schema=MySchema)

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=parser.parse("1a"), validator=MySchema())

    errors = error_info.value.messages()
    assert errors[0].start_position == (1, 2)
    assert errors[0].end_position == (1, 3)

    parser = TokenizeParser(schema=MySchema)


# Generated at 2022-06-12 16:09:07.982485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_schema
    from typesystem.tokenize.positions import Position

    schema = parse_schema('{"foo": {"type": "number"}}')
    tokens = schema.tokenize({"foo": "bar"})
    token = validate_with_positions(token=tokens, validator=schema)
    assert token == {"foo": "bar"}
    assert [
        message
        for message in token.messages()
        if message.start_position == Position(line=1, char_index=8)
    ] == [Message(text="The field 'foo' is required.")]

    token = schema.tokenize({"foo": {"bar": "baz"}})
    tokens = validate_with_positions(token=token, validator=schema)
    assert tokens

# Generated at 2022-06-12 16:09:16.055734
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.json

    token = typesystem.json.JSONParser(
        """
        {
          "name": "John Smith",
          "age": "42",
          "email": 1
        }
        """,
        start_position=typesystem.Position(),
    ).parse()

    class UserSchema(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer()
        email = typesystem.Email()

    try:
        validate_with_positions(token=token, validator=UserSchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.code == "invalid"
        assert message.index == ["email"]

# Generated at 2022-06-12 16:09:24.243589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.schemas import Schema
    from typesystem.tokenize.positions import Position, Span
    import typesystem.tokenize.tokens as TT

    data_token = TT.MapToken(
        span=Span(
            start=Position(column=0, line=0, char_index=0),
            end=Position(column=0, line=2, char_index=11),
        ),
        value={
            "type": "int",
            "required": "required",
            "choices": None,
        },
        errors=[],
    )

    class UserSchema(Schema):
        type = fields.String(min_length=1)
        required = fields.Boolean(default=False)
        choices = fields.List(fields.String())


# Generated at 2022-06-12 16:09:34.960362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyField(Field):
        def validate_value(self, value):
            if value == "foo":
                raise ValidationError("This is an invalid value.")

    field = MyField()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=Token("foo", (0, 0), (0, -1)), validator=field)

    validation_error = excinfo.value
    assert len(validation_error.messages()) == 1
    message = validation_error.messages()[0]
    assert message.text == "This is an invalid value."
    assert message.code == None
    assert message.index == []
    assert message.start_position.line == 0
    assert message.start_position.column == 0
    assert message.start_position.char_index

# Generated at 2022-06-12 16:09:45.997566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.bytestring_tokenize import BytestringTokenizer
    from typesystem.fields import Integer, String
    from typesystem.structures import Structure
    from typesystem.tokenize.base import tokenize

    class User(Structure):
        id = Integer()
        first_name = String(required=False)

    tokenizer = BytestringTokenizer()
    class_schema = User()
    schema = class_schema._schema.schema()
    data = b'{"id": "a", "first_name": 1}'
    stops = tokenize(tokenizer=tokenizer, data=data, schema=schema)
    root = stops.current()

    try:
        class_schema.validate(root.value)
    except ValidationError as error:
        assert len(error.messages())

# Generated at 2022-06-12 16:09:54.877319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import parse_token_tree
    from typesystem.tokenize.tokens import Token
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String as StringField

    class TestSchema(Schema):
        field = StringField(max_length=2)

    tree = parse_token_tree("""
        {
            "field": "foo"
        }
    """)
    token = Token.root(tree)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=TestSchema)
    messages = error.value.messages()
    assert messages[0].index == ["field"]
    assert messages[0].code == "max_length"


# Generated at 2022-06-12 16:09:55.569631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:10:06.193145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    class TestSchema(Schema):
        required = String(min_length=1)

    token = Token(
        {"hello": "world"},
        parent=Token(
            [{"foo": {"bar": "baz"}}], parent=Token({"foo": {"bar": "baz"}})
        ),
    )

# Generated at 2022-06-12 16:10:16.568757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.scanner import scan
    from typesystem.tokenize import definitions as token_definitions

    class IntSchema(Schema):
        value = Integer()

    schema = IntSchema()

    def test_schema(test_data, expected_result):
        tokens = scan(test_data)
        token = parse(tokens)
        assert validate_with_positions(token=token, validator=schema) == expected_result

    assert isinstance(test_schema, (unittest.FunctionType))

    def test_field(test_data, expected_result):
        tokens = scan(test_data)
        token = parse(tokens)


# Generated at 2022-06-12 16:10:47.260065
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:10:58.371549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenize import Tokenize
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import ObjectToken

    validator = String(required=True)
    tokenizer = Tokenize(validator)
    token = tokenizer.tokenize(b'{"test": "value"}')
    assert validate_with_positions(token=token, validator=validator) == 'value'

    token = tokenizer.tokenize(b'{"test": null}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    token = token.lookup(["test"])

# Generated at 2022-06-12 16:11:05.295216
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.exceptions import TokenizationError

    token = tokenize({"foo": "hello"})

    try:
        validate_with_positions(token=token, validator=Integer)
    except TokenizationError as error:
        message = error.messages()[0]
        assert message.text == "Expected Integer, got String."
        assert message.start_position.char_index == 7
        assert message.end_position.char_index == 12
        assert message.start_position.line_number == 1
        assert message.end_position.line_number == 1
    else:
        assert False, "ValidationError not raised."

# Generated at 2022-06-12 16:11:12.181035
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Record(Schema):
        title = Field(type="string")

    schema = Record()
    data = {"title": "the title"}

    token = tokenize(data)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field 'title' is required."
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 0

