

# Generated at 2022-06-12 16:01:12.774740
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:01:16.977842
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Create a trivial field
    class StringField(Field):
        primitive_type = str

        def validate(self, value, *, context=None) -> str:
            return value

    # Create a trivial field
    class IntField(Field):
        primitive_type = int

        def validate(self, value, *, context=None) -> int:
            return value

    # Create a dummy schema
    class TrivialSchema(Schema):
        x: int = IntField(required=True)
        y: str = StringField(required=True)

    # Create an empty token
    token = Token()

    # Attempt to validate a missing x field
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=TrivialSchema)

    # Set a bogus x field value

# Generated at 2022-06-12 16:01:24.314479
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import JsonSchema, fields

    schema_class = type(
        "schema", (JsonSchema,), {"required": fields.StringField(required=True)}
    )
    token = Token(
        value={"key": "value"},
        children=[Token("value")],
        start={"line_index": 0, "char_index": 5},
        end={"line_index": 2, "char_index": 5},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema_class)

    message = exc_info.value.messages[0]
    assert message.text == "The field required is required."
    assert message.code == "required"

# Generated at 2022-06-12 16:01:34.958587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token({"name": "Tom", "age": "twenty"},  # type: ignore
                  start=Token.Position(line=1, column=1, char_index=0),
                  end=Token.Position(line=1, column=16, char_index=15))

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].code == "invalid"
        assert messages[0].index == ["age"]

# Generated at 2022-06-12 16:01:46.184620
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import tokenize

    token = tokenize('{"foo": null, "bar": "baz"}')
    validator = Schema({"foo": {"type": "string", "required": True}, "bar": "string"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    assert exc_info.value.messages()[0].text == "The field 'foo' is required."
    assert exc_info.value.messages()[0].start_position.line_index == 1
    assert exc_info.value.messages()[0].start_position.char_index == 5
    assert exc_info.value.messages()[0].end_position.line_index == 1

# Generated at 2022-06-12 16:01:53.563029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typing import List

    from typesystem.tokenize.tokens import Token, StringToken, FieldToken, CollectionToken
    from typesystem.tokenize.tokens import OpenBracketToken, CloseBracketToken, FieldNameToken

    # NOTE: This should be in the test.fixtures module, but Pytest doesn't collect those
    # fixtures when pytest is called on tests in this module.

# Generated at 2022-06-12 16:02:03.819713
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        Boolean,
        Dictionary,
        Integer,
        Keyword,
        Mapping,
        Numeric,
        String,
        Symbol,
    )
    from typesystem.fields import Integer as _Integer
    from typesystem.schemas import Schema as _Schema
    from typesystem.exceptions import ValidationError as _ValidationError

    token0 = String('foo')
    token1 = Boolean(True)
    token2 = Integer(1)
    token3 = Dictionary([(token0, token2), (token1, token2)])
    token4 = Mapping([(token0, token1)])
    token5 = Symbol('foo')
    token6 = Keyword('foo')
    token7 = Numeric('2.718')

    assert validate_with_

# Generated at 2022-06-12 16:02:15.019321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    class Author(Schema):
        name = Field(type="string")

    class Post(Schema):
        title = Field(type="string", required=True)
        author = Field(type="object", schema=Author, required=True)

    post_input = {"author": {"name": "Erwin Blom"}}
    tokens = list(parse(post_input))
    post = Post()

    with pytest.raises(ValidationError) as exception_info:
        validate_with_positions(token=tokens[0], validator=post)

    assert len(exception_info.value.messages()) == 1
    message = exception_info.value.messages()[0]
    assert message.text == "The field 'title' is required."



# Generated at 2022-06-12 16:02:21.500125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.schemas import TestSchema, TestField
    from tests.tokenize.tokens import TestToken
    from typesystem.exceptions import ValidationError
    from typesystem.messages import Message

    token = TestToken(TestSchema, {"foo": "bar"})
    try:
        validate_with_positions(token=token, validator=TestField)
    except ValidationError as exc:
        assert len(exc.messages()) == 1
        message = exc.messages()[0]
        assert message == Message(
            code="required",
            index=(0, "foo"),
            text="The field 'foo' is required.",
            start_position=token.children[0].children[0].start,
            end_position=token.children[0].children[0].end,
        )
   

# Generated at 2022-06-12 16:02:27.759581
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.regex import RegexTokenizer
    from typesystem.tokenize.schema import TokenSchema
    from typesystem.text import Str

    schema = TokenSchema(
        token_name="int",
        parser=RegexTokenizer(token_name="int", pattern=r"\d+"),
        validators=[Str()],
    )

    token = schema.tokenize("5")

    error = None
    try:
        schema.validate(token)
    except ValidationError as e:
        error = e
    assert error
    assert error.messages()[0].text == "Value is not a string."
    assert error.messages()[0].start_position.char_index == 0
    assert error.messages()[0].end_position.char_index == 1


__

# Generated at 2022-06-12 16:02:40.088988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from textwrap import dedent
    from typesystem import Schema
    from typesystem.tokenize import tokenize

    class SchemaWithPositions(Schema):
        def validate(self, value):
            try:
                return super().validate(value)
            except ValidationError as error:
                return validate_with_positions(
                    token=tokenize(dedent(value)), validator=self
                )

    schema = SchemaWithPositions(
        {
            "name": str,
            "age": int,
            "occupation": {"sport": str, "occupation": {"name": str}},
        }
    )

# Generated at 2022-06-12 16:02:45.392028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import make_token
    from typesystem.types import Integer
    import pytest

    token = make_token({"value": 42}, [])
    validator = Integer()

    assert validate_with_positions(token=token, validator=validator) == 42

    token = make_token({}, [])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    exc_info.match(
        "The field 'value' is required."
    )

# Generated at 2022-06-12 16:02:50.176220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    from .test_fields import Person

    token = tokenize_string(
        """{
            "name": "  Joe",
            "age": "32.5"
        }"""
    )
    assert validate_with_positions(token=token, validator=Person) == {}



# Generated at 2022-06-12 16:02:59.270978
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)
        age = Integer()

    class TestSchema(Schema):
        user = UserSchema(required=True)

    token = Token(
        type="object",
        value={
            "user": {
                "name": "foo",
                "age": "123",
                "extra": "foo",
            },
            "extra": "bar",
        },
    )

    try:
        validate_with_positions(
            token=token, validator=TestSchema
        )
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'extra' is required."
        assert error.messages

# Generated at 2022-06-12 16:03:06.622461
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokenizer import Tokenizer

    class Person(Schema):
        name = String(max_length=100)
        age = Integer(minimum=18)

    stream = StringIO("name: John, age: 50")
    tokenizer = Tokenizer(stream)
    token = tokenizer.tokenize()
    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-12 16:03:17.553477
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Array
    from typesystem.tokenize.tokens import ObjectToken, StringToken

    raw_value = {
        "type": "person",
        "name": "John Doe",
        "addresses": [
            {"type": "street", "street": "Main Street"},
            {"type": "street", "street": "2nd Street"},
        ],
    }
    token = ObjectToken.from_raw(value=raw_value)

    class Address(Schema):
        type = String(enum=["street"], required=True)
        street = String()

    class Person(Schema):
        type = String(enum=["person"], required=True)
        name = String()
        addresses = Array(items=Address())


# Generated at 2022-06-12 16:03:26.700643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Book(Schema):
        name = Field(str)
        isbn = Field(str)

    data = {"isbn": "b"}
    token = Token(data=data)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Book)

    excinfo.match("The field 'name' is required.")
    excinfo.match("The field 'isbn' is required.")

    assert excinfo.value.start_position == Position(0,0)
    assert excinfo.value.end_position == Position(0,0)

# Generated at 2022-06-12 16:03:34.543225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Text

    text = '{"a": 4, "b": "foo"}'
    json_token = Token.from_text(text)

    class MySchema(Schema):
        a = Text()
        b = Text()

    try:
        validate_with_positions(token=json_token, validator=MySchema)
    except ValidationError as error:
        message = error.message()
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 10
        assert message.end_position.line_number == 1
        assert message.end_position.char_index == 11
        assert message.text == 'Expected a text field.'
    else:
        assert False, 'Expected ValidationError'

# Generated at 2022-06-12 16:03:42.604669
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Sequence

    sequence = tokenize("[1, 2, 3]")
    assert isinstance(sequence, Sequence)

    from typesystem.fields import String, Choice

    String.validate_with_positions = validate_with_positions
    Choice.validate_with_positions = validate_with_positions

    field = Choice(choices=[1, 2, 3])
    try:
        field.validate_with_positions(token=sequence)
    except ValidationError as error:
        messages = error.messages()
    else:
        assert False

    assert len(messages) == 3

# Generated at 2022-06-12 16:03:52.722943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import SimpleField
    from typesystem.tokenize.tokenize import Parser
    from typesystem.tokenize.tokens import ContainerToken, Token
    from typesystem.types import IntegerType

    p = Parser(lexers=["default"])
    data = {"a": {"b": 1}}
    container = ContainerToken(
        start=Token(None, None, None, scroll=""), end=Token(None, None, None, scroll=""), value=dict,
    )
    a = p.tokenize(data, container=container)
    a.lookup(["a"])
    b = SimpleField(type_=IntegerType(), required=True)


# Generated at 2022-06-12 16:04:09.875737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String

    class MySchema(Schema):
        a = Integer(required=True)
        b = String()

    schema = MySchema()
    data = {"a": 1}
    try:
        schema.validate(data)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert isinstance(error.messages()[0], Message)
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "The field 'b' is required."
        assert error.messages()[0].start_line == 1
        assert error.messages()[0].start_char == 2
        assert error.messages()[0].end_line

# Generated at 2022-06-12 16:04:20.833880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.storage.redis import RedisStorage
    from typesystem.fields import Any, Float
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Object, FloatToken, TextToken
    from typesystem.tokenize.tokens import FieldKey, FieldValue
    from typesystem.tokenize.tokens import Comma, Colon, Whitespace

    storage = RedisStorage(
        "127.0.0.1",
        6379,
        db=11,
        charset="utf-8",
        decode_responses=True,
        encoding="utf-8",
    )

    class JSONSchema(Schema):
        name = String(max_length=100)
        count = Integer(minimum=1, maximum=100)
        amount = Float()


# Generated at 2022-06-12 16:04:26.660224
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, fields as ts

    from tests.helpers import get_token

    schema = Schema({'title': ts.String(min_length=4)})

    token = get_token(path=['title'], start={"line": 42, "char_index": 13}, end={
        "line": 42, "char_index": 17
    })

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position == {
        "line": 42, "char_index": 13
    }

# Generated at 2022-06-12 16:04:34.666732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, String

    class MySchema(Schema):
        hello = String(required=True)

    token = Token(
        "root",
        [
            Token("hello", "world"),
        ],
        start=TokenPosition(source_name="foo.py", line=1, char_index=0),
        end=TokenPosition(source_name="foo.py", line=1, char_index=9),
    )
    validate_with_positions(token=token, validator=MySchema)



# Generated at 2022-06-12 16:04:43.901965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)

    try:
        validate_with_positions(
            token=tokenize(data='[{"name": "Jane"}]'), validator=Person
        )
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 1
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 18
        assert error.messages()[0].text == "The field name is required."
    else:
        pytest.fail("Should have raised a validation error")

# Generated at 2022-06-12 16:04:48.154677
# Unit test for function validate_with_positions
def test_validate_with_positions():
    s = Schema(fields={"foo": Field(type="string"), "bar": Field(type="string")})

    data = {"foo": "hello", "bar": "world"}
    root = Token(data=data, parent=None)
    token = root.lookup(["bar"])
    validate_with_positions(token=token, validator=s)
    assert token.value == "world"

# Generated at 2022-06-12 16:04:57.364186
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        name = Field(required=True, max_length=10)

    json = json.loads('{"name":"hello"}')
    validated = validate_with_positions(
        token=Token.from_mapping(json), validator=MySchema
    )
    assert validated == json

    json = json.loads('{"name":"hello"}')
    validated = validate_with_positions(
        token=Token.from_mapping(json), validator=MySchema
    )
    assert validated == json

# Generated at 2022-06-12 16:05:04.369014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pygments.token import Text as TextToken
    from typesystem.tokenize import tokenize

    from . import constructors


# Generated at 2022-06-12 16:05:16.001750
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema
    import yaml

    yaml_str = """
    address:
      street: main st
      city: school
      state: CO
    """
    Address = schema(
        {
            "street": schema.String(
                min_length=1
            ),  # must have min length as this fails validation
            "city": schema.String(),
            "state": schema.String(),
        }
    )
    with pytest.raises(ValidationError) as excinfo:
        token = yaml.tokenize.tokenize(yaml_str)
        validate_with_positions(token=token, validator=Address)

    messages = excinfo.value.messages
    assert [m.index for m in messages] == [
        ("address", "street"),
    ]

# Generated at 2022-06-12 16:05:26.477051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.tokenize import tokenize_string, Token

    schema = Object({
        "name": String(max_length=5),
        "tags": String(max_length=20, many=True),
        "metadata": Object({"description": String(min_length=10)}),
    })


# Generated at 2022-06-12 16:05:47.848766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Pet(Schema):
        name = Field(str, required=True)
        kind = Field(str, required=True)
        age = Field(int)

    class Person(Schema):
        name = Field(str, required=True)
        pets = Field([Pet])
    assert Person.validate({}) == {'name': 'missing field'}
    assert Person.validate({'name': 'Joe', 'pets': [{'age': 3}]}) == {'pets.kind': 'required field'}

    class Token:
        def __init__(self, value=None):
            self.value = value
        def lookup(self, index):
            return self

    class Position:
        def __init__(self):
            self.line_index = 1
            self.char_index = 1

# Generated at 2022-06-12 16:05:56.090966
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class ConfigSchema(typesystem.Schema):
        foo = typesystem.String(pattern="^bar$")

    class ArraySchema(typesystem.Schema):
        items = typesystem.Array(typesystem.Integer(minimum=0, maximum=1))

    from tokenize import tokenize, untokenize
    from io import BytesIO

    token_stream = tokenize(BytesIO(b'{"foo": "bar"}').readline)
    next(token_stream)
    root = Token.from_token_stream(token_stream)
    token = root.get_key("foo")
    schema = ConfigSchema()
    validate_with_positions(token=token, validator=schema["foo"])
    with pytest.raises(ValidationError) as exc:
        validate_with_

# Generated at 2022-06-12 16:05:57.118672
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 0

# Generated at 2022-06-12 16:06:05.274819
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import LiteralToken
    from typesystem.fields import String

    schema = String(max_length=10)
    token = LiteralToken({"name": "Abc"}, start=0, end=0)
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=schema)

    assert e.value.messages()[0].text == "Must have no more than 10 characters."
    assert e.value.messages()[0].start_position.char_index == 1
    assert e.value.messages()[0].end_position.char_index == 5



# Generated at 2022-06-12 16:06:13.140558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    input_text = """
    {
      "foo": 1,
      "bar": "abc"
    }
    """

# Generated at 2022-06-12 16:06:23.024329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.lexers import default_lexer
    from typesystem.tokenize import parse_tokens

    # Prepare schema and value
    schema = typesystem.Object(
        {"a": typesystem.Integer(minimum=0), "b": typesystem.Integer(maximum=10)}
    )
    value = {"a": -1, "b": 11}

    # Tokenize value
    tokens = default_lexer.tokenize(value)
    tokenized_value = parse_tokens(tokens)

    # Validate value
    try:
        validate_with_positions(token=tokenized_value, validator=schema)
    except ValidationError as error:
        messages = error.messages()

    assert len(messages) == 2
    assert messages

# Generated at 2022-06-12 16:06:23.735789
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test that errors are recorded in the correct positions
    pass #TODO

# Generated at 2022-06-12 16:06:24.357792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:06:33.767238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        type = Field(type=str)
        name = Field(type=str)

    token = Token(
        value={
            "type": "Person",
            "name": "Anna",
        }
    )
    validate_with_positions(validator=Person, token=token)

    token = Token(
        value={
            "type": "Person",
        }
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=Person, token=token)
    assert exc_info.value.messages()[0].start_position  # type: ignore

# Generated at 2022-06-12 16:06:44.143182
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields, schemas
    from typesystem.tokenize.tokens import TextToken, IntegerToken, Token

    schema = schemas.Schema(fields={"number": fields.Integer()})
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=Token(
                value={
                    "number": IntegerToken(
                        value="a", source="", start=(2, 3), end=(2, 4)
                    )
                },
                source="",
                start=(0, 0),
                end=(0, 0),
            ),
            validator=schema,
        )

    integer = TextToken(value="a", source="", start=(2, 3), end=(2, 4))

# Generated at 2022-06-12 16:07:00.240500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    Token

# End of test

# Generated at 2022-06-12 16:07:11.183040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup code
    from typesystem import fields, schemas
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.lexers import Lexer, LexerConfig
    import typesystem.tokenize.tokens as tokens

    class SimpleSchema(schemas.Schema):
        key = fields.Integer()

    lexer = Lexer(
        config=LexerConfig(
            opening_delimiter="{",
            closing_delimiter="}",
            key_value_delimiter=":",
        )
    )
    document = lexer.tokenize("""
    {
      "key": 3
    }
    """)
    # Exercise code

# Generated at 2022-06-12 16:07:17.049370
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert 42 == validate_with_positions(token=Token(value=42), validator=int)

    with pytest.raises(ValidationError) as error_info:
        assert 42 == validate_with_positions(token=Token(value=42), validator=str)
    messages = error_info.value.messages()
    assert len(messages) == 1
    assert messages[0].code == "invalid_type"
    assert messages[0].start_position == Token.Position(line=0, column=0, char_index=0)
    assert messages[0].end_position == Token.Position(line=0, column=2, char_index=2)

    schema = Schema({"a": int, "b": str})


# Generated at 2022-06-12 16:07:27.580149
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.tokens import JsonToken
    from typesystem.tokenize import tokenize

    class JSONValidator(typesystem.Schema):
        json = typesystem.JSON(required=True)

    token = tokenize(JSONValidator(), '{"json":"not_json"}')[0]
    error = validate_with_positions(token=token, validator=JSONValidator)
    messages = error.messages()
    assert messages[0].code == "invalid"
    assert messages[0].start_position.line_number == 1
    assert messages[0].start_position.char_index == 9
    assert messages[0].end_position.line_number == 1
    assert messages[0].end_position.char_index == 15

# Generated at 2022-06-12 16:07:36.231523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, TokenType, tokenize_json
    from typesystem.fields import String
    from typesystem.schemas import Schema

    token = tokenize_json(
        b"[{'name': 'foo', 'age': 71}, {'name': 'bar', 'age': 'blah'}]"
    )

    class User(Schema):
        name = String()
        age = Integer()

    class Users(Schema):
        class Meta:
            array = True

        user = User()

    users = Users()

    with pytest.raises(ValidationError) as error:
        users.validate(token.value)
    messages = error.value.messages()
    start_token = token.value[1]["age"]
    assert start_token.value == "blah"


# Generated at 2022-06-12 16:07:42.551727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array
    from typesystem.tokenize.tokens import decode_token_stream
    from typesystem.types import String
    from typesystem.validators import Required

    class Person(Schema):
        name = String(validators=[Required()])

    class People(Array[Person]):
        pass

    invalid: Dict[str, typing.Any] = {
        "people": [
            {},
            {
                "name": "Mark",
            },
        ]
    }

    tokens = decode_token_stream(invalid)
    token = tokens[0]

# Generated at 2022-06-12 16:07:48.580305
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.enums import Enum
    from typing_extensions import Literal

    from .parser import parse

    Color = Enum(values=["red", "green", "blue"])
    letters = parse("abc", "abc")
    with pytest.raises(ValidationError):
        validate_with_positions(token=letters, validator=Color)
    with pytest.raises(ValidationError):
        validate_with_positions(token=letters, validator=str)
    assert validate_with_positions(token=letters, validator=Literal["abc"]) == "abc"

# Generated at 2022-06-12 16:07:56.792809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        Keyword,
        Atom,
        List,
        Dict,
        Token,
    )
    from typesystem import Integer, Literal, Schema

    schema = Schema(
        {"name": Literal("Alice"), "age": Integer(gte=12)},
        title="Person",
    )


# Generated at 2022-06-12 16:07:58.295158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-12 16:08:03.687257
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    schema = {"foo": Integer, "bar": String(required=True)}

    from typesystem.tokenize.api import parse

    token = parse('{"foo": 1, "bar": 2}', schema=schema)

    with pytest.raises(ValidationError, match="The field 'bar' is required."):
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-12 16:08:38.341696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String

    class Person(Schema):
        name = String()
        age = Integer(minimum=0, maximum=150)

    Person({"name": "John Doe", "age": -1})

# Generated at 2022-06-12 16:08:44.983783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer  # type: ignore
    from typesystem.tokenize.parser import parse  # type: ignore
    from typesystem.tokenize.tokens import ErrorToken  # type: ignore
    from typesystem.tokenize import lexer  # type: ignore

    source = """
    def make_schema():
        pass
    """
    tokens = lexer(source)
    tree = parse(tokens)
    # Check that there are no errors:
    for token in tree.flatten():
        if isinstance(token, ErrorToken):
            raise Exception(f"Error at {token}")

    # Grab the body of the "make_schema" function
    make_schema_def_token = tree.lookup(["def"])
    make_schema_body_token = make_schema_

# Generated at 2022-06-12 16:08:45.879421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-12 16:08:53.611238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(required=True, type="string")

    token = Token(value=None, start=Position(line=1, column=1, char_index=0))
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    message = excinfo.value.messages[0]
    assert message.start_position == Position(line=1, column=1, char_index=0)
    assert message.end_position == Position(line=1, column=1, char_index=0)



# Generated at 2022-06-12 16:09:04.372327
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Number
    from typesystem.errors import ValidationError

    field = Number()
    text = "hello"
    start_position = None
    end_position = None
    token = tokenize(text, start_position, end_position)
    messages = []

    # Test no error
    field.validate(token.value)

    try:
        # Test validation error
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        messages = error.messages()

    assert len(messages) == 1

    # Test start attribute
    message = messages[0]
    assert message.start_position.line == 1
    assert message.start_position.col == 1

    # Test end attribute

# Generated at 2022-06-12 16:09:13.927599
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        Array,
        String,
        Integer,
        ArrayToken,
        StringToken,
        PositionToken,
    )

    from typesystem.fields import Array

    from typesystem.schemas import Schema

    from typesystem.validators import Length

    from typesystem.exceptions import ValidationError

    error = None
    try:
        validate_with_positions(
            token=ArrayToken([StringToken("a"), StringToken("b")], start=0, end=5),
            validator=Array(type=String(min_length=1), max_length=3),
        )
    except ValidationError as exc:
        error = exc
    assert len(error.messages()) == 1
    assert error.messages()[0].index == [1]


# Generated at 2022-06-12 16:09:21.624346
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Compound

    class TestSchema(Compound):
        field = String(required=True)

    errors = TestSchema.validate({})

    assert errors[0].code == "required"
    assert errors[0].start_position.char_index == 9
    assert errors[0].end_position.char_index == 12
    assert errors[0].start_position.line_number == 1
    assert errors[0].end_position.line_number == 1

    print(errors[0].message)
    # assert errors[0].message == "The field \"field\" is required. (at line 1)"

# Generated at 2022-06-12 16:09:30.524462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, union, Array, Boolean

    schema = union(Array, Boolean, String)
    token = Token(value="invalid")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].text == "Expected Array, Boolean, or String."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 7

# Generated at 2022-06-12 16:09:41.742329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokenizers import tokenize

    schema = {
        "name": "Person",
        "fields": [
            {"name": "name", "type": "string"},
            {"name": "age", "type": "integer", "required": False},
        ],
    }

    schema = typesystem.Schema.from_dict(schema)

    source = """
{
  "name": "Freddy Mercury",
  "age": 45
}
"""

    # There should be no errors.
    token = tokenize(source)
    validate_with_positions(token=token, validator=schema)

    # There should be two errors.
    source = """
{
  "age": 45
}
"""
    token = tokenize(source)

# Generated at 2022-06-12 16:09:51.909296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.parsers.json import parse_json

    token = parse_json(json.dumps({"x": "a"}))
    validator = typesystem.Schema(properties={"x": typesystem.String()})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position.line == 0
        assert error.messages()[0].start_position.char_index == 3
        assert error.messages()[0].end_position.line == 0
        assert error.messages()[0].end_position.char_index == 4

# Generated at 2022-06-12 16:11:04.422328
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.string import tokenize_string
    from typesystem.validators.schemas import validate_schema

    source = """
    {
        "image": "https://example.com/foo.png",
        "title": "New post",
        "content": null,
        "tags": [
            "news",
            "updates"
        ],
        "categories": null,
        "published": "never",
        "extra": {
            "foo": "bar"
        }
    }
    """
    token = tokenize_string(source)

# Generated at 2022-06-12 16:11:12.754040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Expense(Schema):
        type = Field(str)
        amount = Field(int, required=True)

    token = Token.from_json({"type": "food", "amount": 2})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=token, validator=Expense,
        )
    messages = exc.value.messages()
    assert messages[0].code == "required"
    assert messages[0].text == "The field 'amount' is required."
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.char_index == 14
    assert messages[0].end_position.line == 1
    assert messages[0].end_position.char_index == 20

