

# Generated at 2022-06-12 16:01:18.060456
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.validators import NotEmpty
    from typesystem.tokenize.tokens import Token
    from typesystem.contrib.tokenizers.python import tokenize as python_tokenize
    from typesystem.resources import schema_validators

    schema_validators.register("python", python_tokenize)

    class Foo(Schema):
        id = Integer(validators=[NotEmpty()])


# Generated at 2022-06-12 16:01:23.046301
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import SourceFile
    from typesystem.tokenize.tokens import String, Number, List, Object, KeyValuePair
    from typesystem.fields import String as StringField

    source = SourceFile({0: {"source": '{"foo": "bar"}', "name": "test"}}, "test")
    token = Object(
        KeyValuePair(String("foo"), String("bar")), start=source.location(1), end=source.location(9),
    )
    validate_with_positions(token=token, validator=StringField())

# Generated at 2022-06-12 16:01:34.406753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json, tokenize_yaml

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token, _ = tokenize_yaml("name: John")
    try:
        validate_with_positions(token=token, validator=Person)
        assert False, "Expected ValidationError: age missing"
    except ValidationError as error:
        assert error.messages()[0].text == 'The field "age" is required.'
        assert error.messages()[0].start_position == token.end
        assert error.messages()[0].end_position == token.end

    token, _ = tokenize_yaml("name: John\nage: twenty")

# Generated at 2022-06-12 16:01:41.165686
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String
    from typesystem.tokenize import tokenize_yaml

    tokens = list(tokenize_yaml("{key: value}"))
    validated_value = validate_with_positions(
        token=tokens[0], validator=String(min_length=5)
    )
    assert validated_value == "value"

# Generated at 2022-06-12 16:01:48.972140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json_lexer import JsonLexer
    from typesystem.tokenize.json_lexer import JsonLexerOptions

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=15)

    lexer = JsonLexer.create(options=JsonLexerOptions(allow_comments=True))
    tokens = lexer.tokenize("""
        {
            "name": "Hermione Granger"
        }
    """)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=PersonSchema)
    assert len(exc_info.value.messages) == 1
    message = exc_info

# Generated at 2022-06-12 16:01:56.867372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Raw

    class MySchema(Schema):
        field_1 = String(required=True)
        field_2 = String(required=True)
        field_3 = String(default="")

    token = Token({"field_1": "test_1", "field_2": "test_2"})
    result = validate_with_positions(token=token, validator=MySchema)
    assert result == {"field_1": "test_1", "field_2": "test_2", "field_3": ""}

    token = Token({"field_1": "test_1"})

# Generated at 2022-06-12 16:02:08.781169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import re
    import pytest

    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize, Token
    from typesystem.tokenize.tokens import TEXT

    text = "key = value"

    # Parse tokens from text string
    tokens = tokenize(text)

    # Create schema which uses the function validate_with_positions
    schema = Schema(fields={"key": String(required=True)}, validate=validate_with_positions)

    # Create token object from parsed tokens
    token = Token(tokens, {})

    # Validate token object using schema
    with pytest.raises(ValidationError) as excinfo:
        schema.validate(token)

    # Get ValidationError messages
    messages = excinfo.value

# Generated at 2022-06-12 16:02:16.656124
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions

    schema = Schema.from_string("""
        structure:
            first_name: string
            last_name: string
            age: number
            data:
                - structure:
                    first_name: string
                    last_name: string
    """)

    data = {
        "first_name": "Joe",
        "last_name": "Smith",
        "data": [
            {"first_name": "Jane", "last_name": "Doe"},
            {"first_name": "Mike", "last_name": "Doe"},
        ]
    }

    string = json.dumps(data)

    try:
        validate_with_positions(token=schema.parse(string), validator=schema)
    except ValidationError as error:
        message

# Generated at 2022-06-12 16:02:24.984919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Unit test for function validate_with_positions"""
    # pylint: disable=unused-argument
    import typesystem

    class PersonSchema(typesystem.Schema):
        name = typesystem.String(required=True)

    class PersonField(typesystem.Field):
        child = PersonSchema()

    from typesystem.tokenize import tokenize

    tokens = tokenize(PersonField, '{"name": "", "location": "here"}')
    token, _ = tokens
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(validator=PersonField, token=token)

    error = error_info.value
    assert error.messages[0].start_position.line_number == 1
    assert error.messages[0].start_position.column_number

# Generated at 2022-06-12 16:02:35.852510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ListToken, StringToken


# Generated at 2022-06-12 16:02:46.457090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import parse

    source = """{"some": [{}, {"a": "b"}]}"""
    token = parse(source)
    schema_source = """
    type: object
    properties:
      some:
        type: array
        items:
          type: object
          required:
            - a
          properties:
            a:
              type: string
    """

    schema = parse(schema_source, schema=True)

    try:
        validate_with_positions(validator=schema, token=token)
    except ValidationError as error:
        assert len(error.messages) == 2
        assert error.messages[0].text == "The field 'a' is required."
        assert error.messages[0].start_position.line == 0
        assert error.messages[0].start

# Generated at 2022-06-12 16:02:55.724899
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.tokens import Token, TokenType
    from typing import List, Tuple

    def find_token(
        tokens: List[Token], symbol: str, start: Tuple[int, int]
    ) -> Token:
        for token in reversed(tokens):
            if token.start.line == start[0] and token.start.char_index == start[1]:
                return token

    class MyField(Field):
        hash_key = "myfield"

        def validate(self, value):
            return value

        def get_as_string(self, value) -> str:
            return str(value)

    def validate_field(
        *, symbol: str, start: Tuple[int, int], end: Tuple[int, int], content: str
    ) -> None:
        token

# Generated at 2022-06-12 16:03:03.436368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Foo(Field):
        def __init__(self, **kwargs):
            super().__init__(**kwargs)

        def validate(self, value):
            if value != "bar":
                raise ValidationError("Invalid value for Foo")

    field = Foo()
    try:
        validate_with_positions(
            token=tokenize("foo"), validator=field
        )  # Expect failure
        assert False, "Expected failure"
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Invalid value for Foo"
        assert message.start_position.line == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line == 1
        assert message.end_

# Generated at 2022-06-12 16:03:14.886778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Source

    # An abstract schema
    class Abstract(Schema):
        sub_schema = Schema()

    # A concrete schema
    class Concrete(Abstract):
        pass

    # Missing required field
    try:
        validate_with_positions(
            token=Token(
                source=Source("abc"),
                value=Concrete(  # Missing required field
                    sub_schema=Concrete(  # Missing required field
                    ),
                ),
            ),
            validator=Concrete,
        )
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].code == "required"
        assert error.messages()[0].start_position.char_index == 25
        assert error.messages()

# Generated at 2022-06-12 16:03:22.224070
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize_json

    schema = String(serialized_name="The String")
    token = tokenize_json('"string"')
    assert validate_with_positions(token=token, validator=schema) == "string"

    token = tokenize_json('123')
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    assert exc.value.messages()[0].start_position.line_index == 0
    assert exc.value.messages()[0].start_position.char_index == 0
    assert exc.value.messages()[0].end_position.line_index == 0
    assert exc.value.messages()[0].end_

# Generated at 2022-06-12 16:03:30.186361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse

    token = parse('{"data": {"name": "value"}}')  # type: ignore
    validator = Field(
        fields={"data": Field(fields={"name": Field(required=True)})},
        required=True,
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)

    positional_message = error.value.messages[0]
    assert positional_message.index == ["data", "name"]
    assert positional_message.text == "The field 'name' is required."

# Generated at 2022-06-12 16:03:39.826932
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_value
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.types import Object

    class MySchema(Schema):
        foo = String(min_length=1)
        bar = String(min_length=1)
        baz = String(min_length=1)

    schema: MySchema = MySchema()

    value = {"foo": "x", "bar": "y", "baz": "z"}  # type: typing.Dict[str, str]
    token = tokenize_value(value)
    schema.validate(token.value)

    # Unsatisfiable value
    value = {"foo": "x", "bar": "y", "baz": None}

# Generated at 2022-06-12 16:03:44.894164
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ListToken, ObjectToken, StringToken

    def assert_error(
        token: Token, validator, expected_index: typing.List[int], expected_text: str
    ):
        with pytest.raises(ValidationError) as context:
            validate_with_positions(token=token, validator=validator)
        message = context.value.messages[0]
        assert message.text == expected_text
        assert message.index == expected_index
        assert isinstance(message.start_position, Position)
        assert isinstance(message.end_position, Position)

    validator = Schema(fields={"foo": Field(required=True)}, allow_additional_properties=False)
   

# Generated at 2022-06-12 16:03:54.894639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(min_value=0)

    token = Token(
        value={"name": "Alice", "age": "-3"},
        start=Person.name.start_position,
        end=Person.age.end_position,
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Person)

    messages = error.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'age' must be at least 0."
    assert message.code == "min_value"
    assert message.index == ["age"]

    assert message

# Generated at 2022-06-12 16:04:02.787707
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"name": Field(type="string")})
    token = Token(
        "object",
        {"name": Token("string", "")},
        start={"line": 4, "char": 20},
        end={"line": 7, "char": 5},
    )
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert excinfo.value.messages()[0].text == "The field 'name' is required."
    assert excinfo.value.messages()[0].start_position.line == 4
    assert excinfo.value.messages()[0].start_position.char_index == 20
    assert excinfo.value.messages()[0].end_position.line == 7


# Generated at 2022-06-12 16:04:20.709485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas.jsonschema import JsonSchema
    from typesystem.tokenize.fixtures import tokenize_document
    from typesystem.tokenize.schema import validate_with_positions as validate_token
    from typesystem.json_schema import Field as JSONField

    schema = JsonSchema(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "number"},
                "address": {"type": "string"},
            },
            "required": ["name", "age"],
        }
    )

    json_data = {
        "name": "Jenny",
        "age": "42",
    }

    document = tokenize_document(data=json_data)

# Generated at 2022-06-12 16:04:27.485433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DocumentToken

    from typesystem import fields

    # Fixtures
    document = """
    {
        "name": "hello",
        "null": null,
        "list": [1, 2, 3],
        "object": {
            "name_1": "hello",
            "name_2": "world"
        }
    }
    """

    token = DocumentToken(document)

    class SchemaItem(Schema):
        name = "name"
        type = fields.String(required=True)

    class Schema(Schema):
        name = fields.String(required=True)
        null = fields.Null()
        list = fields.List(items=fields.Integer())

# Generated at 2022-06-12 16:04:38.127544
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    request = {
        "name": "John Doe",
        "age": None,
        "email": None,
        "meta": {"foo": "bar"},
    }

    schema = UserSchema()

# Generated at 2022-06-12 16:04:47.599721
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    input = """
    foo: 1
    bar: 0
    """

    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.parse import parse_yaml
    from typesystem.tokenize.source import Source

    schema = {"foo": String()}
    source = Source(input)
    tokens = parse_yaml(source)
    token = Token.from_tokens(tokens)

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 2
        assert error.messages[0].start_position.char_index == 9
        assert error.messages[1].start_position.char_index == 21

# Generated at 2022-06-12 16:04:59.820013
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, String

    class TestSchema(Schema):
        foo = String(min_length=0)

    schema = TestSchema()
    token = Token("{foo: 1}", parent=None)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages() == [
        Message(
            code="type_error",
            index=("foo",),
            start_position=token.lookup("foo").start,
            end_position=token.lookup("foo").end,
            text="Expected type str.",
        )
    ]

    class TestSchema(Schema):
        foo = String(min_length=1)

   

# Generated at 2022-06-12 16:05:05.863793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    import pytest

    class Tree(Schema):
        children = [{"child": "Tree"}]
        name = "string"

    data = Tree()
    data.children.append({"child": {"children": [], "name": "hello"}})
    data.children.append({"child": {"children": [], "name": "hello"}})
    data.name = "A"

    tokens = tokenize(data)
    token = tokens[0]

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Tree)

    messages = exc.value.messages
    assert len(messages) == 2

# Generated at 2022-06-12 16:05:15.907433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SimpleSchema(Schema):
        field = Field(str, required=True)

    from typesystem.tokenize.tokenizer import tokenize

    tokens = tokenize(object_={})

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=SimpleSchema)
    messages = excinfo.value.messages()
    assert messages[0].code == "required"
    assert messages[0].text == "The field 'field' is required."
    assert messages[0].start_position.char_index == 0
    assert messages[0].end_position.char_index == 0

# Generated at 2022-06-12 16:05:26.397195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.schemas import Structure
    from typesystem.fields import String
    from typesystem.tokenize.position import StartPosition

    class BlogPost(Structure):
        title = String()

    tokens = tokenize("{}", "<test>")
    try:
        validate_with_positions(token=tokens, validator=BlogPost)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position == StartPosition(line=1, column=1, char_index=0)
        assert message.end_position == StartPosition(line=1, column=1, char_index=1)
        assert message.text == "The field 'title' is required."
    else:
        assert False  # prag

# Generated at 2022-06-12 16:05:34.270665
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    message = String(min_length=3)

    def validate(input, expected) -> None:
        token = tokenize(input, message)
        try:
            validate_with_positions(token=token, validator=message)
            assert not expected
        except ValidationError as error:
            assert str(error) == expected

    validate(input='"abc"', expected="")
    validate(input='"ab"', expected="[2:4] The value should be at least 3 characters long.")
    validate(input='null', expected="[1:5] The field value is required.")



# Generated at 2022-06-12 16:05:43.246792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import a_string, a_number
    from typesystem.schemas import Object, String, Integer

    token = Token(
        type="object",
        start={"line": 1, "char_index": 0},
        end={"line": 2, "char_index": 0},
        value={
            "name": Token(
                type="string",
                start={"line": 1, "char_index": 3},
                end={"line": 1, "char_index": 8},
                value="Alice",
            )
        },
    )

    class UserSchema(Object):
        name = String(max_length=4)
        age = Integer()

    # this errors out with line/column positions:

# Generated at 2022-06-12 16:06:06.947840
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.errors import TokenizeValidationError
    from typesystem.validators import String

    # Test a validation error from a field
    token = tokenize("foo: bar").token()
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=token.lookup(["properties", "numeric"]), validator=String()
        )

    # Test a validation error from a schema
    with pytest.raises(ValidationError):
        validate_with_positions(
            token=token, validator=typing.cast(Schema, schema_with_errors)
        )

    # Test a tokenize error that is not wrapped in a ValidationError
    with pytest.raises(TokenizeValidationError):
        validate

# Generated at 2022-06-12 16:06:13.419864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem.fields import String
    from typesystem.schemas import Schema

    token = parse('{"name": "tanim"}')

    class MySchema(Schema):
        name = String()

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == 'The field "name" is required.'
        assert message.start_position.line_number == 1

# Generated at 2022-06-12 16:06:23.224019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from simplejson import loads

    from typesystem.tokenize import tokenize

    class RootSchema(Schema):
        name = Field(type="string")
        emails = Field(type="array", items=Field(type="string"))

    data = """{
        "name": "Erin",
        "emails": ["invalid-email", "invalid-email2"]
    }"""
    token = tokenize(loads(data))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=RootSchema)
    error = exc_info.value
    assert len(error.messages) == 2
    message = error.messages[0]

# Generated at 2022-06-12 16:06:33.066899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, Schema

    schema = Schema(name=String(max_length=4), age=Integer())
    token = Token({
        "name": Token("Alice"),
        "age": Token("20")
    })

    value: dict = validate_with_positions(token=token, validator=schema)
    assert value == {"name": "Alice", "age": 20}

    payload = {"name": "Alice"}
    token = Token(payload)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        assert str(e) == (
            "ValidationError: The field 'age' is required. "
            "[('body', ('name',)), ('body', ('age',))]"
        )

# Generated at 2022-06-12 16:06:43.211292
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import LinePosition

    field = Field(type="string", required=True)
    token = Token(
        start=LinePosition(char_index=0),
        end=LinePosition(char_index=7),
        value=None,
        lookup=None,
    )
    error = pytest.raises(ValidationError, lambda: validate_with_positions(
        token=token, validator=field
    ))
    assert error.value.messages() == [Message(
        text="The field 'value' is required.",
        code='required',
        index=('value',),
        start_position=LinePosition(char_index=0),
        end_position=LinePosition(char_index=7),
    )]

# Generated at 2022-06-12 16:06:49.498573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import OrderedDict
    from typesystem.fields import CharField
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import (
        BaseToken,
        DictionaryToken,
        ListToken,
        PrimitiveToken,
        TokenPosition,
    )

    class Person(Schema):
        name = CharField(max_length=255)
        age = CharField(max_length=255)

    class MyToken(BaseToken):
        def __init__(self, value, start=None, end=None):
            self.value = value
            self.start = start
            self.end = end
            self.parent = None
            self.children = []

        def lookup(self, path):
            current = self

# Generated at 2022-06-12 16:06:58.170849
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, fields
    from typesystem.tokenize.tokens import Root

    class ObviousError(Exception):
        pass

    class TestSchema(Schema):
        string = fields.String()

    class SchemaWithException(Schema):
        nested = fields.Nested(TestSchema, allow_missing=True)
        string = fields.String(allow_missing=True)

        def validate(self, value):
            if value == {'nested': {'string': 'test'}}:
                raise ObviousError()

            return super().validate(value)


# Generated at 2022-06-12 16:07:08.007064
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class TestSchema(Schema):
        name = Field(str)
        age = Field(int, required=True)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)

    error = exc_info.value
    assert error.messages()[0].text == "The field 'age' is required."
    assert error.messages()[0].start_position.char_index == 1

# Generated at 2022-06-12 16:07:11.501832
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.tokenize.test_tokens import TestToken

    class TestField(Field):
        pass

    token = TestToken(value="foo", start=(0, 0), end=(0, 3))
    validate_with_positions(token=token, validator=TestField)

# Generated at 2022-06-12 16:07:17.284078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, token_to_string

    field = Field(type="string", required=True)

    tokens = tokenize("foo")
    assert validate_with_positions(token=tokens[0], validator=field) == "f"

    tokens = tokenize("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[0], validator=field)

# Generated at 2022-06-12 16:07:53.449146
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    import json
    import typesystem
    import pytest

    class Person(typesystem.Schema):
        name = types.String(required=True)
        age = types.Integer(required=True)

    json_data = json.loads('{"name": "John", "age": "34"}')

    error = None
    try:
        result = validate_with_positions(
            token=typesystem.tokenize_json(json_data), validator=Person
        )
    except typesystem.ValidationError as e:
        error = e

    assert error.messages[0].start_position.line == 1
    assert error.messages[0].start_position.col == 8
    assert error.messages[0].end_position.line == 1

# Generated at 2022-06-12 16:08:04.478100
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    source = """{
        "name": "Alice",
        "age": "35",
        "address": {
            "city": "London",
            "postal_code": "E1 6LT"
        }
    }"""

    # This code is used to test the Python 3.7.3 implementation,
    # where the error messages are not positional.
    if False:
        class SchemaWithPositions(typesystem.Schema):
            name = typesystem.String(max_length=20)
            age = typesystem.Integer()
            address = typesystem.Nested(
                {
                    "city": typesystem.String(max_length=20),
                    "postal_code": typesystem.String(max_length=10),
                }
            )


# Generated at 2022-06-12 16:08:12.810435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import tokenize

    class User(Schema):
        name = Field(str, required=False)
        password = Field(str, min_length=8)

    class Login(Schema):
        user = Field(User)
        remember_me = Field(bool, required=False)

    json = '{"user": {"name": "Bob"}, "rememberMe": true}'
    tokens = tokenize(json)
    try:
        Login.validate(tokens)
    except ValidationError as error:
        messages = error.messages()
        for message in messages:
            assert isinstance(message.start_position, int)
            assert isinstance(message.end_position, int)
            assert message.start_position < message.end_position

# Generated at 2022-06-12 16:08:25.279401
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import TextToken
    from typesystem.tokenize.tokens import ValueToken
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class UserSchema(Schema):
        id = Field(type='string')
        name = Field(type='string')
        email = Field(type='string')

    class TokenStub(Token):
        start = "start"
        end = "end"

    def test_errors():
        validator = UserSchema()

# Generated at 2022-06-12 16:08:35.792718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    def input_strings(input):
        if isinstance(input, str):
            return [input]
        if isinstance(input, (tuple, list)):
            return input
        return [input]

    def get_test_case(test_data):
        description, schema, input_string, expected_message = test_data

        if isinstance(schema, (tuple, list)):
            schema = Schema(fields=schema)

        input_strings_ = input_strings(input_string)
        expected_messages = [Message(**m) for m in expected_message]


# Generated at 2022-06-12 16:08:43.162871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import io
    from typesystem.schemas import JSONSchema

    text = """
    {
      "foo": "bar",
      "baz": "xyz"
    }
    """.strip()

    schema = JSONSchema({"required": ["foo"]})

    token = Token.parse(io.StringIO(text))
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'baz' is required.",
                code="required",
                index=("baz",),
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-12 16:08:45.028859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("test", start=Position(1, 0, 2), end=Position(1, 4, 5))
    field = Field(type="string")
    validate_with_positions(token=token, validator=field)



# Generated at 2022-06-12 16:08:54.979373
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given
    token = Token([("key", "value")])

    class TestField(Field):
        def validate(self, value, instance):
            if value == "wrong":
                raise ValidationError(message="bad")
            return value

    field = TestField()

    # When/Then
    assert validate_with_positions(token=token, validator=field) == "value"
    try:
        validate_with_positions(token=Token([("key", "wrong")]), validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "bad"
        assert error.messages()[0].end_position.line_index == 0
        assert error.messages()[0].end_position.char_index == 4
    else:
        raise AssertionError

# Generated at 2022-06-12 16:08:57.433433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 16:09:08.325248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.json import tokenize

    tokens = tokenize(json.dumps({"name": "", "age": 14}))
    schema = Schema(fields={"name": Field(required=True), "age": Field(required=True)})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens, validator=schema)
    message = exc.value.messages[0]
    assert message.start_position.line == 0
    assert message.start_position.column == 13
    assert message.start_position.char_index == 13
    assert message.end_position.line == 0
    assert message.end_position.column == 16
    assert message.end_position.char_index == 16

# Generated at 2022-06-12 16:10:09.145232
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.core.schema import Schema

    class RawSchema(Schema):
        class Meta:
            strict = True

        id = Field(typing.Optional[int], default=0)
        name = Field(str)
        description = Field(str)

    token = Token(value=loads(b'{"name": ""}'))

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=RawSchema)
    assert "The field 'name' is required." in str(excinfo.value)

# Generated at 2022-06-12 16:10:14.455910
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, properties, string

    class BasicPerson(Schema):
        name = properties.String(required=True)
        age = properties.Integer(minimum=0)

    schema = BasicPerson(unknown_properties=False)

    raw_data = {"name": "Alfred", "age": "thirty-three"}
    token = Token.from_data(raw_data)
    error = None
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as exc:
        error = exc

    assert error is not None
    assert len(error.messages()) == 1
    assert error.messages()[0].text == "Unable to convert to expected type."
    assert error.messages()[0].start_position.char_index

# Generated at 2022-06-12 16:10:26.108626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import Tokenizer
    from typesystem.tokenize.schemas import TokenSchema
    from typesystem import Integer, String

    tokenizer = Tokenizer(country="en")
    tokens = tokenizer(
        "name =A =B =C =D =E =F =G =H =I =J =K =L =M =N =O =P =Q =R =S =T =U =V =W =X =Y =Z"
    )

# Generated at 2022-06-12 16:10:36.026002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.token import Token, TokenType
    from typesystem.validators import String

    def check_message(
        actual: Message, expected: typing.Dict[str, typing.Any]
    ) -> None:
        assert actual.code == expected["code"]
        assert actual.start_position == expected["start_position"]
        assert actual.end_position == expected["end_position"]
        assert actual.text == expected["text"]

    def validate(input: str, validator: Field) -> None:
        lexer = Lexer(input=input)
        token = Token(type=TokenType.OBJECT)

# Generated at 2022-06-12 16:10:40.304116
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema

    schema = JSONSchema(
        {
            "type": "object",
            "properties": {
                "required": {"type": "integer"},
                "optional": {"type": "string", "default": "default value"},
            },
            "required": ["required"],
        }
    )

    document = "{"
    document += '"required": 20,'
    document += '"optional": "a string",'
    document += "}"
    token = schema.tokenizer(document)
    try:
        schema.validate(document)
    except ValidationError as error:
        assert len(error.messages()) == 2
        for message in error.messages():
            message = message.start_position
            assert message.byte_index == 1

# Generated at 2022-06-12 16:10:51.098759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import Dictionary, String

    try:
        validate_with_positions(
            token={"a": "0"},
            validator=Dictionary({"a": String(min_length=1)}),
        )
        assert False, "Did not raise ValidationError"
    except ValidationError as error:
        messages = error.messages()
        assert messages == [
            Message(
                text='The field "a" is required.',
                code="required",
                index=["a"],
                start_position=Position(
                    line_number=1, line_position=2, char_index=2
                ),
                end_position=Position(
                    line_number=1, line_position=3, char_index=3
                ),
            )
        ]



# Generated at 2022-06-12 16:11:00.810316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken

    class SimpleSchema(Schema):
        title = String()

    token = ObjectToken({"title": None})
    expected_message = Message(
        text="The field 'title' is required.",
        code="required",
        start_position=(1, 22),
        end_position=(1, 28),
    )
    try:
        validate_with_positions(token=token, validator=SimpleSchema)
    except ValidationError as error:
        assert error.messages() == [expected_message]
    else:
        raise AssertionError("Expected a ValidationError.")

# Generated at 2022-06-12 16:11:10.957181
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from django.core.exceptions import ValidationError as DjangoValidationError
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", minimum=18)

    data = {"name": "Jane Doe", "age": 17}
    token = tokenize(data)

    with pytest.raises(DjangoValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    message_chars = "\n".join(
        f"{m.text} ({m.start_position}, {m.end_position})"
        for m in exc_info.value.messages
    )
    assert message_chars