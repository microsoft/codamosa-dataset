

# Generated at 2022-06-22 06:08:07.206391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_json
    from typesystem import fields
    import typesystem

    example = '{"scalar": 1.0, "array": [1.0, 2.0], "object": {"name": "Sam"}}'
    token = parse_json(example)

    float_field = fields.Float()
    float_field.validate(token.lookup("array").value)

    float_array = fields.Array(items=float_field)
    float_array.validate(token.lookup("array").value)

    name_field = fields.String(min_length=3)

    class User(typesystem.Schema):
        name = fields.String(min_length=3)

    user_schema = User()

# Generated at 2022-06-22 06:08:16.585274
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.tokens import DocumentToken

    class Person(Schema):
        name = String(max_length=1)
        age = Integer()

    document = DocumentToken(
        "{'name': 'Joe', 'age': '1'}".encode(), "application/json"
    )
    try:
        validate_with_positions(token=document, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1

        message = error.messages()[0]
        assert message.code == "max_length"
        assert message.index == ["name"]
        assert message.text == "Must have no more than 1 characters."
        assert message.start_position.line == 1
        assert message.start_position

# Generated at 2022-06-22 06:08:28.308838
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Tokenizer
    from typesystem.schemas import List

    tokenizer = Tokenizer(
        lexer="{name: [1, null]}",
        parser="dict",
        schema={"name": List(items="string", allow_nulls=True)},
    )
    token = next(tokenizer)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=tokenizer.schema)
        assert len(error.messages) == 1
        assert error.messages[0].code == "required"
        assert error.messages[0].index == ("name", 0)
        assert error.messages[0].start_position.line == 1

# Generated at 2022-06-22 06:08:35.884917
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    string = String(required=True)
    token = Token.parse(
        "foo",
        start_position=0,
    )
    assert validate_with_positions(token=token, validator=string) == "foo"

    token = Token.parse("")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=string)

    assert excinfo.value.messages()[0] == Message(
        text='The field "value" is required.',
        index=("value",),
        code="required",
        start_position=0,
        end_position=4,
    )
    assert excinfo.value.messages()[0].start_position.get_rendered_line() == 3


# Generated at 2022-06-22 06:08:44.554279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import String, Number

    class TestSchema(Schema):
        foo = String(required=True)
        bar = Number(required=True)

    schema = TestSchema()
    token = Token.parse('{"foo": "", "bar": "baz"}')

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert str(exc_info.value).strip() == """
    Validation error at $.bar:
        1: error: The field 'bar' is required.
        2: error: Value must be a number."""

# Generated at 2022-06-22 06:08:55.094637
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    schema = typesystem.Object(properties={"name": typesystem.String()})
    token = Token.from_string(json.dumps({"name": "John Doe"}), separators=[",", ":"])

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        raise AssertionError(
            "Unable to validate JSON string: "
            + " ".join(
                f"{message.code} at {message.start_position.char_index}..{message.end_position.char_index}: {message.text}"  # noqa E501
                for message in error.messages
            )
        )

# Generated at 2022-06-22 06:09:06.890695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    token = parse("{name: 'Jane Smith'}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        message = messages[0]
        assert message.text == "The field 'age' is required."
        assert message.code == "required"
        assert message.index == ("age",)
        assert isinstance(message.start_position, Position)
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 17
        assert isinstance(message.end_position, Position)

# Generated at 2022-06-22 06:09:08.847937
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from os import path
    from typesystem import String, Number, Schem

# Generated at 2022-06-22 06:09:17.923605
# Unit test for function validate_with_positions
def test_validate_with_positions():

    fields = {"fieldName": {"type": "string", "required": True}}
    schema = Schema(fields=fields)
    input = {"fieldName": "test"}
    token = Token(key=None, value=input, parent=None)
    validate_with_positions(validator=schema, token=token)

    # test that required is enforced
    input = {}
    token = Token(key=None, value=input, parent=None)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(validator=schema, token=token)

        field_name = "fieldName"
        assert field_name in str(excinfo)
        


# Generated at 2022-06-22 06:09:28.771349
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, parse
    from typesystem.fields import String

    schema = String("name")
    token_data = tokenize("""
    { "name": "A" }
    { "name": "B" }
    { "A": "C" }
    """)
    tokens = parse(token_data)
    assert len(tokens) == 3
    token = tokens[2]
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field name is required."
        assert message.code == "required"
        assert message.index == []
        assert message.start

# Generated at 2022-06-22 06:09:43.336243
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string

    def validate(text: str, *, validator):
        token = parse_string(text)
        validate_with_positions(token=token, validator=validator)

    schema = Schema(properties={"x": str, "y": str})
    validate("{ 'x': 'a' }", validator=schema)
    with pytest.raises(ValidationError) as error:
        validate("{ 'x': 'a' }", validator=schema)
    assert [m.text for m in error.value.messages()] == ["The field 'y' is required."]

# Generated at 2022-06-22 06:09:53.017492
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenize import tokenize

    class TestSchema(Schema):
        foo = Integer()

    token = tokenize("{foo}", TestSchema)
    validator = token.lookup(index=["foo"])

    try:
        validate_with_positions(token=validator, validator=TestSchema.fields["foo"])
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=token.start,
                end_position=token.end,
            )
        ]



# Generated at 2022-06-22 06:10:05.824702
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema(typesystem.Schema):
        person = typesystem.SchemaField(Person)

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer()

    schema = Schema({"person": {"name": "Kurt", "age": "foo"}})
    token = Token.from_schema(schema)

# Generated at 2022-06-22 06:10:16.742915
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest


# Generated at 2022-06-22 06:10:22.697095
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name: Field[str, ...]
        age: Field[int, ...]

    class People(Schema):
        people: Field[Person, ...]

    tokens = toke

# Generated at 2022-06-22 06:10:32.620904
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class PersonValidationError(ValidationError):
        def as_message(self) -> Message:
            return Message(
                text="Validation error.",
                code="validation_error",
                start_position=Position(file="", char_index=0),
                end_position=Position(file="", char_index=0),
            )

    class Person(Schema):
        name = String(min_length=1)
        age = Integer(minimum=21)


# Generated at 2022-06-22 06:10:43.548727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(str)

    json_str = "{}"
    token = Token(value=json.loads(json_str), start=0, end=len(json_str))

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=User)

    message = exc.value.messages[0]
    assert message.code == "required"
    assert message.index == ["name"]
    assert message.text == "The field 'name' is required."
    assert message.start_position == Position(
        line_number=1, char_index=2, line="{}"
    )
    assert message.end_position == Position(
        line_number=1, char_index=2, line="{}"
    )



# Generated at 2022-06-22 06:10:53.711085
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Test the validate_with_positions helper.

    """
    # Test with list-like fields that raise a ValidationError.
    text = """
    foo:
    - 123
    -
    """
    schema = Schema([Field(integer())])
    token = tokenize(text)
    action = lambda: validate_with_positions(schema=schema, token=token)
    error = pytest.raises(ValidationError)
    error.match(
        (
            "The field '.' is required.",
            {
                "code": "required",
                "index": (0,),
                "start_position": (1, 3),
                "end_position": (1, 3),
            },
        )
    )

# Generated at 2022-06-22 06:11:04.122512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lexers, parsers
    from typesystem.fields import String
    from typesystem.schemas import Object

    class MySchema(Object):
        a = String()

    lexer = lexers.JSON()
    parser = parsers.JSON(lexer=lexer)
    tokens = parser.parse('{"a": 42}')
    token = tokens

    with pytest.raises(
        ValidationError,
        match=re.escape('[Message(text="invalid literal")]'),
    ):
        validate_with_positions(token=token, validator=MySchema)


# Generated at 2022-06-22 06:11:15.653659
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken

    from .utils import StreamPosition

    token = TextToken(
        value=["key", "value"],
        start=StreamPosition(1, 2, 0),
        end=StreamPosition(1, 4, 2),
    )

    class Schema(Schema):
        key = Field()

    schema = Schema()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'key' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 1

# Generated at 2022-06-22 06:11:33.589803
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from .fixtures import JSON_STRING
    from .utils import parse_document

    document = parse_document(JSON_STRING)
    schema = Schema({"name": {"type": "string", "max_length": 8}})
    try:
        validate_with_positions(token=document, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.end_position.line == 4
        assert message.end_position.char_index == 40
        assert message.start_position.line == 4
        assert message.start_position.char_index == 20

# Generated at 2022-06-22 06:11:43.177905
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokens, tokenize

    from typesystem import String, Structure

    class Person(Structure):
        name = String(required=True)

    try:
        validate_with_positions(
            token=tokenize("{}"), validator=Person
        )
    except ValidationError as error:
        assert isinstance(error, ValidationError)
        assert error.messages() == [
            Message(
                text='The field "name" is required.',
                code="required",
                index=("name",),
                start_position=tokens.Position(char_index=1),
                end_position=tokens.Position(char_index=1),
            )
        ]

# Generated at 2022-06-22 06:11:57.452588
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lex
    from typesystem.tokenize.fields import TokenField
    from typesystem.schemas import ObjectSchema
    from typesystem.fields import String

    class Person(ObjectSchema):
        name = TokenField(type=String())
        age = TokenField(type=String())

    assert validate_with_positions(
        token=lex("{name: 'george', age: '35'}"), validator=Person()
    ) == {"name": "george", "age": "35"}

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=lex("{age: '35'}"), validator=Person(required=["name"])
        )

# Generated at 2022-06-22 06:12:03.031528
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Property, Object

    field = Field(required=True)
    token = Object({"foo": Property("", "bar")}, 0, 0)

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=field)



# Generated at 2022-06-22 06:12:13.725523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pygments.token import Token
    from pygments.lexers.go import GoLexer
    from typesystem.positions import Position
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token as Tk
    from typesystem.tokenize.lexers import Lexer

    content = """
    package main
    import "fmt"
    """

    lexer = Lexer([(GoLexer, {}, None)])
    lines = list(lexer.tokenize(content))

    field = String(required=True)

# Generated at 2022-06-22 06:12:23.769625
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.parser import parse_line
    from typesystem.tokenize.parser import parse_program
    from typesystem.tokenize.formats.simple_format import SimpleFormat

    schema = {"name": String(), "age": String()}
    validator = Schema(schema)
    token = parse_line("name=bob age=44", SimpleFormat())
    assert validate_with_positions(token=token, validator=validator) == {
        "name": "bob",
        "age": "44",
    }

    program = """
    # comment
    [defs]
    bob = bob
    [output]
    name = ${defs.bob}
    """
    tokens = parse

# Generated at 2022-06-22 06:12:33.565464
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Schema
    from typesystem.tokenize.tokens import Token

    schema = Schema({"name": String(min_length=1), "age": Integer(minimum=1)})
    token = Token(
        {"name": "Junebug", "age": 12},
        start=(1, 0),
        end=(2, 1),
        children=[
            Token("Junebug", start=(1, 6), end=(1, 13)),
            Token(12, start=(2, 7), end=(2, 8))
        ],
    )
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-22 06:12:44.703223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    class Item(Schema):
        name = String(required=True)

    from typesystem.tokenize import tokenize

    tokens = tokenize("{name: 'foo'}")
    assert isinstance(tokens, dict)
    assert isinstance(tokens['name'], Token)
    assert tokens['name'].value == 'foo'

    value = validate_with_positions(token=tokens, validator=Item)
    assert value['name'] == 'foo'

    tokens = tokenize("{}")
    assert isinstance(tokens, dict)
    assert isinstance(tokens['name'], Token)
    assert tokens['name'].value is None


# Generated at 2022-06-22 06:12:54.566817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Object
    from typesystem.tokenize.parser import parse

    class TestSchema(Object):
        field1 = Integer()
        field2 = String()

    input_data = parse("{field2: 123, field1: 'Not a number'}")
    try:
        validate_with_positions(token=input_data, validator=TestSchema())
    except ValidationError as error:
        messages = error.messages(flat=True)

    assert messages[0].text == "The field 'field1' is required."
    assert messages[0].code == "required"
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.char_index == 1
    assert messages[0].end

# Generated at 2022-06-22 06:12:55.564217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:13:19.287303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.fields import String
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.positions import Position

    class MySchema(Schema):
        """A simple schema with a required string field."""
        myfield = String(required=True)

    token = StringToken("myfield", value={"myfield": "Hello"}, start=Position(0))

    # This validation should fail because the string field is required.
    try:
        validate_with_positions(token=token, validator=MySchema)
    except typesystem.ValidationError as e:
        [message] = e.messages()
        assert message.text == 'The field "myfield" is required.'
        assert message.start_position.char_index == 0
        assert message.end_

# Generated at 2022-06-22 06:13:28.366316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ObjectToken

    class User(Schema):
        name = Field(required=True)

    token = ObjectToken({"name": "Trevor"}, "", "")

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-22 06:13:36.148362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class SimpleToken(Token):
        start: str
        end: str
        value: int

    class SimpleValidator(Field):
        value_type = int

    # Simple case
    sample = SimpleToken(start="(0:0)", end="(0:1)", value=1)
    assert validate_with_positions(token=sample, validator=SimpleValidator) == 1

    # Simple error case
    sample = SimpleToken(start="(0:0)", end="(0:1)", value=None)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=sample, validator=SimpleValidator)
    assert exc_info.value.text == "The field None is required."

    # Indented error case
    sample

# Generated at 2022-06-22 06:13:47.644230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Dictionary
    from typesystem.tokenize.tokens import List
    from typesystem.tokenize.tokens import String
    from typesystem.tokenize.tokens import Token

    from typesystem.fields import Integer
    from typesystem.fields import String as StringField
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = StringField()

    class PersonListSchema(Schema):
        people = List()

    class ImageSchema(Schema):
        url = StringField()

    class ContentSchema(Schema):
        people = PersonListSchema()

    class PostSchema(Schema):
        title = StringField()
        content = ContentSchema()
        author = PersonSchema()


# Generated at 2022-06-22 06:13:59.585642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import tokenize
    from typesystem.tokenize.serialize import serialize  # type: ignore
    from typesystem.fields import String

    # Test a valid string
    valid_string_token = tokenize(b'"Hello, world!"')
    assert serialize(validate_with_positions(token=valid_string_token, validator=String()))

    # Test a missing string
    missing_string_token = tokenize(b'{}')
    assert serialize(validate_with_positions(token=missing_string_token, validator=String()))

    # Test an integer where a float is expected
    invalid_string_token = tokenize(b'"Oops!"')

# Generated at 2022-06-22 06:14:10.165373
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pprint import pformat
    from typesystem import fields

    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(max_value=99)
        parent = fields.String()

    class Family(Schema):
        mother = fields.Schema(Person)
        father = fields.Schema(Person)
        children = fields.Array(items=fields.Schema(Person))

    import typesystem.tokenize.tokenizers
    tokenizers = typesystem.tokenize.tokenizers
    tokenizer = tokenizers.get_tokenizer("yaml")
    text = """
    children:
        - 
    """
    token = tokenizer.tokenize(text)
    with pytest.raises(ValidationError) as error:
        Family.validate(token.value)


# Generated at 2022-06-22 06:14:21.847046
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        username = Field()

    try:
        validate_with_positions(
            token=Token(
                value={"username": "", "friends": []},
                start=TokenPosition(line=1, char_index=3),
                end=TokenPosition(line=2, char_index=4),
            ),
            validator=UserSchema,
        )
    except ValidationError as error:
        assert error.messages() == [
            Message(
                index=(("username",),),
                text="The field 'username' is required.",
                code="required",
                start_position=TokenPosition(line=1, char_index=4),
                end_position=TokenPosition(line=1, char_index=6),
            )
        ]

# Generated at 2022-06-22 06:14:29.916897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_type
    from typesystem import fields, errors

    token = tokenize_type({})
    try:
        validate_with_positions(token=token, validator=fields.Integer(required=True))
    except errors.ValidationError as error:
        [message] = error.messages()
        assert message.text == "The field 'integer_field' is required."
        assert message.start_position.line == 0
        assert message.start_position.char_index == 1



# Generated at 2022-06-22 06:14:42.580179
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.lexer import lex
    from typesystem.parser import parse
    import json

    example_json = """
    {
        "number": 1,
        "text": "Hello!",
        "object": {
            "a": 1,
            "b": "two",
            "c": {
                "d": 3
            }
        },
        "array": [
            "a",
            "b",
            {
                "c": null
            }
        ]
    }
    """
    tokens = lex(example_json)
    root = parse(tokens)

    class ExampleSchema(Schema):
        number = Field(required=False)
        text = Field(required=False)
        object = Field(required=False)
        array = Field(required=False)


# Generated at 2022-06-22 06:14:54.419728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse_tokens import parse_tokens, parse_token

    token = parse_tokens(
        """
  {
    "key": "value",
    "key2": "value2",
    "key3": "value3",
    "key4": {
        "subkey": "subvalue"
    }
  }
  """
    )[0]

    class Object(Schema):
        key = Field(type=str)

    try:
        validate_with_positions(validator=Object, token=token)
    except ValidationError as error:
        for message in error.messages():
            print(message)

        assert message.start_position.line == 2
        assert message.start_position.column == 2

# Generated at 2022-06-22 06:15:35.551557
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        name = Field(str, required=True)
        age = Field(int, required=True)


# Generated at 2022-06-22 06:15:45.567462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.types import String

    source = """
    {
        "foo": "bar",
        "baz": [
            null,
            "a",
            1,
        ],
        "xyzzy": "hello"
    }
    """
    token = parse(source)

    class TestSchema(Schema):
        foo = String()
        baz = String()
        xyzzy = String()

    validate_with_positions(token=token, validator=TestSchema)

    # baz is not a string
    class TestSchema(Schema):
        foo = String()
        baz = String()
        xyzzy = String()


# Generated at 2022-06-22 06:15:56.821363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", min_length=5)
    token = Token(
        value=[{"f": "a"}, {"f": "b"}, {"f": "c"}, {"f": "d"}, {"f": "e"}],
        start=Token.Pos(line=1, column=1, char_index=0),
        end=Token.Pos(line=1, column=8, char_index=7),
    )
    assert validate_with_positions(token=token, validator=field) == "abcde"

    token = Token(
        value=[{"f": "a"}, {"f": "b"}],
        start=Token.Pos(line=1, column=1, char_index=0),
        end=Token.Pos(line=1, column=4, char_index=3),
    )
   

# Generated at 2022-06-22 06:16:08.887179
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema, fields
    from typesystem.tokenize.base import Source

    def validate_with_positions(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        try:
            return validator.validate(token.value)
        except ValidationError as error:
            messages = []
            for message in error.messages():
                if message.code == "required":
                    field = message.index[-1]
                    token = token.lookup(message.index[:-1])
                    text = f"The field {field!r} is required."
                else:
                    token = token.lookup(message.index)
                    text = message.text


# Generated at 2022-06-22 06:16:18.487680
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Some random data to validate
    token = Token(
        start=0, end=0, value=(("a", 1), ("b", 3)), path=("a", "b"),
    )
    # A field that requires an integer
    field = Field(type="integer")
    # A validation error
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        [message] = error.messages()
        assert message.index == ("a", "b")
        assert message.code == "invalid_type"
        assert message.text == "Value must be of type 'integer'."
        assert message.start_position == 0
        assert message.end_position == 0
    else:
        assert False, "should raise error"

# Generated at 2022-06-22 06:16:27.070979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.stream import tokenize
    from typesystem.tokenize.tokens import Token

    token = tokenize({})
    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'value' is required."
        message = error.messages()[0]
        assert isinstance(message.start_position, Token.Position)
        assert isinstance(message.end_position, Token.Position)

# Generated at 2022-06-22 06:16:38.692161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import parse_json, JSON_TOKENS
    from dataclasses import dataclass


    @dataclass
    class Person(Schema):
        name: str
        age: int

    data = parse_json('{"name": "Erik", "age": null}', tokens=JSON_TOKENS)

# Generated at 2022-06-22 06:16:51.329054
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.primitives import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import Position
    from typesystem.tokenize.tokens import StringToken

    fields = {
        "id": String(max_length=100),
    }
    schema = Schema(fields)
    value = {"id": "fake"}
    token = ObjectToken(
        value=value,
        fields=(
            (StringToken(value="id", start=Position(char_index=2, line_no=1)),),
            (StringToken(value="fake", start=Position(char_index=6, line_no=1)),),
        ),
    )

# Generated at 2022-06-22 06:17:00.671993
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    input = """
    [
        {
            "name": "Josh",
            "age": 10
        },
        {
            "name": "Bob"
            "age": "nope"
        }
    ]
    """

    tokenizer = Person.tokenizer()
    tokens = list(tokenizer.tokenize(input))
    token = tokens[-1]
    # token._token_tree  # type: ignore
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 85
        assert message.code == "invalid_type"

# Generated at 2022-06-22 06:17:11.836420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_with_positions

    data = parse_with_positions("""
    {
      "key": "value",
      "key1": "value1"
    }
    """)
    schema = Schema(fields={"key": Field(), "key1": Field()})
    result = validate_with_positions(token=data, validator=schema)
    assert result == {"key": "value", "key1": "value1"}

    # Test missing keys
    data = parse_with_positions("""
    {
      "key1": "value1"
    }
    """)
    schema = Schema(fields={"key": Field(), "key1": Field()})