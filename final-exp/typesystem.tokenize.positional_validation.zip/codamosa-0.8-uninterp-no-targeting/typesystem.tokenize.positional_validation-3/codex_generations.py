

# Generated at 2022-06-22 06:07:49.420587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.parse import parse_json
    from typesystem.tokenize.tokens import TextToken

    value = '{"key": "value"}'
    tokens = parse_json(value)
    token = tokens[1]
    schema = {"key": String()}

    # Test non-errors
    result = validate_with_positions(token=token, validator=schema)
    assert result == {"key": "value"}

    # Test errors with positions
    value = '{"key": 123}'
    tokens = parse_json(value)
    token = tokens[1]
    schema = {"key": String()}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.mess

# Generated at 2022-06-22 06:07:53.425139
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo": "hello"}')
    validate_with_positions(token=token, validator=MySchema)
    assert True


# Generated at 2022-06-22 06:08:03.203782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.tokenize.tokens import Token, ValidationToken
    from typesystem.types import Integer

    # Simple string test
    token = parse_string("1")
    assert validate_with_positions(token=token, validator=Integer()) == 1

    # Simple string test with a validation error
    token = parse_string("a")
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=Integer())
    messages = error.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == 'Value "a" is not valid.'
    assert message.code == "invalid"
    assert message.index == tuple()

# Generated at 2022-06-22 06:08:14.096782
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.tokenize import JSONTokenizer

    input = '{"foo": "bar", "baz": "qux"}'

    schema = Object(
        properties={"foo": String(max_length=2),}, additional_properties=False
    )
    token = JSONTokenizer(input)()
    error = validate_with_positions(token=token, validator=schema)

    assert error.messages[0].start_position.line_number == 1
    assert error.messages[0].start_position.char_index == 11
    assert error.messages[0].end_position.line_number == 1
    assert error.messages[0].end_position.char_index == 16

# Generated at 2022-06-22 06:08:24.470178
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.parser import parse

    class TestSchema(Schema):
        field = Field(required=True)

    data = json.dumps({"field": None})
    token = parse(data)

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 7
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 11



# Generated at 2022-06-22 06:08:26.702556
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: This is a unit test for the function validate_with_positions
    pass # pragma: no cover

# Generated at 2022-06-22 06:08:35.603273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    token = Token(value="field", start=None, end=None)
    sub_token = Token(value="subfield", start=None, end=None)
    token.items = {"subfield": sub_token}

    text = """
        {
            field: {
                subfield: "subfield value",
                subfield2: 123
            }
        }
    """

    class SubField(Field):
        def get_description(self):
            return "subfield"

        def validate_subfield(self, value):
            if value != "subfield value":
                raise ValidationError("subfield value is wrong")

    class SubSchema(Schema):
        subfield = SubField()
        subfield2 = String()

    class MainSchema(Schema):
        field = SubSche

# Generated at 2022-06-22 06:08:36.635036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:08:46.324334
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Array
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        items = Array(name="items", field=String())

    schema = MySchema()

    try:
        validate_with_positions(schema, token=Token(json.loads('{"foo": "bar"}')))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field items is required.",
                code="required",
                index=("items",),
                start_position=(11, 11),
                end_position=(12, 12),
            )
        ]
    else:
        raise AssertionError("Expected to raise Validation Error with positional messages")


# Generated at 2022-06-22 06:08:57.432580
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    class CommentSchema(Schema):
        text = String(max_length=140)

    token = Token("foo")
    try:
        validate_with_positions(token=token, validator=CommentSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'text' is required."
        assert message.code == "required"
        assert message.index == ("/", "text")
        assert message.start_position.line_number == 0
        assert message.start_position.char_index == 0
        assert message.end_position.line_number == 0
        assert message.end_position.char_index == 3

# Generated at 2022-06-22 06:09:04.133517
# Unit test for function validate_with_positions
def test_validate_with_positions():
    raise NotImplementedError

# Generated at 2022-06-22 06:09:12.793438
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import ObjectToken, StringToken
    from typesystem.tokenize.parsers import parse_json

    schema = {
        "foo": {
            "bar": Integer(),
        }
    }

    text = '{"foo": {"bar": "not an integer"}}'
    token = parse_json(text) # type: ObjectToken
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc_info.value.messages[0]
    assert message.text == "not an integer is not a valid integer"
    assert message.start_position.line == 1
    assert message.start_position.char_index == 20


# Generated at 2022-06-22 06:09:23.531279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PostSchema(Schema):
        title = Field(type=str)
        comments = Field(type=list, items=Field(type=str))

    token_root = Token("""{
        "title": "",
        "comments": ["Hello, world!", ""]
    }""", start=(1, 1), end=(12, 9))
    token_title = Token("", start=(3, 14), end=(3, 14))
    token_comments = Token(["Hello, world!", ""], start=(5, 14), end=(8, 3))
    token_comments[0].start = (6, 6)
    token_comments[0].end = (6, 17)
    token_comments[1].start = (7, 6)
    token_comments[1].end = (7, 7)

# Generated at 2022-06-22 06:09:35.968950
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.types import String
    from typesystem.tokenize.lexers.simple import SimpleLexer

    lexer = SimpleLexer(is_enabled=True)
    token = lexer.tokenize("foo").lookup("bar")

    with pytest.raises(ValidationError):
        validate_with_positions(validator=String(), token=token)

    token.value = "baz"
    try:
        validate_with_positions(validator=String(), token=token)
    except ValidationError as error:
        message = error.messages()[0]
        assert isinstance(message, Message) and message.code == ""
        assert message.text == "The field 'baz' is required."
        assert message.start_position == (1, 1)
        assert message.end

# Generated at 2022-06-22 06:09:40.711623
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"x": int, "y": int})
    token = {
        "x": 12,
        "y": 34,
    }
    validator = validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-22 06:09:47.060652
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.gherkin import tokenize
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import Field

    doc = """
    Feature: 1
    Scenario: 2
        Given 3
        """
    token: Token = tokenize(doc)[2]
    value = validate_with_positions(
        token=token, validator=Field(type=TokenType.GIVEN, required=True)
    )
    assert value == "3"



# Generated at 2022-06-22 06:09:57.175414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_file
    from typesystem.json import JSONSchema
    from typing import Dict

    schema = JSONSchema({"type": "object", "required": ["id"], "properties": {"id": {"type": "integer"}}})
    jsonfile = tokenize_file("tests/data/error.json")  # type: ignore

    def validate_schema(token):
        validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as excinfo:
        validate_schema(jsonfile)

    messages = excinfo.value.messages()

# Generated at 2022-06-22 06:10:08.007811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_fields import SchemaWithRequiredField
    from tests.test_tokenize.tokens import tokenize
    from typesystem.tokenize.positions import Position
    import ast

    source = "foo = 1"
    tree = ast.parse(source)
    tokens = tokenize(tree=tree)

    assert tokens.lookup(["foo"]).value == "1"
    assert tokens.lookup(["foo"]).start == Position(
        line_number=1, character_number=0
    )
    assert tokens.lookup(["foo"]).end == Position(line_number=1, character_number=4)


# Generated at 2022-06-22 06:10:15.141839
# Unit test for function validate_with_positions
def test_validate_with_positions():  # noqa
    from typesystem.schemas import Schema
    from typesystem.fields import Int

    schema = Schema(
        fields={"foo": "bar", "count": Int(minimum=1, exclusiveMaximum=10)}
    )

    content = '{"foo": "bar", "count": 1}'

    token = validate_with_positions(
        token=Token.from_string(content), validator=schema
    )

    assert token.value == {"foo": "bar", "count": 1}

# Generated at 2022-06-22 06:10:26.940440
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Boolean
    from typesystem.tokenize import parse_source
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String  # type: ignore

    source = "{" "  'name': 'Jim'" "}"
    token = parse_source(source)
    assert isinstance(token, ObjectToken)

    strings = String(required=True)

    schema = type("TestSchema", (Schema,), {"name": strings})

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    messages = error.value.messages

    assert len(messages) == 2
    assert messages[0].text == 'The field "name" is required.'
    assert messages[0].code == "required"

# Generated at 2022-06-22 06:10:48.396252
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validators = [{"city": str, "age": int}]
    for validator in validators:
        root = Token(value={"city": "New York", "age": "20"}, start=0)
        try:
            validate_with_positions(token=root, validator=validator)
        except ValidationError as e:
            assert e.messages() == [
                Message(
                    code="invalid_type",
                    index=(1, "age"),
                    start_position=5,
                    end_position=5,
                    text="Expected an integer",
                )
            ]

        root = Token(value={"age": 20}, start=0)

# Generated at 2022-06-22 06:10:59.746609
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "type": "object",
            "properties": {
                "required": {"type": "string"},
                "not_required": {"type": "string"},
            },
        }
    )
    text = '{"required":"foo"}'

    errors = schema.validate(text)
    assert len(errors) == 1
    message = errors[0]
    assert message.text == "The field 'not_required' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line == 1
    assert message.end_position.char_index == len(text)

    errors = validate_with_positions(token=schema.parse(text), validator=schema)

# Generated at 2022-06-22 06:11:11.803537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem import fields, schemas

    class UserSchema(schemas.Schema):
        name = fields.String()
        age = fields.Integer()

    class ExampleSchema(schemas.Schema):
        user = UserSchema()
        field_1 = fields.String()
        field_2 = fields.Integer()

    token = Token(
        "example",
        {
            "user": {
                "name": "joe",
                "age": "10",
                "missing_field": True,
            },
            "field_1": "example",
            "missing_field_2": "foo",
            "field_2": "20",
        },
    )


# Generated at 2022-06-22 06:11:23.159268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ReverseString(Field):
        def validate(self, value: str) -> str:
            if value != value[::-1]:
                raise ValidationError(text="String must be reversed.")
            return value

    class Person(Schema):
        name = Fields.String(required=True)
        tags = Fields.List(of=Fields.String(), required=False)

    def get_messages(token: Token) -> typing.List[Message]:
        try:
            validate_with_positions(token=token, validator=Person)
        except ValidationError as e:
            return e.messages
        else:
            return []

    token = Token.parse({"name": "foo", "tags": ["bar", "baz"]})
    messages = get_messages(token)

# Generated at 2022-06-22 06:11:34.482776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import lex_and_parse

    token, _ = lex_and_parse("{}")
    assert token.value == {}
    assert validate_with_positions(token=token, validator=Schema({"data": Field()})) == {
        "data": None
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=Schema({"data": Field(required=True)})
        )
    error = exc_info.value
    assert error.messages()[0].start_position == (1, 1)
    assert error.messages()[0].end_position == (1, 1)

    token, _ = lex_and_parse("{data: []}")

# Generated at 2022-06-22 06:11:45.105444
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import json_lexer, Lexer
    from typesystem.tokenize.parser import parse_json

    # Create a simple field
    number_field = Field(type="number")
    # Create a simple schema that uses it
    class NumberSchema(Schema):
        n = number_field

    # Create a simple schema that uses it
    class ObjectSchema(Schema):
        m = NumberSchema

    data = '{"m": 123, "n": "not a number"}'
    tokens = parse_json(lexer=json_lexer(lexer=Lexer()), data=data)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens[0], validator=ObjectSchema)

# Generated at 2022-06-22 06:11:57.480911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, format_tokenization_error
    from typesystem import String, Integer
    from typesystem.schemas import Schema

    token = tokenize("{foo: 1, bar: 'hello'}")

    try:
        validate_with_positions(
            token=token,
            validator=Schema(
                {
                    "foo": Integer(required=True),
                    "bar": String(required=True),
                    "baz": Integer(required=True),
                }
            ),
        )
    except ValidationError as err:
        assert len(err.messages) == 1
        assert err.messages[0].code == "required"
        assert err.messages[0].text == "The field 'baz' is required."
        assert err.messages[0].start

# Generated at 2022-06-22 06:12:07.638762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import Token
    from typesystem.tokenize.contexts import FieldContext, ListContext
    from typesystem.tokenize.positions import Position

    class TestSchema(Schema):
        a = Field(required=True)
        b = Field(required=True)
        c = Field(required=True)

    field_context = FieldContext()
    list_context = ListContext()

    token = Token(
        path=(list_context,),
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=1),
    )
    token.value = {"a": "test"}

# Generated at 2022-06-22 06:12:17.686889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        foo = Field(type="integer")
        bar = Field(type="number")

    token = Token(
        "foo",
        [
            Token("bar", [Token("3", value=3, start=4, end=5)], start=4, end=5),
            Token("baz", [Token("2", value=2, start=12, end=13)], start=12, end=13),
        ],
        start=0,
        end=13,
    )

    test_schema = TestSchema()
    assert validate_with_positions(token=token, validator=test_schema) == {
        "foo": {"bar": 3, "baz": 2}
    }

    error = None

# Generated at 2022-06-22 06:12:28.347868
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import String

    schema = String(min_length=1)
    token = Token("", {}, [Token("", {}, [Token("", {}, [Token("a", {}, [])])])])
    validate_with_positions(token=token, validator=schema)
    token = Token("", {}, [Token("", {}, [Token("", {}, [Token("", {}, [])])])])
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.text == "This field may not be blank."
    text = token.as_text()

# Generated at 2022-06-22 06:12:57.452952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Integer, String
    from typesystem.tokenize.tokens import ArrayToken, ObjectToken, ScalarToken
    from typesystem.validators import Equals

    schema = {
        "name": String(max_length=10),
        "age": Integer(maximum=130),
        "verified": Equals(True),
    }
    validator = Schema("Person", schema=schema)


# Generated at 2022-06-22 06:13:05.684686
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        name = Field(str)

    data = '{"age": 34}'
    token = Token.parse(data)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=UserSchema)
    error = excinfo.value
    assert len(error.messages) == 1
    message = error.messages[0]
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 1
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 13

# Generated at 2022-06-22 06:13:14.075267
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringToken

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    data = '{"name": "John"}'
    token = StringToken(value=data)

    validate_with_positions(validator=Person, token=token)

    try:
        validate_with_positions(
            validator=Person,
            token=token,
            value=Person.validate(data={"name": "John", "age": "foo"}),
        )
    except ValidationError as exception:
        messages = exception.messages()

        assert len(messages) == 1
        message = messages[0]
        assert message.text == "Invalid integer."

# Generated at 2022-06-22 06:13:21.245164
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.collections import Dictionary, String

    field = Dictionary[String]()
    token = Token.parse({"foo": 123})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    expected = '''The field "foo" is required to be of type string.'''
    assert excinfo.value.messages[0].text == expected

# Generated at 2022-06-22 06:13:32.745695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import AccessToken, Token

    def make_token(value: str, line: int, column: int) -> Token:
        start = Position(line=0, column=0, char_index=0)
        end = Position(line=0, column=0, char_index=0)
        access = AccessToken(value=value, start=start, end=end)
        return Token(accesses=[access])

    token = make_token(value="foo", line=0, column=0)
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = make_token(value="foo", line=0, column=0)
    with pytest.raises(ValidationError) as excinfo:
        validate

# Generated at 2022-06-22 06:13:42.153732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Text

    class Position:
        def __init__(self, line: int, column: int):
            self.line = line
            self.column = column

    class PositionRange:
        def __init__(self, start: Position, end: Position):
            assert start.line == end.line
            self.start = start
            self.end = end

        @classmethod
        def from_index(cls, start: Position, index: int):
            return cls(start, start._replace(column=start.column + index + 1))

    class Token(typing.NamedTuple):
        value: typing.Any
        start: PositionRange

        def __getitem__(self, index: typing.Any) -> "Token":
            return self


# Generated at 2022-06-22 06:13:49.534668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import errors, schemas, fields
    from typesystem.tokenize.tokens import Token
    from .fixtures import TOKEN_WITH_ERRORS

    for token in TOKEN_WITH_ERRORS:
        assert token.start.char_index == 0
        field = fields.String(required=True)
        with pytest.raises(errors.ValidationError) as exc_info:
            validate_with_positions(token=token, validator=field)
        e = exc_info.value
        assert len(e.messages()) == 1
        message = e.messages()[0]
        assert message.index == ()
        assert message.code == "required"
        assert (
            message.text
            == "The field '' is required."
        )

# Generated at 2022-06-22 06:14:00.566161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema()
    field = Field(type="string", required=True)

    token = Token(start=Message(char_index=10, line_number=1, line_char_index=10), end=Message(char_index=20, line_number=1, line_char_index=20), value=5)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as e:
        assert e.messages()[0].code == "required"
        assert e.messages()[0].text == "The field value is required."
        assert e.messages()[0].start_position == Message(char_index=10, line_number=1, line_char_index=10)

# Generated at 2022-06-22 06:14:11.492974
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typing
    import typesystem
    from typesystem.fields import String

    schema_class = typesystem.Schema

    class PostSchema(schema_class):
        title = String(title="Title", max_length=100)
        body = String(title="Body text", max_length=100)

    schema = PostSchema()

    token = Token.parse(
        value=json.loads(
            """
    {
        "title": "",
        "body": "Hello world"
    }
    """
        ),
        source="",
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=PostSchema)


# Generated at 2022-06-22 06:14:23.267696
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.schema import PersonSchema
    from tests.tokenize.fixtures import person_token
    from tests.tokenize.value import Person

    person = Person(name=None, age=None)
    token = person_token(person)
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=PersonSchema)

    messages = e.value.messages

    assert len(messages) == 2
    assert messages[0].text == "The field 'name' is required."
    assert messages[1].text == "The field 'age' is required."
    assert messages[0].start_position == (1, 1)
    assert messages[0].end_position == (1, 1)
    assert messages[1].start_position == (4, 1)

# Generated at 2022-06-22 06:15:06.243135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse

    class ParagraphSchema(Schema):
        class Meta:
            fields = ["sentences"]

        sentences = [SentenceSchema()]

    class SentenceSchema(Schema):
        class Meta:
            fields = ["words"]

        words = [WordSchema()]

    class WordSchema(Schema):
        class Meta:
            fields = ["letters"]

        letters = [LetterSchema()]

    class LetterSchema(Field):
        pass

    token = parse("hello world")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=ParagraphSchema)

    messages = error.value.messages()
    assert len(messages) == 1

# Generated at 2022-06-22 06:15:13.289051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        foo = Field(type='string', required=True)

    token = Token(value={'foo': 'bar'})
    validate_with_positions(token=token, validator=TestSchema)

# Generated at 2022-06-22 06:15:24.730145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import sys
    import typesystem
    source = b"""{
        "name": "John Doe",
        "email": "john.doe@example.com",
        "address": {
            "city": "Utrecht",
            "country": "Netherlands"
        }
    }"""
    schema = typesystem.Schema(
        {
            "name": typesystem.String(
                min_length=5, max_length=255, required=True
            ),
            "email": typesystem.String(format="email"),
            "address": typesystem.Schema(
                {
                    "city": typesystem.String(required=True, nullable=False),
                    "country": typesystem.String(required=False, default="Netherlands"),
                }
            ),
        }
    )



# Generated at 2022-06-22 06:15:35.523418
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate_with_positions
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.error import TokenizationError
    from typesystem.error import ValidationError
    
    validator = Schema.from_string(
        r"""
        {
            "name": "Name",
            "properties": {
                "first_name": string,
                "last_name": string
            }
        }
    """
    )
    token = Token.from_string(
        r"""
        {
            "first_name": "Darwin",
            "last_name": "The Monkey"
        }
    """
    )
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        message = error

# Generated at 2022-06-22 06:15:45.565384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.fields import Integer

    token = Token(
        value=loads("""
    {
      "stats": [
        {
          "name": "max_hp",
          "value": 3
        },
        {
          "name": "max_mana",
          "value": 5
        }
      ]
    }
    """),
        start=(1, 1),
        end=(15, 1),
    )
    field = Integer(min_value=4)
    error = validate_with_positions(token=token, validator=field)
    assert isinstance(error, ValidationError)
    assert error.messages()[0].start_position == (2, 11)
    assert error.messages()[0].end_position == (2, 11)



# Generated at 2022-06-22 06:15:46.489757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:15:57.353397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import AnyToken, DictToken, ListToken

    string = String(required=True)

    # Good for now, but we should move this test to some kind of integration test.
    root = DictToken({
        "list": ListToken([AnyToken("test"), AnyToken(2)]),
        "dict": DictToken({"string": AnyToken("test")})
    }, start=1, end=1)


# Generated at 2022-06-22 06:16:08.963579
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from json import loads
    from typesystem.tokenize.tokens import Tokenizer

    class TestSchema(Schema):
        field = Field(primitive="string")
        other = Field(primitive="string", required=False)

    text = '{"field": "hello", "other": "world"}'
    validator = TestSchema()
    tokenizer = Tokenizer()

    token = tokenizer.tokenize(text)
    assert validate_with_positions(validator=validator, token=token) == loads(text)

    with pytest.raises(ValidationError):
        validate_with_positions(validator=validator, token=token.lookup(["other"]))


# Generated at 2022-06-22 06:16:19.597463
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Query(Schema):
        limit = Field(type=int, required=True)

    token = Token(
        type="object",
        value={},
        start=Position(line_number=1, char_index=1),
        end=Position(line_number=1, char_index=2)
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Query)
    exc = exc_info.value
    assert len(exc.messages) == 1
    message = exc.messages[0]
    assert message.text == "The field 'limit' is required."
    assert message.code == "required"
    assert message.start_position == token.start
    assert message.end_position == token.end

# Generated at 2022-06-22 06:16:27.109492
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Validator(Field):
        def validate(self, value):
            if value == "ok":
                return True
            else:
                raise ValidationError("Invalid value.")

    class Schema(Schema):
        data = Validator()

    token = Token("""
        {
            "data": "ok"
        }
    """, start=Position(line=0, char_index=0), end=Position(line=4, char_index=28))

    validate_with_positions(token=token, validator=Schema)