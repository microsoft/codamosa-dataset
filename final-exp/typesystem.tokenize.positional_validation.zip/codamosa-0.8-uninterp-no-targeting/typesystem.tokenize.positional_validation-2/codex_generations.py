

# Generated at 2022-06-22 06:07:48.953155
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import ParseError, Parser, parse

    token = parse("{}")
    assert token.value == {}

    schema = Schema({"foobar": Field(required=True)})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.start_position.line_index == 1
    assert message.start_position.char_index == 0
    assert message.end_position.line_index == 1
    assert message.end_position.char_index == 3



# Generated at 2022-06-22 06:08:00.221857
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    class DocumentSchema(typesystem.Schema):
        content = typesystem.String()

    data = {"content": "Hello, World!"}
    token = json.dumps(data)

    try:
        with pytest.raises(ValidationError) as err:
            DocumentSchema.validate(token=token)

        for message in err.value.messages:
            message.text += f" at line {message.start_position.line_number+1}"
            message.text += f", column {message.start_position.char_index+1}"
            print(message.text)

    except JSONDecodeError as error:
        print(f"JSONDecodeError: {error.msg}")

# Generated at 2022-06-22 06:08:05.664987
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    from typesystem.tokenize import tokenize

    Person = Schema(
        fields={"name": String(), "age": Integer(), "friends": Array(items=Person())}
    )

    tokens = tokenize({"friends": [{"name": "Alice", "age": "55"}]})
    validate_with_positions(token=tokens, validator=Person)



# Generated at 2022-06-22 06:08:14.684304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String

    data = {"name": "Jane", "age": 24}
    token = Token.parse_recursive(data)

    schema = Schema(
        {"name": String(), "age": Integer(minimum=30)}, raise_on_error=False
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="24 < 30.", code="minimum", index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end
            ),
        ]

# Generated at 2022-06-22 06:08:25.934844
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import jsonschema
    from typesystem.schemas import (
        Array,
        Boolean,
        Dict,
        Integer,
        String,
    )
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize import tokenize

    schema = Dict(
        {"foo": String(), "bar": Integer(), "baz": Boolean(), "qux": Array(Integer())}
    )
    document = tokenize("""{"foo": "hello", "bar": 1, "baz": true, "qux": [1, 2, 3]}""")
    document = document.lookup(["value"])

    token = document.lookup(["foo"])
    assert token.value == "hello"
    assert token.start.char_index == 8
    assert token.end

# Generated at 2022-06-22 06:08:36.663006
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Tokenizer

    class TestSchema(Schema):
        x = Integer()
        y = Integer()

    tokenizer = Tokenizer(TestSchema())

# Generated at 2022-06-22 06:08:41.001639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    type_ = Field(type="string")
    token = Token(value="string", type_=type_, start=Position(char_index=0), end=Position(char_index=5))
    type_.validate = validate_with_positions
    assert type_.validate(token=token, validator=type_)

# Generated at 2022-06-22 06:08:47.040415
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.objects import Text
    from typesystem.tokenize.tokens import Document
    from typesystem.tokenize.utils import tokenize_schema

    class Test(Schema):
        foo = Text()

    token = tokenize_schema(Test(), data={})
    try:
        validate_with_positions(token=token, validator=Test())
    except ValidationError as error:
        assert len(error.messages) == 1
        assert isinstance(error.messages[0].start_position, Document.Position)

# Generated at 2022-06-22 06:08:58.128439
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import IntegerField
    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import Token

    class SomeSchema(Schema):
        field = IntegerField()

    schema = SomeSchema()
    source = """
{
    "field": "test"
}
"""
    token = Token.tokenize(source)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=token.lookup(["field"]),
            validator=schema.fields["field"],
        )

    message = error.value.messages[0]
    assert message.text == "Must be a valid integer."
    assert message.start_position == (3, 9)
    assert message.end_position == (3, 13)

# Generated at 2022-06-22 06:09:09.344452
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)

    token = Token({"name": ""}, 0, 5)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message: Message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ("name",)
        assert message.start_position.byte_index == 0  # type: ignore
        assert message.start_position.char_index == 0  # type: ignore
        assert message.end_position.byte_index == 5  # type: ignore
        assert message.end_position.char_index == 5  # type: ignore

# Generated at 2022-06-22 06:09:24.798642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.functions import tokenize
    from typesystem import fields

    schema = fields.Object(properties={"title": fields.String(max_length=2)})
    token = tokenize({"title": "a" * 3})
    with pytest.raises(ValidationError, match="maxLength"):
        validate_with_positions(token=token, validator=schema)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 2
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_

# Generated at 2022-06-22 06:09:32.987006
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema
    from typesystem.json_schema import JsonSchema

    class PersonSchema(Schema):
        name = JsonSchema({"type": "string"})
        age = JsonSchema({"type": "integer"})

    from typesystem.tokenize import tokenize

    document = tokenize("""
        {
            "name": "John Doe",
            "age": 20
        }
    """)

    assert PersonSchema().validate(document) == {
        "name": "John Doe",
        "age": 20,
    }

# Generated at 2022-06-22 06:09:45.368409
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.types import String
    from typesystem.typing import CheckedDict

    schema = CheckedDict(
        {"name": String()}, {"name": ["required"]},
    )
    token = Tokenizer(data='{"age": 12}').next()
    with pytest.raises(ValueError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.code == "required"
    assert message.index == ("name",)
    assert message.start_position.char_index == 1
    assert message.end_position.char_index == 8

# Generated at 2022-06-22 06:09:52.575118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer
    from dataclasses import dataclass
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.messages import Position

    @dataclass(frozen=True)
    class BookSchema(Schema):
        name: str
        pages: int


# Generated at 2022-06-22 06:10:04.715363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"a": Field(required=True)})
    token = Token({"a": 1}, start=Point(0, 0), end=Point(1, 1))
    validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Field(required=True))
    message = exc.value.messages[0]
    assert message.code == "required"
    assert message.index == []
    assert message.text == "This field is required."
    assert message.start_position == Point(0, 0)
    assert message.end_position == Point(1, 1)



# Generated at 2022-06-22 06:10:14.985268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import ValidationError, ListToken, MapToken
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class EmptySchema(Schema):
        text = String(required=True)

    tokens = tokenize(
        """
    {
        "text": "hello world",
        "things": [1, 2, 3]
    }
    """
    )
    validate_with_positions(token=tokens, validator=EmptySchema)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=String(required=True))
    # Formatting causes this error to creep in, so we have to ignore it with

# Generated at 2022-06-22 06:10:26.753555
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    import json

    json_data = json.loads('{ "data": "foo" }')
    token = Token(value=json_data, start=None, end=None, child_tokens=[])
    field = String(name="data")
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as e:
        assert False, "given token was expected to be valid"
    json_data = json.loads('{ "data": "bar" }')
    token = Token(value=json_data, start=None, end=None, child_tokens=[])

# Generated at 2022-06-22 06:10:36.723090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize import tokenize

    class UserSchema(Schema):
        username = String(min_length=5)
        password = String(min_length=10)

    user = tokenize(
        {"username": "bill", "password": "hunter2"}, all_nullable=True
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=user, validator=UserSchema)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].start_position == (1, 2)
    assert messages[0].end_position == (1, 10)
    assert messages[1].start_position == (3, 2)
    assert messages

# Generated at 2022-06-22 06:10:48.433637
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")

    from typesystem.tokenize import lexer
    from typesystem.tokenize import tokens

    token = lexer.tokenize("{}")[0]
    assert isinstance(token, tokens.Object)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert [m.code for m in exc_info.value.messages] == ["required"]

    token = lexer.tokenize('{ "a": 3 }')[0]
    assert isinstance(token, tokens.Object)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-22 06:10:59.747612
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class UserSchema(Schema):
        username = Field(type="string", min_length=2)
        age = Field(type="integer")

    # Missing value
    with pytest.raises(ValidationError) as error:
        token = Token("user", type="mapping")
        validate_with_positions(token=token, validator=UserSchema)
    

# Generated at 2022-06-22 06:11:13.536043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String, Integer

    class TestSchema(Object):
        b = String(required=True)
        c = Integer(required=True)

    token = Token(
        value={
            "a": "foo",
            "b": "bar",
            "c": "baz",
            "d": [{"e": 1}, {"f": "g"}],
            "h": [{"i": "j", "k": "l"}],
        },
        start={"line": 0, "char": 0},
        end={"line": 9, "char": 3},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)

    assert exc_

# Generated at 2022-06-22 06:11:24.043578
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema(typesystem.schema.Schema):
        foo = typesystem.fields.String()

    source = '{"foo": 123}'
    tokens = typesystem.tokenize.tokenize(source)
    token = tokens[0]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Schema)

    assert exc_info.value.messages == [
        Message(
            text='Expected string, found 123 (int).',
            code='invalid',
            index=["foo"],
            start_position=Position(line=1, column=6, char_index=6),
            end_position=Position(line=1, column=9, char_index=9),
        )
    ]

# Generated at 2022-06-22 06:11:35.064123
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    from typesystem.tokenize.tokenize_file import tokenize_file
    from typesystem.tokenize.tokenize_file import create_positions

    token = tokenize_file(
        [
            "a.settle.tokens.settle.json",
            "b.settle.tokens.settle.json",
            "c.settle.tokens.settle.json",
        ]
    )
    token.set_positions(create_positions(token))
    try:
        validate_with_positions(token=token, validator=Object(properties={"a": int}))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-22 06:11:45.554997
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    field = Integer()

    token = Token(value=10, start="line 1, col 1", end="line 1, col 3")

    assert validate_with_positions(token=token, validator=field) == 10

    field = Integer(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages[0].text == "The field 'value' is required."
    assert exc_info.value.messages[0].start_position == {"line": 1, "column": 1}
    assert exc_info.value.messages[0].end_position == {"line": 1, "column": 3}


# Generated at 2022-06-22 06:11:55.320512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Lexer
    from typesystem.tokenize.tokens import Token

    lexer = Lexer(ignore_whitespace=False)

# Generated at 2022-06-22 06:12:03.289008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class WorldSchema(typesystem.Schema):
        id = typesystem.Integer()
        name = typesystem.String()

    class RootSchema(typesystem.Schema):
        worlds = typesystem.Array(items=WorldSchema())

    with pytest.raises(ValidationError, match="The field 'name' is required."):
        token = Token.parse_string('{"worlds": [{"id": 3}]}', schema=RootSchema())
        validate_with_positions(token=token, validator=RootSchema())



# Generated at 2022-06-22 06:12:13.726528
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import dataclasses
    import json
    import typesystem
    from typesystem.tokenize.tokenizers import json_tokenizer

    @dataclasses.dataclass
    class MySchema(typesystem.Schema):
        name: str
        age: int

    raw_data = {"name": "foo", "age": "bar"}
    data = json.dumps(raw_data)
    parsed_schema = MySchema()
    parsed_schema.validate(raw_data)
    tokens = list(json_tokenizer(data))
    with pytest.raises(typesystem.ValidationError) as exc_info:
        validate_with_positions(token=tokens[-1], validator=parsed_schema.fields["age"])
    error = exc_info.value
    assert error

# Generated at 2022-06-22 06:12:20.560306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parselets import parse_schema

    class User(Schema):
        name = Field(str)

    data = {"name": "Test"}
    token = parse_schema(User)(data)

    result = validate_with_positions(token=token, validator=User)
    assert result == {"name": "Test"}

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator={"name": Field(int)})

# Generated at 2022-06-22 06:12:27.095575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import Scanner
    from typesystem.tokenize.tokens import Object, Text
    from typesystem.fields import String
    from typesystem.types import StringType
    from typesystem.schemas import ObjectType
    from typesystem.validators import MinLength
    from typesystem import validate

    class MessageType(ObjectType):
        username = String(
            min_length=5,
        )
        message = String(
            validators=[MinLength(5)]
        )

    schema = MessageType()

    usernames = [
        "bob",
        "james",
        "jane",
        "",
    ]
    messages = [
        "hi!",
        "foo bar baz",
        "",
    ]
    scanner = Scanner()

# Generated at 2022-06-22 06:12:39.056572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token(
            value={"a": 1, "b": 2},
            start=Position(line_no=1, char_index=0),
            end=Position(line_no=3, char_index=7),
        ),
        validator=Schema({"a": Field(type="integer")}),
    ) == {"a": 1, "b": 2}

    schema = Schema({"a": Field(type="integer")})

# Generated at 2022-06-22 06:12:56.183548
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, tokenize_primitive
    from typesystem import Integer, Object, validate

    class Foo(Schema):
        bar = Integer()

    token = tokenize({"bar": 1})
    validate_with_positions(token=token, validator=Foo)

    token = tokenize({"bar": 2})
    with pytest.raises(
        ValidationError,
        match="Value must be smaller than or equal to 1. Got 2",
    ) as excinfo:
        validate_with_positions(token=token, validator=Foo)
    message = excinfo.value.messages()[0]
    assert message.index == ("bar",)  # type: ignore
    assert message.code == "max_value"


# Generated at 2022-06-22 06:13:05.873362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String

    class Person(Object):
        first_name = String()
        last_name = String()

        required = ["first_name", "last_name"]

    token = Token.from_python(Person, {"first_name": "John", "last_name": "Doe"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert False, error

    token = Token.from_python(Person, {"first_name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_

# Generated at 2022-06-22 06:13:14.074320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token

    data = {
        "a": {"b": {"c": {"d": 1}, "e": [1, 2]}},
        "f": {
            "g": {
                "h": [
                    {"i": 0},
                    {"j": {"k": "foo"}},
                    {"m": {"n": {"o": {"p": "bar"}}}},
                    {"m": {"n": {"o": {"p": "baz"}}}},
                ]
            }
        },
    }
    token = Token.from_dict(data)
    Field(required=True).validate(token.lookup("f", "g", "h", 2, "m", "n", "o", "p").value)

# Generated at 2022-06-22 06:13:19.586800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    field = Integer()

    assert validate_with_positions(
        token=Token(
            key="foo",
            value="123",
            start=(1, 1),
            end=(1, 4),
            schema={},
            children=[],
        ),
        validator=field,
    ) == 123



# Generated at 2022-06-22 06:13:30.635698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.exceptions import ValidationError as SchemaValidationError
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_json_file

    class User(Schema):
        username = String(max_length=200)

    def validator(value):
        raise SchemaValidationError("Something went wrong.")

    token = tokenize_json_file("tests/samples/test-simple.json")
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

    with pytest.raises(SchemaValidationError):
        validate_with_positions(token=token, validator=User)


# Generated at 2022-06-22 06:13:41.468156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Unit test for function validate_with_positions
    from typesystem.fields import String, Array

    schema = Array(items=String(max_length=3))
    tokens = [
        Token("null"),
        Token("["),
        Token('"foo"', start=(1, 1), end=(1, 4)),
        Token(","),
        Token('"spam"', start=(1, 6), end=(1, 10)),
        Token("]"),
    ]
    value = validate_with_positions(token=tokens[2], validator=schema)
    assert value == ["foo", "spam"]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens[4], validator=schema)

    error = exc_info.value

# Generated at 2022-06-22 06:13:52.869186
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Author(Schema):
        name = Field(str)
        birth_year = Field(int)

    class Book(Schema):
        title = Field(str)
        author = Field(Author)

    class Library(Schema):
        books = Field(
            [Book]
        )  # note: the [list] is not part of the error index.

    token = Token(
        value={
            "books": [
                {
                    "title": "Century 22: The Hollow Ones",
                    "author": {"name": "Peter F. Hamilton"},
                }
            ]
        }
    )

# Generated at 2022-06-22 06:14:07.758414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Float

    try:
        validate_with_positions(
            token=Token(value={"a": 0.0, "b": "c"}, location=(0, 0)),
            validator={
                "a": Float(minimum=1),
                "b": String(min_length=5),
                "c": String(required=True),
            },
        )
    except ValidationError as error:
        assert [message.text for message in error.messages()] == [
            "The field 'b' is required.",
            "The field 'a' must be greater than or equal to 1.",
            "The field 'c' must be of length 5.",
        ]

# Generated at 2022-06-22 06:14:19.743784
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Note(typesystem.Schema):
        text = typesystem.String(required=True)

    class Notes(typesystem.Schema):
        notes = typesystem.Array(items=Note, required=True)

    # Create a Token instance to be validated:
    import json

    json_string = '{"notes": []}'
    token = Token.from_json(json_string)

    # Validate the json string with positions information:
    validate_with_positions(token=token, validator=Notes)

    # Create a Token instance to be validated:
    json_string = '{"notes": []}'
    token = Token.from_json(json_string)

    try:
        validate_with_positions(token=token, validator=Note)
    except ValidationError:
        import types

# Generated at 2022-06-22 06:14:24.435426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    field = String(required=True)
    # Example input
    # {"age": 0
    token = tokenize("{\"age\": 0}")
    assert validate_with_positions(token=token, validator=field) is None

# Generated at 2022-06-22 06:14:41.845389
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:14:53.440196
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Position(typing.NamedTuple):
        line_index: int
        char_index: int

    class Token(typing.NamedTuple):
        start: Position
        end: Position
        value: typing.Any

    class Message(typing.NamedTuple):
        text: str
        code: str
        index: typing.List[int]
        start_position: Position
        end_position: Position


# Generated at 2022-06-22 06:15:04.121555
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema

    data = [
        {"name": "foo", "age": "16", "children": ["Alice", "Bob"]},
        {"name": "bar"},
        {"name": "baz", "age": "twenty-one"},
    ]
    tokens = Token.from_data(data)
    schema = Schema(
        {
            "name": String,
            "age": Integer,
            "children": Array[String](max_items=3),
        }
    )
    token = Token({"name": "foo", "age": 16})
    assert schema.validate(token.value) == {"name": "foo", "age": 16}


# Generated at 2022-06-22 06:15:15.413766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test that position information on validation errors is correct."""
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.tokens import NotAvailableToken
    from typesystem.tokenize.tokens import ObjectToken

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class SimpleObject(Schema):
        name = String(required=True)
        value = String()

    # It must work with valid values
    json = '{ "name": "George", "value": "George is a great name" }'
    token = ObjectToken(value=json)
    validate_with_positions(token=token, validator=SimpleObject())

    # It must handle validation errors in the root
    json = '{ "name": "George" }'
    token = ObjectToken

# Generated at 2022-06-22 06:15:22.987871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.streams import stream
    from typesystem.tokenize.compose import compose

    with open("input.json") as f:
        token = compose(f)
    start = token.start
    end = token.end
    try:
        String().validate(token.value)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == start
        assert message.end_position == end

# Generated at 2022-06-22 06:15:33.110167
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizers import raw_tokenizer

    from .data import INPUT, OUTPUT # import data
    from .utils import validate_all # import function

    class MySchema(Schema):
        one = Integer()
        two = Integer()
        three = Integer()

    def validate_json(value: typing.Any) -> typing.Any:
        tokens = raw_tokenizer.tokenize(value, start_index=0)
        return validate_with_positions(token=tokens[0], validator=MySchema())

    # If a value is valid, it should return the validated value.
    assert validate_json({}) == {}
    assert validate_json({"one": 1}) == {"one": 1}
   

# Generated at 2022-06-22 06:15:38.804165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JsonSchema
    from typesystem.tokenize.sources import StringSource
    from typesystem.tokenize.tokens import Token

    source = StringSource("[1, 2, 3, 4]")
    token = Token.from_source(source)
    validator = JsonSchema({"type": "array"})
    validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-22 06:15:46.304763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse_object

    integer_field = Integer(required=True)

    token = parse_object({"a": "7", "b": "not-an-integer"})
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=integer_field)
    messages = error_info.value.messages
    assert len(messages) == 2

    message = messages[0]
    assert message.text == "The field 'b' is required."
    assert message.code == "required"
    assert message.index == ["b"]
    assert (
        message.start_position.line == 1
        and message.start_position.char_index == 8
    )

# Generated at 2022-06-22 06:15:49.740512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types

    def test():
        class MySchema(Schema):
            a = types.Integer()

        token = tokenize('{"a": "x"}')["a"]
        validate_with_positions(token=token, validator=MySchema)

    import pytest
    with pytest.raises(ValidationError):
        test()

# Generated at 2022-06-22 06:16:00.041187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.strings import String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class User(Schema):
        name = String(max_length=10)

    token = tokenize(User, {"name": "Jane"})
    assert validate_with_positions(token=token, validator=User) == {"name": "Jane"}

    token = tokenize(User, {"name": "very long"})
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        messages = sorted(error.messages(), key=lambda m: m.start_position.char_index)
        assert messages[0].text == "Value too long."
        assert messages

# Generated at 2022-06-22 06:16:26.545332
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem import fields
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = fields.String(required=True)
        age = fields.Integer(min_value=2, max_value=3)

    class Address(Schema):
        street = fields.String(required=True)
        zip_code = fields.String(required=True)

    class Customer(Person):
        address = fields.Nested(Address)

    token = Token(
        value={
            "name": "foo",
            "age": 1,
            "address": {"street": "foo", "zip_code": 123},
        },
        start=None,
        end=None,
    )


# Generated at 2022-06-22 06:16:32.717218
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse_tree import BooleanNode
    from typesystem.fields import Boolean
    example = BooleanNode(start=0, end=5, value=True)
    Boolean.validate(example.value)
    assert validate_with_positions(token=example, validator=Boolean)
    example = BooleanNode(start=0, end=5, value="true")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=example, validator=Boolean)
    assert exc_info.value.messages()[0].text == "Expected a boolean value."



# Generated at 2022-06-22 06:16:44.309355
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from .test_types import Product
    schema = Product.Schema()
    tokens = tokenize("{}")

# Generated at 2022-06-22 06:16:55.124642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.tokens import Token, TokenType

    # Create a minimal JSON Schema
    schema = {
        "type": "object",
        "properties": {"foo": {"type": "string", "required": True}},
    }
    # Create a validator
    validator = typesystem.schema_registry.get_validator_class(schema)
    # Create a token
    token = Token(
        value={"foo": "bar"},
        type=TokenType.OBJECT,
        start=typesystem.tokenize.Pos(line=1, column=0, char_index=0),
        end=typesystem.tokenize.Pos(line=1, column=15, char_index=15),
    )
    # Validate the token

# Generated at 2022-06-22 06:17:01.133733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.schemas import TokenSchema

    schema = TokenSchema(
        {
            "content": [
                {"type": "paragraph", "content": [{"type": "text", "content": "..."}]}
            ]
        }
    )
    parser = Parser(schema)
    token = parser.parse('{"content": [{"type": "paragraph"}, {"type": "text"}]}')
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    error = excinfo.value
    assert len(error.messages) == 1
    assert error.messages[0].text == "The 'content' field requires items of type 'paragraph'."
    position

# Generated at 2022-06-22 06:17:12.089686
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {"name": Field()},
        json_encoders={"type": "dict"},
        json_decoders={"type": "dict", "$schema": "dict"},
    )

    # Check that errors created with `validate` are correctly converted to
    # positional errors by `validate_with_positions`.

    # 1. Check fields created by `validate`
    try:
        schema.validate({"name": ""})
    except ValidationError as e:
        error = e.messages[0]
        assert error.index == ("name",)
        assert error.text == "This field may not be blank."
        assert isinstance(error.start_position, TextPosition)
        assert error.start_position.line_number == 1
        assert error.start_position.char_index

# Generated at 2022-06-22 06:17:21.998128
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem import Schema

    class Foo(Schema):
        first = String()
        second = String(required=True)

    token = Token.from_native({"first": "one", "second": "two"})
    result = validate_with_positions(token=token, validator=Foo)
    assert result["first"] == "one"
    assert result["second"] == "two"

    token = Token.from_native({"first": "one"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Foo)
    assert excinfo.value.messages()[0].start_position.char_index == 16

# Generated at 2022-06-22 06:17:25.332928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass
    #(token, validator) = (None, None)
    #result = validate_with_positions(token=token, validator=validator)
    #assert result is None, "Expected None, but got %(result)r" % locals()

# Generated at 2022-06-22 06:17:36.579170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.tokens import ListStart, ListEnd, MapStart, MapEnd
    from typesystem.tokenize.tokens import Key, Value

    lexer = Lexer(
        lexemes=[
            ListStart,
            MapStart,
            Key,
            Value,
            MapEnd,
            ListStart,
            MapStart,
            Key,
            Value,
            MapEnd,
            ListEnd,
            ListEnd,
        ]
    )

    class UserSchema(typesystem.Schema):
        name = typesystem.String(max_length=10)
        age = typesystem.Integer(minimum=18)
