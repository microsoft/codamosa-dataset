

# Generated at 2022-06-22 06:08:09.337556
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.functions import from_python
    from typesystem.tokenize.tokens import StringToken
    from typesystem.fields import String, Integer, Float
    from typesystem import types

    data = {"foo": 42, "bar": "test_bar"}
    token = StringToken(
        name="root", value="", tokens=[StringToken(name="foo", value=42)]
    )

    # validate_with_positions accepts a token and a Field or Schema type
    assert validate_with_positions(token=token, validator=String) == "42"
    assert validate_with_positions(token=token, validator=types.String) == "42"

    # Raises ValidationError if the field is not valid

# Generated at 2022-06-22 06:08:16.207528
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import json_from_string

    token = json_from_string('{"foo": "bar", "baz": 123}')
    validator = Schema({"foo": str, "baz": int})
    validate_with_positions(token=token, validator=validator)

    # Test required field
    validator = Schema({"foo": str, "baz": {"__any__": int, "__required__": True}})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.index == ("baz",)
        assert message.start_position.byte_index == 13
        assert message

# Generated at 2022-06-22 06:08:27.228903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(type="string", min_length=1)

    token = Token(value={"name": None})
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert error.messages()[0].to_json_data() == {
            "text": "The field 'name' is required.",
            "code": "required",
            "index": ["name"],
            "start_position": {"line_number": 1, "char_index": 11},
            "end_position": {"line_number": 1, "char_index": 11},
        }
    else:
        raise AssertionError("DID NOT RAISE")

# Generated at 2022-06-22 06:08:35.646111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from tests.tokenize.tokens import run_parser

    class MySchema(Schema):
        name = String(required=True)

    token = run_parser("{}")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=token.child("open"), validator=MySchema()  # type: ignore
        )
    message = exc.value.messages[0]
    assert message.code == "required"
    assert message.start_position.char_index == 1
    assert message.end_position.char_index == 1
    assert message.text == "The field 'name' is required."

# Generated at 2022-06-22 06:08:40.996251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.validators import VALIDATORS
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo": 1, "bar": 2}')
    for validator in VALIDATORS.values():
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-22 06:08:49.264509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest.mock import mock_open, patch

    m = mock_open(read_data='{ "foo": 1 }')
    with patch("typesystem.tokenize.utils.open", m):
        from typesystem.tokenize.parser import parse_file

    with pytest.raises(ValidationError) as exc_info:
        parse_file(
            "does_not_exist.json",
            {"foo": Field(type="integer"), "bar": Field(type="integer")},
        )

    error = exc_info.value
    assert len(error.messages) == 1
    message = error.messages[0]
    assert message.text == "The field 'bar' is required."
    assert message.start_position.line == 1
    assert message.start_position.char_index == 13
   

# Generated at 2022-06-22 06:09:00.191227
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken

    fields = {"name": String()}

# Generated at 2022-06-22 06:09:10.275992
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class User(Schema):
        name = Field(str, length=10)
        email = Field(str)

    token = tokenize({"name": "", "email": "foo@a.com"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=User)

    messages = excinfo.value.messages()
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.column_index == 2
    assert messages[0].start_position.char_index == 2
    assert messages[0].text == "The field 'name' is required."



# Generated at 2022-06-22 06:09:17.556420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .schemas import test_schema

    input = """
# This is a header.
name: "Luke Skywalker"
homeworld: "Tattoine"

# This is another header.
age: 19
height: 172
"""
    tokens = list(tokenize(input, token_classes=[test_schema]))
    assert len(tokens) == 3
    assert tokens[0].value["name"] == "Luke Skywalker"
    assert tokens[1].value["age"] == 19
    try:
        validate_with_positions(
            token=tokens[0], validator=test_schema.fields["name"]
        )
    except ValidationError as error:
        assert all(isinstance(m, Message) for m in error.messages())

# Generated at 2022-06-22 06:09:28.250118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class MySchema(typesystem.Schema):
        number = typesystem.Integer(maximum=100)
        name = typesystem.String(required=True)
        age = typesystem.Integer(maximum=100)

    token = (
        Token.root(
            Token.object_(
                Token.object_length(4),
                Token.key("number"),
                Token.integer(20),
                Token.key("age"),
                Token.integer(10),
                Token.key("name"),
            )
        )
    )

    # Should not error
    validate_with_positions(token=token, validator=MySchema)

    # Should error due to "required" message.

# Generated at 2022-06-22 06:09:40.496548
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, validate_with_positions, ValidationError

    class Username(String):

        def validate_string(self, value: str) -> str:
            if value != "root":
                raise ValueError("Username must be root.")
            return value

    username = Username()
    value = validate_with_positions(token=Token(value="root"), validator=username)
    assert value == "root"

    def test_invalid_token():
        try:
            validate_with_positions(token=Token(value="not-root"), validator=username)
        except ValidationError as error:
            messages = error.messages()
            assert len(messages) == 1
            assert messages[0].index == []
            assert messages[0].code == "string-invalid"

# Generated at 2022-06-22 06:09:50.166859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import Object
    from typesystem.fields import Integer

    class MySchema(Schema):
        a = Integer()
        b = Integer()
        c = Integer()

    schema = MySchema()
    input = {"c": 1}

    message = validate_with_positions(token=Token(input), validator=schema)[0]
    assert message.code == "required"
    assert message.index == ("a",)
    assert message.text == "The field 'a' is required."
    assert message.start_position.line == 0
    assert message.start_position.column == 4

    message = validate_with_positions(
        token=Token(input), validator=Object(required=["a", "b", "c"])
    )[0]
    assert message.code

# Generated at 2022-06-22 06:09:56.878096
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import schema
    from typesystem import fields

    class MovieSchema(schema.Schema):
        title = fields.String(required=True)
        year = fields.Integer(max_value=2019)

    syntax_tree = tokenize(
        """
        {
            #
            title: "The Hobbit",
            year: 1937
        }
        """,
        source_path="movies.gql",
        source_line=1,
        source_column=1,
        source_file_contents="",
    )

    try:
        validate_with_positions(token=syntax_tree, validator=MovieSchema)
    except ValidationError as error:
        assert error.messages[0].start_position.line_number == 6
       

# Generated at 2022-06-22 06:10:07.758574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, types
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Array, Object

    class ItemSchema(Schema):
        title = types.String()
        position = types.Integer()

    def test(*, source: str, validator: Schema) -> None:
        parser = Parser(source)
        token = parser.parse()
        messages: typing.List[Message] = []
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            messages.extend(error.messages())
        else:
            raise AssertionError("ValidationError expected")
        messages = sorted(messages, key=lambda m: m.start_position.offset)

        assert messages

# Generated at 2022-06-22 06:10:16.832165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyField(Field):
        def __init__(self, sub_field=None, **kwargs):
            super().__init__(**kwargs)
            self.sub_field = sub_field

        def __repr__(self):
            return "<MyField>"

        def validate(self, value):
            if self.sub_field is not None:
                self.sub_field.validate(value)
            return value

    field = MyField(sub_field=Field(max_length=5))
    token = Token("to much text")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-22 06:10:21.768968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    message = validate_with_positions(token=Token({}), validator=Schema({"foo": int}))
    assert message.text == "The field 'foo' is required."

    message = validate_with_positions(token=Token([{}]), validator=Schema([{"foo": int}]))
    assert message.text == "The field 'foo' is required."

# Generated at 2022-06-22 06:10:29.418406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arrange
    token = Token(value={"name": "John"}, start=(1, 1), end=(1, 5))
    validator = Field(type=str, required=True)

    # Act and assert
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)

    assert error.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=(1, 1),
            end_position=(1, 5),
        )
    ]

# Generated at 2022-06-22 06:10:38.192909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from Hypothesis.stateful import RuleBasedStateMachine
    from Hypothesis.extra.pytest import ExitStack as ExitStackHypothesis
    from Hypothesis.strategies import dictionaries, text
    from typesystem import tokenize, types
    from typesystem.base import Message
    from typesystem.tokenize.tokens import Token

    class StateMachine(RuleBasedStateMachine):
        def __init__(self):
            super().__init__()
            self.EXIT_STACK = ExitStackHypothesis()
            self.counter = 0


# Generated at 2022-06-22 06:10:47.754244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.schemas import Proxy
    from typesystem.fields import String

    schema = Proxy(
        fields={
            "name": String(required=True),
            "employer": String(required=True),
        }
    )
    document = tokenize("""
        {
            "employer": "Porcupine"
        }
    """)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=document, validator=schema)
    assert [str(e) for e in exc_info.value.messages()] == [
        "The field 'name' is required."
    ]

# Generated at 2022-06-22 06:10:53.950855
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.validation import test_validation

    test_validation.test_validate_with_positions(
        validate_with_positions, "typesystem.validate_with_positions"
    )

# Generated at 2022-06-22 06:11:08.696472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Compound
    from typesystem.fields import Field, String
    from typesystem.tokenize.base import Token, Document, Line, Token
    from typesystem.tokenize import tokenize_yaml

    schema = Schema(
        fields=[
            Field(name="name", type=String(min_length=1)),
            Field(name="description", type=String(min_length=1)),
        ]
    )

    source = """
    ---
    name: ''
    """

    document = tokenize_yaml(source)
    message = validate_with_positions(
        token=document, validator=schema
    ).messages[0]
    assert message.text == "The field description is required."
    assert message.start_position.char_index == 0



# Generated at 2022-06-22 06:11:20.551756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Structure

    class TestSchema(Structure):
        name = String()
        age = Integer()

    token1 = Token(
        name="name", value="name", start=0, end=4,
    )
    token2 = Token(
        name="age", value="1234", start=4, end=8,
    )

    TestSchema.fields["name"].validate(token1.value)
    TestSchema.fields["age"].validate(token2.value)

    validate_with_positions(token=token1, validator=TestSchema.fields["name"])

    validate_with_positions(token=token2, validator=TestSchema.fields["age"])


# Generated at 2022-06-22 06:11:30.448028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Test function validate_with_positions
    """

    import pytest

    from typesystem.errors import ValidationError as Val
    from typesystem.fields import String
    from typesystem.tokenize.tokens import FieldToken

    text = '{"field_1": "string", "field_2": 42}'
    field_2_token = FieldToken("field_2", "42", start=20, end=23)
    schema = {"field_1": String, "field_2": String}
    with pytest.raises(Val) as excinfo:
        validate_with_positions(validator=schema, token=field_2_token)

# Generated at 2022-06-22 06:11:36.652389
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="number")

    from typesystem.tokenize import to_tokens

    schema = Person()
    token = to_tokens("{}")
    try:
        result = validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ["name"]
        assert message.start_position.line_no == 1
        assert message.start_position.char_index == 1

# Generated at 2022-06-22 06:11:41.295577
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from .json import loads

    token = loads('{"foo": "hello"}')
    assert validate_with_positions(token=token, validator=Schema({"foo": str})) == {
        "foo": "hello"
    }
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Schema({"foo": int}))
    message = exc_info.value.messages[0]
    assert message.index == ["foo"]
    assert message.code == "invalid_type"
    assert (
        message.text
        == "The value of the field foo must be of type int, but got the value hello (type: str)."
    )
    assert message.start_position == token

# Generated at 2022-06-22 06:11:51.437930
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.fields import Array, Integer
    from typesystem.tokenize import tokenize

    from . import invalid_json

    def test_validator(
        validator: typing.Union[Field, typing.Type[Schema]], input: typing.Any
    ) -> None:

        token = tokenize(input)

        with pytest.raises(ValidationError) as exc:
            validate_with_positions(token=token, validator=validator)

        messages = exc.value.messages()

        if isinstance(input, list) and not isinstance(input, (str, bytes)):
            correct_output = json.dumps(input, indent=2)
        else:
            correct_output = json.dumps(input)


# Generated at 2022-06-22 06:12:02.544659
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    content = """
    [
        {
            "x": "X",
            "y": "Y"
        },
        {
            "x": "X",
            "y": "Y"
        }
    ]
    """

    Document = typing.List[typing.Dict[str, typing.Any]]

    class Item(Schema):
        x = Field(str, required=True)
        y = Field(str, required=False)

    try:
        validate_with_positions(token=tokenize(content), validator=Document)
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.char_index == len(content) - 1

# Generated at 2022-06-22 06:12:09.511712
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import parse

    string_field = String(default="")
    data = parse({"name": "foo"})
    validated = validate_with_positions(token=data, validator=string_field)
    assert validated == ""

    data = parse({"name": {"my": {"name": "foo"}}})
    validated = validate_with_positions(token=data, validator=string_field)
    assert validated == ""

# Generated at 2022-06-22 06:12:23.446481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import yaml
    from typesystem.fields import String

    class Person(Schema):
        name = String(max_length=2)

    data = """
    - relatives:
        - name: Uncle Ben
    """
    token = Token.from_yaml(yaml.safe_load(data))
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()


# Generated at 2022-06-22 06:12:32.829929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields, schemas
    from typesystem import exceptions as typesystem_exceptions
    from typesystem.utils import create_position

    class MySchema(schemas.Schema):
        name = fields.String(required=True)

    token = tokenize("{}")
    with pytest.raises(typesystem_exceptions.ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'name' is required."
    assert message.start_position == create_position(0, 1)


# Generated at 2022-06-22 06:12:40.753766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: implement this method.
    pass

# Generated at 2022-06-22 06:12:52.705272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String(required=True)

    token = Token(
        {
            "name": "John",
            "age": "100",
            "address": {"name": "Home", "address": "Abbey Road"},
        }
    )

# Generated at 2022-06-22 06:13:04.136251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class MySchema(Schema):
        name = String()
        age = Integer(default=0)

    schema = MySchema(strict=True)

    token = Token(value={"name": "Jair"}, children=[])

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.code == "required"
        assert message.index == ("age",)
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line_index == 1

# Generated at 2022-06-22 06:13:14.052792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, fields
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        foo = fields.Integer()

    schema = TestSchema()

    token = Token(
        value={
            "foo": [{"start": {"row": 1, "column": 1, "char_index": 0}, "end": {}}]
        },
        start={},
    )

    expected_message = Message(
        text="The field foo is required.",
        code="required",
        index=["foo"],
        start_position={"row": 1, "column": 1, "char_index": 0},
        end_position={"row": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-22 06:13:25.427863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.utils import tokenize
    from typesystem.utils import get_path

    schema = Schema(
        {"name": Field(required=True), "surname": Field(required=True)}
    )

    token = tokenize("""
    {
        name: "Giuseppe"
    }
    """)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            text='The field "surname" is required.',
            code="required",
            index=["surname"],
            start_position=get_path(),
            end_position=get_path(),
        )
    ]

# Generated at 2022-06-22 06:13:35.918241
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.parser import parse

    from .tokenize import tokenize

    token = tokenize(source=b"""{
    "foobar": 9,
    "bar": "baz"
}""")
    token = parse(token)
    class Child(Schema):
        foobar = Integer()
        bar = String()

    class Parent(Schema):
        child: Child

    try:
        validate_with_positions(token=token.child.child, validator=Parent())
    except ValidationError as error:
        message = next(iter(error.messages()))
        assert message.start_position.line == 2
        assert message.start_position.column == 5
        assert message.end_position.line == 2
        assert message.end_position

# Generated at 2022-06-22 06:13:47.523054
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PostSchema(Schema):
        title = Field(str)
        content = Field(str)

    def test_validator(validator: typing.Union[Field, typing.Type[Schema]], token_value, expected_value):
        token = Token(value=token_value)
        validated_value = validate_with_positions(token=token, validator=validator)
        assert validated_value == expected_value

    test_validator(PostSchema, {"title": "Hi!", "content": "Hello"}, {"title": "Hi!", "content": "Hello"})
    test_validator(PostSchema, {"title": "Hi!", "content": ""}, {"title": "Hi!", "content": ""})


# Generated at 2022-06-22 06:13:59.492248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import json
    import typesystem

    class User(typesystem.Schema):
        name = typesystem.String(max_length=10)
        email = typesystem.String(format="email")

    data = {"name": "joe", "email": "joe@example.com"}

    token = Token(data)
    validate_with_positions(token=token, validator=User)

    data = {"email": "joe@example.com"}
    token = Token(data)

# Generated at 2022-06-22 06:14:10.102793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        type="object",
        start=SourcePosition(
            line_number=1, line_start=(0, 0), char_index=0, line_end=None
        ),
        end=SourcePosition(
            line_number=1, line_start=(0, 0), char_index=18, line_end=None
        ),
        value={"b": {"c": 2, "d": 3}},
        keys={"b": {"c": 2, "d": 3}},
    )
    schema = Schema(fields={"a": Field(required=True)})

# Generated at 2022-06-22 06:14:21.797761
# Unit test for function validate_with_positions
def test_validate_with_positions():

    schema = Schema({
        'columns': [
            {
                'name': str,
                'type': str,
                'constraints': [
                    {
                        'type': str,
                        'params': {
                            'min': int,
                            'max': int,
                        },
                    },
                ],
            },
        ],
    })

    data = [
        'columns',
        [
            'id',
            'int',
            [
                'max',
                10,
            ],
        ],
        [
            'title',
            'string',
            [
                'max',
                10,
            ],
        ],
        [
            'author',
            'string',
            [
                'max',
                10,
            ],
        ],
    ]


# Generated at 2022-06-22 06:14:47.376192
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:14:59.474671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse

    print(
        validate_with_positions(
            token=parse("[1, 2, 3]"),
            validator=Field(type="array", items=Field(type="integer")),
        )
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=parse("[1, 2, 3"),
            validator=Field(type="array", items=Field(type="integer")),
        )
    assert len(exc.value.messages) == 1
    assert (
        exc.value.messages[0].start_position.char_index
        == parse("[1, 2, 3").end.char_index
    )
    assert exc.value.messages[0].end_position.line_number == 3

# Generated at 2022-06-22 06:15:05.630094
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken

    class Person(Schema):
        name = Field(min_length=2)
        age = Field(type=int)
        is_tall = Field(type=bool)

        @property
        def title(self):
            return self.cleaned_data["name"]


# Generated at 2022-06-22 06:15:15.971639
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Booking(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        event = Field(type="string")

    import pytest

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token.parse(
                """
            {
                "name": "Foo",
                "age": "bar",
                "event": "Lorem ipsum dolor sit amet"
            }
            """
            ),
            validator=Booking,
        )
    assert exc_info.match("The value 'bar' is not an integer")
    assert "age" in exc_info.value.message("age").text



# Generated at 2022-06-22 06:15:27.036760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokenizer import Tokenizer

    class Person(Schema):
        name = Field(required=True, max_length=10)
        age = Field(required=True, type="integer", minimum=18, maximum=100)

    tokenizer = Tokenizer(Person)

    # Check that required field errors can be detected.
    token = tokenizer.tokenize("{}")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-22 06:15:31.778526
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        name="something",
        value={"data": {}, "other": {}},
        start=Position(byte_index=0, char_index=0, line_number=1, column_number=1),
        end=Position(byte_index=0, char_index=1, line_number=1, column_number=2),
    ).get_child(["data"])
    validator = Field(name="data", types=object())
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.messages()[0].start_position == token.start
    else:
        assert False

# Generated at 2022-06-22 06:15:42.046813
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Age(typesystem.String):
        def validate_string(self, value):
            value = int(value)
            if value < 0 or value > 150:
                raise ValidationError("This is not a valid age.")
            return value

    class Person(typesystem.Schema):
        name = typesystem.String()
        age = Age()

    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import StringToken

    token = StringToken(
        value='{"name": "John Doe", "age": "500"}',
        start=Position(line=1, char_index=1),
        end=Position(line=1, char_index=25),
    )

# Generated at 2022-06-22 06:15:42.684547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:15:53.622964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token, Tokens
    from typesystem.tokenize.rules import Literal

    token = Token(
        value={
            "f1": "v1",
            "f2": "v2",
            "f3": Tokens([Token(value=[1, 2, 3], rule=Literal)]),
        },
        rule=Literal,
        start="(2, 2)",
        end="(9, 9)",
    )

    class Schema(Field):
        f1 = Field(required=True, min_length=2)
        f2 = Field(required=True)
        f3 = Field(required=True, min_items=4)


# Generated at 2022-06-22 06:16:01.717727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.grammar.schema import schema

    schema = schema(String())
    token = tokenize('{ "first": "Tom" }', schema)

    assert validate_with_positions(token=token, validator=schema) == {
        "first": "Tom"
    }

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokenize('{ "last": "Watts" }', schema), validator=schema)


# Generated at 2022-06-22 06:16:39.834298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_positions(
        payload, indices, expected_start, expected_end, expected_code
    ):
        token = Token(value=payload)
        message = validate_with_positions(
            token=token,
            validator=Field(type="string", max_length=2, required=True),
        )
        assert message[indices].start_position == expected_start
        assert message[indices].end_position == expected_end
        assert message[indices].code == expected_code

    assert_positions(
        {"name": "hello"},
        (0, "name"),
        ((0, 0), (0, 0)),
        ((0, 5), (0, 5)),
        "too_long",
    )


# Generated at 2022-06-22 06:16:51.795301
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Object


# Generated at 2022-06-22 06:16:56.283001
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import (
        Schema,
        Object,
        Array,
        Integer,
        Boolean,
        Null,
    )

    class UserSchema(Schema):
        fields = {
            "id": Integer(required=True),
            "name": String(required=True),
            "active": Boolean(default=True),
            "details": Object(fields={
                "email": String(required=True),
                "phone": String(required=False),
            })
        }
        required = ["id", "name", "details.email"]

    class UsersSchema(Schema):
        fields = {
            "users": Array(items=UserSchema())
        }


# Generated at 2022-06-22 06:17:04.742841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_examples import JSONSchema

    token = Token(field="thing", value="thing", start=0, end=4)

    thing = JSONSchema({"required": ["bar"]}, name="thing")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=thing)
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.start_position == 0
        assert message.end_position == 4

# Generated at 2022-06-22 06:17:09.796500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # GIVEN a field
    field = Field(type=int)
    # GIVEN a token
    token = Token(value="1")
    # WHEN validating with positions
    result = validate_with_positions(token=token, validator=field)
    # THEN the result is equal to the token value
    assert result == 1



# Generated at 2022-06-22 06:17:22.350504
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import CompositeSchema
    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.json import JSONTokenizer

    class SchemaWithPositions(CompositeSchema):
        foo = Field(type="integer", required=False)
        bar = Field(type="integer", required=True)
        baz = Field(type="integer", required=True)

    schema = SchemaWithPositions()
    tokenizer = Tokenizer(tokenizer=JSONTokenizer)
    try:
        validate_with_positions(
            token=tokenizer(b'{"bar": 1}'), validator=schema
        )
    except ValidationError as error:
        assert error.text == 'The field "baz" is required.'
        assert error.start_position.char_index == 12

# Generated at 2022-06-22 06:17:29.914198
# Unit test for function validate_with_positions
def test_validate_with_positions():
  from typesystem.tokenize.tokens import Object, String
  from typesystem.fields import String as TString
  from typesystem.fields import Integer as TInteger
  from typesystem.fields import Float as TFloat
  from typesystem import Field
  from typesystem.exceptions import ValidationError

  class TestSchema(Schema):
    string = String(max_length=4)
    integer = TInteger(minimum=2)
    float = TFloat(minimum=1.0)



# Generated at 2022-06-22 06:17:37.531064
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    import io

    field = Field(name="email")

    source = textwrap.dedent(
        """\
        {
            "email": "foo@bar"
        }
    """
    )
    reader = io.StringIO(source)
    token = Token.parse(reader, at=[("data",)])

    with pytest.raises(ValidationError) as context:
        validate_with_positions(token=token, validator=field)
    assert context.value.messages[0].start_position.char_index == 15

# Generated at 2022-06-22 06:17:48.174117
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(required=True, primitive=str)
        age = Field(primitive=int)

    person = Person()

    content = '{"name": "John"}'
    token = Token.from_json_string(content, name="person")
    validate_with_positions(token=token, validator=Person)

    content = '{"name": "John", "age": "wrong"}'
    token = Token.from_json_string(content, name="person")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as exc:
        messages = [m.text for m in exc.normalized_messages()]

# Generated at 2022-06-22 06:17:58.841151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class UserSchema(typesystem.Schema):
        """
        {
          "name": "John Doe",
          "age": 30
        }
        """
        name = typesystem.String(max_length=10)
        age = typesystem.Integer(min_value=18)

    from typesystem.tokens import tokenize

    token = tokenize(UserSchema, """{
        "name": "John Doe",
        "age": 30
    }""")
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=UserSchema)
    token = tokenize(UserSchema, """{ "name": "John Doe" }""")