

# Generated at 2022-06-22 06:07:47.315248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    data = {
        "name": "bob",
        "age": "twenty six"
    }

    token = Token.from_dict(data)

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-22 06:07:56.655302
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.composite import Dict
    from typesystem.fields import Integer, String

    schema = Dict({
        "name": String()
    })
    json_data = b'{"age": 17}'
    data: typing.Dict[str, typing.Any] = {}
    tokens = tokenize_json(json_data)

    try:
        validate_with_positions(token=tokens, validator=schema)
    except ValidationError as error:
        messages = []
        for message in error.messages():
            assert len(message.index) == 1
            messages.append(f"{message.text} on line {message.start_position.line_index}")

# Generated at 2022-06-22 06:08:07.274642
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    import typesystem
    import typesystem.tokenize

    class ExampleSchema(Schema):
        required_string = typesystem.String(required=True)
        optional_string = typesystem.String(required=False)

    json_text = """{"required_string": "foo", "optional_string": null}"""
    token = typesystem.tokenize.tokenize(json_text)
    schema = ExampleSchema()

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.char_index
        )
        assert len(messages) == 1
        assert messages[0].code == "null"

# Generated at 2022-06-22 06:08:15.342363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import fields
    from typesystem.tokenize.helpers import string_to_token

    token = string_to_token('{"a": "hello", "b": "world"}')
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=fields.Object({}))
    error_messages = error_info.value.messages()
    assert error_messages[0].text == "The field 'a' is required."
    assert error_messages[0].start_position.byte_index == 3
    assert error_messages[0].end_position.byte_index == 5
    assert error_messages[1].text == "The field 'b' is required."
    assert error_messages[1].start_

# Generated at 2022-06-22 06:08:24.797672
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    def validate(s) -> typing.Any:
        return validate_with_positions(token=tokenize(s), validator=PersonSchema)

    assert validate({"name": "Foo", "age": 30}) == {"name": "Foo", "age": 30}
    assert validate("{}") == {}

    with pytest.raises(ValidationError) as excinfo:
        validate("{}")
    assert excinfo.value.messages()[0].start_position == (1, 1)
    assert excinfo.value.messages()[0].end_position == (1, 1)

# Generated at 2022-06-22 06:08:35.131510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    def make_tokens(tokens):
        return [
            Token.from_dict({
                "index": [],
                "start": {"line": i + 1, "char_index": 1},
                "end": {"line": i + 1, "char_index": 1 + len(token)},
                "value": token
            })
            for i, token in enumerate(tokens)
        ]

    tokens = make_tokens(["", "", "hi", "3"])

    class Person(Schema):
        name = String()
        age = Integer()


# Generated at 2022-06-22 06:08:45.169750
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TokenWithPosition(Token):
        def __init__(self, value):
            super().__init__(value)
            self.start = Position(line_number=1, char_index=1)
            self.end = Position(line_number=2, char_index=2)

    class Position():
        def __init__(self, line_number, char_index):
            self.line_number = line_number
            self.char_index = char_index

    token = TokenWithPosition([TokenWithPosition("_"), TokenWithPosition("_")])
    class Validator(Field):
        def to_python_value(self, value):
            raise ValidationError(["validation error"])


# Generated at 2022-06-22 06:08:56.288963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = {"name": {"type": str, "required": True}}
    field = Field(schema=schema)
    token = tokenize("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    message = exc_info.value.messages[0]
    assert isinstance(message, Message)
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 2
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 2
    assert message.text == "The field 'name' is required."
    assert message.code == "required"



# Generated at 2022-06-22 06:09:08.041269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import tokenize
    from typesystem.frame.positions import Position
    from typesystem import fields, schemas
    from typesystem import errors

    position = Position(line=1, char_index=1)
    position2 = Position(line=1, char_index=2)
    token = tokenize([1, 2, 3], position_provider=lambda: position)

    class MySchema(schemas.Schema):
        field = fields.String(max_length=1)

    result = validate_with_positions(token=token[0], validator=MySchema)
    assert str(result) == "1"


# Generated at 2022-06-22 06:09:18.439845
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from datetime import datetime
    from decimal import Decimal
    from typesystem.fields import Array, DateTime, Number
    import pytest

    class StockSchema(Schema):
        symbol = Field(type="string", min_length=2)
        price = Field(type=Number(minimum=Decimal("0.01")))

    stock = StockSchema(
        {"symbol": "FB", "price": Decimal("123.45")},
        context=dict(offset=0, source="FB 123.45"),
    )
    assert stock.validate() == {
        "offset": 0,
        "symbol": "FB",
        "price": Decimal("123.45"),
    }


# Generated at 2022-06-22 06:09:28.303602
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, max_length=10)

    data = {"name": "Jessica"}
    token = Token.build(value=data)
    validate_with_positions(token=token, validator=Person)

    data = {"name": "Jessica Azar"}
    token = Token.build(value=data)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
    assert len(messages) == 1
    assert messages[0].start_position.char_index == 8  # name.length
    assert messages[0].start_position.line == 1
    assert messages[0].start_position.column == 9

    data = {"age": 24}

# Generated at 2022-06-22 06:09:36.626331
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import tokenize
    from typesystem.fields import String
    from typesystem.validators import MaxLength
    from typesystem.tokenize.exceptions import TokenizeError
    from typesystem.exceptions import ValidationError

    field = String(validators=[MaxLength(5)])
    tokens = tokenize("hello world")

    assert validate_with_positions(token=tokens, validator=field) == "hello"

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=tokens, validator=field)
    error_messages = error_info.value.messages()
    assert error_messages[0].start_position == (1, 1)

# Generated at 2022-06-22 06:09:46.893943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    # import pytest; pytest.set_trace();
    from typesystem.tokenize import _tokenize
    from typesystem.schemas import Schema
    from typesystem.types import String
    from typesystem.errors import ValidationError

    # An object with a single required string property
    class PersonSchema(Schema):
        name = String(required=True)

    # An object with a single (optional) number property
    class AnimalSchema(Schema):
        name = String()
        age = Integer()

    # An object with a single required property that is an object
    class ZooSchema(Schema):
        animals = List(items=AnimalSchema())

    # An object with a single required property that is an object
    # with a required property, and an optional property

# Generated at 2022-06-22 06:09:56.429469
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Product(Schema):
        id = Field(type="integer")
        name = Field(required=True)

    try:
        validate_with_positions(
            token=Token(
                value={"id": "", "name": ""},
                start=Position(line=0, column=0, char_index=0),
                end=Position(line=0, column=0, char_index=10),
            ),
            validator=Product,
        )
        assert False
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."  # type: ignore
        assert message.start_position.line == 0
        assert message.start_position.column == 0
        assert message.start_position.char_index == 0  #

# Generated at 2022-06-22 06:10:06.839270
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class FooSchema(Schema):
        field = Field(type="text")

    token = tokenize('{"field": null}')

    try:
        validate_with_positions(token=token, validator=FooSchema)
    except ValidationError as error:
        assert error.messages() == [
            {
                "code": "required",
                "end_position": {"line_index": 0, "char_index": 16},
                "index": ["field"],
                "start_position": {"line_index": 0, "char_index": 9},
                "text": "The field 'field' is required.",
            }
        ]
    else:
        assert False

# Generated at 2022-06-22 06:10:15.730655
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Article(Schema):
        title = Field(type="string")
        author = Field(type="string")

    token = Token(
        value={
            "title": "Hello World",
            "author": {
                "name": "Jane Doe",
                "age": 40,
                "books": [],
            },
            "tags": ["code", "python"],
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 10, "char_index": 27},
    )

    with pytest.raises(ValidationError) as err:
        validate_with_positions(token=token, validator=Article)

    messages = err.value.messages()
    assert len(messages) == 1

# Generated at 2022-06-22 06:10:27.245357
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import Integer, String, Array

    schema = Array[String]

    token = Token(None, {"value": ["eggs"]})

    assert validate_with_positions(token=token, validator=schema) == ["eggs"]

    token = Token(None, {"value": "spam"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    error = excinfo.value
    assert len(error.messages()) == 1

    message = error.messages()[0]
    assert message.end_position.char_index == 4
    assert message.text == "The value is not of type 'array'"

    token = Token(None, {"value": [1]})

# Generated at 2022-06-22 06:10:35.691817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string", max_length=1)

    token = Token(value="hello world", start_position=0, end_position=11)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    message = exc_info.value.messages[0]
    assert message.text == "Ensure this field has no more than 1 characters."
    assert message.code == "max_length"
    assert message.start_position == 0
    assert message.end_position == 11
    assert message.index == ()  # type: ignore



# Generated at 2022-06-22 06:10:47.213094
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field()
    value = {"foo": "bar"}
    token = Token(value=value)

    try:
        validate_with_positions(validator=field, token=token)
    except ValidationError as e:
        message = e.message()
        assert message == Message(
            text="The field 'root' is required.",
            index=["root"],
            start_position=token.start,
            end_position=token.end,
            code="required",
        )
    else:
        assert False, "should raise validation error"

    try:
        validate_with_positions(validator=field, token=token)
    except ValidationError as e:
        message = e.message()

# Generated at 2022-06-22 06:10:54.628103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    token = parse('{"users": [{"name": "foo"}]}')
    token = token.lookup(["users", 0])
    field = Field(type="string", required=True)
    validate_with_positions(token=token, validator=field)



# Generated at 2022-06-22 06:11:03.081779
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"type": "object", "properties": {"name": {"type": "string"}}})
    token = Token()
    token["name"] = Token(value="test")
    assert validate_with_positions(token=token, validator=schema) == {"name": "test"}

# Generated at 2022-06-22 06:11:14.616086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import yaml

    class TestSchema(Schema):
        name = Field(type="string")

    with open(__file__, "r") as f:
        yaml_string = f.read()

    tokens = yaml.load_all(yaml_string)
    token = next(tokens)

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.index == ("name",)
        assert message.code == "required"
        assert message.start_position.line_number == 9
        assert message.start_position.char_index == 3
        assert message.end_position.line_number == 9

# Generated at 2022-06-22 06:11:24.019037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Processor
    from typesystem.tokenize.errors import TokenizationError
    from typesystem.tokenize.tokens import Token
    from typesystem.types import String
    from typesystem.validators import MaxLength, Pattern

    class UserSchema(Schema):
        name = String(max_length=10, pattern="[A-Z]*")

    processor = Processor(
        UserSchema, transformer={"name": lambda value: value.lower()}
    )
    token: Token = processor.parse("NAME")

    try:
        validate_with_positions(token=token, validator=UserSchema)
    except TokenizationError as error:
        for message in error.messages:
            assert message.code in {"required", "max_length", "pattern"}
            assert message.text

# Generated at 2022-06-22 06:11:35.062846
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token(
        "value", [1, 2, 3], [1, 2, 3], [2, 3, 4], [2, 3, 4], "value", start=0, end=1
    )
    check = validate_with_positions(token=token, validator=field)
    assert check == "value"

    field = Field(type="string", required=True)
    token = Token(
        None, [], [], [], [], None, start=0, end=1
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)
    assert error.value.messages[0].start_position.char_index == 0, error.value.messages[0]

# Generated at 2022-06-22 06:11:45.553633
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import DictionaryToken

    def make_token(text: str, start: int, end: int) -> Token:
        return make_token_with_line_number(text, start, end, line_number=1)

    def make_token_with_line_number(text: str, start: int, end: int, line_number: int) -> Token:
        return Token.from_text(text=text, start=start, end=end, line_number=line_number, line_name=1)

    def make_dictionary_token(text: str, start: int, end: int) -> DictionaryToken:
        return make_dictionary_token_with_line_number(text, start, end, line_name=1)


# Generated at 2022-06-22 06:11:57.508882
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    schema = Schema.from_fields({"foo": String()})
    token = Token.from_value(
        {
            "foo": None,
            "bar": [{"foo": None, "bar": {"foo": {"foo": "bar"}}}, {"foo": "bar"}],
        },
        start_position=None,
        end_position=None,
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = list(error.messages())
        # NOTE: Only the `foo` key is required here
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'foo' is required."

# Generated at 2022-06-22 06:12:06.705448
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import Field, Structure

    schema = Structure({"x": Field(str, required=True), "y": Field(str)})

    tokens = tokenize({"x": "hello", "y": "world"})
    validate_with_positions(token=tokens, validator=schema)

    with pytest.raises(ValidationError) as error:
        tokens = tokenize({"y": "world"})
        validate_with_positions(token=tokens, validator=schema)

    assert [m.text for m in error.value.messages()] == ["The field 'x' is required."]

# Generated at 2022-06-22 06:12:15.970947
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(value={"foo": "bar"}, start={"line": 1, "char": 0}, end={"line": 1, "char": 5})
    validator = Field(required=True)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=validator)

    assert excinfo.value.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position={"line": 1, "char": 0},
                end_position={"line": 1, "char": 5},
            )
        ]

# Generated at 2022-06-22 06:12:24.900476
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .fixtures import simple_token, simple_field
    token = simple_token.clone()
    token.value = {"name": "", "created_at": "hello"}

# Generated at 2022-06-22 06:12:36.994181
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem import Message
    from typesystem.validators import MinLength
    from jsonschema.exceptions import ValidationError
    from io import StringIO

    io = StringIO(
        """
{
  "foo":
}
"""
    )

    token = Token.hierarchy(io)
    schema = Schema(fields={"foo": String()})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert messages[0].code == "required"
        assert messages[0].index == ("foo",)

# Generated at 2022-06-22 06:12:52.241589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        type="object",
        start_position=Token.Position(line=1, column=0, char_index=0),
        end_position=Token.Position(line=1, column=12, char_index=12),
        value={},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-22 06:13:04.103078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import JSONSchema

    from .tokens import parse_token

    schema = JSONSchema(
        {"type": "object", "properties": {"name": {"type": "string"}}}
    )
    token = parse_token('{"name": 1}')
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        errors = error.messages()
        assert errors[0].text == "1 is not of type 'string'"
        assert errors[0].start_position.line == 1
        assert errors[0].start_position.column == 13
        assert errors[0].end_position.line == 1
        assert errors[0].end_position.column == 14


# Generated at 2022-06-22 06:13:14.013750
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token

    from .token_fixtures import (
        invalid_data_with_positions,
        simple_schema,
    )
    import json

    tokenizer = Tokenizer(schema=simple_schema)
    token = Token(
        tokenizer.tokenize(json.dumps(invalid_data_with_positions)),
        start=0,
        end=0,
        parent=None,
        key=None,
    )

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=simple_schema)

    text = str(error_info.value)

# Generated at 2022-06-22 06:13:25.380397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String
    from typesystem.tokenize.python import tokenize

    custom_fields = {"string": String()}
    custom_schemas = {"integer": Integer()}
    field = Field(type="integer")
    schema = Schema(fields={"value": field})

    # Test field.
    tokens = tokenize("1")
    field.validate = validate_with_positions
    assert field.validate(tokens[0]) == 1
    with pytest.raises(ValidationError) as error:
        field.validate(tokens[0], custom_fields=custom_fields)
    messages = error.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "invalid_type"
    assert message.text

# Generated at 2022-06-22 06:13:35.917578
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        first_name = Field(type=str, required=True)

    input_text = """\
    {
        "first_name": "John",
        "last_name": "Doe"
    }
    """

    token = Token.parse(input_text)

    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1

        message = messages[0]
        assert message.code == "required"
        assert message.index == ["last_name"]
        assert message.text == 'Missing data for required field.'
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 2

# Generated at 2022-06-22 06:13:47.523758
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    token = Token(
        value={"first_name": "Alex", "last_name": "Costa"}, start={}, end={}
    )

    class Person(Schema):
        first_name = String()
        last_name = String()
        age = Integer()

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.code == "required"
        assert message.index == ("age",)
        assert message.text == 'The field "age" is required.'
        assert message.start_position == {}
        assert message.end_position == {}
    else:
        assert False

# Generated at 2022-06-22 06:13:59.490760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.exceptions import InvalidToken
    from typesystem.fields import String, Integer

    s = String()
    i = Integer()

    # Test valid value
    token = tokenize("abc".encode("utf-8"))
    assert validate_with_positions(token=token, validator=s) == "abc"

    # Test invalid value
    token = tokenize("abc".encode("utf-8"))
    with pytest.raises(InvalidToken):
        validate_with_positions(token=token, validator=i)

    # Test invalid JSON
    token = tokenize("abc".encode("utf-8"))
    with pytest.raises(InvalidToken):
        validate_with_positions(token=token, validator=list)

    #

# Generated at 2022-06-22 06:14:09.233169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import make_token

    try:
        validate_with_positions(
            token=make_token(spec={}, offset=4, start_char=4, end_char=5),
            validator=Integer(required=True),
        )
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line == 0
        assert message.start_position.column == 4
        assert message.start_position.char_index == 4
        assert message.end_position.line == 0
        assert message.end_position.column == 5
        assert message.end_position.char_index == 5

# Generated at 2022-06-22 06:14:20.891481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .tokenize import tokenize

    from .types import User

    from .utils import Position

    from .tokenize.tokens import ObjectToken

    tokenized = tokenize("{username: null}")
    object_token = ObjectToken(
        start=Position(line_index=0, char_index=0),
        value=tokenized,
        end=Position(line_index=0, char_index=15),
    )

    messages = []

    try:
        validate_with_positions(token=object_token, validator=User)
    except ValidationError as error:
        messages = error.messages()

    message = messages[0]

    assert message.code == "required"
    assert message.text == "The field 'username' is required."

    assert len(message.index) == 1

# Generated at 2022-06-22 06:14:32.223268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import Integer, Schema

    token = tokenize("{'foo': '123'}")
    root_validator = Schema({"foo": Integer()})

    foo_validator = root_validator.fields["foo"]

    assert token.value["foo"] == "123"
    assert token.value["foo"] == foo_validator.value
    assert token.value["foo"] != foo_validator.validate(foo_validator.value)

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=root_validator)
    assert len(exc.value.messages) == 1

# Generated at 2022-06-22 06:14:50.656217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Movie(Schema):
        title = Field(type=str, required=True)
        year = Field(type=int)
        rating = Field(type=float)

    data = """
    title: The Godfather
    rating: 9.2
    """

    try:
        tokenized = tokenize(data)
        validate_with_positions(token=tokenized, validator=Movie)
    except ValidationError as error:
        assert error.messages == [
            Message(
                text="The field 'year' is required.",
                code="required",
                index=["year"],
                start_position=Position(line=3, char_index=0),
                end_position=Position(line=3, char_index=4),
            )
        ]

# Generated at 2022-06-22 06:14:57.962841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.json_schema import JSONSchema
    from typesystem.schemas import Schema
    from typesystem.tokenize.scanner import Scanner
    from typesystem.tokenize.tokens import Token

    class SomeSchema(Schema):
        field = String(required=True)

    class SomeJSONSchema(JSONSchema):
        type = "object"
        properties = {"field": {"type": "string"}}
        required = ["field"]

        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.set_type_validator(SomeSchema)

    data = {"field": "hello", "property": "world"}

# Generated at 2022-06-22 06:15:05.454529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    class Person(Object):
        name = String(required=True)
        age = Integer()

    schema = Person()

    def assert_position(token, expected_line_number, expected_column_number):
        assert token.line_number == expected_line_number
        assert token.char_index == expected_column_number


# Generated at 2022-06-22 06:15:14.806704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(str, required=True)
        age = Field(int, required=True)
    token = Token(
        type="object",
        value={},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 1},
    )
    try:
        validate_with_positions(token=token, validator=PersonSchema)
    except ValidationError as error:
        messages = error.messages()
        name_error, age_error = messages
        assert name_error.start_position == {
            "line": 1,
            "column": 1,
            "char_index": 0,
        }

# Generated at 2022-06-22 06:15:26.073513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchemaV4

    schema = JSONSchemaV4.parse_file(os.path.join(os.path.dirname(__file__), "model.json"))
    # Error index is more detailed when using JSONSchemaV4.parse_file, rather than JSONSchemaV4.parse.
    # TODO: investigate why.

    schema = schema.get_type("Document")

    source = '{"version": 2, "some_field": "foo"}'
    token = Token(value=source, start=(1, 0), end=(1, len(source)))

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-22 06:15:35.899551
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.schemas import Schema, JSONSchema

    schema = JSONSchema(
        type="string", required=True, format="email", enum=["email_only"]
    )
    input_ = '{"a": "wrong_email"}'

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token(json.loads(input_), []), validator=schema)

    error_message = exc_info.value.messages()[0]
    assert error_message.index == ["a"]
    assert error_message.text == "Wrong type. Expected string, got dict."
    assert error_message.code == "type"
    assert error_message.field_name == "a"
    assert error_message.start_position

# Generated at 2022-06-22 06:15:45.587211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        foo = str

    # Testing required error
    class MyField(Field):
        validators = [MySchema]

    token = Token(value={})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MyField)
    messages = exc_info.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.code == "required"
    assert message.text == "The field 'foo' is required."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 1
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 1

# Generated at 2022-06-22 06:15:56.425486
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize

    body = """
    {
        "foo": "abc"
    }
    """
    tokens = tokenize(body)
    token = tokens[0]

    with pytest.raises(ValueError) as exc_info:
        validate_with_positions(token=token, validator=Integer())

    assert exc_info.value.messages() == [
        Message(
            text="this value must be an integer",
            code="type_error.integer",
            index=("foo",),
            start_position=Position(line_index=1, char_index=8),
            end_position=Position(line_index=1, char_index=12),
        )
    ]

# Generated at 2022-06-22 06:16:08.886903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest import TestCase
    from typesystem.tokenize.parser import parse_json

    class MySchema(Schema):
        pass

    class TestValidator(TestCase):
        def test_validation_error_with_position(self):
            token = parse_json("{}")
            with self.assertRaises(ValidationError) as context:
                validate_with_positions(token=token, validator=MySchema)
            error = context.exception
            self.assertEqual(
                error.messages(),
                [
                    Message(
                        code="required",
                        text="The field 'MySchema' is required.",
                        index=("MySchema",),
                        start_position=0,
                        end_position=0,
                    )
                ],
            )



# Generated at 2022-06-22 06:16:19.497264
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token, TokenType

    class Book(Schema):
        title = Field(type=str, required=True)

    source_code = """
    path = "road.txt"
    book = {
      "title": "The Road"
    }
    """

    token = Token.stream(source_code)
    token = token.advance(1)
    token = token.advance(2)
    token = token.advance(2)
    assert token.type == TokenType.OBJECT
    assert token.value == {
        "title": "The Road"
    }

    validated_book = validate_with_positions(token=token, validator=Book)

# Generated at 2022-06-22 06:16:45.979072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import DictionaryToken
    from typesystem.tokenize.tokens import ListToken

    from typesystem.fields import String

    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = String(required=True)
        bar = String(required=False)

    schema = MySchema()
    tokenizer = Tokenizer()

    valid_data = {"foo": "abc", "bar": "def"}
    valid_token = tokenizer.validate(valid_data)
    valid_token.lookup(["foo"])

    invalid_data = {"foo": "abc"}
    invalid_token = tokenizer.validate(invalid_data)
    invalid_token.lookup

# Generated at 2022-06-22 06:16:54.489962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, ObjectToken, StringToken

    class String(Field):
        pass

    class Foo(Schema):
        bar = String()

    token = ObjectToken(
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=5, char_index=4),
        fields=[FieldToken(name="bar", value=StringToken(value=""))],
    )
    validate_with_positions(token=token, validator=Foo)



# Generated at 2022-06-22 06:17:01.648255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import DocumentToken

    test_schema = Schema({"a": Integer()})

    test_data = """{"a": "x", "b": 2}"""
    exception = pytest.raises(ValidationError, lambda: validate_with_positions(
        token=DocumentToken.from_string(test_data), validator=test_schema
    ))
    assert len(exception.value.messages) == 2
    assert [m.index for m in exception.value.messages] == [[], ["a"]]
    assert exception.value.messages[0].start_position.row == 0
    assert exception.value.messages[1].start_position.row == 0

# Generated at 2022-06-22 06:17:12.590231
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    class BookSchema(Schema):
        title = Field(str)
        published = Field(str)

    class BookListSchema(Schema):
        books = Field(BookSchema, many=True)

    json_string = """
        {
            "books": [
                {
                    "title": "The Dark Tower",
                    "published": "1982"
                },
                {
                    "title": "The Wind through the Keyhole"
                }
            ]
        }
    """
    tokens = tokenize_string(json_string)

# Generated at 2022-06-22 06:17:18.259061
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import parse

    from typesystem.fields import Text
    from typesystem.tokenize.tokens import LeafToken

    validated = validate_with_positions(
        token=LeafToken(parse("foobar"), value=42), validator=Text()
    )
    assert validated == "42"

# Generated at 2022-06-22 06:17:27.256376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import PropertyToken

    class Field(Schema):
        type = "string"

    class ErrorMessage(Schema):
        code = "required"
        text = "The field foo is required."

    class Test(Schema):
        foo = Field
        bar = Field

    test = Test.validate({"foo": "hello"})
    assert test.errors == [ErrorMessage]

    token = PropertyToken(name="bar", position=Position(line=1, char_index=0))
    token.parent = PropertyToken(name="foo", position=Position(line=1, char_index=0))
    try:
        validate_with_positions(token=token, validator=Field)
    except ValidationError as error:
        error

# Generated at 2022-06-22 06:17:37.307255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    class Person(Schema):
        name = Field(str, min_length=1)
        age = Field(float)
        address = Field(str, optional=True)

    token = parse("Person(name=A person, age=100, address=None)")

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position.column == 19
        assert error.messages()[1].start_position.column == 37
    else:
        raise AssertionError("Expected exception.")

# Generated at 2022-06-22 06:17:43.006980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from .helpers import schema

    tokens = tokenize({"title": "New article", "body": "..."})
    article = schema(
        {"title": "string", "body": ["string", "null"], "author": "string"}
    )
    try:
        validate_with_positions(token=tokens, validator=article)
    except ValidationError as error:
        assert str(error) == 'The field "author" is required.'
    else:
        assert False

