

# Generated at 2022-06-22 06:07:44.991120
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import Integer, String

    class Movie(Schema):
        title = String(required=True)
        year = Integer()

    data = json.loads(
        """
        {
          "title": 4, 
          "year": "2016"
        }
    """
    )

    token = Token.from_data(data)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Movie)
    messages = exc_info.value.messages

    assert messages[0].code == "type"
    assert messages[0].text == "Expected a string, got Integer."
    assert messages[0].start_position.line_number == 3
    assert messages[0].start_position.char_index == 10

# Generated at 2022-06-22 06:07:49.931705
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.types import String

    validator = String()
    token = ObjectToken({}, line="", column=0, line_number=1, column_number=1)
    token.schema = {"foo": validator}
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=token.schema)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'foo' is required."
    assert message.start_position.line_number == 1
    assert message.start_position.column_number == 1

# Generated at 2022-06-22 06:08:00.944359
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, tokenize_document

    document = """
        {
            field1: "a",
            field2: "b",
            field3: "c"
        }
    """
    token = tokenize_document(document)

    class Schema(Schema):
        field1 = Field(type=str)
        field2 = Field(type=int)
        field3 = Field(type=bool)

    schema = Schema()
    try:
        # This won't work because we don't have the positions
        res = schema.validate(token.value)
    except ValidationError as error:
        assert error.messages[0].text == "Expected a integer."
        assert error.messages[1].text == "Expected a boolean."

    # But by calling validate_with_

# Generated at 2022-06-22 06:08:09.673710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    import typesystem.tokenize

    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class PersonError(ValidationError):
        pass

    tokens = typesystem.tokenize.tokens_from_json(
        """
        {
            "name": "Fred",
            "age": "47"
        }
        """
    )
    token = tokens[0]
    with pytest.raises(PersonError) as exc_info:
        validate_with_positions(token=token, validator=PersonSchema())
    error = exc_info.value.messages[0]
    assert error.index == ["age"]
    assert error.text == "The value is not a valid integer."
   

# Generated at 2022-06-22 06:08:18.985150
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parser
    from jsonschema import Draft4Validator
    from typesystem.fields import Integer, String

    validator = Draft4Validator(
        {
            "type": "object",
            "properties": {
                "a": {"type": "integer"},
                "b": {"type": "object", "properties": {"c": {"type": "string"}}},
            },
        }
    )
    val = parser.parse("{a: 10, b: {c: 'test'}}")
    validate_with_positions(token=val, validator=validator)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=val, validator=Integer())

# Generated at 2022-06-22 06:08:29.536692
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    import pytest

    class SimpleSchema(Schema):
        name = String(required=True)
        age = String(required=True)

    schema = SimpleSchema()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token(value={}), validator=schema)

    error = exc_info.value

    assert len(error.messages) == 2
    assert error.messages[0].text == "The field 'name' is required."
    assert error.messages[0].start_position == (0, 18)
    assert error.messages[0].end_position == (0, 24)

# Generated at 2022-06-22 06:08:38.906516
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer
    from typesystem.tokenize.parser import parse

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=parse("{name: 'bob', age: 'thirty' }"), validator=Person
        )

    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].start_position == (7, 8)
    assert exc_info.value.messages[0].end_position == (14, 15)



# Generated at 2022-06-22 06:08:47.142247
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize

    schema = typesystem.Schema(
        {
            "name": typesystem.String(required=True),
            "age": typesystem.Integer(),
            "friends": typesystem.Array(typesystem.String()),
        }
    )
    token = typesystem.tokenize.tokens.Token("foo")
    with pytest.raises(typesystem.ValidationError) as context:
        validate_with_positions(token=token, validator=schema)

    assert context.value.messages()[0].start_position == typesystem.Position(
        line=1, column=1, char_index=0
    )


__all__ = ["validate_with_positions"]

# Generated at 2022-06-22 06:08:58.175983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.parser import TokenParser

    class Person(Schema):
        name = String(max_length=5)
        age = Integer()

    class Team(Schema):
        name = String()
        players = Array(items=Person)

    def test_schema(input):
        # type: (str) -> typing.Dict[str, typing.Any]
        parser = TokenParser()
        token = parser.parse(input)
        validate_with_positions(token=token, validator=Team)
        return {
            "start": token.start,
            "end": token.end,
            "value": token.value,
        }


# Generated at 2022-06-22 06:09:08.271053
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String
    from typesystem.tokenize.tokenizers import Tokenizer

    class User(Schema):
        name = String(required=True)

    json = """
    {
        "name": "",
        "age": "foo"
    }
    """
    tokenizer = Tokenizer.from_json(json)
    try:
        validate_with_positions(token=tokenizer.token, validator=User)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[1].text == "Value must be a string."

# Generated at 2022-06-22 06:09:22.738854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse_string import parse_string
    from typesystem.tokenize.tokens import Token, LookupToken, ReferenceToken


# Generated at 2022-06-22 06:09:29.339960
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class PositiveInt(Field[int]):
        def check_value(self, value: typing.Any) -> int:
            return int(value)

        def check_type(self, value: int) -> typing.NoReturn:
            if value <= 0:
                raise ValidationError(code="value-not-greater-than-zero")

    class SchemaA(Schema):
        a = PositiveInt()

    class SchemaB(Schema):
        b = PositiveInt()

    class SchemaC(Schema):
        c = SchemaA()
        d = SchemaB()

    class SchemaD(Schema):
        d = [SchemaC()]


# Generated at 2022-06-22 06:09:39.453518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import tokenize

    field = String(required=True)
    tokens = tokenize(
        """
This is some text ...
"""
    )
    try:
        validate_with_positions(token=tokens[0], validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 2
        assert error.messages()[0].start_position.char_index == 4
        assert error.messages()[0].end_position.line == 2
        assert error.messages()[0].end_position.char_index == 18
    else:
        assert False

    field = String(min_length=1, max_length=3)

# Generated at 2022-06-22 06:09:49.482489
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        index=(), name="_", value="", start=(0, 0), end=(0, 0), children=[]
    )

    string_field = String(required=True)

    try:
        validate_with_positions(token=token, validator=string_field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field '' is required."
        assert message.index == ()
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 0
        assert message.end_position.line_index == 0
        assert message.end_position.char

# Generated at 2022-06-22 06:09:59.272889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class AddressSchema(Schema):
        required_text = Field(type="text", required=True)
        optional_text = Field(type="text", required=False)

    schema = AddressSchema()
    token = tokenize("""
        required_text: ""
        optional_text: ""
        """)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'required_text' is required.",
            code="required",
            index=["required_text"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-22 06:10:10.944409
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    token = Token.parse({"foo": 100})

    try:
        validate_with_positions(token=token, validator=Field(type=str))
        assert False, "validation did not fail"
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].text == "invalid type"
        assert error.messages[0].index == ["foo"]

    try:
        validate_with_positions(token=token, validator=Schema({"foo": str}))
        assert False, "validation did not fail"
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].text == "invalid type"

# Generated at 2022-06-22 06:10:23.084731
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:10:34.838383
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, Array
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Tokens

    schema = Schema({"a": Integer(), "b": String()})
    tokens = Tokens(
        [
            Token("root", start_index=0, end_index=0, value={}),
            Token("a", start_index=1, end_index=1, value=1),
            Token("b", start_index=2, end_index=2, value="abc"),
        ]
    )
    validator = schema.fields["a"]
    token = tokens[0]
    value = validate_with_positions(token=token, validator=validator)
    assert value == 1

    validator = schema.fields["b"]
    token = tokens

# Generated at 2022-06-22 06:10:46.930215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.location import Location
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.types import String
    from typesystem.validators import required
    from typesystem.fields import Field
    from typesystem.schemas import Schema, key_fields, value_fields

    field = Field(type=String, validators=[required()])

# Generated at 2022-06-22 06:10:55.893431
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema, Structure
    from typesystem.tokenize.tokens import Token

    class Person(Structure):
        name = String(max_length=10)
        age = Integer(minimum=18)

    string = '{"name":"Test1","age":12}'
    token = Token.from_string(string)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert (
            error.messages()[0].text
            == 'Ensure this value is greater than or equal to 18.'
        )
        assert error.messages()[0].start_position == (2, 16)

# Generated at 2022-06-22 06:11:10.380893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SchemaA(Schema):
        a = Field(type="integer")

    class SchemaB(Schema):
        b = Field(type="string")

    a = SchemaA(token={"a": {"value": "a", "start": {"line": 1, "char": 2}}})

    with pytest.raises(ValidationError):
        validate_with_positions(token=a.a, validator=SchemaB)
    schema = SchemaB(token={"b": {"value": "b", "start": {"line": 1, "char": 2}}})
    assert validate_with_positions(token=schema.b, validator=SchemaB).b == "b"

# Generated at 2022-06-22 06:11:20.647055
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    tokens = tokenize(
        {
            "pets": [
                {"name": "mary", "type": "dog"},
                {"name": "jane"},
                {"name": "muffin", "type": "cat"},
            ]
        }
    )
    Pet = Schema({"name": str, "type": str})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=Pet)
    assert exc_info.value.messages[0].start_position.line == 2
    assert exc_info.value.messages[0].start_position.char_index == 32
    assert exc_info.value.messages[1].start_position.line == 4
    assert exc

# Generated at 2022-06-22 06:11:22.456861
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:11:30.788993
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        field = validate_with_positions(
            field=dict(type="string", required=True),
        )

    schema = ExampleSchema()
    data = {"field": "test"}

    assert schema.validate(data) == data

    with pytest.raises(ValidationError) as exc_info:
        schema.validate({})

    error_message = exc_info.value.messages[0]
    assert error_message.text == "The field 'field' is required."
    assert error_message.start_position == (1, 1)
    assert error_message.end_position == (1, 7)

    # Appending optional field

# Generated at 2022-06-22 06:11:36.942985
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lexer, serialize

    class A(Schema):
        name = Field(required=True)
        age = Field(type="integer")
        address = Field(type=Address)

    class Address(Schema):
        street = Field(required=True)
        city = Field(required=True)

    # Attempt to validate a tokenized representation of the input
    assert validate_with_positions(token=serialize(A, {"name": "John"}), validator=A)
    assert validate_with_positions(token=serialize(A, {"name": "John", "age": "29"}), validator=A)

# Generated at 2022-06-22 06:11:47.565840
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.json import parse_json

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="number")

    json_string = """{
        "name": "John Smith",
        "age": "20"
    }"""

    tokens = parse_json(json_string)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=Person)

    errors = sorted(exc_info.value.messages, key=lambda e: e.start_position)
    assert errors[0].start_position == (2, 23)
    assert errors[0].end_position == (2, 25)
    assert errors[0].text == "Expecting to find a number."

# Generated at 2022-06-22 06:11:56.589002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"name": "Joe"}')[0]

    try:
        validate_with_positions(
            token=token,
            validator=Schema({"name": Field(type="string", length=2)}),
        )
    except ValidationError as error:
        messages = list(error.messages())
        assert messages[0].index == ["name"]
        assert messages[0].start_position.line == 2
        assert messages[0].start_position.char_index == 22
        assert messages[0].end_position.line == 2
        assert messages[0].end_position.char_index == 25
        assert messages[0].code == "invalid_length"

# Generated at 2022-06-22 06:12:07.069677
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class BasicPerson(Schema):
        name = String()
        age = Integer()

    from typesystem.tokenize.loaders import load_json_string

    from typesystem.tokenize.parse import json_parse

    from typesystem.tokenize.tokens import Token

    token = json_parse(load_json_string("""
    {
        "name": "Duke",
        "email": "hello@world.com"
    }
    """))

    error_token = Token(
        "Duke",
        start_line=3,
        start_column=9,
        end_line=3,
        end_column=13,
        start_char=47,
        end_char=51,
    )

# Generated at 2022-06-22 06:12:16.472377
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.parser

    errors = []
    # Ensure all positional error messages are sorted by char_index
    validator = typesystem.tokenize.parser.object({
        "end": typesystem.tokenize.parser.number(),
        "start": typesystem.tokenize.parser.number(),
        "name": typesystem.tokenize.parser.string(),
    })
    source = "{e}nd: 1, start: 'foo'}"
    try:
        validator.validate(source)  # type: ignore
    except ValidationError as error:
        errors = error.messages
    assert len(errors) == 2
    assert errors[0].text == "The field 'start' is required."

# Generated at 2022-06-22 06:12:25.269472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.typings import Dict, String

    from typesystem.tokenize.vendored.tokenize import generate_tokens
    from typesystem.tokenize.tokens import Token, Tokens

    from typesystem.schemas import Schema

    from typesystem.tokenize.compat import SourceCode

    text = '{"foo": "bar"}'
    tokens = generate_tokens(io.StringIO(text).readline)
    tokens = Tokens([Token.from_token(t) for t in tokens])

    source_code = SourceCode(source_code=text, tokens=tokens)

    class MySchema(Schema):
        foo = String()


# Generated at 2022-06-22 06:12:41.647843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    from .tokenize import tokenize

    from .typedefs import Position

    class SimpleSchema(Schema):
        name = Field(str)

    text = "---\nname: foo\n"
    token = tokenize(text)
    value = validate_with_positions(token=token, validator=SimpleSchema)
    assert value == {"name": "foo"}

    text = "---\nfoo: bar\n"
    token = tokenize(text)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=SimpleSchema)
    message = exc_info.value.messages[0]
    assert message.index == ["name"]

# Generated at 2022-06-22 06:12:52.013553
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import FieldToken, StringToken

    class PersonSchema(Schema):
        name = String()

    token = FieldToken(
        "person",
        start="None:1:10:None:1:15",
        end="None:1:15:None:1:20",
        children=[StringToken(value="Alice", start="None:1:10:1:10", end="None:1:16:1:16")],
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=PersonSchema)


# Generated at 2022-06-22 06:13:04.102787
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import schema
    from typesystem.tokenize.base import parse

    class TestField(Field):
        sanitize_named = False

    TestField.define(
        "field_name",
        sanitize=lambda *args: validate_with_positions(
            token=args[0], validator=schema.String()
        ),
    )

    class TestSchema(schema.Object):
        @classmethod
        def structure(cls, info):
            return {
                "field_name": TestField(required=True),
            }

    tokens = parse("<data>{field_name}</data>")
    token = tokens[0]
    with pytest.raises(ValidationError) as e:
        TestSchema.validate_token(token)


# Generated at 2022-06-22 06:13:09.441890
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import Document, Object  # type: ignore

    class TestSchema(Object):
        class Options:
            validate_with_positions = True

        field = "string"

    schema = TestSchema()
    result = validate_with_positions(token=Document(""), validator=schema)
    assert result == {"field": ""}

# Generated at 2022-06-22 06:13:19.886666
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import String, Integer, Array

    class Book(Schema):
        title = String(max_length=10)
        chapters = Array(items=Array(items=Integer()))

    data = {
        "title": "hello world",
        "chapters": [[1, 2, 3]]
    }


# Generated at 2022-06-22 06:13:30.965593
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import AttrToken
    from typesystem.tokenize import tokenize, Token

    class User(Schema):
        name = Field(str)
        age = Field(int, required=False)

    content = '{"name":"foo"}'
    tokens: typing.List[Token] = tokenize(content)
    token = AttrToken(tokens=tokens)

    validate_with_positions(token=token, validator=User)

    content = '{"name":"foo", "age":"invalid"}'
    tokens = tokenize(content)
    token = AttrToken(tokens=tokens)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=User)

    error = exc

# Generated at 2022-06-22 06:13:41.654350
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int, required=False)
        address = Field(str, required=False)

    token = Token(
        value={"name": "foo", "age": 15, "address": "bar"},
        start={"line_no": 8, "char_index": 3},
        end={"line_no": 17, "char_index": 29},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        raise AssertionError("not supposed to raise")

    # Now, add a required field
    class Person(Schema):
        name = Field(str)

# Generated at 2022-06-22 06:13:44.011763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False, "Not Implemented"

# Generated at 2022-06-22 06:13:55.232714
# Unit test for function validate_with_positions
def test_validate_with_positions():
    required_field_message = "The field 'a.b.c' is required."
    invalid_field_message = "Invalid value 'invalid', should be a string."

    def get_error_messages(tokens, validator):
        try:
            validate_with_positions(token=tokens, validator=validator)
        except ValidationError as error:
            messages = error.messages()
        return messages

    class ExampleSchema(Schema):
        a = Field(type="string")
        b = Field(type="string")
        c = Field(type="string")

    # noinspection PyTypeChecker

# Generated at 2022-06-22 06:14:08.471040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas.primitive import Any
    from typesystem.schemas.strategies import oneOfStrategy
    from typesystem.schemas.typing import Optional

    from .tokenize import tokenize

    text = """
    bool: true
    int: -10
    float: -3.14159
    str: "str"
    """
    schema = Any(type=int, strategies=[oneOfStrategy([Optional(type=int)])])

    tokens = tokenize(text)


# Generated at 2022-06-22 06:14:27.307597
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import datetime
    from django.core.serializers.json import DjangoJSONEncoder
    from typesystem.tokenize.lexers import parse_json
    from typesystem.tokenize.tokens import Token

    token = parse_json(
        text='{"id": 123, "created": "2015-01-31T12:00:00Z", "balance": 7.25}'
    )  # type: Token
    token = token.lookup("id")
    assert token.value == 123

    class MySchema(Schema):
        id = Field(type="integer")
        created = Field(type="datetime")
        balance = Field(type="number", decimals=2)

    v = MySchema()
    assert v.validate(token.value) == 123


# Generated at 2022-06-22 06:14:35.858033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import new_token
    from typesystem.fields import String
    from typesystem.exceptions import ValidationError
    from typesystem.errors import Error

    field = String(min_length=2)

    try:
        validate_with_positions(
            token=new_token(value="a", start=(1, 0), end=(1, 0)), validator=field
        )
    except ValidationError as e:
        assert isinstance(e.messages()[0], Error)
        assert e.messages()[0].text == "min_length is 2"
        assert e.messages()[0].start_position == (1, 0)
        assert e.messages()[0].end_position == (1, 0)



# Generated at 2022-06-22 06:14:47.126863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import compile_grammar, split_tokens
    from typesystem.tokenize.tokens import Token

    person = compile_grammar(
        """
    type Person {
        name: String!
        age: Float!
        address: String
    }
    """,
        type_name="Person",
    )

    tokens = split_tokens(
        """
    person {
        name: "Jon"
        age: "55"
    }
    """,
    )

    try:
        validate_with_positions(token=tokens[0], validator=person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code

# Generated at 2022-06-22 06:14:55.170511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema({"field": Field(required=True)})
    token = Token.from_object({"field": "value"})
    validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token.delete("field"), validator=schema)
    assert excinfo.value.messages()[0].start_position.char_index == 1

# Generated at 2022-06-22 06:15:05.774612
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ConfigurationSchema(Schema):
        a = Field(type="string", required=True)
        b = Field(type="string")

    token = Token(
        {"start": {"line_index": 1, "char_index": 0}, "end": {}},
        {
            "a": {"start": {"line_index": 1, "char_index": 0}, "end": {}},
            "b": {"start": {"line_index": 1, "char_index": 0}, "end": {}},
        },
        {
            "a": {"start": {"line_index": 1, "char_index": 0}, "end": {}},
            "b": {"start": {"line_index": 1, "char_index": 0}, "end": {}},
        },
    )


# Generated at 2022-06-22 06:15:16.979881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    token = Token(
        value={"text": "hello"}, start={"line_num": 1, "char_index": 0}, end={"line_num": 1, "char_index": 13},
    )
    validator = String(name="text")
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.message.start_position["line_num"] == 1
        assert error.message.end_position["line_num"] == 1
        assert error.message.start_position["char_index"] == 0
        assert error.message.end_position["char_index"] == 13
        assert error.message.text == "expected string"
    else:
        assert False, "expected a ValidationError"

# Generated at 2022-06-22 06:15:27.940145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, compound

    class Settings(compound.Compound):
        username = String(required=True)
        theme = String(allowed=["dark", "light"])
        homepage = Integer()

    from typesystem.tokenize import tokenize
    from typesystem.serialize import loads
    from typesystem.validate import validate

    value = {"username": "john", "homepage": "6"}
    token = tokenize(Settings, value)
    validate(token, Settings)

    value = {"username": "john", "homepage": "6.0"}

    token = tokenize(Settings, value)
    try:
        validate(token, Settings)
    except ValidationError as error:
        message = next(iter(error.messages()))
        assert message.text == "Value must be of type integer."

# Generated at 2022-06-22 06:15:33.436212
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    from typesystem.schemas import Object, String

    class Example(Object):
        field: String

    example = Example()

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(validator=example, token=Token(value={}))
    assert excinfo.value.messages[0].start_position.char_index == 1

# Generated at 2022-06-22 06:15:43.581693
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token
    from typesystem.base import Message
    from typesystem.fields import String

    token = Token(
        value="abc",
        start={"char_index": 0, "line_index": 0, "column_index": 1},
        end={"char_index": 3, "line_index": 0, "column_index": 4},
    )
    validator = String(min_length=4)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=validator)

    messages = excinfo.value.messages()
    assert len(messages) == 1
    message = messages[0]

# Generated at 2022-06-22 06:15:54.517347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.validators import validate_list
    from typesystem.tokenize.types import SchemaType

    document = """a: [1, 2, 3, 4]
b: [1, 2, 3]
""".strip()

    schema = Schema(
        fields={"a": Field(validators=[validate_list]), "b": Field(validators=[validate_list])}
    )
    token = parse(document=document, document_type=SchemaType(schema=schema))
    messages = []

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages.extend(error.messages())

    assert len(messages) == 1

# Generated at 2022-06-22 06:16:20.419257
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        key="top",
        value={
            "key": "",
            "inner": [{"a": 1, "b": 2}, {"a": 3, "b": "c"}],
            "data": 3,
        },
        start=Position(line_number=1, char_index=0),
        end=Position(line_number=4, char_index=4),
    )

    class DataSchema(Schema):
        data = Field(integer)

    class InnerSchema(Schema):
        a = Field(integer)
        b = Field(string)

    class TopSchema(Schema):
        key = Field(string)
        data = DataSchema()
        inner = Field(array(InnerSchema()))


# Generated at 2022-06-22 06:16:27.223316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class DogSchema(Schema):
        name = String(max_length=255)
        age = Integer()

    tokens = tokenize(value={"name": "Waldi", "age": -10})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens["age"], validator=DogSchema)
    assert error.value.messages[0].start_position == (1, 7)
    assert error.value.messages[0].end_position == (1, 10)




# Generated at 2022-06-22 06:16:38.849363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class CustomSchema(Schema):
        field = String()

    value = {"field": ""}
    token = Token(value=value)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=CustomSchema)
    assert len(error.value.messages) == 2
    assert error.value.messages[0].text == "The field 'field' is required."
    assert error.value.messages[1].text == "A non-empty string is required."

# Generated at 2022-06-22 06:16:51.475325
# Unit test for function validate_with_positions
def test_validate_with_positions():
    @dataclass(frozen=True, order=True)
    class Position:
        line: int
        column: int
        char_index: int

    @dataclass(frozen=True, order=True)
    class Token:
        value: typing.Any
        start: Position
        end: Position

        def lookup(self, index: typing.List[int]) -> "Token":
            token = self
            for i in index:
                token = token.value[i]
            return token

    @dataclass(frozen=True, order=True)
    class PositionMessage(Message):
        start_position: Position
        end_position: Position

    class TextField(Field):
        def validate(self, value: typing.Any) -> typing.Any:
            raise ValidationError([PositionMessage(text="fail")])

# Generated at 2022-06-22 06:17:00.672275
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, String

    class Item(Schema):
        name = String(required=True)

    class User(Schema):
        name = String()
        age = Integer()

    class Database(Schema):
        users = Array(items=User())

    token = tokenize({"users": [{"name": "Bob", "age": 14}]}, Database)
    result = validate_with_positions(token=token, validator=Database)
    assert result == token.value
    assert isinstance(result, list)

    result = validate_with_positions(token=token.lookup("users").lookup("0"), validator=User)
    assert result == token.lookup("users").lookup("0").value
    assert isinstance(result, dict)


# Generated at 2022-06-22 06:17:11.836465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Array
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokens import String
    from typesystem.fields import Integer

    json_obj = {
        "items": [
            "a",
            False,
            [],
            {
                "key": {
                    "inner_key": {
                        "another_key": "value",
                        "another_key_2": "value",
                    }
                }
            },
        ]
    }


# Generated at 2022-06-22 06:17:23.071136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class TestSchema(Schema):
        x = Field(required=True)
        y = Field(required=True)

    tokens = tokenize([{"x": 1, "y": 2, "z": 3}], schema=TestSchema)
    assert tokens[0].x.value == 1
    assert tokens[0].y.value == 2
    assert tokens[0].z.value == 3

    try:
        validate_with_positions(token=tokens[0], validator=TestSchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position == (1, 21)  # start of {"x": ...
        assert message.end_position

# Generated at 2022-06-22 06:17:33.260459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    obj = [1, 2, 3]
    token = Token.list_type(value=obj, start=0, end=20)

    class TestSchema(Schema):
        foo = Field(type="integer")

    schema = TestSchema()

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.char_index == 20

# Generated at 2022-06-22 06:17:43.771037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import ujson
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    schema = Schema(fields={"age": Integer(), "name": String()})

    document = ujson.loads("""{
        "age": "",
        "name": ""
    }""")
    token = Token(document)

    error = None
    try:
        validate_with_positions(validator=schema, token=token)
    except ValidationError as e:
        error = e

    assert error is not None
    assert error.messages()[0].start_position.char_index == 10
    assert error.messages()[1].start_position.char_index == 36