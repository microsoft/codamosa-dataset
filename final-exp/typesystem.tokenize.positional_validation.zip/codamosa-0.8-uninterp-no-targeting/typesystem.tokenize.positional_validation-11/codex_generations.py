

# Generated at 2022-06-22 06:07:57.912863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import NullToken, Token
    from typesystem.types import String
    import pytest

    token = NullToken("test_token")("{}", start=0)

    def validate(value):
        return value  # pragma: nocover

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=String(validators=[validate]))
    assert excinfo.value.messages == [
        Message(
            text="This field is required.",
            code="required",
            index=[],
            start_position=0,
            end_position=2,
        )
    ]



# Generated at 2022-06-22 06:08:08.931191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import Schema

    class Test(Schema):
        field = Field(type=str, required=True)

    from typesystem.tokenize.tokenizer import Tokenizer

    tokenizer = Tokenizer(schema=Test)
    token = tokenizer.tokenize(b'{"field": "value"}')
    validate_with_positions(token=token, validator=Test)

    token = tokenizer.tokenize(b'{}')
    try:
        validate_with_positions(token=token, validator=Test)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "required"
        assert message.text == "The field 'field' is required."
        assert message.start_position.char_index == 2

# Generated at 2022-06-22 06:08:18.256639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        field1 = Field(type="integer", required=True)
        field2 = Field(type="number")

    token = Token.build(value={"field1": 2})
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        assert error.messages[0].code == "required"
        assert error.messages[0].index == ("field2",)
        assert error.messages[0].start_position == Position(offset=17, index=17)
        assert error.messages[0].end_position == Position(offset=17, index=17)

# Generated at 2022-06-22 06:08:29.955296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.tokenize.base import tokenize
    from typesystem.tokenize.tokens import Token

    class NoteSchema(Schema):
        title = fields.String(max_length=100)
        body = fields.String()

    tokens = tokenize(
        """
        {
            "title": "the title of the note",
            "body": "the body of the note"
        }
        """
    )
    token = Token.from_tokens(tokens)

    note = validate_with_positions(token=token, validator=NoteSchema)
    assert type(note) is dict
    assert note["title"] == "the title of the note"
    assert note["body"] == "the body of the note"


# The following error message tests illustrate the source

# Generated at 2022-06-22 06:08:35.710327
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.string_types import String

    schema = String()
    input_json = '{"foo": 3}'
    tokens = tokenize(input_json)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=schema)
    assert excinfo.value.messages()[0].start_position.char_index == 7
    assert excinfo.value.messages()[0].end_position.char_index == 9

# Generated at 2022-06-22 06:08:45.487304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema  # noqa
    from typesystem.fields import Field  # noqa
    from typesystem.tokenize import add_positions_to_tokens  # noqa

    class Author(Schema):
        name = Field(str)
        age = Field(int)

    class BlogPost(Schema):
        name = Field(str)
        author = Field(Author)
        tags = Field(array_of=str)

    class User(Schema):
        name = Field(str)
        posts = Field(array_of=BlogPost)


# Generated at 2022-06-22 06:08:56.534184
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    field = Integer()
    tokens = [
        Token("start", "2"),
        Token("end", "4"),
        Token("start", "4"),
        Token("end", "6"),
        Token("start", "6"),
        Token("end", "8"),
    ]

    try:
        validate_with_positions(token=tokens[-1], validator=field)
    except ValidationError as error:
        messages = sorted(
            error.messages(),
            key=lambda m: m.start_position.char_index,  # type: ignore
        )
        assert len(messages) == 3
        assert messages[0].text == "8 is not a valid integer."
        assert messages[0].start_position == tokens[-1].start

# Generated at 2022-06-22 06:09:04.135481
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class TokenStub:

        def __init__(self, value, parent, start, end):
            self.value = value
            self.parent = parent
            self.start = start
            self.end = end

        def lookup(self, index):
            if self.parent is None:
                return self
            return self.parent.lookup(index)

    class FieldStub:

        def __init__(self, messages):
            self.messages = messages

        def validate(self, value):
            raise ValidationError(self.messages)

    class PositionStub:

        def __init__(self, line, line_offset, char_index):
            self.line = line
            self.line_offset = line_offset
            self.char_index = char_index

    # Test a single required field at root level


# Generated at 2022-06-22 06:09:11.802896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import Integer

    with pytest.raises(
        ValidationError, match="not.*valid.*integer.*line.*1.*char.*0"
    ):
        validate_with_positions(
            token=Token(
                value="not_a_valid_integer",
                start=Position(line=1, char_index=0),
                end=Position(line=1, char_index=19),
            ),
            validator=Integer(),
        )



# Generated at 2022-06-22 06:09:22.691297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_serialize_to_yaml import BaseYAMLObject

    class Person(BaseYAMLObject):
        required_properties = ["name"]
        properties = {
            "name": Field(required=True, primitive_type=str),
            "age": Field(required=False, primitive_type=int),
        }

    class People(BaseYAMLObject):
        required_properties = ["people"]
        properties = {"people": Field(type=Person, required=True, is_list=True)}

    token = Token.from_yaml("""
    people:
      - name: John
        age: 50
      - name: Alice
        age: "foo"
      - name: Bob
    """)


# Generated at 2022-06-22 06:09:36.085016
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Object, String

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=Token.parse_text(
                """
            {
                "name": "foo"
                "age": "10"
            }
        """
            ),
            validator=Object(
                properties={
                    "name": String(required=True),
                    "age": Integer(),
                }
            ),
        )
    assert len(error_info.value.messages) == 3
    message = error_info.value.messages[0]
    assert message.text == 'The field "name" is required.'
    assert message.code == "required"
    assert message.start_position.line == 2
    assert message.start_position.column == 5
   

# Generated at 2022-06-22 06:09:38.097809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:09:48.570867
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenize import tokenize_string

    schema = Schema(fields={"name": Field(required=True)})

    token = tokenize_string("{}")[0]
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1

        message = error.messages[0]
        assert message.start_position.line == 1
        assert message.start_position.col == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line == 1
        assert message.end_position.col == 2
        assert message.end_position.char_index == 1



# Generated at 2022-06-22 06:09:58.469741
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import ijson
    from typing import List

    from typesystem.tokenize.base import Token

    from tests.tokenize.utils import string_to_tokens

    from tests.harnesses.schema.conftest import DummySchema

    schema = DummySchema()


# Generated at 2022-06-22 06:10:08.897050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    token = Token(
        value={},
        children=[
            Token(
                value="Jason",
                children=[],
                start=Position(index=1, line=1, char_index=1),
                end=Position(index=5, line=1, char_index=5),
            ),
            Token(
                value=42, children=[], start=Position(index=6, line=1, char_index=6), end=Position(index=7, line=1, char_index=7)
            ),
        ],
        start=Position(index=0, line=1, char_index=0),
        end=Position(index=8, line=1, char_index=8),
    )
    validator = Integer()

# Generated at 2022-06-22 06:10:16.954892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields

    class Person(Schema):
        name = fields.String(required=True)

    obj = Person.validate({"name": "Pablo"})
    assert obj == {
        "name": "Pablo",
    }

    with pytest.raises(ValidationError) as exc_info:
        obj = Person.validate({})
    assert len(exc_info.value.messages()) == 1
    assert exc_info.value.messages()[0].text == "The field 'name' is required."
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.column == 2

# Generated at 2022-06-22 06:10:28.621572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Structure

    class User(Structure):
        name = String()
        email = String()

    # User.validate doesn't work because it gets confused by the line numbers
    # in the ValidationError.
    @User.register_validator
    def validate(token: Token) -> str:
        return validate_with_positions(
            token=token, validator=User
        )  # type: ignore

    with pytest.raises(ValidationError) as exc:
        User.validate({})

    for message in exc.value.messages():
        print(message.text)

    message = exc.value.messages()[0]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 1

# Generated at 2022-06-22 06:10:37.799099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Dict, String, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import MapToken, Token

    class Movie(Schema):
        title = String()

    class MovieList(Schema):
        movies = Dict(Movie)

    text = '{"movies": { "foo":   { "title": "Hello"}}}'
    token = Token.parse(text)
    movie_list = token.lookup(["movies"])
    try:
        validate_with_positions(token=movie_list, validator=MovieList)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == 'The field "foo" is not defined.'


# Generated at 2022-06-22 06:10:47.579985
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize

    class Point(Schema):
        x = Field(type="number")
        y = Field(type="number")

    tokens = tokenize("[1, 2, 3]")
    assert validate_with_positions(token=tokens, validator=Point) == {"x": 1, "y": 2}

    tokens = tokenize("[1, 2, 3]")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens, validator=Point)

# Generated at 2022-06-22 06:10:59.673980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.typing import Number

    class ExampleSchema(Schema):
        field = Number()

    # no validation errors
    token = Token(index=["field"], value=None, start=1, end=1)
    assert validate_with_positions(token=token, validator=ExampleSchema) == {
        "field": None
    }

    # with validation errors
    token = Token(index=["field"], value=None, start=1, end=1)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=ExampleSchema)

# Generated at 2022-06-22 06:11:20.551240
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type=str, source="$.name")
        age = Field(type=int, source="$.age")

    input = dict(name="Peter", age=30)
    token = Token(value=input, type="object")

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        [message] = error.messages()
        assert message.text == "The field 'email' is required."
        assert message.start_position == Position(
            char_index=8, line=1, column=9, line_char_index=8
        )
        assert message.end_position == Position(
            char_index=14, line=1, column=15, line_char_index=14
        )




# Generated at 2022-06-22 06:11:30.418688
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken
    from typesystem.fields import String

    # Test for simple error message
    token = TextToken('"hello"', start=(1, 0), end=(1, 7))  # type: ignore
    validator = {
        "first": String(min_length=3),
        "second": String(max_length=3),
    }
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.code == "too_short"
        assert message.text == 'String value is too short.'
        assert message.start_position.line_index == 1
        assert message.start

# Generated at 2022-06-22 06:11:40.880861
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class AddressSchema(Schema):
        street = String(required=True)
        city = String()
        state = String()

    value = {"street": "", "city": "Brooklyn", "state": "CA"}
    token = Token(value=value)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=AddressSchema)
    messages = exc_info.value.messages()
    print(messages)

    message = messages[0]
    assert message.index == ["street"]
    assert message.code == "required"
    assert message.char_index == 2

    message = messages[1]

# Generated at 2022-06-22 06:11:42.626872
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

# Generated at 2022-06-22 06:11:53.155244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token(
            value={"a": 1},
            start=TokenPosition(line_index=1, char_index=0, filename=None),
            end=TokenPosition(line_index=1, char_index=11, filename=None),
        ),
        validator=Field(type="integer" | "string", required=True),
    ) == {"a": 1}

# Generated at 2022-06-22 06:12:04.212354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parser import parse

    validator = Schema({"value": String(min_length=1)})

    tokens = lex("{'a': 'foo', 'b': 'bar'}")

# Generated at 2022-06-22 06:12:14.933555
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lexer

    lex = lexer.Lexer()
    validator = Field(type="string")
    tokens = lex("""
        {
            "hello": null,
            "world": 42
        }
    """)

    try:
        validate_with_positions(token=tokens[0], validator=validator)
    except ValidationError as error:
        messages = error.messages()
        assert messages[0].text == "The field 'hello' is required."
        assert messages[0].start_position.line == 2
        assert messages[0].start_position.char_index == 18
        assert messages[0].end_position.line == 2
        assert messages[0].end_position.char_index == 23


# Generated at 2022-06-22 06:12:24.322810
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem.schemas import Object
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import Token

    class PersonSchema(Object):
        name = String()
        age = Integer()

    class MovieSchema(Object):
        title = String()
        actors = PersonSchema(many=True)
        director = PersonSchema()

    json_str = '{"title": "Home Alone", "actors": [{"name": "Macaulay Culkin"}]}'
    tokens = tokenize(json_str)
    movie_token = tokens


# Generated at 2022-06-22 06:12:36.845123
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .test_tokenize import tokenize

    from typesystem.fields import Integer

    field = Integer()

    token = tokenize("""
        {
            "foo": [1, "foo"],
            "bar": "bar",
            "baz": {
                "qux": 42,
                "quux": 12.34
            }
        }
    """, source="source.json")

    error = None
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as exc:
        error = exc

    assert error is not None

    message = error.messages()[0]

    assert message.index == ["foo"]
    assert message.start_position == (1, 8)
    assert message.end_position == (1, 11)
    assert message.text

# Generated at 2022-06-22 06:12:45.499269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Compound, Integer, String

    from .lexer import lexer

    from .positions import TextPosition

    class Address(Compound):
        city = String(required=True)
        state = String(required=True)
        zip_code = String()

    class UserSchema(Schema):
        name = String(required=True)
        age = Integer()
        address = Address(required=True)


# Generated at 2022-06-22 06:13:03.501354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import FieldToken, ObjectToken

    input_ = ObjectToken(
        {
            "name": FieldToken(value="Zalando SE", start=(1, 0), end=(1, 11))
        },
        start=(0, 0),
        end=(2, 0),
    )

    schema = Schema(fields={"name": String(required=True)})

    validate_with_positions(token=input_, validator=schema)



# Generated at 2022-06-22 06:13:13.501283
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer, Field
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.parser import parse_path
    import json

    json_data = json.loads(
        """
        {
            "name": "test",
            "items": [
                {"id": 1},
                {"id": "not an integer"}
            ]
        }
    """
    )

    root_token = Token(value=json_data, start=None, end=None)
    items_token = root_token.lookup(parse_path("items"))
    assert items_token.value == json_data["items"]
    item_tokens = items_token.tokens()

# Generated at 2022-06-22 06:13:24.809203
# Unit test for function validate_with_positions
def test_validate_with_positions():  # type: ignore
    from collections import OrderedDict
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(min_length=4)
        age = Integer()

    input = OrderedDict([("name", "Tim"), ("age", "twenty-one")])

    try:
        UserSchema.validate(input)
        assert False
    except ValidationError as error:
        messages = list(error.messages())
        assert messages[0].text == 'Invalid literal for int() with base 10: "twenty-one"'
        assert messages[0].start_position == (1, 7)
        assert messages[0].end_position == (1, 17)

# Generated at 2022-06-22 06:13:35.892314
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .schema import User
    from .tokenize import tokenize

    user = User(name="Joe", age="25")
    tokens = tokenize(user)
    validate_with_positions(token=tokens[0], validator=User)

    user.age = "28"
    user.name = ""
    tokens = tokenize(user)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens[0], validator=User)

    messages = error.value.messages()
    assert messages[0].text == "The field 'name' is required."
    assert messages[0].start_position == (1, 1)
    assert messages[0].end_position == (1, 2)

# Generated at 2022-06-22 06:13:47.495163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.schemas import Schema
    import typesystem.tokenize.tokenize

    class TestSchema(Schema):

        class Meta:
            strict = True

        foo = Field(required=True)
        bar = Field(required=True)
        baz = Field(required=True)
        qux = Field(required=True)

    stream = json.dumps(
        {
            "foo": "Hello",
            "bar": "World",
            "baz": "Hello World",
        }
    )
    tokens = list(typesystem.tokenize.tokenize.tokenize(stream))

    try:
        validate_with_positions(token=tokens[0], validator=TestSchema)
    except ValidationError as error:
        messages = error.messages()


# Generated at 2022-06-22 06:13:59.490911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    class SimpleSchema(Schema):
        name = String()
        address = String(required=True)

    token = tokenize({"name": "Jane"}, "simple.json")
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=SimpleSchema())
    messages = excinfo.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'address' is required."
    assert message.code == "required"
    assert message.index == ("address",)
    # The token is a FileToken, which means that the start and end positions are
    # based on a file.

# Generated at 2022-06-22 06:14:10.100916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, Token
    from typesystem.fields import String

    schema = {"name": String()}
    validator = Schema(schema)

    source = "{\n  'name': 'Alice'\n}\n"
    tokens = tokenize(source)
    token = Token(value={}, parent=None, path=[], tokens=tokens)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=validator)
    assert exc.value.messages()[0].start_position.line == 2
    assert exc.value.messages()[0].start_position.char_index == 4
    assert exc.value.messages()[0].end_position.line == 2
    assert exc.value.messages()

# Generated at 2022-06-22 06:14:21.798251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.tokenize.tokens import Token, StringToken, ObjectToken, RootToken
    from typesystem.fields import BooleanField

    root = RootToken(value=b"", path="", start=0, end=0)
    token = ObjectToken(
        name="object",
        value={},
        path="",
        start=0,
        end=0,
        parent=root,
        items=[],
        keys=["object"],
    )
    string_token = StringToken(value="", path="object", start=0, end=0, parent=token)

    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=string_token, validator=BooleanField(required=True))


# Generated at 2022-06-22 06:14:33.021806
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    start = Token(TokenType.start, "{\n")
    value = Token(TokenType.value, '"name"')
    colon = Token(TokenType.colon, ":")
    string = Token(TokenType.string, '"John"')
    end = Token(TokenType.end, "}\n")

    value.add_child(colon)
    value.add_child(string)

    start.add_child(value)
    start.add_child(end)

    schema = Schema({"name": {"type": "string"}})


# Generated at 2022-06-22 06:14:42.611028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, String, Integer
    from typesystem.tokenize.tokens import Token

    class BookSchema(Schema):
        title = String(required=True)
        page_count = Integer()

    payload = {"title": "The Road"}

    token = Token(value=payload, start=object(), end=object())

    try:
        validate_with_positions(
            token=token, validator=BookSchema()
        )
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'page_count' is required."
        assert message.start_position is not None
        assert message.end_position is not None



# Generated at 2022-06-22 06:15:05.493518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import streams
    import typesystem
    import typesystem_streams

    tokenizer = typesystem_streams.Tokenizer(
        typesystem.components.Array([typesystem.String()]),
        value=["a", "b", "c"],
    )


# Generated at 2022-06-22 06:15:14.825269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Integer

    schema = Integer()

    token = Token(
        value=42,
        start=TokenPosition(line_index=0, char_index=0, line_code="42"),
        end=TokenPosition(line_index=0, char_index=2, line_code="42"),
    )
    value = validate_with_positions(token=token, validator=schema)
    # value = 42
    assert value == 42

    token = Token(
        value="42",
        start=TokenPosition(line_index=0, char_index=0, line_code="42"),
        end=TokenPosition(line_index=0, char_index=2, line_code="42"),
    )
    with pytest.raises(ValidationError) as error:
        validate_

# Generated at 2022-06-22 06:15:25.688392
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    schema = Schema({"id": Field(required=True)})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(start={"char_index": 0, "line_number": 1}),
            validator=schema,
        )

    assert exc_info.value.messages() == [
        Message(
            text="The field 'id' is required.",
            code="required",
            index=["id"],
            start_position={"char_index": 0, "line_number": 1},
            end_position={"char_index": 0, "line_number": 1},
        )
    ]



# Generated at 2022-06-22 06:15:35.691682
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # setup
    class Order(Schema):
        customer = Field(type="string", required=True)
        items = Field(type="list", items={"type": "string", "required": True})

    token = Token(
        {
            "customer": "Michael",
            "items": ["Apple", "Banana", "Cherry", "Damson"],
            "invalid_field": "oops",
        }
    )
    # invoke
    try:
        validate_with_positions(token=token, validator=Order)
    except ValidationError as ex:
        # check
        assert len(ex.messages) == 2

# Generated at 2022-06-22 06:15:45.568606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.position import Position

    from .utils import JSONToken, JSONValidator

    from typing import Any

    class MySchema(Schema):
        name = Field(str)

    v = MySchema()

    token = JSONToken(
        index=[],
        value={
            "name": "Joe Bloggs",
        },
        start=Position(line=1, column=0, char_index=0),
        end=Position(line=1, column=16, char_index=16),
    )

    assert validate_with_positions(
        token=token, validator=v
    ) == {"name": "Joe Bloggs"}  # type: ignore


# Generated at 2022-06-22 06:15:56.819637
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import Boolean, String, Structure

    schema = Structure({"a": String, "b": Integer}, required=["a", "b"])
    token = Token({"a": "Hello", "b": "10"})
    assert validate_with_positions(token=token, validator=schema) == {"a": "Hello", "b": 10}

    token = Token({"b": "10"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)
    assert len(exc.value.messages) == 1
    assert exc.value.messages[0].text == "The field 'a' is required."
    assert exc.value.messages[0].start_position

# Generated at 2022-06-22 06:16:08.887606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import ObjectToken

    class MySchema(Schema):
        a = String(required=True)
        b = String(required=False)

    token = ObjectToken(
        tokens={
            "a": StringToken(start=Position(line=1, column=1), value="abc"),
            "b": StringToken(start=Position(line=2, column=1), value="def"),
        }
    )
    # No error, as both fields are present
    result = validate_with_positions(token=token, validator=MySchema)
    assert result == {"a": "abc", "b": "def"}

    # Error on a, as it is required
    del token["a"]
   

# Generated at 2022-06-22 06:16:19.527776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.example import json_object
    from typesystem.schema import Schema
    from unittest.mock import patch

    from typesystem.schemas import json_schema_to_spec

    json_spec = json_object("""
        {
            "type": "object",
            "properties": {
                "foo": {"type": "integer"},
                "bar": {"type": "integer"}
            },
            "required": ["foo"]
        }
    """)
    spec = json_schema_to_spec(json_spec)
    with patch("typesystem.utils.get_spec_validator") as get_spec_validator:
        get_spec_validator.return_value = Schema.from_spec(spec)


# Generated at 2022-06-22 06:16:28.761739
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import dict, str

    class MySchema(Schema):
        field1 = str()

    schema = MySchema()

    token = dict(field1="yes", field2="")

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="The field 'field2' is required.",
                code="required",
                index=("field2",),
                start_position=token.start.position(1, 1),
                end_position=token.start.position(2, 1),
            )
        ]


# Generated at 2022-06-22 06:16:40.447756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.schemas import Object
    from typesystem.fields import String, Integer

    class Car(Object):
        name = String()
        doors = Integer()

    token = Token(
        value={
            "name": "",
            "doors": 0,
            "does_not_exist": {"foo": 123},
        },
        start=(1, 0),
        end=(2, 14),
    )

    try:
        validate_with_positions(token=token, validator=Car)
    except ValidationError as error:
        assert len(error.messages()) == 3
        assert error.messages()[0].start_position == (1, 2)
        assert error.messages()[0].end_position == (1, 2)

# Generated at 2022-06-22 06:17:25.703427
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, Object

    class Address(Schema):
        street = String()
        number = String()

    class Profile(Schema):
        name = String(required=True)
        age = Integer(min_value=0, max_value=150)
        addresses = Object(fields=[("home", Address()), ("work", Address())])

    source = {"name": None, "age": -10}
    token = Token.parse(source)
    try:
        Profile().validate(source)
    except ValidationError as e:
        for message in e.messages():
            if message.index == ("name",):
                assert message.text == "Field may not be null."
                assert message.start_position.line == 1
                assert message.start_position.char_index == 6

# Generated at 2022-06-22 06:17:36.579389
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokenizers import tokenize
    from tests.tokenize.common import complex_data

    token = tokenize([complex_data])[0]
    field = Integer()

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The value must be an integer."
        assert message.code == "invalid_type"
        assert message.start_position == Position(line_number=1, char_index=9)
        assert message.end_position == Position(line_number=1, char_index=10)

# Generated at 2022-06-22 06:17:40.368223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token.parse('{"x": "hello"}'),
        validator=Schema({"x": Field(type=str)}),
    ) == {"x": "hello"}



# Generated at 2022-06-22 06:17:49.402067
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields
    from typesystem.schemas import Validator

    class TestSchema(Validator):
        name = fields.Text(max_length=10)
        price = fields.Number()

    invalid_json = """{
        "name": "foo",
        "price": 13.5,
    }"""

    try:
        TestSchema.validate(invalid_json)
    except ValidationError as error:
        for message in error.messages:
            print(message.code, message.text)
            print(message.start_position)

    print(validate_with_positions(token=Token(invalid_json), validator=TestSchema))