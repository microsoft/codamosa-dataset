

# Generated at 2022-06-22 06:07:47.616765
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, to_token

    class PersonSchema(Schema):
        name = String(required=True)
        age = String()

    field = PersonSchema.fields["name"]
    token = to_token({"name": "John Doe", "age": "42"})
    assert "field" in repr(validate_with_positions(token=token, validator=field))

    schema = PersonSchema()
    token = to_token({"name": "John Doe", "age": "forty-two"})
    assert "schema" in repr(validate_with_positions(token=token, validator=schema))


# Generated at 2022-06-22 06:07:56.677372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    token = tokenize("{'foo': {'bar': 'baz'}}")[0]
    schema = Schema({"foo": {"bar": Field(name="bar", type="string")}})

    assert validate_with_positions(token=token, validator=schema) == {
        "foo": {"bar": "baz"}
    }


# Generated at 2022-06-22 06:08:07.275039
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Array
    from typesystem.tokenize.tokens import Boolean
    from typesystem.tokenize.tokens import Integer
    from typesystem.tokenize.tokens import Null
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokens import String

    assert validate_with_positions(
        token=Boolean(is_value=True),
        validator=Boolean,
    ) is True

    try:
        validate_with_positions(
            token=Boolean(is_value=True),
            validator=Integer,
        )
    except ValidationError as error:
        assert error.messages()[0].text == (
            "Value must be an integer."
        )

# Generated at 2022-06-22 06:08:15.341657
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Ref, String
    from typesystem.tokenize.parser import parse

    schema = Ref("MySchema")
    schema = schema.bind({"MySchema": String(name="foo")})
    token = parse("{")

# Generated at 2022-06-22 06:08:26.197164
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import JSONTokenReader
    from typesystem.tokenize.positions import Position

    def test(json_str: str):
        try:
            JSONTokenReader.read(json_str)
        except ValidationError as error:
            json_lines = json_str.replace("\r", "").split("\n")
            for message in error.messages():
                line_number = message.start_position.line_number
                char_index = message.start_position.char_index
                line = json_lines[line_number - 1]
                line = f"{line[:char_index]}^---> {line[char_index:]}"
                line = f"{line_number}: {line}"
                print(line)

   

# Generated at 2022-06-22 06:08:34.957912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Document

    field = String(required=True)
    document = Document("", {"my_field": "abc"})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=document, validator=field)
    assert exc_info.value.messages == [
        Message(
            text="The field 'my_field' is required.",
            code="required",
            index=("my_field",),
            start_position=document.start,
            end_position=document.end,
        )
    ]

# Generated at 2022-06-22 06:08:45.813725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem import types
    from typesystem.tokenize.tokens import DictionaryToken

    validator = types.Schema({"name": types.String(max_length=3)})

    input_token = DictionaryToken(
        start=(1, 0),
        end=(1, 12),
        value={
            "name": "foobarbaz",
        },
        schema=[
            ("name", (1, 2), (1, 9), types.String),
        ],
    )

    try:
        validate_with_positions(token=input_token, validator=validator)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]

        assert message.start_position == (1, 2)
       

# Generated at 2022-06-22 06:08:56.894293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Dict, Integer
    from typesystem.tokenize.tokenizers import JSONTokenizer

    schema = Dict(
        fields={
            "people": Array(items=Dict(fields={"name": Integer()}), min_items=1)
        }
    )
    text = '{"people": [{"name": "23"}, {"name": "33"}]}'
    tokenizer = JSONTokenizer(text)
    token = tokenizer.tokenize()

# Generated at 2022-06-22 06:09:04.162217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.tokenize.parser import parse_json
    from typesystem.tokenize.tokens import ArrayToken

    schema = {"type": "object", "properties": {"name": {"type": "string"}}}
    object_schema = Schema(schema)
    token = parse_json('{ "name": "bob" }')
    assert validate_with_positions(token=token, validator=object_schema) == {
        "name": "bob"
    }

    schema = {"type": "array", "items": {"type": "string"}}
    array_schema = Schema(schema)
    token = parse_json('["bob", "alice"]')

# Generated at 2022-06-22 06:09:12.841974
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text = '{"name": "John", "age": 30}'
    token = Token.from_object({"name": "John", "age": 30})
    validator = Schema(
        {"name": Field(str), "age": Field(int)}
    )
    assert validate_with_positions(token=token, validator=validator) == {}

    text = '{"name": "John"}'
    token = Token.from_object({"name": "John"})
    assert validate_with_positions(token=token, validator=validator) == {
        "age": "required"
    }

    text = '{"name": "John", "age": "thirty"}'
    token = Token.from_object({"name": "John", "age": "thirty"})
    validation_error = Validation

# Generated at 2022-06-22 06:09:22.047537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.data.schemas import PersonSchema
    from tests.data.data import Person

    person_json = '{"name": "Paul", "age": "1234.56"}'
    from typesystem.tokenize import tokenize

    token = tokenize(person_json)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=PersonSchema)



# Generated at 2022-06-22 06:09:32.936615
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Object, List, Str, FieldToken
    # from apischema.tokenize import tokenize
    # from apischema.tokenize.tokens import Object, Str, FieldToken
    invalid_token = tokenize({"a": ["b"]})
    token = tokenize({"a": {"b": "c"}})
    try:
        validate_with_positions(token=invalid_token, validator=Object({"a": List(Str())}))
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-22 06:09:45.368413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.validators import string, number
    from typesystem.tokenize.tokens import String, Number

    token = String(index=[0], value="abc123", start=None, end=None)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=number)
    error = excinfo.value
    assert len(error.messages) == 1
    message = error.messages[0]
    assert message.text == f"The value 'abc123' must be a number."
    assert message.start_position is None
    assert message.end_position is None


# Generated at 2022-06-22 06:09:52.575154
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test that validate_with_positions adds positions to ValidationErrors"""
    from typesystem.schemas import JSONSchema
    from typesystem.tokenize.parser import parse_token_stream

    schema = JSONSchema({"type": "integer", "required": True})

    document = parse_token_stream(
        """
        {
            "a": 1,
            "b": 2
        }
    """
    )

    token = document.lookup(["a"])

    assert validate_with_positions(token=token, validator=schema) == 1

    token = document.lookup(["c"])
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert isinstance(error, ValidationError)

# Generated at 2022-06-22 06:10:05.741358
# Unit test for function validate_with_positions
def test_validate_with_positions():
    index: typing.Dict[str, typing.Any] = {
        "f1": "field1",
        "f2": "field2",
        "f3": "field3",
    }

    class TestSchema(Schema):
        f1 = Field(type="string", required=True)
        f2 = Field(type="string", required=False)
        f3 = Field(type="number", required=True)

    token = Token(
        value=index,
        start=Message(line=1, char_index=1, value=""),
        end=Message(line=1, char_index=20, value=""),
    )

# Generated at 2022-06-22 06:10:06.759384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:10:17.100853
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token, TokenType

    class Person(typesystem.Schema):
        name = typesystem.String(max_length=100)
        age = typesystem.Integer()

    tokens = list(tokenize({"name": "Jason", "age": "100"}))
    assert validate_with_positions(token=tokens[1], validator=Person) == {
        "name": "Jason",
        "age": 100,
    }

    tokens = list(tokenize({"name": "Jason", "age": "one-hundred"}))
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=tokens[1], validator=Person)

# Generated at 2022-06-22 06:10:27.986310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_value, parse_schema, tokens

    source = '{"a": {"b": "B"}}'
    token = parse_value(source)
    validator = parse_schema(
        {
            "a": {"type": "object", "properties": {"b": {"type": "string"}}},
            "c": {"type": "string"},
        }
    )

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"
        assert message.start_position.char_index == 4
        assert message.end_position.char_index == 4
        assert message.text

# Generated at 2022-06-22 06:10:32.712207
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import StringToken
    from typesystem import String, Integer

    schema = String(max_length=5)
    token = StringToken(
        value="abcdef",
        start=(0, 0, 0),
        end=(0, 0, 5),
        lookup=lambda path: StringToken(
            value=path[-1], start=(0, 0, 0), end=(0, 0, 5), lookup=lambda path: token
        ),
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert [message.text for message in error.messages()] == [
            "String value is too long. Maximum length is 5."
        ]
        assert [message.code for message in error.messages()]

# Generated at 2022-06-22 06:10:43.695797
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import string

    from typesystem.fields import CharField
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        name = CharField(min_length=3, max_length=7)

    token = Token(value={"name": "a"}, position=None)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=TestSchema)
    assert exc.value.messages() == [
        Message(
            text="Ensure this field has at least 3 characters.",
            code="min_length",
            index=("name",),
            start_position=(1, 0),
            end_position=(2, 0),
        )
    ]


# Generated at 2022-06-22 06:11:00.064263
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.base import ValidationError
    from typesystem.tokenize.parse import parse_with_positions
    from typesystem.tokenize.parse import Position
    source = """
    person:
    name: "John"
    age: 30
    """
    tokens = parse_with_positions(source=source)
    assert isinstance(tokens, Token)

    class PersonSchema(Schema):
        name = String()
        age = String()

    with pytest.raises(ValidationError) as error:
        validate_with_positions(validator=PersonSchema(), token=tokens)


# Generated at 2022-06-22 06:11:12.085763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Struct

    class NameSchema(Struct):
        first_name = Field(type="string")
        last_name = Field(type="string")

    class EmployeeSchema(Struct):
        name = Field(type=NameSchema())
        salary = Field(type="number")

    token = Token(
        type_name="struct",
        value={
            "name": {
                "first_name": "John",
                "last_name": "Smith",
            },
            "salary": 3000,
        },
        start={
            "char_index": 0,
            "line_number": 1,
            "column": 1,
        },
        end={
            "char_index": 36,
            "line_number": 3,
            "column": 16,
        },
    )

# Generated at 2022-06-22 06:11:23.237559
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    validate_with_positions(token: Token, validator: Union[Field, Type[Schema]]) -> Any
    """

    from typesystem.fields import String

    from typesystem.validators import min_length, required

    from typesystem.tokenize.search import tokenize

    from .encode import encode

    from .decode import decode

    schema = Schema({"name": String(validators=[required(), min_length(3)])})

    def parse(string: str) -> str:
        return decode(encode(tokenize(string)))

    try:
        parse('{"name": "B"}')
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 13

# Generated at 2022-06-22 06:11:31.250877
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Test function validate_with_positions
    """
    from typesystem.schemas import Schema, Structure

    class Person(Structure):
        first_name = Field(type="string")
        last_name = Field(type="string")

    token = Token(value={})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person())

    assert exc_info.value.messages()[0].text == "The field 'first_name' is required."
    assert exc_info.value.messages()[0].start_position.offset == 42
    assert exc_info.value.messages()[0].end_position.offset == 51


# Generated at 2022-06-22 06:11:37.278704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token

    token_list = [
        Token(value={"a": 1}, start=0, end=1),
        Token(value="foo", start=1, end=2),
        Token(value="bar", start=2, end=3),
    ]

    class FooSchema(Schema):
        a = Field(str)
        b = Field(str)
        c = Field(str)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token_list[0], validator=FooSchema)

# Generated at 2022-06-22 06:11:47.890800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises

    from typesystem.tokenize.tokens import ObjectToken, ObjectFieldToken

    field = Field(type="string")
    object_token = ObjectToken(
        "window",
        ObjectFieldToken("foo", "bar", 1, 3),
        ObjectFieldToken("baz", None, 9, 17),
        ObjectFieldToken("quux", [], 17, 25),
    )
    with raises(ValidationError) as excinfo:
        validate_with_positions(token=object_token, validator=field)
    messages = excinfo.value.messages
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'baz' is required."
    assert message.code == "required"
    assert message.index == ("baz",)


# Generated at 2022-06-22 06:11:57.874820
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Array, Object, String

    from .test_tokenize import tokenize_string

    body = """
    {
        "a": true,
        "b": false,
        "c": [
            true,
            false,
        ],
        "d": null
    }
    """
    token = tokenize_string(body)

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(
            token=token,
            validator=Object({"a": String, "b": String, "c": Array(String)}),
        )

    messages = error_info.value.messages()

# Generated at 2022-06-22 06:12:09.039393
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:12:14.251414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Integer
    from typesystem.tokenize.tokens import IntegerToken

    token = IntegerToken(start=(1, 2), end=(1, 4), value=5)
    assert validate_with_positions(token=token, validator=Integer()) == 5



# Generated at 2022-06-22 06:12:24.080009
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        first_name = Field(required=True)
        last_name = Field(required=True)

    data = {
        "first_name": "Joe",
        "last_name": "Schmoe",
    }
    data = Token(data)
    validate_with_positions(token=data, validator=PersonSchema)

    data = {
        "first_name": 123,
        "last_name": "Schmoe",
    }
    data = Token(data)
    try:
        validate_with_positions(token=data, validator=PersonSchema)
        assert False, "Expected an error"
    except ValidationError as error:
        message = error.messages()[0]
        assert message.code == "type"

# Generated at 2022-06-22 06:12:47.087713
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import validate_with_positions
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    schema = Schema(fields={"foo": Integer(required=True)})
    token = Token(value={"foo": "hello"})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)

    assert excinfo.value.messages == [
        Message(
            text="The field 'foo' is required.",
            code="required",
            index=["foo"],
            start_position=token.start,
            end_position=token.end,
        )
    ]
    assert excinfo.value.messages[0].start_position == token.start

# Generated at 2022-06-22 06:12:57.355631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field.text(name="test")
    result = validate_with_positions(
        token=Token("text", 0, 3), validator=field
    )
    assert result == "test"

    token = Token.from_json({
        "type": "object",
        "start": {"line": 1, "column": 2},
        "end": {"line": 1, "column": 9},
        "children": [
            {"type": "key", "value": "test", "start": {"line": 1, "column": 2}, "end": {"line": 1, "column": 6}},
            {"type": "value", "value": "test", "start": {"line": 1, "column": 7}, "end": {"line": 1, "column": 9}},
        ],
    })
    result = validate_with_

# Generated at 2022-06-22 06:13:09.641587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import PythonTokenizer
    tokenizer = PythonTokenizer()

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    # Create a token.
    source = '{"name": "Dave", "age": "forty"}'
    root_token = tokenizer.tokenize(source)

    # Use the token to run validation.
    try:
        validate_with_positions(token=root_token, validator=Person)
    except ValidationError as error:
        messages = sorted(error.messages(), key=lambda m: m.start_position.line)

        assert messages[0].text == (
            "The field 'age' is of the wrong type. Expected integer, found string."
        )

# Generated at 2022-06-22 06:13:18.699443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.encoders import JSON
    from typesystem import ValidationError
    from typesystem.tokenize.tests.test_base import TestToken
    from typesystem.schemas import Schema
    import datetime
    import typing

    class User(Schema):
        name = Field(type=str, required=True)
        date_joined = Field(type=datetime.date, required=True)
        roles = Field(type=typing.List[str], required=True)

    user_values = {
        "name": "bob",
        "date_joined": datetime.date(2020, 1, 1),
        "roles": ["admin"],
    }
    token = TestToken(value=user_values)
    result = validate_with_positions(validator=User, token=token)

# Generated at 2022-06-22 06:13:24.094595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Line, Position
    from typesystem.tokenize.tokens import StringToken

    class Data(Schema):
        string = Field(type="string")

    token = StringToken(value="foo", start=Position(line=Line(), char_index=0))
    validate_with_positions(token=token, validator=Data)
    assert True

# Generated at 2022-06-22 06:13:31.512132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer(
        {
            "name": "Test",
            "properties": {"a": {"type": "string"}, "b": {"type": "string"}},
        }
    )
    schema = tokenizer.tokenize().schema()

    token = Token.from_dict({"a": "foo"})
    messages = validate_with_positions(token=token, validator=schema).messages
    assert messages[0].code == "required"
    assert messages[0].start_position.line == 0
    assert messages[0].start_position.char_index == 3

    token = Token.from_dict({"a": "foo", "b": "bar"})
    value = validate_with_positions(token=token, validator=schema).value

# Generated at 2022-06-22 06:13:41.820225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Validate a token and convert error messages to have positional information."""
    from typesystem.tokenize.lexer import lex  # type: ignore

    schema = Schema(name="MySchema", fields=[Field(name="id", type="string")])
    tokens = lex(document="{}")

    class MySchema(Schema):
        id = Field(type="string")

    assert isinstance(schema, typing.Type)
    assert isinstance(tokens, typing.List[Token])

    for token in tokens:
        validate_with_positions(token=token, validator=schema)
        validate_with_positions(token=token, validator=MySchema)


# Generated at 2022-06-22 06:13:49.334994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.marshmallow import MarshmallowSchema
    from typesystem.tokenize.schema import JSONSchema, schema
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Array, Integer, Object, String

    body = {
        "items": [
            {"name": "bob", "age": "30"},
            {"name": "joe", "age": "eight"},
            {"name": "mary"},
        ]
    }
    tokens = tokenize(schema=schema, body=body)
    assert isinstance(tokens, Object)
    items = tokens["items"]
    assert isinstance(items, Array)
    assert len(items) == 3

    class Item(MarshmallowSchema):
        name = String(required=True)

# Generated at 2022-06-22 06:13:56.404698
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """The function should return the output of an object's validate function
    if no errors are thrown.
    """
    field = Field(type="integer")
    token = Token(
        type="integer",
        value=123,
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 3},
    )
    assert validate_with_positions(token=token, validator=field) == 123


# Generated at 2022-06-22 06:14:09.307841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Datetime, Integer

    # Setup
    schema = Schema((("date", Datetime()), ("count", Integer(min_value=0))))
    token = Token(
        "datetime", value={}, start="<>", end="<>", lookup=dict, children=()
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-22 06:14:49.050100
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class P(Schema):
        pass

    class D(Schema):
        pass

    class C(Schema):
        p = P()
        d = D()

    # failing validation
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=tokenize({"p": {"d": 123, "x": True}, "d": {"x": False}}),
            validator=C(),
        )
    assert [m.text for m in error.value.messages()] == [
        "The field 'p' is required.",
        "The field 'x' is required.",
    ]
    assert [m.code for m in error.value.messages()] == ["required", "required"]

# Generated at 2022-06-22 06:14:58.488113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field(string="test", required=True)
    token = Token(
        start=Position(char_index=1, line=1, column=2),
        end=Position(char_index=5, line=1, column=6),
        value=None,
        tokens=[],
    )
    with pytest.raises(ValidationError) as error:
        validate_with_positions(validator=validator, token=token)
    message = error.value.messages[0]
    assert message.code == "required"
    assert message.start_position == token.start
    assert message.end_position == token.end

# Generated at 2022-06-22 06:15:08.806386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    class Person(Schema):
        first_name = String()

    text = b'{"first_name": ""}'

    token = tokenize(text)
    validator = Person()
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.index == ["first_name"]
        assert message.code == "required"
        assert message.text == "The field 'first_name' is required."
        assert message.start_position == (1, 13)
        assert message.end_position == (1, 25)

# Generated at 2022-06-22 06:15:20.511684
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem import types, fields

    with pytest.raises(ValidationError) as excinfo:

        class Person(types.Schema):
            name = fields.String(min_length=8)

        validate_with_positions(
            token=Token(value={"name": "Alice"}, start={}, end={}),
            validator=Person,
        )

    messages = excinfo.value.messages()
    assert messages[0].text == "The field 'name' is required."
    assert messages[0].start_position == {}

    with pytest.raises(ValidationError) as excinfo:

        class Person(types.Schema):
            name = fields.String(min_length=8)


# Generated at 2022-06-22 06:15:30.444136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ArrayToken
    from typesystem.tokenize.tokens import BoolToken
    from typesystem.tokenize.tokens import DictToken
    from typesystem.tokenize.tokens import IntegerToken
    from typesystem.tokenize.tokens import NullToken
    from typesystem.tokenize.tokens import NumberToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.tokens import UnionToken
    from typesystem import Integer
    from typesystem.compat import text_type
    from typesystem.exceptions import ValidationError


# Generated at 2022-06-22 06:15:37.487403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.tokenize.base import tokenize
    from typesystem.tokenize.parser import parse
    from typesystem.schemas import Schema

    class ExampleSchema(Schema):
        name = Field(str, required=True)
        age = Field(str, required=True)

    class ExampleSchemaWithTokenize(Schema):
        example = Field(ExampleSchema, required=True)

    schema = ExampleSchema()
    tokens = parse(tokenize('{"name": "foo"}'))
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=schema)
    message = excinfo.value.messages[0]
    assert message.text == "The field 'age' is required."

# Generated at 2022-06-22 06:15:48.627478
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from typesystem.tokenize import lex

    class TestSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int)
        evil = Field(type=int)

    text = '{"name":"John","age":100,"foo":None,"evil":-1}'
    tokens = lex(text, "json")
    try:
        validate_with_positions(token=tokens, validator=TestSchema)
    except ValidationError as error:
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.char_index  # type: ignore
        )

# Generated at 2022-06-22 06:16:00.287220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parsers import parse_token
    from typesystem.fields import String

    token = parse_token("""{"name": ""}""")
    schema = Schema({"name": String(required=True)})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line == 1
        assert message.start_position.char_index == 8
        assert message.end_position.line == 1
        assert message.end_position.char_index == 14
        assert message.text == "The field 'name' is required."
        assert message.code == "required"

# Generated at 2022-06-22 06:16:11.739400
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .utils import Language

    language = Language.from_source(
        field1="""\
some_number = 1
other_number = 2
"""
    )

    field = language.build_field("some_number")
    assert field.validate(1) == 1

    with pytest.raises(ValidationError) as exc_info:
        field.validate(2)
    assert exc_info.value.messages()[0].code == "invalid"

    token = language.lookup("some_number")
    assert token is token.lookup("some_number")
    assert validate_with_positions(token=token, validator=field) == 1

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-22 06:16:24.001509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json_content

    tokens = tokenize_json_content(b'{"foo": null}')

    class TestSchema(Schema):
        foo = Field(required=True)

    assert validate_with_positions(token=tokens[0], validator=TestSchema) == {
        "foo": None
    }

    class TestField(Field):
        def validate(self, value):
            super(TestField, self).validate(value)
            if value != "foo":
                raise ValidationError("Must be foo")

    assert tokens[0].start == (1, 0)
    assert tokens[0].end == (1, 15)
    assert tokens[1].start == (1, 7)
    assert tokens[1].end == (1, 11)


# Generated at 2022-06-22 06:17:39.666614
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import fields

    class MyStruct(fields.Message):
        field1 = fields.Int()

    class MyRoot(fields.Message):
        field1 = MyStruct()
        field2 = fields.String()

    root = MyRoot()

    token = Token(
        key="root",
        start=Token.Position(line_index=1, char_index=2),
        end=Token.Position(line_index=20, char_index=3),
        value={
            "field1": {"field1": "x"},
            "field2": "y",
        },
    )

    try:
        validate_with_positions(token=token, validator=root)
    except ValidationError as error:
        messages = error.messages()

    assert messages[0].start_position.char_index == 7