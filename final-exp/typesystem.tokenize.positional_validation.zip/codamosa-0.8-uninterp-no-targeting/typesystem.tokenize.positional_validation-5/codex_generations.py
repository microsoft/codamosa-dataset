

# Generated at 2022-06-22 06:08:11.080581
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Boolean
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    assert validate_with_positions(
        token=Token("", start=5, end=5), validator=String()
    ) == ""

    try:
        validate_with_positions(token=Token("", start=5, end=5), validator=Boolean())
    except ValueError as e:
        assert str(e) == "The boolean value of '' is not true or false."
    else:
        assert False, "Expected a ValueError"


# Generated at 2022-06-22 06:08:17.575310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.examples import JSON as JSON_TOKENIZER
    from typesystem.tokenize import Token
    from typesystem.fields import String

    to_validate = """{"name": "", "hello": 1.0}"""
    tokenizer = JSON_TOKENIZER()
    token = Token.parse(tokenizer.tokenize(to_validate))
    error = pytest.raises(ValidationError, validate_with_positions, validator=String, token=token)

    error.match(
        "The following error occurred at line 1, char 23:\n"
        "The value must not be blank."
    )

# Generated at 2022-06-22 06:08:27.441790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import tokenize
    from pprint import pprint

    try:
        validate_with_positions(token=tokenize('invalid'), validator=String())
    except ValidationError as e:
        assert len(e.messages) == 2
        assert e.messages[0].text == "The field 'str' is required."
        assert e.messages[1].text == "'None' is not a valid string."
        assert e.messages[0].start_position.line == 1
        assert e.messages[0].start_position.column == 1
        assert e.messages[0].start_position.char_index == 0
        assert e.messages[1].start_position.line == 1
        assert e.messages[1].start_position.column

# Generated at 2022-06-22 06:08:35.835201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize(
        {
            "foo": [
                {"bar": {"baz": 1}},
                {"bar": {"baz": 2}},
                {"bar": {"baz": 3}},
            ]
        }
    )
    foo_field = Field(type="object", name="foo", required=True)
    bar_field = Field(type="object", name="bar", required=True)
    baz_field = Field(type="integer", name="baz", required=True)

    foo_field.children = [bar_field]
    bar_field.children = [baz_field]

    foo_field.validate(token.value)


# Generated at 2022-06-22 06:08:41.560913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        name = Field(str, required=True)
        age = Field(int)

    text = '{"name": "Pete", "age": 100}'
    token = tokenize(text)

    validated_token = validate_with_positions(validator=PersonSchema, token=token)

    assert validated_token is not None

# Generated at 2022-06-22 06:08:49.616435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema

    class Code(Schema):
        code = Field(required=True)
        options = Field(type=tuple, required=True)

    class Contact(Schema):
        name = Field(required=True)
        age = Field(type=int)

    class Person(Schema):
        name = Field(required=True)
        age = Field(type=int)
        contact = Field(type=Contact, required=True)
        codes = Field(type=list, required=False)


# Generated at 2022-06-22 06:09:00.932575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pytest import raises
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import File
    from typesystem.schemas import Structure
    from typesystem.exceptions import ValidationError

    class MySchema(Structure):
        a = Integer()
        b = Integer()

    file = File(
        contents="""{"a": true, "b": 1}""",
        uri="tests/fixtures/files/example.json",
        encoding="utf-8",
        parse_comments=False,
    )
    with raises(ValidationError) as error:
        validate_with_positions(token=file, validator=MySchema)

    assert len(error.value.messages) == 1
    message = error.value.messages[0]

# Generated at 2022-06-22 06:09:11.520425
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        title = Field(required=True)

    value = {"title": "my title"}
    token = Token(
        name="root",
        value=value,
        start={
            "line_number": 1,
            "column_number": 1,
            "char_index": 0,
        },
        end={
            "line_number": 2,
            "column_number": 1,
            "char_index": len(json.dumps(value)) + 1,
        },
    )
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].text == "The field 'title' is required."

# Generated at 2022-06-22 06:09:21.946462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    class UserSchema(Object):
        name = Field(str)
        age = Field(int)

    value = {
        "name": "Alice",
        "age": "I'm not a number"
    }
    tokens = {'name': {'type': 'string', 'value': 'Alice', 'start': 0, 'end': 5}, 'age': {'type': 'string', 'value': "I'm not a number", 'start': 10, 'end': 25}}
    assert validate_with_positions(token=tokens['name'], validator=UserSchema.fields['name']) == value['name']

# Generated at 2022-06-22 06:09:32.833636
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # NOTE: the test suite is not great because it is sensitive to the structure of the error messages
    # generated in typesystem and tokens. I however don't expect these messages to change dramatically
    # in the future as they are mostly used as referents to identify a field in the data structure.
    # If they are changed, the tests also need to be changed, but only the assertion.
    # The implementation of validate_with_positions can be anything as long as it returns a value
    # that is checked by assertEqual.
    token = Token({"a": 0, "b": {"c": ["a", "b", "c"]}})
    field = Field(required=True, type=str)


# Generated at 2022-06-22 06:09:46.649868
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Array, Choice
    from typesystem.schemas import Object
    from typesystem.tokenize import tokenize

    class Person(Object):
        name = Choice(fields=[Array()])

    person = Person()

    tokens = tokenize("[a, b, c]")
    value, errors = validate_with_positions(
        token=tokens[0], validator=person.validate
    )

    assert errors == []
    assert value == {"name": ["a", "b", "c"]}

    tokens = tokenize("[a, b, c")
    with pytest.raises(ValidationError):
        validate_with_positions(token=tokens[0], validator=person.validate)

# Generated at 2022-06-22 06:09:56.427706
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer

    schema = Schema(
        {
            "text": Field(),
            "choices": Field(type="list"),
            "count": Field(type="integer", minimum=0, maximum=5),
        }
    )

    text = "{'text': 'foo', 'choices': ['one', 'two', 'three'], 'count': 6}"
    tokens = JSONTokenizer.tokenize(string=text, path="path/to/file.json")

    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=tokens, validator=schema)

# Generated at 2022-06-22 06:10:07.512429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.core import load_from_string

    from typesystem import fields

    from typesystem.schemas import Schema

    root = load_from_string("""
        people:
          - name: Brian
            age: 40
          - name: Bob
            age: 30
          - name: [1, 2, '3']
            age: 20
      """)

    class PersonSchema(Schema):
        name = fields.String()
        age = fields.Integer()

    validation_errors = []
    try:
        validate_with_positions(token=root, validator=PersonSchema())
    except ValidationError as error:
        validation_errors = error.messages

    assert validation_errors[0].text == "The field 'name' is required."
    assert validation_errors[0].start

# Generated at 2022-06-22 06:10:16.737603
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.schemas import ExampleSchema
    import typesystem
    import typesystem.tokenize as tokenize

    tokens = tokenize.Tokenizer(
        schema=ExampleSchema(),
        text="""
        {
            "title": "An example",
            "description": "A longer description",
            "items": [
                {
                    "title": "A nested item"
                },
                {
                    "title": "A second nested item"
                }
            ],
            "nested": {
                "id": "xyz",
                "nest": {
                    "title": "A nested value",
                    "count": 1
                }
            }
        }
        """,
    ).tokenize()


# Generated at 2022-06-22 06:10:26.207307
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class MySchema(Schema):
        name = Field(str, required=True)
        age = Field(int)

    token = tokenize({"age": "10"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)
    exc = exc_info.value
    assert len(exc.messages) == 1
    message = exc.messages[0]
    assert message.text == "The field 'name' is required."

# Generated at 2022-06-22 06:10:35.857034
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import lex

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = lex("{name: 'Joe', age: 23}")
    joe = validate_with_positions(token=token, validator=Person)
    assert isinstance(joe, dict)

    token = lex("{name: 'Joe'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    message = exc_info.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'age' is required."
    assert message.start_position.line == 1
    assert message.start_

# Generated at 2022-06-22 06:10:45.235397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize.scanner import scan
    from typesystem.tokenize.tokens import ValueToken

    text = """
    {
        "title": "hello"
    }
    """
    tokens = scan(text=text)
    tokens = [v for v in tokens if isinstance(v, ValueToken)][0]

    schema = Schema(
        {"title": Field(required=True, type="string")},
        error_serializer=lambda e: e.format(pretty=True),
    )


# Generated at 2022-06-22 06:10:56.032674
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import lex
    from typesystem.schemas import String, Integer

    from tests.tokenize import assert_lex, assert_lex_and_parse

    content = """
    key1: "value 1"
    key2:
        a_string: "some string"
        an_int: 12
    """

    def sample_schema(name: str) -> Schema:
        def sample_validator(value: typing.Any) -> typing.Any:
            raise ValidationError([Message(text="Some error")])

        class SampleSchema(Schema):
            key1 = String()
            key2 = sample_validator

        return SampleSchema(name=name)


# Generated at 2022-06-22 06:11:05.997819
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import WhitespaceTokenizer

    class UserSchema(Schema):
        name = Field(required=True)

    validator = WhitespaceTokenizer(schema=UserSchema)
    token = validator.validate("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator.schema)
    assert exc_info.value.messages() == [
        Message(
            code="required",
            index=(0,),
            text="The field 'name' is required.",
            start_position=token[0].start,
            end_position=token[0].end,
        )
    ]

# Generated at 2022-06-22 06:11:14.615566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenize

    tokenize = Tokenize()
    token = tokenize.parse("{}")[0]
    schema = {"id": {"type": "int"}}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'id' is required."
        assert message.start_position == (1, 2)
        assert message.end_position == (1, 2)

# Generated at 2022-06-22 06:11:27.799375
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.examples.tokenize import ExampleSchema, tokens

    validator = ExampleSchema()
    assert tokens.data == validate_with_positions(
        token=tokens, validator=validator
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens.root["title"], validator=validator)
    assert exc_info.value.messages()[0].text == "The field 'title' is required."

# Generated at 2022-06-22 06:11:38.487518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem import String, Integer
    from typesystem.exceptions import ValidationError

    schema = String(min_length=2, max_length=4)

    token = tokenize_string("   abc def ghi   ")[3]
    assert validate_with_positions(token=token, validator=schema) == "abc"

    token = tokenize_string("   abc def ghi   ")[5]
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    assert error.value.text == "Expected a string with a maximum length of 4."
    assert error.value.start_position == token.start
    assert error.value.end_position == token.end

# Generated at 2022-06-22 06:11:47.321446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Example(Schema):
        name = Field(str)
        age = Field(int, required=True)

    token = tokenize('{"name":"foo"}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Example)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.start.subnode(["age"]),
            end_position=token.start.subnode(["age"]).subnode(sub=-1),
        )
    ]

# Generated at 2022-06-22 06:11:57.201593
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:12:08.721614
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import IntegerToken, Token

    def to_schema(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> Schema:
        return validator(*token.children)

    def to_field(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> Field:
        return validator

    schema_validate_with_positions = to_schema(
        token=IntegerToken(value=1, children=[IntegerToken(value=2)], start=0),
        validator=Schema,
    )


# Generated at 2022-06-22 06:12:16.287903
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, fields
    from typesystem.tokenize.parser import parse

    class TestSchema(Schema):
        field = String(format="hex")

    token = parse("{field: 1234}", "json")

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=TestSchema)

    assert len(exc.value.messages) == 1
    assert exc.value.messages[0].text == "Value does not match format hex."

# Generated at 2022-06-22 06:12:27.495783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import typesystem

    source = io.StringIO('{"a":null}')
    token = Token.from_file(source)
    schema = typesystem.Schema(properties={"a": typesystem.String()})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].code == "required"
        assert error.messages[0].text == "The field 'a' is required."
        assert error.messages[0].index == ["a"]
        assert error.messages[0].start_position.line_number == 1
        assert error.messages[0].start_position.line_index == 8

# Generated at 2022-06-22 06:12:39.491529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(required=True)
        age = Field(type=int, required=True)
        email = Field(type=str, required=True)

    class Dog(Schema):
        name = Field(required=True)
        age = Field(type=int, required=True)
        owner = Field(type=Person, required=True)

    class House(Schema):
        address = Field(required=True)
        dogs = Field(type=[Dog], required=True)


# Generated at 2022-06-22 06:12:51.250946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.json_schema import JSONSchema
    from typesystem.schemas import Schema
    from typesystem.fields import String

    field = String(name="name", max_length=10)
    schema = Schema(field=field)
    json_schema = JSONSchema(schema=schema)

    token = schema.tokenizer.tokenize({"name": "abc123abc123abc123abc123"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=json_schema)
    assert len(exc.value.messages()) == 1
    message = exc.value.messages()[0]

# Generated at 2022-06-22 06:13:04.101853
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    import pytest

    class PersonSchema(Schema):
        name = Field(required=True)

    token = Token.from_string(
        """
        {
            "name": "John Doe"
        }
    """
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=PersonSchema)

    error = excinfo.value.messages()[0]

    assert error.text == "The field 'age' is required."
    assert error.start_position.line_number == 2
    assert error.start_position.char_index == 4
    assert error.end_position.line_number == 3
    assert error.end_position.char_index == 11

# Generated at 2022-06-22 06:13:24.715584
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, fields
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.structure import StructureToken, ObjectToken
    from typesystem.tokenize.literals import StringToken
    from typesystem.tokenize.position import Position


# Generated at 2022-06-22 06:13:35.892050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json
    from typesystem.tokenize.exceptions import TokenizeError
    from typesystem.tokenize.tokens import TokenList
    from typesystem.types import String
    from typesystem.validators import is_valid_email
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        email = String(validators=[is_valid_email])

    value = '{"email": "not.valid"}'
    tokens = tokenize_json(value)
    assert isinstance(tokens, TokenList)

# Generated at 2022-06-22 06:13:44.029793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = field.String(max_length=10)

    token = tokenize({"name": "Dave"})
    try:
        validate_with_positions(token, Person)
    except ValidationError as error:
        for message in error.messages():
            print(message.text)

# Generated at 2022-06-22 06:13:55.283161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import ObjectToken
    from tests.validators.sample_validators import BasicType

    schema = BasicType()
    token = tokenize("{}")
    assert isinstance(token, ObjectToken)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error
        messages = list(error.messages())
        assert len(messages) == 3
        message = messages[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.start_position.line == 2
        assert message.start_position.char_index == 2
        assert message.start_position.token_index == 0

# Generated at 2022-06-22 06:14:08.508923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        id = Field(type="integer")

    class EventSchema(Schema):
        title = Field(type="string", required=True)
        people = Field(type="array", items=PersonSchema)

    # Text from:
    # https://www.grammarly.com/blog/compound-sentences

# Generated at 2022-06-22 06:14:20.087913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize import tokenize

    schema = String()

    valid_tokens = tokenize("abc\n")
    assert validate_with_positions(token=valid_tokens[0], validator=schema) == "abc"

    invalid_tokens = tokenize(
        """
---
some:
  - a
  - b
  - c
"""
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=invalid_tokens, validator=schema)

    error = exc.value
    assert error.messages[0].text == "The field 'some' is required."
    assert error.messages[0].start_position == invalid_tokens.start
    assert error

# Generated at 2022-06-22 06:14:31.035075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List
    from typesystem.fields import String
    from typesystem.tokenize import tokens as T
    from typesystem.tokenize.position import Position
    from typesystem.schemas import Schema
    from typesystem.base import Message

    class FieldSchema(Schema):
        name = String()
        description = String()
        required = String()

    class SchemaSchema(Schema):
        fields = List[FieldSchema]()


# Generated at 2022-06-22 06:14:42.833329
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class PersonSchema(Schema):
        first_name = Field(str, required=True)
        last_name = Field(str, required=True)

    data = {"first_name": "John", "last_name": "Doe", "age": 42}
    token = tokenize(data)
    try:
        PersonSchema.validate(data)
    except ValidationError as error:
        with pytest.raises(ValidationError):
            validate_with_positions(token=token, validator=PersonSchema)
        error.raise_additional(
            {
                "data": data,
                "errors": [str(e) for e in error.messages()],
                "whole_file": token.value,
            }
        )


# Generated at 2022-06-22 06:14:49.756096
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_str

    class CitySchema(Schema):
        name = Field(type=str)
        state = Field(type=str, required=True)
        country = Field(type=str, required=True)

    token = tokenize_str('{"name": "Denver", "country": "USA"}')[0]
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=CitySchema)

# Generated at 2022-06-22 06:15:00.896656
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        name = Field(required=True)

    token = Token(
        value={"name": "Example"},
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=17),
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        assert messages[0].start_position == Token.Position(line=1, char_index=1)
        assert messages[0].end_position == Token.Position(line=1, char_index=17)
    else:
        raise AssertionError

# Generated at 2022-06-22 06:15:16.678490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"hello": 42}', linebreak="\n")[0]
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem import types


    class Schema1(Schema):
        x = Field(type=types.Text)


    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Schema1)
    messages = exc_info.value.messages
    assert messages[0].start_position.line == 0
    assert messages[0].start_position.char_index == 9
    assert messages[0].end_position.line == 0
    assert messages[0].end_position.char_index == 13

# Generated at 2022-06-22 06:15:27.337138
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem.types import String
    from typesystem.testing import assert_error_message_equal

    schema = {"name": String(max_length=3)}

    token = parse(schema, "a very long string")["name"]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert_error_message_equal(
        exc_info.value.messages()[0],
        Message(
            index=["name"],
            code="max_length",
            start_position=token.start,
            end_position=token.end,
            text="String value is too long (maximum of 3 characters).",
        )
    )

# Generated at 2022-06-22 06:15:36.245762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.tokenize.interfaces import Tokenizer
    from typesystem.tokenize.vpipes import TokenizerPipeline

    test_schema = Schema(fields={"a": Field(required=True)})
    tokenizer = TokenizerPipeline([
        Tokenizer(rule=r"\s+"),
        Tokenizer(rule=r"[a-z]+", value_keys=["key"]),
    ])
    token = tokenizer.tokenize("foo bar")
    assert token.type == "sequence"
    foo = token[0]
    assert foo.type == "object"
    assert foo.value == {"key": "foo"}
    assert foo.start == (1, 1)
    assert foo.end == (1, 4)
    bar = token[1]
    assert bar

# Generated at 2022-06-22 06:15:45.587428
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer, String
    from typesystem.tokenize.lexers import JSONLexer
    from typesystem.tokenize.tokens import Token
    from typesystem.validators import Length

    schema = Schema(
        {"name": String(), "age": Integer(minimum=0, maximum=150)}
    )
    token = Token.parse(JSONLexer().tokenize('{ "name": "Max", "age": "18" }'))
    try:
        schema.validate(token.value)
    except ValidationError as e:
        assert isinstance(e.messages[0].start_position, int)
        with pytest.raises(AttributeError):
            e.messages[0].start_position.char_index


# Generated at 2022-06-22 06:15:54.470484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_json
    from typesystem.tokenize.exceptions import TokenizeError

    raw_json = '{"a": {"b": {"c": null}}}'
    schema = {
        "a": {"b": {"c": "string"}},
    }

    token = parse_json(raw_json)
    try:
        validate_with_positions(token=token, validator=schema)
        assert False, "Should fail validation"
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].text == "Expected a string."

# Generated at 2022-06-22 06:16:04.747043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, Object
    from typesystem.tokenize.tokens import DocumentToken, Token, ObjectToken
    from typesystem.json_schema import JsonSchema, ObjectField, NumberField
    from typesystem.json import dumps, dumps_strict

    class Int(NumberField):
        def validate(self, value):
            if value != int(value):
                raise ValidationError("NOT_INTEGER")
            return super().validate(value)

    class MySchema(Schema):
        x = ObjectField(fields={"x": Int()})

    schema = MySchema()
    assert schema.validate({"x": {"x": 1}}) == {"x": {"x": 1}}


# Generated at 2022-06-22 06:16:11.054333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token(
            key="name",
            start=(1, 4),
            end=(1, 8),
            value=None,
            children=[Token(key="first", start=(1, 9), end=(1, 14))],
            lookup=lambda index: None,
        ),
        validator=Field(required=True),
    ) == None

# Generated at 2022-06-22 06:16:22.772407
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token.parse('{"name": "bob", "age": "twenty"}')
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == Position(line=1, column=15)
        assert error.messages()[0].end_position == Position(line=1, column=20)
        assert error.messages()[1].start_position == Position(line=1, column=27)
        assert error.messages()[1].end_position == Position(line=1, column=33)
    else:
        assert False

# Generated at 2022-06-22 06:16:32.789664
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import fields
    import json

    schema = fields.Dict(
        {
            "foo": fields.String(),
            "bar": fields.Integer(gt=10)
        }
    )

    def assert_start_end(
        message: Message, line: int, start: int, end: int
    ) -> Message:
        assert message.start_position.line_number == line
        assert message.start_position.char_index == start
        assert message.end_position.char_index == end
        return message


# Generated at 2022-06-22 06:16:36.761174
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        my_field = Field(str)

    token = Token({"my_field": None})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'my_field' is required.",
            code="required",
            index=["my_field"],
            start_position=token.children[0].start,
            end_position=token.children[0].end,
        )
    ]



# Generated at 2022-06-22 06:17:08.188636
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class UserSchema(Schema):
        name = String(required=True)
        age = String(required=True)

    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    token = tokenize("""
        name: John
        age:
        about: Hello World!
    """)

    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=UserSchema)

    messages = e.value.messages()

    assert len(messages) == 2
    assert messages[0].text == "The field 'name' is required."
    assert messages[0].start_position.line_number == 2

# Generated at 2022-06-22 06:17:19.891000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem.tokenize
    import typesystem.tokenize.tokens
    import typesystem.fields

    json_str = '{"example": "value"}'
    token = typesystem.tokenize.tokenize(json_str)

    class Example(typesystem.fields.String):
        def clean(self, value):
            return value[0]

    try:
        validate_with_positions(token=token, validator=Example())
    except typesystem.ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Invalid value. String value expected."
        assert message.code == "invalid"
        assert message.index == ["example"]

# Generated at 2022-06-22 06:17:24.509479
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.rules import convert_to_tokens, TokenizeRule
    from typesystem.tokenize.utils import tokenize

    rule = TokenizeRule(text="foo-bar", type="SYMBOL", subtype="IDENTIFIER")

    tokens = convert_to_tokens({"foo": [rule]})

    token = tokenize(tokens, {"foo": "foo-bar"})["foo"]
    assert validate_with_positions(token=token, validator=Field(type="string")).value == "foo-bar"



# Generated at 2022-06-22 06:17:35.877408
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        my_field = Field(type="string")

    class MyOtherSchema(Schema):
        my_field = Field(type="integer")

    class MyValidator(Schema):
        my_field = Field(type=MySchema)

    class MyOtherValidator(Schema):
        my_field = Field(type=MyOtherSchema)

    JSON = {
        "my_field": {
            "my_field": "1",
        },
    }
    TOKEN = Token.from_json(JSON, start_position=None)
    validate_with_positions(
        token=TOKEN, validator=MyValidator,
    )


# Generated at 2022-06-22 06:17:47.273839
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Structure
    from typesystem.tokenize import tokenize

    class Invoice(Structure):
        invoice_number = Integer(required=True)
        description = Integer()

    token = tokenize(
        {
            "description": "A really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really really long description",
            "invoice_number": 2
        }
    )


# Generated at 2022-06-22 06:17:53.005142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pygments.token import Punctuation, Name, Number, Keyword

    from typesystem.tokenize.tokens import Token

    from typesystem.fields import String, Integer


# Generated at 2022-06-22 06:18:03.711727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Field

    class MineField(Field):
        def __init__(self, minefield, *args, **kwargs):
            self.minefield = minefield
            super().__init__(*args, **kwargs)

        def validate(self, value):
            if self.minefield:
                raise ValidationError(
                    f"{value} is a minefield.", code="minefield"
                )
            return value

    class MineSchema(Schema):
        class Meta:
            fields = ["x", "y"]

        x = MineField(minefield=False)
        y = MineField(minefield=True)

    from typesystem.tokenize import tokenize

    source = "{"
    source += '"x": "moo",'
    source += '"y": "boom"}'
