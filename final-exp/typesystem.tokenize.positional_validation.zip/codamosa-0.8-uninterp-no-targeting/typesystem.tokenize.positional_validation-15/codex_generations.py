

# Generated at 2022-06-22 06:08:01.946752
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Given I have a token dictionary with start and end positions
    token = Token(
        value={
            "integer": "1",
            "float": "1.0",
            "string": "hello",
            "boolean": "falsE",
            "null": "null",
            "list": ["1", "2", "3"],
            "dict": {
                "key1": "value1",
                "key2": ["value2", "value3"],
                "key3": {
                    "key4": "value4",
                    "key5": ["value5", "value6"],
                },
            },
        },
        start=(1, 10),
        end=(10, 0),
    )

    # Given I have a TypeSystem schema

# Generated at 2022-06-22 06:08:10.751894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema()
    schema["a"] = Field(validators=[lambda value: value == 1])

    token = Token(value={"a": 1}, children=[])
    validate_with_positions(token=token, validator=schema)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert len(excinfo.value.messages()) == 1
    message = excinfo.value.messages()[0]
    assert message.text == "A value was expected."
    assert message.code == "required"
    assert message.index == ["a"]
    assert message.start_position == Position(line_number=1, char_index=4)

# Generated at 2022-06-22 06:08:18.418562
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ValidateSchema(Schema):
        field = Field(required=True)

    def assert_no_exception(
        token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> None:
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            raise AssertionError(
                f"ValidationError raised: {error.messages()}"
            ) from error


# Generated at 2022-06-22 06:08:30.163250
# Unit test for function validate_with_positions
def test_validate_with_positions():
    root = Token(
        "root", value={"name": "John"}, start_position=Position(line=1, char_index=1)
    )
    user = Token(
        "user",
        value={},
        start_position=Position(line=1, char_index=1),
        parent=root,
    )

    class UserSchema(Schema):
        name = fields.String(required=True)


# Generated at 2022-06-22 06:08:33.088538
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # TODO: implement function
    assert False


__all__ = [
    "validate_with_positions",
]

# Generated at 2022-06-22 06:08:40.963037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenizer import test_data

    class Foo(Schema):
        bar = Field(type="integer")

    token = Token.read(test_data)
    assert token
    with pytest.raises(ValidationError) as err:
        validate_with_positions(token=token, validator=Foo)
    assert len(err.value.messages) == 1
    assert str(err.value) == "The field 'bar' is required."

# Generated at 2022-06-22 06:08:47.261108
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import dict_token, list_token, str_token

    class MySchema(Schema):
        x = Field(type="integer", required=True)
        y = Field(type="integer", required=True)
        z = Field(type="string", required=True)


# Generated at 2022-06-22 06:08:58.423450
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", gte=0, lte=100)

    # Some of the following tests are inspired by projects using this function.

    token = Token(
        value={"name": "Monty Python", "age": "42"},
        start_index=0,
        start_line=0,
        start_column=0,
    )

    # Test for missing required field.
    try:
        validate_with_positions(token=token, validator=User)
        failed = False
    except ValidationError as error:
        failed = True
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"

# Generated at 2022-06-22 06:09:07.038103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, TokenType
    from typesystem.tokenize.positions import Position

    from typesystem.fields import String

    field = String()

    token = Token(
        value="hello world",
        token_type=TokenType.FIELD,
        start=Position(line=0, char_index=0),
        end=Position(line=0, char_index=6),
    )

    result = validate_with_positions(token=token, validator=field)

    assert result == "hello world"



# Generated at 2022-06-22 06:09:17.299220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.grammars import JSON
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.schemas import Integer

    value = tokenize("{a : 123", JSON)
    try:
        validate_with_positions(token=value, validator={"a": Integer()})
    except ValidationError as error:
        assert len(error.messages) == 2
        assert error.messages[0].code == "required"
        assert (
            error.messages[0].text
            == "The field 'b' is required. The field 'c' is required."
        )
        assert error.messages[0].start_position == (1, 3)
        assert error.messages[0].end_position == (1, 7)

# Generated at 2022-06-22 06:09:28.845744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.definitions import String, Integer
    from typesystem.tokenize.tokens import StringToken, IntegerToken

    string_field = String(name="title")
    integer_field = Integer(name="age")

    class Person(Schema):
        title = string_field
        age = integer_field

    val = validate_with_positions
    t = StringToken("Hello", 0, 6)

    assert val(token=t, validator=string_field) == "Hello"

    t = StringToken("", 0, 0)
    try:
        val(token=t, validator=string_field)
    except ValidationError as e:
        error = e
    assert error.messages()[0].text == "The field 'title' is required."
    assert error.messages()[0].start_position

# Generated at 2022-06-22 06:09:39.148737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        field = Field()
        content = Field()

    token = Token(
        value={"field": "value", "content": "more"},
        start=Token.Position(line=0, column=0, char_index=0),
        end=Token.Position(line=0, column=0, char_index=0),
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        (message,) = error.messages()
        assert message.text == "The field 'content' is required."

# Generated at 2022-06-22 06:09:49.435850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.error import ValidationError
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class MySchema(Schema):
        foo = String()
        bar = Integer()


# Generated at 2022-06-22 06:09:56.243129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    schema = Person()
    data = {'name': 'bob'}
    token = Token("", "", data)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'age' is required."
    assert message.code == "required"
    assert message.index == ['age']
    assert message.start_position == (1, 1)  # line, column
    assert message.end_position == (1, 1)  # line, column

# Generated at 2022-06-22 06:10:06.784601
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(fields={"foo": Field(type="number")})
    token = Token(
        value='{"foo": "bar"}',
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 1, "char_index": 15},
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'foo' must be a number."
        assert message.start_position == token.start
        assert message.end_position == token.end

# Generated at 2022-06-22 06:10:17.124547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem.tokenize import tokenize
    from typesystem.tokens import Token

    class User(Schema):
        name = String(max_length=10)

    tokens = tokenize(
        {
            "name": "",
            "age": 20,
            "gender": "female",
            "location": {
                "city": "",
                "country": "US",
                "country2": "UK",
                "street": {
                    "name": "Main",
                    "number": 5,
                },
            },
        }
    )


# Generated at 2022-06-22 06:10:22.594326
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.json_schema import JSONSchema
    from typesystem.tokenize import tokenize

    schema = JSONSchema(
        {
            "properties": {
                "foo": {
                    "type": "string",
                    "minLength": 3,
                    "maxLength": 5,
                },
            },
        }
    )
    token = tokenize('{"foo": "bar"}')
    validate_with_positions(token=token, validator=schema)

    token = tokenize('{"foo": "ba"}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.code == "min_length"

# Generated at 2022-06-22 06:10:31.484371
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String
    from typesystem.tokenize.tokens import ObjectToken

    class Data:
        title: str

    class DataSchema(Schema):
        title = String()

    token = ObjectToken(data=Data(), errors=[])

    try:
        validate_with_positions(token=token, validator=DataSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'title' is required."



# Generated at 2022-06-22 06:10:34.499963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="integer")
    token = Token(value=42)
    assert validate_with_positions(token=token, validator=field) == 42

# Generated at 2022-06-22 06:10:45.944967
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int)

    token = tokenize(
        {
            "name": "Bob",
            "age": "50",  # <-- Bad string, should be integer.
        }
    )

# Generated at 2022-06-22 06:11:03.320489
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.positions import (
        FilePosition,
        LinePosition,
        CharacterPosition,
        CharacterIndexPosition,
    )
    from typesystem.tokenize.tokens import Token

    # This mimics the start and end count of the TargetToken in this
    # example.
    start = CharacterPosition(
        file=FilePosition(), line=LinePosition(number=2, start_char=7), column=6
    )
    end = CharacterPosition(
        file=FilePosition(), line=LinePosition(number=2, start_char=7), column=15
    )

# Generated at 2022-06-22 06:11:14.141013
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class TestSchema(Schema):
        one = Integer()

    with pytest.raises(ValidationError) as exception:
        validate_with_positions(
            token=Token(value=None, start=None, end=None), validator=TestSchema
        )

    error = exception.value

    assert len(error.messages) == 1

    message = error.messages[0]
    assert message.text == "The field one is required."
    assert message.index == [0]
    assert message.start_position.line == message.end_position.line
    assert message.start_position.char_index == message.end_position.char_index

# Generated at 2022-06-22 06:11:21.449855
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.tokenize import tokenize

    class UserSchema(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(required=True)

    source = {"name": "John", "age": 3}

    try:
        for token in tokenize(json.dumps(source)):
            validate_with_positions(token=token, validator=UserSchema)
        raise AssertionError(
            "expected an error to be raised due to age being an integer, not a string"
        )
    except ValidationError as error:
        message = error.messages[0]
        assert message.code == "invalid_type"
        assert message.index == ("age",)
        assert message.start_position.byte_

# Generated at 2022-06-22 06:11:23.788484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Basic test to ensure correct import
    assert validate_with_positions


# Generated at 2022-06-22 06:11:34.785686
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.tokenize.document import Document
    from typesystem.tokenize.errors import TokenizeError
    from typesystem.fields import String
    from typesystem.schemas import Object

    class MySchema(Object):

        name = String(required=True)
        email = String()

    class MyComplexSchema(Object):

        my_object = MySchema()

    def test_validate_with_positions(input: str, expected: typing.Any):
        document = Document(input)
        try:
            result = validate_with_positions(
                token=document.json(), validator=MySchema
            )
        except TokenizeError as exc:
            assert False, str(exc)
        except ValidationError as exc:
            result = exc


# Generated at 2022-06-22 06:11:45.345759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import OpenApiSchema

    open_api_schema = OpenApiSchema(
        data_type=typing.Dict[str, int],
        properties={"x": "integer", "y": "integer"},
    )

    token = Token(
        path=["root", "dict"],
        value={"x": 1, "y": "foo"},
        start=Message.Position(line=2, char_index=3),
        end=Message.Position(line=2, char_index=7),
    )

    try:
        validate_with_positions(token=token, validator=open_api_schema)
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-22 06:11:57.508529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.tokens import Token, TokenType

    validator = Integer(required=True)
    token = Token(
        value={"a": 1},
        start_position=None,
        end_position=None,
        token_type=TokenType.DICT,
        tokens={
            "a": Token(
                value=1,
                start_position=None,
                end_position=None,
                token_type=TokenType.INT,
                tokens=None,
            )
        },
    )

    # Parsing happens around the code, so that we have start/end positions.
    # This might happen in a library, but not while testing this library.

# Generated at 2022-06-22 06:12:07.637726
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Object, fields

    class Person(Schema):
        first_name = String()
        last_name = String()

    class Address(Schema):
        street = String()

    class User(Schema):
        username = String()
        addresses = fields.List(item=Address())


# Generated at 2022-06-22 06:12:17.689216
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Literal

    from .test_validate import test_validate

    # Set up an example validator for this test.
    class Person(Schema):
        name = Field(str)
        age = Field(int)

    age_validator = Field(int)

    # Set up an example Literal token with position information.
    literal = Literal('{"name": "Foo", "age": "Bar"}')

    # Perform a validation of the example Literal token without positional information.
    caught = False
    try:
        test_validate(token=literal, validator=Person)
    except ValidationError as error:
        for message in error.messages():
            assert message.start_position is None
            assert message.end_position is None

# Generated at 2022-06-22 06:12:25.993422
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Str
    from typesystem.exceptions import ValidationError

    value = "hello world"
    token = Token(value=value, start=[4, 5], end=[4, 11])

    field = Str(min_length=10)

    validate_with_positions(token=token, validator=field)

    field = Str(max_length=8)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.code == "max_length"
    assert message.start_position == (4, 5)

# Generated at 2022-06-22 06:12:44.062487
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.types import String

    from .test_tokenize import tokenize

    field = String(min_length=4)

    source = """
        value: "example"
    """

    token = tokenize(source)
    validate_with_positions(token=token, validator=field)

# Generated at 2022-06-22 06:12:54.138151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize import tokenize

    class Movie(Schema):
        name = Field(str)
        year = Field(int)
        characters = Field(list, items=str)

    assert validate_with_positions(token=tokenize("{}"), validator=Movie) == {}
    with pytest.raises(ValidationError):
        validate_with_positions(token=tokenize("{}"), validator=Movie)

    class Movie(Schema):
        name = Field(str)
        year = Field(int)
        characters = Field(list, items=str)

    assert validate_with_positions(
        token=tokenize("{'name': 'Star Wars'}"), validator=Movie
    ) == {"name": "Star Wars"}

# Generated at 2022-06-22 06:13:06.938387
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, Integer
    from typesystem.tokenize.parser import parse

    schema = Schema({"a": [Integer()], "b": Boolean()})
    # Valid
    token = parse("{a: [1, 2, 3, 4], b: true}")  # type: ignore
    validate_with_positions(token=token, validator=schema)

    # Not valid.
    token = parse("{a: [1, 2, 3, 4], b: true, c: [1]}")  # type: ignore
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    messages = error.value.messages()
    assert messages[0].text.startswith("The field c is not allowed")


# Generated at 2022-06-22 06:13:17.357443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from .examples import Person

    text = u'{ "name": "Foo", "age": 30 }'
    tokens = list(tokenize(text))
    assert len(tokens) == 1
    assert tokens[0].token_type == "value"
    assert tokens[0].start == (1, 0)
    assert tokens[0].end == (1, 20)
    value = validate_with_positions(token=tokens[0], validator=Person.definition)
    assert value == {"name": "Foo", "age": 30}

    text = u'{ "name": "Foo", "age": "bar" }'
    tokens = list(tokenize(text))
    assert len(tokens) == 1
    assert tokens[0].token_type

# Generated at 2022-06-22 06:13:28.008509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.tokenize.tokenizers import tokenize_text

    class Person(Object):
        properties = {"name": {"type": str, "required": True}}

    text = "name: Test"
    token = tokenize_text(text)
    person = token.validate_with_positions(Person)
    assert person == {"name": "Test"}

    text = "\nname:"
    token = tokenize_text(text)
    with pytest.raises(ValidationError) as exc_info:
        person = token.validate_with_positions(Person)

# Generated at 2022-06-22 06:13:36.039433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.parser import parse

    schema = parse(
        """
    type: record
    fields:
      - name: a
        type: string
        required: true
      - name: b
        type: string
    """
    )
    field = schema.fields[0]
    token = schema.tokenize({"b": "foo"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)
    assert exc.value.messages[0].start_position.line == 1
    assert exc.value.messages[0].end_position.line == 1
    assert exc.value.messages[0].start_position.column == 2
    assert exc.value.messages[0].end_

# Generated at 2022-06-22 06:13:46.394471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import json_tokenizer

    from .helpers import StringReader

    # Type-check test
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import RootSchema
    from typesystem import fields

    field: Field = fields.String()
    schema: RootSchema = RootSchema(fields={"field": field})

    reader = StringReader("""
    {
        "field": "test"
    }
    """)

    token = json_tokenizer.tokenize(reader)
    validate_with_positions(token=token, validator=schema)



# Generated at 2022-06-22 06:13:57.375532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.errors import TokenizeError
    from typesystem.types import String

    schema = String(min_length=5)

    token = tokenize("hello")
    assert validate_with_positions(token=token, validator=schema) == "hello"

    token = tokenize("hello world")
    assert validate_with_positions(token=token, validator=schema) == "hello"

    token = tokenize("test")
    try:
        validate_with_positions(token=token, validator=schema)
    except TokenizeError as error:
        message = error.messages()[0]
        assert message.start_position.line == 1
        assert message.start_position.column == 1
       

# Generated at 2022-06-22 06:14:09.380992
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.serialization import json_serializer
    from typesystem import types
    import json

    class Pet(Schema):
        name = types.String()
        age = types.Integer()

    class Person(Schema):
        first_name = types.String()
        last_name = types.String()
        pets = types.Array(types.Instance(Pet))

    token = json_serializer.serialize({"first_name": "Ada", "last_name": "Lovelace"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        for message in error.messages():
            assert isinstance(message.start_position, json_serializer.Position)

# Generated at 2022-06-22 06:14:18.656151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize_file
    from typesystem import String, validate
    import json
    import os

    class Person(Schema):
        name = String()

    path = os.path.join(os.path.dirname(__file__), "fixtures", "tokenize.json")
    with open(path) as fh:
        tokens = tokenize_file(fh)

    try:
        validate(tokens, Person)
    except ValidationError as error:
        expected = json.load(open(path))
        assert error.messages() == expected

# Generated at 2022-06-22 06:14:57.716545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple
    from textwrap import dedent
    from typesystem import Array, Boolean, Compound, String

    class Person(Compound):
        name = String()
        age = String()
        happy = Boolean()
        friends = Array(compound=Person, required=True)

    text = '{"name": "John Doe", "happy": true, "friends": []}'
    CharMap = namedtuple("CharMap", ["row", "column", "char_index", "line_index"])


# Generated at 2022-06-22 06:15:08.515354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ArraySchema(Schema):
        items = Field(type=str)

    array_schema = ArraySchema()
    validate_with_positions(
        token=Token([Token(["test"]), Token(["test"])]), validator=array_schema
    )

    from typesystem.primitives import String

    string = String(
        min_length=5,
        max_length=5,
        message='String length should be 5 and should be of type "str".',
    )

    # works for both field and schema
    try:
        validate_with_positions(token=Token([Token(["test"])]), validator=string)
        assert False, "Validation should fail."
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()

# Generated at 2022-06-22 06:15:19.610996
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.test_tokenize.fixtures import get_token, Person

    token = get_token(Person)

# Generated at 2022-06-22 06:15:29.732547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    input_ = '[true, false]'  # noqa: WPS323
    token = Token.parse(input_)

    def validator(value: typing.Any) -> bool:
        if not isinstance(value, list):
            raise ValidationError(
                f"expected list but found {type(value).__name__!r}",
                code="type-error",
            )
        return True

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as ex:
        msg = ex.messages()[0]
        assert msg.index == []
        assert msg.start_position.line_index == 0
        assert msg.start_position.char_index == 0
        assert msg.end_position.line_index == 0

# Generated at 2022-06-22 06:15:39.897282
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class UserSchema(Schema):
        name = Field(str)
        age = Field(int)


# Generated at 2022-06-22 06:15:51.002294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        email = Field(type="string", pattern=r"\w+@\w+\.\w+")

    from typesystem.tokenize.tokenize import tokenize

    token = tokenize({"email": "foo@bar.com"})
    result = validate_with_positions(token=token, validator=User)
    assert isinstance(result, dict)
    assert result == {"email": "foo@bar.com"}

    token = tokenize({"email": "foo"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=User)

    assert len(exc.value.messages) == 1
    message = exc.value.messages[0]

# Generated at 2022-06-22 06:16:01.457313
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Tokenizer
    from typesystem.tokenize.validators import is_number
    from typesystem.schemas import Schema
    from typesystem.fields import IntegerField

    tokenizer = Tokenizer(schema=Schema)
    with pytest.raises(ValidationError) as exc_info:
        tokenizer.tokenize("{ foo: bar }")

    messages = exc_info.value.messages
    assert messages[0].text == "The field 'foo' is required."
    assert messages[1].text == "This value should be a number."

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokenizer.tokenize("123"), validator=is_number)

    messages = exc_info.value.messages

# Generated at 2022-06-22 06:16:12.872723
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types, fields

    class Schema(types.Schema):
        field1 = fields.Integer()
        field2 = fields.String(min_length=4)

    class Root(types.Schema):
        field1 = fields.Integer()
        field2 = fields.String()
        field3 = fields.Boolean()
        field4 = fields.Object(properties={"field1": fields.Integer()})
        field5 = fields.Array(items=Schema)
        field6 = fields.String()

    schema = Root()

# Generated at 2022-06-22 06:16:24.932900
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ListToken, ObjectToken, ScalarToken
    from typesystem.fields import Boolean, Integer, String
    from typesystem.schemas import Schema

    schema = Schema({"name": String(), "age": Integer(), "married": Boolean()})

# Generated at 2022-06-22 06:16:33.513363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    class PersonSchema(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class CompanySchema(Schema):
        name = Field(type="string")
        members = Field(type="array[person]")

    class AddressSchema(Schema):
        street = Field(type="string")
        city = Field(type="string")
        persons = Field(type="array[person]")

    class Root(Schema):
        person = PersonSchema
        company = CompanySchema
        address = AddressSchema

    # Create data with errors

# Generated at 2022-06-22 06:17:43.207979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pathlib
    import typesystem
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.serialize import serialize
    from typesystem.tokenize.tokens import ListToken
    from typesystem.tokenize.loaders import load_class

    path = pathlib.Path(__file__).parent / "data" / "schema.json"
    data = pathlib.Path(__file__).parent / "data" / "data.json"
    token_schema = tokenize(load_class(typesystem.Schema)({"fields": {"foo": {}}}))
    token 

# Generated at 2022-06-22 06:17:52.508671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_validate(token, validator):
        validate_with_positions(token=token, validator=validator)

    def assert_invalid_validate(token, validator, error_code, error_text):
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            assert [message.code for message in error.messages()] == [error_code]
            assert [message.text for message in error.messages()] == [error_text]
        else:
            assert False, "Should have raised ValidationError"

    from ..tokenize import tokenize

    ast = tokenize("42")[0]
    assert_validate(token=ast, validator=Field(type="integer"))
