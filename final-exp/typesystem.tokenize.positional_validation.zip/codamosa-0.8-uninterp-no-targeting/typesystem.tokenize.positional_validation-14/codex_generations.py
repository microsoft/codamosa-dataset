

# Generated at 2022-06-22 06:08:10.629170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tests.test_tokenize import tokenize
    from jsonpointer import JsonPointer
    from typesystem.structures import Structure

    # The Structure validator will raise a ValidationError
    # with a message that is missing the start_position and end_position attributes.
    # We check that validate_with_positions catches this case, and adds the
    # start_position and end_position attributes.
    class TestSchema(Structure):
        fields = {"foo": "string"}
        required = ["foo"]

    schema = TestSchema()

    token = tokenize({})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert len(exc_info.value.messages) == 1
    message = exc_

# Generated at 2022-06-22 06:08:18.203377
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import dict_to_token, list_to_token

    schema = Schema(fields={"name": Field(type="string", required=True)})
    validator = schema["name"]

    value = {}
    token = dict_to_token(value)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=validator)
    errors = excinfo.value.messages
    assert len(errors) == 1
    assert errors[0].text == "The field 'name' is required."
    assert errors[0].code == "required"
    assert errors[0].start_position.char_index == len("{}")

    value = {"name": 2}
    token = dict_to_token(value)

# Generated at 2022-06-22 06:08:29.905221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestSchema(Schema):
        field = Field(type="string", required=True)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token.object(value={"field": 1}, start=0, end=10),
            validator=TestSchema,
        )
    assert len(error.value.messages()) == 1
    message = error.value.messages()[0]
    assert message.text == "The field 'field' should be of type 'string', got 1."
    assert message.start_position == 0
    assert message.end_position == 10


# Generated at 2022-06-22 06:08:36.660586
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import attr
    import json
    @attr.s
    class UserSchema(Schema):
        name = Field(str)

    with open("tests/data/user.json") as stream:
        data = json.load(stream)

    token = Token.from_parsed(data)
    try:
        validate_with_positions(token=token, validator=UserSchema)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.code == "required"
        assert message.index == ["name"]
        assert message.text == "The field 'name' is required."
        assert message.start_position.line_index == 1
        assert message.start_position.column_index == 3
        assert message.start_

# Generated at 2022-06-22 06:08:46.323494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type=str, required=True)


# Generated at 2022-06-22 06:08:56.142822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse
    from typesystem import fields

    schema = fields.Object(properties={"a": fields.String()})
    document = parse('{"a": 1}')
    try:
        validate_with_positions(token=document, validator=schema)
        pytest.fail("ValidationError not raised")
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Expected string."
        assert message.start_position.line_number == 0
        assert message.start_position.char_index == 6
        assert message.end_position.line_number == 0
        assert message.end_position.char_index == 7

# Generated at 2022-06-22 06:09:07.899269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class A(Schema):
        foo = Field(str, required=True)
        bar = Field(str, required=True)
        baz = Field(str, required=False)

    token = Token(
        {"foo": "foo", "bar": "bar"},
        start=Position(line_number=1, char_index=0),
        end=Position(line_number=4, char_index=0),
    )
    assert validate_with_positions(token=token, validator=A)

    token = Token(
        {"foo": "foo", "baz": "baz"},
        start=Position(line_number=1, char_index=0),
        end=Position(line_number=4, char_index=0),
    )
    with raises(ValidationError) as error:
        validate_

# Generated at 2022-06-22 06:09:16.329951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_string

    from typesystem import Schema
    from typesystem.fields import String

    class PersonaSchema(Schema):
        name = String()

    schema = PersonaSchema()
    string = '{"name": "Juan"}'
    try:
        data = validate_with_positions(
            token=tokenize_string(string), validator=schema
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.char_index == 10
        assert message.end_position.char_index == 15



# Generated at 2022-06-22 06:09:24.445103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer

    tokenizer = JSONTokenizer(object_type=Field)
    tokens = tokenizer.tokenize('{"a": "hello"}')

    validate_with_positions(token=tokens, validator=tokens.value["a"])

    try:
        validate_with_positions(token=tokens, validator=tokens.value["b"])
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 8
        assert error.messages()[0].end_position.char_index == 9

# Generated at 2022-06-22 06:09:35.499223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.metadata import Metadata
    from typesystem.utils import TextPosition

    class ExampleSchema(Schema):
        name = Field(str, required=True)

    token = Token(
        value={"name": "John"},
        start=TextPosition(char_index=0, line=1, column=1, path="example.json"),
        end=TextPosition(char_index=10, line=1, column=11, path="example.json"),
        metadata=Metadata(),
    )

    token = token.lookup(["name"])

# Generated at 2022-06-22 06:09:49.887244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None
    from typesystem.fields import String
    from typesystem.tokenize.positions import Position

    field = String(name="field")
    token = Token(
        value="hello",
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=5),
        path=["field"],
    )
    value = validate_with_positions(token=token, validator=field)
    assert value == "hello"

    token = Token(
        value="",
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=0),
        path=["field"],
    )

# Generated at 2022-06-22 06:09:59.821753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Object, Array

    class Person(Object):
        name = String(required=True)
        age = String()

    class People(Array[Person]):
        pass

    people = People()
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                "objects",
                [
                    {"name": "foo", "age": "20"},
                    {"name": "bar"},
                    {"name": "baz", "age": "30"},
                ],
            ),
            validator=people,
        )
    assert len(exc_info.value.messages()) == 1

    message = exc_info.value.messages()[0]
    assert message.text == "The field 'age' is required."

# Generated at 2022-06-22 06:10:12.061752
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize, TokenizerError
    from typesystem.exceptions import ValidationError

    schema = Schema(
        fields={"foo": Field(required=True), "bar": Field(required=True)}
    )
    tokens, errors = tokenize("{}", schema)
    with pytest.raises(TokenizerError) as exc:
        validate_with_positions(token=tokens["."], validator=schema)

# Generated at 2022-06-22 06:10:23.665523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        class Person(Schema):
            name = Field(type="string", min_length=2, max_length=10)
            age = Field(type="number", min_value=0)

        validate_with_positions(
            token=Token(
                value={},
                start=2,
                end=3,
                lookup=lambda *path: Token(value="{}", start=2, end=3, lookup=None),
            ),
            validator=Person,
        )
    except ValidationError as e:
        assert e.messages[0].text == "The field 'name' is required."
        assert e.messages[0].start_position.char_index == 2
        assert e.messages[0].end_position.char_index == 3

# Generated at 2022-06-22 06:10:35.450738
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Dict
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.lexers import lex_json
    from typesystem.tokenize.parsers import parse_json

    class JsonSchema(Schema):
        a = Field(type=str)
        b = Field(type=int)
        c = Field(type=bool)
        d = Field(type=float)
        e = Field(type=Dict)
        f = Field(type=list, item=int)

    tokens = lex_json("""{
        "a": 1,
        "b": "abc",
        "c": true,
        "d": "abc",
        "e": true
    }""")

# Generated at 2022-06-22 06:10:47.207836
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Token
    from typesystem.tokenize import TokenizeError
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    class User(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={"name": "", "age": "1"},
        start=line(2, 1).char(1),
        end=line(2, 1).char(5),
    )

    try:
        schema = User.validate(token.value)
    except ValidationError as e:
        print(e.messages())


# Generated at 2022-06-22 06:10:56.064878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    schema = typesystem.Schema(fields={"person": Person})

    json_string = (
        '{"person": {"name": "Alice", "age": 25}, "extra_field": "whatever"}'
    )
    token = Token.parse_json(json_string)

    assert schema.validate(token.value) == {
        "person": {"name": "Alice", "age": 25}
    }


# Generated at 2022-06-22 06:11:06.929884
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.composite import Dict, List
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        first = String(max_length=10)
        last = String(max_length=10)

    class People(Schema):
        people = List[Person]()

    token = Token(
        name="people",
        value=[
            {'first': 'Joe', 'last': 'Bloggs'},
            {'first': 'Jane', 'last': 'Blogg'},
        ],
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=People)

    ex = exc_info.value

# Generated at 2022-06-22 06:11:15.527519
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    field = String(max_length=3)
    try:
        validate_with_positions(token=Token(value="Hello"), validator=field)
    except ValidationError as exc:
        assert exc.messages == [
            Message(
                "Ensure this value has at most 3 characters (it has 5).",
                code="invalid",
                start_position=Position(line=0, char_index=0),
                end_position=Position(line=0, char_index=5),
            )
        ]

# Generated at 2022-06-22 06:11:24.742147
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    from typesystem.tokenize.tokens import InvalidToken
    from typesystem.tokenize.parser import TokenCollection

    from typesystem.exceptions import *
    from typesystem.tokenize.exceptions import *

    data = [
        {"data": {"name": "harry", "age": 99}, "expect": 99},  # type: ignore
        {"data": {"name": "harry"}, "error": ValidationError},  # type: ignore
        {"data": {"name": "harry", "age": "xyz"}, "error": ValidationError},  # type: ignore
    ]

    schema = Schema(
        {"name": String(), "age": Integer(nullable=False)}
    )  # type: ignore


# Generated at 2022-06-22 06:11:39.454569
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema import Schema
    from typesystem.tokenize.tokens import ArrayToken, DictToken, Token

    schema = Schema(fields={"items": {"type": "string"}})

    assert (
        validate_with_positions(
            token=ArrayToken([DictToken({}), "foo"], start=(10, 5), end=(21, 5)),
            validator=schema,
        )
        == ["foo"]
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=ArrayToken([DictToken({}), Token()], start=(10, 2), end=(21, 5)),
            validator=schema,
        )

    message: Message = exc_info.value.messages[0]
    assert message

# Generated at 2022-06-22 06:11:47.096226
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        a = String(required=False)
        b = String(required=False)

    doc = "foo\n  b\nbar"
    token = Token.load(doc)
    validate_with_positions(token=token, validator=MySchema)
    token = token.lookup("a")
    token.value = "abc"
    validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-22 06:11:57.584047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import ConditionalToken, KeyToken, Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer()

    class UserSchema(Schema):
        username = Field(type=str)

    raw_token = ConditionalToken(
        [KeyToken(["username"]), Token(value=1234)],
        conditions={
            "missing": ValueError(),
            "invalid": ValueError(),
            "valid": None,
        },
    )
    token = UserSchema._tokenize(tokenizer, raw_token)
    validate_with_positions(token=token, validator=UserSchema)


# Generated at 2022-06-22 06:12:08.813707
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, Schema, ValidationError

    class ArticleSchema(Schema):
        title = String(required=True)
        description = String()
        score = Integer()

    token = Token(
        value={
            "title": "The title",
            "description": "The description",
            "score": "Not an integer",
        }
    )

    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=ArticleSchema)

    exc_info = sys.exc_info()
    error = exc_info[1]
    message = error.messages[0]
    assert message.text == "The field 'score' is not of type 'integer'."
    assert message.fields["index"].value == ["score"]

# Generated at 2022-06-22 06:12:18.197960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typesystem.exceptions import ValidationError
    from typesystem.json_schema import JSONSchema

    class Person(typesystem.Schema):
        name = typesystem.String()

    input_ = Person.validate({"name": 42})
    try:
        json.dumps(input_)
    except ValidationError as exc:
        for message in exc.messages:
            assert isinstance(message, typesystem.Message)
            assert message.text.startswith("Expected string.")
            assert isinstance(message.start_position, typesystem.Position)
            assert message.start_position.char_index == 10
            assert isinstance(message.end_position, typesystem.Position)
            assert message.end_position.char_index == 11

# Generated at 2022-06-22 06:12:26.007907
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.contrib.json_schema import Nullable
    from tests.contrib.openapi.post_request import (
        Pet,
        PetSchema,
        PetStatus,
        PetStatusSchema,
    )

    string = '{"name": "Fido"}'
    token = Token(
        raw_value=string,
        value=json.loads(string),
        start=Point(line_number=1, char_index=0),
        end=Point(line_number=1, char_index=len(string)),
    )

    # NOTE: Passing a field validator
    schema = PetSchema()
    name_field = schema.fields["name"]
    try:
        validate_with_positions(token=token, validator=name_field)
    except ValidationError as error:
        messages

# Generated at 2022-06-22 06:12:38.037964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import PrimitiveLexer
    from typesystem.tokenize.parsers import FunctionParser
    from typesystem.fields import Array, Integer, Object, String

    lexer = PrimitiveLexer()
    parser = FunctionParser(lexer)

    class User(Schema):
        name = String(required=True)
        age = Integer()

    class Users(Schema):
        users = Array(items=User())

    schema = Users()

    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=parser('{"users":[{"name": "Foo"}]}'), validator=schema
        )


# Generated at 2022-06-22 06:12:48.066331
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class TestValidator(Field):
        def validate(self, value):
            if value == "foo":
                raise ValidationError("Invalid value.")
            return value

    token = Token(value="foo", start=("test_file.py", 1, 0), end=("test_file.py", 1, 3))
    try:
        validate_with_positions(token=token, validator=TestValidator())
    except ValidationError as error:
        assert error.messages()[0].start_position.file_path == "test_file.py"
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_

# Generated at 2022-06-22 06:12:57.676673
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ListItem(Schema):
        text = Field(type="string", min_length=1)
        position = Field(type="number")

    class TestSchema(Schema):
        name = Field(type="string", max_length=10)
        items = Field(type="array", min_items=1, items=ListItem)

    # The unit test for this function is implemented as an integration test.
    # This is because adding the position information to the ValidationError
    # messages adds complexity that is already covered in previous test cases.
    # The only thing left to test is that the positions are correct.
    from typesystem.parser import parse_schema

    # This test case uses a complicated dictionary structure.
    # This is because the parse_schema function will interpret this as JSON
    # and the expected ValidationError messages will be different.


# Generated at 2022-06-22 06:13:06.249466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize_python, tokenize_json
    from typesystem.tokenize.tokens import Token


# Generated at 2022-06-22 06:13:17.904834
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TextToken, ObjectToken
    from typesystem import Schema, String, Integer
    from typesystem import validate_with_positions

    class Person(Schema):
        name = String(required=True)
        age = Integer(minimum=0, maximum=120)

    text = '{"name": "Marc", "age": 121}'
    token = ObjectToken(value={"name": "Marc", "age": 121}, index=2)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages[0].text == "Ensure this value is less than or equal to 120."
        assert error.messages[0].start_position.char_index == 12

# Generated at 2022-06-22 06:13:28.217153
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "name": Field(required=True, type=str),
            "email": Field(type=str),
            "age": Field(type=int),
            "tags": Field(type=list),
        }
    )

    token = Token.lookup(
        {
            "name": "Foo Bar",
            "email": "",
            "age": "invalid",
            "tags": "invalid",
        },
        start=Position.from_row_and_column(row=0, column=0),
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    messages = excinfo.value.messages()
    assert len(messages) == 3

# Generated at 2022-06-22 06:13:36.095590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.schemas import Schema

    from . import tokenize

    from .test_tokenize import test_tokens

    class TestSchema(Schema):
        test_field = Field()

    test_schema = TestSchema(name="test_schema")
    value, tokens = tokenize.tokenize(test_tokens, schema=test_schema)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=test_schema)
    error_data = json.loads(exc_info.value.as_json())
    error_data["errors"].sort(
        key=lambda message: (message["start_line"], message["start_column"])
    )


# Generated at 2022-06-22 06:13:46.960248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize.test_tokens import JsonToken
    from tests.test_typesystem.test_objects import Point
    from typesystem.fields import String, Number

    class PointSchema(Schema):
        x = Number()
        y = Number()

    token = JsonToken(
        {
            "x": "1",
            "y": "2",
        },
        start_position=0,
        end_position=10,
        start_locate=0,
        end_locate=2,
    )


# Generated at 2022-06-22 06:13:57.621035
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.base import Message
    from typesystem.fields import Field
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenize import tokenize

    class InnerSchema(Schema):
        foo = Field(str)

    class OuterSchema(Schema):
        bar = Field(str, required=True)
        inner = Field(InnerSchema)

    errors = OuterSchema.validate({"inner": {"foo": "Foo"}}).errors
    assert errors == [
        Message(
            text="The field 'bar' is required.",
            code="required",
            index=("bar",),
        ),
    ]


# Generated at 2022-06-22 06:14:02.597351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, SchemaField
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tree import TreeNode, TreeRoot
    from typesystem.schemas import Schema
    from typesystem.fields import Object

    class AddressSchema(Schema):
        details = Object(properties={"number": Integer(), "street": String()})

    class PersonSchema(Schema):
        name = String()
        age = Integer(minimum=18)
        addresses = SchemaField(AddressSchema)

    doc = {
        "name": "John",
        "age": 17,
        "addresses": [{"number": 666, "street": ""}, {"number": 13, "street": "High Street"}],
    }

# Generated at 2022-06-22 06:14:12.274791
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from xml.etree import ElementTree as ET

    class MySchema(Schema):
        myfield = Field()
        myfield2 = Field()

    token = Token(value=ET.Element("myfield"), start="", end="")
    token = token.add_child(value=ET.Element("myfield2"), start="", end="")
    with raises(ValidationError):
        validate_with_positions(token=token, validator=MySchema)
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as e:
        message = e.messages()[0]
        assert message.text == 'The field "myfield" is required.'
        assert message.code == "required"
        assert message.index == ("myfield",)

# Generated at 2022-06-22 06:14:24.299396
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer

    class User(Schema):
        username = String(max_length=255)
        age = Integer()

    token = Token(
        {
            "username": "john",
            "age": "twenty-five",
            "address": "123 Main St.",
            "pet": {"cat": "Kitty"},
        },
        start=(1, 10),
        end=(1, 13),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].index == ["pet"]
    assert messages[0].start_position == (1, 11)
    assert messages

# Generated at 2022-06-22 06:14:33.742347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String

    field = String(required=True)
    token = Token(start=0, end=1, value="")

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'value' is required.",
                index=("value",),
                code="required",
                start_position=0,
                end_position=1,
            )
        ]
        assert error.full_messages() == [
            "The field 'value' is required."
        ]
    else:
        assert False, "should have raised a ValidationError"

# Generated at 2022-06-22 06:14:42.932306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.fields import String

    class UserSchema(Object):

        name = String(max_length=10)

    schema = UserSchema()

    class Token:
        def __init__(self, value):
            self.value = value

        def lookup(self, index):
            return self

        start = None
        end = None

    token = Token({"name": "John Smith"})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "Text is too long."



# Generated at 2022-06-22 06:15:02.640496
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_schema
    from typesystem.tokenize.tokens import TokenFactory, Token
    from typesystem.schemas import Schema, Object
    from typesystem.fields import (
        IntegerField,
        StringField,
        ObjectField,
        ArrayField,
        BooleanField,
        EnumField,
    )
    from typesystem.exceptions import ValidationError

    code = """
    type SomeObject {
        a: Int!
        b: String
        c: [String]
        d: Boolean
    }
    """
    tokenizer = TokenFactory(
        code=code, start_position=(1, 0), end_position=(5, 18),
    )
    tokens, _ = parse_schema(tokenizer)

    class SomeObject(Schema):
        a

# Generated at 2022-06-22 06:15:14.109729
# Unit test for function validate_with_positions
def test_validate_with_positions():

    @dataclass
    class TestField(Field):
        def validate(self, value, **kwargs):
            raise ValidationError(
                [
                    Message(
                        text="Field is required.",
                        code="required",
                        index=("key",),
                        start_position=Position(line=1, column=1, char_index=0),
                        end_position=Position(line=1, column=1, char_index=0),
                    )
                ]
            )

    @dataclass
    class TestSchema(Schema):
        value = TestField()

        def validate(self, data):
            return super().validate(data)


# Generated at 2022-06-22 06:15:25.586646
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizers import JSONTokenizer, YAMLTokenizer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()

    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize(
        """
    {
        "name": ""
    }
    """
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person())

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.start_position.line == 4
    assert message.start_position.line_

# Generated at 2022-06-22 06:15:30.937204
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import tokenize

    string = '{"x": "Hello"}'
    token = tokenize(string)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=String(required=True))



# Generated at 2022-06-22 06:15:41.421369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import trio
    from typesystem.fields import String, Array, Dict  # noqa
    from typesystem.schemas import Schema, Object  # noqa
    from typesystem.tokenize import Tokenizer, Token  # noqa
    from typesystem.tokenize.position import Position, PositionRange  # noqa
    from typesystem.tokenize.tokens import Token  # noqa

    text = json.dumps({"array": [1, "2", 3]})
    tokenizer = Tokenizer(text)
    tokens: typing.List[Token] = []
    async for token in tokenizer:
        tokens.append(token)

    schema = Schema([Dict({"array": Array(String())}), Object({"array": Array(String())})])

# Generated at 2022-06-22 06:15:52.546197
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, TokenType
    from typesystem import fields

    def assert_field_error(
        token: Token,
        field: fields.Field,
        expected: str,
        code: str = "invalid",
    ):
        try:
            validate_with_positions(token=token, validator=field)
        except ValidationError as error:
            assert error.messages() == [
                Message(
                    text=expected,
                    code=code,
                    start_position=token.start,
                    end_position=token.end,
                )
            ]
        else:
            assert False, "Did not raise ValidationError"


# Generated at 2022-06-22 06:16:00.317015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize('{"foo": 1, "bar": false}')
    validator = {"foo": Integer(), "bar": Integer()}
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    assert str(exc_info.value) == (
        "1:  The field 'bar' is required.\n"
        "2:  Expected type 'integer', found False (type: 'boolean')."
    )



# Generated at 2022-06-22 06:16:07.081098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.field import String
    from typesystem.tokenize import Token, TokenType, Position
    from typesystem.schemas import Schema

    token = Token(type=TokenType.object, value={}, start=Position(0, 0), end=Position(0, 0))
    invalid_string = validate_with_positions(token=token, validator=String(min_length=1))
    assert invalid_string == "The field 'None' is required."



# Generated at 2022-06-22 06:16:15.181805
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize({"foo": 1})
    try:
        validate_with_positions(token=token, validator=Field(required=True))
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start_position == (1, 0)
        assert error.messages()[0].end_position == (1, 1)

# Generated at 2022-06-22 06:16:26.672509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    field = String(required=True)

    token = Token(value={}, start={}, end={})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=field)
    assert [m.code for m in excifier.value.messages] == ["required"]
    assert [m.start_position for m in excifier.value.messages] == [{}]

    token = Token(
        value={
            "foo": {},
            "bar": {},
        },
        start={},
        end={},
    )

# Generated at 2022-06-22 06:16:55.125809
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:16:59.546079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestField(Field):
        pass

    field = TestField()
    token = Token(name="field")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=TestField(), token=token)

    error = exc_info.value
    assert error.messages() == [
        Message(
            code="required",
            index=["field"],
            text="The field 'field' is required.",
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-22 06:17:03.170830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Amount(Schema):
        amount = Field(type=int, required=True)

    token1 = Token(
        start=Token.StartPosition(line=1, char_index=0),
        end=Token.EndPosition(line=1, char_index=7),
        value={},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token1, validator=Amount)

    errors = exc_info.value.messages()
    assert len(errors) == 1
    assert errors[0].text == "The field 'amount' is required."



# Generated at 2022-06-22 06:17:14.343942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer(
        json.loads(
            '{"field_one": "one","field_two": "two","field_three": [{"field_four": "four"}]}'
        )
    )

    class NestedField(Field):
        def validate(self, value):
            raise ValidationError(["This field is nested"])

    class MySchema(Schema):
        field_two = NestedField()

    validator = MySchema()
    token = tokenizer.next()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
    message = exc_info.value.messages[0]

    assert message.start_position.char_index == 1

# Generated at 2022-06-22 06:17:23.325122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class UserSchema(Schema):
        username = Field(type=str)
        password = Field(type=str, required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize({"username": "joe", "password": ""})[0],
            validator=UserSchema,
        )

    message = exc_info.value.messages[0]
    assert message.text == 'The field "password" is required.'
    assert message.code == "required"
    assert message.index == ("password",)
    assert message.start_position.line == 2
    assert message.start_position.column == 2
    assert message.start_position.char_index == 15
    assert message

# Generated at 2022-06-22 06:17:32.883406
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Float

    s = Schema(properties={"username": String(), "age": Integer(), "weight": Float()})
    from json import dumps

    token = Token(
        value=dumps(
            {
                "username": "Ivan Krstić",
                "age": 42,
                "weight": 65.7,
            }
        )
    )
    validated_data = validate_with_positions(token=token, validator=s)

    assert validated_data == {
        "username": "Ivan Krstić",
        "age": 42,
        "weight": 65.7,
    }



# Generated at 2022-06-22 06:17:41.250644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser

    parser = Parser()
    token = parser.parse("{'foo': true}")
    schema_class = Schema.of({"foo": Field(primitive_type=bool)})
    instance = validate_with_positions(token=token, validator=schema_class)
    assert instance == {"foo": True}



# Generated at 2022-06-22 06:17:46.043478
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, Boolean, Array
    from typesystem.tokenize.tokens import Object, String, Number, Token

    # TODO: Write test for each field type.
    field_type = Integer()
    schema_type = Schema({"field1": field_type})

    # TODO: Write tests with non-nested fields.
    token = Object(
        {
            "field1": String("test"),
            "field2": String("test"),
            "field3": Object({"field4": String("test"), "field5": String("test")}),
        }
    )
    field_value1 = validate_with_positions(token=token.lookup(["field1",]), validator=field_type)
    field_value2 = schema_type(token).field1

    # TODO: Test

# Generated at 2022-06-22 06:17:52.602966
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import yaml

    class CatSchema(typesystem.Schema):
        name = typesystem.String()
        age = typesystem.Integer()

    class DogSchema(typesystem.Schema):
        type = typesystem.String(validators=[CatSchema])

    text = """
    type: cat
    name: Boo
    """

    token = yaml.tokenize.tokens.StreamStartToken()
    token.update(1, 2, [])
    token.update(yaml.tokenize.tokens.DocumentStartToken())
    token.update(yaml.tokenize.tokens.MappingStartToken())
    token.update(yaml.tokenize.tokens.ScalarToken(value="type"))

# Generated at 2022-06-22 06:18:03.669494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.fields import String, Integer

    class PersonSchema(Schema):
        name = String(required=True)
        age = Integer()

    token = Token.from_data(json.loads("""
    {
        "name": "Alice",
        "age": "abc"
    }
    """))

    try:
        validate_with_positions(
            token=token,
            validator=PersonSchema,
        )
    except ValidationError as error:
        messages = list(error.messages())
        assert len(messages) == 1
        message: Message = messages[0]
        assert message.text == "Value is not valid for type Integer."
        assert message.code == "invalid-type"
        assert message.start_position.line_index == 2
        assert message