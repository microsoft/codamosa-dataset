

# Generated at 2022-06-22 06:07:44.892964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass


# Generated at 2022-06-22 06:07:49.928041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_string
    from typesystem import fields
    from typesystem import schemas

    class TestSchema(schemas.Schema):
        foo = fields.String(required=True)
        bar = fields.String()

    data = "123"
    root_token = tokenize_string(data)
    assert type(root_token) == Token
    assert root_token.value == data
    assert root_token.start.char_index == 0

    try:
        validate_with_positions(token=root_token, validator=TestSchema)
    except ValidationError as e:
        assert len(e.messages()) == 2
        msg = e.messages()[0]
        assert isinstance(msg, Message)

# Generated at 2022-06-22 06:08:00.944806
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class CommentSchema(Schema):
        text = Field(str)
        rating = Field(int, required=False)
        status = Field(str, choices=["active", "deleted"])

    schema = CommentSchema()

    source = '{"text": "hello"}'
    tree = tokenize(source)
    validate_with_positions(token=tree, validator=schema)

    source = '{"text": "hello", "status": "inactive"}'
    tree = tokenize(source)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tree, validator=schema)
    assert exc_info.value.messages[0].start_position == Position(0, 26)


# Generated at 2022-06-22 06:08:09.673280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import datetime
    from typesystem import String
    from typesystem.collection import Array
    from typesystem.composite import Structure

    class DateTime(String):
        def py_validate(self, value):
            return datetime.datetime.strptime(value, "%Y-%m-%dT%H:%M:%S")

    assert DateTime()(message="2007-11-05T12:15:30")
    assert DateTime()(message="2007-11-05T12:15:30")
    assert DateTime(required=True)(message="2007-11-05T12:15:30")
    try:
        DateTime(required=True)(message="")
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-22 06:08:10.247787
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO

# Generated at 2022-06-22 06:08:18.991667
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class ContactSchema(typesystem.Schema):
        name = typesystem.String(max_length=100)
        email = typesystem.Email()
        phone_number = typesystem.String()

    class MethodSchema(typesystem.Schema):
        name = typesystem.String(max_length=100)
        arguments = typesystem.Array(items=
            typesystem.String(max_length=100)
        )
        contact = typesystem.Object(ContactSchema)

    class ApplicationSchema(typesystem.Schema):
        methods = typesystem.Array(items=MethodSchema)


# Generated at 2022-06-22 06:08:30.781680
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem import fields

    class TestSchema(Schema):
        field_name = fields.String()

    schema = TestSchema()

    # Valid data, type validation
    assert validate_with_positions(
        token=Token("field_name", "foo", start=0, end=4), validator=schema
    ) == {"field_name": "foo"}

    # Valid data, concrete field validation
    assert validate_with_positions(
        token=Token("field_name", "foo", start=0, end=4),
        validator=schema.fields["field_name"],
    ) == "foo"

    # Invalid data, type validation

# Generated at 2022-06-22 06:08:41.043045
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token([], 0, 42)

    class TestField(Field):
        def validate(self, value, context=None):
            raise ValidationError(
                messages=[Message("bad value", code="bad_value")]
            )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=TestField())

    assert excinfo.value.messages[0].start_position == (0, 0)
    assert excinfo.value.messages[0].end_position == (0, 42)

# Generated at 2022-06-22 06:08:49.294233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Document, FieldToken, ObjectToken
    from typesystem.tokenize.utils import make_error_message

    token = Document(
        [
            FieldToken(
                name="foo",
                value=FieldToken(
                    name="bar", value=ObjectToken(value={"baz": "bing"})
                ),
            )
        ]
    )

    from typesystem.fields import String
    from router import Router


# Generated at 2022-06-22 06:09:00.568118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json, resolve_json_pointer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(required=True)

    tokens = tokenize_json("{}")
    token = Token(tokens=tokens, value=resolve_json_pointer("/", tokens=tokens))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    expected = Message(
        text="The field 'name' is required.",
        code="required",
        index=("name",),
        start_position=0,
        end_position=5,
    )
    assert exc_info.value.messages() == [expected]

# Generated at 2022-06-22 06:09:11.245720
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    class Person(Schema):
        name = "string"

    schema = Person()
    token = tokenize_string('{"name": 1}')
    try:
        validate_with_positions(token=token, validator=schema)
        assert False, "Expected ValidationError"
    except ValidationError as error:
        assert error.messages()[0].start_position.char_index == 10

# Generated at 2022-06-22 06:09:18.587005
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize.tokens import StringToken

    token = StringToken(name="name", value="", start=0, end=0)

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position == 0
        assert message.end_position == 0



# Generated at 2022-06-22 06:09:28.770374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import ObjectTokenizer

    def validate(*, data):
        token = ObjectTokenizer(data=data).tokenize()
        return validate_with_positions(token=token, validator=Schema(fields={"a": Field(required=True)}))

    assert validate(data={"a": 10}) == {"a": 10}

    try:
        validate(data={})
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'a' is required.",
                code="required",
                index=["a"],
                start_position=Position(line=1, column=0, char_index=0),
                end_position=Position(line=1, column=1, char_index=1),
            )
        ]

# Generated at 2022-06-22 06:09:36.453824
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    text = '{"key": "value"}'
    token = Token.from_json(json.loads(text))

    schema = typesystem.Schema(properties={"key": typesystem.String(required=True)})

    try:
        validate_with_positions(token=token, validator=schema)
        assert False, "Expected ValidationError"
    except ValidationError as error:
        message = error.messages()[0]
        assert message.line == 1
        assert message.column == 13



# Generated at 2022-06-22 06:09:46.893935
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Text
    import typesystem
    from typesystem.tokenize.tokens import TokenType
    from typesystem.tokenize.positions import TextPosition

    field = Text(required=True)

    token = Token(
        token_type=TokenType.TEXT,
        value="hello",
        start=TextPosition(line_number=1, char_index=1),
        end=TextPosition(line_number=1, char_index=6),
    )


# Generated at 2022-06-22 06:09:56.001371
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer(
        trim_whitespace=True,
        trim_number_literals=True,
        trim_string_literals=True,
    )
    token = tokenizer.tokenize('{"foo": "bar"}')

    class ExampleSchema(Schema):
        foo = Field(type="string")

    try:
        validate_with_positions(token=token, validator=ExampleSchema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                "This field is required.",
                "required",
                ["foo"],
                token.start,
                token.start,
            )
        ]



# Generated at 2022-06-22 06:10:07.470498
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:10:16.703475
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import RawToken
    from typesystem.tokenize import tokenize

    from .utils import assert_message_equal

    from .fixtures import person_schema

    text = """
    name:
        first: "John"
        last: "Doe"
    """
    tokens = tokenize(text=text)
    assert isinstance(tokens, RawToken)
    assert isinstance(tokens.value, dict)

    try:
        validate_with_positions(
            token=tokens, validator=person_schema(required=True)
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-22 06:10:27.269073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from tests.schema_definitions import POSITIONAL_SCHEMA
    from typesystem.tokenize.token import Token
    from typesystem.validation import ValidationError
    from tests.data import DATA

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(value=DATA), validator=POSITIONAL_SCHEMA
        )
    assert len(excinfo.value.messages) == 2
    assert (excinfo.value.messages[0].start_position.line == 4)
    assert (excinfo.value.messages[1].start_position.line == 8)


# Generated at 2022-06-22 06:10:37.148174
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer, StringToken

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokenizer = Tokenizer(
        quote_char="'",
        field_name_token_type=StringToken,
    )
    token = tokenizer.parse_string(
        "Person(name: 'Guido', age: 'not_integer')"
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert (
            str(error)
            == "ValidationError: age: 'not_integer' is not an integer"
        )
        assert error.messages()[0].start_position.line == 0

# Generated at 2022-06-22 06:10:55.265843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.compat import Literal
    from typesystem.fields import Boolean, Integer, String
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize_json

    class Person(Schema):
        name = String()
        age = Integer()

    class Root(Schema):
        people = List(Person())

    def test(value):
        tokens = tokenize_json(value)
        token = tokens.top
        validate_with_positions(token=token, validator=Root)

    # JSON value has a missing group name.
    with pytest.raises(ValidationError) as exc_info:
        test(
            """
            {
              "groups": [
              ]
            }
        """
        )
    assert exc_info.value.messages[0].text

# Generated at 2022-06-22 06:11:03.504661
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object

    # Using a Field.

    class MyField(Field):
        def validate(self, value, path=None):
            if value != "test":
                raise ValidationError(messages=[Message(text="test")])

    try:
        validate_with_positions(
            token=Token(value="test", start=(1, 1), end=(1, 5)), validator=MyField()
        )
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "test"
        assert message.start_position == (1, 1)
        assert message.end_position == (1, 5)

    # Using a Schema.

    class MySchema(Schema):
        field1 = MyField()


# Generated at 2022-06-22 06:11:12.986516
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json  # noqa: F401
    from typesystem.tokenize import tokenize

    data = tokenize(
        """
    {
        'key1': 'value1',
        'key2': 'value2',
        'key3': 'value3',
    }
    """.strip()
    )
    schema = {"key1": {"key2": Field(required=True)}}
    data = validate_with_positions(token=data, validator=schema)

    with pytest.raises(ValidationError) as exc:
        data = validate_with_positions(token=data, validator=schema)
    assert exc.value.messages()[0].start_position.char_index == 23

# Generated at 2022-06-22 06:11:23.769752
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, min_value=18)

    json_string = """{"name": "Foo", "age": "Bar"}"""

    token = Token.from_json(json_string)
    try:
      validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
      messages = error.messages()
      assert len(messages) == 2
      assert messages[0].code == 'type_error'
      assert messages[0].start_position.line_number == 1
      assert messages[0].start_position.column_number == 0
      assert messages[0].end_position.line_number == 1

# Generated at 2022-06-22 06:11:31.249786
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JsonTokenizer
    from typesystem.fields import String
    from typesystem import validation_error

    schema = String("foo")
    with pytest.raises(validation_error) as error:
        validate_with_positions(
            token=JsonTokenizer("{}").get_next(), validator=schema
        )



# Generated at 2022-06-22 06:11:35.773456
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_yaml
    from typesystem.fields import Integer

    field = Integer()
    yaml = """
    foo: 1
    bar: 2
    """

    token = tokenize_yaml(yaml)
    assert validate_with_positions(token=token, validator=field) is None

    token = tokenize_yaml(yaml)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Integer(required=True))
        print(excinfo.value)

# Generated at 2022-06-22 06:11:44.043303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Song:
        title: str
        duration: float

    class Playlist:
        name: str
        songs: typing.List[Song]

    class Playlists:
        playlists: typing.List[Playlist]

    token = tokenize(Playlists, {"playlists": [{}, {}]})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Playlists)

    for message in exc_info.value.messages():
        print(message.text, message.start_position, message.end_position)

# Generated at 2022-06-22 06:11:53.359836
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String


    token = Token(
        [],
        value={
            "foo": "bar",
            "baz": [{"qux": "quux"}, {"qux": "quuz"}],
        },
    )

    schema = Schema(fields={"foo": String(), "baz": [{"qux": String()}]})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as exc:
        assert len(exc.messages()) == 1
        message = exc.messages()[0]
        assert message.text == "The field 'qux' is required."

        # Add column numbers to test
        assert message.start_position == (1, 20)
        assert message.end_position == (1, 20)



# Generated at 2022-06-22 06:11:57.103334
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class TrimmedString(Schema):

        def clean(self, value):
            value = super().clean(value)
      

# Generated at 2022-06-22 06:12:08.629445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class UserSchema(Schema):
        username = Field(str)

    json_token = Token(
        value={
            "username": {"first_name": "Bob", "last_name": "Jones"}
        },
        start=(1, 1, 10),
        end=(1, 1, 54),
    )
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=json_token, validator=UserSchema)
    errors = excinfo.value.messages()
    assert len(errors) == 1
    error = errors[0]
    assert error.text == "The field 'username' is required."
    assert error.code == "required"
    assert error.index == ("username",)
    assert error.start_position == (1, 1, 34)
   

# Generated at 2022-06-22 06:12:37.836860
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    from typesystem.schemas import String

    content = """
    <html>
      <head>
        <title>Hello world</title>
      </head>
      <body>
        <p>A paragraph</p>
      </body>
    </html>
    """
    parser = html.HTMLParser()
    document = parser.parse(io.StringIO(content))
    main_node = document.get_root_node()
    root = main_node.children[1]
    text = root.children[0].children[0].value

    class MySchema(Schema):
        text = String()

    result = validate_with_positions(token=text, validator=MySchema.fields["text"])

    assert result == "A paragraph"

    # Should return required message at the right

# Generated at 2022-06-22 06:12:47.560856
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import Lexer
    from typesystem.json import JSONSchema

    c = '{"a": 1, "b": "foo"}'
    lexer = Lexer(input=c)
    tokens = lexer.lex()
    assert len(tokens) == 1
    token = tokens[0]

    schema = JSONSchema(
        {
            "type": "object",
            "properties": {
                "a": {"type": "integer"},
                "b": {"type": "string"},
                "c": {
                    "type": "object",
                    "required": ["d"],
                    "properties": {
                        "d": {"type": "string"},
                        "e": {"type": "integer"},
                    },
                },
            },
        }
    )

# Generated at 2022-06-22 06:12:57.567838
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token_types import (
        BoolTokenType,
        CommaTokenType,
        ListTokenType,
        LiteralTokenType,
        NullTokenType,
        NumberTokenType,
        ObjectTokenType,
        StringTokenType,
        WhiteSpaceTokenType,
    )
    from typesystem.tokenize import tokenize


# Generated at 2022-06-22 06:13:06.248962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse
    from typesystem.tokenize.errors import ErrorToken

    from .path import Path

    from .examples import (
        Song,
        SongSchema,
        SongWithSchema,
        SongList,
        SongListSchema,
        SongWithSchemaList,
    )

    class String(Field):
        def validate(self, value):
            assert isinstance(value, str)
            return value

    class Integer(Field):
        def validate(self, value):
            assert isinstance(value, int)
            return value

    class SongListSchemaWithPositions(Schema):
        song_list = SongWithSchemaList(
            name="song_list", allow_null=True, *SongWithSchema.as_positional_fields()
        )


# Generated at 2022-06-22 06:13:13.347159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Record, String

    class RecordSchema(Record):
        foo = String(required=True)

    token = Token(
        value={},
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=10, char_index=10),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=RecordSchema)
    messages = exc_info.value.messages()
    assert len(messages) == 1
    assert messages[0].start_position == token.start
    assert messages[0].end_position == token.end

# Generated at 2022-06-22 06:13:24.668729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer

    class Test(Schema):
        field1: String
        field2: Integer

    try:
        validate_with_positions(
            token=Token(value={"field1": {"field2": 4}}, start=0, end=12),
            validator=Test,
        )
        raise AssertionError
    except ValidationError as error:
        assert error.messages == [
            Message(
                text='The field "field1" is required.',
                code="required",
                index=["field1"],
                start_position=0,
                end_position=12,
            )
        ]

# Generated at 2022-06-22 06:13:34.523971
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema({"foo": Field(required=True)})

    try:
        validate_with_positions(token=tokenize({}), validator=schema)
    except ValidationError as e:
        assert e.messages()[0] == Message(
            index=(),
            text="The field 'foo' is required.",
            code="required",
            start_position=Position(line_index=0, char_index=0),
            end_position=Position(line_index=0, char_index=0),
        )



# Generated at 2022-06-22 06:13:46.837503
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.tokenizer import Tokenizer

    from .utils import Position

    tokenizer = Tokenizer()
    token = tokenizer.tokenize({"foo": ""})
    field = Field(required=True)

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)

    required_error = error.value.messages[0]
    assert required_error.text == "The field 'foo' is required."
    assert required_error.start_position == Position(
        line_index=1, char_index=6, line_value='{"foo": ""}'
    )

# Generated at 2022-06-22 06:13:59.105492
# Unit test for function validate_with_positions
def test_validate_with_positions(): # noqa
    from pprint import pprint
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.tokens import (
        Token,
        BooleanToken,
        IntegerToken,
        ListToken,
        MapToken,
        NullToken,
        NumberToken,
        StringToken,
    )
    from typesystem.fields import (
        Array,
        Boolean,
        Field,
        Integer,
        List,
        Map,
        String,
    )

    class Animal(Schema):
        name = String(required=True)

    class Cat(Animal):
        is_last_cat = Boolean()

    class Person(Schema):
        name = String()
        age = Integer()

    class Family(Schema):
        father = Person(required=True)

# Generated at 2022-06-22 06:14:09.895495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class SubSchema(Schema):
        char = Field(max_length=10)

    class MySchema(Schema):
        char = Field(max_length=10)
        number = Field(type=int, required=True)
        subschema = SubSchema()

    raw = {"number": 2, "subschema": {"char": "hello"}}
    token = Token(raw)

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        errors = error.messages()
        assert len(errors) == 1
        message = errors[0]
        assert message.code == "required"
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 12
        assert message.end

# Generated at 2022-06-22 06:14:55.703480
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize import tokenize_json
    from typesystem.types import String
    from typesystem.types.object import Object

    class TestSchema(Object):
        foo = String(required=True)

    value = '{"foo": "bar", "baz": 42}'
    tokens = tokenize_json(value)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tokens, validator=TestSchema())
    assert len(excinfo.value.messages) == 1
    message = excinfo.value.messages[0]
    assert message.text == "The field 'baz' is required."
    assert message.index == [1, 2]
    assert message.start_position.index == 17

# Generated at 2022-06-22 06:15:06.256411
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class A(Field):
        pass


    # Test for a required field
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token.parse(""), validator=A(required=True)
        )
    message = error.value.messages[0]
    assert message.text == "The field 'A' is required."
    assert message.start_position.idx == 0
    assert message.end_position.idx == 0


    # Test for an error with an index
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token.parse({"a": "1"}), validator=A(
                properties={"a": A(validate=lambda x: False)}
            )
        )


# Generated at 2022-06-22 06:15:19.556374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer, String, Object
    from typesystem.tokenize.core import tokenize

    Object.registry.add(Integer)
    Object.registry.add(String)

    schema = Object({"name": String, "age": Integer(maximum=5)})

    token = tokenize(text='{ "name": "john", "age": 10 }')
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(validator=schema, token=token)


# Generated at 2022-06-22 06:15:23.919361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    from .types import API

    token = tokenize(API, {"type": "bird"})
    assert token.type == "animal"
    assert validate_with_positions(token=token, validator=AnimalField) == {"type": "bird"}

# Generated at 2022-06-22 06:15:33.632748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.tokenize import tokenize

    token = tokenize(loads("""{"age": {"name": "juan"}}"""))
    validator = Schema({"age": Field(type="integer")})

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 13
    else:
        assert False

# Generated at 2022-06-22 06:15:43.822304
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from attr import dataclass, fields_dict
    from collections import OrderedDict
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import ObjectToken

    @dataclass
    class Person:
        name: str

    def assert_validate_with_positions_raises(
        token, validator, *, expected_start, expected_end
    ):
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            assert len(error.messages) == 1
            message = error.messages[0]
            assert message.start_position.line == expected_start.line
            assert message.start_position.char_index == expected_start.char_index

# Generated at 2022-06-22 06:15:50.345382
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.tokenize.define import TokenDefn

    user_token = TokenDefn(
        name="user",
        schema={"name": str, "email": str, "age": int},
        tokenize=lambda value: [
            TokenDefn(name="name", value=value["name"]),
            TokenDefn(name="email", value=value["email"]),
            TokenDefn(name="age", value=value["age"]),
        ],
    )


# Generated at 2022-06-22 06:16:00.181681
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Tokenizer

    tokenizer = Tokenizer(
        Schema(fields={"string": Field(type="string", required=True)}),
        strict=True,
    )
    token = tokenizer.tokenize({"string": 123})

    try:
        validate_with_positions(token=token, validator=Schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 11
        assert message.end_position.line_index == 0
        assert message.end_position.char_index == 14
    else:
        assert False



# Generated at 2022-06-22 06:16:07.738286
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types
    from typesystem.tokenize.parser import parse

    token = parse('{"foo": 1}')
    schema = {"foo": types.Integer(minimum=2)}
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as err:
        message = err.messages[0]
        assert message.text == "Must be greater than or equal to 2."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 8



# Generated at 2022-06-22 06:16:17.500545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import Mapping, Scalar

    class PersonSchema(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=True)

    data = {
        "name": "curly",
        "age": "42",
    }

    doc = Mapping()
    doc.add_property(Scalar("name", "curly"), [0, 0])
    doc.add_property(Scalar("age", "42"), [1, 0])

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=doc, validator=PersonSchema())

    assert len(exc.value.messages()) == 1

# Generated at 2022-06-22 06:17:41.097738
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse import parse
    from typesystem.tokenize.typeform import typeform

    data = {"foo": [{"bar": 1}]}
    token = parse(data)

    field = typeform("foo", {"items": typeform("bar", int)})
    validate_with_positions(token=token, validator=field)

    field = typeform("foo", {"items": typeform("bar", float)})
    token = parse("[1, 1.0]")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)

    lines = [
        line.rstrip()
        for line in exc.value.as_pretty_string().strip().split("\n")
        if line.strip()
    ]
   