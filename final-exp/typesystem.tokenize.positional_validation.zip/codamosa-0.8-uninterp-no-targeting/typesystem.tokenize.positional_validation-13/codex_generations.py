

# Generated at 2022-06-22 06:08:02.129233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import String
    from typesystem.schemas import Object

    field = String(required=True)


# Generated at 2022-06-22 06:08:10.950618
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        fields={
            "name": Field(required=True),
            "age": Field(type="number", required=True),
            "gender": Field(type=Field(choices=["male", "female"])),
        }
    )
    schema.raw_schema.check(
        """
        { 
            "name": "Amen Banerjee",
            "age": "21"
        }
        """
    )
    try:
        schema.raw_schema.check(
            """
            {
                "age": "21"
            }
            """
        )
    except ValidationError as error:
        assert error.messages()[0].start_position.line_no == 2
        assert error.messages()[0].start_position.char_index == 1
       

# Generated at 2022-06-22 06:08:18.606399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean, Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    token = tokenize(
        {
            "a": 1,
            "b": "two",
            "c": False,
            "d": {
                "e": "three",
                "f": 5,
                "g": [1, "two", True],
                "h": {},
            },
            "i": [True],
        }
    )

    class TestSchema(Schema):
        a = Integer()
        b = Integer()
        c = Boolean()
        d = Schema({"e": Integer(), "f": Integer(), "g": Integer()})


# Generated at 2022-06-22 06:08:30.369908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize.test_tokens import TokenTest

    from typesystem.schemas import BaseSchema

    class TestSchema(BaseSchema):

        def __init__(self):
            super().__init__({"name": "test_schema"})

            self.add_field("test", required=True)

    token = TokenTest.from_dict({"test": 1})
    result = validate_with_positions(token=token, validator=TestSchema())
    assert result == {"test": 1}

    invalid_token = TokenTest.from_dict({"not_test": 1})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=invalid_token, validator=TestSchema())

# Generated at 2022-06-22 06:08:36.675221
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:08:46.322986
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Dict, Any

    from pygments import highlight
    from pygments.lexers import JsonLexer
    from pygments.formatters import TerminalFormatter

    from typesystem.tokenize import Tokenizer
    from typesystem.tokenize.exceptions import SCMLexingError
    from typesystem.tokenize.tokens import Token

    def validate(*, value: Any, field: Field) -> None:
        token = Token.from_python(value=value)
        validate_with_positions(token=token, validator=field)

    def validate_schema(*, value: Dict[str, Any], schema: Schema) -> None:
        token = Tokenizer().tokenize_json(json=json.dumps(value))
        validate_with_positions(token=token, validator=schema)

   

# Generated at 2022-06-22 06:08:57.385271
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema

    from .fixtures import schema_with_position_fields, sample_data

    token = Token.parse(schema_with_position_fields, sample_data)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Schema)

    assert (
        str(exc.value)
        == """The field "id" is required.
The field "type" is required.
The field "text" is required.
The field "start" is required.
The field "end" is required.
The field "sub_entry" is required.
The field "sub_entry" is required."""
    )

    assert exc.value.messages[0].start_position.line == 1
    assert exc.value.messages[0].start

# Generated at 2022-06-22 06:09:04.737379
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Address(Schema):
        city = Field(type=str, required=True)
        zipcode = Field(type=str)

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=True)
        address = Address(required=True)

    person_data = tokenize("""{
    "name": "Foo",
    "age": 17,
    "address": {
      "zipcode": "8500"
    }
  }""")

# Generated at 2022-06-22 06:09:12.793628
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.io import load
    import json

    schema = load(
        """
    type: object
    properties:
      thing:
        type: string
    required: [thing]
    """
    )

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 15},
    )

# Generated at 2022-06-22 06:09:23.531243
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, Utf8Tokenizer

    class Person(Schema):
        name = Field(str)
        meta = Field(str)

    source = "name = joe #= foo bar"
    tokenizer = Utf8Tokenizer(source)
    token = Token(tokenizer)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert len(exc_info.value.messages) == 1, "There should be only one message"
    message = exc_info.value.messages[0]
    assert message.start_position.line == 1
    assert message.start_position.char_index == 16
    assert message.end_position.line == 1
    assert message.end_position.char

# Generated at 2022-06-22 06:09:36.086514
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parse.regex import regex_parse

    invalid_json = """[
    {
        "id": 1,
        "title": "Foo",
        "body": "Bar",
        "missing": "value",
        "nested": {
            "id": 1,
            "title": "Foo",
            "body": "Bar",
            "missing": "value",
        },
    }
]
"""
    Tree = regex_parse(
        {"id": int, "title": str, "body": str, "nested": {"id": int, "title": str, "body": str}},
        on_validate=validate_with_positions,
    )

    tree = Tree(invalid_json)

# Generated at 2022-06-22 06:09:46.855265
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    import re

    class Example(typesystem.Schema):
        name = typesystem.String(required=True)
        description = typesystem.String()

    source = json.dumps({"description": "abc"})
    tree = json.loads(source)

    with pytest.raises(typesystem.ValidationError) as excinfo:
        validate_with_positions(token=Token(tree), validator=Example)
    error = excinfo.value

    # Make sure that the line/column information is accurate:
    assert error.messages()[0].text == (
        "The field 'name' is required."
    )
    assert error.messages()[0].start_position.line_number == 1
    assert error.messages()[0].start_position.char_index

# Generated at 2022-06-22 06:09:56.430244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    # Field raised a ValidationError
    field = Integer(required=True)
    token = Token(value=None, start=(1, 8), end=(1, 10))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    message = exc_info.value.messages[0]
    assert message.text == "The field 'value' is required."
    assert message.start_position.row == 1
    assert message.start_position.column == 8
    assert message.end_position.row == 1
    assert message.end_position.column == 10

    # Schema raised a ValidationError
    from typesystem.schemas import Schema

# Generated at 2022-06-22 06:10:07.512538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from tests.utils import assert_raises_with_message

    test_string = """
    {
      "name": "Ashley"
    }
    """

    tokens = tokenize(test_string)
    assert validate_with_positions(token=tokens, validator=String()) == "Ashley"

    test_string = """
    {
      "name": ""
    }
    """

    tokens = tokenize(test_string)
    with assert_raises_with_message(ValidationError, 'The field "name" must not be blank.'):
        validate_with_positions(token=tokens, validator=String())

    test_string = """
    {}
    """


# Generated at 2022-06-22 06:10:16.009561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize_string

    class ExampleSchema(Schema):
        foo = Field(required=True, type="integer", default=None)
        bar = Field(required=True, type="integer", default=None)

    try:
        validate_with_positions(
            token=tokenize_string("{}"),
            validator=ExampleSchema,
        )
    except ValidationError as error:
        message, = error.messages()
        assert message.text == "The field 'foo' is required."
        assert message.start_position.line == 0
        assert message.start_position.char_index == 0



# Generated at 2022-06-22 06:10:27.245665
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokens import RefToken

    schema = Schema(fields={"my-ref": {"type": "string"}})

    text = """<#hello>
        <#my-ref>ipsum</#my-ref>
        <#hello/>"""
    tokens = tokenize(text=text)
    token = tokens[0]
    assert isinstance(token, RefToken)
    assert token.name == "hello"
    assert token.start.row == 1
    assert token.start.col == 8
    assert token.end.row == 3
    assert token.end.col == 5
    assert len(token.children) == 1

# Generated at 2022-06-22 06:10:37.101848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    from .fields import String

    class Person(Schema):
        """A schema describing information about a person within a JSON document.
        """

        name = String(max_length=255)
        age = Integer()

    # A valid piece of JSON content.
    content = """{
        "name": "Jane",
        "age": 14
    }"""

    # Tokenize the JSON content, so we have a tree structure to validate against.
    tokens = tokenize(content)

    # Validate the tokens against the `Person` schema, this will return a
    # deserialized object (if successful), or raise a `Val

# Generated at 2022-06-22 06:10:48.861399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Any, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Leaf, Node

    schema = Schema({"name": String()})
    schema.validate = validate_with_positions
    schema.validate(Node({"name": Leaf("Jane")}))

# Generated at 2022-06-22 06:10:57.059471
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import typesystem

    class Child(typesystem.Structure):
        age: int
        name: str

    class Parent(typesystem.Structure):
        child: Child

    schema = Parent(child=Child(age=int, name=str))
    token = Token.from_python(schema.typesystem_type, {"child": {"name": "John"}})
    with pytest.raises(typesystem.ValidationError) as error:
        validate_with_positions(token=token, validator=schema.typesystem_type)

    assert str(error.value) == (
        "The field 'age' is required. "
        "The field 'name' is required."
    )


# Generated at 2022-06-22 06:11:08.195345
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Dict, Integer, String
    from typesystem.tokenize import parse, validate
    from typesystem.tokenize.tokens import WordToken

    class MySchema(Schema):
        name = String()
        ages = Dict[Integer()]

    token = parse("name: Bob, ages: {x: 10}")

    # This will raise a ValidationError
    with pytest.raises(ValidationError):
        validate(token, validator=MySchema())

    # Check that positional information is present in the exception
    try:
        validate(token, validator=MySchema())
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].text == "Missing required field 'name'."

# Generated at 2022-06-22 06:11:24.489142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import Tokenizer
    from typesystem.tokenize.tokens import LookupToken, ValueToken

    # Construct a tokenizer
    tokenizer = Tokenizer({"text":"{'a':[0,1,2]}"})

    # Use the tokenizer to produce a Token tree
    token_tree = tokenizer.tokenize()

    # Loop through the token tree, looking for LookupTokens
    for token in token_tree.walk():
        if isinstance(token, LookupToken):
            # If the token is a LookupToken, check if it has a validator which is a list
            validator = token.get_validator()

# Generated at 2022-06-22 06:11:35.209625
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                value=12,
                start=Token.Position(line_number=1, char_number=1),
                end=Token.Position(line_number=1, char_number=2),
            ),
            validator=Field(type=str),
        )
    assert exc_info.value.messages == [
        Message(
            text="Must be a string.",
            code="type_error",
            index=[],
            start_position=Token.Position(line_number=1, char_number=1),
            end_position=Token.Position(line_number=1, char_number=2),
        )
    ]

# Generated at 2022-06-22 06:11:44.432431
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str, required=True)

    assert (
        validate_with_positions(
            token=Token(value={"name": "Ada Lovelace"}, start=(1, 2), end=(1, 19)),
            validator=Person,
        )
        == {"name": "Ada Lovelace"}
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(value={}, start=(1, 1), end=(1, 1)), validator=Person,
        )
    assert excinfo.value.messages()[0].start_position == (1, 1)

# Generated at 2022-06-22 06:11:57.453281
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    schema = Schema(fields={"foo": Integer(), "bar": Integer()})
    token = Token(
        label="root",
        start=(0, 0),
        end=(1, 5),
        value={
            "foo": "10",
            "bar": 12,
            "baz": 14,
        },
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "invalid_field"
        assert message.index == ["baz"]
        assert message.start_position == (0, 12)
        assert message

# Generated at 2022-06-22 06:12:07.638822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name: str

    class Article(Schema):
        user: User

    article = Article.parse_obj(
        {
            "user": {
                "namme": "Martin Sandström",
                "email": "martin@encode.io",
            }
        }
    )
    try:
        validate_with_positions(
            token=article, validator=Article(unknown=False)
        )
    except ValidationError as error:
        assert len(error.messages) == 2
        assert error.messages[0].text == "The field 'name' is required."
        assert error.messages[1].text == 'Expected a mapping for dictionary value @ data[\'user\'].'
        assert error.messages[0].start_position == error.messages

# Generated at 2022-06-22 06:12:17.689563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)

    tokens = tokenize("{}")
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 2
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 3

# Generated at 2022-06-22 06:12:25.981650
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validate, fields, errors, to_json
    from typesystem.schemas import Object
    import json

    class Person(Object):

        name = fields.String(required=True)

    data = {"name": "Hank Hill"}
    token = Token(value=data)

    validated = validate_with_positions(validator=Person, token=token)
    assert validated == data

    token = Token(value={"name": 1})
    try:
        validate_with_positions(validator=Person, token=token)
    except ValidationError as error:
        assert len(error.messages) == 1
        assert error.messages[0].code == "invalid_type"
        assert error.messages[0].index == [
            "name"
        ]  # can't compare exact position as

# Generated at 2022-06-22 06:12:38.038174
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_validation_messages(
        value,
        validator,
        expected_messages
    ):
        message_texts = []
        try:
            validate_with_positions(token=Token(None, value), validator=validator)
        except ValidationError as error:
            message_texts = [message.text for message in error.messages()]
        assert message_texts == expected_messages

    assert_validation_messages(["1", "2"], [{"a": str}], [])
    assert_validation_messages(["1", "2"], [{"a": int}], [])
    assert_validation_messages(["1", "a"], [{"a": int}], ["Invalid type"])

# Generated at 2022-06-22 06:12:48.066865
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.fields import (
        Array,
        Boolean,
        Integer,
        Map,
        Number,
        String,
        UUID,
    )
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(max_length=8)
        age = Integer(minimum=18)
        gender = String(enum=["M", "F"])
        height = Number()
        weight = Number()
        is_cool = Boolean()

    person_token = tokenize({"name": "Bob"}, PersonSchema())


# Generated at 2022-06-22 06:12:58.406960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token, LabelToken
    token = tokenize("a: 123, b: false")
    validator = Schema.of(
        fields={"a": Field(field_type=int), "b": Field(field_type=bool)}
    )
    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=validator)
    message = info.value.messages()[0]
    assert message.code == "required"
    assert message.text == "The field 'a' is required."
    assert isinstance(message.start_position, LabelToken)
    assert isinstance(message.end_position, LabelToken)
    assert message.start_position.value

# Generated at 2022-06-22 06:13:19.384176
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=Token("a", 0, 0, 0, 0, "abcdef"), validator=Field(name="test")
        )
        assert False, "Expected a ValidationError"
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="The field 'test' is required.",
                code="required",
                index=["test"],
                start_position=0,
                end_position=0,
            )
        ], "Did not extract correct position"

# Generated at 2022-06-22 06:13:28.977336
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer, String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class UserSchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=18)

    json = '{"name": "example", "age": 16}'
    errors = []
    for error in UserSchema.iter_errors(tokenize(json)):
        errors.extend(error.messages())

    assert len(errors) == 1
    assert errors[0].text == "Must be at least 18."
    assert errors[0].start_position.line_number == 1
    assert errors[0].start_position.char_index == 19



# Generated at 2022-06-22 06:13:36.301136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Employee(Schema):
        name = Field(String, required=True)
        age = Field(Integer, required=True)
        department = Field(String, required=True)

    token = tokenize(
        value={"age": "foo", "name": "Eric", "department": "Engineering"},
        schema=Employee,
    )
    try:
        validate_with_positions(token=token, validator=Employee)
    except ValidationError as error:
        messages = sorted(
            error.messages,
            key=lambda m: m.start_position.char_index,  # type: ignore
        )
        assert messages[0].start_position.char_index == 13
        assert messages[0].end_position.char_index == 17
       

# Generated at 2022-06-22 06:13:47.689787
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import simple_tokenize

    tokens = simple_tokenize(
        '{"a": 100, "b": "text", "c": {"x": "foo"}, "d": null, "f": false}'
    )

    class ExampleSchema(Schema):
        f = "number"
        b = Field(type="text")
        c = Field(type="object", fields={"x": "text"})
        e = Field(type="text", required=False)
        d = Field(type="boolean", required=False)
        g = Field(type="text", required=False)


# Generated at 2022-06-22 06:13:59.588127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def assert_validate_with_positions_error(
        source,
        validator,
        expected_message_text,
        expected_message_code,
        expected_message_index,
        expected_message_start_line,
        expected_message_start_column,
        expected_message_end_line,
        expected_message_end_column,
    ):
        try:
            token = Token.parse(source)
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            assert len(error.messages()) == 1
            message = error.messages()[0]
            assert message.text == expected_message_text
            assert message.code == expected_message_code
            assert message.index == expected_message_index

# Generated at 2022-06-22 06:14:05.657090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.base import Schema

    class Person(Schema):
        name = "string"
        age = "integer"

    token = Token({"name": "John", "age": 27})
    cleaned_data = validate_with_positions(token=token, validator=Person())

    assert cleaned_data == {"name": "John", "age": 27}

# Generated at 2022-06-22 06:14:13.334639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    Ensure ValidationError is returned with positional information
    """
    import json
    import unittest
    import typesystem

    class IntSchema(typesystem.Schema):
        integer = typesystem.Integer()

    class NestedSchema(typesystem.Schema):
        required_field = typesystem.String(required=True)
        nested = typesystem.Nested(IntSchema)

    test_data = json.dumps({"nested": {"integer": "Invalid"}})
    token = Token(value=json.loads(test_data))
    schema = NestedSchema()

    try:
        schema.validate(token.value)
    except ValidationError:
        pass


# Generated at 2022-06-22 06:14:25.171306
# Unit test for function validate_with_positions
def test_validate_with_positions():

    def assert_message(msg, pos):
        assert isinstance(msg, Message)
        assert msg.start_position.char_index == pos
        assert msg.end_position.char_index == pos

    from typesystem.tokenize.tokens import CharToken, LineToken
    from typesystem.fields import String

    token = CharToken(value="foobar", start=4, end=4)
    value = validate_with_positions(token=token, validator=String(min_length=10))
    assert value == "foobar"
    assert token.validate_messages()[
        -1
    ].start_position.char_index == 4
    assert token.validate_messages()[
        -1
    ].end_position.char_index == 4


# Generated at 2022-06-22 06:14:35.188164
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.schemas import Dict
    from typesystem.fields import Integer

    schema = Dict(
        {"a": Integer(), "b": Integer(), "c": Integer()}, required=["a"]
    )

    import json
    import pytest
    from typesystem.tokenize import tokenize, token_types

    result = tokenize(json.dumps({"a": 2, "b": "wrong", "c": 3}))
    assert result[1].token_type == token_types.STRING_VALUE
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=result[1], validator=schema.fields["b"])
    assert str(exc.value) == "errors: 1"

# Generated at 2022-06-22 06:14:46.340232
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenize
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.fields import Dict, String
    from typesystem import ValidationError

    # This tests for a bug when adding positional information to error messages.
    # The root problem is that the field structure of the schema does not match
    # the field structure of the input data.  This can occur if a field is an
    # ObjectField that draws its structure from another field.  For example,
    # the `items` field in a `ListField` is an `ObjectField`.
    tokenizer = Tokenize()
    text = '{"a": {"x": "foo"}, "b": {"y": "bar"}}'
    tokens = tokenizer.tokenize(text)
    assert len(tokens) == 1

# Generated at 2022-06-22 06:15:26.709220
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema.of({"number": Field(int)})
    source = b'{"number": "a"}'
    token = Token.from_source(source=source)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as validation_error:
        message = validation_error.messages[0]
        assert message.code == "invalid"
        assert message.text == "Expected a valid integer."
        assert message.index == ["number"]
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 9
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 10
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-22 06:15:32.417091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_schema import ComplexTestSchema

    schema = ComplexTestSchema()

    token = Token(
        {"name": "abc"},
        position=None,
        start={"line": 1, "column": 0, "char_index": 0},
        end={"line": 1, "column": 4, "char_index": 4},
    )

    assert validate_with_positions(token=token, validator=schema).data == {
        "name": "abc"
    }

    token = Token(
        {},
        position=None,
        start={"line": 1, "column": 0, "char_index": 0},
        end={"line": 1, "column": 0, "char_index": 0},
    )


# Generated at 2022-06-22 06:15:42.534572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize.tokens import Objects
    from typesystem.tokenize.positions import Position

    class Tokenizer(typesystem.Schema):
        first = typesystem.Boolean()
        second = typesystem.Boolean()

    objects = Objects()
    start = Position(objects, line=1, column=1, char_index=0)
    first_end = Position(objects, line=1, column=5, char_index=4)
    second_start = Position(objects, line=1, column=6, char_index=5)
    second_end = Position(objects, line=1, column=10, char_index=9)
    end = Position(objects, line=1, column=11, char_index=10)

# Generated at 2022-06-22 06:15:48.760833
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import generate_tokens
    from typesystem.tokenize.tokens import Token

    tokenizer = generate_tokens(
        "fruits",
        {
            "name": "fruits",
            "type": "array",
            "items": {"type": "string", "minLength": 1},
        },
    )
    token = next(tokenizer)
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=String(min_length=1)) == [
        "a",
        "b",
        "c",
    ]



# Generated at 2022-06-22 06:16:00.729994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, fields
    from typesystem.tests import Person

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=P("s/0"),
            validator=fields.JSON(Person),
        )

    messages = exc_info.value.messages


# Generated at 2022-06-22 06:16:09.785978
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema, fields
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.types import TokenType

    person_schema = Schema(
        {"name": fields.String(), "age": fields.Integer(), "address": fields.String()}
    )

    token = Token(token_type=TokenType.object, value={"name": "Dave", "age": "30"})
    try:
        validate_with_positions(token=token, validator=person_schema)
    except ValidationError as e:
        assert e.messages()[0].start_position.line_number == 0
        assert e.messages()[0].start_position.char_index == 12
        assert e.messages()[0].end_position.line_number

# Generated at 2022-06-22 06:16:21.833706
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.base import Position, Tokenizer

    import yaml

    tokenizer = Tokenizer(
        token_class=lambda x: x,
        start_position_class=lambda x: Position(x, 0, 0, 0),
        end_position_class=lambda x: Position(x, x, 0, 0),
    )
    token = tokenizer.tokenize(yaml.load("""
a:
  b: 4
  c:
    - d: !str 5
      e: null
"""))

    class Validator(Schema):
        a = {"b": "integer"}

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(
            token=token.lookup("a"), validator=Validator()
        )
    assert exc.value.mess

# Generated at 2022-06-22 06:16:30.701845
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        id = Integer(required=True)

    token = Token(value={"id": "XXX"}, start=Position(line=0, column=0), end=Position(line=0, column=16))
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

    message = excinfo.value.messages[0]
    assert message.text == "Value 'XXX' is not valid type 'integer'."
    assert message.start_position == Position(line=0, column=4)
    assert message.end_position == Position(line=0, column=7)

# Generated at 2022-06-22 06:16:42.339705
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object
    from typesystem.tokenize.parsers import parse_token

    schema = Object({"name": Field(required=True)})

    value = parse_token({"name": None})
    with pytest.raises(ValidationError) as context:
        validate_with_positions(token=value, validator=schema)
    messages = [m.as_dict() for m in context.value.messages]

# Generated at 2022-06-22 06:16:54.246733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        name="name",
        value="Foo",
        start=(1, 1),
        end=(1, 4),
        children=[],
        lookup=lambda path: "OK"
    )

    class MyField(Field):
        def validate(self, value):
            raise ValidationError({"name": "Value is invalid!"})

    field = MyField()

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            {
                "text": "Value is invalid!",
                "code": "",
                "index": ["name"],
                "start_position": (1, 1),
                "end_position": (1, 4),
            }
        ]

