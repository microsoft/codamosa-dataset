

# Generated at 2022-06-22 06:08:09.410570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Token
    from typesystem.fields import List
    from typesystem.schemas import Schema
    from typesystem.structures import Dict
    from typesystem.types import Integer

    class FooSchema(Schema):
        foo = List(Integer())
        bar = Dict({"a": Integer(), "b": Integer()})

    schema = FooSchema()
    token = Token({"foo": [1, 2, 3], "bar": {"a": 1, "b": 2}}, "foo.bar.a")

    value = validate_with_positions(token=token, validator=schema)
    assert value == {"foo": [1, 2, 3], "bar": {"a": 1, "b": 2}}


# Generated at 2022-06-22 06:08:17.022899
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import pytest
    from typesystem.tokenize.tokenize import tokenize

    class Movie(typesystem.Schema):
        name = typesystem.String(max_length=32)

    movie = Movie()
    pytest.raises(
        ValueError,
        validate_with_positions,
        token=tokenize('{"name": "The Shawshank Redemption"}'),
        validator=movie,
    )
    validate_with_positions(
        token=tokenize('{"name": "The Shawshank Redemption."}'),
        validator=movie,
    )
    pytest.raises(ValueError, validate_with_positions, token=tokenize(""), validator=movie)

# Generated at 2022-06-22 06:08:26.783021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token=Token(value=None), validator=typing.Union[Field, typing.Type[Schema]]
        )
    messages = error.value.messages
    message = messages[0]
    assert message.text == "The field None is required."
    assert message.start_position.row_index == 0
    assert message.start_position.column_index == 0
    assert message.start_position.char_index == 0
    assert message.end_position.row_index == 0
    assert message.end_position.column_index == 0
    assert message.end_position.char_index == 4


# Generated at 2022-06-22 06:08:35.645622
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    @pytest.mark.parametrize(
        "expected,value",
        [
            (["int"], [1, 2, 3]),
            (["int"], [1, "2", 3]),
            (["str"], ["1", 2, 3]),
        ],
    )
    def test_list_of(expected, value):
        Token = collections.namedtuple("Token", ["value", "start", "end"])
        token = Token(value=value, start=0, end=100)
        validator = typesystem.List(items=typesystem.Integer())
        with pytest.raises(ValidationError) as error:
            validate_with_positions(token=token, validator=validator)

        messages = error.value.messages

# Generated at 2022-06-22 06:08:45.850247
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import String, Integer, Object
    from typesystem.tokenize.tokenizer import Tokenizer

    class PersonSchema(Schema):
        name = String()
        phone = String()
        age = Integer()

    tokenizer = Tokenizer(PersonSchema())

    text = """
    first_name: "Rick"
    last_name: "Sanchez"
    age: 70
    """
    token = tokenizer.tokenize(text)
    try:
        validate_with_positions(
            token=token, validator=PersonSchema(stop_on_failure=False)
        )
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position == (1, 12)
        assert error.messages()

# Generated at 2022-06-22 06:08:56.943597
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(
        {
            "name": Field(required=True),
            "data": Field(required=True),
        }
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(
            token={}, validator=schema,
        )
    error = error.value
    assert error.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=None,
            end_position=None,
        ),
        Message(
            text="The field 'data' is required.",
            code="required",
            index=("data",),
            start_position=None,
            end_position=None,
        ),
    ]

# Generated at 2022-06-22 06:09:01.867814
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_tokenize import Tokenizer

    tokenizer = Tokenizer(
        schema={"type": "object", "properties": {"foo": {"type": "string"}}}
    )
    token = tokenizer.tokenize(b'{"foo": 42}')
    token = token.lookup(["foo"])
    try:
        validate_with_positions(token=token, validator=Field(type="string"))
    except ValidationError as error:
        assert error.messages()[0].text == "Expected a string."
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line_index == 1

# Generated at 2022-06-22 06:09:10.197568
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser

    schema = {
        "name": {"type": "string", "required": True},
        "age": {"type": "integer", "required": True},
    }
    parser = Parser(schema)
    token = parser.parse({"name": "foo"})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Schema(schema))
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=token.get_field("age"))

# Generated at 2022-06-22 06:09:17.511131
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser.parser import parse_schema
    from typesystem.parser.lexer import lex_string, tokenize
    from typesystem.parser.types import FieldDefinitionNode
    import pytest

    schema_str = """
    type Person {
        name: String,
        age: Integer
    }

    type PersonReference {
        id: Integer
    }
    """

    node = parse_schema(schema_str)

    lexer = lex_string(schema_str)
    tokens = tokenize(lexer=lexer)
    type_def_nodes = []

# Generated at 2022-06-22 06:09:28.199965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token  # type: ignore
    from typesystem import fields  # type: ignore

    token = Token.tokenize("{'foo': 'bar'}")

    class MyField(fields.Field):
        def validate(self, value):
            return value

    obj: typing.Union[Field, typing.Type[Schema]] = MyField()
    validate_with_positions(token=token, validator=obj)

    class MySchema(fields.Schema):
        foo = fields.String()

    obj = MySchema()
    validate_with_positions(token=token, validator=obj)


# Generated at 2022-06-22 06:09:37.852643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Structure, String
    from typesystem.tokens import Token

    token = Token(
        value={"hello": "world"},
        start={"line": 0, "char_index": 0},
        end={"line": 0, "char_index": 19},
    )

    class MySchema(Schema):
        value = String(required=True)

    schema = MySchema()
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    message = excinfo.value.messages[0]
    assert message.start_position == {"line": 0, "char_index": 0}
    assert message.end_position == {"line": 0, "char_index": 19}

# Generated at 2022-06-22 06:09:47.129655
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Field, IntegerField

    class User(Schema):
        name = Field(str)
        age = IntegerField(min_value=12)

    user = {
        "name": "John Smith",
        "age": 25,
    }

    user_token = Token(user)
    validated_user = validate_with_positions(
        token=user_token, validator=User()
    )
    assert validated_user == {
        "name": "John Smith",
        "age": 25,
    }

    user = {
        "age": 25,
    }

    user_token = Token(user)

# Generated at 2022-06-22 06:09:53.157335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.utils import get_yaml_schema
    from typesystem import Boolean
    from typesystem.fields import Field

    schema = get_yaml_schema()
    token = schema.tokenize("""
    - description: First item
      title: First title
      value: true
    - description: Second item
      value: 123
    - description: Third item
      value: false""")

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = [str(message) for message in error.messages()]
        assert messages == [
            "Failed to validate title (not all items have titles).",
            "The field value is required.",
        ]

    title_field = schema.fields["title"]
    validate_with_positions

# Generated at 2022-06-22 06:10:05.823676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.rules import STRING, WS
    from typesystem.tokenize.strategies import basic

    tokenizer = tokenize.Tokenizer(STRING, WS, tokenize.Sentence(basic.type_name))
    field = Field(name="FIELD", description="")
    assert field is not None, "field is not defined"
    [string, _] = tokenizer.tokenize("{}")
    assert string is not None, "string is not defined"
    assert validate_with_positions(token=string, validator=field) == "{}"

    [string, _] = tokenizer.tokenize("{'field': 'hello'}")
    assert string is not None, "string is not defined"

# Generated at 2022-06-22 06:10:16.753864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem_tokenize import Tokenizer
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema, structure

    schema = Schema(structure({"name": String(), "age": Integer()}))

    # Success, no errors
    data = {"name": "John", "age": 31}
    token = Tokenizer.tokenize(data)
    validate_with_positions(token=token, validator=schema)

    # Fail, required field
    data = {"name": "John"}
    token = Tokenizer.tokenize(data)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert excinfo.value.messages()[0].code == "required"
    assert excinfo

# Generated at 2022-06-22 06:10:27.353988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token.parse('{"foo": "bar", "bar": "baz"}')
    schema = Schema({"foo": Field(required=True), "bar": Field(required=True)})
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)

    assert error.value.messages() == [
        Message(
            start_position=Position(line=0, char_index=9),
            end_position=Position(line=0, char_index=15),
            index=["foo"],
            code="required",
            text="The field 'foo' is required.",
        )
    ]

# Generated at 2022-06-22 06:10:37.052003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import (
        Field,
        Boolean,
        String,
        Integer,
        Float,
        Array,
        Object,
    )
    from typesystem.tokenize.tokens import Token

    name = Field(type=String)
    age = Field(type=Integer)

    class Person(Schema):
        name: Field
        age: Field

    person = Person()

    token = Token(value={"name": "Bob", "age": "26"})

    try:
        validate_with_positions(token=token, validator=person)
    except ValidationError as error:
        assert [m.text for m in error.messages()] == [
            'The field "age" must be an integer.'
        ]

# Generated at 2022-06-22 06:10:48.817732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from io import StringIO
    import sys
    import traceback
    import typesystem
    import typesystem.tokenize.lexers

    example = '{"name": "foo", "age": "42"}'
    source = typesystem.tokenize.lexers.JsonLexer(source=StringIO(example)).tokenize()

    schema = typesystem.Schema(
        fields={"age": typesystem.Integer(minimum=0, maximum=100)}
    )

    try:
        validate_with_positions(token=source, validator=schema)
    except Exception as error:
        exception, *separator, stacktrace = traceback.format_exception(
            type(error), error, error.__traceback__
        )

# Generated at 2022-06-22 06:10:56.148408
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("Foo { name: '' }")
    schema = Schema({"name": Field(required=True)})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position == Position(line=1, column=5)
        assert error.messages()[0].end_position == Position(line=1, column=6)
        assert error.messages()[0].text == (
            "The field 'name' is required. Got: ''"
        )
    else:
        assert False



# Generated at 2022-06-22 06:11:07.029928
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.tokens import Token
    from typesystem.types import String
    import typesystem

    token = Token(
        value={
            "name": "John Smith",
            "address": {
                "street": "52 Example Street",
                "city": "Exampletown",
            },
            "mistakes_in_the_document": [
                {"text": "x", "position": {"line": 0, "char": 1}},
                {"text": "y", "position": {"line": 0, "char": 2}},
                {
                    "text": "z",
                    "position": {"line": 1, "char": "10"},  # This can be converted to integers
                },
                # This object has no position => it will be ignored
                {"text": "a"},
            ],
        }
    )

# Generated at 2022-06-22 06:11:23.073044
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema_spec = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "children": {
                "type": "array",
                "items": {"type": "integer"},
            },
            "cars": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "brand": {"type": "string"},
                        "year": {"type": "integer"},
                    },
                    "required": ["brand", "year"],
                },
            },
        },
        "required": ["name", "age", "children", "cars"],
    }

    Schema = create_schema_class(schema_spec)


# Generated at 2022-06-22 06:11:34.493359
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lexer

    from typesystem.base import ValidationError
    from typesystem.fields import CharField

    import typesystem

    query = """
        query GetHero {
          hero {
            name
            height(unit: METER)
          }
        }
    """
    document = lexer.tokenize(query)

    Hero = typesystem.create_type("Hero", {"name": CharField()})
    Hero2 = typesystem.create_type("Hero", {"name": CharField(required=True)})

    document.lookup("definitions", 0, "selectionSet", "selections", 0, "name")

    Hero.validate(document)
    validate_with_positions(
        token=document, validator=Hero,
    )


# Generated at 2022-06-22 06:11:45.105433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Object, String
    from typesystem.tokenize.tokens import (
        DocumentToken,
        ItemToken,
        KeyToken,
    )

    class Person(Object):
        age = String(required=True)


# Generated at 2022-06-22 06:11:52.937563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token_schema = Schema(fields={"foo": Field(type=str, required=True)})
    token = tokenize(
        b'{"foo": "bar"}', schema=token_schema
    )  # type: ignore

    validate_with_positions(token=token, validator=token_schema)

# Generated at 2022-06-22 06:12:01.882351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Dict
    from typesystem.tokenize import tokenize
    from typesystem.strings import String

    schema = Dict(fields={"name": String(max_length=10)}, required=["name"])

    token = tokenize("""{}""")

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert (
            error.messages()[0].text
            == "The field 'name' is required. (position: row 1, column 2)"
        )
    else:
        raise

# Generated at 2022-06-22 06:12:09.077026
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MyType(Field):
        pass

    class MySchema(Schema):
        myfield = MyType()

    token = Token.from_python(None)
    try:
        validate_with_positions(token=token, validator=MyType())
    except ValidationError as ve:
        assert len(ve.messages) == 1
        assert ve.messages[0].start_position == (0, 0)
        assert ve.messages[0].end_position == (0, 0)

    token = Token.from_python([{}, [], 1])
    try:
        validate_with_positions(token=token, validator=MySchema())
    except ValidationError as ve:
        assert len(ve.messages) == 2

# Generated at 2022-06-22 06:12:18.199735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer, Object

    class Item(Schema):
        rating = Integer()
        name = String()

    class List(Schema):
        items = Object(properties={"item": Item()})

    from typesystem.tokenize import tokenize_json

    tokens = tokenize_json({"item": {"name": "", "rating": "one"}})
    token = tokens[0]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=List)

    assert exc_info.value.messages[0].start_position == (1, 2)
    assert exc_info.value.messages[0].end_position == (1, 2)
    assert exc_info.value.messages[1].start_position

# Generated at 2022-06-22 06:12:18.593214
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-22 06:12:26.082135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.utils import get_source_location
    from typesystem.tokenize.tokens import Token

    class TestField(Field):
        def validate(self, value):
            if value != "value":
                raise ValidationError(["not value"])

    field = TestField()

    token = Token(
        kind="value",
        value="value",
        start=get_source_location(__file__, __name__, 3),
        end=get_source_location(__file__, __name__, 3),
    )

    validate_with_positions(token=token, validator=field)

    token.value = "not value"
    token.start = get_source_location(__file__, __name__, 7)

# Generated at 2022-06-22 06:12:38.128911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Position, Token
    from typesystem.tokenize import tokenize_schema
    from typesystem.tokens import Literal
    from typesystem.fields import Field

    schema = tokenize_schema(
        {"text": {"type": "string"}, "number": {"type": "integer"}}
    )

    token = tokenize_schema({"text": "Test", "number": 1.5})
    messages = []
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        messages = sorted(
            messages, key=lambda m: m.start_position.char_index  # type: ignore
        )


# Generated at 2022-06-22 06:12:52.014370
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PositionalSchema(Schema):
        required_key: str

    assert validate_with_positions(
        token=Token.from_dict({"not_required_key": "val"}), validator=PositionalSchema,
    ) == {"not_required_key": "val"}

    with pytest.raises(ValidationError) as exc:
        assert validate_with_positions(
            token=Token.from_dict({"not_required_key": "val"}),
            validator=PositionalSchema,
        ) == {"not_required_key": "val"}

# Generated at 2022-06-22 06:13:04.102168
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.positions import Position
    from typesystem.tokenize.tokens import Array, Object
    from typesystem.tokenize.tokens import String as StringToken
    from typesystem.tokenize.tokens import Tokenizer

    from .test_tokens import test_schema

    # Test a field that is required in a tokenized array.
    token = Tokenizer(test_schema).tokenize({})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=test_schema,
        )

    assert len(exc_info.value.messages) == 1
    assert exc_info.value.messages[0].code == "required"

# Generated at 2022-06-22 06:13:15.657487
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize import tokenize
    from typesystem import validators

    class UserSchema(Schema):

        class Meta:
            strict = True

        name = validators.String()

    schema = UserSchema()
    input_ = r'{"data": null}'
    tree = tokenize(input_)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=tree, validator=schema)

    error = excinfo.value
    for message in error.messages():
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 10

# Generated at 2022-06-22 06:13:27.063675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parse.ast import Access, Literal
    from typesystem.tokenize.tokens import AccessToken, Token, ValueToken
    from typesystem.tokenize.positions import Position

    class MySchema(Schema):
        title = Field(type=str, required=True)


# Generated at 2022-06-22 06:13:35.960565
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(properties={"name": {"type": "string"}})
    token = Token(
        value={
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
        },
        start={"line": 0, "column": 0},
    )
    errors = []
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        errors = error.messages()

    assert len(errors) == 1
    error = errors[0]
    assert error.text == "The field 'name' is required."
    assert error.code == "required"
    assert error.start_position == {"line": 0, "column": 12}

# Generated at 2022-06-22 06:13:47.547589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test validator types which don't support positions
    class MySchema(Schema):
        my_field = str
    with pytest.raises(
        TypeError, match="Schemas must have a position_info_type attribute"
    ):
        validate_with_positions(
            token=Token(value=[{}]),
            validator=MySchema,
        )

    class MyStringField(Field):
        pass
    with pytest.raises(
        TypeError, match="Fields must have a position_info_type attribute"
    ):
        validate_with_positions(
            token=Token(value=""),
            validator=MyStringField(),
        )

    # Test schema
    schema = MySchema()
    schema.position_info_type = Token

# Generated at 2022-06-22 06:13:48.563903
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:13:58.029213
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        field = Field(str)

    text = '{"field": "foo"}'
    token = Token.parse(text)
    validate_with_positions(token=token, validator=MySchema)

    text = '{"not_field": "foo"}'
    token = Token.parse(text)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=MySchema)

    # TODO: update this test when type checking is available in mypy
    for message in excinfo.value.messages:
        assert isinstance(message, Message)
        assert isinstance(message.start_position, Position)

# Generated at 2022-06-22 06:14:08.113670
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.primitives import String
    from typesystem.tokenize.parser import parse

    field = String(required=True)
    token = parse("{}", schema={'foo': field})

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        expected = "The field 'foo' is required."
        assert message.text == expected
        assert message.code == 'required'
        assert message.start_position == (1, 2)
        assert message.end_position == (1, 2)

# Generated at 2022-06-22 06:14:19.795589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import DataToken

    class IntegerField(Field):
        def validate(self, value):
            try:
                return int(value)
            except ValueError:
                raise ValidationError(text="Not an integer")

    class IntegerSchema(Schema):
        integer = IntegerField()

    token = DataToken(value={"integer": "345"})
    try:
        validate_with_positions(token=token, validator=IntegerSchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "Not an integer"
        assert message.code == "invalid"
        assert message.start_position.line == 1
        assert message.start_position.col == 12
        assert message.end_position.line == 1
       

# Generated at 2022-06-22 06:14:42.515355
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Define a type
    class Person(Schema):
        name = Field(type=str)
        surname = Field(type=str)

    # Make a token
    token = Token(type=Person, value=dict(name="peter", surname=None), file="test.txt")

    # Assert no error is raised
    validate_with_positions(token=token, validator=Person)

    # Assert error with positions is raised
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

    # Assert message has correct code
    code = exc.value.messages[0].code
    assert code == "required"

    # Assert message has correct text
    text = exc.value.messages[0].text

# Generated at 2022-06-22 06:14:54.308347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    import pytest

    from typesystem.schemas import Schema
    from typesystem.tokenize.tokenizers import JsonTokenizer
    from typesystem.tokenize.tokens import Token

    source = "{'a': 'b'}"

    class SimpleSchema(Schema):
        a = Field(type="string")

    token = JsonTokenizer(source).tokenize()
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=SimpleSchema)

    messages = excinfo.value.messages()
    assert messages == [Message(text="The field 'a' is required.", code="required")]

    source = "{'a': 'b', 'c': 'd'}"
    token = JsonTokenizer(source).tokenize

# Generated at 2022-06-22 06:15:04.717835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Any
    from pytest import raises
    from typesystem import schemas, fields
    from typesystem.tokenize.source import Source
    from typesystem.tokenize.tokens import DocumentToken, Token

    schema = schemas.Schema(fields={"test": fields.Text(required=False)})
    data = {"test": 1}

    source = Source(
        data=data,
        filename="test.json",
        tokenizer=schema.get_tokenizer(),
    )
    document_token = DocumentToken(source=source)
    token = next(document_token)  # type: Token

    with raises(ValidationError):
        validate_with_positions(
            token=token,
            validator=schema,
        )
    # do this again to make sure we are still at line 1


# Generated at 2022-06-22 06:15:14.448143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.tokenize.parser import TokenParser

    token_parser = TokenParser(
        {
            "a": Integer(),
            "b": String(),
        }
    )
    result = token_parser.parse(
        '{"a": "not_an_int", "b": 123, "d": "not_allowed"}', "<string>"
    )
    try:
        validate_with_positions(token=result, validator=token_parser)
    except ValidationError as exc:
        sorted_messages = sorted(exc.messages(), key=lambda m: m.start_position.char_index)
        first_message = sorted_messages[0]
        assert first_message.text == '"not_an_int" is not a valid integer.'

# Generated at 2022-06-22 06:15:21.240360
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class TestField(Field):
        def validate(self, value):
            raise ValidationError(["hello"])

    from typesystem.tokenize.parser import tokenize

    # Test that the simple case works.
    with pytest.raises(ValidationError, match="hello"):
        validate_with_positions(
            token=tokenize("""{"foo": "bar"}"""), validator=TestField()
        )



# Generated at 2022-06-22 06:15:33.196103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, Tokenizer
    from typesystem.tokenize.token_types import NumberTokenType

    from typesystem.fields import NumberField

    tokenizer = Tokenizer(token_types=[NumberTokenType])
    tokens = tokenizer.parse("1 2")
    token = Token(value=tokens, raw_value="1 2")

    try:
        validate_with_positions(token=token, validator=NumberField())
    except Exception:  # TODO: handle this better / more specific
        pass

    message = validate_with_positions.__annotations__
    assert message.get("token") == Token
    assert message.get("validator") == typing.Union[Field, typing.Type[Schema]]



# Generated at 2022-06-22 06:15:33.780879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:15:43.964750
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:15:49.223723
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Field(type="string")
    token = Token(
        value=None,
        start_position=Position(line_index=0, char_index=0),
        end_position=Position(line_index=0, char_index=3),
    )

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=schema)
    assert error.value.messages[0].start_position.line_index == 0
    assert error.value.messages[0].start_position.char_index == 0



# Generated at 2022-06-22 06:16:00.718244
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import doctest
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.lexers.auto_lexer import AutoLexer
    from typesystem.tokenize.parser import TypedJSONParser
    from typesystem.tokenize.parsers import json_schema_parser
    from typesystem.tokenize.position import Position
    from typesystem.types import String
    from typesystem import format

    schema = String(max_length=5)

    lexer = AutoLexer(
        lexers=[
            Lexer(chars="alphanumeric", token_type="alphanumeric"),
            Lexer(chars=" ", token_type="whitespace"),
        ]
    )


# Generated at 2022-06-22 06:16:21.611442
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class UserSchema(Schema):
        username = Field(required=True)

    input = "{username: 'bob'}"
    tokens = tokenize(input)
    validate_with_positions(token=tokens, validator=UserSchema)



# Generated at 2022-06-22 06:16:30.701672
# Unit test for function validate_with_positions

# Generated at 2022-06-22 06:16:42.287752
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import uuid

    from typesystem.fields import Array, String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    data = {
        "id": str(uuid.uuid4()),
        "name": "foobar",
        "tags": ["one", "two", "three"],
    }
    serialized = json.dumps(data)
    token = Token.deserialize(serialized)

    class ExampleSchema(Schema):
        name = String(max_length=8)
        tags = Array(String())

    container = ExampleSchema.validate(token.value)
    try:
        container.validate()
    except ValidationError:
        assert False

    del container["name"]

# Generated at 2022-06-22 06:16:54.149513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from tests.test_validators import validator

    token = Token.from_value(
        {"a" : {"b" : {"c" : {"d" : ["e"]}, "b2": "12"}}},
        start={"line": 1, "col": 4},
        end={"line": 2, "col": 4},
    )
    # d is not an integer
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)


# Generated at 2022-06-22 06:17:01.499127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import BaseSchema, String
    from typesystem.tokenize.token_types import TokenType
    from typesystem.tokenize.tokens import SimpleToken

    class TestSchema(BaseSchema):
        field = String()

    schema = TestSchema()
    token = SimpleToken(
        TokenType.OBJECT,
        {"field": "value"},
        start={"line": 1, "char_index": 11},
        end={"line": 1, "char_index": 19},
    )
    try:
        validate_with_positions(token=token, validator=schema.field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 11}

# Generated at 2022-06-22 06:17:08.234223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(start={"char_index": 20}, end={"char_index": 30})
    error = validate_with_positions(token=token, validator=Field(required=True))
    assert isinstance(error, ValidationError)
    assert error.messages()[0].text == "The field None is required."
    assert error.messages()[0].start_position == {"char_index": 20}
    assert error.messages()[0].end_position == {"char_index": 30}

# Generated at 2022-06-22 06:17:19.890919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.fields import String
    from typesystem.tokenize.tokenize import tokenize, tokenize_values

    class MySchema(Schema):
        name = String()
        value = String()

    tokens = tokenize(  # type: ignore
        {"name": "test field name", "value": "test field value"}
    )

    assert len(tokens) == 1

    token = tokens[0]

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line_index == 0
        assert message.start_position.char_index == 16
        assert message.end_position.line_index == 0
        assert message.end_

# Generated at 2022-06-22 06:17:25.581258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem

    class Person(typesystem.Schema):
        name = typesystem.String(min_length=1)
        age = typesystem.Integer(minimum=0)
        address = typesystem.String(min_length=1)

    json_str = """{ "name": "Foo", "age": 42, "address": null }"""
    try:
        validate_with_positions(
            token=Token.parse(json_str), validator=Person()
        )  # type: ignore
    except ValidationError as e:
        for message in e.messages():
            print(f'{message.start_position.line_index+1}:{message.start_position.char_index+1} {message.text}')

# Generated at 2022-06-22 06:17:36.820198
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object, Field as TokenField
    from typesystem.fields import Integer

    object_ = Object(
        fields=[
            TokenField(
                name="required_int",
                value=Object(
                    start_position=42,
                    end_position=42,
                )
            )
        ]
    )

    validator = Integer(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=object_, validator=validator)


# Generated at 2022-06-22 06:17:46.341258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.fields import Integer

    from pytest_toolbox.comparison import AnyStringMatching, CloseToNow

    from .test_tokenize import TOKEN_MAP

    document = json.loads(
        open("test_schemas/test_complex_schema.json").read(), object_pairs_hook=dict
    )

    token = TOKEN_MAP["test_complex_schema.json"]

    now = datetime.datetime.now()

    document["timestamp"] = now.isoformat()