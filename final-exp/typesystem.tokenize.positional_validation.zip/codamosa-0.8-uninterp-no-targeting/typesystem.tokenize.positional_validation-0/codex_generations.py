

# Generated at 2022-06-22 06:07:58.062143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = "string"

    class Organization(Schema):
        owner = Person

    token = Token.from_dict({"owner": {"name": "Ann"}})
    validate_with_positions(token=token, validator=Organization)

    token = Token.from_dict({"owner": {"name": 1}})
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=Organization)

# Generated at 2022-06-22 06:08:09.032477
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer

    source = "{"
    source += "    foo:1"
    source += "    bar:true"
    source += "    baz:null"
    source += "}"

    tokenizer = Tokenizer()
    tokenizer.add_rule(
        "{", "{", lambda: "OPEN_BRACE", lambda _: None, lambda _: None
    )
    tokenizer.add_rule(
        "}", "}", lambda: "CLOSE_BRACE", lambda _: None, lambda _: None
    )
    tokenizer.add_rule(
        '":', ":", lambda: "COLON", lambda _: None, lambda _: None
    )

# Generated at 2022-06-22 06:08:18.256339
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.fields as fields
    import typesystem.tokenize.tokenizer as tokenizer
    from typesystem.tokenize import tokens

    field = fields.String(max_length=2)
    schema = {"foo": field}
    program = "var foo='blah';"
    validator = tokenizer.Tokenizer(schema)
    token = validator.validate(program)
    assert isinstance(token, tokens.Program)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert excinfo.value.cursor == ((0, 11), "char_index", None)

# Generated at 2022-06-22 06:08:26.330632
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parse_text import parse_text

    try:
        validate_with_positions(
            token=parse_text('{"foo": [1, 2]}'), validator={"foo": list}
        )
    except ValidationError as exc:
        assert str(exc.messages[0]) == (
            "The 'foo' field is required. [('foo', 'foo', 'str', 3), "
            "('foo', 'foo', 'dict', 2)]"
        )
    else:
        assert False

# Generated at 2022-06-22 06:08:35.184886
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import scan
    from typesystem.tokenize.token import Token
    # For this test, assume that the following code has been tested:
    #    token = scan(code)
    #    token.parse("""
    #    {
    #        "a": 1
    #    }""")
    code = """{
        "a": 1
    }"""
    token = Token(
        raw=code,
        parse=lambda content: {"a": 1},
        lookup=lambda index: Token(
            raw=code,
            parse=lambda content: 1,
            lookup=lambda index: Token(
                raw=code,
                parse=lambda content: content,
                lookup=lambda index: None,
            ),
        ),
    )

    error = None

# Generated at 2022-06-22 06:08:45.196573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import ObjectSchema

    class Schema(ObjectSchema):
        field = Field(type="string", required=False)

    schema = Schema()
    token = Token(value={"field": "Hello World"})
    assert validate_with_positions(token=token, validator=schema) == {
        "field": "Hello World"
    }

    from typesystem.tokenize.tokens import Token, Token

    token = Token(value=[{"id": 1}, {"id": "invalid"}])
    assert validate_with_positions(token=token, validator=schema) == [
        {"id": 1, "field": None},
        {"id": "invalid", "field": None},
    ]


# Generated at 2022-06-22 06:08:56.288906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class WhateverSchema(Schema):
        name = Field(type=str)
        age = Field(type=int)

    doc = "{'name': 'Joe', 'age': '17'}"
    tokens = tokenize(doc)
    token = tokens[0].lookup("root")
    schema = WhateverSchema()

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "Value should be of type 'int'."
        assert message.start_position.line_number == 1
        assert message.start_position.char

# Generated at 2022-06-22 06:09:01.128536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token(
            {"required": {"a": {"required": "b"}}},
            start=(2, 0),
            end=(3, 1)
        ),
        validator=Schema({"required": {"a": {"required": "b"}}}),
    )

# Generated at 2022-06-22 06:09:11.597960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # unit test for function validate_with_positions
    import typesystem
    from typesystem.schemas import get_schema
    from typesystem.tokenize import Tokenizer
    from typesystem.exceptions import ValidationError

    class Schema1(typesystem.Schema):
        name = typesystem.String(max_length=10)

    class Schema2(typesystem.Schema):
        a = typesystem.Array(items=Schema1())

    class Schema3(typesystem.Schema):
        b = typesystem.Integer(minimum=1)
        c = Schema1()
        d = Schema2()

    schema = Schema3()

# Generated at 2022-06-22 06:09:18.057462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    try:
        validate_with_positions(
            token=Token(
                '(field 1 "foo" (child "bar") "baz")',
                (1, 1),
                (1, 2),
                {
                    "field": Integer(),
                    "child": String(required=True),
                },
            ),
            validator=String(),
        )
    except ValidationError as e:
        assert e.messages()[0].text == 'The value "field 1 (\\"foo\\" (child \\"bar\\") \\"baz\\")" is not valid.'
    else:
        assert False, 'ValidationError not raised.'

# Generated at 2022-06-22 06:09:28.572954
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("""{
        "foo": 1,
        "bar": null,
        "baz": "hello"
    }""")

    token = token.lookup(["foo"])

    validator = Integer(required=True)
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start_position == token.start

# Generated at 2022-06-22 06:09:38.988699
# Unit test for function validate_with_positions
def test_validate_with_positions():
    instance = {"login": "hello", "password": "123456"}
    text = """
    {
        "login": "hello", 
        "password": "123456"
    }
    """

    from typesystem.tokenize.tokens import DocumentToken
    from json.tokenize import tokenize
    from collections import deque

    tokens = deque(list(tokenize(text)))
    token = DocumentToken(tokens=tokens, value=instance)

    from typesystem.fields import String
    from typesystem.schemas import RootSchema

    class LoginSchema(RootSchema):
        login = String(max_length=5)
        password = String(min_length=7)


# Generated at 2022-06-22 06:09:49.349634
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    from .parse import parse

    from .types import Document

    source = """
    query($x: Int!) {
      actor(id: $x) {
        name
        age
      }
    }
    """

    token = parse(source=source)
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=Document)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1

        message = messages[0]
        assert message.text == "The field 'x' is required."
        assert message.code == "required"
        assert message.index == ("query", "variable_definitions", 0, "variable")
        start = message.start_position
        assert start.char

# Generated at 2022-06-22 06:09:56.583413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Source

    source = Source(text="""\
        {
          "name": "",
          "age": 12,
          "email": "j@j.com",
          "birthday": "1995-01-04T00:00:00",
          "address": {
            "city": "San Francisco",
            "country": "US"
          },
          "hobbies": ["Drums", "Guitar"]
        }
        """)

# Generated at 2022-06-22 06:10:04.179804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ExampleSchema(Schema):
        field1 = Field(type="string")

        class Options:
            fields = ("field1",)

    schema = ExampleSchema()
    token = Token(
            value={"field1": "hello"},
            start=Position(char_index=0, line_index=0, line_char_index=0),
            end=Position(char_index=20, line_index=0, line_char_index=20),
        )
    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-22 06:10:14.441879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import RootToken
    from typesystem.fields import String
    from typesystem.tokenization import tokenize_string
    from typesystem import validators

    token = tokenize_string(
        "", root_token=RootToken(start_position=tokenize_string.Position(0, 0, 0))
    )
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert (
            str(error) == "The field '' is required."
            or str(error) == "The field u'' is required."
        )
        message = error.messages()[0]
        assert len(message.index) == 0
        assert message.code == "required"
        assert message.start_position == token

# Generated at 2022-06-22 06:10:25.864592
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FieldToken, ObjectToken, StringToken
    from typesystem.fields import String

    token = ObjectToken({"test_string": FieldToken("hello")}, start=0, end=12)
    schema = Schema({"test_string": String()})

    validate_with_positions(token=token, validator=schema)

    token = StringToken("hello", start=0, end=5)
    schema = String(max_length=4)

    with pytest.raises(ValidationError) as info:
        validate_with_positions(token=token, validator=schema)

    assert (
        str(info.value)
        == """{'test_string.max_length': 'Ensure this field has no more than 4 characters.'}"""
    )

# Generated at 2022-06-22 06:10:35.516397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import types

    class Person(Schema):
        name = types.String()
        age = types.Integer()

    token = Token(
        value={
            "name": "Joe",
            "age": "young",
        },
        start=Position(line=1, column=1),
        end=Position(line=3, column=6),
    )

    # NOTE: The error text is not completely accurate (missing quotes),
    # as it does not take the JSON representation into account.
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(validator=Person, token=token)

# Generated at 2022-06-22 06:10:47.214340
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import ObjectSchema
    from typesystem.fields import IntegerField, StringField
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize import Position
    import typesystem
    import io

    class Schema(ObjectSchema):
        name = StringField(required=True)
        age = IntegerField(required=True)


    token = tokenize(Schema, io.StringIO('{"name":"bob"}'))

    assert isinstance(token, Token)
    assert token.value == {"name": "bob"}

    error: ValidationError
    try:
        validate_with_positions(validator=Schema, token=token)
    except ValidationError as e:
        error = e


# Generated at 2022-06-22 06:10:59.322720
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import lexer, lexers
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        pass

    schema = TestSchema()
    schema.fields = [
        {
            "name": "name",
            "type": "string",
            "required": True,
        }
    ]


# Generated at 2022-06-22 06:11:13.504519
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")

    # No error, return clause is executed
    class User(Schema):
        name = Field(type="string")

    token = Token({"name": "foo"}, start_index=1, end_index=12)
    assert validate_with_positions(token=token, validator=User.name) == "foo"

    # One error, function raises ValidationError
    token = Token({}, start_index=1, end_index=12)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=User.name)

    # Two errors, function raises ValidationError
    class User(Schema):
        name = Field(type="string")
        surname = Field(type="string")


# Generated at 2022-06-22 06:11:21.239402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from typesystem.schemas import Structure
    from typesystem.schemas import Integer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("foo: 5, bar: None", "schema")

    assert validate_with_positions(token=token, validator=Structure(foo=Integer())) == {
        "foo": 5,
        "bar": None,
    }

    try:
        validate_with_positions(token=token, validator=Structure(foo=Integer(), baz=Integer()))
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].code == "required"
        assert error.messages()[0].index == ("baz",)

# Generated at 2022-06-22 06:11:30.530166
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Object
    from typesystem.fields import Field
    from typesystem import String
    import os
    filename = os.path.join(
        os.path.dirname(__file__), "..", "tests", "test_tokenization.py"
    )
    with open(filename, "r") as f:
        contents = f.read()

    lexer = Lexer(contents)
    document = Token.from_tokens(lexer.lex())
    _schema = Object.of({"b": Field.of(String)})


# Generated at 2022-06-22 06:11:36.730909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import textwrap
    import typesystem
    from typesystem.tokenize.tokens import Token, Node

    raw = textwrap.dedent(
        """\
    {
        "name": {
            "first": "Joe",
            "last": "Smith"
        },
        "age": 37,
        "favorite_color": "blue"
        "address": {
            "street": "123 Main St",
            "city": "Springfield",
            "state": "OR"
        }
    }
    """
    )


# Generated at 2022-06-22 06:11:40.920792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        a = Field(type=int)
        b = Field(type=int)

    token = Token(
        key="MySchema",
        value={
            "a": 1,
            "b": "not a number",
        },
        start={
            "line": None,
            "column": None,
        },
        end={
            "line": None,
            "column": None,
        },
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)
    assert exc_info.value.messages()[0].start_position.line is None

# Generated at 2022-06-22 06:11:51.196125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import DocumentToken
    from typesystem.fields import String

    field = String(required=True)

    token = DocumentToken(
        {"a": "b"},
        position=Position(line_number=1, line_index=2, char_index=9),
    )
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages) == 1
        message = error.messages[0]
        assert message.text == "The field 'a' is required."
        assert message.code == "required"
        error.messages[0].index == [0]

# Generated at 2022-06-22 06:11:59.700659
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem import Dict

    class PersonSchema(Schema):
        name = Field(str, required=True)
        email = Field(str, required=True)
        age = Field(int, required=True)

    data = {"name": "Alice", "age": 23, "height": "1.62"}
    schema = PersonSchema()
    tokens = tokenize(data)
    token = next(tokens)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].code == "required"
        assert error.messages()[0].start_position.column == 2
        assert error.messages()[0].start_position.line == 1


# Generated at 2022-06-22 06:12:10.675431
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Test(Schema):
        name = Field(type="string")
        surname = Field(type="string")
        age = Field(type="integer")

    source_code = """
    {
        "name": "Javier",
        "age": "10"
    }
    """
    tokens = Token.make_tokens(source_code)
    try:
        validate_with_positions(
            token=tokens, validator=Test
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line_index == 4
        assert message.start_position.char_index == 11
        assert message.end_position.line_index == 4
        assert message.end_position.char_index == 14

# Generated at 2022-06-22 06:12:19.124166
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest

    from typesystem.fields import String

    text = '{"foo": "bar", "baz": "qux"}'
    token = Token.parse(json.loads(text))
    assert validate_with_positions(token=token, validator={}) == {
        "foo": "bar",
        "baz": "qux",
    }

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator={"foo": String(min_length=5)})

    error = exc.value
    assert len(error.messages()) == 1
    message = error.messages()[0]
    assert message.index == ("foo",)
    assert message.code == "min_length"

# Generated at 2022-06-22 06:12:26.360576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.scanner import Scanner, ScannerParams
    from typesystem.tokenize.tokens import Token

    schema = {
        "type": "object",
        "properties": {
            "foo": {"type": "string"},
            "baz": {"type": "string", "required": True},
        }
    }
    field = Field.from_dict(schema)

    source = "foo 12 baz 3"
    scanner = Scanner(source, params=ScannerParams(position=True))

    try:
        validate_with_positions(token=Token(value=scanner.to_dict()), validator=field)
    except ValidationError as error:
        assert error.messages()[-1].start_position.char_index == 14
    else:
        assert False

# Generated at 2022-06-22 06:12:42.224019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        first_name = Field(type="string")
        last_name = Field(type="string")

    token = Token(
        value={
            "first_name": "Mi",
            "last_name": "Ro",
        },
        start={
            "char_index": 0,
            "line_index": 0,
            "line_number": 1,
        },
        end={
            "char_index": 9,
            "line_index": 0,
            "line_number": 1,
        },
    )
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-22 06:12:52.593306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer

    tokenizer = JSONTokenizer()
    # These are "normal" messages
    json = """{"a": 1, "b": "1", "c": null, "d": [], "e": {}}"""
    token = tokenizer.tokenize(json)
    validate_with_positions(token=token, validator=Schema({
        "a": Field(type="integer"),
        "b": Field(type="integer"),
        "c": Field(type="string"),
        "d": Field(type="list", items=Field(type="integer")),
        "e": Field(type="object")
    }))

    # This is a "required" message
    json = """{"a": 1}"""
    token = tokenizer.tokenize(json)

# Generated at 2022-06-22 06:13:04.136829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # pylint: disable=line-too-long
    from typesystem.tokenize.lexer import Lexer
    from typesystem.tokenize.tokens import EOF, Entry, Exit, Key, Whitespace

    lexer = Lexer(
        [
            Key("a"),
            Whitespace(" "),
            Entry("{"),
            Whitespace("\n  "),
            Key("b"),
            Whitespace(" "),
            Entry("{"),
            Whitespace("\n    "),
            Key("c"),
            Whitespace(" "),
            Entry(":"),
            Whitespace(" "),
            Key("123"),
            Whitespace("\n  "),
            Exit("}"),
            Whitespace("\n"),
            Exit("}"),
            EOF(),
        ]
    )

    schema = Schema

# Generated at 2022-06-22 06:13:14.053162
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import validators

    typesystem_string = """
    name: string
    friends: array(string)
    """

    @validators.schema
    def Person(fields):
        return {
            "name": fields.String(required=True),
            "friends": fields.Array(fields.String(required=True)),
        }

    token = Token(
        "person",
        value={
            "name": "Dan",
            "friends": ["Alice", "Bob"],
        },
    )
    assert validate_with_positions(token=token, validator=Person)
    assert validate_with_positions(token=token, validator=Field(type="person"))


# Generated at 2022-06-22 06:13:21.194540
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: this is just a smoke test. We should write a proper test
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    token = tokenize("""
    {
        'name': 'Foo'
    }
    """)
    class Person(Schema):
        name = Field(type=str)

    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-22 06:13:32.694675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.types import String
    from typesystem.exceptions import ValidationError as TypeSystemValidationError

    class TestSchema(Schema):
        foo = Field(String)
        bar = Field(String, required=True)

    json = '{"foo":"", "bar": "200"}'
    tokens = tokenize(json)
    validate_with_positions(
        token=tokens, validator=TestSchema,
    )
    assert "Foo validated"

    json = '{"foo":null, "bar": "200"}'
    tokens = tokenize(json)
    validate_with_positions(token=tokens, validator=TestSchema,)

# Generated at 2022-06-22 06:13:42.109932
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize.cst import CSTNode
    from typesystem.tokenize.tokens import (
        ArrayToken,
        BooleanToken,
        FloatToken,
        IdentifierToken,
        IntegerToken,
        KeyToken,
        KeyValueToken,
        NullToken,
        ObjectToken,
        StringToken,
    )

    # Setup / testing data

# Generated at 2022-06-22 06:13:53.680953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Object
    from typesystem.fields import String
    from typesystem.tokenize.tokens import String as StringToken
    from typesystem.tokenize.tokens import Object as ObjectToken
    from typesystem.tokenize.core import Tokenizer
    from typesystem.parsers import TOKENIZER_PARSER
    from typesystem.tokenize.tokens import Array
    from typesystem.tokenize.tokens import Array as ArrayToken
    from typesystem.tokenize.tokens import Number
    from typesystem.tokenize.tokens import Number as NumberToken
    from typesystem.tokenize.tokens import Literal
    from typesystem.tokenize.tokens import Literal as LiteralToken
    import pytest


# Generated at 2022-06-22 06:14:07.801763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize import tokenize_string

    class Person(typesystem.Schema):
        name = typesystem.String(required=True)
        age = typesystem.Integer(required=True)

    document = tokenize_string("""
        {
            "age": 17,
        }
    """)

    try:
        validate_with_positions(token=document, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].code == "required"
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start_position.line == 4

# Generated at 2022-06-22 06:14:19.743584
# Unit test for function validate_with_positions
def test_validate_with_positions():  # type: ignore
    from typesystem.basic_types import String
    from typesystem.fields import List
    from typesystem.tokenize.base import Pos
    from typesystem.tokenize.tokens import Token, TokenType

    string = String()

    class Person(Schema):
        name = string
        friends = List[string]

    token = Token(
        type=TokenType.DICT,
        start=Pos(0, 0, 0),
        end=Pos(0, 0, 14),
        value={
            "name": "",
            "friends": ["peter", "jane"],
            "address": "",
        },
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_

# Generated at 2022-06-22 06:14:34.248754
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from graphql import graphql_sync
    from graphql.language.parser import parse
    from graphql import graphql_sync
    from graphql.type import (
        GraphQLArgument,
        GraphQLField,
        GraphQLInputObjectField,
        GraphQLInputObjectType,
        GraphQLList,
        GraphQLNonNull,
        GraphQLObjectType,
        GraphQLString,
    )
    from ..fields import String, Number
    from ..schemas import Query, InputObject, Mutation
    from . import clear_registry, Registry

    clear_registry()

    class ObscureInput(InputObject):
        name = String(max_length=5, required=True)
        number = Number()

        @classmethod
        def get_graphql_type(cls):
            fields = []

# Generated at 2022-06-22 06:14:44.386871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        name="field",
        value=dict(value=25, child=dict(value="twenty five")),
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 30},
    )

    class FieldWithDefault(Field):
        default = "foo"

    class SubSchema(Schema):
        value = Field()
        child = Field()

    class RootSchema(Schema):
        field = Field()
        sub_field = FieldWithDefault()
        sub_schema = SubSchema()

    validator = RootSchema()


# Generated at 2022-06-22 06:14:56.358482
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Unit test for validate_with_positions."""
    class ProductSchema(Schema):
        name = Field(type="string", max_length=3)
        price = Field(type="number", minimum=5)

    token = Token(
        "object",
        {
            "name": "toto",
            "price": 2,
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 6, "char_index": 12},
    )
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=ProductSchema)
    # Asserting output position

# Generated at 2022-06-22 06:15:05.035275
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from . import simple_schema

    source = """
    {
        "name": "Tester",
        "email": "test@example.com",
        "age": 23
    }
    """
    tokens = tokenize(source)
    value = tokens.value

    try:
        validate_with_positions(token=tokens, validator=simple_schema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position.line == 1
        # character index is 0-based while line is 1-based
        assert message.start_position.char_index == 6
        assert message.end_position == message.start_position



# Generated at 2022-06-22 06:15:12.290854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_string

    from .example import Person

    person = Person()
    token = tokenize_string("""
        first_name: "John"
        last_name: "Doe"
    """)
    value = validate_with_positions(token=token, validator=person)
    assert value == {
        "first_name": "John",
        "last_name": "Doe",
    }

# Generated at 2022-06-22 06:15:21.394332
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from typesystem.fields import Integer, String

    schema = Schema({"a": String(required=True)})
    data = {}

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(
            token=Token(value=data, context={"root": Token(value=data)}), validator=schema
        )
    excinfo.match(r"The field 'a' is required.")

    # TODO make the error message check more precise
    # assert str(error.messages[0]) == "The field 'a' is required."



# Generated at 2022-06-22 06:15:34.041163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse

    def assert_error(code, text, source):
        string_text = str(text)
        try:
            token, _ = parse(source)
            validate_with_positions(token=token, validator=Log())
            assert False, f"Expected: {string_text}"
        except ValidationError as error:
            for message in error.messages():
                assert message.text == string_text, f"Expected: {string_text}"
                assert message.code == code, f"Expected: {code}"
                assert message.index == [], f"Expected: []"

    class Log(Schema):
        name = Field(required=True)
        message = Field(required=True)


# Generated at 2022-06-22 06:15:44.263585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer
    from tests.test_cases import ExpectedErrorMessage

    tokenizer = Tokenizer()
    validate = validate_with_positions

    class NoteSchema(Schema):
        text = Field(type="string")

    assert validate(token=tokenizer.tokenize("foo"), validator=NoteSchema) == {
        "text": "foo"
    }

    class NoteSchema(Schema):
        text = Field(type="string", required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate(token=tokenizer.tokenize(""), validator=NoteSchema)
    error = exc_info.value
    assert error.messages() == [ExpectedErrorMessage()]


# Generated at 2022-06-22 06:15:44.902938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False

# Generated at 2022-06-22 06:15:51.584597
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse

    class User(Schema):
        name = Field(type=str, min_length=1)

    class Query(Schema):
        user = Field(type=User)

    query = parse("{ user { name } }")
    validate_with_positions(token=query, validator=Query)

# Generated at 2022-06-22 06:16:11.114661
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.tokenize.tokens import ArrayToken
    from typesystem.fields import Boolean

    token = ArrayToken(start=0, end=0, value=["foo", "foo", None, True, False], name="a")

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Boolean())

# Generated at 2022-06-22 06:16:23.306455
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        age = Field(int)
    token = Token(value={"name": "Guido", "age": "notint"}, start=0, end=14)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-22 06:16:29.632059
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer
    from typesystem.tokenize import make_tokens, tokenize
    from typesystem.utils import parse_query_string

    class QuerySchema(Schema):
        number = Integer(default=10)

    query_string = "number=not-an-integer"
    tokens = make_tokens(parse_query_string(query_string))
    query = tokenize(tokens, QuerySchema)
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=query, validator=QuerySchema)
    assert error.value.messages()[0].text == "Not a valid integer."

# Generated at 2022-06-22 06:16:41.215933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        name = Field(type=str)
        age = Field(type=int)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                key="user",
                value={
                    "name": "foobar",
                    "age": "I'm not an integer!",
                },
                start=Token.Position(line=1, column=1),
                end=Token.Position(line=1, column=2),
            ),
            validator=User,
        )
    message = exc_info.value.messages[0]
    assert message.text == "I'm not an integer! is not a valid integer."
    assert message.start_position.line == 1
    assert message.start_position.column == 16


# Generated at 2022-06-22 06:16:53.246168
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        greeting = Field(type="string")

    schema = MySchema()
    token = Token(
        "dict",
        value={
            "greeting": Token(
                "string", value="hello", start=(1, 1), end=(1, 6)
            )
        },
        start=(1, 1),
        end=(1, 7),
    )

    validate_with_positions(token=token, validator=schema)

    # When there is a validation error, the error message should
    # include the correct position values.

# Generated at 2022-06-22 06:17:00.129587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import parse

    schema = parse("""
        type: object
        properties:
          name:
            type: string
            required: true
          username:
            type: string
            required: true
          password:
            type: string
            required: true
    """)

    token = Token(
        schema.type,
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "username": {"type": "string"},
                "password": {"type": "string"},
            },
        },
    )

    data = {"name": "Jane Doe"}

    token = token.lookup("properties")
    token = token.initialize_object(data)
    token = token.lookup("name")

# Generated at 2022-06-22 06:17:11.269033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.lexing.positions import Position, CharPosition, LinePosition
    from typesystem.lexing.tokens import IntegerToken

    class TestValidator(Field):
        def validate(self, value):
            value = super().validate(value)
            if value >= 5:
                raise ValidationError(
                    [
                        Message(
                            text="Invalid value.",
                            code="invalid",
                            index=[],
                            start_position=CharPosition(char_index=0),
                            end_position=CharPosition(char_index=1),
                        )
                    ]
                )
            else:
                return value


# Generated at 2022-06-22 06:17:20.941277
# Unit test for function validate_with_positions
def test_validate_with_positions():  # type: ignore

    class User(Schema):
        name = Field(type_=str)
        age = Field(type_=int)

    person = User({"name": "Tim", "age": "21"})
    try:
        person.validate()
    except ValidationError as error:
        for message in error.messages():
            print(message)
        print(error)
        # assert message.start_position == Position(line=6, char_index=3)
        # assert message.end_position == Position(line=6, char_index=6)

        print(person.errors)



# Generated at 2022-06-22 06:17:28.501748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    schema = typesystem.Schema(properties={"name": typesystem.String(required=True)})

    token = Token("{'name':''}")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 5
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 12

# Generated at 2022-06-22 06:17:39.523427
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import TokenType

    from typesystem.parser.parser import Parser
    from typesystem.parser.schemas import ObjectSchema

    from . import JSONSchema, UnknownFieldError

    from typesystem.parser.lexer import Lexer, LexerTokenType

    class BookSchema(ObjectSchema):
        title = Field(str)
        pages = Field(int)

    class MonsterSchema(ObjectSchema):
        name = Field(str)
        books = Field(BookSchema, many=True)
