

# Generated at 2022-06-22 06:08:01.857006
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class SimpleSchema(Schema):
        my_field = String(required=True)
        my_other_field = String()

    token = Token.from_data(
        value={"my_other_field": "hello"}, start_position=(1, 0), end_position=(1, 10)
    )
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=SimpleSchema)
    assert exc.value.messages[0].start_position.line == 1  # type: ignore
    assert exc.value.messages[0].start_position.char_

# Generated at 2022-06-22 06:08:10.671280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class User(Schema):
        email = Field(type="email")
        age = Field(type="number")

    with pytest.raises(ValidationError) as excinfo:
        print(dict(User.validate({"age": "string"})))
    assert excinfo.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=TokenPosition(line_index=0, char_index=0),
            end_position=TokenPosition(line_index=0, char_index=0),
        ),
    ]

    with pytest.raises(ValidationError) as excinfo:
        print(dict(User.validate({"age": "string", "email": "invalid_email"})))

# Generated at 2022-06-22 06:08:18.303691
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Object, fields

    class Person(Schema):
        name = fields.String()
        age = fields.Integer()

    token = Token(
        value={
            "name": "dave",
            "age": "21",
        },
        index=[
            "name",
        ],
        start={"line": 1, "col": 1, "char_index": 0},
        end={"line": 5, "col": 1, "char_index": 22},
    )
    validator = Object(fields={"name": fields.String(), "age": fields.Integer()})
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        message = error.messages[0]

# Generated at 2022-06-22 06:08:30.006133
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Object, String
    from typesystem.tokenize.parser import parse_json

    schema = Object(properties={"name": String()})

    input_and_expected = [
        (
            '{"name": "Joe"}',
            '{"name": "Joe"}',
        ),
        (
            '{"name": 1}',
            '1:6: Value {"name": 1} has wrong type: Got integer for field "name", expected string.',
        ),
    ]

    for input, expected in input_and_expected:
        if isinstance(expected, str):
            with pytest.raises(ValidationError) as exc_info:
                validate_with_positions(token=parse_json(input), validator=schema)
            message = str(exc_info.value)
           

# Generated at 2022-06-22 06:08:36.337098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Structure
    from typesystem.fields import String, Integer
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.utils import Line, Position

    schema = Structure(fields={"x": Integer, "y": String})
    tokens = tokenize({"x": 1, "y": "foo"}, strict=True)
    validate_with_positions(token=tokens, validator=schema)

    tokens = tokenize({"x": "foo", "y": "bar"}, strict=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=schema)
    exc = exc_info.value
    assert "int" in [message.text for message in exc.messages()]


# Generated at 2022-06-22 06:08:46.111777
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem_text

    class CommentSchema(typesystem.Schema):
        text = typesystem.String(max_length=255)

    class PostSchema(typesystem.Schema):
        title = typesystem.String()
        comments = typesystem.Array(
            items=typesystem.Schema(fields={"text": typesystem.String()})
        )

    data = {}

    token = typesystem_text.parse(
        """
        title: Hello World
        ---
        comments:
        - text: This is a comment.
        - text: Another comment
        """
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=PostSchema)

    messages = []

# Generated at 2022-06-22 06:08:57.187361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.exceptions import ValidationError, PropertyError
    from typesystem.fields import IntegerField, StringField
    from typesystem.tokenize.tokens import TextToken, KeyToken, ValueToken

    class ItemSchema(Schema):
        prop1 = StringField(required=True)
        prop2 = IntegerField(required=True)

    string = '{"prop1": "foo", "prop2": 123}'

    tokens = [
        KeyToken(value="prop1", start=(1, 0), end=(1, 7)),
        ValueToken(value="foo", start=(1, 8), end=(1, 13)),
        KeyToken(value="prop2", start=(1, 15), end=(1, 22)),
        ValueToken(value=123, start=(1, 23), end=(1, 26)),
    ]
    document_

# Generated at 2022-06-22 06:09:01.909854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema(properties={"foo": Field(type="string", max_length=3)})
    token = tokenize({"foo": "abc"}, schema)
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert [
        msg.text for msg in excinfo.value.messages()
    ] == ["The field 'foo' cannot be longer than 3 characters."]

# Generated at 2022-06-22 06:09:08.459586
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem import Integer

    token = Token(name="foo", value="invalid", start=0, end=0)
    try:
        validate_with_positions(token=token, validator=Integer())
    except ValidationError as error:
        assert error.messages()[0].start_position == 0
        assert error.messages()[0].end_position == 0

# Generated at 2022-06-22 06:09:18.528279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        first_name = String(min_length=1)
        last_name = String(min_length=1)
        age = String(min_length=1)


# Generated at 2022-06-22 06:09:28.318592
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schema.shape import Shape

    from typesystem.tokenize import tokenize

    schema = Shape(properties={"name": Field(type="string", required=True)})
    data = '{"name": "Eric"}'
    tokens = list(tokenize(data))
    assert len(tokens) == 1
    token = tokens[0]
    assert schema.validate(token.value) == {"name": "Eric"}
    assert len(schema.errors) == 0
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert False, "unexpected error"
    data = "{}"
    tokens = list(tokenize(data))
    assert len(tokens) == 1
    token = tokens[0]

# Generated at 2022-06-22 06:09:36.625458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test that errors have positions."""
    import json
    import pprint
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.exceptions import InvalidType
    from typesystem.types import Text

    # Schema to validate
    class MyModel(Schema):
        type = String()
        tags = String()

    token = tokenize(
        json.dumps(
            {
                "type": "document",
                "content": [{"type": "image", "url": "not-a-valid-url"}],
                "tags": ["news", "sport"],
            }
        ),
        Model=Text,
    )


# Generated at 2022-06-22 06:09:40.400582
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token("field_name", "abc", start_position=None, end_position=None),
        validator=Field(max_length=2),
    )



# Generated at 2022-06-22 06:09:48.661399
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class MySchema(Schema):
        name = Field(str, required=True)

    token = Token.parse(data='{"name": null}')

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        message = error.messages[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 11

    token = Token.parse(data='{"name": "Sandy"}')
    assert validate_with_positions(token=token, validator=MySchema) == {"name": "Sandy"}

# Generated at 2022-06-22 06:09:56.519067
# Unit test for function validate_with_positions
def test_validate_with_positions():
  import unittest
  import sys

  field = Field(
    name="my_field", type="string", required=True
  )
  valid_data = validate_with_positions(
    token=Token(value="my string"), validator=field
  )
  assert valid_data == "my string"

  invalid_data = validate_with_positions(token=Token(value=None), validator=field)
  assert invalid_data is None

  class MyFieldSchema(Schema):
    my_field = Field(
      name="my_field", type="string", required=True
    )

  valid_data = validate_with_positions(
    token=Token(value={"my_field": "my string"}), validator=MyFieldSchema
  )

# Generated at 2022-06-22 06:10:07.512864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    schema = String(min_length=3)

    from typesystem.tokenize.parser import parse

    # Test for the case where the string passes validation
    token = parse("""{"foo": "bar"}""")
    result = validate_with_positions(token=token, validator=schema)
    assert isinstance(result, String)
    assert result.value == "bar"

    # Test for the case where validation fails
    token = parse("""{"foo": "b"}""")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=schema)

    assert len(exc.value.messages) == 1

# Generated at 2022-06-22 06:10:16.009737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    field = Field(type="string", required=True)
    text = '{"foo": "[1, 2, 3]"}'
    token = Token(text=text, value=text, start=0, end=len(text))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages[0].text == "The field 'foo' is required."
    assert exc_info.value.messages[0].start_position == (1, 10)
    assert exc_info.value.messages[0].end_position == (1, 15)

# Generated at 2022-06-22 06:10:16.518592
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:10:17.235397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:10:22.219810
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse_file
    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from pprint import pprint

    source = """
    # Definition
    type Person {
        name : string
        age: number
    }

    # Use
    people: [Person]
    """

    document = parse_file(source)
    person_type = document["types"]["Person"]
    schema = Schema(fields={"people": person_type.array(min_length=1)})

    try:
        schema.validate(document["data"])
    except ValidationError as error:
        pprint(error.messages())



# Generated at 2022-06-22 06:10:36.522317
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer, TokenInfo
    from typesystem.schemas import create_schema
    from typesystem.fields import Field, Any

    class IntegerField(Field):
        def validate(self, value):
            try:
                return int(value)
            except ValueError:
                raise ValidationError(f"Invalid integer value: {value!r}")

    class Person(Schema):
        name = Field(required=True)
        age = IntegerField()
        favorite_foods = Field(type=Any, required=True)

    content = """
    {
        "name": "John Smith",
        "age": "32",
        "favorite_foods": [
            "apple pie", "pizza"
        ]
    }
    """

# Generated at 2022-06-22 06:10:45.261146
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import ListToken, ObjectToken, SimpleToken

    from .serializers import Contact, Person


# Generated at 2022-06-22 06:10:51.103111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token.parse(
        {
            "type": "root",
            "value": {"field1": "foo", "field2": "bar"},
            "start": {"line": 1, "column": 0},
            "end": {"line": 1, "column": 14},
            "children": {
                "field1": {
                    "type": "string",
                    "value": "foo",
                    "start": {"line": 1, "column": 2},
                    "end": {"line": 1, "column": 7},
                },
                "field2": {
                    "type": "string",
                    "value": "bar",
                    "start": {"line": 1, "column": 9},
                    "end": {"line": 1, "column": 14},
                },
            },
        }
    )
    schema = Sche

# Generated at 2022-06-22 06:10:51.892099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-22 06:11:00.676334
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Tokenizer, tokens
    from typesystem.schemas import Schema, String, Integer
    from typesystem.fields import Object

    class Person(Schema):
        name = String()
        age = Integer()

    schema = Object(fields={"person": Person()})

    tokenizer = Tokenizer()
    tokenizer.add_rule(
        tokens.String, pattern=r'"([^"]|\\")*"'
    )  # strings may contain escapes
    tokenizer.add_rule(
        tokens.String, pattern=r"'([^']|\\')*'"
    )  # strings may contain escapes
    tokenizer.add_rule(tokens.Integer, pattern=r"\d+")

# Generated at 2022-06-22 06:11:11.662769
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem import types

    class Address(Schema):
        postcode = Field(type=types.String)

    class Person(Schema):
        name = Field(type=types.String, required=True)
        address = Field(type=Address)

    src = """{
        name: 'Alice',
    }"""
    token = tokenize(src)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    exc = excinfo.value
    assert len(exc.messages) == 1
    assert exc.messages[0].start_position.offset == 31

# Generated at 2022-06-22 06:11:23.159291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema_json = {
        "id": "https://example.com/person.schema.json",
        "$schema": "http://json-schema.org/draft-07/schema#",
        "title": "Person",
        "type": "object",
        "required": ["firstName", "lastName"],
        "properties": {
            "firstName": {"type": "string", "description": "The person's first name."},
            "lastName": {"type": "string", "description": "The person's last name."},
            "age": {"description": "Age in years which must be equal to or greater than zero.", "type": "integer", "minimum": 0},
        },
    }
    schema = Schema(schema_json)

# Generated at 2022-06-22 06:11:34.484064
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Schema(properties={"foo": Field(required=True)})

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(
                identity=(),
                value={"foo": 123},
                start=Position(char_index=0, line=1, column=1),
                end=Position(char_index=9, line=1, column=10),
            ),
            validator=schema,
        )

    messages = exc_info.value.messages()
    assert len(messages) == 1
    assert messages[0].index == ("foo",)
    assert messages[0].text == "The field 'foo' is required."

# Generated at 2022-06-22 06:11:45.104275
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import json
    import pytest

    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.schemas import Schema, Component

    class PhoneSchema(Schema):
        area = String(min_length=3, max_length=3, pattern=r"^\d+$")
        major = String(min_length=3, max_length=3, pattern=r"^\d+$")
        minor = String(min_length=4, max_length=4, pattern=r"^\d+$")

    class Schema(Schema):
        name = String()
        phone = Component(schema=PhoneSchema)


# Generated at 2022-06-22 06:11:57.481617
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import FileToken
    from typesystem.tokenize.locations import CharacterLocation, ZeroBasedLineColumn
    from tokenize import tokenize, generate_tokens, NUMBER

    with open("pyfile.py") as fh:
        tokens = list(generate_tokens(fh.readline))
    file_tokens = [
        Token.from_tokenize(token, location=ZeroBasedLineColumn) for token in tokens
    ]
    file_token = FileToken(
        tokens=file_tokens,
        start=CharacterLocation(lineno=1, char_index=0),
        end=CharacterLocation(lineno=1, char_index=11),
    )

    import typesystem
    import pytest


# Generated at 2022-06-22 06:12:15.404801
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # fmt: off
    body: typing.List[typing.Dict[str, str]] = [
        {"name": "Foo"},
        {"name": "Bar"},
        {"name": "Baz"},
    ]
    # fmt: on
    token = Token.from_json(body)
    item = Field(name="name", required=True)
    validator = Field(name="items", type=item, required=True)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=validator)
    assert exc.value.messages[0].text == "The field 'name' is required."
    assert exc.value.messages[0].start_position == token[1]["name"].start

# Generated at 2022-06-22 06:12:20.979856
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.simple import simple_tokenize

    tokens = simple_tokenize('{"key": "value"}')
    token = tokens[0].value[0]

    class MyValidator(Schema):
        key = Field(type=str)

    assert validate_with_positions(token=token, validator=MyValidator) == {
        "key": "value"
    }

# Generated at 2022-06-22 06:12:29.870441
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Boolean, Object
    from typesystem.tokenize import tokenize

    class Person(Object):
        name = String()
        is_ok = Boolean(required=False)

    token = tokenize(value={"name": "John"})["name"]
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    assert (
        excinfo.value.messages()[0].text
        == "The field is_ok is required.\nExpected type Boolean"
    )
    assert excinfo.value.messages()[0].start_position.line == 1
    assert excinfo.value.messages()[0].start_position.column == 8
    assert excinfo.value.messages()[0].start_position

# Generated at 2022-06-22 06:12:36.270314
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token.pass_through(value={"foo": "bar"}),
        validator=Schema(
            fields={
                "foo": Field(type="string"),
                "baz": Field(type="string", required=False),
            }
        ),
    ) == {"foo": "bar"}

# Generated at 2022-06-22 06:12:45.235562
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Person(Schema):
        name = Field(str)
        title = Field(str)

    token = Token(
        value={
            "name": "John",
            "title": "The King",
        }
    )

    try:
        validate_with_positions(token=token, validator=Person())
    except ValidationError as error:
        assert error.messages()[0].text == "Invalid data."
        assert error.messages()[0].code == "invalid"
        assert error.messages()[0].index == []
        assert error.messages()[0].start_position is None
        assert error.messages()[0].end_position is None


# Generated at 2022-06-22 06:12:55.245692
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.json import tokenize_json
    from typesystem.schemas import JSONSchema

    token = tokenize_json("""
{
  "title": "test",
  "properties": {
    "a": {},
    "b": {}
  },
  "required": ["a", "b"]
}
""")

    try:
        validate_with_positions(token=token, validator=JSONSchema)
    except ValidationError as error:
        assert len(error.messages()) == 2

        # Note that the messages are *sorted* by character index
        message = error.messages()[0]
        assert message.code == "required"
        assert message.index == ["properties", "b", "type"]
        assert message.start_position.line == 5
        assert message

# Generated at 2022-06-22 06:13:03.454294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.references import ReferenceField
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.keypath import keypath_to_index

    token = tokenize("foo", "bar")  # type: ignore
    assert keypath_to_index(token, "foo") == (0,)
    assert keypath_to_index(token, "bar") == (1,)
    field = ReferenceField({"bar": "string"})
    validate_with_positions(token=token, validator=field)



# Generated at 2022-06-22 06:13:16.721923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Schema, Integer, String, Array

    class PersonSchema(Schema):
        first_name = String(required=True)
        last_name = String(required=True)
        age = Integer()

    class MovieSchema(Schema):
        title = String(required=True)
        actors = Array(items=PersonSchema())

    token = Token.from_dict(
        {
            "title": "Star Wars",
            "actors": [{"first_name": "Harrison", "last_name": "Ford"}],
        }
    )

    try:
        validate_with_positions(token=token, validator=MovieSchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 2
        assert messages[0].start_

# Generated at 2022-06-22 06:13:27.954497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    from tests.test_schemas import SettingsSchema
    from tests.parse_json import parse_json

    tokens = parse_json('''
        {
            "timeout": "60",
            "host": "127.0.0.1",
        }
    ''')
    settings = validate_with_positions(token=tokens, validator=SettingsSchema)
    assert settings.timeout == 60
    assert settings.host == "127.0.0.1"

    invalid = parse_json('''
        {
            "timeout": "a",
            "host": "127.0.0.1",
        }
    ''')

# Generated at 2022-06-22 06:13:39.367041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .fixtures import UserSchema, User, user_dict
    from .tokenize import tokenize
    from .templates import render_template

    token = tokenize(user_dict)
    schema = UserSchema()


# Generated at 2022-06-22 06:13:55.490163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # implemented in tests/test_validators.py

# Generated at 2022-06-22 06:14:08.636105
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Integer

    class MySchema(Schema):
        foo = Integer()
        bar = Integer(required=True)

    # 1) Missing required field, positional error
    x = {"foo": "123"}
    token = Token(value=x, start=0, end=1)
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as exc:
        assert exc.messages()[0].start_position == 0
        assert exc.messages()[0].end_position == 1
    else:
        assert False

    # 2) Regular error, positional error
    x = {"foo": "xyz", "bar": "456"}

# Generated at 2022-06-22 06:14:20.237915
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Boolean
    from typesystem.tokenize.tokenize import tokenize_string

    token = tokenize_string("true")[0]
    validate_with_positions(token=token, validator=Boolean())

    token = tokenize_string("false")[0]
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Boolean(required=True))
    message = excinfo.value.messages[0]
    assert message.code == "required"
    assert message.text == "The field 'data' is required."
    assert message.start_position.line == 1
    assert message.end_position.line == 1
    assert message.start_position.column == 1
    assert message.end_position.column == 5

# Generated at 2022-06-22 06:14:26.829621
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_token
    from typesystem.types import String, Integer

    token = parse_token({"a": "x"})
    value = validate_with_positions(token=token, validator=Integer())
    assert value is None

    token = parse_token({"a": "x"})
    value = validate_with_positions(token=token, validator=String())
    assert value == "x"

# Generated at 2022-06-22 06:14:35.716333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import TokenParser
    from typesystem.tokenize.positions import Position, Span

    from typesystem.schema import Schema
    from typesystem.fields import String

    raw_input = """
        {
            "foo": "bar",
            "baz": 1.23,
            "bap": null
        }
    """
    parser = TokenParser(
        start_position=Position(line=1, line_index=0, char_index=0),
        end_position=Position(line=1, line_index=0, char_index=0),
    )
    tokens = parser.parse(raw_input)
    assert validate_with_positions(token=tokens[0], validator=Schema(fields={"foo": String()})) == {"foo": "bar"}



# Generated at 2022-06-22 06:14:46.940186
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class SimpleRecordSchema(Schema):
        id = Field(type=str, min_length=10)
        name = Field(type=str)

    import typesystem
    from typesystem.tokenize.tokenizers import JSONTokenizer

    validator = SimpleRecordSchema(required=("id", "name"))

    record = """{"id": "1234567890", "name": "John"}"""
    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize(record)

    result = validate_with_positions(token=token, validator=validator)
    assert result == {"id": "1234567890", "name": "John"}

    record = """{"name": "John"}"""
    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize(record)


# Generated at 2022-06-22 06:14:59.040712
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from typesystem.tokenize import generate_tokens
    from typesystem.exceptions import ValidationError

    schema = Schema({"field1": Field(required=True, type="string")})
    tokens = generate_tokens("{}")

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens[0], validator=schema)

    error_message = error.value.messages[0]
    assert error_message.text == "The field 'field1' is required."
    assert error_message.code == "required"
    assert error_message.start_position.line_index == 0
    assert error_message.start_position.char_index == 1
    assert error_message.end_position.line_index == 0
    assert error_message

# Generated at 2022-06-22 06:15:08.599208
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.parser import parse
    from typesystem.tokenize.tokens import List
    from typesystem.tokenize.tokens import Object
    from typesystem.tokenize.tokens import String as StringToken
    from typesystem.tokenize.tokens import Token
    import pytest

    tree = parse("""
    [
        {
            "foo": "Hello",
            "bar": "World"
        },
        {
            "foo": "Hello",
            "bar": "World"
        }
    ]
    """)
    assert isinstance(tree, List)

    assert isinstance(tree[0], Object)
    assert isinstance(tree[0]["foo"], StringToken)
    assert isinstance(tree[0]["bar"], StringToken)

# Generated at 2022-06-22 06:15:15.981573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.position import Position
    from typesystem.tokenize.tokens import Container, Scalar
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    data = dict(foo=1)
    token = Token(Position.from_string("foo: 1"), data)
    schema = Schema(fields=dict(foo=String()))

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as exc:
        messages = exc.messages()
        start_line = Position(0, 0, 0, 0)
        start_char = Position(0, 2, 0, 2)
        start_position = Position(0, 2, 0, 2)

# Generated at 2022-06-22 06:15:23.092097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.token_types import String
    from typesystem.tokenize import Tokenizer

    tokenizer = Tokenizer()
    token = tokenizer.tokenize(text="Hello world!", token_type=String)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Field(required=False))
    assert exc.value.messages[0].start_position.char_index == 0

# Generated at 2022-06-22 06:15:57.523614
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String, Integer, Array, Boolean, Optional

    class TestSchema(Schema):
        field = String(max_length=3)
        other_field = Integer(minimum=2)
        required_field = Array(items=Boolean())

    assert validate_with_positions(
        token=Token(
            key="field",
            value="hello",
            lookup={
                "field": Token(key="field", value="hello", lookup={}),
                "required_field": Token(
                    key="required_field", value=[], lookup={}
                ),
            },
        ),
        validator=TestSchema,
    ) == {"field": "hello", "required_field": []}


# Generated at 2022-06-22 06:16:05.364718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String

    from .test_tokens import example_token

    string_field = String(min_length=3)

    with pytest.raises(ValueError) as exc_info:
        validate_with_positions(token=example_token, validator=string_field)

    assert str(exc_info.value) == "Value cannot be parsed: 1:0:12: 'foo'"

# Generated at 2022-06-22 06:16:17.029499
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import pytest
    from typesystem.fields import Integer
    from typesystem.tokenize import tokenize

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=tokenize(json.dumps({"x": "foo"})), validator=Integer(name="x")
        )
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.index == ["x"]
    assert message.code == "invalid"
    assert message.start_position.line == 0
    assert message.start_position.char_index == 9
    assert message.end_position.line == 0
    assert message.end_position.char_index == 12

# Generated at 2022-06-22 06:16:26.721364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> None

    import pytest
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    schema = Schema({"name": Field()})

    token_tree = tokenize("""{"name": "John Doe"}""")

    result = validate_with_positions(token=token_tree, validator=schema)
    assert result == {"name": "John Doe"}

    token_tree = tokenize("""{"name": "John Doe" """)  # Missing a brace
    with pytest.raises(ValidationError):
        validate_with_positions(token=token_tree, validator=schema)

# Generated at 2022-06-22 06:16:33.759536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.parse import parse_token
    from typesystem.tokenize.tokenize import tokenize_string

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    a = parse_token(
        tokenize_string(
            """
            {
                "name": "Sallie",
                "age": 20
            }
        """
        )
    )
    b = parse_token(
        tokenize_string(
            """
            {
                "name": "Sallie"
            }
        """
        )
    )

# Generated at 2022-06-22 06:16:44.817163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema_schema = Schema(
        {
            "field1": Field(required=True),
            "field2": Field(required=True),
            "field3": Field(required=True),
        }
    )
    try:
        validate_with_positions(
            token=Token({}),
            validator=schema_schema,
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message == Message(
            text="The field 'field1' is required.",
            code="required",
            index=("field1",),
            start_position=Position(line=1, char_index=1),
            end_position=Position(line=1, char_index=1),
        )

# Generated at 2022-06-22 06:16:55.139421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import yaml
    from typesystem.tokenize.base import Tokenizer, Token

    class AuthToken(Field):
        def validate(self, value):
            return value.split(".")[-1]

    class User(Schema):
        name = AuthToken()

    user_field_type = User()
    user_field_type.validate({})
    json_tokenizer = Tokenizer(loads=json.loads)
    token = json_tokenizer.tokenize('{"name": "bWFj.dG9rZW4="}')
    user_field_type = User()
    user_field_type.validate(token.value)
    validate_with_positions(
        token=token, validator=user_field_type
    )


# Generated at 2022-06-22 06:17:01.134219
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    schema = Schema.from_dict({"name": {"type": "string"}})
    token = Token(
        value={"name": True}, type="object", start={"line": 0, "column": 0}, end={"line":0, "column": 14}
    )
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token, validator=schema)
        assert e.value.messages[0].code == "required"
        assert e.value.messages[0].start_position == {"line": 0, "column": 8}
        assert e.value.messages[0].end_position == {"line": 0, "column": 14}
        assert e.value.messages[0].text == "The field 'name' is required."

# Generated at 2022-06-22 06:17:12.092757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import Text
    from typesystem.tokenize import tokenize, Token
    from typesystem.tokenize.tokens import EndOfLine, Whitespace
    from typesystem.tokenize.positions import LinePosition, CharPosition, Position
    from typesystem.types import Text as TextType

    class TestSchema(Schema):
        test = Text(required=True)

    token = tokenize("\n   \n".encode())

# Generated at 2022-06-22 06:17:15.738383
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.parser import parse
    from typesystem.tokenize.tokens import Token
    from typesystem.types import Dict, String
    from typesystem.utils import ValidateWithPositions

    token = Token(value={"key": 1}, start=0, end=1)

    schema = Dict({"key": String()})

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.index == ["key"]
        assert message.code == "invalid_type"
        assert message.text == "Expected string for field key, got 1 (type: int)."

        assert message.start_position == 0
        assert message