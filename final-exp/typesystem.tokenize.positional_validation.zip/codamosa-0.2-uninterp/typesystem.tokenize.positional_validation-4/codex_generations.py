

# Generated at 2022-06-18 12:34:38.135598
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String(required=True)

    token = tokenize({"name": "foo"})
    validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-18 12:34:46.451262
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, char_index=7),
                end_position=Position(line=1, char_index=8),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:34:52.993386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "invalid"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is invalid.",
                code="invalid",
                index=["age"],
                start_position=Position(line=1, column=12, char_index=11),
                end_position=Position(line=1, column=16, char_index=15),
            )
        ]

# Generated at 2022-06-18 12:35:03.418412
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:35:10.671379
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize('{"foo": "bar"}')
    assert isinstance(token, Token)

    field = String(required=True)
    validate_with_positions(token=token, validator=field)

    field = String(required=False)
    validate_with_positions(token=token, validator=field)

    field = String(required=True)
    token = tokenizer.tokenize('{"foo": null}')
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value

# Generated at 2022-06-18 12:35:21.703354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:35:33.167309
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )
    validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:35:39.172876
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:35:51.180901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:01.787455
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:13.777702
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "30"
        }
        """
    )
    token = tokens[0]
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)
    assert excinfo.value.messages()[0].start_position.line_number == 3
    assert excinfo.value.messages()[0].start_position.char_index == 16
    assert excinfo.value.messages()[0].end_position.line_number == 3

# Generated at 2022-06-18 12:36:22.746145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 6, "char_index": 5},
    )


# Generated at 2022-06-18 12:36:30.110089
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 11
        assert error.messages()[0].end_position.line_index == 1
        assert error.messages()[0].end_position.char_index == 12
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:36:39.403367
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    tokenizer = Tokenizer(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name"],
        }
    )
    token = tokenizer.tokenize("{}")
    assert token.value == {}
    assert token.start.line == 1
    assert token.start.char_index == 0
    assert token.end.line == 1
    assert token.end.char_index == 2


# Generated at 2022-06-18 12:36:50.790788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 18},
    )


# Generated at 2022-06-18 12:37:01.692384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    schema = Schema(fields={"a": String(), "b": Integer()})
    token = tokenize({"a": "foo", "b": "bar"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:37:10.891901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("""
    {
      "name": "John",
      "age": "20"
    }
    """)

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' must be an integer."
        assert message.start_position.line == 3
        assert message.start_position.char_index == 12

# Generated at 2022-06-18 12:37:20.814896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": 42,
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 27},
    )


# Generated at 2022-06-18 12:37:32.789393
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)
        state = String(required=True)
        zip = String(required=True)

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)
       

# Generated at 2022-06-18 12:37:43.920115
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": None},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:37:58.263249
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:06.112402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json

    token = tokenize_json('{"a": "b"}')
    schema = Schema({"a": Field(type="string")})
    validate_with_positions(token=token, validator=schema)

    token = tokenize_json('{"a": "b"}')
    schema = Schema({"a": Field(type="string", required=True)})
    validate_with_positions(token=token, validator=schema)

    token = tokenize_json('{"a": "b"}')
    schema = Schema({"a": Field(type="string", required=False)})
    validate_with_positions(token=token, validator=schema)

    token = tokenize_json('{"a": "b"}')

# Generated at 2022-06-18 12:38:16.021524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    field = String(required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start_position

# Generated at 2022-06-18 12:38:24.971722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:38:35.877368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 2}

# Generated at 2022-06-18 12:38:47.157429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, StringToken
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()


# Generated at 2022-06-18 12:38:57.331427
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = parse_string("{}")
    assert isinstance(token, Token)

    field = String(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'data' is required."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 1
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 1

# Generated at 2022-06-18 12:39:08.302342
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=Position(line=1, column=1, char_index=0),
                end_position=Position(line=1, column=1, char_index=0),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:39:19.860840
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        type=TokenType.STRING,
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )

# Generated at 2022-06-18 12:39:29.990695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, column=1, char_index=0),
                end_position=Position(line=1, column=1, char_index=0),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:39:46.503576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John"}

    validate_with_positions(token=token, validator=User)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokenize({}), validator=User)


# Generated at 2022-06-18 12:39:55.974376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()

    token = Token(
        "Person",
        {
            "name": Token("String", ""),
        },
        start=(1, 1),
        end=(1, 1),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:40:07.833915
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 4},
    )


# Generated at 2022-06-18 12:40:18.692515
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )


# Generated at 2022-06-18 12:40:26.477951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=4, char_index=3),
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:40:37.529765
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "25"
        }
    """
    )
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' must be an integer."
        assert message.code == "type_error"
        assert message.index == ["age"]
        assert message.start_position.line == 3

# Generated at 2022-06-18 12:40:44.335140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:52.080120
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=3)

    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=schema) == "foo"

    token = tokenize("foobar")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:41:02.557842
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("{'foo': 'bar'}")
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar"}

    schema = {"foo": String()}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"
        assert message.index == ["foo"]
        assert message.start_position.line == 1
        assert message.start_position.char

# Generated at 2022-06-18 12:41:13.410004
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:41:41.389129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String()


# Generated at 2022-06-18 12:41:49.077293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String, Integer

    token = Token(
        token_type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "123",
                "zipcode": "12345",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=100),
    )

# Generated at 2022-06-18 12:41:59.904295
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="object")


# Generated at 2022-06-18 12:42:11.220622
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected an integer.",
                code="type_error.integer",
                index=["age"],
                start_position=Position(line=1, column=10, char_index=9),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]
    else:
        assert False, "Expected a ValidationError"

# Generated at 2022-06-18 12:42:20.875827
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 2, "char_index": 1},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."

# Generated at 2022-06-18 12:42:31.702452
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String(required=True)
    token = tokenize("{}")[0]
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 1
    assert exc_info.value.messages()[0].end_position.line == 1
    assert exc_info.value.messages()[0].end_position.char_index == 2

# Generated at 2022-06-18 12:42:39.615893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {"street": "Main", "number": "1"},
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 40},
    )


# Generated at 2022-06-18 12:42:50.044025
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    def assert_validation_error(
        token: Token,
        validator: typing.Union[Field, typing.Type[Schema]],
        expected_messages: typing.List[Message],
    ) -> None:
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError as error:
            assert error.messages() == expected_messages
        else:
            assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:43:00.570310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is not of type 'int'.",
            code="type_error.int",
            index=["age"],
            start_position=Position(line=1, column=9, char_index=8),
            end_position=Position(line=1, column=11, char_index=10),
        )
    ]

    token

# Generated at 2022-06-18 12:43:09.119262
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John Doe",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 20},
    )


# Generated at 2022-06-18 12:43:35.617823
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    token = tokens[0]
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    tokens = tokenize({"name": ""})
    token = tokens[0]

# Generated at 2022-06-18 12:43:45.948208
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 4, "char_index": 3},
    )

    field = String(min_length=4)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be at least 4 characters long."
        assert message.code == "min_length"
        assert message.index == []

# Generated at 2022-06-18 12:43:53.914110
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:44:01.421212
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "Foo"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    validate_with_positions(token=token, validator=String(required=True))

# Generated at 2022-06-18 12:44:08.746928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        "Person",
        {},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 6},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:44:20.987230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "Main St",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 100},
    )


# Generated at 2022-06-18 12:44:27.708194
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=10, column=1, char_index=100),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error