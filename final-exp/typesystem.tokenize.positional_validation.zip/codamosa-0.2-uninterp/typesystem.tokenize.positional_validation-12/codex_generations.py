

# Generated at 2022-06-18 12:34:36.346235
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    token = tokenize({"name": "John", "age": "20"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"age": "20"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:34:45.948663
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )

# Generated at 2022-06-18 12:34:52.935252
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.base import Message

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "thirty",
            "address": {
                "street": "",
                "city": "London",
                "country": "UK",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 5, "char_index": 0},
    )


# Generated at 2022-06-18 12:35:03.378947
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 2},
    )


# Generated at 2022-06-18 12:35:10.526269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""{"name": "John Doe"}""")
    schema = {"name": String()}

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Token.Position(line=1, column=1, char_index=0),
                end_position=Token.Position(line=1, column=1, char_index=0),
            )
        ]

# Generated at 2022-06-18 12:35:21.607976
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must have no more than 2 characters."
        assert message.code == "max_length"
        assert message.index == []
        assert message.start_position == {"line_index": 1, "char_index": 0}
        assert message.end

# Generated at 2022-06-18 12:35:33.089963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 2, "char_index": 1},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:35:39.087676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String()
    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    validate_with_positions(token=token, validator=field)

    field = String(required=True)
    token = Token(
        value=None,
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages())

# Generated at 2022-06-18 12:35:51.081567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "",
        },
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 2, "char_index": 1},
    )


# Generated at 2022-06-18 12:36:01.712912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 0

# Generated at 2022-06-18 12:36:14.146829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
            },
        },
        start=(1, 1),
        end=(1, 1),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1

# Generated at 2022-06-18 12:36:22.146983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema({"name": Field(required=True)})
    token = tokenize({"name": "John"})
    validate_with_positions(token=token, validator=schema)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:36:28.870299
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("""
        {
            "name": "John Doe",
            "age": "thirty"
        }
    """)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be an integer."
        assert message.code == "type_error.integer"
        assert message.index == ("age",)

# Generated at 2022-06-18 12:36:38.319710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 15},
    )

    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 8},
    )


# Generated at 2022-06-18 12:36:49.538897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class User(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=User) == {"name": "John"}

    token = tokenize({"name": ""})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=User) == {"name": ""}

    token = tokenize({})
    assert isinstance(token, Token)

# Generated at 2022-06-18 12:37:00.488193
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 18},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:37:10.066830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "",
        },
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:37:20.392729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected type 'integer' for value '30'",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:37:32.429571
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 14},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Value must be of type 'integer'."
        assert message.code == "type"

# Generated at 2022-06-18 12:37:38.889916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        token_type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "30",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 18},
    )
    validate_with_positions(token=token, validator=String(required=True))

# Generated at 2022-06-18 12:37:55.233453
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=1, char_index=1),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:38:04.216309
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:38:14.325391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages

# Generated at 2022-06-18 12:38:22.800099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.char_index == 17

# Generated at 2022-06-18 12:38:34.068791
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 12
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 14

# Generated at 2022-06-18 12:38:45.025626
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:55.844227
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:03.565668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].text == "The field 'name' is required."
        assert error

# Generated at 2022-06-18 12:39:15.813037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    string = String(max_length=10)

    token = tokenize("hello world")
    assert token == Token(value="hello world", start=(1, 0), end=(1, 11))

    try:
        validate_with_positions(token=token, validator=string)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Must have no more than 10 characters.",
                code="max_length",
                index=(),
                start_position=(1, 0),
                end_position=(1, 11),
            )
        ]
    else:
        assert False, "Expected ValidationError"



# Generated at 2022-06-18 12:39:27.003570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=4, char_index=3),
    )

    assert validate_with_positions(token=token, validator=String()) == "foo"

    try:
        validate_with_positions(token=token, validator=String(min_length=5))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be at least 5 characters long."

# Generated at 2022-06-18 12:39:45.058338
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    token = tokenize({"name": "John", "age": "30"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "30"}

    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John"}


# Generated at 2022-06-18 12:39:54.609312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )


# Generated at 2022-06-18 12:40:06.028847
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={"name": "joe"},
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={},
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )

# Generated at 2022-06-18 12:40:13.864829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main Street",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 50},
    )


# Generated at 2022-06-18 12:40:22.988369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected an integer.",
                code="invalid_type",
                index=("age",),
                start_position=Position(line=1, column=9, char_index=9),
                end_position=Position(line=1, column=11, char_index=11),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:33.678766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 14},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 8},
    )

# Generated at 2022-06-18 12:40:41.201259
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "zipcode": "12345",
                "city": "New York",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:40:49.628694
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str, required=True)
        age = Field(type=int, required=True)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Should have raised a ValidationError"

# Generated at 2022-06-18 12:41:01.022310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: 'invalid'}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is invalid.",
                code="invalid",
                index=["age"],
                start_position=Position(line=1, column=10, char_index=9),
                end_position=Position(line=1, column=15, char_index=14),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:41:12.377877
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    token = tokenize(
        {
            "name": "John",
            "age": "invalid",
            "address": "123 Main St.",
        }
    )


# Generated at 2022-06-18 12:41:31.848761
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        """
        {
            "foo": "bar",
            "baz": "qux"
        }
        """
    )

    assert isinstance(token, Token)


# Generated at 2022-06-18 12:41:41.916445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json
    from typesystem.tokenize.tokens import Token

    from typesystem.fields import String

    token = tokenize_json("{}")
    assert isinstance(token, Token)

    field = String(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert exc_info.value.messages()[0].start_position.char_index == 1
    assert exc_info.value.messages()[0].end_position.char_index == 1

# Generated at 2022-06-18 12:41:49.449538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John Doe",
            "age": "thirty",
            "address": {
                "street": "123 Main St.",
                "city": "Anytown",
                "state": "CA",
                "zip": "90210",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    class Person(Schema):
        name = String()
        age = String()
        address = Schema(fields={"street": String(), "city": String()})


# Generated at 2022-06-18 12:42:00.323758
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": None},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 16},
    )


# Generated at 2022-06-18 12:42:11.664156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )

    try:
        validate_with_positions(token=token, validator=String(min_length=4))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Must be at least 4 characters long.",
                code="min_length",
                index=(),
                start_position={"line_index": 0, "char_index": 0},
                end_position={"line_index": 0, "char_index": 3},
            )
        ]

# Generated at 2022-06-18 12:42:21.276268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:42:32.144411
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    field = String(name="name")
    assert validate_with_positions(token=token, validator=field) == "foo"

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    field = String(name="name", required=True)

# Generated at 2022-06-18 12:42:39.936410
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.tokenizer import tokenize

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize("{name: 'John'}")
    token = Token(
        type=TokenType.OBJECT,
        value=tokens,
        start=tokens[0].start,
        end=tokens[-1].end,
    )
    validate_with_positions(token=token, validator=Person)

    tokens = tokenize("{}")

# Generated at 2022-06-18 12:42:50.044291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected an integer.",
                code="invalid_type",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:43:00.570399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=5, char_index=19),
    )


# Generated at 2022-06-18 12:43:19.259050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:43:30.255264
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=3),
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:43:40.101058
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import JSONTokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    tokenizer = JSONTokenizer()
    token = tokenizer.tokenize('{"name": "John"}')
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenizer.tokenize('{"name": ""}')
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()

# Generated at 2022-06-18 12:43:49.833370
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = Token(
        value=None,
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        message

# Generated at 2022-06-18 12:43:56.544415
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    person = validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:44:06.508256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {"street": "Main Street", "number": "123"},
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 50},
    )


# Generated at 2022-06-18 12:44:18.783242
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 6
        assert error.messages()[0].text == "Expected int, got str."

# Generated at 2022-06-18 12:44:26.770293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize({"name": "John", "age": "invalid"})