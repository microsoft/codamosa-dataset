

# Generated at 2022-06-18 12:34:43.148001
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize({"foo": "bar"})
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar"}

    field = String()
    assert field.validate("bar") == "bar"
    assert validate_with_positions(token=token.lookup("foo"), validator=field) == "bar"

    field = String(required=True)
    assert field.validate("bar") == "bar"
    assert validate_with_positions(token=token.lookup("foo"), validator=field) == "bar"

    field = String(required=True)

# Generated at 2022-06-18 12:34:51.375578
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=30),
    )

# Generated at 2022-06-18 12:35:01.865482
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 3},
    )


# Generated at 2022-06-18 12:35:09.682256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 14},
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position == {"line": 1, "char_index": 0}
        assert message.end_position == {"line": 1, "char_index": 14}

# Generated at 2022-06-18 12:35:16.647881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("""
    {
        "a": 1,
        "b": 2,
        "c": 3
    }
    """)

    class MySchema(Schema):
        a = Field(type=int)
        b = Field(type=int)
        c = Field(type=int)

    validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-18 12:35:24.439092
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = tokenize({"name": "John", "age": "20"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "20"}
    assert token.start.line == 1
    assert token.start.char_index == 0
    assert token.end.line == 1
    assert token.end.char_index == 23


# Generated at 2022-06-18 12:35:35.297616
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = String()

    token = Token(
        type=TokenType.OBJECT,
        value={},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:35:41.752780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positions import Position

    class MySchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
        },
        token_type=TokenType.OBJECT,
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )


# Generated at 2022-06-18 12:35:54.320288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

# Generated at 2022-06-18 12:36:04.965332
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 15},
    )

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]

# Generated at 2022-06-18 12:36:18.854797
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == []
    else:
        assert False

    token = tokenize({})

# Generated at 2022-06-18 12:36:26.599922
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

# Generated at 2022-06-18 12:36:32.003785
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position


# Generated at 2022-06-18 12:36:36.760753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:40.907029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=3),
    )
    validate_with_positions(token=token, validator=String(min_length=4))

# Generated at 2022-06-18 12:36:49.588779
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json

    schema = Schema({"name": Field(required=True)})
    token = tokenize_json("{}")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:37:00.534799
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:37:10.097230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "foo",
            "age": "bar",
            "address": {
                "street": "baz",
                "city": "qux",
                "zip": "quux",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=10, char_index=10),
    )


# Generated at 2022-06-18 12:37:20.395381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": None,
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start=None,
        end=None,
    )

# Generated at 2022-06-18 12:37:32.429565
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({"name": ""})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:37:48.377961
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.start,
            end_position=token.end,
        )
    ]


# Generated at 2022-06-18 12:37:59.407720
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        token_type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "1 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="object")


# Generated at 2022-06-18 12:38:06.830239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class MyField(Field):
        def validate(self, value):
            if value != "foo":
                raise ValidationError(
                    [Message(text="Must be foo", code="invalid")]
                )

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=MyField())

# Generated at 2022-06-18 12:38:16.843005
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:38:25.259445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)

    schema = Schema(
        {
            "name": String(max_length=10),
            "age": String(max_length=2),
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-18 12:38:36.066593
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 9},
    )
    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position={"line_number": 1, "char_index": 0},
                end_position={"line_number": 1, "char_index": 9},
            )
        ]

# Generated at 2022-06-18 12:38:47.307335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=1, char_index=1),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()

# Generated at 2022-06-18 12:38:57.823509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    field = String(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:39:09.076321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 2, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:20.583376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:39:39.644034
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )

# Generated at 2022-06-18 12:39:47.330378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main St",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:39:56.519670
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)


# Generated at 2022-06-18 12:40:08.359298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John Doe"})
    assert isinstance(token, Token)
    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:40:19.179781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        {
            "name": "John Doe",
            "age": 42,
            "address": {
                "street": "123 Main St.",
                "city": "Anytown",
                "state": "NY",
                "zip": "10001",
            },
        }
    )
    assert isinstance(token, Token)

    field = String(required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-18 12:40:26.663994
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_string

    token = tokenize_string("""
    {
        "name": "John Doe",
        "age": "42",
        "address": {
            "street": "123 Main St.",
            "city": "Anytown",
            "state": "CA",
            "zip": "90210"
        }
    }
    """)

    class Address(Schema):
        street = Field(type="string")
        city = Field(type="string")
        state = Field(type="string")
        zip = Field(type="string")

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type=Address)


# Generated at 2022-06-18 12:40:37.637145
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:40:45.294420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token.from_json({"name": "John"})
    validate_with_positions(token=token, validator=Person)

    token = Token.from_json({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:40:55.052829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class User(Schema):
        name = String()
        age = Integer()

    schema = User()

    token = tokenize({"name": "", "age": "foo"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    messages = exc_info.value.messages()
    assert messages[0].start_position.char_index == 2
    assert messages[0].end_position.char_index == 3
    assert messages[1].start_position.char_index == 8

# Generated at 2022-06-18 12:41:03.978583
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {"street": "Main Street"},
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:41:31.257586
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize({"name": "John Doe", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not an integer.",
                code="invalid_type",
                index=["age"],
                start_position=Position(line_index=1, char_index=10),
                end_position=Position(line_index=1, char_index=12),
            )
        ]

# Generated at 2022-06-18 12:41:43.174558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    message = exc_info.value.messages[0]
    assert message.text == "Not a valid integer."
    assert message.code == "type"
    assert message.index == ["age"]

# Generated at 2022-06-18 12:41:50.195749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]

# Generated at 2022-06-18 12:42:01.528476
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 20,
    }

    token = tokenize({"name": "John", "age": "twenty"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:12.173366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'name' is required."
        assert message.start_

# Generated at 2022-06-18 12:42:21.114912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:42:31.971313
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    token = Token(
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )
    schema = Schema({"foo": Field(type="string")})
    validate_with_positions(token=token, validator=schema)

    token = Token(
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )
    schema = Schema({"bar": Field(type="string")})
   

# Generated at 2022-06-18 12:42:39.794149
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "32",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=100),
    )


# Generated at 2022-06-18 12:42:50.281883
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        type=TokenType.OBJECT,
        value={"foo": "bar"},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )
    schema = Schema({"foo": Field(required=True)})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:43:00.748258
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    field = String(required=True)
    token = Token(
        value={"a": "b"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=5, char_index=4),
    )

# Generated at 2022-06-18 12:43:43.419771
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=25, char_index=24),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]

# Generated at 2022-06-18 12:43:50.081465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    try:
        validate_with_positions(token=token, validator=Integer())
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 4}

# Generated at 2022-06-18 12:44:01.427256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(min_length=1)

    token = tokenize("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    message = exc_info.value.messages[0]
    assert message.text == "The field '' is required."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 0
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 0

    token = tokenize("foo")

# Generated at 2022-06-18 12:44:08.736347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )

# Generated at 2022-06-18 12:44:20.997975
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 8
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 10

# Generated at 2022-06-18 12:44:30.874409
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )