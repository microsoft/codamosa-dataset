

# Generated at 2022-06-18 12:34:32.461120
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)

    token = tokenize({"name": "John"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:34:42.934472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 13
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 14
        assert error.messages()[0].text == "Expected an integer."

# Generated at 2022-06-18 12:34:51.182451
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:35:01.780217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:35:09.868671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.fields import String, Integer

    schema = Schema(fields={"name": String(required=True), "age": Integer()})
    token = tokenize({"name": "John", "age": "32"})
    validate_with_positions(token=token, validator=schema)

    token = tokenize({"age": "32"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:35:21.102248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class User(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert error.messages()[0].text == "Must be an integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 11
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 13

# Generated at 2022-06-18 12:35:32.946538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:35:38.965671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    from typesystem.fields import String

    token = Token(
        value="foo",
        start=TokenType.Position(line=1, column=1, char_index=0),
        end=TokenType.Position(line=1, column=4, char_index=3),
    )
    assert validate_with_positions(token=token, validator=String(max_length=2)) == "foo"

    try:
        validate_with_positions(token=token, validator=String(max_length=1))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Must have no more than 1 characters."
        assert message.code == "max_length"

# Generated at 2022-06-18 12:35:49.385577
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]
    else:
        assert False

# Generated at 2022-06-18 12:36:00.620875
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:15.892450
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:24.542296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=tokenize.Position(line=1, column=1, char_index=0),
        end=tokenize.Position(line=3, column=1, char_index=25),
    )


# Generated at 2022-06-18 12:36:31.225843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "", "age": "", "address": {"city": "", "state": ""}},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )
    schema = Schema(
        {"name": String(required=True), "age": String(required=True)}
    )
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start

# Generated at 2022-06-18 12:36:39.742912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=Position(line=2, column=9, char_index=9),
                end_position=Position(line=2, column=9, char_index=9),
            )
        ]

# Generated at 2022-06-18 12:36:51.143535
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "abc"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is not of type 'integer'.",
            code="type_error.integer",
            index=("age",),
            start_position=Position(line=1, column=9, char_index=8),
            end_position=Position(line=1, column=12, char_index=11),
        )
    ]

# Generated at 2022-06-18 12:37:02.401338
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        value={"name": "John Doe"},
        token_type=TokenType.OBJECT,
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 13},
        children=[
            Token(
                value="John Doe",
                token_type=TokenType.STRING,
                start={"line_index": 1, "char_index": 8},
                end={"line_index": 1, "char_index": 13},
            )
        ],
    )

    class Person(Schema):
        name = Field(type="string", required=True)


# Generated at 2022-06-18 12:37:10.947410
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected an integer.",
                code="invalid_type",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:37:20.878078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("""
    {
        "name": "John",
        "age": "twenty"
    }
    """)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:37:32.882805
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:37:44.016351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)

    schema = Schema(
        fields={"name": String(max_length=10), "age": String(max_length=2)}
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 2
    assert exc_info.value.messages[0].text == "String value is too long."

# Generated at 2022-06-18 12:38:00.610659
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 3, "char_index": 1},
    )


# Generated at 2022-06-18 12:38:07.004036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False

# Generated at 2022-06-18 12:38:17.005694
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=10)
    token = Token(value="hello world", start=(0, 0), end=(0, 11))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages() == [
        Message(
            text="Ensure this value has at most 10 characters (it has 11).",
            code="max_length",
            index=[],
            start_position=(0, 0),
            end_position=(0, 11),
        )
    ]


# Generated at 2022-06-18 12:38:25.361459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 15}

# Generated at 2022-06-18 12:38:36.125770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    string = String(required=True)
    token = tokenize("{}")[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=string)

    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 1
    assert exc_info.value.messages()[0].end_position.line == 1
    assert exc_info.value.messages()[0].end_position.char_index == 2


# Generated at 2022-06-18 12:38:47.381840
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 3},
    )


# Generated at 2022-06-18 12:38:57.912426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize(
        {
            "name": "John",
            "age": "twenty",
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:39:09.217501
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    from typesystem.tokenize.tokens import Token

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:39:17.705811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    schema = Schema({"name": Field(required=True)})
    token = tokenize({"age": 42})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:39:28.925075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 9},
    )


# Generated at 2022-06-18 12:39:48.552512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        token_type=TokenType.OBJECT,
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=100),
    )

    class Address(Schema):
        street = Field(type="string", required=True)
        city = Field(type="string", required=True)
        state = Field(type="string", required=True)
        zip = Field(type="string", required=True)

# Generated at 2022-06-18 12:39:56.622421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 5},
    )


# Generated at 2022-06-18 12:40:07.833322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("{}")
    assert isinstance(token, Token)
    assert token.value == {}

    field = String(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'value' is required.",
            code="required",
            index=["value"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:40:18.693135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 9

# Generated at 2022-06-18 12:40:26.476732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 22},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:40:37.529774
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        token_type=TokenType.OBJECT,
        value={"name": "John Doe", "age": "42"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    validate_with_positions(token=token, validator=Person)

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")


# Generated at 2022-06-18 12:40:45.193432
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()

    class People(Schema):
        people = Array(items=Person())

    token = tokenize({"people": [{"name": "John", "age": "42"}]})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=People())

# Generated at 2022-06-18 12:40:52.674563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    assert validate_with_positions(token=tokens, validator=Person) == {"name": "John"}

    tokens = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=Person)

# Generated at 2022-06-18 12:41:02.800595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        """
        {
            "foo": "bar",
            "baz": "qux"
        }
    """
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=token, validator=String(required=True, min_length=10)
        )


# Generated at 2022-06-18 12:41:13.565894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        """
        {
            "name": "John Doe",
            "age": "42"
        }
        """
    )
    assert isinstance(token, Token)
    assert token.value == {
        "name": "John Doe",
        "age": "42",
    }

    field = String(name="name")
    assert validate_with_positions(token=token, validator=field) == "John Doe"

    field = String(name="age")
    assert validate_with_positions(token=token, validator=field) == "42"

    field = String(name="age", min_length=3)
    assert validate_with

# Generated at 2022-06-18 12:41:48.003081
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:41:54.939527
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    schema = String(min_length=1)
    token = tokenize("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert exc_info.value.messages() == [
        Message(
            text="The field '' is required.",
            code="required",
            index=(),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:42:06.547104
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:09.795093
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "foo",
            "age": "bar",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:42:20.314018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "invalid"
        }
        """
    )
    token = Token(tokens)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:30.812675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:38.625088
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "invalid"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    message = exc_info.value.messages[0]
    assert message.text == "Value must be an integer."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 14
    assert message.end_position.line_index == 0
    assert message.end_position.char_index == 20

# Generated at 2022-06-18 12:42:47.990812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=0),
    )


# Generated at 2022-06-18 12:42:56.018000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User)


# Generated at 2022-06-18 12:43:05.367143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize

    token = tokenize('{"foo": "bar"}')
    schema = Schema({"foo": Field(required=True)})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:43:41.028075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an int",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )

# Generated at 2022-06-18 12:43:50.521846
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=10)
    token = tokenize("foo")
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=schema) == "foo"

    token = tokenize("foobar")
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=schema) == "foobar"

    token = tokenize("foobarbaz")
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc

# Generated at 2022-06-18 12:44:02.202398
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({"name": None})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:44:09.111631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:44:21.269111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        value={"foo": "bar"},
        token_type=TokenType.OBJECT,
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )

    class TestSchema(Schema):
        foo = Field(type="string")


# Generated at 2022-06-18 12:44:31.177568
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    tokens = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=tokens, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position.line == 1
        assert message.start_position.char_index == 4
        assert message.end_position.line == 1
        assert message.end_position.char_index == 7

