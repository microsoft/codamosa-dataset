

# Generated at 2022-06-18 12:34:39.225597
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Should have raised ValidationError"

# Generated at 2022-06-18 12:34:48.175277
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 24},
    )


# Generated at 2022-06-18 12:34:57.437341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        {
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        }
    )
    assert isinstance(token, Token)


# Generated at 2022-06-18 12:35:06.178558
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(min_length=4))
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_index": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:35:17.195091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not of type 'integer'."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False

# Generated at 2022-06-18 12:35:24.740212
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )


# Generated at 2022-06-18 12:35:35.475029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "30",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

# Generated at 2022-06-18 12:35:46.401859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]


# Generated at 2022-06-18 12:35:57.544321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:36:07.943530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 4},
    )


# Generated at 2022-06-18 12:36:21.558893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 12},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 2},
    )

# Generated at 2022-06-18 12:36:28.510433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:36:37.877585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 2, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:43.875202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:36:54.185919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.base import ValidationError

    class TestSchema(Schema):
        foo = Integer(required=True)

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema())

# Generated at 2022-06-18 12:37:06.032405
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class User(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11

# Generated at 2022-06-18 12:37:17.777024
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
            },
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:37:28.113709
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:37:38.074475
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:37:49.994749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token

# Generated at 2022-06-18 12:38:05.611125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 5, "char_index": 20},
    )


# Generated at 2022-06-18 12:38:13.189221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:23.596154
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:38:34.874998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize({"name": "John", "age": "42"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John", "age": "42"})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person(required=["age"]))

# Generated at 2022-06-18 12:38:46.248943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
    {
        "name": "John",
        "age": "twenty"
    }
    """
    )
    token = Token(
        type=TokenType.OBJECT,
        value=tokens,
        start=tokens[0].start,
        end=tokens[-1].end,
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:38:57.235524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John"
    }
    """)

    schema = Schema(
        {"name": String(required=True)},
        validate_with_positions=validate_with_positions,
    )

    assert schema.validate(token) == {"name": "John"}

    with pytest.raises(ValidationError) as exc_info:
        schema.validate(Token(value={}, start=token.start, end=token.end))


# Generated at 2022-06-18 12:39:07.974725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:39:19.677065
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    token = tokenize('{"foo": "bar"}')
    schema = Schema({"foo": Field(type="string")})
    validate_with_positions(token=token, validator=schema)

    token = tokenize('{"foo": "bar"}')
    schema = Schema({"foo": Field(type="string", required=True)})
    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)
    assert excinfo.value.messages()[0].text == "The field 'foo' is required."
    assert excinfo.value.messages()[0].start_position.line == 1
    assert excinfo.value.messages()[0].start_position.char

# Generated at 2022-06-18 12:39:29.881867
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=None,
        end=None,
    )
    schema = Schema(
        {
            "name": String(),
            "age": String(),
            "address": Schema(
                {
                    "street": String(required=True),
                    "city": String(),
                    "state": String(),
                    "zip": String(),
                }
            ),
        }
    )


# Generated at 2022-06-18 12:39:40.390533
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        type=TokenType.OBJECT,
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )
    schema = Schema({"foo": Field(type="string")})
    validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-18 12:40:07.169278
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    tokens = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=tokens, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=2, char_index=4),
                end_position=Position(line=2, char_index=7),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:14.566087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 5},
    )

# Generated at 2022-06-18 12:40:23.602382
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("{'foo': 'bar'}")
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar"}

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:34.320616
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:40:41.605177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=("age",),
                start_position=Position(line=1, column=7, char_index=7),
                end_position=Position(line=1, column=7, char_index=7),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:50.512248
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )

# Generated at 2022-06-18 12:41:02.056602
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 8, "char_index": 7},
    )
    validator = String(name="name")

    validate_with_positions(token=token, validator=validator)

    token = Token(
        value={},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 2, "char_index": 1},
    )
    validator = String(name="name", required=True)


# Generated at 2022-06-18 12:41:12.834472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "Must be an integer."
    assert message.code == "type"
   

# Generated at 2022-06-18 12:41:19.586570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:41:25.392459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 20},
    )


# Generated at 2022-06-18 12:41:44.417381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe"
    }
    """)

    schema = {
        "name": String()
    }

    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:41:53.012499
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=20, char_index=19),
    )


# Generated at 2022-06-18 12:42:04.108310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=3),
    )
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = Token(
        value=None,
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=3),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(required=True))
    assert exc_info.value.messages()

# Generated at 2022-06-18 12:42:14.315881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:23.871361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=30),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:34.890780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)
    assert isinstance(token, Token)
    assert token.value == {"name": "John Doe", "age": "42"}

    class Person(Schema):
        name = String(min_length=5)
        age = String(min_length=2)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-18 12:42:43.924037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    token = Token(
        {
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:53.420828
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )


# Generated at 2022-06-18 12:43:04.865995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=2, column=1, char_index=0),
    )

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:43:11.424984
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenizer import tokenize

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)

    schema = Schema({"foo": String()})

    validate_with_positions(token=token, validator=schema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-18 12:43:36.921658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 1, "char_index": 10},
    )
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "20",
    }


# Generated at 2022-06-18 12:43:47.011516
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "42", "extra": "field"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:55.482241
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)

    schema = Schema(
        {
            "name": String(max_length=5),
            "age": String(max_length=2),
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages()
    assert messages[0].text == "The field 'name' is too long."
    assert messages[0].start_position.line == 3

# Generated at 2022-06-18 12:44:05.945762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:44:18.211775
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="string")

    token = tokenize({"name": "John", "age": "20", "address": "123 Main St."})


# Generated at 2022-06-18 12:44:26.449619
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        value={"foo": "bar"},
        token_type=TokenType.OBJECT,
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )

    class MySchema(Schema):
        foo = Field(type="string")
