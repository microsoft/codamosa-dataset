

# Generated at 2022-06-18 12:34:43.734437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main St",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 40},
    )


# Generated at 2022-06-18 12:34:51.816643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="invalid_type",
                index=["age"],
                start_position=Position(line=1, column=8, char_index=8),
                end_position=Position(line=1, column=10, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:35:02.311230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize({"name": "John", "age": "30"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:35:10.169783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    tokenizer = Tokenizer()
    token = tokenizer.tokenize("""
    {
        "foo": "bar",
        "baz": "qux"
    }
    """)

    schema = Schema(
        {"foo": String(required=True), "baz": String(required=True)}
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:35:21.331420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = tokenize("foo")
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert error.messages()[0].text == "Must have no more than 2 characters."
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.char_index == 3
    else:
        assert False, "Expected ValidationError"

    token = tokenize("foo")


# Generated at 2022-06-18 12:35:32.946540
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = Integer()

    token = Token(
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )


# Generated at 2022-06-18 12:35:38.967163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"name": "John"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 8, "char_index": 7},
    )


# Generated at 2022-06-18 12:35:50.932003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize("{}")
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]


# Generated at 2022-06-18 12:36:01.629312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": 30,
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:36:11.234919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    token = Token(
        value={
            "name": "John Doe",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 12},
    )


# Generated at 2022-06-18 12:36:24.103835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:30.222590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )

# Generated at 2022-06-18 12:36:39.403511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo", "age": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 16},
    )

    class Person(Schema):
        name = String()
        age = String()


# Generated at 2022-06-18 12:36:50.790255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 14},
    )

    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}


# Generated at 2022-06-18 12:37:01.734125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

# Generated at 2022-06-18 12:37:10.888869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=30),
    )


# Generated at 2022-06-18 12:37:20.815825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = tokenize({"name": "John", "age": "30"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "30"}


# Generated at 2022-06-18 12:37:32.840143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 12},
    )
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 2},
    )

# Generated at 2022-06-18 12:37:43.968963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        """
    {
        "foo": "bar",
        "baz": "qux",
        "quux": "corge"
    }
    """
    )
    assert isinstance(token, Token)
    assert token.value == {
        "foo": "bar",
        "baz": "qux",
        "quux": "corge",
    }

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-18 12:37:54.691410
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 12},
    )

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 12



# Generated at 2022-06-18 12:38:06.439802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    source = """
    {
        "name": "John",
        "age": "42"
    }
    """
    tokens = tokenize(source)
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 4
        assert error.messages()[0].start_position.char_index == 12
        assert error.messages()[0].end_position.line == 4
        assert error.messages()

# Generated at 2022-06-18 12:38:16.310725
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:38:25.081646
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 23},
    )


# Generated at 2022-06-18 12:38:35.943228
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": "42",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:38:47.194446
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John"}
    assert token.start.line == 1
    assert token.start.char_index == 0
    assert token.end.line == 1
    assert token.end.char_index == 14

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == []
    else:
        assert False, "Expected ValidationError"


# Generated at 2022-06-18 12:38:57.735378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:08.943563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        value="foo",
        type=TokenType.STRING,
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 1, "char_index": 4},
    )

    field = String(min_length=4)


# Generated at 2022-06-18 12:39:20.496355
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 2, "char_index": 1},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {
            "line": 1,
            "column": 1,
            "char_index": 0,
        }

# Generated at 2022-06-18 12:39:30.486982
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:41.161075
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize({"name": "John", "age": "30"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 30,
    }

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:54.441778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=10, char_index=9),
    )

# Generated at 2022-06-18 12:40:05.739777
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:40:13.446768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, char_index=9),
                end_position=Position(line=1, char_index=9),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:22.913365
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main St",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].text == "The field 'age' is not of type 'integer'."


# Generated at 2022-06-18 12:40:33.680445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 10
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 12

# Generated at 2022-06-18 12:40:41.202581
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:40:50.224223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "Must be an integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 10
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 12

# Generated at 2022-06-18 12:41:01.722675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 2, "char_index": 5},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "42",
    }


# Generated at 2022-06-18 12:41:12.417923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    class MyField(Field):
        def validate(self, value):
            if value == "foo":
                raise ValidationError(
                    [Message(text="foo is not allowed", code="invalid")]
                )
            return value

    token = Token(
        type=TokenType.OBJECT,
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )
    assert validate_with_positions(token=token, validator=MyField()) == {"foo": "bar"}


# Generated at 2022-06-18 12:41:20.738412
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class TestSchema(Schema):
        foo = Integer()

    token = Token(
        value={
            "foo": "bar",
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)


# Generated at 2022-06-18 12:41:39.755734
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 20},
    )


# Generated at 2022-06-18 12:41:48.461885
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken, StringToken

    class Person(Schema):
        name = Field(type=str)

    token = ObjectToken(
        {
            "name": StringToken(
                value="John",
                start={"line": 1, "column": 1, "char_index": 0},
                end={"line": 1, "column": 5, "char_index": 4},
            )
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 5, "char_index": 4},
    )


# Generated at 2022-06-18 12:41:58.948313
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()
        age = String()

    token = tokenize({"name": "John", "age": "20"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:09.443704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=3),
    )

# Generated at 2022-06-18 12:42:20.092816
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "ValidationError not raised."

# Generated at 2022-06-18 12:42:30.594190
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        foo = String(required=True)

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

    validate_with_positions(token=token, validator=TestSchema)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:42:39.001204
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 19},
    )

# Generated at 2022-06-18 12:42:48.470995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class TestSchema(Schema):
        field = String()

    token = Token(
        value={
            "field": "value",
            "other_field": "other_value",
            "other_field_2": "other_value_2",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:42:56.238296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    tokenizer = Tokenizer(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name"],
        }
    )
    token = tokenizer.tokenize({"age": "foo"})
    assert isinstance(token, Token)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String())
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()

# Generated at 2022-06-18 12:43:07.086031
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 15},
    )


# Generated at 2022-06-18 12:43:34.551800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:43:44.467157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""{"name": "John Doe"}""")
    schema = {"name": String()}
    validate_with_positions(token=token, validator=schema)

    token = tokenize("""{"name": ""}""")
    schema = {"name": String(min_length=1)}
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:43:53.093613
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = tokenize({"name": "John", "age": "30"})

# Generated at 2022-06-18 12:44:05.133913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:44:16.799534
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class MyField(Field):
        def validate(self, value):
            if value == "foo":
                raise ValidationError(
                    [Message(text="Not foo", code="not_foo", index=[])]
                )
            return value

    token = Token(
        "foo",
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=1, char_index=4),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MyField())

# Generated at 2022-06-18 12:44:25.673764
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "Alice", "age": "23"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is not of type 'int'.",
            code="invalid_type",
            index=["age"],
            start_position=Position(line=1, column=9, char_index=8),
            end_position=Position(line=1, column=11, char_index=10),
        )
    ]

# Generated at 2022-06-18 12:44:35.309802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 25},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
