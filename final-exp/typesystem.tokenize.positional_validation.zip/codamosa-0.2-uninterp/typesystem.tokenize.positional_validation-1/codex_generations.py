

# Generated at 2022-06-18 12:34:40.343633
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "32",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

# Generated at 2022-06-18 12:34:49.382050
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )

    field = String(max_length=2)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Ensure this value has at most 2 characters (it has 3)."
        assert message.code == "max_length"
        assert message.index == []
        assert message.start_position == {"line_index": 0, "char_index": 0}
        assert message.end

# Generated at 2022-06-18 12:35:00.948102
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )

# Generated at 2022-06-18 12:35:09.239475
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": "thirty",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.code

# Generated at 2022-06-18 12:35:20.528344
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=User)


# Generated at 2022-06-18 12:35:32.261995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "",
                "city": "New York",
                "state": "NY",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=0),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.mess

# Generated at 2022-06-18 12:35:39.873706
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42",
        "address": {
            "street": "123 Main Street",
            "city": "New York",
            "state": "NY",
            "zip": "10001"
        }
    }
    """)

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.start_position.line == 2

# Generated at 2022-06-18 12:35:51.943950
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )
    field = String(required=True)

# Generated at 2022-06-18 12:36:02.757574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "John Doe"},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=12),
    )

    class Person(Schema):
        name = Field(type=str)


# Generated at 2022-06-18 12:36:11.946177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )

# Generated at 2022-06-18 12:36:24.953710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": 30,
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:31.507596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "30"
        }
    """
    )
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' must be of type 'integer'."
        assert error.messages()[0].start_position.line == 4
        assert error.messages()[0].start_position.char_index == 16
        assert error.messages()[0].end_

# Generated at 2022-06-18 12:36:35.834951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "foo", "age": "bar"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages[0].start_position.line == 1
    assert exc_info.value.messages[0].start_position.column == 9
    assert exc_info.value.messages[0].end_position.line == 1
    assert exc_info.value.messages[0].end_position.column == 12

# Generated at 2022-06-18 12:36:47.044908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 9
    assert exc_info.value.messages()[0].end_position.line == 1
    assert exc_

# Generated at 2022-06-18 12:36:57.365878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "foo",
            "age": "bar",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )


# Generated at 2022-06-18 12:37:08.282968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "1234",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 5, "char_index": 0},
    )

    field = String(required=True)

# Generated at 2022-06-18 12:37:19.184149
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(min_length=4))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Must be at least 4 characters long.",
                code="min_length",
                index=(),
                start_position={"line_number": 1, "char_index": 0},
                end_position={"line_number": 1, "char_index": 3},
            )
        ]

# Generated at 2022-06-18 12:37:30.355590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "30",
        "address": {
            "street": "123 Main Street",
            "city": "New York",
            "state": "NY",
            "zip": "10001"
        }
    }
    """)

    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Expected a string."

# Generated at 2022-06-18 12:37:40.406501
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 1},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages()[0].start_position == {"line_index": 1, "char_index": 0}

# Generated at 2022-06-18 12:37:52.850481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "30"
    }
    """)
    assert isinstance(token, Token)

    class Person(Schema):
        name = String(max_length=5)
        age = String(max_length=2)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 2

    message = messages[0]
    assert message.text == "Ensure this value has at most 5 characters (it has 9)."

# Generated at 2022-06-18 12:38:04.994755
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "Must be an integer."
        assert error.messages()[0].start_position.line == 2
        assert error.messages()[0].start_position.char_index == 7
        assert error.messages()[0].end_position.line == 2
        assert error.messages()[0].end_position.char_index == 9

# Generated at 2022-06-18 12:38:14.803995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:38:24.272606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 2, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]
        assert message.text == "The field 'age' is required."
        assert message

# Generated at 2022-06-18 12:38:35.401317
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:38:46.640341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": 42,
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=20),
    )
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John Doe"
    }


# Generated at 2022-06-18 12:38:57.288543
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:07.254118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=(1, 1),
        end=(1, 4),
        lookup=lambda index: token,
    )

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'value' is required.",
                code="required",
                index=["value"],
                start_position=(1, 1),
                end_position=(1, 4),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:39:18.149263
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:39:29.342201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:39.817583
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error

# Generated at 2022-06-18 12:39:56.406210
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 11}
        assert error.messages()[0].end

# Generated at 2022-06-18 12:40:08.294040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position={"line_index": 1, "char_index": 0},
                end_position={"line_index": 1, "char_index": 10},
            )
        ]
   

# Generated at 2022-06-18 12:40:19.180982
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": {
                "first": "John",
                "last": "Doe",
            },
            "age": 42,
        },
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=33),
    )

    class Person(Schema):
        name = Field(type="object", required=True)
        age = Field(type="integer", required=True)

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:40:26.664361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize('{"foo": "bar"}')
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar"}
    assert token.start.char_index == 0
    assert token.end.char_index == 13
    assert token.start.line == 1
    assert token.end.line == 1
    assert token.start.column == 1
    assert token.end.column == 14

    field = String(name="foo")
    assert validate_with_positions(token=token, validator=field) == "bar"

    token = tokenize('{"foo": "bar", "baz": "qux"}')

# Generated at 2022-06-18 12:40:37.637445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

    field = String(name="name", required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 0}

# Generated at 2022-06-18 12:40:45.293662
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize("{}")
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token = tokenize('{"name": "foo"}')

# Generated at 2022-06-18 12:40:55.052830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 12},
    )

    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 2},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_

# Generated at 2022-06-18 12:41:03.809085
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(value={"name": None}, start=(1, 1), end=(1, 2))
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=(1, 1),
            end_position=(1, 2),
        )
    ]



# Generated at 2022-06-18 12:41:14.586180
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar",
        "baz": "qux"
    }
    """)

    field = String(required=True)


# Generated at 2022-06-18 12:41:22.407030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main",
                "zipcode": "12345",
                "city": "New York",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 0}

# Generated at 2022-06-18 12:41:41.721780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "30"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "thirty"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:41:49.337639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.positions import Position
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=30, char_index=29),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:00.195753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token

# Generated at 2022-06-18 12:42:11.531759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "42",
    }


# Generated at 2022-06-18 12:42:21.158768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:42:32.013218
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    schema = String(min_length=1)
    token = Token(value="foo", start=0, end=3)
    assert validate_with_positions(token=token, validator=schema) == "foo"

    schema = String(min_length=4)
    token = Token(value="foo", start=0, end=3)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position == 0
    assert exc_info.value.messages()[0].end_position == 3

    schema

# Generated at 2022-06-18 12:42:39.824000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:50.282676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "Joe",
            "age": "twenty",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start={
            "line": 1,
            "char_index": 0,
            "column": 1,
        },
        end={
            "line": 1,
            "char_index": 0,
            "column": 1,
        },
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.mess

# Generated at 2022-06-18 12:43:00.748590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 7
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 8

# Generated at 2022-06-18 12:43:09.228877
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-18 12:43:35.158884
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "20",
    }


# Generated at 2022-06-18 12:43:45.122925
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:43:53.521099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"




# Generated at 2022-06-18 12:44:05.167122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty-five",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error

# Generated at 2022-06-18 12:44:16.846368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )


# Generated at 2022-06-18 12:44:25.674099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer", required=False)

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
    }

    token = tokenize({})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
