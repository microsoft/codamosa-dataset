

# Generated at 2022-06-18 12:34:42.930029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": None},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 15},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:34:51.183640
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )
    field = String(name="name")

# Generated at 2022-06-18 12:35:01.033616
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "John Doe"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 13},
    )
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position == {"line": 1, "char_index": 0}
        assert message.end_position == {"line": 1, "char_index": 13}

# Generated at 2022-06-18 12:35:09.028544
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:35:20.271924
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        {
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:35:23.552672
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_json

    token = tokenize_json('{"a": "b"}')
    validate_with_positions(token=token, validator={"a": str})

# Generated at 2022-06-18 12:35:34.665368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 0},
    )
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 0
        assert error.mess

# Generated at 2022-06-18 12:35:45.294767
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' must be an integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11



# Generated at 2022-06-18 12:35:56.676652
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(required=True)
    token = Token(value="", start=None, end=None)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages() == [
        Message(
            text="The field '' is required.",
            code="required",
            index=(),
            start_position=None,
            end_position=None,
        )
    ]

    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=schema) == "foo"


# Generated at 2022-06-18 12:36:07.061389
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:36:19.965621
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)

    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    assert isinstance(token, Token)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:36:26.881230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:36:32.003901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:36:40.316358
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )

    person = validate_with_positions(token=token, validator=Person)
    assert person == {"name": "John"}


# Generated at 2022-06-18 12:36:51.237535
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_number": 1, "char_index": 1}

# Generated at 2022-06-18 12:37:02.495608
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zipcode": "",
            },
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )

    class PersonSchema(Schema):
        name = String(required=True)
        age = String(required=True)

# Generated at 2022-06-18 12:37:11.277938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": 20,
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_

# Generated at 2022-06-18 12:37:21.053815
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
            "address": {"street": "Main"},
            "friends": [{"name": "Jane"}, {"name": "Bob"}],
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc

# Generated at 2022-06-18 12:37:33.059540
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )

# Generated at 2022-06-18 12:37:44.211729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 4},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ("name",)

# Generated at 2022-06-18 12:37:58.753192
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:38:06.440388
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:38:16.310728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=100),
    )


# Generated at 2022-06-18 12:38:25.081445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John"}
    assert token.start.line_number == 1
    assert token.start.char_index == 0
    assert token.end.line_number == 1
    assert token.end.char_index == 15


# Generated at 2022-06-18 12:38:35.675998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )
    field = String(required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position={"line": 1, "char": 0},
                end_position={"line": 1, "char": 10},
            )
        ]

# Generated at 2022-06-18 12:38:46.922980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    tokens = tokenize("{name: 'John', age: '20'}")
    token = tokens[0]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "The field 'age' must be an integer."
    assert message.start_position.line_index == 0
    assert message.start_position.char_index == 15
    assert message.end_position.line_index

# Generated at 2022-06-18 12:38:57.424850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        token_type=TokenType.OBJECT,
        value={"name": "John"},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )

    class Person(Schema):
        name = Field(type="string", required=True)

    validate_with_positions(token=token, validator=Person)

    token = Token(
        token_type=TokenType.OBJECT,
        value={},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:39:08.416237
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)
        friends = Array(items=String())

    token = Token(
        {
            "name": "John",
            "age": "30",
            "friends": ["Mary", "Jane"],
            "address": "123 Main St",
        },
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=40),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message

# Generated at 2022-06-18 12:39:20.003585
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar",
        "baz": "qux"
    }
    """)

    assert isinstance(token, Token)
    assert token.value == {"foo": "bar", "baz": "qux"}

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'foo' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:39:30.128048
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(required=True)

    token = Token.from_json(
        {
            "name": "Person",
            "start": {"line": 1, "char": 0},
            "end": {"line": 1, "char": 5},
            "value": {"name": "John"},
        }
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=PersonSchema)


# Generated at 2022-06-18 12:39:43.936445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String(min_length=1)
    token = tokenize("foo")[0]
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=field) == "foo"

    token = tokenize("")[0]
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages()[0].text == "This field may not be blank."
    assert exc_info.value.messages()[0].start_position.char_index == 0

# Generated at 2022-06-18 12:39:53.907078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String(required=True)

    token = tokenize_string("""
    {
        "name": "John"
    }
    """)

    validate_with_positions(token=token, validator=MySchema)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema(required=True))


# Generated at 2022-06-18 12:40:05.134463
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize_string("{}")
    assert tokens == [Token(value={}, start=(1, 1), end=(1, 2))]

    try:
        validate_with_positions(token=tokens[0], validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
                start_position=(1, 2),
                end_position=(1, 2),
            )
        ]

# Generated at 2022-06-18 12:40:13.284905
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class TestSchema(Schema):
        field = String()

    token = Token(
        value={
            "field": "foo",
            "other_field": "bar",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:40:22.914022
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 15},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 0
        assert error.messages()[0].end_position.line_index == 1


# Generated at 2022-06-18 12:40:33.686121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line_index == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line_index == 1
        assert error.messages()[0].end_position.char_index == 11

# Generated at 2022-06-18 12:40:41.203129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:46.801800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John",
        "age": "30"
    }
    """)
    assert isinstance(token, Token)

    field = String(required=True)
    validate_with_positions(token=token, validator=field)

# Generated at 2022-06-18 12:40:53.484835
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import Field

    class Person(Schema):
        name = Field(str)

    class Address(Schema):
        street = Field(str)
        city = Field(str)
        state = Field(str)
        zip_code = Field(str)

    class PersonWithAddress(Schema):
        person = Field(Person)
        address = Field(Address)

    token = Token(
        value={
            "person": {"name": "John"},
            "address": {"street": "123 Main St", "city": "New York", "state": "NY"},
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

# Generated at 2022-06-18 12:41:03.250058
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {"street": "", "city": "", "country": ""},
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:41:15.832286
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:41:23.249182
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=20),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]


# Generated at 2022-06-18 12:41:29.701132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)
        children = Array(Integer())

    token = tokenize({"name": "John", "age": "42", "children": ["1", "2", "3"]})
    validate_with_positions(token=token, validator=Person)



# Generated at 2022-06-18 12:41:41.506038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 0
        assert message.end_position.line_number == 1

# Generated at 2022-06-18 12:41:49.165784
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:41:59.991864
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=4, char_index=3),
    )

# Generated at 2022-06-18 12:42:11.311254
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=1, char_index=10),
    )


# Generated at 2022-06-18 12:42:20.957045
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 0},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:31.799495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main St.",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages()[0].start_position.line_index == 0
        assert error.messages()[0].start_position.char_index

# Generated at 2022-06-18 12:42:39.675816
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 27},
    )

# Generated at 2022-06-18 12:42:54.863928
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 5},
    )


# Generated at 2022-06-18 12:43:05.818979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()

    class Address(Schema):
        street = String()

    class Company(Schema):
        name = String()
        address = Address()

    class User(Schema):
        person = Person()
        company = Company()

    token = Token(
        {
            "person": {"name": "John"},
            "company": {"name": "Acme", "address": {"street": "123 Main St"}},
        }
    )


# Generated at 2022-06-18 12:43:17.606963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:43:28.436442
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].text == "The field 'name' is required."

# Generated at 2022-06-18 12:43:38.498635
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 20},
    )

# Generated at 2022-06-18 12:43:48.400710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(min_length=1)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:43:55.204384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:44:05.815812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 3, "char_index": 1},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:44:18.034291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:44:26.172524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
