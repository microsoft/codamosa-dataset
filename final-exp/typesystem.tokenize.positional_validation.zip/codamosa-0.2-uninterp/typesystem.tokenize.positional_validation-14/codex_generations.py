

# Generated at 2022-06-18 12:34:43.218946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 10},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)


# Generated at 2022-06-18 12:34:51.436054
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_

# Generated at 2022-06-18 12:35:01.960794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:35:09.983606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        token_type=TokenType.OBJECT,
        value={
            "name": "John Doe",
            "age": "invalid",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=None,
        end=None,
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="object")

    class Address(Schema):
        street = Field(type="string")
        city = Field(type="string")
        state = Field(type="string")

# Generated at 2022-06-18 12:35:21.182977
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 9},
    )
    validator = String(required=True)
    assert validate_with_positions(token=token, validator=validator) == "foo"

    token = Token(
        value={"name": None},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 9},
    )
    validator = String(required=True)

# Generated at 2022-06-18 12:35:32.945418
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:35:38.938286
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "30"
    }
    """)

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Expected a string."
        assert message.code == "type_error"
        assert message.index == ["name"]
        assert message.start_position.line == 2
        assert message.start_position.char_index == 12
        assert message.end_position.line == 2

# Generated at 2022-06-18 12:35:50.883813
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John"})

# Generated at 2022-06-18 12:36:01.545988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "foo"},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=9),
    )

    schema = Schema({"name": String()})

    validate_with_positions(token=token, validator=schema)

    token = Token(
        type=TokenType.OBJECT,
        value={},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=9),
    )


# Generated at 2022-06-18 12:36:11.160165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message

# Generated at 2022-06-18 12:36:24.203765
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = tokenize({"name": None})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:30.977089
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    tokenizer = Tokenizer(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
            },
            "required": ["name"],
        }
    )
    token = Token(
        "object",
        {
            "name": "John",
            "age": "not an integer",
        },
        tokenizer.tokenize(
            {
                "name": "John",
                "age": "not an integer",
            }
        ),
    )

# Generated at 2022-06-18 12:36:39.576229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "abc",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:51.028628
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 11},
    )

    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 2},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_

# Generated at 2022-06-18 12:37:02.272082
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": None},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 15},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"
        assert message.index == ("name",)

# Generated at 2022-06-18 12:37:11.095942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 5},
    )
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position={"line_number": 1, "char_index": 0},
                end_position={"line_number": 1, "char_index": 5},
            )
        ]
   

# Generated at 2022-06-18 12:37:20.938643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=30),
    )


# Generated at 2022-06-18 12:37:32.925471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main Street",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:37:44.066825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 5, "char_index": 21},
    )


# Generated at 2022-06-18 12:37:55.640914
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = String()

    token = tokenize({"name": "John", "age": "30"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "30"}

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:38:14.324671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=3)
    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=schema) == "foo"

    token = tokenize("foo")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(min_length=5))

# Generated at 2022-06-18 12:38:23.702175
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 9

# Generated at 2022-06-18 12:38:34.989012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )

# Generated at 2022-06-18 12:38:46.433429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=Position(line=1, column=1, char_index=0),
                end_position=Position(line=1, column=1, char_index=0),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:57.287900
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

# Generated at 2022-06-18 12:39:08.020882
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar",
        "baz": "qux"
    }
    """)
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar", "baz": "qux"}

    # Validate with a field
    field = String(required=True)
    validate_with_positions(token=token, validator=field)

    # Validate with a schema
    class MySchema(Schema):
        foo = String(required=True)
        baz = String(required=True)

    validate_with_positions(token=token, validator=MySchema)



# Generated at 2022-06-18 12:39:19.677119
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token.parse(
        {
            "name": "John",
            "age": 30,
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        }
    )

# Generated at 2022-06-18 12:39:29.885151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 1},
    )

    field = String(required=True)

# Generated at 2022-06-18 12:39:40.391596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "The field 'age' is required."
    assert message.start_position.line == 1
    assert message.start_position.column == 1
   

# Generated at 2022-06-18 12:39:47.826046
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token

    tokenizer = Tokenizer(
        {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "age": {"type": "integer"},
                "address": {
                    "type": "object",
                    "properties": {
                        "street": {"type": "string"},
                        "city": {"type": "string"},
                        "state": {"type": "string"},
                    },
                },
            },
        }
    )

# Generated at 2022-06-18 12:40:07.075509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.end,
            end_position=token.end,
        )
    ]



# Generated at 2022-06-18 12:40:14.506030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"name": None},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 14},
    )
    validator = Schema({"name": String()})

# Generated at 2022-06-18 12:40:23.566544
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=("age",),
                start_position=Position(line=1, char_index=9),
                end_position=Position(line=1, char_index=12),
            )
        ]
    else:
        assert False, "Expected ValidationError"



# Generated at 2022-06-18 12:40:34.256817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize_string("{name: 'John', age: '30'}")

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not a valid integer.",
                code="invalid",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:41.539372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "foo": "bar",
            "bar": "baz",
            "baz": "qux",
            "qux": "quux",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    field = String(required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:40:50.516096
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:41:02.062923
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        token_type=TokenType.OBJECT,
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=2, char_index=1),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:41:12.834392
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    class MyField(Field):
        def validate(self, value):
            if value == "foo":
                raise ValidationError(
                    [Message("The field is not foo.", code="not_foo")]
                )
            return value

    class MySchema(Schema):
        foo = MyField()

    token = Token(
        type=TokenType.OBJECT,
        value={"foo": "bar"},
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )

    assert validate_with_positions(token=token, validator=MySchema) == {"foo": "bar"}

    with pytest.raises(ValidationError) as exc_info:
        validate_with_

# Generated at 2022-06-18 12:41:21.082817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": 30,
            "address": {
                "street": "Main Street",
                "city": "New York",
                "state": "NY",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )


# Generated at 2022-06-18 12:41:31.767920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)
        state = String(required=True)
        zip = String(required=True)

    class Person(Schema):
        name = String(required=True)

# Generated at 2022-06-18 12:41:48.070280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String


# Generated at 2022-06-18 12:41:58.437604
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
            "address": {"street": "Main St"},
            "friends": [{"name": "Bob"}],
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()


# Generated at 2022-06-18 12:42:08.967526
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 100},
    )


# Generated at 2022-06-18 12:42:19.411936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class TestSchema(Schema):
        foo = String(required=True)
        bar = String(required=True)

    token = Token(
        value={
            "foo": "foo",
            "bar": "bar",
            "baz": "baz",
        },
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=31),
    )
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        assert error.messages()

# Generated at 2022-06-18 12:42:24.724319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "twenty"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:35.014566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""{
        "foo": "bar",
        "baz": "qux"
    }""")

    schema = Schema({"foo": String(required=True), "baz": String()})

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=schema)


# Generated at 2022-06-18 12:42:44.376943
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:42:49.632961
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)

    schema = Schema({"foo": String()})

    validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:42:56.389054
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    string = String()

    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=string) == "foo"

    token = tokenize("")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=string)

# Generated at 2022-06-18 12:43:06.334253
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:43:18.532688
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:29.242407
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "zip": "",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )


# Generated at 2022-06-18 12:43:39.351946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 2, "char": 1},
    )


# Generated at 2022-06-18 12:43:49.125924
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 11
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 13

# Generated at 2022-06-18 12:44:00.096863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=4, char_index=3),
    )


# Generated at 2022-06-18 12:44:08.022444
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String, Integer

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": "John Doe",
            "age": "42",
            "address": {
                "street": "1 Main Street",
                "city": "San Francisco",
                "state": "CA",
                "zip": "94102",
            },
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )

    class Person(Schema):
        name = String(max_length=10)
        age = Integer()


# Generated at 2022-06-18 12:44:20.312268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": "John Doe",
            "age": "invalid",
            "address": {
                "street": "",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )

    class Person(Schema):
        name = String(max_length=10)
        age = String(max_length=3)


# Generated at 2022-06-18 12:44:30.422469
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(min_length=1)

    token = tokenize("")[0]
    assert token == Token(
        value="",
        start=token.start,
        end=token.end,
        lookup=token.lookup,
        parent=None,
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field '' is required.",
                code="required",
                index=(),
                start_position=token.start,
                end_position=token.end,
            )
        ]
