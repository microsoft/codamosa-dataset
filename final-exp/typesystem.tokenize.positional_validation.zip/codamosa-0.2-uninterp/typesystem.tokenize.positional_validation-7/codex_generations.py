

# Generated at 2022-06-18 12:34:36.227695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 6, "char_index": 0},
    )


# Generated at 2022-06-18 12:34:45.405332
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "1",
                "city": "New York",
            },
        },
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=100),
    )

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:34:52.909466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=25),
    )


# Generated at 2022-06-18 12:35:03.377848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "Bob",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 5},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:35:10.613464
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    field = String(min_length=10)
    token = Token(
        value="foo",
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=3),
    )

# Generated at 2022-06-18 12:35:21.671732
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "Bob"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "Bob"}

    token = tokenize({})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:35:33.126351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )

# Generated at 2022-06-18 12:35:42.156199
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "Main Street",
                "number": "123",
                "zip": "12345",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 100},
    )

    field = String(name="name")
    assert validate_with_positions(token=token, validator=field) == "John"

    field = String(name="age", min_length=2)

# Generated at 2022-06-18 12:35:54.533489
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:36:00.896113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        token_type=TokenType.OBJECT,
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )

    class MySchema(Schema):
        foo = Field(type="string")

    validate_with_positions(token=token, validator=MySchema)

    class MySchema(Schema):
        foo = Field(type="string", required=True)


# Generated at 2022-06-18 12:36:16.360157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:24.953831
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=5, char_index=0),
    )


# Generated at 2022-06-18 12:36:31.321670
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=10)
    token = tokenize("hello world")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages == [
        Message(
            text="Ensure this value has at most 10 characters (it has 11).",
            code="max_length",
            index=[],
            start_position=Token.Position(line=1, char_index=0),
            end_position=Token.Position(line=1, char_index=11),
        )
    ]

# Generated at 2022-06-18 12:36:39.849594
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:36:51.182484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    tokens = tokenize(
        {
            "name": "John",
            "age": 30,
            "address": {
                "street": "Main Street",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        }
    )
    token = Token(value=tokens)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.mess

# Generated at 2022-06-18 12:37:02.448591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:37:11.219828
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "unknown",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:37:21.025546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    tokenizer = Tokenizer(Person)
    tokens = tokenizer.tokenize('{"name": "John", "age": "invalid"}')

# Generated at 2022-06-18 12:37:33.012690
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "not an integer"
        }
    """
    )
    token = tokens[0]

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:37:44.163416
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:38:01.021417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "John", "age": 20},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-18 12:38:12.598115
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "twenty-five",
            "address": "123 Main St",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 30},
    )


# Generated at 2022-06-18 12:38:23.114369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line_number=1, char_index=0),
        end=Token.Position(line_number=1, char_index=10),
    )


# Generated at 2022-06-18 12:38:34.581351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."

# Generated at 2022-06-18 12:38:42.243953
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(min_length=1)
    token = tokenize("")[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position.char_index == 0

# Generated at 2022-06-18 12:38:50.204967
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:39:00.066021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:11.400946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})

# Generated at 2022-06-18 12:39:22.638182
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(max_length=10)

    token = Token(
        value={
            "name": "John Doe",
            "age": 30,
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 20},
    )


# Generated at 2022-06-18 12:39:27.892496
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Value must be of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:39:47.361791
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 20},
    )


# Generated at 2022-06-18 12:39:56.508838
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 3, "char": 1},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].start_position == {"line": 1, "char": 0}

# Generated at 2022-06-18 12:40:04.105925
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.tokenizers import tokenize_json
    from typesystem.fields import String

    json = '{"foo": "bar"}'
    tokens = tokenize_json(json)
    token = Token(tokens, TokenType.OBJECT, json)
    validate_with_positions(token=token, validator={"foo": String()})



# Generated at 2022-06-18 12:40:12.616809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:40:22.718279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token.from_dict({"name": "John"})
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = Token.from_dict({})

# Generated at 2022-06-18 12:40:33.633041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
            },
        },
        token_type=TokenType.OBJECT,
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=100),
    )


# Generated at 2022-06-18 12:40:40.354774
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        raise AssertionError("Expected ValidationError")

# Generated at 2022-06-18 12:40:49.275177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 2, "char_index": 5},
    )


# Generated at 2022-06-18 12:41:00.568850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:41:11.412649
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "21",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 5, "char_index": 17},
    )

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:41:46.865399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "address": {
                "street": "",
                "city": "",
                "country": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]

# Generated at 2022-06-18 12:41:55.695957
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:42:07.340886
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "42"}

    value = validate_with_positions(token=token, validator=Person)
    assert value == {"name": "John", "age": 42}

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John"}

    with pytest.raises(ValidationError) as exc_info:
        validate_

# Generated at 2022-06-18 12:42:17.750891
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:42:27.834778
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    token = Token(tokens)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    tokens = tokenize({})
    token = Token(tokens)

# Generated at 2022-06-18 12:42:37.157051
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:42:46.920733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({"name": None})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:55.449906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=4, char_index=3),
    )
    field = String(min_length=4)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Must be at least 4 characters long."
        assert message.code == "min_length"
        assert message.index == []

# Generated at 2022-06-18 12:43:06.410542
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 8
        assert error.messages

# Generated at 2022-06-18 12:43:17.982224
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=10, char_index=9),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=UserSchema)


# Generated at 2022-06-18 12:44:18.825175
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokenize import tokenize

    schema = Schema({"name": String(required=True)})
    token = tokenize({"age": 20})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position.line_number == 1
    assert message.start_position.char_index == 1
    assert message.end_position.line_number == 1
    assert message.end_position.char_index == 1

# Generated at 2022-06-18 12:44:26.790665
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 1},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position == {"line_index": 1, "char_index": 0}