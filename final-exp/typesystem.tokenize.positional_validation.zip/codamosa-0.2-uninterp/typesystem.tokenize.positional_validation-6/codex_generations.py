

# Generated at 2022-06-18 12:34:34.414794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "John Doe"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 14},
    )
    validator = String(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-18 12:34:44.030532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "twenty"
        }
        """
    )
    token = tokens[0]

# Generated at 2022-06-18 12:34:52.044494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 1
    assert messages[0].text == "The field 'age' is required."

# Generated at 2022-06-18 12:35:02.497724
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=4, char_index=3),
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:35:10.295532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John Doe",
            "age": "30",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    field = String(required=True)

# Generated at 2022-06-18 12:35:21.438421
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar",
        "baz": "qux"
    }
    """)

    schema = Schema(
        {
            "foo": String(max_length=3),
            "baz": String(max_length=3),
        }
    )


# Generated at 2022-06-18 12:35:32.944627
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start=None,
        end=None,
    )


# Generated at 2022-06-18 12:35:38.938683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:35:49.347487
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize({"name": "John Doe"})
    assert isinstance(token, Token)

    field = String(required=True)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:36:00.609731
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    string = String(max_length=10)
    token = Token(value="hello world", start=0, end=11)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=string)
    assert exc_info.value.messages() == [
        Message(
            text="Ensure this value has at most 10 characters (it has 11).",
            code="max_length",
            index=[],
            start_position=0,
            end_position=11,
        )
    ]

    token = tokenize("hello world")

# Generated at 2022-06-18 12:36:12.424931
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=10, column=1, char_index=100),
    )

# Generated at 2022-06-18 12:36:21.807312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({"name": None})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:28.707268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": 42,
        },
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=20),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        message = messages[0]

# Generated at 2022-06-18 12:36:38.160921
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 2},
    )


# Generated at 2022-06-18 12:36:49.206927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )


# Generated at 2022-06-18 12:37:00.203328
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:37:09.820008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

# Generated at 2022-06-18 12:37:20.172789
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:37:32.335372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
    assert message.start_position == {"line_index": 0, "char_index": 0}
    assert message.end_

# Generated at 2022-06-18 12:37:43.392535
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        type=TokenType.OBJECT,
        value={"name": "John Doe"},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 14},
    )

    class Person(Schema):
        name = Field(type="string", required=True)


# Generated at 2022-06-18 12:38:00.449539
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )


# Generated at 2022-06-18 12:38:07.484735
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        token_type=TokenType.OBJECT,
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}


# Generated at 2022-06-18 12:38:15.244545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import Integer

    schema = Integer()
    token = tokenize("123")[0]
    assert validate_with_positions(token=token, validator=schema) == 123

    token = tokenize("abc")[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position.char_index == 0
    assert exc_info.value.messages()[0].end_position.char_index == 3

# Generated at 2022-06-18 12:38:24.540091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "Value must be an integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11

# Generated at 2022-06-18 12:38:35.573927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:38:46.845062
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = String()

    token = Token(
        value={
            "foo": "bar",
            "baz": "qux",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:38:57.331488
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:39:07.350676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "invalid"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is invalid.",
            code="invalid",
            index=["age"],
            start_position=token.lookup(["age"]).start,
            end_position=token.lookup(["age"]).end,
        )
    ]

# Generated at 2022-06-18 12:39:18.236108
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:39:29.424041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=5, char_index=0),
    )


# Generated at 2022-06-18 12:39:49.180942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    token = Token(
        token_type=TokenType.OBJECT,
        value={"foo": "bar"},
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )
    schema = Schema({"foo": Field(type="string")})

# Generated at 2022-06-18 12:39:55.850964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)

    token = tokenize({"name": "John Doe"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 0



# Generated at 2022-06-18 12:40:07.704850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char": 1},
        end={"line": 3, "char": 1},
    )


# Generated at 2022-06-18 12:40:18.131881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    token = Token(tokens)
    validate_with_positions(token=token, validator=Person)

    tokens = tokenize({})
    token = Token(tokens)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.char_index == 1

# Generated at 2022-06-18 12:40:24.836354
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize('{"foo": "bar"}')
    schema = Schema({"foo": Field(required=True)})
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:35.651223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 32},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1

# Generated at 2022-06-18 12:40:43.786566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "thirty"
    }
    """)

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 3
        assert error.messages()[0].start_position.column == 11
        assert error.messages()[0].end_position.line == 3
        assert error.messages()[0].end_position.column == 16
        assert error.messages()[0].text == "Must be of type integer."

       

# Generated at 2022-06-18 12:40:51.659103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John Doe",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'name' is required."
        assert error

# Generated at 2022-06-18 12:41:02.489573
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    schema = Schema(properties={"foo": String(), "bar": Integer()})
    token = tokenize({"foo": "hello", "bar": "world"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages[0].text == "The field 'bar' is not a valid integer."
    assert exc_info.value.messages[0].start_position.line_number == 1
    assert exc_info.value.messages[0].start_position.char_index == 14
    assert exc_info.value.mess

# Generated at 2022-06-18 12:41:13.327856
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:41:37.811327
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "20"
        }
    """
    )
    token = tokens[0]
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 3
        assert error.messages()[0].start_position.char_index == 17
        assert error.messages()[0].end_position.line == 3
        assert error.messages()[0].end_position.char_index == 19

# Generated at 2022-06-18 12:41:47.255298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value={"name": "John"},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )


# Generated at 2022-06-18 12:41:55.267107
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(min_length=4))
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_index": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:42:06.897101
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    schema = {"name": String(), "age": Integer()}
    token = tokenize_json("{}")
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

# Generated at 2022-06-18 12:42:17.242228
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "email": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == {"line_index": 1, "char_index": 0}

# Generated at 2022-06-18 12:42:27.309072
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=3),
    )
    assert validate_with_positions(token=token, validator=String(max_length=2)) == "foo"


# Generated at 2022-06-18 12:42:36.748344
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, column=1, char_index=0),
                end_position=Position(line=1, column=1, char_index=0),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:42:46.314381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 4, "char_index": 33},
    )


# Generated at 2022-06-18 12:42:55.059017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=tokenize.Position(line=1, column=1, char_index=0),
        end=tokenize.Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:43:06.017487
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' must be an integer."
        assert message.code == "type_error"

# Generated at 2022-06-18 12:43:42.365958
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:51.358073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 12},
    )

    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position={"line": 1, "char_index": 0},
                end_position={"line": 1, "char_index": 12},
            )
        ]

# Generated at 2022-06-18 12:43:57.348563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: '30'}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=("age",),
                start_position=token.lookup(("age",)).start,
                end_position=token.lookup(("age",)).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:44:06.895498
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        "Person",
        {
            "name": Token("String", ""),
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=10, char_index=9),
    )


# Generated at 2022-06-18 12:44:19.151873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:44:30.074265
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)

    assert isinstance(token, Token)

    class Person(Schema):
        name = String(max_length=10)
        age = String(max_length=2)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Ensure this value has at most 2 characters (it has 3)."