

# Generated at 2022-06-18 12:34:32.247119
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:34:42.892529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType

    from typesystem.fields import String

    token = Token(
        value="foo",
        token_type=TokenType.STRING,
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=4),
    )
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = Token(
        value="foo",
        token_type=TokenType.STRING,
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=4),
    )
    assert validate_with_positions(token=token, validator=String(min_length=4))

# Generated at 2022-06-18 12:34:46.650124
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    token = tokenize("""
    {
        "name": "John",
        "age": "20"
    }
    """)

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")


# Generated at 2022-06-18 12:34:52.958881
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = parse_string("{}")
    assert isinstance(token, Token)
    assert token.value == {}

    field = String(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:35:03.045054
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11

# Generated at 2022-06-18 12:35:10.526809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:35:21.663118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={
            "age": "20",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:35:33.126057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    field = String(required=True)


# Generated at 2022-06-18 12:35:39.130728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:35:51.128412
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=20),
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "30",
    }


# Generated at 2022-06-18 12:36:00.868854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "42"
    }
    """)

    class Person(Schema):
        name = String()
        age = String()

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'age' is not a valid string."
        assert message.start_position.line_number == 4
        assert message.start_position.char_index == 16
        assert message.end_position.line_number == 4
        assert message.end_

# Generated at 2022-06-18 12:36:10.563474
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 23},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:36:20.349272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "foo",
            "age": "bar",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:36:27.590291
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=100),
    )


# Generated at 2022-06-18 12:36:36.872076
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "country": "USA",
            },
        },
        start=None,
        end=None,
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."

# Generated at 2022-06-18 12:36:47.700350
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "foo",
            "age": "bar",
        },
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].text == "The field 'age' is not valid."


# Generated at 2022-06-18 12:36:58.021972
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

# Generated at 2022-06-18 12:37:08.828983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 0}


# Generated at 2022-06-18 12:37:19.268569
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        {
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 10},
    )


# Generated at 2022-06-18 12:37:30.537727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 15},
    )


# Generated at 2022-06-18 12:37:49.995784
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "John",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:38:00.568826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not of type 'integer'."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 8
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False

# Generated at 2022-06-18 12:38:05.641643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    schema = String(required=True)
    token = tokenize("{}")[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 1

# Generated at 2022-06-18 12:38:15.536876
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 10},
    )


# Generated at 2022-06-18 12:38:20.478387
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize({"foo": "bar"})
    assert isinstance(token, Token)

    validate_with_positions(token=token, validator=String())

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(required=True))

    assert exc_info.value.messages() == [
        Message(
            text="The field 'foo' is required.",
            code="required",
            index=["foo"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:38:27.030320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 5
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 8
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:36.633710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 8
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 10
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:47.769579
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:38:58.217684
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not of type 'int'."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False

# Generated at 2022-06-18 12:39:09.685435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token = token

# Generated at 2022-06-18 12:39:33.042509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].text == "The field 'name' is required."

# Generated at 2022-06-18 12:39:43.929736
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "10001",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

    # Test that the error message contains the correct start and end positions

# Generated at 2022-06-18 12:39:53.907195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String(required=True)

    token = tokenize({"name": "John Doe"})
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=UserSchema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:40:05.514252
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, column=1, char_index=0),
                end_position=Position(line=1, column=1, char_index=0),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:13.572907
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=4, char_index=3),
    )
    field = String(min_length=5)

# Generated at 2022-06-18 12:40:22.951128
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:33.281644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Value '30' is not a valid integer.",
                code="invalid",
                index=("age",),
                start_position=Position(line=1, char_index=10),
                end_position=Position(line=1, char_index=12),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:40.091353
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize_json("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=("name",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:40:48.965863
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 20, "char_index": 19},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "Value must be of type integer."


# Generated at 2022-06-18 12:40:54.399278
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=20),
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "30",
    }


# Generated at 2022-06-18 12:41:36.790010
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:41:46.794789
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "occupation": "Software Engineer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 50},
    )


# Generated at 2022-06-18 12:41:52.038283
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )


# Generated at 2022-06-18 12:42:02.440829
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: 'invalid'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is not a valid integer.",
            code="invalid_type",
            index=("age",),
            start_position=token.lookup(("age",)).start,
            end_position=token.lookup(("age",)).end,
        )
    ]

# Generated at 2022-06-18 12:42:13.003879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: '30'}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:42:22.549658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 13},
    )


# Generated at 2022-06-18 12:42:28.791812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=3),
    )
    validate_with_positions(token=token, validator=String(max_length=2))

# Generated at 2022-06-18 12:42:33.379989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer, Array

    class Person(Schema):
        name = String()
        age = Integer()
        friends = Array(items=String())

    token = tokenize(
        {
            "name": "John",
            "age": "30",
            "friends": ["Jane", "Joe"],
            "address": "123 Main St",
        }
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'address' is not a valid field."

# Generated at 2022-06-18 12:42:40.671275
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize_json
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize_json("""{"name": "John Doe"}""")
    assert isinstance(token, Token)
    assert token.value == {"name": "John Doe"}

    assert validate_with_positions(token=token, validator=String()) == "John Doe"

    token = tokenize_json("""{"name": "John Doe", "age": "42"}""")
    assert isinstance(token, Token)
    assert token.value == {"name": "John Doe", "age": "42"}

    assert validate_with_positions(token=token, validator=String()) == "John Doe"


# Generated at 2022-06-18 12:42:50.950381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        "person",
        {
            "name": Token("name", "John"),
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=10),
    )


# Generated at 2022-06-18 12:43:34.013132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 32},
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:43:43.613589
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexer import lex
    from typesystem.tokenize.parser import parse

    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    tokens = lex("name: 'John'")
    token = parse(tokens)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 0

# Generated at 2022-06-18 12:43:52.635175
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "1 Main Street",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:44:04.962387
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The value 30 is not a valid integer.",
                code="invalid",
                index=["age"],
                start_position=Position(line=1, char_index=14),
                end_position=Position(line=1, char_index=16),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:44:16.619504
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:44:25.539364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    token = Token(
        value={"foo": "bar"},
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )

    class MySchema(Schema):
        foo = Field(type="string")

    validate_with_positions(token=token, validator=MySchema)

    class MySchema(Schema):
        foo = Field(type="string", required=True)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

    assert exc_info.value.messages()