

# Generated at 2022-06-18 12:34:43.401973
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=3),
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:34:51.079848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Should have raised ValidationError"

# Generated at 2022-06-18 12:35:01.692499
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=20),
    )

    # Valid
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "30",
    }

    # Invalid

# Generated at 2022-06-18 12:35:09.814988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=100),
    )

    validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:35:21.102179
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class UserSchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=10),
    )


# Generated at 2022-06-18 12:35:32.944541
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"name": None},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 15},
    )
    try:
        validate_with_positions(token=token, validator={"name": String()})
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=("name",),
                start_position={"line_number": 1, "char_index": 6},
                end_position={"line_number": 1, "char_index": 11},
            )
        ]

# Generated at 2022-06-18 12:35:40.287890
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.fields import String

    field = String(required=True)

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)

    validate_with_positions(token=token, validator=field)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String())

    assert exc_info.value.messages()[0].start_position.line == 3
    assert exc_info.value.messages()[0].start_position.char_index == 4
    assert exc_info.value.messages()[0].end_position.line == 3
    assert exc_info.value.messages()[0].end_position.char_index

# Generated at 2022-06-18 12:35:52.377479
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize({"foo": "bar"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=String()) == "bar"

    token = tokenize({"foo": "bar"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=String(required=True)) == "bar"

    token = tokenize({"foo": "bar"})
    assert isinstance(token, Token)
    assert validate_with_positions(token=token, validator=String(max_length=2)) == "ba"


# Generated at 2022-06-18 12:36:03.196201
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John Doe",
            "age": "42",
            "address": {
                "street": "123 Main St.",
                "city": "Anytown",
                "state": "CA",
                "zip": "90210",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=10, column=1, char_index=100),
    )


# Generated at 2022-06-18 12:36:12.270908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String()

    class Person(Schema):
        name = String(required=True)

    source = """
    {
        "name": "John Doe",
        "age": 42
    }
    """

    tokens = tokenize(source)
    token = tokens[0]


# Generated at 2022-06-18 12:36:24.984358
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    tokenizer = Tokenizer()
    token = tokenizer.tokenize(
        """
        {
            "name": "John Doe",
            "age": "",
            "email": "john@example.com"
        }
    """
    )
    assert isinstance(token, Token)
    assert token.value == {
        "name": "John Doe",
        "age": "",
        "email": "john@example.com",
    }

    name = String(required=True)
    age = String(required=True)
    email = String(required=True)


# Generated at 2022-06-18 12:36:31.527695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 20},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "20",
    }


# Generated at 2022-06-18 12:36:36.377043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    assert validate_with_positions(token=tokens, validator=Person) == {"name": "John"}

    tokens = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=Person)

# Generated at 2022-06-18 12:36:47.328157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        "Person",
        {},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 6},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:36:57.649902
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:37:08.521854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:37:19.223026
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 4, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-18 12:37:30.535894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=0),
    )


# Generated at 2022-06-18 12:37:40.718625
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        value="foo",
        token_type=TokenType.STRING,
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )
    field = String(max_length=2)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Ensure this value has at most 2 characters (it has 3)."
        assert message.code == "max_length"
        assert message.index == []
       

# Generated at 2022-06-18 12:37:52.986734
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 31},
    )


# Generated at 2022-06-18 12:38:05.355851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(min_length=4))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Must be at least 4 characters long.",
                code="min_length",
                index=[],
                start_position={"line_number": 1, "char_index": 0},
                end_position={"line_number": 1, "char_index": 3},
            )
        ]

# Generated at 2022-06-18 12:38:15.111381
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start=None,
        end=None,
    )


# Generated at 2022-06-18 12:38:24.480563
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize({"name": "John", "age": "30"})
    assert isinstance(token, Token)
    assert token.value == {"name": "John", "age": "30"}
    assert token.start.line_index == 0
    assert token.start.char_index == 0
    assert token.end.line_index == 0
    assert token.end.char_index == 17

    person = validate_with_positions(token=token, validator=Person)
    assert person == {"name": "John", "age": 30}


# Generated at 2022-06-18 12:38:35.540336
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected an integer.",
                code="type_error.integer",
                index=("age",),
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:38:46.804399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:38:53.461572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )

# Generated at 2022-06-18 12:39:02.114949
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token.parse(
        """
        {
            "name": "John Doe",
            "age": 42
        }
        """
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:13.482783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        height = Field(type="number")

    token = tokenize({"name": "John", "age": "30"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'height' is required.",
            code="required",
            index=("height",),
            start_position=token.lookup(("height",)).start,
            end_position=token.lookup(("height",)).end,
        )
    ]


# Generated at 2022-06-18 12:39:25.472627
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:33.180276
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 1},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:39:46.502087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(max_length=5)
    token = tokenize("hello world")[0]
    assert isinstance(token, Token)
    assert token.value == "hello world"
    assert token.start.line_index == 0
    assert token.start.char_index == 0
    assert token.end.line_index == 0
    assert token.end.char_index == 11

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be at most 5 characters long."

# Generated at 2022-06-18 12:39:55.974263
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start=Token.Position(line_index=1, char_index=1),
        end=Token.Position(line_index=1, char_index=10),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:40:07.790223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class MySchema(Schema):
        name = String(max_length=10)
        age = Integer(minimum=0)

    token = tokenize({"name": "John", "age": -1})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-18 12:40:18.628186
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "zip": "12345",
                "city": "New York",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error

# Generated at 2022-06-18 12:40:26.449084
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "char_index": 12}

# Generated at 2022-06-18 12:40:37.497191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
        {
            "name": "John Doe",
            "age": "30"
        }
    """)

    assert isinstance(token, Token)
    assert token.value == {
        "name": "John Doe",
        "age": "30",
    }

    field = String(name="name")
    assert field.validate(token.value["name"]) == "John Doe"


# Generated at 2022-06-18 12:40:42.282311
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String(required=True)
    token = tokenize("{}")[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)
    assert exc_info.value.messages()[0].start_position.char_index == 1

# Generated at 2022-06-18 12:40:50.169331
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "42",
    }


# Generated at 2022-06-18 12:41:01.698366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "fourty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.column == 13
    assert exc_info.value.messages()[0].end_position.line

# Generated at 2022-06-18 12:41:12.419534
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 20,
    }

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:41:31.847621
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error

# Generated at 2022-06-18 12:41:43.640384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        field = String(required=True)

    token = Token(
        type=TokenType.OBJECT,
        value={"field": "value"},
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=15, char_index=14),
    )

    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'field' is required."

# Generated at 2022-06-18 12:41:50.472420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=20, char_index=19),
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "42",
    }


# Generated at 2022-06-18 12:42:01.830420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String(required=True)
        age = Integer()

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"age": "42"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:12.422889
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:42:21.990930
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:42:32.921142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token

# Generated at 2022-06-18 12:42:40.393131
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=0),
    )


# Generated at 2022-06-18 12:42:50.699081
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "42", "extra": "field"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:01.490020
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=4, char_index=3),
    )
    assert validate_with_positions(token=token, validator=String()) == "foo"

    token = Token(
        value=None,
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=4, char_index=3),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String())

# Generated at 2022-06-18 12:43:31.401074
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:43:41.418191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    schema = String(required=True)
    token = Token(value=None, start=None, end=None, lookup=lambda x: token)
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages()[0].start_position is None
        assert error.messages()[0].end_position is None

    token = tokenize("foo")
    assert validate_with_positions(token=token, validator=schema) == "foo"

    token = tokenize("")

# Generated at 2022-06-18 12:43:50.869163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = Integer(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=20),
    )


# Generated at 2022-06-18 12:44:02.533383
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String(min_length=1)

    token = Token(
        value="",
        start=Token.Position(line_index=0, char_index=0),
        end=Token.Position(line_index=0, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:44:09.217579
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John Doe", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 8
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11

# Generated at 2022-06-18 12:44:21.349019
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "10001",
            },
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:44:31.257165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )
