

# Generated at 2022-06-18 12:34:40.406028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    from typesystem.fields import String, Integer

    schema = Schema(fields={"name": String(), "age": Integer()})

    token = tokenize("{name: 'John', age: '20'}")
    assert isinstance(token, Token)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "Expected a valid integer."
    assert message.code == "invalid_type"
    assert message.index == ("age",)

# Generated at 2022-06-18 12:34:49.466591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "Bob",
            "age": "not a number",
            "address": {
                "street": "123 Main St",
                "city": "",
                "state": "CA",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 5, "char_index": 22},
    )

    class Address(Schema):
        street = String(max_length=20)
        city = String(max_length=20, required=False)
        state = String(max_length=2)
        zip = String(max_length=5)


# Generated at 2022-06-18 12:35:00.990074
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 1, "column": 1, "char_index": 0}

# Generated at 2022-06-18 12:35:09.273729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 15},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line": 2, "char_index": 6}

# Generated at 2022-06-18 12:35:20.571028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        token_type=TokenType.OBJECT,
        value={
            "name": "John Doe",
            "age": "42",
            "address": {
                "street": "123 Main St",
                "city": "Anytown",
                "state": "CA",
                "zip": "90210",
            },
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=100),
    )

    class Person(Schema):
        name = String()
        age = String()

    class Address(Schema):
        street = String()
        city = String()
        state = String()


# Generated at 2022-06-18 12:35:32.315634
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        type=TokenType.OBJECT,
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc

# Generated at 2022-06-18 12:35:39.904497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 10, "char_index": 9},
    )

# Generated at 2022-06-18 12:35:51.992074
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "10001",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 5, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:02.805169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    field = String(max_length=5)
    token = Token(
        value="hello",
        start=tokenize.Position(line_index=0, char_index=0),
        end=tokenize.Position(line_index=0, char_index=5),
    )
    validate_with_positions(token=token, validator=field)

    token = Token(
        value="hello world",
        start=tokenize.Position(line_index=0, char_index=0),
        end=tokenize.Position(line_index=0, char_index=11),
    )
    with pytest.raises(ValidationError) as exc_info:
        validate

# Generated at 2022-06-18 12:36:11.978794
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:26.943935
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:36:32.371423
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line_index": 1, "char_index": 1},
        end={"line_index": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:36:40.542289
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].start_position.line == 1
    assert exc_info.value.messages()[0].start_position.char_index == 8
    assert exc_info.value.messages()[0].end_position.line == 1

# Generated at 2022-06-18 12:36:51.265157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "extra": "field",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:37:01.181030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "ValidationError not raised"

# Generated at 2022-06-18 12:37:09.960441
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.column == 8
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.column == 9
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:37:20.305497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": None},
        start={"line": 0, "char_index": 0},
        end={"line": 0, "char_index": 0},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:37:32.430760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 1},
    )


# Generated at 2022-06-18 12:37:43.493087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 3},
    )


# Generated at 2022-06-18 12:37:55.103604
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:38:12.831995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "foo": "bar"
    }
    """)
    assert isinstance(token, Token)
    assert token.value == {"foo": "bar"}

    # This should not raise an error
    validate_with_positions(token=token, validator=String(required=True))

    # This should raise an error
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(required=False))
    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message

# Generated at 2022-06-18 12:38:23.303513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=3),
    )
    field = String(min_length=4)

# Generated at 2022-06-18 12:38:34.582030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        field = String()

    token = Token(
        value={
            "field": "hello",
        },
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )

    assert validate_with_positions(token=token, validator=TestSchema) == {
        "field": "hello",
    }

    token = Token(
        value={},
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=10),
    )

# Generated at 2022-06-18 12:38:45.852435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not-an-integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:38:56.979260
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=4, column=6, char_index=100),
    )


# Generated at 2022-06-18 12:39:04.254936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    assert isinstance(token, Token)

    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "forty-two"})
    assert isinstance(token, Token)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.mess

# Generated at 2022-06-18 12:39:16.186126
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not of type 'integer'."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 9
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False

# Generated at 2022-06-18 12:39:27.442749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=10, char_index=9),
    )


# Generated at 2022-06-18 12:39:34.173737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:39:44.039715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize({"name": "foo"})
    assert isinstance(token, Token)

    field = String(required=True)
    validate_with_positions(token=token, validator=field)

    field = String(required=False)
    validate_with_positions(token=token, validator=field)

    token = tokenize({"name": None})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:40:09.705305
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 3},
    )
    field = String(min_length=4)
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_index": 0, "char_index": 0}
        assert error.messages()[0].end_position == {"line_index": 0, "char_index": 3}



# Generated at 2022-06-18 12:40:19.808170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "foo", "age": 42},
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 20},
    )
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position == {"line": 1, "char": 6}


# Generated at 2022-06-18 12:40:27.056524
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = tokenize({"name": "John"}, Person)
    assert isinstance(token, Token)

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'age' is required."
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 1
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 5

# Generated at 2022-06-18 12:40:37.706290
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 20},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "20",
    }


# Generated at 2022-06-18 12:40:44.691845
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]

# Generated at 2022-06-18 12:40:52.338542
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import Tokenizer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    tokenizer = Tokenizer()
    tokens = tokenizer.tokenize("{}")
    token = Token(tokens, 0)
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:41:02.590002
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "thirty",
        },
        start=tokenize.Position(line=1, char_index=0),
        end=tokenize.Position(line=3, char_index=5),
    )


# Generated at 2022-06-18 12:41:13.449549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:41:21.589105
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()
        age = Integer()

    token = Token.parse(
        """
        {
            "name": "John",
            "age": "twenty"
        }
        """
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be an integer."
        assert message.start_position.line == 4
        assert message.start_position.char_index == 16

# Generated at 2022-06-18 12:41:26.077734
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=token.start,
                end_position=token.end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:41:48.795285
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip_code": "",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 10, "char": 0},
    )


# Generated at 2022-06-18 12:41:59.459683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=20, char_index=19),
    )


# Generated at 2022-06-18 12:42:09.984211
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    field = String(required=True)


# Generated at 2022-06-18 12:42:20.400654
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize_string

    class Person(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = tokenize_string("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:30.898042
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=1),
    )


# Generated at 2022-06-18 12:42:39.262309
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Must have no more than 2 characters.",
                code="max_length",
                index=(),
                start_position={"line_index": 1, "char_index": 0},
                end_position={"line_index": 1, "char_index": 3},
            )
        ]

# Generated at 2022-06-18 12:42:49.530929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 6, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages

# Generated at 2022-06-18 12:42:56.358015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": "20",
    }


# Generated at 2022-06-18 12:43:07.183855
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String, Integer

    class Person(Schema):
        name = String()
        age = Integer()

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:18.523355
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "foo",
        },
        start={"line": 1, "char": 1},
        end={"line": 2, "char": 1},
    )

# Generated at 2022-06-18 12:43:42.750547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
            "address": "123 Main St.",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 30},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].text == "The field 'address' is required."

# Generated at 2022-06-18 12:43:51.987842
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:44:04.043532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        token_type=TokenType.STRING,
        value="foo",
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=3),
    )

    field = String(min_length=4)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must be at least 4 characters long."
        assert message.code == "min_length"
        assert message.index == []
        assert message.start_position

# Generated at 2022-06-18 12:44:15.685137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )

# Generated at 2022-06-18 12:44:24.872380
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = Integer()

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 14},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)