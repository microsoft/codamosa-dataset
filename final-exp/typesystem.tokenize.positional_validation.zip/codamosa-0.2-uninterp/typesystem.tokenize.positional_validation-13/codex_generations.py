

# Generated at 2022-06-18 12:34:30.165159
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:34:40.271753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError
    from typesystem.base import Message

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={},
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:34:49.313935
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "foo"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 15},
    )
    validate_with_positions(token=token, validator=MySchema)

    token = Token(
        value={},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 15},
    )

# Generated at 2022-06-18 12:35:00.818614
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = tokenize({"name": "foo"})

# Generated at 2022-06-18 12:35:09.170598
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:35:19.334920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_index": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:35:30.728437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String, Integer

    schema = Schema(fields={"name": String(), "age": Integer()})

    token = tokenize("{name: 'John', age: '42'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "Expected an integer."
    assert message.code == "type_error.integer"
    assert message.index == ("age",)
    assert message.start_position.line == 1
    assert message.start

# Generated at 2022-06-18 12:35:39.119837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:35:51.128224
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"age": "42"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:36:01.760148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String

    token = tokenize({"foo": "bar"})
    field = String(required=True)
    assert validate_with_positions(token=token, validator=field) == "bar"

    token = tokenize({"foo": None})
    field = String(required=True)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-18 12:36:13.409822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token

# Generated at 2022-06-18 12:36:22.647639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:36:29.222826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=4, char_index=3),
    )


# Generated at 2022-06-18 12:36:38.689749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    token = tokens[0]
    assert validate_with_positions(token=token, validator=Person) == {"name": "John"}

    tokens = tokenize({"name": ""})
    token = tokens[0]
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages()[0].text == "The field 'name' is required."
    assert exc_info.value.messages()[0].start_position.line

# Generated at 2022-06-18 12:36:50.013069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 6
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 7
        assert error.messages()[0].text == "Must be an integer."
    else:
        assert False

# Generated at 2022-06-18 12:37:00.951580
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John Doe",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)
        state = String(required=True)
        zip = String(required=True)

    class Person(Schema):
        name = String(required=True)
        age = String()

# Generated at 2022-06-18 12:37:09.782798
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.lookup(["age"]).start,
            end_position=token.lookup(["age"]).end,
        )
    ]

# Generated at 2022-06-18 12:37:20.128591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=User)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."

# Generated at 2022-06-18 12:37:30.585039
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:37:40.771400
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizers import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is not a valid integer."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 13
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 15

# Generated at 2022-06-18 12:37:55.783392
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "42",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 3},
    )

    # Test with a Field
    try:
        validate_with_positions(token=token, validator=String(required=True))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"

# Generated at 2022-06-18 12:38:04.649937
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "fourty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:38:14.448926
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.schemas import Schema
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:38:24.043090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "1",
                "zip": "12345",
                "city": "New York",
            },
        },
        start=Token.Position(line=1, char_index=1),
        end=Token.Position(line=1, char_index=1),
    )

    validate_with_positions(token=token, validator=Person)

    token = Token

# Generated at 2022-06-18 12:38:35.311593
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:38:46.639472
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start=Token.Position(line=1, char_index=0),
        end=Token.Position(line=1, char_index=100),
    )


# Generated at 2022-06-18 12:38:57.287597
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "twenty-five",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 3, "char_index": 0},
    )

# Generated at 2022-06-18 12:39:08.021440
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": None,
            "address": {"city": "", "country": "", "postal_code": ""},
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:19.678122
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 5},
    )


# Generated at 2022-06-18 12:39:29.882767
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:46.408938
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=10, char_index=9),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.code == "required"

# Generated at 2022-06-18 12:39:55.882131
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "number": "1",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages

# Generated at 2022-06-18 12:40:07.702768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:40:18.454871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=("age",),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token

# Generated at 2022-06-18 12:40:26.401868
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "country": "",
                "postcode": "",
            },
        },
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 0},
    )


# Generated at 2022-06-18 12:40:37.456390
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=12, char_index=11),
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:40:45.197434
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    tokens = tokenize(
        """
        {
            "name": "John",
            "age": "twenty"
        }
        """
    )
    token = tokens[0]


# Generated at 2022-06-18 12:40:52.674624
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 5},
    )


# Generated at 2022-06-18 12:41:02.019991
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_index": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:41:12.751180
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'name' is required."
        assert message.start_position == {"line": 1, "char_index": 0}

# Generated at 2022-06-18 12:41:25.787663
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: '42'}")
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error.integer",
                index=("age",),
                start_position=Position(line=1, column=12, char_index=11),
                end_position=Position(line=1, column=14, char_index=13),
            )
        ]
    else:
        assert False



# Generated at 2022-06-18 12:41:36.589830
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zip": "12345",
            },
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 4, "char_index": 15},
    )


# Generated at 2022-06-18 12:41:46.691520
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )


# Generated at 2022-06-18 12:41:51.991222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)
        state = String(required=True)
        zip = String(required=True)

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)
       

# Generated at 2022-06-18 12:42:03.084194
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String(required=True)

    tokens = tokenize({"name": "John"})
    assert validate_with_positions(token=tokens, validator=Person) == {"name": "John"}

    tokens = tokenize({})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=tokens, validator=Person)

# Generated at 2022-06-18 12:42:13.351166
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 3, "char_index": 3},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert len(exc_info.value.messages) == 1
    message = exc_info.value.messages[0]
    assert message.text == "The field 'name' is required."
   

# Generated at 2022-06-18 12:42:22.866365
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import TokenPosition
    from typesystem.tokenize.tokens import TokenType
    from typesystem.tokenize.tokens import ValueToken
    from typesystem.tokenize.tokens import WhitespaceToken
    from typesystem.tokenize.tokens import WordToken
    from typesystem.tokenize.tokens import WordTokenType
    from typesystem.tokenize.tokens import WordTokenValue

    from typesystem.fields import String
    from typesystem.fields import StringField

    from typesystem.schemas import Schema

    from typesystem.tokenize.tokens import TokenType

   

# Generated at 2022-06-18 12:42:33.179534
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=["age"],
                start_position=Position(line=1, char_index=9),
                end_position=Position(line=1, char_index=9),
            )
        ]
    else:
        assert False



# Generated at 2022-06-18 12:42:40.548639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    assert isinstance(token, Token)
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John", "age": "thirty"})
    assert isinstance(token, Token)
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:42:50.868158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class TestSchema(Schema):
        name = String()

    token = Token(
        value={
            "name": "John Doe",
            "age": "42",
            "address": {
                "street": "123 Main St.",
                "city": "Anytown",
                "state": "CA",
                "zip": "90210",
            },
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:43:08.006399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class MySchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 5},
    )

# Generated at 2022-06-18 12:43:14.484929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.lexers import JSONLexer
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    lexer = JSONLexer()
    token = lexer.tokenize("""{"foo": "bar"}""")
    assert isinstance(token, Token)
    validate_with_positions(token=token, validator=String())

# Generated at 2022-06-18 12:43:18.240975
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("foo")
    assert isinstance(token, Token)
    assert token.value == "foo"

    validate_with_positions(token=token, validator=String())



# Generated at 2022-06-18 12:43:28.902911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    assert validate_with_positions(token=token, validator=Person) == {
        "name": "John",
        "age": 42,
    }

    token = tokenize({"name": "John", "age": "forty-two"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

# Generated at 2022-06-18 12:43:38.970493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'int'.",
                code="type_error.int",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:43:48.777215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import parse_string

    class TestSchema(Schema):
        name = Field(type="string", required=True)
        age = Field(type="integer", required=True)

    token = parse_string("{name: 'foo', age: 'bar'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=TestSchema)
    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].text == "The field 'age' is required."
    assert messages[0].start_position.line_index == 0
    assert messages[0].start_position.char_index == 8
    assert messages[0].end_position.line_index == 0

# Generated at 2022-06-18 12:43:55.926874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:44:06.148416
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class User(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 14},
    )

# Generated at 2022-06-18 12:44:18.381960
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "Main Street",
                "city": "New York",
                "zipcode": "12345",
            },
        },
        token_type=TokenType.OBJECT,
        start=Position(line=1, char_index=0),
        end=Position(line=1, char_index=100),
    )

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")
        address = Field(type="object")

    class Address(Schema):
        street = Field(type="string")


# Generated at 2022-06-18 12:44:26.548587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    class PersonWithPositions(Schema):
        name = Field(type="string")
        age = Field(type="integer")

        def validate(self, data):
            return validate_with_positions(
                token=tokenize(data), validator=self
            )

    try:
        Person().validate({"name": "John"})
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is required.",
                code="required",
                index=("age",),
                start_position=None,
                end_position=None,
            )
        ]
