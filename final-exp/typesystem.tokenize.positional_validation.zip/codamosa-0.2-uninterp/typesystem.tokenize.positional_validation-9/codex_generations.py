

# Generated at 2022-06-18 12:34:39.887873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 20},
    )


# Generated at 2022-06-18 12:34:48.908591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = Token(
        value={
            "name": "",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 0},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:34:54.474753
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    field = String(required=True)

    token = Token(
        type=TokenType.OBJECT,
        value={},
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=0),
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:35:04.547933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={"name": "John"},
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 10},
    )


# Generated at 2022-06-18 12:35:13.692317
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "city": "New York",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:35:22.902500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize("{name: 'John', age: '42'}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is not of type 'integer'.",
            code="type_error.integer",
            index=("age",),
            start_position=token.lookup(("age",)).start,
            end_position=token.lookup(("age",)).end,
        )
    ]

# Generated at 2022-06-18 12:35:34.138457
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "not an integer",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:35:44.195251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        """
        {
            "name": "John Doe",
            "age": "thirty"
        }
        """
    )
    assert isinstance(token, Token)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String(max_length=5))


# Generated at 2022-06-18 12:35:56.220944
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"name": "foo"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    validator = String(name="name")
    validate_with_positions(token=token, validator=validator)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    validator = String(name="name")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)
   

# Generated at 2022-06-18 12:36:01.502792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 12},
    )
    try:
        validate_with_positions(token=token, validator=String())
    except ValidationError as error:
        assert error.messages()[0].start_position == {"line_number": 1, "char_index": 0}
        assert error.messages()[0].end_position == {"line_number": 1, "char_index": 12}

# Generated at 2022-06-18 12:36:13.816018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
            "age": "",
        },
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 0},
    )

# Generated at 2022-06-18 12:36:22.786298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )

# Generated at 2022-06-18 12:36:29.697091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize_string
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = tokenize_string("{}")
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)

    assert exc_info.value.messages() == [
        Message(
            text="The field 'name' is required.",
            code="required",
            index=["name"],
            start_position=token.start,
            end_position=token.end,
        )
    ]

# Generated at 2022-06-18 12:36:39.108195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.start,
            end_position=token.end,
        )
    ]


# Generated at 2022-06-18 12:36:50.506929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not of type 'integer'.",
                code="type_error",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:37:01.478798
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not a valid integer.",
                code="invalid_type",
                index=["age"],
                start_position=Position(line=1, column=10, char_index=9),
                end_position=Position(line=1, column=12, char_index=11),
            )
        ]

# Generated at 2022-06-18 12:37:10.757043
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    class Person(Schema):
        name = String()

    token = Token(
        value={"name": "John"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )

# Generated at 2022-06-18 12:37:20.433810
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Must have no more than 2 characters."
        assert message.start_position == {"line_index": 1, "char_index": 0}
        assert message.end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:37:32.429314
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
            "address": {
                "street": "Main Street",
                "number": "123",
                "city": "New York",
                "state": "NY",
            },
        },
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 1, "char_index": 0},
    )


# Generated at 2022-06-18 12:37:43.493697
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={"name": "", "age": None},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 16},
    )
    validator = Schema({"name": Field(required=True), "age": Field(required=True)})

    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert len(error.messages()) == 2
        assert error.messages()[0].text == "The field 'name' is required."
        assert error.messages()[0].start_position == {"line": 1, "char_index": 0}

# Generated at 2022-06-18 12:38:00.897658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer

    token = Token(
        value={"foo": "bar"},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 12},
    )
    try:
        validate_with_positions(token=token, validator=Integer())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.start_position == {"line_number": 1, "char_index": 4}
        assert message.end_position == {"line_number": 1, "char_index": 7}

# Generated at 2022-06-18 12:38:07.718820
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "not an int",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )


# Generated at 2022-06-18 12:38:17.770052
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Integer
    from typesystem.schemas import Schema

    class MySchema(Schema):
        foo = Integer(required=True)

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 10},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=MySchema)

# Generated at 2022-06-18 12:38:25.921105
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="hello",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 5},
    )
    assert validate_with_positions(token=token, validator=String()) == "hello"

    token = Token(
        value=None,
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 5},
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=String())

# Generated at 2022-06-18 12:38:36.471110
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "42"})
    validate_with_positions(token=token, validator=Person)

    token = tokenize({"name": "John"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field 'age' is required.",
            code="required",
            index=["age"],
            start_position=token.start,
            end_position=token.end,
        )
    ]



# Generated at 2022-06-18 12:38:47.666273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "",
        },
        start=Token.Position(line=1, column=1, char_index=0),
        end=Token.Position(line=1, column=10, char_index=9),
    )


# Generated at 2022-06-18 12:38:58.133273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main Street",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 10, "char_index": 0},
    )


# Generated at 2022-06-18 12:39:04.942737
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )


# Generated at 2022-06-18 12:39:16.226929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "20",
        },
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 2, "char_index": 0},
    )
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."

# Generated at 2022-06-18 12:39:27.491409
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String
    from typesystem.tokenize.tokens import Token

    token = Token(
        value={
            "name": "",
            "age": "",
            "address": {
                "street": "",
                "city": "",
                "state": "",
                "zip": "",
            },
        },
        start=None,
        end=None,
    )

    class Person(Schema):
        name = String(required=True)
        age = String(required=True)

    class Address(Schema):
        street = String(required=True)
        city = String(required=True)
        state = String(required=True)
        zip = String(required=True)

    class PersonWithAddress(Schema):
        person = Person(required=True)
       

# Generated at 2022-06-18 12:39:53.409231
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type=str)
        age = Field(type=int)

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'age' is not a valid integer.",
                code="invalid_type",
                index=["age"],
                start_position=Position(line=1, column=9, char_index=8),
                end_position=Position(line=1, column=11, char_index=10),
            )
        ]

# Generated at 2022-06-18 12:40:05.470148
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = Token(
        value={
            "name": "John",
            "age": "invalid",
        },
        start=Position(line_index=1, char_index=1),
        end=Position(line_index=1, char_index=20),
    )


# Generated at 2022-06-18 12:40:13.551167
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class Person(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 2, "char_index": 0},
    )
    validate_with_positions(token=token, validator=Person)

    token = Token(
        value={},
        start={"line": 1, "char_index": 0},
        end={"line": 2, "char_index": 0},
    )

# Generated at 2022-06-18 12:40:22.951968
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Token.Position(line_index=1, char_index=0),
        end=Token.Position(line_index=1, char_index=3),
    )

    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.text == "Must have no more than 2 characters."
        assert message.code == "max_length"
        assert message.index == []
        assert message.start_position == token.start
        assert message.end_position == token.end


# Generated at 2022-06-18 12:40:31.865710
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "invalid"})
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Person)
    assert exc_info.value.messages() == [
        Message(
            text="The field age must be an integer.",
            code="invalid_type",
            index=["age"],
            start_position=token.lookup(["age"]).start,
            end_position=token.lookup(["age"]).end,
        )
    ]

# Generated at 2022-06-18 12:40:40.588676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].text == "The field 'age' is required."
        assert error.messages()[0].start_position.line_number == 1
        assert error.messages()[0].start_position.char_index == 7
        assert error.messages()[0].end_position.line_number == 1
        assert error.messages()[0].end_position.char_index == 9

# Generated at 2022-06-18 12:40:48.298802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.schemas import Schema
    from typesystem.fields import String

    class MySchema(Schema):
        name = String(required=True)

    token = tokenize({"name": "John"})
    try:
        validate_with_positions(token=token, validator=MySchema)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'name' is required.",
                code="required",
                index=["name"],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-18 12:40:54.131142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String

    token = Token(
        value="foo",
        start=Position(line_index=0, char_index=0),
        end=Position(line_index=0, char_index=3),
    )
    field = String(max_length=2)

# Generated at 2022-06-18 12:41:03.571268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token

    class Person(Schema):
        name = Field(str)
        age = Field(int)

    token = Token(
        value={
            "name": "John",
            "age": "abc",
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 20},
    )

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=Person)


# Generated at 2022-06-18 12:41:14.345746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value="foo",
        start={"line_index": 1, "char_index": 0},
        end={"line_index": 1, "char_index": 3},
    )
    try:
        validate_with_positions(token=token, validator=String(max_length=2))
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "Must have no more than 2 characters."
        assert message.start_position == {"line_index": 1, "char_index": 0}
        assert message.end_position == {"line_index": 1, "char_index": 3}

# Generated at 2022-06-18 12:42:00.032009
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={"foo": "bar"},
        start={"line": 1, "char": 0},
        end={"line": 1, "char": 14},
    )

    field = String(required=True)

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'foo' is required.",
                code="required",
                index=["foo"],
                start_position={"line": 1, "char": 0},
                end_position={"line": 1, "char": 14},
            )
        ]

# Generated at 2022-06-18 12:42:11.354847
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token, TokenType
    from typesystem.fields import String

    token = Token(
        token_type=TokenType.STRING,
        value="foo",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 3},
    )

    field = String(min_length=4)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)


# Generated at 2022-06-18 12:42:20.996790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String
    from typesystem.schemas import Schema

    class PersonSchema(Schema):
        name = String(required=True)

    token = Token(
        value={
            "name": "John",
            "age": "30",
            "address": {
                "street": "123 Main St.",
                "city": "New York",
                "state": "NY",
                "zip": "10001",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 1, "char_index": 100},
    )


# Generated at 2022-06-18 12:42:31.841428
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize("""
    {
        "name": "John Doe",
        "age": "20"
    }
    """)
    assert isinstance(token, Token)

    schema = Schema(
        {"name": String(max_length=10), "age": String(max_length=2)}
    )

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=schema)

    messages = exc_info.value.messages()
    assert len(messages) == 2
    assert messages[0].text == "Ensure this value has at most 10 characters (it has 11)."

# Generated at 2022-06-18 12:42:39.705909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.positions import Position
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.exceptions import ValidationError

    class Person(Schema):
        name = String()
        age = String()

    token = Token(
        value={
            "name": "John",
            "age": "twenty",
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=1, char_index=0),
    )

    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert len(error.messages()) == 1

# Generated at 2022-06-18 12:42:50.146111
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John Doe",
            "age": "invalid",
            "address": {
                "city": "New York",
                "state": "NY",
                "zip": "12345",
                "country": "USA",
            },
        },
        start={"line": 1, "char": 1},
        end={"line": 1, "char": 1},
    )

    class Person(Schema):
        name = String()
        age = String()
        address = Schema(
            fields={"city": String(), "state": String(), "zip": String()}
        )


# Generated at 2022-06-18 12:43:00.570652
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "30"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="Expected type 'integer' for value '30'",
                code="type_error.integer",
                index=["age"],
                start_position=token.lookup(["age"]).start,
                end_position=token.lookup(["age"]).end,
            )
        ]
    else:
        assert False, "Expected ValidationError"

# Generated at 2022-06-18 12:43:09.118253
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokenizer import tokenize
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = tokenize(
        {
            "name": "foo",
            "age": "bar",
            "address": {
                "street": "123 Main St",
                "city": "San Francisco",
                "state": "CA",
                "zip": "94102",
            },
        }
    )

    class Address(Schema):
        street = String(min_length=10)
        city = String(min_length=10)
        state = String(min_length=2)
        zip = String(min_length=5)

    class Person(Schema):
        name = String(min_length=3)

# Generated at 2022-06-18 12:43:19.007517
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import String

    token = Token(
        value={
            "name": "John",
            "age": "42",
            "address": {
                "street": "",
                "city": "London",
                "postcode": "SW1A 1AA",
            },
        },
        start={"line": 1, "char_index": 0},
        end={"line": 5, "char_index": 22},
    )

    class Person(Schema):
        name = String()
        age = String()
        address = Schema(
            {"street": String(), "city": String(), "postcode": String()}
        )


# Generated at 2022-06-18 12:43:23.347900
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize

    class Person(Schema):
        name = Field(type="string")
        age = Field(type="integer")

    token = tokenize({"name": "John", "age": "20"})
    try:
        validate_with_positions(token=token, validator=Person)
    except ValidationError as error:
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 10
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 11
    else:
        assert False, "Expected ValidationError"