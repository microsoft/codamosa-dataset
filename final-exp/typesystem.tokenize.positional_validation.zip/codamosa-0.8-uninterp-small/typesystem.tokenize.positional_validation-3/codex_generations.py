

# Generated at 2022-06-26 10:31:00.301374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    field_0 = Field(default=token_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:31:01.039398
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:31:08.835539
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Just running the function to make sure it works

    # Token is a field
    token_0 = Token(
        value=123,
        start={"char_index": 1, "line_index": 1},
        end={"char_index": 2, "line_index": 1},
    )
    field_0 = Field(name="my_field")
    value_0 = validate_with_positions(token=token_0, validator=field_0)
    assert value_0 == token_0

    # Token is not in the validation
    token_1 = Token(
        value=123,
        start={"char_index": 1, "line_index": 1},
        end={"char_index": 2, "line_index": 1},
    )
    required_field = Field(name="my_field")
   

# Generated at 2022-06-26 10:31:17.838219
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    field_0 = module_0.Field(default=token_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    assert any_0 == token_0
    token_1 = None
    field_1 = module_0.Field(required=True)
    try:
        validate_with_positions(token=token_1, validator=field_1)
    except ValidationError as error_1:
        message_0 = error_1.messages[0]
        assert message_0.start_position == None
        assert message_0.end_position == None
        assert message_0.code == "required"
        assert message_0.index == []
        assert message_0.text == "This field is required."

# Generated at 2022-06-26 10:31:18.955426
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()



# Generated at 2022-06-26 10:31:26.420805
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class ExampleSchema(Schema):
        name = Field(required=True)
        age = Field(default=18)

    try:
        ExampleSchema.validate({"name": "Jim"})
    except ValidationError as error:
        messages = list(error.messages())
        assert messages[0].text == "The field 'age' is required."
        assert messages[0].start_position.char_index == 0
        assert messages[0].end_position.char_index == 1


import typesystem.fields as module_1


# Generated at 2022-06-26 10:31:32.156137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value=None, start=Position(line_index=0, char_index=0), end=Position(line_index=0, char_index=0)
    )
    field_0 = module_0.Field(default=token_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:31:36.070068
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    field_0 = module_0.Field(default=token_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:31:44.578709
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.tokens as module_0
    import typesystem.fields as module_1
    import typesystem.schemas as module_2
    import typing
    token_0 = module_0.Token(
        value="",
        start=module_0.Position(line_index=1, char_index=1),
        end=module_0.Position(line_index=2, char_index=1),
    )
    schema_0 = module_2.Schema(
        fields=(module_1.Field(default=token_0),),
        required=True,
        strict=True,
    )

# Generated at 2022-06-26 10:31:45.612018
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        assert test_case_0() == None
    except Exception as e:
        print(e)
        raise

# Generated at 2022-06-26 10:31:52.037937
# Unit test for function validate_with_positions
def test_validate_with_positions():
  p0 = None
  p1 = None
  try:
    validate_with_positions(token=p0, validator=p1)
  except ValidationError as e0:
    assert str(e0) == 'Can\'t lookup from None'

# Generated at 2022-06-26 10:31:58.650695
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = DummyToken()
    validator = DummyField()
    validate_with_positions(token=token, validator=validator)
    validator.validate.assert_called_once_with(value=token.value)
    token.lookup.assert_not_called()


# Generated at 2022-06-26 10:32:00.082222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 0 == 0



# Generated at 2022-06-26 10:32:06.889069
# Unit test for function validate_with_positions
def test_validate_with_positions():

    def validate_with_positions(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        try:
            return validator.validate(token.value)
        except ValidationError as error:
            messages = []
            for message in error.messages():
                if message.code == "required":
                    field = message.index[-1]
                    token = token.lookup(message.index[:-1])
                    text = f"The field {field!r} is required."
                else:
                    token = token.lookup(message.index)
                    text = message.text


# Generated at 2022-06-26 10:32:09.117892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:32:10.362789
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:32:11.412964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False, "unimplemented"

# Generated at 2022-06-26 10:32:20.763941
# Unit test for function validate_with_positions
def test_validate_with_positions():
    source = test_case_0.__code__.co_code
    import dis
    import types
    import inspect

    class MockField(Field):
        def validate(self, value, context=None):
            pass

    mock_field = MockField()

    def mock_schema_validate(self, value, context=None):
        pass

    class MockSchema(Schema):
        pass

    MockSchema.validate = types.MethodType(mock_schema_validate, MockSchema)

    mock_schema = MockSchema()

    special_expressions = [
        t_0_0,
        validate_with_positions,
        MockField,
        mock_field,
        MockSchema,
        mock_schema,
    ]

    code = dis.Bytecode(source)

   

# Generated at 2022-06-26 10:32:21.683677
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:32:30.870274
# Unit test for function validate_with_positions
def test_validate_with_positions():
  # Failure case 1
  try:
    def field_fn_1(value):
      return value
    # Testing with non dict input
    json_str = '{}'
    test_obj = json.loads(json_str)
    token = Token(test_obj)
    assert validate_with_positions(token=token, validator=field_fn_1) == test_obj
  except:
    print(traceback.format_exc())
    assert False
  # Success case 1

# Generated at 2022-06-26 10:32:46.374113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    token_1 = None
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    token_2 = None
    any_2 = validate_with_positions(token=token_2, validator=token_2)
    token_3 = None
    any_3 = validate_with_positions(token=token_3, validator=token_3)
    token_4 = None
    any_4 = validate_with_positions(token=token_4, validator=token_4)
    token_5 = None
    any_5 = validate_with_positions(token=token_5, validator=token_5)
   

# Generated at 2022-06-26 10:32:47.457545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False
    # TODO: write test

# Generated at 2022-06-26 10:32:48.384958
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True



# Generated at 2022-06-26 10:32:51.816720
# Unit test for function validate_with_positions
def test_validate_with_positions():
  # Setup
  token_0 = None

  # Invoke method
  result = validate_with_positions(token=token_0,validator=token_0)

  # Verify results
  assert result is None

# Generated at 2022-06-26 10:32:57.974471
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    from typesystem.integer import Integer

    field = Integer()
    tokens: typing.List[Token] = []

    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=tokens[0], validator=field)

    assert str(error.value) == "The field 0 is required."

# Generated at 2022-06-26 10:33:00.521871
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Possibly, you want to check if we can correctly identify the last statement
    # in this function.
    pass


# Generated at 2022-06-26 10:33:11.009038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .helper import make_token
    from typesystem.fields import Integer, String

    token = make_token("foo", "integer")
    assert validate_with_positions(token=token, validator=Integer()) == "foo"
    try:
        validate_with_positions(token=token, validator=String())
    except ValueError:
        pass


# @pytest.mark.parametrize("token, validator", [])
# def test_validate_with_positions(token, validator):
#     from .helper import make_token
#     from typesystem.fields import Integer, String

#     token = make_token("foo", "integer")
#     assert validate_with_positions(token=token, validator=Integer()) == "foo"
#     try:
#         validate_with

# Generated at 2022-06-26 10:33:14.250561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    schema = Field(primitive=int)
    errors = []
    try:
        validate_with_positions(token=Token("x", "str", 0, 1), validator=schema)
    except ValidationError as error:
        errors = error.messages()
    assert errors == [
        Message(
            text="Expected an int but got str",
            code="invalid",
            index=[],
            start_position=Position(line=1, char_index=0),
            end_position=Position(line=1, char_index=1),
        )
    ]

# Generated at 2022-06-26 10:33:17.106564
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Set up mock

    # Invoke method
    result = validate_with_positions()

    # Check result
    assert result is None

# Generated at 2022-06-26 10:33:21.365722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    field_0 = Field()
    token_0 = None
    any_1 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:33:42.077377
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List, Tuple
    from typesystem.tokenize.token_parser import TokenParser
    from typesystem.tokenize.tokens import FieldToken, ObjectToken
    from typesystem.fields import Array, Integer
    from typesystem.schemas import Schema

    class Root(Schema):
        array = Array(items=Integer())

    schema = Root()
    token_parser = TokenParser(schema=schema)
    tokens = token_parser.parse_json('{"array":[1, 2, "test"]}')


# Generated at 2022-06-26 10:33:52.183108
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import inspect

    import typesystem

    

    data = {
        "title": "My document",
        "authors": [
            {"first_name": "John", "last_name": "Doe"},
            {"first_name": "Jane", "last_name": "Doe"},
        ],
    }
    document_schema = DocumentSchema()
    try:
        document_schema.validate(data)
    except ValidationError as validation_error:
        print(validation_error.messages)
        print(json.dumps(validation_error.to_json(), indent=2))



# Generated at 2022-06-26 10:33:53.094376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False


# Generated at 2022-06-26 10:33:57.979878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        text="import",
        start=Token.Position(line_index=0, char_index=0, pointer_index=0),
        end=Token.Position(line_index=0, char_index=6, pointer_index=6),
    )
    str_0 = validate_with_positions(token=token_0, validator=token_0)
    assert str_0 == "import"

# Generated at 2022-06-26 10:33:59.046091
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass


# Generated at 2022-06-26 10:34:01.605132
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:34:02.152851
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:34:08.916294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    any_1 = validate_with_positions(token=any_0, validator=token_0)
    any_2 = validate_with_positions(token=any_0, validator=any_1)
    assert any_0 is token_0
    assert any_1 is token_0
    assert any_2 is token_0

# Generated at 2022-06-26 10:34:10.198704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() is None

# Generated at 2022-06-26 10:34:13.880611
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    print(any_0)

# Generated at 2022-06-26 10:34:39.621801
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import types
    import typing
    from io import StringIO
    from types import ModuleType
    imp = ModuleType("imp")
    imp.find_module = lambda name, path=None: None
    sys.modules["imp"] = imp
    import typesystem
    import typesystem.schemas
    import typesystem.tokenize.tokens
    import json
    import typesystem.fields
    import typing
    Token = typesystem.tokenize.tokens.Token
    String = typesystem.fields.String
    String.validate = String.validate
    String.validate = String.validate
    String.validate_pattern = String.validate_pattern
    String.validate_pattern = String.validate_pattern

# Generated at 2022-06-26 10:34:41.907378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = TypeOfToken()
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None


# Generated at 2022-06-26 10:34:42.421995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False == False

# Generated at 2022-06-26 10:34:48.211320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test for message_format = "wish I knew what the format is"
    # message_code = "wish I knew what the code is"
    any_0 = validate_with_positions(token=token_0, validator=token_0)


# Generated at 2022-06-26 10:34:48.806489
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:34:59.273378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        type="int",
        value=5,
        start=Position(line=5, column=5, char_index=5),
        end=Position(line=5, column=5, char_index=5),
    )
    
    # A field so that we don't need to specify a complex validator
    #  validator = Any(subtypes=[
    #      Int(gte=0),
    #      Str(pattern="^\d+$"),
    #      Bool(values=[False]),
    #  ])

    field = Field(required=True)
    any_0 = validate_with_positions(token=token_0, validator=field)

    # Get the message and compare against the known values
    message_0 = any_0.messages()[0]

# Generated at 2022-06-26 10:35:00.515265
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validation_error0 = None # type: ValidationError

    pass

# Generated at 2022-06-26 10:35:01.872138
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:35:09.126419
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # simple
    token = Token(value="something")
    validator = Field()
    validated = validate_with_positions(token=token, validator=validator)
    assert validated == "something"

    # simple required
    token = Token(value=None)
    validator = Field()
    try:
        validated = validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.text == "The field None is required."
        assert error.start_position is None
        assert error.end_position is None

    # nested required
    class NestedSchema(Schema):
        foobar = Field(required=True)

    token = Token(value={"foo": {"bar": "baz"}})
    validator = NestedSchema()

# Generated at 2022-06-26 10:35:21.761191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    class schema0(Schema):
        field0 = Field(type=int)
        def validate(self, data: typing.Dict[str, typing.Any]) -> typing.Dict[str, typing.Any]:
            assert self.is_valid(data)
            return data

    schema_0 = schema0()
    field_0 = schema0.field0
    field_1 = schema0().field0
    token_1 = Token(value={}, start={}, end={})
    any_1 = validate_with_positions(token=token_1, validator=schema_0)

# Generated at 2022-06-26 10:36:02.558518
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0: typing.Any
    any_1: typing.Any
    any_2: typing.Any
    iter_0: typing.Iterable[typing.Any]
    typing_0: typing.Union[Field, typing.Type[Schema]]
    token_0: Token

    # Function template:

    # Validate the token at the given index with the given validator.

    # Check that the given validator is capable of validating the given
    # type of value.
    assert isinstance(
        token_0, validator.token_type  # type: ignore
    ), "assert 'isinstance(token, validator.token_type)' failed"

    # Try to validate the value.

# Generated at 2022-06-26 10:36:08.869606
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("in test_validate_with_positions()")

    token_0 = None
    assert token_0 == validate_with_positions(
        token=token_0, validator=token_0
    )


# Testing validate_with_positions

test_validate_with_positions()

# Generated at 2022-06-26 10:36:15.555414
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import time
    import pytest
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema

    token_0 = Token(
        type_="",
        start=token_0,
        end=token_0,
        value=token_0,
        lookup=lambda *args, **kwargs: token_0,
    )
    validator_0 = Schema(
        properties={
            "foo": Schema(
                properties={
                    "bar": Schema(
                        type_="boolean",
                        default=validator_0,
                        required=False,
                        parse_default=False,
                        enable_coercion=False,
                    )
                }
            )
        }
    )

# Generated at 2022-06-26 10:36:16.652272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:36:24.195538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String
    from typesystem.positions import Position, Source
    from typesystem.tokens import Node
    from typesystem.tokenize.lexical import lex
    from typesystem.tokenize.syntax import parse

    source = Source("{'a': {'b': 'c'}}")
    tokens = lex(source=source)
    token: Node = parse(tokens=tokens)
    validate_with_positions(token=token, validator={
        "a": {
            "b": String(),
        },
    })
    validate_with_positions(token=token, validator={
        "a": {
            "b": {
                "c": "d",
            },
        },
    })

    token = token.lookup("a")
    validate_

# Generated at 2022-06-26 10:36:36.428108
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.fakes import fake_token_0, fake_field_0, fake_schema_0, fake_message_0, fake_message_1
    from typesystem.tokenize.utils import _get_positions_for_linebreak, fake_position_0, fake_position_1
    
    # [token_0, validator_0]
    token_0 = fake_token_0 # type: Token
    validator_0 = fake_field_0
    try:
        any_0 = validate_with_positions(token=token_0, validator=validator_0)
    except ValidationError as error_0:
        messages_0 = error_0.messages()
        assert len(messages_0) == 1
        message_0 = messages_0[0]
        assert message

# Generated at 2022-06-26 10:36:37.641480
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions() == "Test"
    assert validate_with_positions() == "Test2"


# Generated at 2022-06-26 10:36:41.092117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == 1

# Generated at 2022-06-26 10:36:49.993832
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:36:54.694933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(type="a", value=None, children=(), start=None, end=None)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == None

# Generated at 2022-06-26 10:37:59.444973
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type=str)
    token_0 = Token(
        value=1,
        start=(0, 0),
        end=(0, 0),
        children=[],
        parent=None,
        lookup={},
    )
    any_0 = validate_with_positions(token=token_0, validator=field)

# Generated at 2022-06-26 10:38:04.914099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here

from typesystem.fields import Field, ValidationError

from typesystem.fields import Field, ValidationError

from typing import TypeVar
from typesystem.fields import Field, ValidationError

from typing import NewType
from typesystem.fields import Field, ValidationError

from typing import Callable
from typesystem.fields import Field, ValidationError


# Generated at 2022-06-26 10:38:16.859999
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Testing error message when token is None
    token = None
    error_message = None
    try:
        validate_with_positions(token=token, validator=token)
    except ValidationError as e:
        error_message = e.messages()
    assert len(error_message) == 1
    assert error_message[0].start_position.line == -1
    assert error_message[0].end_position.line == -1
    assert error_message[0].start_position.column == -1
    assert error_message[0].end_position.column == -1
    assert error_message[0].start_position.char_index == -1
    assert error_message[0].end_position.char_index == -1

    # Testing error message when token is not a Token object
    token = ""


# Generated at 2022-06-26 10:38:21.406261
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == None
    token_1 = None
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    assert any_1 == None

# Generated at 2022-06-26 10:38:23.212404
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:30.412268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Set up test harness
    token_1 = Token(value=None, name='test', start=Token.Position(line_number=0, column_number=0, char_index=0), end=Token.Position(line_number=0, column_number=0, char_index=0))
    field_2 = Field(name='test', required=True, type='string', description=None, pattern=None)
    try:
        # Call test function
        validate_with_positions(token=token_1, validator=field_2)
    except ValidationError as error_3:
        assert error_3.messages() == [Message(text='The field \'test\' is required.', code='required', index=['test'], start_position=None, end_position=None)]

# Generated at 2022-06-26 10:38:34.457035
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = TypeVar('token_0', Token, Token)
    def any_0(token_0: Token) -> object:
        return validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:39.585644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except (ValidationError) as e:
        assert len(e.messages) == 1
        assert e.messages[0].text == 'The field "token" is required.'
        assert e.messages[0].index == [{"pointer": "#/token"}]
        assert e.messages[0].start_position == '<unknown>'
        assert e.messages[0].end_position == '<unknown>'

# Generated at 2022-06-26 10:38:44.919306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)


# Unit tests for constant <function validate_with_positions at 0x7fb83763a350>
# def test_validate_with_positions_0():
#     assert None is validate_with_positions()
#
#
# def test_validate_with_positions_1():
#     assert None is validate_with_positions(token=None, validator=None)
#
#
# def test_validate_with_positions_2():
#     assert None is validate_with_positions(token=token_0, validator=None)
#
#
# def test_validate_with_positions_3():
#     assert None is validate_with_positions(token=token_0, validator=token_0)
#


# Generated at 2022-06-26 10:38:46.445908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True

test_case_0()