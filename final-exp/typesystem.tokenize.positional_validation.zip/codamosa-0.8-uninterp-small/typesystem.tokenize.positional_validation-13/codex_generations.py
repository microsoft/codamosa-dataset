

# Generated at 2022-06-26 10:31:02.492391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert None != None
    # assert False == False

# Generated at 2022-06-26 10:31:04.663813
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Start test for validate_with_positions")
    test_case_0()
    print("End test for validate_with_positions")

# main function for testing

# Generated at 2022-06-26 10:31:07.448609
# Unit test for function validate_with_positions
def test_validate_with_positions():
  try:
    validate_with_positions()

  except:
    assert True
  else:
    assert False

# ----
# Main
# ----
if __name__ == "__main__":

    runTests()

# Generated at 2022-06-26 10:31:17.759401
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=None, validator=-4367.93631) == None
    assert validate_with_positions(token=None, validator=-8609.704120455614) == None
    assert validate_with_positions(token=None, validator=4925.561343363249) == None
    assert validate_with_positions(token=None, validator=-7357.407715997758) == None
    assert validate_with_positions(token=None, validator=-5907.733222778187) == None
    assert validate_with_positions(token=None, validator=6829.947170504069) == None
    assert validate_with_positions(token=None, validator=2951.032896365719) == None

# Generated at 2022-06-26 10:31:19.332378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    float_0 = -4367.93631
    any_0 = validate_with_positions(token=token_0, validator=float_0)

# Generated at 2022-06-26 10:31:30.646165
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # From file test_positional_errors.py
    token_0 = None
    float_0 = -4367.93631
    any_0 = validate_with_positions(token=token_0, validator=float_0)

    # From file test_positional_errors.py
    token_0 = None
    float_0 = -4367.93631
    any_0 = validate_with_positions(token=token_0, validator=float_0)

    # From file test_positional_errors.py
    token_0 = None
    float_0 = -4367.93631
    any_0 = validate_with_positions(token=token_0, validator=float_0)

    # From file test_positional_errors.py
    token_0 = None
    float

# Generated at 2022-06-26 10:31:42.040270
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        function_object = validate_with_positions
        try:
            assert function_object(token=None, validator=None) is None
            raise AssertionError()
        except Exception as exception_object:
            assert isinstance(exception_object, ValidationError)
            assert exception_object.messages == [
                Message(
                    text="Expected an object.",
                    code="exception",
                    index=[],
                    start_position=None,
                    end_position=None,
                )
            ]
    except Exception as exception_object:
        assert False

# Generated at 2022-06-26 10:31:51.351015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    # Json file path
    jsonpath = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'validate_with_positions.json')

    # Read test cases from json
    with open(jsonpath, 'r') as f:
        j = json.loads(f.read())

        for case in j['test_cases']:
            # eval() all variables for test case
            for key, value in case['variables'].items():
                try:
                    case['variables'][key] = eval(value)
                except:
                    case['variables'][key] = value

            # Run test case

# Generated at 2022-06-26 10:31:55.974127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("foo")
    validator_0 = Field(name="test", type=str)
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert any_0 == "foo"



# Generated at 2022-06-26 10:31:58.353988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:32:08.180342
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value={}, start={}, end={})
    # any_0 = validate_with_positions(token=token_0, validator=Schema)
    any_1 = validate_with_positions(token=token_0, validator=Field(type=dict))


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:32:09.547623
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == -4367.93631

# Generated at 2022-06-26 10:32:10.407092
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 0


# Generated at 2022-06-26 10:32:10.987856
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 0 == 0

# Generated at 2022-06-26 10:32:15.384335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    float_0 = -8851.91264
    any_0 = validate_with_positions(token=token_0, validator=float_0)

# Generated at 2022-06-26 10:32:27.777618
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    schema_0 = typing.Union[Field, typing.Type[Schema]]
    float_0 = -4367.93631
    any_0 = validate_with_positions(token=token_0, validator=schema_0)
    any_1 = validate_with_positions(token=token_0, validator=float_0)
    float_1 = typing.Union[Field, typing.Type[Schema]]
    any_2 = validate_with_positions(token=token_0, validator=float_1)

# Generated at 2022-06-26 10:32:42.797906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Position of the first token in the text.
    start_position = Position(line=1, char_index=0)

    # Position of the last token in the text.
    end_position = Position(line=3, char_index=5)

    # Create a token from a (sub)string.
    def token(text: str) -> Token:
        return Token(
            text=text, start=start_position, end=end_position, parent=None
        )

    # Create a token from a StringValue.
    def string_value(text: str, raw: str) -> Token:
        return token(text=text)

    # Create a token from a NumberValue.
    def number_value(number: float) -> Token:
        return token(text=str(number))

    # Create a token from a BooleanValue.


# Generated at 2022-06-26 10:32:49.249408
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    float_0 = Field(value_type=float)
    any_0 = validate_with_positions(token=token_0, validator=float_0)
    token_1 = None
    float_1 = -4367.93631
    any_1 = validate_with_positions(token=token_1, validator=float_1)


# Generated at 2022-06-26 10:32:51.763879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(Exception):
        test_case_0()



# Generated at 2022-06-26 10:33:02.908876
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field_0 = Field(name="basic", primitive=str)
    schema_0 = Schema(name="Person", fields=[field_0])

    assert validate_with_positions(token=Token("foo"), validator=schema_0) == {"basic": "foo"}

    field_1 = Field(name="basic", primitive=int)
    schema_1 = Schema(name="Person", fields=[field_1])

    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=Token("foo"), validator=schema_1)
    messages = sorted(exc.value.messages, key=lambda m: m.start_position.char_index)

# Generated at 2022-06-26 10:33:10.240017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Somehow gremlin always puts the first test in the source file.
    test_case_0()


if __name__ == "__main__":
    import __main__

    print("ran %s" % __main__.__file__)

# Generated at 2022-06-26 10:33:17.688733
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = Token(value="")
    any_0 = validate_with_positions(token=token_1, validator=token_1)

    token_2 = Token(value="")
    any_0 = validate_with_positions(token=token_2, validator=token_2)

    token_3 = Token(value="")
    any_0 = validate_with_positions(token=token_3, validator=token_3)

# Generated at 2022-06-26 10:33:19.714355
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = Token(value=9, start={'line': 1, 'column': 1, 'char_index': 0}, end={'line': 1, 'column': 2, 'char_index': 1}, raw='9')
    any_1 = validate_with_positions(token=token_1, validator=int)
    assert any_1 == 9


# Generated at 2022-06-26 10:33:21.827987
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:33:23.844718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError as e:
        for message in e.messages():
            assert not message.start_position and not message.end_position

# Generated at 2022-06-26 10:33:31.156448
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    from typesystem.tokenize import tokens
    from typesystem.tokenize import lexers

    class Paragraph(typesystem.Schema):
        text = typesystem.Text()

    class Article(typesystem.Schema):
        title = typesystem.String(min_length=10)
        paragraphs = typesystem.Array(items=tokens.Token("Paragraph"))

    lexer = lexers.ArrayLexer(
        items_lexer=lexers.ObjectLexer(
            mapping={
                "text": tokens.Token("Text"),
            },
        ),
    )

    token = lexer.read("[{}]")


# Generated at 2022-06-26 10:33:43.565546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert token_0 == token_0
    assert any_0 == token_0
    assert any_0 == None
    assert error.start_position == (1, 2)
    assert error.end_position == (1, 2)
    assert message_4 == positional_message_4
    assert message_4 == {'index': [], 'code': 'required', 'text': 'The field "foo" is required.', 'start_position': (1, 2), 'end_position': (1, 2)}
    assert positional_message_4 == message_4
    assert positional_message_4 == {'index': [], 'code': 'required', 'text': 'The field "foo" is required.', 'start_position': (1, 2), 'end_position': (1, 2)}
    assert positional_message_5 == message_5
   

# Generated at 2022-06-26 10:33:44.490064
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:33:52.182504
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    token_0.start = Position(char_index=-1, line=-1)
    token_0.end = Position(char_index=-1, line=-1)

    token_1 = Token()
    token_1.start = Position(char_index=-1, line=-1)
    token_1.end = Position(char_index=-1, line=-1)

    any_0 = validate_with_positions(token=token_0, validator=token_1)


# Generated at 2022-06-26 10:33:59.620359
# Unit test for function validate_with_positions
def test_validate_with_positions():

    token_1 = Token(
        name="example",
        required=True,
        value=None,
        start=None,
        end=None,
        index=["example"],
        children={},
    )
    # value
    token_1.value = "not a valid email address"
    # expected output
    expected_output = ValidationError(
        messages=[
            Message(
                text="Must be a valid email address.",
                code="invalid",
                index=["example"],
                start_position=None,
                end_position=None,
            )
        ]
    )
    # actual output
    with pytest.raises(ValidationError) as exception_info:
        validate_with_positions(token=token_1, validator=token_1)

# Generated at 2022-06-26 10:34:04.422000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == None



# Generated at 2022-06-26 10:34:05.495484
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:34:10.053407
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("stdout", LinePosition(0, 0), LinePosition(0, 6))
    with pytest.raises(Exception):
        any_0 = validate_with_positions(token=token_0, validator=token_0)


# Generated at 2022-06-26 10:34:16.475437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = { type: "Mapping", start: 693, end: 698, children: [ { type: "String", start: 693, end: 696, value: "foo" }, { type: "Int", start: 697, end: 698, value: 1 } ] }
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:34:29.317624
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        any_0 = None
        any_1 = None
        token_0 = None
        any_2 = validate_with_positions(token=token_0, validator=token_0)
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = message.index[:-1]
                text = f"The field {field!r} is required."
            else:
                token = message.index
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )

# Generated at 2022-06-26 10:34:30.866965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1


# Generated at 2022-06-26 10:34:34.537807
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=1, start=None, end=None)
    validator_0 = Field(type="integer")
    any_0 = validate_with_positions(token=token_0, validator=validator_0)

# Generated at 2022-06-26 10:34:35.757537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:34:44.722140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pattern = re.compile(
        r"validate_with_positions\((.*)\)$"
    )
    for case in testcases:
        args = {}
        for match in re.finditer(pattern, case):
            for arg in match.groups()[0].split(", "):
                name, value = arg.split("=")
                args[name] = ast.literal_eval(value)

        token = args.get("token")
        validator = args.get("validator")
        with contextlib.redirect_stdout(StringIO()):
            try:
                validate_with_positions(token=token, validator=validator)
            except Exception as exc:
                print(exc)

# Collect testcases

# Generated at 2022-06-26 10:34:57.382906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        type=TokenType.STRING,
        value="string",
        start=Position(
            line=1,
            char_index=0,
            line_text="string    = 'string'",
            file_path="/home/user/.virtualenvs/typesystem_20kaLfm/lib/python3.6/site-packages/typesystem/parser.py",
        ),
        end=Position(
            line=1,
            char_index=18,
            line_text="string    = 'string'",
            file_path="/home/user/.virtualenvs/typesystem_20kaLfm/lib/python3.6/site-packages/typesystem/parser.py",
        ),
    )

# Generated at 2022-06-26 10:35:16.905392
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field()
    assert validator.validate("foo") == "foo"
    assert validator.validate(None) == None

    token = Token(start=0, end=3, value="foo", path=[])
    try:
        assert not validator.validate(token)
    except ValidationError as error:
        assert error.messages() == [
            Message(code="invalid", text="Must be a string.", index=())
        ]
    assert validate_with_positions(token=token, validator=validator) == "foo"

    token = Token(start=0, end=13, value="invalid-value", path=[])

# Generated at 2022-06-26 10:35:20.333310
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()

    # Call function validator
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    assert isinstance(any_0, Token)

# Generated at 2022-06-26 10:35:20.722341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:35:21.589590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True



# Generated at 2022-06-26 10:35:30.057910
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        assert False
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = message.index[:-1]
                text = f"The field {field!r} is required."
            else:
                token = message.index
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )
            messages.append(positional_message)
        messages = sorted(
            messages, key=lambda m: m.start_position.char_index  # type: ignore
        )
        raise ValidationError

# Generated at 2022-06-26 10:35:36.148676
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value={"id": "user1", "name": "Joe"}, start=(0, 0), end=(0, 0))
    schema = Schema({"id": str, "name": str})
    any_0 = validate_with_positions(token=token_0, validator=schema)
    assert any_0 == {
        "id": "user1",
        "name": "Joe",
    }


# Generated at 2022-06-26 10:35:43.865279
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Invalid type for parameter token: got <class 'NoneType'>, expected <class 'typesystem.tokenize.tokens.Token'>
    with pytest.raises(TypeError):
        test_case_0()
    # Invalid type for parameter validator: got <class 'NoneType'>, expected <class 'typesystem.fields.Field'> or <class 'typesystem.schemas.Schema'>
    with pytest.raises(TypeError):
        test_case_0()



# Generated at 2022-06-26 10:35:52.289373
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import ast
    import _ast
    from ast_helper import ast_load, ast_store
    
    
    
    
    ast_0 = None
    ast_1 = None
    ast_2 = None
    ast_3 = None
    ast_4 = None
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    assert(ast_0 == ast_1)
    assert(ast_0 == ast_2)
    assert(ast_0 == ast_3)
    assert(ast_0 == ast_4)
    assert(ast_1 == ast_2)
    assert(ast_1 == ast_3)
    assert(ast_1 == ast_4)
    assert(ast_2 == ast_3)

# Generated at 2022-06-26 10:36:02.189612
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import astroid
    from python_ta.typecheck.base import TypeFail
    from python_ta import check_all
    module_name = 'extract.submissions.lab09.types.checkpoints'
    module_ast, type_store, value_store = check_all(module_name, debug=False)

    i = 0
    for node in module_ast.nodes_of_class(astroid.Call):
        if node.func.attrname == 'validate_with_positions':
            assert node.keywords[0].arg == 'token'
            assert node.keywords[1].arg == 'validator'
            i += 1

    assert i == 2

# Generated at 2022-06-26 10:36:13.057607
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions
    token_0 = Token(value="123", start=1, end=2)
    token_1 = Token(value="", start=None, end=None)
    field_0 = Field(name="foo", type="number")
    schema_0 = Schema(
        name="bar",
        fields=[
            Field(name="foo", type="string", required=True),
            Field(name="bar", type="integer", required=False),
        ],
    )
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    any_1 = validate_with_positions(token=token_0, validator=schema_0)

# Generated at 2022-06-26 10:36:33.621576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import inftest

    # Input parameters and expected results
    token_0 = None
    validator_0 = None
    assert validate_with_positions(token=token_0, validator=validator_0) == None

    token_1 = None
    validator_1 = None
    assert validate_with_positions(token=token_1, validator=validator_1) == None

# Generated at 2022-06-26 10:36:47.536748
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Test that a ValidationError with no message.start_position or
    # message.end_position attribute is returned when the function is called
    # with a token argument that does not have a start and end attribute.
    token_0 = Token()
    try:
        validate_with_positions(token=token_0, validator=token_0)
    except ValidationError as e:
        assert e.args[0] == 'Message(text="Missing position", code="missing", index=[])'

    # Test that a required field from a token is returned when the function
    # is called with a token and a validator that has a required field.
    token_1 = Token()
    validator_0 = Field(name="field_0", required=True)

# Generated at 2022-06-26 10:36:52.983449
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value=["id_0", "id_1", "id_2", "id_3"],
        start={"line_number": 1, "char_index": 1},
        end={"line_number": 5, "char_index": 1},
    )
    class schema_0(Schema):
        field_0 = Field(type="str")
        field_1 = Field(type="float")

        @classmethod
        def validate(cls, value):
            return {'field_0': value[0], 'field_1': value[1]}

    validator_0 = schema_0
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    print(any_0)

# Generated at 2022-06-26 10:37:03.125969
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class ListItem(Schema):
        value = Field(type="string")

    class List(Schema):
        items = Field(type="array", items=ListItem)

    token = Token.from_dict(
        {
            "items": [
                {"value": "foo"},
                {"value": "bar", "other": "baz"},
                {"value": "buz"},
            ]
        }
    )

    error = None
    try:
        List.validate(token.value)
    except ValidationError as error:
        pass
    assert error is not None

    # errors = [(m.start_position.line_index, m.start_position.char_index)
    #           for m in error.messages]
    # assert errors == [(0, 0), (0, 0), (0, 0),

# Generated at 2022-06-26 10:37:05.336547
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arguments
    token = None
    validator = None
    # Return type annotation
    assert isinstance(validate_with_positions(token=token, validator=validator), None)



# Generated at 2022-06-26 10:37:15.347866
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typesystem
    import typesystem.tokenize

    def test_case_0():
        token_0 = typesystem.tokenize.tokens.DictToken(
            start=typesystem.tokenize.position.Position(
                char_index=0, column=0, line_index=0, line_text=""
            ),
            end=typesystem.tokenize.position.Position(
                char_index=0, column=0, line_index=0, line_text=""
            ),
            value={"foo": "bar"},
        )

# Generated at 2022-06-26 10:37:18.550377
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class PersonSchema(Schema):
        name = Field(type=str)
    token_0 = Token(value=1, path=["name"])
    any_0 = validate_with_positions(token=token_0, validator=PersonSchema)

# Generated at 2022-06-26 10:37:28.507090
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # No errors, field
    expected_result = ["x", "y"]
    actual_result = validate_with_positions(
        token=Token(value=expected_result), validator=Field(name="test", type="array")
    )
    assert expected_result == actual_result

    # No errors, schema
    expected_result = {"x": "y"}
    actual_result = validate_with_positions(
        token=Token(value=expected_result), validator=Schema({"x": "text"})
    )
    assert expected_result == actual_result

    # Errors, field
    field = Field(name="test", type="array")
    token_1 = Token(value="not a list")
    with pytest.raises(ValidationError) as error_info:
        validate_with_positions

# Generated at 2022-06-26 10:37:34.001745
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text_0 = "hello world"
    token_0 = Token(text_0, start=0, end=len(text_0))
    assert validate_with_positions(token=token_0, validator=token_0) == text_0



# Generated at 2022-06-26 10:37:36.447199
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = validate_with_positions(
        token={}, validator={'name': "name"}
    )
    assert any_0 == ({'name': "name"},)

# Generated at 2022-06-26 10:37:53.628804
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("foo")
    assert validate_with_positions(token=token, validator=str) == "foo"

# Generated at 2022-06-26 10:37:54.429861
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:37:58.502174
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with mock.patch(
        "typesystem.tokenize.validator.validate_with_positions.Message",
        new_callable=mock.PropertyMock,
        return_value=None,
    ) as Message:
        Message.return_value.text = None
        Message.return_value.code = None
        Message.return_value.index = None
        Message.return_value.start_position = None
        Message.return_value.end_position = None
        with mock.patch(
            "typesystem.tokenize.validator.validate_with_positions.Token",
            new_callable=mock.PropertyMock,
            return_value=None,
        ) as Token:
            Token.return_value.value = None
            Token.return_value.lookup = None

# Generated at 2022-06-26 10:38:00.468187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:01.039236
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False

# Generated at 2022-06-26 10:38:08.733772
# Unit test for function validate_with_positions
def test_validate_with_positions():

    field = Field(type="string", max_length=1)
    token = Token("name", "A", (1, 1))
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages[0]
        assert message.code == "max_length"
        assert message.index == ["name"]
        assert message.text == 'Value should have no more than 1 characters.'
        assert message.start_position.line_index == 1
        assert message.start_position.char_index == 1
        assert message.end_position.line_index == 1
        assert message.end_position.char_index == 2

# Generated at 2022-06-26 10:38:19.554665
# Unit test for function validate_with_positions
def test_validate_with_positions():

    schema = Schema(fields={"foo": Field(required=True)})

    token = Token(
        value={},
        start=Message(line_number=1, char_index=0, char_count=1),
        end=Message(line_number=1, char_index=0, char_count=1),
    )

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 1
        message = error.messages()[0]
        assert message.code == "required"
        assert message.start_position == Message(
            line_number=1, char_index=0, char_count=1
        )

# Generated at 2022-06-26 10:38:28.502427
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test 1
    token_1 = Token(value={"username": "test", "email": "test@test.test"}, start=None, end=None)
    user_1 = validate_with_positions(token=token_1, validator=User)

    assert user_1.username == "test"
    assert user_1.email == "test@test.test"


# Test 2
token_2 = Token(
    value=[
        {"username": "test", "email": "test@test.test"},
        {"username": "test", "email": "test@test.test"},
        {"username": "test", "email": "test@test.test"},
    ],
    start=None,
    end=None,
)

# Generated at 2022-06-26 10:38:39.143568
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import unittest

    from typesystem.tokenize.tokens import Token

    # Mocks
    class Message_Mock:
        def __init__(self):
            pass
        @staticmethod
        def __new__(cls):
            return Message_Mock()
        def __init__(self):
            pass
        def __init__(self):
            pass
        def __init__(self):
            pass

    class ValidationError_Mock:
        def __init__(self):
            pass
        @staticmethod
        def __new__(cls):
            return ValidationError_Mock()
        def __init__(self, messages: typing.Any):
            pass
        def __init__(self):
            pass
        def __init__(self):
            pass


# Generated at 2022-06-26 10:38:41.934895
# Unit test for function validate_with_positions
def test_validate_with_positions():
    code_lines = test_case_0.__code__.co_consts[3].splitlines()
    assert code_lines == [
        "    token_0 = None",
        "    any_0 = validate_with_positions(token=token_0, validator=token_0)",
    ]

# Generated at 2022-06-26 10:39:12.006578
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    token_0.range = None
    token_0.lookup = None
    token_0.end = None
    token_0.start = None
    token_0.value = None
    token_0.length = None
    token_0.depth = None
    token_0.line = None
    token_0.column = None
    token_0.type = None
    validator_0 = Field()
    validator_0.get_matching_options = None
    validator_0.has_default = None
    validator_0.name = None
    validator_0.description = None
    validator_0.get_matching_types = None
    validator_0.error_code = None
    validator_0.choices = None

# Generated at 2022-06-26 10:39:18.326365
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(value={}, start=(0, 0), end=(1, 2))
    field = Field(type=str)
    validator = field.validate(token.value)
    assert validator == None


# Generated at 2022-06-26 10:39:24.311238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Root(Schema):
        name = Field(str, min_length=1)
        age = Field(int, min_value=1)

    token = Token.parse_text(
        text="""
        {
            "age": 18,
            "name": "Fred"
        }
    """
    )

    assert token.end is not None
    value = validate_with_positions(token=token, validator=Root)

    expected = {"age": 18, "name": "Fred"}
    assert value == expected



# Generated at 2022-06-26 10:39:27.435998
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:39:31.444498
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token0 = Token(value=2.1, index=0)
    validator0 = Field(required=True)

    # Call the function
    validate_with_positions(token=token0, validator=validator0)



# Generated at 2022-06-26 10:39:33.776834
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token="foo", validator=str) == "foo"

# Generated at 2022-06-26 10:39:35.889301
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)


# Generated at 2022-06-26 10:39:40.716671
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test case #0
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:39:53.037233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("<input>", "", "", "", "", "")
    try:
        any_0 = validate_with_positions(token=token_0, validator=token_0)
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = message.index[-1]
                text = f"The field {field!r} is required."
            else:
                token = message.index
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )
            messages.append

# Generated at 2022-06-26 10:39:59.163742
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # setup
    token = Token()
    validator = Field()
    # exercise
    result = validate_with_positions(token=token, validator=validator)
    # verify
    assert result == None
    # cleanup
    pass

# Generated at 2022-06-26 10:40:22.845458
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Initialize test case
    token_0 = Token
    validator_0 = Field

    # Call function or method under test
    result_0 = validate_with_positions(token=token_0, validator=validator_0)

# Generated at 2022-06-26 10:40:26.405496
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typesystem

    class TestSchema(typesystem.Schema):
        pass

    schema = TestSchema()

    token_0: Token = Token("foo", "foo")

    with pytest.raises(ValueError):
        any_0 = validate_with_positions(token=token_0, validator=schema)

# Generated at 2022-06-26 10:40:27.470657
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:40:32.567328
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError:
        pass
    else:
        pass


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:40:39.020076
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any  # to fix pyflakes warning: "any" imported but unused

    # Assert that the function throws an exception if "token" is not provided.
    try:
        validate_with_positions()
    except TypeError as e:
        if "missing 1 required positional argument" not in str(e):
            raise e

    # Assert that the function throws an exception if "validator" is not provided.
    try:
        validate_with_positions(token=None)
    except TypeError as e:
        if "missing 1 required positional argument" not in str(e):
            raise e

    # Assert that the function throws an exception if it is provided an invalid value for "token".

# Generated at 2022-06-26 10:40:44.118788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text = "Hello"
    token = Token(type="String", value=text, start_position=0, end_position=5)

    validate_with_positions(token=token, validator=Field(type="string"))



# Generated at 2022-06-26 10:40:45.383028
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False #FIXME: implement your test here


# Generated at 2022-06-26 10:40:50.235273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Make sure we've tested to at least line #2
    assert test_validate_with_positions.__code__.co_firstlineno >= 2
    assert test_case_0() is None

# Generated at 2022-06-26 10:40:59.096758
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value="six",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 4},
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_1 = Token(
        value="six",
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 4},
    )
    any_1 = validate_with_positions(token=token_1, validator=Field(max_length=5))