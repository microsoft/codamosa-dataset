

# Generated at 2022-06-26 10:31:08.667280
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.lexers as module_0
    import typesystem.tokenize.tokens as module_1
    import typesystem.tokenize.position as module_2
    import typesystem.fields as module_3
    token_0 = module_1.Token(
        value=b"a",
        lexer=module_0.StringLexer(pattern=b"[0-9a-zA-Z\\-_\\:]+"),
        start=module_2.Position(line=0, column=0, char_index=0),
        end=module_2.Position(line=0, column=1, char_index=1),
    )

# Generated at 2022-06-26 10:31:16.912208
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        start={
            "line_number": 0,
            "char_index": 0,
            "token_index": 0,
            "column_number": 0,
        },
        end={
            "line_number": 0,
            "char_index": 0,
            "token_index": 0,
            "column_number": 0,
        },
        value=None,
        value_type="null_type",
        lookup=lambda self, key: None,
    )
    field_0 = Field(default=None)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:31:18.249136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:21.750570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="The field description is required.",
                code="required",
                index=[],
                start_position=None,
                end_position=None,
            )
        ]

# Generated at 2022-06-26 10:31:26.024315
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None



from gql.error import GraphQLError

from gql.lexer import lex
from gql.parser import parse
from gql.validator import validate



# Generated at 2022-06-26 10:31:37.341667
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.fields as module_0
    import typesystem.tokenize.tokens as module_1
    token_0 = None
    # Unpack the first element of module_1.tokenize
    tokenize = module_1.tokenize
    tokenize_0 = tokenize[0]
    tokenize_1 = tokenize[1]
    # Call function 'tokenize_0'
    token_0 = tokenize_0(token_0)
    field_0 = module_0.Field(default=token_0)
    # Call function 'validate_with_positions'
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    assert any_0 is None

# Generated at 2022-06-26 10:31:45.005233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value='nested')
    field_0 = module_0.String()
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    token_1 = Token(value={'name': 'John Doe'})
    field_1 = module_0.Object(
        properties={'name': module_0.String()}
    )
    any_1 = validate_with_positions(token=token_1, validator=field_1)
    token_2 = Token(value={'name': 'John Doe', 'age': 42})
    field_2 = module_0.Object(
        properties={'name': module_0.String(), 'age': module_0.Integer()}
    )

# Generated at 2022-06-26 10:31:49.036105
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    field_0 = module_0.Field(default=token_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

import typesystem.fields as module_0
import typing
import typesystem.fields as module_1


# Generated at 2022-06-26 10:32:01.334394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys, io
    import traceback
    from unittest import TestCase
    from unittest.mock import MagicMock, patch

    test_case_1 = TestCase(name="test case 1")
    test_case_2 = TestCase(name="test case 2")
    test_cases = [test_case_1, test_case_2]

    def test_run_test_case(test_case):
        test_method_name = "test_case_{0}".format(test_case.name.split()[-1])
        test_method = globals()[test_method_name]

        buffer = io.StringIO()
        patched_stderr = patch('sys.stderr', buffer)


# Generated at 2022-06-26 10:32:04.248506
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def test_case_0():
        token_0 = None
        field_0 = module_0.Field(default=token_0)
        any_0 = validate_with_positions(token=token_0, validator=field_0)

    test_case_0()

# Generated at 2022-06-26 10:32:08.450321
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None

# Generated at 2022-06-26 10:32:19.073303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        var_0 = None
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = token.lookup(message.index[:-1])
                text = f"The field {field!r} is required."
            else:
                token = token.lookup(message.index)
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )
            messages.append(positional_message)

# Generated at 2022-06-26 10:32:30.256682
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={},
        fields={
            "foo": Token(
                value={},
                fields={
                    "bar": Token(
                        value={},
                        fields={
                            "baz": Token(
                                value="missing",
                                fields=None,
                                start=[(0, 5)],
                                end=[(0, 11)],
                            )
                        },
                        start=[(0, 4)],
                        end=[(0, 12)],
                    )
                },
                start=[(0, 1)],
                end=[(0, 13)],
            )
        },
        start=[(0, 0)],
        end=[(0, 14)],
    )
    validator = Field(type_name="string", required=True)

# Generated at 2022-06-26 10:32:44.134818
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None

    try:
        var_0 = validate_with_positions(token=var_0, validator=var_0)
    except ValidationError as error:
        var_0 = error.messages()
    var_1 = var_0

    var_2 = None

    try:
        var_2 = validate_with_positions(token=var_2, validator=var_2)
    except ValidationError as error:
        var_2 = error.messages()
    var_3 = var_2

    var_4 = None

    try:
        var_4 = validate_with_positions(token=var_4, validator=var_4)
    except ValidationError as error:
        var_4 = error.messages()
    var_5 = var_4

# Generated at 2022-06-26 10:32:46.381390
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert (validate_with_positions(token = var_0, validator = var_0))


# Generated at 2022-06-26 10:32:55.470760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Text

    field = Text(max_length=10)

    token = Token(
        value="Et et ut sunt culpa.",
        start=(1, 12),
        end=(1, 28),
        source="test.example",
    )

    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        message = error.messages[0]
        assert message.code == "too-long"
        assert message.index == []
        assert message.text == "Ensure this value has at most 10 characters (it has 16)."
        assert message.start_position.line_number == 1
        assert message.start_position.char_index == 12
        assert message.end_position.line_number == 1

# Generated at 2022-06-26 10:32:59.786377
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = validate_with_positions(token=var_0, validator=var_0)
    assert isinstance(var_1, ValidationError)


# Generated at 2022-06-26 10:33:03.790576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        assert var_0 == test_case_0()
    except AssertionError as e:
        print("Error running test case: test_case_0")
        raise(e)

# Generated at 2022-06-26 10:33:06.939595
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(start='1:3', end='1:10', value=None)
    validator = True
    assert validate_with_positions(token=token, validator=validator) == True



# Generated at 2022-06-26 10:33:12.951224
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with raises(ValidationError):
        validate_with_positions(
            token=var_0,
            validator=typing.cast(typing.Type[Schema],type(None)),
        )

# Generated at 2022-06-26 10:33:18.886000
# Unit test for function validate_with_positions
def test_validate_with_positions():
    func = validate_with_positions
    # TODO: Write unit tests for validate_with_positions

# Generated at 2022-06-26 10:33:26.842803
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # var_0 = None
    var_0 = Token(value=None, start=None, end=None, lookup=None)
    # call the function validate_with_positions
    # assert the returned value (assert_value) against "None"
    assert validate_with_positions(token=var_0, validator=Field(primitive_type=None)) == "None"

    # var_0 = None
    var_0 = Token(value=None, start=None, end=None, lookup=None)
    # call the function validate_with_positions
    # assert the returned value (assert_value) against "None"
    assert validate_with_positions(token=var_0, validator=Field(primitive_type=None, required=True)) == "None"

    # var_0 = None
    var_

# Generated at 2022-06-26 10:33:32.128913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=var_0,
            validator=var_1,
        )
    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].text == "The field 'foo' is required."
        assert error.messages()[0].start_position.line == 1
        assert error.messages()[0].start_position.char_index == 1
        assert error.messages()[0].end_position.line == 1
        assert error.messages()[0].end_position.char_index == 1


# Generated at 2022-06-26 10:33:37.410786
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from asdf.types import Boolean
    from asdf.tags.core import Typed
    validator = Typed(validator=Boolean())
    token = Token({"type": "object", "value": True})
    validate_with_positions(token=token, validator=validator)



# Generated at 2022-06-26 10:33:45.915447
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from pyspark.sql import Row
    from pyspark.sql.types import StructType, StructField, IntegerType, StringType

    from sparkql import is_schema, Schema, Field, Integer, String

    example_schema = StructType([
        StructField("id", IntegerType(), False),
        StructField("name", StringType(), True),
    ])

    example_row = Row(id=100, name="John")

    my_schema = Schema(fields={
        "id": Integer,
        "name": String,
    })

    assert is_schema(my_schema)
    assert is_schema(example_schema)

    assert my_schema.validate(example_row) == example_row

    assert example_row == example_schema.validate(example_row)

    my

# Generated at 2022-06-26 10:33:54.167954
# Unit test for function validate_with_positions
def test_validate_with_positions():

    t_0_0 = Token(
        "foo",
        start_position=Position(line_index=0, char_index=0),
        end_position=Position(line_index=0, char_index=3),
    )
    v_0_0 = String(required=True)
    try:
        result = validate_with_positions(token=t_0_0, validator=v_0_0)
    except ValidationError as error:
        assert error.messages[0].start_position == Position(line_index=0, char_index=0)

# Generated at 2022-06-26 10:34:00.715010
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    def func_0(token: Token, validator: typing.Union[Field, typing.Type[Schema]]):
        var_0 = validate_with_positions(token=token, validator=validator)
        return var_0
    var_0 = func_0(token, validator)
    assert var_0 == var_0

# Generated at 2022-06-26 10:34:02.333493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = var_0
    var_2 = var_1
    pass


# Generated at 2022-06-26 10:34:05.552781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    var_0 = None
    
    # Invocation
    try:
        validate_with_positions(token=var_0, validator=var_0)
    except Exception as err:
        pass

# Generated at 2022-06-26 10:34:06.432658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test case 0
    assert True == True

# Generated at 2022-06-26 10:34:16.188599
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import collections
    import copy
    import typing
    from typesystem.fields import Field
    from typesystem.tokenize.tokens import Token
    from .cases import cases

    assert_equals = cases.assert_equals
    assert_raises = cases.assert_raises

    assert_raises(validate_with_positions, None, None, None)



# Generated at 2022-06-26 10:34:17.462956
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:34:18.816988
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False


# Generated at 2022-06-26 10:34:25.045142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = tokenize_string("hi")
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0


if __name__ == "__main__":
    import sys

    import pytest

    pytest.main(sys.argv)

# Generated at 2022-06-26 10:34:36.360252
# Unit test for function validate_with_positions
def test_validate_with_positions():

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

   

# Generated at 2022-06-26 10:34:44.992454
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Primitive argument-no defaults
    args = [
        [
            {"token":token_0, "validator":token_0} # {'token': 'a', 'validator': 'a'}
        ]
    ]

    for arg in args:
        try:
            test_case_0(*arg) # {'token': 'a', 'validator': 'a'}
        except Exception as e:
            print(e.__context__, file=sys.stderr)
            print(e.__traceback__, file=sys.stderr)
            print(traceback.format_exc(e), file=sys.stderr)
            raise e
        finally:
            print("test case finished", file=sys.stderr)

if __name__ == "__main__":
    test_validate

# Generated at 2022-06-26 10:34:57.571490
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(start_position=None, end_position=None, value=None, path=(0,))
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert isinstance(any_0, typing.Any)
    token_1 = Token(start_position=None, end_position=None, value=None, path=(1,))
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    assert isinstance(any_1, typing.Any)
    token_2 = Token(start_position=None, end_position=None, value=None, path=(2,))
    any_2 = validate_with_positions(token=token_2, validator=token_2)

# Generated at 2022-06-26 10:34:59.232195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:35:02.366967
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == None

# Generated at 2022-06-26 10:35:07.420648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=False, validator=False) is False
    assert validate_with_positions(token=0, validator=0) == 0
    assert validate_with_positions(token=0.0, validator=0.0) == 0.0
    assert validate_with_positions(token="", validator="") == ""
    assert validate_with_positions(token=[], validator=[]) == []
    assert validate_with_positions(token={}, validator={}) == {}

# Generated at 2022-06-26 10:35:15.951443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:35:18.064316
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions), "Function 'validate_with_positions' not callable"

# Generated at 2022-06-26 10:35:18.792038
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:35:22.293135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = 1
    validator_0 = 1
    with pytest.raises(TypeError):
        any_0 = validate_with_positions(token=token_0, validator=validator_0)



# Generated at 2022-06-26 10:35:26.357707
# Unit test for function validate_with_positions
def test_validate_with_positions():
    _test_case_0()
    _test_case_1()
    _test_case_2()
    _test_case_3()
    _test_case_4()
    _test_case_5()
    _test_case_6()
    _test_case_7()

# Generated tests for case 0

# Generated at 2022-06-26 10:35:29.887812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    mock_validator = Mock(Field)
    mock_validator.validate = dummy_function
    any_0 = validate_with_positions(token=token_0, validator=mock_validator)
    assert any_0 == None
    assert mock_validator.validate.call_count == 0


# Generated at 2022-06-26 10:35:31.968170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=token_0, validator=token_0) == any_0


# Generated at 2022-06-26 10:35:44.141087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(primitive="string")
    token = Token(value="foo")
    validate_with_positions(token=token, validator=field)

    token = Token(value="foo")
    class MySchema(Schema):
        field = Field(primitive="string")
    validate_with_positions(token=token, validator=MySchema)

    # Errors should contain line and column information.
    field = Field(primitive="string", required=True)
    token = Token(value=None)

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=field)

    token = Token(value="foo")
    class MySchema(Schema):
        field = Field(primitive="string", required=True)

# Generated at 2022-06-26 10:35:52.462295
# Unit test for function validate_with_positions
def test_validate_with_positions():   
    # case 1
    token_1 = None
    any_3 = validate_with_positions(token=token_1, validator=token_1)
    # case 2
    token_2 = None
    any_4 = validate_with_positions(token=token_1, validator=token_2)
    # case 3
    token_3 = None
    any_5 = validate_with_positions(token=token_2, validator=token_2)
    # case 4
    token_4 = None
    any_6 = validate_with_positions(token=token_2, validator=token_3)
    # case 5
    token_5 = None
    any_7 = validate_with_positions(token=token_3, validator=token_3)
    # case 6
    token_

# Generated at 2022-06-26 10:35:55.503168
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions() == ''  # TODO: implement your test here


# Generated at 2022-06-26 10:36:12.590210
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="integer")
    token = Token("test", start=("", 1, 1), end=("", 1, 5), value=42)
    value = validate_with_positions(token=token, validator=field)
    assert value == 42



# Generated at 2022-06-26 10:36:13.767936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass


# Generated at 2022-06-26 10:36:16.803823
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = Token()
    any_0 = validate_with_positions(token=token_1, validator=token_1)



# Generated at 2022-06-26 10:36:22.270984
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Define first argument
    token_0 = None
    
    # Define second argument
    validator_0 = None
    
    # Call function
    try:
        function_result = validate_with_positions(token=token_0, 
                                                  validator=validator_0)
    except Exception as exception:
        function_result = exception
    
    # Assert the expected exception is raised
    assert isinstance(function_result, TypeError)

# Generated at 2022-06-26 10:36:28.078215
# Unit test for function validate_with_positions
def test_validate_with_positions():

    token = Token("", 0, 1)
    validator = Field()
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-26 10:36:36.982237
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Any, Dict, Tuple, Type
    from typing import Type as tType


    from typesystem import Array, Boolean, Date, DateTime, Decimal, Field, Integer
    from typesystem import Object, String
    from typesystem.tokenize import Token, Tokenizer


    class User(Object):
        username = String(
            min_length=1, max_length=64, error_messages={"required": "*required*"}
        )
        email = String(format="email", error_messages={"required": "*required*"})
        preferences = Object(
            properties={"opt_in": Boolean()},
            default={"opt_in": False},
            error_messages={"required": "*required*"},
        )


# Generated at 2022-06-26 10:36:48.415436
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None

    # Call function with args
    try:
        validate_with_positions(token=token_0, validator=token_0)
    except Exception as e:
        stypy.errors.type_error.StypyTypeError.get_error_msgs()
        stypy.errors.type_error.StypyTypeError.get_error_msgs()
        # Declaration of the 'token_0' of a type

        stypy_localization = localization.Localization(__file__, 0, 0)
        stypy_type_store = stypy.errors.type_store.TypeStore()
        # Declaration of the 'token_0' of a type

        stypy_localization = localization.Localization(__file__, 0, 0)

# Generated at 2022-06-26 10:36:53.736762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        context=(
            "first_line\nsecond_line",
            {
                "start": {"line_index": 0, "char_index": 0},
                "end": {"line_index": 1, "char_index": 16},
            },
        )
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    token_1 = Token(
        context=(
            "first_line\nsecond_line",
            {
                "start": {"line_index": 0, "char_index": 0},
                "end": {"line_index": 1, "char_index": 16},
            },
        ),
        children=[token_0],
    )

# Generated at 2022-06-26 10:37:00.764188
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup

    validator_0 = None # TODO
    # Late-binding value
    token_0 = None
    # Late-binding value
    any_0 = None

    # Assign

    validator_0 = token_0
    token_0 = validator_0
    any_0 = validate_with_positions(token=token_0, validator=validator_0)

    # Assert

# Generated at 2022-06-26 10:37:01.885363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:37:41.166872
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import ObjectToken
    from typesystem.tokenize.tokens import ArrayToken
    from typesystem.tokenize.tokens import StringToken
    from typesystem.tokenize.tokens import NumberToken
    from typesystem.tokenize.tokens import NullToken
    from typesystem.tokenize.tokens import BooleanToken
    from typesystem.fields import String
    from typesystem.fields import Integer
    from typesystem.fields import Boolean
    from typesystem.fields import Number
    from typesystem.fields import Field
    from typesystem.fields import Object
    from typesystem.fields import Array
    from typesystem.fields import Enum
    from typesystem.schemas import Schema
    from typesystem.schemas import register

# Generated at 2022-06-26 10:37:47.280034
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)



if __name__ == '__main__':
    test_case_0()
    test_validate_with_positions()

# Generated at 2022-06-26 10:37:54.049026
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token(
        value={"field": "foo"},
        start={"line": "line", "column": "column", "char_index": "char_index"},
        end={"line": "line", "column": "column", "char_index": "char_index"},
    )

    assert validate_with_positions(token=token, validator=field) == "foo"



# Generated at 2022-06-26 10:37:56.394221
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        token_type="TEST",
        value="foo",
        start=Token.Position(line=1, char_index=2),
        end=Token.Position(line=1, char_index=5),
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:02.487545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0: Token = Token(
        key=None,
        value=dict,
        start={"line": 1, "column": 2, "char_index": 4},
        end={"line": 2, "column": 4, "char_index": 10},
        children=[],
    )

    with pytest.raises(ValidationError):
        validate_with_positions(token=token_0, validator=Field(name="foo"))

# Generated at 2022-06-26 10:38:09.688441
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        key="key",
        value=None,
        queries=[],
        start=Start(line=2, char_index=15),
        end=End(line=2, char_index=20),
    )
    try:
        validate_with_positions(
            token=token,
            validator=Field(required=True, error_messages=[{"code": "required"}]),
        )
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == "The field 'key' is required."
        assert message.code == "required"
        assert message.index == ["key"]
        assert message.start_position == token.start
        assert message.end_position == token.end



# Generated at 2022-06-26 10:38:10.745189
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here

# Generated at 2022-06-26 10:38:17.950130
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        "token_0",
        {},
        [
            Token("token_1", {"name": "token_1"}, []),
            Token("token_2", {"name": "token_2"}, []),
            Token("token_3", {"name": "token_3"}, []),
        ],
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:26.891916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0 = None
    token_1 = Token(None, 1, 2)
    validator_0 = Field(type=token_0)
    validator_1 = Field(type=token_0)
    validator_2 = token_0
    validator_3 = Field(type=token_0)
    validator_4 = Field(type=token_0)
    validator_5 = Field(type=token_0)
    validator_6 = Field(type=token_0)
    validator_7 = Field(type=token_0)
    validator_8 = Field(type=token_0)
    validator_9 = Field(type=token_0)

    # Assertion

# Generated at 2022-06-26 10:38:36.045685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=token_0, validator=token_0) == any_0
    assert validate_with_positions(token=token_1, validator=token_0) == any_1
    assert validate_with_positions(token=token_2, validator=token_2) == any_2
    assert validate_with_positions(token=token_3, validator=token_2) == any_3
    assert validate_with_positions(token=token_4, validator=token_1) == any_4
    assert validate_with_positions(token=token_5, validator=token_1) == any_5
    assert validate_with_positions(token=token_6, validator=token_4) == any_6

# Generated at 2022-06-26 10:39:42.231811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = None
    any_0 = validate_with_positions(token=token_0, validator=validator_0)

# Generated at 2022-06-26 10:39:43.055185
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:39:44.353826
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert None is None


# Generated at 2022-06-26 10:39:47.304847
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions() == "__main__.validate_with_positions"

# Generated at 2022-06-26 10:39:50.070098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    return any_0

# Generated at 2022-06-26 10:39:55.934284
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field_0 = Field(name="bar")
    token_0 = Token(
        name="foo",
        value=None,
        lookup=lambda *x: None,
        start=None,
        end=None,
    )
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    field_1 = Field(name="foo")
    token_1 = Token(
        name="foo",
        value=None,
        lookup=lambda *x: None,
        start=None,
        end=None,
    )
    any_1 = validate_with_positions(token=token_1, validator=field_1)
    assert any_1 is None



# Generated at 2022-06-26 10:40:04.803760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import typesystem
    from typing import Dict
    from typesystem.fields import Field, String
    from typesystem.tokenize import tokenize
    from typesystem.tokenize.tokens import Token

    schema = typesystem.Object(properties={"name": String()})
    tok_0: Token = tokenize({"name": "hello"}, schema=schema)
    name: str = validate_with_positions(token=tok_0.children.get("name"), validator=String)
    assert name == "hello"

    schema = typesystem.Object(properties={"name": String(min_length=3)})
    tok_1: Token = tokenize({"name": "hel"}, schema=schema)

# Generated at 2022-06-26 10:40:06.003010
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:40:13.719163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        type="Boolean",
        value=True,
        start=typesystem.positions.Position(index=0, line_index=1, char_index=0),
        end=typesystem.positions.Position(index=1, line_index=1, char_index=0),
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:40:26.272680
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = Field(name="token_0")
    assert validate_with_positions(token=token_0, validator=validator_0) is None

    token_1 = Token(
        "key",
        name="UnknownTokenType",
        value={"a": 1, "b": 2},
        start=token_0.start,
        end=token_0.end,
    )
    validator_1 = Schema(name="token_1", fields={"a": Field(), "b": Field()})
    assert validate_with_positions(token=token_1, validator=validator_1) == token_1.value

    token_2 = Token("key", name="SomeUnknownTokenType", value=None, start=0, end=0)
    validator_2