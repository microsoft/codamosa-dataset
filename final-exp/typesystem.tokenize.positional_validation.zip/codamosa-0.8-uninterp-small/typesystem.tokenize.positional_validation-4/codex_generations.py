

# Generated at 2022-06-26 10:30:59.526917
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:07.876343
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'z7\tyO1$vXVD5AT!$o '
    float_0 = -1349.9
    str_1 = "S'\xfb\xa0\xd6\xcc\x02(\x81\xa6\xf0\x1dd\x00\x00\x01\x19\x00\x00\x00\x16\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'\n."
   

# Generated at 2022-06-26 10:31:11.991151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:19.745689
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'z7\tyO1$vXVD5AT!$o '
    int_0 = -4897
    token_0 = module_0.Token(str_0, int_0, int_0)
    field_0 = module_1.Field(title=str_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    assert isinstance(any_0, int)
    assert isinstance(token_0, module_0.Token)
    assert isinstance(field_0, module_1.Field)

# Generated at 2022-06-26 10:31:27.334854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = '`zU6jHiU0wB&6l\x0c'
    int_0 = -30769
    token_0 = module_0.Token(str_0, int_0, int_0)
    str_1 = 'g_b^S|,1xRb*>\x0c'
    field_0 = module_1.Field(title=str_1)
    any_0 = validate_with_positions(token=token_0, validator=field_0)


# Generated at 2022-06-26 10:31:39.750300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A'
    str_1 = 'W5h8.Z'
    str_2 = 'J'
    str_3 = 'z7\tyO1$vXVD5AT!$o '
    int_0 = -4897
    token_0 = module_0.Token(str_3, int_0, int_0)
    field_0 = module_1.Field(title=str_0)
    any_0 = validate_with_positions(token=token_0, validator=field_0)
    str_4 = 'uBw'
    token_1 = module_0.Token(str_4, int_0, int_0)
    str_5 = 'Vw0Mp'
    field_1 = module_1.Field(title=str_5)
    any

# Generated at 2022-06-26 10:31:50.516908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'title'
    # Code with assert statements
    try:
        int_0 = -700
        str_1 = 'title'
        token_0 = module_0.Token(str_1, int_0, int_0)
        field_0 = module_1.Field(title=str_1)
        validate_with_positions(token=token_0, validator=field_0)
    except ValidationError as error_0:
        list_0 = error_0.messages
        message_0 = list_0[0]
        str_2 = message_0.code
        assert str_2 == 'required'


# Generated at 2022-06-26 10:31:52.047755
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("abc", start=0, end=3)
    any_0 = valida

# Generated at 2022-06-26 10:32:00.626241
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'a"\nprV7wDt*+-V^;u1'
    int_0 = -4080
    int_1 = -8901
    token_0 = module_0.Token(str_0, int_0, int_1)
    field_0 = module_1.Field(title=str_0)
    validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:32:07.163212
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:32:20.857704
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        import numpy as np
    except ImportError:
        skip('NumPy is not installed')

    # Basic test of `validate_with_positions`
    str_2 = 'ÝŒÝ‰\x7fÝ\x1a3\n'
    str_3 = "ÝŒÝ\x0f\x7fÝ\x1a3\n"
    str_4 = "Ý\x1a5\n"

    # Test for other complex cases

# Generated at 2022-06-26 10:32:29.075574
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value=str_0, start=Position(line=0, char_index=0), end=Position(line=0, char_index=3)
    )
    assert validate_with_positions(token=token_0, validator=str) == str_0

    token_0 = Token(
        value=str_1, start=Position(line=0, char_index=0), end=Position(line=0, char_index=3)
    )
    assert validate_with_positions(token=token_0, validator=str) == str_1


# Generated at 2022-06-26 10:32:43.542692
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value=str_0,
        start=(3, 2),
        end=(3, 17),
        lookup={
            "k1": Token(
                value=str_0,
                start=(2, 2),
                end=(2, 10),
                lookup={
                    "k2": Token(
                        value=str_0,
                        start=(1, 2),
                        end=(1, 10),
                        lookup={
                            "k3": Token(
                                value=str_0,
                                start=(0, 2),
                                end=(0, 10),
                                lookup={},
                            )
                        },
                    )
                },
            )
        },
    )

    validator = Field(type="string", max_length=5)

    # Test a value that is valid
    assert validate

# Generated at 2022-06-26 10:32:54.376849
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:33:02.438538
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import Integer, String, Float

    text = f"""{str_0}
    {float_0}
    {str_1}"""

    token = Token.parse(text)

    fields = [
        ("str_0", String()),
        ("float_0", Float()),
        ("str_1", String()),
    ]

    for name, field in fields:
        node = token.lookup([name])
        value = validate_with_positions(token=node, validator=field)
        assert value == eval(name)
    return

# Generated at 2022-06-26 10:33:11.882275
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        str_0,
        0,
        16,
        "foo",
        '"z7\tyO1$vXVD5AT!$o "\n',
        position=Position("<string>", 0, 16),
    )

# Generated at 2022-06-26 10:33:22.530617
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'z7\tyO1$vXVD5AT!$o '
    float_0 = -1349.9
    str_1 = "S'û\xa0ÖÌ\x02(\x81¦ð\x1dd\x00\x00\x01\x19\x00\x00\x00\x16\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'\n."
    # @TODO: Not implemented
   

# Generated at 2022-06-26 10:33:30.145414
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert validate_with_positions(token=Token(type="float", value=float_0), validator=Field(type="float")) == float_0, "Expected to return the result of calling validate_with_positions() but the returned result does not equal expected result"

    assert validate_with_positions(token=Token(type="str", value=str_1), validator=Field(type="str")) == str_1, "Expected to return the result of calling validate_with_positions() but the returned result does not equal expected result"

    assert validate_with_positions(token=Token(type="str", value=str_0), validator=Field(type="str", max_length=40)) == str_0, "Expected to return the result of calling validate_with_positions() but the returned result does not equal expected result"

# Generated at 2022-06-26 10:33:42.910728
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json

    from typesystem.fields import Json
    from typesystem.schemas import Schema

    class A(Schema):
        b = Json()
    c = A(b='{"e": "f"}')
    assert c.b == {"e": "f"}
    c = A(b='{"e": "f"}', partial=True)
    assert c.b == {"e": "f"}

    class A(Schema):
        b = Json(validate=lambda x: "string" in x)
    with pytest.raises(ValidationError) as exc_info:
        c = A(b='{"e": "f"}')

# Generated at 2022-06-26 10:33:54.743511
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(
            token=ASN_0_Token, validator=IntegerField(max_value=0, min_value=0)
        )
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = message.index[:-1]
                text = f"The field {field!r} is required."
            else:
                token = message.index
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )
            messages.append(positional_message)


# Generated at 2022-06-26 10:34:10.454526
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 0
    int_1 = 1
    int_2 = 2
    int_3 = 3
    str_0 = "foo"
    str_1 = "bar"
    str_2 = "baz"
    str_3 = "qux"
    list_0 = []
    list_1 = [0]
    list_2 = [0, 1]
    list_3 = [0, 1, 2]
    token_0 = Token({"foo": "bar"})
    token_1 = Token("foo")
    token_2 = Token("bar")
    token_3 = Token("baz")
    token_4 = Token("qux")
    token_5 = Token("quux")
    token_6 = Token("corge")
    token_7 = Token("grault")
    token_

# Generated at 2022-06-26 10:34:23.114073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Testing validate_with_positions")

    # Begin tests
    # TODO: Implement tests
    # End tests


# Run tests
if __name__ == "__main__":
    import sys
    import traceback

    try:
        test_validate_with_positions()
    except Exception:
        exc_info = sys.exc_info()
        traceback.print_tb(exc_info[2])
        print(exc_info[1])

# Generated at 2022-06-26 10:34:25.318302
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:34:28.518516
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 0
    var_0 = []
    var_0.append(test_class_0())
    int_0 = 0
    return var_0[int_0].t_1


# Generated at 2022-06-26 10:34:29.445746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == (True)
# test_case_0

# Generated at 2022-06-26 10:34:40.657417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_cases = [
        {
            "name": "int 0",
            "input": {
                "token": Token(0, 0, value=0, end=2, children=[Token(0, 0, "var 1")]),
                "validator": Field(int),
            },
            "expected_output": 0,
        },
        {
            "name": "var 0",
            "input": {
                "token": Token(0, 0, value=["var"], end=3, children=[Token(0, 0, "var 0")]),
                "validator": Field([int]),
            },
            "expected_output": ["var"],
        },
    ]
    for test_case in test_cases:
        actual_output = validate_with_positions(**test_case["input"])

# Generated at 2022-06-26 10:34:46.866850
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This is a test to ensure that the logging level is set correctly
    var_0 = [0, 1, 2]
    var_0.append(2)
    var_0.remove(1)
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1
    var_0[0] += 1

    assert len(var_0) == 3
    assert var_0[0] == 9
    assert var_0[1] == 0
    assert var_0[2] == 2

# Generated at 2022-06-26 10:34:48.605443
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 0
    var_0 = []



# Generated at 2022-06-26 10:34:49.940973
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 0
    pass



# Generated at 2022-06-26 10:34:53.184549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: Assert the correctness of validate_with_positions using pytest.
    assert 0 == validate_with_positions()

# Generated at 2022-06-26 10:35:06.414521
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text_0 = None
    index_0 = None
    start_0 = None
    end_0 = None
    code_0 = None
    message_0 = Message(text=text_0, code=code_0, index=index_0,
                        start_position=start_0, end_position=end_0)
    messages_0 = [message_0]
    token_0 = None
    validator_0 = None
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None

# Generated at 2022-06-26 10:35:19.591364
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import typesystem_jwt

    def validate_with_positions(*token_1, validator_1):
        token_1 = token_1[0]
        try:
            return validator_1.validate(token_1.value)
        except ValidationError as error_1:
            messages_1 = []
            for message_1 in error_1.messages():
                if message_1.code == "required":
                    field_1 = message_1.index[-1]
                    token_1 = token_1.lookup(message_1.index[:-1])
                    text_1 = 'The field %r is required.' % (field_1,)
                else:
                    token_1 = token_1.lookup(message_1.index)
                    text_1 = message_1.text

# Generated at 2022-06-26 10:35:21.379727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import os
    import doctest
    doctest.testmod()



# Generated at 2022-06-26 10:35:24.370271
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value="foo")
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == "foo"

# Generated at 2022-06-26 10:35:27.174204
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = None
    validator = None

    # Exercise
    result = validate_with_positions(token=token, validator=validator)

    # Verify
    assert result is None
    assert token is None
    assert validator is None

# Generated at 2022-06-26 10:35:36.605985
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    class TestSchema(typesystem.Schema):

        name = typesystem.String(max_length=10)
        age = typesystem.Integer(minimum=0, maximum=100)

    data = {"name": "Joe", "age": 18}
    token = Token(value=data)
    try:
        TestSchema.validate(data)
    except ValidationError as error:
        messages = error.messages()
    else:
        messages = []
    try:
        validate_with_positions(token=token, validator=TestSchema)
    except ValidationError as error:
        positional_messages = error.messages()
    else:
        positional_messages = []

    assert len(positional_messages) == len(messages)

# Generated at 2022-06-26 10:35:46.190513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token()


    class SomeSchema(Schema):
        field = Field(type=str)


    class SomeSchema2(Schema):
        field = Field(type=str)


    def callback(validator):
        return validator


    value_0 = validate_with_positions(token=token, validator=SomeSchema)
    value_1 = validate_with_positions(token=token, validator=SomeSchema2)
    pass


if __name__ == "__main__":
    import sys

    sys.exit(pytest.main(["-s", "-v", __file__]))

# Generated at 2022-06-26 10:35:53.546125
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import typesystem
    from typesystem import Tokenizer

    class PetSchema(typesystem.Schema):
        type = typesystem.String(enum=["dog", "cat", "bird"])
        name = typesystem.String()
        age = typesystem.Integer(minimum=0)
        weight = typesystem.Number(multiple_of=0.1)
        vaccinated = typesystem.Boolean()
        birth_date = typesystem.Date()
        owner = typesystem.String()

    tokenizer = Tokenizer()
    input_stream = io.StringIO('{"type": "cat", "name": "Kitty", "age": 3')
    token_stream = tokenizer.tokenize(input_stream)
    pet_schema = PetSchema()

# Generated at 2022-06-26 10:36:03.782282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field_0: Field = Pass
    schema_0: Schema = type("Schema", (), {"fields": {}})
    
    assert field_0.validate("0") == "0"
    assert schema_0.validate("0") == "0"

    field_1: Field = Int
    token_0 = Token("0", 0, 0, 0, 0)
    
    assert field_1.validate("0") == 0
    assert validate_with_positions(token=token_0, validator=field_1) == 0

    schema_1: Schema = type("Schema", (), {"fields": {"0": Int}})

    assert schema_1.validate("0") == 0
    assert validate_with_positions(token=token_0, validator=schema_1) == 0

    # 

# Generated at 2022-06-26 10:36:08.869714
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test case 0
    token_0 = None
    # assert NoResultFound
    # assert ValidationError
    with pytest.raises(ValidationError):
        any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:36:23.006170
# Unit test for function validate_with_positions
def test_validate_with_positions():
	token_0 = Token(None, 0, 0, None)
	validator_0 = Field(type=None)
	any_0 = validate_with_positions(token=token_0, validator=validator_0)
	token_1 = Token(None, 0, 0, None)
	validator_1 = Field(type=None)
	try:
		any_1 = validate_with_positions(token=token_1, validator=validator_1)
	except ValidationError as error_1:
		messages_1 = []
		for message_1 in error_1.messages():
			if message_1.code == "required":
				field_1 = message_1.index[-1]

# Generated at 2022-06-26 10:36:24.324664
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test cases from Pex
    token_0 = None
  

# Generated at 2022-06-26 10:36:31.975500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(source=None, start=None, end=None, value=None)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    assert isinstance(any_0, Token) is True

# Generated at 2022-06-26 10:36:35.307933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=None, start=None, end=None, lookup=None)
    field_0 = Field(required=None)
    any_0 = validate_with_positions(token=token_0, validator=field_0)

    assert any_0 == None
    

# Generated at 2022-06-26 10:36:48.230462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from unittest.mock import patch, Mock
    from typesystem.schemas import Schema, Type, Field
    from typesystem.tokenize.tokens import Token

    class TestSchema(Schema):
        name = Field(type=Type(type=int))


# Generated at 2022-06-26 10:36:53.602746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import PyInquirer  # type: ignore
    from typesystem.fields import String, Integer  # type: ignore

    from typesystem_inquirer.utils import QType

    class CustomField(Field):
        def to_primitive(self, value, *, context):
            return "primitive"

        def to_python(self, value):
            return "python"

    class TestSchema(Schema):
        text = String()
        position = Integer()

    validator = TestSchema()


# Generated at 2022-06-26 10:36:58.386339
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions()
    except TypeError as e:
        assert "Missing 1 required positional argument" in str(e)



# Generated at 2022-06-26 10:37:03.750238
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    assert any_0 is None

# Generated at 2022-06-26 10:37:07.152394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0 = None
    validator_0 = None

    # AssertionError: RootToken(...)
    try:
        validate_with_positions(token=token_0, validator=validator_0)
    except AssertionError:
        pass


# non-exhaustive

# Generated at 2022-06-26 10:37:09.799084
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("foo")
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:37:23.530825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = None

    # Run
    result = validate_with_positions(token=token, validator=token)

    # Assert
    assert result == None


# Generated at 2022-06-26 10:37:33.492964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from json import loads
    from typesystem.schemas import Schema

    schema = Schema.parse_string(
        """
    object:
        a: int
        b: int
    """
    )

    json_string = '{"a": 1, "b": 2}'
    tokens = schema.tokenize(loads(json_string))
    schema.validate(tokens)



# Generated at 2022-06-26 10:37:42.527952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    s = '{"foo": "bar"}'
    cls = Schema.from_dict(
        {
            "foo": {"type": "string", "required": True},
            "bar": {"type": "integer", "required": True},
        }
    )

    token = Token(s)
    try:
        validate_with_positions(token=token, validator=cls)
    except ValidationError as e:
        assert (
            e.messages()[0].text
            == 'The field "bar" is required, but the value is missing.'
        )
        assert e.messages()[0].start_position.line_index == 0
        assert e.messages()[0].start_position.char_index == 1

# Generated at 2022-06-26 10:37:50.662841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    tests = [
        {
            "name": "Test #1",
            "exception": ValidationError,
            "params": (
                {"token": None, "validator": None},
            ),
        }
    ]
    for test in tests:
        if test["exception"]:
            with raises(test["exception"]):
                validate_with_positions(**test["params"])
        else:
            assert validate_with_positions(**test["params"])

# Generated at 2022-06-26 10:37:54.049384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:37:58.330927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    state = {
        "any_0": None,
        "token_0": 0,
        "token_1": None,
        "token_2": None,
        "token_3": None,
        "token_4": None,
        "token_5": None,
        "token_6": None,
        "token_7": None,
    }
    token_0 = 0
    token_1 = None
    validator_0 = None
    token_2 = None
    token_3 = None
    token_4 = None
    token_5 = None
    token_6 = None
    token_7 = None

# Generated at 2022-06-26 10:38:04.444333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test type conditions
    assert callable(validate_with_positions)

    # Test argument types
    try:
        validate_with_positions(token="", validator="")
    except TypeError as e:
        assert "token has to be Token" in str(e)
    try:
        validate_with_positions(token=Token(""), validator="")
    except TypeError as e:
        assert "validator has to be a Field or Schema" in str(e)

# Generated at 2022-06-26 10:38:10.746012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value="string",
        start=(4, 0),
        end=(4, 6),
        children=[
            Token(
                value="string",
                start=(4, 0),
                end=(4, 6),
                children=[],
                parent=None,
            ),
            Token(
                value="string",
                start=(4, 11),
                end=(4, 17),
                children=[],
                parent=None,
            ),
        ],
    )
    any_0 = validate_with_positions(
        token=token_0, validator=Field(name="str", description="str", type="str")
    )


# Generated at 2022-06-26 10:38:12.658420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:38:15.775076
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

if __name__ == "__main__":
    import sys

    run_mask = {"n": True}
    if True:
        test_case_0()

pass

# Generated at 2022-06-26 10:38:39.426650
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()
# ============================
# END OF CODE GENERATED FILE
# ============================

# Generated at 2022-06-26 10:38:44.843263
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import (
        ArrayToken,
        BooleanToken,
        IntegerToken,
        KeyToken,
        ObjectToken,
        StringToken,
    )

    from typesystem.tokenize.tokens import Token

    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import Token

# Generated at 2022-06-26 10:38:46.944599
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert None is validate_with_positions(token='', validator='')

# Generated at 2022-06-26 10:38:51.172624
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token("foo")
    validator = Field()
    validate_with_positions(token=token, validator=validator)

# Test for error on validate_with_positions

# Generated at 2022-06-26 10:38:58.497027
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0 = None
    validator = None

    try:
        # Exercise
        validate_with_positions(token=token_0, validator=validator)
        assert False, "Expected an exception"
    except Exception as e:
        # Verify
        assert type(e) is TypeError

# Generated at 2022-06-26 10:39:01.412596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)


test_case_0()

# Generated at 2022-06-26 10:39:05.668256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:39:11.909488
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Init validator.
    token_0 = Token(
        key="key_0", value="value_0", start_position=Position(0, 0), end_position=Position(0, 0)
    )
    field_0 = Field(required=True)
    # Call function.
    any_0 = validate_with_positions(token=token_0, validator=field_0)

# Generated at 2022-06-26 10:39:16.382592
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:39:18.035566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:39:45.985975
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(0, {'a': Token(1, {'b': Token(2, {'c': Token(3, 'value')})})})
    token_1 = Token(0, {'a': Token(1, {'b': Token(2, {'d': Token(3, 'value')})})})
    token_2 = Token(0, {'a': Token(1, {'b': Token(2, {'e': Token(3, 'value')})})})
    token_3 = Token(0, {'a': Token(1, {'b': Token(2, {'f': Token(3, 'value')})})})
    token_4 = Token(0, {'a': Token(1, {'b': Token(2, {'g': Token(3, 'value')})})})

# Generated at 2022-06-26 10:39:50.976729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Branch #0 : (token is None or validator is None)
    assert False # <---- Remove this line and complete branch #0
    
    # Branch #1 : (not (token is None) and not (validator is None))
    assert False # <---- Remove this line and complete branch #1

# Generated at 2022-06-26 10:39:54.449430
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True


# Generated at 2022-06-26 10:40:02.763811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Dummy values for non-required args
    # Dummy values for required args
    token = None
    validator = None

    # Call function
    try:
        validate_with_positions(token=token, validator=validator)
    except ValidationError as e:
        # Get arguments from the exception, and check their types
        arg_messages = e.messages()
        for arg in arg_messages:
            assert isinstance(arg, Message)

# Generated at 2022-06-26 10:40:05.221963
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions is not None


# Generated at 2022-06-26 10:40:08.257824
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions()
    except TypeError:
        pass



# Generated at 2022-06-26 10:40:10.776293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError as e:
        assert e.messages()

# Generated at 2022-06-26 10:40:25.946297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(token=token_0, validator=token_0)
    except ValidationError:
        pass


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pyre_log = os.environ.get("PYRE_LOG")
    if pyre_log:
        pyre_log = os.path.join(pyre_log, basename)
    else:
        pyre_log = f"/tmp/{basename}.log"

    pyre_initialize = ["pyre", "--log-file=" + pyre_log]

    # Run Pyre checks

# Generated at 2022-06-26 10:40:37.580502
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        schema=[
            {
                "name": "string",
                "validators": [{"type": "string", "min_length": 1}],
            }
        ],
        value="foo",
        start=None,
        end=None,
        parent=None,
    )

    assert validate_with_positions(token=token, validator=Field(type="string")) == "foo"

    token = Token(
        schema=[
            {
                "name": "string",
                "validators": [{"type": "string", "min_length": 1}],
            }
        ],
        value=None,
        start=None,
        end=None,
        parent=None,
    )

    with pytest.raises(ValidationError) as error:
        validate_with_pos

# Generated at 2022-06-26 10:40:41.465296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Field(title="name", type="string")
    any_0 = validate_with_positions(token=token_0, validator=token_0)
