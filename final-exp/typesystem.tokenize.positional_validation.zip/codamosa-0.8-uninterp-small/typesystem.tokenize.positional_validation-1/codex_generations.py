

# Generated at 2022-06-26 10:31:07.695656
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    message_0 = None
    message_1 = None
    message_2 = None
    message_3 = None
    token_1 = None
    message_4 = None
    message_5 = None
    message_6 = None
    message_7 = None
    message_8 = None
    message_9 = None
    token_2 = None
    message_10 = None
    message_11 = None
    message_12 = None
    token_3 = None
    message_13 = None
    message_14 = None
    message_15 = None
    message_16 = None
    message_17 = None
    message_18 = None
    message_19 = None
    message_20 = None
    message_21 = None
    message_22 = None
    message_23 = None
    message_

# Generated at 2022-06-26 10:31:12.471011
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here

# vim: et:ts=4:sw=4:syntax=python

# Generated at 2022-06-26 10:31:15.182175
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    list_0 = [token_0, token_0]
    any_0 = validate_with_positions(token=token_0, validator=list_0)

# Generated at 2022-06-26 10:31:16.430376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass


# Generated at 2022-06-26 10:31:17.939284
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test without an exception

    # Test with an exception

    pass


# Generated at 2022-06-26 10:31:28.844226
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Mock class Token
    class TokenMock(object):
        def lookup(self):
            return None

        def start(self):
            return None

        def end(self):
            return None

    class validator_Mock(object):
        def __init__(self):
            self.validate = None

    class field_Mock(object):
        def __init__(self):
            self.validate = None

    class schema_Mock(object):
        def __init__(self):
            self.validate = None

    class type_Mock(object):
        def __init__(self):
            self.Schema = schema_Mock()

    class __main__Mock(object):
        def Field(self):
            return field_Mock()

        def Schema(self):
            return schema_

# Generated at 2022-06-26 10:31:40.933303
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        __tracebackhide__ = True
        list_0 = None
        token_0 = None
        any_0 = validate_with_positions(token=token_0, validator=list_0)
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = message.index[-2]
                text = f"The field {field!r} is required."
            else:
                token = message.index[-1]
                text = message.text

            positional_message = Message(
                text=text,
                code=message.code,
                index=message.index,
                start_position=token.start,
                end_position=token.end,
            )

# Generated at 2022-06-26 10:31:51.922450
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import Integer

    # Test error messages with positions.

    schema = Schema({"id": Integer(), "name": Integer()})

    token = Token.parse_object({"id": True, "name": "Sander"})

    try:
        schema.validate(token.value)
    except ValidationError as error:
        assert len(error.messages()) == 2

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert len(error.messages()) == 2
        messages = sorted(
            error.messages(), key=lambda m: m.start_position.line_number
        )
        assert messages[0].text == "The field 'id' is not of type 'integer'."

# Generated at 2022-06-26 10:31:55.837486
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    list_0 = [token_0, token_0]
    any_0 = validate_with_positions(token=token_0, validator=list_0)



# Generated at 2022-06-26 10:31:59.676396
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value={
            "name": "Foo",
            "age": "Not integer",
            "email": "foo@example.com",
            "hobbies": ["golf", "skiing"],
        }
    )
    schema_0 = Schema(
        {
            "name": Field(str),
            "age": Field(int),
            "email": Field(str),
            "hobbies": Field(list, elements=Field(str)),
        }
    )
    any_0 = validate_with_positions(token=token_0, validator=schema_0)

# Generated at 2022-06-26 10:32:15.425521
# Unit test for function validate_with_positions
def test_validate_with_positions():
    input_token_0 = str(bool)
    input_validator_0 = str(bool)
    if validate_with_positions(token=input_token_0, validator=input_validator_0):
        print("Passed")
    else:
        print("Failed")
    input_token_1 = str(bool)
    input_validator_1 = bool
    if validate_with_positions(token=input_token_1, validator=input_validator_1):
        print("Passed")
    else:
        print("Failed")
    input_token_2 = str(bool)
    input_validator_2 = bool
    if validate_with_positions(token=input_token_2, validator=input_validator_2):
        print("Passed")

# Generated at 2022-06-26 10:32:23.039356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    assert any_0 == True

# Generated at 2022-06-26 10:32:29.944251
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import tokenize
    from typesystem.tests.schemas import Person as PersonSchema

    schema = PersonSchema()

    # Test case #0
    body = """
        {}
    """
    tokens, context = tokenize(body, schema=schema, attach_context=True)
    validate_with_positions(token=tokens[0], validator=schema)
    assert len(context.errors) == 1
    assert context.errors[0]["text"] == "The field 'name' is required."
    assert context.errors[0]["line"] == 1

# Generated at 2022-06-26 10:32:40.413085
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Object must be of type int, but is of type str.
    str_0 = "a string"
    int_0 = validate_with_positions(token=str_0, validator=int_0)
    # Object must be of type int, but is of type str.
    str_1 = "another string"
    int_1 = validate_with_positions(token=str_1, validator=int_1)


# Generated at 2022-06-26 10:32:42.361333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)

# Generated at 2022-06-26 10:32:47.937821
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # SUT
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)

    # Test type of `any_0`
    assert isinstance(any_0, bool)

    # Test shape of `any_0`
    assert any_0 == {}

# Generated at 2022-06-26 10:32:56.202021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test with one validator
    class MyValidator(Schema):
        field_0 = bool

    assert validate_with_positions(
        token=Token({"field_0": 1}), validator=MyValidator
    ) == {"field_0": 1}

    # Test with multiple validators
    class MyValidator(Schema):
        field_1 = bool
        field_2 = bool

    assert validate_with_positions(
        token=Token({"field_1": 0, "field_2": 0}), validator=MyValidator
    ) == {"field_1": 0, "field_2": 0}

    # Test with nested validators
    class MyValidator(Schema):
        class MySubValidator(Schema):
            field_0 = bool

        field_1 = MySubValidator



# Generated at 2022-06-26 10:32:58.504194
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 10:33:00.941167
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)




# Generated at 2022-06-26 10:33:04.047545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import unittest
    import sys
    try:
        #
        # Here is the unit test code
        #
        assert True
    except:
        print("An unhandled exception was raised during testing")
        raise

# Generated at 2022-06-26 10:33:22.146937
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test case 0
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    assert True == any_0

    # Test case 1
    bool_1 = True
    any_1 = validate_with_positions(token=bool_1, validator=bool_1)
    assert True == any_1

    # Test case 2
    bool_2 = True
    any_2 = validate_with_positions(token=bool_2, validator=bool_2)
    assert True == any_2

    # Test case 3
    bool_3 = True
    any_3 = validate_with_positions(token=bool_3, validator=bool_3)
    assert True == any_3

    # Test case 4

# Generated at 2022-06-26 10:33:29.844898
# Unit test for function validate_with_positions
def test_validate_with_positions():
    boolean = Field(type="boolean")

    assert validate_with_positions(token=Token(True), validator=boolean) is True
    assert validate_with_positions(token=Token(False), validator=boolean) is False

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=Token(123), validator=boolean)

    assert exc_info.type == ValidationError
    assert exc_info.value.messages()[0].code == "type"
    assert (
        exc_info.value.messages()[0].text
        == "Expected type 'boolean' but got type 'number'."
    )

    token = Token(123)
    token.start.line_number = 1
    token.start.column_number = 1


# Generated at 2022-06-26 10:33:33.493158
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = dict

    token = dict({"a": 1})

    assert validate_with_positions(token=token, validator=validator) == {
        "a": 1
    }

# Generated at 2022-06-26 10:33:35.446225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test for function validate_with_positions"""
    assert validate_with_positions() is None

# Generated at 2022-06-26 10:33:40.086905
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=tokens.text_0,
        validator=types.text_0,
    ) == texts.text_0

# Generated at 2022-06-26 10:33:43.419638
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=False, validator=False)




# Generated at 2022-06-26 10:33:55.099030
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = int(0)
    int_0 = validate_with_positions(token=int_0, validator=int_0)
    assert int_0 is None
    str_0 = str()
    str_0 = validate_with_positions(token=str_0, validator=str_0)
    assert str_0 is None
    str_1 = str()
    str_1 = validate_with_positions(token=str_1, validator=str_1)
    assert str_1 is None
    str_2 = str()
    str_2 = validate_with_positions(token=str_2, validator=str_2)
    assert str_2 is None
    bool_0 = bool()

# Generated at 2022-06-26 10:33:59.517529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # AssertionError: Expected type 'List[str]' got 'str' instead.
    any_0 = validate_with_positions(token=0, validator=0)



# Generated at 2022-06-26 10:34:10.442564
# Unit test for function validate_with_positions
def test_validate_with_positions():
    dict_0 = dict({'test': True})
    str_0 = 'test'
    token_0 = Token(str_0, dict_0, 0, 19)
    dict_1 = dict({'test': False})
    str_1 = 'test'
    token_1 = Token(str_1, dict_1, 0, 18)
    dict_2 = dict({'test': True})
    str_2 = 'test'
    token_2 = Token(str_2, dict_2, 0, 18)

    # test cases
    assert validate_with_positions(token=token_0, validator=token_0) == True
    assert validate_with_positions(token=token_0, validator=token_1) == False

# Generated at 2022-06-26 10:34:25.888129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    msg = Message(
        text="Field at index 0 is required.",
        code="required",
        index=(0,),
        start_position=Position(
            line_number=1, line_start_index=1, line_end_index=1, char_index=1
        ),
        end_position=Position(
            line_number=1, line_start_index=1, line_end_index=1, char_index=1
        ),
    )
    with pytest.raises(ValidationError) as err:
        validate_with_positions(token=Token(value=None), validator=int)
    assert err.value.messages() == [msg]

# Generated at 2022-06-26 10:34:35.265167
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    assert any_0 is True

# Generated at 2022-06-26 10:34:37.489040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # str -> None.
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:34:40.656305
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = "boolean_0"
    validator = "boolean_0"
    expected_output = "int"
    actual_output = validate_with_positions(token=token, validator=validator)
    assert actual_output == expected_output

# Generated at 2022-06-26 10:34:47.449988
# Unit test for function validate_with_positions
def test_validate_with_positions():

    bool_0 = True
    int_0 = 9
    schema = {
        "title": "Simple schema",
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "age": {"type": "integer"},
            "born": {"type": "boolean"},
        },
    }

    message = "The field 'born' is required.",
    try:
        validate_with_positions(token=schema, validator=bool_0)
    except ValidationError as exception:
        assert exception.messages[0].text == message[0]
        assert exception.messages[0].code == "required"
        assert exception.messages[0].index == ("born",)
        assert exception.messages[0].start_position.line_index == 8

# Generated at 2022-06-26 10:34:51.113762
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    # Success
    assert (any_0 == True)


# Generated at 2022-06-26 10:35:00.001365
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value="hi",
        start=Message(text="hi", code="required", index=[0], start_position=2, end_position=2),
        end=Message(text="hi", code="required", index=[0], start_position=2, end_position=2),
    )
    validator = bool
    try:
        validate_with_positions(token=token, validator=validator)

    except ValidationError as error:
        assert len(error.messages()) == 1
        assert error.messages()[0].text == "Must be True or False."

        assert error.messages()[0].start_position == token.start

        assert error.messages()[0].end_position == token.end

# Generated at 2022-06-26 10:35:07.856721
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    bool_1 = False
    validator_0 = bool_1
    token_0 = bool_0
    with pytest.raises(ValidationError) as e:
        validate_with_positions(token=token_0, validator=validator_0)
    messages = e.value.messages
    assert messages == [
        Message(
            text="The field bool() is required.",
            code="required",
            index=(),
            start_position=Position(char_index=0, line_number=1, column_number=1),
            end_position=Position(char_index=4, line_number=1, column_number=5),
        )
    ]

# Generated at 2022-06-26 10:35:20.878831
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text = """{
"string_0": "string",
"bool_0": true,
"object_0": {"array_0": [0, 1]},
"array_0": [0, 1]
}"""
    root = Token(text=text)
    object_0 = root.lookup(index=["object_0"])
    string_0 = root.lookup(index=["string_0"])
    bool_0 = root.lookup(index=["bool_0"])
    array_0 = root.lookup(index=["array_0"])
    array_0_0 = root.lookup(index=["array_0", 0])
    array_0_1 = root.lookup(index=["array_0", 1])

# Generated at 2022-06-26 10:35:25.530113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Set up test values
    # Set up test values
    True
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    # print(any_0)
    assert any_0 == True # "validate_with_positions(token=True, validator=True) did not return True"

# Generated at 2022-06-26 10:35:26.556162
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert "True" == validate_with_positions(token=True, validator=bool(True))



# Generated at 2022-06-26 10:35:40.889143
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False



# Generated at 2022-06-26 10:35:45.404740
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import namedtuple

    from hypothesis import given

    from . import strategies

    token = namedtuple("token", ("value",))
    field = namedtuple("field", ())
    field.validate = lambda self, value: None

    @given(strategies.tokens, strategies.validators)
    def test(token: token, validator: typing.Union[field, Token]):
        result = validate_with_positions(token=token, validator=validator)

        assert result is None



# Generated at 2022-06-26 10:35:47.059596
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)



# Generated at 2022-06-26 10:35:49.949567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 10:36:01.813848
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 4
    str_0 = "test_case_2"
    str_1 = "test_case_0"
    list_0 = [str_0, int_0, str_1]
    dict_0 = {
        str_1: str_0,
        str_0: list_0
    }
    dict_1 = {
        str_0: dict_0,
        str_1: dict_0
    }
    dict_2 = {
        str_1: dict_1,
        str_0: dict_0
    }
    dict_3 = {
        str_0: dict_2,
        str_1: dict_2
    }
    dict_4 = {
        str_1: dict_3,
        str_0: dict_2
    }
    dict

# Generated at 2022-06-26 10:36:13.601347
# Unit test for function validate_with_positions
def test_validate_with_positions():
    args = [
        ([Token(value=1, start=1, end=1)], [1], ('validate_with_positions',)),
        ([Token(value='s', start=1, end=1)], ['s'], ('validate_with_positions',)),
        ([Token(value=2.33, start=1, end=1)], [2.33], ('validate_with_positions',)),
        ([Token(start=1, end=1, value={})], [{}], ('validate_with_positions',)),
        ([Token(start=1, end=1, value=[])], [[]], ('validate_with_positions',)),
    ]
    for i, args_ in enumerate(args):
        with pytest.raises(KeyError) as excinfo:
            assert validate

# Generated at 2022-06-26 10:36:17.884842
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Initialize test variables
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)

    # Assertions
    assert any_0 is True



# Generated at 2022-06-26 10:36:20.024854
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)

# Generated at 2022-06-26 10:36:34.232111
# Unit test for function validate_with_positions
def test_validate_with_positions(): # type: () -> None
    from typesystem.fields import Boolean
    from typesystem.types import Boolean as TBoolean

    token = Token(value="any")
    token.start = 1
    token.end = 1

    assert validate_with_positions(token=token, validator=Boolean()) is True
    token.value = "some_invalid_string"
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Boolean())
    assert exc_info.value.messages[0].start_position == token.start

    token.value = 3.2
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=Boolean())
    assert exc_info.value

# Generated at 2022-06-26 10:36:47.604772
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    list_0 = [True, True, True]
    any_1 = validate_with_positions(token=list_0, validator=list_0)
    list_1 = [True, True, True]
    any_2 = validate_with_positions(token=list_1, validator=list_1)
    list_2 = [True, True, True]
    any_3 = validate_with_positions(token=list_2, validator=list_2)
    list_3 = [True, True, True]
    any_4 = validate_with_positions(token=list_3, validator=list_3)

# Generated at 2022-06-26 10:37:21.180839
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)



# Generated at 2022-06-26 10:37:29.206779
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Foo(object):
        """class Foo"""

        def __init__(self):
            """constructor"""
            self.bar = Bar()

    class Bar(object):
        """class Bar"""

        def __init__(self):
            """constructor"""
            pass

    class FooSchema(Schema):
        """FooSchema"""

        bar = Field(type=Bar)

    foo_schema = FooSchema()

    foo_schema.validate(foo_schema)  # works
    foo_schema.validate(foo_schema.__class__)  # fails

    tokenize = foo_schema.tokenize()
    validate = foo_schema.validate()
    validate_with_positions(token=tokenize, validator=validate)  # works
    validate_with_

# Generated at 2022-06-26 10:37:34.672705
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    assert any_0.start_position.char_index == 1
    assert any_0.end_position.char_index == 5



# Generated at 2022-06-26 10:37:43.123726
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import tokenize

    # Read the source code of this function
    function_source = io.StringIO(inspect.getsource(validate_with_positions))

    # Tokenize the source code
    token_stream = tokenize.generate_tokens(function_source.readline)

    # Extract all the tokens that do not represent whitespace
    tokens = [token for token in token_stream if token.type != tokenize.NL]

    # Validate each token with the correct validator
    for token in tokens:
        validator = None

        if token.string == "*":
            validator = "*"
        elif token.string == ",":
            validator = ","
        elif token.string == ":":
            validator = ":"

# Generated at 2022-06-26 10:37:47.757548
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)


test_case_0()

# Generated at 2022-06-26 10:37:58.876286
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class schema_0(Schema):
        field_0 = Field(type=bool, required=False)
        field_1 = Field(type=bool, required=False)
        field_2 = Field(type=bool, required=False)
        field_3 = Field(type=bool, required=False)

    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)

    schema_1 = schema_0({"field_0": 1, "field_1": 2, "field_2": 3, "field_3": 4})
    bool_1 = True
    any_1 = validate_with_positions(token=bool_1, validator=bool_1)
    bool_2 = True

# Generated at 2022-06-26 10:38:06.168894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool0 = True
    any0 = validate_with_positions(token=bool0, validator=bool0)
    schema = Schema(fields={"field_0": bool0})
    any1 = validate_with_positions(token=schema, validator=schema)

    # Verify that errors are annotated with position information
    with pytest.raises(ValidationError):
        schema.validate(data={"field_0": "string"})

    # Verify that the type system is able to accept the validated result.
    any3 = Field(type_=bool0)

# Generated at 2022-06-26 10:38:09.161061
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)


if __name__ == '__main__':

    test_validate_with_positions()

# Generated at 2022-06-26 10:38:11.175332
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = False
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)


# Generated at 2022-06-26 10:38:17.259909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    bool_0 = True

# Generated at 2022-06-26 10:39:35.102397
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import jsonschema
    import json
    import typesys
    # Test case 0
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    # Test case 1
    json_1 = json.loads("""[true, 13, "foo", {"hello": "world"}, ["a", "b", "c"]]""")
    any_1 = validate_with_positions(token=json_1, validator=json_1)
    # Test case 2
    bool_2 = True
    any_2 = validate_with_positions(token=bool_2, validator=bool_2)
    # Test case 3
    bool_3 = True

# Generated at 2022-06-26 10:39:45.584026
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # testing for coerce_failure: True
    # testing for locale: None
    # testing for extra: {}
    class TestSchema(Schema):
        a: str
        b: int
        c: int
        d: str

    # Check that validating a JSON blob works.
    data = {"a": "123", "b": "456", "c": "456", "d": "456"}
    schema = TestSchema()
    result = schema.validate(data)
    assert result == {"a": "123", "b": 456, "c": 456, "d": "456"}

    # Check that exceptions work.
    data = {"a": 123, "b": "456", "c": "456", "d": "456"}
    schema = TestSchema()

# Generated at 2022-06-26 10:39:53.123566
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        bool_0 = True
        any_0 = validate_with_positions(token=bool_0, validator=bool_0)
        bool_1 = True
        any_1 = validate_with_positions(token=bool_1, validator=bool_1)
    except ValueError:
        bool_2 = False
    except ValidationError:
        bool_3 = False
    else:
        bool_4 = False


if (__name__ == "__main__"):
    test_case_0()

test_validate_with_positions()

# Generated at 2022-06-26 10:39:58.193255
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    assert any_0

# Generated at 2022-06-26 10:40:04.866296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class CustomSchema(Schema):
        message = "test schema"
        score = int
        name = str
        position = int
    class CustomField(Field):
        message = "test field"
        default_value = "test"

    data = {"score": 2, "name": "test", "position": 1}
    schema = CustomSchema(data)
    schema.validate(data)
    field = CustomField(default_value=1)
    field.validate(field.default_value)


# Generated at 2022-06-26 10:40:09.751033
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test for function validate_with_positions
    object_0 = object()
    str_0 = str()
    any_0 = validate_with_positions(token=object_0, validator=str_0)

# Generated at 2022-06-26 10:40:17.188293
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    str_0 = "str_0"
    str_1 = "str_1"
    newstr_0 = str_0.replace("str_0", "str_1")
    str_2 = "str_2"
    str_3 = "str_3"
    newstr_1 = str_2.replace("str_2", "str_3")
    # Execute validate_with_positions
    # Test exception raised
    try:
        any_1 = validate_with_positions(token=bool_0, validator=bool_0)
    except Exception as e:
        # Assert type of exception
        assert type(e) == SystemError

    # Test exception raised


# Generated at 2022-06-26 10:40:27.197550
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1
    float_0 = 1.0
    int_0 = int_0
    float_0 = float_0
    bool_0 = True
    bool_0 = bool_0
    str_0 = '""'
    str_0 = str_0
    dict_0 = {}
    dict_0 = dict_0
    list_0 = []
    list_0 = list_0
    str_1 = '"email"'
    str_2 = '"email"'
    str_1 = str_1
    str_2 = str_2
    dict_1 = {"max_length": int_0}
    dict_1 = dict_1
    dict_2 = {"max_length": int_0}
    dict_2 = dict_2

# Generated at 2022-06-26 10:40:28.770979
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 0 == 0

# Generated at 2022-06-26 10:40:31.994036
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == validate_with_positions(token="", validator=True)

