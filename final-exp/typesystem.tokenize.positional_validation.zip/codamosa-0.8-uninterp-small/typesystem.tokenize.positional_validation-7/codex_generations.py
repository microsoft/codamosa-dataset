

# Generated at 2022-06-26 10:31:04.257209
# Unit test for function validate_with_positions
def test_validate_with_positions(): 
    token_0 = None
    type_0 = None
    any_0 = validate_with_positions(token=token_0, validator=type_0)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:31:06.108428
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None

    assert validate_with_positions(token=any_0, validator=any_0)

# Generated at 2022-06-26 10:31:12.709530
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test with arguments
    pass

# Generated at 2022-06-26 10:31:22.112777
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        name="str",
        value="Hello, World!",
        start=Position(char_index=0, line_index=0, position_index=0),
        end=Position(char_index=13, line_index=0, position_index=1),
    )
    type_0 = Field(type="string")
    any_0 = validate_with_positions(token=token_0, validator=type_0)
    assert any_0 == "Hello, World!"

    token_1 = Token(
        name="str",
        value="Hello, World!",
        start=Position(char_index=0, line_index=0, position_index=0),
        end=Position(char_index=13, line_index=0, position_index=1),
    )
    type_

# Generated at 2022-06-26 10:31:29.490360
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pdb
    pdb.set_trace()
    # Test 1:
    # Set up test here
    token_1 = Token()
    type_1 = None
    try:
        validate_with_positions(token=token_1, validator=type_1)
    except Exception as e:
        if isinstance(e, NotImplementedError):
            print("Exception raised successfully (1)")
        else:
            raise e

# Generated at 2022-06-26 10:31:38.098232
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Set up test values
    token_0 = Token(
        value=1,
        start=Position(line=0, column=0, char_index=0),
        end=Position(line=0, column=100, char_index=100),
    )
    type_0 = Field()

    # Call the test function
    any_0 = validate_with_positions(token=token_0, validator=type_0)

    # Check for correct result
    assert any_0 == 1



# Generated at 2022-06-26 10:31:43.387344
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(text=None, type=None, index=(), start=None, end=None)
    type_0 = Field(required=True)
    any_0 = validate_with_positions(token=token_0, validator=type_0)
    assert any_0 is None
    type_1 = Field(required=False)
    any_1 = validate_with_positions(token=token_0, validator=type_1)
    assert any_1 is None


# Generated at 2022-06-26 10:31:52.561685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value={
            "a_string": "some string",
            "a_number": 42,
            "a_boolean": True,
            "a_null": None,
            "a_list": ["a", "list"],
            "a_dict": {"a": "dict"},
        },
        start={"line": 0, "column": 0, "char_index": 0},
        end={"line": 3, "column": 7, "char_index": 39},
    )

# Generated at 2022-06-26 10:32:04.403400
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Note that for this test, we want to just make sure that errors
    # are properly reported, and not that positions are actually
    # correct, since that would require mocking the tokenizer
    from typesystem import fields, schemas

    class BooleanToken(Token):
        @property
        def start(self):
            return None

        @property
        def end(self):
            return None

        @property
        def value(self):
            return bool(self.text)

    class UserSchema(schemas.Schema):
        email = fields.EmailField(required=True)
        active = fields.BooleanField()

    class BooleanField(fields.Field):
        def convert(self, value, path):
            if not isinstance(value, bool):
                raise ValidationError("Not a boolean.", index=path)

    token_1

# Generated at 2022-06-26 10:32:08.123716
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    type_0 = None
    any_0 = validate_with_positions(token=token_0, validator=type_0)


# Compiled from stuff



# Generated at 2022-06-26 10:32:16.180561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    with pytest.raises(TypeError):
        assert None == any_0

# Generated at 2022-06-26 10:32:21.691198
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() is None

# vim: et:sw=4:syntax=python:ts=4:

# Generated at 2022-06-26 10:32:24.530413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_1 = None
    any_0 = validate_with_positions(token=var_1, validator=var_1)

# Generated at 2022-06-26 10:32:25.584209
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False
 

# Generated at 2022-06-26 10:32:29.976356
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io
    import sys

    captured_output = io.StringIO()
    sys.stdout = captured_output

    test_case_0()
    sys.stdout = sys.__stdout__
    assert (
        captured_output.getvalue()
        == "var_0 = None\nany_0 = validate_with_positions(token=var_0, validator=var_0)\n"
    )

# Generated at 2022-06-26 10:32:31.191065
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:32:32.662134
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == False # TODO: implement your test here


# Generated at 2022-06-26 10:32:38.954958
# Unit test for function validate_with_positions
def test_validate_with_positions():
    val = None
    res = validate_with_positions(token=val, validator=val)
    assert res == "Fail"

# Generated at 2022-06-26 10:32:40.066882
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:32:48.467061
# Unit test for function validate_with_positions
def test_validate_with_positions():

    from io import StringIO
    from typesystem.registry import Registry
    from typesystem.schemas import Schema
    from typesystem.tokenize.tokens import Token

    # 1. Instance
    class B:

        def __init__(self, value):
            self.value = value

    b = B(1)

    # 2. Registry
    class Registry0(Registry):

        def __init__(self, **kwargs):
            super().__init__(**kwargs)
            self.schema = None

        def validate(self, token, **kwargs):
            return validate_with_positions(token=token, validator=self.schema)

    registry = Registry0()

    # 3. Schema

# Generated at 2022-06-26 10:32:59.394577
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This test will pass because we don't raise an error in validate_with_positions.
    assert True

# Generated at 2022-06-26 10:33:04.478288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # :: Error: 3:2: Invalid type "None" for var_0
    var_0 = None
    # :: Error: 4:6: Invalid type "None" for validator
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:33:08.337650
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is var_0



# Generated at 2022-06-26 10:33:14.349493
# Unit test for function validate_with_positions
def test_validate_with_positions():

    node = {'type': 'Object', 'properties': [{'name': 'a', 'type': 'String'}]}

    token = Token(node=node)
    validator = Schema(fields={"a": Field(type="string")})
    validate_with_positions(token=token, validator=validator)

# Generated at 2022-06-26 10:33:21.251083
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as exinfo:
        test_case_0()
    assert exinfo.value.messages[0].start_position.line_number == 1
    assert exinfo.value.messages[0].start_position.char_index == 0
    assert exinfo.value.messages[0].end_position.line_number == 1
    assert exinfo.value.messages[0].end_position.char_index == 22

# Generated at 2022-06-26 10:33:22.980468
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True
    assert True


if __name__ == "__main__":
    test_validate_with_positions()
    print("Done.")

# Generated at 2022-06-26 10:33:24.695970
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)


# Generated at 2022-06-26 10:33:31.712809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        # Arguments to test function
        var_0 = None
        var_1 = None
        validate_with_positions(token=var_0, validator=var_1)

    except Exception as e:
        assert isinstance(e, ValidationError)
        assert e.messages[0].code == "required"
        assert e.messages[0].index == tuple()
        assert e.messages[0].start_position == TokenPosition(
            byte_index=0, char_index=0, line=0, column=0
        )
        assert e.messages[0].end_position == TokenPosition(
            byte_index=0, char_index=0, line=0, column=0
        )
        assert e.messages[1].code == "required"
        assert e.messages

# Generated at 2022-06-26 10:33:41.452372
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        var_0 = None
        any_0 = validate_with_positions(token=var_0, validator=var_0)
    except ValidationError as error:
        messages = []
        for message in error.messages():
            assert message.text == "The field None is required."
            assert message.code == "required"
            assert message.index == []
            assert message.start_position == (1, 0)
            assert message.end_position == (1, 0)
            messages.append(message)



# Generated at 2022-06-26 10:33:53.226833
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    token = typesystem.tokenize("{}")[0]
    schema = typesystem.Schema({"name": typesystem.String(required=True)})
    with pytest.raises(typesystem.ValidationError) as context:
        validate_with_positions(token=token, validator=schema)

    messages = context.value.messages
    assert [message.code for message in messages] == ["required"]
    assert int(messages[0].start_position.line_index) == 1
    assert int(messages[0].end_position.line_index) == 1
    assert int(messages[0].start_position.char_index) == 2
    assert int(messages[0].end_position.char_index) == 2

# Generated at 2022-06-26 10:34:18.747466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    try:
        assert var_0 == validate_with_positions(token=var_0, validator=var_0)
    except ValidationError as error:
        messages = error.messages()
        messages.sort(key=lambda m: m.index)
        assert messages == []
    try:
        assert var_1 == validate_with_positions(token=var_1, validator=var_0)
    except ValidationError as error:
        messages = error.messages()
        messages.sort(key=lambda m: m.index)

# Generated at 2022-06-26 10:34:22.353819
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:34:27.854177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token("name", None, "foo", None)
    var_0.value = {"name": "foo"}
    var_1 = Field(name="name", required=True, type="string")
    any_0 = validate_with_positions(token=var_0, validator=var_1)



# Generated at 2022-06-26 10:34:30.464047
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:34:40.698071
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    token = Token(value="abc", start={"line_index": 1, "char_index": 2})
    assert validate_with_positions(token=token, validator=field) == "abc"

    field = Field(type="string", required=True)
    token = Token(value="", start={"line_index": 1, "char_index": 2})
    try:
        validate_with_positions(token=token, validator=field)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field '' is required.",
                code="required",
                index=[""],
                start_position=token.start,
                end_position=token.end,
            )
        ]

# Generated at 2022-06-26 10:34:47.474262
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = None  # type: Field
    query = None

    try:
        validate_with_positions(token=query, validator=validator)
    except ValidationError as error:
        assert "The field 'query' is required." in str(error)

    query = query.lookup(["query"])

    try:
        validate_with_positions(token=query, validator=validator)
    except ValidationError as error:
        assert "The field 'document' is required" in str(error)

    try:
        validate_with_positions(token=query, validator=validator)
    except ValidationError as error:
        assert (
            "The field 'document' is required. (expected to be initialized "
            "and non-null)" in str(error)
        )

# Generated at 2022-06-26 10:34:53.778080
# Unit test for function validate_with_positions
def test_validate_with_positions():
    num_errors = 0
    pass_msg = f"Passed: {test_case_0.__name__}."
    fail_msg = f"Failed: {test_case_0.__name__}."
    try:
        test_case_0()
    except ValidationError:
        num_errors += 1
    assert num_errors == 0, fail_msg

# Generated at 2022-06-26 10:34:54.547548
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:34:56.269511
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Runs unit test for function
    # validate_with_positions
    test_case_0()

# Generated at 2022-06-26 10:35:05.383226
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:35:39.548591
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:35:44.179495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert hasattr(validate_with_positions, "__call__"), "Function 'validate_with_positions' must be callable"
    assert type(validate_with_positions(token=None, validator=None)) is type(None), "Function 'validate_with_positions' must return an instance of type None"

# Generated at 2022-06-26 10:35:49.811980
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field_0: Field = Field(name="name", type="string")
    var_0: Token = Token(value=None, start=None, end=None, lookup=None)
    var_1: Token = Token(
        value={"name": 123}, start=(1, 1), end=(2, 1), lookup=lambda index: var_0
    )
    any_0 = validate_with_positions(token=var_1, validator=field_0)

# Generated at 2022-06-26 10:35:52.300800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:36:01.140757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # No errors
    validate_with_positions(token=None, validator=None)
    # No errors
    validate_with_positions(token=None, validator=None)
    # No errors
    validate_with_positions(token=None, validator=None)
    # No errors
    validate_with_positions(token=None, validator=None)
    # No errors
    validate_with_positions(token=None, validator=None)
    # No errors
    validate_with_positions(token=None, validator=None)

# Generated at 2022-06-26 10:36:05.208763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    expected = None  # TODO: update with expected value
    actual = test_case_0()
    assert expected == actual



# Generated at 2022-06-26 10:36:14.558749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    def func_0():
      return validate_with_positions(token=var_0, validator=var_0)
    def func_1():
      return validate_with_positions(token=var_0, validator="x")
    def func_2():
      return validate_with_positions(token=var_0, validator=var_0.value)
    def func_3():
      return validate_with_positions(token=var_0, validator=var_0.validate)
    def func_4():
      return validate_with_positions(token=var_0, validator="x".value)
    def func_5():
      return validate_with_positions(token=var_0, validator=var_0.ValidationError)

# Generated at 2022-06-26 10:36:23.264760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    obj_0 = None
    var_0 = obj_0
    var_1 = var_0
    var_2 = None
    var_3 = var_2.validate(var_1)
    var_4 = None
    var_5 = var_4.validate(var_1)
    var_6 = None
    var_7 = var_6.validate(var_1)
    var_8 = None
    var_9 = var_8.validate(var_1)
    var_10 = None
    var_11 = var_10.validate(var_1, var_10)
    var_12 = None
    var_13 = var_12.validate(var_1, var_10)

# Generated at 2022-06-26 10:36:23.795873
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True

# Generated at 2022-06-26 10:36:34.559086
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """
    validate_with_positions
    :param token: Token
    :param validator: typing.Union[Field, typing.Type[Schema]]
    :return: typing.Any
    """

    var_0 = None
    var_1 = None
    try:
        any_1 = validate_with_positions(token=var_0, validator=var_1)
    except ValidationError as error_1:
        any_0 = error_1.messages[0].end_position.char_index  # type: ignore
    assert any_0 == 0

# Generated at 2022-06-26 10:37:52.524874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = Field(type="integer", required=False, format="int32")
    var_2 = Schema([var_1], required=False)
    var_3 = Field(nullable=True, required=False)
    var_4 = Field(type="integer", required=False, format="int32")
    var_5 = Schema([var_4], required=False)
    var_6 = Field(type="boolean", required=False)
    var_7 = Schema([var_6], required=False)
    var_8 = Field(type="boolean", required=False)
    var_9 = Schema([var_3, var_5, var_7, var_8], required=False)
    var_10 = Field(type="string", required=False)
    var_

# Generated at 2022-06-26 10:37:56.476929
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(ValidationError) as excinfo:
        var_0 = None
        any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert excinfo.value.messages == []


# Generated at 2022-06-26 10:38:02.244738
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Dummy:
        pass

    class Dummy0:
        pass

    class Dummy1:
        pass

    dummy_0 = Dummy()
    dummy_1 = Dummy0()
    dummy_2 = Dummy1()
    ret_0 = validate_with_positions(token=dummy_0, validator=dummy_1)
    assert ret_0 == dummy_2

# Generated at 2022-06-26 10:38:03.141615
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:38:10.234265
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem_jsonschema.tokenize import Lexer, make_tokens, token_name

    lexer = Lexer()

# Generated at 2022-06-26 10:38:21.970437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import sys
    import os
    os.chdir(os.path.dirname(sys.argv[0]))
    import json
    with open("example.json", "r") as f:
        example = json.loads(f.read())
    import typesystem
    schema = typesystem.Schema(
        {
            "name": typesystem.String(max_length=10, min_length=1),
            "age": typesystem.Integer(maximum=100, minimum=0),
            "favorites": typesystem.Array(items=typesystem.String()),
        }
    )
    from typesystem.tokenize.parser import parser

# Generated at 2022-06-26 10:38:25.794001
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    str_0 = None
    schema_0 = Schema(fields={"_": Field(name="_", required=None, type=str)})
    var_0 = Token(start=None, end=None, value="")
    any_1 = validate_with_positions(token=var_0, validator=schema_0)

# Generated at 2022-06-26 10:38:28.602714
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # any[1]
    var_0 = None
    # any[1]
    var_1 = None

    # Call function
    validate_with_positions(token=var_0, validator=var_1)

    assert True == True

# Generated at 2022-06-26 10:38:31.271225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)


# Generated at 2022-06-26 10:38:33.768536
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    assert var_0 == var_1