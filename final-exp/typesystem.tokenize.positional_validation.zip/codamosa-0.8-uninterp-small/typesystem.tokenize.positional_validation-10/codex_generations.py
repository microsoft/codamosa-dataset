

# Generated at 2022-06-26 10:31:05.504958
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions(token='abc', validator=str)

        # Type error
    except TypeError:
        pass
    try:
        validate_with_positions(token=123, validator=str)

        # Type error
    except TypeError:
        pass
    try:
        validate_with_positions(token=None, validator=str)

        # Type error
    except TypeError:
        pass
    try:
        validate_with_positions(token='abc', validator=object)

        # Type error
    except TypeError:
        pass
    try:
        validate_with_positions(token=123, validator=object)

        # Type error
    except TypeError:
        pass

# Generated at 2022-06-26 10:31:13.933305
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    type_0 = None
    any_0 = validate_with_positions(token=token_0, validator=type_0)



# Generated at 2022-06-26 10:31:15.930890
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=token_0, validator=type_0) == any_0

# Generated at 2022-06-26 10:31:18.886647
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = None
    type_1 = None
    any_1 = validate_with_positions(token=token_1, validator=type_1)

# Generated at 2022-06-26 10:31:29.876087
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.fields import String, Integer
    from typesystem.schemas import Object
    from typesystem.tokenize.tokens import (
        Token,
        TokenList,
        ArrayToken,
        ObjectToken,
    )

    class DemoSchema(Object):
        name = String()
        age = Integer()

    schema = DemoSchema()
    messages = []

# Generated at 2022-06-26 10:31:38.785368
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    validator_0 = Schema()
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert any_0 == ([]), f'expected: ({[]})'
    token_0 = Token()
    validator_0 = Field(type="string")
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert any_0 == ([]), f'expected: ({[]})'

# Generated at 2022-06-26 10:31:44.882015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    type_0 = None
    any_0 = validate_with_positions(token=token_0, validator=type_0)

# Generated at 2022-06-26 10:31:50.364464
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0: Token = {"value": {"a": [{"b": "c"}]}}
    type_0 = Field(key="a", type=ListField(Field(key="b", type=String)))

    # Exercise
    any_0 = validate_with_positions(token=token_0, validator=type_0)

    # Verify
    assert any_0 == {"a": [{"b": "c"}]}


# Generated at 2022-06-26 10:32:02.570099
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Literal should be: 1
    token_0 = 1
    type_0 = 1
    # Literal should be: 2
    token_1 = 2
    type_1 = 2

    # Literal should be: foo
    token_2 = "foo"
    type_2 = "foo"
    # Literal should be: bar
    token_3 = "bar"
    type_3 = "bar"

    any_0 = validate_with_positions(token=token_0, validator=type_0)
    any_1 = validate_with_positions(token=token_1, validator=type_1)

    any_2 = validate_with_positions(token=token_2, validator=type_2)

# Generated at 2022-06-26 10:32:06.041616
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("One")
    type_0 = Field(required=True, pattern="Two")
    any_0 = validate_with_positions(token=token_0, validator=type_0)

# Generated at 2022-06-26 10:32:10.866575
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        var_0 = []
    except ValidationError:
        pass

# Generated at 2022-06-26 10:32:18.318319
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        var_0 = []
        token = Token(body='{"a": 1}')
        validator = Schema({"a": Field(type="number")})
        try:
            validate_with_positions(token=token, validator=validator)
        except ValidationError:
            var_0.append(False)
    except:
        var_0.append(False)
    assert sum(var_0) == 0

# test_case_0


# Generated at 2022-06-26 10:32:25.787169
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = []

    # test if function could handle the exceptions
    def validate_with_positionswrapper():
        try:
            validate_with_positions(token=var_0, validator=var_0)
        except ValidationError:
            pass

    # assert if an exception was raised
    assert_raises(validate_with_positionswrapper)

# Generated at 2022-06-26 10:32:32.325433
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_6 = []
    var_7 = unittest.mock.Mock()
    var_8 = unittest.mock.Mock()
    var_8.return_value = True
    var_7.validate = var_8
    var_9 = unittest.mock.Mock()
    var_10 = unittest.mock.Mock()
    
    @unittest.mock.patch('typesystem.tokenize.parse.validate_with_positions', side_effect=var_10)
    def function(arg_0, arg_1):
        var_6.append(arg_0)
        var_6.append(arg_1)
        return unittest.mock.Mock()
    arg_0 = unittest.mock.Mock()
   

# Generated at 2022-06-26 10:32:45.501610
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_1 = {"type": "object", "properties": {"name": {"type": "string"}}}

# Generated at 2022-06-26 10:32:48.788682
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Input parameters
    token = test_case_0
    validator = test_case_0

    # Returned result
    result = validate_with_positions(token=token, validator=validator)

    # Next step
    pass

# Generated at 2022-06-26 10:32:50.444505
# Unit test for function validate_with_positions
def test_validate_with_positions():
    for x in range(4):
        assert test_case_0() == False

# Generated at 2022-06-26 10:33:02.677755
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:33:03.963481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)


# Generated at 2022-06-26 10:33:07.128834
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Prepare
    var_0 = []

    # Execute
    ret_0 = validate_with_positions(token=3, validator="")

    # Verify
    assert ret_0 == 3

# Generated at 2022-06-26 10:33:23.882623
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_1 = []
    var_1.append('')
    var_2 = {'token': var_1}
    var_4 = []
    var_4.append('')
    var_3 = {'token': var_4}
    var_3['validator'] = var_1
    var_5 = []
    var_5.append('')
    var_4 = {'token': var_5}
    var_4['validator'] = var_3
    var_5 = []
    var_5.append('')
    var_6 = {'token': var_5}
    var_8 = []
    var_8.append('')
    var_7 = {'token': var_8}
    var_7['validator'] = var_5

# Generated at 2022-06-26 10:33:31.182095
# Unit test for function validate_with_positions
def test_validate_with_positions():
    error_msg = "test failed for function validate_with_positions"
    # test case 0
    try:
        assert validate_with_positions is not None
        print("test case 0 passed")
    except AssertionError:
        print(error_msg)
        raise
    # test case 1
    try:
        assert validate_with_positions is not None
        print("test case 1 passed")
    except AssertionError:
        print(error_msg)
        raise
    # test case 2
    try:
        assert validate_with_positions is not None
        print("test case 2 passed")
    except AssertionError:
        print(error_msg)
        raise
    # test case 3

# Generated at 2022-06-26 10:33:33.540731
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # AssertionError: assert [] == ['X']
    assert var_0 == ['X']


# Generated at 2022-06-26 10:33:44.579459
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Get the path to the test files
    abs_file_path = pathlib.Path(__file__).resolve()
    abs_test_data_path = abs_file_path.parent.joinpath(
        "test_data", pathlib.Path(inspect.getframeinfo(inspect.currentframe()).function)
    )

    # Load the test JSON
    with open(abs_test_data_path.joinpath("test_case_0_data.json"), "r") as test_case_0_file:
        test_case_0_data = json.load(test_case_0_file)

    # We don't use the tokenizer to generate our token, this is because we want to
    # directly test the error message generation

# Generated at 2022-06-26 10:33:55.860457
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = []
    var_1 = {}
    var_2 = {}
    var_2[1] = 2
    var_3 = {}
    var_3[0] = 1
    var_3[1] = 2
    var_3[2] = 3
    var_3[3] = 3
    var_3[4] = 1
    var_3[5] = 2
    var_3[6] = 3
    var_3[7] = 4
    var_3[8] = 4
    var_3[9] = 5
    var_3[10] = 5
    var_3[11] = 6
    var_3[12] = 7
    var_3[13] = 8
    var_3[14] = 9
    var_3[15] = 10
   

# Generated at 2022-06-26 10:34:06.602896
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = Token(
        raw_value={},
        value={},
        tokens={},
        start=IndexedPosition(
            line_index=0,
            column_index=0,
            char_index=0,
            line=0,
            column=0,
            char=0,
            path="",
            string_index=0,
        ),
        end=IndexedPosition(
            line_index=0,
            column_index=0,
            char_index=0,
            line=0,
            column=0,
            char=0,
            path="",
            string_index=0,
        ),
    )
    validator = Schema(fields={})
    # Act

# Generated at 2022-06-26 10:34:11.597918
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        assert str("todo") == str("todo")
    except:
        x = validate_with_positions
        raise RuntimeError("Function 'validate_with_positions' not implemented")
    else:
        print("Function 'validate_with_positions' implemented")


# Generated at 2022-06-26 10:34:15.314297
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = [{}, {}, {}, {}, {}, {}, {}, {}]
    var_0[0]["field"] = Field({})
    var_0[1]["token"] = "token"
    var_0[2]["text"] = "text"
    var_0[3]["index"] = "index"
    var_0[4]["start"] = "start"
    var_0[5]["end"] = "end"
    var_0[6]["messages"] = {
        "text": var_0[2]["text"],
        "code": "index",
        "index": var_0[3]["index"],
        "start": var_0[4]["start"],
        "end": var_0[5]["end"],
    }

# Generated at 2022-06-26 10:34:21.680374
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def example_function_0():
        var_0 = '''
{
"name": {
    "first": "John",
    "last": "Doe"
},
"date": "2020-01-01",
"age": 99
}
'''
        var_0 = Token.from_str(var_0)
        def var_1(var_0):
            var_1 = var_0 # type: Token
            var_2 = var_1.lookup(["name", "first"]) # type: Token
            var_3 = var_2.value # type: str
            if True:
                raise NotImplementedError()
            var_4 = var_2 # type: Token
            var_5 = var_4.lookup(["name", "last"]) # type: Token

# Generated at 2022-06-26 10:34:33.598631
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List

    from typesystem.tokenize.tokens import Token

    from typesystem.fields import Integer
    from typesystem.schemas import Schema
    from typesystem.tokenize import tokenize

    class Product(Schema):
        id = Integer()

    input = "[{'id': 12}"
    tokens = tokenize(input)
    token = tokens[0]

    try:
        validate_with_positions(token=token, validator=Product)
    except ValidationError as error:
        pass
    else:
        assert False

    messages = error.messages()
    assert len(messages) == 1
    message = messages[0]
    assert message.text == "Invalid value."

    index = message.index
    assert index == [0, "id"]

# Generated at 2022-06-26 10:34:40.528398
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:34:42.738222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .utils import check_function_signature

    check_function_signature(validate_with_positions, "test_validate_with_positions")

# Generated at 2022-06-26 10:34:43.460229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:34:47.256817
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert (
        validate_with_positions(token=Token(None, None), validator=Field()).value
        is None
    )

# Generated at 2022-06-26 10:34:58.221722
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.utils import (
        make_end,
        make_start,
        make_token,
    )

    class Person(Schema):
        name = Field(required=True)
        age = Field(type="integer", required=True)
        address = Field(type="object", required=False)

    class Address(Schema):
        city = Field(required=True)
        country = Field(required=True)

    Person.fields["address"].type = Address

    token = Token(
        type="object",
        value={
            "name": "Nikita Sobolev",
            "age": "23",
            "address": {"city": "Moscow", "country": "Russia"},
        },
    )

    var_0 = None

# Generated at 2022-06-26 10:34:59.022431
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True



# Generated at 2022-06-26 10:35:07.866776
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from ast import parse

    from . import syntax
    from . import schema

    from .compiler import compile_schema_code, compile_schema_ast

    class PersonSchema(Schema):
        name = Field(str, required=True)
        age = Field(int)

    schema.PersonSchema = PersonSchema

    schema_source = inspect.getsource(schema)
    schema_ast = parse(schema_source)
    syntax_source = inspect.getsource(syntax)
    syntax_ast = parse(syntax_source)
    schema_syntax = compile_schema_ast(schema_ast)
    syntax_syntax = compile_schema_ast(syntax_ast)

    # print(schema_syntax.schema)
    # print(schema_syntax.format())
   

# Generated at 2022-06-26 10:35:20.888588
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Schema({"name": Field(str)})

    token = Token(
        value={"name": "Robert"},
        start=Token.Position(line_index=0, char_index=1),
        end=Token.Position(line_index=0, char_index=8),
    )
    assert validate_with_positions(token=token, validator=validator) == {"name": "Robert"}

    token = Token(
        value={}, start=Token.Position(line_index=0, char_index=1), end=Token.Position(line_index=0, char_index=5)
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=validator)

    message = exc_info.value.mess

# Generated at 2022-06-26 10:35:23.192874
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:35:30.932073
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def test_validate_with_positions_0():
        var_0 = None
        any_0 = validate_with_positions(token=var_0, validator=var_0)
    with pytest.raises(TypeError):
        test_validate_with_positions_0()

    def test_validate_with_positions_1():
        var_1 = Token(None, None, None)
        any_1 = validate_with_positions(token=var_1, validator=var_1)
    with pytest.raises(TypeError):
        test_validate_with_positions_1()

    def test_validate_with_positions_2():
        var_2 = Token(None, None, None)

# Generated at 2022-06-26 10:35:47.438271
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)



# Generated at 2022-06-26 10:35:48.825806
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:35:52.140204
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_0 = Field()
    var_1 = Token(start=0, end=0, value=0)
    any_0 = validate_with_positions(token=var_1, validator=var_0)


# Unit tests end here

# Test definition

# Generated at 2022-06-26 10:35:54.482278
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)


# Generated at 2022-06-26 10:36:04.267523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class FooSchema(Schema):
        foo = Field(type="integer", minimum=0)

        class Meta:
            strict = True

    token = Token(
        value={
            "foo": "hello"
        },
        start={
            "line_index": 1,
            "char_index": 8,
            "line_number": 2,
        },
        end={
            "line_index": 4,
            "char_index": 12,
            "line_number": 3,
        },
    )
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=FooSchema)

    error = exc_info.value

# Generated at 2022-06-26 10:36:14.124492
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def check_output(input_0, input_1, output_1):
        validator = Field(required=True)
        token = Token(value="foo")
        try:
            any_1 = validate_with_positions(token=input_1, validator=input_0)
        except ValidationError as error:
            messages = [
                Message(
                    text=message.text,
                    code=message.code,
                    index=message.index,
                    start_position=message.start_position,
                    end_position=message.end_position,
                )
                for message in error.messages()
            ]
        else:
            messages = []
        assert messages == output_1


# Generated at 2022-06-26 10:36:18.346337
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0: Token = Token(value="", start=None, end=None)
    var_1 = Schema(name="test")
    any_0 = validate_with_positions(token=var_0, validator=var_1)

# Generated at 2022-06-26 10:36:18.987515
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True

# Generated at 2022-06-26 10:36:33.932719
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . #
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is var_0
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . #

# Generated at 2022-06-26 10:36:47.573284
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test for function validate_with_positions
    var_0 = None
    #there are many ways to check for the output for these basic tests. I'm using the python interactive environment
    var_0 = var_0
    #assert type(var_0) == type(var_0)
    #assert var_0 == var_0
    #these are the result of typing in the interactive environment
    var_1 = 1
    #assert var_1 == 1
    #assert type(var_1) == int
    #assert type(var_1) == int
    #assert var_1 == 1
    var_2 = 'test'
    #assert var_2 == 'test'
    #assert type(var_2) == str
    #assert var_2 == 'test'
    #assert type(var_2) == str
    var

# Generated at 2022-06-26 10:37:19.512820
# Unit test for function validate_with_positions
def test_validate_with_positions():
    """Test function validate_with_positions"""
    # Setup
    token = None
    validator = None

    # Exercise
    result = validate_with_positions(token=token, validator=validator)

    # Verify
    assert result == True

# Generated at 2022-06-26 10:37:22.432702
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:37:30.590894
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # VarDecl(name=var_0, type=Optional[None])
    var_0 = None

    # VarDecl(name=any_0, type=Any)
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:37:40.886916
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    try:
        validate_with_positions(token=var_0, validator=var_1)
    except ValidationError as error:
        var_2 = error
        if (
            (
                var_2.messages[0].start_position.row_index
                == var_2.messages[1].start_position.row_index
            )
            and (var_2.messages[0].start_position.char_index == 0)
            and (var_2.messages[1].start_position.char_index == 0)
        ):
            var_3 = True
        else:
            var_3 = False
        assert var_3


# Generated at 2022-06-26 10:37:54.469197
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # These lines of code should pass type checking
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

    class Class_0(Schema):
        field_0 = Field(type='string')

    Class_0().validate(value={'field_0': "abc"})

    class Class_1(Schema):
        field_0 = Field(type='number')

    Class_1().validate(value={'field_0': 123})

    class Class_2(Schema):
        field_0 = Field(type='boolean')

    Class_2().validate(value={'field_0': True})

    class Class_3(Schema):
        field_0 = Field(type='array')


# Generated at 2022-06-26 10:37:57.240976
# Unit test for function validate_with_positions
def test_validate_with_positions():
    args = {"token": "token", "validator": "validator"}

    with pytest.raises(TypingError):
        validate_with_positions(**args)



# Generated at 2022-06-26 10:38:03.900142
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Test if the 'validator' value raises a ValidationError
    with pytest.raises(ValidationError):
        validate_with_positions(validator=None, token=None)

    # Test if the 'token' value raises a ValidationError
    with pytest.raises(ValidationError):
        validate_with_positions(validator=None, token=None)


if __name__ == "__main__":
    import sys

    pytest.main(sys.argv)

# Generated at 2022-06-26 10:38:06.385213
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Cut-and-paste from above
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:38:08.457184
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)



# Generated at 2022-06-26 10:38:09.255920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None



# Generated at 2022-06-26 10:39:23.933672
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:39:27.045892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:39:35.374801
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_arg_0 = Token(
        "root",
        Token("key", Token("5", 5, start_position=Position(0, 0))),
        start_position=Position(0, 0),
    )
    var_arg_1 = Field(type=int, max_value=10)
    with pytest.raises(ValidationError) as pytest_wrapper_1:
        validate_with_positions(token=var_arg_0, validator=var_arg_1)
    var_1 = pytest_wrapper_1.value
    var_2 = ValidationError(
        [Message("The field key must be less than 10.", "max_value", ["key"])]
    )
    assert var_1 == var_2


# Generated at 2022-06-26 10:39:44.030129
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    any_1 = None
    var_0 = None
    var_1 = None
    var_0 = Token(var_0, any_0, any_1, any_0, any_1)
    var_1 = Field(var_0, any_0)
    any_0 = validate_with_positions(token=var_0, validator=var_1)
    var_2 = Schema()
    any_1 = validate_with_positions(token=var_0, validator=var_2)
    pass

# Generated at 2022-06-26 10:39:53.998801
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        # Line number 6, column number 0
        var_0 = None
        any_0 = validate_with_positions(token=var_0, validator=var_0)
        # Line number 5
        raise AssertionError("validate_with_positions_test.py::test_case_0")
    except ValidationError:
        pass
    except RuntimeError as error:
        raise AssertionError(error)
    except TypeError as error:
        raise AssertionError(error)
    except NameError as error:
        raise AssertionError(error)
    except ValueError as error:
        raise AssertionError(error)
    except AttributeError as error:
        raise AssertionError(error)
    except Exception as error:
        raise error

# Generated at 2022-06-26 10:40:04.956281
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    var_1 = None
    any_1 = validate_with_positions(token=var_1, validator=var_1)
    var_2 = None
    any_2 = validate_with_positions(token=var_2, validator=var_2)
    var_3 = None
    any_3 = validate_with_positions(token=var_3, validator=var_3)
    var_4 = None
    any_4 = validate_with_positions(token=var_4, validator=var_4)
    var_5 = None
    any_5 = validate_with_positions(token=var_5, validator=var_5)
   

# Generated at 2022-06-26 10:40:15.906229
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token(value={"type": "start_map"}, children=[], start=0, end=0)
    var_1 = Token(value={"type": "end_map"}, children=[], start=0, end=0)
    var_2 = Token(
        value={"type": "name", "value": "name"},
        children=[],
        start=0,
        end=0,
    )
    var_3 = Token(
        value={"type": "string", "value": "name"},
        children=[],
        start=0,
        end=0,
    )
    var_4 = Token(value={"type": "start_array"}, children=[], start=0, end=0)

# Generated at 2022-06-26 10:40:26.848230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    data = [
        {
            "input": {
                "token": Token(
                    value={},
                    properties={},
                    start={
                        "line": 1,
                        "column": 1,
                        "char_index": 0,
                        "data_index": 0,
                    },
                    end={
                        "line": 3,
                        "column": 1,
                        "char_index": 11,
                        "data_index": 11,
                    },
                    parent=None,
                ),
                "validator": Schema(
                    {
                        "name": Field(primitive="string"),
                        "age": Field(primitive="integer"),
                    }
                ),
            },
            "expected": ValidationError,
        }
    ]
    for d in data:
        *_, result = d["input"]

# Generated at 2022-06-26 10:40:35.062137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var = Token(
        start=Position(line=1, char_index=1),
        end=Position(line=2, char_index=2),
        value=1,
    )

    def validator(value):
        if value != 1:
            raise ValidationError()

    assert validate_with_positions(token=var, validator=validator) == 1

# Generated at 2022-06-26 10:40:38.692644
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

