

# Generated at 2022-06-26 10:31:03.997434
# Unit test for function validate_with_positions
def test_validate_with_positions():
    document = {
        "type": "array",
        "items": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "minLength": 4, "maxLength": 7},
                "name": {"type": "string", "minLength": 5, "maxLength": 9},
            },
        },
    }

    # Invalid
    invalid_token = Token("[[%s]]" % json.dumps({"name": "bb", "id": "abc"}))
    try:
        validate_with_positions(
            token=invalid_token,
            validator=Schema(schema=document, name="Test"),
        )
    except ValidationError as error:
        messages = error.messages()
    assert len(messages) == 3
    micro_positions

# Generated at 2022-06-26 10:31:10.754003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value={
            "first_name": "Joe",
            "last_name": "Blow",
            "age": 15,
            "address": {
                "street": "123 Fake Street",
                "postcode": "456",
                "city": "Fake City"
            }
        },
        start=Position(line=1, col=1, char_index=0),
        end=Position(line=1, col=90, char_index=89),
    )

# Generated at 2022-06-26 10:31:21.622675
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem
    import tokenize.tokens
    assert type(validate_with_positions(
        token=tokenize.tokens.Token(
            value=None,
            errors=[],
            type=tokenize.tokens.TokenType.NULL,
            start=tokenize.tokens.SourcePosition(line_number=1, char_index=1),
            end=tokenize.tokens.SourcePosition(line_number=1, char_index=1),
        ),
        validator=typesystem.fields.String(
            description=None,
            name=None,
            min_length=0,
            max_length=None,
            pattern=None,
        ),
    )) == None

# Generated at 2022-06-26 10:31:26.229497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    union_0 = Field(type="string", description="A string")
    any_0 = validate_with_positions(token=token_0, validator=union_0)
    assert any_0 == None



# Generated at 2022-06-26 10:31:26.744827
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:31:32.672074
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value="foo",
        start={"line": 0, "char_index": 0},
        end={"line": 0, "char_index": 3},
    )
    union_1 = Field(primitive_type="string")
    any_2 = validate_with_positions(token=token_0, validator=union_1)



# Generated at 2022-06-26 10:31:41.274513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=Token('"foo"'), validator=Field(str)) == 'foo'
    try:
        validate_with_positions(token=Token('1'), validator=Field(str))
    except ValidationError as error:
        message = error.messages[0]
        assert message.text == "Value must be a string."
        assert message.start_position == Position(line=1, char_index=0)
        assert message.end_position == Position(line=1, char_index=2)


# Generated at 2022-06-26 10:31:43.101719
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    union_0 = None
    any_0 = validate_with_positions(token=token_0, validator=union_0)


# Generated at 2022-06-26 10:31:52.244512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value="foo",
        children=[
            Token(
                value=None, start=(1, 1), end=(1, 1), children=[], __field_name__="bar"
            )
        ],
        start=(1, 1),
        end=(1, 1),
        __field_name__="foo",
    )
    field_0 = Field(name="foo", type=str)
    try:
        assert validate_with_positions(
            token=token_0, validator=field_0
        ) == "foo"
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].start_position == (1, 1)
        assert messages[0].end_position == (1, 1)

# Generated at 2022-06-26 10:32:04.153549
# Unit test for function validate_with_positions
def test_validate_with_positions():

    import random
    import string

    class ExampleSchema(Schema):
        bar = Field(type="integer")
        foo = Field(type="string")

    example_schema = ExampleSchema()

    bar_token = Token(
        value=random.randint(1, 10),
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 2, "char_index": 1},
    )
    baz_token = Token(
        value=None,
        start={"line": 1, "column": 1, "char_index": 0},
        end={"line": 1, "column": 2, "char_index": 1},
    )

# Generated at 2022-06-26 10:32:08.804640
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # implemented


# ============================================================================


# Generated at 2022-06-26 10:32:10.776746
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)




# Generated at 2022-06-26 10:32:20.492576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import unittest
    import sys

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(Test_validate_with_positions))
    runner = unittest.TextTestRunner()
    result = runner.run(suite)
    assert type(result) == unittest.runner._TextTestResult
    assert result.wasSuccessful() == True
    assert type(result.testsRun) == int
    assert type(result.errors) == list
    assert type(result.skipped) == list
    assert type(result.failures) == list
    assert type(result.expectedFailures) == list
    assert type(result.unexpectedSuccesses) == list
    assert type(result.shouldStop) == bool
    assert type(result.buffer) == bool

# Generated at 2022-06-26 10:32:22.185489
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:32:31.011173
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import json
    from typesystem.tokenize.tokens import Token

    # Create a dict representation of a Token model

# Generated at 2022-06-26 10:32:41.578055
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is None, f"Got {repr(any_0)} instead of None."

    var_1 = None
    any_1 = validate_with_positions(token=var_1, validator=var_1)
    assert any_1 is None, f"Got {repr(any_1)} instead of None."

# Generated at 2022-06-26 10:32:42.824843
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:32:47.629488
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test passes
    assert validate_with_positions() == None
    assert validate_with_positions() == None
    assert validate_with_positions() == None
    assert validate_with_positions() == None
    assert validate_with_positions() == None



# Generated at 2022-06-26 10:32:50.060995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:32:52.538560
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True



# Generated at 2022-06-26 10:33:08.159250
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typing

    # Define arguments (variables)
    token = None  # type: Token
    validator = None  # type: typing.Union[Field, typing.Type[Schema]]

    # Call function
    try:
        result = validate_with_positions(token=token, validator=validator)
    except ValidationError as exception:
        messages = exception.messages()
    else:
        messages = None

    # Verify
    assert (...) is False

# Generated at 2022-06-26 10:33:09.401613
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:33:10.986832
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:33:22.187098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class schema(Schema):
        title = "Some Title"
        description = "Some Description"
        type = "string"
        minLength = 3
        maxLength = 3

    token = Token(value="foo")
    try:
        schema.validate(token.value)
    except ValidationError as e:
        messages = e.messages()
        assert len(messages) == 1
        assert messages[0].start_position is None
        assert messages[0].end_position is None
        assert messages[0].code == "minLength"
        assert len(messages[0].index) == 1

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as e:
        messages = e.messages()
        assert len(messages) == 1
       

# Generated at 2022-06-26 10:33:27.818161
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from hypothesis import given
    from . import custom_strategies

    @given(value=custom_strategies.data())
    def test_validate_with_positions_impl(value):
        token = value.draw(custom_strategies.tokens())
        validator = value.draw(custom_strategies.fields())
        result = validate_with_positions(
            token=token, validator=validator
        )
        validator.validate(token.value)
        print(result)

    test_validate_with_positions_impl()

# Generated at 2022-06-26 10:33:28.593774
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:33:30.414029
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:33:34.290323
# Unit test for function validate_with_positions
def test_validate_with_positions():
    my_object = validate_with_positions(
        token = "foo",
        validator = Field(name="foo", type="string"),
    )
    assert my_object == "foo"

# Generated at 2022-06-26 10:33:44.877153
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type: () -> typing.Any
    """Test that the validation function work when the token and the
    validator are the same."""
    from typesystem.tokenize.tokens import StringToken
    from typesystem.fields import String
    from typesystem.schemas import Schema
    from typesystem.schemas import Object
    from typesystem.schemas import Array
    from typesystem.schemas import Integer

    # create a token
    token = StringToken(start=None, end=None, value="foo")

# Generated at 2022-06-26 10:33:47.662770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except Exception:
        print("Exception in test case 0")


test_validate_with_positions()

# Generated at 2022-06-26 10:34:11.252682
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class TestSchema0(Schema):
        age = Field(int)
        name = Field(str)

    class TestSchema1(Schema):
        age = Field(int)
        name = Field(str, required=False)

    class TestSchema2(Schema):
        age = Field(int)
        name = Field(str, required=False)
        country = Field(str)

    token = Token(
        value={"age": 12, "name": "Bob"},
        start={"line_no": 1, "char_index": 0},
        end={"line_no": 1, "char_index": 11},
    )
    result = validate_with_positions(token=token, validator=TestSchema0())
    assert result == {"age": 12, "name": "Bob"}


# Generated at 2022-06-26 10:34:28.728942
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:34:31.390214
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:34:31.936669
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False

# Generated at 2022-06-26 10:34:34.538322
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:34:44.059116
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Field()
    token = Token("value", (1, 10))

    validate_with_positions(token=token, validator=validator)

    validator = Field(required=True)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=validator)

    validator = Field(required=True)
    token = Token(None, (1, 10))
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=validator)
    assert error.value.messages()[0].start_position.line == 1
    assert error.value.messages()[0].start_position.column == 11

# Generated at 2022-06-26 10:34:56.784301
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import json
    import unittest

    from boto3.dynamodb.conditions import Attr
    from botocore.exceptions import ClientError
    from boto3.dynamodb.types import TypeDeserializer
    from botocore.client import Config
    from typesystem import types, fields
    from boto3 import Session
    from boto3.resources.base import ServiceResource, Resource

    class CaseValidator(fields.Object):
        key = fields.IntegerField()
        value = fields.StringField()

    class Case(types.Schema):
        name = fields.StringField()
        description = fields.StringField()
        validator = CaseValidator()
        value = fields.StringField()

    class Response(types.Schema):
        data = CaseValidator()


# Generated at 2022-06-26 10:35:05.875999
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        var_0 = None
        var_1 = None
        var_2 = (
            var_1.validate(var_0.value)
        )  # Replace with your expected value

    except ValidationError as e:
        var_2 = e.messages()


# Generated at 2022-06-26 10:35:06.379783
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 42 == 42

# Generated at 2022-06-26 10:35:12.940183
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema_0(Schema):
        id = Field(type="string")

    class Token_0(Token):
        def lookup(self, *args):
            pass

    with pytest.raises(ValidationError):
        token = Token_0(0)
        validator = Schema_0()
        validate_with_positions(validator=validator, token=token)


# Generated at 2022-06-26 10:35:48.836763
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys
    import os
    import utt.utils.color as color

    # Clear screen
    os.system("clear")

    passed = 0
    failed = 0

    # Setup test suite
    test_suite = [
        {
            "id": 1,
            "input": "",
            "output": "",
            "expected": "",
        }
    ]

    # Run tests
    for test in test_suite:
        id = test["id"]
        input = test["input"]
        output = test["output"]
        expected = test["expected"]

        if output == expected:
            passed = passed + 1
            print(color.green("Test %s passed!" % id))
        else:
            failed = failed + 1
            print(color.red("Test %s failed" % id))

    print

# Generated at 2022-06-26 10:35:52.182273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field()
    token = Token(value=None, start=None, end=None)
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-26 10:35:55.694298
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)


# Generated at 2022-06-26 10:35:56.419115
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:35:57.964686
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Setup

    # Test
    # No output

    assert True

# Generated at 2022-06-26 10:36:05.058209
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Field(name="field", type="string")
    var_0.validate = "validation function"
    var_1 = Token(
        name="field", value="value", start=Position(line=1, column=2, char_index=3)
    )
    var_2 = ValidationError(messages=["error message"])
    var_3 = Message(
        text="error message",
        code="required",
        index=["field"],
        start_position=var_1.start,
        end_position=var_1.end,
    )
    var_4 = ValidationError(messages=[var_3])

# Generated at 2022-06-26 10:36:08.247639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:36:13.878217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field()
    token = Token(start_position=0, end_position=0, value=None)

# Generated at 2022-06-26 10:36:17.739895
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = validate_with_positions(token='ab', validator='ab')
    var_1 = validate_with_positions(token='ab', validator='')


# Generated at 2022-06-26 10:36:20.627837
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions()
    except TypeError as e:
        assert str(e) == "Missing 2 required positional arguments: 'token' and 'validator'"


# Generated at 2022-06-26 10:37:24.811908
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None

# Generated at 2022-06-26 10:37:26.220933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:37:27.363502
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert true

# Generated at 2022-06-26 10:37:30.177685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:37:37.131862
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token(end_position=Position(), name="name", start_position=Position(), value="the value")
    var_1 = Field(
        default=None,
        description=None,
        nullable=False,
        required=True,
        validate=None,
        validators=[],
    )
    any_0 = validate_with_positions(token=var_0, validator=var_1)


# Generated at 2022-06-26 10:37:41.546089
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = str('Test text')
    field_0 = Field.__init__(var_0, type='string', pattern='.', max_length=8)
    var_1 = field_0.validate(var_0)
    assert var_1 == var_0


# Generated at 2022-06-26 10:37:44.016546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:37:46.771323
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True
    return



# Generated at 2022-06-26 10:37:58.093911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from itertools import product
    from types import SimpleNamespace
    from typesystem.validators import Integer

    # Test for equality.
    inp = SimpleNamespace(
        token=SimpleNamespace(
            value=123,
            start=(-1, 10),
            end=(-1, 10),
            lookup=lambda x: SimpleNamespace(
                value=123,
                start=(-1, 10),
                end=(-1, 10),
                lookup=lambda x: SimpleNamespace(
                    value=123, start=(-1, 10), end=(-1, 10)
                ),
            ),
        ),
        validator=Integer(),
    )
    expected_outp = 123
    outp = validate_with_positions(**inp.__dict__)
    assert outp == expected_outp

    # Test for

# Generated at 2022-06-26 10:38:07.475519
# Unit test for function validate_with_positions
def test_validate_with_positions():
    f = Field(type="string")
    token = Token("foo")
    assert validate_with_positions(token=token, validator=f) == "foo"

    token = Token("foo")
    f = Field(type="number")
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=f)
    assert exc.value.messages() == [
        Message(
            code="invalid",
            text="Expected a number.",
            index=(),
            start_position=token.start,
            end_position=token.end,
        )
    ]

    token = Token({"foo": "bar"})
    schema = Schema({"foo": Field(type="string")})

# Generated at 2022-06-26 10:40:04.407655
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True

# Generated at 2022-06-26 10:40:09.114656
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None

# Generated at 2022-06-26 10:40:14.214875
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=var_0, validator=var_0) == any_0
    assert validate_with_positions(token=var_1, validator=var_1) == any_1

if __name__ == "__main__":
    import unittest
    unittest.main()

# Generated at 2022-06-26 10:40:25.972525
# Unit test for function validate_with_positions
def test_validate_with_positions():
    arg_0 = None
    with raises(Exception):
        validate_with_positions(token=arg_0, validator=arg_0)

    arg_0 = None
    with raises(Exception):
        validate_with_positions(token=arg_0, validator=arg_0)

    arg_0 = None
    with raises(Exception):
        validate_with_positions(token=arg_0, validator=arg_0)

    arg_0 = None
    with raises(Exception):
        validate_with_positions(token=arg_0, validator=arg_0)

    arg_0 = None
    with raises(Exception):
        validate_with_positions(token=arg_0, validator=arg_0)

# Generated at 2022-06-26 10:40:37.570202
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_1 = Token("flow_mapping", "", "[", 1, 4, 1, 5)

    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)
    assert validate_with_positions(token=var_1, validator=var_1)

# Generated at 2022-06-26 10:40:46.155587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token(
        kind="kind",
        value="value",
        start=Message("start", code="start_code", index=(1, 2)),
        end=Message("end", code="end_code", index=(3, 4)),
    )

    class TestSchema0(Schema):
        # ...
        pass

    var_1 = TestSchema0
    any_0 = validate_with_positions(token=var_0, validator=var_1)

# Generated at 2022-06-26 10:40:54.443744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 == None, f"expected: <None>, actual: {repr(any_0)}"

if __name__ == "__main__":
    test_case_0()
    test_validate_with_positions()