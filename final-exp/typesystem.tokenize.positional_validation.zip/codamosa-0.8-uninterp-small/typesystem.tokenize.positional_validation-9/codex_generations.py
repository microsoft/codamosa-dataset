

# Generated at 2022-06-26 10:31:04.033770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'VVa'
    int_0 = 1626
    token_0 = module_0.Token(str_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=str_0)

# Generated at 2022-06-26 10:31:05.548386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert module_0 is not None
    assert test_case_0 is not None
    assert module_0.Token is not None

    test_case_0()

# Generated at 2022-06-26 10:31:16.034192
# Unit test for function validate_with_positions
def test_validate_with_positions():
    function_name = "validate_with_positions"
    # Run the test for different values for the 'token' argument
    test_cases = [
        {'token': 'token_0', 'validator': 'str_0'},
    ]
    for test_case in test_cases:
        vars()[function_name](**test_case)

# Generated at 2022-06-26 10:31:17.018587
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:19.093584
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

from typesystem.tokenize.tokenizers import BASE_TOKENIZER, TOKEN_MAP


# Generated at 2022-06-26 10:31:24.395282
# Unit test for function validate_with_positions
def test_validate_with_positions():
    ## First example
    str_0 = 'o9e'
    int_0 = -2082
    token_0 = module_0.Token(str_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=str_0)
    
    
    
    
    
    
    
    
    
    
    
    
    pass

# Generated at 2022-06-26 10:31:36.880991
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:31:41.535546
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'o9e'
    int_0 = -2082
    token_0 = module_0.Token(str_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=str_0)
    assert any_0 == str_0

# Generated at 2022-06-26 10:31:45.722363
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        validate_with_positions()
    except TypeError as error:
        assert str(
            error
        ) == "validate_with_positions() missing 2 required positional arguments: 'token' and 'validator'"

# Generated at 2022-06-26 10:31:49.824614
# Unit test for function validate_with_positions
def test_validate_with_positions():

    str_0 = 'o9e'
    int_0 = -2082
    token_0 = module_0.Token(str_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=str_0)


# Generated at 2022-06-26 10:31:59.401966
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:32:03.644615
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    assert isinstance(any_0, int), "Expected type 'int', but got {!r}".format(any_0)

# Generated at 2022-06-26 10:32:04.181647
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:32:05.754432
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # assert False, "Test is not implemented."

    test_case_0()

# Generated at 2022-06-26 10:32:13.695312
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)


if __name__ == '__main__':
    import coverage
    import pytest
    import unittest
    coverage.main()
    pytest.main()
    unittest.main()

# Generated at 2022-06-26 10:32:29.752936
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = validate_with_positions(token=-6694, validator=-6448)
    any_1 = validate_with_positions(token=-7990, validator=-8162)
    any_2 = validate_with_positions(token=-7158, validator=-7298)
    any_3 = validate_with_positions(token=-7170, validator=-7728)
    any_4 = validate_with_positions(token=-7170, validator=-7670)
    any_5 = validate_with_positions(token=-7170, validator=-7358)
    any_6 = validate_with_positions(token=-7170, validator=-7666)

# Generated at 2022-06-26 10:32:30.418749
# Unit test for function validate_with_positions
def test_validate_with_positions():
    return


# Generated at 2022-06-26 10:32:34.996422
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:32:41.364136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import subprocess
    import sys

    subprocess.check_call([sys.executable, "-m", "unittest", "typesystem.tokenize.tokens.test_tokens"])



# Generated at 2022-06-26 10:32:49.085158
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Testing with a validators which raise a ValidationError.

    # Assert that the token start and end positions are assigned to the message
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    try:
        validate_with_positions(token=token_0, validator=int)
    except Exception as exception_0:
        message_0 = exception_0.args[0][0]
        assert message_0.start_position == token_0.start
        assert message_0.end_position == token_0.end

    # Testing with a validators which raise a ValidationError.

    # Assert that the token start and end positions are assigned to the message
    token_0 = module_0.Token(-448, -448, -448)
   

# Generated at 2022-06-26 10:33:02.470654
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    error_0 = False
    try:
        any_0 = validate_with_positions(token=token_0, validator=int_0)
        assert any_0 == int_0
    except ValidationError as error_0:
        assert error_0.messages() == [
            Message(
                text="The field 0 is required.",
                code="required",
                index=[0],
                start_position=int_0,
                end_position=int_0,
            )
        ]

# Generated at 2022-06-26 10:33:11.651417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        int_0 = -3037
        token_0 = module_0.Token(int_0, int_0, int_0)
        any_0 = validate_with_positions(token=token_0, validator=int_0)
    except ValidationError as error:
        messages = [
            module_0.Message(
                text='The field "value" cannot be less than 10.',
                code="minimum",
                index=("value",),
                start_position=module_0.StartPosition(line_no=int_0, char_index=int_0),
                end_position=module_0.EndPosition(line_no=int_0, char_index=int_0),
            )
        ]
        assert error.messages() == messages

# Generated at 2022-06-26 10:33:14.120074
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

if __name__ == '__main__':
    test_validate_with_positions()

# Generated at 2022-06-26 10:33:17.691088
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int = 1
    token = Token(int, int, int)
    validate_with_positions(validator=int, token=token)


import typesystem.tokenize.tokens as module_0


# Generated at 2022-06-26 10:33:20.159037
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("\n##### Begin unit test of function validate_with_positions #####")
    test_case_0()
    print("##### End unit test of function validate_with_positions #####\n")


# Generated at 2022-06-26 10:33:22.632951
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:33:30.236649
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = module_0.Token(0, 0, 0)
    function_0 = validate_with_positions(token=token_0, validator=int)
    expected = 0
    actual = function_0
    assert actual == expected
    token_1 = module_0.Token(0, 0, 0)
    function_1 = validate_with_positions(token=token_1, validator=int)
    expected = 0
    actual = function_1
    assert actual == expected
    token_2 = module_0.Token(0, 0, 0)
    function_2 = validate_with_positions(token=token_2, validator=int)
    expected = 0
    actual = function_2
    assert actual == expected
    token_3 = module_0.Token(0, 0, 0)
   

# Generated at 2022-06-26 10:33:35.204494
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    try:
        validate_with_positions(token=token_0, validator=int_0)
    except ValidationError as e:
        pass


# Generated at 2022-06-26 10:33:44.342648
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Arrange
    # NOTE: it is not possible to specify a `Field` as a type
    # hint. There are to ways to make this work:
    #   1. Use a different decorator (i.e. `typesystem.decorator`)
    #   2. Use `typing.Union[Field, typing.Type[Schema]]`
    #      to explicitly support both.
    token = Token(value=42)
    validator = 42

    # Act
    result = validate_with_positions(validator=validator, token=token)

    # Assert
    assert result == token.value
    assert result == 42

# Generated at 2022-06-26 10:33:52.774191
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = Token("a", 0, 1)
    message = Message("This is a message", code="code")
    field = Field(name="name", validators=[lambda x: message], default="default")
    validator = typing.Type[Schema]()
    # Exercise
    try:
        validate_with_positions(validator=field, token=token)
        raise AssertionError("ValidationError expected")
    except ValidationError as e:
        actual = e.messages()
    # Verify
    assert actual == [message]
    # Cleanup - none necessary

# Generated at 2022-06-26 10:34:01.344294
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

import typesystem.tokenize.tokens as module_1


# Generated at 2022-06-26 10:34:13.004296
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema0(Schema):
        field02 = int()

    class Schema1(Schema):
        field11 = str()

    class Schema2(Schema):
        field20 = str()

    class Schema3(Schema):
        field30 = Schema0()

    class Schema4(Schema):
        field40 = Schema2()

    class Schema5(Schema):
        field51 = Schema1()

    class Schema6(Schema):
        field60 = Schema3()

    class Schema7(Schema):
        field70 = Schema4()

    class Schema8(Schema):
        field80 = Schema1()

    class Schema9(Schema):
        field91 = Schema6()

    class Schema10(Schema):
        field100 = Sche

# Generated at 2022-06-26 10:34:16.594588
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 120
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:34:22.300210
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class MySchema(Schema):
        a = int
    token = MySchema.token({"a": 5})
    value = validate_with_positions(token=token, validator=MySchema)
    assert value == {"a": 5}



# Generated at 2022-06-26 10:34:34.027017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

    int_1 = 5
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)

    int_2 = -1
    token_2 = module_0.Token(int_2, int_2, int_2)
    any_2 = validate_with_positions(token=token_2, validator=int_2)

    int_3 = 2

# Generated at 2022-06-26 10:34:37.849525
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:34:38.883365
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:34:42.181422
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    assert any_0 is None

# Generated at 2022-06-26 10:34:44.657866
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:34:52.921780
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Check for call of function validate_with_positions
    test_case_0()
    try:
        int_0 = -4187
        token_0 = module_0.Token(int_0, int_0, int_0)
        any_0 = validate_with_positions(token=token_0, validator=int_0)
    except TypeError:
        assert True
    else:
        assert False

# Generated at 2022-06-26 10:34:59.456393
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # AssertionError: int_0 != field_0
    # AssertionError: token_0 != token_1
    # AssertionError: any_0 != value_0
    pass

# Generated at 2022-06-26 10:35:03.266424
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = ""
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:35:05.091196
# Unit test for function validate_with_positions
def test_validate_with_positions():
    module_0
    test_case_0()


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:35:07.746114
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: Implement tests
    # validate_with_positions(token=token_0, validator=int_0)
    assert True

import typesystem.tokenize.tokenize as module_1


# Generated at 2022-06-26 10:35:20.794460
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Check that validate_with_positions() raises TypeError when no arguments are supplied
    with pytest.raises(TypeError):
        validate_with_positions()
    # Check that validate_with_positions() raises ValueError when too many arguments are supplied
    with pytest.raises(TypeError):
        validate_with_positions(token=int(), validator=int(), extra=int())
    # Check that validate_with_positions() raises TypeError when an invalid argument type is supplied
    with pytest.raises(TypeError):
        validate_with_positions(token=None, validator=int())
    # Check that validate_with_positions() raises TypeError when an invalid argument type is supplied
    with pytest.raises(TypeError):
        validate_with_positions(token=int(), validator=None)

# Generated at 2022-06-26 10:35:21.347760
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:35:22.962388
# Unit test for function validate_with_positions
def test_validate_with_positions():
    
    assert (test_case_0() == None), "test_case_0"

# Generated at 2022-06-26 10:35:25.499068
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -3484
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:35:27.923429
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    validate_with_positions(token=token_0, validator=int_0)


# Generated at 2022-06-26 10:35:28.699402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 + 1 == 2
    assert False

# Generated at 2022-06-26 10:35:37.433894
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:35:41.978078
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validate_with_positions(token=module_0.Token(-1, -1, -1), validator=module_0.Token(-1, -1, -1))

# vim: et:ts=4:sw=4:tw=79

# Generated at 2022-06-26 10:35:51.176939
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

    int_1 = 4520
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)

    str_0 = str(-5516)
    token_2 = module_0.Token(str_0, str_0, str_0)
    any_2 = validate_with_positions(token=token_2, validator=str_0)

    float_0 = float(2624)
    token_3 = module_0.Token

# Generated at 2022-06-26 10:36:02.593233
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 100
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    int_1 = -100
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)
    int_2 = 0
    token_2 = module_0.Token(int_2, int_2, int_2)
    any_2 = validate_with_positions(token=token_2, validator=int_2)
    set_0 = set()

# Generated at 2022-06-26 10:36:14.705217
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    int_1 = -4187
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)
    int_2 = -4187
    token_2 = module_0.Token(int_2, int_2, int_2)
    any_2 = validate_with_positions(token=token_2, validator=int_2)
    int_3 = -4187

# Generated at 2022-06-26 10:36:20.709754
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class_name, method_name = validate_with_positions.__qualname__.split(".")
    module_name = validate_with_positions.__module__
    print(f"Testing {module_name}.{class_name}.{method_name}")

    test_cases = [
        test_case_0
    ]
    for test_case in test_cases:
        test_case()

# Generated at 2022-06-26 10:36:27.304061
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # int_0 = -4187
    # token_0 = module_0.Token(int_0, int_0, int_0)
    # any_0 = validate_with_positions(token=token_0, validator=int_0)

    assert None

# Generated at 2022-06-26 10:36:31.848451
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_1 = -4187
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)

# Generated at 2022-06-26 10:36:38.319136
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.tokens as module_0
    int_0 = -4187
    string_0 = ":zX|"
    token_0 = module_0.Token(int_0, int_0, int_0)
    try:
        validate_with_positions(token=token_0, validator=string_0)
    except ValidationError as error_0:
        messages_0 = error_0.messages()
        string_1 = "Got type {} for value {}".format(type(int_0).__name__, int_0)
        message_0 = type(messages_0[0])
        assert message_0 is Message
        string_2 = messages_0[0].text()
        assert string_1 == string_2


# Generated at 2022-06-26 10:36:42.118492
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:36:57.406553
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test assignment
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    # Test function call
    test_case_0()



# Generated at 2022-06-26 10:36:58.600748
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:37:05.470413
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 8
    bool_0 = True
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=bool_0)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-26 10:37:09.601361
# Unit test for function validate_with_positions
def test_validate_with_positions():
    string_0 = "string_0"
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=string_0)

# Generated at 2022-06-26 10:37:18.698982
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:37:20.699205
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:37:28.633022
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem import String
    from typesystem.tokenize import Token

    field = String(min_length=10, max_length=20)
    token = Token.from_string("hello world", start=0)
    with pytest.raises(ValidationError) as exc:
        validate_with_positions(token=token, validator=field)
    assert (
        exc.value.messages[0].text
        == "Must be greater than or equal to 10 characters long."
    )
    assert exc.value.messages[0].start_position.line == 0
    assert exc.value.messages[0].start_position.column == 0


import typesystem.tokenize.tokens as module_1


# Generated at 2022-06-26 10:37:33.618867
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

# Generated at 2022-06-26 10:37:39.322402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def int_0(value):
        return value

    token_0 = Token(value='{"test": "asdf"}', start=0, end=14)
    int_1 = {}.get('asdf')
    any_0 = validate_with_positions(token=token_0, validator=int_1)
    int_2 = int
    any_1 = validate_with_positions(token=token_0, validator=int_2)

# Generated at 2022-06-26 10:37:53.385163
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typesystem.fields
    import typesystem.tokenize.tokens

    class Validator(typesystem.fields.Field):
        def __init__(self, start: int, end: int):
            self.start = start
            self.end = end

        def validate(self, value: typing.Any) -> typing.Any:
            token = typesystem.tokenize.tokens.Token(
                value, self.start, self.end
            )
            return validate_with_positions(token=token, validator=self)

    validator = Validator(1, 2)
    try:
        validator.validate("failure")
        assert False, "Did not raise ValidationError"
    except ValidationError as error:
        assert error
    assert error.messages()

# Generated at 2022-06-26 10:38:15.229082
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_1 = -4187
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=int_1)

# Generated at 2022-06-26 10:38:24.627897
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)
    str_0 = "I'm not a valid integer!"
    token_1 = module_0.Token(str_0, str_0, str_0)
    with pytest.raises(ValueError) as info_0:
        validate_with_positions(token=token_1, validator=int_0)
    str_1 = "invalid literal for int() with base 10"
    assert (
        str_1 == info_0.value.args[0]
    )  # assert 'invalid literal for int() with base 10' == info_0.value.args[0

# Generated at 2022-06-26 10:38:27.434528
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    any_0: typing.Any = validate_with_positions(token=module_0.Token(int_0, int_0, int_0), validator=int_0)
    return

# Generated at 2022-06-26 10:38:31.171041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.tokens as module_0
    int_0 = -4187
    token_0 = module_0.Token(int_0, int_0, int_0)
    with pytest.raises(Exception) as exception_0:
        any_0 = validate_with_positions(token=token_0, validator=int_0)

import typesystem.fields as module_0


# Generated at 2022-06-26 10:38:35.603402
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test TypeError raised by the function.
    try:
        validate_with_positions(token=None, validator=None)
    except TypeError:
        # TypeError raised as expected.
        pass
    else:
        # TypeError not raised as expected.
        assert False

# Generated at 2022-06-26 10:38:40.364913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -4187
    token_0 = Token(value=int_0, start=int_0, end=int_0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)


call_function_and_store_exception(test_validate_with_positions)
call_function_and_store_exception(test_case_0)

unreachable()

# Generated at 2022-06-26 10:38:52.839113
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_cases = [
        {
            "name": "test_case_0",
            "params": {
                "token": module_0.Token(-4187, -4187, -4187),
                "validator": -4187,
            },
            "exception": None,
        },
    ]
    for test_case in test_cases:
        try:
            if test_case["exception"]:
                with pytest.raises(test_case["exception"]):
                    validate_with_positions(**test_case["params"])
            else:
                validate_with_positions(**test_case["params"])
        except Exception as exception:
            print(f"FAIL: test_validate_with_positions_{test_case['name']}")

# Generated at 2022-06-26 10:38:53.801182
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:39:03.865729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import faker # type: ignore
    import pytest # type: ignore

    from typesystem.tokenize.tokens import Token

    sample_data_0 = faker.Faker().pystr()
    token_0 = Token(sample_data_0, 0, len(sample_data_0))

    sample_data_1 = faker.Faker().pystr()
    token_1 = Token(sample_data_1, 0, len(sample_data_1))

    sample_data_2 = faker.Faker().pystr()
    token_2 = Token(sample_data_2, 0, len(sample_data_2))

    sample_data_3 = faker.Faker().pystr()
    token_3 = Token(sample_data_3, 0, len(sample_data_3))

# Generated at 2022-06-26 10:39:12.481394
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    int_0 = typesystem.Integer()
    token_0 = typesystem.tokenize.tokens.Token("example", 0, 0)
    any_0 = validate_with_positions(token=token_0, validator=int_0)

    str_0 = typesystem.String(max_length=0)
    token_1 = typesystem.tokenize.tokens.Token("example", 0, 0)
    any_1 = validate_with_positions(token=token_1, validator=str_0)


# Generated at 2022-06-26 10:39:36.100435
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token(
        value={"name": "name"},
        start=Position(line_number=1, character_number=1, char_index=0),
        end=Position(line_number=1, character_number=7, char_index=6),
    )
    var_1 = class_call(class_name="Schema", value=("name",))
    var_2 = None
    any_0 = validate_with_positions(token=var_0, validator=var_2)

# Generated at 2022-06-26 10:39:43.008460
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = Object()
    any_0.value = 10
    any_0.type = int
    any_0.start = (1, 2)
    any_0.end = (1, 4)
    var_0 = any_0  # type: ignore
    any_1 = validate_with_positions(token=var_0, validator=Field(type=str))


# Generated at 2022-06-26 10:39:44.841014
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=1, validator=1) is None

# Generated at 2022-06-26 10:39:52.314256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    foo = Field(required=True)
    schema = Schema(foo=foo)
    assert schema.validate({"foo": "bar"}) == {"foo": "bar"}
    with pytest.raises(ValidationError) as error_info:
        schema.validate({"bar": "baz"})
    assert (
        str(error_info.value)
        == "[{'code': 'required', 'field': 'foo', 'text': 'The field \'foo\' is required.'}]"
    )

# Generated at 2022-06-26 10:39:58.145150
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:40:01.677351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    arg_0 = None

    # Call function
    result = validate_with_positions(token=arg_0, validator=arg_0)

# Generated at 2022-06-26 10:40:02.340901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:40:08.037549
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:40:08.798825
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    assert validate_with_positions(token=var_0, validator=var_0) is None



# Generated at 2022-06-26 10:40:12.739346
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == True
    assert True == True


if __name__ == "__main__":
    test_case_0()
    test_validate_with_positions()

# Generated at 2022-06-26 10:40:40.522838
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Make sure the error message is correct
    # Create a token
    token = Token(value=True, start="(1, 1)", end="(1, 5)")
    try:
        # Pass the token to a Field
        validate_with_positions(token=token, validator=Field(type=str))
        assert False
    except ValidationError as error:
        assert (
            error.messages[0].text
            == "Invalid type for field (expected str, got bool)."
        )
        assert error.messages[0].code == "type_error"
        assert error.messages[0].start_position == token.start



# Generated at 2022-06-26 10:40:42.687353
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:40:49.980721
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import inspect
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.text import Text

    cases = [
        {"name": "0", "input": {"token": None, "validator": None}},
    ]

    for case in cases:
        actual = eval(f"validate_with_positions(**{case['input']!r})")
        print("PASS" if actual == case['output'] else "FAIL", case['name'])


if __name__ == "__main__":
    import sys
    import pytest

    errored = False

# Generated at 2022-06-26 10:40:52.302680
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None



# Generated at 2022-06-26 10:40:58.218812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = Token(value=var_0)
    var_8 = Field(name=var_0)
    var_2 = validate_with_positions(token=var_0, validator=var_0)
    var_3 = validate_with_positions(token=var_1, validator=var_8)
    if (__name__ == "__main__"):
        test_case_0()