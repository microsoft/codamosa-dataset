

# Generated at 2022-06-26 10:31:03.277068
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=('Something',), start=(1, 2), end=(1, 10))
    dict_0 = {token_0: token_0}
    any_0 = validate_with_positions(token=token_0, validator=dict_0)


# Generated at 2022-06-26 10:31:04.963485
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == '' or any_0 == "{\n    'foo': 'bar'\n}"


# Generated at 2022-06-26 10:31:09.210417
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    test_data = [
        (
            (
                # None
                ("foo", {"foo": int}, 1),
                (42, {"foo": int}, 1),
            ),
            3,
        ),
    ]

    @pytest.mark.parametrize("data, expected", test_data)
    def test_something(data, expected):
        assert expected == validate_with_positions(**data)

    test_something()

# Generated at 2022-06-26 10:31:12.089766
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == any_1

# Generated at 2022-06-26 10:31:17.998816
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    dict_0 = {token_0: token_0}
    any_0 = validate_with_positions(token=token_0, validator=dict_0)


if __name__ == '__main__':
    import sys
    import logging
    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    test_case_0()
    test_validate_with_positions()

# Generated at 2022-06-26 10:31:19.305162
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test for function validate_with_positions, case 0
    test_case_0()

# Generated at 2022-06-26 10:31:22.366177
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    dict_0 = {token_0: token_0}
    with pytest.raises(AssertionError):
        any_0 = validate_with_positions(token=token_0, validator=dict_0)


# Generated at 2022-06-26 10:31:28.584640
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token.tokenize({"foo": [{"bar": 1}, {"baz": 2}]})
    dict_0 = Field(type=list, items=Schema({"bar": int, "baz": int}))
    any_0 = validate_with_positions(token=token_0, validator=dict_0)



# Generated at 2022-06-26 10:31:34.850724
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(name_0='f', value_0=token_2, start_0=(1, 1), end_0=(2, 2))
    dict_0 = {token_0: token_0}
    any_0 = validate_with_positions(token=token_0, validator=dict_0)
    assert any_0 == 'f'
    assert True

# Generated at 2022-06-26 10:31:42.915811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    dict_0 = {token_0: token_0}
    stmt_0 = validate_with_positions(token=token_0, validator=dict_0)
    stmt_1 = validate_with_positions(token=token_0, validator=dict_0)
    stmt_2 = validate_with_positions(token=token_0, validator=dict_0)
    stmt_3 = validate_with_positions(token=token_0, validator=dict_0)


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:31:51.262156
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(value={'foo': True}, start={'line': 1, 'column': 1, 'char_index': 0}, end={'line': 11, 'column': 1, 'char_index': 10})
    field = Field(type=str, required=True)
    value = validate_with_positions(token=token, validator=field)
    assert value is None


# Generated at 2022-06-26 10:31:53.790668
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import sys

    # Assert: Call validate_with_positions and check the type of the return value
    token_0 = Token()
    field_0 = Field(name=None)
    try:
        sys.modules[__name__].validate_with_positions(token=token_0, validator=field_0)
    except Exception:
        pass



# Generated at 2022-06-26 10:31:54.592366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:32:04.216239
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value="foo", start=(1, 2), end=(1, 4))

    class FooSchema(Schema):
        baz = int

    foo = FooSchema()

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token_0, validator=foo)

    assert exc_info.value.messages == [
        Message(
            text="The field 'baz' is required.",
            code="required",
            index=("baz",),
            start_position=token_0.end,
            end_position=token_0.end,
        )
    ]

# Generated at 2022-06-26 10:32:16.450055
# Unit test for function validate_with_positions
def test_validate_with_positions():
    func_name = 'validate_with_positions'
    func = globals().get(func_name)
    if func is None:
        raise Exception(f"Function {func_name!r} does not exists.")


# Generated at 2022-06-26 10:32:19.607612
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:32:26.160598
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    dict_0 = {token_0: token_0}
    any_0 = validate_with_positions(token=token_0, validator=dict_0)
    assert any_0 is None


if "__main__" == __name__:
    import unittest

    unittest.main()

# Generated at 2022-06-26 10:32:29.577141
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: consider setting any_0 and any_1 to None
    any_0 = type(lambda: None)  # type: ignore
    any_1 = type(lambda: None)  # type: ignore
    validate_with_positions(token=any_0, validator=any_1)

# Generated at 2022-06-26 10:32:39.534077
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_x = Token(value=34, start=";sdfs;", end=";sdfs;")
    dict_x = {token_x: token_x}
    any_x = validate_with_positions(token=token_x, validator=dict_x)
    any_x = validate_with_positions(token=token_x, validator=dict_x)



# Generated at 2022-06-26 10:32:48.222045
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from collections import (
        namedtuple as namedtuple_0,
        OrderedDict as OrderedDict_0,
        defaultdict as defaultdict_1,
        deque as deque_0,
    )
    from typing import Any, DefaultDict, List, NamedTuple, Optional, overload, Tuple
    from typesystem.base import Field, Message, ValidationError
    from typesystem.tokenize.tokens import Token
    import typesystem.tokenize.tokens as tokens
    import typesystem.tokenize.tokenize as tokenize
    from typesystem.fields import Any as Any_0, Dict as Dict_0
    import typesystem.fields as fields
    from typesystem.schemas import Schema as Schema_0
    from typesystem import error_messages
    from . import language
   

# Generated at 2022-06-26 10:32:54.515403
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This will raise an exception if there is an error in
    # validate_with_positions.
    test_case_0()

# Generated at 2022-06-26 10:32:58.103770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is None



# Generated at 2022-06-26 10:33:05.330989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem import types
    import unittest

    class TestValidateWithPositions(unittest.TestCase):

        def test_case_0(self):
            var_0 = Token("Foo")
            var_0.start = None

            class TestSchema(Schema):
                foo = Field(type=types.String, required=True)

            self.assertRaises(
                ValidationError, 
                validate_with_positions, token=var_0, validator=TestSchema
            )


if __name__ == '__main__':
    import sys

# Generated at 2022-06-26 10:33:06.610336
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token("", "", 0, 0)
    # End of unit test

# Generated at 2022-06-26 10:33:10.819683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = Token.from_text(definition=var_0, text="")
    var_2 = validate_with_positions(
        token=var_1, validator=var_1
    )  # token=var_1, validator=var_1

# Generated at 2022-06-26 10:33:12.146010
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:33:13.320729
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True == (True)

# Generated at 2022-06-26 10:33:14.684751
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=None, validator=None) == None

# Generated at 2022-06-26 10:33:15.784069
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:33:22.024630
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    any_1 = None
    token = Token(any_0, any_1, any_0, any_1)
    assert validate_with_positions(token=token, validator=None) is None
    assert (
        validate_with_positions(token=token, validator=Field(type=str)) is None
    )


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:33:31.498103
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:33:34.411286
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:33:37.613462
# Unit test for function validate_with_positions
def test_validate_with_positions():
    x = Token(value="foo")
    assert validate_with_positions(token=x, validator=Field(name="x", type=str)) == "foo"

# Generated at 2022-06-26 10:33:43.274611
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False, "TODO: Write unit test for function validate_with_positions"

# Generated at 2022-06-26 10:33:46.073970
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    return any_0

# Generated at 2022-06-26 10:33:53.648064
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

    any_0 = var_0.root

    var_1 = var_0.lookup([])
    any_1 = validate_with_positions(token=var_0, validator=var_1)

    var_2 = var_0.lookup(["a"])
    any_2 = validate_with_positions(token=var_0, validator=var_2)



# Generated at 2022-06-26 10:34:05.705793
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3: typing.Any = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    try:
        var_0 = validate_with_positions(token="hello", validator=int)
    except ValidationError as exc:
        var_1 = exc
    try:
        var_2 = validate_with_positions(token=b"hello", validator=int)
    except ValidationError as exc:
        var_3 = exc
    try:
        var_4 = validate_with_positions(token="hi", validator=float)
    except ValidationError as exc:
        var_5 = exc

# Generated at 2022-06-26 10:34:08.456495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Test validate_with_positions")

    test_case_0()
    return


# Unit tests for this module

# Generated at 2022-06-26 10:34:11.596351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Tests that an exception is thrown when an invalid Token is supplied.
    with pytest.raises(exceptions.TokenError):
        validate_with_positions(token=None, validator=Field(typ="integer"))

# Generated at 2022-06-26 10:34:12.232930
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert var_0 == var_0

# Generated at 2022-06-26 10:34:27.681065
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:34:33.733532
# Unit test for function validate_with_positions
def test_validate_with_positions():
    cases = [
        0,
    ]

    for case in cases:
        yield test_case_0, case


if __name__ == "__main__":
    import logging
    import sys

    logging.basicConfig(stream=sys.stderr, level=logging.DEBUG)
    for test_func, case in test_validate_with_positions():
        test_func(case)

# Generated at 2022-06-26 10:34:43.411140
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import Parser
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.scanner import Scanner
    from typesystem.exceptions import ValidationError
    from typesystem.schemas import Schema
    from typesystem.entities import Integer

    class Root(Schema):
        foo = Integer()

    text = "  foo: 123"
    scanner = Scanner(text=text)
    parser = Parser(scanner)
    root = Root()
    token = parser.parse()
    root.validate(token.as_data())
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=root)
    token = token.lookup(["foo"])

# Generated at 2022-06-26 10:34:56.587759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    try:
        any_0 = validate_with_positions(token=var_0, validator=var_1)
    except ValidationError as error:
        assert error.messages() == [
            Message(text="The field 'name' is required.", code="required", index=["name",])
        ]
    else:
        raise AssertionError()

# Generated at 2022-06-26 10:34:58.559121
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:35:01.433796
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = Token("foo", 1)
    any_0 = validate_with_positions(token=var_0, validator=var_0)



# Generated at 2022-06-26 10:35:07.357568
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    schema = Schema(fields={
        "foo": Field(required=True),
        "bar": Field(required=True)
    })
    token = Token.from_object({"foo": "bar"})
    with raises(ValidationError) as error:
        any_0 = validate_with_positions(token=token, validator=schema)
    messages = error.value.messages()
    assert messages == [
        Message(code="required", index=("bar",), text="The field 'bar' is required.")
    ]



# Generated at 2022-06-26 10:35:11.992158
# Unit test for function validate_with_positions
def test_validate_with_positions():

    var_0 = None

    def raises_exception(function):
        try:
            function()
            return False
        except:
            return True
        return False

    assert test_case_0(var_0) == raises_exception(test_case_0)

# Generated at 2022-06-26 10:35:24.124509
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    import typing
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Field
    from typesystem.schemas import Schema

    # Define a mock for the token type.
    class TokenMock:
        name = "TokenMock"
        start = 0
        end = 0

        @staticmethod
        def lookup(index: typing.List[str]) -> TokenMock:
            return TokenMock()

    # Define a mock for the schema type.
    class SchemaMock(Schema):
        pass

    # Define a mock for the field type.
    class FieldMock(Field):
        pass

    var_0 = TokenMock()
    var_1 = SchemaMock()
    var_2 = FieldMock()


# Generated at 2022-06-26 10:35:25.001188
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass


# Generated at 2022-06-26 10:35:55.502186
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = "foobar"
    var_1 = validate_with_positions(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:35:56.641500
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert_equals(test_case_0(), None)

# Generated at 2022-06-26 10:36:02.627795
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_1 = Token(
        "",
        value={
            "type": "type_reference",
            "value": "type_reference",
            "properties": {"properties": [("name", {})]},
        },
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=27, char_index=26),
    )
    # Asserts that the TypeSystemError has the expected messages and line
    # numbers

# Generated at 2022-06-26 10:36:05.510151
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is None
    assert_type(any_0, type(None))
    assert any_0 is None


# Generated at 2022-06-26 10:36:08.344167
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:36:11.993309
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == None



# Generated at 2022-06-26 10:36:14.955901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    pass

    # Exercise
    result = validate_with_positions()

    # Assert
    assert result

    # Teardown
    pass

# Generated at 2022-06-26 10:36:20.599133
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    any_0 = validate_with_positions(token=var_0, validator=var_1)
    assert_equal(any_0, None)
    assert_equal(var_0, None)
    assert_equal(var_1, None)
    assert_equal(any_0, None)

# Generated at 2022-06-26 10:36:22.739399
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate == validate_with_positions
    assert validate_with_positions == validate_with_positions

# Generated at 2022-06-26 10:36:24.408989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert None is validate_with_positions(token=None, validator=None)



# Generated at 2022-06-26 10:37:03.179269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import unittest
    try:
        from unittest.mock import MagicMock, patch
    except ImportError:
        from mock import MagicMock, patch

    class TestValidateWithPositions(unittest.TestCase):
        @patch('test_validate_with_positions.validate_with_positions')
        def test_0(self, mock_validate_with_positions):
            var_0 = None
            var_0 = validate_with_positions(token=var_0, validator=var_0)
            mock_validate_with_positions.assert_called_with(token=var_0, validator=var_0)

# Generated at 2022-06-26 10:37:12.025641
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = True
    var_1 = True
    if var_0:
        var_1 = True
    var_2 = True
    if var_1:
        var_2 = True
    var_3 = True
    if var_2:
        var_3 = True
    var_4 = True
    if var_3:
        var_4 = True
    var_5 = True
    if var_4:
        var_5 = True
    var_6 = False
    if var_5:
        var_6 = True
    var_7 = False
    if var_6:
        var_7 = True
    var_8 = None
    var_9 = None
    var_10 = None
    var_11 = None
    var_12 = None
    var_13 = None
    var_

# Generated at 2022-06-26 10:37:23.841257
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test: Error cases
    # Test: Error cases: Empty sequence
    assert (
        validate_with_positions(
            token=typesystem.tokenize.tokens.Sequence([], (0, 0, 0), (0, 0, 0)),
            validator=typesystem.fields.List(of=typesystem.fields.Integer()),
        )
        == []
    )
    # Test: Error cases: List with extra items

# Generated at 2022-06-26 10:37:28.785491
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)



# Generated at 2022-06-26 10:37:29.999687
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False


# Generated at 2022-06-26 10:37:33.564869
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=Token(value=5), validator=Field(type=int)) == 5



# Generated at 2022-06-26 10:37:42.556605
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # To save the JSON file as an object, so that we can
    # rehydrate the object later.

    # The following two lines of code will help us to
    # get the path of the current file.
    # Basically, __file__ is a magic variable that will store
    # the path of the current file.
    file = pathlib.Path(__file__).resolve()
    parent = file.parent

    # Let's save the json to current directory.
    json_filename = parent / "validate_with_positions.json"

    # To read the existing json file.
    if json_filename.exists():
        with json_filename.open("r") as file_handler:
            data = json.load(file_handler)
    else:
        data = {}

    var_0 = None

# Generated at 2022-06-26 10:37:55.870674
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Set up mock object
    class mock_token:
        def __init__(self):
            self.value = None
            self.lookup = None
            self.start = None
            self.end = None
            self.code = None
            self.text = None
            self.index = None
            self.start_position = None
            self.end_position = None

        def __eq__(self, other):
            return True

    class mock_ValidationError:
        def __init__(self):
            self.messages = None
            self.index = None
            self.start_position = None
            self.end_position = None
            self.code = None
            self.message = None
            self.text = None

        def __eq__(self, other):
            return True

    token = mock_token

# Generated at 2022-06-26 10:38:02.245127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = {'index': [], 'start': {'line': 0, 'column': 0, 'char_index': 0}, 'end': {'line': 0, 'column': 0, 'char_index': 0}, 'value': None}
    var_0 = var_0
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert (any_0 == None)

# Test that the function validates required fields

# Generated at 2022-06-26 10:38:02.764934
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:39:24.190040
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Stub: min_value=(number)
    # Stub: max_length=(number)
    # Stub: description=(string)
    # Stub: max_value=(number)
    var_0 = None
    # Stub: format=(string)
    # Stub: required=(boolean)
    # Stub: title=(string)
    # Stub: child_validators=[(type)]
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    # Stub: value=(any)
    # Stub: start_position=(Position)
    # Stub: end_position=(Position)
    # Stub: text=(string)
    # Stub: code=(string)
    # Stub: index=[(string)]
    var_1 = any_0
    var_2 = var_1
    var_1 = var

# Generated at 2022-06-26 10:39:26.745346
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=None, validator=None) == None


# Generated at 2022-06-26 10:39:29.431773
# Unit test for function validate_with_positions
def test_validate_with_positions():
    x = validate_with_positions(token=Token(), validator=Field())
    assert x == x

# Generated at 2022-06-26 10:39:31.846608
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    any_0 = validate_with_positions(token = var_0, validator = var_1)

# Generated at 2022-06-26 10:39:35.736747
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    assert any_0 is None

# Generated at 2022-06-26 10:39:39.874388
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    validate_with_positions(token=var_0, validator=var_0)
    assert var_0



# Generated at 2022-06-26 10:39:47.027079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = "test"
    var_2 = 12
    var_3 = 12.5
    var_4 = True
    var_5 = False
    var_6 = []
    var_7 = [1, 2, 3]
    var_8 = ["foo", "bar", "baz"]
    var_9 = {"foo": "bar", "baz": "qux"}
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    any_1 = validate_with_positions(token=var_1, validator=var_1)
    any_2 = validate_with_positions(token=var_2, validator=var_2)

# Generated at 2022-06-26 10:39:55.233098
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    var_1 = None
    var_2 = None
    var_3 = None
    var_4 = None
    var_5 = None
    var_6 = None
    var_7 = None
    var_8 = None
    var_9 = None
    var_10 = None
    any_0 = validate_with_positions(token=var_0, validator=var_0)
    any_1 = validate_with_positions(token=var_1, validator=var_1)
    any_2 = validate_with_positions(token=var_2, validator=var_2)
    any_3 = validate_with_positions(token=var_3, validator=var_3)

# Generated at 2022-06-26 10:39:58.334246
# Unit test for function validate_with_positions
def test_validate_with_positions():
    var_0 = None
    assert validate_with_positions(token=var_0, validator=var_0) == None

# Generated at 2022-06-26 10:40:00.835944
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions() == None
# unit_tests:end