

# Generated at 2022-06-26 10:31:09.156341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    token_1 = None
    token_2 = None
    token_3 = None
    token_4 = None
    token_5 = None
    token_6 = None
    token_7 = None
    token_8 = None
    token_9 = None
    token_10 = None
    token_11 = None
    token_12 = None
    token_13 = None
    token_14 = None
    token_15 = None
    token_16 = None
    token_17 = None
    token_18 = None
    token_19 = None
    token_20 = None
    token_21 = None
    token_22 = None
    token_23 = None
    token_24 = None

    validate_with_positions(token=token_0, validator=token_1)
    validate

# Generated at 2022-06-26 10:31:12.087638
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:31:12.902551
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert False

# Generated at 2022-06-26 10:31:16.928611
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        start=None,
        end=None,
        value=None,
        type="end-of-file",
        lookup=None,
    )
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:31:18.249137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:29.083240
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    try:
        any_0 = validate_with_positions(token=token_0, validator=token_0)
        assert False
    except ValidationError:
        pass
    try:
        token_1 = Token()
        any_1 = validate_with_positions(token=token_1, validator=token_1)
        assert False
    except ValidationError:
        pass
    try:
        token_2 = Token()
        any_2 = validate_with_positions(token=token_2, validator=token_2)
        assert False
    except ValidationError:
        pass

# Generated at 2022-06-26 10:31:31.192292
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=token_0, validator=token_0) is any_0

# Generated at 2022-06-26 10:31:42.447561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=token_0, start=token_0, end=token_0, index=token_0)

    any_0 = validate_with_positions(token=token_0, validator=token_0)

    any_1 = validate_with_positions(token=token_0, validator=token_0)

    any_2 = validate_with_positions(token=token_0, validator=token_0)

    any_3 = validate_with_positions(token=token_0, validator=token_0)

    any_4 = validate_with_positions(token=token_0, validator=token_0)

    any_5 = validate_with_positions(token=token_0, validator=token_0)

    any_6 = validate_with_positions

# Generated at 2022-06-26 10:31:45.089513
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:31:55.346627
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert validate_with_positions(token=token_0, validator=token_0)
    assert token_0.start == LineInfo(line=1, column=6, char_index=5)
    assert token_0.value == {'hello': 'world'}
    assert token_0.end == LineInfo(line=1, column=25, char_index=24)

    assert validate_with_positions(token=token_1, validator=token_1)
    assert token_1.start == LineInfo(line=1, column=6, char_index=5)
    assert token_1.value == {'hello': 'world'}
    assert token_1.end == LineInfo(line=1, column=25, char_index=24)


# Generated at 2022-06-26 10:31:59.898770
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:32:05.633555
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema_0(Schema):
        name = Field(type=str)

    token_0 = Token(
        type_name="object", name="", start=(0, 0), end=(0, 0), value={"name": "asdf"}
    )
    any_0 = validate_with_positions(token=token_0, validator=Schema_0)


##

# Generated at 2022-06-26 10:32:07.658362
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with raises(ValidationError):
        test_case_0()

# Generated at 2022-06-26 10:32:16.067339
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        print("\n########## test_validate_with_positions ##########\n")
        test_case_0()
        print("test case 0 passed")
    except ValidationError as error:
        for message in error.messages():
            print(message)
        raise error
    except Exception as error:
        print("exception: %s" % str(error))
        raise error
    print("testing completed")

if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:32:27.107681
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        type=1,
        name="_",
        value=1,
        start=1,
        end=1,
        lookup=None,
        tokens=None,
    )

    validator = Field(required=True, type="string")

    try:
        any_0 = validate_with_positions(token=token, validator=validator)
    except ValidationError as error:
        assert error.messages()[0].text == "The field value is required."

# Generated at 2022-06-26 10:32:42.402600
# Unit test for function validate_with_positions
def test_validate_with_positions():
    validator = Token(
        "person",
        {
            "name": {"first": "John", "last": "Doe"},
            "age": "28",
            "address": {
                "street_address": "21 2nd Street",
                "city": "New York",
                "state": "NY",
                "postal_code": "10021",
            },
        },
        start=(1, 1, 1),
        end=(1, 1, 1),
    )
    assert validate_with_positions(
        token=validator, validator=validator
    ) == validator.value

# Generated at 2022-06-26 10:32:45.246308
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True  # TODO: implement your test here

test_validate_with_positions()

# Generated at 2022-06-26 10:32:45.862576
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:32:55.212148
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:32:58.018594
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=token_0, validator=token_0) == any_0

# Generated at 2022-06-26 10:33:09.796009
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    validator = Schema()

    # Assertion pre-conditions
    assert True

    # Exercise
    result = validate_with_positions(token=token_0, validator=validator)

    # Verify
    assert result == None

    # Cleanup - none necessary


# Generated at 2022-06-26 10:33:14.673920
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Skip test
    if True:
        return

    # Arg 1:
    token_1 = None

    # Arg 2:
    validator_2 = None

    any_0 = validate_with_positions(token=token_1, validator=validator_2)

# Generated at 2022-06-26 10:33:17.515351
# Unit test for function validate_with_positions
def test_validate_with_positions():
    error = None

    try:
        validate_with_positions
    except Exception as exc:
        error = exc

    assert error is None

# Generated at 2022-06-26 10:33:26.255273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token = Token(value=None, start=0, end=10, raw=None, parse=None)
    field = Field(validators=[])

    # Exercise
    with pytest.raises(ValidationError) as error:
        validate_with_positions(token=token, validator=field)

    # Verify
    assert len(error.value.messages) == 1
    message = error.value.messages[0]
    assert message.code == "required"
    assert message.index == []
    assert message.text == "This field is required."
    assert message.start_position.line_number == 1
    assert message.start_position.column_number == 1
    assert message.end_position.line_number == 1
    assert message.end_position.column_number == 11

# Generated at 2022-06-26 10:33:28.007097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)
    assert validate_with_positions(token=None, validator=None) is None

# Generated at 2022-06-26 10:33:30.453222
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == None

# Generated at 2022-06-26 10:33:43.200807
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=None, type=None)
    token_1 = Token(value=None, type=None)
    integer_0 = Field(validators=[])
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    any_2 = validate_with_positions(token=token_0, validator=integer_0)
    any_3 = validate_with_positions(token=token_1, validator=integer_0)

# Generated at 2022-06-26 10:33:47.212664
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token()
    any_0 = validate_with_positions(token=token_0, validator=token_0)


# test_case_0 from test_validate_with_positions

# Generated at 2022-06-26 10:33:57.319993
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token.Null(start={'line': 1, 'column': 0, 'char_index': 0}, end={'line': 1, 'column': 4, 'char_index': 4})
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == None


    token_1 = Token.Array(value=[], start={'line': 1, 'column': 0, 'char_index': 0}, end={'line': 1, 'column': 2, 'char_index': 2})
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    assert any_1 == []



# Generated at 2022-06-26 10:34:00.929306
# Unit test for function validate_with_positions
def test_validate_with_positions():
    cases = [
        "test_case_0",
    ]
    for case in cases:
        globals()[case]()


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:34:18.682630
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from .tokens import ObjectToken, FieldToken

    token = ObjectToken(
        start={"line_index": 0, "char_index": 0},
        end={"line_index": 0, "char_index": 12},
        children=[
            FieldToken(
                name="first_name",
                value=None,
                start={"line_index": 0, "char_index": 1},
                end={"line_index": 0, "char_index": 12},
            )
        ],
    )

    schema = Schema(fields=[Field(name="first_name", type="string")])

    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        messages = []

# Generated at 2022-06-26 10:34:31.468157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    token_1 = Token(type_="null", start=None, end=None, value=None)
    token_2 = Token(
        type_="dict",
        start=None,
        end=None,
        value={"employees": [
            {
                "firstname": "John",
                "lastname": "Doe",
            },
            {
                "firstname": "Anna",
                "lastname": "Smith",
                "age": 26,
            },
            {
                "firstname": "Peter",
                "lastname": "Jones",
                "age": 45,
            },
        ],},
    )
    token_3 = token_2.lookup("employees")
    token_4 = token_3.lookup(1)
    token_5 = token

# Generated at 2022-06-26 10:34:41.979878
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    token_0 = None
    any_0 = validate_with_positions(token=any_0, validator=token_0)
    any_0 = validate_with_positions(token=any_0, validator=any_0)
    any_0 = validate_with_positions(token=any_0, validator=any_0)
    any_0 = validate_with_positions(token=any_0, validator=any_0)
    any_0 = validate_with_positions(token=any_0, validator=any_0)
    any_0 = validate_with_positions(token=any_0, validator=any_0)
    any_

# Generated at 2022-06-26 10:34:49.430944
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Verify that the function performs an operation on any type.
    token_0: Token = Token(value="", start=0, end=0)
    any_0: Any = validate_with_positions(token=token_0, validator=token_0)

    # Verify that the function raises an exception on any type.
    try:
        validate_with_positions(token=token_0, validator=token_0)
    except Exception as e:
        print("Exception raised: " + str(type(e)))

    # Verify that the function returns a value of type int.
    int_0: int = validate_with_positions(token=token_0, validator=token_0)

    # Verify that the function returns a value of type str.

# Generated at 2022-06-26 10:34:59.492170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")

# Generated at 2022-06-26 10:35:06.713495
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Unit: test_validate_with_positions

    class MySchema(object):
        def validate(self, value: typing.Any) -> typing.Any:
            pass
    token_0 = MySchema()
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    class MySchema(object):
        def validate(self, value: typing.Any) -> typing.Any:
            pass
    token_0 = MySchema()
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:35:12.055005
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)


if __name__ == "__main__":
    import sys

    run_module_tests(__file__, sys.modules[__name__], sys.argv[1:])

# Generated at 2022-06-26 10:35:21.379126
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert isinstance(any_0, _)
    assert any_0 == _
    assert not any_0
token_0 = Token(
    value="value",
    start_position=None,
    end_position=None,
    fields=None,
    items=None,
    start_symbol="start_symbol",
    end_symbol="end_symbol",
    is_optional=False,
)



# Generated at 2022-06-26 10:35:29.874366
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import numpy as np
    import tokenize_positions as tkpos
    import typesystem

    schema = typesystem.Schema(fields={"a": tkpos.String(), "b": tkpos.Integer()})

    token = tkpos.tokenize('{"a": "hello", "b": "123"}', '<string>')

    print(token)
    # test_case_1()
    # test_case_2()
    # test_case_3()
    # test_case_4()
    # test_case_5()
    # test_case_6()
    # test_case_7()
    # test_case_8()
    # test_case_9()
    # test_case_10()
    # test_case_11()
    # test_case_12()
   

# Generated at 2022-06-26 10:35:30.312384
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:35:46.757483
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:35:53.828754
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import List
    from typesystem.schemas import Schema
    from typesystem.fields import Field
    from typesystem.enums import TextFormat
    schema = Schema(fields={"name": Field(type="string", format=TextFormat.title)})
    token = Token(value={"name": "matthew"}, start={}, end={})
    assert validate_with_positions(token=token, validator=schema) == {
        "name": "Matthew"
    }
    # exception 'typesystem.exceptions.ValidationError'
    # with message '["Text must be in titlecase\\u00a0format."]'
    token_with_error = Token(value={"name": "matt"}, start={}, end={})
    with pytest.raises(ValidationError):
        validate_with_pos

# Generated at 2022-06-26 10:35:56.593380
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:36:05.551272
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1, validator_1 = None, None
    try:
        validate_with_positions(token=token_1, validator=validator_1)
    except ValidationError as error_1:
        if isinstance(error_1, ValidationError):
            try:
                error_1.messages()
            except ValidationError as error_1:
                if isinstance(error_1, ValidationError):
                    messages_1 = []
                    for message_1 in error_1.messages():
                        if message_1.code == "required":
                            field_1 = message_1.index[-1]
                            token_1 = token_1.lookup(message_1.index[:-1])
                            text_1 = f"The field {field_1!r} is required."

# Generated at 2022-06-26 10:36:07.111146
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() is None

# Generated at 2022-06-26 10:36:11.370529
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Testing validate_with_positions...")
    test_case_0()


##
# Boilerplate code for running unit tests
if __name__ == "__main__":
    test_validate_with_positions()
    print("Done.")

# Generated at 2022-06-26 10:36:22.148567
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    any_1 = validate_with_positions(token=token_0, validator=validator_0)
    any_2 = validate_with_positions(token=token_0, validator=validator_1)


if __name__ == '__main__':
    import sys
    import __main__
    sys.modules[__main__.__name__] = __main__

    import unittest
    test_classes = [
        test_case_0
        ]
    suite = unittest.TestSuite(map(unittest.TestLoader().loadTestsFromTestCase, test_classes))

# Generated at 2022-06-26 10:36:35.277619
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0 = Token(name="PAIR", value=([42, 52]), start=pos(71, 0), end=pos(71, 31))
    validator_0 = Field(validators=[all_pass([str]), max_length(7), min_length(5)])

    # Exercise
    any_2 = validate_with_positions(token=token_0, validator=validator_0)

    # Verify
    assert isinstance(any_2, list)
    assert isinstance(any_2[0], str)
    assert any_2[0] == "[42, 52]"
    assert isinstance(any_2[1], str)
    assert any_2[1] == "[42, 52]"
    assert len(any_2) == 2


# Generated at 2022-06-26 10:36:39.177341
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)


# Generated at 2022-06-26 10:36:39.903811
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:37:24.170017
# Unit test for function validate_with_positions
def test_validate_with_positions():
    mock_token = MagicMock()
    mock_validator = MagicMock()
    mock_validator.validate.return_value = 1

    mock_error = MagicMock()
    mock_error.messages.return_value = [
        MagicMock(code="code0", index=[], text="text0"),
        MagicMock(code="code1", index=["index1"], text="text1"),
    ]
    mock_validator.validate.side_effect = Exception("message")

    try:
        ret = validate_with_positions(token=mock_token, validator=mock_validator)
    except Exception as ex:
        # Check the message of exception
        assert str(ex) == "message"
    else:
        assert ret == 1

        # Check the calls to mock function
       

# Generated at 2022-06-26 10:37:37.937964
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Stub None with a Field
    token_0 = Field.__new__(Field)
    token_0.__init__ = lambda *args, **kwargs: None
    token_0.validator = lambda *args, **kwargs: None
    token_0.errors = lambda *args, **kwargs: None
    token_0.lookup = lambda *args, **kwargs: None
    token_0.start = None
    token_0.end = None
    token_0.value = None
    token_0.type = None
    token_0.text = None

    # Stub None with a Field
    validator_0 = Field.__new__(Field)
    validator_0.__init__ = lambda *args, **kwargs: None

# Generated at 2022-06-26 10:37:42.169944
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # [in] qwe
    token_0 = None
    # [in] None
    validator_0 = None
    # [out] None
    any_0 = validate_with_positions(token=token_0, validator=validator_0)

# Generated at 2022-06-26 10:37:45.645878
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Check function is not None
    assert validate_with_positions is not None



# Generated at 2022-06-26 10:37:46.452268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:37:49.849985
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type="string")
    text = "test"
    token = Token(value=text, start=(1, 2), end=(1, 6))

    assert validate_with_positions(token=token, validator=field) == text



# Generated at 2022-06-26 10:37:55.341481
# Unit test for function validate_with_positions
def test_validate_with_positions():
    q = Queue()
    q.enqueue(1)
    q.enqueue(2)
    q.enqueue(3)

    assert q.dequeue() == 1
    assert q.dequeue() == 2
    assert q.dequeue() == 3
    assert q.isEmpty() == True

# Generated at 2022-06-26 10:37:59.186715
# Unit test for function validate_with_positions
def test_validate_with_positions():
    custom_message_1 = Message(
        text="The field is required.",
        code="required",
        index=["field"],
        start_position=Position(row=0, column=0, char_index=0),
        end_position=Position(row=0, column=0, char_index=0),
    )
    custom_message_0 = Message(
        text="The field is required.",
        code="required",
        index=["field"],
        start_position=Position(row=0, column=0, char_index=0),
        end_position=Position(row=0, column=0, char_index=0),
    )
    custom_exception_1 = ValidationError(messages=[custom_message_1])

# Generated at 2022-06-26 10:38:08.231828
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        token_0 = None
        any_0 = validate_with_positions(token=token_0, validator=token_0)
    except ValidationError as error:
        messages_0: typing.List[Message] = error.messages()
        text_0: str = messages_0[0].text
        try:
            assert (
                text_0
                == "The field 'token_0' is required."
            ), f"Expected: 'The field 'token_0' is required.', Actual: '{text_0}'"
        except AssertionError:
            raise AssertionError(text_0)
        code_0: str = messages_0[0].code

# Generated at 2022-06-26 10:38:19.035497
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        "field",
        index=["field"],
        start=Position(
            line_number=1,
            line_start=0,
            char_index=6,
        ),
        end=Position(
            line_number=1,
            line_start=0,
            char_index=11,
        ),
    )
    token_1 = Token(
        "value",
        index=["field"],
        start=Position(
            line_number=1,
            line_start=0,
            char_index=6,
        ),
        end=Position(
            line_number=1,
            line_start=0,
            char_index=11,
        ),
    )

# Generated at 2022-06-26 10:39:35.146150
# Unit test for function validate_with_positions
def test_validate_with_positions():

    token_0 = None
    validator_0 = Field(type="string")
    with pytest.raises(ValidationError) as error_0:
        validate_with_positions(token=token_0, validator=validator_0)
    messages_0 = error_0.value.messages
    assert messages_0[0].text == "The field 'string' may not be null."
    assert messages_0[0].start_position.char_index == 15
    assert messages_0[0].end_position.char_index == 15

    token_1 = Token(
        value="example", start=(1, 2), end=(1, 9)
    )
    validator_1 = Field(type="string")

# Generated at 2022-06-26 10:39:38.523199
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:39:40.200225
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:39:42.757288
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token('.debug_mode = true', (1, 1))
    assert validate_with_positions(token=token, validator=Field(name='boolean')) is True

# Generated at 2022-06-26 10:39:50.975397
# Unit test for function validate_with_positions
def test_validate_with_positions():

   # inspect.getsource(validate_with_positions)
    # SUT
    token = Token(value=[0, 1, 2, 3], children=[])
    field = Field()

    # SUT
    validate_with_positions(token=token, validator=field)

    # SUT
    token.value = [None, None]
    with pytest.raises(ValidationError):
        validate_with_positions(token=token, validator=field)

# Generated at 2022-06-26 10:40:04.619378
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = validate_with_positions(token=token_0, validator=token_0)
    token_1 = validate_with_positions(token=token_0, validator=token_1)
    token_2 = validate_with_positions(token=token_1, validator=token_0)
    token_3 = validate_with_positions(token=token_1, validator=token_1)
    token_4 = validate_with_positions(token=token_2, validator=token_0)
    token_5 = validate_with_positions(token=token_2, validator=token_1)
    token_6 = validate_with_positions(token=token_3, validator=token_0)

# Generated at 2022-06-26 10:40:08.339186
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:40:09.115142
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False

# Generated at 2022-06-26 10:40:15.359473
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = Field(type="integer")
    try:
        validate_with_positions(token=token_0, validator=validator_0)
    except ValidationError as error_0:
        messages_0 = ['The field "None" is required.']
        for message_0 in error_0.messages:
            if message_0 not in messages_0:
                print(message_0)
    else:
        raise AssertionError('ValidationError not raised')

# Generated at 2022-06-26 10:40:26.696791
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import parse_token

    dashboard_schema = Schema(
        {
            "title": Field(required=True, type="string"),
            "widgets": Field(required=True, type="array"),
        }
    )
    try:
        dashboard_schema.validate({})
    except ValidationError as error:
        assert error.messages == [
            Message(
                text="The field 'widgets' is required.",
                code="required",
                index=("widgets",),
            ),
            Message(
                text="The field 'title' is required.",
                code="required",
                index=("title",),
            ),
        ]
