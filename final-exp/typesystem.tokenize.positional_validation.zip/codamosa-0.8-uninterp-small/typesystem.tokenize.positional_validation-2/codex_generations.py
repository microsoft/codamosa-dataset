

# Generated at 2022-06-26 10:30:57.965880
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=None, validator=float_0) == None

# Generated at 2022-06-26 10:31:00.336906
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    float_0 = 1012.772
    any_1 = validate_with_positions(token=token_0, validator=float_0)
    assert any_1 is None

# Generated at 2022-06-26 10:31:04.180133
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    float_0 = 1012.772
    any_0 = validate_with_positions(token=token_0, validator=float_0)
    token_1 = None
    schema_0 = None
    nullable_int_0 = validate_with_positions(token=token_1, validator=schema_0)

# Generated at 2022-06-26 10:31:10.844788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value="",
        start=None,
        end=None,
        children=[
            Token(
                value="",
                start=None,
                end=None,
                children=[],
            ),
            Token(
                value="",
                start=None,
                end=None,
                children=[],
            ),
        ],
    )
    validator_0 = Field()
    try:
        any_0 = validate_with_positions(
            token=token_0, validator=validator_0
        )
    except ValidationError as exception_0:
        message_0 = exception_0.messages[0]

# Generated at 2022-06-26 10:31:12.002309
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions.__wrapped__)

# Generated at 2022-06-26 10:31:12.782542
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:31:16.845465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    float_0 = 1012.772
    any_1 = validate_with_positions(token=token_0, validator=float_0)


if __name__ == "__main__":
    test_case_0()
    test_validate_with_positions()

# Generated at 2022-06-26 10:31:22.840879
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Testing Token
    token_0 = Token(
        value = {
            'a': {
                'b': [
                    'c',
                    'd',
                    'e',
                ],
            },
        },
        start = {
            'row_index': 3,
            'char_index': 5,
        },
        end = {
            'row_index': 16,
            'char_index': 1,
        },
    )

    # Testing float
    float_0 = 1012.772

    # Testing schema
    schema_0 = type('', (Schema,), {})

    # Testing field
    field_0 = Field()

    # Testing object
    object_0 = type('', (), {})

    # Testing list
    list_0 = [field_0, field_0, schema_0]



# Generated at 2022-06-26 10:31:26.616724
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    float_0 = 1012.772
    any_0 = validate_with_positions(token=token_0, validator=float_0)



# Generated at 2022-06-26 10:31:39.150768
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Input parameters:
    token_0 = None
    token_1 = Token(value="value_1", start=(0, 2), end=(0, 7))
    token_2 = Token(
        value={"name": "name_2", "element": "element_2"},
        start=(0, 2),
        end=(0, 45),
    )
    token_3 = Token(
        value={"name": "name_3", "element": "element_3"},
        start=(0, 2),
        end=(0, 45),
    )
    token_4 = Token(value=None, start=(0, 0), end=(0, 0))
    token_5 = Token(value=100.5, start=(1, 2), end=(1, 7))

# Generated at 2022-06-26 10:31:52.117911
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Tests for Structured Data
    # Tests for Structured Data

    # End Tests for Structured Data
    # Tests for Structured Data
    float_1 = float
    token_2 = Token("float", "0x172c.1p28", (0, 11), (0, 18))
    any_2 = validate_with_positions(token=token_2, validator=float_1)
    assert 0.000000000000000000000000000000000000000000011232768 == any_2

    # End Tests for Structured Data
    # Tests for Structured Data
    float_2 = float
    token_1 = Token("float", "0x172c.1p28", (0, 11), (0, 18))
    any_1 = validate_with_positions(token=token_1, validator=float_2)
    assert 0.0000000000000000000000000000000000000000

# Generated at 2022-06-26 10:32:01.745367
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest

    token = Token(value=None, start=lambda: None, end=lambda: None)
    validator = Field(required=True)

    with pytest.raises(ValidationError) as excinfo:
        validate_with_positions(token=token, validator=validator)
    assert len(excinfo.value.messages()) == 1
    message = excinfo.value.messages()[0]
    assert message.start_position == token.start()
    assert message.end_position == token.end()

# Generated at 2022-06-26 10:32:04.010809
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here


# Generated at 2022-06-26 10:32:04.940409
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == 1012.772



# Generated at 2022-06-26 10:32:09.883022
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test the positiional error message
    token_0 = Token("test", {"foo": Token("bar", {"baz": Token("quux")})})
    any_0 = validate_with_positions(token=token_0, validator=Field(required=True))
    assert any_0 == "test"

# Generated at 2022-06-26 10:32:17.252338
# Unit test for function validate_with_positions
def test_validate_with_positions():
    message = """
    Expected type 'float', got '1012.772' instead.
    """

    def test_case_0():
        token_0 = None
        float_0 = 1012.772
        try:
            validate_with_positions(
                token=token_0, validator=float_0
            )
        except ValidationError as error:
            assert error.messages()[0].text == message

    test_case_0()



# Generated at 2022-06-26 10:32:19.246504
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    str_0 = 'A string'
    any_0 = validate_with_positions(token=token_0, validator=str_0)

# Generated at 2022-06-26 10:32:30.288950
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test with string input
    string_0 = "The quick brown fox jumps over the lazy dog"
    any_0 = validate_with_positions(token=string_0, validator=string_0)
    # Test with bool input
    bool_0 = True
    any_0 = validate_with_positions(token=bool_0, validator=bool_0)
    # Test with int input
    int_0 = 181
    any_0 = validate_with_positions(token=int_0, validator=int_0)
    # Test with tuple input
    tuple_0 = (45, 32)
    any_0 = validate_with_positions(token=tuple_0, validator=tuple_0)
    # Test with float input
    float_0 = 1.879
    any_0 = validate

# Generated at 2022-06-26 10:32:38.830799
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class FooSchema(Schema):
        bar = Field()
    token = Token(value={"bar": "baz"})
    validate_with_positions(token=token, validator=FooSchema)


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 10:32:40.549832
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass  # TODO: implement your test here


# Generated at 2022-06-26 10:32:54.531134
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)

    str_1 = 'Z a'
    any_1 = validate_with_positions(token=str_1, validator=str_1)

    str_2 = 's'
    any_2 = validate_with_positions(token=str_2, validator=str_2)

    str_3 = 'V (W'
    any_3 = validate_with_positions(token=str_3, validator=str_3)

    str_4 = 'm '
    any_4 = validate_with_positions(token=str_4, validator=str_4)


test_validate_with_positions()

# Generated at 2022-06-26 10:32:55.697164
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True


# Generated at 2022-06-26 10:32:58.679110
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)

# Generated at 2022-06-26 10:33:01.094187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Function to test validate_with_positions
    test_case_0()
    # print('passed test case 0')



# Generated at 2022-06-26 10:33:03.830107
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)


# Generated at 2022-06-26 10:33:05.759594
# Unit test for function validate_with_positions
def test_validate_with_positions():
    if True:  # Change to False if you want to run specific test
        test_case_0()

# Generated at 2022-06-26 10:33:09.320376
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    with pytest.raises(Exception) as excinfo:
        validate_with_positions(token=str_0, validator=str_0)

# Generated at 2022-06-26 10:33:21.481236
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=Token(value=3, start=1, end=3), validator=3) == 3
    assert validate_with_positions(token=Token(value=[1], start=1, end=3), validator=[1]) == [1]
    assert validate_with_positions(token=Token(value=4, start=1, end=3), validator=4) == 4
    assert validate_with_positions(token=Token(value="red", start=1, end=3), validator="red") == "red"
    assert validate_with_positions(token=Token(value=5, start=1, end=3), validator=5) == 5
    assert validate_with_positions(token=Token(value="hello", start=1, end=3), validator="hello")

# Generated at 2022-06-26 10:33:29.250432
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:33:42.235206
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    str_1 = 'A sa i2g'
    any_1 = validate_with_positions(token=str_1, validator=str_1)
    str_2 = 'A sa i2g'
    any_2 = validate_with_positions(token=str_2, validator=str_2)
    str_3 = 'A sa i2g'
    any_3 = validate_with_positions(token=str_3, validator=str_3)
    str_4 = 'A sa i2g'
    any_4 = validate_with_positions(token=str_4, validator=str_4)
    str_5

# Generated at 2022-06-26 10:33:56.806154
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    
    try:
        # Test for branch __main__:8:
        # This branch is executed.
        validate_with_positions(token=str_0, validator=str_0)
        assert 0
    except ValidationError as e:
        # Test for branch __main__:15:
        # This branch is executed.
        assert e.messages[0].start_position.char_index == 0

# Generated at 2022-06-26 10:33:57.531430
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:33:58.962336
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)


# Generated at 2022-06-26 10:34:09.869766
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Test 1
    # ~~~~~~

    # A sa i2g
    any_0 = validate_with_positions(token=str_0, validator=str_0)

    assert any_0 is not None
    assert any_0 == 'A sa i2g'
    assert str(any_0) == 'A sa i2g'

    # Test 2
    # ~~~~~~

    # ert
    any_1 = validate_with_positions(token=str_1, validator=str_1)

    assert any_1 is not None
    assert any_1 == 'ert'
    assert str(any_1) == 'ert'

    # Test 3
    # ~~~~~~

    # 
    any_2 = validate_with_positions(token=str_2, validator=str_2)

# Generated at 2022-06-26 10:34:19.480756
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field_0 = Field(type="string")
    field_0.child(name="b")
    field_1 = Field(type="string")
    schema_0 = Schema(fields={'a': field_0}, structure={'a': {'b': field_1}})
    field_3 = Field(type="string")
    field_3.child(name="b")
    field_4 = Field(type="string")
    schema_1 = Schema(fields={'a': field_3}, structure={'a': {'b': field_4}})
    field_5 = Field(type="string")
    field_5.child(name="b")
    field_6 = Field(type="string")

# Generated at 2022-06-26 10:34:31.766170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # A fixer function that will be used to convert field types
    # in the test cases.
    fixer = lambda value: value

    # A list of tuples, where each tuple is of the form
    # (input_value, expected_result, error)

# Generated at 2022-06-26 10:34:41.273545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # AssertionError: Expected None to equal <ValidationError: [<Message: The field 'validator' is required.>]>
    assert validate_with_positions()  # type: ignore
    # AssertionError: Expected None to equal <ValidationError: [<Message: The field 'token' is required.>]>
    assert validate_with_positions(token='A sa i2g')  # type: ignore
    # AssertionError: Expected None to equal <ValidationError: [<Message: The field 'validator' is required.>]>
    assert validate_with_positions(token='A sa i2g', validator='A sa i2g')  # type: ignore

# Generated at 2022-06-26 10:34:41.826922
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:34:46.722149
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Setup
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    any_1 = validate_with_positions(token=str_0, validator=str_0)
    any_2 = validate_with_positions(token=str_0, validator=str_0)

    # Assertion
    assert any_0 is any_1
    assert any_0 is not any_2
    assert any_1 is not any_2


# Generated at 2022-06-26 10:34:58.120823
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    str_1 = 'A sa i2g'
    func_0 = Schema.validate(str_1)
    any_1 = validate_with_positions(token=str_1, validator=str_0)
    str_2 = 'A sa i2g'
    func_1 = Field.validate(str_2)
    any_2 = validate_with_positions(token=str_2, validator=str_0)
    str_3 = 'A sa i2g'
    any_3 = validate_with_positions(token=str_3, validator=str_0)
    str_4 = 'A sa i2g'

# Generated at 2022-06-26 10:35:19.160015
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # AssertionError: ('A sa i2g', <class 'str'>)
    assert validate_with_positions(token='A sa i2g', validator=str) is None
    # AssertionError: ('A sa i2g', <class 'str'>)
    assert validate_with_positions(token='A sa i2g', validator=str) is None
    # AssertionError: ('A sa i2g', <class 'str'>)
    assert validate_with_positions(token='A sa i2g', validator=str) is None
    # AssertionError: ('A sa i2g', <class 'str'>)
    assert validate_with_positions(token='A sa i2g', validator=str) is None
    # AssertionError: ('A sa i2g', <

# Generated at 2022-06-26 10:35:21.516437
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Order of arguments may vary, so check both
    try:
        validate_with_positions(token='B c7b', validator='u9R')
    except TypeError:
        validate_with_positions(validator='yHD', token='k2P')



# Generated at 2022-06-26 10:35:23.122718
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Function case 1

# Generated at 2022-06-26 10:35:24.700370
# Unit test for function validate_with_positions
def test_validate_with_positions():
    a = A()
    b = B()
    a.validate(b)


# Generated at 2022-06-26 10:35:30.313792
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(name="name")
    r = validate_with_positions(
        token=Token("null", "null", line=1, start=1, end=5), validator=field
    )
    assert r is None
    # This should fail but does not because the message does not contain position data
    with pytest.raises(ValidationError):
        validate_with_positions(token=Token("null", "null", line=1, start=1, end=5), validator=str)
    # Check that the case is covered
    if (1):
        pass

# Generated at 2022-06-26 10:35:42.360510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert(any_0 == 'A sa i2g')

    str_0 = 'jP} y=P'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert(any_0 == 'jP} y=P')

    str_0 = 'mwv jj5'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert(any_0 == 'mwv jj5')

    str_0 = 'n}fD-p8'

# Generated at 2022-06-26 10:35:44.338420
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # See http://tinyurl.com/ng8hvq3
    assert validate_with_positions(token=1, validator=1) == 1



# Generated at 2022-06-26 10:35:49.036686
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Setup test values

    str_0 = 'A sa i2g'

    # Execute function
    token = str_0
    validator = str_0
    result = validate_with_positions(
        token=str_0,
        validator=str_0,
    )

    # Verify expected values
    assert result == None or result is any_0

# Generated at 2022-06-26 10:36:01.004044
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()
    try:
        from example_schema import ExampleSchema
        from typesystem.tokenize.tokens import Token
        from yaml import load
        from yaml.error import YAMLError
        from yaml.scanner import ScannerError
        from yaml.parser import ParserError
        from yaml import CLoader as Loader
        tokens = Token.from_yaml(load('some_yaml', Loader=Loader))
        validate_with_positions(token=tokens, validator=ExampleSchema)
    except (TypeError, ValueError, ScannerError, ParserError, YAMLError) as e:
        print(type(e))
    except Exception as e:
        print(e)
test_validate_with_positions()

# Generated at 2022-06-26 10:36:11.332526
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # check_class
    assert inspect.isclass(validate_with_positions) is True

    # check_doc

    # check_args
    try:
        validate_with_positions()
        assert False
    except TypeError:
        assert True

    # check_kwargs
    try:
        validate_with_positions(a=0)
        assert False
    except TypeError:
        assert True

    # check basic
    # No return but assert

    # check return type
    assert isinstance(test_case_0(), type(None))

# Generated at 2022-06-26 10:36:21.120326
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass
# Program to test above function


# Generated at 2022-06-26 10:36:21.855210
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:36:22.938788
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:36:23.852208
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Main function

# Generated at 2022-06-26 10:36:28.193744
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # [TODO] Implement test
    assert True == True

# Generated at 2022-06-26 10:36:37.032003
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Case 0-1: Assert that a string literal is returned when a schema is used on a string
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert any_0 == 'A sa i2g'

    # Case 0-2: Assert that a string literal is returned when a schema is used on a string
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert any_0 == 'A sa i2g'

    # Case 0-3: Assert that a string literal is returned when a schema is used on a string
    str_0 = 'A sa i2g'
    any_0 = validate_with

# Generated at 2022-06-26 10:36:41.823218
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Assigning values for different kinds of variables
    # Formatting the output string
    # Calling function validate_with_positions
    validate_with_positions(token=Token, validator=Schema)
    # Checking for expected value



# Generated at 2022-06-26 10:36:50.449445
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = "A"
    str_1 = "sa"
    str_2 = "i2g"
    str_3 = "wett"
    str_4 = "wett"
    str_5 = "wett"
    str_6 = "wett"
    str_7 = "wett"
    str_8 = "wett"
    str_9 = "wett"
    str_10 = "wett"
    str_11 = "wett"
    str_12 = "wett"
    str_13 = "wett"
    str_14 = "wett"
    str_15 = "wett"
    str_16 = "wett"
    str_17 = "wett"
    str_18 = "wett"
    str_19 = "wett"


# Generated at 2022-06-26 10:36:51.325983
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() == None

# Generated at 2022-06-26 10:37:02.538590
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Attributes
    test_case_0()
    # Attributes
    str_0 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    # Attributes
    str_0 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    # Attributes
    str_0 = 'Lorem ipsum dolor sit amet, consectetur adipiscing elit.'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    # Attributes

# Generated at 2022-06-26 10:37:24.972170
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert any_0["A"] == "A"
    assert any_0["sa"] == "sa"
    assert any_0["i2g"] == "i2g"

# Generated at 2022-06-26 10:37:34.546946
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    str_1 = 'A sa i2g'
    any_1 = validate_with_positions(token=str_1, validator=str_1)
    str_2 = 'A sa i2g'
    any_2 = validate_with_positions(token=str_2, validator=str_2)

# Generated at 2022-06-26 10:37:43.049232
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.tokens import Token
    from typesystem.fields import Field
    from typesystem.exceptions import ValidationError
    from typesystem.positions import Position
    from typesystem.types import String

    class MyField(Field):
        def errors(self, value):
            for s in value.split():
                if s != s[::-1]:
                    yield "VALIDATION_ERROR"

    class MySchema(Schema):
        title = String(validators=[MyField()])

    token = Token(
        source="TITLE: A NI NINEA",
        value={
            "title": "A NI NINEA",
        },
        start=Position(1, 1),
        end=Position(1, 14),
        types={
            "title": "String",
        },
    )

# Generated at 2022-06-26 10:37:48.093802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert any_0 == 'A i2g'

# Generated at 2022-06-26 10:37:50.480620
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert isinstance(test_case_0(), str)


if __name__ == '__main__':
    import pytest
    pytest.main(['-v', __file__])

# Generated at 2022-06-26 10:37:55.909045
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Test case 0
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    # assert any_0 == 'A sa i2g'
    assert any_0 == 'A sa i2g'



# Generated at 2022-06-26 10:37:59.650141
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert isinstance(any_0, str)
    assert str_0 == any_0


# Generated at 2022-06-26 10:38:04.254892
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A valid JSON string'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    str_1 = "another_string"
    any_1 = validate_with_positions(token=str_1, validator=str_1)


# Generated at 2022-06-26 10:38:06.885256
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_1 = 'A sa i2g'
    str_2 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_1, validator=str_2)



# Generated at 2022-06-26 10:38:08.230333
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False # TODO: implement your test here


# Generated at 2022-06-26 10:38:31.044510
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    assert any_0 == 'A sa i2g'
    int_0 = 14
    any_1 = validate_with_positions(token=int_0, validator=int_0)
    assert any_1 == 14
    float_0 = 14.0
    any_2 = validate_with_positions(token=float_0, validator=float_0)
    assert any_2 == 14.0

# Generated at 2022-06-26 10:38:40.663889
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Example 1: A simple example
    str_0 = 'A simple example'
    str_1 = 'A si2gle e1ample'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    any_1 = validate_with_positions(token=str_1, validator=str_1)

    # Example 2: A simple example
    str_2 = 'A simple exampl1'
    str_3 = 'A simple example'
    any_2 = validate_with_positions(token=str_2, validator=str_2)
    any_3 = validate_with_positions(token=str_3, validator=str_3)

    # Example 3: A simple example
    str_4 = 'A simple e2mple'
    str_

# Generated at 2022-06-26 10:38:45.056155
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)

test_validate_with_positions()

# Generated at 2022-06-26 10:38:52.383076
# Unit test for function validate_with_positions
def test_validate_with_positions():
    type_test_utils.assert_equals('[Token(start: Position(line: 0, column: 0, char_index: 0), end: Position(line: 0, column: 8, char_index: 8), value: A sa i2g)]', type_test_utils.get_variable_type_substring('any_0 = validate_with_positions(token=str_0, validator=str_0)', 'any_0'))

# vim: set filetype=python

# Generated at 2022-06-26 10:39:03.552008
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(str_0, required=str_0)
    assert str_0.validate(str_0, str_0), str_0

    with pytest.raises(ValidationError) as excinfo:  # type: ignore
        validate_with_positions(str_1, str_2)
    assert "expected str_1 but received str_2" in str(excinfo.value)
    messages = excinfo.value.messages()
    assert messages[0].text == "Expected 'str_1' but received 'str_2'"

    assert str_0.validate(field, str_0) == str_0

    schema = Schema({"foo": field})
    assert schema.validate({"foo": str_0}) == {"foo": str_0}

# Generated at 2022-06-26 10:39:13.874912
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    str_1 = 'A sa i2g'
    str_2 = 'A sa i2g'
    str_3 = 'A sa i2g'
    int_0 = -1
    int_1 = 0x64
    int_2 = -0x4a818f
    int_3 = 0x37fb9c
    bool_0 = False
    bool_1 = True
    bool_2 = False
    bool_3 = True
    bool_4 = True
    bool_5 = True
    bool_6 = False
    bool_7 = True
    bool_8 = False
    bool_9 = False
    bool_10 = True
    bool_11 = True
    bool_12 = True
    bool_13 = False
    bool_14 = False

# Generated at 2022-06-26 10:39:24.665724
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value="foo",
        index=("key",),
        start=Message.Position(line_number=10, char_index=100),
        end=Message.Position(line_number=20, char_index=200),
    )
    class MyField(Field):
        def validate(self, value):
            if value != "foo":
                raise ValidationError(
                    f"expected {value!r} to be {self.expected!r}"
                )

    try:
        validate_with_positions(token=token, validator=MyField())
    except ValidationError as error:
        message = error.messages()[0]
        assert message.text == 'expected "foo" to be "foo"'
        assert message.index == ("key",)

# Generated at 2022-06-26 10:39:33.502658
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    float_0 = -21.90666666666667
    any_1 = validate_with_positions(token=float_0, validator=float_0)
    bool_0 = False
    any_2 = validate_with_positions(token=bool_0, validator=bool_0)
    class_0 = from_union([str, None], None)
    any_3 = validate_with_positions(token=class_0, validator=class_0)

# Generated at 2022-06-26 10:39:37.323812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)


# Generated at 2022-06-26 10:39:38.448423
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:39:58.195128
# Unit test for function validate_with_positions
def test_validate_with_positions():
    node = __test_case_0()
    # test
    assert node == 'A sa i2g'


# Generated at 2022-06-26 10:40:02.499290
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)
    return any_0 == None


# Generated at 2022-06-26 10:40:15.167102
# Unit test for function validate_with_positions
def test_validate_with_positions():
    B = {
        'A': [
            'A',
            'A',
        ],
        'C': None,
        'B': {},
        'E': 'A',
        'D': [
            'A',
            'A',
            [
                'A',
                'A',
                'A',
            ],
            'A',
        ],
    }

    str_0 = 'A sa i2g'
    assert str_0 == str_0

# Generated at 2022-06-26 10:40:16.731324
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert bool(validate_with_positions)

# Generated at 2022-06-26 10:40:18.083961
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:40:21.976781
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)



# Generated at 2022-06-26 10:40:29.742913
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Mock import function
    sys.path.append(os.getcwd())
    str_0 = 'A sa i2g'
    str_1 = '3sa5'
    str_2 = 'i2g'
    str_3 = 'A'
    str_4 = 'ij3k'
    str_5 = 'i2g'
    str_6 = '3sa5'
    str_7 = 'A sa i2g'
    str_8 = 'A'
    str_9 = 'ij3k'
    str_10 = 'i2g'
    str_11 = '3sa5'
    str_12 = 'A'
    str_13 = 'ij3k'
    str_14 = 'i2g'
    str_15 = '3sa5'

# Generated at 2022-06-26 10:40:31.792127
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test for basic assertions
    assert True

# Generated at 2022-06-26 10:40:36.302338
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_0 = 'A sa i2g'
    any_0 = validate_with_positions(token=str_0, validator=str_0)


# Generated at 2022-06-26 10:40:40.912612
# Unit test for function validate_with_positions
def test_validate_with_positions():

    assert django_tpl_url_0 == '<img src="{% static \'images/hi.jpg\' %}" height="400" width="400">'
