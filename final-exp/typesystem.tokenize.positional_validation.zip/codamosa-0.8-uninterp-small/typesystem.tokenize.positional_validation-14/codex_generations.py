

# Generated at 2022-06-26 10:31:06.679097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typing import Any

    import typesystem.tokenize.tokens as module_0
    import typesystem.fields as module_1

    int_0 = 18725
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    int_1 = 1
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=token_1)



# Generated at 2022-06-26 10:31:21.211678
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import libfoolang

    ctx = libfoolang.AnalysisContext()
    u = ctx.get_from_buffer('main.txt', b'example')
    if u.diagnostics:
        for d in u.diagnostics:
            print(d)
        raise Exception('fail')

    def validate(value, *, position=None, token=None):
        try:
            return ctx.eval(value, position=position, token=token)
        except libfoolang.PropertyError as exc:
            raise ValidationError(
                [Message(text=str(exc), start_position=exc.position, end_position=exc.position)])

    any_0 = validate(b'"hello world"', position=u.root.p_default_position, token=None)

# Generated at 2022-06-26 10:31:33.142269
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Tests for string values
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    # Tests for number values
    str_0 = "1244"
    token_1 = module_0.Token(str_0, str_0, str_0)
    any_1 = validate_with_positions(token=token_1, validator=token_1)

    # Tests for boolean values
    bool_0 = False
    token_2 = module_0.Token(bool_0, bool_0, bool_0)
    any_2 = validate_with_positions(token=token_2, validator=token_2)

# Generated at 2022-06-26 10:31:40.205249
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = -874
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    # assert any_0 is None

if __name__ == "__main__":
    import pytest
    import sys
    pytest.main(["-q", "--tb=native", __file__])

# Generated at 2022-06-26 10:31:44.258391
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Test `validate_with_positions`")

    print(test_case_0())

# Generated at 2022-06-26 10:31:48.323901
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert isinstance(any_0, object)


# Generated at 2022-06-26 10:31:49.665924
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: Implement test_validate_with_positions
    pass

# Generated at 2022-06-26 10:31:50.707537
# Unit test for function validate_with_positions
def test_validate_with_positions():
    raise NotImplementedError

# Generated at 2022-06-26 10:31:55.430465
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

import typesystem.tokenize.tokens as module_0


# Generated at 2022-06-26 10:32:03.357204
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        token_0 = module_0.Token(int_0, int_0, int_0)
        validator_0 = any_0
        validate_with_positions(token=token_0, validator=validator_0)
    except ValidationError as expected:
        text_0 = expected.messages()
        text_1 = text_0[0].text
        text_2 = 'The field "value" is required.'
        assert text_1 == text_2
    else:
        assert False

# Generated at 2022-06-26 10:32:18.197774
# Unit test for function validate_with_positions
def test_validate_with_positions():
    bool_1 = bool()
    int_2 = int()
    str_3 = str()
    int_4 = int()
    int_5 = int()
    int_6 = int()
    message_7 = Message()
    list_8 = [ message_7 ]
    int_9 = int()
    int_10 = int()
    int_11 = int()
    message_12 = Message()
    list_13 = [ message_12 ]
    int_14 = int()
    int_15 = int()
    int_16 = int()
    message_17 = Message()
    list_18 = [ message_17 ]
    int_19 = int()
    int_20 = int()
    int_21 = int()
    message_22 = Message()
    list_23 = [ message_22 ]
    int_

# Generated at 2022-06-26 10:32:19.740952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0()

# Generated at 2022-06-26 10:32:28.592335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    int_1 = 1244
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=token_1)

    assert any_0 is any_1

# Generated at 2022-06-26 10:32:32.769815
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:32:40.507137
# Unit test for function validate_with_positions
def test_validate_with_positions():

    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:32:41.788996
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 is None, "Expected function to raise an exception"

# Generated at 2022-06-26 10:32:53.355941
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:33:03.747959
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1385
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    int_1 = 863
    token_1 = module_0.Token(int_1, int_1, int_1)
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    int_2 = 392
    token_2 = module_0.Token(int_2, int_2, int_2)
    any_2 = validate_with_positions(token=token_2, validator=token_2)
    int_3 = 639

# Generated at 2022-06-26 10:33:07.976965
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # simple mock value
    field = Field(int)
    token = Token(1244, 1244, 1244)
    assert validate_with_positions(token=token, validator=field) == 1244



# Generated at 2022-06-26 10:33:21.029802
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)
# -- END


if __name__ == "__main__":
    import sys
    import inspect
    from coverage import Coverage

    cov = Coverage()
    cov.start()

    # Run unittests
    unittest.main(exit=False)

    # Run doctests
    # python -m doctest -v typesystem/tokenize/tokens.py
    doctest.testmod()

    cov.stop()
    cov.save()
    cov.html_report(directory="report", ignore_errors=True)

# Generated at 2022-06-26 10:33:29.705144
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test subtest 0
    test_case_0()

test_validate_with_positions()

# Generated at 2022-06-26 10:33:42.618909
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Make sure that the function raises ValidationError when ValidationError
    # is raised by the validator
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)

    with pytest.raises(ValidationError) as info:
        any_0 = validate_with_positions(token=token_0, validator=token_0)
    # Check that the first message of the ValidationError has the correct start
    # position
    assert info.value.messages[0].start_position == token_0.start
    # Check that the first message of the ValidationError has the correct end
    # position
    assert info.value.messages[0].end_position == token_0.end
    # Make sure that the function raises ValidationError when ValidationError


# Generated at 2022-06-26 10:33:43.911707
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:33:45.831512
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

import typesystem.tokenize.tokens as module_0


# Generated at 2022-06-26 10:33:48.522223
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # test the call validate_with_positions(token=token_0, validator=token_0) from test_case_0
    pass

# Generated at 2022-06-26 10:33:51.437989
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    test_case_0()

# Generated at 2022-06-26 10:33:54.794523
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)


# Generated at 2022-06-26 10:34:00.579466
# Unit test for function validate_with_positions
def test_validate_with_positions():
    int_1 = 971
    token_1 = module_0.Token(int_1, int_1, int_1)
    def func_0():
        return validate_with_positions(token=token_1, validator=token_0)
    pytest.raises(Exception, func_0)

# Generated at 2022-06-26 10:34:02.616174
# Unit test for function validate_with_positions
def test_validate_with_positions():
    field = Field(type=str)

    token = Token(
        value="test", start=0, end=4,
    )

    assert validat

# Generated at 2022-06-26 10:34:08.311307
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem.tokenize.tokens as module_0
    # Test positional arguments
    # test_case_0
    int_0 = 1244
    token_0 = module_0.Token(int_0, int_0, int_0)
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:34:28.475300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    expected_positions = [
        Position(line_index=0, char_index=0),
    	Position(line_index=0, char_index=1),
    	Position(line_index=0, char_index=2),
    	Position(line_index=0, char_index=3),
    	Position(line_index=0, char_index=4),
    	Position(line_index=0, char_index=5)
    ]

# Generated at 2022-06-26 10:34:31.808685
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value=None, name="bar", start=None, end=None)
    any_0 = validate_with_positions(token=token_0, validator=Field(nullable=True))

# Generated at 2022-06-26 10:34:42.313012
# Unit test for function validate_with_positions
def test_validate_with_positions():
    tokens = [Token("hello"), Token("world")]

    class Hello(Field):
        def validate(self, value):
            if value != "hello":
                raise ValidationError("Expected hello.")

    field = Hello()
    assert validate_with_positions(
        token=tokens[0], validator=field
    ) == "hello"
    try:
        validate_with_positions(token=tokens[1], validator=field)
    except ValidationError as error:
        assert list(error.messages()) == [
            Message(
                text="Expected hello.",
                code="invalid",
                index=[0],
                start_position=Position(0, 0, 1),
                end_position=Position(5, 0, 6),
            )
        ]
    else:
        raise Ass

# Generated at 2022-06-26 10:34:43.156800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    test_case_0()

# Generated at 2022-06-26 10:34:44.669249
# Unit test for function validate_with_positions
def test_validate_with_positions():

    test_case_0()

# Generated at 2022-06-26 10:34:57.284261
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = Token(
        value='foo',
        start=None,
        end=None,
    )
    any_0._parent = None
    str_0 = validate_with_positions(token=any_0, validator=any_0)
    try:
        str_2 = validate_with_positions(token='foo', validator='foo')
    except:
        str_1 = validate_with_positions(token='foo', validator='foo')
    int_0 = validate_with_positions(token=3, validator=3)
    str_4 = validate_with_positions(token='foo', validator=3)
    try:
        str_5 = validate_with_positions(token='foo', validator=None)
    except:
        str_3 = validate_with_

# Generated at 2022-06-26 10:35:03.815371
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Token_0(Token):
        name = "token_0"

    class Field_0(Field):
        value_type = Token_0
        serializer_class = Token_0
        nullable = True

     
    class Schema_0(Schema):
        field_1 = Field_0()
        field_2 = Field_0()

    token_1 = Token_0(
        name="token_1",
        value="token_1",
        start=Position(line=1, column=1, char_index=0),
        end=Position(line=1, column=8, char_index=7),
    )
    any_1 = validate_with_positions(token=token_1, validator=Schema_0())


# Generated at 2022-06-26 10:35:14.190187
# Unit test for function validate_with_positions
def test_validate_with_positions():
    init_0 = None
    validator_0 = init_0
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    init_1 = ""
    validator_1 = init_1
    token_1 = None
    any_1 = validate_with_positions(token=token_1, validator=validator_1)
    init_2 = "0"
    validator_2 = init_2
    token_2 = None
    any_2 = validate_with_positions(token=token_2, validator=validator_2)
    init_3 = 0.0
    validator_3 = init_3
    token_3 = None

# Generated at 2022-06-26 10:35:25.205893
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # We are entering the function and we know all of the parametrs.
    # Now we want to run the validation and record any errors that may be generated.

    # The token and validator are both created outside of the function
    # as they are not relevant to the function.
    
    # We need to create the items that we will pass in validator.validate
    token_value = "token value"
    token_start = "token start"
    token_end = "token end"

    # We will set up the function call to validate_with_positions
    token = Token(value=token_value, start=token_start, end=token_end)
    validator = Field(name="test", types=[int])

    # We can now create a test case in which an error is raised from validator.validate
    # In this case valid

# Generated at 2022-06-26 10:35:27.028888
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = "test"
    any_1 = validate_with_positions(token=token_1, validator=token_1)

# Generated at 2022-06-26 10:35:51.990268
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = typing.cast(str, None)
    any_1 = typing.cast(str, None)
    any_2 = typing.cast(str, None)
    any_3 = typing.cast(str, None)
    any_4 = typing.cast(str, None)
    any_5 = typing.cast(str, None)
    any_6 = typing.cast(str, None)
    any_7 = typing.cast(str, None)
    any_8 = typing.cast(str, None)
    any_9 = typing.cast(str, None)
    any_10 = typing.cast(str, None)
    any_11 = typing.cast(str, None)
    any_12 = typing.cast(str, None)
    any_13 = typing.cast(str, None)
    any_

# Generated at 2022-06-26 10:36:03.218570
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize.parser import ValidatorParser
    from typesystem.tokenize.tokens import Token
    from typesystem.tokenize.tokens import TokenType
    from typesystem.tokenize.tokens import TokenType

    parser = ValidatorParser()
    root = parser.parse("""
foo: str
""")
    assert isinstance(root, Token)
    assert root.type == TokenType.OBJECT
    assert len(root.children) == 1
    assert isinstance(root.children[0], Token)
    assert root.children[0].type == TokenType.FIELD
    assert len(root.children[0].children) == 2
    assert isinstance(root.children[0].children[0], Token)
    assert root.children[0].children[0].type == TokenType.FIELD_NAME
   

# Generated at 2022-06-26 10:36:04.699919
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = token_0

    # Call validate_with_positions
    assert token_0


# Generated at 2022-06-26 10:36:08.678314
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Run test case 0
    test_case_0()
    print("Test case 0 passed")

if __name__ == '__main__':
    test_validate_with_positions()

# Generated at 2022-06-26 10:36:13.876723
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token({}, None, None)
    any_0 = validate_with_positions(token=token_0, validator=token_0)


# Generated at 2022-06-26 10:36:16.918643
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_1 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:36:17.686861
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:36:24.590822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # to_salad
    from salad.types import SaladSchema

    from salad.tests.fixtures import (
        dropbox_input_schema,
        dropbox_interface_input,
        dropbox_interface_output,
    )

    input_schema = SaladSchema.from_yaml(
        yaml_string=dropbox_input_schema, strict=True, infer_types=True
    )
    in_token = Token.from_salad(dropbox_interface_input, input_schema, "inputs")
    out_token = Token.from_salad(dropbox_interface_output, input_schema, "outputs")
    input_result = validate_with_positions(token=in_token, validator=input_schema)

# Generated at 2022-06-26 10:36:36.477639
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = Token(
        value={},
        children=[
            Token(
                value="a",
                start=(2, 3),
                end=(2, 4),
                children=[
                    Token(
                        value={"b": "c"},
                        start=(2, 5),
                        end=(2, 6),
                        children=[
                            Token(
                                value={"d": "e"},
                                start=(2, 7),
                                end=(2, 8),
                                children=[Token(value="f", start=(2, 9), end=(2, 10))],
                            )
                        ],
                    )
                ],
            )
        ],
    )
    field_0 = Field(required=True)
    field_1 = Field(required=True)
    field_2 = Field(required=True)
    field

# Generated at 2022-06-26 10:36:40.425079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert (
        validate_with_positions(
            token={"value": None, "start": {"line_index": 0, "char_index": 0}},
            validator={"required": True, "type": "str"},
        )
        is None
    )
    assert (
        validate_with_positions(
            token={"value": None, "start": {"line_index": 0, "char_index": 0}},
            validator={"required": False, "type": "str"},
        )
        is None
    )
    assert (
        validate_with_positions(
            token={"value": 42, "start": {"line_index": 0, "char_index": 0}},
            validator={"required": True, "type": "str"},
        )
        == "42"
    )

# Generated at 2022-06-26 10:36:58.569188
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass



# Generated at 2022-06-26 10:37:03.470157
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:37:12.323962
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    str_0 = token_0.lookup(index_0=(token_0))
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    str_0 = token_0.lookup(index_0=(token_0))
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    str_0 = token_0.lookup(index_0=(token_0))
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    str_0

# Generated at 2022-06-26 10:37:24.265990
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Find start and end positions of function validate_with_positions
    assert test_case_0.__code__.co_firstlineno == test_case_0.__code__.co_lastlineno == 9
    # Check number of positional arguments in function validate_with_positions
    assert test_case_0.__code__.co_argcount == 2
    # Check number of local variables in function validate_with_positions
    assert test_case_0.__code__.co_nlocals == 4
    # Check number of free variables in function validate_with_positions
    assert test_case_0.__code__.co_nfreevars == 1
    # Check number of parameters in the cell variable in function validate_with_positions
    assert test_case_0.__closure__[0].cell_contents.__

# Generated at 2022-06-26 10:37:26.210450
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert 1 == 1

# Generated at 2022-06-26 10:37:38.707155
# Unit test for function validate_with_positions
def test_validate_with_positions():
    from typesystem.tokenize import Token, TokenKind
    from typesystem import fields
    from typesystem.tokenize.tokens import ObjectToken

    token = ObjectToken(
        start={"line_number": 1, "end_char_index": 2},
        end={"line_number": 1, "end_char_index": 4},
        value={"a": {"name": "Alex", "age": 35}},
    )
    person_schema = fields.Object(
        properties={"name": fields.String(), "age": fields.Integer()}, required=["name"]
    )
    with pytest.raises(ValidationError) as exception_info:
        token = validate_with_positions(token=token, validator=person_schema)


# Generated at 2022-06-26 10:37:52.524118
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import io

    import pytest

    from typesystem.tokenize.tokenizers.base import RegExpTokenizer
    from typesystem.tokenize.tokenizers.fields import FieldTokenizer

    tokenizer = FieldTokenizer(tokenizer=RegExpTokenizer(r"\d+"))
    token = tokenizer.tokenize_text(text=u"Not a number")

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token, validator=tokenizer)

    error = exc_info.value.messages()[0]
    assert error.text == u"Not a number is not a valid number"
    assert error.code == "invalid"
    assert error.index == ()

    assert error.start_position.index == 0

# Generated at 2022-06-26 10:37:58.966153
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:38:00.949070
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = validate_with_positions(token=token_0, validator=validator_0)



# Generated at 2022-06-26 10:38:02.441407
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert test_case_0() is None

# Generated at 2022-06-26 10:38:37.126097
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert set(["validate_with_positions"]) == set(globals())

# Generated at 2022-06-26 10:38:39.264449
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:38:39.796995
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:38:52.558401
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Setup
    token_0 = None
    validator_0 = Field(validators=[lambda value, **options: None])

    # Assertion
    with pytest.raises(ValidationError):
        validate_with_positions(token=token_0, validator=validator_0)

    # Setup
    token_0 = None
    validator_0 = Schema()

    # Assertion
    with pytest.raises(ValidationError):
        validate_with_positions(token=token_0, validator=validator_0)

    # Setup
    token_0 = None
    validator_0 = Schema(validators=[lambda value, **options: None])

    # Assertion

# Generated at 2022-06-26 10:39:01.823492
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Create mock objects
    validator = Field(primitive="string", name="name")
    validator.lookup = lambda key: Token(value="foo", start=Position(0, 0, 0), end=Position(1, 1, 1))
    validator.validate = lambda value: value
    token = Token(value=None, start=Position(0, 0, 0), end=Position(1, 1, 1))

    # Call function
    result = validate_with_positions(token=token, validator=validator)
    assert result == None

# Generated at 2022-06-26 10:39:12.512790
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # assert validate_with_positions((str, None, False), None, None) is None
    # assert validate_with_positions(False, None, any_0) is None
    # assert validate_with_positions(None, any_0, None) is None
    # assert validate_with_positions(any_0, any_0, any_0) is None
    # assert validate_with_positions(token_1, token_1, token_1) is None
    # assert validate_with_positions(token_0, None, None) is None
    assert True


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:39:22.046079
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import unittest
    import sys
    import os

    class TestValidateWithPositions(unittest.TestCase):
        def test_case_0(self):
            token_0 = None
            any_0 = validate_with_positions(token=token_0, validator=token_0)

    module = sys.modules[__name__]
    unittest.main(module=module, argv=[os.path.abspath(__file__)], exit=False)

# Generated at 2022-06-26 10:39:25.990134
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = None
    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert any_0 == None

# Generated at 2022-06-26 10:39:32.530253
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(token=None, validator=None) == None
    assert validate_with_positions(token=None, validator=None) == None
    assert validate_with_positions(token=None, validator=None) == None
    assert validate_with_positions(token=None, validator=None) == None
    assert validate_with_positions(token=None, validator=None) == None

# Generated at 2022-06-26 10:39:33.777063
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False


# Generated at 2022-06-26 10:40:09.115342
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert (
        validate_with_positions(validator=validate_with_positions,
            token=validate_with_positions)
        is None
    )

# Generated at 2022-06-26 10:40:13.710041
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print('Running test_validate_with_positions...')
    if test_case_0() is None:
        print('Test 1 OK!')
    else:
        print('Test 1 FAILED!')


# test_validate_with_positions()

# Generated at 2022-06-26 10:40:15.641885
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:40:24.482612
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = None
    # Uncomment the following line to enable debug output
    # debug.enable()
    ret_0 = validate_with_positions(token=token_0, validator=validator_0)
    try:
        assert ret_0 is None
    except AssertionError as e:
        raise AssertionError(
            "Unable to verify return value for validate_with_positions"
        ) from e

# Generated at 2022-06-26 10:40:36.284352
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    try:
        any_0 = validate_with_positions(token=token_0, validator=token_0)
    except ValidationError as e:
        assert e.messages() == [
            Message(
                text="The field 'undefined' is required.",
                code="required",
                index=[],
                start_position=Position(char_index=0, line_index=0, column_index=0),
                end_position=Position(char_index=0, line_index=0, column_index=0),
            )
        ]
    else:
        raise AssertionError("Expected ValidationError to be raised")

# Generated at 2022-06-26 10:40:40.347415
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0: typing.Any = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:40:43.679212
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert "the field 'name' is required" not in str(test_case_0).lower()

# End of generated test cases.

# Generated at 2022-06-26 10:40:45.978273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 is None

# Generated at 2022-06-26 10:40:58.540104
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # This example is taken from Token.py
    token = Token("0", "value", 0, 1, 0, 1, 1, 1)
    Field(type="integer").validate(token.value)
    # This example is taken from TestSchema.py
    TestSchema(fields={"foo": Field(type="integer")}).validate({"foo": "bar"})
    # This example is taken from TestVariants.py
    t = Field(type="variant", variants=[Field(type="string"), Field(type="integer")])
    t.validate("bar")
    # This example is taken from TestSchema.py