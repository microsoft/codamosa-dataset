

# Generated at 2022-06-26 10:31:06.714493
# Unit test for function validate_with_positions
def test_validate_with_positions():
    str_1 = 'aT0'
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=str_1)
    str_2 = 'P^a'
    any_1 = validate_with_positions(token=token_0, validator=str_2)
    str_3 = '{XH'
    any_2 = validate_with_positions(token=token_0, validator=str_3)
    str_4 = 'zB8'
    any_3 = validate_with_positions(token=token_0, validator=str_4)
    str_5 = 'z'
    any_4 = validate_with_positions(token=token_0, validator=str_5)

# Generated at 2022-06-26 10:31:21.496215
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # print("Test 0")
    try:
        test_case_0()
    except ValidationError as error:
        assert error.messages[0].code == "required", "The code did not match, actual result is: " + str(error.messages[0].code)
        assert error.messages[0].text == "The field None is required.", "The text did not match, actual result is: " + str(error.messages[0].code)
        assert error.messages[0].start_position.line == None, "The start line did not match, actual result is: " + str(error.messages[0].start_position.line)

# Generated at 2022-06-26 10:31:22.237936
# Unit test for function validate_with_positions
def test_validate_with_positions(): # type: ignore
    test_case_0()

# Generated at 2022-06-26 10:31:25.939348
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert not('abc' == 'xyz')
    assert 'abc' == 'abc'
    
    assert not test_case_0()

# Generated at 2022-06-26 10:31:29.553666
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True # TODO: implement your test here

# ---------------------------------------------------------------------
# Parse current file as a testing module
#
if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-26 10:31:34.312773
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError as error:
        expected = [
            { "text": "The field 'qM0' is required." }
        ]
        assert error.messages() == expected
    else:
        assert False

# Generated at 2022-06-26 10:31:35.127137
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:31:44.141230
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(start=Position(row=0, column=0, char_index=0), end=Position(row=0, column=3, char_index=3), value=4)
    schema = Field(primitive="string")
    try:
        validate_with_positions(token=token, validator=schema)
    except ValidationError as error:
        assert error.messages[0].text == "Expected string, but got `4`."
        assert error.messages[0].start_position.row == 0
        assert error.messages[0].start_position.column == 0
        assert error.messages[0].start_position.char_index == 0
        assert error.messages[0].end_position.row == 0
        assert error.messages[0].end_position.column == 3


# Generated at 2022-06-26 10:31:45.088907
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert False, "Test not implemented."

# Generated at 2022-06-26 10:31:50.245057
# Unit test for function validate_with_positions
def test_validate_with_positions():
    print("Testing validate_with_positions")
    try:
        test_case_0()
    except ValidationError as e:
        print('caught ValidationError:')
        for msg in e.messages():
            print(msg.text)
    else:
        print('ok')
    print('')

if __name__ == '__main__':
    test_validate_with_positions()

# Generated at 2022-06-26 10:31:56.367572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    def run_test(test_case):
        test_case()
    run_test(test_case_0)

# Generated at 2022-06-26 10:32:05.715727
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typesystem

    schema = typesystem.Schema(
        {
            "first_name": typesystem.String(required=True),
            "last_name": typesystem.String(required=True),
        }
    )
    token = Token.from_object({"last_name": "Doe"})
    try:
        schema.validate(token.value)
    except ValidationError as error:
        assert error.messages() == [
            Message(
                text="The field 'first_name' is required.",
                code="required",
                index=["first_name"],
            )
        ]


# Generated at 2022-06-26 10:32:17.431084
# Unit test for function validate_with_positions
def test_validate_with_positions():
    obj_0 = validate_with_positions(
        token=Token(
            value={u"username": u"abc", u"password": u"def"},
            start=StartPosition(offset=0, line=1, column=1, char_index=0),
            end=EndPosition(offset=0, line=1, column=1, char_index=0),
        ),
        validator=User,
    )
    obj_0 = validate_with_positions(
        token=Token(
            value={u"username": u"abc"},
            start=StartPosition(offset=0, line=1, column=1, char_index=0),
            end=EndPosition(offset=0, line=1, column=1, char_index=0),
        ),
        validator=User,
    )

# Generated at 2022-06-26 10:32:19.294844
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Object({"hello": "world"}, 0, 1)
    enumerable_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:32:23.891785
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test if any exception is raised
    try:
        validate_with_positions()
        validate_with_positions()
    except Exception:
        assert False


# Generated at 2022-06-26 10:32:25.404317
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Assert if the function validates as expected.
    assert True



# Generated at 2022-06-26 10:32:29.327985
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token("string", "hello-world", "a/b/c", (1, 2, 3), (3, 4, 5))
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert isinstance(any_0, typing.Any)


# Generated at 2022-06-26 10:32:30.469252
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions


# Generated at 2022-06-26 10:32:44.264309
# Unit test for function validate_with_positions

# Generated at 2022-06-26 10:32:53.355822
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Test good case
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

    # Test error case: missing required named argument
    try:
        validate_with_positions(token=token_0)
    except Exception as e:
        if not isinstance(e, TypeError):
            raise AssertionError("Unexpected exception type")

    # Test error case: missing required named argument
    try:
        validate_with_positions(validator=token_0)
    except Exception as e:
        if not isinstance(e, TypeError):
            raise AssertionError("Unexpected exception type")

# Generated at 2022-06-26 10:33:11.093221
# Unit test for function validate_with_positions
def test_validate_with_positions():

    # Test with an instance of str
    token_0 = Token(
        value=["fizz", "buzz", "foo", "bar"], start=1, end=2, parent=None
    )
    try:
        any_0 = validate_with_positions(token=token_0, validator=Field(required=True))
    except ValidationError as error:
        messages = []
        for message in error.messages():
            if message.code == "required":
                field = message.index[-1]
                token = token_0.lookup(message.index[:-1])
                text = f"The field {field!r} is required."
            else:
                token = token_0.lookup(message.index)
                text = message.text


# Generated at 2022-06-26 10:33:22.227127
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Validator:

        @classmethod
        def _validate(
            cls, value: typing.Any, **kwargs: typing.Any
        ) -> typing.Any:
            pass

    assert issubclass(Validator, Field)

    assert not hasattr(Validator._validate, "__doc__")

    def decorator(
        *, token: Token, validator: typing.Union[Field, typing.Type[Schema]]
    ) -> typing.Any:
        try:
            return validator.validate(token.value)
        except ValidationError as error:
            messages = []
            for message in error.messages():
                if message.code == "required":
                    field = message.index[-1]
                    token = token.lookup(message.index[:-1])

# Generated at 2022-06-26 10:33:25.143240
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except ValidationError as error:
        for message in error.messages():
            assert isinstance(message.text, str)
            assert isinstance(message.code, str)
            assert isinstance(message.index, tuple)

# Generated at 2022-06-26 10:33:27.146812
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token.parse('{"value": 12}')
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:33:33.118970
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # call with positional arg Token, Union[Field, Type[Schema]]
    json_field = Field(type="string")
    token = Token(json_field, "foo", None, None)
    assert validate_with_positions(token=token, validator=json_field) == "foo"

    # call with named args Token, Union[Field, Type[Schema]]
    json_field = Field(type="string")
    token = Token(json_field, "foo", None, None)
    assert validate_with_positions(token=token, validator=json_field) == "foo"

    # call with nested named args Token, Union[Field, Type[Schema]]
    json_field = Field(type="string")
    token = Token(json_field, "foo", None, None)
    assert validate_with_pos

# Generated at 2022-06-26 10:33:43.777572
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(
        value=dict(foo=123),
        start=Position(line=1, char_index=1),
        end=Position(line=1, char_index=10),
    )
    validator_0 = Field(name="foo", type=str)
    with pytest.raises(ValidationError) as exc_info:
        test_case_0()
    assert len(exc_info.value.messages) == 1
    assert (
        exc_info.value.messages[0].text
        == "Ensure this value is less than or equal to 10."
    )
    assert exc_info.value.messages[0].index == ("foo",)

# Generated at 2022-06-26 10:33:52.926195
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    any_1 = None
    any_2 = None
    any_3 = None
    any_4 = None
    any_5 = None
    any_6 = None
    any_7 = None
    any_8 = None
    any_9 = None
    any_10 = None
    any_11 = None
    any_12 = None
    any_13 = None
    any_14 = None
    any_15 = None
    any_16 = None
    any_17 = None
    any_18 = None

    # Test case 0
    test_case_0()

# Generated at 2022-06-26 10:33:57.642853
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        assert False
    except ValidationError as error:
        messages = error.messages()
        assert len(messages) == 1
        assert messages[0].index == ('0',)
        assert (
            messages[0].text == "The field 0 is required."
        )
        assert messages[0].code == "required"
        assert messages[0].end_position.char_index == 0

# Generated at 2022-06-26 10:34:00.353473
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        test_case_0()
    except Exception:
        assert False


if __name__ == "__main__":
    test_validate_with_positions()

# Generated at 2022-06-26 10:34:06.736146
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Item(Schema):
        name = Field(type="string")

    class List(Schema):
        items = Field(type="array", items=Item)

    token = Token.parse(
        {
            "items": [{"name": "John"}, {"name": "Paul"}],
            "name": "Beatles",
            "id": 1,
        },
        "abcd",
    )

    validate_with_positions(token=token, validator=List)



# Generated at 2022-06-26 10:34:32.873117
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = validate_with_positions(token=None, validator=None)

    any_1 = validate_with_positions(token=None, validator=None)

    any_2 = validate_with_positions(token=None, validator=None)

    any_3 = validate_with_positions(token=None, validator=None)

    any_4 = validate_with_positions(token=None, validator=None)

    any_5 = validate_with_positions(token=None, validator=None)

    any_6 = validate_with_positions(token=None, validator=None)

    any_7 = validate_with_positions(token=None, validator=None)

    any_8 = validate_with_positions(token=None, validator=None)

   

# Generated at 2022-06-26 10:34:39.309386
# Unit test for function validate_with_positions
def test_validate_with_positions():
    a = None
    # Positional arguments (5)
    try:
        b = validate_with_positions(a, a, a, a, a)
        assert False
    except TypeError:
        assert True

    # Keyword arguments (5)
    try:
        b = validate_with_positions(a=a, b=a, c=a, d=a, e=a)
        assert False
    except TypeError:
        assert True

# Generated at 2022-06-26 10:34:42.261369
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # Positional arguments
    token_0 = None
    validator_0 = None

    # Test function
    assert validate_with_positions(token=token_0, validator=validator_0) is None, "Expected None"



# Generated at 2022-06-26 10:34:42.869330
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:34:44.400320
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:34:57.023593
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    token_1 = None
    token_2 = None
    token_3 = None
    token_4 = None
    token_5 = None
    token_6 = None
    token_7 = None
    token_8 = None
    token_9 = None
    token_10 = None


# Generated at 2022-06-26 10:35:06.057677
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    token_1 = None
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    token_2 = None
    any_2 = validate_with_positions(token=token_2, validator=token_2)
    token_3 = None
    any_3 = validate_with_positions(token=token_3, validator=token_3)
    token_4 = None
    any_4 = validate_with_positions(token=token_4, validator=token_4)
    token_5 = None
    any_5 = validate_with_positions(token=token_5, validator=token_5)
   

# Generated at 2022-06-26 10:35:10.903683
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # type-specific test-cases for validate_with_positions
    validator_0 = None
    token_0 = None
    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(token=token_0, validator=validator_0)

# Generated at 2022-06-26 10:35:14.199135
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=token_0)

# Generated at 2022-06-26 10:35:25.208160
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token = Token(
        value="simple string",
        start=Position(line=Line(number=1, start_char_index=0, end_char_index=1)),
        end=Position(line=Line(number=1, start_char_index=1, end_char_index=2)),
    )
    schema = Field(type="string")
    validate_with_positions(token=token, validator=schema)

    # Case 0
    class ClassWithPositionalError(Schema):
        _default_error_messages = {"invalid": "Invalid value."}

        field = Field(type="integer", required=True)

        def clean_field(self, value):
            raise Exception("Some error")


# Generated at 2022-06-26 10:35:48.837635
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    validator_0 = Field(type="string")
    with raises(ExpectedTypeError):
        validate_with_positions(token=token_0, validator=validator_0)
    
    token_1 = Token()
    validator_1 = Field(type="string")
    with raises(NotImplementedError):
        validate_with_positions(token=token_1, validator=validator_1)
    
    token_2 = Token()
    validator_2 = Field(type="string")
    with raises(NotImplementedError):
        validate_with_positions(token=token_2, validator=validator_2)

# Testing function validate_with_positions

# Generated at 2022-06-26 10:35:52.664877
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_1 = Token()


    # Call validate_with_positions
    any_1 = validate_with_positions(token=token_1, validator=token_1)
    raise NotImplementedError()



# Generated at 2022-06-26 10:35:54.153805
# Unit test for function validate_with_positions
def test_validate_with_positions():
    pass

# Generated at 2022-06-26 10:35:57.115561
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None #type: ignore[var-annotated]
    any_0 = validate_with_positions(token=token_0, validator=token_0)



# Generated at 2022-06-26 10:35:58.727757
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# vim: sw=4:et:ai

# Generated at 2022-06-26 10:36:00.945905
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pytest
    with pytest.raises(ValidationError):
        validate_with_positions(validator=None, token=None)

# Generated at 2022-06-26 10:36:09.951124
# Unit test for function validate_with_positions
def test_validate_with_positions():

    class Field0(Field):
        pass

    field_0 = Field0()  # type: Field
    token_0 = None
    any_0 = validate_with_positions(token=token_0, validator=field_0)

    class Schema0(Schema):
        pass

    schema_0 = Schema0()  # type: Schema
    any_0 = validate_with_positions(token=token_0, validator=schema_0)



# Generated at 2022-06-26 10:36:11.099742
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert True

# Generated at 2022-06-26 10:36:12.698933
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert(validate_with_positions
        (
            token = "a string",
            validator = int
        ) == 0
    )

# Generated at 2022-06-26 10:36:22.790259
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import pouette
    from unittest.mock import Mock
    from typesystem.tokenize.tokens import Token
    from typesystem.schemas import Schema, Field, List
    from typesystem.base import ValidationError
    from typesystem.fields import Integer
    from typing import Any, Union, List as List_

    class MockMessage(Mock):
        text: str
        code: str
        index: List_[Any]
        start_position: Mock
        end_position: Any

    message_1 = MockMessage()
    message_1.text = "bar-foo"
    message_1.code = "string"
    message_1.index = ["x"]
    message_1.start_position = Mock()
    message_1.end_position = 1
    message_2 = MockMessage()
   

# Generated at 2022-06-26 10:36:53.302736
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = validate_with_positions()


# Generated at 2022-06-26 10:36:55.207681
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert any_0 == 1

# Generated at 2022-06-26 10:37:03.758042
# Unit test for function validate_with_positions
def test_validate_with_positions():
    message_2 = Message(text="The field 'foo' is required.", code="required")
    index_0 = []
    start_position_0 = StartPosition(0, 39, 0)
    end_position_0 = EndPosition(0, 44, 0)
    positional_message_0 = Message(text="The field 'foo' is required.", code="required", index=index_0, start_position=start_position_0, end_position=end_position_0)
    message_3 = Message(text="The field 'bar' is required.", code="required")
    index_1 = []
    start_position_1 = StartPosition(0, 41, 0)
    end_position_1 = EndPosition(0, 46, 0)

# Generated at 2022-06-26 10:37:12.617335
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        ast = parse_source_code(test_case_0, ast_type=astroid.scoped_nodes.Module)
    except astroid.exceptions.InferenceError:
        assert False

    graph = astroid_to_graph(ast)
    graph_renderer = GraphRenderer(graph, graph_attrs={"rankdir": "TB"})
    graph_renderer.to_dot(test_case_0.__name__ + ".dot")
    graph_renderer.to_png(test_case_0.__name__ + ".png")
    graph_renderer.to_pdf(test_case_0.__name__ + ".pdf")
    graph_renderer.to_svg(test_case_0.__name__ + ".svg")
    graph_renderer.to_json

# Generated at 2022-06-26 10:37:16.117927
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class Schema1(Schema):
        field_0 = Field(type=int)

    value = {"field_0": "1"}
    schema = Schema1()

    schema.validate(value)

# Generated at 2022-06-26 10:37:26.866584
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    assert validate_with_positions(token=token_0, validator=token_0) == None
    token_1 = Token(value=None, start=None, end=None)
    assert validate_with_positions(token=token_1, validator=token_1) == None
    token_2 = Token(value=None, start=None, end=None)
    token_2.query_result_token = None
    assert validate_with_positions(token=token_2, validator=token_2) == None
    token_3 = Token(value=None, start=None, end=None)
    token_3.query_result_token = None
    token_3.subtokens = []

# Generated at 2022-06-26 10:37:35.681545
# Unit test for function validate_with_positions
def test_validate_with_positions():
    text = "a\nb\nc\n"

    token_0 = Token.create(
        value="abc",
        start=RowColPos(row=0, col=0),
        end=RowColPos(row=2, col=0),
        text=text,
    )

    validator_0 = Field(type="string")

    any_0 = validate_with_positions(token=token_0, validator=validator_0)
    assert any_0 == "abc"



# Generated at 2022-06-26 10:37:37.602300
# Unit test for function validate_with_positions
def test_validate_with_positions():
    try:
        data = validate_with_positions()
        # this should not happen
        assert False
    except TypeError:
        pass

# Generated at 2022-06-26 10:37:44.839625
# Unit test for function validate_with_positions
def test_validate_with_positions():
    any_0 = None
    any_1 = None
    any_2 = None
    any_3 = None
    any_4 = None
    any_5 = None
    any_6 = None
    any_7 = None
    any_8 = None
    any_9 = None
    any_10 = None
    any_11 = None
    any_12 = None
    any_13 = None
    any_14 = None
    any_15 = None
    any_16 = None
    any_17 = None
    any_18 = None
    any_19 = None
    any_20 = None
    any_21 = None
    any_22 = None
    any_23 = None
    any_24 = None
    any_25 = None
    any_26 = None
    any_27 = None
    any_

# Generated at 2022-06-26 10:37:46.747192
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import typing
    import typesystem.tokenize.tokens

    token_0 = None
    validator_0 = token_0

    with pytest.raises(TypeError):
        validate_with_positions(token=token_0, validator=validator_0)


# Generated at 2022-06-26 10:38:53.731759
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # TODO: implement test
    pass

# Generated at 2022-06-26 10:38:57.355550
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = Token(value={})
    any_0 = validate_with_positions(token=token_0, validator=token_0)
    assert any_0 == {}

# Generated at 2022-06-26 10:39:04.906841
# Unit test for function validate_with_positions
def test_validate_with_positions():
    class validator(Schema):
        query = {
            "field": Field(required=True)
        }
        body = {"key": Field(required=True)}

    schema = validator()

    # Default Token
    token = Token(
        name="name",
        value={"query": {"field": "value"}, "body": {"key": "value"}},
        start={"line_number": 1, "char_index": 0},
        end={"line_number": 1, "char_index": 20},
    )
    validated_value = validate_with_positions(token=token, validator=schema)
    assert validated_value == token.value

    # Token with value not validated
    token = Token(
        name="name", value={"query": {"field": "value"}, "body": {}},
    )


# Generated at 2022-06-26 10:39:11.906952
# Unit test for function validate_with_positions
def test_validate_with_positions():
    # strings
    assert validate_with_positions(token=token_0, validator=field_0) == \
        "any_0"
    assert validate_with_positions(token=token_1, validator=field_1) == \
        "any_1"
    assert validate_with_positions(token=token_2, validator=field_2) == \
        "any_2"


# Generated at 2022-06-26 10:39:24.191021
# Unit test for function validate_with_positions
def test_validate_with_positions():
    import datetime
    import typing
    import pytest
    from typesystem import errors, fields, schemas, tokenize
    from typesystem.schemas import Schema

    from .utils import AssertValidationErrors

    def get_schema() -> Schema:
        return schemas.Schema(
            {
                "id": fields.Int(),
                "name": fields.String(),
                "updated_at": fields.Date(),
            }
        )

    token_0 = tokenize.Token(
        "object",
        {
            "id": tokenize.Token("integer", 42),
            "name": tokenize.Token("string", "hello"),
            "updated_at": tokenize.Token("string", "2018-01-01"),
        },
    )

# Generated at 2022-06-26 10:39:33.798273
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert validate_with_positions(
        token=Token(start=None, end=None, value=1),
        validator=Field(type=int),
    ) == 1

    with pytest.raises(ValidationError) as exc_info:
        validate_with_positions(
            token=Token(start=None, end=None, value=1),
            validator=Field(type=str),
        )

    expected_message = Message(
        code="invalid_type",
        index=(),
        text="Must be a string.",
        start_position=None,
        end_position=None,
    )
    assert exc_info.value.messages() == [expected_message]

# Generated at 2022-06-26 10:39:35.374542
# Unit test for function validate_with_positions
def test_validate_with_positions():
    assert callable(validate_with_positions)

# Generated at 2022-06-26 10:39:44.578942
# Unit test for function validate_with_positions
def test_validate_with_positions():
    with pytest.raises(TypeError, message="The 'token' argument is required."):
        validate_with_positions()
    with pytest.raises(TypeError, message="The 'validator' argument is required."):
        validate_with_positions(token=None)
    with pytest.raises(TypeError, message="'validator' must be an instance of Field."):
        validate_with_positions(token=None, validator=None)
    with pytest.raises(TypeError, message="'validator' must be an instance of Field."):
        validate_with_positions(token=None, validator=None)

# Generated at 2022-06-26 10:39:45.919800
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None
    assert any_0 == None

# Generated at 2022-06-26 10:39:49.361859
# Unit test for function validate_with_positions
def test_validate_with_positions():
    token_0 = None # $ExpectedFailure
    any_0 = validate_with_positions(token=token_0, validator=token_0)