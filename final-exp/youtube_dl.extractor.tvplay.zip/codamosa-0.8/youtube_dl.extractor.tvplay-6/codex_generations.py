

# Generated at 2022-06-12 18:38:52.783142
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie.play_video({'url': 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'})
    ie.play_video({'url': 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'})
    ie.play_video({'url': 'https://play.tv3.lt/aferistai-10047125'})
    ie.play_video({'url': 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'})
    ie.play_video({'url': 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'})

# Generated at 2022-06-12 18:38:56.393063
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # check that the constructor is working fine
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-12 18:39:06.191815
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor_test(ViafreeIE, ['http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'])
    constructor_test(ViafreeIE, ['https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'])
    constructor_test(ViafreeIE, ['http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'])
    constructor_test(ViafreeIE, ['http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'])

# Generated at 2022-06-12 18:39:13.629985
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i = ViafreeIE()
    j = TVPlayIE()
    assert i.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not j.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:39:18.732099
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    country, path = re.match(ViafreeIE._VALID_URL, url).groups()
    content = json.loads(
        compat_urllib_request.urlopen(
            'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s' % (country, path))
        .read().decode('utf-8'))
    program = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']
    guid = program['guid']

# Generated at 2022-06-12 18:39:28.394773
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .youtube_dl.extractor.common import InfoExtractor
    from .youtube_dl.extractor.livestream import LivestreamIE
    from .youtube_dl.extractor.tvplay import TVPlayIE
    from .youtube_dl.extractor.mtg import MTGIE
    viafree_ie = ViafreeIE()
    assert isinstance(viafree_ie, InfoExtractor)
    assert viafree_ie._WORKING == False
    assert viafree_ie.IE_NAME == 'viafree'
    assert viafree_ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert isinstance(ViafreeIE._ies[0], LivestreamIE)

# Generated at 2022-06-12 18:39:41.730657
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    input = {
        'url': 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        'info_dict': {
            'id': '366367',
            'ext': 'mp4',
            'title': 'Aferistai',
            'description': 'Aferistai. Kalėdinė pasaka.',
            'series': 'Aferistai [N-7]',
            'season': '1 sezonas',
            'season_number': 1,
            'duration': 464,
            'timestamp': 1394209658,
            'upload_date': '20140307',
            'age_limit': 18,
        },
        'params': {
            'skip_download': True,
        },
    }

# Generated at 2022-06-12 18:39:49.011269
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # test with URL prefixes that should match
    test_urls = [
        'https://tvplay.tv3.lt/aferistai-10047125/',
        'https://tvplay.skaties.lv/vinas-melo-labak-10280317/',
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354/',
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
    ]

# Generated at 2022-06-12 18:39:54.779520
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert ie.country == 'dk'
    assert ie.path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'

    ie = ViafreeIE("https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'


# Generated at 2022-06-12 18:40:00.824943
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(url)
    assert ie.url == url


# Generated at 2022-06-12 18:40:39.558560
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE('TVPlayHomeIE', 'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert instance._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:49.783349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie.suitable(url)
    assert ie.suitable(url+'?autostart=true') is False
    assert ie.suitable('http://www.tv3play.no/programmer/fotball-free/411428') is False
    assert ie.suitable('http://www.tv3play.se/program/husraddarna/395385') is False
    assert ie.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636') is False

# Generated at 2022-06-12 18:40:54.459716
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE('mtg', 'mtg', 'MTG services')
    assert 'MTG services' == IE.IE_DESC
    assert 'http://playapi.mtgx.tv/v3/videos/dummy_id' == IE._build_proxy_request('dummy_id')
    assert 'mtg:dummy_id' == IE._build_unsupported_url('dummy_id')


# Generated at 2022-06-12 18:40:55.911058
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test
    tvplay = TVPlayHomeIE()
    assert tvplay.name == 'TVPlay Home'

# Generated at 2022-06-12 18:40:56.557538
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE is not None)



# Generated at 2022-06-12 18:41:02.720998
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    from . import TVPlayIE
    from . import mtvservicesIE
    from . import MTVIE
    from . import ViafreeIE

    src = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    test_obj = ViafreeIE(MTVIE())
    res = test_obj._real_extract(src)
    assert res['id'] == '395385'
    assert res['title'] == 'Husräddarna S02E07'
    assert res['timestamp'] == 1400596321
    assert 'upload_date' in res

    src = 'http://www.tv3play.se/program/husraddarna/395385'
    test_obj = ViafreeIE(ViafreeIE(TVPlayIE()))
   

# Generated at 2022-06-12 18:41:12.945914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # pylint: disable=redefined-outer-name, unused-argument
    def fake_download_json(url, *args, **kwargs):
        class FakeResponse:
            def __init__(self):
                self.headers = {
                    'Content-type': 'application/json; charset=utf-8',
                }
        return FakeResponse()
    ViafreeIE._download_json = fake_download_json

    # ViafreeIE should not extract TVPlayIE working url
    assert 'tvplay' not in ViafreeIE.suitable(TVPlayIE._VALID_URL)

    # ViafreeIE should always be suitable for ViafreeIE working url
    for url in ViafreeIE._TESTS:
        assert ViafreeIE.suitable(url['url'])

# Generated at 2022-06-12 18:41:24.809176
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-12 18:41:30.080551
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(ViafreeIE.working_class(), url)
    assert(ie.geo_country == 'NO')


# Generated at 2022-06-12 18:41:31.525735
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-12 18:42:13.129791
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test for TVPlayHomeIE constructor
    """
    tvplayhome = TVPlayHomeIE()
    assert tvplayhome.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125')
    assert tvplayhome.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-12 18:42:20.980536
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:42:24.181222
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_input = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = IE_NAME.create_ie(test_input)
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-12 18:42:28.778115
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test if ViafreeIE is not mixed up with TVPlayIE
    instance = ViafreeIE()
    ViafreeIE.suitable(instance, 'http://www.viafree.se/program/husraddarna/sasong-2/avsnitt-1')
    try:
        ViafreeIE.suitable(instance, 'http://www.tv4play.se/program/husraddarna/sasong-2/avsnitt-1')
    except Exception:
        pass

# Generated at 2022-06-12 18:42:35.657980
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    

# Generated at 2022-06-12 18:42:45.098410
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE._build_url_result(TVPlayIE._VALID_URL, 'lv', '418113')
    assert a == 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    b = TVPlayIE._build_url_result(TVPlayIE._VALID_URL, 'lt', '238551')
    assert b == 'http://www.tv3play.lt/programos/kodu-keset-linna/238551?autostart=true'
    c = TVPlayIE._build_url_result(TVPlayIE._VALID_URL, 'ee', '238551')

# Generated at 2022-06-12 18:42:53.479271
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def __init__(self, *args, **kwargs):
            super(TestTVPlayHomeIE, self).__init__(*args, **kwargs)
            self.valid_url = self.__class__._VALID_URL
            self.content_result = None
            self.init()

        def _download_webpage(self, url, video_id, note='Downloading video page', errnote='unable to download video page'):
            if url == urljoin(self.valid_url, '/sb/public/asset/' + self.content_result['assetId']):
                return self.content_result
            else:
                raise KeyError('Unknown URL')


# Generated at 2022-06-12 18:43:03.637397
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if __name__ == '__main__':
        assert 'mtgx.tv' in TVPlayIE._VALID_URL
        if not ViafreeIE.suitable(TVPlayIE._VALID_URL):
            print('Unit test failed: URL %s not recognized' % TVPlayIE._VALID_URL)
        else:
            v = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
            assert v.country == 'dk'
            assert v.path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'
            print('Unit test passed: ViafreeIE constructor recognized URL %s correctly' % TVPlayIE._VALID_URL)


# Generated at 2022-06-12 18:43:05.704290
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert isinstance(ie, TVPlayHomeIE)



# Generated at 2022-06-12 18:43:17.690826
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    re_url = re.compile(ie._VALID_URL)
    assert re_url.match('http://www.viafree.se/program/reality/paradise-hotel/saeson-7/episode-5')
    assert re_url.match('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert re_url.match('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')

# Test for ViafreeIE._real_extract

# Generated at 2022-06-12 18:44:49.610220
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvpie = TVPlayIE()
    assert tvpie._VALID_URL == r'(?x)mtg:'
    assert tvpie.IE_NAME == 'mtg'
    assert tvpie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:44:50.990916
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    # Successful instantiation
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-12 18:44:56.166155
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE is a subclass of TVPlayBaseIE
    assert issubclass(ViafreeIE, TVPlayBaseIE)
    # ViafreeIE cannot handle video from TVPlayBaseIE
    assert not ViafreeIE.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-12 18:44:57.935957
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # This should work
    # The constructor should not throw an exception
    TVPlayIE('some_string')

# Generated at 2022-06-12 18:44:58.617574
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-12 18:45:00.292235
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    print(t)


# Generated at 2022-06-12 18:45:09.043061
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    assert IE.get_id_from_url('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') == '10044354'
    assert IE.get_id_from_url('https://play.tv3.lt/aferistai-10047125') == '10047125'
    assert IE.get_id_from_url('https://tv3play.skaties.lv/vinas-melo-labak-10280317') == '10280317'
    assert IE.get_id_from_url('https://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == '10280317'

# Generated at 2022-06-12 18:45:14.173403
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:45:15.043513
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie is not None


# Generated at 2022-06-12 18:45:17.884038
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable({})
    assert not ViafreeIE.suitable({'url': 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'})
    assert ViafreeIE.suitable({'url': 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'})

