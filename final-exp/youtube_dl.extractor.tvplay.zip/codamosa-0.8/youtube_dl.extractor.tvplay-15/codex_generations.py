

# Generated at 2022-06-12 18:38:39.326312
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-12 18:38:42.969589
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:38:54.158125
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import FakeInfoExtractor
    from .dash import DASHIE
    from .dash_manifest import DASHManifestIE
    from .f4m import F4MIE
    from .hls import HLSIE
    from .ism import ISMIE
    from .rtmp import RTMPIE
    from .smil import SMILIE
    from .mp4 import MP4IE
    from .youtube import YoutubeIE

    yt_ie = YoutubeIE()
    youporn_ie = FakeInfoExtractor()
    dm_ie = DASHManifestIE()
    smil_ie = SMILIE()
    hls_ie = HLSIE()
    mp4_ie = MP4IE()

    assert TVPlayIE()._get_supported_ie(yt_ie) == yt_ie
    assert TVPlayIE

# Generated at 2022-06-12 18:38:58.812363
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Arrange
    # Act
    ie = TVPlayHomeIE()

    # Assert
    assert ie.SUITABLE == TVPlayHomeIE._VALID_URL
    assert ie.GEO_BYPASS == False
    assert ie._GEO_COUNTRIES == ['LV', 'EE', 'LT']

# Generated at 2022-06-12 18:39:14.445877
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('ViafreeIE', 'http://www.viafree.se/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert isinstance(ie, ViafreeIE)
    assert ie.country is None
    assert ie.name == 'Viafree IE'
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?
                                    viafree\.(dk|no|se)
                                    /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                '''

# Generated at 2022-06-12 18:39:16.601287
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in TVPlayHomeIE._TESTS:
        # create a new instance; this should be executed the same as the code
        # in extractor.py
        TVPlayHomeIE(extractor=None, downloader=None, params=None)
#/ Unit test


# Generated at 2022-06-12 18:39:18.008432
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE.suitable(ViafreeIE.suitable)

# Generated at 2022-06-12 18:39:28.148540
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    klass = util.get_IE(url)
    assert klass is TVPlayIE, 'class'
    obj = klass(url)
    assert obj is not None, 'object'
    assert obj.ie_key() == 'tvplay.se', 'ie name'
    assert obj.ie_desc() == 'MTG services', 'description'

# Generated at 2022-06-12 18:39:32.303259
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE()
    assert not IE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')


# Generated at 2022-06-12 18:39:44.211825
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE._initialize_geo_bypass({'countries': ['LV']})
    test_url = 'http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true'
    ie = TVPlayIE(test_url)
    video_id = ie._match_id(test_url)
    ie._download_json(
        'http://playapi.mtgx.tv/v3/videos/%s' % video_id, video_id, 'Downloading video JSON')
    ie._download_json(
        'http://playapi.mtgx.tv/v3/videos/stream/%s' % video_id,
        video_id, 'Downloading streams JSON')

# Generated at 2022-06-12 18:40:05.617364
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_cases = [
        ('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', 1),
        ('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', 0),
    ]
    for url, expected_result in test_cases:
        result = ViafreeIE.suitable(url)
        assert result == expected_result


# Generated at 2022-06-12 18:40:07.931209
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie is not None


# Generated at 2022-06-12 18:40:15.061520
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    href = "https://www.viafree.no/programmer/serier/american-horror-story/sesong-1/episode-1"

# Generated at 2022-06-12 18:40:16.596698
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(youtube_ie)

# Generated at 2022-06-12 18:40:19.638413
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE(None)
    assert 'country' in IE.get_testcases()[0]['url'] or 'dk' in IE.get_testcases()[0]['url']



# Generated at 2022-06-12 18:40:20.825902
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-12 18:40:24.240526
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-12 18:40:29.708725
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/ogled-odprtih-vrat-1-del/odprta-vra_a-10044309/') is False


# Generated at 2022-06-12 18:40:32.656603
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('https://www.tv6play.se/program/husraddarna/395385?autostart=true')
    assert ie.geo_countries is None


# Generated at 2022-06-12 18:40:35.403613
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert class_exists(TVPlayIE, TVPlayIE.IE_NAME)



# Generated at 2022-06-12 18:41:16.487457
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj.suitable('foo') is False
    assert obj.suitable('https://play.tv3.lt/aferistai-10047125') is True
    assert obj.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317') is True
    assert obj.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') is True

# Generated at 2022-06-12 18:41:20.883454
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test basic properties and method of class TVPlayIE
    ie = TVPlayIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL

    # test method '_real_extract'
    # ie._real_extract('http://play.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-12 18:41:32.865596
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Constructor test
    """
    ie = ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._VALID_URL == 'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._TESTS[2]['url'] == 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    assert ie._TESTS[2]['only_matching']

# Generated at 2022-06-12 18:41:38.071846
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:41:40.585845
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert str(ie) == '<mtg>'

# Generated at 2022-06-12 18:41:45.438370
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '366367'
    asset = '{"assetId": "366367", "countryOfOrigin": "USA", "title": {"title": "Aferistai", "titleBrief": "Kal\u0117din\u0117 pasaka.", "runTime": "PT7M44S"}, "movie": {"contentUrl": "https://balkanvod.cdn.rt.lv/balkanvod/f/466a7d8c-6d33-4c48-b4f7-2a2933f9c9b1/playlist.m3u8"}, "mediaType": "CLIP"}'

    tvplay = TVPlayHomeIE({"asset": asset})

# Generated at 2022-06-12 18:41:48.765875
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for correct matching of parent TVPlayIE
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760231')


# Generated at 2022-06-12 18:41:56.693991
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert re.match(ViafreeIE._VALID_URL, 'https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert re.match(ViafreeIE._VALID_URL,'https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert re.match(ViafreeIE._VALID_URL,'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:42:01.917873
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == "mtg"
    assert TVPlayIE().IE_DESC != ""
    assert TVPlayIE()._VALID_URL != ""
    assert TVPlayIE()._TESTS != ""

if __name__ == '__main__':
    test_TVPlayIE()

# Generated at 2022-06-12 18:42:05.447831
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    ie.extract()
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    ie.extract()
    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    ie.extract()

# Generated at 2022-06-12 18:43:17.775511
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    inst = TVPlayIE()
    assert isinstance(inst, InfoExtractor)



# Generated at 2022-06-12 18:43:25.566979
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test TVPlayHomeIE.__init__()."""
    # Test for URL without country part
    assert r'regex:https?://(?:tv3?)?play\.tv3\.lt/(?:[^/]+/)*[^/?#&]+-\d+' == TVPlayHomeIE._VALID_URL
    # Test for URLs with country part
    for tld in [ 'lv', 'ee' ]:
        assert r'regex:https?://(?:tv3?)?play\.tv3\.' + tld + '/' == TVPlayHomeIE._VALID_URL



# Generated at 2022-06-12 18:43:35.593596
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    constructor_test(TVPlayHomeIE, [
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'https://tvplay.tv3.lt/vinas-melo-labak-10280317',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/vinas-melo-labak-10280317',
        'https://tvplay.tv3.ee/vinas-melo-labak-10280317',
        'https://play.tv3.lt/vinas-melo-labak-10280317'
    ])

# Generated at 2022-06-12 18:43:38.536788
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL == r'(?x)mtg:(?P<id>\d+)'



# Generated at 2022-06-12 18:43:39.337028
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:43:40.607338
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check that constructor of class ViafreeIE is private
    with pytest.raises(Exception):
        ViafreeIE()


# Generated at 2022-06-12 18:43:44.569602
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test if the first part of the function is working
    assert ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL

    # Test if the second part of the function is working
    assert ViafreeIE()._TESTS == ViafreeIE._TESTS

    # Test if the third part of the function is working
    assert ViafreeIE()._GEO_BYPASS == ViafreeIE._GEO_BYPASS



# Generated at 2022-06-12 18:43:47.744463
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = "http://www.tvplay.lv/parraides/vinas-melo-labak/418113"
    ie = TVPlayIE()
    ie.IE_NAME = 'test'
    result = ie.get_info(url)
    assert result['id'] == '418113'
    assert result['title'] == 'Kādi ir īri? - Viņas melo labāk'

# Generated at 2022-06-12 18:43:56.676512
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    init_attr = ('_TESTS',)
    test_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    viafree_test_url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'

    # Init a class
    viafree_ie = ViafreeIE()

    # Assert attributes which should be in init
    for attr in init_attr:
        assert(hasattr(viafree_ie, attr))

    # Assert that this site sould be suitable for this class
    assert(ViafreeIE.suitable(test_url))

# Generated at 2022-06-12 18:43:59.658936
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'tv3play.tv3.ee/vinas-melo-labak-10282146/vinas-melo-labak-10282146/'
    ie = TVPlayHomeIE()
    ie._real_extract(url)



# Generated at 2022-06-12 18:47:19.297797
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:47:23.807819
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE(TVPlayHomeIE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    except Exception as e:
        assert False
    try:
        TVPlayHomeIE(TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    except Exception as e:
        assert False

# Generated at 2022-06-12 18:47:25.200876
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()



# Generated at 2022-06-12 18:47:27.763998
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # class TVPlayHomeIE(InfoExtractor)
    TVPlayHomeIE()
    # TODO: Add more tests

# Generated at 2022-06-12 18:47:31.001419
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    except:
        assert False

# Generated at 2022-06-12 18:47:34.280816
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    (ViafreeIE.suitable)('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-12 18:47:35.429470
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE()
    assert (obj != None)

# Generated at 2022-06-12 18:47:37.186366
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE.suitable('')
        assert False
    except AssertionError:
        assert True


# Generated at 2022-06-12 18:47:43.393072
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') == True
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == True
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') == True
    assert ie.suitable('http://www.tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true') == False

# Generated at 2022-06-12 18:47:45.894667
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1').constructor, ViafreeIE)

