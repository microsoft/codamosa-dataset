

# Generated at 2022-06-12 18:38:45.853493
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE

# Generated at 2022-06-12 18:38:55.187254
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_object = TVPlayIE()
    expected_output = 'mtg'
    input_url = 'http://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true'
    assert (test_object._match_id(input_url) == '764300'), "ERROR: test_TVPlayIE test_match_id"
    assert (test_object.IE_NAME == expected_output), "ERROR: test_TVPlayIE test_IE_NAME"
    input_url = 'https://www.tv3play.dk/programmer/kontant/'

# Generated at 2022-06-12 18:39:10.220469
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print('test tvplay ie construction')

# Generated at 2022-06-12 18:39:20.513964
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'mtg:tvplayhome'
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TEST != {}
    assert ie._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

# Generated at 2022-06-12 18:39:27.786743
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-12 18:39:30.540893
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL


# Generated at 2022-06-12 18:39:33.922402
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE('https://tvplay.tv3.lt/showlabas-par-nakti-20170209/pasakos-nakti-10312018/') is not None


# Generated at 2022-06-12 18:39:39.121318
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('Viafree', 'no')
    assert ie.SUCCESSFUL_LOGIN_REGEX is None
    assert ie.GEO_COUNTRIES == [u'SE', u'NO', u'DK']


# Generated at 2022-06-12 18:39:40.558992
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ThumbnailExtractor.test_constructor(ViafreeIE)



# Generated at 2022-06-12 18:39:50.286206
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert ie._match_id('http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true') == '409229'
    assert ie._match_id('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true') == '418113'
    assert ie._match_id('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true') == '418113'

# Generated at 2022-06-12 18:40:12.008823
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL

    # Test valid url
    url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    match = ie._VALID_URL_RE.search(url)
    assert match
    assert match.group('id').isdigit()
    assert match.group('id') == '409229'

    # Test invalid url
    url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/?autostart=true'
    assert not ie._VALID_URL_RE.search(url)

# Generated at 2022-06-12 18:40:23.547603
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from ._test_data import _TEST_DATA
    from . import _extractors as ae
    from . import _get_testcases_from_data as gt

    data = _TEST_DATA['TVPlayIE']
    for tests in data:
        for test in tests:
            ie_test_class = test['test_class']

            def _testcase(self):
                self._run_ie(link, test['expected'])

            # setting ie_test_class.setUpClass to fulfill pytest requirement
            if ie_test_class == TVPlayIE:
                ie_test_class.setUpClass = lambda cls: cls.setUpClass()


# Generated at 2022-06-12 18:40:25.291479
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvp = TVPlayIE()
    assert tvp.IE_DESC == 'MTG services'


# Generated at 2022-06-12 18:40:30.094971
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE(None)
    except Exception as inst:
        if not isinstance(inst, TypeError):
            print('Expected TypeError, but type of exception is ' + type(inst).__name__)
            print('Unexpected error: ' + inst)
            raise


# Generated at 2022-06-12 18:40:35.045714
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:35.587806
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE

# Generated at 2022-06-12 18:40:38.868181
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    params = {'skip_download': True}
    test_ViafreeIE = ViafreeIE().suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    info_dict = {'series': 'Husräddarna'}
    test_ViafreeIE.extract_info_dict(info_dict, params)



# Generated at 2022-06-12 18:40:41.506799
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return super(TestTVPlayHomeIE, self)._real_extract(url)
    return TestTVPlayHomeIE

# Generated at 2022-06-12 18:40:49.872475
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test the TVPlayIE class constructor."""
    ie = TVPlayIE()
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie.URL_VALID_RE == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS
    assert ie._match_id(url) == '238551'



# Generated at 2022-06-12 18:40:51.721321
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_DESC == 'MTG services'
    assert obj.IE_NAME == 'mtg'


# Generated at 2022-06-12 18:41:35.312007
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for verifying that the constructor of ViafreeIE properly choses
    the correct subclass based on the URL.

    The base class ViafreeIE is not meant to be used directly but it is
    instead used as a factory for returning the proper subclass.
    """
    from . import ViaplayIE

    # Test selecting the Viaplay subclass
    viafree_ie = ViafreeIE._build_viafree_ie('viafree:se:program:id', 'http://www.viafree.se/program/title')
    assert(isinstance(viafree_ie, ViaplayIE))

    # Test selecting the default subclass
    viafree_ie = ViafreeIE._build_viafree_ie('viafree:se:program:id', 'http://www.viafree.se/program/title?other=params')

# Generated at 2022-06-12 18:41:39.397470
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie.IE_NAME == 'mtg')
    assert(ie.IE_DESC == 'MTG services')
    assert(ie._VALID_URL is not None)
    assert(ie._TESTS is not None)

# Generated at 2022-06-12 18:41:40.066638
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(ViafreeIE())

# Generated at 2022-06-12 18:41:44.588694
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('https://play.tv2.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:41:45.365512
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

# Generated at 2022-06-12 18:41:51.771139
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Change a parameter to a non-empty string in args
    ie = TVPlayHomeIE(*(['--test-parameter', '--'])).suitable
    # Assert true
    assert(ie('https://tv3play.skaties.lv/vinas-melo-labak-10280317'))
    # Assert false
    assert(not ie('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'))


# Generated at 2022-06-12 18:42:06.215626
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    #Url to test
    url_test= 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    #Create an object of class ViafreeIE
    viafreeIE = ViafreeIE()
    #Get the guid
    guid = viafreeIE._match_id(url_test)
    #Get the path
    path = viafreeIE._match_id(url_test, 'path')
    #Get the country
    country = viafreeIE._match_id(url_test, 'country')
    #Download the json

# Generated at 2022-06-12 18:42:15.575444
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    #TVPlayHomeIE.suitable( 'http://www.tv3play.se/program/det-besta-vorspielen/avsnitt-1' )
    #TVPlayHomeIE.suitable( 'http://www.tv3play.se/program/det-besta-vorspielen/avsnitt-2' )

# Generated at 2022-06-12 18:42:28.377763
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:42:41.264960
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    test.IE_DESC = 'MTG services'
    test.IE_NAME = 'mtg'

# Generated at 2022-06-12 18:44:01.371070
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE()
    except Exception as e:
        if e.args[0] != 'TVPlayHomeIE is disabled':
            # Execute test only if constructor was correct
            assert False, e
    else:
        assert True, 'No exception was thrown'

# Generated at 2022-06-12 18:44:05.101507
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Creates a ViafreeIE instance"""
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is False
    assert ie.suitable('http://play.tv3.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') is True

# Generated at 2022-06-12 18:44:11.152964
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True)
    assert(TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') is True)
    assert(TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') is True)
    assert(TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125') is True)

# Generated at 2022-06-12 18:44:18.437044
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()

# Generated at 2022-06-12 18:44:21.545033
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._real_extract("http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true")

# Generated at 2022-06-12 18:44:26.419225
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafree = ViafreeIE(test_url)
    assert viafree.suitable(test_url)


# Generated at 2022-06-12 18:44:28.079782
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Only test that the constructor doesn't throw.
    ViafreeIE(None)


# Generated at 2022-06-12 18:44:30.346862
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'



# Generated at 2022-06-12 18:44:41.798497
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    extractor = TVPlayHomeIE()
    assert extractor.extractor_key == 'tvplayhome'
    assert extractor.IE_NAME == 'tvplayhome'
    assert extractor.name == 'TVPlayHome'
    assert extractor.description == 'TVPlayHome video extraction'
    assert extractor.suitable(TVPlayHomeIE._VALID_URL)
    assert extractor.suitable(TVPlayHomeIE._VALID_URL.replace('skaties.lv', 'tv3.lt'))
    assert extractor.suitable(TVPlayHomeIE._VALID_URL.replace('skaties.lv', 'tv3.ee'))
    assert not extractor.suitable('http://www.youtube.com/watch?v=BaW_jenozKc')

# Generated at 2022-06-12 18:44:43.493144
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('unit test', 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
# Need to patch this function to run unit test for class ViafreeIE

# Generated at 2022-06-12 18:48:06.517824
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg', 'http://playapi.mtgx.tv/v3/videos/stream/718136', 'video_id')

# Generated at 2022-06-12 18:48:15.216412
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert_equal(ViafreeIE._VALID_URL,
                 r'''(?x)
                 https?://
                     (?:www\.)?
                     viafree\.(?P<country>dk|no|se)
                     /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                 ''')

# Generated at 2022-06-12 18:48:19.906712
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # given
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317/'
    # when
    ie = TVPlayHomeIE().suitable(url)
    # then
    assert ie


# Generated at 2022-06-12 18:48:24.518718
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # unit tests for the ViafreeIE constructors
    ie = ViafreeIE()
    ie = ViafreeIE(ie.extractor)
    ie = ViafreeIE(ie.extractor, ie._DOWNLOADER)
    ie = ViafreeIE(ie.extractor, ie._DOWNLOADER, ie._downloader_params)
    ie = ViafreeIE(ie.extractor, ie._DOWNLOADER, ie._downloader_params, ie._WORKING_AS_OF)
    assert ie is not None
