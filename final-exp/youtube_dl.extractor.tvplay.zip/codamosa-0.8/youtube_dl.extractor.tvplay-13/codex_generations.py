

# Generated at 2022-06-12 18:38:44.791940
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2", {})

# Generated at 2022-06-12 18:38:55.600208
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    '''
    This function only tests the constructor of class TVPlayHomeIE.
    '''
    # Successful test of the constructor.
    # Should not raise any exceptions.
    ie = TVPlayHomeIE()

    # Successful test of the constructor.
    # Should not raise any exceptions.
    ie = TVPlayHomeIE('SKATIES')

    # Unsuccessful test of the constructor.
    # Should raise an exception.
    try:
        ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    except:
        pass

    # Unsuccessful test of the constructor.
    # Should raise an exception.

# Generated at 2022-06-12 18:38:56.877239
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._real_initialize()

# Generated at 2022-06-12 18:38:58.605244
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-12 18:39:00.895910
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.IE_NAME == 'TVPlay'

# Generated at 2022-06-12 18:39:06.205373
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    tvplay_ie._download_json("http://playapi.mtgx.tv/v3/videos/397996",
        '397996', 'Downloading test JSON')



# Generated at 2022-06-12 18:39:15.118336
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:39:25.566490
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    cls = ViafreeIE
    test = cls.suitable
    assert test('http://www.tv3play.dk/programmer/underholdning/den-store-bagedyst/sesong-6/episode-2')
    assert not test('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert test('http://www.tv3play.se/program/husraddarna/395385')
    assert test('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551')
    assert test('http://www.tv3play.lv/raidijums/bez-tabu/78750')

# Generated at 2022-06-12 18:39:26.154425
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE

# Generated at 2022-06-12 18:39:29.447288
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ie.suitable('http://play.tv2.no/programmer/reality/paradise-hotel/saeson-7/episode-5')



# Generated at 2022-06-12 18:39:54.765274
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:40:00.458012
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-12 18:40:01.768042
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    raise NotImplementedError('A unit test for ViafreeIE has not yet been implemented')

# Generated at 2022-06-12 18:40:05.006421
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-12 18:40:10.915340
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test the behaviour of the constructor of class TVPlayHomeIE.
    """
    # These class variables should be set
    assert(TVPlayHomeIE.IE_NAME == 'TVPlayHome')
    assert(TVPlayHomeIE.IE_DESC == 'TVPlayHome and TV3Play')
    # This class variable should not be set
    assert(not hasattr(TVPlayHomeIE, '_TEST'))

    # Test instance of class InfoExtractor
    ie = TVPlayHomeIE()
    assert(isinstance(ie, InfoExtractor))

# end of test_TVPlayHomeIE



# Generated at 2022-06-12 18:40:22.220665
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    example_urls = [
        'http://www.viafree.no/program/underholdning/det-beste-vorspielet/sesong-2/episode-1',
        'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    ]

    for example_url in example_urls:
        ie = ViafreeIE(example_url)
        assert ie.SUITABLE_URL == ie._VALID_URL
        assert ie._VALID_URL == ie._TESTS[0]['url']
        assert ie.ie_key() == 'Viafree'


# Generated at 2022-06-12 18:40:31.087044
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.IE_NAME == 'viafree'
    assert ie.IE_DESC == 'Viafree'
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._GEO_BYPASS == False
    assert ie._TESTS.__len__() == 5
    assert ie.suitable('') == False
    assert ie._real_extract('') == NotImplementedError

# Generated at 2022-06-12 18:40:37.216858
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('https://www.viafree.se/program/nyheter/tv4nyheterna/sasong-1/avsnitt-1')
    assert ie.country == 'se'
    assert ie.path == 'programmer/nyheter/tv4nyheterna/sasong-1/avsnitt-1'

# Generated at 2022-06-12 18:40:39.262176
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()
    ViafreeIE(None)
    ViafreeIE(ThumbIE(None, None))



# Generated at 2022-06-12 18:40:48.281094
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()
    assert vf.geo_verification_headers()
    assert vf.geo_bypass(None)
    url = ViafreeIE._VALID_URL % ('se', 'program/underhallning/i-like-radio-live/sasong-1/676869')
    assert vf._real_extract(url)
    url = 'https://www.viafree.dk/programmer/underholdning/jul-i-valhalla/saeson-2/episode-1'
    assert vf._real_extract(url)


# Generated at 2022-06-12 18:41:34.719506
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:41:38.315931
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE._create_geturl_impl(TVPlayHomeIE._VALID_URL, TVPlayHomeIE._TESTS[0]['url']))



# Generated at 2022-06-12 18:41:41.598302
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Unit test for constructor of class TVPlayIE
    # Values of variant parameters
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    # Expected result
    expected_result = '409229'

    # Run the constructor of the class
    actual_result = TVPlayIE._match_id(TVPlayIE, url)

    # Assert the result
    assert actual_result == expected_result



# Generated at 2022-06-12 18:41:43.754655
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test the constructor of TVPlayHomeIE
    # There is no testable functionality in the constructor
    # Because the constructor only defines some properties
    assert TVPlayHomeIE() is not None

# Generated at 2022-06-12 18:41:47.112368
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """test TVPlayIE constructor"""
    t = TVPlayIE()
    assert t.IE_NAME == 'mtg'



# Generated at 2022-06-12 18:41:49.006200
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    assert IE._VALID_URL == TVPlayHomeIE._VALID_URL


# Generated at 2022-06-12 18:41:49.943369
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-12 18:41:57.583843
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-12 18:41:59.634606
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE._VALID_URL == TVPlayIE._VALID_URL
    assert IE.IE_NAME == TVPlayIE.IE_NAME
    assert IE.IE_DESC == TVPlayIE.IE_DESC
    assert IE._TESTS == TVPlayIE._TESTS


# Generated at 2022-06-12 18:42:03.399826
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert isinstance(ViafreeIE(url), ViafreeIE)

# Generated at 2022-06-12 18:43:24.452025
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-12 18:43:35.653726
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE
    """
    IE = TVPlayIE()
    assert IE.ie_key() == 'TVPlay'
    assert IE.ie_name() == 'mtg'
    assert IE.ie_desc() == 'MTG services'

# Generated at 2022-06-12 18:43:42.879347
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.tv3play.dk/programmer/husraddarna/315785?autostart=true')
    assert ViafreeIE.suitable('http://www.tv3play.no/programmer/husraddarna/315785?autostart=true')
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/315785?autostart=true')
    assert ViafreeIE.suitable('http://www.tv6play.dk/programmer/husraddarna/315785?autostart=true')
    assert ViafreeIE.suitable('http://www.tv6play.no/programmer/husraddarna/315785?autostart=true')

# Generated at 2022-06-12 18:43:52.217731
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    filename = 's.html'
    file = os.path.join(os.path.dirname(__file__), filename)
    with open(file, encoding="utf8") as f:
        file_contents = f.read()
    video_url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    webpage = file_contents
    guid = '749867'
    title = 'Sommaren med Youtube-stjärnorna - Säsong 1 - Avsnitt 1'

# Generated at 2022-06-12 18:43:53.804593
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	test_TVPlayIE = TVPlayIE()
	test_TVPlayIE.test_TVPlayIE()

# Generated at 2022-06-12 18:44:01.617580
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id =  '366367'

# Generated at 2022-06-12 18:44:11.126391
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    ie = TVPlayIE()

    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-12 18:44:13.917845
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    extractor = TVPlayHomeIE('')
    instance = TVPlayHomeIE._create_tvplay_home_ie(extractor)
    assert isinstance(instance, TVPlayHomeIE)


# Generated at 2022-06-12 18:44:24.841263
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-12 18:44:30.164949
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Check if the constructor of class ViafreeIE works correctly
    """
    # Test with Video
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'

    viafree = ViafreeIE()

    assert viafree.suitable(url)

# Generated at 2022-06-12 18:48:17.255178
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import random
    import string
    random_string = lambda n: ''.join(random.choice(string.ascii_uppercase + string.digits) for _ in range(n))

    from .vidisi import VidisiIE
    from .ttv import TTVIE
    from .tv3 import TV3IE
    from .viasat import ViasatIE
    from .nova import NovaIE
    from .viafree import ViafreeIE

    from .subtitles import SubtitlesInfoExtractor

    assert isinstance(TVPlayIE(TV3IE()), SubtitlesInfoExtractor)
    assert TVPlayIE(TV3IE()).IE_NAME == 'mtg:tv3'

    assert isinstance(TVPlayIE(TTVIE()), SubtitlesInfoExtractor)