

# Generated at 2022-06-12 18:38:47.997622
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    r = TVPlayHomeIE()
    assert TVPlayHomeIE.suitable(r.ie_key()), 'Unit test for constructor of class TVPlayHomeIE failed!'


# Generated at 2022-06-12 18:38:55.215895
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = "http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1"
    valid_url = ViafreeIE._VALID_URL
    m = re.match(valid_url, url)
    country = m.group('country')
    path = m.group('id')

    #check the constructed url
    test_url = "https://viafree-content.mtg-api.com/viafree-content/v1/" + country + "/path/" + path
    assert "https://viafree-content.mtg-api.com/viafree-content/v1/" + country + "/path/" + path == test_url



# Generated at 2022-06-12 18:38:59.014664
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree.GEO_COUNTRIES == ['DK']



# Generated at 2022-06-12 18:39:02.420666
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for valid_url in ViafreeIE._TESTS:
        assert ViafreeIE.suitable(valid_url['url'])



# Generated at 2022-06-12 18:39:04.239050
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t.working

# Generated at 2022-06-12 18:39:09.033652
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, TVPlayBaseIE)
    assert isinstance(ie, YoutubeIE)


# Generated at 2022-06-12 18:39:18.874618
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    attrs = {'TVPlayIE': TVPlayIE}
    IE_DESC = """MTG services"""

# Generated at 2022-06-12 18:39:20.623121
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test for constructor
    TVPlayIE()


# Generated at 2022-06-12 18:39:27.813383
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import json

    test_file = open("tests/test_data/viafree/test_url.txt")
    test_url = test_file.readline().replace('\n', '')

    viafree_ie = ViafreeIE()
    info_dict = viafree_ie._real_extract(test_url)

    info_dict_file = open("tests/test_data/viafree/info_dict.txt")
    assert info_dict == json.loads(info_dict_file.readline())
    test_file.close()
    info_dict_file.close()


# Generated at 2022-06-12 18:39:33.653993
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplay_home_ie = TVPlayHomeIE(TVPlayHomeIE.create_ie(url), url)
    assert isinstance(tvplay_home_ie, TVPlayHomeIE)

# Generated at 2022-06-12 18:40:00.643333
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL != ''
    test_set = [{'url': 'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true', 'id': '764300'}]
    for test in test_set:
        test_url = re.sub(r'https?:', '', test['url'])
        assert ie._match_id(test_url) == test['id']


# Generated at 2022-06-12 18:40:04.730769
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE([])
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''


# Generated at 2022-06-12 18:40:12.316602
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test constructor of class TVPlayIE."""
    ie = TVPlayIE()
    ie.IE_NAME = 'MTG'
    ie.IE_DESC = 'MTG services'

# Generated at 2022-06-12 18:40:23.918823
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    URL = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id = TVPlayHomeIE._match_id(URL)
    asset_id = video_id
    asset = TVPlayHomeIE._download_json(
        urljoin(URL, '/sb/public/asset/' + video_id), video_id)
    m3u8_url = asset['movie']['contentUrl']
    video_id = asset['assetId']
    asset_title = asset['title']
    title = asset_title['title']

# Generated at 2022-06-12 18:40:25.656801
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg = TVPlayIE()
    assert mtg.IE_NAME == mtg.ie_key()


# Generated at 2022-06-12 18:40:33.120468
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_cases = [
        ('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'),
        ('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'),
    ]

    ie = ViafreeIE()
    for test_case in test_cases:
        m = ie._VALID_URL_RE.match(test_case)
        assert m is not None, 'URL matching regexp failed for url %s' % test_case

# Generated at 2022-06-12 18:40:35.456050
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-12 18:40:40.800287
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE(None)

# Generated at 2022-06-12 18:40:51.368026
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636')
    TVPlayIE('http://www.tv8play.se/program/antikjakten/282756')

# Generated at 2022-06-12 18:40:51.968679
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()

# Generated at 2022-06-12 18:41:37.521283
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    ViafreeIE("http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869")
    ViafreeIE("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    ViafreeIE("https://www.viafree.se/program/underhallning/parneviks/avsnitt-6")
    ViafreeIE("https://www.viafree.se/program/dokusap/bondelaget-kabeldrama/avsnitt-1")

# Generated at 2022-06-12 18:41:47.986039
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    result = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-12 18:41:56.061293
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    ie = TVPlayIE(url)
    assert ie._match_id(url) == '418113'

# Generated at 2022-06-12 18:42:00.154340
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv6play.se/program/husraddarna/395385?autostart=true')
    assert(ie.IE_NAME == 'mtg')
# test_TVPlayIE()



# Generated at 2022-06-12 18:42:01.036888
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-12 18:42:05.645694
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_ = TVPlayHomeIE
    # test for valid format
    assert class_._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:42:07.668905
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    extended_class = ie.__class__.__name__
    assert  extended_class == 'TVPlayHomeIE'

# Generated at 2022-06-12 18:42:09.534848
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import doctest
    doctest.testmod(ViafreeIE)


# Generated at 2022-06-12 18:42:14.246566
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test empty constructor
    assert TVPlayHomeIE()

    # Test constructor with url
    obj = TVPlayHomeIE(url='http://example.com')
    assert obj.url == 'http://example.com'
    assert obj.video_id == ''


# Generated at 2022-06-12 18:42:16.947322
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'), ViafreeIE)


# Generated at 2022-06-12 18:43:35.692098
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # TODO: add tests
    return



# Generated at 2022-06-12 18:43:42.432386
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._VALID_URL(
        'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert TVPlayIE._VALID_URL(
        'http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert not TVPlayIE._VALID_URL(
        'http://www.nova.bg/')
    assert not TVPlayIE._VALID_URL(
        'https://www.youtube.com/watch?v=W0LHTWG-UmQ')
    assert not TVPlayIE._VALID_URL(
        'https://www.facebook.com/')

# Generated at 2022-06-12 18:43:52.015569
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global TVPlayIE
    import time
    URL = "http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true"
    TVPlayIE = TVPlayIE()
    test_result = TVPlayIE._real_extract(TVPlayIE, URL)
    assert(test_result["id"] == "409229")
    assert(test_result["ext"] == "flv")
    assert(test_result["title"] == "Moterys meluoja geriau")
    assert(test_result["description"] == u'md5:9aec0fc68e2cbc992d2a140bd41fa89e')
    assert(test_result["series"] == "Moterys meluoja geriau")

# Generated at 2022-06-12 18:44:00.112858
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvPlayIE = TVPlayIE()
    assert (tvPlayIE.IE_NAME == 'mtg')
    assert (tvPlayIE.IE_DESC == 'MTG services')

# Generated at 2022-06-12 18:44:05.069832
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tpIE = TVPlayIE("tvplay.lv")
    assert tpIE.IE_NAME is 'mtg'
    assert tpIE.IE_DESC is 'MTG services'
    assert tpIE._VALID_URL is TVPlayIE._VALID_URL
    assert tpIE._TESTS is TVPlayIE._TESTS





# Generated at 2022-06-12 18:44:11.101304
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Testing constructor
    ie = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113/?autostart=true')
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:44:16.056968
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    VF = ViafreeIE(None)
    assert VF._VALID_URL == '''(?x)
                            https?://
                                (?:www\.)?
                                viafree\.(?P<country>dk|no|se)
                                /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                            ''', 'regular expression in VF._VALID_URL has been changed'


# Generated at 2022-06-12 18:44:25.902707
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-12 18:44:29.657063
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie is not None

# Generated at 2022-06-12 18:44:41.228683
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:46:41.732934
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Check that nothing really bad happends
    # when we construct TVPlayIE
    TVPlayIE()


# Generated at 2022-06-12 18:46:45.874035
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Attempt to initialize an instance of the class
    try:
        class_instance = TVPlayIE()
    except Exception as err:
        print(str(err))
    else:
        print("Instance of the TVPlayIE class successfully created")

test_TVPlayIE()


# Generated at 2022-06-12 18:46:46.904692
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:46:55.348283
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_common import run_constructor_test
    # Workaround for failing constructor test (see #5424).
    # TODO: remove once #5424 is fixed.
    class TestTVPlayIE(TVPlayIE):

        _TEST = {
            'url': 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true',
            'only_matching': True
        }

    run_constructor_test(TestTVPlayIE)



# Generated at 2022-06-12 18:47:09.370438
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-12 18:47:15.525375
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for initialization with valid url and arguments for GeoRestrictedError
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    msg = 'This content is not available in your region due to rights restrictions'
    countries = ['DK']
    viafree_ie = ViafreeIE(msg)
    error = viafree_ie.raise_geo_restricted(msg, countries=countries)
    assert error.msg == msg
    assert error.countries == countries


# Generated at 2022-06-12 18:47:18.339247
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')



# Generated at 2022-06-12 18:47:24.686865
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.SUFFIX == ('.tv3.lt', '.skaties.lv', '.tv3.ee')
    assert ie.valid_countries == ('LT', 'LV', 'EE')
    assert ie.valid_urls == ('.*tv3\.lt/(?:[^/]+/)*[^/?#&]+-[0-9]+',
        '.*skaties\.lv/(?:[^/]+/)*[^/?#&]+-[0-9]+',
        '.*tv3\.ee/(?:[^/]+/)*[^/?#&]+-[0-9]+')

# Generated at 2022-06-12 18:47:32.325791
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.SUFFIX == ''
    assert ie.geo_verification_headers() == {}

    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.SUFFIX == ''
    assert ie.geo_verification_headers() == {}

    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.SUFFIX == 'lg'
    assert ie.geo_verification_headers() == {'tvplay-country': 'ee'}

# Generated at 2022-06-12 18:47:33.235639
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)

