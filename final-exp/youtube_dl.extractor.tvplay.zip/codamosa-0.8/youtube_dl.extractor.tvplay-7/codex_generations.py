

# Generated at 2022-06-12 18:38:51.330005
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Check if _VALID_URL of TVPlayIE is the same with _TESTS
    url_lst = []
    for t in TVPlayIE._TESTS:
        url_lst.append(t['url'])
    regex = re.compile(TVPlayIE._VALID_URL, re.VERBOSE)
    regex_lst = [regex.match(x).group('id') for x in url_lst]
    for t in TVPlayIE._TESTS:
        assert t['url'].split('/')[-2] == regex_lst[TVPlayIE._TESTS.index(t)]


# Generated at 2022-06-12 18:38:55.120866
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE()
    assert isinstance(IE, ViafreeIE)

# Generated at 2022-06-12 18:38:57.532717
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test that the constructor of class TVPlayHomeIE doesn't raise any
    # exceptions
    TVPlayHomeIE()

# Generated at 2022-06-12 18:39:01.994244
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception as ex:
        print(repr(ex))
    else:
        assert True, 'constructor of class ViafreeIE executed without exception'


# Generated at 2022-06-12 18:39:10.782110
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert ie._VALID_URL == r'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-12 18:39:20.842922
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    playlist = TVPlayHomeIE._extract_playlist(tvplay_url)
    t = TVPlayHomeIE(tvplay_url, playlist)
    assert t.ie_key() == 'TVPlayHomeIE'

    tvplay_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    playlist = TVPlayHomeIE._extract_playlist(tvplay_url)
    t = TVPlayHomeIE(tvplay_url, playlist)
    assert t.ie_key() == 'TVPlayHomeIE'


# Generated at 2022-06-12 18:39:29.543763
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test with real video: https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true
    test_video_id = 418113
    test_video_url = "http://www.tvplay.lv/parraides/vinas-melo-labak/%s?autostart=true" % test_video_id
    test_video_url = "https://tvplay.skaties.lv/vinas-melo-labak/%s/?autostart=true" % test_video_id
    # test_video_url = "https://www.tvplay.lv/parraides/vinas-melo-labak/%s/?autostart=true" % test_video_id
    # test_video_url = "https://www.tvplay.

# Generated at 2022-06-12 18:39:30.780156
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("")

# Generated at 2022-06-12 18:39:36.337223
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TV3PlayIE()._VALID_URL == TVPlayIE._VALID_URL
    assert TV3PlayIE()._NETRC_MACHINE == TVPlayIE._NETRC_MACHINE
    # test _ready constructor
    assert isinstance(TV3PlayIE().geo_verification_headers, dict)



# Generated at 2022-06-12 18:39:38.057398
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-12 18:40:12.133712
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:40:23.734813
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """ test for constructor of class ViafreeIE """
    # This test is a constructor test for class ViafreeIE.
    # The constructor takes three arguments:
    # ie (an instance of InfoExtractor),
    # guid (string),
    # video_data (dictionary)

# Generated at 2022-06-12 18:40:27.394803
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # This video is age restricted, so it has to be tested only locally
    TVPlayHomeIE(None)._download_json(
        'http://tvplay.tv3.lt/sb/public/asset/366367', '366367')

# Generated at 2022-06-12 18:40:30.479345
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    result = ViafreeIE('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert result == ViafreeIE


# Generated at 2022-06-12 18:40:37.838552
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE."""
    # Test skaties.lv
    skaties_lv = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert skaties_lv.name == 'TVPlay Home'
    assert skaties_lv.country == 'LV'
    assert skaties_lv.geo_verification_headers == {}
    assert skaties_lv.country_code == 'LV'
    skaties_lv._initialize_geo_bypass({'countries': ['LV']})
    assert skaties_lv.geo_verification_headers == {'X-Forwarded-For': '89.222.49.3'}

    # Test

# Generated at 2022-06-12 18:40:48.032743
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE("extractor.tvplay")

# Generated at 2022-06-12 18:40:49.783080
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL



# Generated at 2022-06-12 18:40:57.578402
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	obj=TVPlayIE()
	assert(obj.IE_NAME == 'mtg')
	assert(obj.IE_DESC == 'MTG services')

# Generated at 2022-06-12 18:41:00.130180
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:41:02.902391
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        m = ViafreeIE()
    except AttributeError:
        pass
    else:
        assert False, 'Constructor of class ViafreeIE is not valid'



# Generated at 2022-06-12 18:42:12.624241
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    urls = ['http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869']
    for url in urls:
        viafree.suitable(url)

# Generated at 2022-06-12 18:42:26.717274
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test the constructor of class TVPlayIE"""
    # Create a TVPlayIE instance
    obj = TVPlayIE()

    # Some tests

# Generated at 2022-06-12 18:42:32.586050
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:42:37.637645
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def _test_url(url):
        ie = TVPlayIE(TVPlayIE.ie_key())
        ie.url = url
        return ie

    assert _test_url(None)._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-12 18:42:38.397951
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('418113')

# Generated at 2022-06-12 18:42:43.145514
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert ie.suitable
    assert ie.domain == 'viafree.se'


# Generated at 2022-06-12 18:42:48.907745
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test for constructor of class TVPlayIE"""
    test_ie = TVPlayIE(None)
    assert test_ie.IE_NAME == 'mtg'
    assert test_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:42:57.362730
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_ie = TVPlayIE()

# Generated at 2022-06-12 18:43:06.384435
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    # Return a mock streaming JSON with a given key and format
    def mock_json(formats=['hls'], key = None):
        # Create mock json
        json = '{"_embedded": {"viafreeBlocks": [' \
               '{"_embedded": {"program": {"_links": {"streamLink": {"href": "https://viafree-content.mtg-api.com/viafree-content/v1/dk/path/programmer/bagedyst-junior/4i1Sht9_4i1ShtB/avsnitt-5"}}}}}]}'
        return json

    assert mock_json()

    # Create mock url

# Generated at 2022-06-12 18:43:18.303579
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-12 18:44:45.183878
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    parser = TVPlayHomeIE.tvplay_home_ie
    assert parser({}) == None

# Generated at 2022-06-12 18:44:45.782709
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-12 18:44:48.347302
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')


# Generated at 2022-06-12 18:44:48.908564
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:44:49.481120
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:45:00.099400
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    b = TVPlayIE()

# Generated at 2022-06-12 18:45:08.858510
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Basic test
    tvplay = TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-12 18:45:12.906333
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS
    assert ie._real_extract == TVPlayIE._real_extract


# Generated at 2022-06-12 18:45:14.343844
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test the proper class of the constructor
    viafreeIE = ViafreeIE(None)
    assert isinstance(viafreeIE, ViafreeIE)

# Generated at 2022-06-12 18:45:16.812182
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert TVPlayIE.suitable(url)
    tvplayie = TVPlayIE(url)
    assert isinstance(tvplayie._extract_stream(url), dict)

# Generated at 2022-06-12 18:47:27.635919
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.ie_key() == 'Viafree'
    assert viafree.ie_key('Viasat') == 'Viafree'
    assert viafree.ie_key('TV3') == 'Viafree'
    assert viafree.ie_key('TV6') == 'Viafree'
    assert viafree.ie_key('TV8') == 'Viafree'
    assert viafree.ie_key('ChrisP') == 'Viafree'
    assert viafree.ie_key('TV3Play') == 'Viafree'
    assert viafree.ie_key('TV3PlayDK') == 'Viafree'
    assert viafree.ie_key('TV3PlayNO') == 'Viafree'
    assert viafree.ie_key('TV3PlaySE') == 'Viafree'

# Generated at 2022-06-12 18:47:37.317849
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # unit test for _VALID_URL

# Generated at 2022-06-12 18:47:38.333999
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-12 18:47:39.853169
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    TVPlayHomeIE(url)

# Generated at 2022-06-12 18:47:45.745337
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == r'(?x)mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)'

# Generated at 2022-06-12 18:47:49.906135
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import sys
    import unittest
    if sys.version_info.major == 2:
        raise unittest.SkipTest("Skipping Python 2 test")
    class __test(unittest.TestCase):
        def test(self):
            TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    unittest.main()

# Generated at 2022-06-12 18:47:59.123294
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    print("Unit test for constructor of class ViafreeIE")
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree = ViafreeIE()
    viafree.url = url
    assert viafree.extractor_key == 'Viafree'
    assert viafree.country == 'no'
    assert viafree.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert viafree.age_limit is None
    print("Unit test for constructor of class ViafreeIE is completed.")


# Generated at 2022-06-12 18:48:03.119974
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    classname = 'TVPlayHomeIE'
    ie = globals()[classname]()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-12 18:48:03.839324
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-12 18:48:07.673762
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .utils import FakeYDL
    # noinspection PyTypeChecker
    ie = ViafreeIE(FakeYDL())
    assert isinstance(ie, ViafreeIE)
