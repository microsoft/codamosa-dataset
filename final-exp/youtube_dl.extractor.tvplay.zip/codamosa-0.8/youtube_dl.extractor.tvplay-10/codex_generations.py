

# Generated at 2022-06-12 18:38:48.572109
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    '''
    Unit test for constructor of class TVPlayIE
    '''
    tvplay_ie = TVPlayIE()
    assert tvplay_ie._VALID_URL
    assert tvplay_ie.IE_NAME
    assert tvplay_ie.IE_DESC


# Generated at 2022-06-12 18:38:53.013146
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie
    ie = TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    assert ie
    ie = TVPlayIE('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')
    assert ie


# Generated at 2022-06-12 18:38:56.020941
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Make sure that TVPlayIE is not abstract.
    """
    TVPlayIE()


# Generated at 2022-06-12 18:39:10.923283
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    _RE_TV_PLAY_HOME_ID = re.compile(TVPlayHomeIE._VALID_URL)
    assert _RE_TV_PLAY_HOME_ID.match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert _RE_TV_PLAY_HOME_ID.match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

    # Test with long ID
    assert _RE_TV_PLAY_HOME_ID.match('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-12 18:39:12.866175
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE()
    assert i._VALID_URL

# Generated at 2022-06-12 18:39:16.368646
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        # Varify initialization of the class
        TVPlayIE(None)

    except AssertionError:
        assert False, "Unable to create instance of TVPlayIE"



# Generated at 2022-06-12 18:39:26.761688
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .youtube_dl.extractor.viafree import ViafreeIE
    # random video on viafree
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    vf = ViafreeIE(ViafreeIE.suitable(url))
    assert vf.country == 'se'
    # random video on tvplay
    url2 = 'http://play.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'
    vf2 = ViafreeIE(ViafreeIE.suitable(url2))
    assert not vf2.country
    # random video on tv3play

# Generated at 2022-06-12 18:39:28.254547
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert repr(ie) == '<TVPlayHomeIE>'


# Generated at 2022-06-12 18:39:29.299724
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:39:37.122987
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)
    assert ie.IE_NAME == 'tvplayhome'
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:13.833143
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')

# Generated at 2022-06-12 18:40:19.264786
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv = TVPlayIE()
    assert isinstance(tv, TVPlayIE)
    return tv

if __name__ == '__main__':
    tv = test_TVPlayIE()
    tv.extract('https://play.tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true')
    pass

# Generated at 2022-06-12 18:40:24.699617
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    ie.extract(url)
    assert ie.IE_NAME == 'TVplayHome'


# unit test for extractors

# Generated at 2022-06-12 18:40:26.575818
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC


# Generated at 2022-06-12 18:40:35.574343
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:40:37.113825
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE(TVPlayIE.ie_key())


# Generated at 2022-06-12 18:40:39.261259
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(ExtractorError):
        ViafreeIE.suitable('')
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:40:39.987723
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()

# Generated at 2022-06-12 18:40:40.991717
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:761651', {})

# Generated at 2022-06-12 18:40:51.488758
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-12 18:42:01.403183
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test that the metaclass is checked as expected

    # Test that the class was created successfully
    assert ViafreeIE()

    # Test that the class was NOT created successfully
    with pytest.raises(TypeError):
        class TestClass(ViafreeIE):
            _VALID_URL = False
        TestClass()

# Generated at 2022-06-12 18:42:02.510012
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('TVPlayHomeIE')

# Generated at 2022-06-12 18:42:10.190387
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url_lv = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    url_lt = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    url_ee = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    url_se = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    url_no = 'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'

# Generated at 2022-06-12 18:42:11.722971
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-12 18:42:24.993691
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .viafree_test import TVPlayIE_test
    # Load 'JWPlayer' for decode of encrypted urls
    load_js_module(True, False, TVPlayIE_test.JWPLAYER_KEY, TVPlayIE_test.JWPLAYER_SRC, TVPlayIE_test.JWPLAYER_GLOBAL, TVPlayIE_test.JWPLAYER_VERSION)
    # Read url from test url list
    url = TVPlayIE_test.test_urls[-1]
    # Create a new instance of class
    # viafree_ie = ViafreeIE()
    viafree_ie = globals()[ViafreeIE.ie_key()]()
    # Extract url
    viafree_ie.extract(url)

# Generated at 2022-06-12 18:42:31.557761
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', {'geo_countries': ['dk']})
    assert ie.geo_verification_headers() is None
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', {'geo_countries': ['dk']})
    assert ie.geo_verification_headers() is not None
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', {})
    assert ie.geo_verification_headers() is not None
    ie = ViafreeIE

# Generated at 2022-06-12 18:42:39.930904
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    user_agent = 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Ubuntu Chromium/34.0.1847.116 Chrome/34.0.1847.116 Safari/537.36'
    tvplay_home_extractor = TVPlayHomeIE(user_agent)
    assert str(tvplay_home_extractor) == 'TVPlayHomeIE(user_agent=%s)' % user_agent

# Generated at 2022-06-12 18:42:50.511240
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("http://playapi.mtgx.tv/v3/videos/stream/418113")
    # Check expected string passed back

# Generated at 2022-06-12 18:42:58.922564
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/2_turf_vip_5-10045606/')
    assert ie.suitable('https://tvplay.tv3.lt/2_turf_vip_5-10045606/')
    assert ie.suitable('http://tv3play.tv3.lt/2_turf_vip_5-10045606/')
    assert ie.suitable('http://tv3play.skaties.lv/2_turf_vip_5-10045606/')
    assert ie.suitable('https://tv3play.tv3.ee/2_turf_vip_5-10045606/')

# Generated at 2022-06-12 18:43:00.336446
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    b = ViafreeIE()
    assert b.suitable(ViafreeIE._VALID_URL)


# Generated at 2022-06-12 18:45:44.051815
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-12 18:45:48.867992
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

# Generated at 2022-06-12 18:45:53.983373
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Create a string from the class TVShowIE.
    tp = TVPlayIE("string")
    # We have a string and class TVShowIE must confirm that assertion.
    assertIsInstance(tp,TVPlayIE)


# Generated at 2022-06-12 18:45:56.909309
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    with open('tests/test_blob.json', 'rb') as data_file:
        data = data_file.read()
    _ = TVPlayIE(data)

# Generated at 2022-06-12 18:46:08.541763
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ Unit tests for TVPlayHomeIE constructor """
    assert TVPlayHomeIE._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:46:11.585632
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert ie.IE_NAME == 'tvplay.skaties.lv'


# Generated at 2022-06-12 18:46:21.754267
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()._VALID_URL is None
    assert TVPlayHomeIE()._GEO_BYPASS is None
    assert TVPlayHomeIE()._NETRC_MACHINE is None
    assert TVPlayHomeIE().SUITABLE_DEFAULT is None
    assert TVPlayHomeIE()._REQUEST_HEADERS is None
    assert TVPlayHomeIE().IE_DESC is None
    assert TVPlayHomeIE()._TESTS is None
    assert TVPlayHomeIE()._downloader is None
    assert TVPlayHomeIE()._WORKING is None
    assert TVPlayHomeIE()._download_retry is None
    assert TVPlayHomeIE()._download_webpage_handle is None
    assert TVPlayHomeIE()._type is None
    assert TVPlayHomeIE()._download_webpage is None



# Generated at 2022-06-12 18:46:22.927825
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:415809');

# Generated at 2022-06-12 18:46:25.224045
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE(TVPlayHomeIE.suitable, 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-12 18:46:25.705986
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()