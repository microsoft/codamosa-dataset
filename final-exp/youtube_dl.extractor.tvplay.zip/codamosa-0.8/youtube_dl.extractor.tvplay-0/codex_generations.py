

# Generated at 2022-06-12 18:38:45.980618
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-12 18:38:48.459336
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE is not None
    assert TVPlayIE is ViafreeIE

# Generated at 2022-06-12 18:38:56.198923
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)' # noqa: E501
    assert IE._

# Generated at 2022-06-12 18:39:11.125011
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    t.suitable('https://play.tv3play.lt/aferistai-10047125')
    t.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    t.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    t.suitable('https://play.tv3.lt/aferistai-10047125')
    t.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-12 18:39:13.048201
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError):
        ViafreeIE()

# Generated at 2022-06-12 18:39:16.786799
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true'
    TVPlayIE()._real_extract(url)



# Generated at 2022-06-12 18:39:24.700039
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert not ie.suitable("http://www.tv3play.se/program/husraddarna/395385?autostart=true")
    assert not ie.suitable("https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true")
    assert not ie.suitable("http://www.tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true")

# Generated at 2022-06-12 18:39:30.633480
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE.TVPlayIE()
    # Test that _VALID_URL regexp is correct
    for test in tvplayie._TESTS:
        if "only_matching" in test:
            assert re.match(tvplayie._VALID_URL, test['url'])
        else:
            assert re.match(tvplayie._VALID_URL, test['url']), test['url']



# Generated at 2022-06-12 18:39:33.553583
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")

# Generated at 2022-06-12 18:39:37.343174
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(TypeError):
        TVPlayHomeIE()  # No api is provided for TVPlayHomeIE



# Generated at 2022-06-12 18:40:15.374763
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('http://tvplay.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')

# Generated at 2022-06-12 18:40:21.164803
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE()
    assert obj.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert obj.suitable('http://www.tv4play.se/program/nyhetsmorgon/6161565?autostart=true')

# Generated at 2022-06-12 18:40:32.190837
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # pylint: disable=too-many-locals
    # Test data
    input_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    expected_url = 'https://tvplay.tv3.lt/aferistai-10047125'
    expected_ie_key = 'TVPlayHome'
    expected_video_id = '366367'

    # Getting an instance of TVPlayHomeIE and performing some tests
    ie = TVPlayHomeIE(expected_ie_key)
    assert ie._match_id == TVPlayHomeIE._match_id
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

    # Preparing regexes
    ie._VALID_URL = re.compile(ie._VALID_URL)
   

# Generated at 2022-06-12 18:40:44.548310
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	ie = TVPlayIE()

# Generated at 2022-06-12 18:40:49.783857
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert not ViafreeIE.suitable("http://play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true")


# Generated at 2022-06-12 18:40:52.160706
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import unittest
    from . import TVPlayHomeIE
    from . import URL_VALID
    # import logging
    # logging.basicConfig(level=logging.DEBUG)

    # test if the class could be initialized
    tph = TVPlayHomeIE(URL_VALID)
    assert tph is not None


# Generated at 2022-06-12 18:40:59.456969
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/avsnitt-1')
    assert ie.country == 'se'
    assert ie.path == 'underhallning/i-like-radio-live/sasong-1/avsnitt-1'

    ie = ViafreeIE('http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'no'
    assert ie.path == 'reality/paradise-hotel/saeson-7/episode-5'

    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-12 18:41:01.566431
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME in ie.ie_key()
    assert ie.IE_DESC in ie.ie_key()


# Generated at 2022-06-12 18:41:07.318319
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:41:18.293838
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")    
    assert ie.get_url() == "https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/"
    assert ie.get_url_id() == "vinas-melo-labak-10280317"
    assert ie.get_url_id_regex() == "(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)"
    assert ie.get_url_title_regex() == None
    assert ie.get_url_title() == None
    assert ie.get_thumbnail() == None
    assert ie.get

# Generated at 2022-06-12 18:42:29.480521
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_html import assertExtractAll, assertExtractAllNested
    assertExtractAllNested(TVPlayHomeIE, 'http://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', {
        'series': 'Vīna šķirne Labak',
        'season': 'Sezona 1',
        'season_number': 1,
        'episode_number': 1,
        'episode': 'Vīna šķirne Labak 1. sezona 1. sērija',
        'id': '10280317',
    })


# Generated at 2022-06-12 18:42:42.964074
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # Check 'valid_urls'
    assert ie.VALID_URL
    for url in ie.VALID_URL:
        assert_true(re.match(url, "https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/"),
                    "The URL '" + url + "' is not matching any of the valid URLs")
    # Check '_TESTS'
    assert_true(ie._TESTS, "The value '_TESTS' is empty")
    # Check if '_TESTS' contains all of the valid URLs
    for url in ie._TESTS:
        assert_in("url", url, "The value 'url' is missing in the test")

# Generated at 2022-06-12 18:42:48.839614
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert obj.g_country == 'lt'

    obj = TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert obj.g_country == 'ee'

    obj = TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert obj.g_country == 'se'

    obj = TVPlayIE('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    assert obj.g_

# Generated at 2022-06-12 18:42:57.285205
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Unit test for TVPlayIE"""

# Generated at 2022-06-12 18:42:59.337962
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from mtvservices.mtgx import MTGX
    mtgex = MTGX()
    viafree = ViafreeIE(mtgex)
    assert viafree.mtgx == mtgex

# Generated at 2022-06-12 18:43:05.619403
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?
                                    viafree\.(?P<country>dk|no|se)
                                    /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                '''



# Generated at 2022-06-12 18:43:12.132953
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    viafree = ViafreeIE()
    assert viafree._VALID_URL == 'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'



# Generated at 2022-06-12 18:43:14.244730
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE({'country': 'Norway'})
    ViafreeIE({'country': 'Finland'})

# Generated at 2022-06-12 18:43:15.932738
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    test.register_video_extractor()
    return test



# Generated at 2022-06-12 18:43:30.384482
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    extractor = TVPlayIE()

# Generated at 2022-06-12 18:45:02.692665
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test when URL is from TV3Play
    assert TV3PlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385')
    # Test when URL is not from TV3Play
    assert not TV3PlayIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    # Test when URL is not from TV3Play
    assert not TV3PlayIE.suitable('https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')
    # Test when URL is from TV3Play

# Generated at 2022-06-12 18:45:05.453296
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_site_ie = ViafreeIE('https://www.viafree.se/program/tv3-zinas/avsnitt-3')
    assert isinstance(test_site_ie, ViafreeIE)



# Generated at 2022-06-12 18:45:06.418858
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.country == 'SE'
    assert ie.language == 'sv'

# Generated at 2022-06-12 18:45:07.710216
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-12 18:45:14.771248
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvph_ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert tvph_ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert tvph_ie._GEO_COUNTRIES == ['LT', 'LV', 'EE']

# Generated at 2022-06-12 18:45:16.025128
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    res = TVPlayIE()
    assert res.IE_NAME == 'mtg'
    assert res.IE_DESC == 'MTG services'



# Generated at 2022-06-12 18:45:17.859435
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
        """
        Unit test for constructor of class TVPlayIE
        """
        ie = TVPlayIE()
        assert ie.IE_NAME == 'mtg'
        assert ie.IE_DESC == 'MTG services'



# Generated at 2022-06-12 18:45:22.880393
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-12 18:45:23.652902
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE("test")


# Generated at 2022-06-12 18:45:29.993862
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    viafreeIE = ViafreeIE()
    vf_match = viafreeIE._VALID_URL.match(url)
    vf_country = vf_match.group('country')
    vf_path = vf_match.group('id')

    # Test _VALID_URL regex
    assert vf_path == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    assert vf_country == 'se'
    assert viafreeIE.suitable(url) == True

    # Test _download_json
    # Note that this is actually a correct content of