

# Generated at 2022-06-12 18:38:47.834610
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true', verify = False)
#


# Generated at 2022-06-12 18:38:54.642488
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    test_video = TVPlayIE._TESTS[0]
    test_ignore_list = ['upload_date', 'md5']
    test_dict = test_video.copy()
    test_dict.pop('url')
    test_dict.pop('info_dict')
    for ignore in test_ignore_list:
        test_dict.pop(ignore)
    assert test_dict == TVPlayIE(TVPlayIE.ie_key())._extract_info(url, {})



# Generated at 2022-06-12 18:38:58.711354
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', {})
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'


# Generated at 2022-06-12 18:39:14.400857
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Generates a mock object for class ViafreeIE
    ie = ViafreeIE(MockYDL())
    # Generates a mock object for class InfoExtractor
    base_ie = InfoExtractor(MockYDL())
    assert not hasattr(base_ie, 'geo_verification_headers')
    assert hasattr(ie, 'geo_verification_headers')

    # Tests that the class method suitable is working properly
    url = 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    valid_suitable = ie.suitable(url)
    url = 'http://play.tv3play.se/program/husraddarna/395385?autostart=true'
    invalid_suitable = ie

# Generated at 2022-06-12 18:39:19.486261
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:39:20.802824
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-12 18:39:21.424375
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:39:21.994088
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-12 18:39:28.849148
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test the constructor of ViafreeIE
    # that it works without failing

    # Load data from test file
    import json
    with open('test/data/test_ViafreeIE_init.json') as f:
        t = json.load(f)
    url = t['url']
    country, path = re.match(r'^https://www\.([a-z]{2})\.viafree\.([a-z]{2})', url).groups()

    # Test constructor
    test_ViafreeIE = ViafreeIE(url)
    test_ViafreeIE.geo_verification_headers()
    test_ViafreeIE.country = country
    test_ViafreeIE.path = path
    test_ViafreeIE._download_json(path)


# Generated at 2022-06-12 18:39:31.389268
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')



# Generated at 2022-06-12 18:40:09.877789
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    matches = TVPlayHomeIE._VALID_URL.match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    ie = TVPlayHomeIE(matches.group(1))
    ie._real_extract(matches.group(0))

# Generated at 2022-06-12 18:40:14.101207
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable(ViafreeIE._VALID_URL) == True
    assert ie.suitable(TVPlayIE._VALID_URL) == False

if __name__ == '__main__':
    test_ViafreeIE()

# Generated at 2022-06-12 18:40:25.842017
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE.
    """
    ie = TVPlayIE()
    assert ie.IE_NAME == "mtg"
    assert ie.IE_DESC == "MTG services"

# Generated at 2022-06-12 18:40:28.258171
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import _test_TVPlayIE
    _test_TVPlayIE('TVPlayHomeIE')


# Generated at 2022-06-12 18:40:29.188234
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
    except TypeError as e:
        assert False, e.message


# Generated at 2022-06-12 18:40:31.422442
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert TVPlayHomeIE == ie.__class__
    assert 'TVPlayHomeIE' == ie.IE_NAME

# Generated at 2022-06-12 18:40:34.681514
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from ytdl.ytdl import Youtubedl
    e = TVPlayHomeIE.ie_key()
    instance = e(Youtubedl())
    assert instance.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-12 18:40:37.490605
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = TVPlayHomeIE._VALID_URL
    m = re.match(url, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE(m) # Test constructor


# Generated at 2022-06-12 18:40:39.518984
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = get_info_extractor('Viafree')
    assert isinstance(ie, ViafreeIE)


# Generated at 2022-06-12 18:40:47.073120
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test google-style docstring
    url = 'https://www.google.com'
    ie = ViafreeIE(url)
    assert ie.url == url

    # test __init__ when inherit from InfoExtractor
    ie = InfoExtractor(url)
    assert ie.url == url

    # test __init__ when inherit from YoutubeIE
    ie = YoutubeIE(url)
    assert ie.url == url


# Generated at 2022-06-12 18:41:25.636196
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Without specific order of args of constructor
    ie = TVPlayHomeIE(None, None)
    assert isinstance(ie, TVPlayHomeIE)

    # With specific order of args of constructor
    ie = TVPlayHomeIE(None)
    assert isinstance(ie, TVPlayHomeIE)

TV6PlayHomeIE = TVPlayHomeIE
TV3PlayHomeIE = TVPlayHomeIE



# Generated at 2022-06-12 18:41:27.862998
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    result = TVPlayIE()
    assert hasattr(result, '_VALID_URL')


# Generated at 2022-06-12 18:41:32.658261
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    iev = TVPlayIE()
    iev._initialize_geo_bypass({'countries': ['LV']})
    iev.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-12 18:41:37.454724
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()._get_supported_ie('https://play.novatv.bg/programi/za-mama-si/814050')
    assert tes

# Generated at 2022-06-12 18:41:41.795841
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert ie.name == 'tvplay'
    assert ie.ie_key() == 'TVPlayHome'


# Generated at 2022-06-12 18:41:44.756830
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-12 18:41:49.244756
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'https://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    ie = TVPlayIE()
    ie._real_extract(test_url)


# Generated at 2022-06-12 18:41:50.224913
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-12 18:41:57.754273
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:42:03.622064
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    entry = ViafreeIE().suitable('https://www.example.com/test')
    assert False is entry
    entry = ViafreeIE().suitable(TVPlayIE()._VALID_URL)
    assert False is entry
    entry = ViafreeIE().suitable(ViafreeIE._VALID_URL)
    assert True is entry

# Generated at 2022-06-12 18:43:14.157430
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check that constructor generates instances
    ViafreeIE()


# Generated at 2022-06-12 18:43:16.483195
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE({}, 'http://tvplay.tv3.lt/aferistai-10047125/')
    assert isinstance(IE, TVPlayHomeIE)


# Generated at 2022-06-12 18:43:17.599267
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE() != None


# Generated at 2022-06-12 18:43:27.443533
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)

    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:43:36.622951
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafrees = [ViafreeIE(x) for x in ViafreeIE._TESTS]
    assert (viafrees[0]._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    ''')
    assert(viafrees[0]._GEO_BYPASS == False)
    assert(viafrees[0]._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:43:41.790742
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    tvplay = TVPlayIE()

    # Test the constructor object
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:43:44.558300
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._TESTS[0]['info_dict']['id'] == '366367'

# Generated at 2022-06-12 18:43:45.497675
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')

# Generated at 2022-06-12 18:43:54.354183
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_cases = {
        'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1': True,
        'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1': True,
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5': True,
        'http://play.dplay.se/program/husraddarna/395385?autostart=true': False,
    }
    for url, expected_return_value in test_cases.items():
        assert ViafreeIE._VALID_URL == ViafreeIE._VALID_URL_TEMPL

# Generated at 2022-06-12 18:43:56.559242
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ''' Builds the object and verifies that it is a ViafreeIE '''
    testobject = ViafreeIE()
    assert isinstance(testobject, ViafreeIE)


# Generated at 2022-06-12 18:45:26.198216
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-12 18:45:36.632944
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._VALID_URL.findall('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert TVPlayIE._VALID_URL.findall('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert TVPlayIE._VALID_URL.findall('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert TVPlayIE._VALID_URL.findall('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-12 18:45:37.952253
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-12 18:45:41.778761
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ies = [ViafreeIE]

    for ie in ies:
        ie_test = ie()
        assert ie_test.suitable(ie_test._VALID_URL) == True
        assert ie_test.suitable(ie_test._VALID_URL[:-2]) == False
        assert ie_test._VALID_URL != None


# Generated at 2022-06-12 18:45:44.737763
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:45:46.890021
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert hasattr(ViafreeIE, 'suitable')


# Generated at 2022-06-12 18:45:58.476563
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test class TVPlayIE."""
    def _assert_IE_name(ie):
        assert ie.IE_NAME == 'mtg'
        assert ie.ie_key() == 'TVPlay'

    ie = TVPlayIE(TVPlayIE._build_url_result('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'))
    _assert_IE_name(ie)

# Generated at 2022-06-12 18:46:08.385512
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.__name__ == 'TVPlayHome'
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.host() == 'tvplayhome.com'
    assert ie.logo() == 'https://www.tvplayhome.com/static/img/logo_v2.png'
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._LOGIN_URL == 'https://www.tvplayhome.com/scripts/login.php'


# Generated at 2022-06-12 18:46:09.649201
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_obj = TVPlayHomeIE()
    assert test_obj


# Generated at 2022-06-12 18:46:12.713790
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == ie._build_regex(ie._VALID_URL_TEMPLATE, ie.IE_NAME, 'mtg', 'http')

