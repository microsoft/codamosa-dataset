

# Generated at 2022-06-12 18:38:52.586541
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    print("Executing unit test")
    content = "http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5"
    video = ViafreeIE()
    video_id = video._match_id(content)
    print("Video id is " + video_id)
    country = video._search_regex(r'https?://[^/]+\.([a-z]{2})', content,
                'geo country', default=None)
    print("Country is " + country)
    result = video._download_json(
                    'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s' % (country, video_id), video_id)
    print(result)

# Generated at 2022-06-12 18:38:58.914869
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie.url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie.url == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'



# Generated at 2022-06-12 18:39:08.117079
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    title = 'Kādi ir īri? - Viņas melo labāk'
    description = 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.'
    duration = 25
    series_title = 'Viņas melo labāk'
    season_title = '2.sezona'
    season_number = 2
    upload_date = '20140723'
    timestamp = 1406097056
    view_count = 356
    episode_number = 3

# Generated at 2022-06-12 18:39:20.670026
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Tests:
    # http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5
    # https://www.viafree.dk/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-10
    # https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869
    # https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1
    content = open_testdata(__name__, 'mtg.html')
    expected = open_testdata(__name__, 'mtg.json')
    mtg = ViafreeIE._extract_mtg_json

# Generated at 2022-06-12 18:39:23.532647
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Get instance of class
    mtvp = TVPlayIE()

    # Check
    assert mtvp.IE_NAME == 'mtg'
    assert mtvp.IE_DESC
    assert mtvp._VALID_URL
    assert mtvp._TESTS



# Generated at 2022-06-12 18:39:28.642156
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert ie.url == "https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/"
    assert ie.video_id == "10280317"
    assert ie.age_limit == 18



# Generated at 2022-06-12 18:39:41.777092
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317/", {}, {})
    assert ie.suitable("https://tv3play.skaties.lv/vinas-melo-labak-10280317/")
    assert ie.suitable("https://play.tv3.lt/aferistai-10047125")
    assert ie.suitable("https://play.tv3.ee/cool-d-ga-mehhikosse-10044354")
    assert ie.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")

# Generated at 2022-06-12 18:39:50.089140
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.host == 'tv3play.skaties.lv'
    assert ie.media_id == '418113'
    assert ie.url == 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-418113/'
    
    ie = TVPlayHomeIE(None)
    ie.media_id = '418113'
    ie.host = 'tv3play.skaties.lv'
    assert ie.url == 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-418113/'



# Generated at 2022-06-12 18:39:59.475818
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from ..utils import get_testcases, get_testcases_from_list


# Generated at 2022-06-12 18:40:07.113006
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:40:26.440197
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert instance._VALID_URL
    assert instance._TESTS



# Generated at 2022-06-12 18:40:35.524821
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    str = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    result = ie._match_id(str)
    assert result == '409229'

    str = 'https://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    result = ie._match_id(str)
    assert result == '409229'

    str = 'http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true'
    result = ie._match_id(str)
    assert result == '238551'


# Generated at 2022-06-12 18:40:38.197126
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Smoke test
    instance = TVPlayHomeIE()

    # Test type of each attribute
    assert isinstance(instance.name, str)
    assert isinstance(instance.description, str)
    assert isinstance(instance._VALID_URL, str)
    assert isinstance(instance._TESTS, list)



# Generated at 2022-06-12 18:40:39.772317
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    instance._download_json('', None, None)

# Generated at 2022-06-12 18:40:43.048190
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(FakeInfoExtractor(), 'http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')



# Generated at 2022-06-12 18:40:44.019833
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:40:53.466949
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:40:58.773817
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def contains(search, list_):
        """
        Function to test that a list contains an item
        """
        for l in list_:
            if re.search(search, l):
                return True
        return False

    if 'tvplay.lv' in _GEO_BYPASS_COUNTRIES:
        _GEO_BYPASS_COUNTRIES.remove('tvplay.lv')
    ie = ViafreeIE()
    assert contains('/DK/', ie.get_countries())
    assert contains('.tvplay.lv/', ie.get_countries())

# Generated at 2022-06-12 18:41:00.730112
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_name = 'TVPlayIE'
    try:
        return globals()[class_name].ie_key()
    except:
        return class_name



# Generated at 2022-06-12 18:41:04.066367
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    tvplay_ie.IE_NAME
    tvplay_ie.IE_DESC
    tvplay_ie._VALID_URL
    tvplay_ie._TESTS

# Generated at 2022-06-12 18:41:48.927418
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:41:51.905673
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert instance.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == False


# Generated at 2022-06-12 18:41:54.513719
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:42:05.831360
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert (t.suitable('http://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    assert (t.suitable('https://play.tv3.lt/aferistai-10047125'))
    assert (t.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317'))
    assert (t.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'))
    assert (not t.suitable('https://tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true'))

# Generated at 2022-06-12 18:42:08.598425
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    temp = TVPlayIE()
    temp._initialize_geo_bypass({'countries': ['LV']})
    temp._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    temp._real_extract('http://playapi.mtgx.tv/v3/videos/stream/418113')



# Generated at 2022-06-12 18:42:13.079482
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        assert TVPlayIE.IE_NAME == 'mtg'
        assert TVPlayIE.IE_DESC == 'MTG services'
    except:
        raise

if __name__ == '__main__':
    test_TVPlayIE()

# Generated at 2022-06-12 18:42:27.139478
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    sami_path = "http://static.dr.dk/tv/smi/2012/11/24/dr1_newtopia_28_201211240114_201211240145_123456789101112.dfxp.xml"
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    title = 'Husräddarna S02E07'
    description = 'md5:f210c6c89f42d4fc39faa551be813777'
    series = 'Husräddarna'
    episode_number = 7
    season = '2 säsong'
    season_number = 2
    duration = 2574
    timestamp = datetime.datetime(2014, 5, 20, 21, 2, 1)
    view_

# Generated at 2022-06-12 18:42:28.586950
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Instantiate a TVPlayHomeIE object
    TVPlayHomeIE()

# Generated at 2022-06-12 18:42:42.701496
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert_equal(ie.url, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert_equal(ie.url, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-12 18:42:46.658932
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie_instance = ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert isinstance(ie_instance, TVPlayHomeIE), "Test for constructor failed"

# Generated at 2022-06-12 18:44:19.045434
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test that the correct ie is selected for video links in constructor of class TVPlayHomeIE."""
    def test_case(url, ie_key):
        info_extractor = gen_extractors(
            # Fake input args
            None, None, [url], {})[0]
        assert isinstance(info_extractor, globals()[ie_key])
    # list of test cases with inputs and corresponding expected outputs

# Generated at 2022-06-12 18:44:20.320557
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE().test()


# Generated at 2022-06-12 18:44:21.843073
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE("TVPlayIE('mtg:418113', '');")


# Generated at 2022-06-12 18:44:22.740181
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-12 18:44:26.536969
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = "https://play.tv3.ee/cool-d-ga-mehhikosse-10044354"
    ie = TVPlayHomeIE(url)
    assert ie.suitable(url)

# Generated at 2022-06-12 18:44:28.447758
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie

# Generated at 2022-06-12 18:44:38.905754
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')


# Generated at 2022-06-12 18:44:41.798601
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Basic test for constructor for TVPlayIE."""
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')



# Generated at 2022-06-12 18:44:43.953862
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    Type = TVPlayHomeIE._TESTS[0]['info_dict']['id']
    assert Type == '366367'

# Generated at 2022-06-12 18:44:51.257839
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://play.tv3.lt/aperistai-10047125/') is True
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317/') is True
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354/') is True
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125') is True

# Generated at 2022-06-12 18:48:25.200773
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.utils import RegexNotFoundError

    def test(country, expected_country):
        country_lower = country.lower()
        country_upper = country.upper()
        video_url = 'http://www.viafree.%s/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1' % country_lower

        test_ViafreeIE = ViafreeIE()
        m = test_ViafreeIE._VALID_URL_RE.match(video_url)
        if not m:
            raise RegexNotFoundError('invalid URL: %s' % video_url)

        path = m.group('id')
        country_obtained = m.group('country')

        assert country_obtained == country_lower
        assert test_ViafreeIE._GEO_