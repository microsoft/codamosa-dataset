

# Generated at 2022-06-12 18:38:53.440876
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    ie = ViafreeIE(url)
    assert ie.valid_url(url)
    assert ie.valid_url('http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.valid_url('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ie.valid_url('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')

# Generated at 2022-06-12 18:39:00.861286
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""
    return_value = True

    Play = TVPlayHomeIE(None)

    if Play._VALID_URL is None:
        return_value = False
    if Play._TESTS is None:
        return_value = False
    if Play._GEO_BYPASS is None:
        return_value = False
    if Play._GEO_COUNTRIES is None:
        return_value = False

    return return_value


# Generated at 2022-06-12 18:39:15.452567
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert isinstance(instance, TVPlayIE)

# Generated at 2022-06-12 18:39:21.092254
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Arrange
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    # Act
    tmp_ie = ViafreeIE()(url)
    # Assert
    assert tmp_ie._VALID_URL == ViafreeIE._VALID_URL
    assert tmp_ie._TESTS == ViafreeIE._TESTS
    assert tmp_ie._GEO_BYPASS == ViafreeIE._GEO_BYPASS

# Generated at 2022-06-12 18:39:25.690355
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_urls = ["https://play.tv3.lt/aferistai-10047125",
                 "https://play.tv3.ee/cool-d-ga-mehhikosse-10044354"]
    for url in test_urls:
        if TVPlayHomeIE.suitable(url) :
            TVPlayHomeIE(url)

# Generated at 2022-06-12 18:39:29.286594
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    tvplayIE = TVPlayIE(url)
    assert tvplayIE._TESTS[1]['url'] == url

# Generated at 2022-06-12 18:39:42.215634
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)'

# Generated at 2022-06-12 18:39:49.332227
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafree.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert viafree.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-12 18:39:50.493465
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor "unit test"
    ie = TVPlayIE()
    ie.su


# Generated at 2022-06-12 18:39:56.177542
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:40:37.067558
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import TVPlayHomeIE
    ie = TVPlayHomeIE(None)
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:47.521793
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def mock_search_regex(pattern, string, name, default=NO_DEFAULT, fatal=True, flags=0):
        if pattern == r'https?://[^/]+\.([a-z]{2})':
            return 'se'
        elif pattern == r'<link rel="canonical" href="(.+?)" />':
            return 'http://www.tv3play.se/program/parlamentet/1114?autostart=true'
        else:
            return '418113'


# Generated at 2022-06-12 18:40:55.910870
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    IE = TVPlayHomeIE()
    assert IE._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:57.989031
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert (ie.IE_NAME == 'TVPlayHome')
    assert (ie.IE_DESC == 'TVPlayHome, TV3.lt and TV3.ee')

# Generated at 2022-06-12 18:41:04.830256
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    assert ie.suitable(ie._VALID_URL) is True
    assert ie.suitable('http://www.youtube.com/watch?v=BaW_jenozKc') is False

# Generated at 2022-06-12 18:41:11.650549
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Via e.g. https://github.com/rg3/youtube-dl/issues/11961 ;
    # the problem may not be possible to reproduce anymore, but
    # the test is included for safety
    # TODO: Remove this test in future
    with pytest.raises(TypeError):
        ViafreeIE(object)

# Generated at 2022-06-12 18:41:16.340980
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl import YoutubeDL

    assert YoutubeDL().extract_info(
        'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')


# Generated at 2022-06-12 18:41:24.395493
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    This test suites tests the constructor of class TVPlayIE.
    """
    ie = TVPlayIE()

# Generated at 2022-06-12 18:41:28.208572
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie_tvplayhome = TVPlayHomeIE()
    assert ie_tvplayhome.IE_NAME == 'tvplayhome'
    assert ie_tvplayhome.IE_DESC == 'TVPlay Home'
    assert ie_tvplayhome.VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie_tvplayhome.GEO_COUNTRIES == ['LT', 'EE', 'LV']
    assert ie_tvplayhome.host == 'tvplayhome.com'
    assert ie_tvplayhome.age_limit == 18


# Generated at 2022-06-12 18:41:37.349771
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-12 18:42:17.057644
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    n = TVPlayIE()
    n.IE_NAME
    n.IE_DESC
    n._VALID_URL
    n._TESTS


# Generated at 2022-06-12 18:42:20.037096
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie.IE_NAME



# Generated at 2022-06-12 18:42:23.698663
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    test_TVPlayHomeIE.test_ie = TVPlayHomeIE()
    test_TVPlayHomeIE.test_ie._real_extract(url)



# Generated at 2022-06-12 18:42:28.617230
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/livsstil/husraddarna/saeson-2/episode-2'
    ieTest = ViafreeIE(url)
    assert ieTest.country == 'dk', 'country should be dk'
    assert ieTest.path == 'livsstil/husraddarna/saeson-2/episode-2', 'path should be \'livsstil/husraddarna/saeson-2/episode-2\''



# Generated at 2022-06-12 18:42:42.279623
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import tvplay_tests
    from .extractor import _make_result

    obj = _make_result(TVPlayHomeIE, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', [], [])
    assert obj.url == obj.video_url == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert obj.title == 'Aferistai'
    assert obj.country_code == 'LT'
    assert obj.video_id == '366367'
    assert obj.video_url == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'



# Generated at 2022-06-12 18:42:44.889785
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true', {}, lambda x: None)
    assert a

# Generated at 2022-06-12 18:42:46.288864
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE({})
    assert ie is not None

# Generated at 2022-06-12 18:42:50.948039
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    ie = ViafreeIE(url)
    # TODO: add unit test for ViafreeIE.suitable(url)
    # TODO: add unit test for ViafreeIE._real_extract(url)


# Generated at 2022-06-12 18:42:52.216398
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.extract()

# Generated at 2022-06-12 18:42:52.927294
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-12 18:44:33.490207
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info = {
        'id': '757786',
        'ext': 'mp4',
        'title': 'Det beste vorspielet - Sesong 2 - Episode 1',
        'description': 'md5:b632cb848331404ccacd8cd03e83b4c3',
        'series': 'Det beste vorspielet',
        'season_number': 2,
        'duration': 1116,
        'timestamp': 1471200600,
        'upload_date': '20160814',
    }
    assert info == ViafreeIE()._extract_info('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-12 18:44:40.795465
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/418113'
    ie = TVPlayIE(TVPlayIE.suitable(url), url)
    assert ie._match_id(ie.suitable(url)), ie.suitable(url)
    assert ie._VALID_URL is not None, ie
    assert ie._TESTS is not None, ie
    assert ie._GEO_BYPASS is not None, ie
    assert ie.IE_NAME is not None, ie

# Generated at 2022-06-12 18:44:42.857850
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Check if constructor of class TVPlayIE raise expected exceptions
    raise NotImplementedError



# Generated at 2022-06-12 18:44:43.793628
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:44:44.386535
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-12 18:44:51.596049
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import InfoExtractor
    from ..utils import urldecode_postdata


# Generated at 2022-06-12 18:45:01.759053
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_ = TVPlayIE
    # Positive examples
    # tv3play.lt
    url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    # tv3play.ee
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    # tv3play.se
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    # tv3play.se
    url = 'http://www.tv3play.se/program/den-sista-dokusapan/266636?autostart=true'
    # tv6play.se

# Generated at 2022-06-12 18:45:04.482234
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-12 18:45:06.496861
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()
    # Test with the only supported URL from _TESTS
    x._real_extract(
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-12 18:45:14.231757
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    constructor = TVPlayIE 
    # Test for incorrect url
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    # Test for correct url
    url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    # Test for incorrect url
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    # Test for incorrect url
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    # Test for incorrect url