

# Generated at 2022-06-12 18:38:54.127234
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('http://www.tv3play.dk/programmer/husraddarna/395385?autostart=true')
    assert ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-12 18:38:56.815981
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE(None, None, None)._VALID_URL == TVPlayIE._VALID_URL



# Generated at 2022-06-12 18:38:59.166419
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('test')
    assert isinstance(ie, TVPlayIE)


# Generated at 2022-06-12 18:39:06.895447
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Simple test for constructor of class TVPlayHomeIE
    """
    video_id = '10044354'
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-' + video_id
    tvplayhomeie = TVPlayHomeIE(url)
    assert tvplayhomeie._match_id(url) == video_id

# Generated at 2022-06-12 18:39:16.104459
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info = ViafreeIE._download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/program/underhallning/det-beste-vorspielet/sesong-2/episode-1',
        '757786')
    content = info.get('_embedded', {}).get('viafreeBlocks', [])[0]
    program = content.get('_embedded', {}).get('program', {})
    series = content.get('seriesTitle')
    title = info.get('meta', {}).get('title')
    guid = program.get('guid')
    episode = program.get('episode', {})
    episode_no = episode.get('episodeNumber')
    season_no = episode.get('seasonNumber')

# Generated at 2022-06-12 18:39:19.512582
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	ie = TVPlayIE()
	assert ie.IE_NAME == 'mtg'
	assert ie.IE_DESC == 'MTG services'

# Unit tests for extractors
import unittest
from .common import *
from .test_youtube import *


# Generated at 2022-06-12 18:39:21.502840
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Constructor test
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-12 18:39:22.638790
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable(TVPlayIE())


# Generated at 2022-06-12 18:39:25.748216
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    # Test url
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert viafree_ie.suitable(url)



# Generated at 2022-06-12 18:39:28.618989
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    except ValueError:
        assert False


# Generated at 2022-06-12 18:40:06.204363
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE_test = TVPlayHomeIE(None)
    # Test for the constructor of class TVPlayHomeIE has to be implemented.



# Generated at 2022-06-12 18:40:13.791933
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-12 18:40:19.087766
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test cases for constructor of class TVPlayHomeIE

    # Input unit test case data
    test_object = {
        'url': 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'mode': 'playlist',
    }
    # Expected output when executing the code

# Generated at 2022-06-12 18:40:30.903467
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class TestViafreeIE(ViafreeIE):
        def _download_json(self, path, video_id, headers=None):
            return {
                '_embedded': {
                    'viafreeBlocks': [{
                        '_embedded': {
                            'program': {
                                'guid': '125777',
                                'episode': {},
                                '_links': {
                                    'streamLink': {
                                        'href': 'https://content.viaplay.se/pc-se/film/hercules-2014?blockId=125777&partial=1'
                                    }
                                }
                            }
                        }
                    }]
                },
                'meta': {
                    'title': 'Viaplay'
                }
            }


# Generated at 2022-06-12 18:40:44.144109
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    expected_title = 'Det beste vorspielet - Sesong 2 - Episode 1'
    assert TVPlayIE.suitable(url)
    assert not ViafreeIE.suitable(url)
    assert not ViafreeIE.IE_DESC.lower() in TVPlayIE.IE_DESC.lower()
    # Note: regex is case-sensitive => 'tvplay' != 'TVPlay'
    assert not ViafreeIE.IE_DESC.lower() in globals()['TVPlayIE'].IE_DESC.lower()
    # Instantiate an instance of ViafreeIE and test if url, expected title matches the actual one
    ie = ViafreeIE()
    info

# Generated at 2022-06-12 18:40:48.638652
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE(None, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    except NotImplementedError as e:
        pass
    else:
        raise AssertionError('Exception was not raised')

# Generated at 2022-06-12 18:40:50.660301
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-12 18:40:51.566303
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-12 18:40:56.886574
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ies = [
        ViafreeIE([]),
        TVPlayIE([]),
    ]
    for ie in ies:
        assert ie.geo_countries == ['LV', 'NO', 'SE']
        assert ie.IE_NAME == ie.__class__.__name__
        assert ie.geo_bypass
        assert ie._VALID_URL == ie._build_regex_for_compat()
        assert ie._GEO_COUNTRIES == ie.geo_countries


# Generated at 2022-06-12 18:40:58.026365
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-12 18:41:38.789367
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
	assert re.match(ViafreeIE._VALID_URL, 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

test_ViafreeIE()

# Generated at 2022-06-12 18:41:43.306814
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv6play.se/program/husraddarna/395385?autostart=true'
    t = TVPlayIE()
    assert t._match_id(url) == '395385'
    assert t._VALID_URL == TVPlayIE._VALID_URL

# Generated at 2022-06-12 18:41:53.669503
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    if not ie.needs_login:
        assert ie.IE_NAME == 'mtg'
        assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:42:04.960684
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class TVPlayIE(InfoExtractor):
        def __init__(self, ie_name, ie_desc):
            InfoExtractor.__init__(self, ie_name, ie_desc)

    instance = TVPlayIE('IE_NAME', 'IE_DESC')
    expected = 'https://playapi.mtgx.tv/v3$fmt'
    for formats in ('streams', 'season', 'episode'):
        instance.suitable(expected.replace('$fmt', '/%s' % formats))
        instance.suitable(expected.replace('$fmt', '/videos/%s' % formats))
        instance.not_suitable(expected.replace('$fmt', '/not/%s' % formats))

# Generated at 2022-06-12 18:42:08.202704
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tv_play_home_ie = TVPlayHomeIE(FakeYDL(), {'url': url})
    assert tv_play_home_ie._real_extract(url)



# Generated at 2022-06-12 18:42:13.699355
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-12 18:42:27.588045
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS
    assert ie._GEO_COUNTRIES == TVPlayHomeIE._GEO_COUNTRIES
    assert ie._API_BASE_URL == TVPlayHomeIE._API_BASE_URL
    assert ie._login == TVPlayHomeIE._login
    assert ie._video_password == TVPlayHomeIE._video_password
    assert ie._video_info == TVPlayHomeIE._video_info
    assert ie.BRIGHTCOVE_URL_TEMPLATE == TVPlayHomeIE.BRIGHTCOVE_URL_TEMPLATE
    assert ie

# Generated at 2022-06-12 18:42:31.375777
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    # assert obj.IE_DESC == 'MTG services'
    assert obj._VALID_URL.startswith('(?x)')

# Generated at 2022-06-12 18:42:35.681488
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")


# Generated at 2022-06-12 18:42:38.240148
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(_VALID_URL, {}) is not None

# Generated at 2022-06-12 18:44:07.743835
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return True


# Generated at 2022-06-12 18:44:10.618588
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert(ie.name == 'TVPlayHome')

# Generated at 2022-06-12 18:44:12.661527
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert TVPlayHomeIE._VALID_URL == ie._VALID_URL
    assert TVPlayHomeIE._TESTS == ie._TESTS
    assert TVPlayHomeIE._GEO_BYPASS == ie._GEO_BYPASS

# Generated at 2022-06-12 18:44:21.892127
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('mtg:418113')._VALID_URL == '^(?:mtg:|https?://(?:www\\.)?(?:tvplay(?:\\.skaties)?\\.lv(?:/parraides)?|(?:tv3play|play\\.tv3)\\.lt(?:/programos)?|tv3play(?:\\.tv3)?\\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\\.no|(?:tv3play|viafree)\\.dk)/programmer|play\\.nova(?:tv)?\\.bg/programi)/(?:[^/]+/)*)(?P<id>\\d+)$'


# Generated at 2022-06-12 18:44:32.609431
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_video_id = '10044354'
    tvplay_home_url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-{}'.format(tvplay_home_video_id)

    tvplay_home = TVPlayHomeIE(TVPlayHomeIE._create_get_info_extractor(tvplay_home_url))
    tvplay_home_json_url = 'https://play.tv3.ee/sb/public/asset/{}'.format(tvplay_home_video_id)
    unit_test_url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'

    # Testing the tvplay_home_json_url extraction
    test_tvplay_home_json_url = tvplay_

# Generated at 2022-06-12 18:44:34.477041
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Fails due to missing webpage
    pass


# Generated at 2022-06-12 18:44:38.950270
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?|play)\.tv3\.(?:lt|ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-12 18:44:41.058468
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        # Testing only constructor
        ie = ViafreeIE()
        ie.suitable(None)
    except:
        assert False

# Generated at 2022-06-12 18:44:43.759255
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE._download_json('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', '366367')

# Generated at 2022-06-12 18:44:51.104738
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .common import GeneratorTestCase

    class _FakeTVPlayHomeIE(TVPlayHomeIE):
        def __init__(self, ie, video_id):
            super(_FakeTVPlayHomeIE, self).__init__(ie, video_id)

    class _FakeInfoExtractor(InfoExtractor):
        def __init__(self, ie_name, ie_id, video_id):
            super(_FakeInfoExtractor, self).__init__(ie_name, ie_id)
            self._video_id = video_id

        def _real_extract(self, url):
            return self.url_result(self._video_id)

    video_id = '10001'