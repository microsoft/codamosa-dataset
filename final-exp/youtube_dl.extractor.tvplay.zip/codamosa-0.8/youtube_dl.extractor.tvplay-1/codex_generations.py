

# Generated at 2022-06-12 18:38:52.127363
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test the constructor of class ViafreeIE
    ie = IE()
    viafree = ViafreeIE(ie=ie)
    assert viafree.name == 'Viafree'
    assert viafree.ie == ie
    assert viafree.ie_key() == 'Viafree'

    # Test the constructor of class ViafreeIE with bitrate
    ie = IE()
    viafree = ViafreeIE(ie=ie, bitrate=500)
    assert viafree.name == 'Viafree-500'
    assert viafree.ie == ie
    assert viafree.ie_key() == 'Viafree-500'



# Generated at 2022-06-12 18:39:02.036069
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    options = {'format': 'bestvideo', 'username': 'user', 'password': 'pass', 'videopassword': 'videopass', 'skipsignin': True}
    tvplay = TVPlayHomeIE('tvplay:1', options)
    assert tvplay.get_options()['skipsignin'] is True
    assert tvplay.get_options()['username'] == 'user'
    assert tvplay.get_options()['password'] == 'pass'
    assert tvplay.get_options()['videopassword'] == 'videopass'
    assert tvplay.get_options()['format'] == 'bestvideo'

# Generated at 2022-06-12 18:39:04.809382
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.suitable, 'https://tvplay.tv3.lt/aferistai-10047125/')
    assert ie.country == 'lt'


# Generated at 2022-06-12 18:39:17.753804
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    res = ie._real_extract(url)
    assert res['id'] == '366367'
    assert res['ext'] == 'mp4'
    assert res['title'] == 'Aferistai'
    assert res['description'] == 'Aferistai. Kalėdinė pasaka.'
    assert res['series'] == 'Aferistai [N-7]'
    assert res['season'] == '1 sezonas'
    assert res['season_number'] == 1
    assert res['duration'] == 464
    assert res['timestamp'] == 1394209658
    assert res['upload_date'] == '20140307'
    assert res

# Generated at 2022-06-12 18:39:27.889872
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert(ie.is_mod())
    assert(ie.is_mod("http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2")) == False
    assert(ie.is_mod("http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true"))
    assert(ie.is_mod("https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true"))
    assert(ie.is_mod("www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true"))

# Generated at 2022-06-12 18:39:31.051250
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE."""
    assert TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-12 18:39:34.036935
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")

# Generated at 2022-06-12 18:39:38.258874
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_youtube_dl import YoutubeDL
    from .test_common import ydl
    ydl = YoutubeDL(ydl.params)
    ViafreeIE(ydl)


# Generated at 2022-06-12 18:39:42.696340
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Testing with a valid URL
    VideoIO(TVPlayHomeIE, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

    # Testing with an invalid URL
    VideoIO(TVPlayHomeIE, 'https://google.com/')

# Generated at 2022-06-12 18:39:43.753172
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('ap')

# Generated at 2022-06-12 18:40:10.275021
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	test = TVPlayHomeIE()
	print("TVPlayHomeIE: " + str(test))
	print("TVPlayHomeIE.__class__: " + str(test.__class__))
	print("TVPlayHomeIE.__class__.__name__ : " + str(test.__class__.__name__))
	print("TVPlayHomeIE.__class__.__bases__ : " + str(test.__class__.__bases__))
	print("TVPlayHomeIE.__class__.__bases__[0] : " + str(test.__class__.__bases__[0]))
	print("TVPlayHomeIE.__class__.__bases__[0].__name__ : " + str(test.__class__.__bases__[0].__name__))

# Generated at 2022-06-12 18:40:15.485311
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_dict = TVPlayIE()._extract_video('http://tvplay.skaties.lv/parraides/nemesis-virus/638109')
    assert info_dict['title'] == 'Nemesis – Vīruss'
    assert info_dict['id'] == '638109'
    assert info_dict['series'] == 'Nemesis – Vīruss'
    assert info_dict['season'] == '1.sezona'
    assert info_dict['season_number'] == 1
    assert info_dict['episode_number'] == 1
    assert info_dict['duration'] == 20

# Generated at 2022-06-12 18:40:27.993682
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert ie._match_id(url) == '418113'
    assert ie._search_regex(r'https?://[^/]+\.([a-z]{2})', url, 'geo country') == 'lv'

    url = 'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true'
    assert ie._match_id(url) == '764300'
    assert ie._search_regex(r'https?://[^/]+\.([a-z]{2})', url, 'geo country') == 'bg'


# Generated at 2022-06-12 18:40:29.422407
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay


# Generated at 2022-06-12 18:40:31.270846
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_tvplay import test_TVPlayIE
    tvplay = TVPlayHomeIE(test_TVPlayIE())

# Generated at 2022-06-12 18:40:38.304494
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # VIAFREE_VALID_URL can be a string or a list of strings.
    # If it is a list of strings it is assumed that the test
    # will pass for all URLs in the list.
    VIAFREE_VALID_URL = 'https://www.viafree.se/program/reality/deltagare/sasong-11/avsnitt-1'

# Generated at 2022-06-12 18:40:38.965559
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE() is not None)

# Generated at 2022-06-12 18:40:39.651231
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:40:49.956475
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    def _check(url, expected_id):
        assert TVPlayHomeIE._VALID_URL.match(url)
        assert TVPlayHomeIE._VALID_URL.match(url).group('id') == expected_id

# Generated at 2022-06-12 18:40:51.528779
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, '')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-12 18:41:13.043302
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return [ViafreeIE]

# Generated at 2022-06-12 18:41:15.838232
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvie = TVPlayIE()
    assert tvie.tvplay_url_pattern == re.compile(tvie._VALID_URL)
    assert tvie._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-12 18:41:24.075711
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:41:31.193653
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE.

    In this test cases are tested, whether the base attributes are set correctly.
    """
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:41:33.557678
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-12 18:41:36.633428
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return ViafreeIE(TVPlayIE())

# Generated at 2022-06-12 18:41:40.539230
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.extractor import get_info_extractor
    from youtube_dl.extractor.viafree import ViafreeIE as _ViafreeIE

    assert get_info_extractor(_ViafreeIE.ie_key()) is _ViafreeIE


# Generated at 2022-06-12 18:41:41.830881
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ies = ViafreeIE()


# Generated at 2022-06-12 18:41:46.170388
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '10280317'
    m3u8_url = 'https://c.api.mtgx.tv/v3/videos/stream/' + video_id

# Generated at 2022-06-12 18:41:57.460811
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # get class instance
    ie = TVPlayHomeIE()
    # create some dummy data
    page = "//dummy page data"
    # get a dictionary with all matched fields
    test_dict = re.match(ie._VALID_URL, ie._TESTS[0]['url']).groupdict()
    # get id from matched fields
    id = test_dict.get('id')
    # assert that id from matched fields and id from
    # second element in unit test `test_dict` are the same
    assert(id == ie._TESTS[0]['info_dict']['id'])
    # create a new URL with new id
    url = re.sub(r'\d+', str(int(id) + 1), ie._TESTS[0]['url'])
    # assert that new URL and

# Generated at 2022-06-12 18:42:47.027460
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in TVPlayHomeIE._TESTS:
        ie = TVPlayHomeIE(url, False)
        assert ie.REAL_URL == TVPlayHomeIE._VALID_URL
        assert ie.SUCCESS == [TVPlayHomeIE._VALID_URL]
        assert ie.groupdict['id'] == TVPlayHomeIE._match_id(url)
        assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
        assert ie._TESTS == TVPlayHomeIE._TESTS
        assert ie._GEO_BYPASS == False

# Generated at 2022-06-12 18:42:57.627332
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('')
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-12 18:42:58.753461
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()


# Generated at 2022-06-12 18:43:00.682403
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    TestIEModule.test_IE([ie])


# Generated at 2022-06-12 18:43:04.622002
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(0, 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', {})
    for country in ['dk', 'no', 'se']:
        assert ie.suitable(
            'http://www.viafree.{country}/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'.format(country=country))


# Generated at 2022-06-12 18:43:09.912280
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Unit test for constructor of class TVPlayHomeIE.
    """
    properties = TVPlayHomeIE.get_properties()
    # check if properties were initialized
    for name in ['name', 'url']:
        assert properties[name]
    # check if name of IE is correct
    assert TVPlayHomeIE._NAME == TVPlayHomeIE.get_properties()['name']



# Generated at 2022-06-12 18:43:18.096901
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Normal case - no exception
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

    # Exception case
    #  'TVPlayIE' instance has no 'suitable' member
    with pytest.raises(AttributeError):
        ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-12 18:43:27.751762
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # To test constructor, we need a network connection.
    # In this way we make sure that it will not fail if
    # network connection is not available.
    import socket
    try:
        socket.gethostbyname('example.com')
    except socket.gaierror:
        raise RuntimeError('Network connection required to make TVPlayIE test')

    tv = TVPlayIE()
    assert tv.IE_NAME == 'mtg'
    assert tv.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:43:33.439330
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplay'
    assert ie.IE_DESC == 'TVPlay'
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS

# Generated at 2022-06-12 18:43:40.730721
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    assert(ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') == False)
    assert(ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == False)

    ie = TVPlayHomeIE('TVPlayHome')

    assert(ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') == False)
    assert(ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == False)

# Generated at 2022-06-12 18:45:20.902865
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(TVPlayIE.__name__ == 'TVPlayIE')
    assert(TVPlayIE._VALID_URL == TVPlayIE.IE_NAME)
    assert(TVPlayIE._TESTS[0]['url'] == TVPlayIE._VALID_URL)

# Generated at 2022-06-12 18:45:24.397386
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("test-id", "test-title", "test-description", "test-url", "test-thumbnail")
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.video_id() == "test-id"
    assert ie.title() == "test-title"
    assert ie.description() == "test-description"
    assert ie.url() == "test-url"
    assert ie.thumbnail() == "test-thumbnail"

# Generated at 2022-06-12 18:45:29.808643
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor_test(ViafreeIE, ['http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'])
    constructor_test(
        ViafreeIE, ['http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'],
        expected_warning=viafree_ie.compat_urllib_error.HTTPError(404, 'File not found', msg=('If the file exists, check permissions.'), hdrs={'Content-Type': 'text/plain', 'Connection': 'close'}, fp=None))


# Generated at 2022-06-12 18:45:38.932775
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Tests checking if instance of TVPlayHomeIE class can be created with given URL
    """
    tested_urls = ['https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
                   'https://play.tv3.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
                   'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/']

    for url in tested_urls:
        assert(TVPlayHomeIE.suitable(url))

# Generated at 2022-06-12 18:45:44.023385
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()

    tests = tvplay_ie._TESTS

    # checking for connection to MTG servers before running the tests as tests fail if no network connection exists

# Generated at 2022-06-12 18:45:46.159480
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE()
    tvplayie._VALID_URL

# Generated at 2022-06-12 18:45:52.966484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tphie = TVPlayHomeIE(TVPlayHomeIE._create_ie(url, TVPlayHomeIE.ie_key()))
    return tphie._real_extract(url)

# Generated at 2022-06-12 18:45:57.158188
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-12 18:46:01.432842
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'


# Generated at 2022-06-12 18:46:07.237655
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://viafree.no')
    assert ie.suitable('http://viafree.no')
    assert ie.suitable('http://www.viafree.no')
    assert ie.suitable('https://viafree.se')
    assert ie.suitable('https://viafree.dk')
    assert not ie.suitable('http://tvplay.skaties.lv')