

# Generated at 2022-06-12 18:38:47.752234
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'MTG'
    assert ie.IE_DESC == 'MTG services'


# Generated at 2022-06-12 18:38:53.083701
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.IE_DESC == 'TV3Play, LMT Straume, TV6 Play and Viafree'
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'
    assert TVPlayHomeIE.suitable('https://tv3play.tv3.lt/aferistai-10047125')



# Generated at 2022-06-12 18:38:55.615521
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Create the test object
    TVPlayIE()


# Generated at 2022-06-12 18:38:57.276475
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    if __name__ == "__main__":
        test_TVPlayIE()

# Generated at 2022-06-12 18:39:03.143207
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    valid_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    invalid_url = 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable(valid_url)
    assert not viafree_ie.suitable(invalid_url)


# Generated at 2022-06-12 18:39:11.060017
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return super(TestTVPlayHomeIE, self)._real_extract(url)

    info = TestTVPlayHomeIE().extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert info['id'] == '366367'
    assert info['ext'] == 'mp4'
    assert info['title'] == 'Aferistai'
    assert info['description'] == 'Aferistai. Kalėdinė pasaka.'
    assert info['series'] == 'Aferistai [N-7]'
    assert info['season'] == '1 sezonas'
    assert info['season_number'] == 1

# Generated at 2022-06-12 18:39:20.588410
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test that an informational exception is raised
    # when calling the constructor of an invalid instance
    with pytest.raises(ExtractorError) as e:
        TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert 'This URL belongs to Viafree' == str(e.value)

    # Test that an informational exception is raised
    # when calling the constructor of an invalid instance
    with pytest.raises(ExtractorError) as e:
        ViafreeIE('http://tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert 'This URL belongs to TVPlay' == str(e.value)

# Generated at 2022-06-12 18:39:23.199381
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(TVPlayIE(), ViafreeIE)
    assert isinstance(TVPlayIE(), ViaplayIE)
    assert not isinstance(TVPlayIE(), TVPlayEmbedIE)
    assert not isinstance(TVPlayIE(), ViafreeIE)



# Generated at 2022-06-12 18:39:28.847349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    ie = ViafreeIE(url)
    assert len(ie._TESTS) == 1
    assert ie._TESTS[0]['url'] == url
    assert ie._VALID_URL == 'https?://(?:www\.)?viafree\.(?:dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._GEO_BYPASS == False

# Generated at 2022-06-12 18:39:41.820612
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Construct an instance of a subclass of InfoExtractor.

    This only tests the basic functionality of the constructor,
    and that it raises an error if no suitable IE could be found.

    Further tests should test the ie on an actual video,
    as it might have some dependencies that need to be tested,
    such as the presence of certain libraries (e.g. rtmpdump).
    """
    videos = []
    # Add a video of a different type (different extractor is needed)
    videos.append('http://www.youtube.com/watch?v=BaW_jenozKc')
    # Add a video that should work
    videos.append('http://www.tv3play.se/program/husraddarna/395385')
    for video in videos:
        # Test constructor without parameters
        ie = InfoExtractor()
        #

# Generated at 2022-06-12 18:40:04.400432
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Just for checking if we're still in sync with the source website.
    # It doesn't actually download anything.
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie = TVPlayHomeIE()
    assert ie.suitable(url), 'wrong TVPlayHomeIE URL was matched'



# Generated at 2022-06-12 18:40:07.538811
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # We also test if exception is raised for incorrect URL
    assert(ViafreeIE() != None)
    with pytest.raises(ExtractorError):
        ViafreeIE().suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')

# Generated at 2022-06-12 18:40:11.989924
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(TVPlayHomeIE._VALID_URL == ie._VALID_URL)
    assert(TVPlayHomeIE._TESTS == ie._TESTS)
    assert(TVPlayHomeIE._GEO_BYPASS == ie._GEO_BYPASS)
    assert(TVPlayHomeIE._GEO_COUNTRIES == ie._GEO_COUNTRIES)
    assert("e966d32b-3a3b-4c1b-8b2f-2e45bab30179" == ie._API_KEY)


# Generated at 2022-06-12 18:40:23.550064
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    T = TVPlayIE()
    if T._TESTS:
        T._TESTS.remove(T._TESTS[-1])
    t = T._TESTS[-1]
    assert t['url'] == 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert t['info_dict']['id'] == '418113'
    assert t['info_dict']['title'] == 'Kādi ir īri? - Viņas melo labāk'
    assert t['info_dict']['description'] == 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.'

# Generated at 2022-06-12 18:40:24.827599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-12 18:40:26.859003
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie1 = ViafreeIE()
    assert ie is ie1  # One instance



# Generated at 2022-06-12 18:40:28.258044
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._real_initialize()


# Generated at 2022-06-12 18:40:36.439015
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-12 18:40:47.109528
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafree_ie_test_obj = ViafreeIE()

    url_m = re.search(viafree_ie_test_obj._VALID_URL, test_url)
    country = url_m.group('country')
    path = url_m.group('id')

    content = viafree_ie_test_obj._download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s' % (country, path), path)
    program = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']
    guid = program['guid']


# Generated at 2022-06-12 18:40:52.020673
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    play_home = TVPlayHomeIE()
    # The site use video_id as asset_id,
    # so we can't get video_id from asset_id.
    video_id = '10044354'
    # 1. test url without tv
    input_url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-%s' % video_id
    output_url = 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-%s/' % video_id
    assert play_home._extract_url_info(input_url) == (video_id, output_url)
    # 2. test url with tv

# Generated at 2022-06-12 18:41:29.197444
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    init_TVPlayIE = TVPlayIE.__init__()
    assert init_TVPlayIE is not None


# Generated at 2022-06-12 18:41:32.272687
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = TVPlayHomeIE.suitable(
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert url

# Generated at 2022-06-12 18:41:34.442303
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # If we can create a TVPlayHomeIE(), no exception has been thrown.
    # If it throws an exception, we don't get here.
    ie = TVPlayHomeIE("")

# Generated at 2022-06-12 18:41:45.210781
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import unittest
    import urllib2
    from tvplayhome import TVPlayHomeIE


# Generated at 2022-06-12 18:41:56.368843
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .extractors import _real_extract, ViafreeIE
    from .extractor import _VALID_URL
    from .common import InfoExtractor
    from .extractor import GenericIE
    from .extractor import YoutubeIE
    from .utils import merge_dicts
    from .compat import compat_urlparse
    from .compat import compat_urllib_parse_urlencode
    from .compat import compat_urllib_parse_urlparse
    from .tests.test_extractor import is_m3u8_request

    init = InfoExtractor.__init__
    init_viafree = ViafreeIE.__init__
    test_url = 'https://www.tv3play.no/programmer/underholdning/paradise-hotel/saeson-11/episode-2'
    test_

# Generated at 2022-06-12 18:42:07.078886
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # This checks that a given class is the real class of an URL
    # (ie. checking that the class is the correct one but we don't check
    # that the URL can be downloaded)
    # The correct class is the one where the _VALID_URL contains the URL
    viafree_list = [
        ('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2', ViafreeIE),
        ('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', ViafreeIE),
        ('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', ViafreeIE),
    ]
   

# Generated at 2022-06-12 18:42:08.356666
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE(ViafreeIE.suitable(None)), ViafreeIE)



# Generated at 2022-06-12 18:42:11.382100
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test the constructor of class ViafreeIE
    """
    ViafreeIE(FakeYDL())

# Generated at 2022-06-12 18:42:18.472210
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_ = globals()['ViafreeIE']
    instance = class_('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert instance.DESTINATION_COUNTRIES == ['DK', 'NO', 'SE']


# Generated at 2022-06-12 18:42:30.804266
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import list_objs

# Generated at 2022-06-12 18:43:18.992072
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    input = {
        'tags': 'lt',
        'url': 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
    }
    expected = {
        'ext': 'mp4',
        'format_id': 'hls',
        'duration': 464,
        'width': 1280,
        'height': 720,
    }

    ie = TVPlayHomeIE()
    extracted = ie._real_extract(input['url'])
    actual = [x for x in extracted['formats'] if x['format_id'] == 'hls'][0]

    assert actual['ext'] == expected['ext']
    assert actual['duration'] == expected['duration']
    assert actual['width'] == expected['width']

# Generated at 2022-06-12 18:43:23.608870
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-12 18:43:27.409507
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert(ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'))
    assert(not ViafreeIE.suitable('http://play.tv3play.no/program/husraddarna/395385?autostart=true'))

# Generated at 2022-06-12 18:43:36.601837
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE._build_extractor('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert isinstance(ie, TVPlayHomeIE)
    ie = TVPlayHomeIE._build_extractor('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert isinstance(ie, TVPlayHomeIE)
    ie = TVPlayHomeIE._build_extractor('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-12 18:43:37.323602
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-12 18:43:46.914058
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    with open('test_TVPlayIE.txt') as f:
        txt = f.read()
    ie._VALID_URL = r'http://play\.tv3\.dk/programmer/([^/]+)'
    id = '436149'
    url = 'http://play.tv3.dk/programmer/jonas-og-monique-i-paradis/436149?autostart=true'
    matches = re.findall(ie._VALID_URL, url)
    assert len(matches) == 1
    assert matches[0] == id
    t_url = ie._TESTS[11]['url']
    assert t_url == url
    assert ie._match_id(t_url) == id

# Generated at 2022-06-12 18:43:49.303745
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test constructor with password
    downloader = mtg_extractor.ViafreeIE(downloader=FakeYDL())
    assert downloader.password == 'MTGPLAYER'



# Generated at 2022-06-12 18:43:52.897129
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://play.tv3.ee/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.SUFFIX == '.tv3.ee'

# Generated at 2022-06-12 18:43:55.224843
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert (ie.ie_key() == 'TVPlayHome')
    assert (ie.extractor_key == 'TVPlayHome')


# Generated at 2022-06-12 18:43:56.408598
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('test_TVPlayHomeIE')


# Generated at 2022-06-12 18:45:29.321330
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test the parameter of constructor of class TVPlayIE"""
    from ..utils import fake_browser
    from ..compat import unittest
    from .common import FakeIE


# Generated at 2022-06-12 18:45:40.098727
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._build_url('366367', 'https://tv3play.tv3.ee') == 'https://tv3play.tv3.ee/366367'
    assert ie._build_url('366367', 'https://tv3play.tv3.lt') == 'https://tv3play.tv3.lt/366367'
    assert ie._build_url('366367', 'https://tvplay.tv3.ee') == 'https://play.tv3.ee/366367'
    assert ie._build_url('366367', 'https://tvplay.tv3.lt') == 'https://play.tv3.lt/366367'
    assert ie._build_url('366367', 'https://play.tv3.ee') == 'https://play.tv3.ee/366367'


# Generated at 2022-06-12 18:45:42.478109
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._real_extract("http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true")

# Generated at 2022-06-12 18:45:43.047699
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:45:44.332244
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    VF = ViafreeIE(None)
    assert VF.country == 'se'


# Generated at 2022-06-12 18:45:45.261122
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-12 18:45:52.082300
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TestCase):
        def test_TVPlayHomeIE(self):
            TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    run_test(TestTVPlayHomeIE('test_TVPlayHomeIE'))



# Generated at 2022-06-12 18:45:57.452047
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        from unit.test_downloader import FakeYDL
    except ImportError:
        from .unit.test_downloader import FakeYDL
    from .unit.unit_utils import expected_warnings

    with expected_warnings(['https://viafree-content.mtg-api.com/debug/config']):
        with FakeYDL() as ydl:
            ydl.add_default_info_extractors()
            ydl.params['geo_bypass'] = True
            ydl.params['geo_bypass_country'] = 'DK'
            result = ydl.extract_info(
                'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
                download=False)

# Generated at 2022-06-12 18:46:00.629438
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # You need to have a proper configuration file at ~/.pytube.yaml
    # to be able to run this test
    from .test_pytube import test
    test(TVPlayIE)

# Generated at 2022-06-12 18:46:10.389245
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'