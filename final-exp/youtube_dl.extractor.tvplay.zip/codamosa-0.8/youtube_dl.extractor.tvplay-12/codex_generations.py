

# Generated at 2022-06-12 18:38:46.892891
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert len(IE._TESTS) == 23


# Generated at 2022-06-12 18:38:51.031567
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    # test instantiation of the class
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-12 18:38:57.731167
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317")
    assert t._VALID_URL == "https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)"
    assert t._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert t._TESTS[0]['info_dict']['id'] == '366367'
    assert t._TESTS[0]['info_dict']['title'] == 'Aferistai'
    assert t._TES

# Generated at 2022-06-12 18:39:12.875867
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-12 18:39:14.541735
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE(None, [], {})
    assert False


# Generated at 2022-06-12 18:39:17.308595
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.IE_DESC == 'TVPlayHome.tv3.lt and other TVPlayHome sites'

# Generated at 2022-06-12 18:39:21.589133
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '10044354'
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-' + video_id
    ie = TVPlayHomeIE(url)
    assert ie._match_id(url) == video_id

# Generated at 2022-06-12 18:39:28.727119
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_play = TVPlayIE()._build_url(
        'http://playapi.mtgx.tv/v3/videos?channel=tv3&per_page=10&include=images&fields=title,description,format_title,season,episode,duration,created_at,views,streams,sami_path,is_geo_blocked,age_limit&sort=-created_at&page=1',
        {'channel': 'tv3', 'per_page': '10', 'include': 'images', 'fields': 'title,description,format_title,season,episode,duration,created_at,views,streams,sami_path,is_geo_blocked,age_limit', 'sort': '-created_at', 'page': '1'})

# Generated at 2022-06-12 18:39:31.336306
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .youtu import YoutubeIE
    assert issubclass(ViafreeIE, YoutubeIE)



# Generated at 2022-06-12 18:39:36.489249
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_IE = ViafreeIE()
    assert viafree_IE.suitable(url)


# Generated at 2022-06-12 18:39:56.723556
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    assert info_extractor.IE_NAME == "mtg"
    assert info_extractor.IE_DESC == "MTG services"
    # assert len(info_extractor._TESTS) == 32


# Generated at 2022-06-12 18:40:06.228874
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    tvplay_home_ie = create_IE()
    # All TVPlayHomeIE valid URLs should be supported by constructor
    for url in TVPlayHomeIE._TESTS:
        assert tvplay_home_ie.suitable(url["url"])
        # For each url create InfoExtractor and verify that url is supported
        tvplay_home_ie = create_IE(url['url'])
        assert tvplay_home_ie.suitable(url["url"])

# TVPlayHomeIE should be first, because it can match any possible video that
# TVPlayIE can, and we want TVPlayIE to extract all TVPlayHomeIE videos with
# 'mtg:' prefix instead of TVPlayHomeIE

# Generated at 2022-06-12 18:40:13.821543
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:40:15.910156
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('tv3 play', 'url', 'video_id')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-12 18:40:19.498014
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE(None, None)
    except TypeError:
        pass
    else:
        assert False, "TVPlayHomeIE() class constructor do not raise a TypeError"



# Generated at 2022-06-12 18:40:24.606131
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE(None)
    if instance._TESTS[0] != None:
        pass # Run unit test stub test_TVPlayHomeIE
    else:
        raise AssertionError("Failed to run unit test test_TVPlayHomeIE")

# Generated at 2022-06-12 18:40:34.337360
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_ = ViafreeIE
    # Segmented video
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert class_.suitable(url), 'URL %s not suitable' % url
    # Non segmented video
    url = 'http://www.viafree.se/program/underhallning/svt-play-nyheterna/sasong-1/avsnitt-2/143965'
    assert class_.suitable(url), 'URL %s not suitable' % url
    # Non segmented video

# Generated at 2022-06-12 18:40:36.598593
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL



# Generated at 2022-06-12 18:40:40.742074
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    res = ViafreeIE()._real_extract('https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert res['id'] == '676869'


# Generated at 2022-06-12 18:40:51.326792
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:41:35.680276
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:41:37.377290
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.__name__ == 'TVPlayHome'

# Generated at 2022-06-12 18:41:42.403596
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://play.tv3.lt/aferistai-10047125'
    match = TVPlayHomeIE._VALID_URL.match(test_url)
    assert match is not None, 'URL can be matched'
    assert match.group('id') == '10047125', 'id is correct'



# Generated at 2022-06-12 18:41:51.602960
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE(None)._VALID_URL == TVPlayIE._VALID_URL
    assert ViafreeIE(None)._VALID_URL == ViafreeIE._VALID_URL
    assert isinstance(TVPlayIE(None)._GEO_BYPASS, str)
    assert TVPlayIE(None)._GEO_BYPASS == ViafreeIE._GEO_BYPASS
    assert TVPlayIE(None)._GEO_COUNTRIES == ViafreeIE._GEO_COUNTRIES
    assert TVPlayIE(None).suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-12 18:41:57.557164
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ''' Unit test for constructor of class ViafreeIE '''
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-12 18:42:07.797432
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._GEO_BYPASS == True
    ie = ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._GEO_BYPASS == True
    ie = ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._GEO_BYPASS == True
    ie = ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._GEO_BYPASS == True

# Generated at 2022-06-12 18:42:19.572887
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test constructor of VideoClip object."""

    params = {
        'url': 'http://www.tv3play.se/program/husraddarna/395385?autostart=true',
        'md5': None,
        'info_dict': {
            'id': '395385',
            'ext': 'mp4',
            'title': 'Husräddarna S02E07',
            'description': 'md5:f210c6c89f42d4fc39faa551be813777',
            'duration': 2574,
            'timestamp': 1400596321,
            'upload_date': '20140520',
        },
        'params': {
            'skip_download': True
        }
    }

    expected_result = TVPlayIE()
    test_result = TVPlay

# Generated at 2022-06-12 18:42:20.519173
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(DummyIE)



# Generated at 2022-06-12 18:42:26.887826
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    tvplay_home_ie = TVPlayHomeIE()
    assert tvplay_home_ie.suitable(url) == True
    tvplay_home_ie = TVPlayHomeIE(url)
    assert tvplay_home_ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:42:31.428526
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert isinstance(obj, TVPlayIE)
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'
    assert obj._VALID_URL is not None
    assert obj._TESTS is not None


# Generated at 2022-06-12 18:43:55.501298
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    ie = ViafreeIE()
    assert ie.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5") == True
    assert ie.suitable("http://play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true") == False


# Generated at 2022-06-12 18:44:01.993663
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()

    # init
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

    # extract
    assert obj._extract_url(obj._VALID_URL, obj.ie_key()) == obj._VALID_URL
    assert obj._extract_url('http://www.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true', obj.ie_key()) == 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'


# Generated at 2022-06-12 18:44:08.015066
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert 'MTG services' == ie.IE_DESC
    assert 'mtg' == ie.IE_NAME
    # Match test
    assert ie._VALID_URL == ie._match_id(ie._VALID_URL)
    # Match test
    assert 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true' == ie._match_id(ie._TESTS[0]['url'])


# Generated at 2022-06-12 18:44:14.831962
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    # no URLs or video IDs should raise
    with pytest.raises(TypeError):
        ie.extract(None)
    # an URL or a video ID is needed
    with pytest.raises(ExtractorError):
        ie.extract('')
    # no video URL should raise
    with pytest.raises(ExtractorError):
        ie.extract('http://www.viafree.se/program')
    # invalid video URL should raise
    with pytest.raises(ExtractorError):
        ie.extract('http://www.viafree.se/')


# Generated at 2022-06-12 18:44:24.971689
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test for:
    # 1. inheritance from InfoExtractor
    # 2. the test input
    assert issubclass(TVPlayHomeIE, InfoExtractor)
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert TVPlayHomeIE._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

# Generated at 2022-06-12 18:44:34.827942
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()

# Generated at 2022-06-12 18:44:38.019528
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('www.viafree.dk')
    ViafreeIE('www.viafree.se')
    ViafreeIE('www.viafree.no')



# Generated at 2022-06-12 18:44:41.767528
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import _extractors
    ie = _extractors.get_info_extractor(TVPlayIE.IE_NAME)()
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC


# Generated at 2022-06-12 18:44:44.028449
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info = None
    try:
        info = ViafreeIE()._extract_info()
    except:
        pass
    assert info is not None

# Generated at 2022-06-12 18:44:53.340832
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    viafreeIE = ViafreeIE()
    assert viafreeIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''