

# Generated at 2022-06-12 18:38:52.344516
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        from pycurl import (
            HTTPHEADER
        )
    except ImportError:
        pass
    else:
        #Test getting country code from url
        url = 'https://play.tv6play.se/program/den-sista-dokusapan/266636?autostart=true'
        tvplay = TVPlayIE()
        tvplay._match_id(url)
        tvplay._real_extract(url)
        tvplay._initialize_geo_bypass({'countries': None})
        tvplay._initialize_geo_bypass({'countries': 'SE'})


# Generated at 2022-06-12 18:39:03.983722
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE(None)

    test_vars = {
        'md5': 'a1612fe0849455423ad8718fe049be21',
        'duration': 25,
        'timestamp': 1406097056,
        'title': 'Kādi ir īri? - Viņas melo labāk',
        'description': 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.',
        'series': 'Viņas melo labāk',
        'season': '2.sezona',
        'season_number': 2,
    }


# Generated at 2022-06-12 18:39:07.914414
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('https://viafree.se/program/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'se'
    assert ie.path == 'program/reality/paradise-hotel/saeson-7/episode-5'


# Generated at 2022-06-12 18:39:17.211726
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    clazz = TVPlayHomeIE

# Generated at 2022-06-12 18:39:19.474153
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._real_initialize()
    assert ie.IE_NAME == 'mtg' and ie.IE_DESC == 'MTG services'


# Generated at 2022-06-12 18:39:26.896297
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    response = requests.get('https://viafree-content.mtg-api.com/viafree-content/v1/se/path/programmer/husraddarna/sasong-2/avsnitt-1')
    content = response.json()
    program = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']
    guid = program['guid']
    meta = content['meta']
    title = meta['title']


# Generated at 2022-06-12 18:39:28.419605
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-12 18:39:41.775233
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    infoExtractor = ViafreeIE("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5", "dk", "se")
    assert infoExtractor.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert infoExtractor.suitable("https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    assert not infoExtractor.suitable("https://tv6play.se/program/husraddarna/395385")
    assert not infoExtractor.suitable("https://tv6play.se/program/kodu-keset-linna/238551")




# Generated at 2022-06-12 18:39:43.977637
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    for test in ie._TESTS:
        ie._real_extract(test['url'])


# Generated at 2022-06-12 18:39:57.498468
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	obj = TVPlayIE()
	obj._initialize_geo_bypass({'countries': ['LV']})
	obj._download_json('http://playapi.mtgx.tv/v3/videos/418113', '418113', 'Downloading video JSON')
	obj._download_json('http://playapi.mtgx.tv/v3/videos/stream/418113', '418113', 'Downloading streams JSON')
	obj._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
	obj._real_extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-12 18:40:35.604665
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test unit of TVPlayHomeIE class.
    """
    # constructor
    TVPlayHomeIE()
    test = True
    assert test

# Generated at 2022-06-12 18:40:38.702155
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.GEO_BYPASS == False
    assert ie.BR_DESC == 'Generic'

# Generated at 2022-06-12 18:40:39.592060
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-12 18:40:49.871089
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:40:52.376368
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check that the ViafreeIE constructor is not affected by the removal of
    # IE_NAME from the class definition.
    ie = ViafreeIE()
    assert ie.ie_key() == 'Viafree'

# Generated at 2022-06-12 18:40:55.980458
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113'
    expected_id = '418113'
    tvplay = TVPlayIE()
    actual_id = tvplay._match_id(test_url)
    assert expected_id == actual_id



# Generated at 2022-06-12 18:41:04.683945
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-12 18:41:11.650747
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')



# Generated at 2022-06-12 18:41:13.588510
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Check correct initialization of TVPlayHomeIE instance
    TVPlayHomeIE()

# Generated at 2022-06-12 18:41:23.089230
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE.TVPlayHomeIE(TVPlayHomeIE, url)
    assert(ie.url == url)
    assert(ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')
    assert(ie._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert(ie._TESTS[0]['info_dict']['id'] == '366367')


# Generated at 2022-06-12 18:42:46.154245
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Basic test for TVPlayHomeIE
    """
    def assert_constructor(url, expected_class, expected_args, expected_kwargs):
        ie = TVPlayHomeIE(expected_class, expected_args, expected_kwargs)
        assert ie.suitable(url)
        assert ie._real_initialize(url) is True

    assert_constructor(
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        TVPlayHomeIE, (), {'country': 'skaties.lv'}
    )

# Generated at 2022-06-12 18:42:54.360935
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test case for TVPlayIE, without any error
    report_regex = re.compile(r'^(?P<type>.+) error: (?P<msg>.+)$')
    def report(self, type, key, msg):
        m = report_regex.match(msg)
        if m:
            self.assertEqual(m.group('type'), type)
            self.assertEqual(m.group('msg'), key)

    ie = TVPlayIE()
    ie.report_error = lambda type, key: report(ie, type, key, next(iter(repr(e) for e in ie.extractor_errors), None))
    ie.extractor_errors = []
    ie._download_json('https://tvplay.skaties.lv/', '5686323')
    ie._download_

# Generated at 2022-06-12 18:43:04.746742
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def first_or_none(list):
        if list and list[0]:
            return list[0]
        return None
    def get_video_id(url):
        m = re.match(TVPlayIE._VALID_URL, url)
        if m:
            return m.group('id')
        return None
    def get_video_url(url):
        return 'http://localhost/%s' % get_video_id(url)
    def try_get(data, func, default=None):
        if data:
            try:
                return func(data)
            except (KeyError, ValueError, IndexError):
                pass
        return default

    def get_duration(time):
        return parse_duration(time)


# Generated at 2022-06-12 18:43:16.349832
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i = ViafreeIE()
    i.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    i.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')
    i.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')
    i.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-12 18:43:26.663044
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    video = ViafreeIE()._real_extract('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert video['id'] == '778992'
    assert video['title'] == 'Husräddarna S02E02'
    assert video['description'] == 'md5:2cacd5dd5a5a5a6a5d99c5e6a9c6e5a6'
    assert video['duration'] == 2124
    assert video['timestamp'] == 1437000580
    assert video['upload_date'] == '20150714'
    assert video['series'] == 'Husräddarna'
    assert video['season_number'] == 2
    assert video['episode_number'] == 2


# Generated at 2022-06-12 18:43:35.125326
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ie.country == 'se'
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'dk'
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'no'

# Generated at 2022-06-12 18:43:42.463805
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    a = TVPlayHomeIE()
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    m = re.match(a._VALID_URL, url)
    assert m.group(1) == '10047125'

    a = TVPlayHomeIE()
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    m = re.match(a._VALID_URL, url)
    assert m.group(1) == '10280317'

    a = TVPlayHomeIE()

# Generated at 2022-06-12 18:43:43.677872
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # pylint: disable=no-value-for-parameter
    ViafreeIE()



# Generated at 2022-06-12 18:43:45.320486
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay


# Generated at 2022-06-12 18:43:52.218163
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    # Geo restricted
    info = ie._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    ie._initialize_geo_bypass({'countries': ['EE']})
    # Geo restricted
    info = ie._real_extract('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')

# Generated at 2022-06-12 18:45:27.685836
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ TVPlayHomeIE constructor should set correct i18n language code. """
    import re

    # Extractor init
    tvplayhomeie = TVPlayHomeIE()

    # Validate language code
    valid_language_pattern = re.compile('^[a-z]{2}$')
    match = valid_language_pattern.match(tvplayhomeie._LANGUAGE)
    print("Language code is: '%s'" % tvplayhomeie._LANGUAGE)
    assert match is not None, "TVPlayHomeIE._LANGUAGE not valid"



# Generated at 2022-06-12 18:45:38.380298
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-12 18:45:40.448491
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")



# Generated at 2022-06-12 18:45:41.292322
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert 'Viafree' in repr(ViafreeIE())

# Generated at 2022-06-12 18:45:43.857432
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    tvplay_ie.extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')


# Generated at 2022-06-12 18:45:45.946003
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()
# End of test for constructor of class TVPlayIE



# Generated at 2022-06-12 18:45:49.931901
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Unit test for constructor of class TVPlayHomeIE.
    """
    tvplay = TVPlayHomeIE()
    assert tvplay.IE_NAME == 'TVPlayIE'

# Generated at 2022-06-12 18:45:55.266671
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE('3')
    assert str(IE) == '3'
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-12 18:45:56.907956
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    construct_result = TVPlayIE()
    assert construct_result is not None

# Generated at 2022-06-12 18:46:01.592342
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE('')
    assert viafreeIE.country == None
    assert viafreeIE.path == None
    assert viafreeIE.program == None
    assert viafreeIE.guid == None
    assert viafreeIE.meta == None
    assert viafreeIE.title == None
    assert viafreeIE.stream_href == None
    assert viafreeIE.formats == None
    assert viafreeIE.episode == None