

# Generated at 2022-06-22 08:39:35.890583
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie is not None


# Generated at 2022-06-22 08:39:47.610853
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE

    """Unit test for constructor of class ViafreeIE"""

    assert ViafreeIE.__name__ == 'ViafreeIE'

    assert ViafreeIE.IE_NAME == 'viafree'

    assert ViafreeIE.IE_DESC == 'Viafree'

    assert ViafreeIE.VALID_URL == r'https?://(?:www\.)?viafree\.(?:dk|no|se)/(?:program(?:mer)?/(?:[^/]+/)*[^/?#&]+)'


# Generated at 2022-06-22 08:39:55.556072
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test Case 1
    test_case_1 = 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'

    # Test Case 2
    test_case_2 = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'

    # Test Case 3
    test_case_3 = 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

    # Test Case 4

# Generated at 2022-06-22 08:40:04.544802
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:16.200809
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:40:27.107346
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'

# Generated at 2022-06-22 08:40:29.524624
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE(None)
        raise AssertionError('Should raise ValueError')
    except ValueError:
        pass


# Generated at 2022-06-22 08:40:35.513296
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    for test in tvplay_ie._TESTS:
        _, _, expected_id = test.values()
        extracted_id = tvplay_ie._match_id(test['url'])
        if extracted_id != expected_id:
            raise AssertionError('%s should have given %s, not %s' % (test['url'], expected_id, extracted_id))


# Generated at 2022-06-22 08:40:39.904017
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Constructor test case for ViasatIE"""
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.ie_key() == 'mtg'
    assert tvplay_ie.ie_name() == 'mtg'
    assert tvplay_ie.ie_desc() == 'MTG services'
    assert tvplay_ie.ie_url_name() == 'mtg'
    assert tvplay_ie.ie_version() == '0.1'


# Generated at 2022-06-22 08:40:41.574970
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    m = TVPlayHomeIE()
    assert m.get_test_cases()


# Generated at 2022-06-22 08:41:00.117186
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isclass(ViafreeIE) and issubclass(ViafreeIE, InfoExtractor)

# Generated at 2022-06-22 08:41:10.603745
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import json

    """
    Returns:
        A function which returns a mock object with required fields.
    """
    def _factory(obj, fields):
        """
        Args:
            obj: Dictionary which contains fields that are required for the object.
            fields: Fields that are required for the object.

        Returns:
            Object with requested fields from obj.
        """
        def _func(*args, **kwargs):
            """
            Args:
                args/kwargs: Not used, but necessary for object creation

            Returns:
                Object with requested fields from obj.
            """
            _obj = {}
            for field in fields:
                try:
                    _obj[field] = obj[field]
                except KeyError:
                    pass
            return _obj

        return _func

    # Test 1: Test with all fields
   

# Generated at 2022-06-22 08:41:20.709304
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE('github-username')
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:21.384251
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-22 08:41:23.670095
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://example.com')
    if ie is not None:
        print("test_ViafreeIE done")



# Generated at 2022-06-22 08:41:30.981030
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie.suitable('https://www.tv3play.se/program/husraddarna/395385?autostart=true') == False


# Generated at 2022-06-22 08:41:43.757038
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # HLS video, duration is not required
    assert_true(
        re.match(r'https?://(?:www\.)?tvplayhome\.tv3\.ee/(?:[^/]+/)*[^/?#&]+-\d+', TVPlayHomeIE._VALID_URL) is not None)
    # RTMP video, duration is required
    assert_true(
        re.match(r'https?://(?:www\.)?tvplayhome\.tv3\.ee/(?:[^/]+/)*[^/?#&]+-\d+\?[^#]*duration=\d+', TVPlayHomeIE._VALID_URL) is not None)
    # RTMPE video, duration is required

# Generated at 2022-06-22 08:41:45.888239
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('mtg:418113', 'Video 418113')

# Generated at 2022-06-22 08:41:57.218233
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    base_url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229'

# Generated at 2022-06-22 08:42:02.472901
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE.using_module('tvplayhome')
    ie2 = TVPlayHomeIE.using_module('viafree')
    ie3 = TVPlayHomeIE.using_module('TVPlayHomeIE.using_module')
    assert ie.SUFFIX == 'tvplayhome'
    assert ie2.SUFFIX == 'viafree'
    assert ie3.SUFFIX == 'TVPlayHomeIE.using_module'

# Generated at 2022-06-22 08:42:24.460728
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .testcases import TVPlayIE_TEST

    class TVPlayHomeUnitTest(TVPlayHomeIE, TVPlayIE_TEST):
        pass

    TVPlayHomeUnitTest(TVPlayHomeIE.__name__, {'fatal': False}).run()


# Generated at 2022-06-22 08:42:32.918489
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print('testing TVPlayIE')
    play = TVPlayIE()
    # test to see if the constructor works
    assert(play != None)
    # test the georestricted raise

# Generated at 2022-06-22 08:42:34.369521
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-22 08:42:46.107060
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        from urllib.request import build_opener
    except ImportError:
        from urllib2 import build_opener

    opener = build_opener()
    opener.addheaders = [('User-agent', 'Mozilla/5.0')]

    url = 'https://www.viafree.se/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_ie = ViafreeIE()

    # Test _GEO_BYPASS
    assert viafree_ie._GEO_BYPASS == False
    viafree_ie.geo_verification_headers = lambda: {'X-Forwarded-For': '123.123.123.123'}

# Generated at 2022-06-22 08:42:52.377559
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test with empty argument
    try:
        TVPlayIE()
        assert False, 'An empty argument or an invalid one is passed'
    except Exception:
        pass

    # test with name and invalid argument
    try:
        TVPlayIE('invalid-argument')
        assert False, 'An invalid argument is passed'
    except Exception:
        pass

    # test with name and valid argument
    try:
        TVPlayIE('mtg')
    except Exception:
        assert False, 'An valid argument is passed'

# Generated at 2022-06-22 08:43:00.365706
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    test_urls = (
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
    )

    ie_

# Generated at 2022-06-22 08:43:03.784444
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_instance = TVPlayHomeIE()
    expected_instance = TVPlayHomeIE
    assert isinstance(tvplay_home_instance, expected_instance)

# Generated at 2022-06-22 08:43:09.220742
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in ['https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', 'https://tv3play.skaties.lv/vinas-melo-labak-10280317']:
        ie = TVPlayHomeIE(create_getfirst_mock({'url': url}))
        assert ie.suitable(url)
        assert ie._VALID_URL

# Generated at 2022-06-22 08:43:22.372460
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-22 08:43:28.884334
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE= TVPlayIE()

# Generated at 2022-06-22 08:44:16.210399
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:44:24.580831
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == TVPlayIE._VALID_URL
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'
    assert TVPlayHomeIE.__doc__ == TVPlayIE.__doc__
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie.__name__ == 'TVPlayHomeIE'
    assert ie._TEST == TVPlayIE._TEST
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie.IE_NAME == 'tvplay.tv3play.tv3.ee'
    assert ie.GEO_COUNTRIES

# Generated at 2022-06-22 08:44:33.209414
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie.suitable(ie._VALID_URL) is False
    assert ie.suitable('http://play.tv3.se/program/husraddarna/395385') is False
    assert ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is True


# Generated at 2022-06-22 08:44:40.052501
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test for constructor of class ViafreeIE
    """
    assert ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is True
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') is False

# Generated at 2022-06-22 08:44:49.942162
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE()
    assert x._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-22 08:44:52.225756
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-22 08:44:53.233549
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()  # it will not crash

# Generated at 2022-06-22 08:44:54.885935
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-22 08:45:01.911660
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:45:07.910327
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    viafree_ie = ViafreeIE()
    program = viafree_ie._real_extract(url)
    print('Program name: %s' % program['title'])
    print('Program duration: %d' % program['duration'])


# Generated at 2022-06-22 08:46:48.342816
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('https://tvplay.skaties.lv/parraides/tv3-zinas/760183')


# Generated at 2022-06-22 08:46:59.824794
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:47:08.484869
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test on: http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true
    url = "http://www.tv3play.lv/parraides/vinas-melo-labak/418113"
    # Instantiate class
    ie = TVPlayIE(url)
    # Get id from url
    video_id = ie.match_id(url)
    # Get video from video_id
    video = ie._download_json('http://playapi.mtgx.tv/v3/videos/%s' % video_id, video_id, 'Downloading video JSON')
    # Check video title
    assert video['title'] == 'Kādi ir īri? - Viņas melo labāk'
    # Check episode number
   

# Generated at 2022-06-22 08:47:18.876547
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test normal page parse
    ie = TVPlayHomeIE._build_ie(TVPlayHomeIE._VALID_URL)
    tvplay_home_ie = ie._real_extract(TVPlayHomeIE._TESTS[0]['url'])
    info_dict = TVPlayHomeIE._TESTS[0]['info_dict']
    assert tvplay_home_ie['id'] == info_dict['id']
    assert tvplay_home_ie['title'] == info_dict['title']
    assert tvplay_home_ie['description'] == info_dict['description']
    assert tvplay_home_ie['series'] == info_dict['series']
    assert tvplay_home_ie['duration'] == info_dict['duration']
    assert tvplay_home_ie['timestamp'] == info_dict['timestamp']


# Generated at 2022-06-22 08:47:26.761887
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2') == True
    assert ViafreeIE.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') == False
    assert ViafreeIE.suitable('mtg:418113') == False

# Generated at 2022-06-22 08:47:34.951180
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    opener = Mock()
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    info_dict = {
        'id': '366367',
        'ext': 'mp4',
        'title': 'Aferistai',
        'description': 'Aferistai. Kalėdinė pasaka.',
        'series': 'Aferistai [N-7]',
        'season': '1 sezonas',
        'season_number': 1,
        'duration': 464,
        'timestamp': 1394209658,
        'upload_date': '20140307',
        'age_limit': 18,
    }


# Generated at 2022-06-22 08:47:45.776348
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for url in ['http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1',
                'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1']:
        ie = ViafreeIE(url)
        assert isinstance(ie.url, str) and ie.url
        assert isinstance(ie._VALID_URL, str)
        assert isinstance(ie._TESTS, list) and isinstance(ie._TESTS[0], dict)
        assert isinstance(ie.http_headers, dict)
        assert isinstance(ie.country_code, str) and ie.country_code

# Generated at 2022-06-22 08:47:56.425771
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_OoyalaIE import test_OoyalaIE

# Generated at 2022-06-22 08:48:05.640286
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    '''
    unit testing for the above extractor
    currently the only way to run it is to manually create
    the TVPlayIE instance and call '_real_extract' method
    of it, example is below and the output is from the
    return value of the method:

    from .tvplay import TVPlayIE
    url = u'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    tp = TVPlayIE()
    vid = tp._real_extract(url)
    import pprint
    pprint.pprint(vid)
    '''


# Another unit test class

# Generated at 2022-06-22 08:48:07.587801
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("")
    assert ie is not None