

# Generated at 2022-06-22 08:39:46.952568
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	test_url = "https://tv3play.tv3.lt/aferistai-n-7/aferistai-10047125/"
	test_url = "https://play.tv3.lt/aferistai-10047125"
	test_url = "https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/"
	test_url = "https://play.tv3.ee/cool-d-ga-mehhikosse-10044354"
	test_url = "https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/"

# Generated at 2022-06-22 08:39:57.545589
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE(None)
    assert instance._VALID_URL == '''^(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)*)(?P<id>\d+)'''

# Generated at 2022-06-22 08:40:06.578758
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/program/underholdning/det-beste-vorspielet/sesong-1/episode-1')

# Generated at 2022-06-22 08:40:08.390400
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')


# Generated at 2022-06-22 08:40:17.558427
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Subclasses of ViafreeIE have been created to test their specific behaviour
    # These subclasses don't actually exist, so we need to remove them before instantiating ViafreeIE
    if 'ViafreeIE' in globals():
        del globals()['ViafreeIE']

    ViafreeIE('test')
    assert 'ViafreeDK' in globals()
    del globals()['ViafreeDK']
    assert 'ViafreeNO' in globals()
    del globals()['ViafreeNO']
    assert 'ViafreeSE' in globals()
    del globals()['ViafreeSE']
    assert 'ViafreeEU' in globals()
    del globals()['ViafreeEU']


# Generated at 2022-06-22 08:40:27.798489
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-22 08:40:37.536854
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    _ = TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    _ = TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    _ = TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    _ = TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-22 08:40:46.125769
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Creator functions for test cases
    def create_testcase(url, expected_id, expected_title=None):
        return {
            'url': url,
            'info_dict': {
                'id': expected_id,
                'title': expected_title or expected_id,
            }
        }

    # Test cases for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:55.810635
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Fixture data for the test case.
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/'
    # Assert that the IE is the right one.
    tvplay_home_ie = TVPlayHomeIE(TVPlayHomeIE.suitable(url))
    # Check if the URL is correct.
    assert tvplay_home_ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    # Check if the test case is valid.
    assert TVPlayHomeIE._TESTS[2]['url'] == url
    # Check if the test case is valid.


# Generated at 2022-06-22 08:41:06.782261
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._TESTS[0]['url'].find('http://www.tvplay.lv') > 0
    assert TVPlayIE._TESTS[1]['url'].find('play.tv3.lt') > 0
    assert TVPlayIE._TESTS[2]['url'].find('tv3play.ee') > 0
    assert TVPlayIE._TESTS[3]['url'].find('tv3play.se') > 0
    assert TVPlayIE._TESTS[4]['url'].find('tv6play.se') > 0
    assert TVPlayIE._TESTS[5]['url'].find('tv8play.se') > 0
    assert TVPlayIE._TESTS[6]['url'].find('tv3play.no') > 0
    assert TVPlayIE._

# Generated at 2022-06-22 08:41:25.686197
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE

# Generated at 2022-06-22 08:41:33.911519
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def test_factory(url, classname):
        ie = get_info_extractor(url)
        print(ie.IE_NAME, ie.__class__.__name__)
        assert isinstance(ie, globals()[classname])

    test_factory('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
                 'ViafreeIE')
    test_factory('https://play.viaplay.dk/program/husraddarna/395385',
                 'TVPlayIE')

# Generated at 2022-06-22 08:41:46.084099
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg:418113')

# Generated at 2022-06-22 08:41:47.713931
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'mtg:418113'
    TVPlayIE(url)


# Generated at 2022-06-22 08:41:58.877938
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import inspect
    # Values for testing constructor
    url = 'https://www.viafree.dk/programmer/livsstil/husraddarna/saeson-2/episode-2'
    # Testing constructor
    ie_obj = ViafreeIE(url)

    # Testing for expected result of type of ie_obj
    if inspect.isclass(ViafreeIE) and not isinstance(ie_obj, ViafreeIE):
        print('expected type: %s' %type(ie_obj))
        print('got: %s' %type(ViafreeIE))
        raise AssertionError()
    # Testing for expected result of types of attributes of ie_obj
    if not isinstance(ie_obj._VALID_URL, str):
        print('expected type: %s' %type(str))

# Generated at 2022-06-22 08:42:02.929055
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('https://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    ie.extract('http://playapi.mtgx.tv/v3/videos/760183')

# Generated at 2022-06-22 08:42:07.812429
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Setup and run test for constructor of class ViafreeIE."""
    ViafreeIE.suitable("https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    ViafreeIE.suitable("https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2")

# Generated at 2022-06-22 08:42:13.604985
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.video_id == '10044354'

# Generated at 2022-06-22 08:42:18.217707
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(NotebookTestCase())
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:42:24.704477
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert('mtg:%s' % ViafreeIE._match_id(
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') ==
        ViafreeIE('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')._VALID_URL)
    assert(isinstance(
        ViafreeIE('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'),
        ViafreeIE))


# Generated at 2022-06-22 08:43:03.737371
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-22 08:43:10.699923
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t = ViafreeIE(googletag=None)
    assert t.geo_verification_headers is not None
    assert t._GEO_BYPASS is False
    assert t.IE_NAME == 'viafree:%s' % ViafreeIE._VALID_URL

    t = ViafreeIE(googletag=None, geo_bypass=False)
    assert t.geo_verification_headers is None
    assert t._GEO_BYPASS is True
    assert t.IE_NAME == 'viafree'



# Generated at 2022-06-22 08:43:19.184004
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.url == 'https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    assert ie.country == 'ee'
    assert ie.programUrl == 'cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354'
    assert ie.host == 'play.tv3.ee'
    assert ie.video_id == '10044354'

# Generated at 2022-06-22 08:43:26.443955
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable("http://www.tv3play.ee/sisu/kodu-keset-linna/384444?autostart=true") == False
    assert ie.suitable("https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true") == True
    assert ie.suitable("mtg:418113") == True
    assert ie._match_id("https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true") == '764300'

# Generated at 2022-06-22 08:43:27.740017
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('Viafree')

# Generated at 2022-06-22 08:43:38.571363
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE({'_downloader': None, '_download_webpage_handle': None})

# Generated at 2022-06-22 08:43:49.433269
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from ..jsinterp import JSInterpreter

    api_key = 'KUgZLxFV8mwY6Y4AXqtI4M4cq3D9vF1n'
    secret = 'ZmFpNjYwYmI1YTM1MmZjNDJlYzQ2MjBiZmU5ZjM5Y2E2YzdlNmJhNg=='

    js_interp = JSInterpreter(state={'Math': {'random': lambda: 0.24291747359318012}})

# Generated at 2022-06-22 08:43:51.404034
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import TestCase
    from .generic_tvplay import TVPlayIE
    TestCase(TVPlayIE).run()

# Generated at 2022-06-22 08:43:51.910229
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-22 08:43:53.798743
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(None)._real_initialize(TVPlayHomeIE._VALID_URL)


# Generated at 2022-06-22 08:45:29.468580
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('')

# Generated at 2022-06-22 08:45:39.290108
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    TVPlayHomeIE._VALID_URL = 'http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie._real_extract(TVPlayHomeIE._VALID_URL)
    TVPlayHomeIE._VALID_URL = 'http://tv3play.skaties.lv/vinas-melo-labak-10280317'
    ie._real_extract(TVPlayHomeIE._VALID_URL)
    TVPlayHomeIE._VALID_URL = 'http://play.tv3.lt/aferistai-10047125'
    ie._real_extract(TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-22 08:45:43.001070
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE(), InfoExtractor)

# Generated at 2022-06-22 08:45:44.253743
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:45:53.310428
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    homepage_ie = TVPlayHomeIE(url)
    assert homepage_ie.country == 'lt'
    assert homepage_ie.lang == 'lt'

    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    homepage_ie = TVPlayHomeIE(url)
    assert homepage_ie.country == 'lv'
    assert homepage_ie.lang == 'lv'

    url = 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'

# Generated at 2022-06-22 08:45:55.175439
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    res = TVPlayIE()
    assert res is not None

# Generated at 2022-06-22 08:46:00.117326
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    assert ie.GEO_COUNTRIES == ['LV']


# Generated at 2022-06-22 08:46:05.637063
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test cases for constructor."""
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'
    assert TVPlayHomeIE.ie_key() == 'TVPlayHome'
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-22 08:46:14.557531
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    content = {}
    content['_embedded'] = {}
    content['_embedded']['viafreeBlocks'] = []
    content['_embedded']['viafreeBlocks'].append({})
    content['_embedded']['viafreeBlocks'][0]['_embedded'] = {}
    content['_embedded']['viafreeBlocks'][0]['_embedded']['program'] = {}
    content['_embedded']['viafreeBlocks'][0]['_embedded']['program']['_links'] = {}
    content['_embedded']['viafreeBlocks'][0]['_embedded']['program']['_links']['streamLink'] = {}

# Generated at 2022-06-22 08:46:15.504873
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()