

# Generated at 2022-06-22 08:39:39.326021
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    tvph = TVPlayHomeIE(url)
    assert tvph.IE_NAME == 'TVPlayHome'
    assert tvph._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:39:40.532161
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'



# Generated at 2022-06-22 08:39:45.765164
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert re.match(ie._VALID_URL, 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert re.match(ie._VALID_URL, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

    class TestPlaylistIE(object):
        def test_playlist_id(self):
            ie = TVPlayIE()

# Generated at 2022-06-22 08:39:48.159249
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i = ViafreeIE('test')
    assert i.geo_countries == ['SE', 'DK', 'NO']


# Generated at 2022-06-22 08:39:51.654752
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._download_json
    assert ie.country
    assert ie.url_result
    assert ie._API_URL
    assert ie._API_KEY
    assert ie._TOKEN

# Generated at 2022-06-22 08:39:58.544400
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    domain = 'http://www.viafree.no'
    path = '/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

    url = '%s%s' % (domain, path)
    ie = ViafreeIE(url)
    assert ie._extract_country() == 'no'


# Generated at 2022-06-22 08:40:02.121912
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for the constructor of ViafreeIE
    # See https://github.com/ytdl-org/youtube-dl/issues/10860
    ViafreeIE(None)._download_webpage
    ViafreeIE(None)._get_id_from_url


# Generated at 2022-06-22 08:40:03.673100
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = get_ie('viafree')
    assert ie.IE_NAME in globals()
    # TODO: add more tests

# Generated at 2022-06-22 08:40:15.750182
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:17.482656
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('www.tv3play.ee', '1234')


# Generated at 2022-06-22 08:40:53.034289
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()


# Generated at 2022-06-22 08:40:54.991594
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-22 08:41:05.698351
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10199772/')
    # Using oop access
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.country == 'lv'
    assert isinstance(ie, TVPlayHomeIE)
    # Using class method
    assert ie.suitable('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10199772/')

# Generated at 2022-06-22 08:41:08.010490
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    c = TVPlayHomeIE()
    assert c.IE_NAME == 'tvplay'
    assert c.SUFFIX == 'TVPlayHome'

# Generated at 2022-06-22 08:41:19.329343
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl.downloader.http import HttpFD
    video_id = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie = TVPlayHomeIE(HttpFD())
    ie._initialize_geo_bypass({'countries': ['LV']})
    res = ie._real_extract(video_id)
    assert res['id'] == '10280317'
    assert res['title'] == 'Vīnas melo labāk'

# Generated at 2022-06-22 08:41:28.219750
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    # Test m3u8
    m3u8_url = ie._extract_m3u8('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert m3u8_url == 'https://playcdn.vgtf.net/secure/smil:tv3play/cool-d-ga-mehhikosse-10044354.smil/playlist.m3u8?token=04eab1c1679ef23dfa20d24f1bc7e3e8eb' \
                       'f09a1a&expires=2019-06-29 04:30:00'

    # Test m3u8 - test if initializing bypass_regional

# Generated at 2022-06-22 08:41:30.870620
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE("")
    except:
        assert False
    else:
        assert True



# Generated at 2022-06-22 08:41:33.278222
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')



# Generated at 2022-06-22 08:41:36.697049
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE inherits InfoExtractor *without* calling its constructor
    # https://github.com/rg3/youtube-dl/pull/7846
    ie = ViafreeIE(None)
    assert ie.country == None


# Generated at 2022-06-22 08:41:40.986713
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('www.tv3play.lt', 'http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.SUITABLE_DEFAULT

# Generated at 2022-06-22 08:42:56.323364
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:43:01.885129
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229'
    class_ = TVPlayIE()
    assert class_._match_id(test_url) == '409229'

# Generated at 2022-06-22 08:43:10.944778
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test with an episode
    test_url_1 = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551'
    test_episode_1 = TVPlayIE(test_url_1)
    assert test_episode_1.NAME == 'mtg'
    assert test_episode_1.IE_NAME == 'MTG services'
    assert test_episode_1.VALID_URL == TVPlayIE._VALID_URL

    # Test with an episode
    test_url_2 = 'http://www.tv3play.se/program/husraddarna/395385'
    test_episode_2 = TVPlayIE(test_url_2)
    assert test_episode_2.NAME == 'mtg'

# Generated at 2022-06-22 08:43:23.432670
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-22 08:43:28.570123
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://play.tv3play.no/vinas-melo-labak/vinas-melo-labak-10280317/') is False
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') is True
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') is True


# Generated at 2022-06-22 08:43:32.514650
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie._VALID_URL == 'http://www\.tvplay\.lv/parraides/vinas-melo-labak/418113?autostart=true'



# Generated at 2022-06-22 08:43:43.580058
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url1 = "http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true"
    test_url2 = "https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true"
    test_url3 = "http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true"
    test_url4 = "http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869"
    test_url5 = "http://tvplay.skaties.lv/parraides/tv3-zinas/760183"

# Generated at 2022-06-22 08:43:54.928569
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:44:00.307986
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-22 08:44:09.587021
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS
    ie.url_result
    ie.playlist_result
    ie._real_initialize
    ie.extract
    ie.suitable
    ie.check_url
    ie.geo_verification_headers
    ie._TESTS[0]['url']
    ie.geo_ip_lookup
    ie.geo_bypass_ip
    ie.geo_bypass_country
    ie.geo_bypass_restricted

test_TVPlayIE()

# Generated at 2022-06-22 08:45:45.632471
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_name = 'ViafreeIE'
    extractor = globals()[class_name]()
    instance = extractor.ie_key()
    assert instance == class_name

# Generated at 2022-06-22 08:45:57.549325
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Tests for TVPlayIE"""
    from .test_utils import _tm

    assert(TVPlayIE(
        _tm, None, 'http://www.tv3play.se/program/husraddarna/395385?autostart=true') != None)
    assert(TVPlayIE(
        _tm, None, 'https://www.tv3play.se/program/husraddarna/395385?autostart=true') != None)
    assert(TVPlayIE(
        _tm, None, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true') != None)

# Generated at 2022-06-22 08:46:01.533396
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Constructor should raise exception if URL is invalid
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE('http://example.com/')

# Generated at 2022-06-22 08:46:12.040763
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie.IE_NAME == 'mtg')
    assert(ie.IE_DESC == 'MTG services')

# Generated at 2022-06-22 08:46:13.440833
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    '''
    Validate the TVPlayIE constructor
    '''
    assert TVPlayIE(None)



# Generated at 2022-06-22 08:46:24.314647
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for constructor with no argument
    try:
        ie = ViafreeIE()
        print(ie)
    except Exception as e:
        print(e)
    # Test for constructor with empty argument
    try:
        ie = ViafreeIE({})
        print(ie)
    except Exception as e:
        print(e)
    # Test for constructor with wrong argument
    try:
        ie = ViafreeIE({'url': ''})
        print(ie)
    except Exception as e:
        print(e)
    # Test for constructor with valid argument

# Generated at 2022-06-22 08:46:31.567493
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == True
    ie.suitable('http://play.nova.bg/programi/zdravei-bulgariya') == False

# Generated at 2022-06-22 08:46:37.831306
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:46:39.355540
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie


# Generated at 2022-06-22 08:46:43.880808
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('dk', False, None)
    ViafreeIE('dk', None, None)
    ViafreeIE('dk')
    ViafreeIE(country='dk')
    ViafreeIE(country='dk', _type=False)
    ViafreeIE(country='dk', _type=None)

