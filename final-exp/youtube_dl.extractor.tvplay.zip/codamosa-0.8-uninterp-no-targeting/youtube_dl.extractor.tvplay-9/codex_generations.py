

# Generated at 2022-06-22 08:39:43.188238
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def _test_ViafreeIE(url, exp_country):
        country, _ = re.match(ViafreeIE._VALID_URL, url).groups()
        assert country == exp_country
    _test_ViafreeIE('http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1', 'se')
    _test_ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', 'no')
    _test_ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', 'dk')

# Generated at 2022-06-22 08:39:45.232348
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    return tvplay



# Generated at 2022-06-22 08:39:54.394605
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test url 1: url, viafree_country, expected country
    url1 = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_country1 = 'NO'
    expected_country1 = 'NO'
    # Test url 2: url, viafree_country, expected country
    url2 = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafree_country2 = 'DK'
    expected_country2 = 'DK'

    ie = ViafreeIE()
    ie1 = ViafreeIE()
    ie2 = ViafreeIE()

    assert_true(ie1.suitable(url1), 'Did not match url url1')

# Generated at 2022-06-22 08:40:02.968953
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    title = 'Det beste vorspielet - Sesong 2 - Episode 1'
    mp4 = 'https://example.com/video.mp4'
    assert IE._extract_m3u8_formats(mp4, '757786', title) == [{
        'url': mp4,
        'ext': 'mp4',
        'format_id': 'http-3200',
    }]
    assert IE._extract_f4m_formats(mp4, '757786', title) == [{
        'url': mp4,
        'format_id': 'http-3200',
    }]

# Generated at 2022-06-22 08:40:06.725860
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test the correct creation of TVPlayHomeIE
    TVPlayHomeIE()
    # Test that an error will be raised if an improper URL is given
    # This will test the functionality of the "suitable" method
    with pytest.raises(ExtractorError):
        TVPlayHomeIE.suitable("http://play.tv3.lt/vinas-melo-labak/vinas-melo-labak-10280317/")


# Generated at 2022-06-22 08:40:12.349279
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()
    assert x.IE_DESC == 'TVPlayHome: tv3.lv, tv3.lt, tv3.ee, skaties.lv'



# Generated at 2022-06-22 08:40:20.140383
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with warnings.catch_warnings(record=True) as ws:
        warnings.simplefilter('always')
        ok_(isinstance(TVPlayIE(), TVPlayIE))
        ok_(isinstance(ViafreeIE(), ViafreeIE))
    assert len(ws) == 2
    assert ws[0].category == PendingDeprecationWarning
    assert ws[0].message.args[0] == 'The class TVPlayIE was deprecated and will be removed, for more information follow this link https://github.com/rg3/youtube-dl/issues/12284'
    assert ws[1].category == PendingDeprecationWarning

# Generated at 2022-06-22 08:40:23.647165
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assertViafreeIE(ie)


# Generated at 2022-06-22 08:40:29.741406
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    assert not ie.suitable(TVPlayIE('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')._VALID_URL)


# Generated at 2022-06-22 08:40:38.743389
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:22.216225
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:41:29.467306
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_urls = [
        ('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true', {
            'id': '418113',
            'name': 'Viņas melo labāk',
            'description': 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.',
            'duration': 25,
            'view_count': None,
            'age_limit': 0,
        }),
    ]

    for test_url, expected in test_urls:
        test_info = TVPlayIE()._call_geo_restricted(
            '_real_extract', test_url)
        assert test_info['id'] == expected['id']

# Generated at 2022-06-22 08:41:38.038328
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id = '366367'
    asset = 'https://tvplay.tv3.lt/sb/public/asset/' + video_id
    video_url = 'https://play-f.tv3play.lt/sb/public/video/' + video_id
    m3u8_url = 'https://play-f.tv3play.lt/sb/public/video/' + video_id + '/hls/index.m3u8'
    streams = {
        'streams': {
            'hls': m3u8_url,
        }
    }

# Generated at 2022-06-22 08:41:43.951414
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from compat import unittest
    from ytdl.YoutubeDL import YoutubeDL
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    id = '418113'

    assert TVPlayIE._match_id(url) == id


# Generated at 2022-06-22 08:41:55.477085
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test constructor method
    # mtg: video_id as url
    # https?:// www.tvplay.(skaties.)?lv/parraides/title/video_id?autostart=true
    # There are more cases to test
    # Argument parser checks that it returns 'http://skaties.tvplay.lv/parraides/title/video_id?autostart=true'
    # as 'url' and 'tvplay.lv' as 'ie'
    url = "mtg:418113"
    p = TVPlayIE(url)
    assert p.url == 'http://skaties.tvplay.lv/parraides/title/418113?autostart=true'
    assert p.ie == 'tvplay.lv'
    assert p.video_id == 418113
    # Test get_info

# Generated at 2022-06-22 08:41:59.155977
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert isinstance(viafreeIE, ViafreeIE)
    # The following statement will raise an exception if class is not registered correctly
    tvplayIE.suitable('http://www.viafree.dk/programmer/nyheder/nyhederne-pa-tv2-dk/')


# Generated at 2022-06-22 08:42:00.998111
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/film/harry-potter-og-det-hemmelighetsfulle-kammer-/sesong-1/episode-1')


# Generated at 2022-06-22 08:42:02.783822
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()._real_extract(ViafreeIE._TESTS[0]['url'])
    assert 'q3' in viafree['formats'][0]['format_id']


# Generated at 2022-06-22 08:42:11.671105
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from ..__main__ import UrlTestCase
    from ..ytdl import YoutubeDL
    from .common import InfoExtractor


# Generated at 2022-06-22 08:42:21.168116
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    url = 'https://tvplay.skaties.lv/jaunakie-noziegumi/jaunakie-noziegumi-10044146/'
    _ = ie._real_extract(url)
    data = json.loads(len(ie._download_webpage(
        urljoin(url, '/sb/public/asset/nid-' + tvplay_home_id(url)),
        tvplay_home_id(url), note='Downloading asset JSON')))
    video_id = data['assetId']
    m3u8_url = data['movie']['contentUrl']
    title = data['title']['title']
    description = data['title'].get('summaryLong') or data['title'].get('summaryShort')

# Generated at 2022-06-22 08:43:08.245409
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractors = [x for x in globals().values() if isinstance(x, type) and issubclass(x, InfoExtractor)]
    for info_extractor in info_extractors:
        test_cases = getattr(info_extractor, '_TESTS', [])
        for test_case in test_cases:
            try:
                info_extractor = info_extractor(test_case['url'])
                assert info_extractor.extract()
            except ExtractorError as e:
                if not test_case.get('expected_error') or test_case.get('expected_error') not in str(e):
                    raise

# Generated at 2022-06-22 08:43:11.636549
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Constructor should succeed
    assert TVPlayHomeIE(TVPlayHomeIE._build_url(
        {'id': '10044354'})) is not None
    # Constructor should raise an exception
    assert TVPlayHomeIE(TVPlayHomeIE._build_url(
        {'id': '10044'})) is None

# Generated at 2022-06-22 08:43:17.208580
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.__name__ == 'TVPlayHome'
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.host == 'tvplay.skaties.lv'
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-22 08:43:18.439249
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    constructor(TVPlayHomeIE.__name__)


# Generated at 2022-06-22 08:43:25.533886
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return super(TestTVPlayHomeIE, self)._real_extract(url)

    video = TestTVPlayHomeIE().extract('https://play.tv3.lt/aferistai-10047125')
    assert video['id'] == '366367'
    assert video['title'] == 'Aferistai'
    assert video['description'] == 'Aferistai. Kalėdinė pasaka.'
    assert video['series'] == 'Aferistai [N-7]'
    assert video['season'] == '1 sezonas'
    assert video['episode'] is None
    assert video['season_number'] == 1
    assert video['episode_number'] is None
    assert video['duration'] == 464

# Generated at 2022-06-22 08:43:26.470575
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-22 08:43:31.249287
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC
    assert ie._TESTS == TVPlayIE._TESTS


# Generated at 2022-06-22 08:43:41.049309
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test with input string
    # URL = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    URL = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    inst = TVPlayHomeIE(URL)

    # Test with input of list
    # Test with input of tuple
    # Test with input of None
    # Test with input of other type (float, int)

    # Test for input not matching url
    # Test for url matching capabilities
    # Test for regex matching capabilites
    # Test for regex matching capabilities with regex groups


# Generated at 2022-06-22 08:43:50.879569
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for constructor of class ViafreeIE
    """
    # The following two should not match
    _ = ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    _ = ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    # The following two should match
    _ = ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-22 08:44:01.333972
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('www.tv3play.lt/programos/moterys-meluoja-geriau/409229')

# Generated at 2022-06-22 08:45:33.389860
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert isinstance(ie, TVPlayHomeIE)
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-22 08:45:34.847450
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return (ViafreeIE()._VALID_URL, [])

# Generated at 2022-06-22 08:45:40.849672
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    with pytest.raises(ExtractorError):
        ViafreeIE('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
        ViafreeIE('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')

# Generated at 2022-06-22 08:45:52.224250
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(TVPlayIE.IE_NAME == 'mtg')
    assert(TVPlayIE.IE_DESC == 'MTG services')

# Generated at 2022-06-22 08:45:53.355247
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:45:54.884217
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    _ = ViafreeIE({})

#Unit test for class TVPlayIE

# Generated at 2022-06-22 08:46:05.873258
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    excerpt = TVPlayIE._TESTS[0]
    IE = TVPlayIE(excerpt['url'], excerpt['info_dict'])
    assert 'TVPlayIE' in repr(IE)
    assert excerpt['url'] == IE.url
    assert excerpt['info_dict']['id'] == IE.video_id
    assert excerpt['info_dict']['title'] == IE.title
    assert excerpt['info_dict']['ext'] == IE.ext
    assert excerpt['info_dict']['description'] == IE.description
    assert excerpt['info_dict']['series'] == IE.series
    assert excerpt['info_dict']['season'] == IE.season
    assert excerpt['info_dict']['season_number'] == IE.season_number

# Generated at 2022-06-22 08:46:06.943848
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome = TVPlayHomeIE()



# Generated at 2022-06-22 08:46:12.318506
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test if object not created when URL was not recognized.
    assert TVPlayHomeIE.suitable('https://tv3play.tv3.ee/this_is_not_video_id/') is False
    # Test if object created when URL was recognized.
    assert TVPlayHomeIE.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354/') is True

# Generated at 2022-06-22 08:46:15.162883
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')
    ie.to_screen('TVPlayHomeIE')
