

# Generated at 2022-06-22 08:39:36.088494
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    assert TVPlayIE('mtg:418113')



# Generated at 2022-06-22 08:39:47.917158
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id'])) is False
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id-2'])) is False
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id-3'])) is False
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id-4'])) is False
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id-5'])) is False
    assert (viafreeIE.suitable(test_urls['viafree.se']['video-id-6'])) is False

# Generated at 2022-06-22 08:39:50.832726
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE(None)
    assert t._VALID_URL is TVPlayIE._VALID_URL
    assert t._TESTS is TVPlayIE._TESTS



# Generated at 2022-06-22 08:39:56.826664
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == re.compile(TVPlayIE._VALID_URL)
    ie.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')


# Generated at 2022-06-22 08:39:58.249480
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return ViafreeIE

# Generated at 2022-06-22 08:40:02.154858
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from unit.test_mtg_util import _test_class_constructor
    ie = _test_class_constructor(ViafreeIE)
    ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')


# Generated at 2022-06-22 08:40:02.781616
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:40:08.925545
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    url = 'https://tvplay.tv3.lt/aferistai-10047125'

    '''
    Testing with get_site_name of TVPlayHomeIE
    '''
    site_name = IE.get_site_name(url)
    assert 'tv3.lt' in site_name
    assert 'skaties.lv' not in site_name
    assert 'tv3.ee' not in site_name
    url = 'https://play.tv3.lt/aferistai-10047125'

    site_name = IE.get_site_name(url)
    assert 'tv3.lt' in site_name
    assert 'skaties.lv' not in site_name
    assert 'tv3.ee' not in site_name


# Generated at 2022-06-22 08:40:18.745801
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.YoutubeDL import YoutubeDL
    from itertools import chain
    from types import SimpleNamespace

    check_url = lambda url: bool(ViafreeIE.suitable(url) or TVPlayIE.suitable(url))

    td = YoutubeDL({'dumpjson': True})
    # Test only when TVPlay has not been downloaded yet

    # Viafree (Sweden)

# Generated at 2022-06-22 08:40:19.534626
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-22 08:40:42.646657
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import _TESTS as tvplayhome_ie_tests

    # Assert that the number of tests is equal to the
    # number of keys in tvplayhome_ie_tests
    assert len(tvplayhome_ie_tests) == len(TVPlayHomeIE._TESTS)

# Generated at 2022-06-22 08:40:44.533461
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')


# Generated at 2022-06-22 08:40:48.995361
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317")
    if sys.version_info[0] == 2: # Compare unicode objects
        assert ie.name == u"TVPlayHomeIE"
    else:
        assert ie.name == "TVPlayHomeIE"


# Generated at 2022-06-22 08:40:57.789235
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert json.loads(TVPlayHomeIE._encode_json_call({'callback': 'foo'})) == 'foo'
    assert json.loads(TVPlayHomeIE._encode_json_call({'callback': 'foo', 'foo': 'bar'})) == {'foo': 'bar'}
    assert TVPlayHomeIE._decode_unicode_call(json.dumps(u'\u00a5')) == u'\u00a5'
    assert TVPlayHomeIE._decode_unicode_call(json.dumps({'callback': 'foo'})) == {'callback': 'foo'}
    assert TVPlayHomeIE._parse_json(TVPlayHomeIE._encode_json_call({'callback': 'foo'})) == 'foo'

# Generated at 2022-06-22 08:40:59.058173
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('https://www.viafree.dk/programmer/krimi/broen-iv/')

# Generated at 2022-06-22 08:41:02.463224
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    valid_url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    tvplay._extract_urls(valid_url)
    return tvplay._VALID_URL

# Generated at 2022-06-22 08:41:13.883577
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def new_TVPlayIE(url, tvar):
        return TVPlayIE(
            url,
            tvar['country'],
            HTTP_HEADERS=tvar['headers'],
            params=tvar['params'],
        )
    new_TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true', {
        'country': 'lt',
        'headers': {
            'User-Agent': 'Mozilla/5.0 (X11; Linux i686; rv:10.0) Gecko/20100101 Firefox/10.0',
        },
        'params': {
            'skip_download': True,
        },
    })

# Generated at 2022-06-22 08:41:22.768247
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    video_id = '366367'
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie.suitable(url)
    assert ie._match_id(url) == video_id
    asset = ie._download_json(urljoin(url, '/sb/public/asset/' + video_id), video_id)
    metadata = asset.get('metadata') or {}
    assert ie._real_extract(url)['episode_number'] == int_or_none(metadata.get('episodeNumber'))

# Generated at 2022-06-22 08:41:34.453718
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test the ViafreeIE constructor."""
    viafreeIE = ViafreeIE()
    assert viafreeIE.SUCCESS == 0
    assert viafreeIE.FAILED == -1
    assert viafreeIE.SKIPPED == -2
    assert viafreeIE.result == viafreeIE.SKIPPED
    assert viafreeIE.downloader is not None
    assert viafreeIE.extractor is None
    assert viafreeIE.name is None
    assert viafreeIE.ie_key is None
    assert viafreeIE.info_dict == {}
    assert viafreeIE.add_ie is None
    assert viafreeIE.ie is None
    assert viafreeIE.url == ''
    assert viafreeIE.video_id == ''
    assert viafreeIE.extractor_key == ''
    assert viafreeIE.webpage == ''

# Generated at 2022-06-22 08:41:36.486727
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:42:16.691919
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    classToTest = TVPlayHomeIE()
    assert classToTest.IE_NAME == 'tvplayhome'
    assert classToTest._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:42:18.499515
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # TODO: write tests
    pass


# Generated at 2022-06-22 08:42:19.637841
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:42:20.778572
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('mtg:418113')


# Generated at 2022-06-22 08:42:30.384500
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Tests for constructor of class TVPlayHomeIE"""
    m_normal_url = TVPlayHomeIE._VALID_URL
    m_localized_url = r'https?://tv3play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert TVPlayHomeIE._VALID_URL == re.escape(m_normal_url)
    assert TVPlayHomeIE._VALID_URL == re.escape(m_localized_url)



# Generated at 2022-06-22 08:42:32.514354
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS


# Generated at 2022-06-22 08:42:38.011162
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test for tvplayhomeie.py"""
    global __test__
    __test__ = True  # for unittest discover
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317/'
    tvhomeie = TVPlayHomeIE(url)
    assert tvhomeie.suitable(url) == True
    assert tvhomeie.url_result(url) == True
    assert tvhomeie.valid_url(url) == True
    # unittest discover will run this test twice and assertion on line 71 will fail
    # To avoid that, set global test to False
    __test__ = False

# Generated at 2022-06-22 08:42:40.974178
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        ie = TVPlayIE()
    except NameError:
        assert False, "Constructor of class TVPlayIE failed"
    else:
        assert ie


# Generated at 2022-06-22 08:42:51.188612
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:42:51.860682
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    o = TVPlayIE()


# Generated at 2022-06-22 08:44:02.913936
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie._VALID_URL, re._pattern_type)

# Generated at 2022-06-22 08:44:12.286478
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_class = TVPlayHomeIE()

    assert test_class._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-22 08:44:13.803680
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Ensure the constructor doesn't raise errors
    TVPlayIE()


# Generated at 2022-06-22 08:44:15.344028
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    constructor = lambda: TVPlayIE('418113')


# Generated at 2022-06-22 08:44:17.363110
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert 'MTG' in tvplay.IE_NAME


# Generated at 2022-06-22 08:44:18.850204
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .c9 import C9Test

    C9Test(TVPlayIE).run()

# Generated at 2022-06-22 08:44:25.093367
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert t._downloader == None
    assert t._download_webpage_handle == None
    assert t._db == None
    assert t._type == None
    assert t._ie_key == None

# Generated at 2022-06-22 08:44:33.769394
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    user = ViafreeIE(None, None)
    v = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', None)
    assert user.suitable('http://www.tv3play.no/programmer/lilyhammer/') is True
    assert user.suitable('http://www.tv3play.no/programmer/lilyhammer/sesong-2') is True
    assert user.suitable('http://www.tv3play.no/programmer/lilyhammer/sesong-1/episode-1') is True
    assert user.suitable('http://www.tv3play.no/programmer/lilyhammer/sesong-1/episode-1?autostart=true') is True

# Generated at 2022-06-22 08:44:39.285744
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    if (ie.suitable(url)):
        print("Object created")
    else:
        print("Object not created")

# Generated at 2022-06-22 08:44:41.607302
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC is not None


# Generated at 2022-06-22 08:48:07.325192
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for country in ['dk', 'se']:
        l = ViafreeIE._build_url_result(country, 'test_id')
        if country == 'dk':
            assert l == ('https://www.viafree.dk/programmer/test_id', {'country': country, 'id': 'test_id'})
        else:
            assert l == ('https://www.viafree.se/program/test_id', {'country': country, 'id': 'test_id'})



# Generated at 2022-06-22 08:48:09.222437
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
    except:
        assert False, 'constructor failed'


# Generated at 2022-06-22 08:48:18.844815
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:48:23.568826
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:48:25.830858
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home = TVPlayHomeIE({})
    assert tv_play_home



# Generated at 2022-06-22 08:48:32.742929
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Tests using test_video_url in _TESTS
    n = 0
    while n < len(_TESTS):
        if _TESTS[n]['url'] != 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true':
            ie = TVPlayIE()
            ie._real_extract(_TESTS[n]['url'])
            n += 1
        else:
            n += 1


# Generated at 2022-06-22 08:48:36.041693
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import math
    from extractor import common
    unit = common.Unit(ViafreeIE, 'http://www.viafree.se/program/reality/paradise-hotel/sasong-13/avsnitt-1')
    unit.run()

# Generated at 2022-06-22 08:48:43.167296
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Constructor of an object in order to perform unit tests
    """
    video_id = '10605'
    video_url = 'http://www.tv3play.lt/programos/laimejimas-ir-praradimas/%s?autostart=true' % video_id
    return TVPlayIE()._real_initialize(video_url)


# Generated at 2022-06-22 08:48:45.452743
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Check the constructor of class TVPlayHomeIE does not raise an exception when instantiating a TVPlayHomeIE class
    TVPlayHomeIE()


# Generated at 2022-06-22 08:48:53.905521
# Unit test for constructor of class ViafreeIE