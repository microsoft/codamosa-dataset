

# Generated at 2022-06-22 08:39:37.909901
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:39:43.948388
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.IE_DESC = 'MTG services'
    ie.IE_NAME = 'mtg'

# Generated at 2022-06-22 08:39:49.163124
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113') == False


# Generated at 2022-06-22 08:39:49.982102
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    t.suite()


# Generated at 2022-06-22 08:40:01.726513
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:05.181896
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ViafreeIE.suitable(url)
    # assert False, ViafreeIE._real_extract(ViafreeIE(), url)

# Generated at 2022-06-22 08:40:15.930214
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()

# Generated at 2022-06-22 08:40:25.137456
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    stop_time = time.time() + 2
    while time.time() < stop_time:
        try:
            for country in ['dk', 'no', 'se']:
                ViafreeIE._download_json(
                    'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1' % country,
                    'det-beste-vorspielet',
                    headers=ViafreeIE.geo_verification_headers())
            break
        except ExtractorError:
            pass

# Generated at 2022-06-22 08:40:26.859898
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    assert TVPlayIE('mtg:418113')




# Generated at 2022-06-22 08:40:36.261229
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS
    assert ie._GEO_COUNTRIES == TVPlayHomeIE._GEO_COUNTRIES
    assert ie._NETRC_MACHINE == TVPlayHomeIE._NETRC_MACHINE
    assert ie._downloader is None
    assert ie._download_webpage is None
    assert ie._downloader_params == {}

# Generated at 2022-06-22 08:41:01.284132
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:41:11.210716
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    assert ie.VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.IE_DESC == 'TVPlay'

# Generated at 2022-06-22 08:41:15.446157
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from tests.test_content import tv_play

    instance = TVPlayIE()
    instance._match_id(tv_play.TVPlayIE.IE_NAME, tv_play.TVPlayIE._VALID_URL, tv_play.TVPlayIE._TESTS)


# Generated at 2022-06-22 08:41:17.559695
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.get_url_re() is not None



# Generated at 2022-06-22 08:41:25.116282
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5');
    assert ie._VALID_URL == 'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-22 08:41:30.768938
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    print('Call %s constructor' % __name__)
    viafreeIE = ViafreeIE()
    print('Test %s constructor' % __name__)
    assert viafreeIE.suitable(url) is True
    print('%s constructor works properly' % __name__)

# Generated at 2022-06-22 08:41:41.396043
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE._build_search_regex(TVPlayHomeIE._VALID_URL).pattern)
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.IE_NAME == 'tvplay'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-22 08:41:48.453463
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # check exceptions
    ie = TVPlayIE()
    ie.IE_NAME = "thisisnotaname"
    ie.IE_DESC = "thisisnotadescription"
    ie.IE_VERSION = "thisisnotaname"
    ie._VALID_URL = "thisisnotavalidurl"
    ie._TESTS = [
        {
            'add_ie': ['TVPlayIE'],
            'title': 'this should fail'
        },
    ]
    ie.to_screen("just something to trigger the constructor")
    assert ie.ie_key() == 'TVPlayIE'


# Generated at 2022-06-22 08:41:51.652828
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Smoke test for constructor of class TVPlayHomeIE
    """
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:41:59.360010
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test for invalid URL
    tvplay_ie = TVPlayIE('invalid')
    assert not tvplay_ie.is_suitable('invalid')
    # test for valid URL
    tvplay_ie = TVPlayIE('https://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert tvplay_ie.is_suitable('https://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    return

if __name__ == '__main__':
    # test for constructor of class TVPlayIE
    test_TVPlayIE()

# Generated at 2022-06-22 08:42:36.629839
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    TVPlayIE = TVPlayIE()

    assert viafreeIE.suitable(viafreeIE._VALID_URL) is True
    assert TVPlayIE.suitable(viafreeIE._VALID_URL) is False



# Generated at 2022-06-22 08:42:41.547486
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    ie.geo_verification_headers()
    ie.geo_bypass(None)
    ie.geo_bypass_countries()


# Generated at 2022-06-22 08:42:42.416410
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert instance._GEO_BYPASS is False


# Generated at 2022-06-22 08:42:47.767343
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
        Unit test for class ViafreeIE
    """

    from youtube_dl.extractor.mtg import ViafreeIE
    from youtube_dl.utils import ExtractorError
    from youtube_dl.tests.test_utils import FakeYDL
    from youtube_dl.downloader.http import HTTPFD
    from json import loads as json_loads

    VIAFREE_URL = 'https://playapi.mtgx.tv/v3/videos/757786'
    VIAFREE_STREAMS_URL = 'https://playapi.mtgx.tv/v3/videos/stream/757786'

    ydl = FakeYDL()
    ie = ViafreeIE(ydl)

    assert ie.match_url(VIAFREE_URL)


# Generated at 2022-06-22 08:42:49.007556
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        TVPlayIE.suitable('')
    except Exception as e:
        print(repr(e))
        assert False


# Generated at 2022-06-22 08:42:51.898261
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_TVPlayIE = TVPlayIE()
    class_TVPlayIE.IE_NAME
    class_TVPlayIE.IE_DESC
    class_TVPlayIE._TESTS


# Generated at 2022-06-22 08:42:57.242909
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # constructor keyword arguments
    arg_ls = [
        'ie_key',
        'host',
        'ie_keywords',
        'ieid',
        'class_',
        'title',
        'description',
        'thumbnail',
        'duration',
        'timestamp',
        'upload_date',
        'like_count',
        'dislike_count',
        'age_limit',
        'extractor_key',
        '_testing',
    ]
    # instance members
    mem_ls = ['_downloader', '_download_webpage_handle']
    # instance methods
    func_ls = [ '_real_extract' ]
    tvp = TVPlayIE()

# Generated at 2022-06-22 08:43:00.923547
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('www.example.com')
    assert ie.IE_NAME == 'tvplayhome'
    assert ie.IE_DESC == 'TVPlay Home'
    assert ie._VALID_URL == ie.VALID_URL
    ie = TVPlayHomeIE('www.example.com', ie_key='NotTVPlayHome')
    assert ie.IE_NAME == 'nottvplayhome'
    assert ie.IE_DESC == 'TVPlay Home'
    assert ie._VALID_URL == ie.VALID_URL

# Generated at 2022-06-22 08:43:07.685776
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_case = [
        # test not Viafree program
        {
            'url': 'http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true',
            'info_dict': {
                'id': '266636',
                'ext': 'mp4',
                'title': 'Den sista dokusåpan S01E08',
                'description': 'md5:295be39c872520221b933830f660b110',
                'duration': 1492,
                'timestamp': 1330522854,
                'upload_date': '20120229',
                'age_limit': 18,
            },
            'params': {
                'skip_download': True,
            },
        },
    ]

# Generated at 2022-06-22 08:43:08.346453
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-22 08:43:51.511239
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _download_webpage(self, url, video_id, *args, **kwargs):
            return '{}'
        def _extract_m3u8_formats(self, url, video_id, *args, **kwargs):
            return [{
                'url': url,
                'ext': 'mp4'
            }]

    ie = TestTVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True
    assert ie.suitable('http://tvplay.tv3.lt/vinas-melo-labak/vinas-melo-labak-10280317/') is True


# Generated at 2022-06-22 08:43:56.253532
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    assert ie.IE_NAME == "mtg"
    assert ie.IE_DESC == "MTG services"



# Generated at 2022-06-22 08:44:00.101749
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC
    assert ie._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-22 08:44:04.060888
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    for url in ie._TESTS:
        video_id = ie._match_id(url['url'])
        assert video_id



# Generated at 2022-06-22 08:44:04.701046
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-22 08:44:07.752258
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE()
    i.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    i.get_url_regex()

# Generated at 2022-06-22 08:44:18.176587
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') == True
    assert ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true') == False
    assert ViafreeIE.suitable('https://www.viafree.dk/programmer/mode-og-smaabilleder/smaabilleder-sasong-2/episode-1') == True
    assert ViafreeIE.suitable('https://www.viafree.dk/programmer/mode-og-smaabilleder/smaabilleder-sasong-2/episode-1?autostart=true') == True

# Generated at 2022-06-22 08:44:20.469500
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._add_ie(TVPlayHomeIE._VALID_URL) == TVPlayHomeIE


# Generated at 2022-06-22 08:44:22.474411
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test if TVPlayIE constructor works."""
    _ = TVPlayIE

# Generated at 2022-06-22 08:44:32.884165
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    cls = globals()['ViafreeIE']
    cls._VALID_URL = cls._VALID_URL.replace('https?://', 'http://')

    # Success test for country code set by URL
    test_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = cls()
    assert ie.suitable(test_url)
    assert ie.GEO_COUNTRIES == ['NO']
    # Success test for country code set by default
    test_url = 'http://www.viafree.com/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = cls()

# Generated at 2022-06-22 08:45:29.552473
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(TVPlayIE())



# Generated at 2022-06-22 08:45:39.375039
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:45:48.230872
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.__class__ == TVPlayHomeIE and ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:45:50.612068
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV']})

# Generated at 2022-06-22 08:46:00.727009
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:46:01.824665
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    play_ie = TVPlayIE()


# Generated at 2022-06-22 08:46:03.400871
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None, {})
    ie.suitable()



# Generated at 2022-06-22 08:46:06.189808
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # If the testing method does not raise an error,
    # it means the class is properly inherited from InfoExtractor
    assert isinstance(ViafreeIE(None), InfoExtractor)


# Generated at 2022-06-22 08:46:08.828251
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == 'http://[^/]+/(?:[^/]+/)+\d+'

# Generated at 2022-06-22 08:46:16.881323
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test for constructor - URL + md5
    test1_id = TVPlayIE._match_id('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert test1_id == '418113'
    test1_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    test1_info = TVPlayIE._real_extract(test1_url)

    # test for constructor - URL + md5
    test2_id = TVPlayIE._match_id('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert test2_id == '409229'

# Generated at 2022-06-22 08:48:15.265932
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.country == 'se'
    assert ie.path == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'dk'
    assert ie.path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'



# Generated at 2022-06-22 08:48:26.431270
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_mtg import get_extractor
    from .sport_fun import SportFunIE

    ie = get_extractor(SportFunIE.ie_key(), 'SportFunIE')
    assert(ie.__class__ == SportFunIE)

    ie = get_extractor(TVPlayIE.ie_key(), 'TVPlayIE')
    assert(ie.__class__ == TVPlayIE)

    ie = get_extractor(ViafreeIE.ie_key(), 'ViafreeIE')
    assert(ie.__class__ == ViafreeIE)

    ie = get_extractor(ViafreeIE.ie_key(), 'TVPlayIE')
    assert(ie.__class__ == TVPlayIE)

    ie = get_extractor(ViafreeIE.ie_key(), 'SportFunIE')

# Generated at 2022-06-22 08:48:36.246699
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvie = TVPlayIE()
    assert tvie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:48:38.262721
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:48:47.908502
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:48:48.611998
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:48:50.721860
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert isinstance(tvplay_ie, InfoExtractor)
    assert 'TVPlayIE' == tvplay_ie.IE_NAME
    assert 'MTG' == tvplay_ie.IE_DESC


# Generated at 2022-06-22 08:48:56.422372
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """ test constructor of class TVPlayIE """
    # test with valid url
    url = "http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true"
    tvplay = TVPlayIE(url)
    assert tvplay.url, url
    assert tvplay.geo_country, None
    assert tvplay.geo_verification_headers['Accept-Language'], "lt"
    assert tvplay._VALID_URL, r'(?x)http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    
    # test with new url
    url = "http://www.tv3play.se/program/husraddarna/395385?autostart=true"

# Generated at 2022-06-22 08:49:05.729838
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # dk
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    # no
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    # se
    assert ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    # not match
    assert not Via

# Generated at 2022-06-22 08:49:11.819636
# Unit test for constructor of class TVPlayHomeIE