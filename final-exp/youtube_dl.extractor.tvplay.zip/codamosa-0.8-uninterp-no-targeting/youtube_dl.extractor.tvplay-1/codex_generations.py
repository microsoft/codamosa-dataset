

# Generated at 2022-06-22 08:39:38.135145
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    construct_test('Viafree')

# Generated at 2022-06-22 08:39:44.085070
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    TVPlayIE('http://www.tv8play.se/program/antikjakten/282756?autostart=true')

# Generated at 2022-06-22 08:39:44.982972
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE({})



# Generated at 2022-06-22 08:39:55.786273
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Initialize instance of InfoExtractor class
    ie = TVPlayIE()
    assert ie.IE_NAME == "mtg"
    assert ie.IE_DESC == "MTG services"

# Generated at 2022-06-22 08:40:03.575068
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test an instance of our class
    tv3play = TVPlayHomeIE()

    # Test our URL parsing regex
    tv3play._VALID_URL = r'https?://(?:.*?)/(?P<id>[0-9]+)'
    assert tv3play._match_id("http://www.example.com/123456") == "123456"

    # Test calls to methods of our class
    tv3play._download_json("http://www.example.com/test.json", "testjson", {})

    # Test some helper methods
    tv3play._extract_m3u8_formats("http://www.example.com/test.m3u8", "testm3u8", 'mp4')


# Generated at 2022-06-22 08:40:06.414928
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-22 08:40:18.177685
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:40:18.727399
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-22 08:40:19.945767
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test = TVPlayHomeIE()
    assert(test)

# Generated at 2022-06-22 08:40:20.667016
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-22 08:40:48.781732
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:40:57.625024
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-22 08:41:07.961441
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    # tvplay.lv
    tvplay = TVPlayIE(url)
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:14.567503
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:41:19.210637
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable(TVPlayIE.suitable(""))
    ViafreeIE.suitable(any("www.viafree.se" in url for url in ['http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2']))


# Generated at 2022-06-22 08:41:28.129940
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    embed_url = 'http://playapi.mtgx.tv/v3/videos/624952/embed/info'

# Generated at 2022-06-22 08:41:30.354844
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tester = TVPlayHomeIE()
    assert tester is not None

# Generated at 2022-06-22 08:41:31.831459
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test if the class can be initialized
    TVPlayHomeIE()


# Generated at 2022-06-22 08:41:44.412847
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('https://www.tv3play.se/program/husraddarna/395385?autostart=true')
    ie.extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    ie.extract('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    ie.extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    ie.extract('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-22 08:41:51.440357
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return self._get_info(url)


# Generated at 2022-06-22 08:42:10.806740
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None).to_screen('this is just a test')


# Generated at 2022-06-22 08:42:18.025724
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Do not load any actual data
    ie = ViafreeIE(EchoMock())
    # Use URL of the unit test page

# Generated at 2022-06-22 08:42:29.773293
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplay'
    assert ie.IE_DESC == 'TVPlay.lv, TVPlay.skaties.lv, TVPlay.tv3.lt and TVPlay.tv3.ee'
    assert ie._VALID_URL == 'https?://(?:(?:tv3|tv6|tv10|tv3sport|tv3zinas|tv6zinas)play\.skaties|tv3play|(?:tv6|tv3)\.tv3)\.lv/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)'

# Generated at 2022-06-22 08:42:35.697128
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    obj = ViafreeIE()
    assert obj.suitable(url)



# Generated at 2022-06-22 08:42:39.162988
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t.IE_NAME == 'mtg'
    assert t.IE_DESC == 'MTG services'



# Generated at 2022-06-22 08:42:42.020394
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')



# Generated at 2022-06-22 08:42:43.176444
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor is not implemented.
    pass


# Generated at 2022-06-22 08:42:45.039840
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert isinstance(TVPlayHomeIE('test'), TVPlayHomeIE)

# Generated at 2022-06-22 08:42:46.897075
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Basic test for constructor
    """
    # Constructor for class
    ViafreeIE()

# Generated at 2022-06-22 08:42:56.110515
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:43:43.413286
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tph = TVPlayHomeIE()
    assert tph._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:43:44.068359
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-22 08:43:48.542532
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    initial_state = copy.deepcopy(TVPlayHomeIE._TESTS)
    try:
        TVPlayHomeIE._TESTS = []
        TVPlayHomeIE('TVPlayHomeIE', test_TVPlayHomeIE.__name__)
    finally:
        TVPlayHomeIE._TESTS = initial_state

# Generated at 2022-06-22 08:43:50.436243
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class Options:
        geo_bypass_country = None
    options = Options()
    IE = TVPlayIE(options)
    return 0


# Generated at 2022-06-22 08:44:01.941079
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') == True
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125') == True
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317') == True
    assert ie.suitable('https://viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869') == False
    assert ie.suitable('https://play.tv3.lt/aferistai') == False

# Generated at 2022-06-22 08:44:02.455550
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-22 08:44:13.923311
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test constructors
    name = 'TVPlayHomeIE() for: '

# Generated at 2022-06-22 08:44:23.377944
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE()
    print(i.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113'))
    print(i.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true'))
    print(i.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317'))
    print(i.suitable('https://play.tv3.lt/aferistai-10047125'))
    print(i.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'))

# Generated at 2022-06-22 08:44:25.723168
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()
    x._real_extract("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")

# Generated at 2022-06-22 08:44:26.729684
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:46:07.926392
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)._initialize_geo_bypass({'countries': ['LV'], 'proxies': []})
    TVPlayIE(None)._real_initialize()
    TVPlayIE(None)._real_extract(None)



# Generated at 2022-06-22 08:46:12.355720
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for test in TVPlayIE._TESTS:
        url = test.get('url')
        if url.startswith('mtg:') or TVPlayIE.suitable(url):
            continue
        assert ViafreeIE.suitable(url)
        assert ViafreeIE(ViafreeIE.ie_key()).suitable(url)


# Generated at 2022-06-22 08:46:17.145210
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS


# Generated at 2022-06-22 08:46:22.618474
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    instance = TVPlayIE()
    match = instance._match_id(url)
    assert match is not None


# Generated at 2022-06-22 08:46:25.386797
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE.
    """
    tvplay = TVPlayIE()

    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'


# Generated at 2022-06-22 08:46:35.941276
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Tests for the constructor of class TVPlayHomeIE
    #
    # Set up some test input and output values
    good_input_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

    # Construct an instance of the TVPlayHomeIE class
    inst = TVPlayHomeIE(good_input_url)

    # Check if the constructor sets the correct values

# Generated at 2022-06-22 08:46:46.228465
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .common import InfoExtractor
    ie = InfoExtractor('tvplay', 'lv')
    assert isinstance(ie, TVPlayHomeIE)
    ie = InfoExtractor('tvplay', 'ee')
    assert isinstance(ie, TVPlayHomeIE)
    ie = InfoExtractor('tvplay', 'lt')
    assert isinstance(ie, TVPlayHomeIE)
    ie = InfoExtractor('tv3play', 'lv')
    assert isinstance(ie, TVPlayHomeIE)
    ie = InfoExtractor('tv3play', 'ee')
    assert isinstance(ie, TVPlayHomeIE)
    ie = InfoExtractor('tv3play', 'lt')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:46:51.897217
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    testInstance = ViafreeIE()
    assert(testInstance.IE_NAME == 'viafree')
    assert(testInstance.IE_DESC == 'Viafree')

    URL = 'http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1'
    testInstance = ViafreeIE.suitable(URL)
    assert(testInstance == True)



# Generated at 2022-06-22 08:46:53.956080
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Constructor test
    """
    ie = ViafreeIE(ViafreeIE.suitable(None))
    assert ie.SUCCESS == 'SUCCESS'


# Generated at 2022-06-22 08:46:59.733268
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'