

# Generated at 2022-06-22 08:39:41.159748
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test the ViafreeIE Class.
    """
    v_ie = ViafreeIE()
    url = "http://www.viafree.dk/programmer/underholdning/det-beste-vorspielet/saeson-2/episode-1"
    assert v_ie.suitable(url)
    assert v_ie.IE_NAME == v_ie.ie_key()

# Generated at 2022-06-22 08:39:44.441893
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    for u in t._TESTS:
        t._match_id(u.get('url'))


# Generated at 2022-06-22 08:39:48.493982
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:39:49.633236
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-22 08:39:59.581447
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.suitable('mtg:418113') == True
    assert TVPlayIE.suitable('http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true') == True
    assert TVPlayIE.suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true') == True
    assert TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == True
    assert TVPlayIE.suitable('https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') == True
    assert TVPlayIE.suitable

# Generated at 2022-06-22 08:40:11.360067
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_user_agent = 'test_user_agent'
    test_viafree_header = {
        'Accept': 'application/json',
        'User-Agent': test_user_agent,
    }

    instance = ViafreeIE(test_user_agent)
    assert instance.geo_verification_headers() == test_viafree_header
    assert instance.geo_verification_headers(country_code='DK') == test_viafree_header
    assert instance.geo_verification_headers(country_code='SE') == test_viafree_header
    assert instance.geo_verification_headers(country_code='NO') == test_viafree_header
    assert instance.geo_verification_headers(country_code='LT') == test_viafree_header
    assert instance.geo_verification_

# Generated at 2022-06-22 08:40:12.532315
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:40:25.675056
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')
    assert ie.url == 'https://tvplay.tv3.lt/aferistai-10047125/'
    assert ie.video_id == '10047125'
    assert ie.domain == 'tv3.lt'

    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert ie.url == 'https://tvplay.skaties.lv/vinas-melo-labak-10280317'
    assert ie.video_id == '10280317'
    assert ie.domain == 'skaties.lv'


# Generated at 2022-06-22 08:40:27.154055
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(TVPlayHomeIE.ie_key())

# Generated at 2022-06-22 08:40:32.000048
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert isinstance(ie._VALID_URL, re._pattern_type)
    assert ie._VALID_URL.match('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-22 08:41:10.664775
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-22 08:41:14.226764
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-22 08:41:18.920299
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay_ie = TVPlayIE()
    tvplay_ie._match_id(test_url)
    tvplay_ie._real_extract(test_url)


# Generated at 2022-06-22 08:41:24.529352
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv = TVPlayHomeIE()
    assert tv._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

test_TVPlayHomeIE()

# Generated at 2022-06-22 08:41:26.060683
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()



# Generated at 2022-06-22 08:41:30.724879
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE('mtg:95786')
    except Exception as ex:
        assert False, 'Instantiating ViafreeIE with mtg:95786 should not raise an exception: %s' % ex.message


# Generated at 2022-06-22 08:41:32.544787
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Simple test to check if the class exists.
    """
    ViafreeIE()



# Generated at 2022-06-22 08:41:40.152491
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    encoded_content = b'viafree_json'
    response = compat_urllib_request.Request('viafree_url', data=encoded_content)
    response.add_header('Content-Type', 'application/json;charset=UTF-8')

    content = json.loads(encoded_content.decode('utf-8'))
    video_content = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']
    guid = video_content['guid']

    stream = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']['_links']['streamLink']['href']
    stream_content = json.loads(encoded_content.decode('utf-8'))
    stream_href = stream_content

# Generated at 2022-06-22 08:41:49.271047
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:58.590349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test the constructor of class ViafreeIE
    """
    from .test_suite import ydl
    ydl._ies.clear()

    vf = ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert vf

    vf = ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert not vf

    # Should raise error if video is not available in country

# Generated at 2022-06-22 08:43:14.289596
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()


# Generated at 2022-06-22 08:43:15.878559
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test instantiation of the class
    TVPlayIE()


# Generated at 2022-06-22 08:43:22.858786
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-22 08:43:26.777503
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""
    ie = TVPlayHomeIE()

    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.IE_NAME == 'tvplayhome'
    assert ie.IE_DESC == 'TVPlay Home'
    assert ie.BROADCASTER_NAME == 'TVPlay Home'

# Generated at 2022-06-22 08:43:29.845964
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable(ViafreeIE._VALID_URL)
    assert not ViafreeIE.suitable(TVPlayIE._VALID_URL)


# Generated at 2022-06-22 08:43:31.588421
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie.geo_countries, dict)


# Generated at 2022-06-22 08:43:34.139519
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractor = TVPlayHomeIE()
    assert info_extractor.get_info_extractor() == TVPlayHomeIE



# Generated at 2022-06-22 08:43:42.294060
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._TESTS
    url = 'http://play.tv3play.se/program/husraddarna/395385?autostart=true'
    expected_url = 'http://playapi.mtgx.tv/v3/videos/395385'
    assert ie._request_webpage(compat_urlparse.urlparse(url), '', '', 'application/json') == expected_url


# Generated at 2022-06-22 08:43:47.758728
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.lt/parraides/moterys-meluoja-geriau/409229?autostart=true'
    re_tvplayie = re.compile(TVPlayIE._VALID_URL)
    match = re_tvplayie.match(url)
    assert (match.group('id') == '409229')


# Generated at 2022-06-22 08:43:59.461592
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('tv3play.ee', 'mtg')._real_initialize()
    assert TVPlayIE('tv3play.se', 'mtg')._real_initialize()
    assert TVPlayIE('tv3play.no', 'mtg')._real_initialize()
    assert TVPlayIE('viafree.se', 'mtg')._real_initialize()
    assert TVPlayIE('tv3play.dk', 'mtg')._real_initialize()
    assert TVPlayIE('tv3play.lv', 'mtg')._real_initialize()
    assert TVPlayIE('tvplay.skaties.lv', 'mtg')._real_initialize()
    assert TVPlayIE('play.tv3.lt', 'mtg')._real_initialize()

# Generated at 2022-06-22 08:47:29.171284
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:47:31.878459
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'


# Generated at 2022-06-22 08:47:41.342733
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:47:44.193504
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Purpose:
        Unit test for constructor of class TVPlayIE
    """
    testExtractor = TVPlayIE()
    assert(testExtractor.ie_key() == 'TVPlay')



# Generated at 2022-06-22 08:47:54.701535
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_TVPlayIE = TVPlayIE()
    assert class_TVPlayIE.IE_NAME == 'mtg'
    assert class_TVPlayIE.IE_DESC == 'MTG services'
    assert re.match(class_TVPlayIE._VALID_URL, 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert re.match(class_TVPlayIE._VALID_URL, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-22 08:47:58.603520
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    try:
        TVPlayIE(url)
    except Exception:
        assert False


# Generated at 2022-06-22 08:47:59.826367
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie._GEO_BYPASS is False


# Generated at 2022-06-22 08:48:02.174833
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE([])
    except Exception:
        assert False, 'Constructor of class ViafreeIE should not throw exception'



# Generated at 2022-06-22 08:48:03.665783
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(AttributeError):
        ViafreeIE()

# Generated at 2022-06-22 08:48:08.081524
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg:970905')
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC
    assert ie._VALID_URL == TVPlayIE._VALID_URL
