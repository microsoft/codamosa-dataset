

# Generated at 2022-06-22 08:39:40.703828
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if get_testdata_dir():
        asset_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
        tvplayhome_info_extractor = TVPlayHomeIE(asset_url)
        assert tvplayhome_info_extractor.video_id == "366367"
        assert tvplayhome_info_extractor.url == asset_url

# Generated at 2022-06-22 08:39:41.286052
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-22 08:39:43.473579
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._constructor(TVPlayIE._VALID_URL)



# Generated at 2022-06-22 08:39:47.791546
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from pytube import YouTube
    url = 'https://www.youtube.com/watch?v=U8w6UHx6xJ4'
    yt = YouTube(url)
    ie = TVPlayIE()
    ie.extract(yt)

# Generated at 2022-06-22 08:39:49.538894
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Instantiate ViafreeIE class
    ViafreeIE()

# Generated at 2022-06-22 08:39:50.694982
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-22 08:39:58.805146
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .extractor.common import InfoExtractor
    from .extractor.mtg import ViafreeIE

    info_extractor = InfoExtractor()

    viafree_ie = ViafreeIE.ie_key()

    info_extractor.add_info_extractor(viafree_ie)

    assert viafree_ie in info_extractor._ies
    assert info_extractor._ies[viafree_ie] is ViafreeIE



# Generated at 2022-06-22 08:39:59.693931
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:40:01.164918
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError):
        # Raises TypeError because TVPlayIE is an old-style class
        ViafreeIE()


# Generated at 2022-06-22 08:40:04.154727
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import initialize_api_key
    initialize_api_key()
    import doctest
    doctest.run_docstring_examples(
        TVPlayHomeIE._build_request, globals(),
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-22 08:40:40.216037
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-22 08:40:44.419811
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE(ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'))
    # Test 'TVPlayIE' class was inherited
    assert isinstance(viafreeIE, TVPlayIE) == True
    assert viafreeIE.IE_NAME == 'viafree'

# Generated at 2022-06-22 08:40:54.364866
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test TVPlayIE constructor
    tp = TVPlayIE('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')


# Generated at 2022-06-22 08:41:00.501564
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # Test if the constructor raises an exception for invalid URL
    _, err, _ = ie.suitable('https://www.google.com/')
    assert isinstance(err, ExtractorError)

# Generated at 2022-06-22 08:41:10.548425
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert t.IE_NAME == 'mtg'
    assert t.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:12.587882
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE();
    assert ie.IE_NAME == 'mtg'


# Generated at 2022-06-22 08:41:24.454753
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test loading TVPlayHomeIE as superclass's constructor
    # TVPlayHomeIE class can be loaded by inheritance
    # with constructors of superclass
    i = TVPlayHomeIE()
    i.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    i.extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # Test loading TVPlayHomeIE as superclass's constructor
    # TVPlayHomeIE class can be loaded by inheritance
    # with constructors of superclass
    i = TVPlayHomeIE()
    i.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-22 08:41:34.208119
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .tests import test_viafree

    viafree_ie = ViafreeIE(test_viafree.MockYoutubeDL({}))
    # Note: 'mimetype' is hard to guess.
    assert viafree_ie._get_format('hls', 'mp4', 'mimetype') is not None
    format_with_all_args = viafree_ie._get_format('hls', 'mp4', 'mimetype')
    assert format_with_all_args['ext'] == 'mp4'
    assert format_with_all_args['quality'] == 480
    assert format_with_all_args['format_id'] == 'hls'



# Generated at 2022-06-22 08:41:39.598561
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test if the regex in the constructor of ViafreeIE is properly constructed
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    match = re.match(ViafreeIE._VALID_URL, url)
    assert match.group('country') == 'se'
    assert match.group('id') == 'livsstil/husraddarna/sasong-2/avsnitt-2'

# Generated at 2022-06-22 08:41:47.059259
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.get_country('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == 'no'
    assert ie.get_country('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') == 'se'
    assert ie.get_country('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') == 'dk'


# Generated at 2022-06-22 08:43:08.414863
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""

# Generated at 2022-06-22 08:43:17.933630
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_ie = TVPlayIE()
    assert tv_play_ie.IE_NAME == 'tvplay'
    assert tv_play_ie._VALID_URL == 'https?://(?:www\\.)(?:tvplay(?:\\.skaties)?\\.(?:lv|lt|sk|ee|se|no|dk)|play\\.(?:tv3|nova)\\.(?:lt|bg)|viasat4play\\.no)/(?:[^/]+/){2,}(?P<id>\\d+)'


# Generated at 2022-06-22 08:43:20.832585
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # This test case tests whether it is possible to create an TVPlayIE object
    # without arguments.
    ie = TVPlayIE()
    assert ie


# Generated at 2022-06-22 08:43:26.251388
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test using constructed URL
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551'
    # Retrieve constructor of the class
    TVPlayIE = TVPlayIE("tvplay_ie", {'url': url})
    # Test using generated URL
    url = TVPlayIE._VALID_URL % {'id': '238551'}
    assert TVPlayIE.suitable(url)


# Generated at 2022-06-22 08:43:36.626176
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_tools import get_testdata_folder
    from six import BytesIO
    import os

    # Test case for structure of TVPlay
    #
    # parent-> 
    #   series-> 
    #       seasons-> 
    #           episodes
    # The following test cases are not including a structure where season or episodes are not there
    # The following test cases are also not including a structure where series or seasons are not there

    # Testcase for episodes with series
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    webpage = open(os.path.join(get_testdata_folder(), 'moterys-meluoja-geriau.html'), 'rb').read()
    info = TVPlayIE()._real

# Generated at 2022-06-22 08:43:48.336574
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable(TVPlayHomeIE._VALID_URL)
    assert ie.suitable('https://play.tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.suitable('https://play.tv3play.tv3.se/cool-d-ga-mehhikosse-10044354')
    assert ie.suitable('https://play.tv3play.tv3.no/cool-d-ga-mehhikosse-10044354')
    assert ie.suitable('https://play.tv3play.tv3.lt/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-22 08:43:50.778305
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(TypeError) as excinfo:
        TVPlayHomeIE(TVPlayHomeIE.ie_key(), {})
    assert 'required positional argument' in str(excinfo.value)

# Generated at 2022-06-22 08:44:02.344410
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class Test_ViafreeIE(ViafreeIE):
        _VALID_URL = r'.*'
        _TESTS = [{}]

        def _real_extract(self, url):
            return self._extract_viaplay_smil(url, 'test')

    ie = Test_ViafreeIE()
    m = re.match(ie._VALID_URL, 'https://viafree.se/')
    assert m is not None
    m = re.match(ie._VALID_URL, 'https://www.viafree.se/')
    assert m is not None
    m = re.match(ie._VALID_URL, 'https://www.viafree.dk/')
    assert m is not None
    m = re.match(ie._VALID_URL, 'https://viafree.no/')


# Generated at 2022-06-22 08:44:13.842048
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:44:17.776335
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test if exception is raised when wrong url is given
    with pytest.raises(ExtractorError):
        data = TVPlayHomeIE()._real_extract('https://www.youtube.com/watch?v=BaW_jenozKc')

# Test API key for youtube-dl

# Generated at 2022-06-22 08:45:58.774583
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ Test class TVPlayHomeIE """

# Generated at 2022-06-22 08:46:08.266106
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = VideoInfo(ViafreeIE.ie_key())
    assert instance.suitable("http://www.viafree.no")
    assert not instance.suitable("http://viafree.no")
    assert instance.suitable("http://www.viafree.se")
    assert not instance.suitable("http://viafree.se")
    assert instance.suitable("http://www.viafree.dk")
    assert not instance.suitable("http://viafree.dk")
    assert instance.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")



# Generated at 2022-06-22 08:46:11.379976
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://www.tvplay.lv/programma/druva/1-sezona/22-serija/10044368')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:46:22.989613
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:46:24.177673
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL



# Generated at 2022-06-22 08:46:28.601587
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('url')
    assert ie.geo_bypass is False
    assert ie.geo_bypass_country == 'SE'


# Generated at 2022-06-22 08:46:32.901123
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE()
    assert x.IA_NAME == 'viafree'
    assert x.country == None
    assert x._TEST.get('country') == None
    assert x._TEST.get('url').startswith('http')


# Generated at 2022-06-22 08:46:35.866315
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # Here is the assert on the title of the video
    assert(ie.title() == "With open source development, I get to decide")


# Generated at 2022-06-22 08:46:47.239305
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # This is the output of calling constructor.
    # The id field is generated in constructor.
    ie_id = ie.ie_key()
    assert ie_id == "mtg"
    # This is the output of calling constructor.
    # The name field is generated in constructor.
    ied_name = ie.ie_key_name()
    assert ied_name == "TVPlay"
    # This is the output of calling constructor.
    # The description field is generated in constructor.
    ied_desc = ie.ie_key_description()
    assert ied_desc == "MTG services"
    # This is the output of calling constructor.
    # The IE URL regex is generated in constructor since common does not contain it.
    ie_url_regex = ie.ie_key_url_regex

# Generated at 2022-06-22 08:46:55.833535
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-22 08:48:45.666865
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/', 'test') is True


# Generated at 2022-06-22 08:48:50.073308
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import common
    # Test constructor
    with pytest.raises(RegexNotFoundError):
        common.ViafreeIE('https://tvplay.skaties.lv/vinas-melo-labak/418113')

# Generated at 2022-06-22 08:48:55.799474
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:48:57.266819
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('ddd', 'sss')



# Generated at 2022-06-22 08:49:06.428974
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ref_pattern = r'^https?://play\.tv3\.lt/(?:tv3|tv6|3plus|[^/]+)/[^/]+/\d+/'
    ua = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:62.0) Gecko/20100101 Firefox/62.0'
    tvplay_ie = TVPlayHomeIE(url)
    assert tvplay_ie._referer_url == re.match(ref_pattern, url).group(0)
    tvplay_ie = TVPlayHomeIE(url, referer='/'.join(url.split('/', 3)[:3]))
    assert tvplay_ie

# Generated at 2022-06-22 08:49:08.347580
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie is not None

if __name__ == '__main__':
    test_TVPlayHomeIE()

# Generated at 2022-06-22 08:49:11.508027
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE(None, None)
    except Exception:
        pass
    else:
        raise Exception('Failed to trigger exception in constructor of class ViafreeIE')



# Generated at 2022-06-22 08:49:15.089183
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    '''
    This test is not thorough, it only test the constructor of class ViafreeIE.
    :return:
    '''
    via_free_ie = ViafreeIE()
    assert via_free_ie._VALID_URL is not None
