

# Generated at 2022-06-22 08:39:40.019970
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(GoIE())
    if not ie.suitable(url):
        print('Not suitable')
    else:
        ie.extract(url)


# Generated at 2022-06-22 08:39:45.019705
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://tvplay.tv3.lt/aferistai-10047125/'
    expected = '366367'
    assert TVPlayHomeIE._match_id(test_url) == expected, \
        f'url {test_url} does not match expected value {expected}'

# Generated at 2022-06-22 08:39:46.415717
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = "http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true"
    TVPlayIE().suitable(url)


# Generated at 2022-06-22 08:39:47.986736
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.get_geo_bypass_setting() == ViafreeIE._GEO_BYPASS



# Generated at 2022-06-22 08:39:54.613920
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)

    # Success case
    url = "https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/"
    assert ie._match_id(url) == 'cool-d-ga-mehhikosse-10044354'

    # Failure case
    url = "https://tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true"
    assert ie._match_id(url) is None


# Generated at 2022-06-22 08:39:58.586990
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')


# Generated at 2022-06-22 08:39:59.177755
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    pass

# Generated at 2022-06-22 08:40:05.401963
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.suitable(url)
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.IE_DESC == 'TVPlayHome.lv, TVPlay.tv3.lt and other TVPlayHome sites'

# Generated at 2022-06-22 08:40:17.135001
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_IE = ViafreeIE('https://viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert viafree_IE.suitable('https://viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert viafree_IE.suitable('https://viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert viafree_IE.suitable('https://viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-22 08:40:18.313352
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    m = ViafreeIE()

# Generated at 2022-06-22 08:40:38.253112
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()


# Generated at 2022-06-22 08:40:42.515005
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_case import HttpServer

    server = HttpServer()
    def handler(http_url, http_get_request, http_get_response):
        assert 'download/stream/' in http_url
        http_get_response.write(open('tvplay.json').read())

    server.AddHandler(handler)
    server.Start()
    TVPlayIE()._real_extract(server.GetUrl() + '/id')
    server.Stop()


# Generated at 2022-06-22 08:40:50.299894
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay = TVPlayHomeIE('')
    assert tvplay.IE_NAME == 'TVPlayHome'
    assert tvplay._VALID_URL == TVPlayHomeIE._VALID_URL
    assert tvplay.IE_DESC == 'TV3play.lv, TV6play.se, TV3play.ee and Skaties.lv'
    assert tvplay.TVPLAY_URL_TEMPLATE == 'http://www.tvplay.lv/parraides/%s/?autostart=true'
    assert tvplay.IE_DESC == 'TV3play.lv, TV6play.se, TV3play.ee and Skaties.lv'

# Generated at 2022-06-22 08:40:50.899080
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE();



# Generated at 2022-06-22 08:40:55.244086
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test constructor of ViafreeIE.
    """
    instance = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert isinstance(instance, ViafreeIE)
    assert instance._VALID_URL == ViafreeIE._VALID_URL

# Generated at 2022-06-22 08:41:03.031182
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:41:05.271551
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(mock.Mock())
    assert ie is not None


# Generated at 2022-06-22 08:41:19.007458
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == 'https?://(?:www\\.)?(?:viafree|tvplay)\\.(dk|no|ee|se|lv|bg|lt)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-22 08:41:25.735354
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()

    assert ie.suitable(url)
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-22 08:41:30.302794
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvp = TVPlayIE()
    assert tvp.ie_key() == "TVPlayIE"
    assert tvp.ie_name() == "MTG"
    assert tvp.ie_desc() == "MTG services"

# Generated at 2022-06-22 08:42:08.001704
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert isinstance(TVPlayHomeIE(
        TVPlayHomeIE(
            TVPlayHomeIE(
                TVPlayHomeIE()))),
        TVPlayHomeIE)

# Generated at 2022-06-22 08:42:20.374672
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tvplay = ViafreeIE()
    assert tvplay._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert tvplay._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert tvplay._TESTS[0]['info_dict']['id'] == '757786'
    assert tvplay._TESTS[0]['info_dict']['ext'] == 'mp4'

# Generated at 2022-06-22 08:42:21.501285
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE == type(TVPlayIE())


# Generated at 2022-06-22 08:42:29.268598
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    tvplay._initialize_geo_bypass({'countries': ['LV', 'LT', 'EE']})
    assert tvplay._GEO_COUNTRIES == ['LV', 'LT', 'EE']
    tvplay._initialize_geo_bypass(None)
    assert tvplay._GEO_COUNTRIES == []


# Generated at 2022-06-22 08:42:30.225743
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)



# Generated at 2022-06-22 08:42:40.341442
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    expectedResult = {
        'id': '418113',
        'ext': 'mp4',
        'title': 'Kādi ir īri? - Viņas melo labāk',
        'description': 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.',
        'series': 'Viņas melo labāk',
        'season': '2.sezona',
        'season_number': 2,
        'duration': 25,
        'timestamp': 1406097056,
        'upload_date': '20140723',
    }
    tvplay = TVPlayIE()

# Generated at 2022-06-22 08:42:45.963789
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie._VALID_URL == 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'



# Generated at 2022-06-22 08:42:55.342502
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_urls = ['http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1',
                    'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
                    'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2',
                    'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
                    'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5']

# Generated at 2022-06-22 08:42:57.543685
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
        print('Constructor of class TVPlayIE works')
    except:
        print('Cannot construct class TVPlayIE')



# Generated at 2022-06-22 08:43:01.319848
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('mtg', 'mtg')
    assert 'mtg' == TVPlayIE('mtg', 'mtg')._VALID_URL



# Generated at 2022-06-22 08:44:14.733021
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE(), 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.country == 'lt'


# Generated at 2022-06-22 08:44:16.767373
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()
    assert x.IE_NAME.lower() == 'mtg'

# Generated at 2022-06-22 08:44:24.116730
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie1 = ViafreeIE('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie1.country == 'SE'
    assert ie1.url == 'https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    assert ie1.name == 'Viafree'
    assert ie1.__class__.__name__ == 'ViafreeIE'
    assert ie1.nationality == 'SE'
    assert ie1.compat_kwargs == {}
    assert ie1.assoc_webpage == {}
    assert ie1._GEO_BYPASS == False
    assert ie1.country == 'SE'

# Generated at 2022-06-22 08:44:32.726432
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert TVPlayHomeIE.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-22 08:44:33.695440
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj.IE_NAME == 'tvplay:home'


# Generated at 2022-06-22 08:44:45.258336
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    vf = ViafreeIE()
    assert vf.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert vf.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert vf.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

    assert not vf.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113')

# Generated at 2022-06-22 08:44:47.380477
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable(ViafreeIE._VALID_URL) == True

# Generated at 2022-06-22 08:44:49.909771
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, 'http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie

# Generated at 2022-06-22 08:44:53.748506
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    meta = {
        'view_count': 123,
        'description': 'test description',
        'title': 'test title',
    }
    ie = ViafreeIE(meta)
    assert ie.meta == meta



# Generated at 2022-06-22 08:44:55.641513
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome = TVPlayHomeIE('')
    assert hasattr(tvplayhome, '_download_json')



# Generated at 2022-06-22 08:48:16.582965
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE().suitable('mtg:668658'), bool)
    assert not ViafreeIE().suitable('mtg:668658')

# Generated at 2022-06-22 08:48:21.209972
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    with open('test/testdata/playapi_v3_videos_418113.json','r') as f:
        video = f.read()
    with open('test/testdata/playapi_v3_videos_stream_418113.json','r') as f:
        streams = f.read()

    ie = TVPlayIE()
    ie._download_json = lambda url, video_id, note='', errnote='', fatal=True, data=None: video
    ie._download_json = lambda url, video_id, note='', errnote='', fatal=True, data=None: streams

    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'

    video_result = ie.extract(url)


# Generated at 2022-06-22 08:48:32.581100
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true';
    t = TVPlayIE();

# Generated at 2022-06-22 08:48:43.483439
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("test_TVPlayIE")
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:48:50.459710
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafreeIE.__name__ == 'Viafree'
    assert viafreeIE.IE_NAME == 'viafree'
    assert viafreeIE.SUCCESS == True


# Generated at 2022-06-22 08:48:56.429067
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Note: the following URL is not an official example;
    # it does not need to work in any future version of
    # this test. It is only used to verify that the
    # constructor can be invoked at all.
    #
    # It *should* be a video that TVPlayHomeIE can handle.
    url = 'https://play.tv3.lt/aferistai-10047125'
    TVPlayHomeIE(url)

# Generated at 2022-06-22 08:49:07.778630
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def get_TVPlayIE():
        from youtube_dl.extractor import gen_extractors
        return [e for e in gen_extractors() if e.IE_NAME == 'tvplay'][0]
    TVPlayIE = get_TVPlayIE()
    # Check if there is a test case defined for this extractor
    result = TVPlayIE._TESTS
    if result:
        for elem in result:
            assert 'url' in elem, 'URL is needed for unit tests'
            assert 'info_dict' in elem, 'info_dict is needed for unit tests'
        print('Unit Test is successful!')
    else:
        raise AssertionError('Unit test not defined')



# Generated at 2022-06-22 08:49:08.804327
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    infoExtractor = ViafreeIE(None)
    assert infoExtractor.IE_NAME == 'Viafree'


# Generated at 2022-06-22 08:49:13.677894
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

# Generated at 2022-06-22 08:49:25.038044
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    field = '_VALID_URL'