

# Generated at 2022-06-22 08:39:35.376560
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('mtg:418113') == TVPlayIE

# Unit tests for extractor of class TVPlayIE
# This test doesn't check neither streams nor subtitles

# Generated at 2022-06-22 08:39:46.912183
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:39:52.018020
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Prepare for testing
    unit = ViafreeIE()
    assert unit.suitable('http://www.viplay.se/program/husraddarna/395385?autostart=true')
    assert not unit.suitable('http://play.novatv.bg/programi/predi-na-ponedelnik/760022?autostart=true')

# Generated at 2022-06-22 08:40:02.154039
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert not ie.suitable('http://www.tv3play.se/program/vinas-melo-labak')
    assert not ie.suitable('http://tvplay.tv3.ee/sisu/cool-d-ga-mehhikosse/10044354')

# Generated at 2022-06-22 08:40:06.695070
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:18.398348
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()
    assert x.IE_NAME == 'mtg'
    assert x.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:40:23.568749
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak-10280317'
    tvplay = TVPlayHomeIE(url)
    # we don't want to test this in the real method
    if not tvplay._downloader:
        return
    assert tvplay.match(url) == True



# Generated at 2022-06-22 08:40:24.712846
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')


# Generated at 2022-06-22 08:40:35.286247
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test 1: InfoExtractor without GeoRestriction for TVPlay (mtg)
    viafree_ie = ViafreeIE('mtg', 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree_ie.country == 'dk'
    assert viafree_ie._GEO_BYPASS

    # Test 2: InfoExtractor with GeoRestriction for TVPlay (mtg)
    viafree_ie = ViafreeIE('mtg', 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert viafree_ie.country == 'se'
    assert not viafree_ie._GEO_BYPASS

    # Test 3: InfoExtractor without GeoRestriction for

# Generated at 2022-06-22 08:40:41.468911
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    assert instance.IE_NAME == 'tv3play:home' # Check IE name
    assert instance.IE_DESC == 'TV3Play: Home' # Check IE description
    assert instance.VALID_URL != '' # Check if VALID_URL is empty
    assert instance._TESTS != [] # Check if unit tests exists


# Generated at 2022-06-22 08:41:21.292915
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE
    """
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie.IE_DESC == 'MTG services'
    assert tvplay_ie._VALID_URL == TVPlayIE._VALID_URL
    assert tvplay_ie._TESTS == TVPlayIE._TESTS

# Generated at 2022-06-22 08:41:31.381563
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable(
        'http://viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') is True
    assert viafree_ie.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true') is True

    # Not supported yet
    assert ViafreeIE.suitable('http://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true') is False
    assert ViafreeIE.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/764300?autostart=true') is False

# Generated at 2022-06-22 08:41:39.406525
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:41:47.434934
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.NAME == 'tvplayhome'
    assert ie.IE_NAME == 'tvplayhome'
    assert ie.IE_DESC == 'TVPlay Home'
    assert ie._VALID_URL == ie.VALID_URL == \
        r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:41:49.368957
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable(None)

# Generated at 2022-06-22 08:41:57.607468
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert viafreeIE_instance.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafreeIE_instance.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert viafreeIE_instance.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-22 08:42:00.209707
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(TVPlayIE.IE_NAME)



# Generated at 2022-06-22 08:42:10.045297
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg = TVPlayIE()
    assert mtg._VALID_URL == r'^(?:http(?:s)?:\/\/)?(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:\/parraides)?|(?:tv3play|play\.tv3)\.lt(?:\/programos)?|tv3play(?:\.tv3)?\.ee\/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se\/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)\/programmer|play\.nova(?:tv)?\.bg\/programi)\/(?:[^\/]+\/)+?(?P<id>\d+)$'

# Generated at 2022-06-22 08:42:21.535609
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('')
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-22 08:42:33.204278
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:43:45.599116
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    constructor = TVPlayIE.__dict__['IE_NAME']
    instance = TVPlayIE()
    assert constructor == instance.ie_key()



# Generated at 2022-06-22 08:43:51.373162
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-22 08:43:57.916872
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Create an instance of class ViafreeIE
    viafreeIE = ViafreeIE()
    url = "http://play.tv4play.se/program/husraddarna/395385" #a valid url
    #testing the suitable function
    assert viafreeIE.suitable(url) == True #the url should be suitable
    #testing if the url has been extracted
    assert viafreeIE._match_id(url) == "395385"

# Generated at 2022-06-22 08:43:59.599579
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhomeie = TVPlayHomeIE()
    assert tvplayhomeie is not None



# Generated at 2022-06-22 08:44:03.575498
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if(not isinstance(ViafreeIE(), TVPlayIE)):
        raise Exception("ViafreeIE is not a derived of class TVPlayIE. The constructor of ViafreeIE is broken.")

# Generated at 2022-06-22 08:44:05.130931
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.country is None

# Generated at 2022-06-22 08:44:12.535236
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Cheks whether constructor with URLs from ViafreeIE._TESTS raises exceptions
    # https://docs.pytest.org/en/latest/example/parametrize.html#a-quick-port-of-testscenarios
    @pytest.mark.parametrize('url', [
        pytest.param(url, id=url)
        for url in
        set(test['url'] for test in ViafreeIE._TESTS)
    ])
    def test_viafreeie_instance(url):
        ViafreeIE(url)

# Generated at 2022-06-22 08:44:20.674595
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_api_mtg_tv3_se import SampleVideos

    base_url = 'http://www.viafree.dk/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-2'

    ie = ViafreeIE()

# Generated at 2022-06-22 08:44:23.554648
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    TVPlayIE().suitable(url)

# Generated at 2022-06-22 08:44:24.595224
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie

# Generated at 2022-06-22 08:47:39.260587
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from construct import Container

    import pytest
    from ytdl.util import update_url_query

    from .viafreetvplay import ViafreeIE, TVPlayIE

    def testName(self):
        name = self.__class__.__name__

        if not re.match(r'[A-Z][\w0-9]*', name):
            raise AssertionError('Invalid name: ' + name)

    @staticmethod
    def build_test_container(test_dict):
        test = test_dict.copy()
        container = Container(
            test_dict=test,
            testName=testName,
            test_id=test.get('test_id', '0'),
            test_url=test.get('test_url', '')
        )

# Generated at 2022-06-22 08:47:46.395768
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    video = TVPlayIE()._real_extract(url)
    assert video['id'] == '409229'
    assert video['title'] == 'Moterys meluoja geriau'
    assert video['age_limit'] == 0
    assert video['duration'] == 1330
    assert len(video['subtitles']) == 0
    assert len(video['formats']) == 2



# Generated at 2022-06-22 08:47:50.280465
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    vf_class = viafree_ie.constructor()
    assert vf_class

    # Test if the vf_class instance is the same as the ViafreeIE class
    assert isinstance(vf_class, ViafreeIE)

# Generated at 2022-06-22 08:47:53.791345
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Verify that ViafreeIE inherits from InfoExtractor
    ie = viafree.ViafreeIE()
    assert ie.suitable('http://viafree.no')
    assert ie.IE_NAME == viafree.ViafreeIE.IE_NAME

# Generated at 2022-06-22 08:47:56.376477
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-22 08:47:58.453774
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert isinstance(ie, MTGTVPlayIE)



# Generated at 2022-06-22 08:48:09.571888
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    expected = {
        'id': '418113',
        'ext': 'mp4',
        'title': 'Kādi ir īri? - Viņas melo labāk',
        'description': 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.',
        'series': 'Viņas melo labāk',
        'season': '2.sezona',
        'season_number': 2,
        'duration': 25,
        'timestamp': 1406097056,
        'upload_date': '20140723',
    }
    Video = TVPlayIE().get_info('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-22 08:48:19.139758
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_html import fake_urlopen
    import json

    with fake_urlopen(
            text='''<html><head><title>Viafree for program underholdning det-beste-vorspielet sesong-2 episode-1</title></head></html>'''
    ) as mock:
        ie = ViafreeIE({'_downloader': {'troubleshoot': False}, 'test': True})
        assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == True

        ie.download = mock


# Generated at 2022-06-22 08:48:31.289745
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert TVPlayHomeIE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert TVPlayHomeIE.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/")
    assert TVPlayHomeIE.suitable("https://play.tv3.lt/aferistai-10047125")
    assert TVPlayHomeIE.suitable("https://tv3play.skaties.lv/vinas-melo-labak-10280317")

# Generated at 2022-06-22 08:48:37.153708
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')