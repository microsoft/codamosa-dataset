

# Generated at 2022-06-22 08:39:41.159743
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Run this to test the constructor of class ViafreeIE.
    """
    video_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    viafree = ViafreeIE(FakeYDL())
    viafree.suitable(video_url)
    viafree._real_extract(video_url)


# Generated at 2022-06-22 08:39:50.890280
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert isinstance(
        TVPlayHomeIE('http://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'),
        TVPlayHomeIE)
    assert isinstance(TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317'), TVPlayHomeIE)
    assert isinstance(TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'), TVPlayHomeIE)



# Generated at 2022-06-22 08:40:02.316282
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor = type('ViafreeIE', (ViafreeIE,), dict(
        _VALID_URL=ViafreeIE._VALID_URL,
        _TESTS=ViafreeIE._TESTS,
        _GEO_COUNTRIES=ViafreeIE._GEO_COUNTRIES,
        _GEO_BYPASS=ViafreeIE._GEO_BYPASS,
    ))
    ie = constructor()
    assert ie._VALID_URL == ViafreeIE._VALID_URL
    assert ie._TESTS == ViafreeIE._TESTS
    assert ie._GEO_COUNTRIES == ViafreeIE._GEO_COUNTRIES
    assert ie._GEO_BYPASS == ViafreeIE._GEO_BYPASS



# Generated at 2022-06-22 08:40:04.967194
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE()._extract_url(
        'https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')



# Generated at 2022-06-22 08:40:11.959757
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_ViafreeIE = ViafreeIE()
    assert(test_ViafreeIE.suitable('http://www.viafree.no') is False)
    assert(test_ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898') is False)

# Generated at 2022-06-22 08:40:16.556344
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'

    # Calling ViafreeIE constructor
    viafree = ViafreeIE(IE_NAME, {})

    # Test result of method suitable
    assert viafree._TEST.suitable(url), viafree._TEST.suitable(url)


# Generated at 2022-06-22 08:40:17.738471
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(ValueError):
        ViafreeIE()



# Generated at 2022-06-22 08:40:19.114279
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay == TVPlayIE.ie_key()


# Generated at 2022-06-22 08:40:29.877946
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:40:32.552289
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('dk')
    assert ie.suitable(None) is False
    assert ie.geo_countries is None

# Generated at 2022-06-22 08:40:52.042759
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()

# Generated at 2022-06-22 08:40:57.161232
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable(ie.IE_NAME, 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2') is True
    assert ie.suitable('TVPlayIE', 'http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true') is True

# Generated at 2022-06-22 08:40:59.308826
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'))



# Generated at 2022-06-22 08:41:09.568569
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import unittest
    class TestTVPlayIE(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super(TestTVPlayIE, self).__init__(*args, **kwargs)
            self.ie = TVPlayIE()
        def test_tvplay_url(self):
            self.assertEqual(
                self.ie._match_id(
                    "http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true"),
                "418113")
            self.assertEqual(
                self.ie._match_id(
                    "http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true"),
                "409229")
           

# Generated at 2022-06-22 08:41:14.375372
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-22 08:41:22.099337
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # checking of ViafreeIE is created with success
    ie = ViafreeIE()
    # check if attribute _VALID_URL is set
    assert ie._VALID_URL
    # check if attribute name is set
    assert ie.name
    # check if attribute ie_key is set
    assert ie.ie_key
    # check if attribute ie_key is set
    assert ie.ie_key
    # check if attribute IE is set
    assert ie.IE
    # check if attribute COUNTRIES is set
    assert ie.COUNTRIES
    # check if attribute URL_CANONICALIZER is set
    assert ie.URL_CANONICALIZER



# Generated at 2022-06-22 08:41:29.422530
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert_true(ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert_true(ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    assert_true(ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'))

# Generated at 2022-06-22 08:41:32.502464
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-22 08:41:45.054176
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_ie = TVPlayHomeIE()
    tvplayhome_ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tvplayhome_ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    tvplayhome_ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    tvplayhome_ie.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-22 08:41:45.742283
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE();

# Generated at 2022-06-22 08:42:10.560141
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.constructor(TVPlayIE.IE_NAME, TVPlayIE._VALID_URL)
    ie.constructor('MTGPlayPrinter')
    ie.constructor('MTGPlayPrinter', ie.IE_NAME, TVPlayIE._VALID_URL)
    ie.constructor('MTGPlayPrinter', ie.IE_NAME, TVPlayIE._VALID_URL, 'MTG')
    ie.constructor('MTGPlayPrinter', ie.IE_NAME, TVPlayIE._VALID_URL, 'MTG', 'IE for MTG services')



# Generated at 2022-06-22 08:42:22.031085
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(ValueError) as excinfo:
        ie = TVPlayHomeIE()
        pytest.fail()
    assert 'Invalid country' in str(excinfo.value)
    ie = TVPlayHomeIE(country='ee')
    assert ie._country == 'ee'
    assert ie.GEO_COUNTRIES == ['EE']
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL.replace('(?:tv3?)?', 'tv3')
    assert ie._NETRC_MACHINE == 'tv3'
    ie = TVPlayHomeIE(country='lv')
    assert ie._country == 'lv'
    assert ie.GEO_COUNTRIES == ['LV']

# Generated at 2022-06-22 08:42:30.345467
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # Test that the regex is valid
    assert re.compile(TVPlayIE._VALID_URL).match('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    # Test that the constructor works
    TVPlayIE('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-22 08:42:31.262377
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf_ie = ViafreeIE()

# Generated at 2022-06-22 08:42:35.541463
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert( IE == False )

# Generated at 2022-06-22 08:42:47.195311
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """ test for constructor of class TVPlayIE """
    tvplay_test = TVPlayIE()

# Generated at 2022-06-22 08:42:49.663158
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """ Unit tests for construction of class TVPlayIE. """
    assert type(TVPlayIE({})) is TVPlayIE



# Generated at 2022-06-22 08:42:56.312369
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # This test ensures that the class has a constructor that takes
    # exactly one (1) argument. If it doesn't it probably means that
    # someone forgot to call super or something.
    test_class = ViafreeIE(url='http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert test_class is not None



# Generated at 2022-06-22 08:43:08.332482
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert tvplay_ie._VALID_URL == r'(?x)tvplay(?:\.skaties)?\.lv(?:/parraides)?/(?P<id>\d+)'

# Generated at 2022-06-22 08:43:09.235931
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Instantiate test object:
    TVPlayIE()._test_constructor()


# Generated at 2022-06-22 08:43:32.021319
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    cls = TVPlayHomeIE
    # Smoke test
    instance = cls()
    # Test whether the regex matches a given example
    assert cls._VALID_URL.match("https://tvplay.tv3.lt/aferistai-10047125") is not None


# Generated at 2022-06-22 08:43:36.073319
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.name == 'mtg'
    assert ie.ie_key() == 'mtg'
    assert ie.summary != None


# Generated at 2022-06-22 08:43:47.835828
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    
    # Testing TVPlayHomeIE (full flow)
    args = []
    for url in TVPlayHomeIE._TESTS[:-1]:
        args.append(url)
    tvplay_unit_test(args)

    # Testing _match_id()
    args = []
    for url in TVPlayHomeIE._TESTS[:-1]:
        args.append(url)
    tvplay_unit_test(args)

    # Testing _extract_m3u8_formats()
    args = []
    for url in TVPlayHomeIE._TESTS[:-1]:
        args.append(url)
    tvplay_unit_test(args)

    # Testing TVPlayHomeIE with no videos
    args = [[]]
    tvplay_unit_test(args)


# Generated at 2022-06-22 08:43:59.510921
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import pytest
    from ..utils import fake_httpd

    _http_server = None

    def setup():
        global _http_server
        _http_server = fake_httpd.HTTPDServer()
        _http_server.serve_content(bytes_io=b'''{
            "title": "Zombie Ninja Pro-Am",
            "streams": {
                "medium": "http://example.com/test.mp4"
            },
            "duration": 10,
            "views": {
                "total": 1
            }
        }''', content_type='application/json')
        _http_server.start()
        return _http_server

    def teardown():
        _http_server.stop()


# Generated at 2022-06-22 08:44:02.826659
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-22 08:44:05.087484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE()
# End of unit test for constructor of class TVPlayHomeIE



# Generated at 2022-06-22 08:44:14.440157
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # http://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/
    asset_id = '10044354'
    url = 'https://tvplay.tv3.lt/aferistai-10047125'
    tvph = TVPlayHomeIE(params=dict(url=url, asset_id=asset_id))
    assert tvph.asset_id == asset_id
    assert url == tvph._VALID_URL % {'id': asset_id}
    assert tvph._downloader.params.get('cookiefile') is None



# Generated at 2022-06-22 08:44:24.538275
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636')
    TVPlayIE('http://www.tv8play.se/program/antikjakten/282756')

# Generated at 2022-06-22 08:44:26.800349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie2 = ViafreeIE()
    assert ie._VALID_URL == ie2._VALID_URL


# Generated at 2022-06-22 08:44:31.268394
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test constructor with country parameter
    """
    expected_country = 'dk'
    actual_country = ViafreeIE(expected_country)._GEO_COUNTRY
    assert expected_country == actual_country, 'Expected country: {0}, actual country: {1}'.format(expected_country, actual_country)


# Generated at 2022-06-22 08:45:06.895692
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    m_url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    ie = ViafreeIE.suitable(url)
    ie_m = TVPlayIE.suitable(m_url)
    assert ie == True
    assert ie_m == True

# Generated at 2022-06-22 08:45:15.485043
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ie.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-22 08:45:16.550339
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie is not None


# Generated at 2022-06-22 08:45:27.724978
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # test for same regex when geo_country is None
    ie._VALID_URL = ie._VALID_URL.replace(r'(?:\.([a-z]{2}))?', r'')

# Generated at 2022-06-22 08:45:37.674855
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()

# Generated at 2022-06-22 08:45:44.151801
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Check that TVPlayHomeIE constructor works as intended"""
    url = 'https://play.tv3.no/'
    e = TVPlayHomeIE(url)
    assert e.url == url
    assert e.country == 'no'
    assert e.playlist_id is None



# Generated at 2022-06-22 08:45:45.931150
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()

    assertViafreeIE(viafree_ie)


# Generated at 2022-06-22 08:45:51.303342
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    result = TVPlayIE()
    assert hasattr(result, '_VALID_URL')
    assert hasattr(result, 'IE_NAME')
    assert hasattr(result, '_TESTS')

# Unit tests for instance of class TVPlayIE

# Generated at 2022-06-22 08:45:53.304135
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(AssertionError):
        TVPlayHomeIE('http://mtgx.tv/')

# Generated at 2022-06-22 08:45:54.433054
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-22 08:46:49.793048
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-22 08:46:51.411557
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor = type(ViafreeIE)
    assert issubclass(constructor, InfoExtractor)


# Generated at 2022-06-22 08:46:57.834741
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:47:07.742748
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .vimeo import VimeoIE
    from .youtube import YoutubeIE
    from .viaplay import ViaplayIE
    from .drtv import DRTVIE
    from .tv4 import TV4PlayIE
    from .tv3play import TV3PlayIE
    from .tv6play import TV6PlayIE
    from .sbs import SBSIE
    from .svt import SVTIE
    from .urplay import URPlayIE
    from .nrk import NRKTVIE
    from .tvplay import TVPlayIE
    from .mtg import MTGIE
    from .mixcloud import MixcloudIE

    # TODO: Move to test_youtube when _get_available_subtitles is implemented
    assert YoutubeIE.suitable("http://tv.viarail.ca/video/2365033679")
    assert YoutubeIE.suitable

# Generated at 2022-06-22 08:47:09.276455
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    a = ViafreeIE()
    assert a is not None


# Generated at 2022-06-22 08:47:19.574378
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    p = TVPlayIE()
    assert p.IE_NAME == 'mtg'
    assert p.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:47:21.765895
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL

# Generated at 2022-06-22 08:47:31.802613
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .. import iqiyi, youku, youtube
    ie = TVPlayIE({
    })
    assert ie.file_downloader_factory({
        'f4m': iqiyi.IQIYIE,
        'm3u8': youtube.YoutubeIE,
        'flv': youku.YoukuIE
    })
    assert ie.geo_verification_headers()
    ie.geo_bypass({'countries': ['lv']})
    assert ie.geo_verification_headers()

# Generated at 2022-06-22 08:47:32.543582
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-22 08:47:34.359694
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-22 08:48:35.093852
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test for constructor of class TVPlayHomeIE."""
    tvplayhomeie = TVPlayHomeIE()
    assert tvplayhomeie is not None

# Generated at 2022-06-22 08:48:40.289632
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:48:48.433280
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if not sys.argv[1:]:
        sys.exit('usage: %s <test-video-url>' % sys.argv[0])
    url = sys.argv[1]
    extract_info = TVPlayHomeIE().extract(url)
    print('Video Id: ', extract_info['id'])
    print('Video Title: ', extract_info['title'])
    print('Video Description: ', extract_info['description'])
    print('Video Series: ', extract_info['series'])
    print('Video Season: ', extract_info['season'])
    print('Video Season Number: ', extract_info['season_number'])
    print('Video Episode: ', extract_info['episode'])
    print('Video Episode Number: ', extract_info['episode_number'])

# Generated at 2022-06-22 08:48:49.980876
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:49:00.300394
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:49:04.990939
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # fails when requests>=2.18.0
    ie = TVPlayIE()
    ie.extract('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')



# Generated at 2022-06-22 08:49:15.014662
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE
    """
    t = TVPlayIE()