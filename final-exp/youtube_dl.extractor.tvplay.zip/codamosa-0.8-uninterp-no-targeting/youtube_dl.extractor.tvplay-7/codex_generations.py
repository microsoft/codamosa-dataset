

# Generated at 2022-06-22 08:39:36.624825
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    ie = ViafreeIE(mock.Mock(), url)
    assert ie._VALID_URL == 'https?://www\.viafree\.se/(?:program|programmer)/[^?#]*'

# Generated at 2022-06-22 08:39:39.856405
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test exception
    assert ViafreeIE.suitable('http://tvplay.tv3.lt/1') is False


# Generated at 2022-06-22 08:39:51.829154
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    fake_site = 'http://fake-tvplay.skaties.lv/'

    def fake_urljoin(base, path):
        return base + path.lstrip('/')

    with patch('%s._real_initialize' % __name__) as m:
        with patch('%s.TVPlayHomeIE._download_json' % __name__) as download_json:
            m.side_effect = lambda x: (x, x.url)
            download_json.return_value = {}
            ie = TVPlayHomeIE(fake_site)
            assert ie.urls_re == ie.regex
            assert not ie._GEO_BYPASS
            assert ie.IE_NAME == ie.__class__.__name__
            assert ie.BROWSER_AGE_LIMIT == 18
            assert ie.IE

# Generated at 2022-06-22 08:40:01.382394
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    e = TVPlayIE()

# Generated at 2022-06-22 08:40:12.862891
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test variant of ViafreeIE
    info_extractor = ViafreeIE()
    # Test for private method of ViafreeIE class
    res = info_extractor._real_extract('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert res['title'] == 'Det beste vorspielet - Sesong 2 - Episode 1'
    # Test for private method of ViafreeIE class
    res1 = info_extractor._real_extract('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert res1['title'] == 'I like Radio live'
    # Test for private method of ViafreeIE class
    res2 = info_

# Generated at 2022-06-22 08:40:22.404120
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert not t.suitable('http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert t.suitable('https://play.tv3.lt/aferistai-10047125')
    assert not t.suitable('http://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-22 08:40:26.044540
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Get info on a video
    tvplay = TVPlayIE()
    tvplay.extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')



# Generated at 2022-06-22 08:40:28.449198
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == True

# Generated at 2022-06-22 08:40:38.018871
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    inst = TVPlayIE()
    assert inst.__name__ == 'TVPlay'
    assert inst.IE_NAME == 'mtg'
    assert inst.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:40:39.616227
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Make sure that we create the IE with the constructor
    ie = TVPlayIE('TVPlay', {})
    assert(ie)


# Generated at 2022-06-22 08:41:02.974725
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_ie = TVPlayHomeIE()
    video_id = '366367'
    video_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    asset = tvplay_home_ie._download_json(
        urljoin(video_url, '/sb/public/asset/' + video_id), video_id)
    # TVPlayHomeIE._real_extract method is protected, hence need to use _test_extract method
    tvplay_home_ie._test_extract(video_url, asset)

# Generated at 2022-06-22 08:41:06.397760
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url_valid = TVPlayHomeIE._VALID_URL
    test_url_invalid = 'https://tvplay.tv3.lt/demo-10047125/'


# Generated at 2022-06-22 08:41:19.131060
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:41:21.298831
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-22 08:41:22.697991
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl.extractor.tvplay import TVPlayHomeIE
    assert TVPlayHomeIE != None



# Generated at 2022-06-22 08:41:27.844967
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    # Test for expected behavior of each URL
    for test in instance._TESTS:
        url = test['url']
        match = instance._VALID_URL.match(url)
        # Test for no match of each invalid URL
        for bad_url in instance._BAD_URL_TEST:
            assert not match, 'Invalid URL: %s' % bad_url
        # Test for match of each valid URL
        assert match, 'Valid URL: %s' % url


# Generated at 2022-06-22 08:41:37.815266
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        IE_NAME = 'tvplayhome'
        _TESTS = []

    ie = TestTVPlayHomeIE(
        'http://tv3play.tv3.lt/change-a-life/change-a-life-10089317/',
        'http://tv3play.tv3.lt/change-a-life/change-a-life-10089317/')
    assert ie._match_id('https://tvplay.tv3.lt/elu-muutub/elu-muutub-10065972') == '10065972'
    assert ie._match_id('https://play.tv3.lt/elu-muutub-10065972') == '10065972'

# Generated at 2022-06-22 08:41:46.792635
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info_extractor = ViafreeIE()

    assert info_extractor._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

    assert info_extractor._TESTS[1]['url'] == 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    assert info_extractor._TESTS[1]['only_matching'] == True

    # Test geo_bypassing

# Generated at 2022-06-22 08:41:48.002975
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable(None)



# Generated at 2022-06-22 08:41:57.216953
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://playapi.mtgx.tv/v3/videos/757786'
    ie = ViafreeIE()
    ie.geo_verification_headers = MagicMock(return_value={})
    try:
        ie._real_extract(url)
    except ExtractorError as e:
        if isinstance(e.cause, compat_HTTPError) and e.cause.code == 403:
            assert 'due to copyright reasons' in e.msg
            print('passed test for constructor of class ViafreeIE')
        else:
            raise e
    else:
        raise Exception('class ViafreeIE not geo-restricted')



# Generated at 2022-06-22 08:42:25.422215
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.suitable('https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-22 08:42:27.716684
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.geo_verification_headers() == {'x-geoip-location': 'US:NY'}



# Generated at 2022-06-22 08:42:35.027103
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:42:43.916300
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert (ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL)
    assert (ViafreeIE()._TESTS == ViafreeIE._TESTS)
    assert (ViafreeIE().suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') == True)
    assert (ViafreeIE().suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') == False)



# Generated at 2022-06-22 08:42:44.654711
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE

# Generated at 2022-06-22 08:42:51.051293
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    viafree_ie = ViafreeIE(url)
    assert isinstance(viafree_ie, ViafreeIE)
    assert viafree_ie._VALID_URL == ViafreeIE._VALID_URL
    assert viafree_ie._GEO_BYPASS == ViafreeIE._GEO_BYPASS


# Generated at 2022-06-22 08:42:52.717615
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    instance._assert_valid_url(instance._VALID_URL, instance.IE_NAME)

# Generated at 2022-06-22 08:42:55.383024
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    inst = TVPlayIE()
    assert inst._valid_url('mtg:418113')
    assert inst._valid_url('mtg:418113&format=mp4-hls-medium')

# Generated at 2022-06-22 08:42:55.981053
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass



# Generated at 2022-06-22 08:43:08.337201
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:43:52.739002
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:44:02.476741
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')


# Generated at 2022-06-22 08:44:08.434736
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()

    assert instance.suitable((
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    )) == False

    assert instance.suitable((
        'http://viafree.se/program/reality/paradise-hotel/saeson-7/episode-5'
    )) == True

# Generated at 2022-06-22 08:44:11.021321
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.suitable == (lambda x: False if TVPlayIE.suitable(x) else super(ViafreeIE, viafree).suitable(x))

# Generated at 2022-06-22 08:44:21.862299
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:44:26.240243
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test URL with Viaplay
    url = 'http://viaplay.se/tv/game-of-thrones'
    assert ViafreeIE.suitable(url) is False
    assert ViaplayIE.suitable(url) is True

    # Test URL with TVPlay
    url = 'http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true'
    assert ViafreeIE.suitable(url) is False
    assert TVPlayIE.suitable(url) is True


# Generated at 2022-06-22 08:44:34.400605
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable("https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    ie.suitable("https://www.mtgx.tv/vid-5")
    ie.suitable("http://www.tv3.se/mad-i-vildmarken/episoder/s1e1-v-44-mtg")
    ie.suitable("https://play.df.se/program/reality/paradise-hotel/sasong-14/avsnitt-11")
    ie.suitable("http://www.tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true")

# Generated at 2022-06-22 08:44:45.808363
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.constructor_test('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    ie.constructor_test('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    ie.constructor_test('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    ie.constructor_test('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-22 08:44:54.791222
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://play.skaties.lv/vinas-melo-labak-10280317/')
    assert ie.country == 'lv'
    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/')
    assert ie.country == 'ee'
    ie = TVPlayHomeIE('https://play.tv3.lt/vinas-melo-labak-10280317/')
    assert ie.country == 'lt'
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/vinas-melo-labak-10280317/')
    assert ie.country == 'lt'

# Generated at 2022-06-22 08:45:04.834729
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from io import StringIO
    from tests.helper import _assert_raises_regexp

    # URL not supported
    _assert_raises_regexp(
        ExtractorError, 'URL not supported',
        ViafreeIE, 'some invalid URL')

    # URL not supported
    _assert_raises_regexp(
        ExtractorError, 'URL not supported',
        ViafreeIE, 'https://play.viaplay.se/film/eat-pray-love-2010')

    # URL not supported
    _assert_raises_regexp(
        ExtractorError, 'URL not supported',
        ViafreeIE, 'https://tv.viaplay.se/serier/the-flash-2014')

    # URL not supported

# Generated at 2022-06-22 08:46:34.266835
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)


# Generated at 2022-06-22 08:46:45.935914
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:46:53.847830
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\\.(?:tv3\\.lt|skaties\\.lv|tv3\\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)'
    assert ie._NETRC_MACHINE == 'tv3'
    assert ie._GEO_COUNTRIES == ['LV', 'EE', 'LT']


# Generated at 2022-06-22 08:47:04.878516
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    cls = TVPlayHomeIE
    regexp = cls._VALID_URL
    regexp = regexp.replace('(?:tv3?)?', '(?P<tv3>tv3)?')
    regexp = regexp.replace('(?:[^/]+/)*', '(?P<site_part>[^/]+/)?')

    match1 = re.match(regexp, 'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    match2 = re.match(regexp, 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    match3 = re.match(regexp, 'https://play.tv3.lt/aferistai-10047125')


# Generated at 2022-06-22 08:47:16.657535
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

    assert ie._VALID_URL
    assert re.match(ie._VALID_URL, 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113')
    assert re.match(ie._VALID_URL, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')
    assert re.match(ie._VALID_URL, 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551')

# Generated at 2022-06-22 08:47:23.549556
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == ViafreeIE._VALID_URL
    assert ie._TESTS == ViafreeIE._TESTS
    assert ie._GEO_BYPASS == ViafreeIE._GEO_BYPASS
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-22 08:47:32.802115
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert instance._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'

# Generated at 2022-06-22 08:47:34.718090
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'



# Generated at 2022-06-22 08:47:42.605021
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE('TVPlayHome', 'tvplay.skaties.lv')

    assert instance.name is 'TVPlayHome'
    assert instance._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:47:50.454430
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("http://example.org/")
    assert(ie.url_result("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/") is not None)
    assert(ie.url_result("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/") is not None)
    assert(ie.url_result("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/") is not None)
    assert(ie.url_result("https://play.tv3.lt/aferistai-10047125") is not None)