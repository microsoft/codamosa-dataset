

# Generated at 2022-06-22 08:39:43.355882
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_utils import TestIE
    from .youtube import YoutubeIE


# Generated at 2022-06-22 08:39:51.929477
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable(ie._VALID_URL)
    assert ie.suitable(ie.IE_NAME) is False
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tv3play.tv3.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://play.tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354')


# Generated at 2022-06-22 08:40:01.169946
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # Test valid URLs
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # Test invalid URLs
    assert not ie.suitable('https://tvplay.tv3.lt/aferistai-10047125')
    assert not ie.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-22 08:40:12.608764
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:40:14.480198
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-22 08:40:15.659506
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    assert True

# Generated at 2022-06-22 08:40:18.140488
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable(ViafreeIE._TESTS[0]['url'])
    ie.extract(ViafreeIE._TESTS[0]['url'])



# Generated at 2022-06-22 08:40:21.960966
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.__class__ == TVPlayHomeIE

# Generated at 2022-06-22 08:40:33.691039
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    ie.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    ie.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    ie.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')

# Generated at 2022-06-22 08:40:40.958325
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    con = ViafreeIE()
    assert con.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert con.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert not con.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    assert not con.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-22 08:41:04.325742
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._match_id('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == '10280317'


# Generated at 2022-06-22 08:41:14.711503
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = "http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1"
    viafreeIE = ViafreeIE(url)
    # test for _VALID_URL
    match = re.match(viafreeIE._VALID_URL, url)
    assert match
    # test for _download_json, assert that the class is initialized with a content data
    assert viafreeIE.content_data['_embedded']['viafreeBlocks'][0]['id'] > 0

# Generated at 2022-06-22 08:41:24.695367
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    # Assert that TVPlayHomeIE handles the URL with minified format
    # for skaties.lv, tv3.lt and tv3.ee
    instance._real_extract('https://tv3.ee/cool-d-ga-mehhikosse-10044354')
    instance._real_extract('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    instance._real_extract('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    instance._real_extract('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-22 08:41:31.592560
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('asd')
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') is True


# Generated at 2022-06-22 08:41:44.101297
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE({})
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert re.search(ie._VALID_URL, 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie._TESTS[0]['url'] == 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert ie._TESTS[0]['md5'] == 'a1612fe0849455423ad8718fe049be21'
    assert ie._TESTS[0]['info_dict']['id'] == '418113'

# Generated at 2022-06-22 08:41:47.905425
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test case for correct implementation of ViafreeIE
    video = ViafreeIE()
    assert video._VALID_URL is not None
    assert video._TESTS is not None
    assert video._GEO_BYPASS is not None



# Generated at 2022-06-22 08:41:59.057832
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_utils import TestInfoExtractor

    class TestViafreeIE(TestInfoExtractor):
        IE_DESC = 'Viafree'

        def test_error_missing_program_path(self):
            testcases = [
                'https://www.viafree.dk/programmer?q=Gandhi',
                'https://www.viafree.dk/nyheder',
                'https://www.viafree.dk/fordele'
            ]
            for testcase in testcases:
                self.assertIs(has_external_subtitles(testcase), False)


# Generated at 2022-06-22 08:42:04.266366
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.get_title() == 'TVPlayHome'
    assert ie.extractors[0]['IE'] == TVPlayHomeIE.__name__
    assert ie.extractors[0]['pattern'] == ie._VALID_URL


# Generated at 2022-06-22 08:42:06.750743
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Result should keep the same with original TVPlayHomeIE
    ie = TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL)
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie.ie_key() == TVPlayHomeIE.ie_key()

# Generated at 2022-06-22 08:42:08.936017
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    print(TVPlayHomeIE()._TESTS[0])
    print(TVPlayHomeIE()._TESTS[0]['url'])
    exit()


# Generated at 2022-06-22 08:42:55.135299
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    # test for _VALID_URL
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:43:07.896548
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_obj = TVPlayIE()

# Generated at 2022-06-22 08:43:12.793185
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_common import TestCommon as _TestCommon

    ie = TVPlayIE()
    ie._VALID_URL = ie._VALID_URL.replace('mtg', 'tvplay')
    if _TestCommon.doc:
        _TestCommon.doc.extend(globals().get('__doc__', '').splitlines())
    _TestCommon('mtg', ie, '176737')
    ie._VALID_URL = ie._VALID_URL.replace('tvplay', 'tv3play')
    _TestCommon('mtg', ie, '409229')

# Generated at 2022-06-22 08:43:22.980753
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test with a valid url
    valid_url = 'http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1'
    test_object = ViafreeIE()
    assert test_object.suitable(valid_url) == True
    # Test with a invalid url
    invalid_url = 'https://vidio.com/watch/1032043-super-dikdoank-vs-warga-kota-karena-nya-kontrakan-di-tretes-jawa-timur'
    test_object = ViafreeIE()
    assert test_object.suitable(invalid_url) == False


# Generated at 2022-06-22 08:43:28.405367
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-22 08:43:29.849249
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)


# Generated at 2022-06-22 08:43:33.819691
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.domain == 'tv3.lt'
    assert ie.geo_country == 'LT'


# Generated at 2022-06-22 08:43:35.448669
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_TVPlayHomeIE = TVPlayHomeIE(None)
    assert class_TVPlayHomeIE is not None


# Generated at 2022-06-22 08:43:38.621213
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play = TVPlayIE()
    assert tv_play.IE_NAME == 'mtg'
    assert tv_play.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:43:50.050033
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test the constructor of class TVPlayIE"""
    pattern1 = re.compile(r'http://www\.tv(3|6|8|10)play[^/]+/program/.*')
    pattern2 = re.compile(r'http://(?:www\.)?tvplay.lv/parraides/.*')
    pattern3 = re.compile(r'http://(?:www\.)?play.tv3.lt/programos/.*')
    pattern4 = re.compile(r'http://(?:www\.)?tv3play[^/]+/sisu/.*')
    pattern5 = re.compile(r'http://(?:www\.)?play.nova(?:tv)?.bg/programi/.*')

# Generated at 2022-06-22 08:45:27.764100
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # No exception thrown
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-22 08:45:30.737567
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE('mtg');
    print(IE._VALID_URL);
    print(IE._TESTS);

if __name__ == "__main__":
    test_TVPlayIE();

# Generated at 2022-06-22 08:45:40.362753
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtgx = TVPlayIE()
    # test 'mtg:' urls
    assert_equal(mtgx.IE_NAME, 'mtg')
    assert_equal(mtgx.IE_DESC, 'MTG services')

# Generated at 2022-06-22 08:45:44.926545
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test with an id
    TVPlayHomeIE.suitable('http://tvplay.skaties.lv/a/10000')


# Generated at 2022-06-22 08:45:49.875391
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = TVPlayIE._VALID_URL
    m = re.match(TVPlayIE._VALID_URL, url)
    assert m

    ie = TVPlayIE(TVPlayIE._create_get_info_extractor(url))
    assert ie
    assert ie.IE_DESC == 'MTG services'
    assert ie.IE_NAME == 'mtg'



# Generated at 2022-06-22 08:45:58.061889
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Theoretically, the constructor of ViafreeIE should check if the URL is supported,
    # if it is not supported, it should raise ExtractorError.
    # This function tests this function of the constructor.

    # This is a Viaplay.se URL for a program with several seasons.
    # This URL should be supported
    url_1 = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

    # This is a TVPlay.lv URL.
    # This URL should be supported
    url_2 = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'

    # This is a TVPlay.se URL.
    # This URL should NOT

# Generated at 2022-06-22 08:46:09.695763
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:46:11.549811
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('418113')
    TVPlayIE('mtg:418113')



# Generated at 2022-06-22 08:46:18.165969
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    field_tests = {
        'id': '757786',
        'ext': 'mp4',
        'title': 'Det beste vorspielet - Sesong 2 - Episode 1',
        'description': 'md5:b632cb848331404ccacd8cd03e83b4c3',
        'duration': 1116,
        'timestamp': 1471200600,
        'upload_date': '20160814',
        'season_number': 2,
        'series': 'Det beste vorspielet',
        }

    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_ie = ViafreeIE()

# Generated at 2022-06-22 08:46:20.385032
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    a = ViafreeIE()
    class_name = a.__class__.__name__
    assert class_name == "ViafreeIE"

