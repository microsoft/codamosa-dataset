

# Generated at 2022-06-22 08:39:40.514165
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('Viafree', 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country is 'no'
    assert ie.path is 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-22 08:39:44.274267
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # constructor
    ie = TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL)
    assert ie.SUCCESS


# Generated at 2022-06-22 08:39:49.633911
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == 'TVPlay'
    assert ie.ie_name() == 'MTG'
    assert ie.IE_DESC == 'MTG services'
    assert ie.IE_NAME == 'mtg'
    assert ie.VALID_URL == ie._VALID_URL



# Generated at 2022-06-22 08:39:52.018020
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ies = [TVPlayIE, ViafreeIE]
    for ie in ies:
        with pytest.raises(TypeError):
            ie()


# Generated at 2022-06-22 08:39:58.278865
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        TVPlayIE.suitable(True)
        assert False, "Should raise NotImplementedError"
    except NotImplementedError:
        pass
    try:
        ViafreeIE.suitable(True)
        assert False, "Should raise NotImplementedError"
    except NotImplementedError:
        pass

# Generated at 2022-06-22 08:40:07.932126
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("<url>")
    assert ie.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5") is False
    assert ie.suitable("http://play.tv3.se/program/husraddarna/395385?autostart=true") is True
    assert ie.suitable("https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true") is False
    assert ie.suitable("http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true") is False

# Generated at 2022-06-22 08:40:11.679902
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Check if TVPlayIE can be instantiated
    ie = TVPlayIE()
    assert ie != None

# Generated at 2022-06-22 08:40:13.973282
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor = type('TestConstructor', (ViafreeIE,), {})
    instance = constructor(None)
    assert instance.geo_country is None



# Generated at 2022-06-22 08:40:15.005877
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-22 08:40:18.899546
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE(None)
    assert(IE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'))
    assert(not IE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true'))


# Generated at 2022-06-22 08:40:56.102338
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert isinstance(instance, InfoExtractor)

# Generated at 2022-06-22 08:40:58.019952
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.se/whatever')
    assert not ie.suitable('https://play.di.se/whatever')

# Generated at 2022-06-22 08:40:58.782342
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('test')

# Generated at 2022-06-22 08:40:59.787439
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE([])

# Generated at 2022-06-22 08:41:00.317095
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-22 08:41:10.422388
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-22 08:41:15.894607
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    player = TVPlayHomeIE()
    assert player.IE_NAME == 'tvplay'
    assert player._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-22 08:41:23.801389
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie.set_player_url(lambda x: 'https://tvplay.mtgx.tv/play/iframe-embed/%s' % x)
    ie.set_embed_url(lambda x: 'https://tvplay.mtgx.tv/play/embed/%s' % x)
    ie.set_video_id('testid')
    assert ie.player_url == 'https://tvplay.mtgx.tv/play/iframe-embed/testid'
    assert ie.embed_url == 'https://tvplay.mtgx.tv/play/embed/testid'
    assert ie.video_id == 'testid'
    assert ie.MTG == True



# Generated at 2022-06-22 08:41:30.579320
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Because the constructor of class InfoExtractor is private, class ViafreeIE
    # cannot be constructed.
    # To test the class ViafreeIE, temporarily change the constructor of class
    # InfoExtractor to public.
    InfoExtractor.__init__ = lambda self, *args, **kwargs: None
    ViafreeIE(None, None)



# Generated at 2022-06-22 08:41:37.089361
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert (ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true'))
    assert (ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'))
    assert (not ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'))



# Generated at 2022-06-22 08:42:52.416060
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(TypeError):
        TVPlayHomeIE()

# Generated at 2022-06-22 08:42:53.957908
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg:418113')
    assert isinstance(ie, InfoExtractor)

# Unit tests for method _real_extract()

# Generated at 2022-06-22 08:42:57.187924
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # inst = TVPlayIE()
    inst = TVPlayIE('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    print(inst)

if __name__ == '__main__':
    test_TVPlayIE()

# Generated at 2022-06-22 08:43:08.456575
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert(tvplay.IE_NAME == 'mtg')
    assert(tvplay.IE_DESC == 'MTG services')
    assert(re.match(tvplay._VALID_URL, 'http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true'))
    assert(re.match(tvplay._VALID_URL, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'))
    assert(re.match(tvplay._VALID_URL, 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'))

# Generated at 2022-06-22 08:43:21.387318
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_name = TVPlayIE.__name__
    test_object = TVPlayIE()

    assert class_name == 'TVPlayIE'

# Generated at 2022-06-22 08:43:25.789033
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    ie.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-22 08:43:28.200317
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.GEO_COUNTRIES == ['LT', 'LV', 'EE']



# Generated at 2022-06-22 08:43:33.477671
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test for ViafreeIE constructor
    git_url_prefix = 'https://github.com/rg3/youtube-dl'
    tmp_dir = os.path.abspath(os.path.dirname(os.path.dirname(__file__)))
    os.chdir(tmp_dir)
    ViafreeIE({})

# Generated at 2022-06-22 08:43:35.140499
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import unittest
    ie = TVPlayIE()
    ie.test_parameters()


# Generated at 2022-06-22 08:43:36.073811
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()

# Generated at 2022-06-22 08:46:34.816103
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Testing with
    # http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/
    # sasong-1/avsnitt-2
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    viafree = ViafreeIE()
    viafree.suitable(url)
    viafree.extract(url)



# Generated at 2022-06-22 08:46:44.589316
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tvplay.tv3play.se/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3play.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3play.lt/aferistai-10047125')
    assert not TVPlayHomeIE.suitable('https://tv3play.se/vinas-melo-labak/vinas-melo-labak-10280317')


# Generated at 2022-06-22 08:46:54.060289
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-22 08:47:04.992608
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-22 08:47:08.770313
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test case for constructor of class ViafreeIE
    # Returns:
	#  True if test case passed, False otherwise
    return ViafreeIE(InfoExtractor())



# Generated at 2022-06-22 08:47:13.468271
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS


# Generated at 2022-06-22 08:47:25.223761
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for u in [
      'https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
      'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
      'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',

      'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
      'https://play.tv3.lt/aferistai-10047125',
      'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
    ]:
        assert TV

# Generated at 2022-06-22 08:47:33.895072
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-22 08:47:37.641117
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE('Viafree', 'viafree.no')
    assert 'Geo restricted' == instance.geo_restricted(None, 'NO')
    assert instance.geo_restricted(None, 'SE') is False
    assert instance.geo_restricted(None, 'DK') is False
    assert instance.geo_restricted(None, 'US') is False
    assert instance.geo_restricted(None, 'any') is False

# Generated at 2022-06-22 08:47:39.975571
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE(), ViafreeIE)