

# Generated at 2022-06-22 08:39:43.538386
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    meta = {
        'image': 'https://viafree-content.mtg-api.com/viafree-content/images/1539905823-b48299831524a58ea8c4c4b39c6d74e6.jpg',
        'description': 'Det svenska folkets favoritprogram har tagit sin plats som Sveriges mest populära serie. Nästan en miljon tittare avsnitt efter avsnitt följer med när vi får följa boskap, människor och deras hundar under deras vardag och arbete i vår vackraste landsända.'
    }
    ret = ViafreeIE._build_meta(meta)
    assert ret['thumbnail'] == meta['image']

# Generated at 2022-06-22 08:39:53.039479
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('hls', 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert(ie.name == 'TVPlayHomeIE')
    assert(ie.ie_key == 'TVPlayHome')
    assert(ie.url_basename == 'aferistai-10047125')
    assert(ie._VALID_URL == TVPlayHomeIE._VALID_URL)
    assert(ie.content_type == 'video')
    assert(ie.codec == 'hls')
    assert(ie.video_id == '10047125')



# Generated at 2022-06-22 08:39:59.374166
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    unit_test_case = ('https://play.tv3.lt/aferistai-n-7/aferistai-10047125/',
                      'https://play.tv3.lt/aferistai-10047125',
                      'https://tv3play.skaties.lv/vinas-melo-labak-10280317')

    for url in unit_test_case:
        assert TVPlayHomeIE.suitable(url), 'Fail to pass %s' % url


# Generated at 2022-06-22 08:40:01.758325
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    expected = set(['skaties', 'tv3'])
    assert instance._VALID_URL_SUFFIXES == expected

# Generated at 2022-06-22 08:40:06.097558
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    # Test id + url
    test_url = 'https://play.tv3.lt/aferistai-10047125'
    test_id = '366367'
    ie = TVPlayHomeIE(test_id, test_url)
    assert isinstance(ie, TVPlayHomeIE)
    assert ie._match_id(test_url) == test_id



# Generated at 2022-06-22 08:40:11.912206
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    result = ViafreeIE.suitable(url)
    assert result is True

# Generated at 2022-06-22 08:40:22.063606
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    c = TVPlayHomeIE(params={})
    c.suitable(url)
    assert c._match_id(url) == c._match_id('https://tv3play.tv3.lt/aferistai-10047125')
    assert c._match_id(url) == c._match_id('https://play.tv3.lt/aferistai-10047125')


# TODO: Remove when #4806 is merged

# Generated at 2022-06-22 08:40:24.066822
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._TESTS == TVPlayHomeIE.__dict__['_TESTS']

# Generated at 2022-06-22 08:40:29.877079
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.get_geo_countries() == []
    assert ie.get_geo_verification_headers() == {}
    assert ie.get_geo_bypass() == False
    assert ie.get_cookies() == {}
    assert ie.get_media_id_url(ie) == {}
    assert ie.get_media_id_path(ie) == {}


# Generated at 2022-06-22 08:40:31.286417
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')

# Generated at 2022-06-22 08:40:53.624621
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    ie = TVPlayIE()
    assert TVPlayIE.IE_NAME == ie.name
    assert TVPlayIE.IE_DESC == ie.description
    assert re.match(TVPlayIE._VALID_URL, url) is not None

# Generated at 2022-06-22 08:41:01.956161
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie.SUCCESS_CODES == [200, 204]
    assert ie.IE_NAME == 'Viafree'
    assert ie.IE_DESC == 'TV3, TV6, TV8, TV10, TV3 Play, Viafree and TV6 Play Denmark, Norway and Sweden'
    assert ie.valid_countries == ['dk', 'no', 'se']
    assert ie.page_encoding == 'utf-8'
    assert ie._VALID_URL == ViafreeIE._VALID_URL

# Generated at 2022-06-22 08:41:12.697326
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-22 08:41:24.455562
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    t._download_json = lambda url, video_id, note: url
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    video_id = '409229'
    video_url = t._download_json(
        'http://playapi.mtgx.tv/v3/videos/' + video_id,
        video_id, 'Downloading video JSON')
    play_url = t._download_json(
        'http://playapi.mtgx.tv/v3/videos/stream/' + video_id,
        video_id, 'Downloading streams JSON')
    streams = play_url['streams']
    formats = []

# Generated at 2022-06-22 08:41:33.938435
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Tested as:
    #   ./youtube-dl --dump-intermediate-pages --debug https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/
    extractor = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert extractor._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-22 08:41:41.611128
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE({'geo_countries': ['LV']})
    assert ie._initialize_geo_bypass({'countries': ['LV']})
    ie = TVPlayIE({})
    assert ie._initialize_geo_bypass({'countries': ['LV']})
    ie = TVPlayIE()
    assert ie._initialize_geo_bypass({'countries': ['LV']})



# Generated at 2022-06-22 08:41:49.954448
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Each of these cases should give an instance of InfoExtractor.
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-22 08:41:54.724168
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg', 'mtg:418113')

# Generated at 2022-06-22 08:41:55.895399
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:41:57.646362
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_obj = ViafreeIE()
    expected_result = {
        'no': 'no',
        'se': 'se',
        'dk': 'dk',
    }
    assert (ViafreeIE._GEO_COUNTRIES == expected_result)



# Generated at 2022-06-22 08:42:42.693540
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-22 08:42:44.173744
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    d = TVPlayHomeIE()

# Generated at 2022-06-22 08:42:49.596613
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-22 08:42:58.373439
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = ViafreeIE()
    # Check that the test location for this URL is Denmark
    assert ie.suitable(test_url)
    # Check that the Geo Restriction mechanism works
    ie.geo_verification_headers = lambda: {'Country': 'AU'}

# Generated at 2022-06-22 08:43:03.709598
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    config = {
        'test_video_id': '366367',
        'test_url': 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        'test_playlist_count': 5,
    }
    ie = TVPlayHomeIE(config)
    assert ie.NAME == 'tvplay'

# Generated at 2022-06-22 08:43:10.292702
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Verify that the required instance variables of the ViafreeIE class
    are properly set.
    """
    ie = ViafreeIE()
    assert_true(hasattr(ie, '_GEO_COUNTRIES'),
                'ViafreeIE instance does not have _GEO_COUNTRIES set')
    assert_equal(ie._GEO_COUNTRIES, ['SE', 'NO', 'DK'],
                 'ViafreeIE instance does not have proper _GEO_COUNTRIES')

# Generated at 2022-06-22 08:43:19.457547
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    d = ViafreeIE()
    assert d.__class__.__name__ == 'ViafreeIE'
    assert d._VALID_URL == r'''(?x)
                            https?://
                                (?:www\.)?
                                viafree\.(?P<country>dk|no|se)
                                /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                            '''


# Generated at 2022-06-22 08:43:21.343348
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import test_helper
    test_helper.test_constructor(ViafreeIE)



# Generated at 2022-06-22 08:43:24.821001
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'http://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    m = TVPlayHomeIE._VALID_URL_RE.match(url)
    video_id = m.group('id')
    video_id_re = r'\d+'

    assert video_id == '10044354'

# Generated at 2022-06-22 08:43:26.336905
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError):
        ViafreeIE()



# Generated at 2022-06-22 08:44:53.144775
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-22 08:44:59.210654
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE(None)

    assert IE._VALID_URL == 'https?://(?P<host>tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)'


# Generated at 2022-06-22 08:45:10.757921
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    extractor = ViafreeIE()

# Generated at 2022-06-22 08:45:15.982450
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from youtube_dl. ViafreeIE import ViafreeIE
    # Test with normal url
    viafreeIE = ViafreeIE('https://viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-22 08:45:22.714150
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

    # make sure that if it is video that ViaplayIE also handles
    # that this instance will not extract
    assert not ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-22 08:45:29.279850
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v = ViafreeIE(None)
    assert v.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == True
    assert v.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true') == False


# Generated at 2022-06-22 08:45:39.121649
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie._TESTS[0]['info_dict']['id'] == '366367'
    assert ie._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert ie._TESTS[0]['info_dict']['title'] == 'Aferistai'
    assert ie._TES

# Generated at 2022-06-22 08:45:47.140891
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test import _TEST_INSTANCES

    for test in _TEST_INSTANCES:
        if test.get('IE_NAME') == 'Viafree':
            vi = ViafreeIE(test.get('IE'), test.get('downloader'))
            assert vi is not None
            return
    raise Exception('Test for class ViafreeIE not found')


# Generated at 2022-06-22 08:45:57.549995
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_urls = ["https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/", "https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/"]
    test_video_ids = ["10047125", "10280317"]
    ie = TVPlayHomeIE(test_urls[0])
    assert ie.url == test_urls[0]
    assert ie.id == test_video_ids[0]
    ie = TVPlayHomeIE(test_urls[1])
    assert ie.url == test_urls[1]
    assert ie.id == test_video_ids[1]

# Generated at 2022-06-22 08:45:59.124688
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)