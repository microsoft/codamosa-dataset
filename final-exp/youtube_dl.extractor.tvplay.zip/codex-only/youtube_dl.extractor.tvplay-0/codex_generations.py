

# Generated at 2022-06-24 13:29:19.083180
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:29:20.490959
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import TVPlayIE
    TVPlayIE()



# Generated at 2022-06-24 13:29:22.145882
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE(None) # pylint: disable=abstract-class-instantiated


# Generated at 2022-06-24 13:29:24.469410
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE('Viafree', 'dk')
    if isinstance(viafree, ViafreeIE) == True:
        return True
    else:
        return False

# Generated at 2022-06-24 13:29:27.554690
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    oe = ie._match_id('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert oe == "395385"

# Generated at 2022-06-24 13:29:30.924684
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    video_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/%s?autostart=true' % video_id
    tv_play = TVPlayIE()
    test_info_dict = tv_play._real_extract(video_url)
    assert test_info_dict['id'] == video_id


# Generated at 2022-06-24 13:29:37.023865
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import inspect

    # Check the constructor parameters of ViafreeIE
    members = inspect.getmembers(ViafreeIE)
    members = [x for x in members if x[0] == '__init__'][0][1].__code__.co_varnames
    assert members == ( 'self', 'country', 'video_id'), \
        "Constructor of class ViafreeIE has unexpected parameters"


# Generated at 2022-06-24 13:29:45.421009
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_common import countTest
    from .test_common import ask_for_test
    from .test_common import test_data
    from .test_common import ytdl_opts

    # Test extraction of ViafreeIE
    for test in test_data.get('viafree', []):
        yield countTest, test, test.get('func', ViafreeIE)

    # Test extraction of TVPlayIE and ViafreeIE
    for test in test_data.get('skaties_lv', []):
        yield countTest, test, test.get('func', TVPlayIE)

    # Test extraction of TVPlayIE and ViafreeIE
    for test in test_data.get('tv6_no', []):
        yield countTest, test, test.get('func', TVPlayIE)

    # Test extraction of TVPlayIE and

# Generated at 2022-06-24 13:29:46.213805
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return ViafreeIE(TVPlayIE())

# Generated at 2022-06-24 13:29:47.209368
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tester = TVPlayHomeIE()



# Generated at 2022-06-24 13:29:51.196414
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL
    assert ie._TESTS
    assert ie._GEO_BYPASS



# Generated at 2022-06-24 13:29:52.278227
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:30:00.187847
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:30:11.463747
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie.country_code == 'LT'

    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.country_code == 'EE'

    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert ie.country_code == 'LV'

    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert ie.country_code == 'LT'


# Generated at 2022-06-24 13:30:19.614736
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    constructor_test(TVPlayHomeIE, [
        # Expected test's results
        (
            'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
            {
                'id': '10280317',
                'title': 'Vīnas melo labāk',
                'description': None,
                'series': 'Vīnas melo labāk',
                'episode': None,
                'duration': None,
                '__duration': None,
                'timestamp': None,
                '__timestamp': None,
                'age_limit': 0,
                '__age_limit': 0,
            },
            {
                'skip_download': True,
            },
        ),
    ])


# Generated at 2022-06-24 13:30:20.376966
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:30:27.204741
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie._VALID_URL == "https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)", ie._VALID_URL
    assert ie._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie._TESTS[0]['info_dict']['id'] == '757786'

# Generated at 2022-06-24 13:30:33.224378
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test that error messages are not broken, see:
    # https://github.com/rg3/youtube-dl/issues/6068

    # Test that error messages are not broken, see:
    # https://github.com/rg3/youtube-dl/issues/6068
    for invalid_url in (
            'https://play.tv3.lt/aferistai',
            'https://play.tv3.ee/cool-d-ga-mehhikosse',
            'https://play.tv3.lt/pet-shop-boys-inner-sanctum-10028065'):
        with pytest.raises(ExtractorError) as excinfo:
            TVPlayHomeIE().suitable(invalid_url)
        assert str(excinfo.value).startswith('Invalid URL:')



# Generated at 2022-06-24 13:30:35.590437
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_class = TVPlayIE('TVPlay', 'mtg', 'tvplay')
    assert test_class


# Generated at 2022-06-24 13:30:47.974127
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()

# Generated at 2022-06-24 13:30:49.658500
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(ValueError):
        ViafreeIE(None)

# Generated at 2022-06-24 13:30:56.038863
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test of constructor of class TVPlayHomeIE
    input_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    match = TVPlayHomeIE._VALID_URL.match(input_url)
    assert match is not None
    assert int(TVPlayHomeIE._match_id(input_url)) == 366367

# Generated at 2022-06-24 13:30:56.766906
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:30:57.981000
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_list_extractor import test_list_extractor

    test_list_extractor(TVPlayHomeIE)

# Generated at 2022-06-24 13:31:10.317870
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.IE_DESC == 'TVPlayHome'
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie.SUFFIX == 'Ltd.'
    assert ie._GEO_BYPASS == False
    assert ie._GEO_COUNTRIES == ['LT', 'LV', 'EE']
    assert ie._API_BASE == 'https://api.play.tv3.lt/'
    assert ie._API_KEY == None
    assert ie._GEO_COUNTRY is None
    assert ie._SUBTITLE_LANGUAGE == 'lv'

# Generated at 2022-06-24 13:31:11.878008
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(True)
    print(ie)

# Generated at 2022-06-24 13:31:22.127810
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return {
        'url': 'http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true',
        'info_dict': {
            'id': '266636',
            'ext': 'mp4',
            'title': 'Den sista dokusåpan S01E08',
            'description': 'md5:295be39c872520221b933830f660b110',
            'duration': 1492,
            'timestamp': 1330522854,
            'upload_date': '20120229',
            'age_limit': 18,
        },
        'params': {
            'skip_download': True,
        },
    }


# Generated at 2022-06-24 13:31:34.087176
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def get_formats(url, **kwargs):
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter('always')
            try:
                ie = ViafreeIE()
                ie.extract(url, **kwargs)
            except Exception:
                pass
            return len(w)
    # Test that ViafreeIE threw a warning when constructed.
    # There should be a warning.
    assert get_formats('http://www.tv3play.no/video/216902-husraddarna/season-2/episode-7') == 1
    assert get_formats('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == 1
    # There should not be a warning.

# Generated at 2022-06-24 13:31:44.485609
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.get_domain(None) == 'tv3play.skaties.lv'
    assert ie.get_domain("http://tv3play.skaties.lv/test/test") == 'tv3play.skaties.lv'
    assert ie.get_domain("https://tv3play.skaties.lv/test/test") == 'tv3play.skaties.lv'
    assert ie.get_domain("https://tv3.skaties.lv/test/test") == 'tv3.skaties.lv'
    assert ie.get_domain("https://www.tv3.skaties.lv/test/test") == 'tv3.skaties.lv'

# Generated at 2022-06-24 13:31:47.719987
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    video_id = info_extractor._match_id(url)
    assert video_id == '238551'


# Generated at 2022-06-24 13:31:50.570197
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert ie.SUFFIX == ie._VALID_URL


# Generated at 2022-06-24 13:31:51.809896
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')


# Generated at 2022-06-24 13:31:56.255335
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert t.geo_countries == ['LV']



# Generated at 2022-06-24 13:31:57.357666
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:32:09.250500
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    module = importlib.import_module('youtube_dl.extractor.tvplayhome')
    ie = module.TVPlayHomeIE('TVPlayHomeIE')

    assert ie.get_url_re() == module.TVPlayHomeIE._VALID_URL
    assert ie.get_url_re().match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.get_url_re().match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.get_url_re().match('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-24 13:32:12.888249
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))


# Generated at 2022-06-24 13:32:23.285572
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    inst = ViafreeIE(None)
    assert inst._VALID_URL == ViafreeIE._VALID_URL
    assert inst._TESTS == ViafreeIE._TESTS
    assert inst._GEO_BYPASS == ViafreeIE._GEO_BYPASS
    assert inst._GEO_COUNTRIES == []
    assert inst._downloader is None
    assert inst._geo_bypass_ip is None
    assert inst._geo_bypass_ip_quote_plus is None
    assert inst._WORKING is False
    assert inst._geo_verification_headers() == {}
    assert inst._formats is None
    assert inst._player_cache is None
    assert inst._player_cache_swf_url is None
    assert inst.username is None
    assert inst.password is None
    assert inst.downloader

# Generated at 2022-06-24 13:32:34.926792
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert instance._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-24 13:32:46.486230
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:32:50.690586
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass = lambda x: None
    # Check if the constructor is working
    assert ie.IE_NAME == 'mtg'
    assert ie.ie_key() == 'MTG'
    assert ie.IE_DESC == 'MTG services'


# Generated at 2022-06-24 13:33:01.810024
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:02.533712
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('www.tv3play.lv')

# Generated at 2022-06-24 13:33:05.378057
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    parser = TVPlayIE()
    assert (parser.__name__ in ['MTG', 'TvPlayIE']) == True

# Generated at 2022-06-24 13:33:15.272473
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # tvplay.lv
    assert TVPlayIE._VALID_URL.match('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert TVPlayIE._VALID_URL.match('http://www.tvplay.lv/vinas-melo-labak/418113/?autostart=true')
    assert TVPlayIE._VALID_URL.match('http://www.tvplay.lv/parraides/tv3-zinas/760183')
    # tvplay.skaties.lv
    assert TVPlayIE._VALID_URL.match('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert TVPlayIE._VALID_URL.match

# Generated at 2022-06-24 13:33:19.913762
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert hasattr(tvplay_ie, '_VALID_URL')
    assert hasattr(tvplay_ie, '_TESTS')
    assert hasattr(tvplay_ie, 'IE_NAME')
    assert hasattr(tvplay_ie, 'IE_DESC')


# Generated at 2022-06-24 13:33:22.759374
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test for instantiating class
    TVPlayHomeIE('http://play.tv3.lt/a-b-c')


# Generated at 2022-06-24 13:33:24.160673
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:33:24.868422
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:33:35.017148
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_obj = lambda *args, **kwargs: TVPlayIE(*args, **kwargs)
    obj = test_obj('http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-24 13:33:38.977556
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie = TVPlayHomeIE(url)
    assert ie.extract('10280317')

# Generated at 2022-06-24 13:33:45.430834
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-24 13:33:46.637362
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:33:49.473794
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    ie = ViafreeIE(FakeInfoExtractor(), url)
    assert ie.country == 'se'
    assert ie.path == 'program/livsstil/husraddarna/sasong-2/avsnitt-2'



# Generated at 2022-06-24 13:33:53.434692
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'


# Generated at 2022-06-24 13:34:01.486079
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    '''
    Generate a unit test for class TVPlayIE
    '''

    import unittest
    import re

    class TestTVPlayIE(unittest.TestCase):

        def setUp(self):
            self.ie = TVPlayIE()

        def test_TVPlayIE_constructor(self):
            '''
            Test the constructor of TVPlayIE
            '''

            self.assertIsInstance(self.ie, TVPlayIE)
            self.assertIsInstance(self.ie._VALID_URL, type(re.compile('')))
            self.assertEqual('mtg', self.ie.IE_NAME)
            self.assertEqual('MTG services', self.ie.IE_DESC)


# Generated at 2022-06-24 13:34:06.996333
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert(IE.IE_NAME == 'mtg')
    assert(IE.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:34:15.657685
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        cls = TVPlayHomeIE()
        content = cls.url_result('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    except ExtractorError:
        print('Failed to extract content from URL')
        return False
    else:
        assert content['id'] == '366367', 'Test failed'
        assert content['ext'] == 'mp4', 'Test failed'
        assert content['title'] == 'Aferistai', 'Test failed'
        assert content['description'] == 'Aferistai. Kalėdinė pasaka.', 'Test failed'
        assert content['series'] == 'Aferistai [N-7]', 'Test failed'
        assert content['season'] == '1 sezonas', 'Test failed'
       

# Generated at 2022-06-24 13:34:17.520890
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
    except:
        print('Failed to construct an instance of TVPlayIE')


# Generated at 2022-06-24 13:34:19.953493
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	assert 'tv3' in TVPlayHomeIE._downloader._default_headers.keys()
	assert 'tv3.lt' in TVPlayHomeIE._LOCALES.keys()



# Generated at 2022-06-24 13:34:32.068944
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie._VALID_URL = ViafreeIE._VALID_URL
    ie._TESTS = ViafreeIE._TESTS
    ie._GEO_BYPASS = ViafreeIE._GEO_BYPASS
    ie.suitable = lambda url: True

    errs = {}
    for t in ie._TESTS:
        url = t['url'] if 'url' in t else ''

        if not hasattr(ie, '_real_extract'):
            ie.to_screen('WARNING: _real_extract() method is missing in class %s' % ie.__class__.__name__)
            errs[ie.__class__.__name__] = True
            continue


# Generated at 2022-06-24 13:34:38.582558
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.no') is False
    assert ie.suitable('https://www.viafree.dk') is False
    assert ie.suitable('https://www.viafree.se') is False
    assert ie.suitable('https://www.viafree.com') is False
    assert ie.suitable('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') is True
    assert ie.suitable('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') is True

# Generated at 2022-06-24 13:34:39.744857
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-24 13:34:42.118069
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE()
    with pytest.raises(TypeError):
        _ = IE('http://www.tv3play.no/')

# Generated at 2022-06-24 13:34:52.733488
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:55.634175
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception as e:
        assert False, 'Constructor of class ViafreeIE failed: %s' % repr(e)



# Generated at 2022-06-24 13:34:57.429766
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE(None, None) is not None

# Generated at 2022-06-24 13:35:04.267310
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    result = ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    expected = True
    assert result == expected

    result = ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    expected = False
    assert result == expected

# Generated at 2022-06-24 13:35:12.592568
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert '669963' == TVPlayHomeIE._match_id('https://tvplay.tv3.lt/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert '14593' == TVPlayHomeIE._match_id('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert '472990' == TVPlayHomeIE._match_id('https://play.tv3.lt/aferistai-10047125')
    assert '14593' == TVPlayHomeIE._match_id('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert '472990' == TVPlayHomeIE._match

# Generated at 2022-06-24 13:35:14.209320
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()

# Generated at 2022-06-24 13:35:17.591164
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.get_info('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true') is not None


# Generated at 2022-06-24 13:35:20.575713
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    TVPlayHomeIE()._real_initialize(url)

# Generated at 2022-06-24 13:35:32.078678
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    i = TVPlayIE()
    assert i.IE_NAME == 'mtg'
    assert i.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:35:41.584605
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .. import TVPlayHomeIE
    t = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert 'TVPlayHomeIE' in t.__class__.__name__
    assert t.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert t.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert t.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-24 13:35:48.779894
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url_lv = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    url_lt = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    url_ee = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    url_se = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    url_se_1 = 'https://tv3play.tv3.se/program/husraddarna/395385?autostart=true'

# Generated at 2022-06-24 13:35:53.951919
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    # > test_TVPlayHomeIE
    TVPlayHomeIE = TVPlayHomeIE(url)
    # > test_TVPlayHomeIE
    assert TVPlayHomeIE == 'TVPlayHomeIE'

# Generated at 2022-06-24 13:35:57.846291
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    log.info("Test constructor")
    ie = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie.geo_bypass is False

# Generated at 2022-06-24 13:36:05.389460
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)
    TVPlayHomeIE.suitable('http://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    TVPlayHomeIE.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    TVPlayHomeIE.su

# Generated at 2022-06-24 13:36:07.918587
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE('TVPlayHome', 'https://tv3play.skaties.lv/vinas-melo-labak-10280317/')._VALID_URL == TVPlayHomeIE._VALID_URL



# Generated at 2022-06-24 13:36:11.156308
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test method test_TVPlayIE.

    Checks if _TVPlayIE is a subclass of InfoExtractor.
    """
    ie = TVPlayIE()
    assert issubclass(ie.__class__, InfoExtractor)


# Generated at 2022-06-24 13:36:17.770708
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg', {})
    assert ie.ie_key() == 'mtg'
    assert ie.ie_desc() == 'MTG services'

# Generated at 2022-06-24 13:36:21.298112
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    test_obj = ViafreeIE(url)
    assert isinstance(test_obj, ViafreeIE)



# Generated at 2022-06-24 13:36:28.626484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    video_id = '418113'
    asset = TVPlayHomeIE()._download_json(
        urljoin(url, '/sb/public/asset/' + video_id), video_id)
    m3u8_url = asset['movie']['contentUrl']
    assert m3u8_url == 'https://video-tv3.lv/hls/79/lv/default/a8cda13f2b541c2e2b927ebe803408b7/1440187400/418113/418113.m3u8'

# Generated at 2022-06-24 13:36:37.271104
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    info = {
        'id': '366367',
        'ext': 'mp4',
        'title': 'Aferistai',
        'description': 'Aferistai. Kalėdinė pasaka.',
        'series': 'Aferistai [N-7]',
        'season': '1 sezonas',
        'season_number': 1,
        'duration': 464,
        'timestamp': 1394209658,
        'upload_date': '20140307',
        'age_limit': 18
    }
    # Test that the constructor of class TVPlayHomeIE works
    assert TVPlayHomeIE.suitable(url)

# Generated at 2022-06-24 13:36:39.308249
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:36:48.779694
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://www.tvplay.lv/ferrari-tattoos/ferrari-tattoos-10280335/')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:36:53.198305
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Because it uses a regex to get the video id.
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE(url)
    assert ie._match_id(url) == '366367'



# Generated at 2022-06-24 13:37:01.919518
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test empty url
    with pytest.raises(AssertionError):
        TVPlayHomeIE('')
    # Test invalid url
    with pytest.raises(AssertionError):
        TVPlayHomeIE('http://example.com')
    # Test valid url
    with pytest.warns(None) as record:
        ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
        assert not record
        assert ie.SUITABLE_URL.match(ie._VALID_URL)
        assert ie.SUITABLE_URL.match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317')
        assert ie

# Generated at 2022-06-24 13:37:07.191707
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_mtg import MTGTestCase
    from .test_mtg import viafree_id
    from .test_mtg import viafree_url_re

    def class_test_wrapper(test_func):
        def wrapper(self, *args, **kwargs):
            test_func(self, *args, **kwargs)
            self.assertEqual(type(self.ie).__name__,
                             'ViafreeIE',
                             'Should be instance of ViafreeIE')

        return wrapper

    MTGTestCase.test_mtg_url_re = class_test_wrapper(MTGTestCase.test_mtg_url_re)

# Generated at 2022-06-24 13:37:18.585800
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:37:19.294332
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('418113')

# Generated at 2022-06-24 13:37:28.246267
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE().suitable('http://www.viafree.no')
    ViafreeIE().suitable('http://www.viafree.dk')
    ViafreeIE().suitable('http://www.viafree.se')
    ViafreeIE().suitable('http://play.nova.bg')
    ViafreeIE().suitable('http://play.nova.bg/programi/zdravei-bulgariya/624952')
    ViafreeIE().suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760045')
    ViafreeIE().suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/completed/238551')

# Generated at 2022-06-24 13:37:32.594558
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/livsstil/husraddarna/sasong-4/avsnitt-2')
    assert (ViafreeIE.suitable('http://www.tv3play.dk/programmer/diverse/popstars/popstars-2015-998042')
            is False)


# Generated at 2022-06-24 13:37:34.078428
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)
    assert isinstance(ie, TVPlayIE)



# Generated at 2022-06-24 13:37:43.360805
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info = TVPlayHomeIE()
    assert info._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:37:45.547964
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE()
    assert i
    assert isinstance(i, InfoExtractor)


# Generated at 2022-06-24 13:37:57.313948
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    # Tests for the constructor of ViafreeIE
    # Make sure the constructor works
    ie = ViafreeIE()
    # Make sure the constructor accepts country parameter
    ie = ViafreeIE(geo_countries=['se'])
    # Make sure the constructor accepts a list as country parameter
    ie = ViafreeIE(geo_countries=['dk', 'no', 'se'])
    # Make sure the constructor ignores empty country parameter
    ie = ViafreeIE(geo_countries=[''])
    # Make sure the constructor ignores wrong country parameter
    ie = ViafreeIE(geo_countries=['something'])
    # Make sure the constructor doesn't accept multiple country parameters
    ie = ViafreeIE(geo_countries=['se', 'dk'])
    # Make sure the constructor accepts an empty list as country parameters

# Generated at 2022-06-24 13:37:59.680224
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # call test case
    ie = TVPlayHomeIE()
    # verify
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-24 13:38:05.288375
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if sys.version_info < (3,):
        return  # This test hangs on PY2
    ie = ViafreeIE()
    ie.geo_verification_headers = MagicMock(return_value = {'DNT': '1'})
    ie._download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/dk/path/programmer/reality/paradise-hotel/saeson-7/episode-5',
        'program')

# Generated at 2022-06-24 13:38:09.178050
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t._VALID_URL == re.compile(
        r'http://(?:www\.)?(?:tvplay\.lv/parraides|play\.tv3\.lt/programos|tv3play\.ee/sisu|'
        r'tv(?:3|6|8|10)play\.se/program|(?:tv3play|viasat4play|tv6play|viafree)\.no/programmer|play\.nova\.bg/programi)/(?:[^/]+/)+\d+')


# Generated at 2022-06-24 13:38:20.587009
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj._VALID_URL == r'(?x)https?://(?:www\.)?(?:tvplay\.skaties\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer)/(?:[^/]+/)+(?P<id>\d+)'

# Generated at 2022-06-24 13:38:25.578574
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test whether function is called with correct arguments
    # Return None if arguments are correct
    # Return error message if arguments are not correct
    test_TVPlayIE_error_message = None
    try:
        import extractor_test
        from tvplay.TVPlayIE import TVPlayIE
        extractor_test.test_constructor(TVPlayIE)
    except Exception as e:
        print(e)
        test_TVPlayIE_error_message = str(e)
    return test_TVPlayIE_error_message



# Generated at 2022-06-24 13:38:27.690051
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvie=TVPlayIE()
    assert tvie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:39.724139
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Note: output of test_ViafreeIE() is intentionally out of order!
    ie = ViafreeIE()

# Generated at 2022-06-24 13:38:42.878040
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TODO: Add tests for _real_extract() once it's implemented.
    ie = TVPlayIE()
    ie._initialize_geo_bypass({})

# Generated at 2022-06-24 13:38:51.590475
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in TVPlayHomeIE._TESTS[0:-2]:
        ie = TVPlayHomeIE(url)
        video_id = ie._match_id(url['url'])
        asset = ie._download_json(
            urljoin(url['url'], '/sb/public/asset/' + video_id), video_id)
        m3u8_url = asset['movie']['contentUrl']
        assert m3u8_url.endswith('/playlist.m3u8'), m3u8_url
        assert asset['assetId'] == video_id
        # Test if we're able to extract formats from old-style URLs
        assert ie.suitable(url['url']) is True
    for url in TVPlayHomeIE._TESTS[-2:]:
        ie = TVPlayHome

# Generated at 2022-06-24 13:38:53.741194
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test with no arg (the way extractors are called in workflow)
    ViafreeIE()
    # Test with arg (the way extractors are called unit test-wise)
    ViafreeIE(None)

# Generated at 2022-06-24 13:39:00.821734
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_ = TVPlayIE
    data = {
        'url': 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    }
    test_obj = class_(data)
    assert test_obj.url == 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'


# Generated at 2022-06-24 13:39:02.951933
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception:
        assert False, 'class ViafreeIE should not receive any arguments'



# Generated at 2022-06-24 13:39:14.086958
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie is not None
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL == (
        r'(?x)^(?:mtg:|https?://(?:www\.)?(?:'
            r'(?:tv3play|tv(?:3|6|8|10)play|viasat4play|viafree)\.(?:lt|lv|ee|se|no|dk)|'
            r'play\.tv3\.lt|'
            r'play\.nova(?:tv)?\.bg)'
            r'/(?:[^/]+/)+)(?P<id>\d+)$')