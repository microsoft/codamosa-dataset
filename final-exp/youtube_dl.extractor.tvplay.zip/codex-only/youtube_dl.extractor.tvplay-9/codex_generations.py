

# Generated at 2022-06-24 13:29:16.460337
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    result = IE._real_extract('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert result is not None
    assert "video title" in result
    assert "video id" in result
    assert "thumbnail" in result
    assert "video series" in result
    assert "video season" in result
    assert "duration" in result
# End of test for TVPlayHomeIE


# Generated at 2022-06-24 13:29:20.632224
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    assert ViafreeIE.suitable(url) is True
    vfie = ViafreeIE()
    if vfie.suitable(url) == True:
        vfie._real_extract(url)



# Generated at 2022-06-24 13:29:25.072918
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    ie = ViafreeIE(ViafreeIE._create_ie_instance())
    assert ie.suitable(url) is True
    assert ie.IE_NAME == type(ie).__name__

# Generated at 2022-06-24 13:29:32.816221
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tester = TVPlayIE()

# Generated at 2022-06-24 13:29:42.790598
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')

# Generated at 2022-06-24 13:29:47.163380
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:29:56.816139
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplayhome_ie = TVPlayHomeIE(TVPlayHomeIE._create_ie(), url)

    assert tvplayhome_ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:29:57.767220
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:30:09.313211
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    TVPlayHomeIE.su

# Generated at 2022-06-24 13:30:17.967796
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if not hasattr(InfoExtractor, '_download_xml'):
        return
    title = 'Aferistai'
    description = 'Aferistai. Kalėdinė pasaka.'
    series = 'Aferistai [N-7]'
    season = '1 sezonas'
    video_id = '366367'
    age_limit = '18'

    assert TVPlayHomeIE().suitable(
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') is True

    tv = TVPlayHomeIE({})

    # test _get_attr_content
    assert tv._get_attr_content(None, 'not-existed', 'non-standard') is None

# Generated at 2022-06-24 13:30:22.731830
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    expect_url = "https://tvplay.tv3.lt/aferistai/aferistai-10047126/"
    tvplay_home_ie = TVPlayHomeIE("tv3play.skaties.lv/aferistai/aferistai-10047126/")
    assert tvplay_home_ie._VALID_URL == expect_url

# Generated at 2022-06-24 13:30:30.013142
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie._TESTS[1]['url'] == 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert ie._T

# Generated at 2022-06-24 13:30:33.111502
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable(ViafreeIE._VALID_URL) is True
    assert ie.suitable(TVPlayIE._VALID_URL) is False

# Generated at 2022-06-24 13:30:33.586306
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:30:45.626599
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:57.219960
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_downloader import get_testdata_directory
    doc = compat_etree_fromstring(
        compat_urllib_request.urlopen(
            'file://%s/docs/viafree.se.html' %
            get_testdata_directory()).read().decode('utf-8')
    )
    url = 'https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-6'
    ie = ViafreeIE({'_downloader': None})
    assert ie.suitable(url)
    assert ie._real_extract({'url': url, '_downloader': None, '_download_webpage_handle': lambda *args: doc})

# Generated at 2022-06-24 13:30:59.622089
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("https://tvplay.viafree.com/program/livsstil/husraddarna/sasong-2/avsnitt-2")


# Generated at 2022-06-24 13:31:05.737919
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import get_testcases
    for input_url, expected_output in get_testcases(TVPlayIE).items():
        output = TVPlayIE._extract_info(TVPlayIE, TVPlayIE._match_id(input_url), input_url).get('title')
        assert output == expected_output

# Extractor for TV3 Play's live streams

# Generated at 2022-06-24 13:31:07.298795
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-24 13:31:16.884826
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i = ViafreeIE()
    assert i.suitable("https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert i.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert i.suitable("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    assert i.suitable("http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2")

# Generated at 2022-06-24 13:31:28.427424
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert TVPlayHomeIE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert TVPlayHomeIE.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/")
    assert TVPlayHomeIE.suitable("https://play.tv3.lt/aferistai-10047125")
    assert TVPlayHomeIE.suitable("https://tv3play.skaties.lv/vinas-melo-labak-10280317")

# Generated at 2022-06-24 13:31:30.066438
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert 'TVPlayIE' in globals()


# Generated at 2022-06-24 13:31:31.921236
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(1, 2)

# Generated at 2022-06-24 13:31:42.744925
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_name = 'ViafreeIE'
    viafree_class = globals()[class_name]
    viafree_class.suitable('https://www.viafree.se/program/sport/esport/sasong-1/avsnitt-1')
    viafree_class.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    viafree_class.suitable('http://tv6play.no/programmer/hotelinspektor-alex-polizzi/361883?autostart=true')

    # Check if constructor check is correct
    def __init__(self, name, init):
        pass

# Generated at 2022-06-24 13:31:49.653071
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:32:00.385837
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    m = ie._VALID_URL
    assert re.search(m, 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert re.search(m, 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert re.search(m, 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert re.search(m, 'http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:32:12.146959
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for ViafreeIE
    """
    def test_suitable(url, expected_result):
        """
        Test suitable method of ViafreeIE with single URL
        """
        assert ViafreeIE.suitable(url) == expected_result

    # default region is dk
    ie = ViafreeIE(False)
    # dk
    test_suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', True)
    test_suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5?autostart=true', True)
    # se

# Generated at 2022-06-24 13:32:22.917315
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id = '366367'

# Generated at 2022-06-24 13:32:23.910569
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)



# Generated at 2022-06-24 13:32:24.541067
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:32:36.081915
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert not ie.suitable('http://playapi.mtgx.tv/v3/videos/361883')
    assert not ie.suitable('https://viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:32:39.305187
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie, __, __ = generic_test_dict(ViafreeIE, {}, SITE, [])
    assert ie.HEADERS.get('User-Agent') is None, "Headers should have default User-Agent"



# Generated at 2022-06-24 13:32:43.540108
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-24 13:32:52.847089
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # contructor1: url is given
    url = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    viafree = ViafreeIE(url)
    assert viafree.url == url
    assert viafree.geo_bypass == True
    assert viafree.country == "no"
    assert viafree.path == "programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"

    # contructor2: no parameter is given
    viafree2 = ViafreeIE()
    assert viafree2.url == None
    assert viafree2.geo_bypass == False
    assert viafree2.country == None
    assert viafree2.path == None


# Unit

# Generated at 2022-06-24 13:33:04.234315
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')  # embedding video
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:33:13.274980
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_cases = [
        ('https://tv3play.skaties.lv/vinas-melo-labak-10280317/', 'tvplay_skaties'),
        ('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/', 'tvplay_tv3'),
        ('https://play.tv3.lt/aferistai-10047125/', 'tvplay_tv3'),
    ]
    for url, ie_name in test_cases:
        ie_info = common_info_extractor.suitable_ie(url)
        assert ie_info and ie_info.IE_NAME == ie_name, "Expected %r, got %r, for URL %r" % (ie_name, ie_info, url)

# Generated at 2022-06-24 13:33:20.130606
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # pylint: disable=protected-access

    video_id = '757786'
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-24 13:33:31.163867
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg = TVPlayIE()
    assert mtg.IE_NAME == 'mtg'
    assert mtg.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:34.723249
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_info_extractor import test_InfoExtractor
    from .test_utils import SkipTest
    try:
        test_InfoExtractor(TVPlayIE, should_return_playlist_result=False)
    except SkipTest:
        pass

# Generated at 2022-06-24 13:33:40.432495
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ViafreeIE.suitable('https://www.viafree.se/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:33:46.225853
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true'
    TVPlayIE().suitable(url)

# Generated at 2022-06-24 13:33:54.537601
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    video_url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/'+video_id+'?autostart=true'
    geo_country = 'lt'
    tvplay_ie = TVPlayIE('')
    tvplay_ie._initialize_geo_bypass({'countries': [geo_country.upper()]})
    tvplay_ie._real_initialize()
    tvplay_ie._real_extract(video_url)


# Generated at 2022-06-24 13:34:01.399629
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Unit test for constructor of class ViafreeIE
    # Test ViafreeIE with different values
    assert ViafreeIE._VALID_URL.match('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ViafreeIE._VALID_URL.match('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ViafreeIE._VALID_URL.match('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-24 13:34:06.218860
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class TestViafreeIE(ViafreeIE):
        valid_url = 'https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    TestViafreeIE(TestViafreeIE.valid_url)

# Generated at 2022-06-24 13:34:08.482721
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE('', {})

# Generated at 2022-06-24 13:34:14.935300
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for c in ('no', 'se'):
        for p in ('programmer', 'program'):
            with pytest.raises(ExtractorError) as e:
                ViafreeIE().suitable(
                    'http://www.viafree.{}/{}/underholdning/det-beste-vorspielet/sesong-2/episode-1'
                    .format(c, p))
            assert 'xt=urn:btih:50a6e1895db13817b86c2a7c9d393f75db3e43e2' in str(e)



# Generated at 2022-06-24 13:34:24.926379
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor should raise exception if the url is not supported
    with pytest.raises(ExtractorError):
        TVPlayIE("123456789")
    

# Generated at 2022-06-24 13:34:29.297453
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    for extractor in TVPlayIE.__dict__.values():
        if isinstance(extractor, type) and issubclass(extractor, TVPlayIE) and extractor is not TVPlayIE:
            print(extractor._VALID_URL)


# Generated at 2022-06-24 13:34:36.857594
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    g = globals()
    g['TVPlayIE'] = type(
            'TVPlayIE',
            (object,),
            {'_VALID_URL': TVPlayIE._VALID_URL,
             '_TESTS': TVPlayIE._TESTS,
             }
    )
    test_video_urls = [entry['url'] for entry in TVPlayIE._TESTS]
    for video_url in test_video_urls:
        ie = TVPlayIE({})
        assert ie.suitable(video_url)
        assert ie.IE_NAME == 'mtg'
        assert ie.IE_DESC == 'MTG services'
        ie.extract(video_url)

# Generated at 2022-06-24 13:34:40.194450
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.SUCCESS == extractor.true_or_false('true')
    assert ie.SUCCESS == extractor.true_or_false('false')

# Generated at 2022-06-24 13:34:43.532909
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import _test_decryptor
    _test_decryptor('http://tvplayvideos.mtg-api.com/v3/videos/372314')

# Generated at 2022-06-24 13:34:47.187789
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tp = TVPlayIE()

    assert tp.IE_DESC == 'MTG services'
    assert tp.IE_NAME == 'mtg'
    assert 'mtg:418113' in tp._VALID_URL


# Generated at 2022-06-24 13:34:50.333772
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Basic test cases for TVPlayIE."""
    # basic smoke test
    TVPlayIE("http://www.tv3play.se/program/husraddarna/395385?autostart=true")

# Generated at 2022-06-24 13:34:53.361449
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(Exception):
        class InvalidViafreeIE(ViafreeIE):
            _VALID_URL = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'



# Generated at 2022-06-24 13:34:59.625932
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test a TVPlayHomeIE constructor, since we can't test the class via
    # test_play.py.
    tvplayhome_ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert 'Vinās melo labāk' in tvplayhome_ie.IE_NAME

# Generated at 2022-06-24 13:35:10.008498
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:35:10.896753
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test for ViafreeIE"""
    ViafreeIE()

# Generated at 2022-06-24 13:35:18.074882
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:35:19.573818
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    info_extractor



# Generated at 2022-06-24 13:35:31.273508
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    ie.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:35:34.769243
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    v = ViafreeIE(url)
    assert v.suitable(url)



# Generated at 2022-06-24 13:35:39.994458
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    username = 'example'
    password = 'example'
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    # Test constructor
    viafree_ie = ViafreeIE(username, password)
    # Test suitable for URL
    assert(viafree_ie.suitable(url))

if __name__ == '__main__':
    test_ViafreeIE()

# Generated at 2022-06-24 13:35:43.560947
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie.IE_NAME == TVPlayHomeIE.IE_NAME
    assert ie.ie_key() == TVPlayHomeIE.ie_key()



# Generated at 2022-06-24 13:35:45.589396
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("")
    assert ie is not None

# Generated at 2022-06-24 13:35:49.415257
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    # Test create instance
    instance = TVPlayHomeIE(url)
    # Test call method
    instance._real_extract(url)

# Generated at 2022-06-24 13:35:50.588499
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:36:01.057282
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    tvplay_url = 'http://www.tv3play.no/programmer/underholdning/det-beste-vorspielet/711612?autostart=true'
    # find suitable class for each url
    viafree_class = get_suitable_ie(viafree_url)
    tvplay_class = get_suitable_ie(tvplay_url)
    # test that ViafreeIE and TVPlayIE are suitable classes for their respective urls
    assert viafree_class.suitable(viafree_url)
    assert tvplay_class.suitable(tvplay_url)
    # test that ViafreeIE is not suitable for a

# Generated at 2022-06-24 13:36:07.372448
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_utils import get_testdata_file
    import json
    import os

    final_test_data = []
    for file_name in os.listdir(get_testdata_file(os.path.join('mtg', 'tvplay'))):
        if not file_name.startswith('tvplay-'):
            continue
        file_path = os.path.join(get_testdata_file(os.path.join('mtg', 'tvplay')), file_name)
        with open(file_path, 'rb') as f:
            test_data = json.loads(f.read().decode('utf-8'))
        for data in test_data:
            url = data.pop('url')

# Generated at 2022-06-24 13:36:09.857451
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(
        TVPlayHomeIE.ie_key())._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-24 13:36:19.433018
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:36:20.990847
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE(None, None)
    except Exception as e:
        assert "Invalid parameter" in str(e)



# Generated at 2022-06-24 13:36:27.348944
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test with no geo-restricted message
    json_data = '{"_embedded":{"viafreeBlocks":[{"_embedded":{"program":{"guid":"757786","_links":{"streamLink":{"href":"https://viafree-content.mtg-api.com/viafree-content/v1/dk/programs/757786/streams"}}}}}]},"meta":{"title":"Det beste vorspielet - Sesong 2 - Episode 1"}}'

    VIAFREE_REGISTRY = {}
    def _download_json(url, *args, **kwargs):
        if url not in VIAFREE_REGISTRY:
            VIAFREE_REGISTRY[url] = json.loads(json_data)
        return VIAFREE_REGISTRY[url]

    VIAFREE_REGISTRY = {}

# Generated at 2022-06-24 13:36:32.267364
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    test_countries = ['dk', 'no', 'se']
    for country in test_countries:
        url = re.sub(r'\.[a-z]{2}(?=/)', '.' + country, test_url)
        with pytest.raises(ExtractorError):
            ViafreeIE()._real_initialize(url)

# Generated at 2022-06-24 13:36:35.476473
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test to instantiate a class object
    instance = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    # End of test



# Generated at 2022-06-24 13:36:46.207585
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://play.tv3.lt/aferistai-10047125'
    m = re.match(TVPlayHomeIE._VALID_URL, url)
    assert m is not None
    IE = TVPlayHomeIE()
    assert IE.suitable(url)
    # test_TVPlayHomeIE.py:9: ResourceWarning: unclosed <ssl.SSLSocket fd=8, family=AddressFamily.AF_INET, type=SocketKind.SOCK_STREAM, proto=6, laddr=('192.168.56.1', 55185), raddr=('93.174.126.210', 443)>
    #test_TVPlayHomeIE.py:9: ResourceWarning: unclosed <socket.socket fd=9, family=AddressFamily.AF_INET, type=SocketKind.SOCK_ST

# Generated at 2022-06-24 13:36:47.207713
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:36:48.294190
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass  # Nothing to test in constructor

# Generated at 2022-06-24 13:36:58.291521
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Create a subclass of TVPlayHomeIE for testing
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _download_json(self, *args, **kwargs):
            return {
                'movie': {
                    'contentUrl': 'm3u8'
                },
                'assetId': 'video_id',
                'title': {
                    'title': 'title'
                }
            }

    t = TestTVPlayHomeIE()
    t.suitable(None)

# Generated at 2022-06-24 13:37:05.452540
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert isinstance(ie.geo_countries, list)
    assert ie.geo_countries == ['LT', 'LV', 'EE']
    assert ie.geo_bypass is False
    ie = TVPlayHomeIE(None, geo_bypass=True)
    assert ie.geo_bypass is True
    ie = TVPlayHomeIE(None, geo_countries=['LT'])
    assert ie.geo_countries == ['LT']
    assert ie.geo_bypass is False
    ie = TVPlayHomeIE(None, geo_countries=['LT'], geo_bypass=True)
    assert ie.geo_countries == ['LT']
    assert ie.geo_bypass is True

# Generated at 2022-06-24 13:37:15.389167
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country is 'dk'
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country is 'no'
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie.country is 'se'


# Generated at 2022-06-24 13:37:20.760877
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test unit for constructor of class ViafreeIE.
    """
    import sys
    import pytest
    from ytdl.extractor.common import InfoExtractor

    sys.modules['pytest'] = pytest
    sys.modules['pytest.config'] = None
    ViafreeIE.suitable(pytest) == False
    ViafreeIE('test:test') == 'test'


# Generated at 2022-06-24 13:37:31.457985
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    media_group = TVPlayHomeIE()
    if media_group is None:
        raise Exception('Failed to make TVPlayHomeIE instance')
    if media_group._VALID_URL is None:
        raise Exception('Invalid _VALID_URL')
    if media_group._TESTS is None:
        raise Exception('Invalid _TESTS')
    test = media_group._TESTS[0]
    if test['url'] is None:
        raise Exception('Invalid test url')
    if test['info_dict'] is None:
        raise Exception('Invalid test info_dict')
    info_dict = test['info_dict']
    if info_dict['id'] is None:
        raise Exception('Invalid id')
    if info_dict['ext'] is None:
        raise Exception('Invalid ext')

# Generated at 2022-06-24 13:37:38.203474
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ie.suitable('http://play.nova.bg/programi/zdravei-bulgariya/')
    assert ie.GEO_COUNTRIES == ['DK', 'NO', 'SE']


# Generated at 2022-06-24 13:37:45.884879
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_name = 'ViafreeIE'
    # When adding an entry for a new country, make sure to add the country code
    # to the set of GeoRestrictedError.countries in the _real_extract() method of
    # that class.
    valid_countries = {'dk', 'no', 'se'}
    # check that each country has a class
    # the class must be named ViafreeIE + country
    # e.g. ViafreeIE.dk, ViafreeIE.no, ViafreeIE.se
    for country in valid_countries:
        assert hasattr(sys.modules[__name__], class_name + country)
        assert issubclass(getattr(sys.modules[__name__], class_name + country), ViafreeIE)

    # check that all ViafreeIE classes are tested by this unit test


# Generated at 2022-06-24 13:37:47.234268
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-24 13:37:58.771163
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert(TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'))
    assert(TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125'))
    assert(TVPlayHomeIE.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'))

# Generated at 2022-06-24 13:38:00.095955
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:38:09.392128
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # Test case for valid URL

# Generated at 2022-06-24 13:38:20.633654
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    input = ['http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2']

# Generated at 2022-06-24 13:38:27.555128
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:38:39.581283
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Example with 2 arguments
    test_TVPlayHomeIE = TVPlayHomeIE('http://tv3play.tv3.lt/aferistai-10047125')
    assert test_TVPlayHomeIE._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:38:50.954392
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def extract_video(url, params=None, error_re=None):
        if params is None:
            params = {}
        video_id = TVPlayIE._match_id(url)

        video = TVPlayIE._download_json(
            'http://playapi.mtgx.tv/v3/videos/%s' % video_id, video_id, 'Downloading video JSON')

        title = video['title']

        streams = TVPlayIE._download_json(
            'http://playapi.mtgx.tv/v3/videos/stream/%s' % video_id,
            video_id, 'Downloading streams JSON')

        quality = qualities(['hls', 'medium', 'high'])
        formats = []

# Generated at 2022-06-24 13:38:52.452440
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-24 13:38:53.956344
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')

# Generated at 2022-06-24 13:38:54.767986
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)



# Generated at 2022-06-24 13:38:58.957263
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # This test checks that TVPlayHomeIE raises an exception when
    # user tries to access video without correct credentials.
    # For example, video with age restriction.
    with pytest.raises(ExtractorError):
        TVPlayHomeIE('https://tvplay.tv3.lt/vinas-melo-labak-10284641')._real_extract('https://tvplay.tv3.lt/vinas-melo-labak-10284641')

# Generated at 2022-06-24 13:39:06.384397
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert VIAFREE_COUNTRIES

    ie = ViafreeIE(None)
    assert ie.IE_NAME == 'Viafree'
    assert ie.IE_DESC == 'Viafree.se and TV3Play.se'
    assert VIAFREE_COUNTRIES.keys() == sorted(ie._available_countries())
    assert len(ie._available_countries()) > 1
    assert ie._country_fallback('xx') is None
    assert ie._country_fallback('dk') == 'dk'
    assert ie._country_fallback('se') == 'se'

# Test for constructor of class TV3PlayIE

# Generated at 2022-06-24 13:39:15.574833
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print("Testing TVPlayIE")
    from .common import TestCommon
    playbook_url = "http://play.tv3play.lt/programos/pilna-liguma-spele/392471?autostart=true"
    playlist_url = "mtg:392471"

    # Just checking if it works
    print("    Test TVPlayIE url=" + playlist_url)
    t = TestCommon.TestIE(TVPlayIE, playlist_url)
    t.test()

    # Just checking if it works
    print("    Test TVPlayIE url=" + playbook_url)
    t = TestCommon.TestIE(TVPlayIE, playbook_url)
    t.test()

test_TVPlayIE()