

# Generated at 2022-06-24 13:29:18.885920
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    TVPlayHomeIE.su

# Generated at 2022-06-24 13:29:19.573630
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:29:28.314704
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie._download_json('https://playapi.mtgx.tv/', 'test')
    assert ie.cookiejar is not None
    ie = ViafreeIE()
    ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/')
    ie.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300')
    ie.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    ie.suitable('http://www.tv3play.se/premium')

# Generated at 2022-06-24 13:29:29.993126
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test that the ViafreeIE is a subclass of TVPlayIE.
    assert issubclass(ViafreeIE, TVPlayIE)

# Test that the ViafreeIE is not a subclass of TVPlayBaseIE.

# Generated at 2022-06-24 13:29:37.296210
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    inst = TVPlayHomeIE()
    assert inst.TVPLAYHOME_URL_TEMPLATE == 'https://tvplayhome.com/video/%s'
    assert inst._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:29:38.632602
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Testing if correct instance is initiated
    ViafreeIE(None, None)



# Generated at 2022-06-24 13:29:49.663370
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:29:50.541564
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Instantiate the class to make unit test happy
    ie = TVPlayHomeIE()

# Generated at 2022-06-24 13:29:53.195530
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/reality/frihetsgudinnen/sesong-1/episode-1') == True
    assert ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true') == False
    return

# Generated at 2022-06-24 13:29:55.583550
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'


# Generated at 2022-06-24 13:30:01.119404
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-24 13:30:06.462307
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:15.863499
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:30:17.276778
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.search_paths is None
    assert ViafreeIE == ViafreeIE(None, None)



# Generated at 2022-06-24 13:30:19.031982
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:30:27.794810
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # At the time of writing, the link in this test was being redirected to
    # https://tvplay.skaties.lv/vinas-melo-labak-10280317/

    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

    _test_url = 'https://tv3play.tv3.ee/vinas-melo-labak/vinas-melo-labak-10280317/'

    match = re.match(TVPlayHomeIE._VALID_URL, _test_url)

    assert match is not None

# Generated at 2022-06-24 13:30:28.896610
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert isinstance(TVPlayIE(), TVPlayIE)



# Generated at 2022-06-24 13:30:40.737356
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test where we can test/run the constructor of class TVPlayHomeIE"""
    print('### Running test_TVPlayHomeIE ###')
    import sys
    # Del the first argument of sys.argv since it is the name of the file itself
    # sys.argv = sys.argv[1:]

    # TEST CASE 1
    print('TEST CASE1')
    print('URL: https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tvp = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    print(tvp.extract())
    del tvp

    # TEST CASE 2
    print('\nTEST CASE2')

# Generated at 2022-06-24 13:30:53.263370
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:30:53.689375
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-24 13:31:00.566261
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()

    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.suitable('http://www.tv3play.dk/programmer/husraddarna/395385')

    assert not ie.suitable('http://www.viaplay.se/program/husraddarna/395385')
    assert not ie.suitable('http://www.tv3play.se/program/husraddarna/395385')



# Generated at 2022-06-24 13:31:10.257879
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vfie = ViafreeIE('https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert vfie._VALID_URL == 'https?://(?:www\.)?viafree\.(?:dk|no|se)/(?:program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert vfie.country == 'se'
    assert vfie.path == 'program/underhallning/i-like-radio-live/sasong-1/676869'
    assert vfie.geo_country == 'se'


# Generated at 2022-06-24 13:31:18.522976
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'TVPlayHome'
    assert TVPlayHomeIE.ie_key() == ie.ie_key()
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317') is True
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317') is True
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125') is True
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') is True

# Generated at 2022-06-24 13:31:24.579856
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:31:36.317047
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test case from TVPlayHomeIE._TESTS
    video_id = '366367'
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

# Generated at 2022-06-24 13:31:46.215879
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:31:49.060944
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # We don't really care if this works or not.
    # Just please don't crash.
    TVPlayHomeIE()._real_extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125')

# Generated at 2022-06-24 13:31:54.617872
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Empty dict representing empty page content
    page_content = {}
    meta_data = {"title":{"title":""}}
    m3u8_url = ""

    # create instance of class TVPlayHomeIE
    tphie = TVPlayHomeIE(page_content, meta_data, m3u8_url)
    tphie.url = ""
    tphie.age_limit = 0
    tphie.formats = []

    # Check if return value of function _real_extract is correct

# Generated at 2022-06-24 13:32:01.302102
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class TestTVPlayIE(TVPlayIE):
        def _download_html(self, url, video_id, Note):
            raise ExtractorError('test download_html', expected=True)

        def _extract_info_dict(self, *args, **kwargs):
            raise ExtractorError('test extract_info_dict', expected=True)

    TestTVPlayIE().extract('http://playapi.mtgx.tv/v3/videos/1')



# Generated at 2022-06-24 13:32:06.024348
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ps.determine_ext('/path/to/mp4') == 'mp4'

    assert ps.parse_duration('5:25') == 325


# Unit tests for TVPlayIE._real_extract()

# Generated at 2022-06-24 13:32:17.794785
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test constructor of class TVPlayHomeIE.
    """
    # Create instance of class TVPlayHomeIE
    tvplayhome_ie = TVPlayHomeIE()

    # Check if it is an instance of InfoExtractor
    from youtube_dl.extractor import InfoExtractor
    if not isinstance(tvplayhome_ie, InfoExtractor):
        raise Exception('TVPlayHomeIE is not an instance of InfoExtractor!')

    # Check for correct _VALID_URL
    VALID_URL = 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:32:21.529962
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'se'
    assert ie.path == 'program/underhallning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-24 13:32:25.344494
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert 'Kādi ir īri? - Viņas melo labāk' in t._download_json(
        'http://playapi.mtgx.tv/v3/videos/418113', '418113', 'Downloading video JSON')[
            'title']

# Generated at 2022-06-24 13:32:36.765917
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test case 1: japanese
    japanese_url = 'https://play.tv3.lt/aferistai-10047125'

# Generated at 2022-06-24 13:32:45.398271
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.__class__ == TVPlayHomeIE
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:32:50.158827
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class DummyClass():
        pass
    a = DummyClass()
    a.suitable = lambda x: False
    b = DummyClass()
    b.suitable = lambda x: True
    i = ViafreeIE([b, a])
    assert i.IE_NAME == b.IE_NAME
    assert not ViafreeIE([a, a]).suitable('url')

# Generated at 2022-06-24 13:32:53.186957
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie._VALID_URL is not None
    assert ie.__version__ is not None

# Generated at 2022-06-24 13:33:04.581668
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Just check the result of constructing this class
    # Don't really need to test it

    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    video_id = '395385'
    TVPlayIE(TVPlayIE.ie_key())._real_extract(url)

    url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    video_id = '409229'
    TVPlayIE(TVPlayIE.ie_key())._real_extract(url)

    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'

# Generated at 2022-06-24 13:33:14.049174
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE("http://www.tv3play.se/program/husraddarna/395385?autostart=true")
    TVPlayIE("https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true")
    TVPlayIE("http://tvplay.skaties.lv/parraides/tv3-zinas/760183")
    TVPlayIE("http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true")
    TVPlayIE("http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869")
    TVPlayIE("mtg:418113")


# Generated at 2022-06-24 13:33:20.505573
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    warning_log.start()

    import requests
    session = requests.Session()
    ie = ViafreeIE()
    ie._download_json = lambda url, video_id, note='Downloading JSON metadata': session.get(url).json()
    # Testing url with forbidden video stream
    url = 'https://www.viafree.se/program/reality/paradise-hotel/sasong-11/avsnitt-6'
    try:
        ie.extract(url)
    except ExtractorError as e:
        error = e.args[0]
        if error == 'This content might not be available in your country due to copyright reasons':
            print('%s is OK' % url)
        else:
            raise AssertionError(error)
    else:
        raise AssertionError('No error was raised')


# Generated at 2022-06-24 13:33:25.332813
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie.suitable(url)
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.ie_key() != 'TVPlay'
    assert ie.ie_key() != 'TVPlayIE'
    assert ie.ie_key() != 'TVPlayTV3'
    assert ie.ie_key() != 'TVPlaySkatiesLV'
    assert ie.ie_key() != 'TVPlayTV3LT'
    assert ie.ie_key() != 'TVPlayTV3EE'


# Generated at 2022-06-24 13:33:27.061645
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie._VALID_URL == r'(?x)mtg:(?P<id>\d+)'



# Generated at 2022-06-24 13:33:31.014566
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'http://play.tv3play.tv3play.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie = TVPlayHomeIE(url, {})
    print(ie)
    #assert ie.country == 'lv'

# Generated at 2022-06-24 13:33:32.436720
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """ Test for the constructor of class ViafreeIE """
    # This should not raise an exception
    ViafreeIE()



# Generated at 2022-06-24 13:33:36.917645
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:33:40.440562
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE(None)
    assert viafree_ie.GEO_COUNTRIES == ['DK', 'NO', 'SE']



# Generated at 2022-06-24 13:33:46.604924
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_html import fake_headers

# Generated at 2022-06-24 13:33:53.641634
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('static', 'http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:33:57.435194
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    ViafreeIE([test_url], {'geo_bypass_country': 'SE'})


# Generated at 2022-06-24 13:34:04.310829
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    _instantiator = TVPlayIE.extract_url # Reference to the constructor method
    cls = _instantiator(url) # Create an instance
    assert cls.__class__.__name__ == 'TVPlayIE' # Check if instance was created successfully
    return cls


# Generated at 2022-06-24 13:34:14.122038
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:34:18.577474
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    g = globals()
    for each in g['TVPlayIE']._TESTS:
        if each.get('only_matching', False):
            continue
        url = each['url']
        url_res = g['TVPlayIE']._VALID_URL.findall(url)
        print('url: %s' % url)
        print('url_res: %s' % url_res)
        assert url_res == [url]

# Generated at 2022-06-24 13:34:30.476089
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    constructor_test(TVPlayHomeIE, [
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
    ])

# Generated at 2022-06-24 13:34:32.008584
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert ie


# Generated at 2022-06-24 13:34:33.052307
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()

# Generated at 2022-06-24 13:34:37.480448
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import get_testcases
    from .test_common import make_result_testcases
    Test = make_result_testcases(TVPlayHomeIE.suitable, lambda x: x)
    Test.addTests(get_testcases(TVPlayHomeIE))
    return Test



# Generated at 2022-06-24 13:34:43.027506
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE.suitable('https://mtg:418113')
    assert not TVPlayIE.suitable('https://www.tv3play.dk/programmer/husraddarna/395385')
    assert not TVPlayIE.suitable('https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-24 13:34:48.488507
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    input_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    output_url = 'https://viafree-content.mtg-api.com/viafree-content/v1/no/path/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ViafreeIE._VALID_URL == re.compile(r'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)')

# Generated at 2022-06-24 13:34:54.798087
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvphomeIE = TVPlayHomeIE()
    if tvphomeIE.suitable(url) == False:
        raise Exception('The TVPlayHomeIE is not suitable with this URL: %s' % url)
    try:
        info = tvphomeIE.extract(url)
    except Exception as e:
        raise Exception('Could not extract %s: %s' % (url, str(e)))


# Generated at 2022-06-24 13:34:55.814538
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)



# Generated at 2022-06-24 13:35:07.278666
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from youtube_dl.utils import AttributeDict
    from youtube_dl.downloader.rtmp import RTMPDownloader

    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()
    ie = TVPlayIE()


# Generated at 2022-06-24 13:35:08.633768
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-24 13:35:19.483413
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:35:21.382882
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print('Test ' + __name__)
    assert TVPlayIE(None)

# Generated at 2022-06-24 13:35:25.413699
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    test_video_id = '366367'

    check_video_id_for_url(url, test_video_id)

# Generated at 2022-06-24 13:35:32.291611
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    # Test example from extractor docstring
    ie = TVPlayIE()
    ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

    # Test example from issue #3475
    ie = TVPlayIE()
    ie.extract('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')



# Generated at 2022-06-24 13:35:36.049961
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # there are many flavours of URL
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    tvplay = TVPlayIE()
    assert tvplay.suitable(url)
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'
    assert tvplay.get_id(url) == '409229'
    assert tvplay.get_url(url) == '409229'


# Generated at 2022-06-24 13:35:37.166901
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE('Viasat4')
        assert False
    except ViafreeIE.IEKeyError:
        assert True

# Generated at 2022-06-24 13:35:38.573588
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE()
    assert obj.url_result('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', None)

# Generated at 2022-06-24 13:35:43.915012
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL, ie.IE_NAME
    assert ie._TESTS, ie.IE_NAME
    assert ie._download_json, ie.IE_NAME
    assert ie._extract_f4m_formats, ie.IE_NAME
    assert ie._extract_m3u8_formats, ie.IE_NAME
    assert ie._match_id, ie.IE_NAME

# Generated at 2022-06-24 13:35:47.014489
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']
    assert ie.IE_NAME == ie._TESTS[0]

# Generated at 2022-06-24 13:35:54.276687
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        assert TVPlayIE.IE_NAME in TVPlayIE.ie_key()
    except AssertionError:
        exception_type, exception_value, traceback = sys.exc_info()
        logger.error('''
TVPlayIE.IE_NAME not in TVPlayIE.ie_key()
ie_name: {}
ie_key: {}
'''.format(TVPlayIE.IE_NAME,
    TVPlayIE.ie_key()))
        raise exception_value


# Generated at 2022-06-24 13:36:01.474995
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie._download_json( 'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/programmer/underholdning/i-like-radio-live/sasong-1/episode-1')
    ie._download_json('https://viafree-content.mtg-api.com/viafree-content/v1/se/path/programmer/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')

# Generated at 2022-06-24 13:36:04.759344
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE()
    expected_urls = [r'%s.*' % url for url in tvplayie._TESTS]
    assert len(tvplayie._VALID_URL) == 1
    assert len(expected_urls) == len(tvplayie._TESTS)
    assert tvplayie._VALID_URL[0] in expected_urls


# Generated at 2022-06-24 13:36:11.210499
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = mtg_url('757786')
    assert ViafreeIE._VALID_URL == ViafreeIE._VALID_URL_TEMPLATE % ViafreeIE._TESTS[0]['url']
    assert ViafreeIE._VALID_URL == ViafreeIE._VALID_URL_TEMPLATE % url
    if ViafreeIE._TESTS[0]['url'] == url:
        raise Exception('Possible breaking change. Add new test URL to Viafree IE')



# Generated at 2022-06-24 13:36:20.514099
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Create an object of class ViafreeIE
    instance = ViafreeIE()

    # Check if _VALID_URL matches with the given url
    assert instance._VALID_URL == r'''(?x)https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

    # Check if _TESTS doesn't have any empty dictionary element
    assert not any(not element for element in instance._TESTS)

    # Check if _GEO_BYPASS is set to false
    assert instance._GEO_BYPASS == False

    # Check if suitable is set to false when TVPlayIE.suitable(url) is true

# Generated at 2022-06-24 13:36:28.261356
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = ViafreeIE._VALID_URL
    m = re.match(url, 'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert m
    assert m.groupdict()['country'] == 'no'
    assert m.groupdict()['id'] == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    m = re.match(url, 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert m
    assert m.groupdict()['country'] == 'se'

# Generated at 2022-06-24 13:36:29.166840
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    inst = TVPlayHomeIE("dummy")


# Generated at 2022-06-24 13:36:36.537139
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl.extractor.tvplay import TVPlayHomeIE
    TVPlayHomeIE._VALID_URL = r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.SUFFIX == '.ee'

# Generated at 2022-06-24 13:36:40.481407
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import os
    import sys
    import inspect
    import unittest
    import tvplayIE

    path = inspect.getfile(inspect.currentframe())
    dirname = os.path.dirname(os.path.abspath(path))
    os.chdir(dirname)
    sys.path.insert(0, dirname)

    class TVPlayIETest(unittest.TestCase):
        def test_TVPlayIE(self):
            tvplayIE.TVPlayIE(None)

    if __name__ == '__main__':
        unittest.main()

# Generated at 2022-06-24 13:36:49.525507
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    de_factory = TVPlayHomeIE._build_video_url('afefseg', '123456', 'swe')
    da_factory = TVPlayHomeIE._build_video_url('afefseg', '123456', 'dk')
    lt_factory = TVPlayHomeIE._build_video_url('afefseg', '123456', 'lv')
    ee_factory = TVPlayHomeIE._build_video_url('afefseg', '123456', 'ee')
    assert de_factory == 'https://play.tv3.ee/afefseg/123456'
    assert da_factory == 'https://play.tv3.ee/afefseg/123456'

# Generated at 2022-06-24 13:36:52.384642
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_utils import test_data_dir
    from .test_utils import TestIE
    from .test_utils import MockIE
    assert isinstance(TVPlayIE(), (TestIE, MockIE))
    assert isinstance(TVPlayIE(test_data_dir), (TestIE, MockIE))

# Generated at 2022-06-24 13:36:53.579335
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie



# Generated at 2022-06-24 13:37:02.204559
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    runner = Runner()

# Generated at 2022-06-24 13:37:03.414468
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE) is True


# Generated at 2022-06-24 13:37:07.367295
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert IE.name == "TVPlayHomeIE"



# Generated at 2022-06-24 13:37:09.373008
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._GEO_BYPASS == False, 'ViafereIE is not geo restricted'

# Generated at 2022-06-24 13:37:14.635191
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    fetcher = TVPlayHomeIE()
    assert fetcher.extractor._VALID_URL == TVPlayHomeIE._VALID_URL
    assert fetcher.extractor._TESTS == TVPlayHomeIE._TESTS
    assert fetcher.extractor.GEO_COUNTRIES == ['LT', 'LV', 'EE']

# Generated at 2022-06-24 13:37:18.548510
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE(TVPlayIE.IE_NAME, TVPlayIE.IE_DESC).extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-24 13:37:19.217941
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-24 13:37:21.325305
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .. import ViafreeIE
    a=ViafreeIE()
    assert(isinstance(a, ViafreeIE))


# Generated at 2022-06-24 13:37:23.092484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import TVPlayHomeIE
    ie = TVPlayHomeIE()
    assert(ie.name == 'TVPlayHome')

# Generated at 2022-06-24 13:37:33.362128
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import requests
    t = TVPlayIE(requests.Session())
    assert t._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'
   

# Generated at 2022-06-24 13:37:34.773253
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'


# Generated at 2022-06-24 13:37:36.548226
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    assert ie._match_id(url) is None


# Generated at 2022-06-24 13:37:44.947599
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:37:50.436361
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    unit = TVPlayHomeIE(None)
    assert unit._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:38:01.810144
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('test')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:38:03.865468
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test that constructor of TVPlayIE is not throwing exceptions.
    ie = TVPlayIE()


# Generated at 2022-06-24 13:38:11.695057
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:15.278075
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie_instance = ViafreeIE()
    assert isinstance(ie_instance, InfoExtractor)
    assert ie_instance.country == None
    assert ie_instance.path == None


# Generated at 2022-06-24 13:38:16.034698
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:38:18.803067
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    inst = TVPlayIE()
    assert inst._VALID_URL == TVPlayIE._VALID_URL
    assert inst._TESTS == TVPlayIE._TESTS

# Generated at 2022-06-24 13:38:27.079090
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    url = 'http://www.viafree.se/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    import sys
    from rtsp import RTSPIE
    print(ie.suitable(url))
    print(sys.modules[__name__])

# Generated at 2022-06-24 13:38:33.990222
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not ViafreeIE.suitable('http://www.tv3play.no/sumo/video/102697/sjekk-ut-de-superklare-bildene-fra-sony-action-cam')

# Generated at 2022-06-24 13:38:44.887188
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    original_class = TVPlayHomeIE
    original_extract = TVPlayHomeIE._real_extract

    class MockIE(TVPlayHomeIE):
        def __init__(self, *args, **kwargs):
            super(MockIE, self).__init__(*args, **kwargs)
            self.called = False
            self.is_download_webpage_called = False

        def _download_webpage(self, *args, **kwargs):
            self.is_download_webpage_called = True
            return original_extract(self, *args, **kwargs)


# Generated at 2022-06-24 13:38:46.416210
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Instance of TVPlayHomeIE
    TVPlayHomeIE()



# Generated at 2022-06-24 13:38:57.147678
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test cases for constructor of class TVPlayIE."""
    tvplay_ie = TVPlayIE()
    tvplay_ie_geo = TVPlayIE(geo_countries=['LV'])
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie_geo.geo_countries == ['LV']

    def assert_valid_url(url):
        assert TVPlayIE._VALID_URL == re.compile(TVPlayIE._VALID_URL)
        # check that the url passes the regexp
        assert re.match(TVPlayIE._VALID_URL, url)
        # check that the regexp matches the whole url
        assert re.match(TVPlayIE._VALID_URL, url).group() == url
        # check that the regexp does not match urls starting with

# Generated at 2022-06-24 13:39:06.183192
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:39:07.242989
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Simply check if class can be initialized
    ViafreeIE()

