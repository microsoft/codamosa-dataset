

# Generated at 2022-06-24 13:29:15.040960
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import determines_ext
    from . import info_dict

    m = TVPlayHomeIE._VALID_URL.match('tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/?autostart=true')
    assert m is not None
    assert m.groups() == ('10280317',)

    ie = TVPlayHomeIE(m.groups()[0])
    ie_dict = ie.__dict__
    assert ie_dict['_VALID_URL'] == TVPlayHomeIE._VALID_URL
    assert ie_dict['_TESTS'] == TVPlayHomeIE._TESTS
    assert ie_dict['IE_NAME'] == 'tvplay'
    assert ie_dict['_GEO_BYPASS'] is True

# Generated at 2022-06-24 13:29:26.877671
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE().extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE().extract('https://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE().extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE().extract('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    TVPlayIE().extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:29:29.113057
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Simple test of object creation.
    """
    ie = ViafreeIE()
    assert ie.ie_key() == 'Viafree'
    assert ie.ie_name() == 'Viaplay: Viafree'
    assert ie.SUCCESS == 'SUCCESS'
    assert ie._GEO_BYPASS == False

# Generated at 2022-06-24 13:29:41.258403
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    tvhome = TVPlayHomeIE(url)
    tvhome.TVPlayIE._VALID_URL = r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:29:51.802957
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Unit test for constructor of class TVPlayHomeIE.
    """
    # Url of TVPlayHomeIE is passed as a first parameter.
    # Instance of InfoExtractor is a second parameter.
    instance = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', TVPlayHomeIE)
    instance.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    instance.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:30:02.097406
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    eq_(ie.domain, 'tv3.lt')
    eq_(ie.expected_id, '366367')

    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    eq_(ie.domain, 'skaties.lv')
    eq_(ie.expected_id, '416113')

    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    eq_(ie.domain, 'tv3.ee')
   

# Generated at 2022-06-24 13:30:05.196458
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    assert isinstance(instance, InfoExtractor)
    assert isinstance(instance, TVPlayBaseIE)


# Generated at 2022-06-24 13:30:14.945611
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229")
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:24.731847
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    assert instance._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert TVPlayHomeIE.__name__ == "TVPlayHomeIE"
    assert TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert not TVPlayHomeIE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")

# Generated at 2022-06-24 13:30:31.374187
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:30:33.998344
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))



# Generated at 2022-06-24 13:30:38.013513
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TestTVPlayIE = TVPlayIE.__name__
    import unittest
    from . import test_common
    test_common.test_class(TestTVPlayIE)

# test_TVPlayIE()



# Generated at 2022-06-24 13:30:40.682526
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:42.802571
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TODO: unittest
    # Unit test requires access to outside server.
    pass



# Generated at 2022-06-24 13:30:55.284833
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()

# Generated at 2022-06-24 13:31:03.362560
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:31:14.228118
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 13:31:25.122671
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:31:25.872818
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-24 13:31:35.977402
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # One of the tests for ViafreeIE
    url= 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    # Expected title for the test
    expected_title = 'Det beste vorspielet - Sesong 2 - Episode 1'

    # Extracting the information from the url using the constructor of the class
    info_dict = ViafreeIE()._real_extract(url)
    # Extracting the title from the info_dict
    title = info_dict.get('title')
    # Asserting whether title extracted is same as the one expected
    assert expected_title == title

# Generated at 2022-06-24 13:31:45.951293
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_cases = [
        {
            'name': '1',
            'data': 'https://play.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true',
            'expected': 'mtg:230898'
        },
        {
            'name': '2',
            'data': 'http://www.tv3play.se/program/husraddarna/395385?autostart=true',
            'expected': 'mtg:395385'
        },
    ]
    for test_case in test_cases:
        print(test_case['name'])

# Generated at 2022-06-24 13:31:52.328338
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Check that all constructors are supported."""
    from ..compat import parse_qs
    from ..jsinterp import JSInterpreter

    def _get_cookies(url):
        return 'qwerty=qwerty;'

# Generated at 2022-06-24 13:31:59.722870
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None, 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ViafreeIE(None, 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE(None, 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-24 13:32:01.118298
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("http://",{})
    assert ie is not None



# Generated at 2022-06-24 13:32:09.413383
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from youtube_dl.utils import SearchInfoExtractor
    from youtube_dl.tests.test_extractor import FakeYDL

    ydl = FakeYDL()
    ie = SearchInfoExtractor(ydl)
    ie.report_warning = lambda msg: None
    ie.add_info_extractor(TVPlayIE())

    assert ie.extract_info(TVPlayIE._VALID_URL, download=False) == {'url': TVPlayIE._VALID_URL, 'ie_key': 'TVPlay'}



# Generated at 2022-06-24 13:32:16.713063
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.lt/aferistai-10047125/')
    assert ie.suitable('http://tvplay.tv3.lt/aferistai-10047125/')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:32:20.746208
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    This function is used to run a test on TVPlayIE.
    """
    tvPlay_ie = TVPlayIE()
    assert tvPlay_ie.IE_NAME == 'mtg'
    assert tvPlay_ie.IE_DESC == 'MTG services'



# Generated at 2022-06-24 13:32:32.114589
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE.suitable('https://play.tv3.lt/kursas-pirmais-10047960')
    assert ie == TVPlayHomeIE
    ie = TVPlayHomeIE.suitable('https://tvplay.tv3.lt/kursas-pirmais-10047960')
    assert ie == TVPlayHomeIE
    ie = TVPlayHomeIE.suitable('https://tv3play.tv3.lt/kursas-pirmais-10047960')
    assert ie == TVPlayHomeIE
    ie = TVPlayHomeIE.suitable('https://tvplay.tv3.ee/kursas-pirmais-10047960')
    assert ie == TVPlayHomeIE

# Generated at 2022-06-24 13:32:33.703469
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL



# Generated at 2022-06-24 13:32:45.398376
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.tv3play.no/programmer/husraddarna/395385?autostart=true')
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.suitable('http://www.viafree.no/programmer/husraddarna/395385?autostart=true')
    assert ie.suitable('http://www.viafree.se/program/husraddarna/395385?autostart=true')
    assert not ie.suitable('http://www.tv6play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:32:46.355834
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global TVPlayIE
    assert TVPlayIE is not None



# Generated at 2022-06-24 13:32:54.795147
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # We need to set the geo verification header upfront for the test to pass
    class MockViafreeIE(ViafreeIE):
        def _download_json(self, *args, **kwargs):
            return {
                "embedded": {
                    "prioritizedStreams": [{
                        "links": {
                            "stream": {
                                "href": "https://somem3u8url.com"
                            }
                        }
                    }]
                }
            }
    assert(MockViafreeIE.suitable('https://viafree.dk/program/series-title') is False)
    assert(MockViafreeIE.suitable('https://play.tv4play.se/program/series-title') is True)



# Generated at 2022-06-24 13:33:06.166006
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113'
    result = t._real_extract(url)
    assert result['id'] == '418113'
    assert result['title'] == 'Kādi ir īri? - Viņas melo labāk'
    assert result['description'] == 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.'
    assert result['series'] == 'Viņas melo labāk'
    assert result['season'] == '2.sezona'
    assert result['season_number'] == 2
    assert result['duration'] == 25
    assert result['timestamp'] == 1406097056

# Generated at 2022-06-24 13:33:09.798591
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.ie_key() == 'mtg'
    assert tvplay.ie_name() == 'mtg'
    assert tvplay.__name__ == 'TVPlayIE'
    assert tvplay.ie_description() == 'MTG services'


# Generated at 2022-06-24 13:33:17.670186
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:33:18.856765
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.constructor_name == 'TVPlayHomeIE'

# Generated at 2022-06-24 13:33:19.339942
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    main()

# Generated at 2022-06-24 13:33:22.542511
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'

    tphie = TVPlayHomeIE(TVPlayHomeIE._downloader,
                         TVPlayHomeIE._match_id(test_url), {}, False)

    assert tphie._VALID_URL is not None


# Generated at 2022-06-24 13:33:26.676264
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test constructor of the class TVPlayHomeIE."""
    assert(TVPlayHomeIE._VALID_URL ==
           'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)')

test_TVPlayHomeIE()



# Generated at 2022-06-24 13:33:28.173338
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(TVPlayIE.IE_NAME, TVPlayIE.IE_DESC)

# Generated at 2022-06-24 13:33:37.649421
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:44.154777
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_utils import TestLoggingInterceptor
    from .test_utils import MockSizedRequestHandler
    from .test_utils import MockServer

    class TestHttpRequestHandler(MockSizedRequestHandler):
        def do_GET(self):
            if self.path == '/sb/public/asset/366367':
                self.send_response(200)
                self.send_header('Content-Type', 'application/json')
                self.send_header('Content-Length', '5665')
                self.end_headers()

# Generated at 2022-06-24 13:33:47.191922
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()._VALID_URL == TVPlayHomeIE._VALID_URL
    assert TVPlayHomeIE()._TESTS == TVPlayHomeIE._TESTS


# Generated at 2022-06-24 13:33:48.491879
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable(None)
    assert True

# Generated at 2022-06-24 13:33:50.147168
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL



# Generated at 2022-06-24 13:33:54.489502
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor of class InfoExtractor
    ie = InfoExtractor(TVPlayIE.IE_NAME)
    assert ie.ie_key() == 'TVPlay'
    assert ie.ie_name() == 'MTG'
    assert ie.ie_desc() == 'MTG services'

# Generated at 2022-06-24 13:34:02.069265
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tph = TVPlayHomeIE()
    assert TVPlayHomeIE._VALID_URL == tph._VALID_URL
    assert not tph.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/")
    assert tph.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354")
    assert not tph.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse-1004435")
    assert not tph.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/-10044354")

# Generated at 2022-06-24 13:34:12.756768
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:34:16.453556
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import warnings
    warnings.filterwarnings('ignore', category=DeprecationWarning) # viafree.dk was shut down
    with pytest.raises(ExtractorError, match='No %s could be extracted' % _type):
        ViafreeIE()._extract_item('mtg:', 'mtg:')



# Generated at 2022-06-24 13:34:23.690879
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:34:34.876090
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TVPlayHomeIE_Test(TVPlayHomeIE):
        pass

    class TVPlayHomeIE_Test2(TVPlayHomeIE):
        _VALID_URL = TVPlayHomeIE._VALID_URL + '1'

    # Test default value
    ie = TVPlayHomeIE_Test()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

    # Test subclass override
    ie = TVPlayHomeIE_Test2()
    assert ie._VALID_URL == TVPlayHomeIE_Test2._VALID_URL

    # Test the constructor fail
    delattr(TVPlayHomeIE_Test, '_VALID_URL')
    with pytest.raises(TypeError):
        TVPlayHomeIE_Test()

    delattr(TVPlayHomeIE_Test2, '_VALID_URL')
   

# Generated at 2022-06-24 13:34:46.506532
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Run the test only once
    # Using try-except block because of the unittest module
    try:
        test_TVPlayHomeIE.count += 1
    except AttributeError:
        test_TVPlayHomeIE.count = 1
    if test_TVPlayHomeIE.count != 1:
        return


    # Test if the constructor of TVPlayHomeIE is executed
    # It can be done by checking the value of one of its attribute,
    # which is '_VALID_URL' in this case because of it's unique to the constructor
    # It's set to the wanted value in the constructor of TVPlayHomeIE
    tvplayhomeIE = TVPlayHomeIE(None)
    assert hasattr(tvplayhomeIE, '_VALID_URL')
    assert tvplayhomeIE._VALID_URL != ''



# Generated at 2022-06-24 13:34:55.620898
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert "mtg" == tvplay_ie.ie_key()
    assert "TVPlayIE" == tvplay_ie.ie_name()
    assert "MTG services" == tvplay_ie.ie_desc()
    assert "http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true" == tvplay_ie.extract("http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true")

# Generated at 2022-06-24 13:35:07.059359
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def _test_valid_url(self, url, valid):
        self.assertEqual(bool(ViafreeIE.suitable(url)), valid)

    test = type('test', (unittest.TestCase,), {})()
    _test_valid_url(test, 'https://www.tv4play.se/sport/esport/lol/idrottbladet-esport-38-559955', True)
    _test_valid_url(test, 'https://www.tv4play.se/program/husraddarna/husraddarna-hallbar-uthyrning-4649456?autostart=true', True)

# Generated at 2022-06-24 13:35:15.137017
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)
    # Check _VALID_URL matches only valid urls
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    # Check _TESTS matches only valid urls

# Generated at 2022-06-24 13:35:26.261219
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Create a dummy field storage
    class FieldStorage:
        def __init__(self, dict):
            self.dict = dict

        def __getitem__(self, key):
            return self.dict[key]

    # Create a dummy object
    class FakeObject:
        def __init__(self, **entries):
            self.__dict__.update(entries)
    path = '/home/tyue/youtube-dl/test/tvplay-home-urls'
    with open(path, 'r') as f:
        while True:
            line = f.readline()
            if not line:
                break
            line = line.strip('\n')
            video_id = line.split('/')[-1]
            video_id = video_id[:video_id.find('-')]


# Generated at 2022-06-24 13:35:28.906699
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113') is True

# Generated at 2022-06-24 13:35:35.984907
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/test')
    ie.test_constructor()
    ie = TVPlayHomeIE('https://play.tv3.ee/test')
    ie.test_constructor()
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/test')
    ie.test_constructor()
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/test')
    ie.test_constructor()



# Generated at 2022-06-24 13:35:42.708558
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:35:53.019426
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert instance._VALID_URL == '(?:mtg:|https?://(?:www\\.)?(?:tvplay(?:\\.skaties)?\\.lv(?:/parraides)?|(?:tv3play|play\\.tv3)\\.lt(?:/programos)?|tv3play(?:\\.tv3)?\\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\\.no|(?:tv3play|viafree)\\.dk)/programmer|play\\.nova(?:tv)?\\.bg/programi)/(?:[^/]+/)+)\\d+'



# Generated at 2022-06-24 13:35:53.503970
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:35:54.233080
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:35:57.755839
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Constructor test for ViafreeIE."""
    assert ViafreeIE._VALID_URL is ViafreeIE.IE_DESC._VALID_URL
    assert ViafreeIE._TESTS is ViafreeIE.IE_DESC._TESTS

# Generated at 2022-06-24 13:36:02.376411
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://play.tv3play.lt/vinas-melo-labak/vinas-melo-labak-10280317/");
    assert ie.get_setting('URL') == "https://play.tv3play.lt/vinas-melo-labak/vinas-melo-labak-10280317/"


# Generated at 2022-06-24 13:36:03.299856
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)

# Generated at 2022-06-24 13:36:05.500961
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv = TVPlayIE()
    assert tv.IE_NAME == 'mtg'
    assert tv.IE_DESC == 'MTG services'


# Generated at 2022-06-24 13:36:12.331122
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable(None) == False
    assert ViafreeIE.suitable('https://www.tv3play.se') == False
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == True
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == False



# Generated at 2022-06-24 13:36:15.459156
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().extract('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    assert TVPlayIE().extract('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')


# Generated at 2022-06-24 13:36:17.056531
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    r = ViafreeIE()
    assert r.name == 'viafree'
    assert r.IE_NAME == 'viafree'



# Generated at 2022-06-24 13:36:18.263688
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-24 13:36:27.623717
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Channel URL
    channel_url = 'https://tvplay.skaties.lv/t/tv3'
    channel_data = None
    with open('test/testdata/%s' % 'tv3_channel1.json', 'rb') as stream:
        channel_data = stream.read().decode('utf8')
    channel_data = channel_data.replace(
        '\\u003Ca href=\\"/t/tv3\\" class=\\"channel-title\\"\\u003E', ''
    )
    channel_data = channel_data.replace('\\u003C\\/a\\u003E', '')
    channel_data = channel_data.replace('\\n', '').strip()
    channel_data = channel_data.replace('\\"', '"')
    channel_data = channel_data

# Generated at 2022-06-24 13:36:29.639208
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    ViafreeIE.__init__()
    """
    viafreeie = ViafreeIE()
    assert isinstance(viafreeie, ViafreeIE)



# Generated at 2022-06-24 13:36:36.922578
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    temp_dir = tempfile.mkdtemp()


# Generated at 2022-06-24 13:36:40.917693
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317/')
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-24 13:36:46.938156
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')._VALID_URL == \
           r'(?x)https?://(?:www\.)?tvplay(?:\.skaties)?\.lv(?:/parraides)?/(?:[^/]+/)+(?P<id>\d+)'

# For all services in this extractor _VALID_URL should be the same

# Generated at 2022-06-24 13:36:48.729522
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, {}, {}, None, None)
    assert ie



# Generated at 2022-06-24 13:36:54.819294
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_ie = ViafreeIE()
    assert test_ie.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1") is True
    assert test_ie.suitable("http://play.tv2.no/programmer/entertainment/paradise-hotel/sesong-2016/episode-3") is False



# Generated at 2022-06-24 13:37:02.244689
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL.match('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie._VALID_URL.match('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie._VALID_URL.match('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')

# Generated at 2022-06-24 13:37:06.357098
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return

    # No need to test an instance of ViafreeIE since it doesn't inherit from
    # YoutubeIE nor it is the base of any descendant.
    # Calling its constructor directly is enough to check that the regex is
    # still functional.
    ViafreeIE('http://www.viafree.no')



# Generated at 2022-06-24 13:37:17.838510
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info = TVPlayIE()._get_info({'url': 'http://www.tv6play.se/program/husraddarna/395385?autostart=true'})
    assert info.download_info['id'] == '395385', 'test for ID failed'
    assert info.download_info['title'] == 'Husräddarna S02E07', 'test for title failed'
    assert info.download_info['description'] == 'md5:f210c6c89f42d4fc39faa551be813777', 'test for description failed'
    assert info.download_info['duration'] == 2574, 'test for duration failed'
    assert info.download_info['timestamp'] == 1400596321, 'test for timestamp failed'

# Generated at 2022-06-24 13:37:21.516407
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable(url)
    assert ViafreeIE.suitable(url)

# Generated at 2022-06-24 13:37:22.469827
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()

# Generated at 2022-06-24 13:37:25.873621
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert isinstance(viafree, ViafreeIE)
    assert isinstance(viafree, InfoExtractor)

# Generated at 2022-06-24 13:37:28.592310
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')


# Generated at 2022-06-24 13:37:39.357469
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:37:40.344943
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE.test()

# Generated at 2022-06-24 13:37:43.327156
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test correct TVPlayIE instantiation
    instance = TVPlayIE(TVPlayIE.IE_NAME)
    assert isinstance(instance, TVPlayIE)



# Generated at 2022-06-24 13:37:47.960298
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie._check_url_result(TVPlayHomeIE._VALID_URL, TVPlayHomeIE._TESTS)
    assert ie._check_url_result(TVPlayHomeIE._VALID_URL, TVPlayHomeIE._TESTS) == None

# Generated at 2022-06-24 13:37:50.541826
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._VALID_URL == TVPlayIE._TESTS[0]['url'], 'TVPlayIE url must match regex'

# Generated at 2022-06-24 13:37:54.761226
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()._real_extract(
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    )


# Generated at 2022-06-24 13:37:57.498733
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()._real_extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-24 13:38:06.270558
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def do_test(url, expected):
        ie = TVPlayIE(None, {}, {})
        match = ie._match_id(url)
        assert match == expected, 'Expected "%s" to match %s.' % (url, expected)

    do_test('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true', '418113')
    do_test('http://www.tvplay.lv/vinas-melo-labak/418113/?autostart=true', '418113')
    do_test('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true', '409229')

# Generated at 2022-06-24 13:38:17.735134
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHome = TVPlayHomeIE()
    assert TVPlayHome.ie_key() == 'TVPlayHome'
    assert TVPlayHome.ie_name() == 'TVPlayHome'
    assert TVPlayHome.IS_TVPLAYHOME
    assert TVPlayHome.IS_TVPLAYHOME_BASE_URL
    assert not TVPlayHome.IS_TVPLAY_HOME
    assert not TVPlayHome.IS_TV3PLAY_LT
    assert not TVPlayHome.IS_SKATIES_LV
    assert not TVPlayHome.IS_TV3PLAY_EE
    assert not TVPlayHome.IS_TV3PLAY_NO
    assert not TVPlayHome.IS_TV3PLAY_SE
    assert not TVPlayHome.IS_VIAFREE_DK
    assert not TVPlayHome.IS_VIAFREE_NO
    assert not TVPlayHome

# Generated at 2022-06-24 13:38:26.556902
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    # Testing the constructor of TVPlayIE
    info_extractor = TVPlayIE()
    assert info_extractor.IE_NAME == 'mtg'
    assert info_extractor.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:29.903031
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    TVPlayHomeIE(url)

# Generated at 2022-06-24 13:38:40.048062
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_extractors import (
        determine_ext, int_or_none, parse_iso8601, qualities, try_get,
    )
    from .common import InfoExtractor
    url = "http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869"
    ie = ViafreeIE(InfoExtractor())
    # print(ie.__class__.__name__)
    # print(ie._VALID_URL)
    # print(ie.suitable(url))
    # print(ie.extract(url))
    print(ie.extract_info(url))

# Generated at 2022-06-24 13:38:41.108823
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_file = TVPLayHomeIE()

# Generated at 2022-06-24 13:38:44.291210
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://play.tv3.lt/aferistai-10047125/')
    assert ie.asset_id == '10047125'
    assert ie.video_id == '366367'

# Generated at 2022-06-24 13:38:52.561827
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for case in [
        'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2',
    ]:
        try:
            inst = ViafreeIE(case)
            break
        except ExtractorError:
            pass

# Generated at 2022-06-24 13:39:00.166961
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:39:01.739602
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE("TVPlayIE", "")
    assert obj is not None

# Generated at 2022-06-24 13:39:05.895496
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:39:06.979074
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE is not None

# Unit test to check if module is running