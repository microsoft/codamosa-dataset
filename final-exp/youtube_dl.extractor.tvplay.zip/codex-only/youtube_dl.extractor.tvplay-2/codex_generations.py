

# Generated at 2022-06-24 13:29:13.846323
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert hasattr(TVPlayHomeIE, '_VALID_URL')
    assert hasattr(TVPlayHomeIE, '_TESTS')
    assert TVPlayHomeIE.IE_DESC == 'TVPlay Home'
    assert TVPlayHomeIE.IE_NAME == 'tvplayhome'
    assert TVPlayHomeIE.SUITABLE == 'universal'

# Generated at 2022-06-24 13:29:17.163611
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    result = ViafreeIE()
    assert result.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') != False


# Generated at 2022-06-24 13:29:20.317153
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""
    instance = TVPlayHomeIE()
    expected = 'TVPlayHomeIE'
    assert expected == repr(instance).split('.')[-1][:-2], 'Expected class name "{}" does not match!'.format(expected)

# Generated at 2022-06-24 13:29:24.734347
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)

# Generated at 2022-06-24 13:29:25.706204
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    clazz = TVPlayIE()

# Generated at 2022-06-24 13:29:28.353707
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test for #4580
    ViafreeIE().extract('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')


# Generated at 2022-06-24 13:29:35.038781
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    print(ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'))
    print(ie.suitable('http://www.tv3play.se/program/husraddarna/395385'))
    assert (ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'))
    assert not ie.suitable('http://www.tv3play.se/program/husraddarna/395385')

# Generated at 2022-06-24 13:29:45.972662
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    TVPlayIE('http://www.tv8play.se/program/antikjakten/282756?autostart=true')
    TVPlayIE('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')

# Generated at 2022-06-24 13:29:47.719900
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'Tv3PlayHome'

# Generated at 2022-06-24 13:29:57.300668
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def test_success(url, expected_country):
        assert ViafreeIE.suitable(url), url
        assert ViafreeIE._VALID_URL.match(url), url
        country, _ = re.match(ViafreeIE._VALID_URL, url).groups()
        assert country == expected_country

    def test_failure(url):
        assert not ViafreeIE.suitable(url), url
        assert ViafreeIE._VALID_URL.match(url) is None, url

    test_success('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', 'dk')

# Generated at 2022-06-24 13:29:59.834946
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    (ViafreeIE("http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869") is not None)

# Generated at 2022-06-24 13:30:04.326192
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    ViafreeIE().suitable(url)



# Generated at 2022-06-24 13:30:09.120646
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from extractor import ExtractorError
    from youtube_dl.utils import compat_urlparse

    ie = ViafreeIE()
    # test if constructor can set geo_country
    assert ie._country == ie._GEO_COUNTRY
    # test if constructor can set url
    assert ie._url == ie._VALID_URL
    # test if constructor can set video_id
    assert ie._video_id == ie._TESTS[0]['info_dict']['id']
    # test if constructor can set content
    assert ie._content == ie._download_json(ie._TESTS[0]['url'], ie._video_id)
    # test if constructor can set title
    assert ie._title == ie._TESTS[0]['info_dict']['title']

    # test if constructor can set program

# Generated at 2022-06-24 13:30:11.274533
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable(ie.IE_NAME)
    ie.IE_DESC


# Generated at 2022-06-24 13:30:19.481729
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    constructor = TVPlayIE.__init__
    instance = TVPlayIE(1, 1, 1)

    assert instance.geo_verification_headers['User-Agent'] == 'Mozilla/5.0'
    assert instance.geo_verification_headers['Accept'] == 'application/json, text/javascript, */*; q=0.01'
    assert instance.geo_verification_headers['Accept-Language'] == 'en-gb'
    assert instance.geo_verification_headers['X-Requested-With'] == 'XMLHttpRequest'
    assert instance.geo_verification_headers['Referer'] == 'http://tv.mtgx.tv/'
    assert instance.geo_verification_headers['Pragma'] == 'no-cache'
    assert instance.geo_verification_headers

# Generated at 2022-06-24 13:30:26.050383
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert viafree._VALID_URL == \
           r'https?://(?:www\.)?viafree\.(dk|no|se)/program(?:mer)?/(?:[^/]+/)+[^/?#&]+'
    assert viafree._GEO_BYPASS == False
    assert viafree.IE_NAME == 'viafree'
    assert viafree.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:30:35.427153
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Basic test of class TVPlayIE constructor. The constructor of the
    class is tested for the errors raised for the wrong input.
    """
    # Test for invalid values.
    with pytest.raises(TypeError):
        ie = TVPlayIE(None)
    with pytest.raises(TypeError):
        ie = TVPlayIE(123)
    with pytest.raises(TypeError):
        ie = TVPlayIE([])
    with pytest.raises(TypeError):
        ie = TVPlayIE(['1'])
    with pytest.raises(TypeError):
        ie = TVPlayIE(('1',))
    with pytest.raises(TypeError):
        ie = TVPlayIE({})

# Generated at 2022-06-24 13:30:37.340946
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()


# Generated at 2022-06-24 13:30:41.048589
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ViafreeIE(url)._real_initialize()

# Generated at 2022-06-24 13:30:46.925972
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:30:58.974396
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TVPlayHomeIE1(TVPlayHomeIE):
        pass

    class TVPlayHomeIE2(TVPlayHomeIE):
        _VALID_URL = 'http://play.tv3.ee/cool-d-ga-mehhikosse-10044354'

    class TVPlayHomeIE3(TVPlayHomeIE):
        _VALID_URL = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'

    class TVPlayHomeIE4(TVPlayHomeIE):
        _VALID_URL = 'https://play.tv3.lt/aferistai-10047125'

    assert TVPlayHomeIE1.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE1

# Generated at 2022-06-24 13:31:11.390325
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL == r'(?x)https?://www\.tv(?:3|6|8|10)?play(?:\.tv3)?\.se/program/(?P<id>[^/?]+)/?(?:\?|$)'

# Generated at 2022-06-24 13:31:16.607634
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Tests that the class is working
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    video_id = '757786'
    vf = ViafreeIE(url)
    assert vf.video_id == video_id

# Generated at 2022-06-24 13:31:21.588851
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = "https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125"
    # Get the right constructor and 
    tphIE = TVPlayHomeIE(TVPlayHomeIE.suitable(url))
    assert isinstance(tphIE, InfoExtractor)



# Generated at 2022-06-24 13:31:23.444463
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:31:24.351388
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-24 13:31:27.078532
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Simple test for ViafreeIE.
    """
    object = ViafreeIE()
    object_match = object._VALID_URL
    assert object_match


# Generated at 2022-06-24 13:31:31.266917
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE._create_get_video_info_regex(TVPlayHomeIE._VALID_URL), TVPlayHomeHomeIE({}, TVPlayHomeIE.ie_key()))

# Generated at 2022-06-24 13:31:33.319524
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # check if it fails without the correct video_id argument
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE()._real_extract('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', {})

# Generated at 2022-06-24 13:31:36.412210
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE = TVPlayIE.TVPlayIE
    o = TVPlayIE()
    assert o.IE_DESC == 'MTG services'
    assert o.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:31:43.446712
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.SUITABLE == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.GEO_COUNTRIES == ['LV', 'LT', 'EE']

# Generated at 2022-06-24 13:31:46.161691
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'

    # Instantiating class TVPlayIE
    ieTVPlay = TVPlayIE()

    # Testing extractor
    test_extractor(ieTVPlay, url)



# Generated at 2022-06-24 13:31:48.718732
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-24 13:31:52.422192
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test this code
    # sample_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    # ie_instance = TVPlayHomeIE()
    # ie_instance._get_video_id(sample_url)
    assert True

# Generated at 2022-06-24 13:31:55.436936
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractor_list = [TVPlayHomeIE(i) for i in dir(TVPlayHomeIE)]
    assert "TVPlayHomeIE" in str(info_extractor_list)


# Generated at 2022-06-24 13:31:57.020763
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-24 13:32:01.302764
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    result = ie.match(url)
    assert result == '409229'

# Generated at 2022-06-24 13:32:02.828761
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    ViafreeIE('Viafree', 'dk')
    ViafreeIE('Viafree', 'no')
    ViafreeIE('Viafree', 'se')

# Generated at 2022-06-24 13:32:08.533435
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', {})
    ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', {})

# Generated at 2022-06-24 13:32:14.467523
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    module = importlib.import_module('youtube_dl.extractor.viafree')
    globals = sys.modules[module.__name__].__dict__
    viafree_ie = globals['ViafreeIE'](None)
    from youtube_dl.extractor.tvplay import TVPlayIE
    assert type(viafree_ie) == TVPlayIE


# Generated at 2022-06-24 13:32:18.316747
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie.SUFFIX == 'Ltd'



# Generated at 2022-06-24 13:32:22.653280
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie.country == "Norway"
    assert ie.path == "/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"

# Generated at 2022-06-24 13:32:23.299424
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:32:34.968422
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    def _assert_result(ie, *args, **kwargs):
        def _assert_func(url, expected_url, expected_domain):
            ie = TVPlayHomeIE(kwargs)
            assert ie._extract_domain(url) == expected_url
            assert ie._extract_domain(url).netloc == expected_domain
        for domain, expected_domain in kwargs.items():
            for url in args:
                yield _assert_func, url, url.replace(domain, expected_domain), expected_domain
    valid_domains = ['play.tv3.lt', 'tvplay.skaties.lv', 'play.tv3.ee']
    valid_urls = valid_domains + [domain.replace('.', '') for domain in valid_domains]

# Generated at 2022-06-24 13:32:36.260892
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(FakeYDL(), 'https://tvplayhome.com')

# Generated at 2022-06-24 13:32:39.533414
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree = ViafreeIE(url)



# Generated at 2022-06-24 13:32:44.999972
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tv_play = TVPlayHomeIE(TVPlayHomeIE._create_get_url(url), {'skip_download': True})
    assert isinstance(tv_play, InfoExtractor)

# Generated at 2022-06-24 13:32:53.721495
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Unit test for constructor of class TVPlayIE
    test_instance = TVPlayIE()
    m = TVPlayIE._VALID_URL.search('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')
    assert m.group('id') == '409229'
    m = TVPlayIE._VALID_URL.search('https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551')
    assert m.group('id') == '238551'
    assert m.group('id') == '238551'
    m = TVPlayIE._VALID_URL.search(test_instance._real_extract('http://www.tv3play.se/program/husraddarna/395385')['id'])
    assert m

# Generated at 2022-06-24 13:33:05.135514
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.country == 'lt'

    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.country == 'ee'

    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.country == 'lv'

    # When

# Generated at 2022-06-24 13:33:14.513098
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().ie_key() == 'TVPlay'


# Generated at 2022-06-24 13:33:20.744758
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '366367'
    url = 'https://tv3play.tv3.lt/aferistai-n-7/aferistai-10047125/'

# Generated at 2022-06-24 13:33:31.753319
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE('mtg', {})
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:33.890685
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check extractors initialisation without URL
    ie = ViafreeIE()
    ie.extract('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')



# Generated at 2022-06-24 13:33:37.131952
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(AssertionError):
        TVPlayHomeIE('http://www.tv3.skaties.lv/')

# Generated at 2022-06-24 13:33:44.271639
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url_test = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_ie = ViafreeIE.suitable(url_test)
    assert viafree_ie, 'ViafreeIE not suitable on URL: %s' % url_test
    viafree_ie = ViafreeIE.suitable(url_test)
    assert not viafree_ie, 'ViafreeIE suitable on URL: %s' % url_test



# Generated at 2022-06-24 13:33:55.596964
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true') == TVPlayIE
    assert TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true') == TVPlayIE
    assert TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true') == TVPlayIE
    assert TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == TVPlayIE

# Generated at 2022-06-24 13:34:00.717357
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('https://www.tv3play.no/programmer/husraddarna/395385')



# Generated at 2022-06-24 13:34:12.060404
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    t._VALID_URL = r'.*'
    assert t.suitable('http://www.tv8play.se/program/antikjakten/282756?autostart=true') == True
    assert t.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true') == True
    # check if the tests are compatible with the constructor
    assert t.suitable('mtg:418113') == True
    assert t.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true') == True

# Generated at 2022-06-24 13:34:19.163064
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg_url_1 = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    mtg_url_2 = 'https://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    tvplay_url_1 = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay_url_2 = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    tv_play_ie = TVPlayIE()

# Generated at 2022-06-24 13:34:21.867052
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ses = TVPlayIE()
    assert ses.IE_NAME == 'mtg'
    assert ses.IE_DESC == 'MTG services'
    assert ses._VALID_URL == r'(?x)mtg:(?P<id>\d+)'



# Generated at 2022-06-24 13:34:22.711342
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:34:30.459377
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import unittest
    class TestTVPlayHomeIE(unittest.TestCase):
        def test_constructor_smoke(self):
            ie = TVPlayHomeIE('http://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
            self.assertTrue(isinstance(ie, InfoExtractor))
    unittest.main(argv=[''])

# Generated at 2022-06-24 13:34:34.453674
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert hasattr(TVPlayHomeIE(), '_VALID_URL')
    assert hasattr(TVPlayHomeIE(TVPlayHomeIE()), '_VALID_URL')
    assert hasattr(TVPlayHomeIE(TVPlayHomeIE(TVPlayHomeIE())), '_VALID_URL')



# Generated at 2022-06-24 13:34:40.244249
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    ie.suitable('http://www.viasat4play.no/programmer/budbringerne/21873?autostart=true')

# Unit tests for methods of class TVPlayIE

# Generated at 2022-06-24 13:34:42.222410
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(TVPlayIE.IE_NAME,TVPlayIE.IE_DESC)


# Generated at 2022-06-24 13:34:44.994538
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    insts = ie._extractors.get('https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)')
    assert len(insts) == 1 and isinstance(insts[0], TVPlayHomeIE)

# Generated at 2022-06-24 13:34:47.286726
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.se/program/husraddarna/395385?autostart=true')



# Generated at 2022-06-24 13:34:53.197701
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    tvplay_home_ie = TVPlayHomeIE()

    # Test regexps
    assert tvplay_home_ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert tvplay_home_ie._TESTS  # pylint: disable=W0104


# Generated at 2022-06-24 13:35:04.959613
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:35:13.579060
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    with open('test.html','r') as myfile:
        html = myfile.read().replace('\n', '')
    url_datas = {}
    url_datas['url'] = url
    url_datas['ie'] = 'TVPlay'
    url_datas['videoid'] = '395385'
    url_datas['playlistid'] = 'null'

    TVPlayIE = TVPlayIE(url_datas, html)


# Generated at 2022-06-24 13:35:18.166408
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.get_id() == '418113'
    assert ie.IE_NAME == 'mtg'
 

# Generated at 2022-06-24 13:35:19.502163
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-24 13:35:22.210141
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    """
        Test to make sure that regex is correct.
    """
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-24 13:35:23.736816
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE()
    viaplat = x.viaplat

# Generated at 2022-06-24 13:35:26.206484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")

# Generated at 2022-06-24 13:35:33.322057
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.SUITABLE_DEFAULT == False


# Generated at 2022-06-24 13:35:42.695260
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/");
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:35:48.848475
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert instance.META_URL == 'https://viafree-content.mtg-api.com/viafree-content/v1/no/path/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'



# Generated at 2022-06-24 13:35:52.510995
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	tvplay_url = "http://www.tv3play.lt/parraides/vinas-melo-labak/418113?autostart=true"
	TVPlayIE()._real_extract(tvplay_url)


# Generated at 2022-06-24 13:36:02.674279
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tvplay_ie = TVPlayIE(None)
    assert tvplay_ie.geo_country is None
    assert tvplay_ie.geo_verification_headers() == {}

    geo_verification_headers = {}
    tvplay_ie = TVPlayIE(None, geo_verification_headers=geo_verification_headers)
    assert tvplay_ie.geo_country is None
    assert tvplay_ie.geo_verification_headers() == {}

    geo_country = 'se'
    tvplay_ie = TVPlayIE(None, geo_country=geo_country)
    assert tvplay_ie.geo_country == geo_country
    assert tvplay_ie.geo_verification_headers() == {}


# Generated at 2022-06-24 13:36:09.831946
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert(instance.IE_NAME == 'mtg')
    assert(instance.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:36:19.384862
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Sample URL from documentation
    # http://developer.mtgx.tv/docs/get-video-streams
    sample_url = 'http://playapi.mtgx.tv/v3/videos/stream/1235'

    ie = TVPlayIE()
    ie.set_downloader(
        downloader_for_test(
            'http://playapi.mtgx.tv/v3/videos/stream/1235',
            'v3/videos/stream/1235.json',
            content_type='application/json'))

    # Check correct TVPlayIE selection with sample URL
    assert ie._matches(sample_url)

    # Check correct extraction with sample URL

# Generated at 2022-06-24 13:36:20.653176
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(ViafreeIE.ie_key())
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-24 13:36:23.305846
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    TVPlayIE()._real_extract(url)


# Generated at 2022-06-24 13:36:26.118789
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None, 'http://play.tv3play.tv3.ee/sisu/kodu-keset-linna/238551', {'geo_countries': ['EE']})



# Generated at 2022-06-24 13:36:29.920198
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert (ViafreeIE().suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')) is True

# Extractor for viasat.jojo.dk
# This is just a redirect to TVplay, so we can reuse the TVplay extractor for it.

# Generated at 2022-06-24 13:36:32.357922
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check old URL
    ViafreeIE('http://play.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    # Check new URL
    ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')



# Generated at 2022-06-24 13:36:42.793619
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tvplay_ie = ViafreeIE()
    test_url = 'https://www.viafree.no/program/reality/paradise-hotel/sesong-7/episode-5'
    # Check if the pattern of ViafreeIE is a valid one
    tvplay_ie._VALID_URL
    viafree_ie = ViafreeIE._build_url_result(test_url)
    assert viafree_ie[0] == 'dk'
    assert viafree_ie[1] == 'programmer/reality/paradise-hotel/saeson-7/episode-5'
    # Check if the country is returned as expected

    # ViafreeIE should be present in classes of YoutubeDL,
    # assert it being True

# Generated at 2022-06-24 13:36:47.881605
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    ie.extract('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')


# Generated at 2022-06-24 13:36:57.888689
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ins = ViafreeIE()
    print(ins.suitable('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'))
    print(ins.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true'))
    print(ins.suitable('http://play.tv3play.lv/parraides/tv3-zinas/760183'))
    print(ins.suitable('http://www.viasat4play.no/programmer/budbringerne/21873?autostart=true'))
    print(ins.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'))


# Generated at 2022-06-24 13:37:05.609742
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_DESC
    assert TVPlayIE.IE_NAME
    assert TVPlayIE._TESTS
    assert TVPlayIE._VALID_URL
    assert TVPlayIE._download_json
    assert TVPlayIE._extract_f4m_formats
    assert TVPlayIE._extract_m3u8_formats
    assert TVPlayIE._real_extract
    assert TVPlayIE._search_regex
    assert TVPlayIE._sort_formats
    assert TVPlayIE.age_limit
    assert TVPlayIE.BRIGHTCOVE_URL_TEMPLATE
    assert TVPlayIE.IE_DESC
    assert TVPlayIE.IE_NAME
    assert TVPlayIE.PAGE_TEMPLATE
    assert TVPlayIE.SUCCESS
    assert TVPlayIE.ext

# Generated at 2022-06-24 13:37:08.225808
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.ie_key() == 'mtg', 'Test constructor of class TVPlayIE'


# Generated at 2022-06-24 13:37:17.996181
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import inspect
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    argspec = inspect.getargspec(ViafreeIE.__init__)
    # Function has no argument called 'go_geo_bypass'
    assert 'go_geo_bypass' not in argspec.args

    # The object of class ViafreeIE is created without any errors
    ie = get_info_extractor('viafree', url)
    assert isinstance(ie, ViafreeIE)
    assert ie.suitable(url)
    assert ie.IE_NAME == 'viafree'

# Generated at 2022-06-24 13:37:21.518120
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    args = ['http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true']
    kwargs = {
        'geo_countries': ['lt'],
    }
    TVPlayIE(*args, **kwargs)


# Generated at 2022-06-24 13:37:32.155936
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_dict = {
        'id': '366367',
        'ext': 'mp4',
        'title': 'Aferistai',
        'description': 'Aferistai. Kalėdinė pasaka.',
        'series': 'Aferistai [N-7]',
        'season': '1 sezonas',
        'season_number': 1,
        'duration': 464,
        'timestamp': 1394209658,
        'upload_date': '20140307',
        'age_limit': 18,
    }

    tp = TVPlayHomeIE()
    video = tp.suitable("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")

# Generated at 2022-06-24 13:37:34.278525
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': [u'LV'], 'whitelist': True})
    assert isinstance(ie, InfoExtractor)



# Generated at 2022-06-24 13:37:35.825736
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE('mtg', 'mtg', 'mtg')


# Generated at 2022-06-24 13:37:40.015553
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = ViafreeIE.suitable(url="")
    assert url == False

    url = ViafreeIE.suitable(url="http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2")
    assert url == True

# Generated at 2022-06-24 13:37:50.086786
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(AssertionError):
        TVPlayHomeIE('https://www.tv3play.lt/programa/laidos/liecua-993/')
    with pytest.raises(AssertionError):
        TVPlayHomeIE('https://www.tv3play.skaties.lv/')
    with pytest.raises(AssertionError):
        TVPlayHomeIE('https://www.tv3play.skaties.lv/programme/laidos/liecua-993/')
    with pytest.raises(AssertionError):
        TVPlayHomeIE('https://www.tv3play.tv3.ee/')

# Generated at 2022-06-24 13:37:54.338146
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()._real_extract("https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/")



# Generated at 2022-06-24 13:37:56.336096
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://play.viaplay.no/api/watch/760341')

# Generated at 2022-06-24 13:37:58.699899
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.media_url_re == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-24 13:38:02.397657
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.geo_countries is None
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS


# Generated at 2022-06-24 13:38:10.899068
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:38:17.684236
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_test_url = 'http://tvplay.lv/418113/?autostart=true'
    tvplay_test_url_2 = 'http://tvplay.lv/418113'
    ie_tvplay_test = TVPlayIE(TVPlayIE._VALID_URL)
    assert ie_tvplay_test.suitable(tvplay_test_url)
    assert ie_tvplay_test.suitable(tvplay_test_url_2)

# Generated at 2022-06-24 13:38:22.846640
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ie.extract('mtg:418113') == ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-24 13:38:25.239497
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    ViafreeIE().suitable(test_url)

# Generated at 2022-06-24 13:38:29.537652
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    res = re.match(ie._VALID_URL, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert res.group('id') == '10047125'

# Generated at 2022-06-24 13:38:31.913527
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Simple test that ViafreeIE can be instantiated
    try:
        ViafreeIE()
    except Exception:
        assert False



# Generated at 2022-06-24 13:38:34.321576
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL)



# Generated at 2022-06-24 13:38:42.350213
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayIE(), 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # TODO: Test this.
    # Here is a test for the function _real_extract
    if False:
        test_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
        tvplay = TVPlayHomeIE(TVPlayIE(), test_url)
        print(tvplay._real_extract(test_url))



# Generated at 2022-06-24 13:38:49.932874
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    #TVPlayIE.suitable = original_TVPlayIE_suitable
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    #TVPlayIE.suitable = lambda url: True
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-24 13:38:51.772917
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
        obj = TVPlayIE()
# Check there are no errors in process
        assert isinstance(obj, object)


# Generated at 2022-06-24 13:38:58.284779
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == True
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') == True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == True
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125') == True

# Generated at 2022-06-24 13:38:59.685716
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    raise SkipTest('Unit tests for ViafreeIE not implemented')



# Generated at 2022-06-24 13:39:11.168844
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'