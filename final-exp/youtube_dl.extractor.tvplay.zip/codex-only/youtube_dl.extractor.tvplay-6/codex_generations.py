

# Generated at 2022-06-24 13:29:12.806062
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    module = 'test_video_viafree_embedded_no_geo_bypass'
    result = getattr(sys.modules[__name__], module)
    setattr(sys.modules[__name__], module, lambda x: True)
    test_ie = ViafreeIE(None)
    setattr(sys.modules[__name__], module, result)
    return test_ie

# Generated at 2022-06-24 13:29:21.929370
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()

    # Class should have a working method _match_id
    # This is needed, because the regex returns
    # None if it doesn't match.
    assert x._match_id('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == '10047125'
    assert x._match_id('https://play.tv3.lt/aferistai-10047125') == '10047125'
    assert x._match_id('https://tv3play.skaties.lv/vinas-melo-labak-10280317') == '10280317'
    assert x._match_id('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') == '10044354'

# Generated at 2022-06-24 13:29:23.675681
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import BaseIE

    tvph = TVPlayHomeIE._build_video_result(url=None, video_id='vId', title='vTitle')
    assert isinstance(tvph, BaseIE)
    assert 'tvph' in globals()



# Generated at 2022-06-24 13:29:27.369116
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_IE = TVPlayHomeIE()
    video_id = tvplay_home_IE._match_id("https://tvplay.skaties.lv/vinas-melo-labak-10280317")
    assert video_id == '10280317'
    pass



# Generated at 2022-06-24 13:29:34.377585
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Get country from URL
    assert ('dk', 'programmer/reality/paradise-hotel/saeson-7/episode-5') == ViafreeIE._VALID_URL_RE.match('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5').groups()
    assert ('no', 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == ViafreeIE._VALID_URL_RE.match('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1').groups()

# Generated at 2022-06-24 13:29:38.227851
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert isinstance(ie, TVPlayIE)
    assert isinstance(ie._TESTS, list)
    assert ie._VALID_URL == r'(?x)tvplay(?:\.skaties)?\.lv/parraides/(?P<id>\d+)'


# Generated at 2022-06-24 13:29:46.307849
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:29:48.085647
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global TVPlayIE
    TVPlayIE({})
    assert True  # avoid "unreachable code" warning

# Generated at 2022-06-24 13:29:50.960612
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    res = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert res.get('id') == '366367'

# Generated at 2022-06-24 13:29:59.416002
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:03.503941
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert ie.IE_NAME == 'mtg'


# Generated at 2022-06-24 13:30:07.250413
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1').extract()

# Generated at 2022-06-24 13:30:14.224834
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_name() == 'mtg'
    assert ie.ie_key() == 'mtg'
    assert ie.FEED_URL == 'http://playapi.mtgx.tv/v3/videos'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?tv(?:3|6|8|10)play\.se/program/[^/]+/(?P<id>\d+)'
    assert ie.IE_DESC == 'MTG services'


# Generated at 2022-06-24 13:30:15.824508
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(TypeError):
        TVPlayHomeIE('abc')



# Generated at 2022-06-24 13:30:20.919167
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_  = TVPlayIE
    # First argument of constructor (ie_key)
    ie_key = 'MTG'
    # Second argument of constructor (video_id_re)
    video_id_re = 'http://tvplay\.lv/(?:[^/]+/)+(\d+)'
    # Third argument of constructor (webpage_url)
    webpage_url = 'http://tvplay.lv/kakdi-ir-iri-vinas-melo-labak/418113'
    # Fourth argument of constructor (video_title)
    video_title = 'Kādi ir īri? - Viņas melo labāk'
    # Fifth argument of constructor (access_limit)
    access_limit = None
    # Sixth argument of constructor (geo_limit)
    geo_limit = None
    # Seventh

# Generated at 2022-06-24 13:30:28.965657
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # assert True
    from os import listdir
    from os.path import join
    # import copy

    def _get_files(direcory):
        pattern = re.compile('[a-zA-Z0-9\-]+.json')
        return [f for f in listdir(direcory) if pattern.match(f)]

    import sys
    import urllib.parse

    # arguments passed to current test
    args = sys.argv[1:]

    # remove all non-needed arguments
    p = urllib.parse.urlparse(args[0])
    args = [p.netloc, p.path]

    files = _get_files(join('tests', 'resources', 'TVPlayHomeIE'))

    count_errors = 0

    ie = TVPlayHomeIE()

# Generated at 2022-06-24 13:30:29.562956
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass


# Generated at 2022-06-24 13:30:32.118949
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE(None)._VALID_URL == ViafreeIE._VALID_URL


# Generated at 2022-06-24 13:30:40.788795
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.get_video_id('https://tv3play.tv3.ee/suur-praktik-10044366/', None) == '10044366'
    assert ie.get_video_id('https://tvplay.tv3.lt/aferistai-10047125/', None) == '10047125'
    assert ie.get_video_id('https://tvplay.skaties.lv/vinas-melo-labak-10280317/', None) == '10280317'

# Generated at 2022-06-24 13:30:53.262953
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert i.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert not i.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317')
    assert i.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert not i.suitable('https://tvplay.tv3.lt/aferistai-10047125')

# Generated at 2022-06-24 13:30:58.225260
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ViafreeIE.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-24 13:31:05.688105
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # url of video
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    # create constructor of class TVPlayIE
    tvplay_ie = TVPlayIE(url)
    # extracting video
    tvplay_ie.extract()

    # Check if video_id is correct
    assert tvplay_ie.video_id == '418113'


# Generated at 2022-06-24 13:31:06.647076
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-24 13:31:16.444005
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '10044354'
    m3u8_url = 'http://tv3play-vh.akamaihd.net/i/2.0/playlist/playlist.m3u8?v=1439862742&e=1439862742&p=web'
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-' + video_id
    asset = {'movie': {'contentUrl': m3u8_url},
             'assetId': video_id,
             'title': {'title': 'Cool D&G-ga Mehhikosse'}}
    info = TVPlayHomeIE()._real_extract(url)
    assert info['id'] == asset['assetId']

# Generated at 2022-06-24 13:31:27.676918
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    _test_TVPlayIE('https://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true', '418113')
    _test_TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true', '409229')
    _test_TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true', '238551')
    _test_TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true', '395385')

# Generated at 2022-06-24 13:31:32.708991
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_ie = TVPlayHomeIE()
    tvplayhome_ie_suitable_url = tvplayhome_ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert(tvplayhome_ie_suitable_url == True)

# Generated at 2022-06-24 13:31:35.478335
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("TVPlayIE", "TVPlayIE", "os.system('echo \"TVPlayIE unit test success\")")
    ie.test("mtg:418113")

# Generated at 2022-06-24 13:31:37.743564
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE()
    assert obj.__class__.__name__ == 'ViafreeIE'

# Generated at 2022-06-24 13:31:46.953804
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie.IE_NAME == 'mtg')
    assert(ie.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:31:52.221604
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info_extractor = ViafreeIE()
    # Not a subclass of TVPlayIE
    assert info_extractor.__class__ is ViafreeIE
    # Check _VALID_URL
    match = re.match(ViafreeIE._VALID_URL, 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert match
    assert match.group('country') == 'se'
    assert match.group('id') == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

# Generated at 2022-06-24 13:32:02.012141
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # Test URL matching
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._match_id('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') == '10044354'
    assert ie._match_id('https://play.tv3.lt/vinas-melo-labak-10280317') == '10280317'
    # Test extractions

# Generated at 2022-06-24 13:32:03.047537
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:32:07.512867
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    except ExtractorError as e:
        print(e)


# Generated at 2022-06-24 13:32:19.162234
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:32:30.309073
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:32:33.995980
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert "TVPlayHomeIE" == ie.__class__.__name__

# Generated at 2022-06-24 13:32:45.525195
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:32:52.652251
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    mtgx_url = 'http://play.mtgx.tv/video/fhsgjdfg/sdhgfsd'
    ViafreeIE.suitable(mtgx_url)
    ie = ViafreeIE(mtgx_url)
    assert ie.name == 'MTGX'

    mtgx_url_2 = 'http://play.mtgx.tv/video/fhsgjdfg/sdhgfsd?viafree=true'
    ViafreeIE.suitable(mtgx_url_2)
    ie = ViafreeIE(mtgx_url_2)
    assert ie.name == 'Viafree'


# Generated at 2022-06-24 13:32:55.225285
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:06.581543
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    fields = ['url', 'info_dict', 'params']

# Generated at 2022-06-24 13:33:14.777540
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Expected fields in info dict:
    # ['id', 'ext', 'title', 'description', 'series', 'season', 'season_number', 'duration', 'timestamp', 'upload_date', 'age_limit']
    test_urls = ['https://play.tv3.lt/aferistai-10047125', 'https://tv3play.skaties.lv/vinas-melo-labak-10280317', 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354']
    for url in test_urls:
        info_dict = TVPlayHomeIE().extract(url)
        assert ('id' and 'title') in info_dict

# Generated at 2022-06-24 13:33:19.034143
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for ie in [TVPlayHomeIE(), TVPlayHomeIE.ie_key()]:
        ie.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
        ie.suitable('https://tvplay.tv3.lt/aferistai-10047125')
        ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317')



# Generated at 2022-06-24 13:33:24.780301
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # First check that the regex really match
    ie = TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317')

    # Then check that the constructor really works
    ie = TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317')

    # Check that there is a language set
    assert ie.lang is not None

    # Check that the language is set to "lv"
    assert ie.lang == "lv"

    # Check that the name is set to "TVPlayHomeIE"
    assert ie.name == "TVPlayHomeIE"

    # Check that the name is set correctly
    assert ie.name == "TVPlayHomeIE"

    # Check that the regex matches

# Generated at 2022-06-24 13:33:27.609891
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('mtg:418113')
    assert ie._VALID_URL == r'(?x)mtg:(?P<id>\d+)'


# Generated at 2022-06-24 13:33:35.517266
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.get_info('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/').get('id') != None
    assert ie.get_info('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/').get('id') != None
    assert ie.get_info('https://play.tv3.lt/aferistai-10047125').get('id') != None
    assert ie.get_info('https://tv3play.skaties.lv/vinas-melo-labak-10280317').get('id') != None

# Generated at 2022-06-24 13:33:38.093385
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie.name == 'viafree:viafree'
    assert ie.description == 'viafree.dk, viafree.no and viafree.se'
    assert ie.ie_key() == 'viafree'
    assert ie.duration == TVPlayIE.duration



# Generated at 2022-06-24 13:33:46.663752
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Functional test for constructor of class ViafreeIE
    """
    ie = ViafreeIE('dk')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.dk
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''
    ie = ViafreeIE('se')
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.se
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''
    ie = ViafreeIE('no')

# Generated at 2022-06-24 13:33:52.159678
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    i = TVPlayIE()
    assert re.match(r'http://(?:www\.)?tv3play(?:\.tv3)?\.ee/sisu/kodu-keset-linna/238551\?autostart=true', i.construct_url("238551"))
    assert re.match(r'http://(?:www\.)?tvplay\.lv/parraides/vinas-melo-labak/418113\?autostart=true', i.construct_url("418113", "lv"))
    assert re.match(r'http://(?:www\.)?tvplay\.lv/vinas-melo-labak/418113\?autostart=true', i.construct_url("418113", "lv", True))

# Generated at 2022-06-24 13:33:54.181786
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-24 13:34:05.389757
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == r'''(?x)
                                     https?://
                                         (?:www\.)?
                                         viafree\.(?P<country>dk|no|se)
                                         /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                     '''
    assert ViafreeIE._GEO_BYPASS == False

# Generated at 2022-06-24 13:34:07.564855
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Unit test for constructor without instantiation of class ViafreeIE
    ViafreeIE()
    


# Generated at 2022-06-24 13:34:09.940961
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViaplayIE.suitable('http://playapi.mtgx.tv/v3/videos/123')



# Generated at 2022-06-24 13:34:12.197286
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://www.tvplay.lv/fermeri/fermeri-10044481/')
    assert ie

# Generated at 2022-06-24 13:34:17.482946
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    expected = 'https://viafree-content.mtg-api.com/viafree-content/v1/dk/path/programmer/reality/paradise-hotel/saeson-7/episode-5'
    # Assert if expected is equal to the URL constructed by the constructor
    assert ie._VALID_URL == expected



# Generated at 2022-06-24 13:34:24.464315
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://example.com/')
    assert ie.REAL_URL_PATTERN.match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.REAL_URL_PATTERN.match('https://tvplay.tv3.lt/vinas-melo-labak-10280317')
    assert ie.REAL_URL_PATTERN.match('https://play.tv3.lt/aferistai-10047125/')
    assert ie.REAL_URL_PATTERN.match('https://play.tv3.lt/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:34:31.283441
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_tvplay import TVPlayBaseTest

    class TestTVPlayHomeIE(TVPlayBaseTest):
        _port = 8090
        _site_info = TVPlayHomeIE
        _url = 'http://tv3play.skaties.lv/vinas-melo-labak-10280317/'

    obj = TestTVPlayHomeIE()
    obj.test_constructor()



# Generated at 2022-06-24 13:34:36.489223
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_case_list = []
    test_case_list.append(_test_case_one(TVPlayIE))
    test_case_list.append(_test_case_two(TVPlayIE))
    test_case_list.append(_test_case_three(TVPlayIE))
    test_case_list.append(_test_case_four(TVPlayIE))
    test_case_list.append(_test_case_five(TVPlayIE))

    return test_case_list


# Generated at 2022-06-24 13:34:47.856740
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test the constructor of class TVPlayHomeIE
    def check(url, expected_video_id):
        assert TVPlayHomeIE._match_id(url) == expected_video_id
    check('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', '10047125')
    check('https://play.tv3.lt/aferistai-10047125', '10047125')
    check('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', '10280317')
    check('https://tv3play.skaties.lv/vinas-melo-labak-10280317', '10280317')

# Generated at 2022-06-24 13:34:55.209706
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    '''Test the constructor of TVPlayHomeIE.'''
    tests = {
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317': 'viafree.lv',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354': 'viafree.no',
        'https://play.tv3.lt/aferistai-10047125': 'viafree.se'
    }
    for test, expected in tests.items():
        tvplayhomeie = TVPlayHomeIE(test)
        assert tvplayhomeie.get_country() == expected

# Generated at 2022-06-24 13:35:06.650119
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:35:14.270042
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie2 = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie2.country == 'dk'
    assert ie2.path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'

    ie3 = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert ie3.country == 'se'
    assert ie3.path == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'

# Generated at 2022-06-24 13:35:17.638092
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == 'mtg'
    assert ie.ie_name() == 'mtg'
    assert ie.ie_description() == 'MTG services'



# Generated at 2022-06-24 13:35:22.801370
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # The constructor of class ViafreeIE can be tested in this way
    # because it delegates extraction to the super class (InfoExtractor).
    # This makes sure that the code paths for both the old and new classes are
    # tested.
    ie = ViafreeIE(None)
    assert isinstance(ie, ViafreeIE)


# Generated at 2022-06-24 13:35:26.918302
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    s = TVPlayHomeIE()
    assert(s != None)
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    assert(s._match_id(url) == '10280317')



# Generated at 2022-06-24 13:35:27.917386
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_ = TVPlayIE
    assert class_.IE_NAME
    assert class_.IE_DESC



# Generated at 2022-06-24 13:35:29.068228
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:35:39.232686
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    imp = TVPlayIE()
    assert imp._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'

# Generated at 2022-06-24 13:35:42.557866
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.IE_NAME == 'tv3play:home'
    # ie.ie_key() is deprecated
    assert ie.ie_key() == 'TVPlayHome'


# Generated at 2022-06-24 13:35:43.968734
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE("https://www.tv3play.no/")


# Generated at 2022-06-24 13:35:50.746974
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE.suitable('https://play.tv3.lt/xx-10047125')
    TVPlayHomeIE.suitable('https://tv3play.skaties.lv/xx-10280317/')
    TVPlayHomeIE.suitable('https://play.tv3.ee/xx-10044354')


# Generated at 2022-06-24 13:36:01.199491
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE().suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/")
    assert TVPlayHomeIE().suitable("https://play.tv3.lt/aferistai-10047125")
    assert not TVPlayHomeIE().suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert not TVPlayHomeIE().suitable("https://tv3play.skaties.lv/vinas-melo-labak-10280317")
    assert not TVPlayHomeIE().suitable("https://play.tv3.ee/cool-d-ga-mehhikosse-10044354")




# Generated at 2022-06-24 13:36:09.692500
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test = {
        'url' : 'https://tvplay.tv3.lt/aferistai-10047125/',
        'info_dict': {
            'id': '366367',
            'ext': 'mp4',
            'title': 'Aferistai',
            'description': 'Aferistai. Kalėdinė pasaka.',
            'series': 'Aferistai [N-7]',
            'season': '1 sezonas',
            'season_number': 1,
            'duration': 464,
            'timestamp': 1394209658,
            'upload_date': '20140307',
            'age_limit': 18,
        },
        'params': {
            'skip_download': True,
        },
        'expected_warnings' : [],
    }

# Generated at 2022-06-24 13:36:12.076490
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert isinstance(ie, ViafreeIE)



# Generated at 2022-06-24 13:36:21.413338
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ie.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    assert ie.suitable('http://www.tv8play.se/program/antikjakten/282756?autostart=true')
    assert ie.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    assert ie.suitable('http://www.viasat4play.no/programmer/budbringerne/21873?autostart=true')
    assert ie

# Generated at 2022-06-24 13:36:23.872577
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:36:26.415012
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE({})
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.IE_DESC == 'TVPlayHome Latvia and Estonia'
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-24 13:36:27.216125
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg', 'MTV Play')


# Generated at 2022-06-24 13:36:28.173743
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable(ie._VALID_URL)

# Generated at 2022-06-24 13:36:29.987699
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE('http://www.tv3play.dk/programmer/kodu-keset-linna/246540')
    except:
        assert False
    assert True

# Generated at 2022-06-24 13:36:32.866485
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Unit tests for extraction of parameters, which are necessary for extraction of URL of video stream
# and definition of final video title.

# Generated at 2022-06-24 13:36:43.108443
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test main functionality
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125'
    tph = TVPlayHomeIE()
    assert tph.suitable(url) == True
    assert tph._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:36:47.454923
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = "http://www.tv8play.se/program/antikjakten/282756?autostart=true"
    extracted_id = "282756"
    tv_play_ie = TVPlayIE()
    assert tv_play_ie._match_id(url) == extracted_id


# Generated at 2022-06-24 13:36:54.172878
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:55.156839
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert isinstance(instance, TVPlayIE)


# Generated at 2022-06-24 13:37:02.573616
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:37:03.693923
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    inst = ViafreeIE()
    assert inst.IE_NAME == 'tvplay'

# Generated at 2022-06-24 13:37:04.598751
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:37:06.463095
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    res = re.search(r'\(\?x\)', ie._VALID_URL)
    assert res.group(0) == '(?x)'

# Generated at 2022-06-24 13:37:10.680425
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE('mtg', "MTG services")
    assert test.name == "mtg"
    assert test.description == "MTG services"
    assert test._VALID_URL == r'(?x)mtg:(?P<id>\d+)'



# Generated at 2022-06-24 13:37:12.914220
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    obj = t.suite()
    assert obj is not None

# Generated at 2022-06-24 13:37:18.860935
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # We need to test the constructor as well. Superclass TVPlayHomeIE
    # depends on an object of subclass _TVPlayHomeIE.
    ie = TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.__name__ == '_TVPlayHomeIE', ie.__name__


# Generated at 2022-06-24 13:37:19.377349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:37:22.831261
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE("https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/", None)
        assert True
    except:
        assert False


# Generated at 2022-06-24 13:37:26.299865
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE([])
    assert ie.IE_NAME == ie.ie_key() == 'viafree'



# Generated at 2022-06-24 13:37:34.554462
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # For coverage
    TVPlayIE.ie_key('http://play.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE.ie_key('http://www.viasat4play.no/programmer/budbringerne/21873?autostart=true')
    TVPlayIE.ie_key('http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE.ie_key('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-24 13:37:38.809667
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    print(ie.IE_DESC)
    print(ie._VALID_URL)
    print(re.match(ie._VALID_URL, 'http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true'))

# Generated at 2022-06-24 13:37:40.951454
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
  # Testing proper instatiation - __init__ method of TVPlayIE
  assert(TVPlayIE.__name__ == "TVPlayIE")


# Generated at 2022-06-24 13:37:45.547469
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert TVPlayHomeIE.suitable(ie.suitable('http://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))


# Generated at 2022-06-24 13:37:57.312966
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_urls = [
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-1',
        'https://www.viafree.no/programmer/underholdning/reality/paradise-hotel/sesong-23/episode-7',
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    ]
    for test_url in test_urls:
        ViafreeIE().suitable(test_url)
        ViafreeIE()._real_ext

# Generated at 2022-06-24 13:38:07.491674
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    from . import TVPlayIE
    from . import ExtractorError
    vf_ie = ViafreeIE('http')
    # matching url
    matching_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert vf_ie.suitable(matching_url), 'Suitable function failed with matching url'
    # non matching url
    tvplay_url = 'http://play.tv2.no/programmer/dokumentar/kodu-keset-linna/238551'
    assert not vf_ie.suitable(tvplay_url)
    # TVPlayIE should take care of this url
    tvplay_ie = TVPlayIE('http')
    assert tvplay

# Generated at 2022-06-24 13:38:18.395923
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.suitable('http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
   

# Generated at 2022-06-24 13:38:24.624543
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree_ie.suitable('mtg:757786')
    assert not viafree_ie.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')


# Generated at 2022-06-24 13:38:30.953949
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie._real_extract('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354/')
    ie._real_extract('https://play.tv3.lt/aferistai-10047125')
    ie._real_extract('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:38:32.670116
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test construction of class ViafreeIE."""
    ViafreeIE()


# Generated at 2022-06-24 13:38:43.737601
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    extractor_class = ViafreeIE
    assert extractor_class.__name__ == "ViafreeIE"
    extractor_instance = extractor_class()
    assert isinstance(extractor_instance, InfoExtractor)
    assert extractor_instance.IE_NAME == "viafree"
    assert extractor_instance.IE_DESC == "VIAplay.se, TV3Play.se, TV3Play.no, TV3Play.dk and TV6Play.se"
    assert extractor_instance._VALID_URL == TVPlayIE._VALID_URL
    assert extractor_instance.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/videojs/BrightcoveExperiences.js'

# Generated at 2022-06-24 13:38:45.190263
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test_TVPlayHomeIE_constructor()
    TVPlayHomeIE()



# Generated at 2022-06-24 13:38:47.005900
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-24 13:38:47.857381
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()

# Generated at 2022-06-24 13:38:50.002223
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test whether it is creating an instance without error
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-24 13:38:57.177902
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    methods = [
        '_extract_from_url',
        '_real_extract',
        '_get_info_dict',
    ]

# Generated at 2022-06-24 13:39:05.630319
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    mtg_test_url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    viafree_test_url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    netloc_part = mtg_test_url.split('/')[2]
    through_mtg = TVPlayIE._build_url_result(netloc_part, mtg_test_url)
    through_viafree = TVPlayIE._build_url_result(netloc_part, viafree_test_url)
    assert (through_mtg == through_viafree)
    return True

# Generated at 2022-06-24 13:39:07.243901
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    def create_TVPlayHomeIE():
        return TVPlayHomeIE('http://x.xx')
    assert create_TVPlayHomeIE()

# Generated at 2022-06-24 13:39:08.971294
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import tvplayIE
    tvplayIE.TVPlayIE()



# Generated at 2022-06-24 13:39:11.095932
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()
    assert vf.geo_verification_headers()
    assert vf.geo_bypass
    assert vf._GEO_BYPASS
