

# Generated at 2022-06-24 13:29:19.231329
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url_dk = "http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5"
    url_no = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    url_se = "http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1"

    ViafreeIE()
    ViafreeIE()

    ViafreeIE({"country": "dk"})
    ViafreeIE({"country": "no"})
    ViafreeIE({"country": "se"})

    v = ViafreeIE({"country": "dk"})

# Generated at 2022-06-24 13:29:23.838657
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert (TVPlayHomeIE._VALID_URL ==
            'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')
    assert TVPlayHomeIE._TESTS[1]['only_matching'] == True


# Generated at 2022-06-24 13:29:31.925800
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info = TVPlayIE()._real_extract("https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    assert info["id"] == "409229"
    assert info["series"] == "Moterys meluoja geriau"
    assert info["episode_number"] == 47
    assert info["season"] == "1 sezonas"
    assert info["season_number"] == 1
    assert info["title"] == "Moterys meluoja geriau"
    assert info["duration"] == 1330
    assert info["timestamp"] == 1403769181
    assert info["upload_date"] == "20140626"
    assert info["view_count"] == 515
    assert info["subtitles"] == {}

# Generated at 2022-06-24 13:29:36.078253
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test the cases where ViafreeIE can be used
    assert ViafreeIE.suitable('http://www.viafree.se...') is True
    assert ViafreeIE.suitable('http://tvplay.skaties.lv/...') is False

# Generated at 2022-06-24 13:29:46.935017
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'
    #url of the testcase
    test_TVPlayIE.get_url() == "https://www.tv3play.se/program/husraddarna/395385?autostart=true"
    #check the length of video
    assert len(test_TVPlayIE.get_video().formats) != 0
    #check the formats of video
    test_TVPlayIE.get_video().formats[0].get('format') == 'hls'
    #check the status of the testcase
    assert test_TVPlayIE.get_video().status == "SUCCESS"

# Generated at 2022-06-24 13:29:47.847993
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')


# Generated at 2022-06-24 13:29:57.375998
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')

# Generated at 2022-06-24 13:29:59.059595
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.geo_verification_headers() == {}


# Generated at 2022-06-24 13:30:03.159055
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.IE_NAME == 'tvplay:home'

# Generated at 2022-06-24 13:30:04.338940
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:30:10.487319
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import Gen
    from .common import InfoExtractor

    url = 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    ie = Gen(InfoExtractor._call_downloader, url)
    ie.add_info_extractor(ViafreeIE)
    info = ie.extract()
    assert(info['id'] == '676869')

# Generated at 2022-06-24 13:30:12.490729
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:30:17.605928
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test constructor of Class TVPlayIE."""
    # This URL is a TVPlayIE video and must be matched.
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    url_info = extractor.suitable(url)
    assert url_info[0] == 'TVPlayIE', "url_info[0] must be 'TVPlayIE'"


# Generated at 2022-06-24 13:30:20.883687
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert hasattr(ViafreeIE, 'suitable')
    assert hasattr(ViafreeIE, '_TESTS')
    assert hasattr(ViafreeIE, '_GEO_BYPASS')
    assert hasattr(ViafreeIE, '_VALID_URL')
    assert hasattr(ViafreeIE, '_real_extract')


# Generated at 2022-06-24 13:30:27.758733
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:30:38.719720
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == "mtg" # Channel ID for mtg
    assert ie._VALID_URL == r'(?x)http://(?:www\.)?tvplay\.lv/(?:parraides|programmas)/(?P<id>\d+)'
    # Test extractor with URL of a movie
    ie.extract("http://tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true")
    ie.extract("http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true")
    ie.extract("https://tvplay.lv/vinas-melo-labak/418113/?autostart=true")


# Generated at 2022-06-24 13:30:42.014326
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t.IE_DESC is not None
    assert t.IE_NAME is not None
    assert t.ie_key() is not None


# Generated at 2022-06-24 13:30:47.134254
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import tvplay
    from ..compat import unittest

    class TVPlayIETest(unittest.TestCase):
        def test_tvplay_create(self):
            tvplay.TVPlayIE()

    unittest.main(argv=['test'], defaultTest='TVPlayIETest')


# Generated at 2022-06-24 13:30:59.057292
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:31:05.589807
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')


# Generated at 2022-06-24 13:31:13.616149
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(ie.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'))
    assert(not ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert(not ie.suitable('https://viafree.se/program/underhallning/utmanarna/sasong-1/avsnitt-1'))

# Generated at 2022-06-24 13:31:24.824922
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:31:28.327970
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # fail to instantiate due to missing url_result argument
    with pytest.raises(ExtractorError):
        TVPlayHomeIE(FakeInfoExtractor())

# Unit tests for extractors:

# Generated at 2022-06-24 13:31:29.865058
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:31:41.576780
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert all(ViafreeIE.suitable(url) for url in (
        'http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5',
        'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
        'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    ))
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    assert not ViafreeIE.suitable('mtg:719652')
    assert not ViafreeIE.su

# Generated at 2022-06-24 13:31:42.948245
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL, {'test': True})

# Generated at 2022-06-24 13:31:44.563174
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_ = globals()['ViafreeIE']
    assert class_ == ViafreeIE



# Generated at 2022-06-24 13:31:49.025908
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(url)
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie.content == None
    assert ie._GEO_BYPASS == False



# Generated at 2022-06-24 13:31:51.465368
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    i = TVPlayIE()
    assert isinstance(i, TVPlayIE)

#Unit test for _VALID_URL

# Generated at 2022-06-24 13:31:56.047061
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE({}).get_id('http://www.tv3play.dk/programmer/sygt-parat/3') == '3'
    assert TVPlayIE({}).get_id('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == '395385'

# Generated at 2022-06-24 13:32:04.994635
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    if __name__ == "__main__":
        IE = TVPlayIE()
        print(IE.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'))
        print(IE.extract('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'))
        print(IE.extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true'))
        print(IE.extract('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true'))

# Generated at 2022-06-24 13:32:06.178445
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg:418113')


# Generated at 2022-06-24 13:32:17.953466
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # assert that you can construct the class with a valid URL
    assert re.match(ViafreeIE._VALID_URL, 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert re.match(ViafreeIE._VALID_URL, 'http://viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert re.match(ViafreeIE._VALID_URL, 'https://viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:32:23.081972
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    
    # Test with normal working case
    tvp = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    
    # Test with non valid URL
    try:
        TVPlayIE('this is not url')
    except AssertionError:
        pass
    
    print ('All tests for class TVPlayIE run')

# Generated at 2022-06-24 13:32:34.751557
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:32:38.431858
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t.get_video_id('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true') == '409229', 'TVPlayIE check constructor'

# Generated at 2022-06-24 13:32:49.510814
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable(None)
    assert not viafree_ie.suitable('http://viasat4play.no/')
    assert not viafree_ie.suitable(TVPlayIE.suitable('http://viasat4play.no/'))
    assert not viafree_ie.suitable(TVPlayListIE.suitable('http://viasat4play.no/'))
    assert not viafree_ie.suitable(TV3PlayIE.suitable('http://viasat4play.no/'))
    assert viafree_ie.suitable(
        'https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-24 13:32:56.515701
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    assert ViafreeIE.__name__ == 'ViafreeIE'
    assert ViafreeIE.IE_NAME == 'viafree'
    assert ViafreeIE.IE_DESC == 'Viafree'
    assert ViafreeIE._VALID_URL == r'''(?x)
                                        https?://
                                            (?:www\.)?
                                            viafree\.(?P<country>dk|no|se)
                                            /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                        '''

# Generated at 2022-06-24 13:33:05.419901
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert (instance.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'))
    assert (instance.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'))
    assert (instance.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') is not
            True)

# Generated at 2022-06-24 13:33:06.444458
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:33:15.604497
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE

    class _FakeInfoExtractor(ViafreeIE):
        def _download_json(self, url, video_id, *args, **kwargs):
            json_string = '{ "geoblocked":true,"type":"geoblock" }'
            return json.loads(json_string)

    fake_extractor = _FakeInfoExtractor({})
    fake_extractor.add_geo_bypass = True
    fake_extractor.IE_NAME = 'fake_extractor'


# Generated at 2022-06-24 13:33:21.386743
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # extractor properties
    assert ie.IE_NAME == 'tvplay.home'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_downloader')
    assert hasattr(ie, '_download_webpage_handle')
    assert hasattr(ie, 'suitable')
    assert hasattr(ie, '_real_extract')
    # instance properties
    assert hasattr(ie, 'url')
    assert hasattr(ie, 'video_id')
    assert hasattr(ie, '_initialize')
    assert hasattr(ie, '_download_webpage')

# Generated at 2022-06-24 13:33:25.396693
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    vp = TVPlayIE()
    assert isinstance(vp._VALID_URL, str)
    assert vp._TESTS
    assert vp.IE_NAME
    assert vp.IE_DESC


# Generated at 2022-06-24 13:33:26.377578
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(None);

# Generated at 2022-06-24 13:33:29.645959
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('tvplay.tv3.lt', 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.SUFFIX == '.lt'

# Generated at 2022-06-24 13:33:31.530165
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for the constructor of class ViafreeIE."""
    viafreeIE = ViafreeIE()
    assert(viafreeIE._VALID_URL == ViafreeIE._VALID_URL)
    assert(viafreeIE.name == 'Viafree')
    assert(viafreeIE.ie_key() == 'viafree')

# Generated at 2022-06-24 13:33:34.117032
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:33:35.720557
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('mtg')
    assert TVPlayIE(TVPlayIE.ie_key())



# Generated at 2022-06-24 13:33:40.437381
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay = TVPlayIE()
    test_dict = tvplay._real_extract(test)
    assert 'title' in test_dict
    assert '418113' in test_dict['id']
    assert 'mp4' in test_dict['formats'][0]['ext']


# Generated at 2022-06-24 13:33:41.866873
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    ViafreeIE(None)



# Generated at 2022-06-24 13:33:45.264941
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    # Have to use this URL since the test URL of class ViafreeIE
    # is a future episode
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')



# Generated at 2022-06-24 13:33:48.139189
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')



# Generated at 2022-06-24 13:33:58.601176
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:34:10.338674
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    inst = TVPlayIE()

# Generated at 2022-06-24 13:34:19.117218
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-24 13:34:21.372925
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for test in TVPlayHomeIE._TESTS:
        assert TVPlayHomeIE._match_id(test['url']) is not None

# Generated at 2022-06-24 13:34:26.145600
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE()
    assert x.IE_NAME == 'viafree'
    assert x.SITE_NAME == 'viafree'
    assert x._VALID_URL == ViafreeIE._VALID_URL
    assert x._TEST == ViafreeIE._TESTS

# Generated at 2022-06-24 13:34:32.444145
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert ie.url == "https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/"
    assert ie.video_id == "366367"
    assert ie.country == 'lt'


# Generated at 2022-06-24 13:34:42.918240
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL == "^https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)")

# Generated at 2022-06-24 13:34:51.253858
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t = ViafreeIE('test')
    assert t.name == 'test'
    assert t.domain == 'test'
    assert t.ia_video_id_key == 'test_id'
    assert t.ia_video_result_key == 'test'
    assert t.playlist_result_key == 'test'
    assert t.playlist_count_key == 'test_result_count'
    assert t.playlist_title_key == 'test_title'
    assert t.playlist_description_key == 'test_description'
    assert t.playlist_thumbnail_key == 'test_image'

# Generated at 2022-06-24 13:34:53.898352
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Constructor for class ViafreeIE should not raise exception"""
    try:
        ViafreeIE()
    except Exception:
        raise AssertionError("ViafreeIE constructor should not raise exception")

# Generated at 2022-06-24 13:34:59.577748
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert not ViafreeIE.suitable('https://www.tv3play.se/program/husraddarna/395385?autostart=true')



# Generated at 2022-06-24 13:35:09.971550
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE._download_json = lambda self, *a, **kw: {
        'assetId': '123',
        'title': {
            'title': 'Title',
            'summaryLong': 'Long',
            'summaryShort': 'Short',
            'runTime': '00:01:00',
            'titleBrief': 'Brief',
        },
        'movie': {
            'contentUrl': 'movie.m3u8',
        },
    }

# Generated at 2022-06-24 13:35:21.284777
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:35:24.896056
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE()
    ie.extract(url)


# Generated at 2022-06-24 13:35:27.592637
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
        Test to instantiate class ViafreeIE.
    """
    ie = ViafreeIE()    # Should not fail


# Generated at 2022-06-24 13:35:29.174478
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree._GEO_BYPASS == False

# Generated at 2022-06-24 13:35:35.472445
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check if we get the right IE when using ViafreeIE.suitable
    assert(ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == False)
    assert(ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == True)


# Generated at 2022-06-24 13:35:40.321476
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:35:41.030869
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:35:47.134368
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.VALID_URL_PATTERN == '^(?x)https?://(?:www\.)?viafree\.(?:dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie.IE_NAME == 'mtg'
    assert ie.GEO_COUNTRIES == ['DK', 'NO', 'SE']

# Generated at 2022-06-24 13:35:49.107199
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Simple check that the constructor makes an object of class ViafreeIE
    assert isinstance(ViafreeIE(), ViafreeIE)

# Generated at 2022-06-24 13:35:50.696705
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE('url', 'username', 'password')

# Generated at 2022-06-24 13:35:51.850123
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:36:00.296942
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317")
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie.ie_key() == 'tvplayhome'
    assert ie.ies == [TVPlayHomeIE]
    assert ie.test() is False
    assert ie.is_suitable() is True
    assert ie.working

# Generated at 2022-06-24 13:36:03.986715
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._is_valid_url(TVPlayHomeIE._VALID_URL)
    assert not TVPlayHomeIE._is_valid_url('https://tvplay.tv3.lt/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:36:04.965565
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-24 13:36:09.951282
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert instance.suitable(
        'https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == True
    assert instance.suitable(
        'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true') == False

# Generated at 2022-06-24 13:36:16.522600
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # construct TVPlayHomeIE object
    tvplay_home_ie_obj = TVPlayHomeIE()

    # Check if the object's URL property has been set
    assert tvplay_home_ie_obj._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-24 13:36:24.979260
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:36:27.239196
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE('ViafreeSE', 'dk') == ViafreeIE('ViafreeDK', 'dk')
    assert not ViafreeIE('ViafreeDK', 'dk') == ViafreeIE('ViafreeSE', 'dk')

# Generated at 2022-06-24 13:36:30.121178
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id = ie._match_id(url)
    assert video_id == '366367'

# Generated at 2022-06-24 13:36:32.190186
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert hasattr(ViafreeIE, 'IE_DESC')
    viafreeIE = ViafreeIE()
    assert viafreeIE.IE_NAME == 'viafree'

# Generated at 2022-06-24 13:36:35.079245
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('Viafree', True)
    assert ie.IE_NAME == 'Viafree'
    assert ie._GEO_COUNTRIES == ['NO', 'DK', 'SE']

# Generated at 2022-06-24 13:36:42.557235
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.get_geo_allowed() == [None]
    ie = ViafreeIE(geo_countries=None)
    assert ie.get_geo_allowed() == [None]
    ie = ViafreeIE(geo_countries=['SE'])
    assert ie.get_geo_allowed() == ['SE']
    ie = ViafreeIE(geo_countries=['DK','NO','SE'])
    assert ie.get_geo_allowed() == ['DK','NO','SE']

# Generated at 2022-06-24 13:36:45.366828
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv6play.se/program/undercover-boss-sverige/341757?autostart=true')


# Generated at 2022-06-24 13:36:55.248287
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:36:57.023892
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    assert instance._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-24 13:37:00.481305
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplay_home'
    assert ie.IE_DESC == 'TVPlay Home, TV3Play and Viaplay - via m3u8 or rtmp download'
    assert ie.BR_DESC == 'hls'



# Generated at 2022-06-24 13:37:04.970074
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t.ie_key() == 'mtg'
    assert TVPlayIE.ie_key() == 'mtg'
    assert t.ie_name() == 'MTG services'
    assert TVPlayIE.ie_name() == 'MTG services'
    assert t.ie_desc() == 'MTG services'
    assert TVPlayIE.ie_desc() == 'MTG services'



# Generated at 2022-06-24 13:37:07.203458
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:37:12.437989
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(
        'https://www.tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'https://www.tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.url == 'https://www.tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert ie.video_id == '10280317'
    assert ie._site_id == 'skaties'
    assert ie._site_name == 'tv3play'

# Generated at 2022-06-24 13:37:13.593644
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE({})



# Generated at 2022-06-24 13:37:20.476242
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(0, '', {}, {}, 0, None)

    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    assert ie.suitable(url) == True

    url = 'http://www.tv3play.se/program/paradise-hotel/saeson-7/episode-5'
    assert ie.suitable(url) == False



# Generated at 2022-06-24 13:37:24.033539
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    return_value = ViafreeIE(None)._download_webpage
    assert_equal(
        "http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869",
        return_value.__defaults__[0],
        "ViafreeIE doesn't work")

# Generated at 2022-06-24 13:37:24.634226
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:37:29.815888
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL
    assert re.match(ie._VALID_URL, 'https://play.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')

# Generated at 2022-06-24 13:37:40.869014
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        from youtube_dl.downloader.http import HttpFD
        import pycurl
    except ImportError:
        return

    # Set up the unit test
    def _download_json(*args):
        pass

    def _sort_formats(*args):
        return

    class _FakeInfoExtractor(ViafreeIE):
        def _real_extract(self, url):
            return

    # _download_json() returns 403 error
    ie = _FakeInfoExtractor()
    ie._download_json = _download_json

    try:
        ie._real_extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    except Exception as e:
        assert isinstance(e, ExtractorError)

    # Tested with pycurl version 7

# Generated at 2022-06-24 13:37:52.589236
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()

# Generated at 2022-06-24 13:38:03.624378
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898')
    assert not ViafreeIE.suitable('http://www.viasat4play.no/programmer/budbringerne/21873')

# Generated at 2022-06-24 13:38:04.149166
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:38:11.889989
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    # url = 'https://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay = TVPlayIE()

# Generated at 2022-06-24 13:38:13.469677
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()._VALID_URL == ViafreeIE._VALID_URL

# Generated at 2022-06-24 13:38:23.991378
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import _TEST_DATA


# Generated at 2022-06-24 13:38:25.245462
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None).to_screen('test')


# Generated at 2022-06-24 13:38:37.245035
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from ..YoutubeIE import YoutubeIE
    from ..YoutubePlaylistIE import YoutubePlaylistIE
    from ..SVTIE import SVTIE
    from ..DrTVIE import DrTVIE
    from ..NPOIE import NPOIE
    from ..RTVNHIE import RTVNHIE
    from ..RaiPlayIE import RaiPlayIE
    from ..TFIOnDemandIE import TFIOnDemandIE
    from ..TVPlayIE import TVPlayIE

    site = ViafreeIE(YoutubeIE())
    assert isinstance(site, YoutubeIE)
    assert isinstance(site.ie, YoutubeIE)

    site = ViafreeIE(YoutubePlaylistIE())
    assert isinstance(site, YoutubePlaylistIE)
    assert isinstance(site.ie, YoutubePlaylistIE)

    site = ViafreeIE(SVTIE())
   

# Generated at 2022-06-24 13:38:42.638495
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome = TVPlayHomeIE()
    # For each given testcase check if it matches with regular expression and
    # if the value of video_id is the expected one
    for test in tvplayhome._TESTS:
        match = re.match(tvplayhome._VALID_URL, test['url'])
        vid = match.group('id')
        assert vid == test['info_dict']['id']

# Generated at 2022-06-24 13:38:46.848530
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    assert t._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:38:48.102947
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:38:55.783614
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test case 1: A valid url is given as 'url' argument
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'
    ie = TVPlayHomeIE(url)
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

    # Test case 2: An invalid url is given as 'url' argument
    url = 'https://www.youtube.com/watch?v=U0uMbq3a7cY'
    with pytest.raises(ExtractorError):
        ie = TVPlayHomeIE(url)



# Generated at 2022-06-24 13:39:00.429456
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    url = 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    tvPlayHomeIE = TVPlayHomeIE(TVPlayHomeIE._create_ie(url), url, {})
    # TODO: This is a unit test, add assertions.
    tvPlayHomeIE._real_extract(url)

# Generated at 2022-06-24 13:39:02.604720
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:39:06.573391
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TODO: remove when it's possible to pass the actual class type as (TVPlayIE, ...)
    assert TVPlayIE.__name__ == 'TVPlayIE'
    assert TVPlayIE.__name__ == TVPlayIE().ie_key()



# Generated at 2022-06-24 13:39:14.126854
# Unit test for constructor of class TVPlayHomeIE