

# Generated at 2022-06-24 13:29:17.995867
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # The ViafreeIE test case is derived from TVPlayIE test case,
    # thus we will only test the following:
    # (1) ViafreeIE.suitable
    # (2) ViafreeIE constructor
    
    # Test #1: Unsupported URL
    url = 'http://www.tv3play.se/program/husraddarna/395385'
    assert not ViafreeIE.suitable(url)
    
    # Test #2: Supported URL
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    assert ViafreeIE.suitable(url)

# Generated at 2022-06-24 13:29:20.100400
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-24 13:29:22.746213
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # http://palai.tvweb.com/index.php/show/index/type/clip/id/8117
    ie = TVPlayIE()
    ie.extract('mtg:8117')

# Generated at 2022-06-24 13:29:27.158042
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    except:
        print("Constructor test of class ViafreeIE failed!")
        return False
    print("Constructor test of class ViafreeIE is OK!")
    return True



# Generated at 2022-06-24 13:29:27.599613
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:29:29.295453
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # The string that construct instance of class TVPlayHomeIE
    TVPlayHomeIE('test')

#####################################
#
#   For Platform Viasat4, Viafree
#
#####################################

# Generated at 2022-06-24 13:29:30.408324
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None).constructor_test()


# Generated at 2022-06-24 13:29:36.873182
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class Mock_TVPlayIE():
        """Mock for class TVPlayIE"""

# Generated at 2022-06-24 13:29:47.815294
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:29:48.861931
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'

# Generated at 2022-06-24 13:29:51.802159
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()
    x._download_json('https://play.tv3.lt/sb/public/asset/366367', '366367')

# Generated at 2022-06-24 13:29:53.982181
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    testie = ViafreeIE(ViafreeIE.suitable)
    assert isinstance(testie, ViafreeIE)



# Generated at 2022-06-24 13:29:56.581447
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    _test_TVPlayIE = TVPlayIE()
    assert _test_TVPlayIE.IE_NAME == 'mtg'
    assert _test_TVPlayIE.IE_DESC



# Generated at 2022-06-24 13:29:59.942768
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = ViafreeIE(None)
    assert ie.suitable(url)


# Generated at 2022-06-24 13:30:07.500980
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # should not raise an exception in either of the cases
    # case 1
    ViafreeIE('http://www.viafree.dk/programmer/livsstil/husraddarna/saeson-5/episode-5')
    # case 2
    ViafreeIE('http://www.viafree.dk/programmer/livsstil/husraddarna/saeson-5/episode-5/video/husraddarna-avsnitt-3-sasong-5')



# Generated at 2022-06-24 13:30:11.595086
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    video_id = ie._match_id(test_url)
    assert video_id == '366367'



# Generated at 2022-06-24 13:30:15.364758
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Initializes TVPlayIE class
    klass = TVPlayIE()
    # Test for 'tvplay.se' site
    url = 'http://tvplay.se/program/husraddarna/395385'
    play_list = klass.suitable(url)
    assert play_list


# Generated at 2022-06-24 13:30:18.234109
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE(GOOD_URL)._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'


# Generated at 2022-06-24 13:30:21.937656
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE('www', 'tvplay.tv3.lt', 'aferistai-10047125')
    assert instance.domain == 'tvplay.tv3.lt'
    assert instance._format_id(None) == 'www'


# Generated at 2022-06-24 13:30:29.471294
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:30:33.112821
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # TVPlayHomeIE doesn't have name attribute
    assert not hasattr(TVPlayHomeIE, 'name')
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'


# Generated at 2022-06-24 13:30:37.007870
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_class = TVPlayIE
    test_input = '228871'
    inst = test_class(test_input)
    actual = inst.IE_DESC
    expected = 'MTG services'
    assert actual == expected


# Generated at 2022-06-24 13:30:49.197421
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:31:00.421692
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._TESTS[0]['url'] == 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert TVPlayIE._TESTS[0]['info_dict']['title'] == 'Moterys meluoja geriau'
    assert TVPlayIE._TESTS[0]['info_dict']['episode_number'] == 47
    assert TVPlayIE._TESTS[0]['info_dict']['season_number'] == 1
    assert TVPlayIE._TESTS[0]['info_dict']['duration'] == 1330
    assert TVPlayIE._TESTS[0]['info_dict']['timestamp'] == 1403769181
    assert TVPlayIE._TES

# Generated at 2022-06-24 13:31:04.306590
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    for url in ['http://playapi.mtgx.tv/v3/videos/624952']:
        assert ie.suitable(url), 'assert URL %s is suitable.' % url



# Generated at 2022-06-24 13:31:11.328603
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    assert_equal(ie._VALID_URL, ie.VALID_URL)
    assert_equal(re.match(ie.VALID_URL, url).groups()[0], ie._match_id(url))
    assert_equal(ie._VALID_URL, TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-24 13:31:15.462702
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_utils import IETestCase
    from .test_utils import make_test_video_result
    IETestCase.doTest(TVPlayIE, "tvplay.TVPlayIE", make_test_video_result)


# Generated at 2022-06-24 13:31:26.538068
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    string = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    result = TVPlayIE()._VALID_URL.search(string)
    if result is not None:
        assert 'id' in result.groupdict()
    result = TVPlayIE()._VALID_URL.search('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    if result is not None:
        assert 'id' in result.groupdict()
    result = TVPlayIE()._VALID_URL.search('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:31:30.119714
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE().suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-24 13:31:32.021731
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE().suitable('')

# Generated at 2022-06-24 13:31:35.977595
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    example_tvplay_url = "http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true"
    tv = TVPlayIE(example_tvplay_url)
    print(tv)


# Generated at 2022-06-24 13:31:37.903076
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE(TVPlayIE.ie_key())


# Generated at 2022-06-24 13:31:43.996657
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == False
    assert viafreeIE.suitable('http://play.viaplay.se/program/buddy-thunderstruck/3fc3e3b5-cbc2-4baf-bfa0-eaf5e1b76136') == True

# Generated at 2022-06-24 13:31:46.587324
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    viafree = ViafreeIE()
    viafree._initialize_geo_bypass("NO")
    viafree._download_json(url, "757786", headers=viafree.geo_verification_headers())


# Generated at 2022-06-24 13:31:48.484456
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.lt/')
    assert ie.get_host() == 'tvplay.tv3.lt'

# Generated at 2022-06-24 13:31:59.276727
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url_class in [
        TVPlayIE,
        ViafreeIE,
        TVPlayHomeIE,
    ]:
        ie = url_class(None)
        assert ie.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113/?autostart=true')
        assert ie.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')
        assert ie.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-24 13:32:07.896349
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-24 13:32:10.781481
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie, TVPlayIE)
    assert isinstance(ie, TV3PlayIE)

# Generated at 2022-06-24 13:32:14.026440
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()
    assert vf.IE_NAME == 'viafree'
    assert vf.IE_DESC == 'Viasat - Viafree'


# Generated at 2022-06-24 13:32:17.479939
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-24 13:32:26.368439
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:32:33.597752
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_ = TVPlayHomeIE
    # test wrong url
    try:
        class_(DummyIE())
        assert False
    except TypeError:
        assert True
    # test correct url
    try:
        class_(DummyIE(url='https://tv3play.skaties.lv/vinas-melo-labak-10280317'))
        assert True
    except TypeError:
        assert False



# Generated at 2022-06-24 13:32:36.001780
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('www.tv3.ee', 'tv3/')
    assert ie.ie_key() == 'TVPlayHome'


# Generated at 2022-06-24 13:32:43.649969
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    with open("test.html", "rb") as read_file:
        '''
        This test is only used to make a code coverage test.
        Mocking would be better, but also more difficult to understand.
        '''
        ie = TVPlayIE()
        ie.extract("http://play.tv3play.lv/programos/moterys-meluoja-geriau/409229?autostart=true", read_file)


# Generated at 2022-06-24 13:32:45.722029
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global ie
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:32:49.150371
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Since the real url is going to be passed to the class, we don't need
    # to use real url here.
    url = "http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5"
    viafreeIE = ViafreeIE()
    assert viafreeIE.suitable(url)

# Generated at 2022-06-24 13:32:50.441361
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._initialize_geo_bypass(None)



# Generated at 2022-06-24 13:33:01.811578
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from tvplaydownload.extractor import TVPlayHomeIE
    import requests
    import logging

    # Logging for debug
    logging.basicConfig(level=logging.DEBUG)

    url = 'https://tvplay.skaties.lv/vinas-melo-labak-10280317'
    video_id = '418113'
    requests.get('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE._download_webpage = lambda self, url, *args: requests.get(url).text

    asset = TVPlayHomeIE._download_json(
        urljoin(url, '/sb/public/asset/' + video_id), video_id)


# Generated at 2022-06-24 13:33:02.952626
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor of TVPlayIE
    TVPlayIE()

# Generated at 2022-06-24 13:33:09.095417
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Exception when video_id doesn't match pattern
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    # Exception when video_id is None
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak/')

# Generated at 2022-06-24 13:33:14.550934
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('Viafree', 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.name == 'Viafree'
    assert ie.SUCCESS == 200
    assert ie.country == 'no'
    assert ie.path == '/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'


# Generated at 2022-06-24 13:33:15.750528
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import types
    assert type(ViafreeIE) == types.TypeType

# Generated at 2022-06-24 13:33:19.617960
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    klass = TVPlayIE

# Generated at 2022-06-24 13:33:23.934728
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie._VALID_URL is not None
    assert ie.IE_NAME is not None
    assert ie.IE_DESC is not None
    assert ie.__name__ is not None
    assert ie.test() is not None

# Generated at 2022-06-24 13:33:34.257122
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """ Use TVPlayIE's constructor to run tests on youtube-dl's unit testing framework
    """

    # Setup
    from youtube_dl.utils import YoutubeDL
    ydl_opts = {}
    ydl = YoutubeDL(ydl_opts)

    # Test some URLs.

# Generated at 2022-06-24 13:33:35.324159
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError):
        ViafreeIE(TVPlayIE())

# Generated at 2022-06-24 13:33:37.890683
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    test._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')

# Generated at 2022-06-24 13:33:46.555445
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE."""


# Generated at 2022-06-24 13:33:51.429339
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if sys.version_info < (2, 5):
        raise SkipTest("Test case requires Python >= 2.5")
    # test whether the error of constructing incorrect url is caught
    url = TVPlayHomeIE._VALID_URL
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://play.tv3.lt/aferistai-10047125')
    assert not re.match(TVPlayHomeIE._VALID_URL, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:33:53.140748
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._download_json('test', 'test')

# Generated at 2022-06-24 13:33:55.494739
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvp = TVPlayIE()
    assert tvp.IE_NAME == 'mtg'
    assert tvp.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:59.728494
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    expect_match = False
    assert ie.suitable(test_url) == expect_match

# Generated at 2022-06-24 13:34:04.586448
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(
        mimic_browser=False,
        mimick_browser_for_hls=False,
        is_test=True)
    assert ie.mimic_browser == False
    assert ie.mimic_browser_for_hls == False


# Generated at 2022-06-24 13:34:05.346633
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:34:14.733142
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:16.221867
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        assert(ViafreeIE() != None)
    except:
        assert(False)

# Generated at 2022-06-24 13:34:24.113366
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    def test_class(url, ie_name):
        ie = ie_by_url(url)
        assert isinstance(ie, ie_name), ie.__class__
    test_class('https://play.tv3.lt/aferistai-10047125', TVPlayHomeIE)
    test_class('https://tv3play.skaties.lv/vinas-melo-labak-10280317', TVPlayHomeIE)
    test_class('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354', TVPlayHomeIE)


# Generated at 2022-06-24 13:34:27.972574
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/');

# Generated at 2022-06-24 13:34:29.073887
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
        assert True
    except AssertionError:
        assert False

# Generated at 2022-06-24 13:34:37.405103
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:40.296511
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable(ViafreeIE._VALID_URL)
    ie.suitable(TVPlayIE._VALID_URL)



# Generated at 2022-06-24 13:34:45.875178
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'
    assert TVPlayIE._VALID_URL.startswith('(?x)')
    assert TVPlayIE._VALID_URL.endswith(')')

test_TVPlayIE()



# Generated at 2022-06-24 13:34:48.864914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2")


# Generated at 2022-06-24 13:34:53.280016
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .youtube_dl.YoutubeDL import YoutubeDL

    ydl = YoutubeDL({})
    assert ydl.extract_info(
        'http://www.viafree.se/program/underhallning/det-beste-vorspielet/sesong-2/episode-1')['id'] == '757786'

# Generated at 2022-06-24 13:34:56.884336
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test of constructor of class TVPlayIE"""
    obj = TVPlayIE(None)
    assert isinstance(obj, TVPlayIE)
    assert isinstance(obj, InfoExtractor)


# Generated at 2022-06-24 13:34:57.988404
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-24 13:35:03.509473
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test for 1st constructor with regular expression
    cnst = TVPlayHomeIE._VALID_URL
    # Check for valid urls
    assert re.search(cnst, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert re.search(cnst, 'https://play.tv3.lt/aferistai-10047125')
    assert re.search(cnst, 'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert re.search(cnst, 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    # Check for invalid urls

# Generated at 2022-06-24 13:35:12.599343
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert ie.geo_countries == ['LT']
    ie = TVPlayHomeIE(TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    assert ie.geo_countries == ['LV']
    assert ie.url_result('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/').geo_countries == ['EE']

# Generated at 2022-06-24 13:35:15.564056
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie_TVPlayHomeIE = TVPlayHomeIE()
    print('Successfully created instance for class TVPlayHomeIE')


# Generated at 2022-06-24 13:35:26.755163
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_object = TVPlayIE()
    assert test_object.IE_NAME == 'mtg'
    assert test_object.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:35:32.290208
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    For creating unit tests:
    $ pip install nose
    $ nosetests test_ViafreeIE.py
    """
    class Tester(object):
        def test(self):
            """ViafreeIE should be constructor of ViafreeIE"""
            assert ViafreeIE is get_info_extractor('ViafreeIE')
    Tester().test()

# Generated at 2022-06-24 13:35:38.786370
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    vf = ViafreeIE(url)
    assert vf.country == 'se'

    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    vf = ViafreeIE(url)
    assert vf.country == 'no'


# Generated at 2022-06-24 13:35:47.173348
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for class methods
    assert ViafreeIE.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is False
    assert TVPlayIE.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is True
    assert ViafreeIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') is True
    assert TVPlayIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') is False


# Generated at 2022-06-24 13:35:49.156790
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE(None, None)
    except:
        pass


# Generated at 2022-06-24 13:35:51.157023
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.extract('mtg:418113')



# Generated at 2022-06-24 13:36:01.564910
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:05.462474
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert ie.get_geo_country() == 'lt'
    assert ie.get_domain() == 'tv3.lt'
    assert ie.get_id() == '366367'

# Generated at 2022-06-24 13:36:09.229425
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true")
    expected_url = "http://playapi.mtgx.tv/v3/videos/238551"
    assert ie._download_json.call_args == ((expected_url, "238551", "Downloading video JSON"),)



# Generated at 2022-06-24 13:36:15.660823
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree = ViafreeIE()
    assert viafree.suitable(url)
    url_emb = viafree.extract(url)
    print('This is extract_url: ', url_emb)
    assert url_emb['id'] == '757786'


# Generated at 2022-06-24 13:36:22.181939
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class MockInfoExtractor(InfoExtractor):
        def report_warning(self, message):
            pass

        def report_error(self, message):
            pass

    tvplay_ie = MockInfoExtractor(
        None,
        {
            'url': 'https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true',
            'params': {
                'test': 'true'
            }
        })


# Generated at 2022-06-24 13:36:24.007247
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    tvplayhome = TVPlayHomeIE()
    tvplayhome._real_extract(url)



# Generated at 2022-06-24 13:36:26.435859
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    #I want to make sure that ViafreeIE can handle url without country code
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    ViafreeIE().suitable(url)

# Generated at 2022-06-24 13:36:27.258711
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg', 'mtg')


# Generated at 2022-06-24 13:36:34.680008
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import httpretty
    from .test_html import fake_http_response

    # HTTPretty must be activated for test; watching for the registering of all urls
    httpretty.enable()
    httpretty.register_uri(httpretty.GET, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    httpretty.register_uri(httpretty.GET, 'https://tvplay.tv3.lt/aperistai-10047125')
    httpretty.register_uri(httpretty.GET, 'https://tvplay.tv3.lt/kur-tiesiogiai?productlist=9')

# Generated at 2022-06-24 13:36:40.091561
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ieurl = 'https://tvplay.skaties.lv/kodu-keset-linna/kodu-keset-linna-10191813/'
    webpage = ie.url_result(ieurl)
    assert webpage.url == ieurl
    assert webpage.ie_key() == 'TVPlayHome'


# Generated at 2022-06-24 13:36:41.614046
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
        assert False
    except TypeError:
        pass

# Generated at 2022-06-24 13:36:50.219186
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    video_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    IE = ViafreeIE()
    assert IE.suitable(video_url) is True
    assert IE._VALID_URL == '^(?:https?://)?(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)$'
    assert IE.__name__ == 'Viafree'

# Generated at 2022-06-24 13:36:52.070087
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie_test = TVPlayIE()
    assert ie_test._VALID_URL == ie_test._TEST.get('valid_url')


# Generated at 2022-06-24 13:36:58.700264
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:37:04.078830
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    # Check if _VALID_URL matches correct url
    match = ie._VALID_URL_RE.match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert match is not None

    # Check if _VALID_URL does not match an invalid url
    match = ie._VALID_URL_RE.match('https://tvplay.tv3.lt/not/a/real/url-10047125/')
    assert match is None


# Generated at 2022-06-24 13:37:11.067421
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie._match_id(None) == None
    assert ie._match_id('') == None
    assert ie._match_id('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') == 'livsstil/husraddarna/sasong-2/avsnitt-2'


# Generated at 2022-06-24 13:37:21.512046
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie.IE_NAME == 'mtg')
    assert(ie.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:37:32.155992
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:37:35.727448
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS


# Generated at 2022-06-24 13:37:36.806280
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-24 13:37:45.098490
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:37:47.345845
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME in ie.ie_key()


# Generated at 2022-06-24 13:37:58.858774
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._download_webpage = lambda url, *args, **kwargs: '{'

# Generated at 2022-06-24 13:38:08.657660
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    # Tests if constructor assigns appropriate values to the TVPlayIE object
    def test_TVPlayIE_constructor(self):
        assert self.play_list_id

    # Tests if service's name is correct
    def test_TVPlayIE_get_service_name(self):
        assert self.service_name == 'TVPlay'

    # Tests if constructor of base class has been executed (if it returned not None)
    def test_TVPlayIE_call_to_constructor_of_parent_class(self):
        assert self.page_url != None

    # Tests if url is correct
    def test_TVPlayIE_url(self):
        assert self.url == 'https://www.tvplay.lv/parraides/popkorns-s02e02/415239/'

    # Tests if content has appropriate properties (check if extract

# Generated at 2022-06-24 13:38:20.008917
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:38:26.989547
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    c = TVPlayHomeIE()
    assert c.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert c.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert c.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert c.suitable('https://play.tv3.lt/aferistai-10047125')
    assert c.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:38:39.229191
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Run unit test for constructor of class TVPlayIE.
    """
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:40.633120
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE({})
    assert isinstance(x, TVPlayHomeIE)

# Generated at 2022-06-24 13:38:48.493295
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE. Raises ValueError if 
    it fails and does nothing if it succeeds."""
    from .tvplay import TVPlayHomeIE
    ie = TVPlayHomeIE([])
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    expected = re.compile('https://tv3play\.tv3\.lt/(?:[^/]+/)*[^/?#&]+-\d+')
    if not expected.match(url):
        raise ValueError('TVPlayHomeIE failed: expected: %r, got: %r'%
            (expected, url))

# Generated at 2022-06-24 13:38:56.078212
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree = ViafreeIE()
    assert viafree._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert viafree.suitable(url) is True
    assert viafree.IE_NAME == 'viafree'
    assert viafree._TEST is ViafreeIE._TEST
    assert viafree._TESTS == ViafreeIE._TESTS
    assert viafree._GEO_BYPASS == ViafreeIE._GEO_BYPASS
    assert viafree._VALID_URL == ViafreeIE._VALID

# Generated at 2022-06-24 13:39:02.067841
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    assert ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:39:04.696738
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:39:06.194260
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import tvplayhome
    assert issubclass(tvplayhome.TVPlayHomeIE, TVPlayHomeIE)

# Generated at 2022-06-24 13:39:13.791797
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class Options(object):
        def __init__(self):
            self.parse_m3u8_in_init = True

        def __getitem__(self, _):
            return None

    compat_getprog = lambda: 'youtube-dl'
    compat_getpass = lambda: None
