

# Generated at 2022-06-24 13:29:14.976521
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    content = '{}'
    meta = {}
    stream_href = 'http://www.example.com/path/'
    guid = '357630'
    title = 'series title'
    episode = {}
    program = {'guid': guid, 'episode': episode, '_links': {'streamLink': {'href': stream_href}}, 'video': {'duration': {'milliseconds': '251000'}}, 'availability': {'start': '2016-11-24T18:00:00.000Z'}}
    content = {'meta': meta, '_embedded': {'viafreeBlocks': [{'_embedded': {'program': program}}]}}
    path = 'path/to/program'
    country = 'se'


# Generated at 2022-06-24 13:29:16.382527
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, None, None)
    assert ie is not None, "Can not create instance for TVPlayHomeIE"


# Generated at 2022-06-24 13:29:27.038223
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)

# Generated at 2022-06-24 13:29:28.629951
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(TVPlayHomeIE.ie_key()) is not None, 'TVPlayHomeIE failed'

# Generated at 2022-06-24 13:29:35.210109
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert 'Vīna melo labāk' in IE._VALID_URL
    assert IE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/") is True
    assert IE.suitable("https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/") is True
    assert IE.suitable("https://play.tv3.lt/aferistai-10047125") is True

# Generated at 2022-06-24 13:29:36.749222
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplayhome'

# Generated at 2022-06-24 13:29:39.859241
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Constructor for class ViafreeIE should raise error
    with pytest.raises(TypeError) as excinfo:
        ViafreeIE()
    assert '__init__() takes exactly 3 arguments' in str(excinfo.value)

# Generated at 2022-06-24 13:29:50.193913
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test _VALID_URL
    match = TVPlayHomeIE._VALID_URL.match
    assert match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert match('https://play.tv3.lt/aferistai-10047125')
    assert match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert match('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert match('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-24 13:29:51.105543
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assertViafreeIE(ie)

# Generated at 2022-06-24 13:29:52.920220
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_ie = TVPlayIE()
    assert(test_ie.IE_NAME == 'mtg')


# Generated at 2022-06-24 13:29:54.246966
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Instantiation of class TVPlayHomeIE
    TVPlayHomeIE()


# Generated at 2022-06-24 13:29:56.275550
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import unittest
    obj = ViafreeIE()
    assert isinstance(obj, ViafreeIE)
    assert isinstance(obj, InfoExtractor)

# Generated at 2022-06-24 13:30:02.843374
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    c = ViafreeIE('https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/avsnitt-3')
    assert isinstance(c, ViafreeIE)
    assert c.get_country() == 'SE'
    assert c.get_path() == '/program/underhallning/i-like-radio-live/sasong-1/avsnitt-3'

# Generated at 2022-06-24 13:30:08.355364
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def get_info(url):
        try:
            TVPlayIE()._real_extract(url)
            return True
        except ExtractorError:
            return False

    url_list = TVPlayIE._TESTS[0]['url']
    for url in url_list:
        assert get_info(url)


# Generated at 2022-06-24 13:30:13.784931
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE(url)
    assert ie.suitable(url)
    assert ie.extract(url).get('id') == '366367'
    assert ie.extract(url).get('title') == 'Aferistai'
    ie.suitable(url)



# Generated at 2022-06-24 13:30:21.270252
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)

# Generated at 2022-06-24 13:30:29.061011
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    def test_url(url, vid, country):
        asset = ie._download_json(urljoin(url, '/sb/public/asset/' + vid), vid)
        assert asset['assetId'] == vid
        assert url[url.index('play.'):].startswith(ie._geo_countries()[country])

    test_url('https://tvplay.tv3.lt/aferistai-10047125', '366367', 'lt')
    test_url('https://tvplay.skaties.lv/vinas-melo-labak-10280317', '418113', 'lv')

# Generated at 2022-06-24 13:30:40.988774
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE('http://www.viafree.net/program/reality/paradise-hotel/saeson-7/episode-10')
    assert not ViafreeIE('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true').suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')
    # The URL is suitable for TVPlayIE

# Generated at 2022-06-24 13:30:49.605771
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Testing the constructor of TVPlayHomeIE
    class_TVPlayHomeIE = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert class_TVPlayHomeIE is not None
    assert class_TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-24 13:30:56.861508
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.url_result('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == ie.url_result(
        'https://play.tv3.lt/aferistai-10047125') == ie.url_result('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')



# Generated at 2022-06-24 13:31:04.106947
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test = ViafreeIE()
    assert test.name == 'mtg'
    assert test.age_limit == 0
    assert test._VALID_URL is not None
    assert test._TESTS is not None
    assert test.geo_verification_headers() is not None
    assert test.extract_urls('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == [
        'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    ]

# Generated at 2022-06-24 13:31:14.478483
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/") == True)
    assert(TVPlayHomeIE.suitable("https://tvplayhome.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/") == False)
    assert(TVPlayHomeIE.suitable("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317") == True)
    assert(TVPlayHomeIE.suitable("https://play.tv3.lt/vinas-melo-labak-10280317") == True)

# Generated at 2022-06-24 13:31:17.675562
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    page = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    i = TVPlayHomeIE(page)
    assert i._match_id(page) == '366367'

# Generated at 2022-06-24 13:31:29.237085
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('https://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.suitable('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-24 13:31:41.094422
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import sys
    import inspect

    if 'test' not in sys.argv:
        return

    # all class objects from current module
    classes = inspect.getmembers(sys.modules[__name__], inspect.isclass)
    for name, cls in classes:
        if name != "TVPlayIE":
            continue
        clsobj = cls()
        regex = getattr(clsobj, "_VALID_URL", None)
        test_urls = getattr(clsobj, "_TESTS", None)
        # check that _VALID_URL regex exists and is not empty

# Generated at 2022-06-24 13:31:49.085847
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    desc = 'MTG services'

# Generated at 2022-06-24 13:31:54.641239
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    field_values_test_data = [
        ("http://play.tv3play.se/program/husraddarna/395385?autostart=true",
         "MTG services", "MTG services", _VALID_URL, {}),
    ]

    def compare_results(test_data, field, field_name):
        for item in test_data:
            field_value = item[field]
            assert field_value == getattr(TVPlayIE, field_name), 'field: %s, expected: %s, got: %s' % (field_name, field_value, getattr(TVPlayIE, field_name))

    for item in field_values_test_data:
        ie = TVPlayIE(item[0])
        compare_results(field_values_test_data, 1, 'IE_NAME')

# Generated at 2022-06-24 13:32:04.155089
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test for constructor of class TVPlayHomeIE
    """
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.SUFFIX == 'skaties.lv'
    assert isinstance(ie.VALID_URL, compat_re_type)
    assert ie.VALID_URL.match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:32:04.933311
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)



# Generated at 2022-06-24 13:32:11.080700
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.__name__ == 'TVPlayIE'
    assert TVPlayIE.__doc__ == 'MTG services'

# Generated at 2022-06-24 13:32:15.338419
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import tests
    from . import TVPlayHomeIE
    tvh = TVPlayHomeIE(tests.getTestInstance())
    assert isinstance(tvh, TVPlayHomeIE)
    assert tvh.SUFFIX == ' TVPlayHomeIE'

# Generated at 2022-06-24 13:32:18.237667
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    test_html = open('test.html')
    context = {'data': test_html.read()}
    info_extractor = TVPlayHomeIE(url)
    info_extractor._real_extract(url, context=context)
    test_html.close()



# Generated at 2022-06-24 13:32:23.606229
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test if all the necessary fields for ViafreeIE are present"""
    assert ViafreeIE.__name__ == 'Viafree'
    assert hasattr(ViafreeIE, '_VALID_URL')

# Generated at 2022-06-24 13:32:25.299074
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE._VALID_URL == TVPlayHomeIE.VALID_URL)


# Generated at 2022-06-24 13:32:31.946591
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    # Test regex and regex groups
    regex = IE._VALID_URL
    re_match = re.match(regex, 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert re_match.group('id') == '418113'

# Generated at 2022-06-24 13:32:35.381447
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafreeIE = ViafreeIE(URLDownloader())
    assert viafreeIE.suitable(url) == True

# Generated at 2022-06-24 13:32:47.075023
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:32:56.950005
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .common import fake_netrc
    fake_netrc(False)
    TVPlayIE.suitable('http://www.tv4play.se/program/damernas-varld')
    fake_netrc(True)
    TVPlayIE.suitable('http://www.tv4play.se/program/damernas-varld')
    TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    TVPlayIE.suitable('http://www.tv8play.se/program/antikjakten/282756?autostart=true')
    TV

# Generated at 2022-06-24 13:33:00.444109
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')



# Generated at 2022-06-24 13:33:02.554683
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE(None)
    assert obj is not None

# Test for TVPlayIE

# Generated at 2022-06-24 13:33:09.952832
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    inner = type('ViafreeIE', (), {'_VALID_URL': ViafreeIE._VALID_URL})()
    suitable = inner.suitable
    # assert not suitable('http://www.tv3play.no/programmer/budbringerne/21873')
    assert suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    # assert suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-24 13:33:15.785584
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.geo_verification_headers()

    # First TVPlayHomeIE is created by calling TVPlayHomeIE constructor.
    # The second one - by extended constructor of ViafreeIE.
    ie = TVPlayHomeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.geo_verification_headers()

# Generated at 2022-06-24 13:33:26.605145
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    v = TVPlayIE("https://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    assert v.name == 'mtg'
    assert v.IE_NAME == 'mtg'
    assert v.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:30.830983
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    class VideoItem:
        pass
    test_video = VideoItem()
    test_video.formats = []
    assert len(test_video.formats) == 0
    ie._sort_formats(test_video)
    assert len(test_video.formats) == 0



# Generated at 2022-06-24 13:33:33.093609
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')



# Generated at 2022-06-24 13:33:41.426285
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    test_TVPlayIE = TVPlayIE(url)

    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:44.906685
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj._VALID_URL is not None
    assert obj._TESTS is not None
    assert obj._GEO_BYPASS is not None
    assert obj.__name__ is not None
    assert obj.SUITABLE is not None
    assert obj.IE_DESC is not None
    assert obj.IE_NAME is not None
    assert obj.BROWSER is not None

# Generated at 2022-06-24 13:33:51.451563
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    # First check that the constructor raises no exception
    assert viafreeIE.suitable('http://www.viafree.se/program')

    # Then check that the constructor does not return true for
    # the URL of TVPlayIE (see https://github.com/rg3/youtube-dl/issues/11338)
    assert not TVPlayIE().suitable('http://www.tv3play.se/program')

# Generated at 2022-06-24 13:33:54.196509
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert(ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)')


# Generated at 2022-06-24 13:33:55.384955
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE


# Generated at 2022-06-24 13:34:07.299943
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # test case 1
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    result = ie._real_extract(url)
    assert result['id'] == '366367'
    assert result['ext'] == 'mp4'
    assert result['title'] == 'Aferistai'
    assert 'Aferistai. Kalėdinė pasaka.' in result['description']
    assert result['series'] == 'Aferistai [N-7]'
    assert result['season_number'] == 1
    assert result['duration'] == 464
    assert result['timestamp'] == 1394209658
    assert result['upload_date'] == '20140307'
    assert result['age_limit'] == 18


# Generated at 2022-06-24 13:34:10.503206
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    tvplay_home_ie = TVPlayHomeIE('TVPlayHome', ie.ie_key())
    assert isinstance(tvplay_home_ie, TVPlayHomeIE)

# Generated at 2022-06-24 13:34:19.268254
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    #Check if valid patterns are detected

# Generated at 2022-06-24 13:34:25.501641
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317')
    assert isinstance(x, TVPlayHomeIE)
    x = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert isinstance(x, TVPlayHomeIE)
    x = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert isinstance(x, TVPlayHomeIE)
    x = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert isinstance(x, TVPlayHomeIE)

# Generated at 2022-06-24 13:34:35.777790
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    image_url = 'http://bilder.viafree.no/programbilder/13/6/5/5/5/0/13655550/13655550.jpg'

# Generated at 2022-06-24 13:34:47.431720
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:49.652680
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE('abc', 'abc')
    assert viafree.country == 'abc'
    assert viafree.path == 'abc'

# Generated at 2022-06-24 13:34:53.293544
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafreeIE = ViafreeIE(fake_url_test)
    viafreeIE.suitable(url)

# Generated at 2022-06-24 13:35:05.056262
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import unittest
    import re
    TVPlayIE = TVPlayIE.TVPlayIE
    assert re.match(TVPlayIE._VALID_URL, 'https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert TVPlayIE._TESTS[14] == {'url': 'http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true', 'only_matching': True}
    test = TVPlayIE._TESTS[13]
    assert re.match(TVPlayIE._VALID_URL, test['url'])
    assert re.match(test['info_dict']['id'], '395385')

# Generated at 2022-06-24 13:35:08.979816
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if sys.gettrace() is not None:
        raise RuntimeError('TVPlayHomeIE tests do not work when tracing (sys.gettrace() is not None)')
    if not sys.warnoptions:
        warnings.simplefilter('default')
    TVPlayHomeIE('TVPlayHomeIE')

# Generated at 2022-06-24 13:35:19.870123
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME.lower() == 'mtg'
    assert TVPlayIE.IE_DESC.lower() == 'mtg services'


# Generated at 2022-06-24 13:35:27.977645
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(dk|no|se)
                        /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == True


# Generated at 2022-06-24 13:35:29.174646
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    extractor = TVPlayHomeIE()
    assert extractor

# Generated at 2022-06-24 13:35:32.398795
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Unit test for constructor of class TVPlayIE
    """
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.IE_NAME == 'tvplay'



# Generated at 2022-06-24 13:35:33.467444
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:35:35.654917
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie = TVPlayIE('TVPlay')
    assert ie.IE_NAME == 'mtg'



# Generated at 2022-06-24 13:35:44.710976
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class _Tester(object):
        def __init__(self, url):
            self.url = url
            self.ie = TVPlayHomeIE(self)

        def result(self):
            return self.ie._real_extract(self.url)

    x = _Tester("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert x.result()['id'] == '366367'
    assert x.result()['ext'] == 'mp4'
    assert x.result()['title'] == 'Aferistai'
    assert x.result()['description'] == 'Aferistai. Kalėdinė pasaka.'
    assert x.result()['series'] == 'Aferistai [N-7]'

# Generated at 2022-06-24 13:35:55.972715
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    # Test single country where ViafreeIE is suitable
    test_url = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    assert ViafreeIE.suitable(test_url)

    # Test multiple countries where ViafreeIE is suitable
    test_url = "http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2"
    assert ViafreeIE.suitable(test_url)

    # Test single country where ViafreeIE is not suitable

# Generated at 2022-06-24 13:35:58.853211
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    # URL for IP with geo restriction
    ViafreeIE._GEO_BYPASS = True
    ie = ViafreeIE(url)
    # URL for IP with no geo restriction
    ie = ViafreeIE(url)

# Generated at 2022-06-24 13:36:00.835257
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay = TVPlayHomeIE(None)
    assert tvplay._VALID_URL == TVPlayHomeIE._VALID_URL
    assert tvplay._TESTS == TVPlayHomeIE._TESTS

# Generated at 2022-06-24 13:36:05.084834
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.compat import str

    assert str(ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')) == '<ViafreeIE(http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2>'

# Generated at 2022-06-24 13:36:12.843405
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125', {}, None)
    assert ie.country is None
    assert ie._VALID_URL == (TVPlayHomeIE._VALID_URL + '|https?://tv3play\.skaties\.lv/(?:[^/]+/)+(?P<id>\d+)|'
        + 'https?://(?:tv3?)?play\.tv3\.ee/(?:[^/]+/)*[^/?#&]+(?P<id>\d+)')
    assert ie._GEO_BYPASS is True



# Generated at 2022-06-24 13:36:19.120627
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test constructor of class TVPlayIE"""

    t = TVPlayIE()
    # test if the class name is TVPlayIE
    assert t.IE_NAME == 'mtg'
    # test if the class description is MTG services
    assert t.IE_DESC == 'MTG services'
    # test if the regex for checking if a url can be extracted matches
    assert re.match(t._VALID_URL, 'http://www.viafree.no/program/underholdning/i-like-radio-live/sasong-1/676869') is not None
    # test if the regex for checking if a id can be extracted matches
    assert re.match(t._VALID_URL, 'mtg:418113') is not None

# Generated at 2022-06-24 13:36:27.177937
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE('TVPlayHome', True)
    test_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert IE._valid_url(test_url, 'TVPlayHome')
    assert not IE._valid_url('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', 'TVPlayHome')
    assert not IE._valid_url('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/', 'TVPlayHome')

# Generated at 2022-06-24 13:36:29.427535
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv8play.se/program/antikjakten/282756?autostart=true')
    assert ie.name == 'mtg'



# Generated at 2022-06-24 13:36:30.553404
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ Unit test for constructor of class TVPlayHomeIE """
    ie = TVPlayHomeIE()

# Generated at 2022-06-24 13:36:35.163994
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.tv3play.no/programmer/house/395385') == False
    assert ie.suitable('http://www.viafree.se/program/husraddarna/395385') == True
    assert ie.suitable('http://www.tv3play.no/programmer/house') == False
    assert ie.suitable('http://www.tv3play.se/program/husraddarna') == False

# Generated at 2022-06-24 13:36:38.344195
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.SUITABLE(TVPlayHomeIE._VALID_URL)
    assert not ie.SUITABLE(TVPlayIE._VALID_URL)


# Generated at 2022-06-24 13:36:42.746879
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125'
    ie = TVPlayHomeIE(url)
    assert ie.__module__ == 'youtube_dl.extractor.tvplayhome'
    assert ie.url == url



# Generated at 2022-06-24 13:36:46.530391
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lv/vinas-melo-labak/vinas-melo-labak-10044354/')
    TVPlayHomeIE('https://play.tv3.lv/vinas-melo-labak-10044354')

# Generated at 2022-06-24 13:36:48.643659
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv4play.se/program/bonde-soker-fru?video_id=495514')


# Generated at 2022-06-24 13:36:52.194698
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('tv3play:238551')
    ViafreeIE('mtg:418113')
    ViafreeIE('https://viafree.se/program/sport/viafree-sport-extra/season-1/episode-1')

# Generated at 2022-06-24 13:37:01.269922
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    cls = get_info_extractor('Viafree')
    assert cls is not None, 'Extractor not found'

# Generated at 2022-06-24 13:37:03.722277
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')


# Generated at 2022-06-24 13:37:08.710653
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE('TVPlayIE') == TVPlayIE('TVPlayIE')
    assert TVPlayIE('TVPlayIE') != TVPlayIE('GenericIE')
    assert TVPlayIE('TVPlayIE') == TVPlayIE('TVPlayIE') != TVPlayIE('GenericIE')

# Generated at 2022-06-24 13:37:19.900977
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:37:20.793886
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE

# Generated at 2022-06-24 13:37:22.045259
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().extractor_keywords == TVPlayIE._TESTS



# Generated at 2022-06-24 13:37:27.607700
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE("http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    assert ie.ie_key() == "TVPlay"
    assert ie.video_id == "409229"


# Generated at 2022-06-24 13:37:37.433671
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import YoutubeIE
    from . import RTL2IE
    assert not ViafreeIE.suitable('https://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    assert ViafreeIE.suitable(
        'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    viafree_ie = ViafreeIE('test', {})
    assert isinstance(viafree_ie._og_search_thumbnail('http://foo.bar/'), YoutubeIE)
    assert isinstance(viafree_ie._og_search_thumbnail('http://foo.bar/', default='rtl2'), RTL2IE)

# Generated at 2022-06-24 13:37:39.680423
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE()._call_api('http://www.skaties.lv/tv/')


# Generated at 2022-06-24 13:37:51.658342
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')
    assert TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert TVPlayHomeIE.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-24 13:38:03.033403
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Tests module constructor with:
        - valid url ending with id
        - invalid url containing id
        - none url
    """
    valid_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    invalid_url = 'https://tvplay.tv3.lt/aferistai-n-7/10047125/'
    none_url = None

    # check for valid url
    ie_tvplay = TVPlayHomeIE(valid_url)
    assert ie_tvplay is not None

    # check for invalid url
    try:
        TVPlayHomeIE(invalid_url)
    except ExtractorError:
        pass

    # check for none url

# Generated at 2022-06-24 13:38:04.933270
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print('Constructing TVPlayIE object')
    ie = TVPlayIE()
    print('Done')


# Generated at 2022-06-24 13:38:06.630693
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in TVPlayHomeIE._TESTS:
        TVPlayHomeIE(url)


# Generated at 2022-06-24 13:38:10.550445
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert isinstance(ie, TVPlayIE)


# Generated at 2022-06-24 13:38:18.076543
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    TVPlayIE.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') is True
    ViafreeIE.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869') is False
    ViafreeIE.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') is False

# Generated at 2022-06-24 13:38:23.754465
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert not ie.suitable('https://play.tv3.lt')
    assert not ie.suitable('http://tvplayhome.com/')



# Generated at 2022-06-24 13:38:25.283444
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == ViafreeIE._TESTS[0]['url']

# Generated at 2022-06-24 13:38:27.114347
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    assert isinstance(instance, TVPlayHomeIE)



# Generated at 2022-06-24 13:38:29.652537
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Test for constructor of class TVPlayIE.
    """
    tvplay_ie = TVPlayIE()
    tvplay_ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    print(tvplay_ie)


# Generated at 2022-06-24 13:38:30.793051
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable(TVPlayIE())

# Generated at 2022-06-24 13:38:32.446261
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert isinstance(ie, TVPlayIE)

# Generated at 2022-06-24 13:38:33.878407
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-24 13:38:39.444719
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_ = TVPlayHomeIE.__class__
    print(class_.__name__)
    test_class = TVPlayHomeIE('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    print(test_class)

# Generated at 2022-06-24 13:38:47.143106
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'mtg:418113'
    geo_country = 'lv'
    assert TVPlayIE._VALID_URL == TVPlayIE._TESTS[0]['url']
    assert TVPlayIE._match_id(TVPlayIE._TESTS[0]['url']) == TVPlayIE._TESTS[0]['info_dict']['id']
    assert TVPlayIE._match_id(url) == TVPlayIE._TESTS[0]['info_dict']['id']

# Generated at 2022-06-24 13:38:49.818548
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if not os.environ.get('CI'):
        return
    i = ViafreeIE()
    i._VALID_URL = ViafreeIE._VALID_URL
    assert i._VALID_URL is not None

# Generated at 2022-06-24 13:38:54.656861
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://play.mtgx.tv/videos/737409?autostart=true'
    assert isinstance(TVPlayIE.suitable(url), bool)
    assert isinstance(ViafreeIE.suitable(url), bool)
    assert TVPlayIE.suitable(url) ^ ViafreeIE.suitable(url)

    TVPlayIE.suitable(url) and test_TVPlayIE()
    ViafreeIE.suitable(url) and test_ViafreeIE()

# Generated at 2022-06-24 13:38:58.564576
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'
    assert ie._VALID_URL is not None
    assert ie._TESTS is not None
    assert ie.__doc__ is not None



# Generated at 2022-06-24 13:39:07.395444
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.IE_NAME == 'viafree'
    assert viafreeIE.IE_DESC == 'Viafree'
    assert viafreeIE._VALID_URL == 'https?://(?:www\.)?viafree\.(?:dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert viafreeIE._GEO_BYPASS == False
    assert viafreeIE._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert viafreeIE._TESTS[0]['info_dict']['series'] == 'Det beste vorspielet'