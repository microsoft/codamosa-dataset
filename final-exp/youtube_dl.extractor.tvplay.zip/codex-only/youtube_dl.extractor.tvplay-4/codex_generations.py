

# Generated at 2022-06-24 13:29:18.967481
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:29:28.745255
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:29:33.982712
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    video_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    mtg = TVPlayIE()
    assert mtg._download_json(
        'http://playapi.mtgx.tv/v3/videos/%s' % video_id,
        video_id, 'Downloading video JSON')['id'] == '418113'
    assert mtg.suitable(video_url)
    assert mtg.IE_NAME in mtg.ie_key()

# Generated at 2022-06-24 13:29:35.277438
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    for valid_url in TVPlayIE._TESTS:
        assert TVPlayIE._VALID_URL in valid_url['url']



# Generated at 2022-06-24 13:29:44.327121
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie._VALID_URL == 'http://(?:www\.|new\.|sport\.|tv6|tv8|tv10|tv3|tv6play|tv8play|tv10play|tv3play|viasat4play|tvplay|play\.tv3)(?:play\.nova|play|tv3|tv6|tv8|tv10|tv3play|tv6play|tv8play|tv10play|tv3play|viafree|viasat4play|skaties)\.lv(?:/parraides)?/(?:[^/]+/)+(?P<id>\d+)')

# Generated at 2022-06-24 13:29:50.250409
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    data = ie.get_information_extractor_data()
    assert data['_type'] == 'IE_DESC', 'TVPlayHomeIE must be IE_DESC.'
    assert data['id'] == 'tvplayhome', 'TVPlayHomeIE id must be "tvplayhome".'
    assert data['name'] == 'TVPlayHome', 'TVPlayHomeIE name must be "TVPlayHome".'

# Generated at 2022-06-24 13:29:53.274545
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Create an instance of class TVPlayHomeIE
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-24 13:29:54.246966
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()

# Generated at 2022-06-24 13:30:02.519136
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert(x.country == 'se')
    assert(x.program_id == 'husraddarna')
    assert(x.season_number is None)
    assert(x.episode_number is None)
    assert(x.section is None)
    assert(x.URL == 'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/programmer/livsstil/husraddarna')

# Generated at 2022-06-24 13:30:13.252801
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie.country == 'lt'
    assert ie.host is None
    assert ie.host_id is None
    assert ie.playlist_id is None
    assert ie.title is None

    ie = TVPlayHomeIE('https://play.tv3.lt/vinas-melo-labak-10280317')
    assert ie.country == 'lv'
    assert ie.host is None
    assert ie.host_id is None
    assert ie.playlist_id is None
    assert ie.title is None

    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:30:20.883478
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvi = TVPlayIE()
    assert isinstance(tvi, InfoExtractor)
    assert isinstance(tvi._VALID_URL, str)
    assert isinstance(tvi._TESTS, list)
    assert isinstance(tvi._downloader, YoutubeDL)
    assert isinstance(tvi.IE_NAME, str)
    assert isinstance(tvi.IE_DESC, str)
    assert tvi.ie_key() == 'TVPlay'
    assert tvi.description() == 'MTG services'
    assert len(tvi._WORKING) == 0
    assert hasattr(tvi, '_prepare_request')
    assert hasattr(tvi, '_real_extract')
    assert hasattr(tvi, '_real_initialize')

# Generated at 2022-06-24 13:30:23.503998
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    x = TVPlayHomeIE(ie)
    y = TVPlayHomeIE(ie)
    assert x != y



# Generated at 2022-06-24 13:30:26.870143
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for constructor of class ViafreeIE
    """
    with_mock = ViafreeIE(None, True)
    assert with_mock._GEO_BYPASS is True

    no_mock = ViafreeIE(None, False)
    assert no_mock._GEO_BYPASS is False



# Generated at 2022-06-24 13:30:28.735360
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info = TVPlayHomeIE()
    assert info._VALID_URL == TVPlayHomeIE._VALID_URL
    assert info._TESTS == TVPlayHomeIE._TESTS

# Generated at 2022-06-24 13:30:30.473753
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # All TVPlayHomeIE code is in extract method, thus there is no need to test constructor
    TVPlayHomeIE()

# Generated at 2022-06-24 13:30:39.230612
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v = ViafreeIE()
    assert v.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert v.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert v.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:30:41.101824
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    assert IE.get_url_re() is not None

# Generated at 2022-06-24 13:30:41.851617
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assertViafreeIE(viafreeIE)

# Generated at 2022-06-24 13:30:42.898434
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:30:49.302114
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # https://github.com/rg3/youtube-dl/issues/9898
    url = 'https://tvplay.skaties.lv/vinas-melo-labak-10280317/'
    tvplay_home_ie = TVPlayHomeIE(url)
    assert 'playlist' in tvplay_home_ie._download_webpage(url, 'test', note='Playlist')

# Generated at 2022-06-24 13:30:53.482469
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_obj = TVPlayIE()
    assert test_obj.ie_key() == 'TVPlayIE'
    assert test_obj.ie_desc() == 'MTG services'


# Unit tests for module functions

# Generated at 2022-06-24 13:30:54.544691
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info = TVPlayHomeIE()
    assert 'TVPlayHomeIE' == info.__class__.__name__

# Generated at 2022-06-24 13:31:03.061562
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    ie.IE_NAME = 'TVplayIE'
    ie.IE_DESC = 'TVplay'
    ie.IE_VALID_URL = r'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'

# Generated at 2022-06-24 13:31:03.899385
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-24 13:31:14.640220
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    if (not hasattr(TVPlayIE, '_WORKING') or not
            TVPlayIE._WORKING or
            TVPlayIE.IE_NAME not in minsrvr):
      return
    ie = TVPlayIE
    video_id = '21873'
    url = 'http://www.tv8play.se/program/antikjakten/' + video_id + '?autostart=true'

# Generated at 2022-06-24 13:31:20.402226
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('TVPlayIE', 'mtg', None).extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE('TVPlayIE', 'mtg', None).extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')



# Generated at 2022-06-24 13:31:25.437866
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    if not ie._TESTS:
        return ie
    for test in ie._TESTS:
        assert test == ie._real_extract(test['url'])

# Generated at 2022-06-24 13:31:28.934412
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for country in ['no', 'dk', 'se']:
        ie = ViafreeIE({'countries': [country]})
        assert isinstance(ie, ViafreeIE)


# Generated at 2022-06-24 13:31:34.298417
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._VALID_URL == 'test_TVPlayIE'
    ie._TESTS == 'test_TVPlayIE'
    ie.IE_NAME == 'test_TVPlayIE'
    ie.IE_DESC == 'test_TVPlayIE'



# Generated at 2022-06-24 13:31:44.640966
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    
    # Test with website 1 (se)
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    test = ViafreeIE()
    assert test.suitable(url)
    
    # Test with website 2 (dk)
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    test = ViafreeIE()
    assert test.suitable(url)

    # Test with website 3 (no)
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    test = ViafreeIE()

# Generated at 2022-06-24 13:31:46.987516
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(RegexNotFoundError):
        ViafreeIE('http://www.viafree.com/program/livsstil/husraddarna/sasong-2/avsnitt-2', {})._real_extract({})

# Generated at 2022-06-24 13:31:49.794559
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')



# Generated at 2022-06-24 13:31:53.003993
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE('url', {}, 'md5')
    assert viafree_ie.geo_verification_headers() is None
    assert viafree_ie.suitable('url')



# Generated at 2022-06-24 13:32:04.225273
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:32:10.508392
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test that ViafreeIE cannot extract any url that is matched by TVPlayIE
    for url in TVPlayIE._TESTS:
        url = url.get('url')
        assert not ViafreeIE.suitable(url)

    # test that ViafreeIE can extract urls that are not matched by TVPlayIE

# Generated at 2022-06-24 13:32:16.491578
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'


# Generated at 2022-06-24 13:32:25.087935
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # This test ensures that TVPlayIE will not fail
    # when using unknown url, for example:
    # http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true
    # or
    # https://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true
    TVPlayIE().suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE().suitable('https://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')



# Generated at 2022-06-24 13:32:28.952506
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.IE_NAME
    ie.IE_DESC
    ie._VALID_URL
    ie._TESTS



# Generated at 2022-06-24 13:32:38.326875
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for constructor of class ViafreeIE
    """
    default_width = 0
    default_height = 0
    #test url
    url = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    #test data

# Generated at 2022-06-24 13:32:49.768802
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869') == False
    assert ViafreeIE.suitable('http://play.mtgx.tv/program/husraddarna/395385?autostart=true') == False
    assert ViafreeIE.suitable('http://www.mtgx.tv/husraddarna/395385') == True
    assert ViafreeIE.suitable('http://play.tv3play.se/program/det-beste-vorspielet/sesong-2/episode-1') == False
    assert ViafreeIE.suitable('http://www.tv3play.se/program/det-beste-vorspielet/sesong-2/episode-1') == True

# Generated at 2022-06-24 13:32:56.803612
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    _tvplay_ie = TVPlayIE()
    print('tvplay_ie', tvplay_ie)
    print('tvplay_ie._VALID_URL', tvplay_ie._VALID_URL)
    print('tvplay_ie.IE_NAME', tvplay_ie.IE_NAME)
    print('tvplay_ie.IE_DESC', tvplay_ie.IE_DESC)
    assert tvplay_ie.IE_NAME == "mtg"
    assert tvplay_ie.IE_DESC == "MTG services"


# Generated at 2022-06-24 13:33:08.056218
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()

    # Several consecutive tests to test different functions in the class

# Generated at 2022-06-24 13:33:16.575029
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('www.tv3play.lv', '3play:10627059', 'http://www.tv3play.lv/gramata-ne-zinot-kur-beigsies-10627059/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>[^/?#&]+)'
    assert ie._GEO_BYPASS == False
    assert ie._GEO_COUNTRIES == []
    assert ie._downloader is not None
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == True

# Generated at 2022-06-24 13:33:20.265246
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """ Unit tests for constructor of class ViafreeIE """
    print("Testing class ViafreeIE")
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    class_instance = ViafreeIE(downloader=None)
    class_instance.suitable(url)
    class_instance.extract(url)
    print("Successfully passed test")

test_ViafreeIE()

# Generated at 2022-06-24 13:33:31.263611
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from . import _test_generic_info_extractor

# Generated at 2022-06-24 13:33:32.197253
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie 


# Generated at 2022-06-24 13:33:33.699373
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie._download_json(
                'https://tvplay.skaties.lv/sb/public/asset/10280317', '10280317')


# Generated at 2022-06-24 13:33:43.095423
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with warnings.catch_warnings():
        warnings.simplefilter('ignore') # XXX: remove when __init__ does not issue a warning anymore
        ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:33:46.890141
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://play.tv3.lt/aferistai-10047125");
    assert ie._VALID_URL
    assert ie._TESTS


# Generated at 2022-06-24 13:33:49.928885
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    print(ViafreeIE._build_url_result('dsadas123213'))
    print(ViafreeIE._build_url_result('dsadas123213', 'sadsad'))

# Generated at 2022-06-24 13:33:51.118566
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global TVPlayIE
    TVPlayIE()

# Generated at 2022-06-24 13:33:54.181525
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('test', 'https://tvplay.skaties.lv/parraides/vinas-melo-labak/418113/?autostart=true')

# Generated at 2022-06-24 13:33:56.078396
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError, match=r'expects an url'):
        ViafreeIE()

# Generated at 2022-06-24 13:34:05.550088
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # this test should be run with a certain locale (preferably sv_SE)
    import locale
    locale.setlocale(locale.LC_ALL, '')
    ie = ViafreeIE()

    assert ie.extract('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.extract('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')



# Generated at 2022-06-24 13:34:08.695521
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.country == 'LT'

# Generated at 2022-06-24 13:34:12.099182
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    print(ie.__repr__()) # Use for debugging purposes
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, '_TESTS')
    assert hasattr(ie, '_real_extract')

# Generated at 2022-06-24 13:34:16.127602
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .util import dumploader
    from .extractor import GenericIE

    m = GenericIE._extractors[TVPlayHomeIE.ie_key()]
    assert isinstance(m, TVPlayHomeIE)

    # Check if extractors are discovered automatically
    dumploader(TVPlayHomeIE._downloader, 'tvplayhome')

# Generated at 2022-06-24 13:34:18.366361
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()._VALID_URL.search('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')



# Generated at 2022-06-24 13:34:23.884307
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None, 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    ViafreeIEInstance = isinstance(ie, ViafreeIE)
    assert ViafreeIEInstance == True, "Constructor of class ViafreeIE fails to return a object of ViafreeIE class"


# Generated at 2022-06-24 13:34:35.009455
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:39.851595
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test for correct instantiation
    print("Testing TVPlayIE constructor...")
    print("Testing instantiation of TVPlayIE...")
    ie = TVPlayIE()

    assert ie is not None
    print("Successfully instantiated TVPlayIE")

    print("Successfully tested")



# Generated at 2022-06-24 13:34:44.001847
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.NAME == 'Viafree'
    assert viafree.IE_NAME == 'viafree'
    assert viafree.IE_DESC == 'Viafree, TV4 Play and Viaplay'

# Generated at 2022-06-24 13:34:44.715820
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:34:49.357422
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    res = ie._download_json('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert res

# Generated at 2022-06-24 13:34:52.057400
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class TestViafreeIE(ViafreeIE):
        @property
        def IE_NAME(self):
            return 'test_viafree'
    TestViafreeIE('test_viafree')

# Generated at 2022-06-24 13:34:57.866434
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    if sys.version_info >= (3, 8):
        assert '_VALID_URL = r\'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)\'' == ie._VALID_URL
        assert '_VALID_URL = re.compile(r"<![CDATA[!>)(?P<id>\\d+)(?<!\\w)<!]]>")' == ie._API_URL



# Generated at 2022-06-24 13:35:01.598950
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Unit test forconstructor of class TVPlayIE
    # Constructor of TVPlayIE must work for all URLs.
    for url in TVPlayIE._TESTS:
        instance = TVPlayIE()
        instance._match_id(url["url"])

# Generated at 2022-06-24 13:35:11.487136
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:35:22.849975
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE
    assert ie.__name__ == "mtg"
    assert ie.IE_NAME == "mtg"
    assert ie.IE_DESC == "MTG services"

# Generated at 2022-06-24 13:35:28.017690
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    obj = TVPlayHomeIE('TVPlayHome', ie.ie_key())
    obj.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie == obj


# Generated at 2022-06-24 13:35:30.788945
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE("http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869")

# Generated at 2022-06-24 13:35:32.803295
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Basic test to check creation of class TVPlayHomeIE
    """
    TVPlayHomeIE()

# Generated at 2022-06-24 13:35:34.672168
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()._VALID_URL == TVPlayHomeIE._VALID_URL


# Generated at 2022-06-24 13:35:37.129807
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')

# Generated at 2022-06-24 13:35:42.121032
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('Viasat4playDN:764300')
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._VALID_URL_TEMPLATE == 'https://viafree.%s/%s'

# Generated at 2022-06-24 13:35:48.168816
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('dk')
    assert ie.GEO_COUNTRIES == ['dk']
    ie = ViafreeIE('no')
    assert ie.GEO_COUNTRIES == ['no']
    ie = ViafreeIE('se')
    assert ie.GEO_COUNTRIES == ['se']
    instance = ViafreeIE()
    assert instance.GEO_COUNTRIES == None

# Generated at 2022-06-24 13:35:58.954615
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:02.503806
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_common import TestUnit

    class TestViafreeIE(TestUnit):
        def __init__(self, *args, **kwargs):
            TestUnit.__init__(self, *args, id='ViafreeIE', **kwargs)

    TestViafreeIE()

# Generated at 2022-06-24 13:36:12.077532
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Dummy object for the tests.
    site = {
        '_VALID_URL': ViafreeIE.VALID_URL,
        'IE_NAME': 'viafree',
        '_GEO_COUNTRIES': ViafreeIE.GEO_COUNTRIES,
        '_TESTS': ViafreeIE.TESTS
    }
    # Create a new object from the constructor.
    obj = type('testViafree', (ViafreeIE,), site)

    assert obj.suitable(obj._VALID_URL) is True
    assert obj.suitable(obj._VALID_URL) is True

    obj._initialize_geo_bypass(obj._GEO_COUNTRIES)
    obj._real_initialize()


# Generated at 2022-06-24 13:36:21.616720
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv = TVPlayIE()
    assert tv.IE_NAME == 'mtg'
    assert tv.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:23.451356
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('www.viafree.no', 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:36:30.138706
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafreeIE = ViafreeIE(url=url)
    assert viafreeIE._VALID_URL == 'https?://(?:www\\.)?viafree\\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert viafreeIE.suitable(url) == False

# Generated at 2022-06-24 13:36:37.328721
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'tvplay:home'
    entry = ie._build_video_result('366367', 'Aferistai. Kalėdinė pasaka.', 364, 1394209658)

# Generated at 2022-06-24 13:36:39.408961
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()
    TVPlayIE()

# Generated at 2022-06-24 13:36:45.412040
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")._VALID_URL == \
        "https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)"

# Generated at 2022-06-24 13:36:55.387606
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-24 13:36:57.127200
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE("https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true")


# Generated at 2022-06-24 13:36:58.719254
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_downloader import downloader_test
    downloader_test(TVPlayHomeIE, [])

# Generated at 2022-06-24 13:37:04.744514
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    extractor = ViafreeIE(suitable=ViafreeIE.suitable)
    extractor.suitable = ViafreeIE.suitable
    assert extractor.suitable(test_url)
    assert extractor._VALID_URL == extractor.VALID_URL
    assert extractor._TESTS == extractor.TESTS
    assert extractor._GEO_BYPASS == extractor.GEO_BYPASS
    assert extractor._real_extract == extractor.real_extract

# Generated at 2022-06-24 13:37:07.476124
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie._GEO_BYPASS is False

# Generated at 2022-06-24 13:37:08.686327
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Unit test for constructor of class ViafreeIE
    """
    # Test correct instantiation of an object
    ViafreeIE()

# Constructor test for class TVPlayIE

# Generated at 2022-06-24 13:37:19.900151
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE(): # pylint: disable=invalid-name
    tv = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert 'TVPlayHomeIE' == tv[0]
    assert 'Vināšu melo labāk - S01E08' == tv[1]
    tv = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert 'TVPlayHomeIE' == tv[0]
    assert 'Aferistai' == tv[1]
    tv = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert 'TVPlayHomeIE' == tv[0]

# Generated at 2022-06-24 13:37:26.423844
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_urls = [
        'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
        'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
    ]

    for url in test_urls:
        finder = ViafreeIE()
        assert finder.suitable(url)

# Generated at 2022-06-24 13:37:34.606274
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:37:43.690881
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # assert that the regex complies
    assert bool(re.match(ie._VALID_URL, 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert bool(re.match(ie._VALID_URL, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    assert bool(re.match(ie._VALID_URL, 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'))

# Generated at 2022-06-24 13:37:50.223623
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:37:59.001436
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE('https://play.tv3.ee')
    except AssertionError as e:
        assert e.args == ('The video id must be specified!',)
    try:
        TVPlayHomeIE('https://play.tv3.ee/123')
    except AssertionError as e:
        assert e.args == ('The video id must be specified!',)
    try:
        TVPlayHomeIE('https://play.tv3.ee/123/456')
    except AssertionError as e:
        assert e.args == ('The id must be a number!',)



# Generated at 2022-06-24 13:38:01.928288
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    home_ie = TVPlayHomeIE(ie)



# Generated at 2022-06-24 13:38:10.619251
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)

# Generated at 2022-06-24 13:38:11.671542
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtgIE = TVPlayIE()


# Generated at 2022-06-24 13:38:22.582127
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == False
    assert ie.suitable('http://www.viafree.se/program/husraddarna/395385?autostart=true') == True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true') == False
    assert ie.suitable('https://www.viafree.se/husraddarna/395385/?autostart=true') == True
    assert ie.suitable('http://www.viafree.no/husraddarna/395385/?autostart=true') == True

# Generated at 2022-06-24 13:38:28.814403
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    video_id = '676869'
    content = download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/program/underhallning/i-like-radio-live/sasong-1/676869')
    program = content['_embedded']['viafreeBlocks'][0]['_embedded']['program']
    guid = program['guid']
    meta = content['meta']
    title = meta['title']


# Generated at 2022-06-24 13:38:31.661444
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        TVPlayHomeIE()
    except ValueError as e:
        assert 'Neither _VALID_URL nor _API_BASE set in class ' in str(e)


# Generated at 2022-06-24 13:38:38.057161
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeie = ViafreeIE()
    assert False == viafreeie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert True == viafreeie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:38:47.741975
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Input URL = https://www.tv3play.se/program/husraddarna/395385?autostart=true
    # We can use below ID to extract video from a webpage
    #   videoId: "395385"
    arg_url = "https://www.tv3play.se/program/husraddarna/395385?autostart=true"
    arg_video_id = "395385"


# Generated at 2022-06-24 13:38:55.476773
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE, TVPlayIE
    from .tvplay import TVPlayBaseIE
    from .common import InfoExtractor
    assert ViafreeIE.IE_DESC == 'Viafree and TV3 play'
    assert ViafreeIE.geo_verification_headers()
    assert type(ViafreeIE.ALLOWED_IE_COUNT) == type(1)
    assert type(ViafreeIE.ALLOWED_IE_NAMES) == type([])
    assert type(ViafreeIE.IE_NAME) == type('')
    assert ViafreeIE.ie_key() == ViafreeIE.IE_NAME
    assert ViafreeIE.ie_key() == 'ViafreeIE'
    assert ViafreeIE.suitable('')

# Generated at 2022-06-24 13:39:04.317457
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for normal use.
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    e = ViafreeIE(url)
    assert e._VALID_URL == 'https?://(?:www\.)?viafree\.(?P<country>dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:39:07.937063
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    # ViafreeIE(_VALID_URL, ViafreeIE.ie_key(), 'no')._real_extract(url)
    ViafreeIE._real_extract(ViafreeIE,'',url)

