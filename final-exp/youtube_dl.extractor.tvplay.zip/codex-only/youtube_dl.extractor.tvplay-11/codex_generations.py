

# Generated at 2022-06-24 13:29:10.741389
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    '''
    This function tests the TVPlayIE constructor.
    '''
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    ie = TVPlayIE(url)
    assert ie.url == url

# Generated at 2022-06-24 13:29:13.516900
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    u = 'mtg:238551'
    r = re.compile(t._VALID_URL)
    assert r.match(u) is not None

# Generated at 2022-06-24 13:29:15.890242
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # tests that creator doesn't need to be called
    assert hasattr(ViafreeIE, '_VALID_URL')



# Generated at 2022-06-24 13:29:26.959178
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:29:32.082240
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS
    assert ie._extract_m3u8_formats == TVPlayHomeIE._extract_m3u8_formats
    assert ie._real_extract == TVPlayHomeIE._real_extract
    assert ie._match_id == TVPlayHomeIE._match_id
    assert ie.geo_verification_headers == TVPlayHomeIE.geo_verification_headers
    assert ie.suitable == TVPlayHomeIE.suitable
    assert ie.extract_from_url == TVPlayHomeIE.extract_from_url
    assert ie

# Generated at 2022-06-24 13:29:40.324915
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()

# Generated at 2022-06-24 13:29:41.760516
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # FIXME: implement this unit test for constructor of class TVPlayIE
    pass


# Generated at 2022-06-24 13:29:48.515447
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(url)
    assert ie._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie._TESTS[0]['info_dict']['id'] == '757786'

# Generated at 2022-06-24 13:29:50.767081
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .. import viafree
    viafree_ie = viafree.ViafreeIE()
    assert ViafreeIE.suitable(viafree_ie._VALID_URL)



# Generated at 2022-06-24 13:29:54.775044
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test class TVPlayHomeIE.
    """
    test_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    TVPlayHomeIE(test_url, {})


# Generated at 2022-06-24 13:29:56.977865
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    ViafreeIE("mtg:757786")


# Generated at 2022-06-24 13:30:03.208263
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.ie_name() == 'TVPlayHome'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:30:07.144756
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info_extractor = ViafreeIE()
    assert info_extractor.IE_NAME == 'viafree'
    assert info_extractor.geo_verification_headers() == {}


# Generated at 2022-06-24 13:30:14.136724
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    e = TVPlayIE("379890")
    print(e)
    assert type(e) == TVPlayIE
    assert e.IE_NAME == 'mtg'
    assert e.IE_DESC == 'MTG services'
    assert e._VALID_URL == "(?x)mtg:379890"
    assert e._TESTS == []
    assert e._downloader.params == {'usenetrc': True, 'username': '', 'password': ''}
    assert e._match_id("mtg:379890") == '379890'

# Generated at 2022-06-24 13:30:20.248725
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie.name == 'Viafree'
    assert ie.geo_countries == ['NO', 'SE']
    assert ie.SUCCESS == 0
    assert ie.FAILED == 1
    assert ie.__name__ == 'ViafreeIE'
    assert ie.info_dict is None
    assert ie.params is None
    assert ie.url is None
    assert ie.http is None
    assert ie.initialize() is None
    assert ie.get_host_and_id is None
    assert ie.SUCCESS == 0
    assert ie.FAILED == 1


# Generated at 2022-06-24 13:30:20.977491
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert True


# Generated at 2022-06-24 13:30:22.994698
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tph = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert tph.url.startswith('https://tvplay.')

# Generated at 2022-06-24 13:30:30.473149
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('MTG')

# Generated at 2022-06-24 13:30:42.614143
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    # Test for __init__ method of class TVPlayIE
    assert ie.ie_key() == 'mtg'
    assert ie.ie_name() == 'mtg'
    assert ie.ie_desc() == 'MTG services'

# Generated at 2022-06-24 13:30:46.899852
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie is not None
    assert ie._TESTS.__len__() == 1

# Generated at 2022-06-24 13:30:57.474894
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # base url based on asset
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assetId = '366367'
    tvplay_home_ie = TVPlayHomeIE(url)
    tvplay_home_ie.suitable(url)
    assert tvplay_home_ie._match_id(url) == assetId
    # base url based on assetId
    url = 'https://tvplay.tv3.lt/' + assetId
    tvplay_home_ie = TVPlayHomeIE(url)
    assert tvplay_home_ie._match_id(url) == assetId



# Generated at 2022-06-24 13:31:09.642898
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.extractor.ie_key() == 'TVPlay'
    assert ie.thumbnail == 're:^https?://.*\.jpg'
    assert ie.extractor._VALID_URL == TVPlayIE._VALID_URL
    assert ie.extractor._GEO_BYPASS == TVPlayIE._GEO_BYPASS
    assert ie.extractor.ie_key() == 'TVPlay'

# Generated at 2022-06-24 13:31:15.181927
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    parameter_list = [
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.lt/aferistai-10047125',
    ]
    for parameter_url in parameter_list:
        TVPlayHomeIE(parameter_url)

# Generated at 2022-06-24 13:31:26.228138
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

    instance = ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert type(instance) == bool
    assert instance == True

    instance = ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert type(instance) == bool
    assert instance == True

    instance = ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert type(instance) == bool
    assert instance == True

    instance = ie.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-24 13:31:29.286092
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.extractor.common import InfoExtractor
    ie = InfoExtractor([ViafreeIE.ie_key()])
    assert ie.extractor is ViafreeIE

# Generated at 2022-06-24 13:31:41.147481
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie._GEO_BYPASS == False
    ie = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.country == 'se'
    assert ie.path == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    assert ie._G

# Generated at 2022-06-24 13:31:42.565136
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie is not None

# Generated at 2022-06-24 13:31:49.989142
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if not hasattr(TVPlayHomeIE, '_WORKING'):
        return

    tvplay = TVPlayHomeIE()
    assert tvplay.ie_key() == 'TVPlayHome'
    assert tvplay.IE_NAME == 'TVPlayHome'
    assert tvplay.IE_DESC == 'TVPlay Home; TV3, LNT, TV6, Kanāls 2, TV8'
    assert tvplay._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert hasattr(tvplay, '_TESTS')
    assert hasattr(tvplay, '_GEO_COUNTRIES')
    assert tvplay._

# Generated at 2022-06-24 13:32:00.760047
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    def _assert_url_result(url, expected_video_id, expected_result):
        video_id = ie._match_id(url)
        assert video_id == expected_video_id
        assert 'autostart=true' not in url
        assert ie._is_valid_url(video_id) == expected_result
    _assert_url_result(
        'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true',
        '418113', True)
    _assert_url_result(
        'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true',
        '409229', True)
    _assert_

# Generated at 2022-06-24 13:32:12.833366
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    si = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert si._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:32:16.768840
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test to check the constructor of class ViafreeIE"""
    try:
        _ = ViafreeIE()
    except NameError:
        pytest.fail('Failed to create an instance of the ViafreeIE')


# Generated at 2022-06-24 13:32:18.499353
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)
    assert isinstance(ie._VALID_URL, compat_re_type)


# Generated at 2022-06-24 13:32:29.097493
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor of class TVPlayIE
    tvplayie = TVPlayIE()
    # Check _VALID_URL

# Generated at 2022-06-24 13:32:29.640907
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-24 13:32:35.961081
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    obj = TVPlayIE()
    test_key = lambda key: obj.suitable(url)
    assert obj.ie_key() == 'TVPlay'
    assert test_key('tvplay')
    assert not test_key('tv')
    assert not test_key('youtube')
    assert not test_key('invalid')



# Generated at 2022-06-24 13:32:39.197314
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test the constructor of ViafreeIE
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:32:40.362847
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass



# Generated at 2022-06-24 13:32:45.398488
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    ie = TVPlayIE()
    expect = '418113'
    actual = ie._match_id(url)
    assert (actual == expect)


# Generated at 2022-06-24 13:32:52.033059
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    base_url = 'https://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay = TVPlayIE()
    tvplay_url = tvplay._match_id(base_url)
    assert tvplay_url == '418113'
    tvplay_geo = tvplay._search_regex(r'https?://[^/]+\.([a-z]{2})', base_url, 'geo country', default=None)
    assert tvplay_geo == 'lv'


# Generated at 2022-06-24 13:32:59.455597
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test _VALID_URL regex. regex must not miss valid urls
    invalid_urls = [
        'https://tvplay.tv3.lt/aferistai-10047125',
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354',
    ]
    ie = TVPlayHomeIE()
    for url in invalid_urls:
        assert ie._VALID_URL_TEST.match(url) is None


# Generated at 2022-06-24 13:33:09.997445
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv = TVPlayIE()
    assert tv.IE_NAME == 'mtg'
    assert tv.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:20.484954
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:33:25.447885
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """test constructor of class ViafreeIE."""
    IE = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert isinstance(IE, ViafreeIE)
    assert isinstance(IE, InfoExtractor)
    assert isinstance(IE, TVPlayIE)
    assert isinstance(IE, BaseIE)


# Generated at 2022-06-24 13:33:26.550234
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl.extractor.tvplay import TVPlayHomeIE
    TVPlayHomeIE('TVPlayHome', 'lv')

# Generated at 2022-06-24 13:33:34.709484
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE()
    assert IE.IE_NAME == 'TVPlayHome'
    assert IE.IE_DESC == 'TVPlay Home (Latvian, Lithuanian and Estonian) channels'
    assert IE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert len(IE._TESTS) == 7
    assert 'id' in IE._TESTS[0]

# Generated at 2022-06-24 13:33:39.959511
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ie.suitable('http://www.tv3play.no/programmer/hundenettet/350431')
    assert not ie.suitable('http://www.tv3play.se/program/husraddarna/395385')

# Generated at 2022-06-24 13:33:46.283791
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    testimport = 'playlist_from' in str(ViafreeIE)
    if testimport:
        ies = [TV3PlayIE(), TV6PlayIE(), TV8PlayIE(), TV3PlayLatviaIE(), TV3PlayLithuaniaIE(), TVPlayIE(),
               ViafreeIE]
        for ie in ies:
            assert ie.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183') == False
            assert ie.suitable('https://www.tv3play.lt/programa/kreditai-bedarbiams/234040') == True
            assert ie.suitable('http://viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') == True

# Generated at 2022-06-24 13:33:46.788275
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:33:50.200846
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:33:59.822245
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.url_result('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == """<class 'youtube_dl.extractor.tvplayhome.TVPlayHomeIE'>"""
    assert ie.url_result('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == """<class 'youtube_dl.extractor.tvplayhome.TVPlayHomeIE'>"""

# Generated at 2022-06-24 13:34:10.741980
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[0]['url'])
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[1]['url'])
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[2]['url'])
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[3]['url'])
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[4]['url'])
    assert_equal(TVPlayIE._VALID_URL, TVPlayIE._TESTS[5]['url'])


# Generated at 2022-06-24 13:34:12.859411
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Initialize
    ie = TVPlayIE()

    # Test
    assert TVPlayIE._VALID_URL in ie._working_internally()


# Generated at 2022-06-24 13:34:17.049366
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE({'url': 'https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'})
    assert ie.NAME == 'TVPlayHome'
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.SUCCESS.get('url') == 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'

# Generated at 2022-06-24 13:34:20.588559
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ydl = YoutubeDL(dict(forcejson=True))
    viafree = ViafreeIE(ydl)
    p = viafree.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert p is True


# Generated at 2022-06-24 13:34:32.540843
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # The following session key is used in multiple tests and should be checked
    # for validity.
    ie = TVPlayIE()
    ie._download_webpage('https://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true', video_id='418113')
    ie._download_webpage('https://tvplay.skaties.lv/parraides/tv3-zinas/760183', video_id='418113')
    ie._download_webpage('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true', video_id='418113')

# Generated at 2022-06-24 13:34:43.489283
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('Viafree', 'DK')._download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/dk/path/programmer/reality/paradise-hotel/saeson-7/episode-5',
        'programmer/reality/paradise-hotel/saeson-7/episode-5')
    ViafreeIE('Viafree', 'SE')._download_json(
        'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/program/livsstil/husraddarna/sasong-2/avsnitt-2',
        'program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:34:47.521760
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE('mtg')
    assert IE.ie_key() == 'mtg'
    assert IE.ie_name() == 'MTG services'
    assert IE.ie_desc() == 'MTG services'

# Testcase for testing _real_extract URL

# Generated at 2022-06-24 13:34:56.307818
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert(ie.IE_NAME == 'mtg')
    assert(ie.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:35:04.153755
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Unit test for constructor of class TVPlayHomeIE
    """
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    tv_home = TVPlayHomeIE(extract_flat)
    tv_home.suitable(url)
    tv_home.extract(url)
    expected = True
    returned = tv_home.suitable(url)
    assert expected == returned


# Generated at 2022-06-24 13:35:07.849304
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    test_url = "https://mtg:418113"

    with pytest.raises(RegexNotFoundError):
        TVPlayIE()._match_id(test_url)

    assert TVPlayIE()._match_id(test_url) == '418113'


# Generated at 2022-06-24 13:35:09.479368
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.warns(RemovedInPytest4Warning):
        ViafreeIE()


# Generated at 2022-06-24 13:35:20.845714
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # The constructor of ViafreeIE can be called when the class is imported,
    # so we need to catch the errors.
    class DummyEntry(object):
        def __init__(self, ie, **kwargs):
            self.ie = ie
            self.__dict__.update(kwargs)

    IE = ViafreeIE.ie_key()

    # Test 1: wrong page
    page = 'http://www.viafree.se'
    with expect_http_error(404):
        IE(DummyEntry(IE, url=page))

    # Test 2: normal page
    page = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    entry = DummyEntry(IE, url=page)
   

# Generated at 2022-06-24 13:35:28.122462
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie.IE_NAME == 'tvplayhome:url'
    assert ie.IE_DESC == 'TVPlay Home (tvplay.tv3.lt, skaties.lv and tv3.ee)'

# Generated at 2022-06-24 13:35:36.743183
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL.startswith('(?x)')
    assert 'play.tv3play.no/programmer/' in ie._VALID_URL
    assert len(ie._TESTS) == 22
    assert ie._TESTS[-1]['only_matching'] is True
    assert ie._TESTS[-1]['url'] == 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'

# Generated at 2022-06-24 13:35:38.277565
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie != None
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:35:40.400928
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Basic test for constructor of ViafreeIE
    """
    ie = ViafreeIE()
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-24 13:35:48.150941
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert ie.IE_NAME == 'Tv3PlayHome'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:35:49.208914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    runner = unittest.TextTestRunner()
    runner.run(unittest.makeSuite(ViafreeTestCase))

# Generated at 2022-06-24 13:35:49.626809
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:35:51.633206
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL
    assert ie._TESTS

# Generated at 2022-06-24 13:36:01.952652
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:36:11.018728
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:36:20.620315
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Test whether TVPlayIE needs to be updated for new video platforms
    """
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-24 13:36:21.150553
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:36:23.418372
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert TVPlayIE.suitable('mtg:418113')


# Generated at 2022-06-24 13:36:24.190677
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE("TVPlayIE")



# Generated at 2022-06-24 13:36:32.368438
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test if extractors are initialized correctly using regex
    # and parsing of HTML
    url = 'https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    path = '/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    content = {}
    content['_embedded'] = {}
    content['_embedded']['viafreeBlocks'] = []
    content['_embedded']['viafreeBlocks'].append({})
    content['_embedded']['viafreeBlocks'][0]['_embedded'] = {}
    content['_embedded']['viafreeBlocks'][0]['_embedded']['program'] = {}

# Generated at 2022-06-24 13:36:34.028257
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """ Test constructor method
    """
    # Constructor of TVPlayIE
    TVPlayIE()



# Generated at 2022-06-24 13:36:43.885119
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == r'(?x)^(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)$'

# Generated at 2022-06-24 13:36:49.307377
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Unfortunately, the constructor needs a whole fake URL, so we just make
    # one up
    viafree = ViafreeIE('http://www.viafree.se/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafree._VALID_URL == ViafreeIE._VALID_URL
    assert viafree.IE_NAME == ViafreeIE.IE_NAME
    assert viafree._TESTS == ViafreeIE._TESTS

# Generated at 2022-06-24 13:36:50.294589
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    check_corresponding_constructor(ViafreeIE)

# Generated at 2022-06-24 13:36:54.354867
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    test_title = 'Det beste vorspielet - Sesong 2 - Episode 1'
    scraped_content = ViafreeIE()._real_extract(test_url)

    # Check that title is correct
    assert(scraped_content['title'] == test_title)


# Generated at 2022-06-24 13:37:02.790608
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ViafreeIE.suitable('ViafreeIE:757786')
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385')
    tvi = ViafreeIE('test')
    assert tvi.IE_NAME == 'Viafree'
    assert tvi._VALID_URL == ie.ViafreeIE._VALID_URL
    assert tvi._TESTS == ie.ViafreeIE._TESTS
    assert tvi._GEO_BYPASS == ie.ViafreeIE._GEO_BYPASS

# Generated at 2022-06-24 13:37:14.431874
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .nova import NovaTVIE
    from .tv3play import TV3PlayIE
    from .televisioon import TelevisioonIE
    from .tv6 import TV6IE
    from .viasat import ViasatIE

    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert ie._VALID_URL == 'http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true'
    assert ie._downloader is None

    try:
        ie = TVPlayIE('faketest')
    except TypeError as e:
        assert str(e) == 'expected downloader'

    # check countries
    assert ie.geo

# Generated at 2022-06-24 13:37:20.159657
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay = TVPlayIE()
    assert tvplay.suitable(url)
    tvplay.extract(url)
    assert list(tvplay._TESTS) # list() is to check if we have any testcases in _TESTS

# Generated at 2022-06-24 13:37:21.732000
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Testing constructor directly:
    IE = TVPlayIE('lv')
    assert True



# Generated at 2022-06-24 13:37:31.764062
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    from functools import lru_cache
    from viafree import ViafreeIE
    with lru_cache():
        viafree_object = ViafreeIE()
    assert type(viafree_object) == ViafreeIE
    assert hasattr(viafree_object, '_VALID_URL')
    assert hasattr(viafree_object, '_TEST')
    assert hasattr(viafree_object, '_GEO_COUNTRIES')
    assert hasattr(viafree_object, '_GEO_BYPASS')
    assert hasattr(viafree_object, 'suitable')
    assert hasattr(viafree_object, '_real_extract')


# Generated at 2022-06-24 13:37:42.332706
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_cases = [
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
    ]

# Generated at 2022-06-24 13:37:54.298472
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tvplay.lv/name')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    ie_tv3 = TVPlayHomeIE('https://tv3play.tv3.ee/name')
    assert ie_tv3._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    ie_play = TVPlayHomeIE('https://play.tv3.ee/name')
   

# Generated at 2022-06-24 13:37:58.394973
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_class = TVPlayIE("TVPlayIE")
    assert test_class.IE_NAME == 'mtg', test_class.IE_NAME
    assert test_class.IE_DESC == 'MTG services', test_class.IE_DESC


# Generated at 2022-06-24 13:38:04.976361
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("www.viafree.se", "program", "reality", "sommaren-med-youtube-stjarnorna","sasong-1","avsnitt-1")
    assert ie.country == "se"
    assert ie.path == "programmer/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1"
    assert ie.country in ViafreeIE._VALID_URL



# Generated at 2022-06-24 13:38:15.969593
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .ttvn import TVNorgeIE
    from .tv2 import TV2NoIE
    from .mtg import TV3PlayIE, TV6PlayIE, TV8PlayIE, ViafreeCouchModeIE
    viafree_ie = ViafreeIE.suitable() # false
    viafree_ie = ViafreeIE.suitable('') # false
    viafree_ie = ViafreeIE.suitable(None) # false
    viafree_ie = ViafreeIE.suitable('http://www.tv3.lt/video/95616') # false, TV3PlayIE
    viafree_ie = ViafreeIE.suitable('http://www.tv3play.no/programmer/kodu-keset-linna/238551') # true, TV3PlayIE

# Generated at 2022-06-24 13:38:22.352271
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert not ViafreeIE.suitable('https://play.nova.bg/programi/zdravei-bulgariya/764300')
    assert ViafreeIE.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is True
    assert ViafreeIE.suitable('https://www.tv3play.se/program/husraddarna/395385') is True
    assert ViafreeIE.suitable('http://play.nova.bg/programi/zdravei-bulgariya/764300') is True
    assert ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183') is True

# Generated at 2022-06-24 13:38:26.249652
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert not TVPlayHomeIE.suitable('http://www.tv6play.se/anything')
    assert not TVPlayHomeIE.suitable('http://tvplay.skaties.lv/anything')
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317')


# Generated at 2022-06-24 13:38:38.594425
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for constructor of class ViafreeIE"""
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:38:41.625952
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Arrange
    tv_play_home_ie = TVPlayHomeIE()

    # Act
    url = "https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/"

    # Assert
    assert tv_play_home_ie._match_id(url) == "10044354"



# Generated at 2022-06-24 13:38:52.624525
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert re.match(ie._VALID_URL, 'https://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert re.match(ie._VALID_URL, 'https://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    assert re.match(ie._VALID_URL, 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-24 13:38:57.025763
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    # Check if find_constructor_by_url() uses correct regex for "mtg:" URL
    assert tvplay.IE_NAME in TVPlayIE.find_constructor_by_url('mtg:418113').IE_NAME


_METADATA_URL = 'https://tvplay.skaties.lv/api/metadata/video/%s'
_CAPTIONS_URL = 'https://tvplay.skaties.lv/api/captions/video/%s'



# Generated at 2022-06-24 13:39:06.044057
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Must raise RegexNotFoundError since this URL is only supported by TVPlayIE (disguised as ViafreeIE)
    with pytest.raises(RegexNotFoundError):
        ViafreeIE().suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    # Must raise RegexNotFoundError since this URL is only supported by ViaplayIE (disguised as TVPlayIE)
    with pytest.raises(RegexNotFoundError):
        ViafreeIE().suitable('https://www.viaplay.se/program/husraddarna/395385?autostart=true')
    # Must return False since this video is only supported by ViafreeIE