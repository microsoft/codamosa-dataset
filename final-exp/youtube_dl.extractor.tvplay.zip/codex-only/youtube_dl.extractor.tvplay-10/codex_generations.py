

# Generated at 2022-06-24 13:29:16.216851
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for TVPlayHomeIE in (TVPlayHomeIE(), TV3PlayHomeIE(), ViaplayIE(), TVPlayIE(), TV3PlayIE()):
        TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
        TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
        TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
        TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')
        TVPlayHomeIE.suitable

# Generated at 2022-06-24 13:29:18.301672
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import viacom
    ie = viacom.ViafreeIE('http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert isinstance(ie, viacom.ViafreeIE)

# Generated at 2022-06-24 13:29:20.976838
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE().to_screen('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')



# Generated at 2022-06-24 13:29:30.006432
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:29:33.580216
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:29:40.286465
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    # Assert that import of constructor of class TVPlayHomeIE returns
    # the right class.
    assert(type(TVPlayHomeIE()).__name__ == 'TVPlayHomeIE')
    # Assert that constructor of class TVPlayHomeIE is working properly.
    assert(type(TVPlayHomeIE()._real_extract(url)).__name__ == 'dict')

# Generated at 2022-06-24 13:29:42.751889
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == ViafreeIE._VALID_URL
    assert ie._TESTS == ViafreeIE._TESTS


# Generated at 2022-06-24 13:29:53.144733
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:29:57.300448
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tester = ViafreeIE()
    assert tester.suitable("mtg:418113") is False
    assert tester.suitable("http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869") is True


# Generated at 2022-06-24 13:30:04.076128
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info = TVPlayHomeIE._build_url_result(
        TVPlayHomeIE._VALID_URL,
        {'id': '10044354'},
        'Cool džäss & Garo',
        'Cool džäss & Garo. Mehhikosse')
    assert info['id'] == '10044354'
    assert info['title'] == 'Cool džäss & Garo. Mehhikosse'

# Generated at 2022-06-24 13:30:05.907374
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'

# Generated at 2022-06-24 13:30:15.486793
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:30:25.238315
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import TVPlayHomeIE as tvplayhomeie


# Generated at 2022-06-24 13:30:29.029036
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert isinstance(ie, TVPlayHomeIE)
    ie2 = TVPlayHomeIE('https://play.tv3.lv/vinas-melo-labak-10280317')
    assert isinstance(ie2, TVPlayHomeIE)

# Generated at 2022-06-24 13:30:31.824199
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == "mtg"
    assert TVPlayIE().IE_DESC == "MTG services"



# Generated at 2022-06-24 13:30:32.882471
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE("TVPlayIE")

# Generated at 2022-06-24 13:30:33.568483
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:30:34.666235
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE({})
    instance.suitable(None)
    instance.extract(None)

# Generated at 2022-06-24 13:30:45.433532
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test video without feed
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    # Constructor of class ViafreeIE should raise an error
    # if no geo bypassing is set up
    with pytest.raises(ExtractorError) as e:
        ViafreeIE()._real_extract(url)
    assert e.value.args[0] == 'Only works in Denmark, Norway, Sweden.'
    # If at least one geo bypassing is set up constructor of class ViafreeIE
    # should not raise an error
    ViafreeIE._GEO_BYPASS = True
    ViafreeIE()._real_extract(url)

# Generated at 2022-06-24 13:30:57.809012
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .common import FakeYDL
    from .test_utils import Args, exec_test

    def generic_test(url, expected_id, expected_title, expected_series=None,
                     expected_season=None, expected_episode=None,
                     expected_season_number=None, expected_episode_number=None):
        ie = TVPlayHomeIE(Args({}))
        # Create a fake downloader
        downloader = FakeYDL({
            'info_dict': {
                'id': expected_id,
                'title': expected_title,
                'series': expected_series,
                'season': expected_season,
                'episode': expected_episode,
                'season_number': expected_season_number,
                'episode_number': expected_episode_number,
            }
        })
        # Extract info
       

# Generated at 2022-06-24 13:31:08.298658
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.ie_key() == 'TVPlayHome'
    assert TVPlayHomeIE.ie_key(
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == 'TVPlayHome'
    assert TVPlayHomeIE.ie_key(
        'https://tvplay.tv3.lv/aferistai-n-7/aferistai-10047125/') == 'TVPlayHome'
    assert TVPlayHomeIE.ie_key(
        'https://tvplay.tv3.ee/aferistai-n-7/aferistai-10047125/') == 'TVPlayHome'

# Generated at 2022-06-24 13:31:14.014791
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS
    assert ie._GEO_COUNTRIES == TVPlayIE._GEO_COUNTRIES
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC

# Generated at 2022-06-24 13:31:24.626349
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    params = {
        'url': 'http://www.tv3play.se/program/husraddarna/395385?autostart=true',
        'info_dict': {
            'id': '395385',
            'ext': 'mp4',
            'title': 'Husräddarna S02E07',
            'description': 'md5:f210c6c89f42d4fc39faa551be813777',
            'duration': 2574,
            'timestamp': 1400596321,
            'upload_date': '20140520',
        },
        'params': {
            'skip_download': True,
        }
    }
    obj = TVPlayIE(**params)
    return obj.get_info(**params)



# Generated at 2022-06-24 13:31:36.364983
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = ViafreeIE

# Generated at 2022-06-24 13:31:41.199890
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    text = 'mtg:418113'
    tvplay_ie = TVPlayIE()
    tvplay_ie._VALID_URL = re.compile(tvplay_ie._VALID_URL)
    match = tvplay_ie._VALID_URL.match(text)
    assert match is not None



# Generated at 2022-06-24 13:31:43.808478
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-24 13:31:47.984874
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie_test = ViafreeIE()
    assert ie_test.suitable("https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5") == True
    assert ie_test.suitable("http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true") == False


# Generated at 2022-06-24 13:31:58.587821
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    ViafreeIE = ViafreeIE.ViafreeIE(TVPlayIE)

    # Testing for no overrides
    assert ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183') is False
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') is True

    # Testing for overrides
    ViafreeIE = ViafreeIE.ViafreeIE(ViafreeIE)
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') is False

# Generated at 2022-06-24 13:32:00.448595
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-24 13:32:01.559513
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('418113')

# Generated at 2022-06-24 13:32:08.595585
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay = TVPlayHomeIE()
    assert tvplay._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert tvplay.IE_NAME == 'TVPlayHome'
    assert tvplay.__name__ == 'TVPlayHomeIE'

# Generated at 2022-06-24 13:32:16.773308
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # pylint: disable=maybe-no-member
    ie = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    # pylint: enable=maybe-no-member



# Generated at 2022-06-24 13:32:18.987552
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test contructor of class TVPlayHomeIE
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-24 13:32:20.659989
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:32:21.336598
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

# Generated at 2022-06-24 13:32:24.089222
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvp = TVPlayIE()
    tp = tvp._VALID_URL
    assert(len(tp) > 0)
    assert(isinstance(re.compile(tp), re.Pattern))

# Generated at 2022-06-24 13:32:28.274672
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import warnings
    TVPlayIE._WORKING = True
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        t = TVPlayIE()
    assert t._WORKING == True


# Generated at 2022-06-24 13:32:32.478377
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if not _is_running_on_travis():
        ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')



# Generated at 2022-06-24 13:32:40.065402
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert 'TVPlayIE' in globals()
    test_ie = TVPlayIE()
    assert test_ie.IE_NAME == 'mtg'
    assert test_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:32:44.344753
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie._GEO_BYPASS is False


# Generated at 2022-06-24 13:32:53.344599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def constructor(self):
        import re
        import time
        import json
        import calendar

        info_dict = {'id': '757786', 'ext': 'mp4', 'title': 'Det beste vorspielet - Sesong 2 - Episode 1', 'description': 'md5:b632cb848331404ccacd8cd03e83b4c3', 'series': 'Det beste vorspielet', 'season_number': 2, 'duration': 1116, 'timestamp': 1471200600, 'upload_date': '20160814'}
        path = "/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
        country = "no"

# Generated at 2022-06-24 13:33:04.759852
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import simulator
    tmp_dir = tempfile.mkdtemp()
    file_name = os.path.join(tmp_dir, '36')

# Generated at 2022-06-24 13:33:09.446644
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._GEO_BYPASS is False

# Generated at 2022-06-24 13:33:11.906806
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    site_id = 'mtg'
    TVPlayIE(TVPlayIE.ie_key(), site_id=site_id)


# Generated at 2022-06-24 13:33:16.823246
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in TVPlayHomeIE._TESTS:
        ie = TVPlayHomeIE(url)
        assert ie.suitable(url), 'suitable() element of invalid url %s' % url
        assert ie._VALID_URL == url, '_VALID_URL element of invalid url %s' % url
        assert ie._TESTS == url, '_TESTS element of invalid url %s' % url
        assert ie._real_extract(url)
        assert ie._real_extract(url)['id'] == ie._match_id(url), 'id element of invalid url %s' % url
        assert ie._real_extract(url)['ext'] == 'mp4', 'ext element of invalid url %s' % url

# Generated at 2022-06-24 13:33:18.433022
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE(): 
    # Test construction of class ViafreeIE without argument
    ViafreeIE(None)
    # Test construction of class ViafreeIE with empty argument
    ViafreeIE('')

# Generated at 2022-06-24 13:33:29.276015
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'DE']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'LT']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'EE']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'SE']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'NO']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'DK']})
    TVPlayIE()._initialize_geo_bypass({'countries': ['LV', 'BG']})
    TVPlayIE()._real_extract

# Generated at 2022-06-24 13:33:38.437036
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class TestTVPlayIE(TVPlayIE):
        pass

    t_IE = TestTVPlayIE
    t_IE.IE_NAME = 'tvplay'

# Generated at 2022-06-24 13:33:40.942992
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    construct_class(TVPlayHomeIE, 'TVPlayHomeIE', s_kwargs={'http_headers': 'fake headers'})

# Generated at 2022-06-24 13:33:46.856596
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_object = TVPlayHomeIE()
    assert class_object.IE_DESC == 'TVPlay Home'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert class_object.ie_key() == 'TVPlayHome'
    assert not hasattr(class_object, '_GEO_COUNTRIES')

# Generated at 2022-06-24 13:33:57.729099
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:34:09.610325
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:34:11.623314
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('TVPlayHomeIE')
    assert ie.ie_key() == 'TVPlayHome'

# Generated at 2022-06-24 13:34:16.633128
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        with pytest.raises(Exception):
            url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
            ViafreeIE._initialize_geo_bypass(ViafreeIE)
            ViafreeIE.suitable(url)
    finally:
        ViafreeIE.geo_bypass = None



# Generated at 2022-06-24 13:34:17.521031
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-24 13:34:29.085219
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:30.889994
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('TVPlayHome', 'tv3.lt')

# Generated at 2022-06-24 13:34:38.094902
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test some TV Play related services
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-24 13:34:42.181426
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:34:47.989335
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    e = TVPlayIE()
    x = e._extract_urls('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert x == ['http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true']
    x = e._extract_urls('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert x == ['http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true']

# Generated at 2022-06-24 13:34:56.650080
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:58.410564
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    test.suite()



# Generated at 2022-06-24 13:34:59.527531
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-24 13:35:09.928729
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:35:21.232389
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import re
    i = TVPlayIE()
    assert re.search(i._VALID_URL, 'https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert re.search(i._VALID_URL, 'http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert re.search(i._VALID_URL, 'http://www.viasat4play.no/programmer/budbringerne/21873?autostart=true')
    assert re.search(i._VALID_URL, 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-24 13:35:24.843890
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE(None)._VALID_URL == 'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'


# Generated at 2022-06-24 13:35:26.917089
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    tvplayhome = TVPlayHomeIE(None)

# Generated at 2022-06-24 13:35:32.447240
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert isinstance(ie, ViafreeIE)
    assert ie._VALID_URL.find('http://www.viafree.no/programmer') != -1

# Generated at 2022-06-24 13:35:35.424539
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    settings.TVPLAY_GEO_BYPASS = True
    ie = TVPlayHomeIE()
    assert ie.geo_verification_headers() != None
    settings.TVPLAY_GEO_BYPASS = False



# Generated at 2022-06-24 13:35:44.486377
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://tv3play.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert re.match(TVPlayHomeIE._VALID_URL, 'https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-24 13:35:52.917725
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test a valid URL
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL.match('https://tv3play.skaties.lv/vinas-melo-labak-10280317/'))

    # Test an invalid URL
    ie = TVPlayHomeIE()
    assert(not ie._VALID_URL.match('https://tv3play.skaties.lv/vinas-melo-labak-10280317/ppp'))

# Test for TVPlayHomeIE constructor
if __name__ == '__main__':
    test_TVPlayHomeIE()

# Generated at 2022-06-24 13:35:58.663423
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplayhomes'
    assert ie.IE_DESC == 'TVPlayHome'
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:36:02.621029
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''


# Generated at 2022-06-24 13:36:12.203742
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:36:18.934947
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'
    geo_country = 'no'
    video_id = '230898'
    series = 'Anna Anka søker assistent'
    episode_number = 8
    season = '1 sezonas'
    season_number = 1
    duration = 2656
    title = 'Anna Anka søker assistent - Ep. 8'
    description = 'md5:f80916bf5bbe1c5f760d127f8dd71474'
    timestamp = 1277720005
    upload_date = '20100628'

    assert_equal(TVPlayIE._valid_url(url), True)

# Generated at 2022-06-24 13:36:26.988033
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.IE_NAME == 'viafree'
    assert ie.IE_DESC == 'TV3 Play/Viaplay (only in Denmark, Norway and Sweden)'
    assert ie.VALID_URL
    assert ie.VALID_URL.match('mtg:418113')
    assert ie.VALID_URL.match('http://play.tv3.lt/programos/dviraecio-detektyvai/354269')
    assert ie.VALID_URL.match('http://www.tv3play.ee/sisu/kodu-keset-linna/238551')
    assert ie.VALID_URL.match('http://www.tv3play.se/program/husraddarna/395385')

# Generated at 2022-06-24 13:36:30.068296
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(UrlTemplateIE())
    assert ie.suitable(url) is False

# Unit tests for constructor of class ViafreeIE

# Generated at 2022-06-24 13:36:37.244056
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test constructor with a TVPlayHomeIE url (legal)
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplay_home_ie = TVPlayHomeIE(url)
    assert tvplay_home_ie.suitable(url) is True
    assert tvplay_home_ie.IE_NAME == 'tvplayhome'
    assert tvplay_home_ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert tvplay_home_ie.ie_key() == 'tvplayhome:366367'
    assert tvplay_home_ie

# Generated at 2022-06-24 13:36:40.144833
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj._VALID_URL is not None


# Generated at 2022-06-24 13:36:41.280636
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg', 'MTG services')

# Generated at 2022-06-24 13:36:43.061573
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    # TODO: Add unit tests
    #tvplay_ie.extract()

# Generated at 2022-06-24 13:36:45.105292
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_ie = TVPlayHomeIE()
    assert tvplay_home_ie



# Generated at 2022-06-24 13:36:47.731082
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://play.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.__class__ == TVPlayHomeIE


# Generated at 2022-06-24 13:36:57.721802
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.extractor.tvplay import TVPlayHomeIE
    from youtube_dl.extractor import GENERIC_IE_DESCRIPTIONS

    tvplayhome_ie = TVPlayHomeIE.ie_key()
    assert tvplayhome_ie in YoutubeDL.list_extractors()

    ie_desc = YoutubeDL.get_info_extractor(tvplayhome_ie).IE_DESC
    print('\n' + ie_desc)
    assert ie_desc == ('tvplay:home (' + GENERIC_IE_DESCRIPTIONS['tvplay:home'] + ')')

    ie_test_urls = ['https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/']


# Generated at 2022-06-24 13:36:59.258072
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check whether constructor of class ViafreeIE is working by calling it
    VidstitchIE().test()



# Generated at 2022-06-24 13:37:03.029724
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie._VALID_URL == 'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:37:07.312287
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert TVPlayHomeIE.suitable(ie._VALID_URL) is True
    assert TVPlayHomeIE.suitable('https://dummy_url.com/program/title/option/') is False

# Generated at 2022-06-24 13:37:10.276407
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert isinstance(
        TVPlayHomeIE.ie_keywords[-1], int) is False, \
        'TVPlayHomeIE found at wrong index'


# Generated at 2022-06-24 13:37:11.655674
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-24 13:37:14.067725
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-24 13:37:16.663805
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317/");


# Generated at 2022-06-24 13:37:20.760448
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()
    tvplay_ie.IE_DESC
    tvplay_ie._VALID_URL
    tvplay_ie._TESTS
    tvplay_ie.IE_NAME

if __name__ == '__main__':
    test_TVPlayIE()

# Generated at 2022-06-24 13:37:21.672078
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE()



# Generated at 2022-06-24 13:37:32.285112
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check if constructor without input prints a warning
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        ViafreeIE()
        assert len(w) == 1

        # Check if warning has message
        assert issubclass(w[-1].category, UserWarning)
        assert "without a country code" in str(w[-1].message)

    # Check if constructor with a country code does not print a warning
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        ViafreeIE(country='no')
        assert len(w) == 0

        # Check if constructor with invalid country code throws exception
        with pytest.raises(ValueError):
            ViafreeIE('no')

# Generated at 2022-06-24 13:37:42.634266
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    start_url = 'http://www.tv6play.se/program/husraddarna/395385?autostart=true'
    video_id =  '395385'
    geo_country = 'se'
    info_dict = {
        'id': video_id,
        'ext': 'mp4',
        'title': 'Husräddarna S02E07',
        'description': 'md5:f210c6c89f42d4fc39faa551be813777',
        'duration': 2574,
        'timestamp': 1400596321,
        'upload_date': '20140520',
    }

    video_url = (
        'http://playapi.mtgx.tv/v3/videos/stream/{0}'.format(video_id))
    streams_json

# Generated at 2022-06-24 13:37:54.553348
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE()
    assert obj._VALID_URL == 'https?://(?:www\\.)?viafree\\.(?:dk|no|se)/(?:program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:37:58.629262
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()
    ViafreeIE.suitable('https://play.viafree.se/program/hundraaringen-som-klev-ut-genom-fonstret-och-forsvann/avsnitt-2')


# Generated at 2022-06-24 13:38:04.842848
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .. import TVPlayIE

    # TVPlayIE should be constructed with the class name
    ie = TVPlayIE(TVPlayIE.IE_NAME)
    assert ie.ie_key() == TVPlayIE.IE_NAME

    # TVPlayIE should raise a RegexNotFoundError when given
    # an invalid URL
    with pytest.raises(RegexNotFoundError):
        ie.extract('http://domain.invalid/12345')



# Generated at 2022-06-24 13:38:06.546248
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()._VALID_URL == r'(?x)tvplay:\d+'


# Generated at 2022-06-24 13:38:15.656725
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE({})
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie.IE_NAME == TVPlayIE.IE_NAME
    assert ie.IE_DESC == TVPlayIE.IE_DESC
    assert ie.extract('http://tv6play.se/program/den-sista-dokusapan/266636?autostart=true') is not None
    assert ie._real_extract('http://tv6play.se/program/den-sista-dokusapan/266636?autostart=true') is not None

# Generated at 2022-06-24 13:38:16.749496
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractor = TVPlayHomeIE()

# Generated at 2022-06-24 13:38:20.631999
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317")
    assert ie.parameters == {'sku': ''}

# Generated at 2022-06-24 13:38:28.007214
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''
    assert ie._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie._TESTS[0]['info_dict']['duration'] == 1116
    assert ie._TESTS[0]['info_dict']['timestamp'] == 1471200600

# Generated at 2022-06-24 13:38:31.306904
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable(
        'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')



# Generated at 2022-06-24 13:38:42.787719
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    # Test regex pattern in extractor

# Generated at 2022-06-24 13:38:45.733524
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""
    tv = TVPlayHomeIE()
    assert isinstance(tv, TVPlayHomeIE)


# Generated at 2022-06-24 13:38:48.688973
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE(url)
    assert ie.extract() == TVPlayHomeIE._TESTS[0]



# Generated at 2022-06-24 13:38:56.221077
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL == TVPlayHomeIE._VALID_URL)
    assert(ie._TESTS == TVPlayHomeIE._TESTS)
    assert(ie._GEO_COUNTRIES == TVPlayHomeIE._GEO_COUNTRIES)
    assert(ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS)
    assert(ie._LOOKUP_URL == TVPlayHomeIE._LOOKUP_URL)
    assert(ie._geo_countries == TVPlayHomeIE._geo_countries)
    assert(ie._lookup_url == TVPlayHomeIE._lookup_url)
   

# Generated at 2022-06-24 13:39:08.193995
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    title = TVPlayIE._TESTS[0]['info_dict']['title']
    video_id = TVPlayIE._TESTS[0]['info_dict']['id']
    description = TVPlayIE._TESTS[0]['info_dict']['description']
    series = TVPlayIE._TESTS[0]['info_dict']['series']
    episode_number = TVPlayIE._TESTS[0]['info_dict']['episode_number']
    season_number = TVPlayIE._TESTS[0]['info_dict']['season_number']
    season = TVPlayIE._TESTS[0]['info_dict']['season']
    duration = TVPlayIE._TESTS[0]['info_dict']['duration']
    timestamp = TVPlay

# Generated at 2022-06-24 13:39:11.333214
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url= 'https://play.tv3.lt/aferistai-10047125'
    ie=TVPlayHomeIE()
    ie._real_initialize()
    if ie.suitable(url):
        ie._real_extract(url)
        return True
    else:
        print('wrong URL')
        return False
