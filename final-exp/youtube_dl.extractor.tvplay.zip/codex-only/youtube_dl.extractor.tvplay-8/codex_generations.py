

# Generated at 2022-06-24 13:29:19.269296
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert (TVPlayHomeIE()._get_info_extractor(
            'http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
        == TVPlayHomeIE._get_info_extractor('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
    assert (TVPlayHomeIE()._get_info_extractor(
            'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
        == TVPlayHomeIE._get_info_extractor('https://tv3play.skaties.lv/vinas-melo-labak-10280317'))

# Generated at 2022-06-24 13:29:21.895027
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE().suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')


# Generated at 2022-06-24 13:29:29.549026
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class Options:
        geo_bypass_country = 'SE'
        geo_bypass = True

    viafreeIE = ViafreeIE(Options())
    assert viafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert viafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')


# Generated at 2022-06-24 13:29:41.342980
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test parsing of constructor arguments
    assert (TVPlayHomeIE._VALID_URL ==
            'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')

    # Test initialization of instance
    tvplayhome_ie = TVPlayHomeIE()
    # Test extraction method using a real URL
    # result = tvplayhome_ie._real_extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # print(json.dumps(result, sort_keys=True, indent=4, separators=(',', ': ')))

    # Test extraction of URL without '/' at end
    # result = tv

# Generated at 2022-06-24 13:29:44.234838
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    with pytest.raises(ExtractorError):
        ie._real_extract(TVPlayHomeIE._TESTS[0]['url'])

# Generated at 2022-06-24 13:29:54.339799
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert TVPlayHomeIE._TESTS[0]['url'] == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert TVPlayHomeIE._TESTS[0]['info_dict']['id'] == '366367'
    assert TVPlayHomeIE._TESTS[0]['info_dict']['ext'] == 'mp4'
    assert TVPlayHomeIE._TESTS[0]['info_dict']['title'] == 'Aferistai'


# Generated at 2022-06-24 13:29:58.600810
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplay = TVPlayHomeIE(url)
    assert tvplay.url == url
    assert tvplay.id == '366367'
    assert tvplay.video_id == '366367'

# Generated at 2022-06-24 13:30:10.204902
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:30:13.083406
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test creating the class and calling it.
    """
    # Create the unit test
    unittest.TestCase.__init__(ViafreeIE.__init__)

# Unit test

# Generated at 2022-06-24 13:30:16.948998
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.suitable)
    assert ie.suitable('http://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') is True


# Generated at 2022-06-24 13:30:20.533309
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''


# Generated at 2022-06-24 13:30:23.265058
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    checker = TVPlayIE()
    if len(str(checker))<10:
        assert False, '__str__ has not been implemented or is too short'
    if len(repr(checker))<10:
        assert False, '__repr__ has not been implemented or is too short'


# Generated at 2022-06-24 13:30:30.899162
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert IE._match_id(url) == '418113'
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert IE._match_id(url) == '409229'
    url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    assert IE._match_id(url) == '238551'
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'


# Generated at 2022-06-24 13:30:39.799046
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    result = ViafreeIE()
    assert result.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert result.suitable('http://www.viafree.se/program/benefits-of-to-give-up/sesong-1/episode-1') is False
    assert result.suitable('http://www.tvplayhome.com/program/benefits-of-to-give-up/sesong-1/episode-1') is False

# Generated at 2022-06-24 13:30:44.398421
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    tv = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert tv.IE_NAME == 'mtg'
    assert tv.IE_DESC == 'MTG services'
    assert ie.IE_DESC == 'MTG services'


# Generated at 2022-06-24 13:30:47.928314
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, {'info_dict': {'id': '366367'}})

    assert ie.country == 'lt'


# Generated at 2022-06-24 13:30:50.615866
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable(None)
    ViafreeIE.suitable(ViafreeIE._VALID_URL)


# Generated at 2022-06-24 13:30:51.939576
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(TVPlayIE())



# Generated at 2022-06-24 13:31:01.874335
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    c = ViafreeIE()
    c.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    if not c.suitable('http://play.nova.bg/programi/zdravei-bulgariya/624952?autostart=true'):
        raise Exception('test constructor of class ViafreeIE failed!')
    if c.suitable('http://play.nova.bg/programi/zdravei-bulgariya/624952?autostart=true'):
        raise Exception('test constructor of class ViafreeIE failed!')

# Generated at 2022-06-24 13:31:05.805130
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Use 'online' to manually launch the viafree extractor
    ViafreeIE()._test_extractors({'online': False})
    ViafreeIE()._test_extractors({'online': True})


# Generated at 2022-06-24 13:31:10.283848
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from ..utils import R_IDENTIFIER
    from .common import InfoExtractor
    from ..compat import unittest
    from ..compat import compat_urllib_request

    REQUEST_URL = 'https://www.test.com/test'

    class MockClass(TVPlayIE):
        def _download_json(self, url, video_id, note):
            raise Exception('Exception is Expected!')

        def _download_webpage(self, url, video_id, note, errnote, fatal):
            assert url == REQUEST_URL

        def _real_extract(self, url):
            return tvplay_class.get_fields(url)

        def _real_initialize(self):
            return tvplay_class.initialize()

    tvplay_class = MockClass({})
    tvplay_class

# Generated at 2022-06-24 13:31:21.299021
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:31:22.773118
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import doctest
    doctest.testmod(tvplayhome)

# Generated at 2022-06-24 13:31:25.278691
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # this test only checks if TVPlayIE can be instantiated
    # no error should be raised in the creation of object
    TVPlayIE()



# Generated at 2022-06-24 13:31:33.413807
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._GEO_BYPASS == TVPlayHomeIE._GEO_BYPASS
    assert ie._GEO_COUNTRIES == TVPlayHomeIE._GEO_COUNTRIES
    assert ie._FAILED_GEOCOUNTRIES == TVPlayHomeIE._FAILED_GEOCOUNTRIES



# Generated at 2022-06-24 13:31:38.250386
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')

# Generated at 2022-06-24 13:31:42.729352
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # sample 1
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viaIE = ViafreeIE(url)
    assert viaIE.country == 'no'
    assert viaIE.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

    # sample 2
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    viaIE = ViafreeIE(url)
    assert viaIE.country == 'se'

# Generated at 2022-06-24 13:31:49.605392
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-2')
    assert ie.suitable('http://www.viafree.no/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-24 13:31:50.893517
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-24 13:31:55.881991
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE
    attrs = (
        ('_VALID_URL', TVPlayHomeIE._VALID_URL),
        ('_TESTS', TVPlayHomeIE._TESTS))
    for attr, val in attrs:
        assert getattr(ie, attr) == val


# Generated at 2022-06-24 13:31:58.480735
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'



# Generated at 2022-06-24 13:31:59.675080
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:32:02.145950
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/');

# Generated at 2022-06-24 13:32:09.484425
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    assert viafree.country is None
    assert viafree.path == 'program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    assert viafree.url == 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2'
    viafree = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree.country == 'dk'

# Generated at 2022-06-24 13:32:10.424697
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:32:21.665044
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IEC = InfoExtractor.get_info_extractor_classes()
    ie = IEC['ViafreeIE'](InfoExtractor())
    assert ie.IE_NAME == 'Viafree'
    assert ie.ie_key() == 'Viafree'
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not ie.suitable('http://tvplay.skaties.lv/vinas-melo-labak/418113')
    assert ie._VALID_URL == 'https?://(?:www\\.)?viafree\\.(?:dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._GEO

# Generated at 2022-06-24 13:32:24.043839
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.tv3.lt/aferistai-10047125/')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-24 13:32:35.681377
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'
    tp_ie = TVPlayIE(url)
    assert (tp_ie.IE_NAME == 'mtg')
    assert (tp_ie.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:32:47.413174
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:32:57.710983
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.suitable('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert TVPlayIE.suitable('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert TVPlayIE.suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:33:00.120501
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE("tvplay.lv")._VALID_URL == TVPlayIE._VALID_URL

# Generated at 2022-06-24 13:33:10.469710
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    ViafreeIE('http://www.viafree.no/programmer/serier/det-beste-vorspielet/sesong-2/episode-1')
    # Different og:image URL schema
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')
    # With relatedClips
    ViafreeIE('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    # Danish page

# Generated at 2022-06-24 13:33:20.901092
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from youtube_dl import YoutubeDL
    from youtube_dl.downloader.http import HttpFD
    from youtube_dl.utils import HEADRequest

    import urllib2
    with YoutubeDL({}) as ydl:
        results = ydl.extract_info(
            'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true',
            download=False
        )
    assert_equals(results['id'], '418113')
    assert_equals(results['title'], u'K\u0101di ir \u012bri? - Vi\u0146as melo lab\xe4k')

# Generated at 2022-06-24 13:33:31.947585
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t._VALID_URL == r'(?x)()(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'

# Generated at 2022-06-24 13:33:36.804975
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import random
    from .extractors.common import InfoExtractor
    from .extractors.tvplay import TVPlayHomeIE
    from .compat import compat_str


# Generated at 2022-06-24 13:33:40.351926
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://play.tv3.lt/aferistai-10047125'
    ie = TVPlayHomeIE(url)
    assert ie.suitable(url)

# Generated at 2022-06-24 13:33:47.844734
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    extractor = TVPlayHomeIE('https://play.tvplay.tv/2/esarid-10045289/')
    assert extractor.IE_NAME == 'TVPlay'
    assert extractor._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>[0-9]+)'
    assert extractor._TEST == TVPlayHomeIE._TESTS[0]
    assert extractor._GEO_BYPASS == False
    assert extractor._GEO_COUNTRIES == ['LT', 'LV', 'EE']
    assert extractor._API_URL == 'https://playapi.mtgx.tv/v3/'
    assert extractor._BU

# Generated at 2022-06-24 13:33:58.492961
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ViafreeIE.suitable("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    assert ViafreeIE.suitable("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2")
    assert ViafreeIE.suitable("http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2")

# Generated at 2022-06-24 13:34:10.253532
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    video_id = '418113'
    video = 'http://playapi.mtgx.tv/v3/videos/stream/418113'
    assert ie._match_id(url) == video_id, 'Test for id failed'
    assert ie._search_regex(ie._VALID_URL, url, 'match') == url, 'Test for url failed'
    assert ie._real_extract(url)['id'] == video_id, 'Test for video id failed'

# Generated at 2022-06-24 13:34:15.891426
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:34:26.566434
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'

# Generated at 2022-06-24 13:34:32.068881
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5")
    assert not ViafreeIE.suitable("http://www.tv3play.se/program/husraddarna/395385?autostart=true")


# Generated at 2022-06-24 13:34:34.717842
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie.suitable() == True


# Generated at 2022-06-24 13:34:37.470972
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome = TVPlayHomeIE()
    assert tvplayhome is not None
    assert isinstance(tvplayhome, TVPlayHomeIE)

# Generated at 2022-06-24 13:34:48.672032
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_downloader import TestDownloader
    from .test_common import TestCommon
    from .test_extractor import TestExtractor

    TestDownloader.test_tvplay = lambda self: self.run_test_class(
        test_tvplay, functions=[create_test_class(TVPlayIE)], expected_count=87)
    TestDownloader.test_m3u8_formats = lambda self: self.run_test_class(
        test_m3u8_formats, functions=[create_test_class(TVPlayIE)], expected_count=87)
    TestDownloader.test_f4m_formats = lambda self: self.run_test_class(
        test_f4m_formats, functions=[create_test_class(TVPlayIE)], expected_count=87)

    test_

# Generated at 2022-06-24 13:34:51.388205
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:35:02.473748
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('', '')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-24 13:35:04.363051
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'tvplay'

# Generated at 2022-06-24 13:35:12.633931
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_urls = [
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',
    ]

    video_

# Generated at 2022-06-24 13:35:18.597148
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Tests ViafreeIE constructor
    url = 'https://www.viafree.dk/programmer/underholdning/paradise-hotel-2018/saeson-11/episode-1'
    country = 'dk'
    path = '/programmer/underholdning/paradise-hotel-2018/saeson-11/episode-1'
    ViafreeIE(country, path)

# Generated at 2022-06-24 13:35:30.067964
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Constructor test"""
    fld_instance = TVPlayIE()
    assert (fld_instance.IE_NAME == 'mtg')
    assert (fld_instance.IE_DESC == 'MTG services')

# Generated at 2022-06-24 13:35:32.545395
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for x in [1, 2]:
        try:
            ViafreeIE()
            break
        except:
            continue



# Generated at 2022-06-24 13:35:34.339281
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert_equal(type(ie), TVPlayHomeIE)


# Generated at 2022-06-24 13:35:36.411618
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    s = TVPlayHomeIE(None, None)
    assert s.geo_verification_headers() == {'User-Agent': 'ABC', 'X-Forwarded-For': '0.0.0.1'}



# Generated at 2022-06-24 13:35:37.021053
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert TVPlayIE == ViafreeIE



# Generated at 2022-06-24 13:35:42.007286
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('tvplay.lv', '418113', ['https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true'],
             'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true', u'Kādi ir īri? - Viņas melo labāk')

# Generated at 2022-06-24 13:35:43.422515
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:35:54.642140
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    from . import TVPlayIE
    from . import TV3PlayIE
    from . import ViafreeIE
    from . import NovaTVPlayIE
    from . import SkatiesTVPlayIE
    from . import Tv3PlayIE
    from . import SkatiesViasatIE
    from . import TV3PlayIE
    from . import TV3PlayLatviaIE
    from . import TV6PlayIE
    from . import TV8PlayIE
    from . import TV3PlayLithuaniaIE
    from . import Viasat4PlayIE
    from . import TV3PlayEstoniaIE
    from . import TV3PlaySEIE
    from . import TV3PlayLithuaniaIE
    from . import TV3PlayLatviaIE
    from . import ViafreeIE
    from . import TV3PlayEstonia

# Generated at 2022-06-24 13:35:59.708195
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = InfoExtractor({}, {}, 'Viafree')
    assert ie.get_priority() == 3
    assert ie.extractor_info == {
        'name': 'Viafree',
        'description': 'Viafree, TV3 Play, TV6 Play, TV8 Play and TV10 Play',
        'hosts': ['viafree', 'tv3play', 'tv6play', 'tv8play', 'tv10play', 'tv3play.is', 'tv3play.no', 'tv3play.se', 'tv6play.no', 'tv8play.dk', 'tv10play.se', 'play.novatv.bg'],
        'ie_key': 'Viafree',
        'url_re': ViafreeIE.URL_RE,
    }
    assert ie.get_basename() == 'viafree'

# Generated at 2022-06-24 13:36:08.017088
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test with correct URLs (should not raise any exceptions)
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak-10280317')
    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354')

    # Simple tests with incorrect URLs
    with pytest.raises(ExtractorError):
        ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')

# Generated at 2022-06-24 13:36:11.760404
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    not_standalone_urls = [
        'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
    ]
    for url in not_standalone_urls:
        assert not ViafreeIE.suitable(url)
    assert ViafreeIE.suitable()

# Generated at 2022-06-24 13:36:13.026557
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Ensure that the import of TVPlayIE works
    return ViafreeIE({})

# Generated at 2022-06-24 13:36:15.334633
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    obj = ViafreeIE('Viafree')

    assert ie is obj


# Generated at 2022-06-24 13:36:23.872412
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ViafreeIE._download_json = lambda x, y: {}
    ViafreeIE._extract_m3u8_formats = lambda x, y, z: [{'format_id': 'hls'}]
    ie = ViafreeIE(url)
    assert ie.suitable(url) == False
    assert ie.compat_url(url) == 'mtg:757786'
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._TES

# Generated at 2022-06-24 13:36:30.472554
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    # Unit test for _VALID_URL
    # Valid URL starts with http(s)://(tv3?)play.(tv3.lt|skaties.lv|tv3.ee)/(..-)?[^/]
    # -[0-9]+

# Generated at 2022-06-24 13:36:37.567590
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.name == 'TVPlay Home'
    assert ie.ie_key() == 'TVPlayHome'
    assert ie.url_re == TVPlayHomeIE._VALID_URL
    assert ie.valid_url('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.valid_url('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie.valid_url('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-24 13:36:48.071302
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:58.052278
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Use function to avoid hardcoded test_ids
    def test_ctor(test_id):
        try:
            inspect.getfullargspec(cls.__init__)
        except TypeError:
            pytest.skip('Class is not callable')

        test_url = 'http://www.viafree.se/program/underhallning/det-beste-vorspielet/sasong-2/episode-1'

# Generated at 2022-06-24 13:37:01.086605
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check that the constructor throws an exception if it is invoked with an invalid URL
    test_url = 'invalid_url'
    assert not ViafreeIE.suitable(test_url)
    with pytest.raises(ExtractorError):
        ViafreeIE(test_url)

# Generated at 2022-06-24 13:37:02.520504
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()._VALID_URL == TVPlayHomeIE._VALID_URL


# Generated at 2022-06-24 13:37:13.965376
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.country == 'NO'
    assert ie.program_path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = ViafreeIE('https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'DK'
    assert ie.program_path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'
    ie = ViafreeIE('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.country == 'NO'

# Generated at 2022-06-24 13:37:17.058521
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractor = TVPlayHomeIE()
    info_extractor.suitable('blahblah')
    assert len(TVPlayHomeIE._TESTS) > 0



# Generated at 2022-06-24 13:37:17.751377
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass



# Generated at 2022-06-24 13:37:18.429830
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('mtg', 'tvplay.se')

# Generated at 2022-06-24 13:37:19.813081
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_constructor(TVPlayIE)


# Generated at 2022-06-24 13:37:28.808660
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TestClass = TVPlayIE
    TestClass = TestClass.ie_key()
    assert TestClass.IE_NAME == "tvplay"
    assert TestClass.IE_DESC == "MTG services"

# Generated at 2022-06-24 13:37:39.643914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert (viafree._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(dk|no|se)
                        /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    ''')
    assert (viafree._TESTS[0].get('url') == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert (viafree._TEST_CASES[0].get('id') == '757786')
    assert (viafree._TEST_CASES[0].get('title') == 'Det beste vorspielet - Sesong 2 - Episode 1')

# Generated at 2022-06-24 13:37:40.651911
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TODO
    assert False


# Generated at 2022-06-24 13:37:51.234229
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    try:
        # In case test fails, it may be useful to see the content of page
        # for copying to a static file for manual testing
        content = compat_urllib_request.urlopen('http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/').read()
    except Exception:
        pass

    inst = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    inst.extract('https://tvplay.tv3.lt/aferistai-10047125')
    assert '366367' == inst._match_id('https://tvplay.tv3.lt/aferistai-10047125')



# Generated at 2022-06-24 13:37:53.561314
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Run the class constructor for ViafreeIE
    """
    ie = ViafreeIE()


# Generated at 2022-06-24 13:38:04.401349
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()

# Generated at 2022-06-24 13:38:08.961121
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not ie.suitable('http://tvplay.skaties.lv/parraides/sarga-dzive/26407?autostart=true')


# Generated at 2022-06-24 13:38:20.397914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import unittest
    class TestViafreeIE(unittest.TestCase):
        def setUp(self):
            self.ie = ViafreeIE()
            self.s = '-http://www.-viafree.se/program/underh%C3%A5llning/familjen-annorlunda/s%C3%A4song-2/avsnitt-2'
        def test_format_url(self):
            url = 'http://www.viafree.se/program/underh%C3%A5llning/familjen-annorlunda/s%C3%A4song-2'
            answer = 'http://www.viafree.se/program/underhallning/familjen-annorlunda/sasong-2'

# Generated at 2022-06-24 13:38:23.796385
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    # Example to test URL with
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    result = ie.suitable(url)
    assert result


# Generated at 2022-06-24 13:38:28.876190
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.geo_verification_headers() == {'x-forwarded-for': '37.252.176.67,37.252.176.67'}

# Generated at 2022-06-24 13:38:40.637988
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:49.742033
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:38:56.993291
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie._VALID_URL == r'(?x)https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert ie._TESTS[1]['url'] == 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

# Generated at 2022-06-24 13:39:01.018526
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    name = info_extractor.IE_NAME
    description = info_extractor.IE_DESC
    assert name == 'mtg'
    assert description == 'MTG services'


# Generated at 2022-06-24 13:39:04.730400
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.tv3play.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    viafreeIE = ViafreeIE()
    match = viafreeIE._VALID_URL.match(url)
    assert match is not None, url


# Generated at 2022-06-24 13:39:11.159965
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    download_url = 'https://playback-api.mtg-ss-staging.com/playlist/v1/playlist/playlist_viasat_nordic_viasat_reality.m3u8?cb=1475289285'
    guid = '650022'
    assert isinstance(ViafreeIE, type)
    viafree = ViafreeIE(download_url, guid)
    assert isinstance(viafree, ViafreeIE)
    assert viafree.guid == guid
    assert viafree.download_url == download_url
    assert isinstance(viafree.password, str)
    assert viafree.password != ''
    assert isinstance(viafree.token, str)
    assert viafree.token != ''
