

# Generated at 2022-06-24 13:29:19.342041
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ies = [
        TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125'),
        TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317'),
        TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'),
        ]
    for ie in ies:
        # Check for _VALID_URL property
        assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
        # Check for _TESTS property

# Generated at 2022-06-24 13:29:24.984505
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    parsed_url = compat_urlparse.urlparse(video_url)
    _check_valid_url = TVPlayHomeIE._VALID_URL
    mo = re.match(_check_valid_url, video_url)

    assert mo.group('id') == '10047125'
    assert re.compile(_check_valid_url).match(video_url)



# Generated at 2022-06-24 13:29:29.246409
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor_test(ViafreeIE, ['https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'])
    constructor_test(ViafreeIE, ['http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'])

# Generated at 2022-06-24 13:29:41.342308
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # With variable throught all MediaExtractor class and its subclasses, self.url
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE().prepare_url_for_extraction(url)
    assert ie.viafree_url_template == 'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s'
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert ie.url == url


# Generated at 2022-06-24 13:29:42.899761
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-24 13:29:44.512565
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie2 = TVPlayIE()

# Generated at 2022-06-24 13:29:48.668488
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:29:51.605902
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-24 13:29:53.010201
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'



# Generated at 2022-06-24 13:29:57.811679
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')._real_extract('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')  # noqa: E501

# Generated at 2022-06-24 13:30:09.360194
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL))
    assert(not TVPlayHomeIE.suitable("https://tvplay.tv3.lt"))
    assert(TVPlayHomeIE.suitable("https://tvplay.tv3.lt/10044354"))
    assert(TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai-10047125"))
    assert(TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai-10047125/"))
    assert(TVPlayHomeIE.suitable("https://tvplay.tv3.lt/aferistai/aferistai-10047125/"))
    assert(TVPlayHomeIE.suitable("https://play.tv3.lt/aferistai-10047125/"))

# Generated at 2022-06-24 13:30:17.998059
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE()

# Generated at 2022-06-24 13:30:19.029391
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-24 13:30:20.976272
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie_search_results = ie.ie_keywords
    assert ie_search_results == [
        'viafree'
    ]



# Generated at 2022-06-24 13:30:24.204241
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    url = "http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true"
    print(info_extractor.extract(url))
    url = "mtg:418113"
    print(info_extractor.extract(url))


# Generated at 2022-06-24 13:30:25.387747
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie != None


# Generated at 2022-06-24 13:30:34.685469
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvp = TVPlayIE()
    assert tvp.IE_NAME == 'mtg'
    assert tvp.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:40.021337
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('https://www.viafree.dk')
    assert ie.get('_VALID_URL') == r'https?://www\.viafree\.dk/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'



# Generated at 2022-06-24 13:30:42.372337
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._TESTS[0]['url'] == ie._VALID_URL

# Generated at 2022-06-24 13:30:48.603933
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_ie = TVPlayHomeIE()
    for test in tvplayhome_ie._TESTS:
        test_url = test.get('url')
        id = re.search(tvplayhome_ie._VALID_URL, test_url).group('id')
        m = TVPlayHomeIE._match_id(test_url)
        print(id)
        assert id == m


# Generated at 2022-06-24 13:31:00.053034
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    r = TVPlayIE()
    assert r.IE_NAME == 'mtg'
    assert r.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:31:01.746435
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test constructor of class ViafreeIE
    ViafreeIE()



# Generated at 2022-06-24 13:31:03.026623
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-24 13:31:09.699961
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Needs to be in youtube_dl/extractor/mtg.py.
    from .mtg import TVPlayIE
    from .mtg import _VALID_URL
    from .mtg import _TESTS
    for test in _TESTS:
        tv_play = TVPlayIE()
        if test['url'] in tv_play.ie_key():
            assert test['url'], tv_play.ie_key()



# Generated at 2022-06-24 13:31:18.170729
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # This is not a full test of TVPlayIE, but just a class constructor test
    tvplay_ie = TVPlayIE()
    assert tvplay_ie.IE_NAME == 'mtg'
    assert tvplay_ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:31:29.385172
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # simple call, no error should be raised
    try:
        ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
        ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    except:
        assert(False)
    # more complex call, should raise

# Generated at 2022-06-24 13:31:41.251784
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # First test with single keyword arguments
    tvplay_home_ie = TVPlayHomeIE(url='https://tvplay.tv3.lt/aferistai-10047125')
    assert tvplay_home_ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:31:43.283343
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    # It is just for test class ViafreeIE, we should use other platform's URL to make sure we can get the data
    ie.extract('http://www.tv3play.se/program/husraddarna/395385?autostart=true')


# Generated at 2022-06-24 13:31:50.471827
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    raise NotImplementedError('Unit tests not implemented')
    import sys
    import os
    import re
    import hashlib
    import unittest
    re_id = re.compile(r'^[a-z0-9_-]+$')
    cur_dir = os.path.dirname(__file__)
    y_t_c_i_d_path = os.path.join(
        cur_dir, 'youtube-dl', '__main__.py')
    ie_path = os.path.join(
        cur_dir, 'youtube_dl', 'extractor', '__init__.py')
    sys.path.append(os.path.dirname(y_t_c_i_d_path))
    from __main__ import main as y_t_c_i_d_main
   

# Generated at 2022-06-24 13:31:51.776573
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ie


# Generated at 2022-06-24 13:31:52.810866
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    print(ViafreeIE())


# Generated at 2022-06-24 13:31:53.495781
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-24 13:32:04.909360
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert not ie.suitable('https://play.tv3.ee/')
    assert not ie.suitable('https://tvplay.tv3.lt/')
    assert not ie.suitable('https://tvplay.tv3.ee/')
    assert not ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')

# Generated at 2022-06-24 13:32:06.695535
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    constructor_test(ViafreeIE, 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

# Generated at 2022-06-24 13:32:18.589947
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .utils import make_IE_regex_tests

    def test_factory(input_url, expected_field_values):
        return make_IE_regex_tests(TVPlayIE, expected_field_values, [input_url])

    fields_urls = {
        'id': 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229',
        'title': 'Moterys meluoja geriau',
        'series': 'Moterys meluoja geriau',
        'season': '1 sezonas',
        'season_number': 1,
        'episode_number': 47,
    }
    _test_url = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229'


# Generated at 2022-06-24 13:32:29.275083
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:32:38.479436
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:32:49.853124
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_instance = ViafreeIE()
    assert class_instance._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''
    assert class_instance._GEO_BYPASS == False
    assert class_instance._TESTS[0]['url'] == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    assert class_instance._TESTS[0]['info_dict']['id'] == '757786'

# Generated at 2022-06-24 13:32:52.873767
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE().suitable('')
    assert not ViafreeIE().suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:32:54.650809
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-24 13:32:58.221540
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_class = TVPlayHomeIE()
    assert test_class._VALID_URL == TVPlayHomeIE._VALID_URL
    assert test_class._TESTS == TVPlayHomeIE._TESTS

# Generated at 2022-06-24 13:32:59.722481
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE()



# Generated at 2022-06-24 13:33:10.167359
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:33:14.784963
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # check that TVPlayHomeIE.suitable() function can be called on instance of class TVPlayHomeIE
    assert ie.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')



# Generated at 2022-06-24 13:33:15.661562
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree is not None


# Generated at 2022-06-24 13:33:26.452622
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import doctest
    from .common import _media, _media_json
    from .common import _media_xml
    from .common import _real_extract
    from .common import _test_desc
    from .common import _test_f4m
    from .common import _test_m3u8
    from .common import _test_real_extract
    from .common import _test_xml
    from .common import _url
    from .common import FakeFilesystem
    from .common import FakeHttpAdapter
    from .common import FakeStdin
    from .common import FakeTempfile
    from .common import stdin_test
    from .common import TestCommon

    import sys

    stdin_test.test_transcript = FakeStdin().test_transcript


# Generated at 2022-06-24 13:33:27.559075
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE() is not None


# Generated at 2022-06-24 13:33:35.484027
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    class Mock_IE(object):

        def __init__(self):
            self.event_info = {
                'id': '757786',
                'ext': 'mp4',
                'title': 'Det beste vorspielet - Sesong 2 - Episode 1',
                'description': 'md5:b632cb848331404ccacd8cd03e83b4c3',
                'series': 'Det beste vorspielet',
                'season_number': 2,
                'duration': 1116,
                'timestamp': 1471200600,
                'upload_date': '20160814',
            }

        def _real_extract(self, country, path):
            return self.event_info

    ie = ViafreeIE()
    ie.test_IE = Mock_IE()
   

# Generated at 2022-06-24 13:33:41.129385
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # i.e. 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    pathname_pattern = r'%s(?:-\d+)' % TVPlayHomeIE._VALID_URL

    # Constructor of class TVPlayHomeIE
    def constructor_test(pathname):
        tvplay_home_url = 'https://tv3play.skaties.lv/%s' % pathname
        assert TVPlayHomeIE.suitable(tvplay_home_url)
        return TVPlayHomeIE(tvplay_home_url)

    random_string = ''.join([random.choice(string.ascii_lowercase)
                             for _ in range(random.randint(1, 100))])

    # Pathname should start with 'vinas-melo-lab

# Generated at 2022-06-24 13:33:45.486237
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2') is False
    assert ie.suitable('http://play.tv2.no/programmer/underholdning/paa-kino-aktuell-med-andreas-wahl/sesong-1/episode-8?autostart=true') is False
    assert ie.suitable('http://tv2.no/') is False

# Generated at 2022-06-24 13:33:47.923558
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE.TVPlayIE(TVPlayIE.IE_NAME, TVPlayIE.IE_DESC, TVPlayIE._VALID_URL)


# Generated at 2022-06-24 13:33:58.528891
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        submodule_search_re = re.compile(r'submodule=([a-z0-9_]+)', re.IGNORECASE)
    except re.error:
        submodule_search_re = None

    def extractor_for_url(url):
        match = submodule_search_re.search(url)
        if match:
            submodule_name = match.group(1)
            assert submodule_name in globals()
            return globals()[submodule_name]()
        else:
            return None

    url = 'https://www.tv3play.no/programmer/krim/maurizio/sesong-1'
    # Test constructor that takes an extractor
    ie = _GenericIE(extractor_for_url)

# Generated at 2022-06-24 13:34:09.153913
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class TestLoad(object):
        def __init__(self):
            self.modules = {}
        def load_module(self, fullname):
            if fullname == 'geoip2':
                self.modules[fullname] = geoip2
            else:
                raise ImportError
        def __getattr__(self, name):
            try:
                return self.__getattribute__(name)
            except AttributeError:
                for mod in self.modules.values():
                    if hasattr(mod, name):
                        return getattr(mod, name)
                raise AttributeError
    globals()['__loader__'] = TestLoad()
    assert TVPlayIE
    assert callable(TVPlayIE)


# Generated at 2022-06-24 13:34:18.174104
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_obj = TVPlayIE()

# Generated at 2022-06-24 13:34:24.936080
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Testing with a URL of the Viafree site and then the class is initialised to verify that the URL is in fact of
    # the Viafree site
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie = ViafreeIE(ViafreeIE.suitable(url))
    assert ie.SUITABLE == ViafreeIE.suitable(url)



# Generated at 2022-06-24 13:34:35.537250
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:34:37.415627
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree is not None


# Generated at 2022-06-24 13:34:42.440954
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable('https://www.viafree.se/program/reality/paradise-hotel/saeson-24/episode-5') is False
    assert ie.suitable('https://tvplay.skaties.lv/parraides/tv3-zinas/762278') is True

# Generated at 2022-06-24 13:34:49.653828
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # constructor loads asset and parses some data
    url='https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    ie = TVPlayHomeIE(url)
    assert ie.asset.get('assetId') == '10278121'
    assert ie.video_id == '10278121'
    assert ie.title == 'Vīna vai melo labāk'
    assert ie.age_limit == 16


# Generated at 2022-06-24 13:34:53.898426
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()

    # ViafreeIE matches URLs that TVPlayIE matches
    # And therefore, ViafreeIE excludes those URLs
    assert ie._VALID_URL == ViafreeIE._VALID_URL
    assert ie.suitable(TVPlayIE()._VALID_URL) is False

# Generated at 2022-06-24 13:34:54.575885
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-24 13:35:06.077205
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Different asset types
    asset1 = { 'assetType': 'SERIES' }
    asset2 = { 'assetType': 'PROGRAM' }
    asset3 = { 'assetType': 'EPISODE' }
    assert TVPlayHomeIE._build_series_title('', asset1) is None
    assert TVPlayHomeIE._build_series_title('', asset2) is None
    assert TVPlayHomeIE._build_series_title('', asset3) is None
    asset1 = { 'assetType': 'SERIES', 'seriesTitle': 'Aferistai' }
    asset2 = { 'assetType': 'PROGRAM', 'seriesTitle': 'Aferistai' }
    asset3 = { 'assetType': 'EPISODE', 'seriesTitle': 'Aferistai' }
    assert TV

# Generated at 2022-06-24 13:35:11.795957
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    from .extractor import URL_VALID
    from .extractor import URL_TYPES
    from .extractor import URL_CLASSES
    from .extractor import GENERIC_IE_DESCRIPTIONS
    for url, secret_code in ViafreeIE._TESTS:
        if not re.match(ViafreeIE._VALID_URL, url):
            print("Not match " + url)
            continue
        if url in URL_CLASSES.keys():
            print("Registered as " + url)
            continue
        ie = ViafreeIE(url)
        if ie.IE_NAME not in GENERIC_IE_DESCRIPTIONS.keys():
            print("Unknown " + ie.IE_NAME)

# Generated at 2022-06-24 13:35:21.180728
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test for creating an instance of class ViafreeIE with parameter url
    url = 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    ie = ViafreeIE(url)
    # Test for validating the country code of passed url
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?
                                    viafree\.(dk|no|se)
                                    /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                '''


# Generated at 2022-06-24 13:35:28.429350
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(params={'geo_countries': 'se'})
    assert ie._GEO_COUNTRIES == ['SE']
    ie = ViafreeIE(params={'geo_countries': 'se,dk'})
    assert ie._GEO_COUNTRIES == ['SE', 'DK']
    ie = ViafreeIE(params={'geo_countries': 'se, dk'})
    assert ie._GEO_COUNTRIES == ['SE', 'DK']


# Generated at 2022-06-24 13:35:38.702538
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    if TVPlayIE()._WORKING == False:
        return
    info_extractor = TVPlayIE()
    video_id = '624952'
    url = info_extractor._VALID_URL % video_id
    url1 = 'http://play.novatv.bg/programi/zdravei-bulgariya/%s?autostart=true' % video_id
    url2 = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    url3 = 'https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true'
    tvie = TVPlayIE()

# Generated at 2022-06-24 13:35:43.029664
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
                            https?://
                                (?:www\.)?
                                viafree\.(dk|no|se)
                                /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                            '''

# Generated at 2022-06-24 13:35:43.625173
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:35:54.948133
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test for constructor of class ViafreeIE"""
    print("Testing constructor of class ViafreeIE")
    viafree = ViafreeIE()
    assert(hasattr(viafree, '_VALID_URL'))
    assert(hasattr(viafree, 'SUCCESS'))
    assert(hasattr(viafree, '_downloader'))
    assert(hasattr(viafree, '_GEO_COUNTRIES'))
    assert(hasattr(viafree, '_GEO_BYPASS'))
    assert(hasattr(viafree, 'IE_NAME'))
    assert(hasattr(viafree, '_NETRC_MACHINE'))
    assert(hasattr(viafree, 'BRIGHTCOVE_URL_TEMPLATE'))

# Generated at 2022-06-24 13:36:04.303225
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie._VALID_URL == r'''(?x)
                                https?://
                                    (?:www\.)?
                                    viafree\.(?P<country>dk|no|se)
                                    /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                '''

# Generated at 2022-06-24 13:36:07.543988
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    mtg = TVPlayIE()
    result = mtg._real_extract(url)
    assert len(result['formats']) >= 1


# Generated at 2022-06-24 13:36:11.157021
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Check correct initialization of instance of class TVPlayIE
    ie = TVPlayIE()
    regex = r'https?://playapi\.mtgx\.tv/(.*?)\?platform=TVPlayWebsite.*?$'
    assert ie._VALID_URL == regex



# Generated at 2022-06-24 13:36:12.692833
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie != None


# Generated at 2022-06-24 13:36:13.992342
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_htmlparser import test_htmlparser

    test_htmlparser(TVPlayIE)

# Generated at 2022-06-24 13:36:17.001361
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """
    Test constructor viafree.
    """
    viafree_ie = ViafreeIE()
    assert viafree_ie._GEO_COUNTRIES == ['NO', 'SE', 'DK']


# Generated at 2022-06-24 13:36:25.474248
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:36:26.334302
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE("test")
    assert ie

# Generated at 2022-06-24 13:36:28.690072
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.tv/parraides/vinas-melo-labak/418113?autostart=true'
    TVPlayIE._real_extract(TVPlayIE(), url)



# Generated at 2022-06-24 13:36:29.657784
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE({})


# Generated at 2022-06-24 13:36:34.873336
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(
        compat_urllib_request.Request('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'),
        compat_urllib_request.urlopen(
            compat_urllib_request.Request('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')))

# Generated at 2022-06-24 13:36:36.104529
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE({}), ViafreeIE)

# Generated at 2022-06-24 13:36:44.081421
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tph_ie = TVPlayHomeIE('https://tvplay.tv3.ee/buduaar-mehhiko-kuumadel-randadel/buduaar-mehhiko-kuumadel-randadel-10044351/')
    assert tph_ie.extractor_key == 'TVPlayHome'
    assert tph_ie.player_key == 'TVPlayHomePlayer'
    assert tph_ie.video_id == '10491726'
    assert tph_ie.page_key == '10491726'

# Generated at 2022-06-24 13:36:48.588896
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    tvplayhome = TVPlayHomeIE(FakeInfoExtractor())
    tvplayhome._real_initialize()
    tvplayhome.suitable(url)
    tvplayhome._real_extract(url)



# Generated at 2022-06-24 13:36:52.470571
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    # test empty url
    url = ''
    assert not ie.suitable(url)
    # test wrong url
    url='https://tvplay.tv3play.ee/aferistai-10047125'
    assert not ie.suitable(url)

# Generated at 2022-06-24 13:36:54.950084
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        # Test on https://www.tvplay.de/asset/2558/fernsehen
        TVPlayIE(None)._real_initialize()
    except Exception as e:
        assert False, 'Unable to create instance of TVPlayIE'

# Generated at 2022-06-24 13:36:59.336410
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE should inherit from TVPlayIE
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.__class__.__name__ == 'TVPlayIE'
    assert ie._VALID_URL == ViafreeIE._VALID_URL


# Generated at 2022-06-24 13:37:02.749121
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    video = TVPlayIE()._real_extract('mtg:418113')
    assert video['id'] == video_id
    assert video['title'] == 'Kādi ir īri? - Viņas melo labāk'



# Generated at 2022-06-24 13:37:03.941638
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    one_test = TVPlayIE()
    return one_test



# Generated at 2022-06-24 13:37:07.465983
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        from IPython import embed, get_ipython  # @UnusedImport pylint: disable=import-error
        ip = get_ipython()
        ip.register_magics(SphinxMagic)
        ip.run_cell_magic('sphinx', 'embed_globals {}', '.. automodule:: youtube_dl.extractor.viafree')
    except (NameError, ImportError):
        pass

# Generated at 2022-06-24 13:37:10.867565
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    assert ie.geo_verification_headers()["Accept-Language"] == "lv-LV"

# Generated at 2022-06-24 13:37:16.240677
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('1')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.__class__.__name__ == 'TVPlayHomeIE'

# Generated at 2022-06-24 13:37:19.769895
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_class = TVPlayIE()
    assert test_class.IE_NAME == 'mtg'
    assert test_class.IE_DESC == 'MTG services'
    assert (test_class._VALID_URL is not None)



# Generated at 2022-06-24 13:37:21.954020
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_js_extractors import test_js_extractors
    return test_js_extractors(TVPlayIE)


# Generated at 2022-06-24 13:37:27.097644
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE(): # pragma: no cover
    from .common import InfoExtractor
    from .. import compat_urllib_request

    # call constructor
    InfoExtractor.TVPlayIE()

    # assert http request was called
    assert compat_urllib_request.urlopen.called


# Generated at 2022-06-24 13:37:29.280433
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert isinstance(ie, TVPlayHomeIE)

# Generated at 2022-06-24 13:37:40.248486
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Provides minimal test coverage of the TVPlayIE constructor.
    """

# Generated at 2022-06-24 13:37:45.601146
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass = lambda x: None
    ie._download_json = lambda x, y: x
    ie.extract(
        'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'
    )

# Generated at 2022-06-24 13:37:57.362009
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    video_id = '10044354'
    asset = TVPlayHomeIE()._download_json(
        'https://play.tv3.ee/sb/public/asset/' + video_id, video_id)
    assert asset
    assert 'imageUrl' in asset
    assert 'metadata' in asset
    assert 'title' in asset
    assert 'movie' in asset
    assert 'assetId' in asset
    assert 'contentUrl' in asset['movie']
    assert 'runTime' in asset['title']
    assert 'summaryLong' in asset['title']
    assert 'summaryShort' in asset['title']
    assert 'tvSeasonTitle' in asset
    assert 'tvSeriesTitle' in asset
    assert 'titleBrief' in asset['title']
    assert 'seasonNumber' in asset['metadata']

# Generated at 2022-06-24 13:37:59.961809
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    c = TVPlayIE()
    c.url_result('mgt:418113', 'TVPlay', 'video', '418113')

# Generated at 2022-06-24 13:38:03.526359
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    youtube_ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert youtube_ie.constructor_name == 'TVPlayHomeIE'

# Generated at 2022-06-24 13:38:08.910012
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def viafree_ie_instance(url):
        return ViafreeIE(ExtractorRegistry.gen_extractor(url))

    # country == se
    ie = viafree_ie_instance('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie.country == 'se'
    assert ie._GEO_BYPASS

    # country == dk
    ie = viafree_ie_instance('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert ie.country == 'dk'
    assert ie._GEO_BYPASS

    # country == no

# Generated at 2022-06-24 13:38:13.523584
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    playlist_id = 404709
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/404709/?autostart=true'
    tvplay_ie = TVPlayIE(url)
    assert playlist_id == tvplay_ie.playlist_id



# Generated at 2022-06-24 13:38:19.490797
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869') == False
    assert viafreeIE.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true') == True
    assert viafreeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true') == True
    assert viafreeIE.suitable('http://www.viasat.se/sport/fotboll/barnsleys-assistent-far-sota-bonusar-2.5893615') == False
    assert viafreeIE

# Generated at 2022-06-24 13:38:26.476510
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5') == True
    ie.suitable('http://www.tv3play.se/program/husraddarna/395385') == False
    ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113') == False
    ie.suitable('http://www.tvplay.skaties.lv/parraides/vinas-melo-labak/418113') == False
    ie.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952') == False

# Generated at 2022-06-24 13:38:38.864356
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:40.363929
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 13:38:46.496212
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    # Check that _AVAILABLE_COUNTRIES is working properly
    regex = 'https?://tv3?play\.(tv3\.lt|skaties\.lv|tv3\.ee)'
    assert ie._VALID_URL == regex + '/(?:[^/]+/)*[^/?#&]+-(\d+)'


# Generated at 2022-06-24 13:38:54.319827
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    tot_test_case_num = 1
    test_case_num = 1
    if not ie._VALID_URL == 'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)':
        print ('Fail in test case %d, line %d' % (test_case_num, inspect.currentframe().f_lineno))
    test_case_num += 1

# Generated at 2022-06-24 13:38:55.189015
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()

# Generated at 2022-06-24 13:38:58.616345
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-24 13:39:10.332349
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_ie = TVPlayIE("TVPlayIE", "tvplay")
    tv_play_ie.download("http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    tv_play_ie.download("http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true")
    tv_play_ie.download("http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true")
    tv_play_ie.download("http://www.tv3play.se/program/husraddarna/395385?autostart=true")