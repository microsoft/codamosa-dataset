

# Generated at 2022-06-24 13:29:13.143381
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.IE_NAME == 'TVPlayHome'


# Generated at 2022-06-24 13:29:22.234665
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie._VALID_URL = ViafreeIE._VALID_URL
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')

# Generated at 2022-06-24 13:29:23.194829
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()


# Generated at 2022-06-24 13:29:25.915634
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('www.tv10play.se')._real_extract('http://www.tv10play.se/program/ridskolan-3/282689?autostart=true')

# Generated at 2022-06-24 13:29:31.416803
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = "https://play.tv3.lt/aferistai-10047125"
    ie = TVPlayHomeIE(url)
    expected_url = "https://tvplay.tv3.lt/aferistai-10047125"
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._TESTS == TVPlayHomeIE._TESTS
    assert ie._real_extract(expected_url) == TVPlayHomeIE._real_extract(ie, expected_url)


# Generated at 2022-06-24 13:29:41.843822
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(TVPlayHomeIE.suitable(''))
    assert ie.__class__.__name__ == 'TVPlayHomeIE'
    assert hasattr(ie, '_VALID_URL')
    assert hasattr(ie, 'IE_NAME')
    assert hasattr(ie, '_TESTS')
    assert ie.IE_NAME == 'tvplayhome'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:29:46.517656
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    print('Test for ViafreeIE')
    assert('https' in ViafreeIE._VALID_URL)
    assert(ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'))
    assert(not ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'))

# Generated at 2022-06-24 13:29:50.446181
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'TVPlayHome'
    assert ie.GEO_COUNTRIES == ['LT', 'LV', 'EE']
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL



# Generated at 2022-06-24 13:29:55.505933
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(TypeError):
        ViafreeIE()
    with pytest.raises(TypeError):
        ViafreeIE.suitable(None)
    with pytest.raises(TypeError):
        ViafreeIE.suitable(
            'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    with pytest.raises(TypeError):
        ViafreeIE()._real_extract(None)
    with pytest.raises(ExtractorError):
        ViafreeIE()._real_extract(
            'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-24 13:30:01.120976
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    c = ViafreeIE(URL(url), url)
    assert c.country == 'dk'
    assert c.path == 'programmer/reality/paradise-hotel/saeson-7/episode-5'


# Generated at 2022-06-24 13:30:03.856425
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-24 13:30:11.905778
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info_extractors = [
        ('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', ViafreeIE),
        ('http://play.tv2.no/programmer/magasinet-dokument-2/episodes/ahdvq3s', ViafreeIE),
    ]

# Generated at 2022-06-24 13:30:15.973409
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'''(?x)
        https?://
            (?:www\.)?
            viafree\.(dk|no|se)
            /(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
        '''



# Generated at 2022-06-24 13:30:21.062841
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

    # Constructor test
    assert ie.suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    assert ie.suitable('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie.suitable('http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:30:27.951445
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/cool-d-ga-mehhikosse/', 'cool-d-ga-mehhikosse/')
    # Check URL
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)'
    # Check if URL is valid
    assert ie.suitable('https://play.tv3.lt/cool-d-ga-mehhikosse/') == True
    # Check if URL is not valid
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317') == False
   

# Generated at 2022-06-24 13:30:29.058711
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert isinstance(instance, InfoExtractor)


# Generated at 2022-06-24 13:30:40.988906
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:53.480975
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'
    assert len(re.findall(tvplay._VALID_URL, tvplay._TESTS[0]['url'])) != 0
    assert tvplay._TESTS[0]['only_matching'] == False
    assert tvplay._TESTS[0]['info_dict']['id'] == '418113'
    assert tvplay._TESTS[0]['info_dict']['title'] == 'Kādi ir īri? - Viņas melo labāk'

# Generated at 2022-06-24 13:30:55.613748
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert "TVPlayHomeIE" == ie.ie_key()


# Generated at 2022-06-24 13:31:03.545563
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_tvplay = TVPlayIE()
    assert test_tvplay.IE_NAME == 'mtg'
    assert test_tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:31:06.205085
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('tv3play.skaties.lv/vinas-melo-labak-10280317')


# Generated at 2022-06-24 13:31:16.125471
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Check that __init__() for all subclasses of ViafreeIE has same parameters.
    # This can help avoid a lot of boring redefinitions.
    params = inspect.signature(ViafreeIE).parameters
    params = params.values()
    params = {p.name for p in params if p.default == inspect.Parameter.empty}
    params = params.difference({'self'})

    base_params = params.copy()
    for subclass in ViafreeIE.__subclasses__():
        _params = inspect.signature(subclass).parameters
        _params = _params.values()
        _params = {p.name for p in _params if p.default == inspect.Parameter.empty}
        _params = _params.difference({'self'})

# Generated at 2022-06-24 13:31:22.665530
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import _mock_extract  # pylint: disable=unused-import
    # It should work with TVPlayIE URLs
    assert ViafreeIE.suitable(TVPlayIE.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183'))
    # And it shouldn't work with its own
    assert not ViafreeIE.suitable(ViafreeIE._VALID_URL)

# Generated at 2022-06-24 13:31:33.414265
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317') == True
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125') == True
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317/') == True
    assert ie.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354') == True

# Generated at 2022-06-24 13:31:43.957181
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert (ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')) is False
    assert (ViafreeIE.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')) is False
    assert (ViafreeIE.suitable('http://play.nova.bg/programi/zdravei-bulgariya/624952?autostart=true')) is False
    assert (ViafreeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')) is False

# Generated at 2022-06-24 13:31:50.884547
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert IE.name == "tvplay-home"
    assert IE.ie_key() == "tvplay-home"
    assert IE.supported_ie == ["mtg", "tvplay-home", "tvplay-se", "tvplay-dk", "tvplay-no", "tvplay-lt", "tvplay-lv", "tvplay-ee"]

# Generated at 2022-06-24 13:32:01.252099
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test the constructor of class TVPlayHomeIE"""
    test_urls = [
        # Viasat is detected as TVPlayHomeIE
        'https://tvplay.viasat.tv/programm/nove-kriminalkas/pirma-serija/',
        # TVPlayHomeIE is not suitable, so ViasatIE is chosen
        'https://tvplay.viasat.tv/film/sneki-sneki/',
    ]
    for url in test_urls:
        info_dict = TVPlayHomeIE()._real_extract(url)
        video_id = IE_NAME_TO_CONTENT_ID[TVPlayHomeIE.ie_key()](url)
        video_url = 'https://tvplay.viasat.tv/sb/public/asset/' + video

# Generated at 2022-06-24 13:32:13.411608
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    tvplay_ie = TVPlayIE(None)

    # Test valid video id
    video_id = '418113'
    url = 'https://play.tv3play.lv/programos/moterys-meluoja-geriau/' + video_id + '?autostart=true'
    tvplay_ie._real_extract(url)

    # Test invalid URL
    invalid_url = 'https://play.tv3play.lv/programos/moterys-meluoja-geriau/0?autostart=true'
    with pytest.raises(ExtractorError) as excinfo:
        tvplay_ie._real_extract(invalid_url)
    assert 'Invalid URL' in str(excinfo.value)

    # Test nonexisting video

# Generated at 2022-06-24 13:32:17.794516
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:32:26.584964
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE._VALID_URL = (
        r'^https?://(?:www\.)?tv3play\.tv3\.ee/sisu/kodu-keset-linna/238551')
    TVPlayIE._TESTS = [{
        'url': 'http://www.tv3play.tv3.ee/sisu/kodu-keset-linna/238551'
    }]
    ie = TVPlayIE()

# Generated at 2022-06-24 13:32:37.240188
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    outside_url_1 = 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    outside_url_2 = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    outside_url_3 = 'http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true'
    outside_url_4 = 'http://www.tv8play.se/program/antikjakten/282756?autostart=true'
    outside_url_5 = 'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true'
    outside

# Generated at 2022-06-24 13:32:41.532670
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception as err:
        assert(False, "%s should not throw exception" % type(err))
    else:
        assert(True)


# Generated at 2022-06-24 13:32:46.298686
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # test with a link to a program and test if it can create objects of it's superclass
    # InfoExtractor
    IE = TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert isinstance(IE, InfoExtractor)

# Generated at 2022-06-24 13:32:47.373256
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie



# Generated at 2022-06-24 13:32:57.710683
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        from test.test_utils import get_testdata_dir  # get_real_testdata_dir
        test_dir = get_testdata_dir( )
    except AttributeError:
        test_dir = r'E:\Downloads\test\info_extractor'
    from test.test_video_jwplayer import TestVideoJwplayer

    tvplay_ie = TVPlayIE( )
    for child in TestVideoJwplayer( ).__class__.__subclasses__( ):
        child_cls = child( )
        print("Videoplay:%s, TestVideoJwplayer:%s" %(tvplay_ie.__class__.__name__, child_cls.__class__.__name__))

# Generated at 2022-06-24 13:33:08.647414
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-24 13:33:17.009415
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:33:18.858726
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert isinstance(ie, ViafreeIE)


# Generated at 2022-06-24 13:33:22.331923
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')


# Generated at 2022-06-24 13:33:29.550308
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()
    assert t._VALID_URL == r'(?x)https?://(?:www\.)?(?:tvplay\.skaties\.lv(?:/parraides)?|tv(?:3|6|8|10)play\.se/program|tv(?:3|6|8|10)play\.no/programmer|viasat4play\.no/programmer|play\.nova\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)'

# Generated at 2022-06-24 13:33:33.341772
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    parsed_url = compat_urlparse.urlparse(TVPlayIE._VALID_URL)
    assert ViafreeIE.suitable(TVPlayIE._VALID_URL) == False
    assert ViafreeIE.suitable(TVPlayIE._VALID_URL.replace(parsed_url.netloc, 'www.viafree.se')) == True



# Generated at 2022-06-24 13:33:35.619116
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplay = TVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert tvplay.suitable(url)
    assert tvplay.PLATFORM == 'tv3play'


# Generated at 2022-06-24 13:33:37.027724
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test with no parameter
    instance = ViafreeIE()
    # Ensure it is the right class
    assert isinstance(instance, ViafreeIE)


# Generated at 2022-06-24 13:33:38.911395
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None, 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229')

# Generated at 2022-06-24 13:33:47.202428
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.tv3.lt/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.name == 'TVPlay Home'
    assert ie.IE_NAME == 'tvplayhome'
    assert ie.url_re == TVPlayHomeIE._VALID_URL
    assert ie.country == 'lt'
    assert ie.domain == 'tv3play.tv3.lt'
    assert ie.url_re == TVPlayHomeIE._VALID_URL
    assert ie.IE_DESC == 'TV3 Play, TV6 Play, TV8 Play, TV3 Play Latvia, TV3 Play Estonia, TVPlay Sports, Play.lt, Viafree'


# Generated at 2022-06-24 13:33:52.833373
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    wc = TVPlayIE()
    assert wc.IE_NAME == 'mtg'
    assert wc.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:54.381523
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE(None)._VALID_URL, str)

# Generated at 2022-06-24 13:33:58.336816
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    client = ViafreeIE()
    assert(client.IE_NAME == "viafree")
    assert(client.IE_DESC == "Viafree")
    assert(client._VALID_URL == ViafreeIE._VALID_URL)
    assert(client._TESTS == ViafreeIE._TESTS)

# Generated at 2022-06-24 13:34:10.077288
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE()
    assert i.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert i.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert i.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert i.suitable('https://play.tv3.lt/aferistai-10047125')
    assert i.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-24 13:34:11.986622
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    return TVPlayIE()._get_info_from_url("tvplay://408147")



# Generated at 2022-06-24 13:34:13.619277
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()
    assert x is not None

# Unit tests for regular expressions of class TVPlayIE

# Generated at 2022-06-24 13:34:14.980180
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play = TVPlayIE()
    assert tv_play


# Generated at 2022-06-24 13:34:16.260762
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:34:18.523481
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")

# Generated at 2022-06-24 13:34:30.459554
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import InfoExtractor
    from .TVPlayIE import TVPlayIE
    from ..utils import parse_duration
    from ..compat import (
        compat_etree_fromstring,
        compat_parse_qs,
        compat_urllib_parse_urlparse,
    )

    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113'
    video_id = '418113'
    video_tag_url = 'http://tvplay.skaties.lv/player/config/418113.xml'


# Generated at 2022-06-24 13:34:31.148263
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(None)

# Generated at 2022-06-24 13:34:36.682188
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-24 13:34:44.760880
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    instance = ViafreeIE(url, 'test name')
    assert instance._GEO_BYPASS  == False
    url = 'http://play.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    instance = ViafreeIE(url, 'test name')
    assert instance._GEO_BYPASS  == True

# Generated at 2022-06-24 13:34:46.312179
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == 'TVPlay'

# Generated at 2022-06-24 13:34:48.526896
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.suitable(viafree._VALID_URL) == True


# Generated at 2022-06-24 13:34:52.777834
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    ie = TVPlayHomeIE()

    # Check for TVPlayHomeIE constructor
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:35:04.523533
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    # test case: https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie.suitable(url)
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    tvplayhome_ie = TVPlayHomeIE(url)
    assert tvplayhome_ie.suitable(url)

# Generated at 2022-06-24 13:35:08.157523
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert "https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s" % (
        "country", "path") in ie._download_json.__code__.co_varnames


# Generated at 2022-06-24 13:35:10.430251
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_tvplay import test_TVPlayHomeIE as test_TVPlayHomeIE_test_tvplay
    test_TVPlayHomeIE_test_tvplay(TVPlayHomeIE())

# Generated at 2022-06-24 13:35:12.259218
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE._VALID_URL == TVPlayIE.VALID_URL
    TVPlayIE('TVPlayIE', 'mtg')


# Generated at 2022-06-24 13:35:23.839257
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        if not os.environ.get('TRAVIS_EVENT_TYPE') == 'cron':
            raise unittest2.SkipTest('Test only runs on Travis.')
    except NameError:
        pass
    ies = [
        ViafreeIE(''),
    ]
    for ie_name in sorted(ies, key=lambda ie: ie.IE_NAME):
        ie = ie_name()
        # Test whether it raises ExtractorError when
        # accessed outside the allowed countries
        with pytest.raises(ExtractorError):
            ie.extract('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')


# Generated at 2022-06-24 13:35:31.485725
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home = TVPlayHomeIE()
    tv_play_home._match_id('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tv_play_home._real_extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tv_play_home._real_extract('https://play.tv3.lt/aferistai-10047125')



# Generated at 2022-06-24 13:35:32.595853
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie


# Generated at 2022-06-24 13:35:37.675827
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie.url == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert ie.name == 'TVPlayHome'
    assert ie.video_id == '366367'


# Generated at 2022-06-24 13:35:46.311544
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not TVPlayIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not TV3PlayIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert not ViaplayIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-24 13:35:57.194424
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    obj = TVPlayIE()
    assert obj.IE_NAME == 'mtg'
    assert obj.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:36:02.228098
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._TESTS[0] == TVPlayHomeIE(
        "https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/",
        "Vīnuši melo labāk",
        "Skaties Latvijas raidījumus, ziņas un sporta pārraides tiešraidē TV3, TV6, TV8 un TV3 Life - arī no sava mobilā telefona vai planšetes. | TV3 play")

# Generated at 2022-06-24 13:36:05.423027
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie._VALID_URL == r'^(?P<country>dk|no|se)$'
    assert ie._TESTS == TVPlayIE._TESTS
    assert ie._GEO_BYPASS == False


# Generated at 2022-06-24 13:36:11.929741
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import InfoExtractor
    from ..utils import parse_duration

    TVPlayIE('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')

    TVPlayIE('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE('http://www.tv3play.se/program/husraddarna/395385?autostart=true')

# Generated at 2022-06-24 13:36:16.069431
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    "Test the constructor of class TVPlayIE."
    tvplay = TVPlayIE()
    pattern = tvplay._VALID_URL
    assert re.compile(pattern).match('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    # TODO: assert re.compile(pattern).match('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')



# Generated at 2022-06-24 13:36:17.074258
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()


# Generated at 2022-06-24 13:36:23.572565
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:36:26.620760
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('url')
    assert ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:36:27.698229
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_TVPlayHomeIE = TVPlayHomeIE()


# Generated at 2022-06-24 13:36:35.194247
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    class ViafreeTestIE(ViafreeIE):
        def _real_extract(self, url):
            raise Exception('Should not call _real_extract')

    # u'\xa0' is the non-breaking space character, which is valid utf-8

# Generated at 2022-06-24 13:36:44.907247
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from youtube_dl.utils import DateRange
    # Dummy video id
    video_id = '12345'
    # Dummy timestamp
    timestamp = '1997-01-01T12:00:00+0000'
    # Dummy metadata
    dummy_json = {
        'title': 'Dummy title',
        'description': 'Dummy description',
        'created_at': timestamp,
        'duration': '12345',
        'views': {'total': 12345},
        '_embedded': {
            'season': {'title': 'Dummy series'},
        },
        'format_position': {
            'episode': '1',
            'season': '2',
        },
    }
    # Dummy streams

# Generated at 2022-06-24 13:36:54.775340
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()._real_extract('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie['id'] == '366367'
    assert ie['ext'] == 'mp4'
    assert ie['title'] == 'Aferistai'
    assert ie['description'] == 'Aferistai. Kalėdinė pasaka.'
    assert ie['series'] == 'Aferistai [N-7]'
    assert ie['season'] == '1 sezonas'
    assert ie['season_number'] == 1
    assert ie['duration'] == 464
    assert ie['timestamp'] == 1394209658
    assert ie['upload_date'] == '20140307'
    assert ie['age_limit'] == 18

# Generated at 2022-06-24 13:37:03.028722
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test constructed URL with path argument
    assert ViafreeIE("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5").url == "http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5"
    # test constructed URL with url argument
    assert ViafreeIE("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5").url == "http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5"
    # test constructed URL with url with part argument

# Generated at 2022-06-24 13:37:07.443359
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert ie.SUFFIX == "/sb/public/asset/"



# Generated at 2022-06-24 13:37:18.815628
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-24 13:37:21.115058
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    e = ViafreeIE()
    assert e.country == 'se'
    assert e.country_code == 'se'
    assert e.country_title == 'Sverige'

# Generated at 2022-06-24 13:37:22.875519
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .tvplay import TVPlayHomeIE
    home_tvplay = TVPlayHomeIE()


# Generated at 2022-06-24 13:37:30.823828
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    y = ViafreeIE("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert y.country == "no" and y.path == "programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"


# Generated at 2022-06-24 13:37:36.901317
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestClass(TVPlayHomeIE):
        @property
        def _content(self):
            data = TVPlayHomeIE._content
            return data

        @property
        def _lang(self):
            lang = TVPlayHomeIE._lang
            return lang

    obj = TestClass()
    assert obj._content is not None
    assert obj._lang is not None


# Generated at 2022-06-24 13:37:45.155140
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()
    assert vf.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5") == True
    assert vf.suitable("http://www.tv3play.lv/parraides/tv3-zinas/572343") == False
    assert vf.IE_NAME == 'viafree'
    assert vf.IE_DESC == 'Viafree'
    assert hasattr(vf, '_VALID_URL')
    assert hasattr(vf, '_TESTS')
    assert hasattr(vf, '_GEO_BYPASS')
    assert hasattr(vf, '_download_json')
    assert hasattr(vf, '_real_extract')

# Generated at 2022-06-24 13:37:56.976542
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-24 13:38:06.196411
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    b = TVPlayIE()
    assert b.IE_NAME == 'mtg'
    assert b.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:13.098190
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == ie.IE_NAME
    assert ie.ie_desc() == ie.IE_DESC
    assert ie.valid_url('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.valid_url('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie.valid_url('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    assert ie.valid_url('http://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    assert ie.valid_

# Generated at 2022-06-24 13:38:23.714457
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert isinstance(tvplay.geo_countries, list)
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:24.872517
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert 2 == len(TVPlayIE._VALID_URL.split("|"))


# Generated at 2022-06-24 13:38:30.009969
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # https://github.com/rg3/youtube-dl/issues/14665
    url = 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'
    from tests import get_testcases
    for t in get_testcases(url).values():
        t.run(TVPlayHomeIE)

# Generated at 2022-06-24 13:38:31.161460
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()

# Generated at 2022-06-24 13:38:37.025909
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    assert ie.IE_NAME == 'mtg'
    assert ie._VALID_URL == 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'

# Generated at 2022-06-24 13:38:40.979911
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    class_ = globals()['TVPlayHomeIE']
    ie = class_(url, {})
    assert(isinstance(ie, class_))


# Generated at 2022-06-24 13:38:45.237129
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_ = TVPlayHomeIE
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    video_id = class_._match_id(url)
    print('tvplay_home_id = %s' % video_id)



# Generated at 2022-06-24 13:38:50.221303
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE(TVPlayIE.IE_NAME, TVPlayIE.IE_DESC, TVPlayIE._VALID_URL, TVPlayIE._TESTS)
    except AssertionError as e:
        assert False, "Unit testing of class TVPlayIE has failed"

# This test is for the main function

# Generated at 2022-06-24 13:38:55.541413
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    instance._match_id('https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    instance._real_extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    instance._real_extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-24 13:39:07.379884
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == 'mtg'
    assert ie.ie_name() == 'mtg'
    assert ie.ie_description() == 'MTG services'
    assert ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie.extract('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')

# Generated at 2022-06-24 13:39:10.740542
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None, "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert ie.country == "no"
    assert ie.path == "programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
