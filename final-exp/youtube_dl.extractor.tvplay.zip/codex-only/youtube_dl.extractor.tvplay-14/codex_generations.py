

# Generated at 2022-06-24 13:29:19.096379
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.IE_NAME = 'mtg'
    ie.IE_DESC = 'mtg services'

# Generated at 2022-06-24 13:29:27.783570
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert ie._TESTS[3]['url'] == 'https://play.tv3.lt/aferistai-10047125'
    assert ie._TESTS[4]['url'] == 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'
    assert ie._TESTS[5]['url']

# Generated at 2022-06-24 13:29:32.786938
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    assert t.url_to_id('https://tv3play.skaties.lv/vinas-melo-labak-10280317/') == '10280317'
    assert t.url_to_id('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354') == '10044354'
    assert t.url_to_id('https://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == '10280317'

# Generated at 2022-06-24 13:29:42.751970
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(_TEST_URL)
    assert ie._VALID_URL == _TEST_URL
    assert ie._TEST == {}
    assert ie._GEO_BYPASS == False
    assert ie._GEO_COUNTRIES == []
    assert ie._FILE_EXTENSIONS == ['flv', 'mp4', 'm3u8']
    assert ie._TITLE_RE == r'(?:title|name|label)'
    assert ie._DESCRIPTION_RE == r'(?:description|message|introtext)'
    assert ie._UPLOAD_DATE_RE == r'(?:date|created|timestamp)'
    assert ie._LANG_RE == r'lang|language'
    assert ie._DIRECT_URL_RE == r'direct_url|directURL'
    assert ie._FORMAT

# Generated at 2022-06-24 13:29:47.382018
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Simple test for constructor of TVPlayIE
    # Input url identifies video to be retrieved
    # Output: Title of a video
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    ie = TVPlayIE()
    video = ie._real_extract(url)
    assert video['title'] == 'Husräddarna S02E07'


# Generated at 2022-06-24 13:29:50.575819
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .. import TVPlayIE
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Unit test to check_valid_url function

# Generated at 2022-06-24 13:29:59.161989
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Unit test for TVPlayIE."""
    url = "http://www.tv3play.lv/parraides/vinas-melo-labak/" + "418113?autostart=true"
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:09.638813
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Unit test for methods
    # - _real_extract
    #   Retrieve the infomation of video "Viņas melo labāk" being played on http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true
    #   The video content is not available in your country due to copyright reasons
    #   Video content: http://tv3.lt/uploads/images/2015/05/18/ba.jpg
    #   Already checked on 20160117
    TVPlayIE()._real_extract("http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true")

# Generated at 2022-06-24 13:30:18.202247
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
        ie = TVPlayIE()
        ie.IE_NAME = 'mtg'
        ie.IE_DESC = 'MTG services'

# Generated at 2022-06-24 13:30:24.879024
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test that valid patterns match.
    valid_patterns = [
        'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
        'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
    ]
    for pattern in valid_patterns:
        match = re.match(ViafreeIE._VALID_URL, pattern)
        assert match is not None, 'Pattern %s should match' % pattern

    # Test that invalid patterns do not match.

# Generated at 2022-06-24 13:30:29.471622
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test 1
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    tvplay = TVPlayIE()
    result = tvplay._real_extract(url)
    assert(result['url'] == 'http://api-tvplay-vh.akamaihd.net/video/data/2/418113/1.mp4')
    assert(result['id'] == '418113')

# Generated at 2022-06-24 13:30:31.975241
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvph = TVPlayHomeIE()
    assert tvph.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-24 13:30:33.925020
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("test")
    assert ie.suitable("test") == True


# Generated at 2022-06-24 13:30:39.737596
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    IE = TVPlayIE(url)
    # Testing if the video ID has been extracted correctly
    video_id = IE.video_id
    assert video_id == '418113'


# Generated at 2022-06-24 13:30:43.968045
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test creating TVPlayHomeIE
    """
    tvpl = TVPlayHomeIE(TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'))
    assert tvpl is not None


# Generated at 2022-06-24 13:30:56.646458
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test constructor."""
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:30:58.724972
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert(instance.IE_NAME=='mtg')
    assert(instance.IE_DESC== 'MTG services')
    

# Generated at 2022-06-24 13:31:01.698186
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE(None)
    assert isinstance(x, TVPlayHomeIE)

# Generated at 2022-06-24 13:31:07.904681
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    cls = type('TVPlayHomeIE', (TVPlayHomeIE,), {})
    cls._TESTS_BASE = [{
        'url': 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/?type=video&autostart=true',
        'only_matching': True,
    }]
    cls._main()


# Generated at 2022-06-24 13:31:09.136761
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-24 13:31:15.485788
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import json
    myurl = 'https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    with open('test_data/test_tvplayhome.json') as json_file:
        data = json.load(json_file)
        assert data['movie']['contentUrl'] is not None
        assert data['assetId'] is not None
        assert data['title']['title'] is not None

# Generated at 2022-06-24 13:31:26.585585
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	with open('tvplay_info.txt', 'r') as f:
		tvplay_info = f.read()

	with open('tvplay_info.json', 'r') as f:
		import json
		tvplay_json = json.load(f)

	with open('tvplay_streams.txt', 'r') as f:
		tvplay_streams = f.read()

	with open('tvplay_streams.json', 'r') as f:
		import json
		tvplay_streams_json = json.load(f)

	IE = TVPlayIE()

	# test function _real_extract
	#print IE._real_extract('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
	

# Generated at 2022-06-24 13:31:35.878695
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
       TVPlayIE._initialize_geo_bypass({'countries': ['DK']})
    except:
        pass
    ie = ViafreeIE()
    ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    try:
        TVPlayIE._initialize_geo_bypass({'countries': ['LV']})
    except:
        pass
    ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-24 13:31:41.481407
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE()
    assert IE.suitable('https://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1') == False
    assert IE.suitable('http://play.viaply.se/program/underhallning/i-like-radio-live/sasong-1') == True



# Generated at 2022-06-24 13:31:46.396934
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test that VideoIE is still in registered IE's
    assert 'mtg:tvplay' in [ie.ie_key() for ie in gen_extractors()]
    assert 'mtg' in [ie.ie_key() for ie in gen_extractors()]
    assert TVPlayIE().ie_key() == 'mtg:tvplay'
    assert ViafreeIE().ie_key() == 'mtg'



# Generated at 2022-06-24 13:31:56.046717
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE._VALID_URL == r'''(?x)
                                    https?://
                                        (?:www\.)?
                                        viafree\.(?P<country>dk|no|se)
                                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                                    '''

# Generated at 2022-06-24 13:32:07.787297
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .test_mtg import mtg
    from .test_common import get_testdata_file
    import json

    mtg_req = mtg.request

    def test_viafree_req(url, **kwargs):
        if url == 'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/programmer/underhallning/det-beste-vorspielet/sesong-2/episode-1':
            return {
                'status_code': 200,
                'content': get_testdata_file('test_viafree_content_se.json', None).read(),
                'headers': {
                    'Content-Type': 'application/json; charset=UTF-8',
                },
            }

# Generated at 2022-06-24 13:32:19.418374
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_name = 'mtg.TVPlayIE'
    mtg_ie = test_TVPlayIE.__module__  # pylint: disable=no-member
    import sys
    # This is required because when this is imported from
    # extractor/__init__.py, it is not accessible by its name
    TVPlayIE = getattr(sys.modules[mtg_ie], class_name)
    # This is required to set self.IE_NAME
    TVPlayIE.ie_key = mtg_ie
    # This is required to set self._VALID_URL
    TVPlayIE.ie_key = class_name
    # This is required to set self.IE_DESC
    TVPlayIE.ie_key = mtg_ie
    ie = TVPlayIE(TVPlayIE.ie_key)
    assert ie

# Generated at 2022-06-24 13:32:21.232488
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception as e:
        assert False, e.message

# Generated at 2022-06-24 13:32:26.650898
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    ie_info = viafreeIE._real_extract(url)

    assert(ie_info['title'] == 'Det beste vorspielet - Sesong 2 - Episode 1')
    assert(ie_info['id'] == '757786')
    assert(ie_info['ext'] == 'mp4')
    assert(ie_info['duration'] == 1116)
    assert(ie_info['timestamp'] == 1471200600)
    assert(ie_info['view_count'] is None)
    assert(ie_info['season_number'] == 2)

# Generated at 2022-06-24 13:32:29.106454
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125')
    assert(i.extract('https://tvplay.tv3.lt/aferistai-10047125') != None)


# Generated at 2022-06-24 13:32:34.141986
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_ie = TVPlayHomeIE()
    assert tvplayhome_ie._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-24 13:32:45.571086
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE()
    if tvplayie.IE_NAME != 'mtg':
        raise ValueError('IE_NAME value different.')
    if tvplayie.IE_DESC != 'MTG services':
        raise ValueError('IE_DESC value different.')

# Generated at 2022-06-24 13:32:47.827403
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Throw exception because it has no data
    with pytest.raises(ExtractorError):
        TVPlayHomeIE()


# Generated at 2022-06-24 13:32:48.775205
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()


# Generated at 2022-06-24 13:32:51.905439
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Verify that the constructor throws an exception when an empty dict is
    # given as the info_dict parameter
    with pytest.raises(TypeError):
        ie = TVPlayHomeIE({})



# Generated at 2022-06-24 13:33:03.151475
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    main = TVPlayIE()
    assert main.IE_NAME == 'mtg'
    assert main.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:08.915393
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE([])
    assert ie.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') is True
    assert ie.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true') is False


# Generated at 2022-06-24 13:33:17.897708
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test videos
    # Kādi ir īri? - Viņas melo labāk
    # http://www.tvplay.lv/parraides/vinas-melo-labak/418113
    test_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113'
    test_id = '418113'
    TVPlayIE()._real_initialize(test_url)
    assert TVPlayIE()._match_id(test_url) == test_id
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:33:22.801398
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    print(viafreeIE.extract('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'))

# Generated at 2022-06-24 13:33:23.989194
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE
    assert ViafreeIE.suitable(URL) == False

# Generated at 2022-06-24 13:33:32.297135
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('some_url') == False
    assert ViafreeIE.suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true') == True
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == True
    assert ViafreeIE.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true') == True
    assert ViafreeIE.suitable('http://www.tv8play.se/program/antikjakten/282756?autostart=true') == True

# Generated at 2022-06-24 13:33:33.430299
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg = TVPlayIE()
    mtg_dict = mtg.IE_DESC
    print(mtg_dict)


# Generated at 2022-06-24 13:33:34.567843
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE('mtg:418113')
    except Exception:
        raise Exception('Unit test of TVPlayIE failed')


# Generated at 2022-06-24 13:33:35.518962
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert not TVPlayIE()._WORKING

# Generated at 2022-06-24 13:33:45.403359
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:33:56.590677
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    def _test_quality(self, expected_id, expected_preference, id, preference, quality_dict):
        assert quality_dict[(id, preference)] == expected_id
        assert quality_dict[(expected_id, expected_preference)] == expected_id
        assert len(quality_dict) == len(set(quality_dict.keys())) + len(set(quality_dict.values()))

    _test_quality(None, 10, 'hls', 0, qualities(['hls', 'medium', 'high']))
    _test_quality(None, 0, 'medium', 10, qualities(['medium', 'high']))
    _test_quality(None, 10, 'low', 0, qualities(['low', 'medium', 'high']))

# Generated at 2022-06-24 13:33:59.498673
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        # init TVPlayIE
        TVPlayIE()
    except Exception as e:
        assert False, "Could not initialize TVPlayIE()."


# Generated at 2022-06-24 13:34:09.801254
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.suitable('www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ie.suitable('http://play.tv2.no/programmer/besok-fra-vest-front/340349')
    assert ie.country == 'no'
    assert ie.path == 'programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-24 13:34:16.088384
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert not TVPlayHomeIE.suitable('http://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317')
    assert TVPlayHomeIE.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/')



# Generated at 2022-06-24 13:34:26.958443
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE('foo')
    assert IE.IE_NAME == 'mtg'
    assert IE.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:34:30.788164
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.extract('http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')


# Generated at 2022-06-24 13:34:34.024282
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(TVPlayIE()._VALID_URL == 'http(s?):\/\/.*?\.tv(3|6|8|10)play\.se\/(?:program\/)?(?:[^\/]+\/)*(\d+)\??')


# Generated at 2022-06-24 13:34:41.903373
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Sanity tests so as to not forget to fill in the constructor of TVPlayIE
    mtg_play_vars = ['TVPlayIE', 'TVPlayIEMtg']
    tvplay_extractor = TVPlayIE('mtg', 'tvplay', mtg_play_vars)

    assert tvplay_extractor._VALID_URL == TVPlayIE._VALID_URL
    assert tvplay_extractor._TESTS == TVPlayIE._TESTS
    assert tvplay_extractor._download_json == InfoExtractor._download_json



# Generated at 2022-06-24 13:34:45.339599
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://play.tv3.lt/aferistai-10047125")
    assert ie.__class__.__name__ == TVPlayHomeIE.__name__

# Generated at 2022-06-24 13:34:48.331258
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    video = ViafreeIE()
    # Should be false, as it is not an URL from any of the sites
    assert not video.suitable('https://www.example.com/')


# Generated at 2022-06-24 13:34:49.405838
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-24 13:34:50.565931
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()



# Generated at 2022-06-24 13:34:58.051730
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # arange
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

    # act
    ie_obj = TVPlayHomeIE(TVPlayHomeIE.suitable)

    # assert
    assert ie_obj._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-24 13:35:03.532680
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE(): 
    video_id = "331267"
    

# Generated at 2022-06-24 13:35:04.540172
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()
    tvplayIE._real_initialize()


# Generated at 2022-06-24 13:35:07.412093
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
        assert True, "Test Passed"
    except Exception as e:
        assert False, "Test Failed: " + str(e)


# Generated at 2022-06-24 13:35:11.619303
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    ('366367', 'mp4', 'Aferistai', 'Aferistai. Kalėdinė pasaka.', 'Aferistai [N-7]', '1 sezonas', 1, 464, 1394209658, '20140307', 18)

# Generated at 2022-06-24 13:35:14.574810
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie._GEO_COUNTRIES == ['NO']


# Generated at 2022-06-24 13:35:18.166041
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        TVPlayHomeIE('http://tvplay.tv3.lt/aferistai-10047125')
    assert len(w) == 1
    assert w[0].category == RemovedInIE11Warning
    assert str(w[0].message) == 'The TVPlayHomeIE can not download videos anymore'

# Generated at 2022-06-24 13:35:29.467128
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    video_id = '757786'
    assert ViafreeIE._VALID_URL == (
        'https?://'
        '(?:www\.)?viafree\.(dk|no|se)/'
        '(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    )
    assert ViafreeIE._TESTS[0]['url'] == url
    assert ViafreeIE._TESTS[0]['info_dict']['id'] == video_id

# Generated at 2022-06-24 13:35:38.128417
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE(None)

    # call with a non-local URL
    instance.suitable('http://www.viafree.dk/')
    assert instance.suitable('https://www.viafree.dk/programmer/livsstil/husraddarna/saeson-2/episode-2')
    assert instance.suitable('http://www.viafree.dk/programmer/livsstil/husraddarna/saeson-2/episode-2')
    assert not instance.suitable('http://www.youtube.com/')
    assert not instance.suitable('http://www.tv4play.se/program/husraddarna/395385')

# Generated at 2022-06-24 13:35:40.216653
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")

# Generated at 2022-06-24 13:35:48.037591
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1') == False
    assert ViafreeIE.suitable('http://playapi.mtgx.tv/v3/videos/757786') == True
    assert ViafreeIE.suitable('https://playapi.mtgx.tv/v3/videos/757786') == True
    assert ViafreeIE.suitable('https://playapi.mtgx.tv/v3/videos/757786?device=tv') == True
    assert ViafreeIE.suitable('http://exp.mtgx.tv/video/757786') == True

# Generated at 2022-06-24 13:35:58.825316
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = "http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true"

    TVPlay = TVPlayIE(extractor=None)
    TVPlay._initialize_geo_bypass({'countries': ['LV']})

# Generated at 2022-06-24 13:36:07.374924
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree.name == 'viafree'
    assert viafree.description, 'Downloads videos from Viafree'
    assert viafree.ie_key() == 'viafree', 'ie_key() for class should return the name of the class'
    assert viafree.ie_key() != 'TVPlay', 'ie_key() for class should return the name of the class and not the parent'

# Generated at 2022-06-24 13:36:13.584717
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    lv_domain = 'https://tvplay.skaties.lv/'
    lt_domain = 'https://play.tv3.lt/'
    ee_domain = 'https://tv3play.tv3.ee/'


# Generated at 2022-06-24 13:36:20.251212
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Test constructor of class ViafreeIE
    from youtube_dl.extractor import gen_extractors
    ext_list = gen_extractors()

    # Results of the constructor should be a list
    assert isinstance(ext_list, list)

    # Verify that some subclass of InfoExtractor is in list
    assert list(filter(lambda x: type(x).__name__ == 'InfoExtractor', ext_list))

    # Verify that ViafreeIE is in list
    assert list(filter(lambda x: type(x).__name__ == 'ViafreeIE', ext_list))

# Generated at 2022-06-24 13:36:25.683522
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE._VALID_URL = r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+(?P<id>\d+)'
    data = TVPlayHomeIE._real_extract(TVPlayHomeIE(),'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert data['id'] == 366367

# Generated at 2022-06-24 13:36:34.428280
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i = ViafreeIE()
    assert i._VALID_URL == r'^(?:https?://)?(?:www\.)?viafree\.(?:dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)$'

# Generated at 2022-06-24 13:36:45.121925
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for url in ['http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1',
                'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2',
                'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
                'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5']:
        m = re.match(r'^https?://(?:www\.)?viafree\.(?:dk|no|se)/.+$', url)
        ie = Viafree

# Generated at 2022-06-24 13:36:52.197691
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'

# Generated at 2022-06-24 13:36:54.506358
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    #TODO: Pass a real url
    assert 'a_password' != ViafreeIE(FakeYDL())._password
    assert 'a_password' != ViafreeIE(FakeYDL(), 'a_password')._password
    assert 'b_password' != ViafreeIE(FakeYDL(), 'a_password')._password

# Generated at 2022-06-24 13:36:58.052771
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test constructor of class TVPlayHomeIE.
    from . import tvplayhome
    assert TVPlayHomeIE() == tvplayhome.TVPlayHomeIE()
    assert TVPlayHomeIE()._VALID_URL == tvplayhome.TVPlayHomeIE._VALID_URL



# Generated at 2022-06-24 13:37:05.044064
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable(TVPlayHomeIE._VALID_URL)
    assert ie.suitable(TVPlayHomeIE._VALID_URL.replace('https://', 'http://'))
    assert ie.suitable(TVPlayHomeIE._VALID_URL.replace('play.tv3.lt', 'tvplay.tv3.lt'))
    assert ie.suitable(TVPlayHomeIE._VALID_URL.replace('play.skaties.lv', 'tvplay.skaties.lv'))
    assert ie.suitable(TVPlayHomeIE._VALID_URL.replace('play.tv3.ee', 'tvplay.tv3.ee'))

# Generated at 2022-06-24 13:37:08.592406
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor from TVPlayIE is not public
    # This test will fail if that changes
    with pytest.raises(TypeError):
        ie = TVPlayIE()



# Generated at 2022-06-24 13:37:09.332472
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:37:16.074526
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie.name == 'Viafree'
    assert ie.country == 'NO'
    assert ie.content_id == '757786'
    assert ie.content_title == 'Det beste vorspielet - Sesong 2 - Episode 1'



# Generated at 2022-06-24 13:37:22.257157
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # The constructor of class TVPlayIE must accept 'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true' as an argument
    try:
        ie = TVPlayIE(TVPlayIE.IE_NAME)
    except TypeError:
        raise TypeError('class TVPlayIE constructor must accept \'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true\' as an argument')


# Generated at 2022-06-24 13:37:23.064230
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-24 13:37:33.362877
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class InfoExtractor(object):
        IE_NAME = 'mtg'
    ie = TVPlayIE(InfoExtractor())

# Generated at 2022-06-24 13:37:34.937256
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    unit_test_class_constructor(
        ViafreeIE, request_mock=get_request_mock(get_content_list_json_data))


# Generated at 2022-06-24 13:37:36.338779
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE is a subclass of InfoExtractor, therefore we can test it using test_InfoExtractor
    test_InfoExtractor(ViafreeIE)

# Generated at 2022-06-24 13:37:42.986502
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test constructor of class TVPlayHomeIE"""
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    tvplayhome = TVPlayHomeIE(url)
    assert tvplayhome.url == url
    assert tvplayhome.asset_id == '10280317'
    assert tvplayhome.country == 'LV'
    assert tvplayhome.valid_countries == ('LV',)
    assert tvplayhome.IE_NAME == 'tvplayhome:lv'



# Generated at 2022-06-24 13:37:44.018876
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-24 13:37:56.136692
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    e = TVPlayIE()
    url = 'https://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    class Test:
        content = None
    test = Test()

    e.extract(url)

    # Test constructor

# Generated at 2022-06-24 13:38:00.381073
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test if __init__ function is working
    tvplay_home_ie = TVPlayHomeIE()
    # test if _VALID_URL is updated
    tvplay_home_ie._VALID_URL = re.compile('(?P<id>-\d+)')


# Generated at 2022-06-24 13:38:04.794436
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie
    assert ie._VALID_URL
    assert ie._TESTS    
    assert ie._GEO_BYPASS
    assert ie._GEO_COUNTRIES
    assert ie._GEO_COUNTRIES == {'lt', 'lv', 'ee'}

# Generated at 2022-06-24 13:38:12.825579
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE().suitable('https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ie == True
    ie = ViafreeIE().suitable('https://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')
    assert ie == False
    ie = ViafreeIE()
    ie._initialize_geo_bypass({'countries': ['DK']})
    assert ie._GEO_COUNTRIES == ['DK']

# Generated at 2022-06-24 13:38:15.115169
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    via = ViafreeIE()
    via._initialize_geo_bypass({})
    assert via

# Generated at 2022-06-24 13:38:24.941990
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-24 13:38:36.863807
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor_class = TVPlayIE
    IE_NAME = 'mtg'
    IE_DESC = 'MTG services'

# Generated at 2022-06-24 13:38:38.594108
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE().ie_key() == 'Viafree'


# Generated at 2022-06-24 13:38:46.017646
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Required arguments: vid, title, country
    with pytest.raises(TypeError): ViafreeIE()

    # test default parameters
    viafree = ViafreeIE('123456', 'test video', 'no')
    assert viafree.country == 'no'

    # test that the class correctly extract the country from the url
    viafree = ViafreeIE('123456', 'test video', 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree.country == 'dk'

# Generated at 2022-06-24 13:38:53.906763
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from . import TVPlayIE
    from . import ViafreeIE
    from . import TVPlayHomeIE
    m = TVPlayIE._VALID_URL_TEMPLATE % r'(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert TVPlayHomeIE._VALID_URL == m
    m = ViafreeIE._VALID_URL_TEMPLATE % r'viafree\.(?:dk|no|se)/.*?(?<!\bprogram)(?:/(?:programmer|program)/[^/?#&]+)'
    assert TVPlayHomeIE._VALID_URL == m + '|' + m.replace('/programmer/', '/program/')

# Generated at 2022-06-24 13:38:58.957850
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE will fail without a valid browser cookie. Test that a
    # empty browser cookie will raise an error.
    with pytest.raises(ExtractorError) as excinfo:
        ViafreeIE()._download_webpage(
            'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', None,
            fatal=False, headers={
                'Cookie':
                '',
            })
    assert 'Cookie header is invalid' in str(excinfo)

# Generated at 2022-06-24 13:39:03.328409
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t = ViafreeIE()
    assert t.IE_NAME == 'mtg'
    assert t._VALID_URL == '%s://www\.(?:viafree\.%s|viafree\.skaties\.lv)/(?:program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-24 13:39:07.144546
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    '''Unit test for constructor of class TVPlayHomeIE'''
    from . import extractors
    ie = get_info_extractor_for_url(
        extractors,
        "https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert isinstance(ie, TVPlayHomeIE)


# Generated at 2022-06-24 13:39:11.064591
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.geo_verification_headers()
    ie.geo_bypass()
    assert ie.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert ie.suitable('http://play.tv3.se/program/husraddarna/395385?autostart=true') == False
