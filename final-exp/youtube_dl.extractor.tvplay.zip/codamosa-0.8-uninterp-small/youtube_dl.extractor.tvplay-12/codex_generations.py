

# Generated at 2022-06-26 13:02:37.089858
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
    except Exception as e:
        print(str(e))

# Generated at 2022-06-26 13:02:38.435616
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:39.309301
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:42.306402
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_test_1 = ViafreeIE()

test_cases = {
    'test_case_0' : test_case_0,
    'test_ViafreeIE' : test_ViafreeIE
}

# Generated at 2022-06-26 13:02:43.076568
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:43.912715
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:46.927342
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_2 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:47.787096
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_i_e = ViafreeIE()

# Generated at 2022-06-26 13:02:58.596243
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-26 13:02:59.659864
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()

# Generated at 2022-06-26 13:03:47.678914
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_equal(t_v_play_home_i_e_0.IE_NAME, 'TVPlayHomeIE')
    assert_equal(t_v_play_home_i_e_0.IE_DESC, 'TVPlay Home')
    assert_equal(t_v_play_home_i_e_0.IE_DESC, 'TVPlay Home')
    assert_equal(t_v_play_home_i_e_0.VALID_URL,
                 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P!')

# Generated at 2022-06-26 13:03:50.263433
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()
    from .ttest.test_Class_T_V_play_home_i_e import case_0
    case_0(t_v_play_home_i_e_0)

# Generated at 2022-06-26 13:03:54.879724
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    object_TVPlayHomeIE = TVPlayHomeIE()
    print(TVPlayHomeIE._VALID_URL)
    print(TVPlayHomeIE._TESTS)


# Generated at 2022-06-26 13:03:56.346012
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_case_0()


# Generated at 2022-06-26 13:03:58.309984
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:04:02.758679
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:04:04.706414
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # global tvplay_ie
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-26 13:04:06.741531
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # stub
    url = ''
    TVPlayHomeIE()


# Generated at 2022-06-26 13:04:08.053711
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:04:09.579322
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(TypeError):
        TVPlayHomeIE()

# Generated at 2022-06-26 13:05:21.485045
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # First test case
    t_v_play_i_e_0 = TVPlayIE()

# Generated at 2022-06-26 13:05:32.626507
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert isinstance("url", TVPlayHomeIE()._VALID_URL)
    assert isinstance("url", TVPlayHomeIE()._TESTS)
    assert isinstance("url", TVPlayHomeIE()._TESTS)
    assert isinstance("url", TVPlayHomeIE()._TESTS)
    assert isinstance("url", TVPlayHomeIE()._TESTS)
    assert isinstance("url", TVPlayHomeIE()._TESTS)
    assert isinstance("url", TVPlayHomeIE()._TESTS)


# Generated at 2022-06-26 13:05:43.422423
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = TVPlayIE._VALID_URL
    url_for_test = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'

    m = re.match(url, url_for_test)
    video_id = m.group('id')

    result = TVPlayIE._real_extract(TVPlayIE(), url_for_test)
    assert video_id == result['id']

# Simple unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:05:44.820637
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:05:51.587006
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_i_e = ViafreeIE()
    # Check url
    assert_equal(v_i_e._VALID_URL, 'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)')
    # Check country
    assert_equal(v_i_e._GEO_COUNTRIES, ['DK', 'NO', 'SE'])
    # Check name
    assert_equal(v_i_e._NAME, 'Viafree')

# Generated at 2022-06-26 13:06:00.009438
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # unit tests for TVPlayIE (1 of 2)
    # constructor
    assert(isinstance(TVPlayIE(), InfoExtractor))
    # unit tests for TVPlayIE (2 of 2)
    # methods
    assert(isinstance(TVPlayIE._real_extract(), dict))
    assert(TVPlayIE._VALID_URL() is None)
    assert(TVPlayIE._TESTS() is None)


# Generated at 2022-06-26 13:06:01.217726
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i_e = ViafreeIE()


# Generated at 2022-06-26 13:06:02.013509
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:06:07.175173
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    t_v_play_i_e_1 = TVPlayIE()
    t_v_play_i_e_1.suitable(url)
    t_v_play_i_e_1.get_urls(url)
    t_v_play_i_e_1.extract(url)
    t_v_play_i_e_1.extract_start_urls(url)
    t_v_play_i_e_1._real_extract(url)


# Generated at 2022-06-26 13:06:09.229748
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:08:53.182655
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()


# Generated at 2022-06-26 13:08:54.668117
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE() is not None

# Generated at 2022-06-26 13:08:57.183984
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_raises(TypeError,TVPlayHomeIE)


# Generated at 2022-06-26 13:09:03.454676
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert isinstance(TVPlayIE, InfoExtractor)
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'
    assert TVPlayIE._VALID_URL == 's'


# Generated at 2022-06-26 13:09:07.292695
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-26 13:09:10.003615
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE('https://viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')


# Generated at 2022-06-26 13:09:14.766482
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert isinstance(TVPlayIE(), TVPlayIE)



# Generated at 2022-06-26 13:09:18.905111
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        TVPlayIE()
    except TypeError:
        assert False
    else:
        assert True

# Generated at 2022-06-26 13:09:31.669793
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # For testing use the following string as the argument to TVPlayIE,
    # the value will be passed to _VALID_URL regex.
    """
    For testing use the following string as the argument to TVPlayIE, 
    the value will be passed to _VALID_URL regex.
    """
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:09:33.268499
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_i_e = TVPlayIE()
