

# Generated at 2022-06-26 13:02:33.592092
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:35.095216
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:35.621868
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:02:36.578978
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE()
    return


# Generated at 2022-06-26 13:02:38.149408
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:39.623454
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	assert TVPlayIE._VALID_URL, 'The regex does not match any of the video URLs'

# Generated at 2022-06-26 13:02:42.916220
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    t_v_play_home_i_e_0 = TVPlayHomeIE()
    t_v_play_home_i_e_1 = TVPlayHomeIE()

# test for method _real_extract in class TVPlayHomeIE

# Generated at 2022-06-26 13:02:46.235383
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

if __name__ == '__main__':
    test_case_0()
    test_ViafreeIE()

# Generated at 2022-06-26 13:02:48.125630
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:58.990009
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:03:19.257741
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE()

# Generated at 2022-06-26 13:03:29.307633
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE = TVPlayIE._TVPlayIE
    # Test construction of TVPlayIE
    ie = TVPlayIE(None)

    # Test _VALID_URL.

# Generated at 2022-06-26 13:03:30.778833
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:03:37.389022
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._initialize_geo_bypass({'countries': ['LV']})
    ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')


# Generated at 2022-06-26 13:03:49.567771
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafree_ie.suitable('http://www.viafree.se/programmer/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert viafree_ie.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert viafree_ie.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == False


# Generated at 2022-06-26 13:03:53.205673
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-26 13:03:55.197877
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    for url in ie._TESTS[0]["url"], ie._TESTS[1]["url"], ie._TESTS[2]["url"]:
        ie.suitable(url)


# Generated at 2022-06-26 13:03:59.693536
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        # Test for https://github.com/rg3/youtube-dl/issues/11402
        ctl = ViafreeIE(None)
        assert ctl.IE_NAME == 'Viafree'
    except (AttributeError, AssertionError) as e:
        raise AssertionError(e)



# Generated at 2022-06-26 13:04:05.305193
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    '''Testing constructor of class ViafreeIE'''
    fields = ('url',)
    # Test missing parameters
    with pytest.raises(TypeError):
        ViafreeIE()
    # Test all parameters
    ViafreeIE(url='http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')

# Generated at 2022-06-26 13:04:09.529318
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert TVPlayIE._VALID_URL == ie._VALID_URL
    assert TVPlayIE.IE_NAME == ie.IE_NAME
    assert TVPlayIE.IE_DESC == ie.IE_DESC


# Generated at 2022-06-26 13:04:52.535962
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert_equal(ie._VALID_URL, ie.VALID_URL)
    assert_equal(ie._TESTS, ie.TESTS)
    assert_equal(ie._GEO_BYPASS, ie.GEO_BYPASS)
    assert_equal(ie._WORKING, ie.WORKING)



# Generated at 2022-06-26 13:05:04.202905
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-26 13:05:10.253233
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://play.tv3.lt/aferistai-10047125'
    try:
        ie = TVPlayHomeIE()
        assert re.match(ie._VALID_URL, url)
    except AssertionError as e:
        assert False, str(e)



# Generated at 2022-06-26 13:05:23.994204
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:05:35.982877
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Create an object of TVPlayIE class
    tvplay = TVPlayIE()

    # For each test, returns dictionary with result and expected data
    for test in tvplay._TESTS:

        # Extract the id and get the correct result
        video_id = tvplay._match_id(test['url'])
        tvplay._download_json(
                "http://playapi.mtgx.tv/v3/videos/%s" % video_id, video_id, "Downloading video JSON")

        # Check if the video was downloaded succesfully, if not raise exception
        if video_id is None:
            raise Exception('Video not downloaded')

        # Return info from the video
        info = tvplay._real_extract(test['url'])

        # If test contains only_matching return true or false depending if it matches


# Generated at 2022-06-26 13:05:44.699955
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    a = TVPlayHomeIE()

    assert a.name == 'TVPlayHome'


# Generated at 2022-06-26 13:05:53.395505
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE({})
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:06:03.072507
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    test_urls = [
        'https://play.tv3.lt/aferistai-10047125',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354'
    ]
    for url in test_urls:
        ie.suitable(url)

# Generated at 2022-06-26 13:06:05.759991
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    inst = TVPlayHomeIE()
    try:
        TVPlayHomeIE._match_id(inst, url)
        assert True
    except:
        assert False


# Generated at 2022-06-26 13:06:17.773055
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()
    assert test.IE_NAME == 'mtg'
    assert test.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:07:57.466118
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    mtg = TVPlayIE()
    assert mtg.IE_NAME == 'mtg'
    assert mtg.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:08:09.216753
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:08:19.524174
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()
    assert isinstance(tvplayIE, TVPlayIE)
    assert hasattr(tvplayIE, '_VALID_URL')
    assert hasattr(tvplayIE, '_download_json')
    assert hasattr(tvplayIE, '_match_id')
    assert hasattr(tvplayIE, '_initialize_geo_bypass')
    assert hasattr(tvplayIE, '_real_extract')


# Generated at 2022-06-26 13:08:21.254952
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')

# Generated at 2022-06-26 13:08:29.208218
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    try:
        TVPlayHomeIE(url)
    except Exception as ex:
        import traceback
        if hasattr(ex, '__traceback__'):
            tb = ex.__traceback__
        else:
            tb = traceback.extract_tb(ex.__traceback__)
        raise AssertionError(
            'Unexpected error while constructing TVPlayHomeIE(%r) '
            '\nTraceback: %s' % (url, ''.join(traceback.format_tb(tb))))
    else:
        assert True

# Generated at 2022-06-26 13:08:34.418625
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('tvplay')
    assert ie.name == 'TVPlayHome'
    assert ie.domain == 'tvplay.tv3.lt'
    assert ie.provider_name == 'TV3'
    assert ie.provider_id == 'TV3'

# Generated at 2022-06-26 13:08:49.638145
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-26 13:09:03.515781
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Test constructor of class TVPlayHomeIE.
    """

    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return super(TestTVPlayHomeIE, self)._real_extract(url)

    tvplay_home_ie = TestTVPlayHomeIE('TVPlayHomeIE')
    assert tvplay_home_ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)', "Test constructor of class TVPlayHomeIE failed"

# Generated at 2022-06-26 13:09:13.297377
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test case for constructor
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    from youtube_dl.extractor import gen_extractors
    tvplay_ie = gen_extractors(TVPlayIE._VALID_URL)[0](TVPlayIE._VALID_URL, {})
    ie = tvplay_ie.suitable(url) and tvplay_ie
    for field in dir(ie):
        if field.startswith('_') or field in ['suitable', 'working', 'IE_DESC', 'IE_NAME', 'webpage_url_basename']:
            continue
        print('%s: %s' % (field, repr(getattr(ie, field))))

# Unit test to get information of the videos

# Generated at 2022-06-26 13:09:20.667773
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        import cgi
        cgi.escape
        class_ = ViafreeIE
    except NameError:
        from html.escape import html_escape
        class_ = ViafreeIE._get_suitable_class(html_escape)

