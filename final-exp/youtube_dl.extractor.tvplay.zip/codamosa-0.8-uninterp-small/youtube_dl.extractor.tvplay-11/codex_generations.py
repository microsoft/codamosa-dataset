

# Generated at 2022-06-26 13:02:37.963136
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:02:40.593407
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_i_e_1 = TVPlayHomeIE()
    assert(t_v_play_i_e_1 is not None)

if __name__ == "__main__":
    test_case_0()
    test_TVPlayHomeIE()

# Generated at 2022-06-26 13:02:43.258937
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    t_v_play_i_e.IE_NAME
    t_v_play_i_e.IE_DESC



# Generated at 2022-06-26 13:02:44.258449
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:02:46.073774
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_ViafreeIE = ViafreeIE()

# Generated at 2022-06-26 13:02:56.859674
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test valid cases
    assert TVPlayHomeIE._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert TVPlayHomeIE._VALID_URL.match(url)
    assert TVPlayHomeIE._VALID_URL.match(url).group('id') == '10047125'
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert TVPlayHomeIE._VALID_

# Generated at 2022-06-26 13:03:07.511108
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1') == True
    assert ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true') == False
    assert ViafreeIE.suitable('http://play.tv4.se/program/lovasagor-fran-sodra-sverige-1/631192/?autostart=true') == False
    assert ViafreeIE.suitable('http://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true') == False

# Generated at 2022-06-26 13:03:11.842742
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.eu/parraides/vinas-melo-labak/418113?autostart=true'
    t_v_play_i_e = TVPlayIE()
    t_v_play_i_e._match_id(url)

if __name__ == '__main__':
    test_TVPlayIE()

# Generated at 2022-06-26 13:03:14.346285
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    z_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:16.627128
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:52.994798
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:03:54.221057
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_2 = TVPlayIE()


# Generated at 2022-06-26 13:03:58.610490
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    if not ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'):
        t_v_play_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:04:12.699129
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie = TVPlayIE()

# Generated at 2022-06-26 13:04:14.785619
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_ie = TVPlayHomeIE()


# Generated at 2022-06-26 13:04:24.815028
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test for valid url
    valid_url = 'https://tvplay.skaties.lv/vinas-melo-labak-10280317/'
    t_v_play_home_i_e_valid_url = TVPlayHomeIE()

    # Test for invalid url
    invalid_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    t_v_play_home_i_e_invalid_url = TVPlayHomeIE()

    assert t_v_play_home_i_e_valid_url._VALID_URL == t_v_play_home_i_e_invalid_url._VALID_URL

    assert t_v_play_home_i_e_valid_url._VALID

# Generated at 2022-06-26 13:04:26.563599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ve = ViafreeIE()

# Generated at 2022-06-26 13:04:29.849797
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        test_case_0()
    except Exception as e:
        print('Exception: ' + str(e))

test_TVPlayIE()

# Generated at 2022-06-26 13:04:31.037448
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:04:42.457559
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert t_v_play_i_e_0.geo_countries == []
    assert t_v_play_i_e_0.cache == {}
    assert t_v_play_i_e_0.IE_NAME == 'mtg'
    assert t_v_play_i_e_0.IE_DESC == 'MTG services'
    assert re.match(t_v_play_i_e_0._VALID_URL, 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true', 0)

# Generated at 2022-06-26 13:05:50.994262
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie_0 = ViafreeIE()


# Generated at 2022-06-26 13:05:51.710093
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()


# Generated at 2022-06-26 13:05:53.093479
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tv_play_ie = ViafreeIE()


# Generated at 2022-06-26 13:05:58.164225
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    file_url = "www.viafree.dk"
    viafreeIE = ViafreeIE(file_url)
    assert viafreeIE is not None


# Generated at 2022-06-26 13:06:05.896883
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    testCase = ViafreeIE()

if __name__ == '__main__':
    #test_case_0()
    #test_ViafreeIE()
    ext = TVPlayIE()
    res = ext.suitable('http://tvplay.skaties.lv/parraides/tv3-zinas/760183')
    if res:
        print("Found")
    else:
        print("Not found")
    #res = ext._real_extract('http://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true')
    #res = ext._real_extract('https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true')
    #res = ext._real_extract('http://

# Generated at 2022-06-26 13:06:08.999717
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:06:17.533589
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)
    assert TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[0]['url'])
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[1]['url'])
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[2]['url'])
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[3]['url'])
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[4]['url'])
    assert not TVPlayHomeIE.suitable(TVPlayHomeIE._TESTS[5]['url'])


# Generated at 2022-06-26 13:06:19.061009
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    result = InfoExtractor().suitable("http://tvplay.tv3.lv/")
    assert result == False


# Generated at 2022-06-26 13:06:21.176378
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = TVPlayIE(None, None)

# Generated at 2022-06-26 13:06:23.342753
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:09:03.770830
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Constructor test
    TVPlayHomeIE()


# Generated at 2022-06-26 13:09:04.315634
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:09:05.558593
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:09:07.562602
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:09:11.732299
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = ViafreeIE()
    t_v_play_i_e_1 = ViafreeIE()
    t_v_play_i_e_2 = ViafreeIE()


# Generated at 2022-06-26 13:09:16.101263
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()

# Generated at 2022-06-26 13:09:19.460883
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:09:20.668060
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i_e = ViafreeIE()

# Generated at 2022-06-26 13:09:23.098124
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = "http://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/"
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Test for method _real_extract for TVPlayIE

# Generated at 2022-06-26 13:09:28.512404
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_free_i_e = ViafreeIE()
    for test in v_free_i_e._TESTS:
        assert re.match(v_free_i_e._VALID_URL, test['url'])
        print("testing: " + test['url'])