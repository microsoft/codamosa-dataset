

# Generated at 2022-06-26 13:02:34.730832
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlay_I_E_0 = TVPlayIE()


# Generated at 2022-06-26 13:02:41.824375
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_raises_regex(TVPlayHomeIE, ValueError, 'Invalid URL', TVPlayHomeIE, 'https://tvplay.tv3.lt/vinas-melo-labak-10280317')
    assert_raises_regex(TVPlayHomeIE, ValueError, 'Invalid URL', TVPlayHomeIE, 'https://tvplayhome.tv3.lt/vinas-melo-labak-10280317')
    assert_raises_regex(TVPlayHomeIE, ValueError, 'Invalid URL', TVPlayHomeIE, 'https://tvplay.tv3.lt/vinas-melo-labak')

# Generated at 2022-06-26 13:02:42.762682
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()

# Generated at 2022-06-26 13:02:43.694802
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_unit_test = ViafreeIE()

# Generated at 2022-06-26 13:02:47.211552
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    try:
        tvplay_ie = TVPlayIE()
        tvplay_ie_context = TVPlayIE(context=0)
        print("\nSuccessfully instantiated TVPlayIE object\n")
    except:
        print("\nFailed to instantiate TVPlayIE object\n")

test_case_0()
test_TVPlayIE()

# Generated at 2022-06-26 13:02:48.885070
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test case 0
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:53.505996
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_equal(TVPlayHomeIE._VALID_URL, r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')


# Generated at 2022-06-26 13:02:54.538453
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

test_case_0()

# Generated at 2022-06-26 13:02:55.911430
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_1 = TVPlayIE()



# Generated at 2022-06-26 13:02:56.916502
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:03:16.545284
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert callable(TVPlayHomeIE)


# Generated at 2022-06-26 13:03:20.700686
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_case_0()

# ##############################################################################################################
# ####################################     IPLDOWNLOADER     ###################################################
# ##############################################################################################################

# Generated at 2022-06-26 13:03:23.036258
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    via_free_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:03:30.807727
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_raises_regex(RegexMatchError, "Couldn't find urls", t_v_play_home_i_e_0.suitable, "http://google.com")
    assert t_v_play_home_i_e_0.suitable("https://play.tv3.lt/aferistai-10047125")
    assert_raises_regex(ExtractorError, "Error downloading", t_v_play_home_i_e_0._real_extract, "https://play.tv3.lt/aferistai-10047125")

# Generated at 2022-06-26 13:03:33.863420
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_home_i_e_1 = ViafreeIE()



# Generated at 2022-06-26 13:03:37.912407
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-26 13:03:39.457726
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:03:40.363816
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

# Generated at 2022-06-26 13:03:43.818902
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:45.435013
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:04:08.292457
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true'
    TVPlayIE._match_id(url)
    return


# Generated at 2022-06-26 13:04:21.979681
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:04:26.099588
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    to_test = {
        'https://play.tv3.lt/aferistai-10047125': 'tv3.lt',
        'https://tv3play.skaties.lv/vinas-melo-labak-10280317': 'skaties.lv',
        'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354': 'tv3.ee'
    }
    for url in to_test:
        ie = TVPlayHomeIE(url)
        assert ie._GEO_BYPASS == to_test[url]

# Generated at 2022-06-26 13:04:34.615811
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    x = TVPlayIE()
    x._initialize_geo_bypass({'countries': ['LV']})
    video = x._real_extract(url)
    assert video['id'] == '418113'
    assert video['title'] == 'Kādi ir īri? - Viņas melo labāk'
    assert len(video['formats']) > 0
    assert video['duration'] == 25
    assert video['timestamp'] == 1406097056
    assert video['view_count'] == 159
    assert video['age_limit'] == 0
    assert video['series'] == 'Viņas melo labāk'

# Generated at 2022-06-26 13:04:38.356937
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test constructor for class TVPlayIE
    ie = TVPlayIE()
    assert isinstance(ie, TVPlayIE)
    assert isinstance(ie, InfoExtractor)


# Generated at 2022-06-26 13:04:45.350037
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    Video = TVPlayIE(
        'mtg:418113',
        lambda url: {
            'url': url,
            'status_code': 200,
            'content': 'x'
        },
        lambda url: {
            'url': url,
            'status_code': 200,
            'content': 'x'
        }
    )._real_extract(
        'mtg:418113'
    )
    assert Video['id'] == '418113'
    assert Video['title'] == 'Kādi ir īri? - Viņas melo labāk'
    assert Video['description'] == 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.'
    assert Video['series'] == 'Viņas melo labāk'
    assert Video

# Generated at 2022-06-26 13:04:54.307526
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tvplay_ie = TVPlayIE()
    viafree_ie = ViafreeIE()
    assert tvplay_ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert tvplay_ie.suitable('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')
    assert tvplay_ie.suitable('http://play.viareggio.it/v/b/0ejd6r2m6b/il-figlio-della-notte-il-gioco-della-verita')

# Generated at 2022-06-26 13:05:04.875246
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Test to see if MediaExtractor of class TVPlayHomeIE
    returns expected values.

    """
    return_value = {'title': 'Aferistai',
                    'description': 'Aferistai. Kalėdinė pasaka.',
                    'series': 'Aferistai [N-7]',
                    'season_number': 1,
                    'season': '1 sezonas',
                    'duration': 464,
                    'id': '366367',
                    'ext': 'mp4',
                    'timestamp': 1394209658,
                    'upload_date': '20140307',
                    'age_limit': 18}
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvphie = TVPlayHomeIE

# Generated at 2022-06-26 13:05:06.328273
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    unit_test_init(ViafreeIE)



# Generated at 2022-06-26 13:05:12.006497
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    expected_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'

    assert ie.url == expected_url


# Generated at 2022-06-26 13:05:52.142205
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE()
    assert a.IE_NAME in a.ie_key()
    assert a.IE_DESC in a.ie_key()
    assert a.ie_key() in ("TVPlayIE", "TVPlay", None)


# Generated at 2022-06-26 13:06:04.919748
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Constructing instance of class TVPlayIE
    """
    ie = TVPlayIE()
    # test password protected video
    tvplay_password_protected_video = 'https://tvplay.skaties.lv/parraides/vinas-melo-labak/418113/?autostart=true'
    # test geo restricted video
    tvplay_geo_restricted_video = 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'
    # test video with httpurl
    tvplay_video_with_httpurl = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    # test video with httpsurl

# Generated at 2022-06-26 13:06:06.826344
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()



# Generated at 2022-06-26 13:06:10.575914
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('tv3play.no', 'https://www.viacom.com/')


# Generated at 2022-06-26 13:06:18.410569
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.suitable('https://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')

# Generated at 2022-06-26 13:06:23.249202
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    #test TVPlayIE
    obj1 = TVPlayIE()
    assert obj1._VALID_URL == r'(?x)http://(?:www\.)?tvplay\.skaties\.lv/parraides/.+'
    assert obj1._TESTS[0]['url'] == 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    assert obj1._TESTS[0]['md5'] == 'a1612fe0849455423ad8718fe049be21'
    assert obj1._TESTS[0]['info_dict']['id'] == '418113'

# Generated at 2022-06-26 13:06:33.324759
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class TestTVPlayHomeIE(TVPlayHomeIE):
        def _real_extract(self, url):
            return super(TestTVPlayHomeIE, self)._real_extract(url)
    ie = TestTVPlayHomeIE()
    # Testing a normal episode url
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'

# Generated at 2022-06-26 13:06:39.321037
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import unit_test
    ViafreeIE().IE_NAME
    unit_test.run(ViafreeIE)


# Generated at 2022-06-26 13:06:42.272727
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.IE_NAME == 'mtg:tvplayhome'


# Generated at 2022-06-26 13:06:53.202260
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'tvplayhome'
    assert TVPlayHomeIE.suitable('http://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert TVPlayHomeIE.suitable('https://tv3play.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-26 13:08:28.645150
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    i = TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    assert i._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-26 13:08:31.469599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test = ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert test.preference == 1
    assert test.name == 'Viafree'



# Generated at 2022-06-26 13:08:35.660188
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    object_ = TVPlayIE()
    assert object_.name == 'MTG'
    assert object_.ie_key() == 'MTG'
    assert object_.ie_label() == 'MTG'



# Generated at 2022-06-26 13:08:37.891149
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()

# Generated at 2022-06-26 13:08:43.877212
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    p = TVPlayHomeIE('TVPlayHomeIE')
    result = p.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert(result == True)



# Generated at 2022-06-26 13:08:46.325431
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == TVPlayIE._VALID_URL
    assert ie._TESTS == TVPlayIE._TESTS


# Generated at 2022-06-26 13:08:49.642010
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    URL = 'http://www.tv3.lt/programos/pardavimas-kaip-profesija/408845?autostart=true'
    print(TVPlayIE._VALID_URL)
    print(URL)
    print(TVPlayIE._VALID_URL == URL)
    assert TVPlayIE._VALID_URL == URL


# Generated at 2022-06-26 13:09:01.919320
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.suitable(None)
    assert ie.suitable('https://www.viafree.se/program/entertainment/hells-kitchen-sverige-2/season-2/episode-1')
    assert not ie.suitable('https://play.tv3.lt/programa/senis-uz-mergaites-2/sesija-1-serija-1')
    assert ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

# Generated at 2022-06-26 13:09:03.698620
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')


# Generated at 2022-06-26 13:09:05.212122
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE(TVPlayHomeIE._create_ie_instance())._VALID_URL == TVPlayHomeIE._VALID_URL