

# Generated at 2022-06-26 13:02:45.983098
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()
    assert t_v_play_i_e_0.IE_DESC == 'MTG services', 'Expected attribute IE_DESC to be MTG services but is %s' %t_v_play_i_e_0.IE_DESC
    assert t_v_play_i_e_0.IE_NAME == 'mtg', 'Expected attribute IE_NAME to be mtg but is %s' %t_v_play_i_e_0.IE_NAME

# Generated at 2022-06-26 13:02:49.304291
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    args = ('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true',)
    TVPlayIE(*args)


# Generated at 2022-06-26 13:02:52.749922
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test case 1
    assert TVPlayIE().IE_NAME == 'mtg'
    # Test case 2
    assert TVPlayIE().IE_DESC == 'MTG services'


# Generated at 2022-06-26 13:02:53.773004
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    tv_play_i_e = ViafreeIE()

# Generated at 2022-06-26 13:02:55.521885
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    extractor = ViafreeIE()
    assert isinstance(extractor, ViafreeIE)

# Generated at 2022-06-26 13:03:01.410120
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert not ViafreeIE.suitable("https://tvplay.skaties.lv/parraides/vinas-melo-labak/418113")

# Generated at 2022-06-26 13:03:04.143789
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_ = TVPlayIE()

    assert TVPlayIE._VALID_URL == t_v_play_i_e_.VALID_URL



# Generated at 2022-06-26 13:03:06.093542
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_i_e = TVPlayIE()
    assert tv_play_i_e



# Generated at 2022-06-26 13:03:07.050245
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-26 13:03:08.319618
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:03:41.825220
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:03:46.525462
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from ytdl.extractor.common import InfoExtractor
    t_v_play_i_e_1 = TVPlayIE()
    assert isinstance(t_v_play_i_e_1, InfoExtractor)


# Generated at 2022-06-26 13:03:49.375545
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TVPlayIE(InfobaseIE, InfoExtractor)

    # instantiate the object
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:03:50.905064
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:53.952080
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from m_librarian.extractors.viafree import ViafreeIE
    v_i_e = ViafreeIE()


# Generated at 2022-06-26 13:03:55.930481
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE == TVPlayIE()


# Generated at 2022-06-26 13:04:05.799157
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Unit test for constructor of class TVPlayIE
    try:
        TVPlayIE()
    except ZeroDivisionError:
        assert('Sucessfully raised an ' + 'ZeroDivisionError')
    except AttributeError:
        assert ('Sucessfully raised an ' + 'AttributeError')
    except NotADirectoryError:
        assert ('Sucessfully raised an ' + 'NotADirectoryError')
    except ImportError:
        assert ('Sucessfully raised an ' + 'ImportError')
    except OSError:
        assert ('Sucessfully raised an ' + 'OSError')
    except UnicodeDecodeError:
        assert ('Sucessfully raised an ' + 'UnicodeDecodeError')
    except UnicodeEncodeError:
        assert ('Sucessfully raised an ' + 'UnicodeEncodeError')

# Generated at 2022-06-26 13:04:06.984309
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test = TVPlayIE()


# Generated at 2022-06-26 13:04:07.932320
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_free_i_e = ViafreeIE()

# Generated at 2022-06-26 13:04:09.129599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:05:18.851217
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'
    assert TVPlayIE._VALID_URL != None
    assert TVPlayIE._TESTS != None


# Generated at 2022-06-26 13:05:26.450464
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tv3play.tv3.ee/cool-d-ga-mehhikosse-10044354'
    t_v_play_home_i_e = TVPlayHomeIE()
    assert t_v_play_home_i_e._match_id(url) == '10044354'
    assert t_v_play_home_i_e._VALID_URL is not None
    assert t_v_play_home_i_e._TESTS is not None
    assert t_v_play_home_i_e.suitable(url)
    # cannot test the method since it calls downloader
    # assert t_v_play_home_i_e._real_extract(url) is not None

test_case_0()
test_TVPlayHomeIE()

# Generated at 2022-06-26 13:05:28.180675
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:05:29.808120
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE()


# Generated at 2022-06-26 13:05:31.432212
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:05:33.807065
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import sys
    t_v_play_i_e = TVPlayIE()
    yield t_v_play_i_e._real_extract


# Generated at 2022-06-26 13:05:35.809656
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:05:37.484123
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:05:39.024552
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_case_0()

# Generated at 2022-06-26 13:05:41.317531
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayerhome = TVPlayHomeIE()



# Generated at 2022-06-26 13:06:58.883760
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:07:00.510692
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    inst = ViafreeIE()



# Generated at 2022-06-26 13:07:06.541373
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE

    video_id = '3a14fc0f'
    stream_href = 'https://viafree-hls-prod-eu01.viafree.io/viafree-content/v1/se/path/3a14fc0f/index.m3u8'
    guid = '537009'
    self = ViafreeIE()
    BypassDNSObject = self.BypassDNS
    self.BypassDNS = _BypassDNSObject()
    collections = self.collections
    self.collections = []

    self.geo_bypass = True
    video = self._real_extract(
        'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-1')

# Generated at 2022-06-26 13:07:16.158629
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    roku_url = 'https://play.tv3.lt/aferistai-10047125'
    tv3play_skaties_lv_url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    tv3play_tv3_ee_url = 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    tv3play_skaties_lv_url_without_slashes = 'https://tv3play.skaties.lv/vinas-melo-labak-10280317'

# Generated at 2022-06-26 13:07:26.442368
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true'
    test_match = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    test_not_match = 'https://tv3play.tv3.ee/sisu/kodu-keset-linna/238551?autostart=true'
    tvplay = TVPlayIE(None)
    assert tvplay._match_id(test_url) == '238551'
    assert tvplay._match_id(test_not_match) != '238551'
    assert tvplay._match_id(test_match) == '395385'


# Generated at 2022-06-26 13:07:32.829551
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-26 13:07:38.358256
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Create instance of class
    ie = ViafreeIE()

    # Check if _VALID_URL matches
    (url, video_id, items) = (ie._VALID_URL, '757786', ie._TESTS)
    for url_ in items:
        m = re.match(url, url_['url'])
        assert m is not None, 'Invalid ' + url + ' for: ' + url_['url'] + '\npattern: ' + items[0]['url']

# Generated at 2022-06-26 13:07:50.932316
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE.suitable('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    TVPlayIE.suitable('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    TVPlayIE.suitable('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')
    TVPlayIE.suitable('http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    TVPlayIE.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')


# Generated at 2022-06-26 13:07:52.331228
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()



# Generated at 2022-06-26 13:08:04.585465
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    # 1st test
    test_url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    tvplay = TVPlayIE()
    match = tvplay._VALID_URL.match(test_url)
    assert (match is not None)

    # 2nd test
    test_url = 'http://play.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true'
    tvplay = TVPlayIE()
    match = tvplay._VALID_URL.match(test_url)
    assert (match is not None)

    # 3rd test

# Generated at 2022-06-26 13:11:19.295969
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    #test class without raise error
    try:
        TVPlayHomeIE()
    #python2.6 does not have assertRaisesRegexp, process exception message
    except Exception as exc:
        assert False, exc.args[0]


# Generated at 2022-06-26 13:11:21.732056
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    try:
        ie.extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    except Exception as e:
        return False
    return True



# Generated at 2022-06-26 13:11:27.362411
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay = TVPlayHomeIE()
    assert tvplay.suitable('https://play.tv3.ee/supernovat-10044362/') == True
    assert tvplay.suitable('https://tvplay.tv3.ee/supernovat-10044362/') == True
    assert tvplay.suitable('https://play.tv3.lt/supernovat-10044362/') == True
    assert tvplay.suitable('https://tvplay.tv3.lt/supernovat-10044362/') == True
    assert tvplay.suitable('https://tvplay.skaties.lv/supernovat-10044362/') == True
    assert tvplay.suitable('https://play.skaties.lv/supernovat-10044362/') == True

# Generated at 2022-06-26 13:11:30.316124
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    VIAFREE_URL = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    viafree_ie = ViafreeIE()
    assert viafree_ie.suitable(VIAFREE_URL) == True

# Generated at 2022-06-26 13:11:35.987189
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test without arguments
    TVPlayIE()
    # Test with valid URLs
    tvplay_ie = TVPlayIE(TVPlayIE._VALID_URL)
    assert tvplay_ie._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-26 13:11:41.905547
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE as viafree_ie

    # Checking initialize of class ViafreeIE
    viafree_ie = ViafreeIE("1")
    assert isinstance(viafree_ie, ViafreeIE)



# Generated at 2022-06-26 13:11:54.201680
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Basic arguments
    t = TVPlayIE()

    # Check class attributes
    assert t.IE_DESC == 'MTG services'
    assert t.IE_NAME == 'mtg'
    assert t.IE_URL_TEMPLATE == 'https://www.tvplay.lv/parraides/vinas-melo-labak/418113'
    assert t.IE_CONFIG_URL == 'http://playapi.mtgx.tv/v3/config'
    assert t.IE_CONFIG_TIMEOUT == 5
    assert t.IE_CONFIG_ENSURE_NAME is True
    assert t.IE_CONFIG_ENSURE_RELEASE_TIME is True
    assert t.IE_CONFIG_ENSURE_LICENCE_KEY is True

# Generated at 2022-06-26 13:11:55.045288
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:11:56.855272
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(TVPlayHomeIE.ie_key(), TVPlayHomeIE._VALID_URL, {})



# Generated at 2022-06-26 13:11:58.028441
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t = TVPlayIE()  # noqa

