

# Generated at 2022-06-26 13:02:35.971345
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:02:36.720644
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play = TVPlayIE()

# Generated at 2022-06-26 13:02:37.919237
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test for instance
    TVPlayIE()


# Generated at 2022-06-26 13:02:39.229666
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:42.080486
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Initialize TVPlayHomeIE class
    tvplay_home_i_e = TVPlayHomeIE()
    print("test_TVPlayHomeIE:")
    print("\ttype(tvplay_home_i_e): " + str(type(tvplay_home_i_e)))



# Generated at 2022-06-26 13:02:47.978399
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-26 13:02:50.350287
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(pytest.raises.Exception):
        viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:51.898896
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_i_e = TVPlayIE()


# Generated at 2022-06-26 13:02:53.554360
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:02:54.584559
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE_i_e = TVPlayIE()

# Generated at 2022-06-26 13:03:38.555396
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert viafree_i_e_0.is_extractable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafree_i_e_0.is_extractable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1')
    assert viafree_i_e_0.is_extractable('http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2')

# Generated at 2022-06-26 13:03:40.939639
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # test the constructor
    tv_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:42.619796
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	test_case_0()

# Generated at 2022-06-26 13:03:50.551472
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(TVPlayIE.IE_DESC == 'MTG services')
    assert(TVPlayIE.IE_NAME == 'mtg')

# Generated at 2022-06-26 13:03:51.832152
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_ie_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:53.274339
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:04:04.739985
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    test_instance = TVPlayIE()
    test_instance._real_extract(test_url)

    test_url2 = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    test_instance._real_extract(test_url2)

    test_url3 = 'http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true'
    test_instance._real_extract(test_url3)


# Generated at 2022-06-26 13:04:06.786109
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:04:08.408560
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert_raises(ExtractorError, viafree_i_e_0.video_info)


# Generated at 2022-06-26 13:04:22.078962
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    
    tvplay_i_e = TVPlayIE()
    assert tvplay_i_e.geo_countries == None
    assert tvplay_i_e.IE_NAME == 'mtg'
    assert tvplay_i_e.IE_DESC == 'MTG services'
    assert tvplay_i_e.valid_urls[0] == 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert tvplay_i_e.valid_urls[1] == 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'

# Generated at 2022-06-26 13:05:00.820627
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_url = 'http://play.tv3play.se/program/vad-tyst-det-ar/vad-tyst-det-ar-10100858'
    TVPlayHomeIE(test_url)



# Generated at 2022-06-26 13:05:03.683218
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == ie.VALID_URL



# Generated at 2022-06-26 13:05:10.464265
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)
    assert TVPlayHomeIE._VALID_URL.startswith('http')
    assert TVPlayHomeIE.IE_NAME == 'tvplayhome'
    assert TVPlayHomeIE.IE_DESC == 'TVPlay Home Latvia, Estonia, Lithuania'



# Generated at 2022-06-26 13:05:15.829954
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    a = ViafreeIE()
    try:
        a = ViafreeIE()
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


# Generated at 2022-06-26 13:05:23.544980
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE should not match TVPlayIE regex
    assert not ViafreeIE.suitable('http://www.tv3play.se/program/husraddarna/395385')
    # ViafreeIE should not match TVPlayIE regex but should match ViafreeIE regex
    assert ViafreeIE.suitable('http://www.viafree.se/program/husraddarna/395385')
    ViafreeIE('http://www.viafree.se/program/husraddarna/395385')

# Generated at 2022-06-26 13:05:35.057603
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'http://tvplay.tv3.ee/suburgatory/suburgatory-10217232/'
    expected_url = 'https://tvplay.tv3.ee/suburgatory/suburgatory-10217232/'
    video_id = '366674'
    expected_video_id = '366674'
    ie = TVPlayHomeIE(url)
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    assert ie._download_webpage == InfoExtractor._download_webpage
    assert ie._match_id(url) == video_id
    assert ie._match_id(expected_url) == expected_video_id


# Generated at 2022-06-26 13:05:35.953989
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:05:37.901272
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    d = TVPlayIE()
    assert d._TESTS[0]['url'] == d._VALID_URL % '418113'


# Generated at 2022-06-26 13:05:39.386000
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE() is not None


# Generated at 2022-06-26 13:05:42.205925
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'TVPlayIE url'
    t = TVPlayIE(url)
    assert t.url == url


# Generated at 2022-06-26 13:07:00.437194
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert isinstance(t, TVPlayHomeIE)


# Generated at 2022-06-26 13:07:06.472738
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)
    assert ie.IE_NAME == 'mtg'
    assert ie._VALID_URL == 'https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+(?P<id>\d+)'



# Generated at 2022-06-26 13:07:16.290518
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Test for __init__ method of class TVPlayIE
    from .tvplay import TVPlayIE
    from .generic import GenericIE

    # Test case 1: Initialize TVPlayIE
    t = TVPlayIE()
    assert t.ie_key() == 'tvplay'
    assert t.ie_name() == 'MTG services: TVPlay'

    # Test case 2: Check if subclass of GenericIE
    assert issubclass(TVPlayIE, GenericIE)



# Generated at 2022-06-26 13:07:27.933518
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie.IE_NAME == 'viafree'
    assert viafree_ie.IE_DESC == 'viafree.dk, viafree.no and viafree.se'
    assert viafree_ie.ie._WORKING == isinstance(viafree_ie, type(TVPlayIE())) == True
    assert viafree_ie._VALID_URL == r'(?x)https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-26 13:07:34.890177
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from .. import ViafreeIE
    url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    viafree = ViafreeIE(6, url)
    viafree.extract(url)


# Generated at 2022-06-26 13:07:40.109134
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    for url in [
        'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-1/episode-1',
        'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2',
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5',
    ]:
        success = False
        try:
            ie = ViafreeIE(url)
            success = True
        except (AssertionError, ExtractorError):
            pass
        assert success

# Generated at 2022-06-26 13:07:43.324272
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-26 13:07:49.511105
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ Test case for class TVPlayHomeIE"""
    tvplayhome = TVPlayHomeIE()
    url = "https://tv3play.skaties.lv/vinas-melo-labak-10280317"
    tvplayhome.suitable(url)
    video = tvplayhome._real_extract(url)
    assert video is not None


# Generated at 2022-06-26 13:07:52.731769
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)._initialize_geo_bypass({'countries': ['LV', 'LT']})



# Generated at 2022-06-26 13:07:57.023855
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.ie_key() == 'tvplay'
    assert ie.ie_key() in IE_DESC

# Generated at 2022-06-26 13:11:03.392749
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .test_tvplay_ie import TVPlayIE_test
    assert isinstance(TVPlayIE_test(TVPlayIE.ie_key()), TVPlayIE)



# Generated at 2022-06-26 13:11:07.084391
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable('https://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-26 13:11:11.465138
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL
    ie = TVPlayHomeIE(TVPlayHomeIE.ie_key())
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-26 13:11:17.192793
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE().get_info('http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert a['view_count'] == 4120


# Generated at 2022-06-26 13:11:23.962191
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class A(object):
        def __init__(self):
            pass
    tvplayhome_ie = TVPlayHomeIE(A())
    # Without initializing class "A", _VALID_URL would be None.
    # After initializing class "A", _VALID_URL is the right regular expression.
    assert str(tvplayhome_ie._VALID_URL) == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\\d+)'


# Generated at 2022-06-26 13:11:36.541917
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    IE = TVPlayIE();
    assert(IE.IE_NAME == 'mtg');
    assert(IE.IE_DESC == 'MTG services');

# Generated at 2022-06-26 13:11:49.035479
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:12:02.555657
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    import unittest

    class TVPlayIETest(unittest.TestCase):
        def test_tvplay(self):
            tested_url1 = "http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true"
            tested_url2 = "http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true"
            tested_url3 = "http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true"
            tested_url4 = "http://www.tv3play.se/program/husraddarna/395385?autostart=true"

# Generated at 2022-06-26 13:12:05.692628
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert re.match(ie._VALID_URL, ie.IE_NAME) is not None



# Generated at 2022-06-26 13:12:08.082335
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass

