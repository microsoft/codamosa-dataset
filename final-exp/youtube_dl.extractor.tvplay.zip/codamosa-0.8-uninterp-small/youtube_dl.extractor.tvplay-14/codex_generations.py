

# Generated at 2022-06-26 13:02:35.913025
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	assert TVPlayHomeIE() != None


# Generated at 2022-06-26 13:02:39.202477
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = ViafreeIE()


if __name__ == '__main__':
    # Test for class method test_case_0
    test_case_0()

    # Unit test for constructor of class ViafreeIE
    test_ViafreeIE()

# Generated at 2022-06-26 13:02:42.140057
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(t_v_play_i_e_0.IE_NAME == 'mtg')
    assert(t_v_play_i_e_0.IE_DESC == 'MTG services')


# Generated at 2022-06-26 13:02:43.095134
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:02:44.349928
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()



# Generated at 2022-06-26 13:02:47.497793
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_1 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:49.303476
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:50.953785
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()


# Generated at 2022-06-26 13:03:02.323136
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()

# Generated at 2022-06-26 13:03:03.684232
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:03:35.465486
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Unit test for class ViafreeIE."""
    # Init
    ie = ViafreeIE()

    # #1
    # Precondition
    dataUrl = \
        'https://viafree-content.mtg-api.com/viafree-content/v1/no/path/programmer/underholdning/det-beste-vorspielet/sasong-2/episode-1'
    content = ''
    with open('testdata/viafree_det_beste_vorspielet.json', 'r') as f:
        content = f.read()
    # Action
    ie.test_passed = False
    ie._download_json = lambda *a: json.loads(content)
    ie._real_extract(dataUrl)
    # Verification
    assert ie.test_passed

    # #

# Generated at 2022-06-26 13:03:38.593341
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    global TVPlayIE
    TVPlayIE()



# Generated at 2022-06-26 13:03:39.193010
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:03:50.230659
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:03:58.191508
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    assert ie.suitable('https://play.tv3.lt/aferistai-10047125')
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'TV3 Play, TV6 Play and Viafree'
    assert ie._VALID_URL == TVPlayHomeIE._VALID_URL

# Generated at 2022-06-26 13:04:09.444294
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    if not compat_etree_ElementTree:
        pytest.skip('The ElementTree package is needed')

    url = 'https://play.tv3.se/serier/vinas-melo-labak/981237/10-avsnitt-av-vinas-melo-labak'
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE._match_id(url)
    with pytest.raises(RegexNotFoundError):
        TVPlayHomeIE._real_extract(url)

# Generated at 2022-06-26 13:04:22.816384
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:04:24.041992
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home = TVPlayHomeIE()
    assert tvplay_home == TVPlayHomeIE()



# Generated at 2022-06-26 13:04:34.204133
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    m = TVPlayHomeIE()
    assert m.IE_NAME == 'tvplayhome'
    assert m._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert (
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    ) == m.url_result('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/').url

# Generated at 2022-06-26 13:04:36.733488
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    loader = TestLoader()
    suite = loader.loadTestsFromTestCase(TestTVPlayHomeIE)
    buffer = StringIO()
    runner = TextTestRunner(buffer)
    res = runner.run(suite)
    assert res.wasSuccessful()


# Generated at 2022-06-26 13:05:14.506403
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, None)
    assert ie.geo_verification_headers() is None



# Generated at 2022-06-26 13:05:18.113731
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    testing_class = TVPlayIE
    new_instance = testing_class('mtg:418113')
    assert new_instance is not None



# Generated at 2022-06-26 13:05:20.113357
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Extractor for the following websites:
    - tvplay.lv
    - tvplay.ee
    - tvplay.lt
    - tvplay.se
    - tvplay.dk
    - tvplay.no
    - nova.bg
    """
    return TVPlayIE()



# Generated at 2022-06-26 13:05:22.871229
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()
    assert tvplayIE.IE_NAME == 'mtg'
    assert tvplayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:05:35.561899
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    youtube_ie = InfoExtractor("youtube")
    assert youtube_ie.ie_key() == "Youtube"

    # test normal constructor
    viafree_ie = ViafreeIE("youtube")
    assert viafree_ie.kitchen_sink == youtube_ie.kitchen_sink
    assert viafree_ie.ie_key() == youtube_ie.ie_key()
    assert viafree_ie._WORKING == youtube_ie._WORKING
    assert viafree_ie.url_transparent == youtube_ie.url_transparent
    assert viafree_ie.age_limit == youtube_ie.age_limit

    viafree_ie = ViafreeIE("Viafree", youtube_ie, False)
    assert viafree_ie.ie_key() == "Viafree"
    assert viafree_ie.working == youtube_ie.working

# Generated at 2022-06-26 13:05:47.131780
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_TVPlayIE = TVPlayIE()
    assert test_TVPlayIE.IE_NAME == 'mtg'
    assert test_TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:05:54.781634
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    instance = ViafreeIE()
    instance.suitable('http://www.tv6play.se/program/den-sista-dokusapan/266636?autostart=true')
    instance.suitable('http://play.novatv.bg/programi/zdravei-bulgariya/624952?autostart=true')
    instance.suitable('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    info_dict = instance._real_extract(url)


# Generated at 2022-06-26 13:05:58.372795
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_ie = TVPlayHomeIE()
    assert isinstance(tvplay_home_ie, TVPlayHomeIE)



# Generated at 2022-06-26 13:06:06.108271
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:06:17.856261
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie.suitable('https://play.tv3.lt/aperistai-10047125/')
    assert ie.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354/')
    assert ie.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    assert ie.suitable('https://tvplay.skaties.lv/vinas-melo-labak-10280317/')
    assert ie.suitable('https://tvplay.tv3.lt/aperistai-10047125/')
    assert ie.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse-10044354/')

# Generated at 2022-06-26 13:07:52.895142
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE.suitable(None)
    TVPlayHomeIE.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE.suitable('https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-26 13:08:00.201086
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from tvplayhome import TVPlayHomeIE
    from youtube_dl.extractor import YoutubeIE
    # Check It is instance of InfoExtractor
    assert isinstance(TVPlayHomeIE, YoutubeIE)
    print("Is instance of InfoExtractor: ", isinstance(TVPlayHomeIE, YoutubeIE))

# Generated at 2022-06-26 13:08:14.378659
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_cases = [
        # (Country, URL, expected ID)
        ('se', 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2', '430284'),
        ('no', 'https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1', '757786'),
        ('dk', 'https://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5', '744563'),
    ]
    for country, url, expected in test_cases:
        assert ViafreeIE._match_id(url) == expected
        assert ViafreeIE._search_country(url) == country

# Generated at 2022-06-26 13:08:23.167039
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    for url in (
            'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
            'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
            'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
            'https://play.tv3.lt/aferistai-10047125',
            'https://tv3play.skaties.lv/vinas-melo-labak-10280317',
            'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354',):

        ie = TVPlayHomeIE

# Generated at 2022-06-26 13:08:26.788240
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    print('Testing constructor of class TVPlayIE')
    info_extractor = TVPlayIE()
    return info_extractor



# Generated at 2022-06-26 13:08:27.777892
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    rval = ViafreeIE()
    assert rval is not None


# Generated at 2022-06-26 13:08:38.669863
# Unit test for constructor of class ViafreeIE

# Generated at 2022-06-26 13:08:40.117548
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.IE_NAME == 'TVPlayHome'



# Generated at 2022-06-26 13:08:48.327257
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'
    assert len(ie._TESTS) >= 10
    assert re.match(ie._VALID_URL,
                    'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')



# Generated at 2022-06-26 13:08:55.846346
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, '', '', '', '')
    info = ie._real_extract(
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert(info['id'] == '366367')
    assert(info['title'] == 'Aferistai')
    assert(info['ext'] == 'mp4')
    assert(info['description'] == 'Aferistai. Kalėdinė pasaka.')
    assert(info['series'] == 'Aferistai [N-7]')
    assert(info['season'] == '1 sezonas')
    assert(info['season_number'] == 1)
    assert(info['duration'] == 464)