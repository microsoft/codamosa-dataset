

# Generated at 2022-06-26 13:02:35.376639
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:38.144741
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()
    assert t_v_play_home_i_e is not None

if __name__ == '__main__':
    test_case_0()
    test_TVPlayHomeIE()

# Generated at 2022-06-26 13:02:46.670183
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Positive case
    url = 'http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    expected_url = 'http://playapi.mtgx.tv/v3/videos/409229'
    t_v_play_i_e = TVPlayIE()
    # Test method _real_initialize
    assert expected_url == t_v_play_i_e._real_initialize(url)
    # Test method _real_extract for above url
    assert 409229 == t_v_play_i_e._real_extract(url)['id']
    # Test method _real_extract for non positive case

# Generated at 2022-06-26 13:02:47.573411
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:50.289590
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_case_0()

if __name__ == '__main__':
    import sys
    test_case_0()
    sys.exit(0)

# Generated at 2022-06-26 13:02:51.852463
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:03.121774
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    unit_test_case_0 = UnitTestCase(
        t_v_play_home_i_e_0,
        "https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/",
        {
            "id": "366367",
            "ext": "mp4",
            "title": "Aferistai",
            "description": "Aferistai. Kalėdinė pasaka.",
            "series": "Aferistai [N-7]",
            "season": "1 sezonas",
            "season_number": 1,
            "duration": 464,
            "timestamp": 1394209658,
            "upload_date": "20140307",
            "age_limit": 18,
        },
        "",
        "True")

# Generated at 2022-06-26 13:03:04.433928
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()
    assert viafree_ie is not None

# Generated at 2022-06-26 13:03:05.411923
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_ = ViafreeIE()

# Generated at 2022-06-26 13:03:15.653631
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    assert t_v_play_i_e.IE_NAME == "mtg"
    assert t_v_play_i_e.IE_DESC == "MTG services"

# Generated at 2022-06-26 13:03:52.992483
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:04:02.099497
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    t_v_play_i_e = TVPlayIE()
    if not t_v_play_i_e.suitable(url) and t_v_play_i_e._VALID_URL == TVPlayIE._VALID_URL:
        print('test_TVPlayIE():  Failed')
        return
    t_v_play_i_e.extract(url)

# Generated at 2022-06-26 13:04:03.633795
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()


# Generated at 2022-06-26 13:04:06.516078
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:04:07.845387
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:04:10.008407
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:04:11.529862
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:04:13.249993
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    test_case_0()



# Generated at 2022-06-26 13:04:14.088840
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:04:14.716127
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:05:27.730458
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:05:29.941523
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvp_home_ie = TVPlayHomeIE()


# Generated at 2022-06-26 13:05:39.122239
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    print('TESTING TVPlayHomeIE')
    t_v_play_home_i_e_ = TVPlayHomeIE()
    print('TEST 1')
    # CALLING judge_valid_url()
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert t_v_play_home_i_e_.judge_valid_url(url), 'url valid'
    print('###')
    print('PASS 1')
    print('###')
    print('TEST 2')
    # CALLING _real_extract()
    video_id = '10280317'

# Generated at 2022-06-26 13:05:49.094793
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()

# Generated at 2022-06-26 13:05:51.137363
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()

# Generated at 2022-06-26 13:05:54.878600
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    assert t_v_play_i_e.IE_NAME == 'mtg'
    assert t_v_play_i_e.IE_DESC == 'MTG services'


# Generated at 2022-06-26 13:05:57.329578
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_ie_0 = TVPlayIE()

# Generated at 2022-06-26 13:05:58.782599
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_el = ViafreeIE()

# Generated at 2022-06-26 13:06:00.786407
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie_0 = ViafreeIE()


# Generated at 2022-06-26 13:06:05.294519
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    t_v_play_i_e_0 = TVPlayIE()
    if t_v_play_i_e_0.suitable(url):
        assert True
    else:
        assert False


# Generated at 2022-06-26 13:08:49.456351
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i = ViafreeIE()

# Generated at 2022-06-26 13:08:52.503740
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:08:54.086511
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:09:04.918955
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_equal(TVPlayHomeIE._VALID_URL, r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')

# Generated at 2022-06-26 13:09:06.849370
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:09:13.197929
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    video_id = '418113'
    geo_country = 'lv'
    url = 'https://play.tv3.lv/programos/moterys-meluoja-geriau/409229?autostart=true'

    t_v_play_i_e = TVPlayIE()
    try:
        t_v_play_i_e.initialize()
    except:
        print('ERROR: Failed to initialize!')


# Generated at 2022-06-26 13:09:16.738228
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_e_0 = TVPlayIE()

# Generated at 2022-06-26 13:09:20.537355
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie.suitable('mtg:418113')


# Generated at 2022-06-26 13:09:21.499048
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()

# Generated at 2022-06-26 13:09:27.145007
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert t_v_play_home_i_e_0.url == None
    assert t_v_play_home_i_e_0.video_id == None
    assert t_v_play_home_i_e_0.tbr == None
    assert t_v_play_home_i_e_0.json_ld == None
    assert t_v_play_home_i_e_0.player_vars == None
    assert t_v_play_home_i_e_0.smil_data == None
    assert t_v_play_home_i_e_0._f4m_data == None
    assert t_v_play_home_i_e_0.redirect_urls[0] == None
    assert t_v_play_home_i_e_0.params