

# Generated at 2022-06-26 13:02:34.468122
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()

# Generated at 2022-06-26 13:02:36.124994
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Constructor of class ViafreeIE
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:37.050710
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    video = ViafreeIE()


# Generated at 2022-06-26 13:02:38.390664
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:40.426571
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert t_v_play_home_i_e_0.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')


# Generated at 2022-06-26 13:02:42.306316
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass

if __name__ == "__main__":
    # Add a test case here to generate the main method
    tvplay_home_ie = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:43.576129
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:44.781346
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:02:45.909637
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:02:47.012385
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:03:07.588070
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    TVPlayHomeIE(url)

# Generated at 2022-06-26 13:03:19.474611
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Initialize TVPlayIE object
    ie = TVPlayIE()

    # Test for valid url
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    test_url = ie._match_id(url)
    assert test_url == '418113'

    # Test for invalid url
    url = 'https://www.youtube.com/user/lattelecom'
    assert ie._match_id(url) is None

    # Test for geo restricted url
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'

# Generated at 2022-06-26 13:03:26.069999
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_ = TVPlayIE()
    assert class_.IE_NAME == 'mtg'
    assert class_.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:38.498229
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:50.015297
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Tests for first test case
    a = TVPlayIE()
    a._initialize_geo_bypass({'countries': 'LV'})
    assert a._GEO_BYPASS == True

    # Tests for sixth test case
    b = TVPlayIE()
    b._initialize_geo_bypass({'countries': 'NO'})
    assert b._GEO_BYPASS == True

    # Tests for second test case
    c = TVPlayIE()
    c._initialize_geo_bypass({'countries': 'LT'})
    assert c._GEO_BYPASS == True

    # Tests for third test case
    d = TVPlayIE()
    d._initialize_geo_bypass({'countries': 'EE'})
    assert d._GEO_BYPASS == True

    # Tests

# Generated at 2022-06-26 13:03:51.442581
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE._match_id('mtg:418113')
    ViafreeIE._match_id('mtg:418113/?autostart=true')



# Generated at 2022-06-26 13:03:53.419375
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert isinstance(ViafreeIE([], {}), TVPlayIE)

# Generated at 2022-06-26 13:03:56.124333
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_raises(RegexNotFoundError, TVPlayHomeIE, 'http://test_test.test', None)
    assert_raises(ExtractorError, TVPlayHomeIE, 'http://play.tv3.ee/tere', None)
    assert_raises(RegexNotFoundError, TVPlayHomeIE, 'http://play.tv3.ee/tere-tere', None)



# Generated at 2022-06-26 13:04:05.846047
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    objects = TVPlayIE()
    assert(objects.IE_NAME == 'mtg')
    assert(objects.IE_DESC == 'MTG services')

# Generated at 2022-06-26 13:04:14.637096
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE('www.viafree.no', 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert viafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not viafreeIE.suitable('http://play.mtgx.tv/program/systrarna-karlsson/418113?autostart=true')


# Generated at 2022-06-26 13:04:51.548928
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_ie = TVPlayHomeIE()
    assert re.match(TVPlayHomeIE._VALID_URL, tvplay_home_ie._VALID_URL)


# Generated at 2022-06-26 13:04:53.230266
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-26 13:05:00.735669
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_equals(TVPlayHomeIE._VALID_URL, r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')

# TV3Play.lt is a part of TVPlayHomeIE

# Generated at 2022-06-26 13:05:03.034671
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
	#Check if instance can be created
	IE = TVPlayIE()

# Generated at 2022-06-26 13:05:14.351482
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_ = ViafreeIE
    # test error in case of missing URL
    with pytest.raises(MissingParameterError):
        class_(None)
    # Test if missing country char on URL
    assert class_('')._match_id('') == ''
    # Test if country char is set in URL, for example Danish
    url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    assert class_('DK')._match_id(url) is not None
    assert class_('DK').geo_verification_headers()['Origin'] == 'http://www.viafree.dk'
    # Test if country char is set in URL, for example Swedish

# Generated at 2022-06-26 13:05:21.714121
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    # only test check_valid_url()
    input_url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    expected_output = '366367'
    assert t._match_id(input_url) == expected_output


# Generated at 2022-06-26 13:05:29.809659
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_ie = TVPlayIE()
    test_url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    id = tv_play_ie._match_id(test_url)
    assert id == '418113'


# Generated at 2022-06-26 13:05:42.994582
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():

    resource = TVPlayHomeIE.TVPlayHomeIE()

    resource.suitable('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    resource.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    resource.suitable('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    resource.suitable('https://play.tv3.lt/aferistai-10047125')
    resource.suitable('https://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-26 13:05:46.336913
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE("")
        assert False
    except TypeError:
        assert True


# Generated at 2022-06-26 13:05:53.897915
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://viafree-content.mtg-api.com/viafree-content/v1/dk/path/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    obj = ViafreeIE._download_json(url, '1234', query=None)
    assert obj['meta']['title'] == 'Det beste vorspielet - Sesong 2 - Episode 1'



# Generated at 2022-06-26 13:07:10.559003
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:07:18.504199
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    assert ie.url == 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/'
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-26 13:07:28.578696
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:07:41.958948
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-26 13:07:43.472367
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()
    

# Generated at 2022-06-26 13:07:44.857040
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()._VALID_URL == TVPlayIE._VALID_URL


# Generated at 2022-06-26 13:07:45.772778
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:07:49.252595
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from .test_download import _assert_download
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    _assert_download(TVPlayHomeIE(), url)

# Generated at 2022-06-26 13:08:03.573335
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'https://viafree-content.mtg-api.com/viafree-content/v1/%s/path/%s'
    content = {
        "_embedded": {
            "viafreeBlocks": [
                {
                    "_embedded": {
                        "program": {
                            "guid": "feac2b2d-4e33-4c8b-b4d7-4f763d927b65",
                            "_links": {
                                "streamLink": {
                                    "href": url % ('dk', 'programmer/serier/storbyens-sikreste-pige/saeson-3/episode-3')
                                }
                            }
                        }
                    }
                }
            ]
        }
    }
    test_result = ViafreeIE._

# Generated at 2022-06-26 13:08:06.478994
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-26 13:11:09.119871
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    a = ViafreeIE()
    assert a is not None


# Generated at 2022-06-26 13:11:13.768165
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    i = TVPlayIE()
    assert i._VALID_URL == TVPlayIE._VALID_URL
    assert i._TESTS == TVPlayIE._TESTS

# Add in TVPlayIE when it has been made a public class

# Generated at 2022-06-26 13:11:17.845678
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.compat_url('http://www.tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true') == 'https://tvplay.skaties.lv/vinas-melo-labak/418113/?autostart=true'


# Generated at 2022-06-26 13:11:21.281446
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-26 13:11:21.986557
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    website = TVPlayHomeIE()


# Generated at 2022-06-26 13:11:22.750055
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE(None)


# Generated at 2022-06-26 13:11:23.671755
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(AssertionError):
        ViafreeIE()


# Generated at 2022-06-26 13:11:26.694426
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5'
    test_instance = ViafreeIE()._match_id(test_url)
    assert test_instance == '6e63bc94-1b6a-4c57-b6c0-48679e2038fc', 'Test for constructor of class ViafreeIE failed'

# Generated at 2022-06-26 13:11:28.231290
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie._download_json.__name__ == 'TVPlayHomeIE._download_json'



# Generated at 2022-06-26 13:11:31.007999
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf = ViafreeIE()
    assert vf._VALID_URL == 'https?://(?:www\.)?viafree\.(?:dk|no|se)/(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'
    assert vf._GEO_BYPASS == False