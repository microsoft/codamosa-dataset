

# Generated at 2022-06-26 13:02:37.681337
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert callable(TVPlayIE)


# Generated at 2022-06-26 13:02:39.165116
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:40.152986
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:41.461677
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_1 = TVPlayIE()

# Generated at 2022-06-26 13:02:42.391623
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:43.120604
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:02:44.599719
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = TVPlayIE()
    viafree_i_e_0 = ViafreeIE(t_v_play_i_e_0)

# Generated at 2022-06-26 13:02:47.534413
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert t_v_play_i_e_0


# Generated at 2022-06-26 13:02:50.232444
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    assert repr(t_v_play_i_e) == '<TVPlayIE -1>'


# Generated at 2022-06-26 13:02:52.144167
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from yt_dl.extractor.tvplay import ViafreeIE
    v_i_e = ViafreeIE()

# Generated at 2022-06-26 13:03:19.308999
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        if ViafreeIE._GEO_BYPASS:
            raise RuntimeError('ViafreeIE is not geo blocked anymore.')
        ViafreeIE('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
        raise RuntimeError('ViafreeIE is not geo blocked.')
    except GeoRestrictedError:
        pass


# Generated at 2022-06-26 13:03:20.445747
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # ViafreeIE should not be registered
    assert not any(isinstance(ie, ViafreeIE) for ie in gen_extractors())



# Generated at 2022-06-26 13:03:29.621959
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    IE = ViafreeIE
    i = IE()
    try:
        i._initialize_geo_bypass({'countries': ['se']})
    except ValueError:
        pass
    else:
        raise AssertionError('Test #1 failed')
    try:
        i._initialize_geo_bypass({'countries': ['dk']})
    except ValueError:
        pass
    else:
        raise AssertionError('Test #2 failed')
    try:
        i._initialize_geo_bypass({'countries': ['no']})
    except ValueError:
        pass
    else:
        raise AssertionError('Test #3 failed')
    i._initialize_geo_bypass({'countries': ['XXX']})



# Generated at 2022-06-26 13:03:35.038335
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'https://play.nova.bg/programi/zdravei-bulgariya/764300?autostart=true'
    tv_play = TVPlayIE(url)
    assert_equal(True, hasattr(tv_play, 'url'))


# Generated at 2022-06-26 13:03:47.717051
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:03:51.263227
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    s = ViafreeIE()
    assert s is not None, 'Instantiated ViafreeIE'

# vim:set ts=4 sw=4 et:

# Generated at 2022-06-26 13:04:02.024672
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """ Unit test for constructor of class TVPlayHomeIE
    """
    info_extractor = TVPlayHomeIE()
    with pytest.raises(RegexNotFoundError):
        info_extractor.suitable("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    assert info_extractor.suitable("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/") == True


# Generated at 2022-06-26 13:04:08.839593
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert 'skaties.lv' in [domain for domain, ie_name in ie._IES]
    assert 'tv3.lt' in [domain for domain, ie_name in ie._IES]
    assert 'tv3.ee' in [domain for domain, ie_name in ie._IES]

# Generated at 2022-06-26 13:04:22.436893
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    assert ie.IE_NAME == 'Viafree'
    assert ie.IE_DESC == 'Viafree'
    assert ie._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-26 13:04:24.408525
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    with pytest.raises(AttributeError):
        ViafreeIE()

# Generated at 2022-06-26 13:05:14.539287
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class_name = 'TVPlayHomeIE'
    class_obj = globals()[class_name]
    ins = class_obj(None, {}, {}, {})
    assert ins.ie_key() == class_name.lower()
    assert ins.ie_key_compat() == 'tvplay'
    assert ins.SITE_NAME == 'TVPlay'
    assert ins.BRANDING_DOMAIN == 'tvplay.skaties.lv'
    assert ins.GEO_COUNTRIES == ['LT', 'LV', 'EE']
    assert ins.COUNTRY_GROUPS == {'lt': 'LT', 'lv': 'LV', 'ee': 'EE'}
    assert ins.countries == ('LT', 'LV', 'EE')

# Generated at 2022-06-26 13:05:17.957617
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # The ViafreeIE constructor requires a country code.
    assert ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert not ViafreeIE.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    assert not ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')



# Generated at 2022-06-26 13:05:19.416263
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert ie is not None
    assert ie.SUCCESS == 0
    assert ie.FAILURE == 1
    assert ie.ERROR == 2


# Generated at 2022-06-26 13:05:22.016101
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    IE = TVPlayHomeIE("tvplay(?:tv3\.lt|skaties\.lv|\.tv3\.ee)")

# Generated at 2022-06-26 13:05:35.335083
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.ie_key() == 'TVPlayIE'
    assert ie.ie_name() == 'mtg'
    assert ie.ie_desc() == 'MTG services'

# Generated at 2022-06-26 13:05:47.034765
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:05:49.948035
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """
    Check if TVPlayHomeIE constructor works ok
    """
    assert TVPlayHomeIE(TVPlayHomeIE.ie_key())

# Generated at 2022-06-26 13:05:50.868916
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    pass


# Generated at 2022-06-26 13:05:58.563372
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    # Test for valid URL
    url_valid = 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    assert ie.suitable(url_valid)
    # Test for invalid URL
    url_invalid = 'http://foo.se/program/underhallning/i-like-radio-live/sasong-1/676869'
    assert not ie.suitable(url_invalid)
    url_invalid = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    assert not ie.suitable(url_invalid)

# Generated at 2022-06-26 13:06:06.221478
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t = ViafreeIE()
    assert t.compiled_regex.match("https://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert t.compiled_regex.match("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1")
    assert t.compiled_regex.match("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2")

# Generated at 2022-06-26 13:07:39.446019
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()

# Generated at 2022-06-26 13:07:45.019046
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    x = TVPlayIE()
    assert x.extractor_keywords != None
    assert x.IE_NAME != None
    assert x.IE_DESC != None
    assert x._VALID_URL != None


# Generated at 2022-06-26 13:07:57.280771
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ydl = YoutubeDL()
    ydl.add_default_info_extractors()

    class Country:
        def __init__(self, name):
            self.name = name

    for country in ['DK', 'NO', 'SE']:
        ydl.params['geo_bypass_country'] = Country(country)
        embed_code = '1oj7z8g'
        url = 'http://www.viafree.{}/programmer/underholdning/sommaren-med-youtube-stjarnorna/sesong-1/{}'.format(country.lower(), embed_code)
        if not re.search(ViafreeIE._VALID_URL, url):
            raise Exception("URL is invalid")
        m = re.match(ViafreeIE._VALID_URL, url)
        assert m

# Generated at 2022-06-26 13:08:09.123515
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tvplay.tv3.lv/gimenes-darzs/gimenes-darzs-s01e05-10046210')
    assert ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-26 13:08:12.629582
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    '''
    Unit test to run the constructor of class ViafreeIE
    '''
    viafree = ViafreeIE()
    assert viafree is not None


# Generated at 2022-06-26 13:08:16.384388
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE"""

    # Test constructor
    assert isinstance(TVPlayHomeIE(), TVPlayHomeIE)



# Generated at 2022-06-26 13:08:22.781607
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE('http://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    # test URL without trailing slash
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125')



# Generated at 2022-06-26 13:08:30.880752
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:08:33.385028
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('TVPlay', '', '', '', '', '', '')



# Generated at 2022-06-26 13:08:39.043588
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Temporarily disable for these tests because it downloads a whole bunch
    # of stuff that's just too slow
    speedup_raises = SpeedupRaises
    SpeedupRaises = []

    try:
        # Try create a new instance of ViafreeIE
        viafree_ie = ViafreeIE()
    except:
        raise
    finally:
        SpeedupRaises = speedup_raises

