

# Generated at 2022-06-26 13:02:36.448343
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = ViafreeIE()
    assert t_v_play_i_e_0 is not None


# Generated at 2022-06-26 13:02:38.572956
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e = ViafreeIE()


# Test for the extractor of ViafreeIE

# Generated at 2022-06-26 13:02:39.574086
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:40.800144
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:41.702171
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert isinstance(viafreeIE, ViafreeIE)

# Generated at 2022-06-26 13:02:47.088775
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert obj._TESTS[0].get("url") == 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    assert obj._TESTS[1].get("url") == 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'


# Generated at 2022-06-26 13:02:48.119110
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:02:49.619081
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:51.642723
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    #assert(False)

    test_case = 0
    if test_case == 0:
        test_case_0()

# Generated at 2022-06-26 13:02:52.958093
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    expected = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:33.025070
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME
    assert TVPlayIE.IE_DESC
    assert TVPlayIE._VALID_URL
    assert TVPlayIE._TESTS
    assert TVPlayIE._downloader
    assert TVPlayIE._download_webpage
    assert TVPlayIE._download_xml

# Generated at 2022-06-26 13:03:38.902494
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf_ie = ViafreeIE()
    assert (vf_ie is not None), 'ViafreeIE object is None!'


# Generated at 2022-06-26 13:03:42.454065
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i_e = ViafreeIE()
    assert isinstance(v_f_i_e, ViafreeIE)

# Generated at 2022-06-26 13:03:48.997666
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
	t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:58.350143
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    info_extractor = TVPlayHomeIE()
    info_extractor._match_id('https://tvplay.tv3.lt/aferistai-10047125')
    info_extractor._match_id('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    info_extractor._match_id('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

if __name__ == '__main__':
    test_case_0()
    test_TVPlayHomeIE()

# Generated at 2022-06-26 13:04:02.834923
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()


# Generated at 2022-06-26 13:04:10.474026
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from .common import InfoExtractor
    from .common import test_assert
    from .common import get_testcases
    # all test cases
    test_list = get_testcases(TVPlayIE, 'test_TVPlayIE')
    # run unit tests
    for item in test_list:
        print(item)
        test_class = getattr(t_v_play_i_e_0, item)
        try:
            test_class()
            test_assert(True)
        except:
            test_assert(False)

test_case_0()

# Generated at 2022-06-26 13:04:13.323704
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:04:14.858542
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:04:31.456662
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    assert t_v_play_i_e.IE_NAME == 'mtg'
    assert t_v_play_i_e.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:05:17.966007
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    with pytest.raises(AssertionError):
        TVPlayHomeIE('http://www.example.com/?url=https%3A%2F%2Ftvplay.tv3.lt%2Faferistai-n-7%2Faferistai-10047125%2F')


# Generated at 2022-06-26 13:05:23.040069
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    assert ie.name == 'tv3play.tv3.ee:home'
    assert ie.compat_str == 'tv3play.tv3.ee'



# Generated at 2022-06-26 13:05:23.999538
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:05:34.341165
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    constructor_test(TVPlayHomeIE, [
        # case in English
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/',
        # case in Latvian
        'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/',
        # case in Estonian
        'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/',
    ])



# Generated at 2022-06-26 13:05:46.545189
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/dokumentar/the-hunters/sesong-1/episode-1')
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert ViafreeIE.suitable('http://www.viafree.no/programmer/dokumentar/trucker-trucker/sesong-1/episode-1')
    assert ViafreeIE.suitable('http://www.viafree.se/program/dokumentar/sporten-som-forsvann/sasong-1/avsnitt-1')

# Generated at 2022-06-26 13:05:49.119756
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay = TVPlayHomeIE('tvplay')
    assert tvplay.IE_NAME == 'tvplay'
    assert TVPlayHomeIE.IE_NAME == 'tvplay'



# Generated at 2022-06-26 13:05:55.982262
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    def _test_module(module):
        assert module.IE_NAME == "Viafree"
        assert module.IE_DESC == "Viasat and TV3"
        assert module.TV3_URL == "http://playapi.mtgx.tv/v3/videos/%s"
        assert module.TV6_URL == "http://playapi.mtgx.tv/v3/videos/%s"
        assert module.TV8_URL == "http://playapi.mtgx.tv/v3/videos/%s"
        assert module.TV3PLAY_URL == "http://playapi.mtgx.tv/v3/videos/%s"
        assert module.TV6PLAY_URL == "http://playapi.mtgx.tv/v3/videos/%s"
        assert module.TV8

# Generated at 2022-06-26 13:06:04.193620
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Test: TVPlayIE class constructor
    """
    test = TVPlayIE()

    assert test.IE_NAME == 'mtg'
    assert test.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:06:17.261954
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_tvplay = TVPlayIE()
    assert class_tvplay.IE_NAME == 'mtg'
    assert class_tvplay.IE_DESC ==  'MTG services'

# Generated at 2022-06-26 13:06:24.322951
# Unit test for constructor of class TVPlayHomeIE

# Generated at 2022-06-26 13:08:00.275769
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('http://www.tv3play.ee/sisu/kodu-keset-linna/238551?autostart=true')


# Generated at 2022-06-26 13:08:14.379256
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:08:18.159894
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    init_test = TVPlayIE()
    test_match_id = init_test._match_id("http://play.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true")
    assert test_match_id == "230898"


# Generated at 2022-06-26 13:08:20.970227
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_under_test = TVPlayIE
    is_instance = isinstance(class_under_test(), InfoExtractor)
    msg = 'TVPlayIE class is not an instance of InfoExtractor'
    assert is_instance, msg


# Generated at 2022-06-26 13:08:34.480775
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay._VALID_URL == r'(?x)(?:mtg:|https?://(?:www\.)?(?:tvplay(?:\.skaties)?\.lv(?:/parraides)?|(?:tv3play|play\.tv3)\.lt(?:/programos)?|tv3play(?:\.tv3)?\.ee/sisu|(?:tv(?:3|6|8|10)play|viafree)\.se/program|(?:(?:tv3play|viasat4play|tv6play|viafree)\.no|(?:tv3play|viafree)\.dk)/programmer|play\.nova(?:tv)?\.bg/programi)/(?:[^/]+/)+)(?P<id>\d+)'
    assert tvplay._TESTS

# Generated at 2022-06-26 13:08:38.884636
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('http://tv3play.skaties.lv/vinas-melo-labak-10280317/')

# Generated at 2022-06-26 13:08:48.465543
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()
    assert viafreeIE.geo_country == 'se'
    assert viafreeIE.GEO_COUNTRIES == ['SE']
    assert viafreeIE._VALID_URL == r'https?://(?:www\.)?viafree\.(dk|no|se)/(program(?:mer)?/(?:[^/]+/)+[^/?#&]+)'

# Generated at 2022-06-26 13:08:53.849869
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    deps = ['play_tv3']
    ie = TVPlayIE.station_instance('tv3.lt', deps)
    assert isinstance(ie, TVPlayIE)
    assert ie._VALID_URL == r'http://(?:www\.)?(?:tv3play|play\.tv3)\.lt(?:/programos)?/(?:[^/]+/)+(?P<id>\d+)'
    assert ie._TESTS[0]['url'] == 'http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true'
    assert ie._TESTS[0]['info_dict']['id'] == '409229'

# Generated at 2022-06-26 13:09:02.848988
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from youtube_dl.test import FakeYDL
    from youtube_dl.extractor import ExtractorError
    ydl = FakeYDL()
    ie = ViafreeIE(ydl)
    with pytest.raises(ExtractorError):
        ie.suitable(
            'http://www.tv3play.se/program/husraddarna/395385?autostart=true')
    assert ie.suitable('http://www.viafree.se/program/husraddarna/sesong-20/avsnitt-2')

# Generated at 2022-06-26 13:09:07.083063
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    print(ie.extract('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'))
