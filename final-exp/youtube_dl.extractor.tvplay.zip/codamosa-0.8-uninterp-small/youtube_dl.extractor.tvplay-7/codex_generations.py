

# Generated at 2022-06-26 13:02:34.227568
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlay = TVPlayIE()
    assert TVPlay.IE_NAME == 'mtg'

# Unit test to test url extraction

# Generated at 2022-06-26 13:02:37.126574
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert(TVPlayIE._TESTS[0] is not None)
    assert(TVPlayIE._TESTS[1] is not None)


# Generated at 2022-06-26 13:02:37.732101
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE

# Generated at 2022-06-26 13:02:38.685797
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    a = TVPlayHomeIE()
    return a

# Generated at 2022-06-26 13:02:40.504747
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # test case 0
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:42.181268
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()
    return viafree_i_e_0


# Generated at 2022-06-26 13:02:45.609688
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    title_url = "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1"
    viafree_i_e = ViafreeIE()
    viafree_i_e.suitable(title_url)


# Generated at 2022-06-26 13:02:47.723441
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:54.950527
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    instance = TVPlayHomeIE()
    instance.suitable('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
    instance.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    instance.suitable('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')


# Generated at 2022-06-26 13:02:56.620839
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:26.462538
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import re
    from youtube_dl.options import parseOpts
    from youtube_dl.extractor import gen_extractors, list_extractors
    from youtube_dl.utils import WARN

    ydl = YoutubeDL(parseOpts(yes_postprocess=True))
    gen_extractors(ydl)
    tp_home = next(
        e for e in list_extractors(ydl)
        if e.IE_NAME == 'tvplayhome')

    assert tp_home._VALID_URL == re.compile(
        r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    ).pattern

    assert tp_

# Generated at 2022-06-26 13:03:38.583290
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()
    assert tvplay.IE_NAME == 'mtg'
    assert tvplay.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:39.767665
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()

# Generated at 2022-06-26 13:03:50.391102
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')

# Generated at 2022-06-26 13:03:52.339306
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('www', 'dk')
    assert ie._VALID_URL == ViafreeIE._VALID_URL.replace('(?P<country>dk|no|se)', 'dk')
    assert ie._GEO_BYPASS == False




# Generated at 2022-06-26 13:03:58.350539
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert(ie._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)')


# Generated at 2022-06-26 13:04:12.593451
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    from .common import InfoExtractor
    from .common import _is_valid_url

    ie = InfoExtractor
    ie = ViafreeIE

    # Match
    assert ie._VALID_URL == ViafreeIE._VALID_URL
    assert ie.suitable(ie._VALID_URL)
    assert ie._GEO_BYPASS == False
    assert ie.IE_NAME == "viafree"
    assert ie.IE_DESC == "MTV Networks sites"

    # Country part of URL
    m = re.match(ie._VALID_URL, u'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert m.group('country') == 'no'

# Generated at 2022-06-26 13:04:19.631945
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Try creating an instance of class ViafreeIE
    ie = ViafreeIE()
    # Test whether the class was initialized correctly
    assert ie.name == 'Viafree'
    assert ie.suitable(ie.VALID_URL)
    assert ie.suitable(ie.VALID_URL_TEMPLATE)

# Generated at 2022-06-26 13:04:20.307251
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE

# Generated at 2022-06-26 13:04:24.408525
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Check if .IE_NAME and .IE_DESC are defined
    """
    ie = TVPlayIE()
    assert ie.IE_NAME
    assert ie.IE_DESC



# Generated at 2022-06-26 13:05:13.185559
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class TestViafreeIE(ViafreeIE):
        _VALID_URL = ViafreeIE._VALID_URL

        def _real_extract(self, url):
            return self.url_result(url)

    ie = TestViafreeIE()
    assert isinstance(ie.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'), type(True))
    assert ie.url_result('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1').url == 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'

# Generated at 2022-06-26 13:05:19.824338
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    import unittest
    from unittest import TestCase, TestSuite
    from unittest import TextTestRunner, TestLoader
    from unittest.mock import Mock
    from io import StringIO
    from collections import OrderedDict
    from youtube_dl.compat import compat_urllib_request
    # Create a mock "compat_urllib_request.urlopen" function.
    compat_urllib_request.urlopen = Mock()
    request = Mock()
    # Create a mock "StringIO" object.
    stringIO = StringIO()
    stringIO.write(json.dumps({'assetId': 718206}))
    stringIO.seek(0)
    request.read = stringIO.read
    compat_urllib_request.urlopen.return_value = request
    #

# Generated at 2022-06-26 13:05:21.535522
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:05:35.094224
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Values taken from a test
    guid = 757817
    streams = {
        "streams": {
            "high": "https://viafree-hls-eu.mtgx.tv/viafree/nrk_vf_kreditering1/mp4/high/index.m3u8",
            "medium": "https://viafree-hls-eu.mtgx.tv/viafree/nrk_vf_kreditering1/mp4/medium/index.m3u8",
            "low": "https://viafree-hls-eu.mtgx.tv/viafree/nrk_vf_kreditering1/mp4/low/index.m3u8"
        }
    }

# Generated at 2022-06-26 13:05:46.934366
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class MockInput:
        def __init__(self):
            self.string = ""

        def readline(self):
            ret = self.string
            self.string = ""
            return ret

        def write(self, s):
            self.string += s

    m = MockInput()

    # Test for ViafreeIE._real_initialize()
    V = ViafreeIE(m)
    m.readline()
    assert m.string == V._GEO_COUNTRIES + '\n'

    # Test for ViafreeIE._real_extract()
    V.extract('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')

    # Test for ViafreeIE.suitable()

# Generated at 2022-06-26 13:05:51.424867
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    test_url = 'http://www.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true'

    tvp = TVPlayIE()
    tvp._get_video_info(test_url)



# Generated at 2022-06-26 13:06:04.480960
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    module = import_module('youtube_dl.extractor.tvplay')
    TVPlayHomeIE = module.TVPlayHomeIE
    url = 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/'
    assert TVPlayHomeIE.suitable(url)
    result = TVPlayHomeIE.__call__(TVPlayHomeIE(), url)
    assert isinstance(result, TVPlayHomeIE)
    assert 'id' in result.__dict__
    assert result.__dict__['id'] == '366367'
    assert 'url' in result.__dict__
    assert result.__dict__['url'] == url
    assert '_downloader' in result.__dict__
    assert result.__dict__['_downloader'] is not None


# Generated at 2022-06-26 13:06:17.376306
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    info = ViafreeIE()._real_extract(
        'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')
    assert info.get('id') == 'mf9q3qx8'
    assert info.get('title') == 'Paradise Hotel - Sæson 7 - Episode 5'
    assert info.get('description') == 'md5:f90e7f79c8e3a39dcc038b69d9f4c4c4'
    assert info.get('series') == 'Paradise Hotel'
    assert info.get('season_number') == 7
    assert info.get('episode_number') == 5
    assert info.get('duration') == 2260
    assert info.get('timestamp') == 1392246

# Generated at 2022-06-26 13:06:18.074695
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE("mtg:418113")



# Generated at 2022-06-26 13:06:30.045562
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # Constructor of class TVPlayIE
    ie = TVPlayIE()
    # Validate correct initialization of TVPlayIE
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:08:06.031017
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    class_ = globals()['ViafreeIE']
    instance = class_()
    assert (instance.suitable('http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')) is True
    assert (instance.suitable('http://play.tv2.no/programmer/reality/paradise-hotel/saeson-15/episode-1')) is False
    assert (instance.suitable('http://play.tv2.no/programmer/underholdning/jakten-pa-kjaerligheten-sjaaheim/sesong-13/episode-1')) is False

# Generated at 2022-06-26 13:08:10.855249
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    ie._real_initialize()


# Generated at 2022-06-26 13:08:15.566862
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayIE = TVPlayIE()
    tvplayIE.IE_NAME

# Generated at 2022-06-26 13:08:19.990259
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    """Unit test for constructor of class TVPlayHomeIE."""
    tph = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-10047125/')
    assert str(tph) == '<TVPlayHomeIE https://tvplay.tv3.lt/aferistai-10047125/>'



# Generated at 2022-06-26 13:08:22.347821
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    inst = TVPlayHomeIE('TVPlayHome')
    assert inst.name == 'TVPlayHome'

# Generated at 2022-06-26 13:08:24.992566
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    return TVPlayHomeIE('test', 'https://play.tv3.lt/aferistai-10047125')

# Generated at 2022-06-26 13:08:26.619516
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert (TVPlayHomeIE()._VALID_URL == TVPlayHomeIE._VALID_URL)

# Generated at 2022-06-26 13:08:35.840883
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from __main__ import IE_NAME, IE_DESC
    from .ttv_embed import TTVEmbedIE
    from .tv4 import TV4IE
    from .tv3 import TV3IE
    from .tv6 import TV6IE
    from .tv3play import TV3PlayIE
    from .tv9play import TV9PlayIE
    from .tv8play import TV8PlayIE
    from .viasat4 import Viasat4IE
    from .tv3play_no import TV3PlayNoIE
    from .tv3play_se import TV3PlaySeIE
    from .tv3play_dk import TV3PlayDKIE
    from .tv3play_lv import TV3PlayLVIE
    from .tv3play_lt import TV3PlayLTI
    from .viafree import ViafreeIE

# Generated at 2022-06-26 13:08:48.934735
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """
    Basic test of TVPlayIE.constructor
    """
    ie_obj = TVPlayIE()

    # Check if _VALID_URL is a valid URL matching _VALID_URL
    valid_url = ie_obj._VALID_URL
    m = re.match(valid_url, valid_url)
    assert m is not None

    # Check if _VALID_URL is not a valid URL matching _VALID_URL
    invalid_url = 'http://www.viasat.se/program/en-sak-ar-sak/sasong-1/avsnitt-1'
    m = re.match(valid_url, invalid_url)
    assert m is None

# Generated at 2022-06-26 13:09:03.153845
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE('http://www.tv3play.lv/parraides/vinas-melo-labak/418113?autostart=true')
    assert ie.IE_NAME == 'mtg'