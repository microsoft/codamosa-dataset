

# Generated at 2022-06-26 13:02:34.185952
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    _ = ViafreeIE()

# Generated at 2022-06-26 13:02:35.788739
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafreeIE = ViafreeIE()

# Generated at 2022-06-26 13:02:37.089167
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
  t_v_play_home_i_e = ViafreeIE()

# Generated at 2022-06-26 13:02:39.142336
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:47.545908
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    a = TVPlayIE()._real_extract('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113?autostart=true')
    b = TVPlayIE()._real_extract('http://www.tvplay.lv/parraides/vinas-melo-labak/418113')
    c = TVPlayIE()._real_extract('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229')
    d = TVPlayIE()._real_extract('http://www.tv3play.ee/sisu/kodu-keset-linna/238551')


# Generated at 2022-06-26 13:02:48.984093
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_home_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:02:50.628059
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_free_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:02:52.143539
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:02:52.903842
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    pass


# Generated at 2022-06-26 13:02:54.355420
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i = ViafreeIE()


# Generated at 2022-06-26 13:03:18.236120
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE_inst = TVPlayIE()
    assert TVPlayIE_inst._VALID_URL == TVPlayIE._VALID_URL
    assert TVPlayIE_inst.IE_NAME == TVPlayIE.IE_NAME
    assert TVPlayIE_inst.IE_DESC == TVPlayIE.IE_DESC



# Generated at 2022-06-26 13:03:28.385311
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    class_ = TVPlayIE
    instance = class_()
    assert instance.IE_NAME == "mtg"
    assert instance.IE_DESC == "MTG services"

# Generated at 2022-06-26 13:03:34.735360
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None)
    assert ie.geo_countries == ['LT', 'LV', 'EE']



# Generated at 2022-06-26 13:03:49.201996
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    """Test TVPlayIE constructor"""
    ie = TVPlayIE()
    ie_name = ie.IE_NAME
    ie_desc = ie.IE_DESC
    _VALID_URL = ie._VALID_URL
    _TESTS = ie._TESTS
    # test that the extractor implements a generic test for valid urls
    assert ie.suitable('%s/mtg:418113' % _VALID_URL)
    assert ie.suitable('http://play.tv3.lt/programos/moterys-meluoja-geriau/409229?autostart=true')
    assert ie.suitable('http://play.tv3play.lt/programos/moterys-meluoja-geriau/409229?autostart=true')

# Generated at 2022-06-26 13:03:54.822200
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE(None, None)
    assert hasattr(ie, 'format_id')
    assert hasattr(ie, 'age_limit')
    assert hasattr(ie, 'extractor')
    assert hasattr(ie, 'formats')


# Generated at 2022-06-26 13:04:05.388665
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME == 'mtg'
    assert ie.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:04:09.016931
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    url = 'http://www.tv3play.se/program/husraddarna/395385?autostart=true'
    tvplayie = TVPlayIE()
    tvplayie._real_initialize()
    tvplayie._real_extract(url)


# Generated at 2022-06-26 13:04:13.030005
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    """Test constructor of class ViafreeIE."""
    viafree_ie = ViafreeIE()
    assert viafree_ie.geo_countries == ['DK', 'NO', 'SE']

# Generated at 2022-06-26 13:04:15.078134
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE('asd', _init_opener=True)




# Generated at 2022-06-26 13:04:20.123627
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE("https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/")
    assert ie.get_id() == '366367'


# Generated at 2022-06-26 13:05:01.346829
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    TVPlayHomeIE(url)._download_json('https://tvplay.tv3.lt/sb/public/asset/366367', '366367')

# Generated at 2022-06-26 13:05:12.216130
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'tvplay'
    assert TVPlayIE.IE_DESC == 'TVPlay.lv and similar services'
    assert TVPlayIE.TVPLAY_URL_TEMPLATE == 'http://tvplay.skaties.lv/parraides/%s'
    assert TVPlayIE.STREAMS_URL_TEMPLATE == 'http://playapi.mtgx.tv/v3/videos/stream/%s'
    assert TVPlayIE.VIDEO_URL_TEMPLATE == 'http://playapi.mtgx.tv/v3/videos/%s'


# Generated at 2022-06-26 13:05:24.621576
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    a = TVPlayHomeIE(url)
    print(a)
    assert a._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'

# Generated at 2022-06-26 13:05:35.982486
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE(None, 'https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/')
    TVPlayHomeIE(None, 'https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/')
    TVPlayHomeIE(None, 'https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE(None, 'https://tv3play.skaties.lv/vinas-melo-labak-10280317')
    TVPlayHomeIE(None, 'https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')

# Generated at 2022-06-26 13:05:43.655299
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    class MockM3U8IE(M3U8IE):
        def _real_extract(self, url):
            return {
                'id': '123456',
                'formats': [{
                    'url': 'http://example.com',
                    'quality': 4,
                    'ext': 'mp4',
                }]
            }
    ie = TVPlayHomeIE({}, {}, {}, MockM3U8IE)

    assert ie._real_extract({}) == {'formats': [{
        'url': 'http://example.com',
        'quality': 4,
        'ext': 'mp4',
    }], 'id': '123456'}

# Generated at 2022-06-26 13:05:50.923607
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE()
    ie.extract('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')
    ie.extract('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-26 13:05:52.424219
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert ViafreeIE



# Generated at 2022-06-26 13:05:57.641985
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    test_url = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'

    test_viafreeIE = ViafreeIE()

    assert test_viafreeIE.suitable(test_url) == True

    test_url = 'http://tvplay.skaties.lv/parraides/tv3-zinas/760183'

    assert test_viafreeIE.suitable(test_url) == False

# Generated at 2022-06-26 13:05:59.045006
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE.suitable(TVPlayHomeIE._VALID_URL)
    assert TVPlayHomeIE.suitable('https://tvplay.tv3.lt/filmai/pagrindine') == False

# Generated at 2022-06-26 13:05:59.965791
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ue = TVPlayHomeIE()
    assert ue is not None

# Generated at 2022-06-26 13:07:35.972676
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert not ViafreeIE.suitable(None, '')
    assert not ViafreeIE.suitable(None, 'http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898')
    assert ViafreeIE.suitable(None, 'http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')

# Generated at 2022-06-26 13:07:50.390376
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # no geo restriction
    ViafreeIE._GEO_BYPASS = False

    tester = ViafreeIE()
    assert not tester.suitable('http://www.tv3play.se/program/sport/super-bowl-50/720741?autostart=true')
    assert TVPlayIE.suitable('http://www.tv3play.se/program/sport/super-bowl-50/720741?autostart=true')
    assert tester.suitable('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')

    # geo restriction
    ViafreeIE._GEO_BYPASS = True
    tester = ViafreeIE()

# Generated at 2022-06-26 13:08:03.929413
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    c = TVPlayIE()
    c._initialize_geo_bypass({'countries': 'LV'})
    url = 'http://www.tvplay.lv/parraides/vinas-melo-labak/418113?autostart=true'
    result = c._real_extract(url)
    assert result['id'] == '418113'
    assert result['title'] == 'Kādi ir īri? - Viņas melo labāk'
    assert result['description'] == 'Baiba apsmej īrus, kādi tie ir un ko viņi dara.'
    assert result['series'] == 'Viņas melo labāk'
    assert result['season'] == '2.sezona'
    assert result['season_number'] == 2

# Generated at 2022-06-26 13:08:07.003563
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert re.match(ie._VALID_URL, ie._VALID_URL)
    assert hasattr(ie, '_GEO_COUNTRIES')


# Generated at 2022-06-26 13:08:12.653964
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    from nose.tools import raises

    with raises(RegexNotFoundError):
        TVPlayIE('http://www.test/test.lv/test/test/test')._VALID_URL

    assert TVPlayIE._VALID_URL


# Generated at 2022-06-26 13:08:18.702471
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj.PLAYER_URL.endswith(obj.IE_NAME + '/player.json')
    assert obj.PLAYER_URL.has_key(obj.IE_NAME)

# Generated at 2022-06-26 13:08:26.011811
# Unit test for constructor of class TVPlayIE

# Generated at 2022-06-26 13:08:27.560367
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie._VALID_URL == ie._TESTS[0]['url']



# Generated at 2022-06-26 13:08:31.027211
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    obj = ViafreeIE("test_2", "http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1")
    assert obj.name == "test_2"
    assert obj.country == "no"



# Generated at 2022-06-26 13:08:32.474005
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:12:10.221490
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/', 'test')
    assert ie._GEO_BYPASS == False
    ie = TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125', 'test')
    assert ie._GEO_BYPASS == True
    ie = TVPlayHomeIE('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/', 'test')
    assert ie._GEO_BYPASS == False
    ie = TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317', 'test')
    assert ie._GEO_BYPASS == True


# Generated at 2022-06-26 13:12:11.595333
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE(None)

    m = ie._VALID_URL
    m.group('id')