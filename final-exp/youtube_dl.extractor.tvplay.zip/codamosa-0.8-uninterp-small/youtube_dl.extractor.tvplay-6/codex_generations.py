

# Generated at 2022-06-26 13:02:43.418913
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert viafree_i_e._VALID_URL == r'''(?x)
                    https?://
                        (?:www\.)?
                        viafree\.(?P<country>dk|no|se)
                        /(?P<id>program(?:mer)?/(?:[^/]+/)+[^/?#&]+)
                    '''

# Generated at 2022-06-26 13:02:44.624702
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:02:56.567189
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test with valid url
    tvplay_1 = TVPlayHomeIE()
    tvplay_1.extract(
        'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tvplay_2 = TVPlayHomeIE()
    tvplay_2.extract(
        'https://play.tv3.lt/aferistai-n-7/aferistai-10047125/')
    tvplay_3 = TVPlayHomeIE()
    tvplay_3.extract('https://tv3play.skaties.lv/vinas-melo-labak-10280317/')
    tvplay_4 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:58.003830
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    via_f_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:03:08.359383
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:09.997815
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Case 0
    viafree = ViafreeIE()
    assert viafree is not None



# Generated at 2022-06-26 13:03:10.921225
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:11.519564
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:03:12.455466
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    v_f_i_e = ViafreeIE()

# Generated at 2022-06-26 13:03:13.765829
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    vf_instance = ViafreeIE()


# Generated at 2022-06-26 13:03:50.275768
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:51.733343
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:55.653978
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:57.470247
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:04:00.245733
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert re.sub(r'^.*?(?=\n.*?^#)', '', test_case_0.__doc__, 1, re.M | re.S).startswith('# Unit test for constructor of class TVPlayIE')


# Generated at 2022-06-26 13:04:06.349708
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()


# Generated at 2022-06-26 13:04:07.378096
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:04:08.599807
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:04:10.291477
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    instance = ViafreeIE()
    assert isinstance(instance, ViafreeIE)


# Generated at 2022-06-26 13:04:11.959068
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_ViafreeIE = ViafreeIE()

# Generated at 2022-06-26 13:05:27.561337
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:05:32.455502
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_viafree_i_e_0 = ViafreeIE()

if __name__ == '__main__':
    from unit_test import test_case_0, test_ViafreeIE

    test_case_0()
    test_ViafreeIE()

# Generated at 2022-06-26 13:05:37.697203
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # t_v_play_i_e = TVPlayIE()
    t_v_play_i_e = TVPlayIE.TVPlayIE
    assert t_v_play_i_e is not None


# Generated at 2022-06-26 13:05:42.833647
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert issubclass(TVPlayHomeIE, InfoExtractor)
    assert TVPlayHomeIE.__name__ == 'TVPlayHomeIE'
    assert TVPlayHomeIE._VALID_URL == TVPlayHomeIE._VALID_URL


# Generated at 2022-06-26 13:05:44.277503
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:05:46.416830
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert callable(TVPlayIE)

# Generated at 2022-06-26 13:05:47.936567
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()

# Generated at 2022-06-26 13:05:52.505891
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()
    assert viafree_i_e_0 is not None
    viafree_i_e_1 = ViafreeIE()
    assert viafree_i_e_0 is not viafree_i_e_1
    assert viafree_i_e_1 is not None


# Generated at 2022-06-26 13:05:53.519934
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:05:56.639638
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:08:39.351492
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_viafree_i_e = ViafreeIE()

# Generated at 2022-06-26 13:08:42.126298
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:08:44.822505
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:08:48.076214
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_h_o_me_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:08:49.132969
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e = ViafreeIE()

# Generated at 2022-06-26 13:09:03.278635
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e_0 = TVPlayHomeIE()
    assert t_v_play_home_i_e_0._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    t_v_play_home_i_e_1 = TVPlayHomeIE()
    assert t_v_play_home_i_e_1._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'



# Generated at 2022-06-26 13:09:04.522146
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    try:
        ViafreeIE()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 13:09:05.051230
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE()

# Generated at 2022-06-26 13:09:07.716495
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE().IE_NAME == 'mtg'
    assert TVPlayIE().IE_DESC == 'MTG services'


# Generated at 2022-06-26 13:09:09.705549
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t = TVPlayHomeIE()
    t._initialize_geo_bypass({'countries': ['NO']})
