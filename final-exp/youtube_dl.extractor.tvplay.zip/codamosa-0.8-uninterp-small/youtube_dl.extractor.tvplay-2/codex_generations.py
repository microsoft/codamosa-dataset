

# Generated at 2022-06-26 13:02:36.960677
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert TVPlayHomeIE()

# Generated at 2022-06-26 13:02:38.190399
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()


# Generated at 2022-06-26 13:02:39.073740
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(TVPlayIE())


# Generated at 2022-06-26 13:02:40.305416
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:41.734360
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:02:43.053869
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_0 = ViafreeIE()

# Generated at 2022-06-26 13:02:44.897869
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    assert_true(t_v_play_i_e)


# Generated at 2022-06-26 13:02:51.165696
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert hasattr(TVPlayIE, '_VALID_URL')

# Generated at 2022-06-26 13:02:52.468729
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()

# Generated at 2022-06-26 13:02:55.342466
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    # TODO: Check if number of arguments match that are passed to constructor
    t_v_play_i_e_1 = TVPlayIE()
    assert t_v_play_i_e_1 is not None



# Generated at 2022-06-26 13:03:29.557378
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e_1 = ViafreeIE()

# Generated at 2022-06-26 13:03:31.546066
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    t_v_play_i_e = TVPlayIE()
    pass



# Generated at 2022-06-26 13:03:40.614742
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.IE_NAME == 'mtg'
    assert TVPlayIE.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:43.301375
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    assert TVPlayIE.__name__ == 'TVPlayIE'



# Generated at 2022-06-26 13:03:48.670218
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_home_i_e = TVPlayHomeIE()



# Generated at 2022-06-26 13:03:49.894486
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_ie = ViafreeIE()


# Generated at 2022-06-26 13:03:50.715874
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    t_v_play_i_e = ViafreeIE()

# Generated at 2022-06-26 13:03:51.901951
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    t_v_play_h_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:56.623364
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert_raises(ExtractorError, TVPlayHomeIE, 'www.tv3play.skaties.lv/vinas-melo-labak-10280317')

# Generated at 2022-06-26 13:03:58.428943
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:04:41.544514
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    VIAFREE_TEST = 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1'
    VIAFREE_EXPECTED = 'https://viafree-content.mtg-api.com/viafree-content/v1/se/path/(program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1)'
    viafree_test_object = ViafreeIE()
    assert viafree_test_object._download_webpage(VIAFREE_TEST, '1') == VIAFREE_EXPECTED


# Generated at 2022-06-26 13:04:52.427075
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    m3u8_url = 'http://lb.tv3play.tv3.ee/et/hls_akamai/online_et/sb/1472366771/1472366771.m3u8?token=147236677152140a726b6a946c79e10a1a49b1c5a992a2a2a2'
    m3u8_id = 'hls'
    ie = TVPlayHomeIE()
    formats = ie._extract_m3u8_formats(
        m3u8_url, m3u8_id, 'mp4', 'm3u8_native', m3u8_id=m3u8_id)
    assert(len(formats) > 0)

# Generated at 2022-06-26 13:04:53.949960
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay = TVPlayIE()


# Generated at 2022-06-26 13:04:59.686105
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert isinstance(ie, TVPlayHomeIE)
    assert ie.IE_NAME == 'TVPlayHome'

# Generated at 2022-06-26 13:05:00.648420
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()



# Generated at 2022-06-26 13:05:11.508218
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from youtube_dl.extractor import YoutubeIE
    from youtube_dl.utils import url_or_none
    ie = TVPlayHomeIE('foo')
    assert ie.embed_url == url_or_none(ie.IE_NAME) == ie.ie_key() == 'foo'
    ie.embed_url = 'bar'
    assert url_or_none(ie.IE_NAME) == ie.ie_key() == 'bar'
    ie.embed_url = None
    assert url_or_none(ie.IE_NAME) == ie.ie_key() == YoutubeIE.ie_key()

# Generated at 2022-06-26 13:05:16.190764
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE(IE_NAME, 'http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')

# Generated at 2022-06-26 13:05:25.784523
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    ie = TVPlayIE()
    assert ie.IE_NAME ==  'mtg'
    assert ie.IE_DESC ==  'MTG services'

# Generated at 2022-06-26 13:05:36.891902
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    obj = TVPlayHomeIE()
    assert obj.IE_NAME == "MTG"
    assert obj.IE_DESC == "TV3, LNT, TV6 and TV8 video websites"
    assert obj._VALID_URL == r'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'
    assert obj.GEO_BYPASS == False
    assert obj.BRIGHTCOVE_URL_TEMPLATE == 'http://players.brightcove.net/%s/' + 'default_default/index.html?videoId=%s'

# Generated at 2022-06-26 13:05:45.713600
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE('viafree.se')
    assert ie.url_result('http://www.viafree.se/program/underhallning/i-like-radio-live/sasong-1/676869')
    assert not ie.url_result('http://play.tv2.no/programmer/serier/hotell-c%C3%A6sar/3836/sesong/3/episode/1')
    assert not ie.url_result('http://www.tv3play.no/programmer/anna-anka-soker-assistent/230898?autostart=true')

# Generated at 2022-06-26 13:07:00.465069
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE('http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2')


# Generated at 2022-06-26 13:07:01.149332
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    # Tested by TVPlayIE
    pass

# Generated at 2022-06-26 13:07:03.220593
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ie = ViafreeIE(None)
    assert isinstance(ie, ViafreeIE)

# Generated at 2022-06-26 13:07:11.708980
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    m = TVPlayHomeIE('TVPlayHomeIE', 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    assert(m.countries == ['LT', 'LV', 'EE'])



# Generated at 2022-06-26 13:07:16.715243
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    tvplayhome_ie = TVPlayHomeIE()
    assert tvplayhome_ie.suitable(url)
    assert isinstance(tvplayhome_ie, TVPlayHomeIE)

# Generated at 2022-06-26 13:07:17.670163
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE

# Generated at 2022-06-26 13:07:20.543085
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert type(ViafreeIE({})) is ViafreeIE


# Generated at 2022-06-26 13:07:28.265685
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
  video_id = '366367'
  url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
  ie = TVPlayHomeIE()
  ie._real_initialize()
  ie.extract(url)
  # ie.extract('https://tv3play.skaties.lv/vinas-melo-labak-10280317')
  # ie.extract('https://play.tv3.ee/cool-d-ga-mehhikosse-10044354')
  # ie.extract('https://play.tv3.lt/aferistai-10047125')



# Generated at 2022-06-26 13:07:41.753301
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    def test_match(url):
        m = TVPlayHomeIE._VALID_URL_RE.match(url)
        if m:
            return m.groupdict()
    assert test_match('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/') == {'id': '10047125'}
    assert test_match('https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/') == {'id': '10280317'}
    assert test_match('https://tvplay.tv3.ee/cool-d-ga-mehhikosse/cool-d-ga-mehhikosse-10044354/') == {'id': '10044354'}
    assert test

# Generated at 2022-06-26 13:07:47.673790
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    from tv3play import TVPlayHomeIE
    TVPlayHomeIE('http://www.tv3play.no/programmer/underholdning/julekalendere/advent-advent/sesong-3/episode-1')

# Generated at 2022-06-26 13:10:45.878685
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplayie = TVPlayIE()
    assert tvplayie.IE_NAME == 'mtg'

# Generated at 2022-06-26 13:10:53.815300
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    x = TVPlayHomeIE()
    assert x._VALID_URL == 'https?://(?:tv3?)?play\.(?:tv3\.lt|skaties\.lv|tv3\.ee)/(?:[^/]+/)*[^/?#&]+-(?P<id>\d+)'


# Generated at 2022-06-26 13:11:01.059228
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    mainclass = class_from_name('ViafreeIE')
    assert mainclass.suitable(test_ViafreeIE._TESTS[0]) is False
    assert mainclass.suitable(test_ViafreeIE._TESTS[1]) is True
    assert mainclass.suitable(test_ViafreeIE._TESTS[2]) is True
    assert mainclass.suitable(test_ViafreeIE._TESTS[3]) is True
    assert mainclass.suitable(test_ViafreeIE._TESTS[4]) is True
    assert mainclass.suitable(test_ViafreeIE._TESTS[5]) is True



# Generated at 2022-06-26 13:11:09.044454
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    # Test an extractor with valid parameters
    TVPlayHomeIE('https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/')
    TVPlayHomeIE('https://play.tv3.lt/aferistai-10047125')
    TVPlayHomeIE('https://tv3play.skaties.lv/vinas-melo-labak-10280317')



# Generated at 2022-06-26 13:11:12.672710
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE.suitable('http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5')



# Generated at 2022-06-26 13:11:21.611126
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tmp = TVPlayHomeIE("https://tvplay.skaties.lv/vinas-melo-labak/vinas-melo-labak-10280317/")
    assert tmp.country == "lv"
    tmp = TVPlayHomeIE("https://tv3play.skaties.lv/vinas-melo-labak-10280317")
    assert tmp.country == "lv"
    tmp = TVPlayHomeIE("https://play.tv3.lt/aferistai-10047125")
    assert tmp.country == "lt"

# Generated at 2022-06-26 13:11:24.567126
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert re.match(ViafreeIE._VALID_URL, 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1')
    assert not ViafreeIE.suitable('http://tvplay.skaties.lv/parraides/vinas-melo-labak/418113')

# Generated at 2022-06-26 13:11:36.608637
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    from . import ViafreeIE

    test_cases = [
        'http://viafree.no/12345',
        'http://viafree.com/12345',
        'http://www.viafree.no/12345',
        'http://www.viafree.dk/12345',
        'http://www.viafree.se/12345'
    ]

    for url in test_cases:
        print(url)
        assert ViafreeIE._VALID_URL_TEMPLATE == ViafreeIE._VALID_URL
        assert len(ViafreeIE._VALID_URL_TEMPLATE) == len(ViafreeIE._VALID_URL)
        assert ViafreeIE._VALID_URL == re.compile(ViafreeIE._VALID_URL_TEMPLATE).match(url).group(0)


# Generated at 2022-06-26 13:11:38.280712
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()

# Generated at 2022-06-26 13:11:40.193120
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    ie = TVPlayHomeIE()
    assert ie

