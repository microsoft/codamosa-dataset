

# Generated at 2022-06-26 13:02:36.579475
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert 'ViafreeIE' == viafree_i_e.__class__.__name__


# Generated at 2022-06-26 13:02:37.869171
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:02:39.444448
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    x = ViafreeIE()
    assert x.get_IE().__name__ == 'ViafreeIE'


# Generated at 2022-06-26 13:02:44.625490
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_i_e_0._real_extract(url)

if __name__ == '__main__':
    from . import utils
    test_case_0()
    test_ViafreeIE()

# Generated at 2022-06-26 13:02:47.576434
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    assert(isinstance(TVPlayHomeIE(), InfoExtractor))


# Generated at 2022-06-26 13:02:48.983263
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_i_e = TVPlayIE()


# Generated at 2022-06-26 13:02:50.093577
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:02:58.492386
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert 'ViafreeIE' == viafree_i_e.ie_key()
    assert viafree_i_e._VALID_URL == viafree_i_e._TEST.valid()
    assert 'http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-1' == viafree_i_e._TEST.valid().url
    assert '757786' == viafree_i_e._TEST.valid().video_id


# Generated at 2022-06-26 13:03:08.675262
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():

     # Test for correct inheritance
    tvplay_i_e_1 = TVPlayIE()
    assert tvplay_i_e_1.IE_NAME == 'MTG'
    assert tvplay_i_e_1.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:03:10.259739
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert viafree_i_e !=""


# Generated at 2022-06-26 13:03:30.420787
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tvplay_i_e_0 = TVPlayIE()


# Generated at 2022-06-26 13:03:34.288559
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:38.691107
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():

    viafree_i_e_0 = ViafreeIE()
    test_case_0()


# Generated at 2022-06-26 13:03:40.213452
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e_0 = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:42.704111
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tv_play_home_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:44.026992
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:03:45.980749
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:03:49.353290
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()
    assert isinstance(instance, TVPlayIE)


# Generated at 2022-06-26 13:03:51.517082
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_i_e = TVPlayHomeIE()
    t_v_play_home_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:03:54.626208
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    via_free_i_e = ViafreeIE()
    assert via_free_i_e is not None


# Generated at 2022-06-26 13:04:35.602227
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    info_extractor = TVPlayIE()
    assert info_extractor.IE_NAME == 'mtg'
    assert info_extractor.IE_DESC == 'MTG services'

# Generated at 2022-06-26 13:04:36.839805
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:04:39.571244
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert(isinstance(viafree_i_e, InfoExtractor))


# Generated at 2022-06-26 13:04:42.352088
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    assert(viafree_i_e)


# Generated at 2022-06-26 13:04:44.499528
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_0 = ViafreeIE()


# Generated at 2022-06-26 13:04:46.445579
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlay = TVPlayIE()
    assert TVPlay.IE_NAME == 'mtg'

# Generated at 2022-06-26 13:04:48.789510
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()


# Generated at 2022-06-26 13:04:50.135973
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    tv_play_i_e = TVPlayIE()


# Generated at 2022-06-26 13:04:52.025773
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_1 = ViafreeIE()


# Generated at 2022-06-26 13:05:04.010975
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert(ViafreeIE.suitable("http://www.viafree.se/program/reality/sommaren-med-youtube-stjarnorna/sasong-1/avsnitt-2") == True)
    assert(ViafreeIE.suitable("http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1") == True)
    assert(ViafreeIE.suitable("http://www.viafree.dk/programmer/reality/paradise-hotel/saeson-7/episode-5") == True)
    assert(ViafreeIE.suitable("https://www.nakigoe.com/") == False)

    x = ViafreeIE()

# Generated at 2022-06-26 13:06:14.433564
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()
    if check_constuctor(viafree_i_e, 'VIAFREE_DOMAINS', 'VIAFREE_URL_TEMPLATE'):
        assert True
    else:
        assert False


# Generated at 2022-06-26 13:06:19.146714
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_obj = ViafreeIE()
    if not isinstance(viafree_i_e_obj, ViafreeIE):
        raise AssertionError("Constructor of ViafreeIE is broken")


# Generated at 2022-06-26 13:06:20.776491
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    instance = TVPlayIE()



# Generated at 2022-06-26 13:06:22.918919
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:06:26.035356
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_i_e_0 = TVPlayHomeIE()
    tvplay_home_i_e_1 = TVPlayHomeIE()


# Generated at 2022-06-26 13:06:33.960368
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    url = 'https://tvplay.tv3.lt/aferistai-n-7/aferistai-10047125/'
    #Test constructor of class TVPlayHomeIE
    if TVPlayHomeIE.suitable(url):
        assert True
    else:
        assert False


# Generated at 2022-06-26 13:06:35.082609
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:06:35.790232
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_i_e = TVPlayHomeIE()

# Generated at 2022-06-26 13:06:39.127880
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e = ViafreeIE()


# Generated at 2022-06-26 13:06:39.775356
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:09:16.789618
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree_i_e_1 = ViafreeIE()



# Generated at 2022-06-26 13:09:19.671766
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    ViafreeIE()


# Generated at 2022-06-26 13:09:20.505961
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    TVPlayHomeIE()

# Generated at 2022-06-26 13:09:23.825511
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.no/programmer/underholdning/det-beste-vorspielet/sesong-2/episode-1'
    viafree_i_e = ViafreeIE()
    # url
    assert url == viafree_i_e._VALID_URL
    # suiatble
    assert viafree_i_e.suitable(url)


# Generated at 2022-06-26 13:09:25.774887
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplayhome_i_e = TVPlayHomeIE()


# Generated at 2022-06-26 13:09:27.715562
# Unit test for constructor of class TVPlayHomeIE
def test_TVPlayHomeIE():
    tvplay_home_i_e_0 = TVPlayHomeIE()


# Generated at 2022-06-26 13:09:32.347699
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    viafree = ViafreeIE()
    assert viafree is not None


# Generated at 2022-06-26 13:09:34.525666
# Unit test for constructor of class TVPlayIE
def test_TVPlayIE():
    TVPlayIE()


# Generated at 2022-06-26 13:09:41.502473
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    url = 'http://www.viafree.se/program/livsstil/husraddarna/sasong-2/avsnitt-2'
    viafree_i_e = ViafreeIE()
    viafree_i_e.suitable(url)
    viafree_i_e.extract(url)


# Generated at 2022-06-26 13:09:47.231375
# Unit test for constructor of class ViafreeIE
def test_ViafreeIE():
    assert hasattr(ViafreeIE, '_VALID_URL'), "Missing attribute _VALID_URL"
    assert hasattr(ViafreeIE, '_TESTS'), "Missing attribute _TESTS"
    assert hasattr(ViafreeIE, '_GEO_BYPASS'), "Missing attribute _GEO_BYPASS"
    assert hasattr(ViafreeIE, 'suitable'), "Missing method suitable"
    assert hasattr(ViafreeIE, '_real_extract'), "Missing method _real_extract"
    assert hasattr(ViafreeIE, '_download_json'), "Missing method _download_json"
    assert hasattr(ViafreeIE, '_download_m3u8_formats'), "Missing method _download_m3u8_formats"