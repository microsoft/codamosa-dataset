

# Generated at 2022-06-17 03:29:17.874805
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSysctlDetectionMixin()
    assert mixin.detect_

# Generated at 2022-06-17 03:29:29.376932
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, name):
            return '/bin/%s' % name

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test 1: sysctl

# Generated at 2022-06-17 03:29:34.485729
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module

# Generated at 2022-06-17 03:29:41.836383
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    t = TestClass()
    assert t.detect_virt_vendor('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([])}


# Generated at 2022-06-17 03:29:54.181578
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test for kvm
    fake_virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin()
    fake_virtual_sysctl_detection_mixin.module.run

# Generated at 2022-06-17 03:30:04.945855
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModuleMock()

    class AnsibleModuleMock:
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_results.append((0, 'QEMU', ''))
            self.run_command_results.append((0, 'OpenBSD', ''))
            self.run_command_results.append((0, '', ''))

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return self.run_command_results.pop()

    virtual_sysctl_detection_mixin_test = VirtualSys

# Generated at 2022-06-17 03:30:16.732743
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    test_obj = VirtualSysctlDetectionMixinTest()
    test_obj.sysctl_path = '/usr/sbin/sysctl'
    test_obj.module = None
    test_obj.detect_virt_product('hw.model')
    assert test_obj.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-17 03:30:23.612645
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test with no sysctl
    module = TestModule(0, '', '')
    test_class = TestClass(module)
    test_class.sysctl_path = None
    assert test_class.detect_virt_vendor('hw.model') == {}

# Generated at 2022-06-17 03:30:28.993411
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:30:38.098662
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls

# Generated at 2022-06-17 03:30:52.841901
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:31:00.024994
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return self.rc, self.out, self.err

    # Test for KVM
    test_module = TestModule(0, 'KVM', '')
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = test_module
    test_obj.detect_sysctl()
    assert test_obj.sysctl_path == '/usr/bin/sysctl'

# Generated at 2022-06-17 03:31:05.753684
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()


# Generated at 2022-06-17 03:31:17.776666
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_result = (0, 'KVM', '')
            self.get_bin_path_result = '/sbin/sysctl'

        def get_bin_path(self, arg):
            return self.get_bin_path_result

        def run_command(self, arg):
            return self.run_command_result

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')
    assert v.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-17 03:31:27.883703
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:31:39.577316
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:52.195822
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'VirtualBox', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_sysctl()
    assert facts.sysctl_path == '/sbin/sysctl'

    virtual_product_facts = facts.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'virtualbox'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in virtual_product_facts

# Generated at 2022-06-17 03:32:04.496755
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/usr/sbin/sysctl',
                None,
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:32:17.648601
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeFacts:
        def __init__(self):
            self.sysctl_path = None

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.facts = FakeFacts()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')
    assert v.facts.virtualization_type == 'kvm'
    assert v.facts.virtualization_role == 'guest'


# Generated at 2022-06-17 03:32:25.737760
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 1.0', ''
            elif cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            elif cmd == '/sbin/sysctl -n security.jail.osreldate':
                return 0, '1200056', ''
            elif cmd == '/sbin/sysctl -n security.jail.host.hostuuid':
                return 0

# Generated at 2022-06-17 03:33:00.640391
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'QEMU', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_virt_vendor('machdep.cpu.brand_string')
    assert facts.virtualization_type == 'kvm'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['kvm'])
    assert facts.virtualization_tech_host == set()


# Generated at 2022-06-17 03:33:05.858169
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)


# Generated at 2022-06-17 03:33:17.631521
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', '')
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule

# Generated at 2022-06-17 03:33:28.736817
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, '', ''

    class FakeFacts(object):
        def __init__(self):
            self.sysctl_path = None
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_sysctl()
    assert facts.sysctl_path == '/sbin/sysctl'

    facts = FakeFacts()
    facts.detect_virt_product('hw.model')
    assert facts.virtualization_type == 'kvm'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['kvm'])
    assert facts.virtualization

# Generated at 2022-06-17 03:33:35.874978
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()

# Generated at 2022-06-17 03:33:44.336120
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:33:55.970215
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    test_obj = TestClass()
    test_obj.module = FakeAnsibleModule()
    test_obj.module.run_command = FakeRunCommand(0, 'QEMU', '')
    virtual_vendor_facts = test_obj.detect_virt_vendor('machdep.cpu.vendor')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:34:04.518423
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 2.5+', ''
            elif cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            elif cmd == '/sbin/sysctl -n hw.vendor':
                return 0, 'QEMU', ''
            else:
                return 0, '', ''


# Generated at 2022-06-17 03:34:18.372384
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, arg, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with QEMU
   

# Generated at 2022-06-17 03:34:25.074035
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    mixin = FakeSysctlDetectionMixin()
    mixin.sysctl_path

# Generated at 2022-06-17 03:35:39.761127
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:35:49.776727
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = [0]

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run

# Generated at 2022-06-17 03:36:00.959505
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:36:08.882070
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:19.133655
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test for KVM
    module = MockModule(0, 'KVM', '')
    sysctl_detection_mixin = MockSysctlDetectionMixin(module)

# Generated at 2022-06-17 03:36:31.479116
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeFacter(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-17 03:36:37.434655
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class Module:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_rc_map = {}
            self.run_command_out_map = {}
            self.run_command_err_map = {}

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'


# Generated at 2022-06-17 03:36:50.075196
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:37:01.555590
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test virtualization_type and virtualization_role
    module = TestModule(0, 'KVM', '')
    test_class = TestClass(module)

# Generated at 2022-06-17 03:37:10.024339
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)
