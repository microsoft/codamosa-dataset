

# Generated at 2022-06-17 03:29:19.295061
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/sbin/sysctl',
                None,
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:29:30.293732
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module

# Generated at 2022-06-17 03:29:41.918994
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:29:47.875116
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:29:58.373940
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()

# Generated at 2022-06-17 03:30:08.380171
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_result = (0, 'KVM', '')
            self.get_bin_path_result = '/sbin/sysctl'

        def get_bin_path(self, arg):
            return self.get_bin_path_result

        def run_command(self, arg):
            return self.run_command_result

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake_virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin()

# Generated at 2022-06-17 03:30:15.095362
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_args.append(args)
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl


# Generated at 2022-06-17 03:30:24.708612
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU', ''
            elif cmd == '/sbin/sysctl -n hw.machine':
                return 0, 'OpenBSD', ''
            else:
                return 1, '', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_vendor('hw.model')
    assert test_class.virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert test_

# Generated at 2022-06-17 03:30:36.575093
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts

# Generated at 2022-06-17 03:30:43.805443
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule(0, 'QEMU', '')
    test_class = TestClass(module)
    virtual_vendor_facts = test_class.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
   

# Generated at 2022-06-17 03:31:03.323812
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'KVM'
            self.run_command_err = ''

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with KVM
    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')

# Generated at 2022-06-17 03:31:16.894636
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/sbin/sysctl'

        def get_bin_path(self, path):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_

# Generated at 2022-06-17 03:31:27.216986
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=False):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    obj = FakeVirtualSysctlDet

# Generated at 2022-06-17 03:31:38.945931
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

# Generated at 2022-06-17 03:31:51.340281
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:56.972363
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:32:08.840306
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module

# Generated at 2022-06-17 03:32:18.912153
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    obj = FakeSysctlDetectionMixin()
    obj.detect_

# Generated at 2022-06-17 03:32:30.276870
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:32:41.311052
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    fake_module = FakeModule()
    fake_class = FakeClass(fake_module)
    fake_class.detect_sysctl()
    assert fake_class.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-17 03:33:19.740664
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, _):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self

# Generated at 2022-06-17 03:33:29.978171
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    v = VirtualSysctlDetectionMixin_test()
    v.detect_sysctl = MagicMock(return_value=None)
    v.module = MagicMock()
    v.module.run_command = MagicMock(return_value=(0, 'KVM', ''))
    v.detect_virt_product('machdep.cpu.features')
    assert v.sysctl_path == '/sbin/sysctl'
    assert v.module.run_command.call_count == 1

# Generated at 2022-06-17 03:33:37.918100
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = ['/usr/sbin/sysctl']
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:33:42.661975
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixin_freebsd
    from ansible.module_utils.facts.virtual.netbsd import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixin_netbsd
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixin_openbsd
    from ansible.module_utils.facts.virtual.dragonfly import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixin_dragonfly

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = MockRunCommand

# Generated at 2022-06-17 03:33:51.023884
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:33:59.204592
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()


# Generated at 2022-06-17 03:34:09.622299
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_calls = []

        def get_bin_path(self, arg, opt_dirs=[]):
            self.get_bin_path_calls.append(arg)
            return self.get_bin_path_results.pop(0)

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:34:18.378715
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeFacts(object):
        def __init__(self):
            self.sysctl_path = None
            self.module

# Generated at 2022-06-17 03:34:23.530503
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    test_obj = VirtualSysctlDetectionMixinTest()
    test_obj.sysctl_path = '/sbin/sysctl'
    test_obj.module = None
    test_obj.detect_virt_product('hw.model')
    assert test_obj.sysctl_path == '/sbin/sysctl'
    assert test_obj.module == None


# Generated at 2022-06-17 03:34:33.039861
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:35:45.553477
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'KVM'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/sbin/sysctl'

        def get_bin_path(self, path):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_product

# Generated at 2022-06-17 03:35:53.074078
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_called = False
            self.get_bin_path_rc = 0
            self.get_bin_path_path = ''
            self.get_bin_path_called = False

        def get_bin_path(self, path):
            self.get_bin_path_called = True
            self.get_bin_path_path = path
            return self.get_bin_path_path

        def run_command(self, cmd):
            self.run_command_called = True
            self.run_command_cmd = cmd
            return self.run_command_rc, self.run_command

# Generated at 2022-06-17 03:36:01.244864
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    test_obj = VirtualSysctlDetectionMixin_test()
    test_obj.module = FakeModule()
    test_obj.module.run_command = FakeRunCommand()
    test_obj.module.run_command.rc = 0
    test_obj.module.run_command.out = 'KVM'
    test_obj.module.run_command.err = ''
    result = test_obj.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
   

# Generated at 2022-06-17 03:36:09.130248
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, arg):
            return self.bin_path

        def run_command(self, arg):
            return 0, 'KVM', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_product('hw.model')
    assert test_class.sysctl_path == '/usr/bin/sysctl'
    assert test_class.module.run_command.call_count == 1

# Generated at 2022-06-17 03:36:19.377188
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_sysctl()
    assert v.sysctl_path == '/sbin/sysctl'

    facts = v.detect_virt_product('hw.model')
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_guest'] == set(['kvm'])
   

# Generated at 2022-06-17 03:36:31.771837
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:39.902956
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    mixin = FakeVirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    assert mixin.detect_virt_product('hw.model') == {}

   

# Generated at 2022-06-17 03:36:51.721042
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    assert v.detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-17 03:37:02.114392
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            if cmd == '/bin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 1.0.2', ''
            elif cmd == '/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            else:
                return 0, '', ''

    class FakeFacts(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-17 03:37:15.944359
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)
