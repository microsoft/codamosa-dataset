

# Generated at 2022-06-17 03:29:10.638648
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_path = ''

        def get_bin_path(self, path):
            return self.run_command_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with a KVM guest
    fake_virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin()
    fake_virtual_sysctl

# Generated at 2022-06-17 03:29:21.331851
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake_virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin()
    virtual_product_facts = fake_virtual_sysctl_detection_mixin.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-17 03:29:29.806897
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()


# Generated at 2022-06-17 03:29:41.452647
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
        def get_bin_path(self, arg, *args, **kwargs):
            return '/sbin/sysctl'
        def run_command(self, arg, *args, **kwargs):
            self.run_command_calls.append(arg)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    mixin = FakeVirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    assert mixin.detect_virt_

# Generated at 2022-06-17 03:29:52.058810
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append(name)
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd == '/bin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 2.5+', ''
            if cmd == '/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''

# Generated at 2022-06-17 03:29:58.130208
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
   

# Generated at 2022-06-17 03:30:08.196678
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = '/usr/bin/sysctl'
            self.module = FakeModule()

    class FakeModule:
        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            if cmd == '/usr/bin/sysctl -n hw.model':
                return 0, 'QEMU', ''
            elif cmd == '/usr/bin/sysctl -n hw.machine':
                return 0, 'OpenBSD', ''
            else:
                return 1, '', ''

    virtual_sysctl_detection_mixin_test = VirtualSysctlDetectionMixinTest()
    virtual_vendor_facts

# Generated at 2022-06-17 03:30:20.767497
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'KVM'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/usr/bin/sysctl'

        def get_bin_path(self, path):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = Module()

    v = VirtualSysctlDetectionMixinTest()
    v.det

# Generated at 2022-06-17 03:30:31.337442
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetection

# Generated at 2022-06-17 03:30:41.558417
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/usr/sbin/sysctl'
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:31:02.211107
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/sbin/sysctl',
                None,
            ]
            self.get_bin_path_calls = []

       

# Generated at 2022-06-17 03:31:09.743619
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return self.rc, self.out, self.err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test with kvm
    module = FakeModule(0, 'KVM', '')
    v = FakeVirtualSysctlDetectionMixin(module)
    facts = v.detect_virt_product('hw.model')

# Generated at 2022-06-17 03:31:20.394888
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:27.395218
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/sbin/sysctl',
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:31:39.110290
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:31:51.662538
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    test_class = TestClass()
    test_class.module = FakeModule()
    test_class.module.run_command = FakeRunCommand()
    test_class.module.run_command.return_value = (0, 'QEMU', '')
    result = test_class.detect_virt_vendor('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' in result['virtualization_tech_guest']
    assert len

# Generated at 2022-06-17 03:32:04.184850
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class FakeOpenBSD(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeLinux(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeFreeBSD(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    openbsd = FakeOpenBSD(module)
    linux = FakeLinux(module)
    freebsd = FakeFreeBSD(module)

    assert openbsd.detect

# Generated at 2022-06-17 03:32:17.754082
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'


# Generated at 2022-06-17 03:32:29.891921
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = facts.module
    virtual_sysctl_detection_mixin.detect_sysctl()
    virtual_product_facts = virtual_sysctl_detection_mixin.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product

# Generated at 2022-06-17 03:32:40.316976
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    mixin = FakeVirtualSysctlDet

# Generated at 2022-06-17 03:33:17.524164
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            if args == '/bin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 2.5+', ''
            if args == '/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''

# Generated at 2022-06-17 03:33:28.737275
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            if args == '/bin/sysctl -n hw.model':
                return 0, 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz', ''
            elif args == '/bin/sysctl -n hw.machine':
                return 0, 'amd64', ''

# Generated at 2022-06-17 03:33:39.129171
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_sysctl()

# Generated at 2022-06-17 03:33:49.757961
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestSystem(object):
        def __init__(self):
            self.sys_name = 'FreeBSD'
            self.distribution = None
            self.release = None
            self

# Generated at 2022-06-17 03:33:57.851837
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:34:08.284597
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def __init__(self):
            self.run_command_result = (0, 'KVM', '')

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return self.run_command_result

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')
    assert v.module.run_command_result == (0, 'KVM', '')
    assert v.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-17 03:34:20.111145
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualHardware
    from ansible.module_utils.facts.virtual.freebsd import VirtualProduct
    from ansible.module_utils.facts.virtual.freebsd import VirtualVendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctl
    from ansible.module_utils.facts.virtual.freebsd import VirtualDmesg
    from ansible.module_utils.facts.virtual.freebsd import VirtualZpool

# Generated at 2022-06-17 03:34:28.252262
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    test_object = VirtualSysctlDetectionMixinTest()
    test_object.sysctl_path = '/sbin/sysctl'
    test_object.module = None
    assert test_object.detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-17 03:34:34.202801
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:34:44.190572
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-17 03:35:50.052482
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_virt_vendor('hw.model')
    assert facts.module.exit_json.call_args[0][0]['virtualization_type'] == 'kvm'
    assert facts.module.exit_json.call_args[0][0]['virtualization_role'] == 'guest'


# Generated at 2022-06-17 03:36:00.997922
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:14.296779
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    # Test with no sysctl path
    mixin = MockVirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    assert mixin.detect_virt_vendor('hw.model') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

   

# Generated at 2022-06-17 03:36:25.756074
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:36.501091
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    virtual_sysctl_detection

# Generated at 2022-06-17 03:36:48.994093
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_product
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_jail
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_vmm
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_bhyve
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_xen

# Generated at 2022-06-17 03:36:59.748869
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    obj = FakeVirtualSysctlDetectionMixin()
    obj.sysctl_path = None


# Generated at 2022-06-17 03:37:09.716329
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSysctlDetectionMixin()


# Generated at 2022-06-17 03:37:17.426193
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_path = ''

        def get_bin_path(self, path):
            return self.run_command_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    test_obj = FakeVirtualSysctlDetectionMixin()
    test_obj.module.run_command_path = None
    result

# Generated at 2022-06-17 03:37:27.926062
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)
