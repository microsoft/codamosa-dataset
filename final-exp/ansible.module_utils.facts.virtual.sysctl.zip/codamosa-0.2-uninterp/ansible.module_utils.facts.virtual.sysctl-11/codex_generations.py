

# Generated at 2022-06-17 03:29:19.356769
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, cmd):
            if cmd == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'KVM', ''
            if cmd == '/usr/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            if cmd == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'KVM', ''
            if cmd == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'KVM', ''

# Generated at 2022-06-17 03:29:30.384466
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()

# Generated at 2022-06-17 03:29:41.979565
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test 1: sysctl command returns 0 and output is 'KVM'
    module = TestModule(0, 'KVM', '')
    test_class = TestClass(module)
    virtual_product_facts = test_class.detect_virt_product('hw.model')
    assert virtual_product_facts

# Generated at 2022-06-17 03:29:54.321709
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModuleMock()

    virtual_sysctl_detection_mixin_test = VirtualSysctlDetectionMixinTest()
    virtual_sysctl_detection_mixin_test.detect_sysctl = MagicMock(return_value=True)
    virtual_sysctl_detection_mixin_test.module.run_command = MagicMock(return_value=(0, 'KVM', ''))
    virtual_sysctl_detection_mixin_test.detect_virt_product('hw.model')
    assert virtual_sysctl_detection_mixin_test.sysctl_path == '/sbin/sysctl'
    assert virtual_sysctl_detection_mixin

# Generated at 2022-06-17 03:30:05.178430
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_virt_vendor('hw.model')
    assert facts.virtualization_type == 'kvm'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['kvm'])
    assert facts.virtualization_tech_host == set()


# Generated at 2022-06-17 03:30:19.603486
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'KVM'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/sbin/sysctl'

        def get_bin_path(self, name):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_sysctl()

# Generated at 2022-06-17 03:30:31.247062
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x
            self.fail_json = lambda x: x

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return (0, 'KVM', '')

    class FakeClass(object):
        def __init__(self):
            self.module = FakeModule()

    fc = FakeClass()
    fc.detect_sysctl()
    assert fc.sysctl_path == '/usr/bin/sysctl'

# Generated at 2022-06-17 03:30:41.529707
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'OpenBSD', ''),
                (0, 'QEMU', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestFacts(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_facts = TestFacts()
    test_facts

# Generated at 2022-06-17 03:30:51.680651
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestFacts(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    facts = TestFacts

# Generated at 2022-06-17 03:31:02.272958
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'OpenBSD', ''),
                (0, 'QEMU', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    mixin = MockVirtualSysctlDetectionMixin()
    mixin.detect_virt_vendor('hw.model')

# Generated at 2022-06-17 03:31:19.349491
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:22.922003
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x, **kwargs: x
            self.fail_json = lambda x, **kwargs: x

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')
    assert v.module.exit_json.called

# Generated at 2022-06-17 03:31:31.968811
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    class Module(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class Module_test(Module):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'KVM'


# Generated at 2022-06-17 03:31:42.572857
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:53.772202
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

   

# Generated at 2022-06-17 03:32:06.720924
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    mixin = MockSysctlDetectionMixin()
    assert mixin.det

# Generated at 2022-06-17 03:32:12.238148
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
            ]
            self.run_command_calls = []

# Generated at 2022-06-17 03:32:19.016748
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    sysctl_detection_mixin = FakeSysctlDetectionMixin()
    sysctl_detection_mixin.detect_virt_product('hw.model')
    assert sysctl_detection_mixin.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-17 03:32:30.380242
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeFacts(object):
        def __init__(self):
            self.facts = {}

        def populate(self, facts):
            self.facts = facts

    module = FakeModule()
   

# Generated at 2022-06-17 03:32:41.715236
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_product
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_jail
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_vmm
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_bhyve
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_xen

# Generated at 2022-06-17 03:33:18.099138
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import BSDHardware
    from ansible.module_utils.facts.system.bsd import BSDVirtual
    from ansible.module_utils.facts.system.bsd import BSDHardware
    from ansible.module_utils.facts.system.bsd import BSDVirtual
    from ansible.module_utils.facts.system.bsd import BSDHardware
    from ansible.module_utils.facts.system.bsd import BSDVirtual
    from ansible.module_utils.facts.system.bsd import BSDHardware
    from ansible.module_utils.facts.system.bsd import BSDVirtual

# Generated at 2022-06-17 03:33:28.773987
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualHardware
    from ansible.module_utils.facts.virtual.freebsd import VirtualProduct
    from ansible.module_utils.facts.virtual.freebsd import VirtualVendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualVirtWhat
    from ansible.module_utils.facts.virtual.freebsd import VirtualZfs
    from ansible.module_utils.facts.virtual.freebsd import VirtualDmidecode

# Generated at 2022-06-17 03:33:35.901031
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/sbin/sysctl',
                None,
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:33:41.334442
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, '', ''

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    mixin = MockSysctlDetectionMixin()
    mixin.detect_virt_product('hw.model')
    assert mixin.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-17 03:33:49.943483
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_

# Generated at 2022-06-17 03:33:58.069939
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None


# Generated at 2022-06-17 03:34:08.584152
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:34:20.271588
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeFacts(object):
        def __init__(self):
            self.facts = {}

        def populate(self):
            return self.facts


# Generated at 2022-06-17 03:34:30.540111
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:34:37.755694
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
           

# Generated at 2022-06-17 03:35:49.861262
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = ['/sbin/sysctl']
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append(name)
            return self.get_bin_path_results.pop(0)

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run

# Generated at 2022-06-17 03:36:00.994408
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self

# Generated at 2022-06-17 03:36:14.296999
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''

        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_vendor('hw.model')
    assert test_class.module.run_command_rc == 0
    assert test_class.module.run_

# Generated at 2022-06-17 03:36:25.759760
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.get_bin_path_results = []
            self.get_bin_path_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append(name)
            return self.get_bin_path_results.pop(0)

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:36:36.500335
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'


# Generated at 2022-06-17 03:36:48.999141
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [(0, 'QEMU', ''), (0, 'OpenBSD', '')]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    mixin = FakeVirtualSysctlDetectionMixin(module)
    assert mixin.detect_virt_v

# Generated at 2022-06-17 03:36:59.747991
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    t = TestVirtualSysctlDetectionMix

# Generated at 2022-06-17 03:37:10.836958
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.run_command_calls = 0

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls += 1
            self.run_command_args.append(args)
            rc = self.run_command_rcs[self.run_command_calls - 1]
            out = self.run_command_outs[self.run_command_calls - 1]

# Generated at 2022-06-17 03:37:18.405004
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]

# Generated at 2022-06-17 03:37:28.531806
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_result = (0, 'KVM', '')
            self.get_bin_path_result = '/sbin/sysctl'

        def get_bin_path(self, path):
            return self.get_bin_path_result

        def run_command(self, cmd):
            return self.run_command_result

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake_virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin()