

# Generated at 2022-06-17 03:29:19.233352
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    sysctl

# Generated at 2022-06-17 03:29:30.304330
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule

# Generated at 2022-06-17 03:29:41.918797
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.get_bin_path_called = False
            self.get_bin_path_path = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_bin = ''

        def get_bin_path(self, path):
            self.get_bin_path_called = True
            self.get_bin_path_path = path
            return self.get_bin_path_bin

        def run_command(self, cmd):
            self.run_command_called = True
            self.run_command_cmd = cmd
            return

# Generated at 2022-06-17 03:29:54.229625
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:30:04.974415
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()


# Generated at 2022-06-17 03:30:19.603565
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None
    test_class = TestClass()
    test_class.detect_sysctl = lambda: None
    test_class.module = MockModule()
    test_class.module.run_command = lambda x: (0, 'QEMU', '')
    assert test_class.detect_virt_vendor('machdep.hypervisor') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set()}
    test_class.module.run_command = lambda x: (0, 'OpenBSD', '')
    assert test_

# Generated at 2022-06-17 03:30:26.218665
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
            ]
            self.run_command_calls = [0]

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls[0] += 1

# Generated at 2022-06-17 03:30:33.795220
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test 1: sysctl is not present
    mixin = FakeVirtualSysctlDetectionMix

# Generated at 2022-06-17 03:30:42.286183
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_rc_map = {}
            self.run_command_out_map = {}
            self.run_command_err_map = {}

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd in self.run_command_rc_map:
                rc = self.run_command_rc_map[cmd]
            else:
                rc = self.run_command_rc
            if cmd in self.run_command_out_map:
                out = self.run_command_out_map[cmd]

# Generated at 2022-06-17 03:30:51.705266
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_path = ''
            self.run_command_args = ''

        def get_bin_path(self, path):
            return self.run_command_path

        def run_command(self, args):
            self.run_command_args = args
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    fake_virtual_sysctl_

# Generated at 2022-06-17 03:31:09.665559
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: None

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeVirtSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    virt_sysctl_detection_mixin = FakeVirtSysctlDetectionMixin()

# Generated at 2022-06-17 03:31:20.348557
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()

    # Test kvm
    test_class.module.run_command_out = 'KVM'

# Generated at 2022-06-17 03:31:27.366564
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

    class Module:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class Module_test:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'OpenBSD'


# Generated at 2022-06-17 03:31:39.110292
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:31:51.614876
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()

# Generated at 2022-06-17 03:32:04.143416
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'
            self.module = MockModule()

    class MockModule:
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 1.0', ''
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            if cmd == '/sbin/sysctl -n hw.product':
                return 0, 'OpenBSD', ''

# Generated at 2022-06-17 03:32:16.889726
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'QEMU', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    assert test_class.detect_virt_vendor('machdep.cpu.features') == {'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([]), 'virtualization_type': 'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-17 03:32:25.693344
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/sbin/sysctl'


# Generated at 2022-06-17 03:32:32.466482
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = [0]
            self.get_bin_path_results = ['/usr/sbin/sysctl']
            self.get_bin_path_calls = [0]


# Generated at 2022-06-17 03:32:37.646890
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test with KVM
    module = TestModule(0, 'KVM', '')
    test_class = TestClass(module)

# Generated at 2022-06-17 03:33:13.572571
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:33:19.277343
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None
    test_class = VirtualSysctlDetectionMixin_test()
    test_class.sysctl_path = '/sbin/sysctl'
    test_class.module = None
    test_class.detect_virt_product('hw.model')
    assert test_class.sysctl_path == '/sbin/sysctl'
    assert test_class.module == None


# Generated at 2022-06-17 03:33:29.531067
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.get_bin_path_calls = []
            self.get_bin_path_paths = []

        def get_bin_path(self, path):
            self.get_bin_path_calls.append(path)
            return self.get_bin_path_paths.pop(0)

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:33:34.487913
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:33:42.878718
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/usr/bin/sysctl'

        def get_bin_path(self, name, opt_dirs=[]):
            return self.get_bin_path_path

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return self.run_command_rc, self.run_command_out, self.run_command_err


# Generated at 2022-06-17 03:33:51.265103
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test 1:
    # sysctl -n hw.vendor returns 'QEMU'
    # Expected result:
    # virtualization_type = 'kvm'
    # virtualization_role = 'guest'
    # virtualization_tech_guest = ['kvm']
    # virtualization

# Generated at 2022-06-17 03:33:59.376625
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    class MockModule:
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_index = 0


# Generated at 2022-06-17 03:34:09.623270
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    sysctl_detection_mixin = FakeSysctlDet

# Generated at 2022-06-17 03:34:18.388993
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    test_class = VirtualSysctlDetectionMixinTest()
    test_class.detect_sysctl = lambda: None
    test_class.module = type('', (), {'run_command': lambda self, cmd: (0, 'KVM', '')})()
    assert test_class.detect_virt_product('machdep.cpu.features') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }
    test_class.module = type

# Generated at 2022-06-17 03:34:23.559043
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_product('hw.model')
    assert v.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-17 03:35:34.935208
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleStub(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class VirtualSysctlDetectionMixinStub(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = ModuleStub()

    v = VirtualSysctlDetectionMixinStub()
    assert v.detect_virt_vendor('hw.model') == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-17 03:35:44.159151
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake_class = FakeClass()
    assert fake_class.detect_virt_product('hw.model') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-17 03:35:54.234047
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    sysctl_detection_mixin = FakeSysctlDetectionMixin()
    virtual_product_facts = sysctl_detection_mixin.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert virtual_product_facts['virtualization_tech_guest'] == set(['kvm'])


# Generated at 2022-06-17 03:36:00.474584
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module

# Generated at 2022-06-17 03:36:08.474062
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            self.run_command_calls.append(arg)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_virt_v

# Generated at 2022-06-17 03:36:20.690693
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    mixin = FakeVirtualSys

# Generated at 2022-06-17 03:36:32.793254
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:40.085027
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_product
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_sysctl
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_sysctl

# Generated at 2022-06-17 03:36:52.114687
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:37:02.613800
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return self.rc, self.out, self.err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test with a QEMU virtualization
    module = FakeModule(0, 'QEMU', '')
    virtual_sysctl_detection_mixin = FakeVirtualSysctlDetectionMixin(module)
    virtual_vendor_facts