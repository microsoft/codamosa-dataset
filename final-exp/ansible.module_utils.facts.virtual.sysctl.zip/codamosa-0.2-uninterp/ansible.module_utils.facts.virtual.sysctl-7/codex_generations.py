

# Generated at 2022-06-17 03:29:18.972571
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.bin_path = '/usr/bin'

        def get_bin_path(self, arg):
            return self.bin_path

        def run_command(self, arg):
            if arg == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'kvm', ''
            elif arg == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'VMware', ''
            elif arg == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'VirtualBox', ''

# Generated at 2022-06-17 03:29:29.919622
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            if cmd == '/bin/sysctl -n hw.model':
                return 0, 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz', ''
            elif cmd == '/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            elif cmd == '/bin/sysctl -n security.jail.host.hostuuid':
                return

# Generated at 2022-06-17 03:29:41.602139
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModuleMock()

    class AnsibleModuleMock:
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return (0, 'KVM', '')

    v = VirtualSysctlDetectionMixinTest()
    assert v.detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    class AnsibleModuleMock:
        def get_bin_path(self, name):
            return '/sbin/sysctl'


# Generated at 2022-06-17 03:29:52.564336
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_Test
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_Test_Run_Command
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_Test_Get_Bin_Path

    class VirtualSysctlDetectionMixin_Test_Detect_Sysctl(VirtualSysctlDetectionMixin_Test):
        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')


# Generated at 2022-06-17 03:29:59.321184
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:30:09.013711
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = MockModule.run_command

        @staticmethod
        def run_command(command):
            if command == 'sysctl -n hw.model':
                return 0, 'KVM', ''
            if command == 'sysctl -n security.jail.jailed':
                return 0, '1', ''
            if command == 'sysctl -n hw.model':
                return 0, 'VMware', ''
            if command == 'sysctl -n hw.model':
                return 0, 'VirtualBox', ''
            if command == 'sysctl -n hw.model':
                return 0, 'HVM domU', ''
            if command == 'sysctl -n hw.model':
                return 0

# Generated at 2022-06-17 03:30:21.122067
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:30:31.364800
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    mixin = FakeVirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    facts = mixin.detect_virt_product('hw.model')
   

# Generated at 2022-06-17 03:30:39.074866
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:30:45.465590
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'OpenBSD', ''),
                (0, 'QEMU', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeFacts(object):
        def __init__(self):
            self.facts = {}


# Generated at 2022-06-17 03:31:02.064483
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    # Test with a sysctl command that returns a string that matches a virtualization technology
    virtual_sysctl_detection_mixin_test = VirtualSysctlDetectionMixinTest()
    virtual_sysctl_detection_mixin_test.sysctl_path = '/usr/sbin/sysctl'
    virtual_sysctl_detection_mixin_test.module = AnsibleModuleMock()
    virtual_sysctl_detection_mixin_test.module.run_command = run_command_mock

# Generated at 2022-06-17 03:31:09.715238
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, arg, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    mixin = FakeVirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    result = mixin.detect_virt_vendor('hw.model')
   

# Generated at 2022-06-17 03:31:20.371736
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    v

# Generated at 2022-06-17 03:31:27.368240
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:31:39.110916
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:31:51.615025
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return 0, 'QEMU', ''

        def get_bin_path(self, cmd):
            self.get_bin_path_calls.append(cmd)
            return '/usr/bin/sysctl'

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_vendor('hw.model')

# Generated at 2022-06-17 03:32:04.143735
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return (0, 'KVM', '')

    class FakeVirtSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    virt_sysctl_detection = FakeVirtSysctlDetectionMixin()
    assert virt_sysctl_detection.detect_virt_product('hw.model') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-17 03:32:17.754463
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:32:29.891199
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:32:34.935372
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:33:17.359956
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:33:28.699746
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_sysctl()
    assert test_class.sysctl_path == '/sbin/sysctl'
    assert test_class.module.run_command

# Generated at 2022-06-17 03:33:35.382959
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM', ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake_class = FakeClass()
    result = fake_class.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set()


# Generated at 2022-06-17 03:33:43.824056
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd import VirtualHardware
    from ansible.module_utils.facts.virtual.freebsd import VirtualProduct
    from ansible.module_utils.facts.virtual.freebsd import VirtualVendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctl
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlVendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlProduct

# Generated at 2022-06-17 03:33:52.160111
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self

# Generated at 2022-06-17 03:34:00.152591
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    module.run_

# Generated at 2022-06-17 03:34:10.202131
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    mix

# Generated at 2022-06-17 03:34:20.858815
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with no sysctl
    fake_object = FakeVirtualSysctlDetectionMixin()
    fake_object.sys

# Generated at 2022-06-17 03:34:27.382085
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    facts = FakeFacts()
    facts.detect_virt_product('hw.model')
    assert facts.virtualization_type == 'kvm'
    assert facts.virtualization_role == 'guest'
    assert facts.virtualization_tech_guest == set(['kvm'])
    assert facts.virtualization_tech_host == set()


# Generated at 2022-06-17 03:34:33.694771
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]

# Generated at 2022-06-17 03:35:49.710101
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSysctl

# Generated at 2022-06-17 03:36:00.960314
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = MockModule()

# Generated at 2022-06-17 03:36:13.686380
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    test_class = TestClass(TestModule())
    result = test_class.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' in result['virtualization_tech_guest']
    assert 'kvm' not in result['virtualization_tech_host']


# Generated at 2022-06-17 03:36:24.789375
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSysctlDet

# Generated at 2022-06-17 03:36:31.660249
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    # Test with QEMU
    v = FakeVirtualSysctlDetectionMix

# Generated at 2022-06-17 03:36:39.818070
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:51.945940
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            return self.rc, self.out, self.err

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Test with no sysctl
    module = FakeModule(1, '', '')
    sysctl_detection_mixin = FakeSysctlDetectionMixin(module)
    assert sysctl_detection_mixin.detect_virt_v

# Generated at 2022-06-17 03:37:02.516189
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:37:16.396141
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDHardware
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDKernel
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDPlatform
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualFacts
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDHardwareFacts
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDKernelFacts
    from ansible.module_utils.facts.virtual.openbsd import OpenBSD

# Generated at 2022-06-17 03:37:27.458129
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin