

# Generated at 2022-06-17 03:29:18.420693
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/usr/sbin/sysctl'

        def get_bin_path(self, path):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_

# Generated at 2022-06-17 03:29:29.421980
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = [0]

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls[0] += 1
            return

# Generated at 2022-06-17 03:29:34.505275
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'


# Generated at 2022-06-17 03:29:43.164137
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = FakeModule()
    mixin = FakeVirtualSys

# Generated at 2022-06-17 03:29:55.362329
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (1, '', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'


# Generated at 2022-06-17 03:30:06.047120
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, _):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    mixin = MockVirtualSysctlDetectionMixin()
    assert mixin.detect_

# Generated at 2022-06-17 03:30:11.931038
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = MockModule()
    mixin

# Generated at 2022-06-17 03:30:22.180954
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_virt_vendor('hw.model')
    assert test_class.module.run_command_rc == 0
    assert test_class.module.run_

# Generated at 2022-06-17 03:30:30.360737
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fake = FakeClass()
    assert fake.detect_virt_product('hw.model') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-17 03:30:41.463348
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-17 03:30:59.445059
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (1, '', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls

# Generated at 2022-06-17 03:31:09.552554
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [(0, 'QEMU', ''), (0, 'OpenBSD', ''), (1, '', '')]
            self.run_command_calls = []

        def get_bin_path(self, _):
            return '/usr/bin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSysctlDetectionMixin()
    assert mixin.detect_virt_vendor('hw.model')

# Generated at 2022-06-17 03:31:20.216434
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)


# Generated at 2022-06-17 03:31:27.342933
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:31:39.069183
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDModule
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDPlugin

    class TestVirtualFreeBSDModule(VirtualFreeBSDModule):
        def __init__(self):
            self.facts = {}

        def get_bin_path(self, executable):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    class TestVirtualFreeBSDPlugin(VirtualFreeBSDPlugin, VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestVirtualFreeBSDModule()
    plugin = TestVirtualFreeBSDPlugin(module)

# Generated at 2022-06-17 03:31:51.535487
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'QEMU', ''

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()

    virtual_vendor_facts = VirtualSysctlDetectionMixin().detect_virt_vendor('hw.model')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert virtual_vendor_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_vendor_facts['virtualization_tech_host'] == set()

# Unit test

# Generated at 2022-06-17 03:31:57.058690
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (1, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = None

    facts = FakeFacts()
    mixin = VirtualSysctlDetectionMixin()

   

# Generated at 2022-06-17 03:32:08.879926
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['!all', '!min']
            self.params['gather_timeout'] = 10
            self.params['filter'] = '*'
            self.params['gather_network_resources'] = 'no'
        def get_bin_path(self, arg):
            return '/sbin/sysctl'
        def run_command(self, arg):
            return 0, 'KVM', ''
    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = None
    facts = FakeFacts()
    facts.detect_virt_product('hw.model')

# Generated at 2022-06-17 03:32:19.200940
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None
            self.sysctl_path = '/sbin/sysctl'

        def detect_sysctl(self):
            pass

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU', ''
            if cmd == '/sbin/sysctl -n hw.machine':
                return 0, 'OpenBSD', ''
            if cmd == '/sbin/sysctl -n hw.product':
                return 0, 'OpenBSD', ''
            if cmd == '/sbin/sysctl -n hw.version':
                return 0, 'OpenBSD', ''

# Generated at 2022-06-17 03:32:30.499042
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = ''

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_sysctl()
    assert test_class.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-17 03:33:05.885328
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, args):
            self.run_command_calls.append(args)
            if args == '/sbin/sysctl -n kern.vm_guest':
                return (0, 'QEMU', '')
            elif args == '/sbin/sysctl -n kern.vm_guest':
                return (0, 'OpenBSD', '')
            else:
                return (1, '', '')

    # Test with QEMU
    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()

# Generated at 2022-06-17 03:33:14.389858
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/usr/sbin/sysctl',
                None,
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:33:22.273350
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:33:32.461463
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, args, *kwargs, **kwargs2):
            self.run_command_calls.append(args)
            return self.run_command_results.pop(0)

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    test_class = TestClass

# Generated at 2022-06-17 03:33:42.327433
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:33:50.701353
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_product
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_sysctl
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_vendor
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin_detect_virt_product

# Generated at 2022-06-17 03:33:58.854619
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixin
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

# Generated at 2022-06-17 03:34:04.593054
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Module(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, arg, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    module = Module()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = module

    virtual_vendor_facts = virtual_sysctl_det

# Generated at 2022-06-17 03:34:18.372820
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModule(argument_spec={})
            self.sysctl_path = None

    class AnsibleModule:
        def __init__(self, argument_spec):
            self.argument_spec = argument_spec

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 2.5+', ''
            elif cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''

# Generated at 2022-06-17 03:34:23.286192
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command = lambda x: (0, 'QEMU', '')
            self.get_bin_path = lambda x: '/usr/bin/sysctl'
    class FakeFacts(object):
        def __init__(self):
            self.module = FakeModule()
    facts = FakeFacts()
    facts.module.run_command = lambda x: (0, 'QEMU', '')
    facts.module.get_bin_path = lambda x: '/usr/bin/sysctl'
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_det

# Generated at 2022-06-17 03:35:40.585598
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.get_bin_path_results = [
                '/sbin/sysctl'
            ]
            self.get_bin_path_calls = []


# Generated at 2022-06-17 03:35:49.834913
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:00.993120
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, required=False):
            return '/usr/bin/sysctl'


# Generated at 2022-06-17 03:36:08.915620
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-17 03:36:19.200885
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.run_command_rc_index = 0
            self.run_command_out_index = 0
            self.run_command_err_index = 0

        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg):
            self.run_command_calls.append(arg)
            rc = self.run_command_rcs[self.run_command_rc_index]
            out = self.run_command_outs[self.run_command_out_index]
           

# Generated at 2022-06-17 03:36:31.520673
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
                (1, '', '')
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    mixin = FakeVirtualSys

# Generated at 2022-06-17 03:36:37.486331
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [(0, 'QEMU', ''), (0, 'OpenBSD', ''), (0, '', '')]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect

# Generated at 2022-06-17 03:36:50.125271
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def __init__(self):
            self.run_command_results = [
                (0, 'QEMU', ''),
                (0, 'OpenBSD', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

    class TestSystem(object):
        def __init__(self):
            self.module = TestModule()

    system = TestSystem()
    mixin = VirtualSysctlDetectionMixin()


# Generated at 2022-06-17 03:37:01.585290
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def __init__(self):
            self.run_command_results = [
                (0, 'KVM', ''),
                (0, 'VMware', ''),
                (0, 'VirtualBox', ''),
                (0, 'HVM domU', ''),
                (0, 'Hyper-V', ''),
                (0, 'Parallels', ''),
                (0, 'RHEV Hypervisor', ''),
                (0, '1', ''),
                (0, '', ''),
            ]
            self.run_command_calls = []
            self.bin_path_results = [
                '/sbin/sysctl',
                None,
            ]
            self.bin_path_calls = []


# Generated at 2022-06-17 03:37:08.411911
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None

    v = VirtualSysctlDetectionMixinTest()
    v.sysctl_path = '/sbin/sysctl'
    v.module = None
    assert v.detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set()}