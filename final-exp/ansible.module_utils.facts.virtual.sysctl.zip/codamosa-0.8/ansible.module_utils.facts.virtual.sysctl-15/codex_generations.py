

# Generated at 2022-06-11 06:07:37.404908
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinFake(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/usr/sbin/sysctl'
    obj = VirtualSysctlDetectionMixinFake()
    obj.module = AnsibleModuleFake()
    assert obj.detect_virt_vendor('hw.product') == {
        'virtualization_role': 'guest', 'virtualization_type': 'vmm',
        'virtualization_tech_guest': set(['vmm']), 'virtualization_tech_host': set()}


# Generated at 2022-06-11 06:07:47.177245
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import AnsibleFactCollector
    from ansible.module_utils.openbsd import OpenBSD
    from ansible.module_utils.openbsd import VirtualSysctlDetectionMixin
    from sys import version_info

    if not version_info[0] == 2:
        print("This test is currently specific to python 2")
        return

    module = AnsibleModule({}, {}, False, False, False)
    setattr(module, 'run_command', lambda x: (0, "something", ""))
    setattr(module, 'get_bin_path', lambda x: "/bin/sysctl")

    facts = {}
    fact_collector = AnsibleFactCollector(module)
    virtual_facts = VirtualSysctlDetection

# Generated at 2022-06-11 06:07:55.904726
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixinTestCase
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixinTestCaseResult
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixinTestCaseResultUtil

    sysctl_output = 'QEMU'
    sysctl_returncode = 0
    sysctl_path = '/sbin/sysctl'

    test_case = VirtualSysctlDetectionMixinTestCase()
    test_case.sysctl_path = sysctl_path
    test_case.sysctl_returncode = sysctl_return

# Generated at 2022-06-11 06:08:05.693342
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class _System:
        def __init__(self):
            self.module = _Module()

    class _Module:
        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            return 0, '', ''

    class _VirtualSysctlDetectionMixin:
        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

    class _VirtualProduct:
        def __init__(self):
            super(_VirtualProduct, self).__init__()

        def detect_virt_product(self, key):
            return {'virtualization_type': '',
                    'virtualization_role': '',
                    'virtualization_tech_guest': set(),
                    'virtualization_tech_host': set()}

# Generated at 2022-06-11 06:08:15.888228
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts

    class MyVirtualFacts(VirtualFacts):
        def __init__(self, module):
            super(MyVirtualFacts, self).__init__(module)
            self.virtual_facts_class = self

    class MyVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            super(MyVirtualSysctlDetectionMixin, self).__init__(module)
            self.virtual_facts = MyVirtualFacts(module)

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc

# Generated at 2022-06-11 06:08:25.320777
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleStub(object):
        def get_bin_path(self, command, opt_dirs=[]):
            return '/test/bin/sysctl'

        def run_command(self, command):
            return 0, 'OpenBSD', ''
    class VirtualSysctlDetectionMixinStub(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            pass

    obj = VirtualSysctlDetectionMixinStub()
    obj.module = ModuleStub()

# Generated at 2022-06-11 06:08:35.870764
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class BSDModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ""
            self.run_command_err = ""
            self.run_command_called = False

        def get_bin_path(self, arg):
            return arg

        def run_command(self, arg):
            self.run_command_called = True
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    mixin = VirtualSysctlDetectionMixinTest(BSDModule())
    mixin.module.run_command_rc = 0

   

# Generated at 2022-06-11 06:08:44.453573
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeFS(object):

        def __init__(self):
            pass

        def read_file(self, path):
            return "QEMU Virtual CPU"

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.fs = FakeFS()

        def get_bin_path(self, name, opts=None, required=False):
            if name == 'sysctl':
                return "/sbin/sysctl"

        def run_command(self, cmd):
            return (0, "QEMU Virtual CPU", "")

    vcsdm = VirtualSysctlDetectionMixin()
    module = FakeModule()
    vcsdm.module = module
    module.params = {'detect_virt_what': 'product'}
    virtual_product_facts = vcs

# Generated at 2022-06-11 06:08:54.817369
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    if not HAS_UNITTEST:
        module.fail_json(msg="unittest2 required for this module.")

    attrs = {
        'module': module,
        'sysctl_path': '/sbin/sysctl',
    }
    src = VirtualSysctlDetectionMixin()
    for attr, value in attrs.items():
        setattr(src, attr, value)

    # QEMU
    cmd_out = dict(rc=0, stdout='QEMU', stderr='')
    src.module.run_command = MagicMock(side_effect=[cmd_out, ])
    facts = src.detect_virt_vendor('hw.model')
   

# Generated at 2022-06-11 06:09:05.629325
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-11 06:09:26.036699
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    fake_module = FakeAnsibleModule()
    fake_module.sysctl_path = '/sbin/sysctl'
    fake_module.run_command = MagicMock()
    fake_module.run_command.return_value = (0, 'foo', '')

    test_class = VirtualSysctlDetectionMixin()
    test_class.module = fake_module
    test_class.detect_sysctl()

    # Nothing should be set
    assert not test_class.detect_virt_vendor('foo')

    fake_module.run_command.return_value = (0, 'QEMU', '')
    assert test_class.detect_virt_vendor('foo')['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 06:09:35.262476
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda x: None
            self.run_command = lambda x: (0, "OpenBSD", "")
    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = "/bin/sysctl"
    x = FakeVirtualSysctlDetectionMixin(FakeModule())
    facts = x.detect_virt_vendor("machdep.vm_guest")
    kvm_guest = facts['virtualization_tech_guest']
    assert 'kvm' not in kvm_guest
    assert 'vmm' in kvm_guest

# Generated at 2022-06-11 06:09:43.536708
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    detected_virt_vendor_facts = {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    vsdm = VirtualSysctlDetectionMixin_test()
    virt_vendor_facts = vsdm.detect_virt_vendor('hw.vmm.product')
    for key in ('virtualization_type', 'virtualization_role'):
        assert virt_vendor_facts[key] == detected_virt_vendor_facts[key]



# Generated at 2022-06-11 06:09:53.447264
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MagicMock(name='module')
            self.module.run_command.return_value = (0, 'QEMU', None)
            self.module.get_bin_path.return_value = 'sysctl'

    testclass = TestClass()
    testclass.detect_sysctl = MagicMock(name='detect_sysctl')
    testclass.detect_virt_vendor('vm.vmm.vendor')

    assert testclass.sysctl_path == 'sysctl'
    assert testclass.module.run_command.call_count == 1
    assert testclass.module.run_command.call_args[0][0] == 'sysctl -n vm.vmm.vendor'


# Generated at 2022-06-11 06:10:04.073800
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Using OSX for our testing
    module = AnsibleModule(argument_spec=dict(
        ansible_facts=dict(required=True, type='dict'),
        ansible_sysctl=dict(required=False, type='dict'),
    ))
    module.params['ansible_facts']['ansible_system'] = 'Darwin'
    module.params['ansible_facts']['ansible_distribution'] = 'MacOSX'
    module.params['ansible_facts']['ansible_distribution_version'] = '10.12.1'
    module.params['ansible_sysctl'] = {}

    virtual_object = VirtualSysctlDetectionMixin()
    virtual_object.module = module
    # If sysctl is not found we return an empty dictionary

# Generated at 2022-06-11 06:10:12.298657
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Creating a mock class
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None

    test_class = TestVirtualSysctlDetectionMixin()
    # Creating a mock module
    mock_module = Mock()
    mock_module.run_command.return_value = (0, 'KVM', '')
    mock_module.get_bin_path.return_value = '/usr/bin/sysctl'
    test_class.module = mock_module
    result = test_class.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:10:23.346970
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # create a mock module for testing
    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command_calls = 0
            self.run_command_rcs = list()
            self.run_command_outs = list()
            self.run_command_errs = list()

        def fail_json(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            self.run_command_calls += 1
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    test_cases

# Generated at 2022-06-11 06:10:32.771453
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    mixin.sysctl_path = '/usr/bin/sysctl'

    # Unit test what happens when we detect a BSD jail.
    args = dict()
    args['product'] = 'jails'
    args['key'] = 'security.jail.jailed'
    args['command'] = ['1']
    args['rc'] = 0
    mixin.run_command = lambda cmd, *arg, **kwarg: (args[cmd[0]], args[cmd[0]], "")
    ret = mixin.detect_virt_product(args['key'])
    assert ret['virtualization_tech_guest'] == {'jails'}
    assert ret['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:10:42.958450
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.virtual.freebsd.freebsd import VirtualSysctlDetectionMixin as VirtualBSDDetectionMixin
    class ModuleMock():
        def __init__(self, return_stdout, return_rc):
            self.rc = return_rc
            self.stdout = return_stdout

        def get_bin_path(self, binary):
            return '/bin/' + binary
            
        def run_command(self, binary, *args):
            return (self.rc, self.stdout, '')
            
        def fail_json(self, *args, **kwargs):
            raise Exception("fail_json called")
            

# Generated at 2022-06-11 06:10:51.294841
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    if not hasattr(VirtualSysctlDetectionMixin, 'detect_virt_vendor'):
        return

    # Setup
    class TestModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''

        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, args):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class TestFactCollector(TestModule, VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()
            super(TestFactCollector, self).__init__()


# Generated at 2022-06-11 06:11:19.652138
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    #
    # This is a copy of a function generated by Ansible's unit test framework.
    #
    class Object:
        """ Dummy class representing module object. """
        def __init__(self, arg1):
            self.params = arg1

        def get_bin_path(self, arg1):
            if arg1 == "sysctl":
                return "/sbin/sysctl"
            else:
                return None

        def run_command(self, arg1):
            if arg1 == "/sbin/sysctl -n hw.model":
                return 0, "VMware, Inc. VMware Virtual Platform", ""
            elif arg1 == "/sbin/sysctl -n hw.machine":
                return 0, "x86_64", ""

# Generated at 2022-06-11 06:11:30.211741
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class_name = VirtualSysctlDetectionMixin.__name__
    class_module = VirtualSysctlDetectionMixin.__module__
    class_object = VirtualSysctlDetectionMixin()

    module_fake = FakeOsModule(class_object)

    VirtualSysctlDetectionMixin.detect_sysctl = fake_detect_sysctl
    virtual_product_facts = VirtualSysctlDetectionMixin.detect_virt_product(class_object, "hw.model")
    assert virtual_product_facts == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': {}
    }


# Generated at 2022-06-11 06:11:39.460442
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    obj = VirtualSysctlDetectionMixin()

    # Testing for KVM
    obj.sysctl_path = 'sysctl'
    rc = 0
    out = 'KVM'
    err = ''
    obj.module.run_command = lambda x: (rc, out, err)
    result = obj.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

    # Testing for QEMU
    obj.sysctl_path = 'sysctl'
    rc = 0
    out = 'QEMU'
    err = ''

# Generated at 2022-06-11 06:11:48.100197
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    # This class is only for unit testing
    class FakeModule(object):
        def get_bin_path(self, arg):
            return "/usr/sbin/sysctl"
        def run_command(self, arg):
            if arg == '/usr/sbin/sysctl -n hw.product':
                return 0, 'KVM', ''
            if arg == '/usr/sbin/sysctl -n hw.vendor':
                return 0, 'OpenBSD', ''
            if arg == '/usr/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            return 0, '', ''

    # This class is only for unit testing
    class FakeSystem(object):
        def __init__(self):
            self.module = FakeModule()

# Generated at 2022-06-11 06:11:59.003765
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleMock():
        @staticmethod
        def get_bin_path(path):
            return '/sbin/sysctl'

        @staticmethod
        def run_command(command):
            return 0, 'OpenBSD', ''

    class VirtualSysctlDetectionMock(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            return ''

    v = VirtualSysctlDetectionMock()
    v.module = ModuleMock()

    # Test if detect_virt_vendor returns correct dict when ran on OpenBSD
    result = v.detect_virt_vendor('hw.model')
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:12:09.431638
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import get_distribution
    from ansible.module_utils.facts.system.bsd import get_distribution_release
    from ansible.module_utils.facts.system.bsd import get_file_content
    import os
    import pytest
    import shutil
    import subprocess
    import tempfile

    class VirtualSysctlDetectionMixinClass(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            pass

    # create temporary directory and files
    tmpdir = tempfile.mkdtemp()
    tmpdir_src = tmpdir + '/src'
    tmpdir_dst = tmpdir + '/dst'
    os.mk

# Generated at 2022-06-11 06:12:17.190576
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class _module(object):
        def __init__(self, *args, **kwargs):
            self.params = kwargs
            self.run_command_results = [0, 'QEMU', '']
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            return self.run_command_results

    module = _module()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.detect_sysctl_vendor()
    assert ('virtualization_type' in mixin.virtual_facts)
    assert ('virtualization_role' in mixin.virtual_facts)
    assert ('virtualization_tech_host' in mixin.virtual_facts)

# Generated at 2022-06-11 06:12:22.771416
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_fixture = VirtualSysctlDetectionMixin()
    key = "hw.product"
    expected = {'virtualization_tech_guest': {'xen'}, 'virtualization_tech_host': set(), 'virtualization_role': 'guest', 'virtualization_type': 'xen'}
    assert test_fixture.detect_virt_product(key) == expected


# Generated at 2022-06-11 06:12:31.959010
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class _module(object):
        def get_bin_path(self, arg):
            return '/sbin/sysctl'
        def run_command(self, arg):
            return 0, 'QEMU', ''
    class _VirtualSysctlDetectionMixin():
        module = _module()
    my_obj = _VirtualSysctlDetectionMixin()
    my_obj.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl.__get__(my_obj, _VirtualSysctlDetectionMixin)
    my_obj.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product.__get__(my_obj, _VirtualSysctlDetectionMixin)
    result = my_obj.detect_virt_product('hw.model')

# Generated at 2022-06-11 06:12:35.678015
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    result = VirtualSysctlDetectionMixin().detect_virt_vendor('hw.product')
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:13:40.456331
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    tmp = VirtualSysctlDetectionMixin()
    tmp.sysctl_path = '/sbin/sysctl'
    tmp.module = openbsd_module_mock()

    # Test if the virtualization_type is 'kvm' and virtualization_role is 'guest'
    tmp.detect_virt_product = lambda x: {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    assert tmp.detect_virt_product('machdep.hypervisor')['virtualization_type'] == 'kvm'
    assert tmp.detect_virt_product('machdep.hypervisor')['virtualization_role'] == 'guest'

    # Test if the virtualization_type is 'VMware' and virtualization_role is 'guest'

# Generated at 2022-06-11 06:13:50.735106
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from . import OpenBSD
    from . import ModuleTestCase
    from . import AnsibleExitJson, AnsibleFailJson, AnsibleModule
    from . import ModuleTestCase

    class MyModule(OpenBSD, VirtualSysctlDetectionMixin):
        ''' dummy class for testing class methods of VirtualSysctlDetectionMixin '''
        def __init__(self, *args, **kwargs):
            self.sysctl_path = '/sbin/sysctl'
            self.module = AnsibleModule(argument_spec={})
            self.module.exit_json = lambda **kwargs: None
            self.module.fail_json = lambda **kwargs: None


# Generated at 2022-06-11 06:13:59.172833
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule():
        def __init__(self):
            self.run_command_results = []
            self.run_command_calls = []
            self.params = []

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, cmd):
            self.run_command_calls.append(cmd)
            return self.run_command_results.pop(0)

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

    class VirtualSysctlDetectionMixinImpl(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

        def detect_sysctl(self):
            pass


# Generated at 2022-06-11 06:14:08.487011
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    virtual_vendors_facts = test_object.detect_virt_vendor('machdep.hypervisor')
    assert sorted(virtual_vendors_facts) == ['virtualization_role', 'virtualization_tech_guest', 'virtualization_tech_host', 'virtualization_type']
    assert virtual_vendors_facts['virtualization_role'] == 'guest'
    assert virtual_vendors_facts['virtualization_tech_guest'] == set(['kvm', 'vmm'])
    assert virtual_vendors_facts['virtualization_tech_host'] == set()
    assert virtual_vendors_facts['virtualization_type'] == 'vmm'


# Generated at 2022-06-11 06:14:17.853570
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Client:
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None
            self.facts = {}

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

        def get_facts(self):
            return self.facts

        def add_fact(self, key, value):
            if key not in self.facts:
                self.facts[key] = value

        def get_virtual_product(self):
            virtual_product_facts = self.detect_virt_product('hw.model')
            for k, v in virtual_product_facts.items():
                self.add_fact(k, v)


# Generated at 2022-06-11 06:14:27.904226
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.modules.system.freebsd.facts import VirtualSysctlDetectionMixin
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.module = None
            self.sysctl_path = None
            return

        def detect_sysctl(self):
            self.sysctl_path = "/sbin/sysctl"
            return

        def run_command(self, cmd):
            # KVM detection
            if re.match("/sbin/sysctl -n hw.product", cmd):
                return 0, "VirtualBox", ""
            # Vendor detection
            if re.match("/sbin/sysctl -n hw.vendor", cmd):
                return 0, "QEMU", ""

# Generated at 2022-06-11 06:14:33.256328
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    # We don't really need to do anything, as the method will only expect a module
    # but we'll just make sure it runs fine.
    virtual_detect_mixin = VirtualSysctlDetectionMixin()
    virtual_detect_mixin.module = module
    virtual_detect_mixin.detect_virt_product('hw.machine')


# Generated at 2022-06-11 06:14:38.049691
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    v = VirtualSysctlDetectionMixin()
    v.module = MockModule()
    v.sysctl_path = '/sbin/sysctl'
    v.module.run_command.return_value = (0, '', '')
    v.detect_virt_product('machdep.hypervisor')
    v.module.run_command.assert_called_with('/sbin/sysctl -n machdep.hypervisor')


# Generated at 2022-06-11 06:14:47.420738
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    expected_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }
    module_mock = type('module', (object,), {'get_bin_path': lambda x: '/sbin/sysctl'})
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = module_mock
    virtual_sysctl_detection_mixin.run_command = lambda x: (0, 'KVM', None)
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None


# Generated at 2022-06-11 06:14:58.583290
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.base import VirtualSysctlDetectionMixin, VirtualFactsBase
    class Foo(VirtualSysctlDetectionMixin, VirtualFactsBase):
        def __init__(self, module, **kwargs):
            self.module = module

    def sysctl_path_check(self, path):
        if path == './sysctl':
            return path
        raise OSError()

    test_module = type(str('anonymous_module'), (), {'get_bin_path': sysctl_path_check})
    test_module.run_command = MagicMock(return_value=(0, 'KVM', ''))
    test_class = Foo(test_module)
    test_class.detect_virt_product('hw.model')
    assert test_class.virtual_product

# Generated at 2022-06-11 06:16:57.423218
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class NetFreeBSDModule:
        def __init__(self, run_command_value, get_bin_path_value):
            self.run_command_value = run_command_value
            self.get_bin_path_value = get_bin_path_value

        def run_command(self, cmd):
            return self.run_command_value

        def get_bin_path(self, executable):
            return self.get_bin_path_value

    netbsd = VirtualSysctlDetectionMixin()

    def test_success(key, ret_code, out, expected_virtual_product_facts):
        value = (ret_code, out, '')
        netbsd.module = NetFreeBSDModule(value, 'true')

# Generated at 2022-06-11 06:17:07.350038
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(object):
        sysctl_path = '/sbin/sysctl'

        def __init__(self):
            self.module = MockModule()
            self.detect_sysctl = VirtualSysctlDetectionMixin().detect_sysctl

    class MockModule(object):
        def run_command(self, cmd):
            return cmd.strip() == '/sbin/sysctl -n hw.model' and (0, "QEMU", "") or (0, "OpenBSD", "")

    obj = TestClass()
    result = obj.detect_virt_vendor(key='hw.model')
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set([])

    result = obj.detect_virt_v

# Generated at 2022-06-11 06:17:15.328056
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    x = VirtualSysctlDetectionMixin()
    assert x.detect_virt_product('machdep.hypervisor') == {'virtualization_tech_guest': set(['virtualbox']), 'virtualization_tech_host': set([]), 'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}
    assert x.detect_virt_product('machdep.cpu.brand_string') == {'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set([]), 'virtualization_type': 'xen', 'virtualization_role': 'guest'}


# Generated at 2022-06-11 06:17:23.314520
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeModule()
    detect = VirtualSysctlDetectionMixin()
    detect.module = module
    detect.sysctl_path = '/sbin/sysctl'
    module.run_command = fake_run_command_for_detect_virt_product
    module.exit_json = fake_exit_json
    detect.exit_json = fake_exit_json
    detect.exit_json_fail = fake_exit_json_fail
    detect.detect_virt_product('hw.model')
    module.run_command = fake_run_command_for_detect_virt_vendor
    detect.detect_virt_vendor("security.jail.jailed")
    detect.detect_virt_product("security.jail.jailed")

