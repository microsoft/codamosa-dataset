

# Generated at 2022-06-11 06:07:42.200279
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    import sys
    import os
    import tempfile

    fake_sysctl_path = tempfile.mktemp()
    fake_sysctl_content = ""
    def fake_sysctl_command():
        return 0, "QEMU", ""

    class FakeModule(object):

        def get_bin_path(self, command):
            return fake_sysctl_path

        def run_command(self, args):
            if args.startswith("%s -n " % fake_sysctl_path):
                return fake_sysctl_command()
            else:
                raise Exception("unexpected args run_command %s" % args)

    class FakeOS(object):

        class FakePath(object):
            def join(self, *args):
                if args[0] == fake_sysctl_path:
                    return fake_sys

# Generated at 2022-06-11 06:07:52.428918
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinClass():
        def detect_sysctl(self):
            self.sysctl_path = '/usr/bin/sysctl'

    class Module(object):
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/sysctl'

        def run_command(self, command):
            if command == '/usr/bin/sysctl -n hw.model':
                return 0, 'VMware vSMP RT', ''
            elif command == '/usr/bin/sysctl -n machdep.cpu.brand_string':
                return 0, 'Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz', ''
            elif command == '/usr/bin/sysctl -n security.jail.jailed':
                return 0,

# Generated at 2022-06-11 06:08:03.751249
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModuleMock()
    detector = VirtualSysctlDetectionMixin()
    detector.module = module
    detector.sysctl_path = "/sbin/sysctl"
    (rc, out, err) = module.run_command("%s -n %s" % (detector.sysctl_path, "hw.model"))
    assert rc == 0
    assert out == 'OpenBSD'
    facts = detector.detect_virt_vendor('hw.model')
    assert 'virtualization_type'    in facts
    assert 'virtualization_role'    in facts
    assert 'virtualization_tech_guest' in facts
    assert 'vmm' in facts['virtualization_tech_guest']
    assert 'virtualization_tech_host' in facts
    assert len(facts['virtualization_tech_host'])

# Generated at 2022-06-11 06:08:05.199002
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # TODO: Implement unit test.
    return


# Generated at 2022-06-11 06:08:15.442618
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Get the method and class objects
    m = VirtualSysctlDetectionMixin()
    c = type('', (object,), {})

    # Execute the method detect_sysctl. This is needed to store sysctl_path
    # attribute.
    m.detect_sysctl()

    # Set sysctl_path to a known return value.
    m.sysctl_path = '/usr/sbin/sysctl'
    if m.sysctl_path:
        # Create a mock_run_command method for the class.
        def mock_run_command(self, command):
            return 0, 'QEMU Virtual CPU version (cpu64-rhel6)', ''
        c.run_command = mock_run_command

        # Run detect_virt_product, which in turn would call c.run_command
        # and return

# Generated at 2022-06-11 06:08:24.656376
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    cmd_mock = {
        'sysctl -n hw.model': (0, 'VirtualBox\n', '')
    }
    module_mock = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    module_mock.run_command = lambda x: cmd_mock[x]
    module_mock.get_bin_path = lambda x: 'sysctl'
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module_mock
    mixin.detect_sysctl = lambda: True
    ret = mixin.detect_virt_product('hw.model')
    assert ret['virtualization_type'] == 'virtualbox'
    assert ret['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:08:35.266494
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = 'sysctl'
        def run_command(self, command):
            # rc, out and err must match the expected command if it is in
            # the list.  Otherwise, we return a default set.
            default_out = 'Not a Virtual Machine'
            default_rc = 0
            default_err = None

            if command == 'sysctl -n kern.vm_guest':
                return 0, 'VMware', None
            if command == 'sysctl -n security.jail.jailed':
                return 0, '1', None

            return default_rc, default_out, default_err
    class_under_test = VirtualSysctlDetectionMixinMock()

# Generated at 2022-06-11 06:08:44.006195
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class host(object):
        class module(object):
            class run_command(object):
                class rc(object):
                    returncode = 0
                    stdout = ['KVM guest']
                    stderr = []
        def get_bin_path(bin_path):
            return 'sysctl'

    test = VirtualSysctlDetectionMixin()
    test.module = host()
    test.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl(test)
    assert {'virtualization_type': 'kvm', 'virtualization_role': 'guest',
            'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['kvm'])} == test.detect_virt_product('hw.product')

# Generated at 2022-06-11 06:08:54.163254
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, binary):
            return "/sbin/sysctl"

        def run_command(self, binary):
            if binary.startswith("/sbin/sysctl -n hw.model"):
                return 0, "QEMU Virtual CPU version 1.0", ''
            if binary.startswith("/sbin/sysctl -n security.jail.jailed"):
                return 0, "1", ''
            if binary.startswith("/sbin/sysctl -n hw.product"):
                return 0, "OpenBSD Virtual Machine", ''

# Generated at 2022-06-11 06:09:04.995384
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, 'QEMU', '')
            self.get_bin_path = lambda x: '/usr/bin/sysctl'
    class MockClass(object):
        def __init__(self):
            self.module = MockModule()
            self.sysctl_path = None

    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_sysctl = lambda: None
    cls = MockClass()
    result = mixin.detect_virt_vendor('')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' in result['virtualization_tech_guest']

# Unit test

# Generated at 2022-06-11 06:09:25.491987
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FreebsdModule(object):

        def __init__(self):
            self.virtual_facts = {}

        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return [0, 'QEMU', '']

    fake_module = FreebsdModule()
    fake_sysctl = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    fake_sysctl.module = fake_module
    result = fake_sysctl.detect_virt_vendor(key)

    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'



# Generated at 2022-06-11 06:09:34.991799
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import unittest
    import pkg_resources
    import sys
    import os
    # workaround to be able to load module when test is run in the jenkins testsuite
    sys.path.append(os.path.dirname(sys.modules[__name__].__file__))
    import module_utils.virtual

    class ModuleMock(object):
        def __init__(self):
            self.run_command_values = {}
            self.run_command_values['sysctl -n hw.product'] = ('0', 'QEMU', 'something')
            self.run_command_values['sysctl -n dm.version'] = ('0', 'QEMU', 'something')

        def get_bin_path(self, app):
            return '/bin/' + app


# Generated at 2022-06-11 06:09:42.989313
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Mock module, mock sysctl path and output 'OpenBSD'
    mock_module = mock()
    mock_module.get_bin_path = lambda arg: arg
    mock_module.run_command = lambda arg: (0, 'OpenBSD', None)
    result = VirtualSysctlDetectionMixin().detect_virt_vendor('mock_key')
    # Expected result
    assert type(result) == dict
    assert result == {'virtualization_type': 'vmm',
                      'virtualization_role': 'guest',
                      'virtualization_tech_host': set(),
                      'virtualization_tech_guest': {'vmm'}}

# Generated at 2022-06-11 06:09:52.016122
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockLinuxModule(object):
        def get_bin_path(self, arg):
            return "/usr/bin/sysctl"

        def run_command(self, arg):
            return (0, 'VirtualBox', '')  # RC, out, err

    vspdm = VirtualSysctlDetectionMixin()
    vspdm.module = MockLinuxModule()
    vspdm.detect_sysctl()
    assert vspdm.sysctl_path == "/usr/bin/sysctl"
    virtual_facts = vspdm.detect_virt_product('machdep.cpu.brand_string')
    assert virtual_facts == {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest'}



# Generated at 2022-06-11 06:10:02.444916
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            return 0, "QEMU\n", ""

        def get_bin_path(self, name):
            return "/usr/bin/sysctl"
    import uuid
    from ansible_collections.misc.not_a_real_collection.plugins.module_utils.facts import virtual

    virtual_product_detection = virtual.VirtualSysctlDetectionMixin()
    virtual_product_detection.module = MockModule()


# Generated at 2022-06-11 06:10:11.615290
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, exe):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'KVM', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fvdm = FakeVirtualSysctlDetectionMixin()
    result = fvdm.detect_virt_product('hw.model')
    assert result == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }


# Generated at 2022-06-11 06:10:22.546945
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''
        def get_bin_path(self, cmd, opts=None):
            return self.get_bin_path_out
        def run_command(self, command):
            return self.run_command_rc, self.run_command_out, self.run_command_err

    class FactsMock(object):
        def __init__(self, module):
            self.module = module

    class Module():
        def __init__(self, module, facts):
            self.module = module
            self.facts = facts

    module = Module

# Generated at 2022-06-11 06:10:27.693352
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """Performs unit test for method detect_virt_product of VirtualSysctlDetectionMixin class."""
    import unittest2 as unittest
    from ansible.module_utils.facts.virtual.base import VirtualSysctlDetectionMixin as VSysM
    results = VSysM.detect_virt_product("hw.model")
    assert('virtualization_type' in results)
    assert('virtualization_role' in results)
    assert('virtualization_tech_host' in results)
    assert('virtualization_tech_guest' in results)


# Generated at 2022-06-11 06:10:38.779063
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.six import b
    from ansible.module_utils.basic import AnsibleModule
    virtual_vendor_facts = {}

    class VirtualSysctlDetectionMixin_ModuleMock(object):
        class ModuleFailException(Exception):
            pass

        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            raise VirtualSysctlDetectionMixin_ModuleMock.ModuleFailException

        def run_command(self, args):
            if self.run_command_matcher:
                self.run_command_matcher(args)
            return self.run_command_rc, self.run_command_stdout, self.run_command_stderr


# Generated at 2022-06-11 06:10:48.269966
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd.freebsd import VirtualSysctlDetectionMixin
    from mock import patch

    # Case 1, for non-virtualized system
    module = VirtualSysctlDetectionMixin()
    module.module = module
    module.module.run_command = lambda x: (0, '', '')
    assert module.detect_virt_product('hw.model') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

    # Case 2, for kvm guest
    module = VirtualSysctlDetectionMixin()
    module.module = module
    module.module.run_command = lambda x: (0, 'KVM', '')

# Generated at 2022-06-11 06:11:19.651893
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os.path
    import platform

    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin

    class VirtualSysctlDetectionMixinSubclass(VirtualSysctlDetectionMixin):
        def __init__(self, sysctl_path='/sbin/sysctl', module=None, class_name='VirtualSysctlDetectionMixinSubclass'):
            self.sysctl_path = sysctl_path
            self.module = module
            self.class_name = class_name

        def detect_sysctl(self):
            pass

    # Test openbsd
    if platform.system() != 'OpenBSD':
        return

    tested_class = VirtualSysctlDetectionMixinSubclass()

    assert tested_class.detect_virt_vendor('hw.vmm.vendor')

# Generated at 2022-06-11 06:11:30.211717
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # create class to test
    class AnsibleModule:
        def __init__(self):
            self.debug = False
            self.exit_json = print

    class OsDetect:
        def __init__(self):
            self.module = AnsibleModule()
            self.freebsd_version = '12.0-RELEASE'

    # set test data for calling instance of class OsDetect
    module1 = AnsibleModule()
    detect1 = OsDetect()
    detect1.module = module1

    # create and set test data for instance of class VirtualSysctlDetectionMixin
    module2 = AnsibleModule()
    detect2 = VirtualSysctlDetectionMixin()
    detect2.module = module2

    # set test data for return value of detect_sysctl method

# Generated at 2022-06-11 06:11:34.795454
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = VirtualSysctlDetectionMixin()
    virtual_product_facts = {'virtualization_role': 'guest', 'virtualization_type': 'kvm'}
    assert module.detect_virt_product('machdep.hypervisor') == virtual_product_facts


# Generated at 2022-06-11 06:11:41.647847
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
        module = FakeModule()
        module.run_command = FakeRunCommand()
        mixin = VirtualSysctlDetectionMixin()
        mixin.module = module
        virtual_product_facts = mixin.detect_virt_product('hw.model')
        assert virtual_product_facts['virtualization_type'] == 'parallels'
        assert virtual_product_facts['virtualization_role'] == 'guest'
        assert 'parallels' in virtual_product_facts['virtualization_tech_guest']
        assert len(virtual_product_facts['virtualization_tech_host']) == 0

        virtual_product_facts = mixin.detect_virt_product('hw.model')
        assert virtual_product_facts['virtualization_type'] == 'Hyper-V'

# Generated at 2022-06-11 06:11:49.174725
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.bsd import VirtualSysctlDetectionMixin

    v_sysctl_detect_virt_vendor = VirtualSysctlDetectionMixin()
    host_tech = set()
    guest_tech = set()
    v_sysctl_detect_virt_vendor.sysctl_path = '/sbin/sysctl'
    (virtual_vendor_facts, rc, out, err) =  v_sysctl_detect_virt_vendor.detect_virt_vendor('hw.model')
    assert rc == 0
    assert out.rstrip() == 'QEMU'
    guest_tech.add('kvm')
    virtual_vendor_facts['virtualization_type'] = 'kvm'
    virtual_vendor_facts['virtualization_role'] = 'guest'

# Generated at 2022-06-11 06:11:50.938131
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # TODO: Mock out sysctl and test different outputs
    pass


# Generated at 2022-06-11 06:12:01.801798
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import tempfile
    test_file = tempfile.NamedTemporaryFile()
    test_file.write(b'something')
    test_file.flush()

    test_VirtualSysctlDetectionMixin = VirtualSysctlDetectionMixin()
    test_VirtualSysctlDetectionMixin.sysctl_path = test_file.name
    test_VirtualSysctlDetectionMixin.module = MagicMock()
    test_VirtualSysctlDetectionMixin.module.run_command = MagicMock(return_value = (0, "kvm\n", ''))
    test_VirtualSysctlDetectionMixin.module.run_command.return_value = (0, "kvm\n", '')
    product = test_VirtualSysctlDetectionMixin.detect_virt_product('machdep.hypervisor')
   

# Generated at 2022-06-11 06:12:12.034148
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    with open('/sys/devices/virtual/dmi/id/product_name', 'w') as f:
        f.write('ProductName')
    with open('/proc/xen/capabilities', 'w') as f:
        f.write('control_d')

    class TestModule(object):
        def get_bin_path(self, command, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None, binary_data=True, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None):
            rc = 0
            out = ''
            err = ''
            return (rc, out, err)

# Generated at 2022-06-11 06:12:18.264807
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakedModule:
        def get_bin_path(self, name):
            return "/sbin/sysctl"

        def run_command(self, command):
            return (0, 'XenPVHVM', '')

    class FakedVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakedModule()

    ins = FakedVirtualSysctlDetectionMixin()
    ins.detect_virt_product(key='hardware.model')
    assert ins.sysctl_path == "/sbin/sysctl"


# Generated at 2022-06-11 06:12:28.415235
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockPlugin(object):
        def __init__(self):
            self.sysctl_path = "/sbin/sysctl"

        def detect_sysctl(self):
            return

        def get_bin_path(self, path):
            return self.sysctl_path

        def run_command(self, cmd):
            rc = 0
            out = 'QEMU'
            err = ""
            return rc, out, err

    obj = VirtualSysctlDetectionMixin()
    obj.module = MockPlugin()
    key = "compat.linux.osrelease"
    expected_result = {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([])}
    result = obj

# Generated at 2022-06-11 06:13:40.176701
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    # If the test is being run from the ansible-test harness, ansible_module_runner
    # will be set to the name of the module being tested.  In that case, we
    # use the runner module as the mock module.

    mock_module = 'ansible_test_mock_module'
    if 'ansible_module_runner' in globals():
        mock_module = globals()['ansible_module_runner']

    # Create a module mock

    module = AnsibleModuleMock(mock_module)

    # For this test, we make the mock module return '/usr/bin/sysctl' when get_bin_path
    # is called with 'sysctl'.


# Generated at 2022-06-11 06:13:49.231826
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Init class
    module_executor = VirtualSysctlDetectionMixin()
    # Create object
    setattr(module_executor, 'sysctl_path', 'sysctl')
    key = "hw.model"
    # Method to test
    virtual_vendor_facts = module_executor.detect_virt_vendor(key)
    assert virtual_vendor_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_vendor_facts['virtualization_tech_host'] == set()
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-11 06:13:58.185878
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-11 06:14:07.796526
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MyModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'
        def run_command(self, command_line):
            return (self.rc, self.out, self.err)


# Generated at 2022-06-11 06:14:17.354254
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.tmpdir = None
            self.params = {'dst': '/tmp/ansible_facts'}

        def get_bin_path(self, arg):
            return "/sbin/sysctl"

        def run_command(self, arg):
            return (0, "QEMU", "")

    class FakeContext(object):
        def __init__(self):
            self.module = FakeModule()

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    fact_collector = FakeVirtualSysctlDetectionMixin()
    fact_collector.detect_virt_product('hw.model')

# Generated at 2022-06-11 06:14:27.171374
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualDetectionBase
    from ansible.module_utils.facts.virtual import PlatformSysctlVirtualDetectionMixin

    from ansible_collections.ansible.community.plugins.module_utils.facts.virtual import PlatformSysctlVirtualDetectionMixin

    class VirtualTest(PlatformSysctlVirtualDetectionMixin, VirtualSysctlDetectionMixin, VirtualDetectionBase):
        pass

    virtualTestObj = VirtualTest({}, None)
    virtualTestObj.module.run_command = lambda x: [0, 'VirtualBox', '']
    v = virtualTestObj.detect_virt_product('hw.model')
    assert v['virtualization_type'] == 'virtualbox'

# Generated at 2022-06-11 06:14:27.816295
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    pass

# Generated at 2022-06-11 06:14:36.179286
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.collector.system.freebsd_system import VirtualSysctlDetectionMixin
    x = VirtualSysctlDetectionMixin()

    class FakeModule(object):
        def get_bin_path(self, path):
            return "/sbin/sysctl"

        def run_command(self, command):
            return 0, "Parallels", None

    x.module = FakeModule()

    assert x.detect_virt_product('hw.product') == {
        'virtualization_type': 'parallels',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'parallels'},
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-11 06:14:45.117121
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from units.modules.utils import set_module_args
    from ansible.module_utils.facts.collector.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.collector.bsd import OpenBSDFactsCollector
    from ansible.module_utils.facts import Facts

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.sysctl_path = '/usr/bin/sysctl'
            self.module = module

    set_module_args({})
    fact_collector = OpenBSDFactsCollector()
    fact_collector.collect()
    facts = Facts(dict(ansible_facts=fact_collector.facts))
    test_obj = TestVirtualSysctlDetectionMixin(facts)

# Generated at 2022-06-11 06:14:56.279388
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class _VirtualSysctlDetectionMixin():

        def __init__(self):
            self.module = _AnsibleModule()
            self.sysctl_path = '/sbin/sysctl'

        def detect_virt_vendor(self, key):
            return super(_VirtualSysctlDetectionMixin, self).detect_virt_vendor(key)

    class _AnsibleModule():

        def __init__(self):
            self.run_command_counter = 0

        def run_command(self, cmd, check_rc=True):
            out = "foo"
            rc = 0
            if self.run_command_counter == 0:
                out = "QEMU"
            elif self.run_command_counter == 1:
                out = "foo"

# Generated at 2022-06-11 06:17:07.442880
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # mock_module and mock_run_command are copied from module/system/linux.py
    # around line 945
    class MockModule:
        def __init__(self):
            self.fail_json = lambda *args, **kwargs: exit(1)
            self.params = {'platform': 'FreeBSD'}
            self.run_command = lambda *args, **kwargs: [0, 'some vendor', '']
            self.get_bin_path = lambda *args, **kwargs: 'some/bin/dir'

    # mock the actual test method
    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass

    m = MockModule()
    vsdm = MockVirtualSysctlDetectionMixin()
    # test without key
    assert vs

# Generated at 2022-06-11 06:17:16.409078
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module_mock = AnsibleModuleMock(
        dict(
            params=dict(
                key='machdep.simulator',
            ),
        ),
    )
    root_mock = VirtualSysctlDetectionMixin()
    root_mock.module = module_mock
    sysctl_path_mock = SysctlPathMock()
    root_mock.sysctl_path = sysctl_path_mock
    assert root_mock.detect_virt_vendor('machdep.simulator') == dict(virtualization_tech_guest=set(['kvm']), virtualization_tech_host=set(), virtualization_type='kvm', virtualization_role='guest')
    with pytest.raises(AssertionError):
        root_mock.detect_virt_v

# Generated at 2022-06-11 06:17:22.366302
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = MagicMock()
    test_object.module.run_command.return_value = (0, 'kvm', '')
    test_object.detect_virt_product('hw.model')
    assert test_object.sysctl_path == '/sbin/sysctl'
    assert test_object.module.run_command.call_count == 1
    assert test_object.module.run_command.call_args == call('/sbin/sysctl -n hw.model')
