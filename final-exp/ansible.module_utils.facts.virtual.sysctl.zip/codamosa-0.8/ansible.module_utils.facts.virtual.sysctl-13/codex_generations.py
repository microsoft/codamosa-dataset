

# Generated at 2022-06-11 06:07:41.795357
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = MockModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_sysctl = MockSysctlDetection()

    mixin.module = module
    facts = mixin.detect_virt_product('')
    assert 'virtualization_type' not in facts
    facts = mixin.detect_virt_product('machdep.hypervisor')
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'kvm'
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts


# Generated at 2022-06-11 06:07:52.065700
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = object()
    key = 'hw.product'
    out = 'OpenBSD'
    results = (0, out, '')

    # Prerequisites
    class_object = VirtualSysctlDetectionMixin()
    class_object.module = module
    class_object.sysctl_path = 'sysctl'
    # Mock
    class MockModule:
        def run_command(self, cmd):
            if cmd == 'sysctl -n hw.product':
                return results
            else:
                return False

    module = MockModule()
    class_object.module = module

    # Test
    virtual_vendor_facts = class_object.detect_virt_vendor(key)

# Generated at 2022-06-11 06:08:03.328064
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class X(VirtualSysctlDetectionMixin):
        def run_command(self, *args, **kwargs):
            pass
        def get_bin_path(self, *args, **kwargs):
            pass

    x = X()
    x.sysctl_path = '/usr/local/bin/sysctl'
    x.module = {'run_command': '', 'get_bin_path': ''}

    # If rc is not 0, we return dict()
    assert x.detect_virt_product('not.a.real.key') == dict()

    # Run a real test that should return some real data
    x.detect_sysctl()
    x.module.run_command = lambda *args: (0, 'QEMU\n', '')

# Generated at 2022-06-11 06:08:13.782863
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class mock_module(object):
        def __init__(self):
            self.run_command = self.mock_run_command

        def mock_run_command(self, command):
            if re.match('.*-n kern.vm_guest.*', command) and not re.match('.*-n security.jail.jailed.*', command):
                rc = 0
                out = 'KVM'
                err = ''
            elif re.match('.*-n security.jail.jailed.*', command):
                rc = 0
                out = '1'
                err = ''
            else:
                rc = 0
                out = 'foo'
                err = ''
            return (rc, out, err)


# Generated at 2022-06-11 06:08:21.606829
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDFactCollector

    class MockModule(object):
        @staticmethod
        def get_bin_path(name, opts=None):
            return '/foo/sysctl'

        @staticmethod
        def run_command(cmd, check_rc=True, close_fds=True, exec_in_place=True, data=None, binary_data=False):
            return 0, 'qemu', ''

    class MockFreeBSDFactCollector(VirtualFreeBSDFactCollector, VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
    mock_module = MockModule()
    mock_collect

# Generated at 2022-06-11 06:08:32.249314
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # detect_virt_product should return dictionary with virtualization_type of 'jails'
    # and virtualization_role of 'guest' when current system is jailed
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            # Fake sysctl command
            self.sysctl_path = 'fake_sysctl'

    virtual_sysctl = VirtualSysctlDetectionMixinTest()
    virtual_sysctl.module = FakeModule()
    result = virtual_sysctl.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-11 06:08:41.824559
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Should detect FreeBSD kvm guests
    for virtualization_type in ['kvm']:
        module = MockModule('sysctl', {'security.bsd.unprivileged_proc_debug' : 0,
                                       'machdep.cpu_vendor' : 'GenuineIntel',
                                       'hw.model' : 'Intel(R) Xeon(R) CPU E5-2650 v2 @ 2.60GHz',
                                       'hw.machine' : 'amd64',
                                       'hw.ncpu' : 2,
                                       'kern.version' : '10.2-RELEASE',
                                       'security.jail.jailed' : 0})
        facts = VirtualSysctlDetectionMixin()
        facts.module = module


# Generated at 2022-06-11 06:08:48.216025
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule:
        def __init__(self):
            self.params = None
        def get_bin_path(self, in_bin):
            if in_bin == 'sysctl':
                return '/sbin/sysctl'
                
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()
            self.sysctl_path = None
        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n kern.vm_guest':
                if self.sysctl_path:
                    return (0, 'QEMU', '')
            if cmd == '/sbin/sysctl -n hw.model':
                return (0, 'OpenBSD', '')
            
    myTest = TestClass()
    my

# Generated at 2022-06-11 06:08:56.698149
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = AnsibleModule(argument_spec={})
    # This emulates a Xen guest
    data = {
        'sysctl_path': 'sysctl',
        'key': 'machdep.cpu.brand_string'
    }
    result = virtual_sysctl_detection_mixin.detect_virt_product(data['key'])
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:09:07.405895
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.community.general.plugins.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    class module(object):

        def get_bin_path(self, name):
            return name

        def run_command(self, command):
            if 'sysctl -n hw.product' == command:
                return 0, "QEMU", ""
            if 'sysctl -n hw.vendor' == command:
                return 0, "OpenBSD", ""

    virtual = VirtualSysctlDetectionMixin()
    virtual.module = module()


# Generated at 2022-06-11 06:09:26.629775
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sysctl

# Generated at 2022-06-11 06:09:28.995498
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    output = test_object.detect_virt_vendor('hw.model')
    assert output



# Generated at 2022-06-11 06:09:34.319596
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Obj(object):
        def test_VirtualSysctlDetectionMixin_detect_virt_vendor(self):
            assert True
    Obj.detect_virt_vendor = VirtualSysctlDetectionMixin().detect_virt_vendor
    assert 'virtualization_type' not in Obj().detect_virt_vendor('machdep.hypervisor_vendor')


# Generated at 2022-06-11 06:09:43.988076
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    obj = VirtualSysctlDetectionMixin()
    obj.module = module

    module.run_command = mock.Mock(return_value=(0, '', ''))

    # Test non-zero return code
    module.run_command.return_value = (1, '', '')
    results = obj.detect_virt_product('')

    assert results == {}

    # Test VMware host
    module.run_command.return_value = (0, '.VMware. vmx family 5 model 10', '')
    results = obj.detect_virt_product('dev.cpu.0.brand_raw')


# Generated at 2022-06-11 06:09:53.792509
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = False

        def detect_virt_product(self, key):
            # This is the method we're testing
            return VirtualSysctlDetectionMixin.detect_virt_product(self, key)

    # Test detecting different product types

# Generated at 2022-06-11 06:10:04.467927
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    import ansible_module_freebsd_virtual as am
    d = am.VirtualSysctlDetectionMixin()
    d.module = FakeAnsibleModule()
    assert d.detect_virt_vendor('security.jail.jailed') == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'jails'},
        'virtualization_role': 'guest',
        'virtualization_type': 'jails'
    }
    assert d.detect_virt_vendor('hw.model') == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_role': None,
        'virtualization_type': None
    }



# Generated at 2022-06-11 06:10:12.732227
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinObj(object):
        def __init__(self):
            self.sysctl_path = './bin/sysctl'
            self.module = VirtualSysctlDetectionMixinObj

        def detect_sysctl(self):
            self.sysctl_path = './bin/sysctl'

    class VirtualSysctlDetectionMixinObj2(object):
        def run_command(self, cmd, check_rc=True):
            return (0, 'QEMU', '')

        def get_bin_path(self, binary, opt_dirs=[]):
            return './bin/sysctl'

    class VirtualSysctlDetectionMixinModule(object):
        def __init__(self):
            self.run_command = VirtualSysctlDetectionMixinObj2().run_command

       

# Generated at 2022-06-11 06:10:23.667376
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin

# Generated at 2022-06-11 06:10:33.377305
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    import os
    import sys

    facts = Facts()
    virtual_sysctl = Virtual(facts, None)

    if sys.version_info.major < 3:
        builtin_module = '__builtin__'
    else:
        builtin_module = 'builtins'

    if os.path.exists('/proc/cpuinfo'):
        with open('/proc/cpuinfo', 'r') as f:
            virtual_sysctl.module.run_command = lambda *args, **kwargs: (0, f.read(), '')
            virtual_product_facts = virtual_sysctl.detect_virt_product('machdep.cpu.brand_string')
            assert virtual_product

# Generated at 2022-06-11 06:10:43.596775
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, string):
            return '/sbin/sysctl'
        
        def run_command(self, string):
            return 1, 'QEMU', ''

    mockmodule = MockModule()

    # Create an instance of the class we want to test
    test_mixin = VirtualSysctlDetectionMixin()
    test_mixin.module = mockmodule
    test_mixin.detect_sysctl()
    retvals = test_mixin.detect_virt_vendor('hw.product')

    # Call the detect_virt_vendor method

# Generated at 2022-06-11 06:11:15.857490
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    check_object = VirtualSysctlDetectionMixin()
    # Setup Module
    check_object.module = MagicMock()

    # Setup check_object.sysctl_path
    check_object.sysctl_path = '/sbin/sysctl'

    set_module_args({})

    # Setup subprocess.Popen
    mock_popen = MagicMock()
    mock_communicate = MagicMock(
        return_value=(
            'KVM, SVM, SVM',
            '',
        ),
    )
    mock_popen.attach_mock(mock_communicate, 'communicate')
    mock_popen.return_value = 0
    with patch.object(subprocess, 'Popen', mock_popen):
        virtual_product_facts = check_object.detect_virt_product

# Generated at 2022-06-11 06:11:25.307029
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Config():
        class Module():
            def get_bin_path(self, app):
                if app == 'sysctl':
                    return '/bin/sysctl'

    class ModuleMock():
        def __init__(self):
            self.config = Config()

        def run_command(self, cmd):
                if cmd == '/bin/sysctl -n kern.vm_guest':
                    return 0, 'QEMU', ''
                if cmd == '/bin/sysctl -n kern.vm_guest':
                    return 0, 'OpenBSD', ''
        def get_bin_path(self, app):
            return self.config.Module.get_bin_path(app)

    vm = VirtualSysctlDetectionMixin()
    vm.module = ModuleMock()
    vm.detect_virt_vendor

# Generated at 2022-06-11 06:11:35.729735
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import MagicMock
    from ansible_collections.notstdlib.moveitallout.plugins.modules import freebsd_pkg

    class my_virtual_sysctl_detection_mixin(VirtualSysctlDetectionMixin):
        pass

    my_virtual_sysctl_detection_mixin.module = MagicMock()
    my_virtual_sysctl_detection_mixin.sysctl_path = "/usr/bin/sysctl"
    my_virtual_sysctl_detection_mixin.module.run_command.return_value = (0, "QEMU", "")


# Generated at 2022-06-11 06:11:39.988953
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # This is a very limited test, since this method is mostly sysctl calls.
    # We're just testing that we get the right dictionary and key names back.
    class BSDMixin(object):
        def __init__(self):
            self.sysctl_path = 'testbin/sysctl'

    class Module(BSDMixin):
        def __init__(self):
            self.run_command_calls = 0

        def get_bin_path(self, name, **kwargs):
            return self.sysctl_path

        def run_command(self, cmd, **kwargs):
            self.run_command_calls += 1
            return 0, 'VirtualBox', None

    class Mixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = Module()


# Generated at 2022-06-11 06:11:45.998185
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = mock.MagicMock()
    module._run_command.return_value = (0, 'QEMU', '')
    module.get_bin_path.return_value = 'sysctl'
    facts = VirtualSysctlDetectionMixin()
    facts.module = module
    result = facts.detect_virt_vendor("machdep.kern_paravirt_provider")
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:11:57.111259
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Successfully run sysctl command
    class FakeModule(object):
       def run_command(self):
           return 0, 'QEMU', ''
       def get_bin_path(self):
           return ''
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    assert mixin.detect_virt_vendor('security.jail.jailed') == {
      'virtualization_tech_guest': set(['kvm']),
      'virtualization_tech_host': set(),
      'virtualization_type': 'kvm',
      'virtualization_role': 'guest'
    }

    # Failed to run sysctl command
    class FakeModule(object):
       def run_command(self):
           return 1, '', ''

# Generated at 2022-06-11 06:11:59.973474
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    obj = VirtualSysctlDetectionMixin()
    obj.module = FakeAnsibleModule()
    obj.detect_virt_product('hw.model')


# Generated at 2022-06-11 06:12:10.433936
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self, run_rc, run_out, run_err):
            self.run_rc = run_rc
            self.run_out = run_out
            self.run_err = run_err

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return "/sbin/sysctl"

        # Mock return values of module.run_command
        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            return self.run_rc, self.run_out, self.run_err


# Generated at 2022-06-11 06:12:15.080331
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = "/usr/bin/sysctl"
    obj_result = obj.detect_virt_vendor("hw.model")
    assert obj_result == {'virtualization_tech_guest': set(['vmm']), 'virtualization_tech_host': set(), 'virtualization_type': 'vmm', 'virtualization_role': 'guest'}

# Generated at 2022-06-11 06:12:25.297789
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            pass

    obj = VirtualSysctlDetectionMixinMock()

    obj.sysctl_path = None
    ret = obj.detect_virt_vendor('machdep.hypervisor_vendor')
    assert ret == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}, \
        'These facts should be empty: %s' % ret

    obj.sysctl_path = '/bin/sysctl'
    obj.module = object()
    obj.module.run_command = run_command_mock
    ret = obj.detect_virt_vendor('machdep.hypervisor_vendor')

# Generated at 2022-06-11 06:13:27.292518
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.openbsd import OpenBSDVirtual
    sysctl_output = dict()
    sysctl_output['hw.model'] = 'OpenBSD'
    virtual_product_facts = dict()
    virtual_product_facts['virtualization_type'] = 'vmm'
    virtual_product_facts['virtualization_role'] = 'guest'
    virtual_product_facts['virtualization_tech_guest'] = set(['vmm'])
    virtual_product_facts['virtualization_tech_host'] = set()
    openbsd_virtual = OpenBSDVirtual(module=None)
    openbsd_virtual.sysctl_path = 'sysctl'

    class OpenBSDModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_

# Generated at 2022-06-11 06:13:34.077043
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeModule({'path': {'sysctl': '/sbin/sysctl'}}, virtual_type="kvm", virtual_role="guest")
    virt_detection_mixin = VirtualSysctlDetectionMixin()
    virt_detection_mixin.module = module
    key = 'hw.model'
    res = virt_detection_mixin.detect_virt_product(key)
    assert res['virtualization_type'] == 'kvm'
    assert res['virtualization_role'] == 'guest'
    assert res['virtualization_tech_guest'] == set(['kvm'])


# Generated at 2022-06-11 06:13:43.299330
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def run_command(self, cmd):
            return(0, '', '')

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MockModule()
    mixin.detect_sysctl = lambda: setattr(mixin, 'sysctl_path', '/bin/sysctl')
    virtual_vendor_facts = mixin.detect_virt_vendor('machdep.hypervisor')
    assert virtual_vendor_facts == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }

    class MockModuleQEMU(object):
        def run_command(self, cmd):
            return(0, 'QEMU', '')

    mixin = VirtualSysctlDetectionMixin()
    mix

# Generated at 2022-06-11 06:13:53.765078
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    import copy
    if sys.version_info[0] == 2:
        import __builtin__ as builtins  # pylint: disable=import-error
    else:
        import builtins  # pylint: disable=import-error

    class TestModule:
        def __init__(self):
            self.params = {'key': 'kern.vm_guest'}
            self.run_command_stdout = 'OpenBSD'

        def get_bin_path(self, *path, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, *cmd, **kwargs):
            return (0, self.run_command_stdout, '')


# Generated at 2022-06-11 06:14:00.192640
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestClass:
        def __init__(self):
            self.sysctl_path = 'no_sysctl'
        def get_bin_path(self, key):
            if key == 'sysctl':
                return 'sysctl'
        def run_command(self, a):
            return (0, 'KVM', '')

    tc = TestClass()
    detected_virt = VirtualSysctlDetectionMixin().detect_virt_product('hw.model')
    assert detected_virt['virtualization_type'] == 'kvm'
    assert detected_virt['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in detected_virt


# Generated at 2022-06-11 06:14:09.951133
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Make sure detect_virt_product works for KVM
    virtual_product_facts = {}
    class DummyModule(object):
        class DummyRunCommand(object):
            def run_command(self, cmd):
                return (0, 'KVM', '')
        run_command = DummyRunCommand()
        def get_bin_path(self, cmd):
            return '/sbin/sysctl'
    class DummyObj(object):
        def __init__(self):
            self.module = DummyModule()
        detect_sysctl = VirtualSysctlDetectionMixin().detect_sysctl
        detect_virt_product = VirtualSysctlDetectionMixin().detect_virt_product
    dummy_obj = DummyObj()

# Generated at 2022-06-11 06:14:18.674382
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-11 06:14:21.716718
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeAnsibleModule()
    VirtualSysctlDetectionMixin().detect_virt_product('dev.cpu.0.product')
    assert module.params == {'key': 'dev.cpu.0.product'}


# Generated at 2022-06-11 06:14:31.556045
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    # Setup Mocks
    sysctl_path = 'sysctl_path'
    module = MockAnsibleModule()
    module.get_bin_path = Mock(return_value=sysctl_path)
    module.run_command = Mock(return_value=[0, 'QEMU', None])
    module.params = {}

    # sysctl found and QEMU is returned
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = module
    virtual_vendor_facts = virtual_sysctl_detection_mixin.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 06:14:39.407918
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_product_facts = {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set()
    }

    # Test KVM
    class KVM(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = '/sbin/sysctl'

        def distro(self):
            return 'kvm'

    kvm = KVM(module=None)
    kvm.detect_virt_product('hw.model')
    kvm_virtual_product_facts = kvm.detect_virt_product('hw.model')
    virtual_product_facts['virtualization_tech_guest'].add('kvm')
    virtual_product_facts['virtualization_type'] = 'kvm'


# Generated at 2022-06-11 06:16:30.135781
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mock_module = type("module", (object,), {
        "run_command": lambda self, command: (0, "foo\n", ""),
        "get_bin_path": lambda self, executable: "/tmp/sysctl"
    })
    detection_mixin = VirtualSysctlDetectionMixin()
    detection_mixin.module = mock_module()
    virtual_vendor_facts = detection_mixin.detect_virt_vendor("machdep.cpu.vendor")

    assert virtual_vendor_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_vendor_facts['virtualization_tech_host'] == set([])
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-11 06:16:37.396539
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class TestModule(object):
        def run_command(self, cmd):
            if 'hw.model' in cmd:
                return 0, 'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz', ''
            if 'security.jail.jailed' in cmd:
                return 0, '0', ''
            if 'hw.machine' in cmd:
                return 0, 'amd64', ''
            if 'kern.hostuuid' in cmd:
                return 0, '', ''

# Generated at 2022-06-11 06:16:44.114345
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: None
        def get_bin_path(self, x):
            return '/usr/bin/sysctl'
        def run_command(self, *args, **kwargs):
            return (0, "KVM (version 4.1.0_1) Oracle Corporation", "")
    class TestObject(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = {}
            self.module = TestModule()
        def gather_block_devices_info(self):
            # override block devices being detected,
            # as it is not needed for this test.
            pass

    to = TestObject()
    to.detect_virt_product('hw.model')
    assert to

# Generated at 2022-06-11 06:16:52.028237
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule:
        def __init__(self, out='KVM\n'):
            self.out = out
            self.run_command_rc = 0

        def get_bin_path(self, path):
            return "/usr/bin/sysctl"

        def run_command(self, cmd):
            return self.run_command_rc, self.out, ''

    # Testing when everything works
    module_test = TestModule()
    test_class = VirtualSysctlDetectionMixin()
    test_class.module = module_test
    test_class.detect_virt_product('hw.model')

    assert test_class.sysctl_path == '/usr/bin/sysctl'
    assert module_test.out == 'KVM\n'
    assert module_test.run_command_rc == 0


# Generated at 2022-06-11 06:17:00.356952
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import textwrap
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    sys.modules['ansible.module_utils.facts.virtual.base'] = Virtual
    sys.modules['ansible.module_utils.facts.virtual.openbsd'] = OpenBSDVirtual


# Generated at 2022-06-11 06:17:10.032691
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    test_dict = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': set()
    }
    m = VirtualSysctlDetectionMixin()
    m.module = basic.AnsibleModule(
        argument_spec=dict(
            foo=dict(type='str', required=False),
        )
    )
    m.sysctl_path = "/usr/sbin/sysctl"

    result = m.detect_virt_vendor('hw.model')
    assert result == test_dict



# Generated at 2022-06-11 06:17:16.675924
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class_under_test = VirtualSysctlDetectionMixin()
    virtual_vendor_facts = class_under_test.detect_virt_vendor('machdep.hypervisor_vendor')
    assert virtual_vendor_facts['virtualization_type'] == 'vmm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_host' not in virtual_vendor_facts
    assert 'kvm' in virtual_vendor_facts['virtualization_tech_guest']
    assert 'vmm' in virtual_vendor_facts['virtualization_tech_guest']


# Generated at 2022-06-11 06:17:24.818243
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class MockModule(object):
        def __init__(self):
            self.params = dict()
            self.run_command_called = False
            self.bin_path_called = False
            self.params['virtualization_type'] = None
            self.params['virtualization_role'] = None
            self.params['virtualization_tech_guest'] = None
            self.params['virtualization_tech_host'] = None

        def fail_json(self, **args):
            self.exit_args = args
            self.exit_called = True

        def get_bin_path(self, binary):
            self.bin_path_called = True
            return "/usr/bin/%s" % binary

        def run_command(self, command):
            self.run_command_called = True
            self.command = command