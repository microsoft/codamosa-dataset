

# Generated at 2022-06-11 06:07:39.662414
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    v = VirtualSysctlDetectionMixin()
    assert v.detect_virt_vendor('hw.model') == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    }

# Generated at 2022-06-11 06:07:50.012157
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import os
    import ansible.module_utils.facts.system.virtual as virtual
    class TestModule:
        def __init__(self):
            self.params = { 'module_name': 'virtual' }
        def get_bin_path(self, prog, opts=None, required=False):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            return 0, 'VMWare\n', ''
    testmodule = TestModule()
    testmodule.run_command = TestModule.run_command
    virtual_sysctl = virtual.VirtualSysctlDetectionMixin()
    virtual_sysctl.module = testmodule
    virtual_sysctl.detect_virt_product('hw.model')
    assert testmodule.params['virtualization_type'] == 'VMware'


# Generated at 2022-06-11 06:07:53.297351
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''
    Since the unit tests require root permissions, we only check the type of the method
    :return:
    '''
    assert type(VirtualSysctlDetectionMixin().detect_virt_vendor('kern.vm_guest')) == dict


# Generated at 2022-06-11 06:08:04.185824
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys

    module_mock = type('module', (object,), {
        'run_command': lambda self, command: (0, "KVM", ""),
        'get_bin_path': lambda self, command: "/bin/sysctl"
    })()
    module_mock.__class__.__name__ = 'module'
    sys.modules['ansible.module_utils.facts.virtual.virtual_sysctl_detection'] = module_mock

    vm = VirtualSysctlDetectionMixin()
    vm.module = module_mock

    result = vm.detect_virt_product('machdep.cpu.brand_string')
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-11 06:08:14.355899
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.virtual.base import VirtualSysctlDetectionMixin

    class MockModule:
        def __init__(self, params):
            self._params = params

        def get_bin_path(self, executable, opt_dirs=[]):
            # Return dummy path, this is not required for test case
            return '/bin/sysctl'

        def run_command(self, cmd):
            # Return dummy result, this is not required for test case
            return 0, 'QEMU', ''

    class MockFactsCollector(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = MockModule({})
    fact_collector = MockFactsCollector(module)

# Generated at 2022-06-11 06:08:21.864263
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    key = 'machdep.hypervisor'

    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'VMware', ''

    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = FakeModule()
    result = test_obj.detect_virt_product(key)

    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'VMware'
    assert 'virtualization_tech_host' in result
    assert result['virtualization_tech_host'] == set()
    assert 'virtualization_tech_guest' in result

# Generated at 2022-06-11 06:08:32.482698
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    p = VirtualSysctlDetectionMixin()
    p.sysctl_path = None
    ret = p.detect_virt_vendor('hw.model')
    assert ret['virtualization_tech_guest'] == set()
    assert ret['virtualization_tech_host'] == set()
    assert ret['virtualization_type'] == None
    assert ret['virtualization_role'] == None

    p.sysctl_path = "/bin/sysctl"
    def run_command_return(args):
        if args == '/bin/sysctl -n hw.model':
            return 0, 'foo', ''
    p.module.run_command = run_command_return
    ret = p.detect_virt_vendor('hw.model')
    assert ret['virtualization_tech_guest'] == set()
    assert ret

# Generated at 2022-06-11 06:08:42.014937
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    class sysctl_virtual_vendor_mockup(object):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

        def run_command(self, command):
            return 0, '', ''

    class sysctl_virtual_vendor_mockup_without_sysctl(object):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    class sysctl_virtual_vendor_mockup_with_sysctl(object):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = 'dummy'



# Generated at 2022-06-11 06:08:47.972772
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    here = os.path.abspath(os.path.dirname(__file__))
    mock_module = imp.load_source('ansible_module', os.path.join(here, '../unit/module_utils/powershell.py'))
    virtual_sysctl_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_mixin.module = mock_module
    result = virtual_sysctl_mixin.detect_virt_vendor('kern.vm_guest')
    assert result == {'virtualization_type': 'vmm', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-11 06:08:59.579825
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinClass(VirtualSysctlDetectionMixin):
        pass

    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, exe):
            return "/usr/sbin/%s" % exe

        def run_command(self, cmd):
            if cmd == "/usr/sbin/sysctl -n machdep.cpu.brand_string":
                return 0, "Intel(R) Core(TM) i5-4590 CPU @ 3.30GHz", ""
            if cmd == "/usr/sbin/sysctl -n hw.product":
                return 0, "VirtualBox", ""
            if cmd == "/usr/sbin/sysctl -n security.jail.jailed":
                return 0, "1", ""

# Generated at 2022-06-11 06:09:15.724037
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDModule
    import os

    class VirtualFreeBSDModuleImpl(basic.AnsibleModule, VirtualFreeBSDModule):
        pass

    module = VirtualFreeBSDModuleImpl(
        argument_spec={},
        supports_check_mode=True,
        mutually_exclusive=[],
        required_together=[]
    )

    class VirtualSysctlDetectionMixinImpl(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    out1 = to_bytes('QEMU\n')
   

# Generated at 2022-06-11 06:09:26.267137
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import unittest

    class TestModule(object):
        def get_bin_path(self, command):
            return 'sysctl'


# Generated at 2022-06-11 06:09:31.867969
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Testing of module
    module = VirtualSysctlDetectionMixin()
    module.sysctl_path = '/sbin/sysctl'
    module.module = FakeAnsibleModules()
    assert module.detect_virt_vendor('hw.model') == {'virtualization_tech_guest': set(), 'virtualization_role': None, 'virtualization_type': None, 'virtualization_tech_host': set()}


# Generated at 2022-06-11 06:09:38.882193
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockFreeBSDModule(object):
        def __init__(self):
            self.exit_json = None
            self.params = {'gather_subset': ['all']}
            self.run_command = self.run_command_impl
            self.get_bin_path = self.get_bin_path_impl

        def get_bin_path_impl(self, arg):
            if arg == "sysctl":
                return "/sbin/sysctl"
            else:
                return None

        def run_command_impl(self, arg):
            if arg.startswith("/sbin/sysctl -n security.hostid"):
                return 0, "OpenBSD", ""
            return 1, "", ""

    m = MockFreeBSDModule()

    v = VirtualSysctlDetectionMixin()
    v

# Generated at 2022-06-11 06:09:43.726390
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    assert m.detect_virt_vendor('hw.model') == {'virtualization_tech_host': set(),
                                                'virtualization_tech_guest': set(),
                                                'virtualization_role': 'guest',
                                                'virtualization_type': 'kvm'}



# Generated at 2022-06-11 06:09:48.595034
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Initialize this object
    virt_detect_object = VirtualSysctlDetectionMixin()
    if virt_detect_object.detect_virt_vendor('security.jail.host.hostuuid')['virtualization_type'] == 'vmm':
        print("TEST SUCCESS")
    else:
        print("TEST FAILURE")



# Generated at 2022-06-11 06:09:58.165837
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Build a module, injecting the required path
    import platform
    import sys

    class FakeModule:
        def __init__(self, sys_path=None):
            self.params = {'path': sys_path}

        def get_bin_path(self, module):
            return self.params['path']

        def run_command(self, module):
            return 0, 'kvm', ''

    test_module = FakeModule([])
    if sys.version_info < (2, 6):
        test_class = 'BaseBSD'
    else:
        test_class = 'VirtualSysctlDetectionMixin'
    exec("from ansible.module_utils.facts.system.%s import %s" % (platform.system().lower(), test_class))
    test_class = eval(test_class)
    test_

# Generated at 2022-06-11 06:10:08.921125
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def get_bin_path(self, key):
            return 'sysctl'
        def run_command(self, cmd):
            return self.rc, self.out, self.err


# Generated at 2022-06-11 06:10:19.289937
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MyVirtualOpenBSDFactsModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = {}
            self.sysctl_path = '/sbin/sysctl'
            self.rc = 0
            self.out = 'OpenBSD'
            self.err = ''

        def get_bin_path(self, name):
            return self.sysctl_path

        def run_command(self, cmd):
            return (self.rc, self.out, self.err)

    vobm = MyVirtualOpenBSDFactsModule()
    facts = vobm.detect_virt_vendor('hw.model')
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'vmm'

# Generated at 2022-06-11 06:10:27.550706
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    unlocked_sysctl_module = AnsibleModule(argument_spec={})
    unlocked_sysctl_module.run_command = MagicMock(return_value=(0, '', ''))
    unlocked_sysctl_module.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')
    virtual_detect_sysctl_mixin_instance = VirtualSysctlDetectionMixin()
    virtual_detect_sysctl_mixin_instance.module = unlocked_sysctl_module
    virtual_detect_sysctl_mixin_instance.detect_sysctl = MagicMock()

    locked_sysctl_module = AnsibleModule(argument_spec={})
    locked_sysctl_module.run_command = MagicMock(return_value=(0, 'LockType: Lock', ''))
    locked

# Generated at 2022-06-11 06:10:52.644266
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def get_bin_path(self, name):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n kern.vm_guest':
                return 0, 'KVM/kvm', ''
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            return 1, '', ''
    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.detect_sysctl()
    facts = dict()

# Generated at 2022-06-11 06:11:02.063332
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.collector import VirtualSysctlDetectionMixin

    test_object = VirtualSysctlDetectionMixin()
    fake_run_command = lambda x: (0, "QEMU\n", "")

    test_object.module = type('obj', (object,), {
        'run_command': fake_run_command,
    })

    test_object.sysctl_path = '/bin/sysctl'

    assert test_object.detect_virt_vendor('hw.machine_arch') == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-11 06:11:11.280288
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.virtual import VirtualSysctlDetectionMixin
    class Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.sysctl_cmd = None
            self.module = None

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    o = Test()

    # Test an output that contains 'KVM', 'bhyve' or 'HVM domU', and tests
    # that we set the correct variables
    rc, stdout, stderr = 0, 'KVM', ''
    o.module = AnsibleModuleStub(rc, stdout, stderr)

# Generated at 2022-06-11 06:11:18.770380
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import platform
    # Test Virt Detection on Linux and OpenBSD platforms
    for platform_name in ['Linux', 'OpenBSD']:
        platform.system = lambda: platform_name
        sysctl_path = 'sysctl'
        module = type('module', (object,), {})
        setattr(module, 'get_bin_path', lambda x: sysctl_path)
        setattr(module, 'run_command', lambda x: (0, "", ""))
        VirtualSysctlDetectionMixin.__module__ = module

        fact = VirtualSysctlDetectionMixin()
        fact.module = module
        fact.detect_sysctl = lambda: None
        virtual_product_facts = fact.detect_virt_product('hw.model')
        assert len(virtual_product_facts) == 3

        fact = VirtualSysctlDet

# Generated at 2022-06-11 06:11:29.230438
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_cases = [
        {
            'sysctl_out': 'QEMU\n',
            'expected': {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
        },
        {
            'sysctl_out': 'OpenBSD\n',
            'expected': {'virtualization_type': 'vmm', 'virtualization_role': 'guest'}
        },
        {
            'sysctl_out': '\n',
            'expected': {}
        }
    ]

    for test_case in test_cases:
        test = VirtualSysctlDetectionMixin()

        # mock method for detect_sysctl
        test.sysctl_path = '/path/to/sysctl'

        # mock method for module.run_command
        test.module = MockModule()


# Generated at 2022-06-11 06:11:38.877544
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, exe):
            return True
        def run_command(self, command):
            virt_product_test_cases = {
                'security.jail.jailed': ('0','VirtualBox','XenPV','XenPVHVM','HVM domU','VMware','KVM','kvm','Bochs','Hyper-V','RHEV Hypervisor','SmartDC'),
                'kern.vm_guest': ('none','User','VirtualBox','VMware','XenPV','XenPVH'),
                'hw.model': ('VirtualBox',)
            }
            for key in virt_product_test_cases.keys():
                if key in command:
                    rc = 0
                    out = virt_product_test_cases[key][0]


# Generated at 2022-06-11 06:11:47.814685
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule({})
    # Case 1 - QEMU
    module.run_command = lambda *args: (0, 'QEMU', '')
    virtual_product_facts = VirtualSysctlDetectionMixinImpl.detect_virt_product(module, 'machdep.hypervisor_vendor')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    # Case 2 - VMware
    module.run_command = lambda *args: (0, 'VMware', '')
    virtual_product_facts = VirtualSysctlDetectionMixinImpl.detect_virt_product(module, 'machdep.hypervisor_vendor')
    assert virtual_product_facts['virtualization_type'] == 'VMware'


# Generated at 2022-06-11 06:11:58.349168
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeAnsibleModule()
    facts = VirtualSysctlDetectionMixin()
    facts.module = module

    facts.detect_virt_product('kern.hostname')
    assert facts.sysctl_path is not None
    assert facts.virtual_product_facts == {'virtualization_type': 'virtualbox',
                                           'virtualization_role': 'guest',
                                           'virtualization_tech_guest': set(['virtualbox']),
                                           'virtualization_tech_host': set()}

    assert module.run_command.call_count == 1
    assert module.run_command.call_args == ((facts.sysctl_path + ' -n kern.hostname',),)



# Generated at 2022-06-11 06:12:08.891066
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_subject = VirtualSysctlDetectionMixin()
    test_subject.module = FakeAnsibleModule()
    test_subject.sysctl_path = '/sbin/sysctl'
    test_subject.module.run_command = lambda cmd: (0, 'KVM\n', '')
    assert test_subject.detect_virt_product('machdep.hypervisor') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }
    test_subject.module.run_command = lambda cmd: (0, 'VirtualBox\n', '')

# Generated at 2022-06-11 06:12:16.857494
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    class TestSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        sysctl_path = "/sbin/sysctl"
        module = TestModule()

    class TestModule:
        def get_bin_path(self, name):
            return TestSysctlDetectionMixin.sysctl_path

        def run_command(self, cmd):
            return 0, "KVM", ""

    tsdm = TestSysctlDetectionMixin()

# Generated at 2022-06-11 06:13:11.397136
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MyBsdModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            class MyModule:
                def __init__(self):
                    self.params = {}

                def get_bin_path(self, path):
                    return '/sbin/sysctl'

                def run_command(self, path):
                    return 0, 'QEMU', ''

            self.module = MyModule()

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

    mod = MyBsdModule()
    facts = mod.detect_virt_vendor('machdep.cpu_vendor')
    assert 'kvm' in facts['virtualization_tech_guest']
    assert 'kvm' == facts['virtualization_type']
   

# Generated at 2022-06-11 06:13:17.774511
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def run_command(self, dummy):
            return 0, 'OpenBSD', ''

        def get_bin_path(self, dummy):
            return '/usr/bin/sysctl'

    class VirtVendorDetection(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    vm = VirtVendorDetection(FakeModule())
    vm.detect_virt_vendor('machdep.pcibios')
    assert vm.virtualization_type == 'vmm'
    assert vm.virtualization_role == 'guest'


# Generated at 2022-06-11 06:13:25.045440
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mdict = VirtualSysctlDetectionMixin()
    mdict.detect_sysctl = lambda: True
    mdict.sysctl_path = 'test_sysctl'
    mdict.module = MockModule()
    mdict.module.run_command = lambda x: (0, 'VMware', '')
    assert mdict.detect_virt_product('hw.model') == {'virtualization_type': 'VMware', 'virtualization_role': 'guest'}
    mdict.module.run_command = lambda x: (0, 'VMware ESXi', '')
    assert mdict.detect_virt_product('hw.model') == {'virtualization_type': 'VMware', 'virtualization_role': 'guest'}

# Generated at 2022-06-11 06:13:33.228644
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = MockModule()
    class test_class():
        def __init__(self, module):
            self.module = module
        def detect_sysctl(self):
            self.sysctl_path = 'sysctl_test_path'

    i = test_class(module)
    i.detect_virt_product("security.jail.jailed")
    assert module.run_command_calls[0] == "sysctl_test_path -n security.jail.jailed"
    assert module.run_command_calls[1] == "sysctl_test_path -n security.jail.jailed"
    assert module.run_command_calls[2] == "sysctl_test_path -n security.jail.jailed"

# Generated at 2022-06-11 06:13:42.374838
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    class FreeBSD_Base_Mock(object):
        class Task(object):
            def __init__(self):
                self.args = {}
        class Module(object):
            def __init__(self):
                self.params = {'gather_subset':'all'}
            def get_bin_path(self,program):
                return '/sbin/sysctl'
            def run_command(self,cmd):
                return 0,'QEMU',[]
        loader = Task()
        params = Task()
        module = Module()

    fb = FreeBSD_Base_Mock()
    fb_mix = VirtualSysctlDetectionMixin()
    fb_mix.module = fb.module
    fb_

# Generated at 2022-06-11 06:13:52.982311
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    import sys
    import unittest
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/sbin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, 'QEMU', ''

    class Test(unittest.TestCase):
        def setUp(self):
            self.mixin = VirtualSysctlDetectionMixin()
            self.mixin.module = TestModule()


# Generated at 2022-06-11 06:13:59.489477
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    expected_result = {'virtualization_role': 'guest', 'virtualization_type': 'kvm'}
    fact_result = VirtualSysctlDetectionMixin().detect_virt_product('hw.model')
    assert expected_result == fact_result, \
        "Expected virtualization_role: %s; virtualization_type: %s; actual:" \
        " virtualization_role: %s; virtualization_type: %s" % \
        (expected_result['virtualization_role'],
         expected_result['virtualization_type'],
         fact_result['virtualization_role'],
         fact_result['virtualization_type'])


# Generated at 2022-06-11 06:14:09.348511
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestClassVirtualSysctlDetectionMixin_detect_virt_product:
        def __init__(self, run_command_output):
            self.run_command_output = run_command_output
            self.sysctl_path = None

        def get_bin_path(self, binary):
            return '/sbin/sysctl'

        def run_command(self, command):
            return self.run_command_output

    # Parallels
    t = TestClassVirtualSysctlDetectionMixin_detect_virt_product((0, 'Parallels', ''))
    s = VirtualSysctlDetectionMixin()
    s.module = t
    virtual_product_facts = s.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'parallels'


# Generated at 2022-06-11 06:14:15.819820
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    detector = VirtualSysctlDetectionMixin()
    res = detector.detect_virt_product('kern.vm_guest')
    assert res == {
        'virtualization_tech_guest': {
            'xen',
            'kvm',
            'virtualbox',
            'VMware',
            'Hyper-V',
            'parallels',
            'RHEV',
            'jails'
        },
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-11 06:14:24.088050
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MyVirtualSysctlDetectionMixin(object):
        def __init__(self, return_value):
            self.return_value = return_value

        def detect_sysctl(self):
            return self.return_value

    test_instance = MyVirtualSysctlDetectionMixin(True)
    expected_result = {
        'virtualization_tech_guest': set(),
        'virtualization_role': 'guest',
        'virtualization_type': 'xen',
        'virtualization_tech_host': set()
    }
    result = test_instance.detect_virt_product('machdep.hypervisor_detect')
    assert result == expected_result, \
        "detect_virt_product did not detect virtualization_type correctly"


# Generated at 2022-06-11 06:16:01.808452
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class OpenBSD:
        def detect_sysctl(self):
            pass

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return (0, 'QEMU', None)
            if cmd == '/sbin/sysctl -n kern.hostname':
                return (0, 'OpenBSD.xen', None)
            raise Exception("unexpected command '%s'" % cmd)

        def get_bin_path(self, path):
            return '/sbin/sysctl'

    openbsd = OpenBSD()
    openbsd.detect_virt_vendor('hw.model')


# Generated at 2022-06-11 06:16:10.253199
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MyModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'VMware'

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return self.run_command_rc, self.run_command_out, ''

    class MyVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    mixin = MyVirtualSysctlDetectionMixin(MyModule())
    facts = mixin.detect_virt_product('machdep.hypervisor_name')

# Generated at 2022-06-11 06:16:16.839314
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    import ansible.module_utils.facts.virtual.freebsd

    # define a class named TestClass that is-a VirtualOpenBSDDetectionMixin
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass

    # Instantiate a class object
    test_obj = TestClass()

    # Replace the module object with our own object
    test_obj.module = ansible.module_utils.facts.virtual.freebsd.AnsibleModuleMock()

    # Run the method detect_virt_product
    virtual_facts_from_sysctl = test_obj.detect_virt_product("machdep.cpu_brand")

    # Assert some results
    assert virtual_facts_from_sys

# Generated at 2022-06-11 06:16:20.997097
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    test_result = test_object.detect_virt_vendor('hw.vmm.vendor')
    assert test_result
    assert test_result['virtualization_role'] == 'guest'
    assert test_result['virtualization_type'] == 'vmm'

# Generated at 2022-06-11 06:16:29.544200
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinImplem(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = '/usr/sbin/sysctl'
            self.module = type('AnsibleModule', (object,), {})()
            self.module.run_command = run_command
            self.module.get_bin_path = get_bin_path

        def detect_sysctl(self):
            return


# Generated at 2022-06-11 06:16:36.698046
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = None
    expected_facts = {
        'virtualization_type': 'hyperv',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'hyperv'}
    }

    class ModuleProxy(object):
        def get_bin_path(self, arg):
            return '/bin/sysctl'

        def run_command(self, arg):
            return 0, "Hyper-V", ""

    class VirtualSysctlDetectionMixinProxy(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = ModuleProxy()

    mixin = VirtualSysctlDetectionMixinProxy()
    assert mixin.detect_virt_product('hw.model') == expected_facts



# Generated at 2022-06-11 06:16:43.761026
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    obj = VirtualSysctlDetectionMixin()
    obj.module = FakeAnsibleModule()
    obj.module.run_command = MagicMock()
    obj.sysctl_path = None

    obj.module.run_command.return_value = (0, 'QEMU', '')
    ret = obj.detect_virt_vendor('machdep.hypervisor_vendor')
    assert ret == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'kvm'}}
    assert obj.sysctl_path is not None

    obj.module.run_command.return_value = (0, 'QEMU', '')

# Generated at 2022-06-11 06:16:51.606391
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockSysctlVM(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = self
        def fail_json(self, **kwargs):
            raise Exception('fail_json')
        def get_bin_path(self, path):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if 'security.jail.jailed' in cmd:
                return (0, '1', '')
            return (0, 'KVM', '')
    virtual_facts = MockSysctlVM()
    virtual_facts.detect_sysctl()
    facts = {}

# Generated at 2022-06-11 06:16:59.911901
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {'path': '/bin'}

        def get_bin_path(self, arg):
            return '/bin/' + arg

        def run_command(self, arg):
            return 0, 'QEMU', ''

    class FakeFacts(object):
        # This is what is returned to the calling method (parsed)
        virtual_vendor_facts = {}

    class FakeVendor(VirtualSysctlDetectionMixin, FakeFacts):
        # Don't actually run sysctl
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    module = FakeModule()
    vendor = FakeVendor(module)


# Generated at 2022-06-11 06:17:10.500635
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    vm = VirtualSysctlDetectionMixin()
    vm.module = basic.AnsibleModule(
        argument_spec={'kernel': {'required': False, 'default': 'linux'}},
        supports_check_mode=True
    )

    vm.sysctl_path = '/bin/sysctl'

    assert vm.detect_virt_vendor('machdep.cpu.vendor') == {
        'virtualization_type': None,
        'virtualization_role': None,
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    }
