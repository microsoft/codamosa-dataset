

# Generated at 2022-06-11 06:07:41.550109
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda *args, **kwargs: None
            self.fail_json = lambda *args, **kwargs: None
            self.run_command = lambda *args, **kwargs: (0, '', '')

        def get_bin_path(self, item, required=False):
            return "/bin/%s" % item

    class FakeFactCollector(object):
        def __init__(self):
            self.sysctl_path = None
            self.detect_sysctl = lambda: None

    vm = FakeFactCollector()
    vm.module = FakeModule()

    host_facts = vm.detect_virt_vendor('kern.vm_guest')

# Generated at 2022-06-11 06:07:51.896264
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    def test_objects(m):
        m.run_command = run_command

        class FakeModule:
            def __init__(self):
                self.exit_json = exit_json

            def get_bin_path(self, module):
                return '/sbin/sysctl'

        fm = FakeModule()

        class FakeOpenBSDSysctlModule(VirtualSysctlDetectionMixin, FactsBase):
            def __init__(self, module):
                self.module = fm

        m.sysctl = FakeOpenBSDSysctlModule(fm)


    def run_command(self, cmd, check_rc=True):
        class FakeRetCode:
            def __init__(self, cmd, rc, out, err):
                self.cmd = cmd
                self.rc = rc
                self.stdout = out


# Generated at 2022-06-11 06:08:03.107237
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Module(object):
        def __init__(self):
            self.run_command_results = [[0, "OpenBSD", ""]]
            self.run_command_calls = []
            self.run_command_checked_commands = ['sysctl -n hw.model']
            self.get_bin_path_results = ['sysctl']
            self.get_bin_path_calls = []
            self.get_bin_path_checked_paths = ['sysctl']

        def run_command(self, cmd, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_calls.append(cmd)

# Generated at 2022-06-11 06:08:13.674061
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import platform
    import tempfile
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    VirtualSysctlDetectionMixin.detect_sysctl = lambda *a, **k: None
    # Set up sysctl and sysctl.conf files
    sysctl_file = tempfile.NamedTemporaryFile(mode='w')
    sysctl_file.write('vm.vmm.vendor: OpenBSD\n')
    sysctl_file.flush()
    sysctl_conf_file = tempfile.NamedTemporaryFile(mode='w')
    sysctl_conf_file.write('vm.vmm.vendor: QEMU\n')
    sysctl_conf_file.flush()

    # We patched sysctl_path in the following module, so sysctl is found.

# Generated at 2022-06-11 06:08:21.529007
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def get_bin_path(self, thing):
            return '/sbin/sysctl'

        def run_command(self, thing):
            return 1, 'OpenBSD', ''

    class MockFact(object):
        def get_bin_path(self):
            return '/sbin/sysctl'

        def run_command(self):
            return 1, 'OpenBSD', ''

    class MockFacts(MockFact):
        def __init__(self):
            self.__virtual_vendor_facts = {}

    a = VirtualSysctlDetectionMixin()
    a.module = MockModule()
    a.facts = MockFacts()
    a.detect_virt_vendor('hw.model')
    assert a.facts.virtualization_type == 'vmm'
    assert a

# Generated at 2022-06-11 06:08:32.195113
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # create a mock of the class containing the method we want to test
    class MockModule:
        def get_bin_path(self, s):
            return s
    class MockSystemdDetection(VirtualSysctlDetectionMixin):
        module = MockModule()
        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

# Generated at 2022-06-11 06:08:41.747735
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'
            self.run_command_calls = []

        def get_bin_path(self, exe, opts=None, required=False):
            return self.sysctl_path

        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            self.run_command_calls.append(cmd)
            out = ''
            if 'qemu.hw.vendor' in cmd:
                out = 'QEMU'
            elif 'hw.vmm.vendor' in cmd:
                out = 'OpenBSD'
            elif 'hw.model' in cmd:
                out = 'KVM'
            el

# Generated at 2022-06-11 06:08:47.768115
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule():
        @staticmethod
        def get_bin_path(name):
            if name in ('sysctl'):
                return name

        @staticmethod
        def run_command(cmd):
            return 0, 'QEMU', ''

    class MockSysctlDetection():
        def __init__(self, module):
            self.module = module

    sysctl_detection = MockSysctlDetection(MockModule())
    virtual_vendor_facts = sysctl_detection.detect_virt_vendor('hw.vmm.vm')
    assert(virtual_vendor_facts['virtualization_role'] == 'guest')
    assert(virtual_vendor_facts['virtualization_type'] == 'kvm')


# Generated at 2022-06-11 06:08:56.205828
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test = VirtualSysctlDetectionMixin()
    test.module = {'run_command': lambda x: (0, 'KVMKVMKVM', '')}
    test.sysctl_path = 'sysctl'
    out = test.detect_virt_product('user.emulab.prog')
    assert out['virtualization_type'] == 'kvm'
    assert out['virtualization_role'] == 'guest'
    assert 'kvm' in out['virtualization_tech_guest']
    assert len(out['virtualization_tech_host']) == 0


# Generated at 2022-06-11 06:09:02.940555
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    result = mixin.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set()


# Generated at 2022-06-11 06:09:25.265007
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import errno
    import os

    class Mock(object):
        def __init__(self):
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []
            self.get_bin_path_success = True

        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            if len(self.run_command_rcs) < 1:
                raise Exception('ran out of canned rcs')
            if len(self.run_command_outs) < 1:
                raise Exception('ran out of canned outs')
            if len(self.run_command_errs) < 1:
                raise Exception('ran out of canned errs')
            rc = self.run_command_rcs.pop

# Generated at 2022-06-11 06:09:34.165893
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Setup
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, "something", ""))
    module.get_bin_path = Mock(return_value="/usr/bin/sysctl")
    # Execute
    tmp = VirtualSysctlDetectionMixin()
    tmp.module = module
    ret = tmp.detect_virt_product("somedummystring")
    # Assert
    # Check return value
    assert ret == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    # Check call count
    assert module.run_command.call_count == 1
    assert module.get_bin_path.call_count == 1



# Generated at 2022-06-11 06:09:39.905594
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule:
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return (0, 'KVM', '')

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    testobject = TestClass()
    third_part = testobject.detect_virt_product('hw.model')
    assert 'virtualization_type' in third_part
    assert 'virtualization_role' in third_part
    assert 'virtualization_tech' in third_part
    assert third_part['virtualization_type'] == 'kvm'
    assert third_part['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:09:47.140779
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def get_bin_path(self, *_):
            sysctl_path = '/sbin/sysctl'
            return sysctl_path

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'Intel(R) Xeon(R) CPU E5-2660 v3 @ 2.60GHz', None
            if cmd == '/sbin/sysctl -n hw.product':
                return 0, 'VirtualBox', None
            if cmd == '/sbin/sysctl -n kern.hostuuid':
                return 0, '00000000-0000-0000-0000-000000000000', None
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '0', None
            #

# Generated at 2022-06-11 06:09:56.782392
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.args = {}
        def get_bin_path(self, arg):
            return '/sbin/sysctl'
        def run_command(self, arg):
            if arg == '/sbin/sysctl -n kern.vm_guest':
                return 0, 'XenPV', ''
            if arg == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            raise AssertionError("Expected %s" % arg)

    module = TestModule()

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = module
    os_detection = TestVirtualSysctlDetection

# Generated at 2022-06-11 06:10:04.125654
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    fake_module = FakeModule()
    test_class = VirtualSysctlDetectionMixin()
    test_class.module = fake_module

    result = test_class.detect_virt_product('hw.model')
    assert result == {'virtualization_type': 'VMware',
                      'virtualization_role': 'guest',
                      'virtualization_tech_guest': set(['kvm', 'VMware']),
                      'virtualization_tech_host': set([])}


# Generated at 2022-06-11 06:10:12.577591
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Module(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = "/sbin/sysctl"
            self.module = self

        def run_command(self, cmd):
            return (0, 'QEMU', '')

    module = Module()
    virtual_facts = module.detect_virt_vendor(key='vm.product')

    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()

    virtual_facts_vmm = module.detect_virt_vendor(key='vm.vendor')


# Generated at 2022-06-11 06:10:23.617933
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'
            pass

    v = TestVirtualSysctlDetectionMixin()
    v.module = 'fake_module'

    # Test virtualbox
    class TestModuleArgs(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path
        def get_bin_path(self, name, *args, **kwargs):
            return self.bin_path
    class TestRunCommand(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

# Generated at 2022-06-11 06:10:28.188690
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    m.detect_sysctl = MagicMock()
    m.module = MagicMock()
    m.module.run_command.return_value = (0, 'QEMU', None)

    res = m.detect_virt_vendor('hw.product')
    assert 'kvm' in res['virtualization_type']
    assert 'guest' in res['virtualization_role']

# Generated at 2022-06-11 06:10:39.253071
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mod_args = dict(
        detect_virt=True
    )
    mod_inst = VirtualSysctlDetectionMixin()
    mod_inst.module = AnsibleModuleStub(**mod_args)
    mod_inst.detect_sysctl = lambda: setattr(mod_inst, 'sysctl_path', "/sbin/sysctl")
    sysctl_return_map = {
        "hw.model": "Bochs\n",
        "hw.machine": "x86_64",
        "hw.product": "VMware Virtual Platform\n",
        "hw.vendor": "Red Hat, Inc.\n",
        "hw.machine_arch": "amd64"
    }

# Generated at 2022-06-11 06:11:12.568277
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():  # pylint: disable=invalid-name
    sysctl_path = '/sbin/sysctl'
    module = FakeModule({'sysctl_path': sysctl_path})
    sut = VirtualSysctlDetectionMixin()
    sut.module = module
    sut.detect_sysctl()
    facts = sut.detect_virt_product('hw.model')
    assert 'virtualization_role' in facts
    assert facts['virtualization_role'] == 'guest'
    assert 'virtualization_type' in facts
    assert facts['virtualization_type'] == 'kvm'
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-11 06:11:19.304858
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtualsysctldetectionmixin = VirtualSysctlDetectionMixin()
    virtualsysctldetectionmixin.detect_virt_vendor('kern.vm_guest')
    virtualsysctldetectionmixin.detect_virt_product('hw.model')
    virtualsysctldetectionmixin.detect_virt_product('hw.product')
    virtualsysctldetectionmixin.detect_virt_product('hw.machine')
    virtualsysctldetectionmixin.detect_virt_product('kern.securelevel')
    virtualsysctldetectionmixin.detect_virt_product('kern.hostname')
    virtualsysctldetectionmixin.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-11 06:11:29.808298
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self._sysctl_path = None

    test_vendor_facts = TestVirtualSysctlDetectionMixin()
    vendor_facts = test_vendor_facts.detect_virt_vendor('hw.model')
    assert not vendor_facts

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self._sysctl_path = None

        def run_command(self, cmd):
            output = {
                'rc': 0,
                'out': 'Intel QEMU Virtual CPU version 2.0.0',
                'err': ''
            }


# Generated at 2022-06-11 06:11:39.229701
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from facts import facts
    import tempfile
    import os
    VirtSysctlDetection = facts.get_weak_nested_class(facts.OpenBSDFactCollector, 'VirtualSysctlDetectionMixin')
    test = VirtSysctlDetection()
    out = []
    out.append('KVM')
    out.append('Bochs')
    out.append('VMware')
    out.append('VirtualBox')
    out.append('Xen')
    out.append('Xen')
    out.append('Hyper-V')
    out.append('RHEV Hypervisor')
    out.append('Parallels')
    out.append('HVM domU')
    out.append('XenPVH')
    out.append('XenPVHVM')
    out.append('jail')
   

# Generated at 2022-06-11 06:11:47.961768
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        class RunCommand(object):
            def __init__(self, rc, out):
                self.rc = rc
                self.out = out

            def __call__(self, cmd):
                self.cmd = cmd
                return (self.rc, self.out, '')

    class Platform(object):
        def __init__(self, module):
            self.module = module

    class FreeBSDVirtDetection(VirtualSysctlDetectionMixin, Platform):
        def __init__(self, module):
            Platform.__init__(self, module)
            VirtualSysctlDetectionMixin.__init__(self)
            self.module = module
            self.sysctl_path = module.get_bin_path('sysctl')


# Generated at 2022-06-11 06:11:59.260187
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class RunModule:
        def __init__(self, module, cmd_result):
            self.module = module
            command_result = cmd_result

        def run_command(self, cmd):
            return self.command_result

    test_module = RunModule(None, (0, 'KVM', ''))
    virtual_sysctl_obj = VirtualSysctlDetectionMixin()
    virtual_sysctl_obj.module = test_module
    virtual_product_facts = virtual_sysctl_obj.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virtual_product_facts['virtualization_tech_guest']
    assert not virtual_product

# Generated at 2022-06-11 06:12:09.636951
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Create a fake module
    from ansible.module_utils.facts import ModuleBase

    class TestModule(ModuleBase):
        def __init__(self, args):
            self.facts = {}
            self.run_command = run_command

        def exit_json(self, **kwargs):
            return True

    # Create a fake ansible argument spec
    class FakeAnsibleArgSpec(object):
        def __init__(self):
            self.argument_spec = {}
            self.supports_check_mode = False

    def run_command(self, c):
        if c == 'sysctl -n kern.vm_guest':
            return 0, 'kvm', ''
        if c == 'sysctl -n security.jail.jailed':
            return 0, '1', ''

# Generated at 2022-06-11 06:12:17.317317
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import virt_facts
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    m_obj = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    v_obj = VirtualSysctlDetectionMixin()
    v_obj.detect_virt_product = lambda x: {'virtualization_type': x}
    v_obj.detect_sysctl = lambda: True
    v_obj.sysctl_path = "true"

    virt_facts.gather_virt_facts = lambda: {'virtual': {}}
    virt_facts.gather_virt_facts()


# Generated at 2022-06-11 06:12:27.630079
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils import basic
    import ansible
    # Mock ansible.module_utils.basic.AnsibleModule
    mock_module = basic.AnsibleModule(
        argument_spec = dict()
    )
    # Mock the sysctl binary
    mock_module.run_command.return_value = [0, 'KVM', '']
    detection = VirtualSysctlDetectionMixin()
    detection.module = mock_module
    result = detection.detect_virt_product('hw.model')
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'kvm'
    # Test Hyper-V
    mock_module.run_command.return_value = [0, 'Hyper-V', '']

# Generated at 2022-06-11 06:12:35.806573
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    sysctl_path = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files/sysctl')  # NOQA
    sysctl_mock = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'files/sysctl-mock')  # NOQA
    # test for kvm
    module = VirtualSysctlDetectionMixin()
    module.detect_sysctl = MagicMock(return_value=sysctl_path)
    module.run_command = MagicMock(return_value=(0, 'QEMU\n', ''))
    module.module = MagicMock()

# Generated at 2022-06-11 06:13:49.087872
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(argument_spec={'name': dict(type='str')})

    class FakeVirtualization(object):
        sysctl_path = "sysctl"

        def detect_sysctl(self):
            return True

    class FakeModule(object):
        def __init__(self):
            self.virtualization = Virtualization()

        def run_command(self, cmd, check_rc=True, close_fds=True,
                        executable=None, data=None, binary_data=False,
                        path_prefix=None, cwd=None, use_unsafe_shell=False):
            rc = 0

# Generated at 2022-06-11 06:13:54.656188
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_class = VirtualSysctlDetectionMixin()
    test_class.module = FakeModule()
    test_class.module.run_command = lambda x: (0, 'OpenBSD', '')
    result = test_class.detect_virt_vendor("not_a_real_key")
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-11 06:14:01.258368
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''Test method detect_virt_vendor of class VirtualSysctlDetectionMixin'''
    class VirtualSysctlModule(object):
        '''Fake module'''
        class FakeModule(VirtualSysctlDetectionMixin):
            def __init__(self):
                self.virtual_facts = {}

            def run_command(self, cmd):
                '''Fake run_command'''
                if cmd == 'sysctl -n hw.vendor':
                    return 0, 'OpenBSD', ''
                if cmd == 'sysctl -n kern.vm_guest':
                    return 0, 'OpenBSD', ''
                if cmd == 'sysctl -n hw.product':
                    return 0, 'QEMU', ''
                return 0, '', ''


# Generated at 2022-06-11 06:14:09.831082
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = VirtualSysctlDetectionMixin()
    module.module = type('module', (object,), {'get_bin_path': lambda x: x})
    module.module.run_command = lambda x: (0, 'VirtualBox', '')
    module.detect_sysctl = lambda: None
    result = module.detect_virt_product('hw.model')
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'virtualbox'
    assert 'virtualization_role' in result
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result


# Generated at 2022-06-11 06:14:18.599302
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    try:
        from __main__ import module
    except ImportError:
        from ansible.module_utils.facts_virtual.BSD.OpenBSD.sysctl import module
    module.sysctl_path = '/usr/sbin/sysctl'
    module.run_command = lambda x: (0, "QEMU", "")

    class Test:
        def __init__(self):
            self.module = module
    test = Test()
    test.detect_virt_vendor('kern.vm_guest')
    assert test.module.ansible_facts['virtualization_type'] == 'kvm'
    assert 'kvm' in test.module.ansible_facts['virtualization_tech_guest']
    assert test.module.ansible_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-11 06:14:28.734004
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    a = VirtualSysctlDetectionMixin()
    # Check that correct virtual org is found.
    a.module = {'run_command': lambda x: (0, 'QEMU', '')}
    results = a.detect_virt_vendor('security.jail.osrelease')
    assert results['virtualization_type'] == 'kvm'
    assert results['virtualization_role'] == 'guest'
    # Check that no virtual org is found.
    a.module = {'run_command': lambda x: (0, '', '')}
    results = a.detect_virt_vendor('security.jail.osrelease')
    assert len(results) == 2
    # Check that exception is handled.
    a.module = {'run_command': lambda x: (1, '', '')}
    results = a

# Generated at 2022-06-11 06:14:37.511035
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import OpenBSD_Hardware

    # OpenBSD_Hardware object instance
    openbsd_hardware = OpenBSD_Hardware()
    # Add method detect_virt_product to the instance
    openbsd_hardware.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product
    # Add variable sysctl_path to the instance
    openbsd_hardware.sysctl_path = '/sbin/sysctl'
    # Set of expected virtualization_tech_guest values
    kvm_virtualization_tech_guest = {'kvm'}
    vmware_virtualization_tech_guest = {'VMware'}
    virtualbox

# Generated at 2022-06-11 06:14:46.859275
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import os
    import inspect
    import sysctl
    class Module(object):
        def __init__(self):
            self.params = {'name': 'hw.model'}
            self.run_command_environ_update = {}
            self.run_command_checks = False

        def get_bin_path(self, arg, opt_dirs=[]):
            # since test should be executed from the same directory,
            # ./lib/ansible/module_utils/facts/system/ is the current path
            return './sysctl'


# Generated at 2022-06-11 06:14:58.011920
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin
    v = VirtualSysctlDetectionMixin()
    v.sysctl_path='/sbin/sysctl'
    v.module.run_command = lambda x: (0, 'QEMU', '')
    assert v.detect_virt_vendor('hw.model') == {'virtualization_role': 'guest',
                                                'virtualization_type': 'kvm',
                                                'virtualization_tech_guest': {'kvm'},
                                                'virtualization_tech_host': set()}

    v.module.run_command = lambda x: (0, 'OpenBSD', '')

# Generated at 2022-06-11 06:15:04.252000
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    a = VirtualSysctlDetectionMixin()
    a.module = FakeModule()
    ret = a.detect_virt_vendor('machdep.hypervisor_vendor')
    assert(ret['virtualization_role']=='guest')
    assert(ret['virtualization_type']=='kvm')
    assert(ret['virtualization_tech_host']==set([]))
    assert(ret['virtualization_tech_guest']==set(['kvm']))


# Generated at 2022-06-11 06:17:17.121506
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.sysctl_path = True
    mixin.module = MockModule()
    mixin.module.run_command.return_value = (0, 'QEMU', '')
    result = mixin.detect_virt_vendor('machdep.hypervisor_name')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    mixin.module.run_command.assert_called_once_with('/usr/bin/sysctl -n machdep.hypervisor_name')


# Generated at 2022-06-11 06:17:25.326463
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Trying to detect kvm
    sysctl_mock = MagicMock()
    sysctl_mock.return_value = '/usr/sbin/sysctl'
    module = MagicMock(name='AnsibleModule')
    module.get_bin_path.side_effect = sysctl_mock
    module.run_command.return_value = (0, 'KVM', '')

    o = VirtualSysctlDetectionMixin()
    o.module = module

    virtual_product_facts = o.detect_virt_product('hw.model')

    assert virtual_product_facts == {
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'}