

# Generated at 2022-06-25 01:28:48.121429
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = "hw.model"
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert virtual_vendor_facts == { 'virtualization_tech_guest': set(['vmm']), 'virtualization_tech_host': set(), 'virtualization_type': 'vmm', 'virtualization_role': 'guest' }


# Generated at 2022-06-25 01:28:51.523194
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:28:54.698513
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert None == virtual_sysctl_detection_mixin_0.detect_virt_product(key='security.jail.jailed')


# Generated at 2022-06-25 01:28:58.326931
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:29:06.200643
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = None
    assert {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()} == virtual_sysctl_detection_mixin.detect_virt_product(key)
    key = 'hw.model'
    assert {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set()} == virtual_sysctl_detection_mixin.detect_virt_product(key)


# Generated at 2022-06-25 01:29:07.103007
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_case_0()

# Generated at 2022-06-25 01:29:08.557694
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # TODO: write test code
    return True



# Generated at 2022-06-25 01:29:10.456407
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Tests avoid method calls
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:29:15.432342
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    result_0 = set()
    result_0.add('kvm')
    result_0.add('vmm')
    result_1 = dict()
    result_1['virtualization_role'] = 'guest'
    result_1['virtualization_type'] = 'kvm'
    result_2 = set()
    result_2.add('kvm')
    result_2.add('vmm')
    result_3 = dict()
    result_3['virtualization_tech_guest'] = result_2
    result_3['virtualization_tech_host'] = result_0
    result_3['virtualization_role'] = 'guest'
    result_3['virtualization_type'] = 'kvm'
   

# Generated at 2022-06-25 01:29:17.810252
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('Virtual product')


# Generated at 2022-06-25 01:29:29.807049
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:29:36.203025
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    virtual_sysctl_detection_mixin.module = 'module'
    virtual_sysctl_detection_mixin.sysctl_path = 'sysctl_path'

    virtual_sysctl_detection_mixin.detect_virt_vendor('product')

    assert virtual_sysctl_detection_mixin.detect_virt_vendor('product') == {}



# Generated at 2022-06-25 01:29:45.212474
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = object()
    class subprocess(object):
        class Popen(object):
            def __init__(self, args, stdout, stderr):
                self.returncode = 0
                pass
            def communicate(self):
                return (None, None)
    virtual_sysctl_detection_mixin.subprocess = subprocess
    virtual_sysctl_detection_mixin.module.run_command = subprocess.Popen
    virtual_sysctl_detection_mixin.sysctl_path = "dummy"
    res = virtual_sysctl_detection_mixin.detect_virt_product('hw')

# Generated at 2022-06-25 01:29:52.943150
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    assert (virtual_sysctl_detection_mixin_0.detect_virt_vendor('security.jail.jailed') == {'virtualization_type': 'jails',
                                                                                            'virtualization_role': 'guest',
                                                                                            'virtualization_tech_guest': {'jails'},
                                                                                            'virtualization_tech_host': set()}
                                                                                           ), "Invalid output from detect_virt_vendor()"


# Generated at 2022-06-25 01:30:00.812000
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None
    class FakeModule:
        class FakeCommandResult:
            def __init__(self):
                self.rc = 0
                self.stdout = None
                self.stderr = None
        def get_bin_path(self, path):
            return path
        def run_command(self, cmd):
            return FakeModule.FakeCommandResult()
    class FakeAtsInfo:
        def __init__(self):
            self.sysctl_path = '/'
    fake_ats_info = FakeAtsInfo()
    fake_module = FakeModule()
    actual_result = virtual_sysctl_detection_mixin.detect_virt_product

# Generated at 2022-06-25 01:30:11.252773
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock(return_value=None)

    rc, out, err = virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n security.jail.jailed')

    if out.rstrip() == '1':
        key = 'security.jail.jailed'
    elif out.rstrip() == '0':
        key = 'machdep.hypervisor'

    out = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)

# Generated at 2022-06-25 01:30:14.229167
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('dev.xen.info.capabilities')


# Generated at 2022-06-25 01:30:25.232440
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = FakeAnsibleModule(version_control=True,
                                                                virtualization_enabled=True,
                                                                virtualization_type=['kvm'])
    virtual_sysctl_detection_mixin_1.sysctl_path = '/usr/sbin/sysctl'
    virtual_sysctl_detection_mixin_1.module.run_command = FakeAnsibleModuleRunCommand(rc=0, stdout='QEMU\n')
    virtual_sysctl_detection_mixin_1.virtualization_type = ['kvm']

# Generated at 2022-06-25 01:30:29.143138
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:30:39.142410
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_case_0()
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = StubModule()
    virtual_sysctl_detection_mixin_1.module.run_command = lambda *args: (0, 'QEMU', '')
    virtual_sysctl_detection_mixin_1.sysctl_path = '/usr/sbin/sysctl'
    virtual_sysctl_detection_mixin_1.detect_virt_vendor('machdep.cpu.brand_string')


# Generated at 2022-06-25 01:31:06.520228
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_sysctl = lambda: None
    virtual_sysctl_detection_mixin_1.module = MockAnsibleModule()
    virtual_sysctl_detection_mixin_1.module.run_command = module_run_command

# Generated at 2022-06-25 01:31:12.372731
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.module.get_bin_path = MagicMock(return_value='/bin/sysctl')
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0, 'XenPVHVM', ''))
    virtual_sysctl_detection_mixin_0.detect_virt_product(key='security.jail.jailed')



# Generated at 2022-06-25 01:31:16.052007
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = None # This is magic, we will force a module to be used
    virtual_sysctl_detection_mixin_0.detect_sysctl = lambda: None
    virtual_sysctl_detection_mixin_0.module.run_command = lambda cmd: (0, 'QEMU', '')
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:31:23.939222
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    # We don't need to do much here, since it uses sysctl, and the amd64
    # platform we're running on doesn't have the right sysctl
    assert virtual_sysctl_detection_mixin_1.detect_virt_vendor('machdep.cpu.vendor') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': None, 'virtualization_role': None}


# Generated at 2022-06-25 01:31:34.056580
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = MockModule()
    virtual_sysctl_detection_mixin_1.module.get_bin_path = MockGetBinPath()
    virtual_sysctl_detection_mixin_1.run_command = MockRunCommand()
    virtual_sysctl_detection_mixin_1.module.run_command = virtual_sysctl_detection_mixin_1.run_command
    virtual_sysctl_detection_mixin_1.virtual_facts = {}
    virtual_sysctl_detection_mixin_1.sysctl_path = "/sbin/sysctl"
    key = 'hw.model'

# Generated at 2022-06-25 01:31:42.222198
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_obj = VirtualSysctlDetectionMixin()
    rc, out, err = test_obj.module.run_command("echo 'KVM paravirtualized domain'")
    if rc == 0:
        test_obj.module.params = {'sysctl_path': 'sysctl', 'key': 'machdep.cpu.features'}
        test_obj.detect_virt_product('machdep.cpu.features')
    elif rc == 1:
        test_obj.module.params = {'sysctl_path': 'sysctl', 'key': 'machdep.cpu.features'}
        test_obj.detect_virt_product('machdep.cpu.features')
        assert 1 == 1


# Generated at 2022-06-25 01:31:50.152472
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    # Detects vendor for sysctl vm.vmm_version
    virtual_sysctl_detection_mixin.detect_virt_vendor = lambda key: {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    assert virtual_sysctl_detection_mixin.detect_virt_vendor('vm.vmm_version') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Detects vendor for sysctl vm.vmm_version
    virtual_sysctl_detection_mixin.detect_virt_vendor = lambda key: {'virtualization_type': 'vmm', 'virtualization_role': 'guest'}
    assert virtual_

# Generated at 2022-06-25 01:31:56.125380
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    class ModuleStub:
        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'
    class RunCommandStub:
        def __init__(self):
            self.rc = 0
            self.out = ''
            self.err = ''
        def run_command(self, arg):
            return self.rc, self.out, self.err
    module_stub = ModuleStub()
    run_command_stub = RunCommandStub()

    run_command_stub.out = 'BochsJail\n'

# Generated at 2022-06-25 01:31:58.983230
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    res = virtual_sysctl_detection_mixin.detect_virt_product(key)
    assert res['virtualization_tech_guest'] == set()
    assert res['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:32:05.724079
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor(key) == {'virtualization_tech_guest': set(),
                                                                        'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:32:54.220109
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    # We will only test this with a valid key to test if we get the proper
    # dictionaries as output
    result = virtual_sysctl_detection_mixin_1.detect_virt_product('kern.vm_guest')

    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == {'kvm'}
    assert result['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:32:58.214614
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    VirtualSysctlDetectionMixin_instance = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virt_product = 'hw.model'
    return_value = VirtualSysctlDetectionMixin_instance.detect_virt_product(virt_product)
    assert return_value == None


# Generated at 2022-06-25 01:33:00.939161
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.sysctl_path = '/usr/bin/sysctl'

    key = 'machdep.hypervisor_vendor'
    virtual_vendor_facts = virtual_sysctl_detection_mixin.detect_virt_vendor(key)
    assert isinstance(virtual_vendor_facts, dict)
    assert virtual_vendor_facts == {}


# Generated at 2022-06-25 01:33:11.009955
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """
    Test detect_virt_vendor
    """
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.vmm_name')
    assert(virtual_sysctl_detection_mixin_0.virtualization_type == 'kvm')
    assert(virtual_sysctl_detection_mixin_0.virtualization_role == 'guest')
    assert(virtual_sysctl_detection_mixin_0.virtualization_tech_guest == 'kvm')
    assert(virtual_sysctl_detection_mixin_0.virtualization_tech_host == set())


# Generated at 2022-06-25 01:33:13.649021
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:33:20.043359
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Test without setting module.run_command
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0, 'vmware', ''))
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock(return_value='')
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('') == {}
    # Test without setting module.run_command
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

# Generated at 2022-06-25 01:33:22.229912
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor("16")


# Generated at 2022-06-25 01:33:31.803176
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = Mock()
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = "/bin/sysctl"
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = (0, 'VMware', '')
    virtual_sysctl_detection_mixin_0.detect_sysctl = Mock()
    virtual_sysctl_detection_mixin_0.detect_sysctl.return_value = None

    key = "hw.product"

    expected_return = {'virtualization_type': 'VMware', 'virtualization_role': 'guest'}
    return_value

# Generated at 2022-06-25 01:33:40.285698
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = type('aModuleType', (object,), {"run_command": detect_virt_product_0})
    virtual_sysctl_detection_mixin.detect_virt_product('machdep.hypervisor')
    assert "machdep.hypervisor" == virtual_sysctl_detection_mixin.module.params.get('key','')
    assert "return_code" == virtual_sysctl_detection_mixin.module.rc
    assert "stdout" == virtual_sysctl_detection_mixin.module.out

# Generated at 2022-06-25 01:33:47.454336
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock(name='AnsibleModule')
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(name='run_command')
    virtual_sysctl_detection_mixin_0.module.get_bin_path = MagicMock(name='get_bin_path')
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = '/usr/sbin/sysctl'
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = (0, '', '')

    result = virtual_sysctl_detection_mixin_

# Generated at 2022-06-25 01:35:44.208021
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.sysctl_path = '/sbin/sysctl'
    virtual_sysctl_detection_mixin.module = MockModule()
    virtual_sysctl_detection_mixin.module.run_command.return_value = (0, "VirtualBox", "abc")
    key = 'hw.model'
    expected = {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['virtualbox']),
        'virtualization_tech_host': set()
    }
    assert expected == virtual_sysctl_detection_mixin.detect_virt_product(key)


# Generated at 2022-06-25 01:35:46.917766
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('kern.vm_guest')
    virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed')


# Generated at 2022-06-25 01:35:50.943326
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.hypervisor_vendor') == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.hypervisor_name') == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}


# Generated at 2022-06-25 01:35:54.902268
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_product('hw.model') == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': None, 'virtualization_tech_guest': None}
    assert virtual_sysctl_detection_mixin_1.detect_virt_product('security.jail.jailed') == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_host': None, 'virtualization_tech_guest': None}


# Generated at 2022-06-25 01:35:58.172108
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = '__OpenBSD_version'
    virtual_sysctl_detection_mixin_detect_virt_vendor = virtual_sysctl_detection_mixin.detect_virt_vendor(key)


# Generated at 2022-06-25 01:36:02.818069
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'machdep.cpu.features'
    test_case_0.detect_sysctl()
    rc, out, err = virtual_sysctl_detection_mixin_0.module.run_command('%s -n %s' % (virtual_sysctl_detection_mixin_0.sysctl_path, key))
    if rc == 0:
        if re.match('(KVM|kvm|Bochs|SmartDC).*', out):
            assert 'kvm' in virtual_sysctl_detection_mixin_0.detect_virt_product(key)['virtualization_tech_guest']

# Generated at 2022-06-25 01:36:10.032936
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, path):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            rc = 0
            out = 'hw.model: VirtualBox'
            err = ''
            return rc, out, err
    virtual_sysctl_detection_mixin_detect_virt_product = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_detect_virt_product.module = TestModule()
    virtual_sysctl_detection_mixin_detect_virt_product.fact_name = 'virtual_sysctl'
    virtual_sysctl_detection_mixin_detect_virt_product.fact_subsets = 'all'
    virtual

# Generated at 2022-06-25 01:36:16.796620
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    key = 'machdep.hypervisor'
    return_value = virtual_sysctl_detection_mixin_1.detect_virt_vendor(key)
    assert return_value == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': {
            'kvm'
        },
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 01:36:22.916009
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_virt_product('machdep.hypervisor')
    assert(virtual_sysctl_detection_mixin_1.virtual_product_facts == {})


# Generated at 2022-06-25 01:36:27.873525
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_sysctl = lambda: __detect_sysctl()
    virtual_sysctl_detection_mixin_1.module = __create_test_module({'run_command': lambda *args: __test_run_command('test_case_2', *args)})
    ret = virtual_sysctl_detection_mixin_1.detect_virt_product('hw.model')
    assert(ret == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()
    })

# Unit test