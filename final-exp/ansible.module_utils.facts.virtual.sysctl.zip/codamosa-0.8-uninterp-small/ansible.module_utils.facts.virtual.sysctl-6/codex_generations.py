

# Generated at 2022-06-25 01:28:48.305531
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None

    virtual_sysctl_detection_mixin.module = MockModule()
    virtual_sysctl_detection_mixin.module.run_command.return_value = (0, 'OpenBSD', '')

    assert virtual_sysctl_detection_mixin.detect_virt_vendor('') == {
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
    }


# Generated at 2022-06-25 01:28:51.342333
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_vendor(key='hw.model') == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}


# Generated at 2022-06-25 01:28:54.864024
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    out = virtual_sysctl_detection_mixin_0.detect_virt_vendor('vm.vmm.vendor')
    assert (out == {})


# Generated at 2022-06-25 01:29:00.167389
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:29:09.793935
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()

    virtual_sysctl_detection_mixin_1.module = AnsibleModuleMock(dict(
        get_bin_path=AnsibleModuleMock(return_value='/sbin/sysctl'),
        run_command=AnsibleModuleMock(return_value=(0, 'VirtualBox', '')),
        ))
    virtual_sysctl_detection_mixin_1.detect_sysctl()
    virtual_product_facts = virtual_sysctl_detection_mixin_1.detect_virt_product(key='hw.model')
    virtual_product_facts = virtual_product_facts.get('virtualization_role')
    assert virtual_product_facts == 'guest'



# Generated at 2022-06-25 01:29:14.891514
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    object_0 = {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_role': None}
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest') == \
        object_0


# Generated at 2022-06-25 01:29:20.433628
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.sysctl_path = "/path/to/sysctl"
    virtual_sysctl_detection_mixin.module = MockModule()
    virtual_sysctl_detection_mixin.detect_virt_vendor("machdep.hypervisor_vendor")
    assert virtual_sysctl_detection_mixin.sysctl_path == "/path/to/sysctl"


# Generated at 2022-06-25 01:29:24.518394
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_product('security.jail.jailed') == {'virtualization_type': 'jails', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'jails'}, 'virtualization_tech_host': set()}



# Generated at 2022-06-25 01:29:34.884941
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = MagicMock(return_value=True)
    virtual_sysctl_detection_mixin.module.get_bin_path = MagicMock(return_value=True)
    virtual_sysctl_detection_mixin.module.run_command = MagicMock(return_value=(0, 'kvm', ''))
    virtual_sysctl_detection_mixin.sysctl_path = True

    key = 'kvm'
    data = virtual_sysctl_detection_mixin.detect_virt_product(key)

    assert data != {}, data
    assert virtual_sysctl_detection_mixin.sysctl_path is not None, data


# Generated at 2022-06-25 01:29:39.516766
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    ret_val_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('kern.vm_guest')
    assert isinstance(ret_val_0, dict)
    assert ret_val_0 == {}


# Generated at 2022-06-25 01:30:00.331327
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    key_1 = 'hw.product'
    virtual_sysctl_detection_mixin_1.detect_virt_vendor(key_1)


# Generated at 2022-06-25 01:30:05.658926
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('vm.vmtotal')


# Generated at 2022-06-25 01:30:12.425830
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    key = 'machdep.vmm_guest'
    virtual_vendor_facts = virtual_sysctl_detection_mixin_1.detect_virt_vendor(key)
    if 'virtualization_type' in virtual_vendor_facts:
        # Test passed - expected result == actual result
        print('virtual_vendor_facts[virtualization_type] = %s' % (virtual_vendor_facts['virtualization_type']))
    else:
        # Test failed - expected result != actual result
        print('virtual_vendor_facts[virtualization_type] = %s' % (virtual_vendor_facts['virtualization_type']))

# Generated at 2022-06-25 01:30:17.698401
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert {'virtualization_tech_guest': set(), 'virtualization_type': None, 'virtualization_tech_host': set(), 'virtualization_role': None} == virtual_sysctl_detection_mixin_0.detect_virt_vendor('dev.vmm.0.%desc')


# Generated at 2022-06-25 01:30:26.477130
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()

    # Test with valid values
    result = virtual_sysctl_detection_mixin_1.detect_virt_product('hw.model')
    assert result == {'virtualization_tech_guest': {'kvm', 'xen', 'parallels', 'jails', 'virtualbox', 'RHEV'}, 'virtualization_tech_host': set(), 'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Test with valid values
    result = virtual_sysctl_detection_mixin_1.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-25 01:30:29.873407
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    assert not virtual_sysctl_detection_mixin_0.detect_virt_vendor("hw.model")

# Generated at 2022-06-25 01:30:38.682022
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_sysctl = lambda : True
    virtual_sysctl_detection_mixin_1.sysctl_path = '/sysctl'
    virtual_sysctl_detection_mixin_1.run_command = os.system
    virtual_sysctl_detection_mixin_1.detect_virt_product('i can be any key')


# Generated at 2022-06-25 01:30:42.022387
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = None
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    virtual_sysctl_detection_mixin_0.set_defaults = None
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor('security.jail.jailed') == {'virtualization_tech_guest': {'jails'}, 'virtualization_type': 'jails', 'virtualization_tech_host': set(), 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:30:44.304697
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('') == {}


# Generated at 2022-06-25 01:30:55.098265
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    # test1: if sysctl path is not defined and the method runs, it returns None
    # test2: if sysctl path is None and the method runs, it returns None
    # test3: if sysctl path is defined and the method runs, it returns a dict
    # test4: if sysctl path is defined and the method runs, it returns a dict
    if hasattr(virtual_sysctl_detection_mixin, 'sysctl_path'):
        if virtual_sysctl_detection_mixin.sysctl_path:
            virtual_sysctl_detection_mixin.sysctl_path = None
            virtual_vendor_facts_test1 = virtual_sysctl_detection_mixin.detect

# Generated at 2022-06-25 01:31:40.189396
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:31:49.222773
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = 'sysctl_path'

    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0,"vmware",""))
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    virtual_sysctl_detection_mixin_0.module.run_command.assert_called_with('sysctl_path -n hw.model')

    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock

# Generated at 2022-06-25 01:31:53.508747
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    res = virtual_sysctl_detection_mixin_0.detect_virt_product('')
    assert 'virtualization_tech_guest' in res
    assert 'virtualization_tech_host' in res
    assert 'virtualization_type' in res
    assert 'virtualization_role' in res
    assert 'virtualization_type' in res['virtualization_tech_guest']


# Generated at 2022-06-25 01:31:58.902578
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None
    virtual_sysctl_detection_mixin.module = None
    virtual_sysctl_detection_mixin.detect_virt_product('machdep.hypervisor')


# Generated at 2022-06-25 01:32:04.187073
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_2 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_2.detect_virt_product('hw.model')


# Generated at 2022-06-25 01:32:13.511835
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    rc, out, err = virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n hw.product')
    if rc == 0:
        assert out.rstrip() == 'OpenBSD', '%s != %s' % (out.rstrip(), 'OpenBSD')
    rc, out, err = virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n hw.vendor')
    if rc == 0:
        assert out.rstrip() == 'QEMU', '%s != %s' % (out.rstrip(), 'QEMU')


# Generated at 2022-06-25 01:32:16.456052
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_vendor_facts_1 = virtual_sysctl_detection_mixin_1.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts_1 == {}


# Generated at 2022-06-25 01:32:23.778047
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'machdep.hypervisor_vendor'
    assert len(virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)) == 2


# Generated at 2022-06-25 01:32:27.421779
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    assert 'virtualization_type' in mixin.detect_virt_product(
        'hw.model')['virtualization_type']
    assert 'virtualization_role' in mixin.detect_virt_product(
        'hw.model')['virtualization_role']
    assert 'virtualization_tech_guest' in mixin.detect_virt_product(
        'hw.model')['virtualization_tech_guest']
    assert 'virtualization_tech_host' in mixin.detect_virt_product(
        'hw.model')['virtualization_tech_host']


# Generated at 2022-06-25 01:32:28.802764
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:34:11.735000
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.sysctl_path = None
    mixin.detect_virt_vendor("hw.vmm.vm_guest")
    assert mixin.sysctl_path

# Generated at 2022-06-25 01:34:15.414828
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    virtual_sysctl_detection_mixin_0.detect_virt_product(key)


# Generated at 2022-06-25 01:34:19.641420
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = "sysctl"
    virtual_sysctl_detection_mixin_0.module = object()
    virtual_sysctl_detection_mixin_0.module.run_command = Mock(return_value=(0, 'kvm', ''))
    result = virtual_sysctl_detection_mixin_0.detect_virt_vendor('dev.cpu.1.brand')
    if result['virtualization_type'] != 'kvm':
        raise Exception()


# Generated at 2022-06-25 01:34:21.555629
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:34:23.615476
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert(virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model') == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set(),
    })


# Generated at 2022-06-25 01:34:33.896107
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert('virtualization_tech_guest' in virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.hypervisor_vendor'))
    assert('virtualization_type' in virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.hypervisor_vendor'))
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert('virtualization_tech_guest' in virtual_sysctl_detection_mixin_1.detect_virt_vendor('machdep.hypervisor_vendor'))

# Generated at 2022-06-25 01:34:43.326792
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None
    virtual_sysctl_detection_mixin.module = MockModule()

    virtual_sysctl_detection_mixin.module.run_command.return_value = (0, 'QEMU', '')
    result = virtual_sysctl_detection_mixin.detect_virt_product('machdep.hypervisor')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in result
    assert len(result['virtualization_tech_guest']) == 1

# Generated at 2022-06-25 01:34:47.722539
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module.run_command = run_command
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:34:54.237514
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.virtual_sysctl_detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor
    key = 'machdep.hypervisor_vendor'
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.virtual_sysctl_detect_virt_vendor(key)
    assert virtual_vendor_facts == {'virtualization_tech_host': set(), 'virtualization_tech_guest': {'vmm'}}


# Generated at 2022-06-25 01:34:59.369911
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = ansible_module_0
    virtual_sysctl_detection_mixin_0.detect_sysctl = test_detect_sysctl_0
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    assert virtual_sysctl_detection_mixin_0.sysctl_path == 'sysctl'
