

# Generated at 2022-06-25 01:28:49.996369
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # Test for key: 'hw.model'
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    # Test for key: 'machdep.cpu.brand_string'
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.cpu.brand_string')
    # Test for key: 'machdep.cpu.features'
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.cpu.features')
    # Test for key: 'machdep.cpu.leaf7_features'
    virtual_sysctl_detection_mixin_0.detect_virt_v

# Generated at 2022-06-25 01:28:53.908958
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    product_facts_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.hypervisor')
    assert 'virtualization_type' in product_facts_0.keys()
    assert "virtualization_role" in product_facts_0.keys()
    assert "virtualization_tech_guest" in product_facts_0.keys()
    assert "virtualization_tech_host" in product_facts_0.keys()


# Generated at 2022-06-25 01:28:57.079253
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert(virtual_sysctl_detection_mixin_0.detect_virt_product(0) == 0)


# Generated at 2022-06-25 01:29:08.141748
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # Test using command line argument
    virtual_sysctl_detection_mixin_0.module = AnsibleModule(
        argument_spec = dict(
            key = dict(type='str'),
        ),
        supports_check_mode=True
    )
    virtual_sysctl_detection_mixin_0.module.params['key'] = 'hw.model';
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    virtual_product_facts = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    assert 'virtualization_role' in virtual_product_facts
    assert 'virtualization_type' in virtual_product_facts

# Generated at 2022-06-25 01:29:10.436325
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor("kern.host.hostname") is not None


# Generated at 2022-06-25 01:29:13.624691
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.vm_guest')


# Generated at 2022-06-25 01:29:21.485415
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = mock.Mock()
    virtual_sysctl_detection_mixin_1.module.run_command = mock.Mock(side_effect=[(0, 'KVM', ''), (0, 'VirtualBox', ''), (0, 'Hyper-V', ''), (0, 'Parallels', ''), (0, 'RHEV Hypervisor', ''), (1, '', '')])
    virtual_sysctl_detection_mixin_1.detect_sysctl = mock.Mock()
    
    virtual_sysctl_detection_mixin_1.detect_sysctl()

# Generated at 2022-06-25 01:29:26.687292
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.sysctl_path = '/sbin/sysctl'

    key = 'hw.product'
    virtual_product_facts = virtual_sysctl_detection_mixin_1.detect_virt_product(key)
    assert virtual_product_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_product_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:29:32.042910
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    print('Running unit test method detect_virt_product of class VirtualSysctlDetectionMixin')
    print('- - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -')

    virtual_sysctl_detection_mixin_0.detect_sysctl = lambda : None
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.module.get_bin_path = MagicMock('/usr/bin/sysctl')

# Generated at 2022-06-25 01:29:40.551816
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    # Test with expected value
    assert(virtual_sysctl_detection_mixin_0.detect_virt_vendor(key='hw.model') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()})

    # Test with expected value
    assert(virtual_sysctl_detection_mixin_0.detect_virt_vendor(key='hw.machine') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()})


# Generated at 2022-06-25 01:30:00.516460
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('') == {}


# Generated at 2022-06-25 01:30:10.677897
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts == {}

    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_vendor_facts = virtual_sysctl_detection_mixin_1.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts == {}
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:30:16.595288
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    result_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.hypervisor')
    assert result_0['virtualization_tech_guest'] == {'parallels', 'virtualbox', 'xen', 'kvm'}, \
        "Failed to return the expected result for method detect_virt_product"


# Generated at 2022-06-25 01:30:19.577169
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor("hw.model")
    assert virtual_vendor_facts == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set(), 'virtualization_type': None, 'virtualization_role': None}


# Generated at 2022-06-25 01:30:29.957996
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = None
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    key = 'hw.model'
    # Test with return values from method detect_sysctl so we test method detect_sysctl is called
    # and return values as expected
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock(return_value=(None, 'OpenBSD', None))
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0, 'KVM', None))

    return_value = virtual_sysctl_detection_mixin_0.detect_virt_

# Generated at 2022-06-25 01:30:41.097440
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    params = {'virtualization_type': dict(), 'virtualization_role': dict(),
              'virtualization_tech_guest': dict(), 'virtualization_tech_host': dict()}
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: True
    virtual_sysctl_detection_mixin.sysctl_path = '/bin/sysctl'
    virtual_sysctl_detection_mixin.module = dict()
    virtual_sysctl_detection_mixin.module.run_command = lambda cmd: (0, 'QEMU', '')
    result = virtual_sysctl_detection_mixin.detect_virt_vendor('hw.model')
    assert result == params


# Generated at 2022-06-25 01:30:43.684089
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key_0 = 'hw.model'
    virtual_sysctl_detection_mixin_0.detect_virt_product(key_0)


# Generated at 2022-06-25 01:30:51.300032
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert 'virtualization_tech_guest' in result
    assert 'virtualization_tech_host' in result


# Generated at 2022-06-25 01:30:57.471692
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = Mock(return_value=None)
    virtual_sysctl_detection_mixin_0.module = Mock()
    virtual_sysctl_detection_mixin_0.module.run_command = Mock(return_value=(0, 'VirtualBox', ''))
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.hypervisor') == {'virtualization_type': 'virtualbox', 'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': {'virtualbox'}}


# Generated at 2022-06-25 01:31:03.200208
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    # Test cases for detect_virt_product
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed')


# Generated at 2022-06-25 01:31:51.609334
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_vendor('product') == {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:32:00.388567
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = test_case_0
    ret_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    if ret_0 != {'virtualization_role': 'guest',
                 'virtualization_type': 'kvm',
                 'virtualization_tech_host': set(),
                 'virtualization_tech_guest': {'kvm'}}:
        raise Exception("fail: %s" % ret_0)



# Generated at 2022-06-25 01:32:02.982053
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:32:04.807385
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:32:07.139982
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    result = VirtualSysctlDetectionMixin().detect_virt_vendor()
    assert result == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}

# Generated at 2022-06-25 01:32:14.429554
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    key_1 = "kern.vm_guest"
    virtual_sysctl_detection_mixin_1.detect_sysctl = lambda : True
    virtual_sysctl_detection_mixin_1.module.run_command = lambda x: (0, "KVM", "")
    result_1 = virtual_sysctl_detection_mixin_1.detect_virt_product(key_1)
    assert result_1['virtualization_role'] == 'guest'
    assert result_1['virtualization_type'] == 'kvm'
    assert result_1['virtualization_tech_host'] == set()
    assert result_1['virtualization_tech_guest'] == set(['kvm'])


# Generated at 2022-06-25 01:32:20.267229
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    class module_0:
        class ModuleError(Exception):
            pass
        get_bin_path = lambda *args, **kwargs: '/usr/bin/sysctl'
        run_command = lambda *args, **kwargs: (0, 'QEMU', '')
    setattr(virtual_sysctl_detection_mixin_0, 'module', module_0())
    virtual_vendor_facts_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key='hw.model')
    assert virtual_vendor_facts_0['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts_0['virtualization_role'] == 'guest'
    assert virtual

# Generated at 2022-06-25 01:32:23.197979
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:32:31.297889
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin_0.detect_virt_product("machdep.hypervisor_name")
    assert result == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-25 01:32:31.927858
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    assert test_case_0()


# Generated at 2022-06-25 01:34:16.675053
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert \
        virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.vmm.name') == \
        {'virtualization_role': 'guest',
         'virtualization_tech_guest': set(['vmm']),
         'virtualization_tech_host': set(),
         'virtualization_type': 'vmm'}


# Generated at 2022-06-25 01:34:26.220879
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mock_module = MagicMock()
    mock_module.run_command.return_value = (0, "OpenBSD", None)
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = mock_module
    virtual_sysctl_detection_mixin.sysctl_path = "sysctl"

    assert virtual_sysctl_detection_mixin.detect_virt_vendor(key="vm.vmm.vendor") == {'virtualization_tech_guest': {'vmm'}, 'virtualization_role': 'guest', 'virtualization_type': 'vmm', 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:34:34.355346
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = AnsibleModuleStub()
    virtual_sysctl_detection_mixin_0.module.run_command = AnsibleRunCommandStub()
    virtual_sysctl_detection_mixin_0.module.run_command.add_cmd(cmd_type="shell", rc=0, stdout='KVM', stderr='')
    virtual_sysctl_detection_mixin_0.detect_sysctl = AnsibleModuleStub()

    virtual_sysctl_detection_mixin_0.detect_sysctl.get_bin_path = AnsibleModuleStub()
    virtual_sysctl_detection_mixin_0.detect_sys

# Generated at 2022-06-25 01:34:43.345541
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = {}
    virtual_sysctl_detection_mixin_0.module = {}
    virtual_sysctl_detection_mixin_0.module.run_command = {}
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = { 'rc': 0, 'out': 'QEMU', 'err': 'Mock_Err' }
    expected_result = { 'virtualization_tech_host': set(), 'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']) }
    result = virtual_sysctl_detection_

# Generated at 2022-06-25 01:34:45.203629
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = 'security.jail.jailed'
    ret = virtual_sysctl_detection_mixin.detect_virt_vendor(key)
    assert isinstance(ret, dict) == True


# Generated at 2022-06-25 01:34:49.160260
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dummy_module = DummyAnsibleModule()

    dummy_sysctl_path = 'dummy_sysctl_path'
    dummy_key = 'dummy_key'
    dummy_rc = 0
    dummy_out_1 = 'dummy_out_1'
    dummy_out_2 = 'dummy_out_2'
    dummy_out_3 = 'dummy_out_3'
    dummy_out_4 = 'dummy_out_4'
    dummy_out_5 = 'dummy_out_5'
    dummy_out_6 = 'dummy_out_6'
    dummy_out_7 = 'dummy_out_7'
    dummy_out_8 = 'dummy_out_8'
    dummy_out_9 = 'dummy_out_9'
    dummy_out_

# Generated at 2022-06-25 01:34:53.228097
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = AnsibleModuleMock()
    virtual_sysctl_detection_mixin.module.run_command = lambda x: (0, 'KVM/Linux', '')
    virtual_sysctl_detection_mixin.detect_virt_product('hw.vmm.vm') == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:34:58.086435
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed')


# Generated at 2022-06-25 01:35:04.129726
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    distro = 'Ubuntu'
    virtual_sysctl_detection_mixin_0.module.params['gather_subset'] = ['all']
    virtual_sysctl_detection_mixin_0.module.params['gather_timeout'] = 5
    virtual_sysctl_detection_mixin_0.module.params['filter'] = '*'
    virtual_sysctl_detection_mixin_0.module.params['verbosity'] = 0
    key = 'hw.product'

    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert virtual_vendor_facts['virtualization_type'] == 'kvm' or virtual_

# Generated at 2022-06-25 01:35:08.410721
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # it will fail without sysctl_path
    try:
        virtual_sysctl_detection_mixin_0.detect_virt_product(None)
    except:
        pass
