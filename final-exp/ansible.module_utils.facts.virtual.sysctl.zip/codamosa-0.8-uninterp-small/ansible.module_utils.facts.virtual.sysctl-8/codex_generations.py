

# Generated at 2022-06-25 01:28:50.590503
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Create a some values for testing
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = 'machdep.hypervisor_vendor'
    result = virtual_sysctl_detection_mixin.detect_virt_vendor(key)

    assert result['virtualization_tech_guest'] == 'kvm'
    assert result['virtualization_tech_host'] == 'kvm'

# Generated at 2022-06-25 01:28:58.482877
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model') == {
        'virtualization_tech_guest': set(['kvm', 'vmware', 'virtualbox', 'xen', 'hyper-v', 'parallels', 'rhev', 'jails']),
        'virtualization_tech_host': set([]),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }


# Generated at 2022-06-25 01:29:03.254928
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    return_value = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert return_value is None


# Generated at 2022-06-25 01:29:12.800036
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()

    virtual_vendor_facts = {'virtualization_role': 'guest', 'virtualization_type': 'kvm'}
    assert virtual_vendor_facts == virtual_sysctl_detection_mixin_1.detect_virt_vendor('machdep.hypervisor_vendor')

    virtual_vendor_facts = {'virtualization_role': 'guest', 'virtualization_type': 'vmm'}
    assert virtual_vendor_facts == virtual_sysctl_detection_mixin_1.detect_virt_vendor('machdep.hypervisor_vendor')

# Generated at 2022-06-25 01:29:19.476144
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    # any type will do as long as no exception is raised
    try:
        virtual_sysctl_detection_mixin_0.detect_virt_product(None)
    except Exception:
        fail_test("Exception raised while calling detect_virt_product(None)")


# Generated at 2022-06-25 01:29:27.663256
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0, '\n', ''))
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')


# Generated at 2022-06-25 01:29:31.782985
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product("security.jail.jailed")


# Generated at 2022-06-25 01:29:41.544502
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # Test using the class variable sysctl_path
    virtual_sysctl_detection_mixin_0.sysctl_path = u'/sbin/sysctl'
    virtual_sysctl_detection_mixin_0.module = MockAnsibleModule(
        sysctl_path=u'/sbin/sysctl')

    virtual_virt_product_facts_0 = {'virtualization_type': 'Hyper-V', 'virtualization_role': 'guest'}

# Generated at 2022-06-25 01:29:44.290461
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')


# Generated at 2022-06-25 01:29:50.989218
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.guest')


# Generated at 2022-06-25 01:30:13.762924
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_detect_virt_product_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_detect_virt_product_0.detect_virt_product('debug.kdb.enter_kernel')


# Generated at 2022-06-25 01:30:21.602264
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # We emulate the sysctl command by passing a string
    # This result is from a VM running OpenBSD from https://www.openbsd.org/
    path = "OpenBSD"
    # We emulate the sysctl command by passing a string
    # key = security.jail.jailed
    key = "security.jail.jailed"
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert(virtual_vendor_facts['virtualization_type'] == "vmm")
    assert(virtual_vendor_facts['virtualization_role'] == "guest")

# Generated at 2022-06-25 01:30:31.984174
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    # Testcase 0
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    # Testcase 1
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()

    # Testcase 2
    virtual_sysctl_detection_mixin_2 = VirtualSysctlDetectionMixin()

    # Testcase 3
    virtual_sysctl_detection_mixin_3 = VirtualSysctlDetectionMixin()

    # Testcase 4
    virtual_sysctl_detection_mixin_4 = VirtualSysctlDetectionMixin()

    # Testcase 5
    virtual_sysctl_detection_mixin_5 = VirtualSysctlDetectionMixin()

    # Testcase 6
    virtual_sysctl_detection_mixin_6 = VirtualSysctlDetection

# Generated at 2022-06-25 01:30:35.488611
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    mock_key_0 = 'mock key'
    expected_result = {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['kvm'])}
    actual_result = virtual_sysctl_detection_mixin_0.detect_virt_vendor(mock_key_0)
    assert expected_result  == actual_result


# Generated at 2022-06-25 01:30:42.817005
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = 'sysctl'
    virtual_sysctl_detection_mixin_0.module = AnsibleModule(argument_spec={})
    virtual_sysctl_detection_mixin_0.module.run_command = mock.MagicMock(return_value=(0, 'KVM', ''))
    x = virtual_sysctl_detection_mixin_0.detect_virt_product('product')

# Generated at 2022-06-25 01:30:47.928015
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert callable(getattr(virtual_sysctl_detection_mixin_0, "detect_virt_vendor", None))


# Generated at 2022-06-25 01:30:55.826369
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock, Mock

    class TestVirtualSysctlDetectionMixinDetectVirtVendor(unittest.TestCase):
        def setUp(self):
            self.sysctl_path_mock = MagicMock()
            self.module_mock = MagicMock()
            self.module_mock.run_command.return_value = (0, 'test_return', '')

            self.test_class = VirtualSysctlDetectionMixin()
            self.test_class.sysctl_path = self.sysctl_path_mock
            self.test_class.module = self

# Generated at 2022-06-25 01:31:05.555944
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = None
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    # Detection code should work even if sysctl is not installed and we should get empty result
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('fake.key')
    # Detection code should be able to detect jail/jails
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('security.jail.jailed')


# Generated at 2022-06-25 01:31:09.501414
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_fact_vendor_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_fact_vendor_0.detect_virt_vendor(key='kern.vm_guest')


# Generated at 2022-06-25 01:31:12.687468
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    # Input parameters for function detect_virt_product
    key = 'machdep.hypervisor_vendor'
    # Output from function detect_virt_product
    output = {}
    output = virtual_sysctl_detection_mixin_1.detect_virt_product(key)
    return output


# Generated at 2022-06-25 01:31:48.562535
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    int_0 = 1726
    # Run against "kern.vm_guest"
    assert virtual_sysctl_detection_mixin_0.detect_virt_product(int_0) == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([])
    }

    # Run against "security.jail.jailed"
    int_0 = 6223

# Generated at 2022-06-25 01:31:52.093087
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = 'sysctl'
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)


# Generated at 2022-06-25 01:32:00.110936
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module_0 = 854
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(module_0)
    assert(isinstance(var_0, dict))
    assert('virtualization_tech_host' in var_0)
    assert('virtualization_tech_guest' in var_0)
    assert('virtualization_type' in var_0)
    assert('virtualization_role' in var_0)


# Generated at 2022-06-25 01:32:04.916441
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 485
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)



# Generated at 2022-06-25 01:32:08.419372
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 761
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-25 01:32:11.948380
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 0
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:32:18.678621
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(1726)
    assert var_0['virtualization_type'] == 'kvm'
    assert var_0['virtualization_role'] == 'guest'
    assert list(var_0['virtualization_tech_host']) == []
    assert list(var_0['virtualization_tech_guest']) == ['kvm', 'virtualbox', 'hyper-v', 'rhev', 'parallels']


# Generated at 2022-06-25 01:32:23.708963
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1667
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)

# Generated at 2022-06-25 01:32:26.404164
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 'security.jail.jailed'
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = Mock()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)
    assert not var_0['virtualization_tech_guest']
    assert not var_0['virtualization_tech_host']

# Generated at 2022-06-25 01:32:28.661938
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(var_0)

# Generated at 2022-06-25 01:33:18.582481
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    int_15 = 1726
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product(int_15)


# Generated at 2022-06-25 01:33:25.388319
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1624
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:33:31.191585
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    int_0 = 1726;
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)



# Generated at 2022-06-25 01:33:36.587096
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # No additional parameters
    int_0 = 1527
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:33:41.141220
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)

if __name__ == "__main__":
    #import sys;sys.argv = ['', 'Test.testName']
    test_case_0()
    #test_VirtualSysctlDetectionMixin_detect_virt_product()

# Generated at 2022-06-25 01:33:45.005571
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1631
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:33:47.312612
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)
    assert (len(var_0) == 3)


# Generated at 2022-06-25 01:33:50.155315
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1725
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)
    assert var_0['virtualization_type'] == 'kvm'


# Generated at 2022-06-25 01:33:53.437140
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)
    print(var_0)


# Generated at 2022-06-25 01:33:55.748516
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:35:39.369749
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)
    assert var_0['virtualization_role'] == 'guest'
    assert var_0['virtualization_type'] == 'kvm'


# Generated at 2022-06-25 01:35:41.971229
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 440
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:35:44.550597
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)



# Generated at 2022-06-25 01:35:53.421877
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    print("<html><body><h2>Test Case :: test_VirtualSysctlDetectionMixin_detect_virt_product of class VirtualSysctlDetectionMixin</h2><hr /><br />")
    print('<table border="1"><tr><th>Input Parameter</th><th>Expected Output</th><th>Actual Output</th></tr>')


# Generated at 2022-06-25 01:35:57.338856
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    int_0 = 1726
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)


# Generated at 2022-06-25 01:35:59.126686
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)


# Generated at 2022-06-25 01:36:00.923059
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)


# Generated at 2022-06-25 01:36:02.681267
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0)


# Generated at 2022-06-25 01:36:07.394345
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    int_0 = 1726
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor(int_0) == virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)


# Generated at 2022-06-25 01:36:10.777348
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    int_0 = 1598
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(int_0)
