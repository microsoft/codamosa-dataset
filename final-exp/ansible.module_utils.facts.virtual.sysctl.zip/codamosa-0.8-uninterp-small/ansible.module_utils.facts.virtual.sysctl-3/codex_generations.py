

# Generated at 2022-06-25 01:28:52.890885
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin_1.detect_virt_vendor()
    assert virtual_sysctl_detection_mixin_1.sysctl_path is None
    assert result == {}
    result = virtual_sysctl_detection_mixin_1.detect_virt_vendor(key="machdep.hypervisor")
    assert result == {'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([]),
                      'virtualization_role': 'guest', 'virtualization_type': 'kvm'}

# Generated at 2022-06-25 01:28:55.451625
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_product('machdep.hypervisor_name') == {'virtualization_tech_host': set(), 'virtualization_role': 'guest', 'virtualization_type': 'VMware', 'virtualization_tech_guest': set(['VMware'])}


# Generated at 2022-06-25 01:28:59.723848
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.sysctl_path = ''
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock()
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock()
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = 0, "OpenBSD", ""

# Generated at 2022-06-25 01:29:04.861553
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virt_product_key = 'hw.model'
    virt_product = virtual_sysctl_detection_mixin_1.detect_virt_product(virt_product_key)
    assert virt_product['virtualization_type'] == 'kvm'


# Generated at 2022-06-25 01:29:09.416915
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    test_module_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    test_module_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.machine')



# Generated at 2022-06-25 01:29:14.556542
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:29:16.419597
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # TODO: Implement test


# Generated at 2022-06-25 01:29:23.937239
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    return_value = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert return_value['virtualization_tech_guest'] == set([])
    assert return_value['virtualization_tech_host'] == set([])
    assert return_value['virtualization_type'] == None
    assert return_value['virtualization_role'] == None
    virtual_sysctl_detection_mixin_0.sysctl_path = 'overwrite_sysctl_path'
    key = 'hw.model'
    return_value = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)

# Generated at 2022-06-25 01:29:26.090710
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:29:28.238025
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = None
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor(key) == 0


# Generated at 2022-06-25 01:29:52.974654
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    key = "hw.vmm.system_type"
    virtual_sysctl_detection_mixin.sysctl_path = "/sbin/sysctl"
    out = "QEMU"
    virtual_sysctl_detection_mixin.module = MockModule(out, "QEMU")
    virtual_sysctl_detection_mixin_detect_virt_vendor_result = virtual_sysctl_detection_mixin.detect_virt_vendor(key)

# Generated at 2022-06-25 01:29:57.291035
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    print("\n*** Test_VirtualSysctlDetectionMixin_detect_virt_vendor ***")
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    key = "machdep.dmi.system-product"
    output = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    print(output)


# Generated at 2022-06-25 01:29:58.406775
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # this requires a host to run on.
    return NotImplemented


# Generated at 2022-06-25 01:30:03.051349
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.dmi.vendor') == {'virtualization_type': 'vmm',
                                                                                          'virtualization_role': 'guest',
                                                                                          'virtualization_tech_guest': {'vmm'},
                                                                                          'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:30:11.900357
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    host_tech = set()
    guest_tech = set()
    guest_tech.add('kvm')
    virtual_vendor_facts = {}
    virtual_vendor_facts['virtualization_tech_guest'] = guest_tech
    virtual_vendor_facts['virtualization_tech_host'] = host_tech
    virtual_vendor_facts['virtualization_role'] = 'guest'
    virtual_vendor_facts['virtualization_type'] = 'kvm'
    virtual_vendor_facts_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.vendor')
    assert virtual_vendor_facts == virtual_vendor_facts_1


# Generated at 2022-06-25 01:30:16.790846
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_product_facts = virtual_sysctl_detection_mixin_1.detect_virt_product('machdep.hypervisor')
    assert virtual_product_facts == {}


# Generated at 2022-06-25 01:30:26.039678
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.sysctl_path = "/usr/local/bin/sysctl"
    key = "hw.model"
    out = "OpenBSD"

    # Define a "run_command" method in the "AnsibleModule" object so that AnsibleModule.run_command is able to run
    class AnsibleModule:
        class RunCommandMock():
            def __init__(self, module_1, command_0, check_rc_0):
                self.rc = 0
                self.__test_out = out
                self.__test_err = ""

            def communicate(self):
                return self.__test_out, self.__test_err


# Generated at 2022-06-25 01:30:34.950532
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    assert result == {'virtualization_tech_guest': set([u'kvm']), 'virtualization_tech_host': set([]), 'virtualization_type': u'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:30:38.825894
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest')


# Generated at 2022-06-25 01:30:43.862104
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Mod:
        class Run:
            RC = 0
            stdout = 'KVM'
            stderr = ''

    mod = Mod()
    virtual_sysctl_detection_mixin_x = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_x.module = mod
    virtual_sysctl_detection_mixin_x.sysctl_path = 'sysctl'
    result = virtual_sysctl_detection_mixin_x.detect_virt_product('machdep.cpu.features')

    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-25 01:31:11.360184
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_product(key="security.jail.jailed")
    assert var_1 == {'virtualization_tech_guest': set(['jails']), 'virtualization_tech_host': set(), 'virtualization_type': 'jails', 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:31:13.717725
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.product')
    assert isinstance(var_0, dict)


# Generated at 2022-06-25 01:31:16.851617
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('vm.guest')


# Generated at 2022-06-25 01:31:23.451943
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest')

test_VirtualSysctlDetectionMixin_detect_virt_vendor()


# Generated at 2022-06-25 01:31:29.947924
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    str_0 = ""
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(**str_0)


# Generated at 2022-06-25 01:31:35.204877
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1['virtualization_type'] = 'kvm'
    dict_1['virtualization_role'] = 'guest'
    dict_0['virtual_product_facts'] = dict_1
    dict_2['virtualization_type'] = 'kvm'
    dict_2['virtualization_role'] = 'guest'
    dict_0['virtual_vendor_facts'] = dict_2
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_sysctl()

# Generated at 2022-06-25 01:31:44.508970
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {'a':False, 'b':'bar', 'c':'baz'}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    virtual_sysctl_detection_mixin_0.sysctl_path = 'mvjt'
    virtual_sysctl_detection_mixin_0.module = Mock()
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = (0, 'QEMU', '')
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('foo')

# Generated at 2022-06-25 01:31:48.170356
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product("hw.model")


# Generated at 2022-06-25 01:31:52.904797
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Setup for test
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_1 = None
    var_2 = None

    # calling method
    var_3 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(var_1)

    # testing for expected behavior

    # testing for expected behavior
    assert var_3 == var_2
    assert var_3 is not var_2


# Generated at 2022-06-25 01:31:59.199633
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {'virtualization_type': 'jails', 'virtualization_role': 'guest'}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('security.jail.jailed')


# Generated at 2022-06-25 01:32:36.376799
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    pass


# Generated at 2022-06-25 01:32:45.723830
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key = 'hw.vmm.vm_guest')
    assert var_0 == {'virtualization_tech_guest': set([u'vmm', u'kvm']), 'virtualization_tech_host': set([]), 'virtualization_role': u'guest', 'virtualization_type': u'vmm'}

# Generated at 2022-06-25 01:32:53.010968
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    str_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest')
    list_0 = str_0.keys()
    int_0 = len(list_0)
    assert int_0 == 3


# Generated at 2022-06-25 01:32:55.237188
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_1 = {}
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin(**dict_1)
    var_0 = virtual_sysctl_detection_mixin_1.detect_virt_vendor("hw.vmm.name")



# Generated at 2022-06-25 01:32:58.025412
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    test_case_0()


# Generated at 2022-06-25 01:33:03.248414
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor("security.jail.jailed") == {}
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor("hw.model") == {}


# Generated at 2022-06-25 01:33:11.731615
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("emulation.osrelease")
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("emulation.version")
    var_2 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("emulation.sysname")
    var_3 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("emulation.osrelease")
    var_4 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("emulation.version")
   

# Generated at 2022-06-25 01:33:15.123071
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product("hw.model")


# Generated at 2022-06-25 01:33:17.796102
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('')


# Generated at 2022-06-25 01:33:26.384988
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.vmm.vendor') == {
        'virtualization_tech_guest': set(['vmm']),
        'virtualization_tech_host': set(['vmm']),
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest'
    }


# Generated at 2022-06-25 01:35:25.952130
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    # Tests for KeyError
    if 'key_error_0' in dict_0:
        virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
        var_1 = virtual_sysctl_detection_mixin_0.detect_virt_product('key_error_0')
    # Tests for TypeError
    try:
        virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin(**dict_0)
        var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product(var_1)
    except TypeError:
        pass
    else:
        raise AssertionError()


# Generated at 2022-06-25 01:35:34.659374
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    virtual_sysctl_detection_mixin_0.sysctl_path = 'sysctl_path_1'
    var_1 = set()
    var_2 = set()
    dict_1 = {}
    dict_1['virtualization_tech_guest'] = var_1
    dict_1['virtualization_tech_host'] = var_2
    dict_1['virtualization_role'] = 'guest'
    dict_1['virtualization_type'] = 'kvm'
    var_3 = dict_1
    dict_1['virtualization_tech_guest'] = var_1
    dict_1['virtualization_tech_host'] = var_2
    dict

# Generated at 2022-06-25 01:35:38.180166
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = 'hw.model'
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_product(var_0)


# Generated at 2022-06-25 01:35:41.344649
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product()


# Generated at 2022-06-25 01:35:44.263074
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed')


# Generated at 2022-06-25 01:35:50.576486
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {'module': None}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(None)


# Generated at 2022-06-25 01:35:52.707435
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.vm_guest')


# Generated at 2022-06-25 01:36:02.739743
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_sysctl()
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    assert var_1 == {'virtualization_role': 'guest', 'virtualization_tech_guest': {}, 'virtualization_tech_host': {}, 'virtualization_type': None}
    var_2 = virtual_sysctl_detection_mixin_0.detect_virt_product('machdep.xcputype')

# Generated at 2022-06-25 01:36:03.312329
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    assert True


# Generated at 2022-06-25 01:36:08.307311
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    dict_0 = {}
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin(**dict_0)
    var_0 = virtual_sysctl_detection_mixin_0.detect_sysctl()
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.hypervisor')
