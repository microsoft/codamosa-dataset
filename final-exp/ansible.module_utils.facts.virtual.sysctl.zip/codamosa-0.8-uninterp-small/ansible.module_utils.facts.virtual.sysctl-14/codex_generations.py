

# Generated at 2022-06-25 01:28:44.086401
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    pass


# Generated at 2022-06-25 01:28:48.533645
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert virtual_vendor_facts['virtualization_type'] == 'kvm' 


# Generated at 2022-06-25 01:28:54.864204
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    hw_vendor_keys = ['vm.vmm.vendor', 'hw.vmm.vm_guest']
    for key in hw_vendor_keys:
        # testing in linux platform
        virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
        virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)


# Generated at 2022-06-25 01:29:05.626711
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = mock.MagicMock()
    virtual_sysctl_detection_mixin_0.module.run_command = mock.MagicMock(return_value=(0, 'KVM', ''))
    virtual_sysctl_detection_mixin_0.sysctl_path = '/path/to/sysctl'
    virtual_sysctl_detection_mixin_0.detect_virt_product('vm.name')
    expected_virtual_product_facts = {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['kvm'])}

# Generated at 2022-06-25 01:29:09.068906
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin.detect_virt_vendor('machdep.bios.vendor')
    assert result == {}


# Generated at 2022-06-25 01:29:17.699258
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = 'sysctl'
    virtual_sysctl_detection_mixin_0.module = None
    virtual_sysctl_detection_mixin_0.module.run_command = module_run_command
    virtual_sysctl_detection_mixin_0.module.get_bin_path = None
    key = 'hw.model'
    res = virtual_sysctl_detection_mixin_0.detect_virt_product(key)
    assert len(res) == 2
    assert res.get('virtualization_type') == 'xen'
    assert res.get('virtualization_role') == 'guest'



# Generated at 2022-06-25 01:29:20.318885
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor("kern.vm_guest")


# Generated at 2022-06-25 01:29:25.160361
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product("machdep.hypervisor")



# Generated at 2022-06-25 01:29:35.789964
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    args = dict(key='hw.model', sysctl_path='sysctl')
    # Note: setting sysctl_path is not required,
    # but it is included to show how a setter method works
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_sysctl = lambda: virtual_sysctl_detection_mixin_1.__dict__.update(dict(sysctl_path=args['sysctl_path']))
    rc, out, err = virtual_sysctl_detection_mixin_1.module.run_command(args['sysctl_path'] + ' -n ' + args['key'])

# Generated at 2022-06-25 01:29:38.106430
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:29:51.167704
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product(key='hw.model')


# Generated at 2022-06-25 01:29:57.937183
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Instantiate VirtualSysctlDetectionMixin
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    var = virtual_sysctl_detection_mixin.detect_virt_product('kern.vm_guest')
    assert var['virtualization_tech_guest'] == set(('kvm', 'xen'))


# Generated at 2022-06-25 01:30:02.561197
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('vm.vmtotal')
    assert "virtualization_type" in var_0
    assert var_0["virtualization_type"] == "RHEV"
    assert "virtualization_role" in var_0
    assert var_0["virtualization_role"] == "guest"


# Generated at 2022-06-25 01:30:04.394047
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    print()
    virtual_sysctl_detection_mixin_2 = VirtualSysctlDetectionMixin()
    var_2 = virtual_sysctl_detection_mixin_2.detect_sysctl()
    var_3 = virtual_sysctl_detection_mixin_2.detect_virt_product('machdep.hypervisor')


# Generated at 2022-06-25 01:30:09.345941
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = lambda: None

    var = virtual_sysctl_detection_mixin.detect_virt_product('security.jail.jailed')
    assert var == {'virtualization_tech_guest': set(['jails']), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:30:15.037099
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    assert mixin.detect_virt_vendor("kern.vm_guest") == {'virtualization_tech_guest': set(['vmm']), 'virtualization_tech_host': set(), 'virtualization_type': 'vmm', 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:30:20.799547
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    str_1 = 'hw.model'
    var_0 = virtual_sysctl_detection_mixin_1.detect_virt_vendor(str_1)


# Generated at 2022-06-25 01:30:28.104617
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()

    # Test with false key
    virtual_sysctl_detection_mixin_1.detect_virt_product(key = "")
    assert(virtual_sysctl_detection_mixin_1.detect_virt_product(key = "false_key") == {})
    assert(virtual_sysctl_detection_mixin_1.detect_virt_product(key = "") == {})


# Generated at 2022-06-25 01:30:33.040317
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("/123")
    assert var_0 == {}


# Generated at 2022-06-25 01:30:39.487288
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key='hw.model')
    assert var_0 == {'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set(), 'virtualization_type': 'vmm', 'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:31:05.083175
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock()
    var_0 = virtual_sysctl_detection_mixin_0.detect_sysctl()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_product('virtual')

    assert var_1 == {}


# Generated at 2022-06-25 01:31:09.471337
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product('kern.hostuuid')


# Generated at 2022-06-25 01:31:12.234574
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_0.detect_sysctl()
    var_2 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')


# Generated at 2022-06-25 01:31:16.360399
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product()


# Generated at 2022-06-25 01:31:24.839483
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_0.detect_sysctl()
    key = 'hw.product'
    var_2 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    assert var_2['virtualization_tech_guest'] == set(['vmm', 'kvm'])
    assert 'virtualization_type' in var_2
    assert 'virtualization_role' in var_2
    assert var_2['virtualization_tech_host'] == set()


# Generated at 2022-06-25 01:31:30.258067
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_test_case_0 = VirtualSysctlDetectionMixin()
    arg_0 = 'vm.kvm_guest_support'
    var_0 = virtual_sysctl_detection_mixin_test_case_0.detect_virt_product(arg_0)


# Generated at 2022-06-25 01:31:32.249731
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')


# Generated at 2022-06-25 01:31:35.965290
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    print("Testing detect_virt_vendor")
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    test_case_0()


# Generated at 2022-06-25 01:31:40.741100
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = 'hw.model'
    result = virtual_sysctl_detection_mixin_0.detect_virt_product(var_1)


# Generated at 2022-06-25 01:31:42.409198
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product()


# Generated at 2022-06-25 01:32:19.914649
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.product')


# Generated at 2022-06-25 01:32:25.819801
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.sysctl_path = "sysctl_path"

    expected_result = {}
    expected_result['virtualization_tech_guest'] = set()
    expected_result['virtualization_tech_host'] = set()

    result = virtual_sysctl_detection_mixin.detect_virt_vendor(None)

    assertEqual(result, expected_result)


# Generated at 2022-06-25 01:32:28.365390
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.product')


# Generated at 2022-06-25 01:32:33.583961
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    module = AnsibleModule(argument_spec={
        'test_name': dict(required=True, type='str'),
        'key': dict(required=True, type='str')
    })
    key = module.params['key']
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(key)


# Generated at 2022-06-25 01:32:41.948878
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    arg_0 = "machdep.emulated_guest"
    var_0 = virtual_sysctl_detection_mixin_1.detect_virt_vendor(arg_0)
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    arg_0 = "machdep.emulated_guest"
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_vendor(arg_0)


# Generated at 2022-06-25 01:32:44.710868
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    return_value = virtual_sysctl_detection_mixin_0.detect_virt_vendor('machdep.hypervisor_vendor')
    assert return_value == {}


# Generated at 2022-06-25 01:32:54.454811
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Run unit test
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = mock_module
    key = "hw.model"
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(key)
    assert var_0['virtualization_type'] == 'unknown'
    assert var_0['virtualization_role'] == 'unknown'
    assert len(var_0['virtualization_tech_guest']) == 0
    assert len(var_0['virtualization_tech_host']) == 0


# Generated at 2022-06-25 01:32:58.191041
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_1.detect_sysctl()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product("kern.vm_guest")


# Generated at 2022-06-25 01:33:02.823020
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    global virtual_sysctl_detection_mixin_0
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    global var_0
    var_0 = 'hv_vendor_id'
    virtual_sysctl_detection_mixin_0.detect_virt_product(var_0)



# Generated at 2022-06-25 01:33:04.778348
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product('hw.vmm.vm_guest')


# Generated at 2022-06-25 01:35:03.546754
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # set up test case
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()

    # execute test method
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    rc, out, err = virtual_sysctl_detection_mixin_0.module.run_command("%s -n hw.model" % virtual_sysctl_detection_mixin_0.sysctl_path)
    if rc == 0:
        if re.match('(KVM|kvm|Bochs|SmartDC).*', out):
            var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product("hw.model")

# Generated at 2022-06-25 01:35:07.877399
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_vendor("hw.vmm.version")


# Generated at 2022-06-25 01:35:13.277342
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("hw.model")


# Generated at 2022-06-25 01:35:19.414626
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product()


# Generated at 2022-06-25 01:35:24.032012
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_2 = virtual_sysctl_detection_mixin_1.detect_virt_product('security.jail.jailed')
    assert 'virtualization_role' in var_2.keys()


# Generated at 2022-06-25 01:35:30.192440
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = None
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('kern.hostuuid')
    assert var_1['virtualization_tech_host'] == set()
    assert var_1['virtualization_tech_guest'] == set()
    assert virtual_sysctl_detection_mixin_0.sysctl_path == None


# Generated at 2022-06-25 01:35:35.887880
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    var = virtual_sysctl_detection_mixin.detect_virt_product(key = 'kern.vm_guest')


# Generated at 2022-06-25 01:35:43.584768
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("security.jail.jailed")
    assert var_1 == {'virtualization_tech_guest': {'jails'}, 'virtualization_tech_host': set(), 'virtualization_role': 'guest', 'virtualization_type': 'jails'}
    var_2 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("hw.model")
    assert var_2 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

test_VirtualSysctlDetectionMixin_detect_virt_vendor()

# Generated at 2022-06-25 01:35:51.476942
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_0.detect_virt_vendor('hw.model')
    assert('virtualization_role' in var_1)
    assert('virtualization_tech_host' in var_1)
    assert('virtualization_tech_guest' in var_1)
    assert('virtualization_type' in var_1)


# Generated at 2022-06-25 01:35:57.187979
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor("kern.vm_guest")
    assert var_0['virtualization_tech_guest'] == 'kvm'
    assert var_0['virtualization_tech_host'] == set()

