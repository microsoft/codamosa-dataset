

# Generated at 2022-06-25 01:28:49.924554
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock()
    virtual_sysctl_detection_mixin_0.detect_sysctl.return_value = 'sysctl_path'
    virtual_sysctl_detection_mixin_0.module = ansible.module_utils.basic.AnsibleModule()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock()
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = (0, 'rc', 'stdout', 'stderr')

# Generated at 2022-06-25 01:28:55.341915
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = SLUFAKE_MODULE_INSTANCE
    test_key = 'hw.model'
    result = virtual_sysctl_detection_mixin_0.detect_virt_product(test_key)
    # assert all checks, class values populated here
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_tech_guest'] == set()
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-25 01:29:01.722839
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Initialize class object
    virtual_sysctl_detection_mixin_obj = VirtualSysctlDetectionMixin()

    # Assign input data
    key = 'kern.vm_guest'

    # Invoke method to be tested
    result = virtual_sysctl_detection_mixin_obj.detect_virt_product(key)
    print('Result of detect_virt_product: ', result)


# Generated at 2022-06-25 01:29:10.756123
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = 'sysctl'
    virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n kern.vm_guest')
    virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n kern.vm_guest')
    virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n kern.vm_guest')
    virtual_sysctl_detection_mixin_0.module.run_command('sysctl -n kern.vm_guest')

# Generated at 2022-06-25 01:29:18.894309
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = MockAnsibleModule(argument_spec={})
    virtual_sysctl_detection_mixin_1.module.run_command = Mock(return_value=(0, "QEMU", ""))
    virtual_sysctl_detection_mixin_1.detect_sysctl = Mock()
    assert virtual_sysctl_detection_mixin_1.detect_virt_vendor('hw.model') == {'virtualization_tech_guest': {'kvm'}, 'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:29:21.171947
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor('')


# Generated at 2022-06-25 01:29:27.838836
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.sysctl_path = ''
    virtual_sysctl_detection_mixin_0.module = "MockModule"
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = '/sbin/sysctl'
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = (0, 'KVM', '')
    virtual_sysctl_detection_mixin_0.detect_virt_product('hw.model')
    virtual_sysctl_detection_mixin_0.detect_virt_product('')


# Generated at 2022-06-25 01:29:30.326985
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()


# Generated at 2022-06-25 01:29:33.773482
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_vendor(None)


# Generated at 2022-06-25 01:29:36.147140
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_virt_product('hw.model')

# Generated at 2022-06-25 01:30:02.035906
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module.get_bin_path = MagicMock(name='get_bin_path')
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = '/usr/sbin/sysctl'
    key = 'machdep.hypervisor'
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock(name='detect_sysctl')
    virtual_sysctl_detection_mixin_0.run_command = MagicMock(name='run_command')

# Generated at 2022-06-25 01:30:11.829263
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0._AnsibleModule__init__(argument_spec=dict(), supports_check_mode=False)
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock()
    virtual_sysctl_detection_mixin_0.detect_sysctl()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock()
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = '', 0, ''
    virtual_sysctl_detection_mixin_0.detect_virt_product(key='')


# Generated at 2022-06-25 01:30:17.908197
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_1.detect_virt_product('hw.model') == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_host': set(), 'virtualization_tech_guest': set(['kvm'])}


# Generated at 2022-06-25 01:30:23.561157
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    output = virtual_sysctl_detection_mixin_0.detect_virt_vendor(arg0=...)
    # The returned value is of type dictionary
    assert isinstance(output, dict)


# Generated at 2022-06-25 01:30:25.330127
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_virt_product('hw.model')


# Generated at 2022-06-25 01:30:31.917209
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    # Test default value
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor(key="hw.model") == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}



# Generated at 2022-06-25 01:30:33.706897
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()



# Generated at 2022-06-25 01:30:41.125117
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # arrange
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = "hw.model"
    # act
    result = virtual_sysctl_detection_mixin_0.detect_virt_product(key)
    # assert
    assert result == {'virtualization_tech_guest': set(['kvm', 'VMware', 'virtualbox', 'xen', 'Hyper-V', 'parallels', 'RHEV', 'jails']), 'virtualization_tech_host': set([]), 'virtualization_role': 'guest', 'virtualization_type': 'kvm'}

# Generated at 2022-06-25 01:30:44.304439
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_product('security.jail.jailed') == {"virtualization_tech_guest": set(), "virtualization_tech_host": set()}


# Generated at 2022-06-25 01:30:51.035732
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key = 'hw.model'
    assert virtual_sysctl_detection_mixin_0.detect_virt_product(key) == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-25 01:31:43.063578
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MagicMock()
    virtual_sysctl_detection_mixin_0.module.get_bin_path.return_value = 'path_to_bin/bin_file'
    key = 'key'

    # Stub out return values of @virtual_sysctl_detection_mixin_0.module.run_command
    virtual_sysctl_detection_mixin_0.module.run_command.return_value = [0, 'KVM', '']
    virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)
    virtual_sysctl_detection_mixin_0.module.run_command.assert_called_

# Generated at 2022-06-25 01:31:50.579045
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    sysctl_path = '/sbin/sysctl'
    out = 'KVM'
    rc = 0
    testcase = VirtualSysctlDetectionMixin()
    testcase.detect_sysctl = lambda: None
    testcase.module = lambda: None
    testcase.module.run_command = lambda x, foo: (rc, out, "")
    testcase.sysctl_path = sysctl_path

    # Case 0: rc == 0
    assert testcase.detect_virt_product('hw.model') == {
        'virtualization_tech_guest': {'kvm'},
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set()
    }



# Generated at 2022-06-25 01:31:57.788822
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_0.detect_virt_vendor(key="") is None


# Generated at 2022-06-25 01:32:06.504365
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = MagicMock(return_value=None)
    assert virtual_sysctl_detection_mixin_0.detect_virt_product("machdep.hypervisor") == {}
    assert virtual_sysctl_detection_mixin_0.detect_sysctl.call_count == 1


# Generated at 2022-06-25 01:32:10.386524
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = lambda : None
    result = virtual_sysctl_detection_mixin_0.detect_virt_product(key='vm.vmtotal')
    assert virtual_sysctl_detection_mixin_0.sysctl_path == None


# Generated at 2022-06-25 01:32:18.078269
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.module = 'module_0'
    virtual_sysctl_detection_mixin_1.module.get_bin_path = 'get_bin_path_0'
    virtual_sysctl_detection_mixin_1.module.run_command = 'run_command_0'
    virtual_sysctl_detection_mixin_1.detect_sysctl()
    virtual_sysctl_detection_mixin_1.detect_virt_product('key_0')


# Generated at 2022-06-25 01:32:26.231947
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_sysctl = lambda: True
    virtual_sysctl_detection_mixin_0.module = lambda: True
    virtual_sysctl_detection_mixin_0.module.run_command = lambda x, y: (
        0, 'KVM', '')

    assert virtual_sysctl_detection_mixin_0.detect_virt_product(
        'hw.product') == {'virtualization_tech_host': set(),
                          'virtualization_tech_guest': {'kvm'},
                          'virtualization_type': 'kvm',
                          'virtualization_role': 'guest'}


# Generated at 2022-06-25 01:32:26.987991
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    pass


# Generated at 2022-06-25 01:32:34.572437
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    virtual_sysctl_detection_mixin_0.sysctl_path = 'echo -n'
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(
        return_value=(0, 'OpenBSD', '')
    )
    output = {}
    output['virtualization_type'] = 'vmm'
    output['virtualization_role'] = 'guest'
    virtual_sysctl_detection_mixin_0.detect_virt_vendor = MagicMock()
    assert output == virtual_sysctl

# Generated at 2022-06-25 01:32:39.151086
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_1.detect_virt_vendor('kern.vm_guest')


# Generated at 2022-06-25 01:33:38.683582
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_1 = []
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product(list_1)


# Generated at 2022-06-25 01:33:40.648927
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)

# Generated at 2022-06-25 01:33:45.810800
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Test_VirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_virt_product(self, key):
            return self.detect_virt_product(key)

    list_0 = []
    virtual_sysctl_detection_mixin_0 = Test_VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)


# Generated at 2022-06-25 01:33:47.798394
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)


# Generated at 2022-06-25 01:33:53.130016
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)


# Generated at 2022-06-25 01:33:55.470835
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    assert not virtual_sysctl_detection_mixin_0.detect_virt_vendor(list_0)


# Generated at 2022-06-25 01:34:00.377565
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(list_0)

    assert(var_0['virtualization_type'] == None)
    assert(var_0['virtualization_role'] == None)


# Generated at 2022-06-25 01:34:03.910409
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    assert True



# Generated at 2022-06-25 01:34:10.740876
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(list_0)
    assert 'virtualization_tech_guest' in var_0
    assert 'virtualization_tech_host' in var_0
    assert 'virtualization_type' in var_0
    assert 'virtualization_role' in var_0


# Generated at 2022-06-25 01:34:12.092492
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    assert VirtualSysctlDetectionMixin.detect_virt_product(VirtualSysctlDetectionMixin)


# Generated at 2022-06-25 01:35:51.425538
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_vendor(list_0)


# Generated at 2022-06-25 01:36:01.687756
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Input parameters
    key = ''

    # Output parameters
    # Return value
    virtual_vendor_facts = {}

    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_0.module = MockModule()
    virtual_sysctl_detection_mixin_0.module.run_command = MagicMock(return_value=(0, 'QEMU', ''))

    virtual_vendor_facts = virtual_sysctl_detection_mixin_0.detect_virt_vendor(key)

    # Case: test_case_0
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert virtual_vendor

# Generated at 2022-06-25 01:36:03.627050
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_1 = []
    virtual_sysctl_detection_mixin_1 = VirtualSysctlDetectionMixin()
    var_1 = virtual_sysctl_detection_mixin_1.detect_virt_product(list_1)


# Generated at 2022-06-25 01:36:08.810966
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin.detect_virt_vendor(['hw.model']) == \
        {'virtualization_role': 'guest', 'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set(),
         'virtualization_type': 'vmm'}


# Generated at 2022-06-25 01:36:17.671503
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    list_0 = []
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)
    assert var_0 == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}, var_0
    list_0 = ['KVM']
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)
    assert var_0 == {'virtualization_type': 'kvm', 'virtualization_tech_host': set(), 'virtualization_role': 'guest', 'virtualization_tech_guest': {'kvm'}}, var_0

# Generated at 2022-06-25 01:36:21.851993
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    if isinstance(VirtualSysctlDetectionMixin().detect_virt_product(), dict):
        return True
    else:
        return False


# Generated at 2022-06-25 01:36:23.583147
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    out_1 = {'virtualization_type': 'vmm', 'virtualization_role': 'guest', 'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set()}
    assert out_1 == test_case_0()


# Generated at 2022-06-25 01:36:29.524462
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_0 = []
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)


# Generated at 2022-06-25 01:36:35.425300
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    key_0 = 'hw.model'
    virtual_sysctl_detection_mixin_0.detect_virt_product(key_0)


# Generated at 2022-06-25 01:36:44.089839
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    list_0 = [1,2,3]
    list_1 = [4,5,6,7]
    virtual_sysctl_detection_mixin_0 = VirtualSysctlDetectionMixin()
    if len(list_0) != len(list_1):
        var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_0)
    else:
        var_0 = virtual_sysctl_detection_mixin_0.detect_virt_product(list_1)
    return var_0
