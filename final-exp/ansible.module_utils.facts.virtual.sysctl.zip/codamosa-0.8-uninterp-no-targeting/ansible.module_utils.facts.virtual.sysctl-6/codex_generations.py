

# Generated at 2022-06-20 20:48:24.962997
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class FakeModule(object):
        def get_bin_path(self, name):
            return True

        def run_command(self, cmd):
            return 0, 'KVM', ''

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    virtual_product_facts = mixin.detect_virt_product('hw.product')
    assert virtual_product_facts['virtualization_type'] is 'kvm'
    assert virtual_product_facts['virtualization_role'] is 'guest'
    assert virtual_product_facts['virtualization_tech_guest'] == set(['kvm'])

    class FakeModule(object):
        def get_bin_path(self, name):
            return True

        def run_command(self, cmd):
            return 0, 'VMware', ''

# Generated at 2022-06-20 20:48:37.412587
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.six import create_bound_method
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    import os
    test_object = VirtualSysctlDetectionMixin()
    os.environ['PATH'] = ''
    test_object.run_command = lambda self, cmd, check_rc=True: (0, "XXX", "")
    test_object.module = object()
    test_object.module.run_command = create_bound_method(test_object.run_command, test_object)
    test_object.module.get_bin_path = lambda name: "/bin/sysctl"

# Generated at 2022-06-20 20:48:49.223392
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self.bin_path = '/usr/bin'

        def get_bin_path(self, name, required=False):
            if name == 'sysctl':
                return self.bin_path + '/sysctl'

        def run_command(self, cmd, use_unsafe_shell=False):
            self.cmd = cmd

    class MockOsDetection(object):
        pass

    class MixinTest(VirtualSysctlDetectionMixin, MockOsDetection):
        def __init__(self):
            self.module = MockModule()
            super(MixinTest, self).__init__()

    # Mock sysctl

# Generated at 2022-06-20 20:48:56.637833
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def run_command(self, cmd):
            if cmd == "sysctl -n kern.vm_guest":
                return 0, "XenPVHVM", ""
            if cmd == "sysctl -n kern.jail.osreldate":
                return 0, "1200055", ""
            if cmd == "sysctl -n security.jail.jailed":
                return 0, "1", ""

        def get_bin_path(self, path):
            if path == "sysctl":
                return path

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeGatherFacts:
        def __init__(self, module):
            self.virtual_sysctl

# Generated at 2022-06-20 20:49:09.105923
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class DummyModule:
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'kvm', ''

    class DummySys(object):
        def __init__(self):
            self.module = DummyModule()
    sys = DummySys()
    sysctl_obj = VirtualSysctlDetectionMixin()
    virtual_product_facts = sysctl_obj.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert virtual_product_facts['virtualization_tech_guest'] == {'kvm'}

# Generated at 2022-06-20 20:49:16.722898
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Fake method
    def fake_run_command(*args, **kwargs):
        return 0, "", ""
    class FakeTopModule:
        run_command = fake_run_command
        def get_bin_path(*args, **kwargs):
            return "/usr/sbin/sysctl"
    class FakeFactsModule:
        def __init__(*args, **kwargs):
            pass
    # Fake test class
    class FakeClass:
        def __setattr__(self, name, value):
            pass
    # Testing detect_virt_vendor
    detector = VirtualSysctlDetectionMixin()
    detector.module = FakeTopModule()
    original_system = detector.module.system
    detector.module.system = 'FreeBSD'
    detector.facts = FakeFactsModule()
    detector.facts.virtualization

# Generated at 2022-06-20 20:49:27.661950
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Module(object):
        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            return 0, 'VirtualBox', ''
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = self.module.get_bin_path('sysctl')
    virtualsysctldetectionmixin_test = VirtualSysctlDetectionMixin_test(Module())

# Generated at 2022-06-20 20:49:39.480517
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule:
        def get_bin_path(self, name):
            return "/sbin/sysctl"
        def run_command(self, cmd):
            if cmd == "/sbin/sysctl -n security.jail.jailed":
                return 0, "1", None
            elif cmd == "/sbin/sysctl -n hw.model":
                return 0, "QEMU Virtual CPU version 2.5.0", None
            return 0, "", None

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    t = TestClass()

# Generated at 2022-06-20 20:49:50.309706
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class module:
        def get_bin_path(self, key):
            return '/usr/bin/sysctl'
    class module1:
        def get_bin_path(self, key):
            return False

    class test_class:
        pass

    obj = test_class()
    obj.module = module()
    obj1 = test_class()
    obj1.module = module1()

    mixin = VirtualSysctlDetectionMixin()
    virtual_product_facts = mixin.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'



# Generated at 2022-06-20 20:50:03.541501
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Test(object):
        def __init__(self):
            class Module(object):
                def run_command(self, cmd):
                    return 0, 'QEMU', ''
                def get_bin_path(self, cmd):
                    return '/sbin/sysctl'
            class BsdSysctlSystem(object):
                def __init__(self):
                    self.module = Module()
            self.bsd_sysctl_system = BsdSysctlSystem()

    class_instance = Test()
    mixin_class_instance = VirtualSysctlDetectionMixin()
    mixin_class_instance.module = class_instance.bsd_sysctl_system.module
    result = mixin_class_instance.detect_virt_vendor('hw.model')


# Generated at 2022-06-20 20:50:20.404087
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule(object):
        pass

    module = FakeModule()
    module.get_bin_path = lambda x: '/bin/%s' % (x)
    module.run_command = lambda x: (0, '', '')

    v = VirtualSysctlDetectionMixin()
    v.module = module
    v.detect_virt_product = lambda x: x
    v.detect_sysctl()
    if not v.sysctl_path:
        raise AssertionError('sysctl path not detected')

    v.detect_virt_vendor = lambda x: x
    v.detect_sysctl()
    if not v.sysctl_path:
        raise AssertionError('sysctl path not detected')

# Generated at 2022-06-20 20:50:32.209933
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        run_command_calls = 0
        run_command_rcs = []
        run_command_outs = []
        run_command_errs = []

        def run_command(self, cmd):
            run_command_calls += 1
            rc = 0
            out = ''
            err = ''

            if run_command_calls < len(run_command_rcs) + 1:
                rc = run_command_rcs[run_command_calls]
                out = run_command_outs[run_command_calls]
                err = run_command_errs[run_command_calls]
            else:
                rc = 0
                out = '\n'
                err = ''

            return rc,out,err


# Generated at 2022-06-20 20:50:38.860200
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    import sys

    # Define test class
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = ''

    # Define test_module class
    class TestModule(object):

        def __init__(self):
            self.rc = 0
            self.called = ''
            self.run_command = None

        def get_bin_path(self, arg):
            return self.run_command

        def run_command(self, cmd):
            self.called = cmd
            self.rc = 0
            if self.run_command == '/doesnotexist/sysctl':
                return self.rc, "", "sysctl: kern.vm_guest: No such file or directory"

# Generated at 2022-06-20 20:50:39.921219
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:50:51.652507
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    sysctl_obj = VirtualSysctlDetectionMixin()
    sysctl_obj.module = type('', (), {'get_bin_path': lambda self, x: '/usr/sbin/sysctl'})()

    import  mock
    sysctl_obj.module.run_command = mock.Mock(return_value=(0, 'Xen PV', ''))
    result = sysctl_obj.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'xen'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['xen'])
    assert result['virtualization_tech_host'] == set()

    # test when multiple techs show up
    sysctl_obj.module.run_command = mock.M

# Generated at 2022-06-20 20:51:01.437700
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule(object):
        def __init__(self):
            self.params = ''

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/sysctl'

        def command(self, cmd, args, **kwargs):
            return cmd

    class FakeVirtSysctlDetection(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    f = FakeVirtSysctlDetection(FakeModule())
    assert f.detect_sysctl() == None

# Generated at 2022-06-20 20:51:10.625443
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.base import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.base import VirtualDetectionMixin
    class MyFacts(VirtualDetectionMixin):
        pass
    m = MyFacts()

    class MySysctlMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.module.get_bin_path = lambda x: '/bin/' + x
            self.module.run_command = lambda x: [0, 'VirtualBox', '']
    m.system = MySysctlMixin(m)

    facts = m
    assert 'virtualization_type' in m.get_virtual_facts(facts, 'sysctl', {})


# Generated at 2022-06-20 20:51:18.750909
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable):
            return '/path/to/sysctl'

        def run_command(self, command):
            if command == '/path/to/sysctl -n kern.hostuuid':
                return (0, 'QEMU', '')
            if command == '/path/to/sysctl -n kern.hostid':
                return (0, '9', '')
            if command == '/path/to/sysctl -n kern.ident':
                return (0, 'VirtualBox', '')
            if command == '/path/to/sysctl -n kern.vm_guest':
                return (0, 'XenPV', '')

# Generated at 2022-06-20 20:51:28.145356
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, Mock

    class TestVirtualSysctlDetectionMixin(unittest.TestCase, VirtualSysctlDetectionMixin):
        def setUp(self):
            self.sysctl_path = None
            self.module = Mock()

        @patch.object(VirtualSysctlDetectionMixin, 'detect_sysctl')
        @patch.object(VirtualSysctlDetectionMixin, 'run_command')
        def test_VirtualSysctlDetectionMixin_detect_virt_product_kvm(self, mock_run_cmd, mock_detect_sysctl):
            mock_run_cmd

# Generated at 2022-06-20 20:51:30.740126
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_mixin = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_mixin


# Generated at 2022-06-20 20:51:54.950123
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    import tempfile
    import os

    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def __call__(self, *args, **kwargs):
                return self.rc, self.out, self.err

        def __init__(self):
            self.run_command = self.MockRunCommand(0, "something", "")

        def get_bin_path(self, name, opts=None, required=False):
            return '/usr/sbin/sysctl'

    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-20 20:51:56.022180
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    assert type(mixin) is VirtualSysctlDetectionMixin

# Generated at 2022-06-20 20:52:00.615424
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    '''
    Constructor test
    '''
    obj = VirtualSysctlDetectionMixin()
    assert hasattr(obj, 'detect_sysctl')
    assert hasattr(obj, 'detect_virt_product')
    assert hasattr(obj, 'detect_virt_vendor')


# Generated at 2022-06-20 20:52:04.576629
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MockModule()
    obj = VirtualSysctlDetectionMixin()
    obj.module = module
    obj.detect_sysctl()
    assert obj.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-20 20:52:10.876833
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    mixin.detect_virt_vendor('vm.vmm.name')
    assert mixin.detect_virt_vendor('vm.vmm.name')['virtualization_type'] == 'kvm'
    assert mixin.detect_virt_vendor('vm.vmm.name')['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:52:17.213357
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.openbsd import OpenBSDFacts

    openbsd_detection_mocks = {
        'sysctl_path': '/sbin/sysctl',
        'run_command': lambda self, cmd: (0, 'VMware', '')
    }

    openbsd_facts_obj = OpenBSDFacts()

    # Apply mocks
    for key, value in openbsd_detection_mocks.items():
        setattr(openbsd_facts_obj, key, value)

    facts = openbsd_facts_obj.get_all_facts()


# Generated at 2022-06-20 20:52:21.693978
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    fact = mixin.detect_virt_product('hw.product')
    assert "{u'virtualization_type': 'xen'}" == str(fact)

    fact = mixin.detect_virt_vendor('hw.machine')
    assert "{u'virtualization_type': 'vmm'}" == str(fact)

# Generated at 2022-06-20 20:52:32.144636
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    from ansible.module_utils.facts import virtual

    class FakeModule(object):

        def __init__(self, *args, **kwargs):
            self.run_command_value = (0, "7", "")
            self.get_bin_path_value = os.path.join('/', 'bin', 'sysctl')

        def run_command(self, *args, **kwargs):
            return self.run_command_value

        def get_bin_path(self, *args, **kwargs):
            return self.get_bin_path_value

    class FakeModuleClass(object):
        def __init__(self, *args, **kwargs):
            self.module = FakeModule()

        def detect_sysctl(self, *args, **kwargs):
            pass


# Generated at 2022-06-20 20:52:38.133779
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(argument_spec={})
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = "/usr/bin/sysctl"
    obj.module = module
    results = obj.detect_virt_vendor('hw.model')
    module.exit_json(changed=False, ansible_facts=results)


# Generated at 2022-06-20 20:52:45.859987
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self, return_values):
            self.return_values = return_values
            self.run_command_values = return_values

        def run_command(self, command):
            return self.run_command_values.pop(0)

        def get_bin_path(self, command):
            return self.return_values.pop(0)

    class FakeModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = self

        def fail_json(self, *args, **kwargs):
            pass

        def exit_json(self, *args, **kwargs):
            pass

    # Happy Path: Find kvm, vmware, virtualbox, xen, and jails
    test_module = FakeModule()

# Generated at 2022-06-20 20:53:34.836150
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    sysctl_path = '/usr/bin/sysctl'
    detect_sysctl = VirtualSysctlDetectionMixin()

    class MockModule(object):
        def __init__(self):
            self.run_command_results = [(0, "KVM", ""), (0, "", "/usr/bin/sysctl: jail.jailed: unknown oid 'jail.jailed'\n"), (0, "VMware", ""), (0, "VirtualBox", ""), (0, "XenPV", ""), (0, "Hyper-V", ""), (0, "Parallels", ""), (0, "RHEV Hypervisor", ""), (0, "1", ""), (0, "QEMU", ""), (0, "OpenBSD", "")]
            self.run_command_calls = []
           

# Generated at 2022-06-20 20:53:40.203379
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import platform
    l = VirtualSysctlDetectionMixin()
    l.module = FakeModule({'ansible_system': platform.system()})
    l.detect_sysctl()
    assert l.sysctl_path != None


# Generated at 2022-06-20 20:53:48.216425
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd.sysctl import VirtualSysctlDetectionMixin
    import subprocess

    class TestSysctl:
        def __init__(self):
            self.sysctl_binary = '/sbin/sysctl'
            self.sysctl_path = '/sbin/sysctl'

        def get_bin_path(self, module):
            return self.sysctl_path

        def run_command(self, cmd):
            try:
                run_cmd = subprocess.Popen(cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
            except OSError as e:
                return 1, '', e
            out = run_cmd.communicate()[0]
            return run_cmd.returncode, out, ''

# Generated at 2022-06-20 20:53:57.482263
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin as TestVirtDetectionMixin

    # Test that the module throws an exception if the command returns a non-zero exit code
    module = TestVirtDetectionMixin()
    module.run_command = lambda x: (1, "", "")
    try:
        module.detect_virt_product("hw.product")
        assert False, "An error should have occured"
    except Exception as e:
        assert 'Unable to detect virtualization product using sysctl' in e.message

    # Test that the module works as expected
    module.run_command = lambda x: (0, "toto", "")
    facts = module.detect_virt_

# Generated at 2022-06-20 20:54:05.378935
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    class FakeModule():
        def __init__(self):
            self.params = None
            self.fail_json = None
            self.run_command = None
            self.get_bin_path = None

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = None

    # Detect a FreeBSD Jail
    class FakeSubclass(FakeClass):
        def run_command(self, command, check_rc=True):
            return 0, '1', ''

    fake = FakeSubclass()
    my_dict = fake.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-20 20:54:18.940767
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    class VirtualSysctlDetectionModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = '/bin/sysctl'
            self.facts = {}

        def run_command(self, *args, **kwargs):
            return 0, 'VMware', ''
    a = VirtualSysctlDetectionModule()
    key = 'hw.product'
    result = a.detect_virt_product(key)
    assert type(result) is dict
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'VMware'


# Generated at 2022-06-20 20:54:27.662218
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Create a fake module
    module = type('module', (object,), dict(run_command=lambda *_: (0, '/sbin/sysctl', '')))

    # Create a class instance (note that we do not set the sysctl_path class member)
    inst = VirtualSysctlDetectionMixin()
    inst.module = module

    # Execute the method
    inst.detect_sysctl()

    # Check that we have set the class member sysctl_path
    assert inst.sysctl_path == '/sbin/sysctl'

# Unit tests for the method detect_virt_product

# Generated at 2022-06-20 20:54:29.672471
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    x = VirtualSysctlDetectionMixin()
    assert x.module is None

# Generated at 2022-06-20 20:54:40.858625
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class ActionModule(object):
        def run_command(self, args, check_rc=True):
            return 1, "KVM/Xen/VirtualBox/Hyper-V", ""
        def get_bin_path(self, command):
            return "sysctl"
    module = ActionModule()
    virtual_facts = VirtualSysctlDetectionMixin()
    virtual_facts.module = module
    result = virtual_facts.detect_virt_product('hw.model')
    assert 'virtualization_type' in result
    assert result['virtualization_type'] == 'kvm'


# Generated at 2022-06-20 20:54:50.182278
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class MockModule(object):
        def __init__(self, rc, output, err):
            self.rc = rc
            self.output = output
            self.err = err

        def get_bin_path(self, path, default=None):
            return self.bin_path

        def run_command(self, cmd):
            return (self.rc, self.output, self.err)

    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        pass

    mixin = VirtualSysctlDetectionMixinTest()

    # test kvm
    key = 'kern.vm_guest'
    out = 'kvm'
    err = ''
    rc = 0
    module = MockModule(rc=rc, output=out, err=err)
    mixin.module = module
    mix

# Generated at 2022-06-20 20:56:35.915831
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    class MockModule:
        def __init__(self):
            self.check_mode = False
            self.run_command_return_values = {
                ('sysctl -n %s' % key): (0, guest_tech, None)
                for key, guest_tech in {
                    'hw.product': 'QEMU',
                    'hw.vendor': 'OpenBSD'
                }.items()
            }
            self.run_command_calls = []

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return 'sysctl'

        def run_command(self, cmd, check_rc=True):
            real_cmd = cmd.split()[1:]

# Generated at 2022-06-20 20:56:48.822203
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

        def detect_sysctl(self):
            self.sysctl_path = "/usr/local/sbin/sysctl"

    mixin = MockVirtualSysctlDetectionMixin()
    assert not mixin.detect_virt_vendor("hw.model")['virtualization_type']

    class MockModule(object):
        def __init__(self):
            self.run_command_args = None
            self.run_command_rc = None
            self.run_command_out = ""

        def run_command(self, args, check_rc=True):
            self.run_command_args = args
            self.run_command_rc = 0

# Generated at 2022-06-20 20:57:04.066150
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    o = VirtualSysctlDetectionMixin()

    o.module = AnsibleModuleMock()
    o.module.get_bin_path = MagicMock(return_value='/bin/sysctl')
    o

# Generated at 2022-06-20 20:57:08.476893
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    m = VirtualSysctlDetectionMixin()
    assert hasattr(m, 'detect_sysctl')
    assert hasattr(m, 'detect_virt_product')
    assert hasattr(m, 'detect_virt_vendor')

# Generated at 2022-06-20 20:57:13.439353
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = "/usr/bin/sysctl"
    res = obj.detect_sysctl()
    assert sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-20 20:57:17.223528
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from BSD import sysctl
    sysctl1 = sysctl.VirtualSysctlDetectionMixin()
    sysctl1.module = MagicMock()
    sysctl1.module.get_bin_path = MagicMock(return_value='/sbin/sysctl')
    sysctl1.detect_sysctl()
    assert '/sbin/sysctl' == sysctl1.sysctl_path


# Generated at 2022-06-20 20:57:27.774469
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = '/usr/bin/sysctl'
    obj.module = MagicMock()
    obj.module.run_command = MagicMock(return_value=(0, 'QEMU', None))
    virtual_vendor_facts = obj.detect_virt_vendor('kern.vm_guest')
    assert virtual_vendor_facts == {'virtualization_type': 'kvm',
                                    'virtualization_role': 'guest',
                                    'virtualization_tech_guest': {'kvm'},
                                    'virtualization_tech_host': set()}

    obj.module.run_command = MagicMock(return_value=(0, 'OpenBSD', None))
    virtual_vendor_facts = obj.detect_virt

# Generated at 2022-06-20 20:57:31.228510
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    assert obj
    assert obj.sysctl_path is None
    obj.detect_sysctl()
    assert obj.sysctl_path is None

# Generated at 2022-06-20 20:57:45.395902
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin"""

    class OpenBSDModule(object):

        """Mock ansible.module_utils.basic.AnsibleModule"""

        def __init__(self):
            self.params = {}

        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            """Fake method returning the path of a binary"""
            return '/usr/local/bin/%s' % executable

        def run_command(self, cmd):
            """Fake method with fake output"""
            return 0, 'OpenBSD', ''

    virtual_sysctl_mixin = VirtualSysctlDetectionMixin()
    module = OpenBSDModule()
    virtual_sysctl_mixin.module = module
    virtual_sysctl_mixin.sysctl_

# Generated at 2022-06-20 20:57:57.266364
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(argument_spec={})
    setattr(module, 'is_linux', lambda: False)
    setattr(module, 'is_freebsd', lambda: True)
    setattr(module, 'run_command', lambda x: (0, 'QEMU', ''))
    setattr(module, 'get_bin_path', lambda x: '/bin/sysctl')
    obj = VirtualSysctlDetectionMixin()