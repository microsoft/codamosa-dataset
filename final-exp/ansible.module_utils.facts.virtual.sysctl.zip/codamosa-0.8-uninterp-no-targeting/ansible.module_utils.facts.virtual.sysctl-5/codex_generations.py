

# Generated at 2022-06-20 20:48:20.812225
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestFactsModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    test_facts_module = TestFactsModule()
    assert test_facts_module.detect_sysctl() == None
    assert test_facts_module.detect_virt_vendor('vm.vmtotal') == None
    assert test_facts_module.detect_virt_product('hw.model') == None

# Generated at 2022-06-20 20:48:21.377948
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert True

# Generated at 2022-06-20 20:48:28.965557
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeAnsibleModule()
    module_mixin = VirtualSysctlDetectionMixin()
    module_mixin.module = module
    module_mixin.detect_sysctl = virtual_detect_sysctl
    module.run_command = virtual_run_command
    # detect_virt_product
    module_mixin.detect_virt_product('machdep.cpu.brand_string')
    # detect_virt_product
    module_mixin.detect_virt_product('machdep.hypervisor')
    # detect_virt_product
    module_mixin.detect_virt_product('machdep.hypervisor_string')
    # detect_virt_product
    module_mixin.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-20 20:48:35.425163
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    # Define members (this is normally set by the module) to make the
    # class pass parameter checks
    VirtualSysctlDetectionMixin.sysctl_path = '/sbin/sysctl'
    VirtualSysctlDetectionMixin.module = 'module'

    # Define a class that uses VirtualSysctlDetectionMixin
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            VirtualSysctlDetectionMixin.__init__(self)

        def detect_virt_vendor(self, key):
            return super(VirtualSysctlDetectionMixin_test, self).detect_virt_vendor(key)

    # Define mock methods for module


# Generated at 2022-06-20 20:48:47.427136
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Facts_Module(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    class Mock_AnsibleModule:
        def get_bin_path(self, binary):
            return "/usr/bin/sysctl"
        def run_command(self, command):
            if command == '/usr/bin/sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 0.11.1', ''
            if command == '/usr/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''
        def add_fact(self, **kwargs):
            pass

    class Mock_Facts:
        def __init__(self):
            self.virtual_product = None


# Generated at 2022-06-20 20:48:55.590874
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Create a mock module
    class TempModule:
        def __init__(self):
            self.params = dict()
        def run_command(self, cmd):
            if cmd == 'test_command':
                return 0, "This is a test", None
            else:
                return 1, "", None
        def get_bin_path(self, cmd):
            return 'test_command'
    m = TempModule()
    # Create a mock object from the class we want to test
    class TempClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = m
    # Create an instance of the mixin to test
    x = TempClass()

    # Set up test cases

# Generated at 2022-06-20 20:49:08.153764
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualMachineInfoModule
    class DummyModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, bin_path):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'Virtual Machine', None
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 1, None, None
            return 0, '', None
    obj = VirtualMachineInfoModule()
    obj.detect = VirtualSysctlDetectionMixin()
    obj.module = DummyModule()
    facts

# Generated at 2022-06-20 20:49:10.351270
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    ''' Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
    '''
    pass

# Generated at 2022-06-20 20:49:22.110508
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    key = 'hw.model'
    out = 'KVM'
    class ModuleMock():
        def get_bin_path(self, arg):
            return '/usr/sbin/sysctl'
        def run_command(self, arg):
            return (0,out,'')
    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.module = ModuleMock()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixinMock()

    virtual_product_facts = virtual_sysctl_detection_mixin.detect_virt_product(key)
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role']

# Generated at 2022-06-20 20:49:23.380952
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()


# Generated at 2022-06-20 20:49:41.647459
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import Virtual, virtual_facts_cleanup
    from ansible.module_utils.facts import FactCache

    f = Virtual()
    f.module = FactCache()
    f.module.get_bin_path = lambda x: '/usr/bin/sysctl'

    # Test VirtualBox
    f.detect_sysctl = lambda: None
    f.module.run_command = lambda x: (0, 'VirtualBox', '')
    f.detect_virt_product('hw.model')
    assert f.facts['virtualization_type'] == 'virtualbox'
    assert f.facts['virtualization_role'] == 'guest'

    # Reset the vars to their defaults
    virtual_facts_cleanup(f.facts)

    # Test VMware

# Generated at 2022-06-20 20:49:50.524824
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class M(object):
        @staticmethod
        def get_bin_path(b):
            return True

        @staticmethod
        def run_command(c):
            return (0, 'QEMU', None)

    class VSDM(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = M()

    vsdm = VSDM()

    assert vsdm.detect_virt_vendor('hw.model') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([])}

    class VSDM(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module

# Generated at 2022-06-20 20:49:54.927579
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # It is a Unit test, so we do not do anything - we just check is it missing
    # any parameters or anything.
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl()

# Generated at 2022-06-20 20:50:07.906284
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    guest_facts = dict()
    guest_facts['virtualization_role'] = 'guest'
    guest_facts['virtualization_type'] = 'kvm'
    guest_facts['virtualization_tech_host'] = set()
    guest_facts['virtualization_tech_guest'] = set()
    class Module:
        def get_bin_path(self, name):
            return '/usr/bin/sysctl'
        def run_command(self, cmd):
            return 0, 'KVM', ''
    module = Module()
    vsdd = VirtualSysctlDetectionMixin()
    vsdd.module = module
    vsdd.detect_sysctl()
    vsdd_guest_facts = vsdd.detect_virt_product('hw.model')
    assert guest_facts == vsdd_guest_facts


# Generated at 2022-06-20 20:50:10.209181
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    this = VirtualSysctlDetectionMixin()
    this.sysctl_path = '/sbin/sysctl'
    assert this.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-20 20:50:14.103594
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # Create an empty object with name my_obj
    my_obj = VirtualSysctlDetectionMixin()

    # We can now access attributes on this object normally...
    assert my_obj.sysctl_path == None, "Constructor of VirtualSysctlDetectionMixin failed to initialize sysctl_path"

# Generated at 2022-06-20 20:50:18.047039
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mod = ansible.module_utils.basic.AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = mod
    mixin.detect_sysctl()
    assert mixin.sysctl_path is None


# Generated at 2022-06-20 20:50:20.216068
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vsc = VirtualSysctlDetectionMixin()
    vsc.sysctl_path = None
    vsc.module = None
    assert not vsc.sysctl_path
    assert not vsc.module

# Generated at 2022-06-20 20:50:32.158831
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''unit test for the method detect_virt_vendor of class VirtualSysctlDetectionMixin'''

    sysctl_path = "/sbin/sysctl"
    key = "kern.vm_guest"
    rc = 0
    out = "QEMU"
    err = ""

    class Module(object):
        class RunCommand(object):
            def __call__(self, command, check_rc=True, close_fds=True, executable=None, data=None):
                if command != "%s -n %s" % (sysctl_path, key):
                    return (42, "", "") # unexpected command
                return (rc, out, err)

        def __init__(self):
            self.run_command = self.RunCommand()


# Generated at 2022-06-20 20:50:38.815806
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Following values are taken from OpenBSD output
    key_kvm = 'hw.model'
    key_vmm = 'hw.model'
    value_kvm = 'QEMU'
    value_vmm = 'OpenBSD'

    class VirtualSysctlDetectionMixinFake:
        def run_command(self, cmd):
            return 0, value_kvm, ''

    class VirtualSysctlDetectionMixinFakeVMM:
        def run_command(self, cmd):
            return 0, value_vmm, ''

    v = VirtualSysctlDetectionMixin()
    v.module = VirtualSysctlDetectionMixinFake()
    v.detect_sysctl = lambda: None
    facts = v.detect_virt_vendor(key_kvm)

# Generated at 2022-06-20 20:51:08.124619
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import ModuleFacts
    module = ModuleFacts(dict(sysctl_path='/usr/bin/sysctl')) # Stub
    freebsd_sysctl = VirtualSysctlDetectionMixin()
    freebsd_sysctl.module = module
    freebsd_sysctl.detect_sysctl()
    assert(freebsd_sysctl.sysctl_path == '/usr/bin/sysctl')


# Generated at 2022-06-20 20:51:20.167400
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_Test(VirtualSysctlDetectionMixin):
        def __init__(self, virtual_product_facts, virtual_vendor_facts):
            self.virtual_product_facts = virtual_product_facts
            self.virtual_vendor_facts = virtual_vendor_facts

        def detect_sysctl(self):
            self.virtual_product_facts['sysctl_path'] = self.sysctl_path

    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = 'unknown'
            self.run_command_stderr = ''


# Generated at 2022-06-20 20:51:29.409656
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def get_bin_path(arg):
            return '/sbin/sysctl'
        def run_command(arg):
            return 0, '', ''
    class Obj(object):
        def __init__(self):
            self.module = Module()

        def detect_sysctl(self):
            pass
    a = VirtualSysctlDetectionMixin()
    b = Obj()

    expected_result = {'virtualization_type': 'virtualbox',
                       'virtualization_role': 'guest',
                       'virtualization_tech_host': set([]),
                       'virtualization_tech_guest': set(['virtualbox'])}
    rc, out, err = b.module.run_command("/sbin/sysctl -n kern.vm_guest")

# Generated at 2022-06-20 20:51:31.018544
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    o = VirtualSysctlDetectionMixin()
    assert o is not None

# Generated at 2022-06-20 20:51:36.796757
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    facts = {}
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MockModule()
    mixin.detect_virt_vendor('machdep.cpu.brand_string')
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:51:48.491038
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, *args, **kwargs):
            return (0, 'VMware', '')

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    my_obj = TestClass(module)
    my_obj.detect_virt_product('hw.model')
    assert 'virtualization_type' in my_obj.facts.keys()
    assert 'virtualization_role' in my_obj.facts.keys()
    assert my_obj.facts['virtualization_type'] == 'VMware'
    assert my_obj.facts['virtualization_role']

# Generated at 2022-06-20 20:51:50.310976
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """
    Create a VirtualSysctlDetectionMixin object
    """
    VirtualSysctlDetectionMixin()



# Generated at 2022-06-20 20:52:01.817166
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import os
    import tempfile
    import sys

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a fake file in the temporary directory
    fake_sysctl_path = os.path.join(tmpdir, 'sysctl')
    fake_sysctl_file = open(fake_sysctl_path, 'w')
    fake_sysctl_file.flush()

    # Create an instance of a fake module
    class FakeModule:
        def __init__(self):
            self.params = {'tmpdir': tmpdir}
        def get_bin_path(self, path):
            return fake_sysctl_path
        def run_command(self, cmd):
            return (0, 'KVM', '')

    fake_module = FakeModule()

    # Test the constructor
    test_

# Generated at 2022-06-20 20:52:14.185925
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    module = FakeModule()
    module.run_command = MagicMock(return_value=(0, 'QEMU', ''))
    module.get_bin_path = MagicMock(return_value='/sbin/sysctl')

    virtual_sysctl_detect = VirtualSysctlDetectionMixin()
    setattr(virtual_sysctl_detect, 'module', module)

    virtual_vendor_facts = virtual_sysctl_detect.detect_virt_vendor('kern.vm_guest')

    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:52:26.939617
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import ansible_test
    from ansible_test.module_utils.facts.virtual.openbsd_virtual import VirtualSysctlDetectionMixin

    class MockModule(object):
        def __init__(self, fail_command=False):
            self.fail_command = fail_command
            self.run_command_args = None
            self.run_command_rc = None
            self.run_command_stdout = None
            self.run_command_stderr = None
            self.run_command_call_counts = 0

        def get_bin_path(self, executable):
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_call_counts += 1
            self.run_command_args = cmd

# Generated at 2022-06-20 20:53:09.264169
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd.sysctl import VirtualSysctlDetectionMixin
    class MockModule(object):
        def get_bin_path(self, path):
            return "sysctl"
        def run_command(self, cmd):
            return (0, 'QEMU', '')
    virt_sysctl_detection = VirtualSysctlDetectionMixin()
    v_s_d = virt_sysctl_detection.detect_virt_product('hw.model')
    assert v_s_d == {'vendor': 'QEMU', 'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'product': '', 'version': ''}


# Generated at 2022-06-20 20:53:14.716277
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts import virtual

    # Construct VirtualSysctlDetectionMixin class
    obj = virtual.VirtualSysctlDetectionMixin()

    # Assert that sysctl_path is None
    assert obj.sysctl_path is None


# Generated at 2022-06-20 20:53:26.558331
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class MyFacts(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.os = 'OpenBSD'
            self.module = module
            self.sysctl_path = module.get_bin_path('sysctl')
            self.sysctl_result = 0, 'OpenBSD', ''

    fact_class = MyFacts(module)
    result = fact_class.detect_virt_vendor('hw.model')
    assert result, 'Failed to detect OpenBSD VM'

# Generated at 2022-06-20 20:53:29.206432
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_detection_mixin = VirtualSysctlDetectionMixin()
    assert type(virtual_detection_mixin) is VirtualSysctlDetectionMixin


# Generated at 2022-06-20 20:53:32.610991
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    s = VirtualSysctlDetectionMixin()
    assert isinstance(s, VirtualSysctlDetectionMixin)
    assert s.sysctl_path is None

# Generated at 2022-06-20 20:53:40.966074
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    f = VirtualSysctlDetectionMixin()
    f.sysctl_path = '/bin/sysctl'
    f.module = FakeAnsibleModule()
    f.module.run_command.return_value = (0, 'QEMU', '')
    assert f.detect_virt_vendor('vm.vmtotal') == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['kvm'])
    }

# Generated at 2022-06-20 20:53:53.193497
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_sysctl = lambda: None
    # QEMU looks like KVM, however it is the name of the binary
    mixin.module = MockModule(mixin, {'kern.vm_guest': 'VMware'})
    assert mixin.detect_virt_product('kern.vm_guest') == {
        'virtualization_type': 'VMware',
        'virtualization_role': 'guest'
    }
    mixin.module = MockModule(mixin, {'kern.vm_guest': 'Parallels'})

# Generated at 2022-06-20 20:54:02.064253
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeVirt(object):
        def __init__(self, module, sysctl_path):
            self.module = module
            self.sysctl_path = sysctl_path

        def detect_sysctl(self):
            pass

    class FakeModule(object):
        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, arg):
            return (0, 'QEMU', '')

    linux = FakeVirt(FakeModule(), '/usr/bin/sysctl')
    detected_facts = linux.detect_virt_vendor('hw.model')
    assert detected_facts['virtualization_role'] == 'guest'
    assert detected_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-20 20:54:09.173412
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.base import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.virtual import Virtual

    sysctl_path = '/usr/bin/sysctl'

    class FakeModule:
        def get_bin_path(self, cmd):
            return sysctl_path

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    virtual = Virtual(FakeModule())
    # test no sysctl_path
    sysctl_detection_mixin = FakeSysctlDetectionMixin(virtual.module)
    assert sysctl_detection_mixin.sysctl_path is None
    # test sysctl path
    virtual.module.run_command.return_code = None


# Generated at 2022-06-20 20:54:19.590952
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class LinuxModule:
        def __init__(self, test_param):
            self.run_command_rc = 0
            self.run_command_out = test_param
            self.run_command_err = None

        def get_bin_path(self, arg):
            return "/usr/bin/" + arg

        def run_command(self, arg):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    class TestClass(object):
        def __init__(self, test_param):
            self.sysctl_path = "/usr/bin/sysctl"
            self.module = LinuxModule(test_param)

    test_obj = TestClass("QEMU Virtual CPU")

# Generated at 2022-06-20 20:55:47.458444
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Module:
        def get_bin_path(self, name, required=True):
            return '/bin/sysctl'
    class System:
        class FreeBSD:
            def __init__(self, module):
                self.module = module
    module = Module()
    facter = VirtualSysctlDetectionMixin()
    facter.module = module
    facter.system = System(module)
    facter.detect_sysctl()
    assert facter.sysctl_path == '/bin/sysctl'


# Generated at 2022-06-20 20:55:59.003015
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class_name = 'VirtualSysctlDetectionMixin'
    method_name = 'detect_sysctl'
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = 'fake_sysctl_path'
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = module_mock
    vsdm.detect_sysctl()
    assert vsdm.sysctl_path == module_mock.get_bin_path.return_value
    module_mock.get_bin_path.assert_called_once_with('sysctl')



# Generated at 2022-06-20 20:56:12.020648
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    import sys
    import tempfile
    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(__file__))))))
    from lib.ansible.module_utils.facts import hurd
    from lib.ansible.module_utils.facts import openbsd
    from lib.ansible.module_utils.facts import virtual
    from lib.ansible.module_utils.facts.collector import BaseFactCollector
    from lib.ansible.module_utils.facts.system.distribution import Distribution

    class FakeModule(object):
        def __init__(self):
            self._ansible_module_initialized = True

# Generated at 2022-06-20 20:56:14.258669
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    x = Test()
    assert x



# Generated at 2022-06-20 20:56:23.812682
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    import os
    tmp = VirtualSysctlDetectionMixin()
    tmp.module = os
    tmp.sysctl_path = 'echo'
    tmp.sysctl_path = 'echo'
    tmp.module.run_command = os.system
    tmp.module.get_bin_path = os.system
    os.system = lambda x: (0, "1", '')
    assert tmp.detect_virt_product('no.such.key') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    os.system = lambda x: (0, 'Hyper-V', '')

# Generated at 2022-06-20 20:56:30.938726
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from lib_freebsd import FreeBSDModule
    module = FreeBSDModule()
    obj = VirtualSysctlDetectionMixin()
    obj.module = module
    obj.detect_sysctl()
    assert 'sysctl' == obj.sysctl_path
    assert module == obj.module

# Generated at 2022-06-20 20:56:37.655851
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class MockModule(object):
        def get_bin_path(self, name):
            return "/bin/sysctl"
        def run_command(self, cmd):
            return (0, "", "")

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            super(MockSysctlDetectionMixin, self).__init__()
            self.module = module

    virt_detect_mixin = MockSysctlDetectionMixin(MockModule())
    virt_detect_mixin.detect_sysctl()
    assert virt_detect_mixin.sysctl_path == "/bin/sysctl"

# Generated at 2022-06-20 20:56:49.107576
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import VirtualTestModule
    from ansible.module_utils.facts.virtual import VirtualCollector

    class TestOpenBSDVirtualSysctlDetectionMixin(VirtualCollector, OpenBSDVirtualSysctlDetectionMixin):
        pass

    test_module = VirtualTestModule()
    test_virtual = TestOpenBSDVirtualSysctlDetectionMixin(module=test_module)

    # Test QEMU
    test_module.run_command = lambda *args, **kwargs: (0, 'QEMU', '')

# Generated at 2022-06-20 20:56:58.517594
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import sys
    import platform
    import collections

    if sys.version_info[0] == 2:
        import mock
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.facts import virtual
    else:
        from unittest import mock
        from ansible.module_utils._text import to_bytes
        from ansible.module_utils.basic import AnsibleModule
        from ansible.module_utils.facts import virtual

    if platform.system() == "Linux":
        args = collections.namedtuple(
            'args',
            ['connector', 'params', 'cache', 'cache_timeout', 'task_vars', 'ansible_facts', 'module_name'])

# Generated at 2022-06-20 20:57:08.701240
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Setup
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    obj = VirtualSysctlDetectionMixinTest()
    # Test case 1: Return guest_tech of host_tech when virtual vendor is QEMU or VMM
    obj.module.run_command = lambda args, check_rc=False, close_fds=True: ('', '', '')
    obj.module.run_command.return_value = (0, 'QEMU', '')