

# Generated at 2022-06-20 20:48:27.164088
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule():
        def __init__(self):
            self.run_command_results = []
            self.run_command_results.append((0, "QEMU", ""))

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

        def get_bin_path(self, arg, required=False):
            if arg == 'sysctl':
                return 'sysctl'

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.key = "machdep.hypervisor_vendor"
            self.sysctl_path = None
            self.module = MockModule()

    mvsdm = MockVirtualSysctlDetectionMixin()
    mvsdm.detect_sysctl()
   

# Generated at 2022-06-20 20:48:31.212991
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    detection_mixin = VirtualSysctlDetectionMixin()
    assert detection_mixin


# vim: expandtab tabstop=4 shiftwidth=4

# Generated at 2022-06-20 20:48:42.317143
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    if __name__ == '__main__':
        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            return 0, "OpenBSD", ""
        import sys
        sys.modules['ansible.module_utils.basic'] = sys.modules['ansible.module_utils.basic']
        VirtualSysctlDetectionMixin_object = VirtualSysctlDetectionMixin()
        VirtualSysctlDetectionMixin.module = type('module', (object,), {
            "run_command": run_command,
        })
        virtual_vendor_facts = VirtualSysctlDetectionMixin_object.detect_virt_vendor("machdep.hypervisor")
        assert virtual_vendor_facts['virtualization_type'] == 'vmm'
        assert virtual

# Generated at 2022-06-20 20:48:46.141752
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    class A(VirtualSysctlDetectionMixin):
        pass

    A()

# Generated at 2022-06-20 20:48:48.844695
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    obj = VirtualSysctlDetectionMixin()
    obj.module = MockModule()
    obj.detect_sysctl()
    assert obj.sysctl_path is None


# Generated at 2022-06-20 20:48:50.328946
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    sysctl_obj = VirtualSysctlDetectionMixin()
    assert sysctl_obj

# Generated at 2022-06-20 20:48:57.149476
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class ModuleStub(object):
        class RunCommandStub(object):
            pass
        class get_bin_pathStub(object):
            pass
        def run_command(self, cmd):
            assert cmd == "/usr/sbin/sysctl -n kern.vm_guest"
            return 0, "KVM", ""

        def get_bin_path(self, cmd):
            assert cmd == "sysctl"
            return "/usr/sbin/sysctl"
    class Stub(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    stub = Stub(ModuleStub())

# Generated at 2022-06-20 20:49:01.928964
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vsdm = VirtualSysctlDetectionMixin()
    assert hasattr(vsdm, 'sysctl_path')
    assert hasattr(vsdm, 'detect_virt_vendor')
    assert hasattr(vsdm, 'detect_virt_product')
    assert hasattr(vsdm, 'detect_sysctl')

# Generated at 2022-06-20 20:49:08.153625
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    vsu = VirtualSysctlDetectionMixin()
    vsu.module = Mock_AnsibleModule('key')
    vsu.detect_virt_product = MagicMock(return_value=None)
    vsu.detect_virt_product('key')
    vsu.detect_virt_product.assert_called_once_with('key')



# Generated at 2022-06-20 20:49:15.696113
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from collections import namedtuple
    import mock

    class SysctlDetectionMixin(object):
        def detect_sysctl(self):
            self.sysctl_path = 'sysctl'

    class Test:
        def __init__(self):
            pass

    def run_command(command):
        command = command.split()
        command.remove('-n')
        if command[1] == 'hint.hv_vendor.0':
            return 0, 'QEMU', ''
        if command[1] == 'hint.hv_vendor.1':
            return 0, 'OpenBSD', ''

# Generated at 2022-06-20 20:49:32.482640
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def get_bin_path(self, *args):
            return '/bin/sysctl'

        def run_command(self, *args):
            return 0, '', ''
    sysctl_object = VirtualSysctlDetectionMixin()
    sysctl_object.module = MockModule()
    result_dict = sysctl_object.detect_virt_vendor('hw.product')
    assert result_dict['virtualization_role'] == 'guest'
    assert result_dict['virtualization_type'] == 'kvm'
    assert 'kvm' in result_dict['virtualization_tech_guest']


# Generated at 2022-06-20 20:49:39.176924
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import ansible.module_utils.facts.virtual.sysctl as sysctl_detect
    sysctl_detect_facts = sysctl_detect.VirtualSysctlDetectionMixin()
    assert hasattr(sysctl_detect_facts, "detect_sysctl")
    assert hasattr(sysctl_detect_facts, "detect_virt_product")
    assert hasattr(sysctl_detect_facts, "detect_virt_vendor")

# Generated at 2022-06-20 20:49:51.113971
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """Test method detect_sysctl of class VirtualSysctlDetectionMixin"""
    from ansible.module_utils.facts.base import TestVirtualSysctlDetectionModule
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils._text import to_bytes

    # This is the return of sysctl -n compat.linux.osrelease
    _sysctl_output = 'Linux-4.4.0-31-generic-x86_64-with-Ubuntu-16.04-xenial'

    _get_bin_path_map = {
        b'sysctl': b'sysctl-test'
    }


# Generated at 2022-06-20 20:50:03.992179
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Fake_module:
        def get_bin_path(self, path):
            return '/usr/bin/sysctl'

    class Fake_VirtualSysctlDetectionMixin:
        def __init__(self):
            self.module = Fake_module()

    v = VirtualSysctlDetectionMixin()
    v.module = Fake_module()
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'
    # Also test that it can handle the case where the binary does not exist
    def mock_get_bin_path(path):
        if path == 'sysctl':
            return None
        else:
            return ''
    v.module.get_bin_path = mock_get_bin_path
    v.sysctl_path = None
    v.detect_

# Generated at 2022-06-20 20:50:14.839690
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual.freebsd.sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd.sysctl import VirtualSysctlDetectionMixinTestCase
    import sysctl

    class VirtualSysctlDetectionMixinHostTestCase(VirtualSysctlDetectionMixinTestCase):
        def setUp(self):
            self.test_class = VirtualSysctlDetectionMixin
            super(VirtualSysctlDetectionMixinHostTestCase, self).setUp()


    # Test KVM guest
    sysctl.sysctl = {'hw.model': 'QEMU',
                     'hw.vm.guest': 'FreeBSD'}
    virtual_vendor_facts = VirtualSysctlDetectionMixinHost

# Generated at 2022-06-20 20:50:24.970794
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, rc, stdout, stderr):
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def get_bin_path(self, *args, **kwargs):
            return "/bin/sysctl"

        def run_command(self, cmd, *args, **kwargs):
            return (self.rc, self.stdout, self.stderr)

    #
    # Test cases for VirtualSysctlDetectionMixin.detect_virt_product
    #

# Generated at 2022-06-20 20:50:35.097944
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """Create the unit test for the detect_sysctl method of the
    VirtualSysctlDetectionMixin class.
    Execute this using:

    ```
    python -m pytest -v test_VirtualSysctlDetectionMixin_detect_sysctl.py
    ```
    """
    import os

    class MockModule:
        """Mock of the AnsibleModule class.
        """
        def __init__(self, params=None):
            if params:
                self.params = params
            else:
                self.params = {}

        def get_bin_path(self, command, *args, **kwargs):
            for path in os.environ["PATH"].split(os.pathsep):
                if not os.path.isdir(path):
                    continue

# Generated at 2022-06-20 20:50:42.312528
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.common.sys_info import VirtualSysctlDetectionMixin
    vvm = VirtualSysctlDetectionMixin()
    vvm.sysctl_path = None
    vvm.module = MockModule()
    vvm.detect_sysctl()
    assert vvm.sysctl_path == 'test'


# Unit tests for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-20 20:50:54.941220
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = type('', (), {'run_command': lambda x: ('', '', '')})()
    plugin = VirtualSysctlDetectionMixin()
    plugin.module = module
    result = plugin.detect_virt_product('hw.model')
    assert result.get('virtualization_type') is None and result.get('virtualization_role') is None, \
           'detect_virt_product failed to correctly detect virtualization_type and virtualization_role'
    result = plugin.detect_virt_product('security.jail.jailed')
    assert result.get('virtualization_type') == 'jails' and result.get('virtualization_role') == 'guest', \
           'detect_virt_product failed to correctly detect virtualization_type and virtualization_role'
    result = plugin.detect_virt_

# Generated at 2022-06-20 20:50:59.018817
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    bd = VirtualSysctlDetectionMixin()
    rc, out, err = bd.module.run_command("/sbin/sysctl -n kern.vm_guest")

    assert rc == 0
    assert bd.detect_virt_vendor('kern.vm_guest')['virtualization_tech_guest'] == set(['kvm'])
    assert bd.detect_virt_vendor('kern.vm_guest')['virtualization_type'] == 'kvm'
    assert bd.detect_virt_vendor('kern.vm_guest')['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:51:24.223250
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class ModuleMock(object):
        def __init__(self):
            pass

        def get_bin_path(self, arg1):
            return arg1

    class OpenBSDMixin(VirtualSysctlDetectionMixin):
        pass

    mixin = OpenBSDMixin()
    mixin.module = ModuleMock()
    mixin.detect_sysctl()
    assert mixin.sysctl_path == 'sysctl'


# Generated at 2022-06-20 20:51:37.788225
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class fake_module:
        def get_bin_path(self, executable=None, required=True, opt_dirs=[]):
            return '/usr/bin/sysctl'
        def run_command(self, executable=None, path_prefix=None, data=None, binary_data=False,
                        timeout=10, check_rc=True, environ_update=None):
            return 0, 'OpenBSD', None
    class fake_class:
        def __init__(self):
            self.facts = dict()
            self.facts['kernel'] = 'OpenBSD'
            self.module = fake_module()
    obj = fake_class()
    VirtualSysctlDetectionMixin().detect_virt_vendor(obj, 'hw.vendor')
    assert obj.facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:51:44.970784
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockFreebsdSystemFacts(VirtualSysctlDetectionMixin):
        def __init__(self, sysctl_path):
            self.module = MockModule(sysctl_path)

    class MockModule:
        def __init__(self, sysctl_path):
            self.sysctl_path = sysctl_path

        def get_bin_path(self, name, required=False):
            return self.sysctl_path

        def run_command(self, command):
            rc = 0
            err = []
            if command == "%s -n kern.hostuuid" % self.sysctl_path:
                out = 'QEMU'
            elif command == "%s -n hw.product" % self.sysctl_path:
                out = 'OpenBSD'
            else:
                rc = 1

# Generated at 2022-06-20 20:51:53.797788
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = VirtualSysctlDetectionMixin()
    module.sysctl_path = "%s/fixtures/sysctl_kvm.py" % os.path.dirname(__file__)
    virtual_product_facts = module.detect_virt_product('hw.model')
    assert 'kvm' in virtual_product_facts['virtualization_tech_guest']
    assert 'virtualbox' not in virtual_product_facts['virtualization_tech_guest']
    assert 'xen' not in virtual_product_facts['virtualization_tech_guest']
    assert 'virtualization_type' in virtual_product_facts
    assert 'virtualization_role' in virtual_product_facts
    assert virtual_product_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-20 20:52:03.461808
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, key):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            return (self.rc, self.out, self.err)

    class VirtualSysctlDetectionMixinClass(object):
        def __init__(self):
            self.module = VirtualSysctlDetectionMixinModule(0, '', '')
            self.sysctl_path = None

    obj = VirtualSysctlDetectionMixinClass()
    obj.detect_sysctl()


# Generated at 2022-06-20 20:52:13.293145
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    import os
    class Module:
        def __init__(self):
            self.params = dict()
            self.run_command_environ_update = dict()
        def run_command(self, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '0', ''
            else:
                return 1, '', ''
        def get_bin_path(self, binary, required=False, opt_dirs=[]):
            return '/sbin/sysctl'

# Generated at 2022-06-20 20:52:16.825712
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    m = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:52:26.097122
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule(object):
        def run_command(self, command):
            return 0, '1', ''
        def get_bin_path(self, name):
            return '/usr/bin/grep'

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    m = FakeModule()

    # test detect_sysctl
    fc = FakeClass(m)
    fc.detect_sysctl()
    assert fc.sysctl_path == '/usr/bin/grep'

    # test detect_virt_product
    fc = FakeClass(m)
    fc.detect_sysctl()

# Generated at 2022-06-20 20:52:38.024419
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Mock(object):
        pass

    # Create a fake module
    module = Mock()
    module.get_bin_path = Mock()
    module.run_command = Mock()

    # Create a fake sysctl executable
    module.get_bin_path.return_value = Mock()

    # Create a fake system output
    out = Mock()

    # Fake return values of the system command
    rc = Mock()
    out = 'KVM Virtual CPU version 0.0'
    err = Mock()
    module.run_command.return_value = rc, out, err

    # Create a fake object from class VirtualSysctlDetectionMixin
    object = VirtualSysctlDetectionMixin()
    object.module = module

    # Test detect_virt_product() method
    key = 'machdep.hypervisor'
    result = object

# Generated at 2022-06-20 20:52:41.372095
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    sysctl_path = '/sbin/sysctl'
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = lambda x: sysctl_path
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
    testclass = TestClass(module)
    testclass.detect_sysctl()
    assert(testclass.sysctl_path == sysctl_path)

# Generated at 2022-06-20 20:53:30.965698
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()

    class Module:
        def get_bin_path(self, command):
            return 'sysctl'

        def run_command(self, command):
            if command == 'sysctl -n hw.product':
                return 0, 'VirtualBox', ''
            elif command == 'sysctl -n security.jail.jailed':
                return 0, '1', ''
            else:
                return 1, '', ''
    mixin.module = Module()
    vf = mixin.detect_virt_product('hw.product')
    assert vf['virtualization_type'] == u'virtualbox'
    assert vf['virtualization_role'] == u'guest'
    assert 'jails' in vf['virtualization_tech_guest']

# Unit test

# Generated at 2022-06-20 20:53:45.481979
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_module = AnsibleModule(argument_spec={})
    test_class = VirtualSysctlDetectionMixin()
    test_class.module = test_module
    test_class.sysctl_path = '/usr/sbin/sysctl'
    test_class.virtual_product_key = 'hw.product'
    test_class.virtualization_product_facts = {}
    # Test product_facts
    test_class.virtualization_product_facts = test_class.detect_virt_product(test_class.virtual_product_key)
    # hw.product = VirtualBox
    # virtualization_product_facts = {
    #     "virtualization_type": "virtualbox",
    #     "virtualization_role": "guest",
    #     "virtualization_product": "VirtualBox",
    #     "

# Generated at 2022-06-20 20:54:00.459382
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.kvm import VirtualKVMDetection
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual.vmm import VirtualVMMDetection

    collect_facts = VirtualKVMDetection()
    key = 'hw.product'
    out = 'QEMU'
    collect_facts.sysctl_path = '/sbin/sysctl'
    collect_facts.module.run_command = lambda x: (0, out, None)
    virtual_vendor_facts = collect_facts.detect_virt_vendor(key)

    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virtual_vendor_

# Generated at 2022-06-20 20:54:07.830077
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    class_name = 'VirtualSysctlDetectionMixin'
    class_obj = VirtualSysctlDetectionMixin()

    class_module = VirtualSysctlDetectionMixin.__module__
    class_parent_module = class_module.rpartition('.')[0]

    method_name = 'detect_virt_vendor'
    key = 'security.jail.jailed'
    virtual_vendor_facts = {}

    # import parent module
    parent_mod = __import__(class_parent_module, fromlist=[''])

    # import class module
    class_mod = getattr(parent_mod, class_name)

    # get class object
    class_obj = class_mod()

    # import module
    mod = __import__(class_module, fromlist=[''])

    # get the method object


# Generated at 2022-06-20 20:54:18.676991
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FreebsdHost:
        sysctl_path = '/sbin/sysctl'
        module = FreebsdHost

    class ansibleModule:
        def get_bin_path(self, cmd):
            return FreebsdHost.sysctl_path

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.model':
                return 0, 'FreeBSD', ''
            if cmd == '/sbin/sysctl -n kern.vm_guest':
                return 0, 'QEMU', ''
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                return 0, '0', ''

    # create a temp instance of ModuleUtilsGenericVirtLinux and change its
    # module to a dummy one
    m = VirtualSysctlDetectionMixin

# Generated at 2022-06-20 20:54:25.307249
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={'virtualization': dict(required=False, type='list')})
    module.params['virtualization'] = ['system', 'jail']
    obj = VirtualSysctlDetectionMixin()
    obj.module = module
    obj.detect_sysctl()
    assert obj.sysctl_path == '/usr/sbin/sysctl'



# Generated at 2022-06-20 20:54:30.753283
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mock_self = MockThis()
    mock_self.module = MockModule()
    VirtualSysctlDetectionMixin().detect_sysctl(mock_self)
    # sysctl is a valid command
    assert mock_self.sysctl_path is not None



# Generated at 2022-06-20 20:54:36.472776
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    bsd = VirtualSysctlDetectionMixin()
    facts = bsd.detect_virt_vendor('hw.model')
    assert {'virtualization_role': 'guest', 'virtualization_type': 'vmm'} == facts


# Generated at 2022-06-20 20:54:45.254381
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    class Object(object):
        def get_bin_path(self, command):
            return "/sbin/sysctl"
    m.module = Object()

    class Object(object):
        def run_command(self, args):
            return 0, "QEMU", ""
    m.module = Object()
    virtual_vendor_facts = m.detect_virt_vendor("machdep.hypervisor")
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:54:49.123907
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()

    # Check that class variables are set to empty string or empty set
    assert mixin.sysctl_path == None



# Generated at 2022-06-20 20:56:32.856367
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl = VirtualSysctlDetectionMixin()
    assert isinstance(virtual_sysctl, VirtualSysctlDetectionMixin)

# Generated at 2022-06-20 20:56:40.825470
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule:
        def get_bin_path(self, name):
            return ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = TestModule()

    test_class = TestClass()
    test_class.detect_sysctl()
    assert test_class.sysctl_path == ''



# Generated at 2022-06-20 20:56:50.985172
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/sysctl'

        class TestSubModule(object):
            def __init__(self, module):
                self.module = module

            def run_command(self, arg):
                if arg == '/bin/sysctl -n hw.model':
                    return 0, 'i386', None
                if arg == '/bin/sysctl -n security.jail.jailed':
                    return 0, '1', None
                if arg == '/bin/sysctl -n security.jail.host.hostname':
                    return 0, 'host.hostname.com', None
                if arg == '/bin/sysctl -n security.jail.path':
                    return 0, '/jail/test1', None

# Generated at 2022-06-20 20:57:05.547397
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import platform

    class ModuleStub:
        def get_bin_path(self, path):
            if path == 'sysctl':
                if platform.system() == 'FreeBSD':
                    return '/sbin/sysctl'
                else:
                    return '/usr/sbin/sysctl'
            else:
                assert False, 'get_bin_path() no longer uses a string argument'

        def run_command(self, *args):
            assert False, 'run_command() called unexpectedly'


    class VirtualSysctlDetectionMixinStub(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = ModuleStub()

    stub = VirtualSysctlDetectionMixinStub()
    stub.detect_sysctl()
    assert stub.sysctl_path

# Unit tests for method

# Generated at 2022-06-20 20:57:15.902023
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    def systl_run_command(self, args_string, check_rc=True):
        if args_string == "sysctl -n hw.model":
            return (0, "OpenBSD", "")
        if args_string == "sysctl -n hw.model":
            return (0, "QEMU", "")

    def get_bin_path(self, arg):
        return 'sysctl'

    class OpenBSDModule:
        def __init__(self):
            self.run_command = systl_run_command
            self.get_bin_path = get_bin_path

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = OpenBSDModule()
    mixin.detect_sysctl()


# Generated at 2022-06-20 20:57:25.435726
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MockModule(object):
        def __init__(self):
            self.sysctl_path = None

        def get_bin_path(self, name):
            return self.sysctl_path

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MockModule()

    mixin.module.sysctl_path = None
    mixin.detect_sysctl()
    assert mixin.sysctl_path is None

    mixin.module.sysctl_path = '/fake/path'
    mixin.detect_sysctl()
    assert mixin.sysctl_path == '/fake/path'



# Generated at 2022-06-20 20:57:27.968890
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mod = VirtualSysctlDetectionMixin()
    mod.module = {}
    mod.module.get_bin_path = lambda x: 'test'
    mod.detect_sysctl()
    assert mod.sysctl_path == 'test'

# Generated at 2022-06-20 20:57:36.575766
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    class TestVirtualSysctlDetection:
        def __init__(self):
            self.exit_json = exit_json
            self.check_mode = False
            self.run_command = run_command
            self.get_bin_path = get_bin_path
            self.sysctl_path = None

    v = VirtualSysctlDetectionMixin()
    v.module = TestVirtualSysctlDetection()
    assert v.sysctl_path is None

    # Fake `sysctl` found in PATH
    v.detect_sysctl()
    assert v.sysctl_path == 'sysctl_path'

    module.fail_json.assert_has_calls([])

# Generated at 2022-06-20 20:57:45.763148
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_vendor_facts = {}
    host_tech = set()
    guest_tech = set()
    module = AnsibleModule()
    module.get_bin_path = Mock(return_value=True)
    module.run_command = Mock(return_value=0, side_effect=MockSideEffect)
    vsysctl = VirtualSysctlDetectionMixin()
    vsysctl.module = module
    virtual_vendor_facts = vsysctl.detect_virt_vendor('machdep.hypervisor_vendor')
    assert virtual_vendor_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_vendor_facts['virtualization_tech_host'] == host_tech
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_v

# Generated at 2022-06-20 20:57:53.184645
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={})
    test_class = VirtualSysctlDetectionMixin()
    test_class.module = module
    test_class.detect_sysctl()
    assert test_class.sysctl_path
