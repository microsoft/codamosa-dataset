

# Generated at 2022-06-20 20:48:24.367713
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = ''

        def detect_sysctl(self):
            self.sysctl_path = '/usr/sbin/sysctl'

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})
    test_class = TestClass(module)

    # Test detect vmm
    key = 'hw.vmm.name'
    module.run_command = MockRunCommand('OpenBSD')
    result = test_class.detect_virt_vendor(key)
    assert 'vmm' in result['virtualization_tech_guest']
    assert len(result['virtualization_tech_host']) == 0
    assert result

# Generated at 2022-06-20 20:48:30.981320
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FreeBSDModule(object):
        @staticmethod
        def get_bin_path(name, opt_dirs=None, required=False):
            return sysctl_path

        @staticmethod
        def run_command(cmd, check_rc=False, close_fds=True, executable=None,
                        data=None, binary_data=False, path_prefix=None,
                        cwd=None, use_unsafe_shell=False, prompt_regex=None,
                        environ_update=None, umask=None, encoding=None):
            return (0, "VirtualBox", "")

    sysctl_path = "/sbin/sysctl"
    mod = VirtualSysctlDetectionMixin()
    mod.module = FreeBSDModule()

# Generated at 2022-06-20 20:48:36.959815
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = AnsibleModule(argument_spec={})
    # From docs: https://docs.python.org/3/library/unittest.mock.html#unittest.mock.MagicMock()
    # MagicMock() does not have some attrs that
    # VirtualSysctlDetectionMixin() expects. So
    # class VirtualSysctlDetectionMixin() can't be tested
    # with Python 3.

# Generated at 2022-06-20 20:48:43.572426
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from units.modules.utils import set_module_args
    from ansible.module_utils.openbsd_virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.utils import Facts

    module = MyModule()
    sysctl = VirtualSysctlDetectionMixin()

    sysctl.module = module
    sysctl.detect_sysctl()

    assert sysctl.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:48:54.037280
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    vd = VirtualSysctlDetectionMixin()
    # Simulate sysctl
    vd.sysctl_path = '/usr/bin/sysctl'

    # Simulate sysctl response
    class Module:
        def run_command(self, cmd):
            return (0, 'QEMU', '')
    vd.module = Module()

    # Test one
    expected = {
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }
    # Should match
    assert vd.detect_virt_vendor('machdep.vm_guest') == expected

    # Test two - OpenBSD

# Generated at 2022-06-20 20:49:05.974893
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    facts = dict()
    # set up class for testing
    class MockModule(object):
        def run_command(self, cmd):
            if 'sysctl -n hw.model' in cmd:
                return 0, 'QEMU Virtual CPU version (cpu64-rhel6) (2040 MHz)', ''
            elif 'sysctl -n security.jail.jailed' in cmd:
                return 0, '1', ''

        def get_bin_path(self, cmd):
            return '/sbin/sysctl'
    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Set up a fake module
    module = MockModule()

    # Run the code to be tested
    sysctl_detection_mixin

# Generated at 2022-06-20 20:49:07.404786
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert True

# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 20:49:16.222948
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """
    Test for VirtualSysctlDetectionMixin.detect_virt_vendor stub
    """
    sample_vendor_facts = { 'virtualization_type': 'vmm',
                            'virtualization_role': 'guest',
                            'virtualization_tech_guest': ['vmm'],
                            'virtualization_tech_host': [],
                          }

    class TestVirtualSysctlDetectionMixin:
        def __init__(self):
            self.sysctl_path = '/usr/sbin/sysctl'
        def get_bin_path(self, *args, **kwargs):
            return self.sysctl_path
        def run_command(self, *args, **kwargs):
            return 0, 'OpenBSD', ''

# Generated at 2022-06-20 20:49:20.170400
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin_instance = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin_instance.sysctl_path is None

# Generated at 2022-06-20 20:49:25.522007
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(argument_spec=dict())
    mock_self = Mock()
    mock_self.module = module
    virtual_product_facts = VirtualSysctlDetectionMixin.detect_virt_product(mock_self, 'hw.product')
    assert not virtual_product_facts.has_key('virtualization_tech_guest')
    assert not virtual_product_facts.has_key('virtualization_tech_host')


# Generated at 2022-06-20 20:49:37.401672
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.virtual.other.freebsd import VirtualSysctlDetectionMixin
    virtualdetectionmixin_obj = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:49:39.244042
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.system import VirtualSysctlDetectionMixin
    v = VirtualSysctlDetectionMixin()


# Generated at 2022-06-20 20:49:51.174469
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestObject(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, bin_path):
            return '/usr/bin/' + bin_path

        def run_command(self, command):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.detect_sysctl()

    module = TestObject(0, '', '')
    test_class = TestClass(module)

    # Test KVM
    module.out = 'KVM'

# Generated at 2022-06-20 20:50:04.034673
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

    class AnsibleModuleMock(object):
        def __init__(self, out):
            self.out = out

        def get_bin_path(self, cmd):
            return '/usr/sbin/sysctl'

        def run_command(self, cmd):
            return 0, self.out, ''

    # Test with a valid value of out
    out = 'OpenBSD\n'
    mod = AnsibleModuleMock(out)
    virt_mixin = VirtualSysctlDetectionMixinMock(mod)

# Generated at 2022-06-20 20:50:14.892760
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import types
    import platform
    import os

    class TestVirtualSysctlDetectionMixin:
        """
        Class for testing the detect_virt_vendor method of the VirtualSysctlDetectionMixin class.
        """
        def detect_virt_vendor(self, key):
            return VirtualSysctlDetectionMixin.detect_virt_vendor(self, key)

        def detect_sysctl(self):
            return VirtualSysctlDetectionMixin.detect_sysctl(self)

        def get_bin_path(self, binary):
            """
            Returns the system path(s) to the binary provided
            """
            if binary == 'sysctl':
                return os.path.join(os.sep, 'sbin', binary)
            raise Exception('Unknown binary')


# Generated at 2022-06-20 20:50:22.624995
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mac = VirtualSysctlDetectionMixin()
    # test with sysctl command
    mac.sysctl_path = '/sbin/sysctl'
    mac.module = MagicMock()

    mac.detect_sysctl()
    assert mac.sysctl_path == '/sbin/sysctl'

    # test without sysctl command
    mac.sysctl_path = None
    mac.detect_sysctl()

    assert mac.sysctl_path is None

    mac.detect_virt_product('hw.model')
    mac.detect_virt_vendor('kern.vm_guest')

# Generated at 2022-06-20 20:50:33.373530
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    from sys import version_info
    from ansible.module_utils import basic
    from ansible.module_utils.facts import virtual
    from ansible.module_utils._text import to_bytes

    class TestModule(object):
        def __init__(self, sysctl_path, rc, stdout, stderr):
            self.sysctl_path = sysctl_path
            self.rc = rc
            self.stdout = stdout
            self.stderr = stderr

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.sysctl_path

        def run_command(self, cmd):
            return self.rc, self.stdout, self.stderr


# Generated at 2022-06-20 20:50:44.905681
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Set up a class whose method detect_sysctl returns
    # "/sbin/sysctl"
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    # Set up a class whose method run_command returns
    # ("0", "VirtualBox", "") for the "sysctl -n kern.vm_guest" call
    # and ("0", "1", "") for the "sysctl -n security.jail.jailed" call
    class TestModule:
        def get_bin_path(self, arg):
            return "mock_bin_path"


# Generated at 2022-06-20 20:50:52.837730
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = AnsibleModule(argument_spec={})
    detect = VirtualSysctlDetectionMixin()
    detect.module = module
    detect.sysctl_path = '/usr/bin/sysctl'
    detect.detect_virt_product('machdep.cpu.brand_string')
    detect.detect_virt_vendor('kern.vm_guest')
    module.exit_json(changed=False)

# import module snippets
from ansible.module_utils.basic import *
main()

# Generated at 2022-06-20 20:51:00.892398
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def get_bin_path(self, exe):
            return "/usr/bin/" + exe
    fMODULE = FakeModule()
    fVIRT = VirtualSysctlDetectionMixin()
    fVIRT.module = fMODULE
    fVIRT.detect_sysctl()
    assert fVIRT.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-20 20:51:29.046087
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    FakeModule = type('FakeModule', (), {})
    FakeModule.sudo = False
    FakeModule.get_bin_path = lambda self, arg: arg

    class FakeCmdDiff:
        rc = 0
        stdout = 'fake stdout'
        stderr = 'fake stderr'

    FakeCmdRunner = type('FakeCmdRunner', (), {'run_command': lambda self, cmd: FakeCmdDiff})

    class FakeVirtSysctl:
        def __init__(self, module):
            module = FakeModule()
            cmdrunner = FakeCmdRunner()
            module.run_command = cmdrunner.run_command

        detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl

    virtualSysctl = FakeVirtSysctl(FakeModule)
    virtualSysctl.detect_sysctl()

# Generated at 2022-06-20 20:51:34.531105
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    test_obj = OpenBSDVirtual()
    test_obj.module = FakeModule()
    test_obj.detect_sysctl()
    assert test_obj.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:51:46.278067
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import sys
    import os

    script_dir = os.path.join(
        os.path.dirname(os.path.realpath(__file__)),
        os.path.pardir,
        os.path.pardir,
        'unit'
    )
    sys.path.insert(0, script_dir)
    from shared.module_utils.net_tools.nios import VirtualSysctlDetectionMixin
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = "/usr/local/sbin/sysctl"

    # Test with sysctl installed
    obj.detect_sysctl()
    assert obj.sysctl_path == "/usr/local/sbin/sysctl"

    # Test with sysctl not installed
    obj.sysctl_path = None
    obj.detect_

# Generated at 2022-06-20 20:51:54.473718
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Create a dummy file to be used as sysctl
    import os
    sysctl_filename = "test_sysctl"
    open(sysctl_filename, "a").close()

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )

    virtual_vendor_facts = VirtualSysctlDetectionMixin()
    virtual_vendor_facts.module = module
    virtual_vendor_facts.sysctl_path = sysctl_filename

    # Test Role and Type
    result = virtual_vendor_facts.detect_virt_vendor("vm.vmm.vendor")
    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'

    # Test set
    result = virtual_vendor_facts.det

# Generated at 2022-06-20 20:52:04.536035
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Create object
    class MockedModule(object):
        """ fake AnsibleModule class """
        def __init__(self, *args, **kwargs):
            self.params = []

        def fail_json(self, *args, **kwargs):
            """ fail method """
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            out = ''
            if ' -n security.bsd.see_other_uids' in cmd:
                out = 'OpenBSD'
            return 0, out, ''
    module = MockedModule()

    # Create VirtualSysctlDetectionMixin object
    virt_obj = VirtualSysctlDetectionMixin()

    # Assign module to object

# Generated at 2022-06-20 20:52:14.001938
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test = VirtualSysctlDetectionMixin()
    # pylint: disable=protected-access
    test.sysctl_path = '/sbin/sysctl'
    test.detect_sysctl()
    assert test.sysctl_path == '/sbin/sysctl'

    test.module = FakeAnsibleModule()
    test.module.run_command = lambda x: (0, '', '')
    test.module.get_bin_path = lambda x: '/sbin/sysctl'
    test.detect_sysctl()
    assert test.sysctl_path == '/sbin/sysctl'

    test.detect_virt_product('hw.model')
    assert test.sysctl_path == '/sbin/sysctl'

    test.detect_virt_vendor('kern.vm_guest')

# Generated at 2022-06-20 20:52:19.763587
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert isinstance(virtual_sysctl_detection_mixin, VirtualSysctlDetectionMixin)


# Generated at 2022-06-20 20:52:28.650300
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import ansible.utils.virtual_facts as virtual_facts
    v = virtual_facts.BaseVirtualFacts()
    vc = VirtualSysctlDetectionMixin()
    assert not hasattr(vc, 'sysctl_path')
    vc.detect_sysctl()
    assert hasattr(vc, 'sysctl_path')
    assert vc.sysctl_path is not None
    assert hasattr(vc, 'virtual_facts')

    # test detect_virt_product
    vp = vc.detect_virt_product('hw.model')
    assert 'virtualization_type' in vp
    assert 'virtualization_role' in vp

    # test detect_virt_vendor
    vv = vc.detect_virt_vendor('hw.machine')
    assert 'virtualization_type' in v

# Generated at 2022-06-20 20:52:42.264227
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestModule(object):
        def __init__(self, params=None, module=None):
            if params:
                self.params = params
            else:
                self.params = dict()
            if module:
                self.module = module
            else:
                self.module = None

        def run_command(self, cmd, check_rc=True):
            if cmd == '%s -n %s' % (self.params['sysctl_path'], self.params['key_to_test']):
                if self.params['key_to_test'] == 'kern.bootfile':
                    return 0, self.params['output_to_test'], None
                if self.params['key_to_test'] == 'hw.model':
                    return 0, self.params['output_to_test'], None


# Generated at 2022-06-20 20:52:53.478382
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    os_data = {
        'kernel': 'FreeBSD',
    }
    for case_name in ['host', 'guest']:
        virtual_product_facts = {}
        module_args = {}
        if case_name == 'guest':
            module_args['key'] = 'kern.vm_guest'
        else:
            module_args['key'] = 'kern.vm_guest'
        setattr(VirtualSysctlDetectionMixin, 'module', MagicMock(return_value=''))
        setattr(VirtualSysctlDetectionMixin, 'run_commands', MagicMock(return_value=''))
        setattr(VirtualSysctlDetectionMixin, 'get_bin_path', MagicMock(return_value='sysctl'))
        virtual_product_facts = VirtualSysctlDet

# Generated at 2022-06-20 20:53:41.704102
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    result = {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    assert(VirtualSysctlDetectionMixin.detect_virt_vendor('test_VirtualSysctlDetectionMixin', 'hw.model') == result)


# Generated at 2022-06-20 20:53:48.540797
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
            self.result = {'rc': 0, 'stdout': "", 'stdout_lines': []}
            self.bin_path = None

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, cmd):
            if self.params['run_command_rc'] == 0:
                if self.params['run_command_out_value'] == "Hyper-V":
                    self.result['stdout'] = "Hyper-V"
                elif self.params['run_command_out_value'] == "VirtualBox":
                    self.result['stdout'] = "VirtualBox"

# Generated at 2022-06-20 20:53:57.775028
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MyFactCollector(VirtualSysctlDetectionMixin,
                          BaseFactCollector):
        def __init__(self, module):
            self.module = module

    # Sample output of sysctl
    class fake_module:
        class fake_run_command:
            def __init__(self, out):
                self.out = out
            def __call__(self, args):
                rc = 0
                err = ''
                if args == 'sysctl -n machdep.cpu.vendor':
                    rc = 0
                    out = self.out
                if args == 'sysctl -n machdep.cpu.brand_string':
                    rc = 0

# Generated at 2022-06-20 20:54:02.504220
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    test_class = TestClass(module)
    test_class.detect_sysctl()

    assert test_class.sysctl_path is not None


# Generated at 2022-06-20 20:54:03.565161
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # TODO: Unit test detect_virt_product
    pass


# Generated at 2022-06-20 20:54:14.356110
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            assert cmd == '/sbin/sysctl -n machdep.cpu.brand_string'
            return (0, 'QEMU Virtual CPU version 2.5+', None)

    assert VirtualSysctlDetectionMixin()._detect_virt_product(MockModule(), 'machdep.cpu.brand_string') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(),
    }


# Generated at 2022-06-20 20:54:21.576113
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    v = VirtualSysctlDetectionMixin()
    sysctl_path = '/bin/sysctl'
    v.sysctl_path = sysctl_path
    facts = {'ansible_product_name': 'OpenBSDs'}
    rc_out_err = (0, 'OpenBSD', '')
    facts['virtualization_tech_guest'] = set()
    if v.sysctl_path:
        rc_result, out_result, err_result = v.module.run_command("%s -n %s" % (sysctl_path, 'vm.vmm.vendor'))
    if rc_result == 0:
        if out_result.rstrip() == 'QEMU':
            facts['virtualization_tech_guest'].add('kvm')

# Generated at 2022-06-20 20:54:27.704606
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MockModule(object):
        def get_bin_path(self, name):
            return '/bin/%s' % (name)

    class FakeVirt(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.module = MockModule()
            self.sysctl_path = None

    virt = FakeVirt()
    assert virt.sysctl_path == '/bin/sysctl'


# Generated at 2022-06-20 20:54:38.323492
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual import VirtualCollector

    class FakeVirt(VirtualCollector,VirtualSysctlDetectionMixin):
        def __init__(self, module, sysctl_path=None):
            self.module = module
            self.sysctl_path = sysctl_path
        def run(self, module):
            return self.detect_virt_vendor('hw.model')

    class FakeModule:
        def __init__(self, sysctl_path):
            self.params = {}
            self.sysctl_path = sysctl_path

    class FakeCmd:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out

# Generated at 2022-06-20 20:54:44.571081
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    key = 'hw.model'
    out = 'OpenBSD'
    module = MockModule()
    facts = VirtualSysctlDetectionMixin()
    facts.module = module
    virtual_vendor_facts = facts.detect_virt_vendor(key)
    assert virtual_vendor_facts['virtualization_type'] == 'vmm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-20 20:56:31.507615
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def get_bin_path(self, name):
            if name == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None
        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n hw.vendor':
                return (0, 'QEMU', '')
            elif cmd == '/sbin/sysctl -n hw.product':
                return (0, 'QEMU', '')
            elif cmd == '/sbin/sysctl -n security.jail.jailed':
                return (0, '0', '')
            elif cmd == '/sbin/sysctl -n security.jail.host_hostname':
                return (0, '', '')

# Generated at 2022-06-20 20:56:36.280251
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Instantiate a TestFixture.
    fixture = TestFixture()
    # Create a VirtualSysctlDetectionMixin instance.
    obj = VirtualSysctlDetectionMixin()
    # Call the detect_sysctl method.
    obj.detect_sysctl()
    # Assert the sysctl_path returned by the detect_sysctl method equals the
    # sysctl_path on the TestFixture instance.
    assert obj.sysctl_path == fixture.sysctl_path


# Generated at 2022-06-20 20:56:45.230447
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from sys import version_info
    if version_info[0] == 2:
        # Python 2.x
        from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    else:
        # Python 3.x
        from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    o = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:56:54.836271
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    assert m.detect_virt_vendor({'system': 'OpenBSD'}) == {'virtualization_tech_guest': set(['vmm']), 'virtualization_role': 'guest', 'virtualization_type': 'vmm', 'virtualization_tech_host': set([])}
    assert m.detect_virt_vendor({'system': 'QEMU'}) == {'virtualization_tech_guest': set(['kvm']), 'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_host': set([])}

# Generated at 2022-06-20 20:57:07.623021
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FauxModule():
        def get_bin_path(self, bin):
            return bin

        def run_command(self, cmd):
            if cmd == 'sysctl -n kern.vm_guest':
                return (0, 'QEMU', '')
            if cmd == 'sysctl -n security.jail.jailed':
                return (0, '0', '')
            if cmd == 'sysctl -n kern.hostname':
                return (0, 'hostname', '')
    class FauxSysctl():
        def detect_sysctl(self):
            pass
    class FauxThis():
        pass
    this = FauxThis()
    setattr(this, 'module', FauxModule())

    this.sysctl_path = FauxSysctl()
    test_class = VirtualSysctlDet

# Generated at 2022-06-20 20:57:16.813401
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    o = VirtualSysctlDetectionMixin()
    o.module = type('AnsibleModule', (object,), dict(params=dict(),
                                                    run_command=lambda self, cmd: (0, 'OpenBSD', None)))()
    assert 'virtualization_type' in o.detect_virt_vendor('machdep.fakekpi.vendor')
    assert 'virtualization_role' in o.detect_virt_vendor('machdep.fakekpi.vendor')
    assert 'virtualization_tech_guest' in o.detect_virt_vendor('machdep.fakekpi.vendor')
    assert 'virtualization_tech_host' in o.detect_virt_vendor('machdep.fakekpi.vendor')


# Generated at 2022-06-20 20:57:27.564548
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    sysctl_path = 'usr/bin/sysctl'
    sysctl_path_fact = dict(sysctl_path=sysctl_path)

    class TestModule(object):
        def is_freebsd(self):
            return True

        def get_bin_path(self, name):
            return sysctl_path

        def run_command(self, command):
            if sysctl_path not in command:
                raise AssertionError('Unexpected command %s %s' % (
                    sysctl_path, command))
            return 0, '', ''

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    tc = TestClass(TestModule())
    tc.detect_sysctl()

    assert tc.sysctl_path == sysctl

# Generated at 2022-06-20 20:57:35.121362
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = MockModule()
    test_object.module.run_command = Mock(return_value=(0, 'QEMU', ''))
    virtual_vendor_facts = test_object.detect_virt_vendor('machdep.cpu.brand_string')
    assert virtual_vendor_facts == dict(virtualization_type='kvm',
                                        virtualization_role='guest',
                                        virtualization_tech_host=set(),
                                        virtualization_tech_guest={'kvm'})


# Generated at 2022-06-20 20:57:45.742105
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.collector import BaseFactCollector

    class SysctlMockModule(AnsibleModule):
        def __init__(self):
            self.params = {}
            self.exit_args = {}
            super(SysctlMockModule, self).__init__(
                argument_spec={},
                supports_check_mode=True
            )

    class VirtualSysctlDetectionMixinImpl(VirtualSysctlDetectionMixin, BaseFactCollector):
        def __init__(self, module, name, always_run=False):
            super(VirtualSysctlDetectionMixinImpl, self).__init__(module=module, name=name)

        def collect(self, module=None, collected_facts=None):
            return

# Generated at 2022-06-20 20:57:57.380805
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = MockModule()

    sysctl_path = 'sysctl'
    key = 'machdep.hypervisor'
    out = 'QEMU'
    err = ''
    rc = 0
    vm = VirtualSysctlDetectionMixin()
    vm.module = module
    vm.sysctl_path = sysctl_path

    #
    # test product QEMU
    #
    module.run_command.return_value = (rc, out, err)

    vendor_facts = vm.detect_virt_vendor(key)
    assert vendor_facts.get('virtualization_tech_guest') == set(['kvm'])
    assert vendor_facts['virtualization_type'] == 'kvm'
    assert vendor_facts['virtualization_role'] == 'guest'
