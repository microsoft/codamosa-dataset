

# Generated at 2022-06-20 20:48:15.824882
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_object = VirtualSysctlDetectionMixin()
    assert test_object

# Generated at 2022-06-20 20:48:25.827325
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(
        argument_spec=dict()
    )

    class TestFreebsdFactCollector(object):
        def __init__(self, module):
            self.module = module

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    test_collector = TestFreebsdFactCollector(module)
    test_sysctl_detection_mixin = TestVirtualSysctlDetectionMixin(module)

    virt_vendor_facts = test_sysctl_detection_mixin.detect_virt_vendor('security.jail.host.hostuuid')

    assert not virt_vendor_facts['virtualization_type']
    assert not virt_vendor_facts['virtualization_role']

# Generated at 2022-06-20 20:48:30.874961
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    assert isinstance(virtual_sysctl_detection_mixin, object)

# Generated at 2022-06-20 20:48:34.636613
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    inst = VirtualSysctlDetectionMixin()
    result = inst.detect_virt_product('hw.model')
    print(result)


# Generated at 2022-06-20 20:48:46.614163
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from units.compat.mock import MagicMock
    from units.compat.mock import Mock
    from ansible.modules.system.openbsd import VirtualSysctlDetectionMixin

    class OpenBSD(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.run_command = MagicMock(return_value=(0, 'QEMU', ''))
            self.module = Mock()
            self.module.get_bin_path = MagicMock(return_value='/bin/sysctl')

    openbsd = OpenBSD()
    openbsd.detect_virt_vendor('hw.model')
    assert openbsd.run_command.call_count == 1
    assert openbsd.module.get_bin_path.call_count == 1
    assert openbsd.virtual

# Generated at 2022-06-20 20:48:51.235168
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    module = TestModule()
    module.detect_sysctl()
    assert module.sysctl_path == '/sbin/sysctl', 'sysctl path should be /sbin/sysctl'

# Generated at 2022-06-20 20:49:02.216629
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils import basic
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual import OpenBSDVirtual
    from ansible.module_utils.facts.virtual import OpenBSDVmmHost
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    mixin_obj = VirtualSysctlDetectionMixin()
    mixin_obj.detect_sysctl()
    mixin_obj.module = module

    virtual_vendor_facts = {}
    virtual_product_facts = {}

    if mixin_obj.sysctl:
        # Using Vmware as hypervisor
        set_obj = set()
        set_obj.add('kvm')

# Generated at 2022-06-20 20:49:04.491525
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # create an instance of VirtualSysctlDetectionMixin
    v = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:49:14.665611
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def run_command(self, command):
            out = ''
            if command.endswith("security.jail.jailed"):
                out = '1'
            if command.endswith("hw.model"):
                out = 'XenPVHVM'
            if command.endswith("machdep.hypervisor_name"):
                out = 'VMware'
            if command.endswith("kern.vm_guest"):
                out = 'OpenBSD'
            return (0, out, '')
        def get_bin_path(self, command):
            return '/sbin/sysctl'

    tm = TestModule()

# Generated at 2022-06-20 20:49:15.539208
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:49:42.915441
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class BSDModule(object):
        def __init__(self):
            self._sysctl_path = None

        def get_bin_path(self, name, *args, **kwargs):
            # This function is mocked in tests, but we still call it to actually
            # test this method.
            return self._sysctl_path

        def run_command(self, cmd):
            return 0, "", ""

    class OS(VirtualSysctlDetectionMixin, BSDModule):
        pass

    bsdobj = OS()

    bsdobj._sysctl_path = "/usr/bin/sysctl"
    bsdobj.detect_sysctl()

    # If sysctl is not in PATH, sysctl_path must be None
    bsdobj._sysctl_path = None
    bsdobj.detect_sysctl

# Generated at 2022-06-20 20:49:51.305865
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = {
                'get_bin_path': lambda cmd: 'sysctl'
            }
            self.module.run_command = lambda cmd: (0,'KVM\tVirtualBox','')
            self.detect_sysctl()

    test = VirtualSysctlDetectionMixin_test()

    if test.sysctl_path == 'sysctl':
        print('Unit test for method detect_sysctl in class VirtualSysctlDetectionMixin\n'
              'Test Passed')
    else:
        print('Unit test for method detect_sysctl in class VirtualSysctlDetectionMixin\n'
              'Test Failed')


# Generated at 2022-06-20 20:50:04.120303
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class ModuleStub():
        class RunCommandResult():
            def __init__(self):
                self.rc = 0
                self.out = "KVM"
                self.err = ""

        def run_command(self, cmd):
            class F():
                def read(self):
                    return "KVM"
                def close(self):
                    pass
            return self.RunCommandResult(), F(), F()

    class VirtualSysctlDetectionMixinStub(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = ModuleStub()

    virtual_detector = VirtualSysctlDetectionMixinStub()
    virtual_detector.detect_sysctl()
    assert virtual_detector.sysctl_path



# Generated at 2022-06-20 20:50:14.984328
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeAnsibleModule()
    dut = VirtualSysctlDetectionMixin()
    dut.module = module
    # We don't really have a choice but to return junk, since we're
    # mocking module.run_command, and the mixin doesn't seem to support
    # instantiating with the sysctl path passed in.
    dut.sysctl_path = 'fakedut.sysctl_path'
    module.run_command_value = (0, 'VMware', '')
    virt_facts = dut.detect_virt_product('hw.model')
    assert len(virt_facts) > 0
    assert 'virtualization_type' in virt_facts
    assert virt_facts['virtualization_type'] == 'VMware'
    assert 'virtualization_role' in virt_facts
    assert virt_facts

# Generated at 2022-06-20 20:50:17.612353
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    sysctl_path = '/sbin/sysctl'
    module = VirtualSysctlDetectionMixin()
    module.module = sysctl_path
    assert module.sysctl_path == sysctl_path

# Generated at 2022-06-20 20:50:23.260672
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin 
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = None
    mixin.sysctl_path = '/sbin/sysctl'
    rc, out, err = mixin.module.run_command("%s -n %s" % (mixin.sysctl_path, 'kern.vm_guest'))
    expected_result = {
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest'
    }
    assert mixin.detect_virt_vendor('kern.vm_guest') == expected_result

# Generated at 2022-06-20 20:50:23.845342
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    assert obj.sysctl_path is None

# Generated at 2022-06-20 20:50:34.283183
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(dict())
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.sysctl_path = 'invalid_path'

    # Test detect_virt_vendor without sysctl
    assert mixin.detect_virt_vendor('machdep.dmi.system-product-name') == {}

    # Test detect_virt_vendor with real sysctl
    mixin.detect_sysctl()
    assert 'sysctl' in mixin.sysctl_path
    import subprocess
    if not subprocess.call(['which', mixin.sysctl_path]):
        output = subprocess.check_output('%s -n machdep.dmi.system-product-name' % (mixin.sysctl_path), shell=True)

# Generated at 2022-06-20 20:50:38.701948
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_product_facts = VirtualSysctlDetectionMixin().detect_virt_product('machdep.hypervisor')
    assert(virtual_product_facts['virtualization_type'] == 'jails')


# Generated at 2022-06-20 20:50:43.417929
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    #
    # This is a stub. Only used by the unit tests.
    #
    # NOTE: this stub was generated by hand, because Python stdlib
    # mock.patch.object doesn't work well in this case, probably due to
    # mixins
    #
    class SysModuleMock():
        def __init__(self):
            pass

        def get_bin_path(self, bin_path):
            return True

    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = ''
            self.module = SysModuleMock()

    obj = VirtualSysctlDetectionMixinMock()

# Generated at 2022-06-20 20:51:27.464929
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    '''Unit test for _detect_sysctl of VirtualSysctlDetectionMixin'''
    import sys
    import platform
    import os
    from ansible.module_utils.facts import ModuleFactCollector

    # Inits
    test_mixin = VirtualSysctlDetectionMixin()
    test_spec = {'platform': platform.system()}
    test_module = ModuleFactCollector(None, None, test_spec)
    if test_module.ops == 'windows':
        # In this case we do not have sysctl, we need to set 'sysctl_path' to None
        # before calling the method to be tested, because it is not directly
        # settable
        test_mixin.sysctl_path = None

# Generated at 2022-06-20 20:51:39.788960
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def run_command(self, args):
            return (0, 'Hyper-V', '')

        def get_bin_path(self, arg):
            return '/bin/sysctl'

    class FakeInheritedClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    fake_module = FakeModule()
    fake_inherited_class = FakeInheritedClass(fake_module)
    result = fake_inherited_class.detect_virt_product('machdep.hyperviso')
    assert result['virtualization_type'] == 'Hyper-V'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_host'] == set()

# Generated at 2022-06-20 20:51:50.582343
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    class FakeModule:
        def __init__(self, *args, **kwargs):
            args = ()
            self.params = kwargs

            # hack to make unit test work for both of our classes
            if 'base' in self.params:
                self.base = self.params['base']

        def get_bin_path(self, *args, **kwargs):
            class FakeBinPath:
                def __init__(self, *args, **kwargs):
                    self.rc = 0
                    self.stdout = 'QEMU'
                    self.stderr = ''

            return FakeBinPath()

        def run_command(self, *args, **kwargs):

            class FakeRunCommand:
                def __init__(self, *args, **kwargs):
                    self.rc = 0
                    self

# Generated at 2022-06-20 20:51:59.243199
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    module_args = dict(
        executable="/usr/bin/sysctl",
    )

    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    virt = VirtualSysctlDetectionMixin()
    virt.module = module
    result = virt.detect_sysctl()

    assert result == "/usr/bin/sysctl"


# Generated at 2022-06-20 20:52:10.294560
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection = VirtualSysctlDetectionMixin()
    class FakeModule:
        class RunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run(self, cmd):
                return (self.rc, self.out, self.err)

        def test_sub_command(self, run_cmd):
            self.run_command = run_cmd

        def get_bin_path(self, path):
            if path == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        def __init__(self):
            self.run_command = None

    virtual_sysctl_detection.module = FakeModule()
    # Test detection of sysctl command


# Generated at 2022-06-20 20:52:16.890626
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Module(object):
        def __init__(self):
            self.run_command_stat = 0
            self.run_command_out = 'QEMU'
            self.run_command_err = ''
        def get_bin_path(self, arg):
            return '/sbin/sysctl'
        def run_command(self, arg):
            return (self.run_command_stat, self.run_command_out, self.run_command_err)

    class VirtualSysctlDetectionMixin(object):
        def __init__(self):
            self.module = Module()

    v = VirtualSysctlDetectionMixin()
    out = v.detect_virt_vendor('hw.model')
    assert out['virtualization_tech_guest'] == set(['kvm'])
    assert out

# Generated at 2022-06-20 20:52:18.794171
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # TODO: assert values properly
    VirtualSysctlDetectionMixin().detect_sysctl()


# Generated at 2022-06-20 20:52:28.119953
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    setattr(VirtualSysctlDetectionMixin, 'module', object())
    setattr(VirtualSysctlDetectionMixin.module, 'run_command', None)
    setattr(VirtualSysctlDetectionMixin.module, 'get_bin_path', None)
    obj = VirtualSysctlDetectionMixin()
    obj.detect_sysctl = lambda: setattr(obj, 'sysctl_path', 'sysctl')
    obj.module.run_command = lambda *args: [0, 'KVM', '']
    assert obj.detect_virt_product('machdep.dmi.system-product-name') == {'virtualization_role': 'guest', 'virtualization_type': 'kvm', 'virtualization_tech_guest': {'kvm'}, 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:52:32.394304
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.openbsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.openbsd import OpenBSDHardware

    hardware_instance = OpenBSDHardware()
    virtual_instance = VirtualSysctlDetectionMixin()

    hardware_instance.detect_sysctl = virtual_instance.detect_sysctl
    hardware_instance.detect_sysctl()

    assert hardware_instance.sysctl_path is not None


# Generated at 2022-06-20 20:52:41.137549
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """
    The method detects the virtualization_type and virtualization_role
    when the `sysctl -n kern.vm_guest` gives the expected values.
    """
    module = openbsd_common.OpenBSDGenericModule()
    setattr(module, 'run_command', mock_run_command)
    virtual_system_facts = openbsd_virtual.OpenBSDVirtual(module)
    virtualization_facts = virtual_system_facts.detect_virt_product('kern.vm_guest')
    assert virtualization_facts['virtualization_type'] == 'jails' and virtualization_facts['virtualization_role'] == 'guest'
    virtualization_facts = virtual_system_facts.detect_virt_product('kern.somestupidvalue')
    assert virtualization_facts['virtualization_type']

# Generated at 2022-06-20 20:53:32.062270
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import os
    import imp
    import platform
    import struct

    class OSDetectionFake(object):
        def __init__(self, *args, **kwargs):
            self.system_major_version = platform.release()

    # We cheat a bit here and make a class that has the same
    # methods as module_utils.basic.AnsibleModule, so we can
    # have a basic flow for our tests
    class AnsibleFakeModule(object):

        def __init__(self, *args, **kwargs):
            self.params = {}
            self.facts = {}
            self.deprecations = []
            self.os_detection = OSDetectionFake()


# Generated at 2022-06-20 20:53:38.696080
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class VirtSysctlDetectionMixinTest():
        __metaclass__ = VirtualSysctlDetectionMixin
        module = None

    virt_sysctl_detection_mixin_test = VirtSysctlDetectionMixinTest()
    assert virt_sysctl_detection_mixin_test


# Generated at 2022-06-20 20:53:39.688724
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VSDM = VirtualSysctlDetectionMixin()
    assert VSDM.sysctl_path is None

# Generated at 2022-06-20 20:53:48.099941
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts

    class TestVirtualFacts(VirtualFacts, VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.sysctl_path = 'sysctl'
            VirtualSysctlDetectionMixin.__init__(self, *args, **kwargs)
            VirtualFacts.__init__(self, *args, **kwargs)


# Generated at 2022-06-20 20:53:58.364148
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts import virtual
    class AnsibleModule:
        def get_bin_path(self, cmd):
            return "/bin/sysctl"
        def run_command(self, *args, **kwargs):
            return 0, "", ""
    sysctl_detector = virtual.VirtualSysctlDetectionMixin()
    sysctl_detector.module = AnsibleModule()
    sysctl_detector.detect_sysctl()
    assert sysctl_detector.sysctl_path == "/bin/sysctl"

# Generated at 2022-06-20 20:54:05.950686
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class _module(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, _):
            return '/sbin/sysctl'

        def fail_json(self, msg):
            raise AssertionError(msg)

        def run_command(self, cmd):
            if cmd == "/sbin/sysctl -n hw.model":
                return 0, "QEMU", ''
            return 1, '', ''

    class _FactsCollector(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = _module()
    fact_collector = _FactsCollector(module)

# Generated at 2022-06-20 20:54:20.823384
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from collections import namedtuple
    from ansible.module_utils.six import b
    from ansible.module_utils.facts import VirtualMachine

    TestVirtualSysctlDetectionMixin = namedtuple('TestVirtualSysctlDetectionMixin', 'sysctl_path')
    test_VirtualSysctlDetectionMixin = TestVirtualSysctlDetectionMixin(sysctl_path='/sbin/sysctl')
    test_VirtualSysctlDetectionMixin.module = VirtualMachine()
    test_VirtualSysctlDetectionMixin.module.run_command = lambda cmd: (0, b('QEMU'), b(''))
    test_virtual_vendor_facts = test_VirtualSysctlDetectionMixin.detect_virt_vendor('hw.model')

# Generated at 2022-06-20 20:54:26.416316
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    v = VirtualSysctlDetectionMixin()

    v.detect_sysctl = lambda: 'test_sysctl'
    v.module = lambda: None
    v.module.get_bin_path = lambda s: s
    v.module.run_command = lambda s, s2: ('test_rc', 'test_out', 'test_err')

    v.detect_virt_product('test_key')
    v.detect_virt_vendor('test_key')

# Generated at 2022-06-20 20:54:37.664415
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class MockModule:
        def get_bin_path(self, bin):
            return bin
        def run_command(self, cmd):
            return 0, "KVM", ""

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    v = MockVirtualSysctlDetectionMixin()
    v.detect_virt_product('')
    assert v.sysctl_path == "sysctl"
    assert v.facts['virtualization_type'] == "kvm"
    assert v.facts['virtualization_role'] == "guest"
    assert v.facts['virtualization_tech_guest'] == set(['kvm'])
    assert v.facts['virtualization_tech_host'] == set()

# Unit

# Generated at 2022-06-20 20:54:44.632793
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():

    module = AnsibleModule(argument_spec={})

    class FakeVirtCustom:
        def __init__(self):
            self.module = module

    custom_virt = FakeVirtCustom()
    test_virt = VirtualSysctlDetectionMixin()
    for base in VirtualSysctlDetectionMixin.__bases__:  # pylint: disable=not-an-iterable
        setattr(test_virt, base.__name__, base(custom_virt))
    test_virt.module = module
    test_virt.detect_sysctl()
    assert test_virt.sysctl_path

# Generated at 2022-06-20 20:56:37.530354
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # test defined variables
    test_class = VirtualSysctlDetectionMixin()
    expected = {'virtualization_technologies_guest': ['AMAZON'],
                'virtualization_technologies_host': [],
                'virtualization_type': 'AMAZON',
                'virtualization_role': 'guest'}
    test_results = test_class.detect_virt_product('machdep.cpu.vendor')
    assert test_results == expected
    # test undefined variables
    test_class = VirtualSysctlDetectionMixin()
    expected = {'virtualization_technologies_guest': [],
                'virtualization_technologies_host': []}
    test_results = test_class.detect_virt_product('machdep.cpu.vendor')
    assert test_results == expected



# Generated at 2022-06-20 20:56:49.108002
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import types

    class TestModule(types.ModuleType):
        def __init__(self):
            self.sysctl_path = None
            self.parms = {}

        def get_bin_path(self, binary):
            return self.sysctl_path

        def run_command(self, command_args):
            if command_args == '%s -n %s' % (self.sysctl_path, self.parms['key']):
                return (0, '', '')
            else:
                raise Exception('Unexpected command args %s' % command_args)

    test_module = TestModule()
    test_module.sysctl_path = '/sbin/sysctl'

    class TestBase(object):
        def __init__(self, module):
            self.module = module

    test_base = Test

# Generated at 2022-06-20 20:56:56.972558
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinImplementation(VirtualSysctlDetectionMixin):
        def __init__(self, sysctl_path):
            self.sysctl_path = sysctl_path

    sut = VirtualSysctlDetectionMixinImplementation('/sbin/sysctl')
    result = sut.detect_virt_vendor('machdep.cpu_vendor')

    assert 'kvm' in result['virtualization_tech_guest']
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'kvm'


# Generated at 2022-06-20 20:57:08.323896
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    v = VirtualSysctlDetectionMixin()
    v.sysctl_path = '/sbin/sysctl'
    v.module = DummyModule()
    v.module.run_command = run_command
    facts = v.detect_virt_vendor('kern.vm_guest')
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host'] == set()
    assert facts['virtualization_tech_guest'] == set(['vmm'])

    facts = v.detect_virt_vendor('hw.vendor')
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_tech_host']

# Generated at 2022-06-20 20:57:10.609593
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    results = VirtualSysctlDetectionMixin()
    assert results



# Generated at 2022-06-20 20:57:20.890255
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDModule
    class MyVirtualModule:
        def get_bin_path(self, arg):
            return None
    myvirtual = VirtualFreeBSDModule()
    myvirtual.module = MyVirtualModule()
    myvirtual.detect_sysctl()
    assert myvirtual.sysctl_path is None

# Generated at 2022-06-20 20:57:34.030352
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == "/sbin/sysctl -n hw.product":
                return 0, "OpenBSD", ''
            elif cmd == "/sbin/sysctl -n kern.vm_guest":
                return 0, "QEMU", ''
            else:
                return 1, "", 'Command not found.'

    # Mock of a guest machine running OpenBSD under vmm
    mm = MockModule()
    fc = VirtualSysctlDetectionMixin()
    fc.module = mm

# Generated at 2022-06-20 20:57:45.100306
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return 'sysctl'

        def run_command(self, *args, **kwargs):
            if args[0] == 'sysctl -n hw.model':
                return 0, 'Your-CPU-brand-here (12)-Your-model-here (41) @ 2.224 GHz', ''
            if args[0] == 'sysctl -n security.jail.jailed':
                return 0, '1', ''
            if args[0] == 'sysctl -n kern.vm_guest':
                return 0, 'FreeBSD', ''

# Generated at 2022-06-20 20:57:50.448583
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from distutils.spawn import find_executable
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualFreeBSDFactCollector
    from ansible.module_utils.facts import __virtualname__
    from ansible.module_utils.facts.system import virtual
    import sys
    import os
    import tempfile
    import shutil
    import pytest

    facts_collector = virtual.collect_virtual_facts()
    if __virtualname__ not in facts_collector:
        pytest.skip("virtual facts module is not supported on this platform")

    # Skip if sysctl is unavailable
    if not find_executable('sysctl'):
        pytest.skip("sysctl is not available on this platform")

    # Create a temporary directory
    temp_dir = tempfile.mkdtemp()

    # Create

# Generated at 2022-06-20 20:58:01.554389
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    import os
    import __builtin__
    import types

    class mock_module:
        def __init__(self):
            self.params = {'path': ['/bin', '/sbin']}
            self._name = 'module'
        def fail_json(self, **kwargs):
            pass
        def get_bin_path(self, name, **kwargs):
            try:
                self.bin_path = os.path.join(self.params['path'][0], name)
                return os.path.join(self.params['path'][0], name)
            except:
                return None