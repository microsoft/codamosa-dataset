

# Generated at 2022-06-20 20:48:27.193575
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """ Testing VirtualSysctlDetectionMixin.detect_virt_product """
    import sys
    sys.path.append('/Users/shady/git/ansible')

    # we create a mock module class
    class MyAnsibleModule(object):
        """ Mock module for this unit test """
        def __init__(self, argument_spec, bypass_checks=False, no_log=False,
                     check_invalid_arguments=True, mutually_exclusive=None,
                     required_together=None, required_one_of=None, add_file_common_args=False,
                     supports_check_mode=False):
            self.argument_spec = argument_spec
            self.params = {}

        def fail_json(self, *args, **kwargs):
            """ Mock method for fail_json """
            self.exit

# Generated at 2022-06-20 20:48:39.447609
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Test for any known jvm type
    params = {'security.jail.jailed': '1'}
    virtual_product_facts = VirtualSysctlDetectionMixin().detect_virt_product(params['security.jail.jailed'])
    assert virtual_product_facts['virtualization_type'] == 'jails'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    virtualization_tech_guest = set(['jails'])
    assert virtualization_tech_guest == virtual_product_facts['virtualization_tech_guest']
    assert virtual_product_facts['virtualization_tech_host'] == None

    # Test for unknown jvm type
    params = {'security.jail.jailed': '0'}
    virtual_product_facts = VirtualSysctlDetection

# Generated at 2022-06-20 20:48:51.147798
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class SysctlModule:
        def get_bin_path(self, command):
            if command == 'sysctl':
                return 'sysctl'

        def run_command(self, command):
            if command == 'sysctl -n kern.brand':
                return 'HVM domU', '', ''
            elif command == 'sysctl -n kern.hostname':
                return 'OpenBSD', '', ''
            elif command == 'sysctl -n security.jail.jailed':
                return '1', '', ''
            elif command == 'sysctl -n security.jail.param.host.hostname':
                return 'foo.example.org', '', ''
            else:
                return '', '', ''

    sysctlModule = SysctlModule()
    facts = VirtualSysctlDetectionMixin

# Generated at 2022-06-20 20:49:01.700318
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule:
        class MockRunCommand:
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out.strip()
                self.err = err
            def run(self, cmd, cwd=None, environ=None, data=None):
                return (self.rc, self.out, self.err)
        def __init__(self):
            self.get_bin_path = lambda x : "/sbin/sysctl"
            self.run_command = MockRunCommand(0, "QEMU", "")
    o = VirtualSysctlDetectionMixin()
    o.module = MockModule()
    o.detect_virt_vendor('hw.model')
    assert o.module.run_command.rc == 0
    assert o.module.run

# Generated at 2022-06-20 20:49:03.048642
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:49:14.004442
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule:
        def __init__(self):
            self.run_command = lambda a, b: (0, 'OpenBSD', '')
    class MockFacts:
        pass
    mock_facts = MockFacts()
    mock_module = MockModule()
    virtual_sysctl_detection_mixin_obj = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_obj.module = mock_module
    virtual_sysctl_detection_mixin_obj.facts = mock_facts
    virtual_sysctl_detection_mixin_obj.detect_sysctl = lambda: None
    virtual_sysctl_detection_mixin_obj.detect_virt_vendor('hw.model')

# Generated at 2022-06-20 20:49:25.088635
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestParams(object):
        def __init__(self):
            self.module = object()

    class TestModule(object):
        def __init__(self):
            self.params = TestParams()
            self.run_command = lambda: (0, 'VirtualBox', '')
            self.get_bin_path = lambda: '/sbin/sysctl'

    test = VirtualSysctlDetectionMixin()
    test.module = TestModule()
    assert test.sysctl_path == '/sbin/sysctl'
    assert test.detect_virt_product('hw.model').get('virtualization_tech_guest') == set(['virtualbox'])

# Generated at 2022-06-20 20:49:33.431883
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestModule(object):
        def get_bin_path(self, arg):
            return '/bin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM log', ''

    test_module = TestModule()
    test_class = VirtualSysctlDetectionMixin()

    assert test_class.detect_sysctl(test_module) == '/bin/sysctl'
    assert test_class.detect_virt_product(test_module, 'hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    assert test_class.detect_virt_vendor(test_module, 'hw.model') == {}

if __name__ == '__main__':
    test_VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:49:41.172938
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.collector.os import OpenBSDOpenRCFactCollector

    for key in ('hw.model', 'machdep.dmi.system-manufacturer'):
        for out in ('VirtualBox', 'RHEV Hypervisor', 'XenPVVM', 'HVM domU', 'VMware', 'KVM', 'Bochs', 'SmartDC'):
            mixin = VirtualSysctlDetectionMixin()
            mixin.module = OpenBSDOpenRCFactCollector({}, {}, {})
            mixin.sysctl_path = "/sbin/sysctl"
            mixin.module.run_command = lambda x: (0, out, '')
            virtual_product_facts = mixin.detect_virt_product(key)
            assert 'virtualization_type' in virtual_product_

# Generated at 2022-06-20 20:49:51.265036
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.modules.system.setup import setup_freebsd
    from ansible.module_utils.facts.base_facts import BaseFactsModule, BaseFactCollector

    class MockModule(object):
        def get_bin_path(self, executable):
            return '/usr/bin/sysctl'

        def run_command(self, command):
            return 0, 'This is a test', None

    class MockFactsModule(BaseFactsModule):
        def populate_facts(self, collected_facts):
            return {'ansible_facts': {'virtual_sysctl': None}}


# Generated at 2022-06-20 20:50:11.706111
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    try:
        from libvirt import openReadOnly
    except ImportError:
        return {'changed': False}

    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()
            self.sysctl_path = 'sysctl'

    mcd = MockSysctlDetectionMixin()
    assert_result = {'virtualization_type': 'kvm',
                     'virtualization_role': 'guest',
                     'virtualization_tech_guest': set(['kvm']),
                     'virtualization_tech_host': set()}

    # We check to make sure we have libvirt available whether or not we have a
    # valid connection.  This is to support the unit test running a scenario
    # where libvirt is not running.

# Generated at 2022-06-20 20:50:20.185186
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()

    class FakeModule():
        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'KVM', ''

    mixin.module = FakeModule()
    mixin.detect_sysctl()
    virtual_product_facts = mixin.detect_virt_product('hw.model')

    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virtual_product_facts['virtualization_tech_guest']
    assert len(virtual_product_facts['virtualization_tech_guest']) == 1

# Generated at 2022-06-20 20:50:27.565127
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    fact_class = VirtualSysctlDetectionMixin()

    assert fact_class.detect_virt_vendor('machdep.hypervisor') == \
        {
            'virtualization_type': 'vmm',
            'virtualization_role': 'guest',
            'virtualization_tech_guest': set(['vmm']),
            'virtualization_tech_host': set(),
        }


# Generated at 2022-06-20 20:50:37.860800
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    m = VirtualSysctlDetectionMixin()
    m.module = FakeModule()
    m.sysctl_path = True
    assert m.detect_virt_product('') == {
            'virtualization_tech_host': set([]), 
            'virtualization_tech_guest': set([])
            }
    assert m.detect_virt_product('hw.model') == {
            'virtualization_tech_host': set([]), 
            'virtualization_tech_guest': set([])
            }
    assert m.detect_virt_product('hw.model') == {
            'virtualization_tech_host': set([]), 
            'virtualization_tech_guest': set([])
            }

# Generated at 2022-06-20 20:50:49.437449
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.bsd.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.bsd.freebsd import Sysctl

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def run_command(self, cmd):
            if cmd == 'sysctl -n kern.hostuuid':
                return 0, 'fcffc80b-f386-11e5-9aae-002590d2eac8', ''
            else:
                return 1, '', ''

        def get_bin_path(self, cmd):
            return '/sbin/' + cmd

    hosts = [{'name': 'fake_host', 'ansible_facts': {}}]


# Generated at 2022-06-20 20:50:57.269788
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    sysctl_path = '/sbin/sysctl'
    m = VirtualSysctlDetectionMixin()
    m.module = MockModule(run_command=MockRunCommand(rc=0, out='', err='',
                                                     sysctl_path=sysctl_path))
    m.detect_sysctl()
    assert m.sysctl_path == sysctl_path


# Generated at 2022-06-20 20:51:08.806385
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            pass
        def run_command(self, cmd):
            return (0, 'QEMU', None)
    mixin = MockMixin()
    assert mixin.detect_virt_vendor('hw.model') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
        }
    mixin.run_command = lambda cmd: (1, None, None)

# Generated at 2022-06-20 20:51:19.785830
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass():
        def __init__(self):
            self.sysctl_path = None
            self.module = None
        def run_command(self, path):
            return 0, '', ''
    test_class = TestClass()
    test_mixin = VirtualSysctlDetectionMixin()
    test_mixin.detect_sysctl()
    test_mixin.detect_virt_product(test_class, 'testkey')
    test_mixin.detect_virt_vendor(test_class, 'testkey')

# Run test if called from command line
if __name__ == '__main__':
    test_VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:51:29.206481
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule(object):
        def run_command(self, command):
            rc = 0
            if command == '/usr/bin/sysctl -n security.jail.jailed':
                out = '0'
            elif command == '/usr/bin/sysctl -n security.jail.param.jail_name':
                out = 'BLAH'
            elif command == '/usr/bin/sysctl -n security.jail.param.jail_version':
                out = 'BLEHH'
            elif command == '/usr/bin/sysctl -n hw.model':
                out = 'VMware Virtual Platform'
            elif command == '/usr/bin/sysctl -n hw.machine_arch':
                out = 'x86_64'
            else:
                rc = -1

# Generated at 2022-06-20 20:51:41.378663
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = 'sysctl'
            self.module = FakeAnsibleModule()

    class FakeAnsibleModule:
        def __init__(self):
            self.run_command_values = [[0, 'QEMU', ''], [0, 'OpenBSD', ''], [0, '', '']]
            self.run_command_call_count = 0

        def get_bin_path(self, module_name, required=False):
            if module_name == 'sysctl':
                return 'sysctl'

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None):
            output = self.run_command_

# Generated at 2022-06-20 20:52:10.298097
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class MyVirtOpenBSD(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    module_params = dict(
        ansible_facts={},
        ansible_virtualization_type='',
        ansible_virtualization_role='',
    )
    module.params = module_params
    virt = MyVirtOpenBSD(module)

    assert virt
    assert virt.sysctl_path is None
    assert virt.detect_virt_vendor('hw.vendor') == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set(),
                                                   'virtualization_role': '', 'virtualization_type': ''}
    assert virt

# Generated at 2022-06-20 20:52:14.618099
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts import collector
    class TestClass():
        def __init__(self):
            self.sysctl_path = None
            self.module = collector
    test_class = TestClass()
    detect = VirtualSysctlDetectionMixin()
    detect.detect_sysctl()
    sysctl_path = test_class.sysctl_path = detect.sysctl_path
    assert sysctl_path.endswith('sysctl')

# vim: set et ts=4 sts=4 sw=4 :

# Generated at 2022-06-20 20:52:27.002564
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class BSDMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = "/sbin/sysctl"
            self.module = AnsibleModule(argument_spec=dict())

    mixin_obj = BSDMixin()
    import sys
    if sys.version_info[0] < 3:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.__dict__['AnsibleModule'] = AnsibleModule
    # Testing OpenBSD
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.base import VirtualFactCollector
    collect_obj = VirtualFactCollector()
    collect_obj.virtual_vendor_facts = {}
    collect_obj.virtual_vendor

# Generated at 2022-06-20 20:52:36.910952
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_object = VirtualSysctlDetectionMixin()
    test_object.sysctl_path = '/sbin/sysctl'
    test_object.module = FakeAnsibleModule()
    test_object.sysctl_path = '/sbin/sysctl'
    test_object.module.run_command = lambda x: (0, "QEMU", "")
    test_object.detect_sysctl()
    data = test_object.detect_virt_vendor('machdep.cpu.features')
    assert data['virtualization_type'] == 'kvm'


# Generated at 2022-06-20 20:52:45.534178
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import os
    import shutil
    from tempfile import mkdtemp
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class FakeModule(object):
        def __init__(self, params=None, module=None):
            self.params = params
            self.tmpdir = None
            self.tmpdir_host = None
            self.tmpdir_guest = None
            self.tmpdir_jailed = None
            self.tmpdir_vmware = None
            self.tmpdir_xen = None
            self.tmpdir_vbox = None
            self.tmpdir_hypr = None
            self.tmpdir_para = None
            self.tmpdir_rhev = None

        def get_bin_path(self, executable):
            return executable


# Generated at 2022-06-20 20:52:54.241866
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    import sys
    import sysconfig
    import ansible.module_utils.basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    import pytest
    tmpdir = pytest.ensuretemp('test_VirtualSysctlDetectionMixin')

    mydir = tmpdir.mkdir('ansible')
    mydir.chdir()

    sysctl_filename = mydir.join('sysctl')
    sysctl_filename.write('''#!/bin/sh
echo OpenBSD
    ''')
    os.chmod(str(sysctl_filename), 0o755)


# Generated at 2022-06-20 20:52:59.997095
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import unittest.mock
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec={}
    )

    virtual_sysctl = VirtualSysctlDetectionMixin()
    virtual_sysctl.module = module

    with unittest.mock.patch("os.path.exists") as exists, \
            unittest.mock.patch("ansible.module_utils.basic.AnsibleModule.get_bin_path") as get_bin_path:
        exists.return_value = True
        get_bin_path.return_value = True
        virtual_sysctl.detect_sysctl()
        get_bin_path.assert_called_once_with("sysctl")
        assert virtual_sysctl.sysctl_path == True


# Generated at 2022-06-20 20:53:08.325023
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass:
        module = None
        sysctl_path = None

    module = dict()
    module['get_bin_path'] = lambda x: None

    virtualsysctldetectionmixin = VirtualSysctlDetectionMixin()

    testclass = TestClass()
    testclass.module = module
    testclass.detect_sysctl()

    virtualsysctldetectionmixin.detect_sysctl()

    assert testclass.sysctl_path == None

    testclass.sysctl_path = '/usr/sbin/sysctl'
    testclass.detect_virt_product('hw.model')

    virtualsysctldetectionmixin.detect_virt_product('hw.model')

# Generated at 2022-06-20 20:53:16.902676
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    v = VirtualSysctlDetectionMixin()
    result = v.detect_virt_vendor('machdep.hypervisor')
    test_result = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }
    assert result == test_result


# Generated at 2022-06-20 20:53:20.611875
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.collector import BaseFactCollector
    data = {"key": "security.jail.jailed"}
    return_value = VirtualSysctlDetectionMixin().detect_virt_vendor(data["key"])
    assert return_value == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}



# Generated at 2022-06-20 20:54:04.422746
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class fake_module(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd, **kwargs):
            if cmd == "/sbin/sysctl -n" + "security.jail.jailed":
                return (0, '1\n', '')
            if cmd == "/sbin/sysctl -n" + "hw.model":
                return (0, 'GenuineIntel\n', '')

    class fake_self():
        pass

    fm = fake_module()
    fs = fake_self()
    fs.module = fm
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl()
    assert(v.sysctl_path == '/sbin/sysctl')

# Generated at 2022-06-20 20:54:16.223031
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from Base import CapabilityCheckMixin
    from collections import namedtuple
    from ansible.module_utils.facts import module_extras
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDHostFactCollector
    from ansible.module_utils.facts.virtual.freebsd import VirtualFreeBSDGuestFactCollector

    v_g_facts = namedtuple('VirtualGuestFacts', 'virtualization_type virtualization_role virtualization_tech_guest virtualization_tech_host')
    v_h_facts = namedtuple('VirtualHostFacts', 'virtualization_type virtualization_role virtualization_tech_guest virtualization_tech_host')

    virtual_product_facts = {}
    virtual_vendor_facts = {}

    # Create CapabilityCheckMixin class with mocked module.run_command

# Generated at 2022-06-20 20:54:29.291750
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.sysctl_path = "/path/to/sysctl"
            self.sysctl_key = "hw.machine_arch"
            self.sysctl_out = "amd64\n"
            self.sysctl_err = ""
            self.sysctl_rc = 0
        def get_bin_path(self, name):
            return self.sysctl_path

        def run_command(self, cmd):
            if cmd.startswith(self.sysctl_path):
                if cmd == ("%s -n %s" % (self.sysctl_path, self.sysctl_key)):
                    return self.sysctl_rc, self.sysctl_out, self.sysctl_err
            return 1, "", ""

# Generated at 2022-06-20 20:54:36.943820
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    sysctl_path = '/usr/sbin/sysctl'
    module = type('AnsibleModule', (object,), dict(run_command=lambda *args, **kwargs: (0, '', '')))
    sysctl_mixin = VirtualSysctlDetectionMixin()
    sysctl_mixin.module = module
    sysctl_mixin.sysctl_path = sysctl_path
    assert sysctl_mixin.sysctl_path == sysctl_path

# Generated at 2022-06-20 20:54:45.431122
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Poopy(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeModule:
        def __init__(self):
            # sysctl -n machdep.cpu.brand_string
            self.rc = 0
            self.out = 'QEMU Virtual CPU version (cpu64-rhel6)'
            self.err = ''
            self.run_command = self.new_run_command

        def get_bin_path(self, name):
            return 'sysctl'

        def new_run_command(self, cmd):
            return (self.rc, self.out, self.err)

    class FakeModule2:
        def __init__(self):
            # sysctl -n machdep.cpu.brand_string
            self.rc = 0


# Generated at 2022-06-20 20:55:00.647826
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def get_bin_path(self, name):
            return "sysctl"

        def run_command(self, c):
            return (0, 'QEMU', None)

    class FakeVirtualSysctlDetectionMixin:
        def __init__(self):
            self.module = FakeModule()

    test_mixin = FakeVirtualSysctlDetectionMixin()
    test_mixin.detect_virt_vendor('hw.model')

    assert test_mixin.sysctl_path == "sysctl"
    assert test_mixin.virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert test_mixin.virtual_vendor_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:55:05.819595
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    class FakeModule(object):
        def get_bin_path(self, arg):
            return "/sbin/sysctl"

        def run_command(self, arg):
            return (0, "QEMU", "")

    fact_module = VirtualSysctlDetectionMixin()
    fact_module.module = FakeModule()
    result = fact_module.detect_virt_vendor('hw.model')
    assert result == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:55:15.487636
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(object):
        def get_bin_path(name, required=False, opt_dirs=[]):
            class TestObject(object):
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.out = out
                    self.err = err
                def run_command(self, cmd):
                    if cmd == '/sbin/sysctl -n kern.hostuuid':
                        return (0, '0cfc5762-1fcd-11e9-9ab7-00163e545d86', '')
                    if cmd == '/sbin/sysctl -n security.jail.jailed':
                        return (0, '1', '')

# Generated at 2022-06-20 20:55:21.518538
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    cmd = VirtualSysctlDetectionMixin()
    cmd.module = type('obj', (object,), {'run_command': run_command})
    actual = cmd.detect_virt_product('hw.model')
    assert actual == {'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([]),
                      'virtualization_type': 'kvm', 'virtualization_role': 'guest'}



# Generated at 2022-06-20 20:55:27.620595
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Test 1
    # Depending on the kernel and the host, the number of items in the tuple may vary
    if len(VirtualSysctlDetectionMixin().detect_virt_vendor('machdep.guest')) == 0:
        print("No virtualization detected")

    # Test 2
    # If the output of the method is corresponding to the one expected, we will get no error !
    assert VirtualSysctlDetectionMixin().detect_virt_vendor('machdep.guest') == {'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set(), 'virtualization_type': 'vmm', 'virtualization_role': 'guest'}


# Generated at 2022-06-20 20:57:00.181990
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    pass

# Generated at 2022-06-20 20:57:08.204770
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    virtual_sysctl_detection_mixin_object_instance = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_object_instance.module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Invoke detect_sysctl
    virtual_sysctl_detection_mixin_object_instance.detect_sysctl()

    assert virtual_sysctl_detection_mixin_object_instance.sysctl_path != None and virtual_sysctl_detection_mixin_object_instance.sysctl_path != ''


# Generated at 2022-06-20 20:57:16.736307
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinSubclass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None
    o = VirtualSysctlDetectionMixinSubclass()
    o.module = FakeModule(rc=0, out='(XenPVHVM)')
    assert o.detect_virt_product('hw.model') == {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': set(['xen'])}
    assert o.detect_virt_product('security.jail.jailed') == {'virtualization_tech_guest': set()}


# Generated at 2022-06-20 20:57:27.533376
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestVirtualSysctlDetectionMixin():
        def __init__(self, module=None):
            class TestModule():
                def run_command(self, command):
                    rc = 0
                    if 'sysctl' in command:
                        out = 'sysctl'
                        err = ''
                    else:
                        rc = 1
                        out = ''
                        err = 'Not Found'

                    return rc, out, err

                def get_bin_path(self, command):
                    return command

            class TestAnsibleModule():
                def __init__(self):
                    self.params = {}

                def fail_json(self, *args, **kwargs):
                    pass

            self.module = TestModule()
            self.ansible_module = TestAnsibleModule()

    mixin = VirtualSysctlDetectionMixin()
   

# Generated at 2022-06-20 20:57:33.794326
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None

        def detect_sysctl(self):
            super(FakeVirtualSysctlDetectionMixin, self).detect_sysctl()

    v = FakeVirtualSysctlDetectionMixin()
    v.detect_sysctl()
    assert v.sysctl_path is not None


# Generated at 2022-06-20 20:57:44.954422
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class System(object):
        def __init__(self, command_result, run_command_result):
            self.sysctl_path = '/sbin/sysctl'
            self.command_result = command_result
            self.run_command_result = run_command_result

        def get_bin_path(self, path):
            if path == 'sysctl':
                return self.sysctl_path

        def run_command(self, command):
            return self.run_command_result

    class Module(object):
        def __init__(self, command_result, run_command_result):
            self.sys_module = System(command_result, run_command_result)

        def get_bin_path(self, path):
            return self.sys_module.get_bin_path(path)


# Generated at 2022-06-20 20:57:48.294517
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class VirtualSysctlDetectionMixin():
        def detect_sysctl(self):
            self.sysctl_path = 'sysctl'

    class VirtualSysctlDetectionMixin_test(VirtualSysctlDetectionMixin):
        def get_bin_path(self, search_path):
            return 'sysctl'

    mixin = VirtualSysctlDetectionMixin_test()
    assert mixin.detect_sysctl() == None


# Generated at 2022-06-20 20:57:57.879881
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def get_bin_path(self, *args):
            return '/sbin/sysctl'
        def run_command(self, *args):
            return 0, 'KVM', ''
    tm = TestModule()
    vd = VirtualSysctlDetectionMixin()
    vd.module = tm
    vd.detect_sysctl = lambda: None
    out = vd.detect_virt_product('machdep.hypervisor')
    assert out['virtualization_type'] == 'kvm'
    assert out['virtualization_role'] == 'guest'
    assert out['virtualization_tech_guest'] == set(['kvm'])
    assert out['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:58:01.517478
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    fixture = VirtualSysctlDetectionMixin()
    fixture.module = MockModule()
    fixture.module.get_bin_path = MockGetBinPath()
    fixture.detect_sysctl()
    assert fixture.sysctl_path == '/usr/local/sbin/sysctl'


# Generated at 2022-06-20 20:58:06.408685
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule():
        def get_bin_path(self, name):
            return '/usr/bin/%s' % name
        def run_command(self, args):
            return 0, 'blah', None

    test_object = VirtualSysctlDetectionMixin()
    test_object.module = FakeModule()
    test_object.detect_virt_product('machdep.cpu.vendor')
    test_object.detect_virt_vendor('hw.vmm.vendor')

# import module snippets
from ansible.module_utils.basic import *
if __name__ == '__main__':
    main()