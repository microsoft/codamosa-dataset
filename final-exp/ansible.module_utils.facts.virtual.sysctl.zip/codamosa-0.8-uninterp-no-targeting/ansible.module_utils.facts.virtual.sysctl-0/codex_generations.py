

# Generated at 2022-06-20 20:48:30.278429
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import sys
    import os

    sys.modules.pop('ansible.module_utils.facts.virtual.sysctl', None)

    from ansible.module_utils.facts.virtual.sysctl import VirtualSysctlDetectionMixin

    vd = VirtualSysctlDetectionMixin()
    vd.sysctl_path = '/usr/bin/sysctl'
    vd.detect_sysctl()

    assert vd.sysctl_path == '/usr/bin/sysctl'

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..', '..',
                                 'lib', 'ansible', 'module_utils'))


# Generated at 2022-06-20 20:48:41.322924
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class DummyModule(object):
        def __init__(self):
            self.run_command_called = False

        class DummyRunCommand(object):
            out = 'KVM'

            def __init__(self):
                pass

            def run_command(self, command):
                self.run_command_called = True
                return 0, self.out, ''

        def get_bin_path(self, binary):
            return 'sysctl'

    x = DummyModule()
    y = VirtualSysctlDetectionMixin()
    y.module = x
    z = y.detect_virt_product('hw.model')
    assert z['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:48:48.592600
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    testvm = VirtualSysctlDetectionMixin()
    testvm.module = AnsibleModuleMock()
    testvm.module.get_bin_path.return_value = '/usr/bin/sysctl'

    testvm.detect_sysctl()
    testvm.module.get_bin_path.assert_called_once_with('sysctl')
    assert testvm.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-20 20:48:49.943532
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vsdm = VirtualSysctlDetectionMixin()
    assert vsdm


# Generated at 2022-06-20 20:48:56.363220
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={
        'name': dict(required=True),
        'value': dict(type='list', elements='int', required=True),
        'sysctl_set': dict(required=False, type='bool', default=False),
        'state': dict(required=False, default='present', choices=['present', 'absent']),
    })
    key = 'security.jail.jailed'
    sysctl_path = module.get_bin_path('sysctl')
    rc, out, err = module.run_command("%s -n %s" % (sysctl_path, key))
    assert rc == 0
    assert out.rstrip() == '1'

# Generated at 2022-06-20 20:49:08.914034
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import platform
    import json
    import subprocess
    import shlex

    class FakeModule(object):
        def __init__(self, **kwargs):
            self._facts_cache = {}
            for k, v in kwargs.items():
                setattr(self, k, v)

        @property
        def facts(self):
            return self._facts_cache

        @facts.setter
        def facts(self, value):
            self._facts_cache = value

    # create a fake ansible module

# Generated at 2022-06-20 20:49:16.628577
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-20 20:49:22.716459
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    change_check_obj = VirtualSysctlDetectionMixin()
    assert isinstance(change_check_obj, VirtualSysctlDetectionMixin)
    assert change_check_obj.detect_sysctl() is None
    assert change_check_obj.detect_virt_product('') == {}
    assert change_check_obj.detect_virt_vendor('') == {}

# Generated at 2022-06-20 20:49:25.713893
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin().detect_virt_vendor('hw.product') == {}
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw.product') == {}

# Generated at 2022-06-20 20:49:31.477753
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    ''' Unit test for constructor of class VirtualSysctlDetectionMixin '''
    class testModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = {}
            self.module = object()
            self.module.run_command = object()
            self.module.params = object()

        def get_bin_path(self, command):
            return '/bin/%s' % command

    assert testModule() is not None

# Generated at 2022-06-20 20:49:44.132345
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert hasattr(v, "detect_sysctl")
    assert hasattr(v, "detect_virt_product")
    assert hasattr(v, "detect_virt_vendor")

# Generated at 2022-06-20 20:49:52.181048
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def __init__(self, name, bin_paths):
            self.bin_paths = bin_paths
            self.name = name
        def get_bin_path(self, name, required=False):
            if name in self.bin_paths.keys():
                return self.bin_paths[name]
            elif required:
                raise Exception('Cannot find %s in path!' % name)
            else:
                return None

    # Mock class instance
    mock_mixin = type('mock_mixin', (VirtualSysctlDetectionMixin, object), {})
    mixin = mock_mixin()

    # Test normal conditions
    mixin.module = FakeModule('test1', {'sysctl': '/sbin/sysctl'})
    mixin.detect

# Generated at 2022-06-20 20:49:59.232766
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    test_object = VirtualSysctlDetectionMixin()
    test_object.sysctl_path = None
    module_mock = MockModule()
    test_object.module = module_mock
    test_object.detect_sysctl()
    assert test_object.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-20 20:50:10.677502
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """ Tests detect_sysctl() from VirtualSysctlDetectionMixin """

    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualFactCollector

    class DummyModule:
        def __init__(self):
            return

        def get_bin_path(self, path):
            return '/usr/bin/sysctl'

    dummy_module = DummyModule()

    class DummyCollector(VirtualFactCollector, VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

# Generated at 2022-06-20 20:50:19.493189
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_return_value = (0, "QEMU", "")
        def run_command(self, command):
            return self.run_command_return_value
        def get_bin_path(self, executable):
            return "sysctl"

    module = FakeModule()
    assert VirtualSysctlDetectionMixin.detect_virt_vendor(module, "machdep.booted_kernel") == {
        "virtualization_type": "kvm",
        "virtualization_role": "guest",
        "virtualization_tech_guest": {"kvm"},
        "virtualization_tech_host": set()
    }

    module.run_command_return_value = (1, "", "")
    assert VirtualSys

# Generated at 2022-06-20 20:50:23.623178
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw.product') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-20 20:50:34.090218
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import os
    import types
    import unittest

    # Disable debug log so we can actually test stdout
    os.environ["ANSIBLE_DEBUG"] = "False"

    # Make test directory
    os.mkdir('/tmp/test_base_discovery')

    # Make fake module
    sys.modules['ansible.module_utils.basic'] = types.ModuleType('ansible.module_utils.basic')
    sys.modules['ansible.module_utils.basic'].AnsibleModule = types.ModuleType('AnsibleModule')
    sys.modules['ansible.module_utils.basic'].AnsibleModule.run_command = run_command_mock
    sys.modules['ansible.module_utils.basic'].AnsibleModule.get_bin_path = get_bin_path

# Generated at 2022-06-20 20:50:45.848571
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Test(object):
        def __init__(self):
            self.paths = {'sysctl': 'sysctl'}
            self.sysctl_path = None

        def get_bin_path(self, name, opt_dirs=[], required=False):
            return self.paths[name]

        def run_command(self, cmd):
            if cmd == 'sysctl -n security.jail.jailed':
                rcode = 0
            else:
                rcode = 1
            return (rcode, '', '')

    class VirtualSysctlDetectionMixin_detect_sysctl_Test(VirtualSysctlDetectionMixin, Test):
        pass

    test = VirtualSysctlDetectionMixin_detect_sysctl_Test()
    test.detect_sysctl()
    assert test.sys

# Generated at 2022-06-20 20:50:47.298241
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
   v = VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:51:00.790303
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class AnsibleModuleFake(object):
        def __init__(self):
            self.params = {}
            self.fail_json = False
            self.fail = None
        def fail_json(self, msg):
            self.fail = msg
        def get_bin_path(self, bin_path, required=False, opt_dirs=[]):
            return "/sbin/sysctl"
        def get_bin_path(self, bin_path, required=False, opt_dirs=[]):
            return "/sbin/sysctl"
        def run_command(self, cmd):
            return [0, "KVM", ""]
            
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = None

    test_class = TestClass()
    test_

# Generated at 2022-06-20 20:51:24.001667
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    with patch.object(VirtualSysctlDetectionMixin, 'module') as mock_module:
        mock_module.get_bin_path.return_value = 'a_path'
        class TestClass(VirtualSysctlDetectionMixin):
            pass
        test_obj = TestClass()
        test_obj.detect_sysctl()
    assert test_obj.sysctl_path == 'a_path'


# Generated at 2022-06-20 20:51:37.007932
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # We don't actualy have a sysctl binary, so we need to patch out that part
    # of the method.

    # Import the object to test and patch it
    from ansible.modules.system import virtual_sysctl_detection
    real_method = virtual_sysctl_detection.VirtualSysctlDetectionMixin.detect_sysctl
    virtual_sysctl_detection.VirtualSysctlDetectionMixin.detect_sysctl = lambda self: None

    # Create the object to test
    from ansible.module_utils.basic import AnsibleModule

    # The 'detect_virt_product' method requires some of the attributes, so set
    # them
    test_object = virtual_sysctl_detection.VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:51:48.695669
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    # VirtualSysctlDetectionMixin_detect_virt_product
    # Checks that detect_virt_product method returns key and value pair

    class FakeModule(object):
        @staticmethod
        def get_bin_path(program, required=False, opt_dirs=None):
            print(program)
            return "/usr/sbin/sysctl"

        @staticmethod
        def run_command(program):
            print(program)

            if program == "/usr/sbin/sysctl -n kern.smp.cpus":
                return 0, "8", ""
            elif program == "/usr/sbin/sysctl -n hw.model":
                return 0, "my_model", ""

# Generated at 2022-06-20 20:51:51.438937
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestVirtFactModule:
        def get_bin_path(self, x):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            return 0, '', ''

    class TestVirtFacts(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    test_vf = TestVirtFacts(TestVirtFactModule())
    assert test_vf.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-20 20:51:57.335039
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """
    Test detect_sysctl() of VirtualSysctlDetectionMixin()
    """
    import tempfile
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as detect_sysctl
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes, to_text
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.virtual import Virtual, VirtualBSDFactsCollector

    class MockModule(object):
        def __init__(self, bin_ansible_callbacks):
            self.params = {}
            self.bin_ansible_callbacks = bin_ansible_callbacks


# Generated at 2022-06-20 20:52:04.231082
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    import pytest
    from ansible.module_utils.facts.virtual.virtual_sysctl import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.virtual_sysctl import VirtualSysctlDetectionMixin_test
    # Test the VirtualSysctlDetectionMixin class
    test_inst = VirtualSysctlDetectionMixin_test()
    test_inst.sysctl_path = '/bin/sysctl'
    virt_product_facts = test_inst.detect_virt_product('hw.model')

    assert virt_product_facts['virtualization_type'] == 'kvm'
    assert 'guest' in virt_product_facts['virtualization_role']
    assert len(virt_product_facts['virtualization_tech_guest']) == 1


# Generated at 2022-06-20 20:52:12.151767
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = module

    with patch.multiple(VirtualSysctlDetectionMixin,
                        module=DEFAULT,
                        sysctl_path=DEFAULT) as mocks:
        mocks['module'].get_bin_path.return_value = '/sbin/sysctl'
        test_obj.detect_sysctl()
        assert test_obj.sysctl_path == '/sbin/sysctl'



# Generated at 2022-06-20 20:52:15.389517
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    m = AnsibleModule(
        argument_spec=dict(
            test_key=dict(type='str', default='test_key')
        )
    )
    vm = VirtualSysctlDetectionMixin()
    if hasattr(m, 'detect_sysctl'):
        if hasattr(m, 'detect_virt_product'):
            if hasattr(m, 'detect_virt_vendor'):
                return True
    return False

# Generated at 2022-06-20 20:52:18.908296
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    # v is an instance of VirtualSysctlDetectionMixin
    assert v

# Generated at 2022-06-20 20:52:20.376175
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    my_mixin = VirtualSysctlDetectionMixin()
    assert my_mixin

# Generated at 2022-06-20 20:52:59.934933
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def get_bin_path(bin):
            return FakeBinPath(bin)
        class FakeBinPath:
            def __init__(self, bin):
                self.bin = bin
            def __call__(self, *args, **kwargs):
                return "/usr/bin/%s" % self.bin
        def run_command(self, command):
            if command == "/usr/bin/sysctl -n hw.model":
                return 0, "QEMU Virtual CPU version 1.0", None
            elif command == "/usr/bin/sysctl -n hw.model":
                return 0, "OpenBSD", None
            elif command == "/usr/bin/sysctl -n hw.model":
                return 0, "Some other model", None
            else: 
                raise

# Generated at 2022-06-20 20:53:05.674044
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={})
    module.expect_binaries_found('sysctl')
    assert module.sysctl_path == module.get_bin_path('sysctl')
    module.expect_binaries_not_found('sysctl')
    assert module.sysctl_path == module.get_bin_path('sysctl')


# Generated at 2022-06-20 20:53:14.273116
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from mock import Mock
    mixin = VirtualSysctlDetectionMixin()

    mixin.detect_sysctl = Mock()
    mixin.detect_sysctl.return_value = True

    result = mixin.detect_virt_vendor('vendor')
    assert isinstance(result, dict)
    assert result == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}

# Generated at 2022-06-20 20:53:26.313082
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """
    Test detect_sysctl mixin method of VirtualSysctlDetectionMixin
    """
    # Test that the sysctl is detected on a host that has it
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule('/sbin/sysctl')
    mixin.detect_sysctl()
    assert '/sbin/sysctl' == mixin.sysctl_path

    # Test that the sysctl is not detected on a host that does not have it
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule(None)
    mixin.detect_sysctl()
    assert None == mixin.sysctl_path


# Generated at 2022-06-20 20:53:29.287485
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert isinstance(v, object)
    assert hasattr(v, 'detect_sysctl')
    assert hasattr(v, 'detect_virt_product')

# Generated at 2022-06-20 20:53:32.765818
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert issubclass(VirtualSysctlDetectionMixin, object) is True

# Unit tests for detect_virt_product and detect_virt_vendor

# Generated at 2022-06-20 20:53:46.091834
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(argument_spec={})
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = module

    # Fake sysctl path
    test_obj.detect_sysctl()
    assert test_obj.sysctl_path is not None

    # Fake sysctl values

# Generated at 2022-06-20 20:53:48.732220
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    system = VirtualSysctlDetectionMixin()
    assert isinstance(system, VirtualSysctlDetectionMixin)

# Generated at 2022-06-20 20:53:57.940536
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    OUTPUTS = {
        'dev.vm.0.vmm_sysctl': "XenPV",
        'security.jail.jailed': "0",
        'dev.vm.0.vendor': "OpenBSD",

    }

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    class ModuleFailException(Exception):
        pass

    class Module(object):
        def __init__(self, fail_on_default=True):
            self.params = Bunch(
                dict(
                    detect_virt=True
                )
            )
            self._debug = []
            pass

        def fail_json(self, *args, **kwargs):
            raise ModuleFailException(args)


# Generated at 2022-06-20 20:54:00.498230
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vsdm = VirtualSysctlDetectionMixin()
    assert vsdm is not None


# Generated at 2022-06-20 20:55:18.830927
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = MockAnsibleModule()
    test_object.detect_sysctl()
    assert test_object.sysctl_path == "/bin/false"


# Generated at 2022-06-20 20:55:29.028816
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    v = VirtualSysctlDetectionMixin()
    v.module = module

    # Test case: sysctl is not installed
    v.sysctl_path = None
    host_tech, guest_tech, virtual_tech, virtual_role = v.detect_virt_vendor('machdep.xen.guest')
    assert {} == host_tech
    assert {} == guest_tech
    assert None == virtual_tech
    assert None == virtual_role

    # Test case: sysctl is installed and we are running in OpenBSD's VMM
    v.sysctl_path = 'sysctl'

# Generated at 2022-06-20 20:55:44.660501
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeAnsibleModule(object):
        def __init__(self, params=None):
            if params is None:
                params = {}
            self._params = params

        def get_bin_path(self, app, opt_dirs=[]):
            return "/usr/bin/sysctl"

        def run_command(self, command):
            return 0, "OpenBSD", None

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeVirtualGuest(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    sysd = FakeVirtualSysctlDetectionMixin(FakeAnsibleModule())

# Generated at 2022-06-20 20:55:55.751605
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule():
        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command = FakeModule.run_command

        def run_command(self, cmd):
            return self.rc, self.out, self.err

        def get_bin_path(self, item):
            return ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = ''

    def test_VirtualSysctlDetectionMixin_detect_virt_vendor_QEMU_type_guest():
        module = FakeModule(rc=0, out='QEMU')

# Generated at 2022-06-20 20:55:56.534008
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin



# Generated at 2022-06-20 20:56:06.543061
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixin

    class LocalVirtSys(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.sysctl_path = None
            self.module = module
            self.detect_sysctl()

    class FakeModule(object):
        def __init__(self):
            self.run_command_expect_return = (0, "/usr/bin/sysctl", "")

        def run_command(self, cmd):
            return self.run_command_expect_return

        def get_bin_path(self, name, required=False):
            return "/usr/bin/sysctl"

        def fail_json(self, **kwargs):
            raise Exception('fail_json')

   

# Generated at 2022-06-20 20:56:08.043416
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    detect_sysctl = VirtualSysctlDetectionMixin()
    detect_virt_product = VirtualSysctlDetectionMixin()
    detect_virt_vendor = VirtualSysctlDetectionMixin()

# Overwrite AnsibleModule

# Generated at 2022-06-20 20:56:15.243139
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Mock sysctl
    sysctl_path = '/sbin/sysctl'
    key = 'hw.model'

    # Mock module
    module = MockModule()

    # Create an instance of class VirtualSysctlDetectionMixin
    class VirtualSysctlDetectionMixinExt(VirtualSysctlDetectionMixin):
        sysctl_path = sysctl_path
        module = module

    instance = VirtualSysctlDetectionMixinExt()

    # Test with mocked output of sysctl
    def mocked_command(cmd, *args):
        if (sysctl_path in cmd) and ('hw.model' in cmd):
            if ('HVM domU' in cmd):
                output = 'hw.model: HVM domU'

# Generated at 2022-06-20 20:56:25.177725
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    vsd = VirtualSysctlDetectionMixin()
    vsd.module = MagicMock()
    vsd.module.get_bin_path.return_value = '/sbin/sysctl'
    vsd.detect_sysctl()
    assert vsd.sysctl_path == '/sbin/sysctl'

    vsd = VirtualSysctlDetectionMixin()
    vsd.module = MagicMock()
    vsd.module.get_bin_path.return_value = '/usr/bin/sysctl'
    vsd.detect_sysctl()
    assert vsd.sysctl_path == '/usr/bin/sysctl'

    vsd = VirtualSysctlDetectionMixin()
    vsd.module = MagicMock()
    vsd.module.get_bin_path.return_value = None
   

# Generated at 2022-06-20 20:56:34.292440
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestClass(object):
        def __init__(self):
            self.sysctl_path = None
            self.run_command = lambda x: (0, 'KVM', '')
        def get_bin_path(self, program, opts=None, required=False):
            return '/sbin/sysctl'

    # test on empty class
    vmsysctl = VirtualSysctlDetectionMixin()
    vmsysctl.module = TestClass()
    vmsysctl.detect_sysctl()
    assert vmsysctl.sysctl_path == '/sbin/sysctl'
