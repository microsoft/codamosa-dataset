

# Generated at 2022-06-20 20:48:24.771370
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VirtSysctlDetectionMixin = VirtualSysctlDetectionMixin()
    VirtSysctlDetectionMixin.detect_virt_vendor('hw.model')
    VirtSysctlDetectionMixin.detect_virt_product('hw.model')
    VirtSysctlDetectionMixin.detect_sysctl()

# Generated at 2022-06-20 20:48:37.157669
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mock_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    mock_module.run_command = Mock(return_value=(0, 'KVM', ''))
    sysctl_path = mock_module.get_bin_path('sysctl')
    if sysctl_path:
        test_module = VirtualSysctlDetectionMixin()
        test_module.module = mock_module
        test_module.sysctl_path = sysctl_path
        results = test_module.detect_virt_product('kern.bootfile')
        assert results["virtualization_type"] == "kvm"
        assert results["virtualization_role"] == "guest"
        assert 'kvm' in results["virtualization_tech_guest"]

# Generated at 2022-06-20 20:48:39.448674
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vdm = VirtualSysctlDetectionMixin()
    vdm.module = MagicMock()
    vdm.detect_sysctl()

# Generated at 2022-06-20 20:48:51.192433
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin

    class MockModule(object):
        def __init__(self, command_success=True, virtualization_type=None, virtualization_role=None, virtualization_guest=None, virtualization_host=None):
            self._command_success = command_success
            self.virtualization_type = virtualization_type
            self.virtualization_role = virtualization_role
            self.virtualization_guest = virtualization_guest
            self.virtualization_host = virtualization_host

        def get_bin_path(self, bin_name):
            if bin_name == 'sysctl':
                return 'sysctl'

        def run_command(self, command):
            if self._command_success:
                return 0, self

# Generated at 2022-06-20 20:48:57.376950
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = type('TestModule', (object,), {})()
    module.get_bin_path = lambda *args, **kwargs: None
    module.run_command = lambda *args, **kwargs: (0, '', '')
    sysctl = VirtualSysctlDetectionMixin()
    sysctl.module = module
    assert sysctl.sysctl_path == None
    sysctl.detect_sysctl()
    assert sysctl.sysctl_path == None

# Generated at 2022-06-20 20:49:09.799836
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin

    class FakeModule:
        class FakeOS:
            sysname = 'OpenBSD'

        def __init__(self):
            self.os = self.FakeOS()

        def run_command(self, command):
            if command == "sysctl -n hw.model":
                return (0, 'QEMU', '')
            elif command == "sysctl -n hw.product":
                return (0, 'OpenBSD', '')
            else:
                return (1, '', '')

        def get_bin_path(self, app, optional=False):
            return 'sysctl'

    fm = FakeModule()
    vsm = VirtualSysctlDetectionMixin()
    vsm.module = f

# Generated at 2022-06-20 20:49:17.018913
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = ''
            self.module = type('module', (object,), {'run_command': self.mock_run_command})
        def mock_run_command(self, cmd):
            tmp_cmd = os.system('which sysctl')
            if tmp_cmd == 0:
                return 0, 'sysctl', ''
            else:
                return 1, '', ''

    TestVirtualSysctlDetectionMixin_instance = TestVirtualSysctlDetectionMixin()
    TestVirtualSysctlDetectionMixin_instance.detect_sysctl()
    assert TestVirtualSysctlDetectionMixin_instance.sysctl_path == 'sysctl'


# Generated at 2022-06-20 20:49:28.286542
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # python 2.6 does not have assertCountEqual
    try:
        from unittest.case import SkipTest
        try:
            from unittest.case import assertCountEqual
        except ImportError:
            pass
    except ImportError:
        from unittest import SkipTest
        from unittest import TestCase
        assertCountEqual = TestCase.assertItemsEqual

    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.posix.collector import BaseFactCollector

    class FakeModule(object):
        def __init__(self):
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda binary: (0, '%s is a binary' % binary, None)



# Generated at 2022-06-20 20:49:39.513719
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # pylint: disable=protected-access,unused-argument
    # pylint: disable=too-many-arguments
    # pylint: disable=too-few-public-methods

    # Mock out module because we aren't testing that here
    class VirtualHostInfoAnsibleModuleDummy():  # pylint: disable=too-few-public-methods
        def __init__(self):
            self.params = {}
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, executable, required=False):
            # We'll only be calling this with executable="sysctl"
            return '/sbin/sysctl'

        def run_command(self, command):
            return exit_code, stdout, stderr


# Generated at 2022-06-20 20:49:46.181740
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl = VirtualSysctlDetectionMixin()
    assert hasattr(virtual_sysctl, 'detect_sysctl')
    assert hasattr(virtual_sysctl, 'detect_virt_product')
    assert hasattr(virtual_sysctl, 'detect_virt_vendor')

# Generated at 2022-06-20 20:50:08.805178
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            class DummyModule:
                def __init__(self):
                    self.sysctl_path = '/sbin/sysctl'

                def get_bin_path(self, argv):
                    return self.sysctl_path

                def run_command(self, cmd):
                    if cmd == '/sbin/sysctl -n hw.model':
                        return (0, 'qemu', '')
                    if cmd == '/sbin/sysctl -n kern.version':
                        return (0, 'OpenBSD', '')

            self.module = DummyModule()
        get_bin_path = detect_virt_vendor

    mixin = VirtualSysctlDetectionMixinTest()


# Generated at 2022-06-20 20:50:12.622202
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """
    Test constructor of VirtualSysctlDetectionMixin class
    """
    class TestClass(VirtualSysctlDetectionMixin):
        """
        Test class for VirtualSysctlDetectionMixin
        """
        pass

    assert VirtualSysctlDetectionMixin() is not None
    assert TestClass() is not None

# Generated at 2022-06-20 20:50:13.914410
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_class = VirtualSysctlDetectionMixin()
    assert(test_class)

# Generated at 2022-06-20 20:50:21.489998
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.virtual.virtualbox import VirtualBox
    from ansible.module_utils.facts.virtual.freebsd_bhyve import Bhyve
    from ansible.module_utils.facts.virtual.freebsd_vmm import Vmm
    from ansible.module_utils.facts.virtual.freebsd_jail import Jails
    from ansible.module_utils.facts.virtual.freebsd_xen import Xen
    from ansible.module_utils.facts.virtual.hybrid import HybridFactCollector

    vbox = VirtualBox()
    bhyve = Bhyve()
    vmm = Vmm()
    jails = Jails()
    xen = Xen()
    hybrid = HybridFactCollector()

    assert vbox
    assert bhyve
    assert vmm

# Generated at 2022-06-20 20:50:32.752813
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    host_virt_type_product_list = [
        'kvm', 'KVM', 'kvm', 'Bochs', 'Bochs',
        'VMware', 'VMware', 'SmartDC', 'virtualbox',
        'VirtualBox', 'XenPVH', 'XenPV', 'XenPVHVM',
        'HVM domU', 'Hyper-V', 'Hyper-V', 'Parallels',
        'Parallels', 'RHEV Hypervisor', 'RHEV Hypervisor',
        'OpenBSD'
    ]

    class TestModule():
        class Test:
            def __init__(self, result):
                self.cmd = ''
                self.rc = 0
                self.stdout = result

            def run_command(self, cmd):
                self.cmd = cmd
                return

# Generated at 2022-06-20 20:50:39.098819
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    class FakeModule(object):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'
        def get_bin_path(self, arg, required=False):
            return self.sysctl_path
        def run_command(self, cmd):
            if cmd == '%s -n kern.vm_guest' % self.sysctl_path:
                return 0, 'OpenBSD', ''
            if cmd == '%s -n hw.product' % self.sysctl_path:
                return 0, 'QEMU', ''
            return 0, '', ''
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    assert mixin.detect_virt

# Generated at 2022-06-20 20:50:42.034241
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import Virtual
    virtual = Virtual()
    virtual.detect_sysctl()



# Generated at 2022-06-20 20:50:53.377078
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = Fake_AnsibleModule('virtualization_type')
    module.detect_sysctl = MagicMock()
    module.run_command = MagicMock()
    module.detect_sysctl.return_value = None
    module.run_command.return_value = 0, 'OpenBSD', ''

    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    result = virtual_sysctl_detection_mixin.detect_virt_vendor(
        key='hw.model'
    )
    assert result == {'virtualization_role': 'guest', 'virtualization_type': 'vmm', 'virtualization_tech_guest': {'vmm'}, 'virtualization_tech_host': set()}



# Generated at 2022-06-20 20:51:06.607769
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import collector
    import sys

    class FakeModule(object):
        def __init__(self):
            self.facts = collector.get_platform_facts()
            self.params = {
                'gather_subset': '!all',
                'gather_timeout': 10,
            }
            self.args = {'gather_subset': '!all', 'gather_timeout': 10}

        def fail_json(self, *args, **kwargs):
            sys.exit(1)

        def get_bin_path(self, binary):
            return binary

        def run_command(self, cmd):
            return (0, "XenPV", "")


# Generated at 2022-06-20 20:51:14.817345
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MagicMock()
    module.get_bin_path.return_value = False

    vsdm = VirtualSysctlDetectionMixin()
    vsdm.detect_sysctl()
    assert vsdm.sysctl_path is None

    module.get_bin_path.return_value = "/bin/sysctl"
    vsdm.detect_sysctl()
    assert vsdm.sysctl_path == "/bin/sysctl"

# Generated at 2022-06-20 20:51:44.820167
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.sysctl_path = '/bin/sysctl'
    test_obj.module = ansible.module_utils.basic.AnsibleModule(argument_spec={})
    test_obj.module.run_command = MagicMock(return_value=(0, b'KVM', b''))
    result = test_obj.detect_virt_vendor('machdep.cpu.vendor')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    # Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
    def test_VirtualSysctlDetectionMixin_detect_virt_product():
        test_obj = VirtualSysctlDetectionMixin()
       

# Generated at 2022-06-20 20:51:54.643790
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    class FakeModule:
        def command(self):
            return "test_output"

        def get_bin_path(self):
            return None

        def run_command(self):
            return 0, "test_output", "test_error"

    class FakeFacts:
        def get_all(self):
            return {}

    class FakeAnsibleModule(FakeModule):
        def __init__(self):
            self.exit_json = lambda: None
            self.fail_json = lambda: None

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
            def __init__(self, *args, **kwargs):
                self.module = FakeAnsibleModule()
                self.sysctl_path = None
                self.facts = FakeFacts()


# Generated at 2022-06-20 20:51:59.900023
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from io import StringIO
    class MockModule(object):
        def run_command(obj, cmd, check_rc=True, close_fds=True, executable=None, data=None):
            if "sysctl -n kern.vm_guest" in cmd:
                return 0, "VMware", ""
        def get_bin_path(obj, arg):
            return "/sbin/sysctl"

    class MockBaseClass(object):
        STATIC_FACTS = dict()
        def __init__(self):
            self.module = MockModule()
            self.facts = dict()

    class MockClass(VirtualSysctlDetectionMixin, MockBaseClass):
        def __init__(self):
            MockBaseClass.__init__(self)

# Generated at 2022-06-20 20:52:10.829641
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeAnsibleModule()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = module
    virtual_sysctl_detection_mixin.detect_sysctl = FakeDetectSysctl()
    # Add tests for VirtualBox
    assert virtual_sysctl_detection_mixin.detect_virt_product('hw.model') == {
        'virtualization_tech_guest': {'virtualbox'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest'
    }
    # Add tests for ESXi type 6.5

# Generated at 2022-06-20 20:52:17.197189
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.base import BaseVirtual
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    # XXX: This is a best-effort test as we can't stub 'sysctl'
    # To make this test work, it's necessary to run it manually
    # and fix the expected dict after verifying that the test failed
    # because the dict is incorrect.
    class TestVirtualFacts(VirtualSysctlDetectionMixin, VirtualFacts):  # pylint: disable=too-many-ancestors
        def __init__(self):
            self.module = None
            self.sysctl_path = None
            self.exit_json = None
            self.fail_json = None

# Generated at 2022-06-20 20:52:21.695351
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestClass:
        def get_bin_path(self, name):
            return name

    detection = VirtualSysctlDetectionMixin()
    detection.module = TestClass()
    detection.detect_sysctl()
    assert detection.sysctl_path == 'sysctl'


# Generated at 2022-06-20 20:52:34.997769
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {
                'syctl': '/sbin/sysctl',
            }

        def get_bin_path(self, key):
            return self.params.get(key)

        def run_command(self, cmd, check_rc=True):
            return 0, 'QEMU', ''

    class MockFactsBase(object):
        @property
        def module(self):
            return MockModule()

        def detect_virtualization(self):
            return self.detect_virt_vendor('machdep.tools_version')

    facts_base = MockFactsBase()
    assert facts_base.detect_virtualization()

# Generated at 2022-06-20 20:52:40.933863
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.utils.virtual.sysctl import VirtualSysctlDetectionMixin
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.exit_json_called = False
            self.fail_json_called = False
            self.argument_spec = {}
            self.params = {}
            self.exit_args = {}
            self.fail_args = {}
            self.run_command_args = {}
            self.virtual_facts = {}
            self.bin_path_args = {}
            self.bin_path_called = False
        def run_command(self, cmd):
            self.run_command_args['cmd'] = cmd
            self.run_command_called = True
            return (0, '', '')
       

# Generated at 2022-06-20 20:52:43.374669
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    '''
    Unit test for constructor of class VirtualSysctlDetectionMixin
    '''
    mixin = VirtualSysctlDetectionMixin()
    assert mixin.sysctl_path == None


# Generated at 2022-06-20 20:52:46.004334
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from units.compat.mock import MagicMock

    # Test that the class can be constructed
    VirtualSysctlDetectionMixin()

# Generated at 2022-06-20 20:53:37.389282
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # prepare the test environment
    module_args = dict()
    set_module_args(module_args)

    # setup AnsibleModule
    sysctl_manager = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )

    # setup VirtualSysctlDetectionMixin
    set_module_inst(sysctl_manager)
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.sysctl_path = 'sysctl'

    # get sysctl output
    sysctl_product_output = """
    security.jail.jailed: 0
    
    
    
    
    
    
    """
    sysctl_vendor_output = """
    security.jail.jailed: 0
    """

    # create the mock for run_command
    m_run

# Generated at 2022-06-20 20:53:40.549137
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/bin/sysctl'

    sysctlmock = VirtualSysctlDetectionMixinTest()
    sysctl_output = sysctlmock.detect_virt_product('kern.vm_guest')
    assert sysctl_output['virtualization_type'] == 'kvm'
    assert sysctl_output['virtualization_role'] == 'guest'
    assert sysctl_output['virtualization_tech_guest'] == set(['kvm'])
    assert sysctl_output['virtualization_tech_host'] == set()


# Generated at 2022-06-20 20:53:42.635128
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import unittest
    from ansible.module_utils. FreeBSD import FreeBSDSysctlDetection
    module = FreeBSDSysctlDetection()
    module.detect_sysctl()
    assert module.sysctl_path == 'sysctl'

# Generated at 2022-06-20 20:53:52.923934
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    key = 'hw.model'
    out = 'QEMU'
    rc = 0
    err = ''
    ansible_facts = {'sysctl_path': 'sysctl'}
    result = VirtualSysctlDetectionMixin().detect_virt_vendor(key, ansible_facts)
    virtual_vendor_facts = {}
    host_tech = set()
    guest_tech = set()
    guest_tech.add('kvm')
    virtual_vendor_facts['virtualization_type'] = 'kvm'
    virtual_vendor_facts['virtualization_role'] = 'guest'
    virtual_vendor_facts['virtualization_tech_guest'] = guest_tech
    virtual_vendor_facts['virtualization_tech_host'] = host_tech
    assert result == virtual_vendor_

# Generated at 2022-06-20 20:54:01.768115
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Set up
    import types

    test_module = FakeModule()
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = test_module

    test_object.sysctl_path = "data/sysctl"
    key = "hw.model"
    expect_rc = 0
    expect_stdout = "Intel(R) Xeon(R) CPU E5-2660 v2 @ 2.20GHz"
    test_module.run_command.return_value = expect_rc, expect_stdout, None

    # Test
    result = test_object.detect_virt_product(key)
    test_module.run_command.assert_called_with("data/sysctl -n hw.model")

    assert result is not None
    assert isinstance(result, dict)

# Generated at 2022-06-20 20:54:05.264545
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class module:
        def get_bin_path(self, value):
            return '/sbin/sysctl'
    class class_under_test():
        sysctl_path = None

    c = class_under_test()
    c.module = module()
    c.detect_sysctl()
    assert c.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:54:16.542714
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Create a dummy class
    class dummy_module():
        def __init__(self):
            self.bin_path = "/bin"

        def get_bin_path(self, name):
            if name == "sysctl":
                return os.path.join(self.bin_path, "sysctl")
            return name

    class dummy_class():
        def __init__(self):
            self.module = dummy_module()

    obj = dummy_class()
    # Test sysctl binary is detected
    obj.detect_sysctl()
    assert obj.sysctl_path == "/bin/sysctl"

# Generated at 2022-06-20 20:54:26.349353
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class linux_system():
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'

        def get_bin_path(self, path):  # pylint: disable=unused-argument
            return self.sysctl_path

    class module():
        def __init__(self):
            self.run_command_results = []

        def run_command(self, cmd):
            return self.run_command_results.pop(0)

    class test_VirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            super(test_VirtualSysctlDetectionMixin, self).__init__()


# Generated at 2022-06-20 20:54:33.412555
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_object = VirtualSysctlDetectionMixin()
    virtual_product_facts = test_object.detect_virt_product('hw.product')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virtual_product_facts['virtualization_tech_guest']
    assert not virtual_product_facts['virtualization_tech_host']


# Generated at 2022-06-20 20:54:37.640147
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule({})
    plugin = VirtualSysctlDetectionMixin()
    assert issubclass(type(plugin), VirtualSysctlDetectionMixin)

# Generated at 2022-06-20 20:56:29.361545
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mod = AnsibleModule({})
    obj = VirtualSysctlDetectionMixin()
    obj.module = mod
    assert(obj.detect_sysctl() == None)

# Generated at 2022-06-20 20:56:33.884919
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    my_object = VirtualSysctlDetectionMixin()
    my_object.module = FakeModule()
    my_object.module.get_bin_path = lambda x: "/sbin/sysctl"
    my_object.detect_sysctl()

    assert my_object.sysctl_path == "/sbin/sysctl"


# Generated at 2022-06-20 20:56:37.125166
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    try:
        from ansible.module_utils.basic import AnsibleModule
    except:
        from ansible.module_utils.basic import *

    import sys
    sys.modules['ansible'] = AnsibleModule
    from ansible.module_utils.common.sys_info import VirtualSysctlDetectionMixin

    obj = VirtualSysctlDetectionMixin()
    assert obj is not None


# Generated at 2022-06-20 20:56:47.666509
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import DefaultCollector

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    collector = DefaultCollector(module, VirtualSysctlDetectionMixin())
    result = collector.detect_virt_vendor('security.jail.osreldate')
    assert 'virtualization_type' in result
    assert 'virtualization_role' in result
    assert result['virtualization_type'] == 'OpenBSD'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-20 20:56:58.276062
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    stdout_value_virtualbox = 'VirtualBox'
    stdout_value_vmware = 'Dell Inc.        PowerEdge R220 VMware Virtual Platform'
    stdout_value_kvm = 'KVM: HVM domU'
    stdout_value_parallels = 'Parallels Software International Inc. Parallels Virtual Platform'
    stdout_value_hyperv = 'Hyper-V'
    stdout_value_rhev = 'RHEV Hypervisor'
    stdout_value_xenpv = 'XenPV'
    stdout_value_xenpvh = 'XenPVH'
    stdout_value_jailed = '1'
    stdout_value_everythingelse = 'everythingelse'


# Generated at 2022-06-20 20:57:03.639051
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ..modules.system import VirtualSysctlDetectionMixin
    v = VirtualSysctlDetectionMixin()
    v.sysctl_path = None
    v.module = MockAnsibleModule()
    v.detect_sysctl()
    assert v.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-20 20:57:15.384042
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """Unit test for VirtualSysctlDetectionMixin's detect_virt_product method
    """
    # These tests could be improved using a mocking library.  I haven't found
    # a good one for Python yet.
    import sys
    # Make sure our module imports
    sys.path.append("../../lib")
    from ansible.module_utils import basic
    module = basic.AnsibleModule(argument_spec={})

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = module
            self.sysctl_path = '/bin/false'

    class TestVirtualSysctlDetectionMixinWithSysctl(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = module

# Generated at 2022-06-20 20:57:17.910542
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v

# vim: set et:

# Generated at 2022-06-20 20:57:28.127748
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class module:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, a):
            return '/usr/sbin/sysctl'
        def run_command(self, a):
            return a

    class mqm:
        def __init__(self):
            self.module = module()

    facts = {}
    mqm = mqm()
    mqm.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product
    facts = mqm.detect_virt_product(VirtualSysctlDetectionMixin, key="/dev/vmm/vmm0")

# Generated at 2022-06-20 20:57:36.681534
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import detect_virt_product
    klass = VirtualSysctlDetectionMixin()

    # Test: Guest Technology Detection