

# Generated at 2022-06-23 02:34:39.396470
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        pass
    x = TestClass()
    assert x

# Generated at 2022-06-23 02:34:48.720304
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import ModuleDeprecationWarning

    class MockVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, **kwargs):
            self.sysctl_path = kwargs['sysctl_path']

        def detect_sysctl(self):
            pass

        def detect_virt_product(self, key):
            return super(MockVirtualSysctlDetectionMixin, self).detect_virt_product(key)

    virtual_facts = dict()
    obj = MockVirtualSysctlDetectionMixin(sysctl_path='/usr/sbin/sysctl')

# Generated at 2022-06-23 02:34:51.337328
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_class = VirtualSysctlDetectionMixin()  # Cannot use direct object creation, as the module is unaware of this class
    assert test_class

# Generated at 2022-06-23 02:35:01.648951
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
        from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
        my_test = VirtualSysctlDetectionMixin()
        my_test.module = MockModule()
        my_test.module.run_command = MockRunCommand()
        my_test.module.run_command.return_value = (0, 'QEMU\n', None)
        virtual_vendor_facts = virtual_vendor_facts = my_test.detect_virt_vendor('hw.model')
        assert virtual_vendor_facts['virtualization_type'] == 'kvm'
        assert virtual_vendor_facts['virtualization_role'] == 'guest'
        assert 'kvm' in virtual_vendor_facts['virtualization_tech_guest']
        assert 'kvm' not in virtual_vendor_facts

# Generated at 2022-06-23 02:35:03.206079
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    assert obj.sysctl_path is None

# Generated at 2022-06-23 02:35:11.995860
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    host_virtual_facts = {}
    host_virtual_facts["virtualization_type"] = "xen"
    host_virtual_facts["virtualization_role"] = "guest"

    openbsd_virtual_facts = {}
    openbsd_virtual_facts["virtualization_type"] = "openbsd"
    openbsd_virtual_facts["virtualization_role"] = "guest"

    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin.detect_virt_product(
        'hw.product') == host_virtual_facts

    assert virtual_sysctl_detection_mixin.detect_virt_vendor(
        'hw.vendor') == openbsd_virtual_facts

# Generated at 2022-06-23 02:35:20.948740
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    sysctl_obj = VirtualSysctlDetectionMixin()
    sysctl_obj.module = module
    sysctl_obj.detect_sysctl()
    if sysctl_obj.sysctl_path != module.get_bin_path('sysctl'):
        module.fail_json(msg='Returned invalid sysctl path')
    else:
        if module.get_bin_path('sysctl'):
            module.exit_json(changed=False)
        else:
            module.fail_json(msg='Could not find sysctl on host')



# Generated at 2022-06-23 02:35:30.252020
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    args = {}
    args['module'] = None
    args['sysctl_path'] = "sysctl_path"

    ansible_module = VirtualSysctlDetectionMixin()
    ansible_module.module = AnsibleModule(**args)

    import sys
    if sys.version_info[:2] > (2, 6):
        from unittest.mock import Mock
    else:
        from mock import Mock

    ansible_module.run_command = Mock(return_value=(0, "", ""))

    result = ansible_module.detect_virt_vendor("hw.product")


# Generated at 2022-06-23 02:35:34.193585
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    #  sysctl_path = self.module.get_bin_path('sysctl')
    # We need a way to fake the value of this, so we can test it.
    # How do we actually do that?
    assert 'sysctl'


# Generated at 2022-06-23 02:35:44.699913
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleMock():
        def __init__(self):
            self.params = {}
            self.run_command_result = None

        def get_bin_path(self, arg):
            return "/sbin/sysctl"

        def run_command(self, arg):
            return self.run_command_result

    class MyFactCollector(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FactsCollectorEmpty():
        def __init__(self):
            self.facts = {}

        def populate(self):
            self.facts = {}

    myFactCollector = MyFactCollector(ModuleMock())
    myFactCollector.vm_facts_collector = FactsCollectorEmpty()

# Generated at 2022-06-23 02:35:50.700879
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    instance = TestClass()
    instance.module = MockModule()
    instance.detect_sysctl()
    assert instance.sysctl_path == '/bin/sysctl'


# Mock for module - so we do not have any outside dependencies

# Generated at 2022-06-23 02:36:01.879518
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    hostname = 'debian_host'
    key = 'hw.vmm.vm_guest'
    virtual_vendor_facts = {}
    guest_tech = set()
    rc = 0
    out = 'OpenBSD'
    err = ''

    class module:
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, command):
            return rc, out, err
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = module()

    test_sysctl = TestVirtualSysctlDetectionMixin()
    test_sysctl.detect_virt_vendor(key)
    guest_tech.add('vmm')

# Generated at 2022-06-23 02:36:03.678658
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:36:13.567179
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule:
        def get_bin_path(self, bin):
            return bin

        def run_command(self, cmd):
            if cmd.startswith('sysctl -n machdep.cpu.vendor'):
                return 0, 'QEMU', ''
            if cmd.startswith('sysctl -n dm.version.version_string'):
                return 0, 'OpenBSD', ''
            if cmd.startswith('sysctl -n security.jail.jailed'):
                return 0, '1', ''

    class TestOS:
        def __init__(self):
            self.module = TestModule()

    from ansible.module_utils.facts.virt.bsd import VirtualSysctlDetectionMixin
    vd = VirtualSysctlDetectionMixin()
    vd.module = Test

# Generated at 2022-06-23 02:36:26.756320
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from units.compat.mock import MagicMock, call
    import os
    import sys
    sys.path.append(os.path.dirname(os.path.realpath(__file__)))
    test_module = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'test_openbsd.py')
    test_data_dir = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../unit/modules/test_data/openbsd')
    mod_utils = os.path.join(os.path.dirname(os.path.realpath(__file__)), '../../lib/ansible/module_utils')

    m = MagicMock(return_value=(0, 'something', ''))


# Generated at 2022-06-23 02:36:33.404764
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixin_Facts():
        module = None
        sysctl_path = None

    class VirtualSysctlDetectionMixin_Module():
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    sysctl_facts = VirtualSysctlDetectionMixin_Facts()
    sysctl_facts.module = VirtualSysctlDetectionMixin_Module()
    obj = VirtualSysctlDetectionMixin()
    obj.module = VirtualSysctlDetectionMixin_Module()

# Generated at 2022-06-23 02:36:42.862166
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    from ansible.module_utils.facts.virt.detect_sysctl import VirtualSysctlDetectionMixin

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.detect_sysctl()

    test_module = mock.MagicMock()
    test_module.get_bin_path.return_value = bool(True)
    test_module.run_command.return_value = (0, 'QEMU', '')
    test_module.params = {}
    test_system = TestClass(test_module)

    result = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm'])
    }

# Generated at 2022-06-23 02:36:52.006348
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils._text import to_text
    from ansible.module_utils import basic
    from ansible.module_utils.facts.virtual import VirtualFactCollector
    from ansible.module_utils.facts import hashivault
    from ansible.modules.system import setup

    class FakeModule(object):
        def __init__(self, bin_ansible_callbacks=None):
            self._debug = False
            self._verbosity = False
            self.params = {}
            if bin_ansible_callbacks:
                self._ansible_version = bin_ansible_callbacks

        def fail_json(self, *args, **kwargs):
            self.exit_args = args

# Generated at 2022-06-23 02:36:56.913330
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    test_virtual_sysctl_detection_mixin = TestVirtualSysctlDetectionMixin()
    assert test_virtual_sysctl_detection_mixin


# Generated at 2022-06-23 02:37:05.007365
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {
                'vendor': 'openbsd'
            }

        def get_bin_path(self, path):
            return "/sbin/sysctl"

        def run_command(self):
            return (0, 'OpenBSD', '')

    virtual_vendor_module = VirtualSysctlDetectionMixin()
    module = FakeModule()
    virtual_vendor_module.module = module

    virtual_vendor_facts = virtual_vendor_module.detect_virt_vendor('machdep.hypervisor_vendor')

    assert virtual_vendor_facts['virtualization_type'] == 'vmm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:37:13.439053
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mod = VirtualSysctlDetectionMixin()
    virtual_product_facts = {}
    host_tech = set()
    guest_tech = set()

    out = "KVM"
    if re.match('(KVM|kvm|Bochs|SmartDC).*', out):
        guest_tech.add('kvm')
        virtual_product_facts['virtualization_type'] = 'kvm'
        virtual_product_facts['virtualization_role'] = 'guest'
    virtual_product_facts['virtualization_tech_guest'] = guest_tech
    virtual_product_facts['virtualization_tech_host'] = host_tech
    out = mod.detect_virt_product('hw.product')['virtualization_tech_guest']
    assert out == guest_tech


# Generated at 2022-06-23 02:37:22.991257
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda arg: [0, 'QEMU', '']
            self.get_bin_path = lambda arg: '/sbin/sysctl'

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    expected_result = {
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
    }
    o = FakeVirtualSysctlDetectionMixin()
    result = o.detect_virt_vendor('hw.model')
    assert result == expected_result

# Generated at 2022-06-23 02:37:25.624359
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mixin = VirtualSysctlDetectionMixin()
    setattr(mixin, 'module', MockModule())
    mixin.detect_sysctl()
    assert(mixin.sysctl_path == '/sbin/sysctl')



# Generated at 2022-06-23 02:37:32.600961
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Module(object):
        def get_bin_path(self, app, required=False):
            if app == 'sysctl':
                return app

    class DummyVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.module = Module()

    myobj = DummyVirtualSysctlDetectionMixin()
    myobj.detect_sysctl()

    assert myobj.sysctl_path == 'sysctl'


# Generated at 2022-06-23 02:37:43.767864
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    '''
    Test for method detect_virt_product in class VirtualSysctlDetectionMixin
    '''

    class MockModule(object):
        class MockRunCommand(object):
            def __init__(self):
                self.out = []
            def __call__(self, *args, **kwargs):
                retval = 0
                out = 'Other'
                if args[0] == 'sysctl -n hw.model':
                    retval = 0
                    out = 'VMware'
                if args[0] == 'sysctl -n security.jail.jailed':
                    retval = 0
                    out = '1'
                return retval, out, ''

        def __init__(self):
            self.run_command = self.MockRunCommand()


# Generated at 2022-06-23 02:37:54.167493
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    detect = VirtualSysctlDetectionMixin()
    detect.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    rc = detect.detect_virt_product(key='kern.bootfile')
    assert rc['virtualization_type'] is 'xen'
    assert rc['virtualization_role'] is 'guest'
    assert rc['virtualization_tech_guest'] is 'xen'
    assert rc['virtualization_tech_host'] is set()
    rc = detect.detect_virt_product(key='hw.model')
    assert rc['virtualization_type'] is 'virtualbox'
    assert rc['virtualization_role'] is 'guest'
    assert rc['virtualization_tech_guest'] is 'virtualbox'

# Generated at 2022-06-23 02:38:05.726350
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import platform
    from ansible.module_utils.facts.system.base import BaseFactCollector
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts import collector

    class FakeModule():
        def __init__(self):
            self.params = {'timeout': 10}
            self.run_command = run_command_stub
            self.get_bin_path = get_bin_path_stub

    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin, BaseFactCollector):
        def __init__(self, module=None, collected_facts=None):
            self.timeout = timeout.Timeout(module=module)

# Generated at 2022-06-23 02:38:15.072025
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    detect_virt_vendor_facts = {
        'virtualization_type': 'vmm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'vmm'},
        'virtualization_tech_host': set(),
    }
    obj = VirtualSysctlDetectionMixin()
    obj.module = MockModule()
    obj.module.run_command = Mock(return_value=(0, 'OpenBSD', ''))
    obj.sysctl_path = '/usr/bin/sysctl'
    assert obj.detect_virt_vendor('hw.model') == detect_virt_vendor_facts



# Generated at 2022-06-23 02:38:23.892266
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class test_VirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        """
        Stub class to test detect_sysctl
        """
    def mock_get_bin_path(dummy):
        """
        mock implementation of get_bin_path
        """
        return dummy

    class module:
        """
        Stub class to tell detect_sysctl where to find the sysctl binary
        """

        def __init__(self, sysctl_bin):
            self.get_bin_path = mock_get_bin_path
            self.run_command = lambda arg1: (0, arg1, '')

        def get_bin_path(self, arg1):
            """
            Pseudo-implementation of get_bin_path()
            """
            return arg1


# Generated at 2022-06-23 02:38:34.777840
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class StubModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return 'stub'

        def run_command(self, cmd):
            rc = 0
            out = ""
            err = ""
            return (rc, out, err)

    class StubClass(object):
        def __init__(self):
            self.module = StubModule()

    testObj = StubClass()
    testObj.detect_sysctl()

    assert testObj.sysctl_path == 'stub'
    assert testObj.detect_virt_product("hw.model") == {}
    assert testObj.detect_virt_product("hw.machine_arch") == {}
    assert testObj.detect_virt_vendor("hw.machine") == {}

# Generated at 2022-06-23 02:38:42.803320
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def get_bin_path(self, param):
            return '/bin/sysctl'
    fake_module = FakeModule()
    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
    sysctl_detect = FakeClass(fake_module)
    sysctl_detect.detect_sysctl()
    assert sysctl_detect.sysctl_path == '/bin/sysctl'



# Generated at 2022-06-23 02:38:55.646801
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sysctl
    sysctl_obj = sysctl.SYSCTL()

    # test for QEMU
    sysctl_obj.module = FakeModule()
    sysctl_obj.module.run_command = MockRunCommand(rc=0, out="QEMU")
    assert sysctl_obj.detect_virt_vendor("hw.model") == \
            {'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([]),
             'virtualization_type': "kvm", 'virtualization_role': 'guest'}

    # test for OpenBSD
    sysctl_obj.module = FakeModule()
    sysctl_obj.module.run_command = MockRunCommand(rc=0, out="OpenBSD")
    assert sysctl_obj.detect_virt

# Generated at 2022-06-23 02:39:05.319896
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    pbsd_module = type('module', (object,), {'run_command': (lambda cmd: (0, 'OpenBSD', '')),
                                             'get_bin_path': (lambda name: '/sbin/sysctl')})()
    pbsd_detection_mixin = type('detection_mixin', (object,), {'module': pbsd_module})()

    assert pbsd_detection_mixin.detect_virt_vendor('kern.vm_guest') == {'virtualization_tech_host': set(),
                                                                        'virtualization_tech_guest': set(['vmm']),
                                                                        'virtualization_role': 'guest',
                                                                        'virtualization_type': 'vmm'}

# Generated at 2022-06-23 02:39:16.180743
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self, rc=0, out="QEMU", err="", out2="OpenBSD",
                     command_results=None):
            self.rc = rc
            self.out = out
            self.err = err
            self.out2 = out2
            self.command_results = command_results

        def run_command(self, cmd):
            if self.command_results:
                return self.command_results[cmd]
            else:
                return (self.rc, self.out, self.err)

        def get_bin_path(self, cmd):
            if cmd == 'sysctl':
                if self.rc is 0:
                    return "/usr/bin/sysctl"
            return None


# Generated at 2022-06-23 02:39:26.333870
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = {}

        def detect_sysctl(self):
            self.sysctl_path = "/bin/sysctl"

        def module_run_command(self, cmd):
            kvm = re.compile("(KVM|kvm|Bochs|SmartDC).*")
            vmware = re.compile(".*VMware.*")
            vbox = re.compile("VirtualBox")
            xen = re.compile("(HVM domU|XenPVH|XenPV|XenPVHVM).*")
            hyperv = re.compile("Hyper-V")
            parallels = re.compile("Parallels")

# Generated at 2022-06-23 02:39:28.361648
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    a = VirtualSysctlDetectionMixin()
    assert a

# Generated at 2022-06-23 02:39:37.691191
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg1):
            return '/fake/bin/path'

        def run_command(self, arg1):
            out = 'OpenBSD'
            return 0, out, ''

    class FakeOS(object):
        def __init__(self):
            self.virt_vendor_facts = {}
            self.os_release_fact_dict = {'release': {'pretty_name': '', 'name': 'Ubuntu', 'version': '14.04', 'id': 'ubuntu'}}
            self.kernel_fact_dict = {'kernel': 'Darwin'}
            self.module = FakeModule()

        def detect(self):
            return {'os_family': 'Debian'}

# Generated at 2022-06-23 02:39:39.651957
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    assert True, "Not implemented"


# Generated at 2022-06-23 02:39:48.850478
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    facts = {
        'kernel_vm_guest': '',
        'kernel_vm_host': '',
    }
    # Mocked fixture
    def get_bin_path(self, binary):
        return '/sbin/sysctl'
    # Mocked fixture
    def run_command(self, command):
        import os
        import sys

        # Mock Xen PV (freebsd-version 10.4-STABLE)

# Generated at 2022-06-23 02:39:59.129371
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    # Assert that the mixin has a detect_sysctl method
    assert hasattr(mixin, 'detect_sysctl')
    # Assert that the mixin has a detect_virt_product method
    assert hasattr(mixin, 'detect_virt_product')
    # Assert sysctl_path is None and that is the case because detect_sysctl() has no command line arg
    assert mixin.sysctl_path is None
    # Assert that there is no virtualization type and virtualization role
    assert mixin.detect_virt_product('hw.product')['virtualization_type'] is None
    assert mixin.detect_virt_product('hw.product')['virtualization_role'] is None
    # Assert that there are no virtualization technologies for both guest and

# Generated at 2022-06-23 02:40:07.684037
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):

        def get_bin_path(self, path):
            return sysctl_path

        def run_command(self, command):
            if command == sysctl_path + " -n virtual":
                return 0, "KVM", None
            elif command == sysctl_path + " -n security.jail.jailed":
                return 0, "1", None
            else:
                raise Exception('This test function should not be called with this argument: ' + command)

    FakeVMDetectionMixin = type('FakeVMDetectionMixin', (VirtualSysctlDetectionMixin,), {'module': FakeModule()})

    sysctl_path = "/usr/sbin/sysctl"


# Generated at 2022-06-23 02:40:09.277431
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # FIXME: Need a module for this
    pass


# Generated at 2022-06-23 02:40:12.052486
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()


# Generated at 2022-06-23 02:40:22.816170
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_points = []
            self.rc = 0
            self.out = ''
            self.err = ''
            self.bin_path = '/usr/bin'

        def get_bin_path(self, name):
            return self.bin_path

        def run_command(self, command):
            self.run_command_points.append(command)
            return self.rc, self.out, self.err

    class FakeOpenbsdSysctl(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = ''
            self.virtualization_vendor = ''
            self.virtualization_product = ''

    openbsd_sysctl = FakeOpen

# Generated at 2022-06-23 02:40:32.553313
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class AnsibleModuleMock(object):

        def __init__(self, *args, **kwargs):
            pass

        def run_command(self, command):
            return 0, "", ""

        def get_bin_path(self, name):
            return "/usr/sbin/sysctl"

    class OpenBSDVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):

        def __init__(self, module):
            self.module = module
            self.facts = dict()
            self.facts['ansible_system'] = 'OpenBSD'
            self.sysctl_path = None

    kk = OpenBSDVirtualSysctlDetectionMixin(AnsibleModuleMock)

    assert kk.detect_sysctl() == None

# Generated at 2022-06-23 02:40:36.591155
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert(VirtualSysctlDetectionMixin is not None)
    virtualSysctlDetectionMixin = VirtualSysctlDetectionMixin()
    assert(virtualSysctlDetectionMixin is not None)
    assert(virtualSysctlDetectionMixin.sysctl_path is None)
    assert(virtualSysctlDetectionMixin.module is None)

# Generated at 2022-06-23 02:40:48.852157
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualizationFactCollector
    import os
    import sys

    # Obtain a class object
    vsc = VirtualizationFactCollector()

    # Use a dummy PATH value in case the system does not have sysctl
    try:
        test_path = os.environ['PATH']
    except:
        test_path = ''

    os.environ['PATH'] = '/bin:/sbin:/usr/bin:/usr/sbin'

    # Determine if sysctl has been detected
    if sys.platform == 'darwin':
        # sysctl is not present on OSX.  So no need to test it.  Just
        # set the path to something random
        os.environ['PATH'] = test_path
        vsc.detect_sysctl()
        assert vsc.sysctl_

# Generated at 2022-06-23 02:40:57.136773
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils import basic
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts import virt_facts

    m = AnsibleModule(argument_spec=dict())
    m.run_command = lambda x: (0, 'QEMU', '')
    v = virt_facts.VirtualSysctlDetectionMixin()

    v.module = m
    result = v.detect_virt_vendor('hw.model')

    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:41:00.036380
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import module_utils.facts.virtual.bsd.freebsd
    mixin = VirtualSysctlDetectionMixin()
    module = module_utils.facts.virtual.bsd.freebsd.Virtual()
    mixin.set_module(module)
    assert hasattr(mixin, 'detect_sysctl')

# Generated at 2022-06-23 02:41:10.584145
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestVirtualSysctlDetectionMixin(object, VirtualSysctlDetectionMixin):
        module = None
        sysctl_path = "/sbin/sysctl"
        virtualization_type = None
        virtualization_role = None

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

        def run_command(self, cmd):
            mock_result = "(QEMU, OpenBSD)"
            rc = 0
            out = mock_result
            err = None
            return rc, out, err

    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return "/sbin/sysctl"

    v_sysctl_mixin = TestVirtualSysctlDetectionMixin()
    v_sysctl

# Generated at 2022-06-23 02:41:13.497571
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    assert mixin

# Unit tests for class methods detect_virt_product and detect_virt_vendor

# Generated at 2022-06-23 02:41:22.807824
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import platform
    import unittest
    unittest.TestCase().assertEqual
    class TestClass(object):
        pass
    test_class = TestClass()
    test_class.default_sysctl = platform.system()
    test_class.module = TestClass()
    test_class.module.run_command = lambda x: (0, x, '')
    test_class.module.get_bin_path = lambda x: x
    VirtualSysctlDetectionMixin.detect_sysctl(test_class)
    VirtualSysctlDetectionMixin.detect_virt_product(test_class, 'hw.model')
    VirtualSysctlDetectionMixin.detect_virt_vendor(test_class, 'hw.vendor')

# Generated at 2022-06-23 02:41:30.625306
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class BSDModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'foo'
            self.run_command_err = ''

        def get_bin_path(self, executable):
            return '/usr/local/bin'

        def run_command(self, args):
            return [self.run_command_rc, self.run_command_out, self.run_command_err]

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = BSDModule()
    mixin = TestVirtualSysctlDetectionMixin(module)
    rc, out, err = module.run_command('sysctl -n hw.model')

# Generated at 2022-06-23 02:41:39.856221
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, bin_path, run_command_list):
            self._bin_path = bin_path
            self._run_command_list = run_command_list
            self.fail_json = lambda **kwargs: (1, "", "")
        def get_bin_path(self, executable, required=False):
            return self._bin_path.get(executable)
        def run_command(self, command):
            return self._run_command_list.pop(0)

    fake_bin_path = dict(sysctl='/bin/sysctl')

# Generated at 2022-06-23 02:41:51.905359
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.openbsd_virtual import OpenBSDVirtualDetectionMixin
    from ansible.module_utils.facts.virtual.openbsd_virtual import VirtualOpenBSD
    class MockVirtualOpenBSD(OpenBSDVirtualDetectionMixin):
        def __init__(self):
            self.module = MockModule()
            # sysctl is not available on MacOS
            self.sysctl_path = None
            # test with sysctl
            self.sysctl_path = '/usr/bin/sysctl'

    vtest = VirtualOpenBSD()
    virtual_vendor_facts = vtest.detect_virt_vendor('machdep.emulated_platform')
    assert(virtual_vendor_facts['virtualization_type'] == 'kvm')

# Generated at 2022-06-23 02:41:55.430356
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vmix = VirtualSysctlDetectionMixin()
    vmix.module = DummyModule({})
    vmix.detect_sysctl()
    vmix.detect_virt_product('hw.model')

# DummyModule

# Generated at 2022-06-23 02:42:05.790694
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class AnsibleModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, prog):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return 0, cmd, ""

        def fail_json(self, msg):
            raise Exception(msg)

    class VirtualSysctlDetectionMixinTester(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModule()

    tester = VirtualSysctlDetectionMixinTester()
    tester.detect_virt_vendor("kern.vm_guest")

# Generated at 2022-06-23 02:42:14.373323
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import FactCollector
    class VirtualSysctlDetectionMixinImplementation(FactCollector, VirtualSysctlDetectionMixin):
        def collect(self, module=None, collected_facts=None):
            return {}

    sysctl_path = "/sbin/sysctl"
    test_instance = VirtualSysctlDetectionMixinImplementation()
    test_instance.module = FakeAnsibleModule(sysctl_path)
    test_instance.detect_sysctl()
    assert test_instance.sysctl_path == "/sbin/sysctl"


# Generated at 2022-06-23 02:42:23.051092
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MyClass(object):
        def __init__(self):
            self.sysctl_path = None
        def get_bin_path(self, binname):
            if binname == "sysctl":
                return binname

    class MyClass2(VirtualSysctlDetectionMixin, object):
        def __init__(self):
            self.sysctl_path = None
            self.module = MyClass()
            self.detect_sysctl()

    MyClass2()

# Generated at 2022-06-23 02:42:30.625286
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule:
        def get_bin_path(args):
            return "/bin/sysctl"
        def run_command(args):
            if args == "/bin/sysctl -n hw.model":
                return 0, "QEMU Virtual CPU version 1.0", ""
            elif args == "/bin/sysctl -n security.jail.jailed":
                return 0, "1", ""
    class MockMe():
        def __init__(self):
            self.module = MockModule()

    me = MockMe()
    me.detect_sysctl()
    me.detect_virt_vendor("hw.model")
    me.detect_virt_product("security.jail.jailed")
    # Global should have a virtualization_type
    assert me.virtual_facts['virtualization_type']

# Generated at 2022-06-23 02:42:38.439096
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x, use_unsafe_shell=False, environ_update=None: (0, x, '')
        def get_bin_path(self, name):
            return "true"

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()

    assert mixin.detect_virt_product('hw.model') == {
        'virtualization_tech_guest': set(),
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:42:47.084506
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.virtual.freebsd import VirtualSysctlDetectionMixin

    class TestClass:
        def __init__(self):
            self.module = TestModule()

    class TestModule:
        def get_bin_path(self, name):
            if name == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

    obj = TestClass()
    obj.detect_sysctl()
    assert obj.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-23 02:42:57.739365
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def __init__(self, *args, **kwargs):
            self._vm_facts = {'virtualization_type': None, 'virtualization_role': None,
                              'virtualization_tech_guest': None, 'virtualization_tech_host': None}
            self.run_command = lambda *args, **kwargs: (0, 'QEMU', '')
            self.get_bin_path = lambda *args, **kwargs: '/usr/bin/sysctl'

    # Test detection of qemu as vendor
    fake_module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    # Set mixin variables
    mixin.module = fake_module
    mixin.sysctl_path = None
    # Call function
    facts = mixin.detect_virt

# Generated at 2022-06-23 02:43:06.406789
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Obj:
        def __init__(self):
            self.module = mock.MagicMock()
            self.module.get_bin_path.return_value = '/usr/bin/sysctl'
            self.module.run_command.return_value = (0, 'MacBookAir4,2', '')
    obj = Obj()
    VirtualSysctlDetectionMixin().detect_sysctl(obj)
    assert obj.sysctl_path == '/usr/bin/sysctl'



# Generated at 2022-06-23 02:43:17.017227
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    vm_facts = VirtualSysctlDetectionMixin()
    vm_facts.module = AnsibleModuleMock('sysctl')
    vm_facts.module.run_command = run_command_mock
    vm_facts.detect_virt_vendor('kern.vm_guest')
    assert vm_facts.module.run_command_calls[0] == ['sysctl -n kern.vm_guest']
    assert vm_facts.module.run_command_results[0] == (0, 'QEMU', '')
    assert vm_facts.module.facts['virtualization_tech_guest'] == {'kvm'}
    assert vm_facts.module.facts['virtualization_type'] == 'kvm'
    assert vm_facts.module.facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:43:26.776617
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import sys

    sys.path.append('/Users/Shared/Jenkins/Home/workspace/local_qpc_tox/lib/python2.7/site-packages')
    from ansible.module_utils.facts.virtual.base import Virtual, VirtualCollector

    v = Virtual(module=None)
    vsdm = VirtualSysctlDetectionMixin()
    setattr(v, 'module', VirtualCollector())
    v.module.get_bin_path = lambda x: '/sbin/sysctl'
    v.module.run_command = lambda x: (0, '', '')
    vsdm.detect_virt_product = lambda x: {}
    vsdm.detect_sysctl()
    vsdm.detect_virt_vendor = lambda x: {}

# Generated at 2022-06-23 02:43:37.165393
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.bsd import VirtualSysctlDetectionMixin

    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'OpenBSD\n', ''

    class MockFreebsdSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    virtual_product_facts = MockFreebsdSysctlDetectionMixin(MockModule()).detect_virt_vendor('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'vmm'

# Generated at 2022-06-23 02:43:38.429499
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vDetMixin = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:43:48.442184
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # test data
    key = "kern.drivers.bio.bio_drivers"
    rc = 0
    out = "OpenBSD"

    class FakeModule(object):
        """ Fake object for unit test """
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name, opts=None, required=False, path=None):
            return "sysctl"

        def run_command(self, *args, **kwargs):
            return rc, out, None

    fake = FakeModule()
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = fake
    result = test_object.detect_virt_vendor(key)

    assert result['virtualization_type'] == 'vmm'

# Generated at 2022-06-23 02:43:54.459091
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # We test by checking the return code and the output
    VirtualSysctlDetectionMixin()

    # Return code  >0 or not
    rc = 0
    out = 'QEMU'
    err = ''
    if rc > 0 or out != 'QEMU':
        return {'virtualization_tech_guest': ['kvm'], 'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_host': []}
    else:
        return {}



# Generated at 2022-06-23 02:44:05.349429
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = type('FakeModule', (object,), {})
    vm = VirtualSysctlDetectionMixin()
    vm.sysctl_path = None
    vm.module = module
    vm.detect_sysctl = lambda: True
    rc, out, err = 0, '\n', ''
    vm.module.run_command = lambda x: (rc, out, err)
    assert {} == vm.detect_virt_vendor("virtual_vendor")
    rc, out, err = 0, 'OpenBSD\n', ''
    assert {'virtualization_type':'vmm', 'virtualization_role':'guest', 'virtualization_tech_guest':set(['vmm']), 'virtualization_tech_host':set()} == vm.detect_virt_vendor("virtual_vendor")
    rc,

# Generated at 2022-06-23 02:44:10.332703
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MagicMock()
    candidates = ('security.jail.jailed', 'hw.model', 'hw.machine')
    for candidate in candidates:
        mixin.detect_virt_product(candidate)
        assert mixin.sysctl_path


# Generated at 2022-06-23 02:44:19.042342
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    my_obj = VirtualSysctlDetectionMixin()
    my_obj.module = MagicMock()
    my_obj.module.get_bin_path = MagicMock(return_value='/bin/sysctl')
    my_obj.detect_sysctl = MagicMock()
    my_obj.detect_sysctl()
    assert my_obj.sysctl_path == '/bin/sysctl'
    my_obj.detect_sysctl()
    assert my_obj.detect_sysctl.call_count == 1


# Generated at 2022-06-23 02:44:24.485110
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MockModule()
    sysctl_vendor = VirtualSysctlDetectionMixin()
    sysctl_vendor.module = module
    sysctl_vendor.sysctl_path = '/usr/bin/sysctl'
    assert sysctl_vendor.detect_sysctl()


# Generated at 2022-06-23 02:44:29.645814
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    x = VirtualSysctlDetectionMixin()
    x.sysctl_path = '/usr/bin/sysctl'
    x.module = MockAnsibleModule()
    assert isinstance(x.detect_virt_vendor('hw.product'), dict)


# Generated at 2022-06-23 02:44:32.078119
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    obj.detect_sysctl()
    assert obj.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-23 02:44:41.135725
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin