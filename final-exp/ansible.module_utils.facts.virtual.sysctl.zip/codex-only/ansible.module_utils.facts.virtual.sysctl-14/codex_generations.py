

# Generated at 2022-06-23 02:34:46.202495
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import ansible.utils.virtual_sysctl_detection_mixin as mixin
    module = mixin.VirtualSysctlDetectionMixin()
    module.module = None
    module.sysctl_path = 'sysctl'
    product_key = ('hw.product' in mixin.VIRTUAL_PRODUCT_KEYS) and 'hw.product' or 'hw.model'
    product_facts = {'virtualization_tech_guest': set(['kvm']), 'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_host': set()}
    assert module.detect_virt_product(product_key) == product_facts

# Generated at 2022-06-23 02:34:56.443530
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Skip this whole test if detect_virt_vendor is not defined in the class
    # we're testing
    if not hasattr(VirtualSysctlDetectionMixin, 'detect_virt_vendor'):
        return

    from ansible.module_utils.facts.collector import BaseFactCollector
    import ansible.module_utils.facts.virtual.openbsd

    class MyVirtualCollector(BaseFactCollector):
        _fact_class = ansible.module_utils.facts.virtual.openbsd.VirtualCollector

    # Create a "mock" module object and set the following attributes.
    # These attributes should match the types of the arguments to the
    # collect() method we're testing.
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command

# Generated at 2022-06-23 02:34:59.058339
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert isinstance(virtual_sysctl_detection_mixin, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:35:10.306051
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, name):
            return '/usr/bin/sysctl'
        def run_command(self, cmd):
            if cmd == '/usr/bin/sysctl -n kern.version':
                return (0, 'OpenBSD', '')
            elif cmd == '/usr/bin/sysctl -n hw.model':
                return (0, 'OpenBSD', '')
            elif cmd == '/usr/bin/sysctl -n security.jail.jailed':
                return (0, '0', '')
            else:
                raise Exception("Wrong command passed to run_command for test!")

    c = VirtualSysctlDetectionMixin()
    c.module = FakeModule()
   

# Generated at 2022-06-23 02:35:21.348301
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Create a class with the needed attributes
    class FakeModule(object):
        def __init__(self, name):
            self.name = name
            self.run_command_result = [0, 'QEMU', '']
        def get_bin_path(self, cmd, opt_dirs=None):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            return self.run_command_result

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # This is what we expect to be returned

# Generated at 2022-06-23 02:35:26.096759
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import Mock

    # Create instance
    vmd = VirtualSysctlDetectionMixin()
    vmd.module = Mock()
    vmd.module.get_bin_path = Mock(return_value='/bin/sysctl')

    # Call method with valid input
    vmd.detect_sysctl = Mock()
    vmd.detect_virt_vendor = Mock()
    vmd.detect_virt_vendor('security.jail.jailed')

    assert vmd.sysctl_path == '/bin/sysctl'

# Generated at 2022-06-23 02:35:35.018177
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    openbsd_virtual = OpenBSDVirtual()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    openbsd_virtual.module = None
    openbsd_virtual.sysctl_path = None
    openbsd_virtual.sysctl_path = virtual_sysctl_detection_mixin.detect_sysctl(openbsd_virtual)


# Generated at 2022-06-23 02:35:37.361790
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    detection_object = VirtualSysctlDetectionMixin()
    detection_object.module = None
    assert detection_object.sysctl_path is None

# Generated at 2022-06-23 02:35:47.702588
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    def run_module(task_args=None):
        class TestVirtualSysctlDetectionMixinClass():
            def __init__(self, module, test_sysctl_path):
                self.module = module
                self.sysctl_path = test_sysctl_path

            def detect_sysctl(self):
                pass

        mod = TestVirtualSysctlDetectionMixinClass(module, sysctl_path)
        mixin = VirtualSysctlDetectionMixin()
        mixin.sysctl_path = mod.sysctl_path
        facts = mixin.detect_virt_product({
            'hw.model': 'KVM'
        })
        return facts

    from ansible.module_utils.facts import VirtualSysctlDetectionMixin


# Generated at 2022-06-23 02:35:56.648542
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleMock(object):
        class RunCommandMock(object):
            def __init__(self):
                self.rc = 0
                self.out = ''
                self.err = ''
        def get_bin_path(self, path, opt_dirs=[]):
            return '/usr/bin/sysctl'
        def run_command(self, cmd):
            return RunCommandMock()
    module = ModuleMock()

    class TestClass(object):
        class VirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
            def __init__(self):
                self.module = module

    test_class = TestClass()
    test_class.VirtualSysctlDetectionMixin()
    test_class.detect_virt_vendor('kern.vm_guest')
    test_class

# Generated at 2022-06-23 02:35:59.877923
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    __test_VirtualSysctlDetectionMixin = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:36:01.478752
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v is not None

# Generated at 2022-06-23 02:36:06.436620
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestObject:
        def __init__(self):
            self.module = AnsibleModuleStub()

    t = TestObject()
    t.detect_sysctl()
    assert t.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:36:08.222503
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    assert mixin is not None

# Generated at 2022-06-23 02:36:17.197465
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    mixin = VirtualSysctlDetectionMixin()
    # test for return values expected for VirtualBox on FreeBSD 11.2
    out1 = 'QEMU'
    out2 = 'OpenBSD'
    mixin.module = {'run_command': lambda command: (0, out1, '')}
    results = mixin.detect_virt_vendor('machdep.hypervisor_vendor')
    assert results == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([]),
    }

# Generated at 2022-06-23 02:36:20.167183
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl = VirtualSysctlDetectionMixin()
    assert virtual_sysctl is not None



# Generated at 2022-06-23 02:36:21.989053
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_openbsd_os = VirtualSysctlDetectionMixin()

    assert test_openbsd_os != None

# Generated at 2022-06-23 02:36:28.386199
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class module_mock:
        def get_bin_path(self, arg):
            return "/bin/true"

    virtual_facts = VirtualSysctlDetectionMixin()
    virtual_facts.module = module_mock()
    virtual_facts.detect_sysctl()
    assert virtual_facts.sysctl_path == "/bin/true"


# Generated at 2022-06-23 02:36:37.874691
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class AnsibleModule_mock(object):
        def __init__(self):
            self.run_command_args = []

        def run_command(self, args):
            self.run_command_args.append(args)
            if args == '/usr/sbin/sysctl -n kern.hostuuid':
                return (0, '3e3bc455-88da-11e6-b2f2-080027c12788', '')
            elif args == '/usr/sbin/sysctl -n kern.vm_guest':
                return (0, '\"FreeBSD\"', '')
            elif args == '/usr/sbin/sysctl -n security.jail.jailed':
                return (0, '1', '')
            else:
                return (0, '', '')

# Generated at 2022-06-23 02:36:40.070158
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    ad = VirtualSysctlDetectionMixin()
    assert ad is not None

# Generated at 2022-06-23 02:36:47.935120
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class test_module:
        class exit_json:
            def __init__(self, rc):
                self.rc = rc
            def __call__(self, rc):
                return self.rc

        class fail_json:
            def __init__(self, rc):
                self.rc = rc
            def __call__(self, rc):
                return self.rc

        def __init__(self):
            self.params = {'sysctl': '/sbin/sysctl'}
            self.exit_json = test_module.exit_json(0)
            self.fail_json = test_module.fail_json(1)
            self.run_command = run_command

        def get_bin_path(self, key):
            if key == 'sysctl':
                return '/sbin/sysctl'

   

# Generated at 2022-06-23 02:36:53.071559
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # We fixture the module to give us a clean args namespace
    module = AnsibleModule(
        argument_spec={}
    )
    # We instantiate the class to test, passing in the module we created
    instance = VirtualSysctlDetectionMixin()
    instance.module = module
    # We run the test
    from ansible.module_utils.facts import virtual

    results = instance.detect_virt_product("hw.model")
    assert len(results) > 0



# Generated at 2022-06-23 02:37:02.515481
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    class TestModule:
        def __init__(self):
            self.run_command_result = (0, 'VMware', None)
            self.get_bin_path_result = '/usr/local/bin/sysctl'
        def get_bin_path(self, path):
            return self.get_bin_path_result
        def run_command(self, cmd):
            return self.run_command_result
    module = TestModule()
    virt = VirtualSysctlDetectionMixin()
    virt.module = module
    product_facts = virt.detect_virt_product('hw.model')
    assert product_facts['virtualization_type'] == 'VMware'

# Generated at 2022-06-23 02:37:13.494848
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Create the class we are going to test.
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts

    # Set the values of the attributes we expect to be set.
    sysctl_path = '/usr/bin/sysctl'
    module_mock = MagicMock()
    module_mock.get_bin_path.return_value = sysctl_path

    # Create the object.
    virtual_facts_object = VirtualFacts(module_mock)

    # Put the object type in the module_cls attribute of the module_mock.
    module_mock.module_cls = VirtualFacts

    # Create the object we can mock the run_command method call.
    ansible_module_mock = MagicMock()
    key = 'hw.model'
    ansible_module

# Generated at 2022-06-23 02:37:18.602169
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None

        def detect_sysctl(self):
            self.sysctl_path = "/sbin/sysctl"

    # test init
    test_obj = TestClass()
    assert test_obj
    assert test_obj.sysctl_path == "/sbin/sysctl"

# Generated at 2022-06-23 02:37:29.538312
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mocked_module = Mock_AnsibleModule()
    virtual_facts = VirtualSysctlDetectionMixin()

    # Create a sysctl binary path
    virtual_facts.sysctl_path = '/bin/sysctl'

    # Set data for mocked module
    mocked_module.run_command_stdout = 'KVM'
    mocked_module.run_command_rc = 0

    # Set data for virtualization_facts
    virtualization_data = {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Set data for virtualization_tech_guest
    virtualization_tech_guest = set(['kvm'])

    # Set data for virtualization_tech_host
    virtualization_tech_host = set()


# Generated at 2022-06-23 02:37:40.038336
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class Module:
        def __init__(self):
            self.sysctl_path = None
        def get_bin_path(self, name):
            if name == 'sysctl':
                self.sysctl_path = '/sbin/sysctl'
            return self.sysctl_path
        def run_command(self, cmd):
            return 0, '', ''
    class MagicMock(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = Module()
    # if get_bin_path doesn't work it should return nothing
    mm = MagicMock()
    assert mm.detect_sysctl() is None
    # if sysctl_path is not set it should return nothing
    mm.module.get_bin_path('sysctl')
    assert mm.detect_sysctl()

# Generated at 2022-06-23 02:37:42.045528
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        pass

    assert(TestClass)

# Generated at 2022-06-23 02:37:52.606281
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Set up virtualization facts
    virtual_facts = {
        'virtualization_type': '',
        'virtualization_role': '',
        'virtualization_tech_guest': None,
        'virtualization_tech_host': None
    }

    # Set up a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': run_command,
        'get_bin_path': get_bin_path
    })

    # Set up a module instance and populate the virtualization facts
    module_instance = module()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module_instance
    mixin.detect_sysctl()

    # Test detect_virt_vendor() with an expected result
    virtual_facts = mixin.detect_virt_v

# Generated at 2022-06-23 02:37:53.256071
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    return

# Generated at 2022-06-23 02:38:01.550093
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    #
    # NOTE: The error handling below is not related to the actual fault,
    # but it is a test to ensure that the correct exception class is
    # raised. If a wrong exception class is raised, then the test will
    # fail.
    #

    import os
    import tempfile
    import shutil
    import pytest

    class FakeSysctlModule(object):
        def __init__(self):
            self.sysctl_path = None

        def get_bin_path(self, cmd):
            return self.sysctl_path

        def run_command(self, cmd):
            return 0, 'testing', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = FakeSysctlModule

# Generated at 2022-06-23 02:38:12.742960
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    import types
    import platform

    sys.modules['platform'] = types.ModuleType('platform')
    sys.modules['platform'].system = lambda: 'OpenBSD'
    sys.modules['platform'].release = lambda: '6.8'
    m = types.ModuleType('ansible_facts')
    sys.modules['ansible_facts'] = m

# Generated at 2022-06-23 02:38:15.103771
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin

    assert VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:38:21.493786
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module, sysctl_path):
            self.module = module
            self.sysctl_path = sysctl_path

    module = type("module", (), {})
    setattr(module, 'get_bin_path', lambda x: '/usr/bin/sysctl')
    setattr(module, 'run_command', lambda x: (0, '', ''))
    assert TestClass(module, '/usr/bin/sysctl').sysctl_path == '/usr/bin/sysctl'

# Generated at 2022-06-23 02:38:26.508904
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_object = VirtualSysctlDetectionMixin()
    assert hasattr(test_object, 'detect_sysctl')
    assert hasattr(test_object, 'detect_virt_product')
    assert hasattr(test_object, 'detect_virt_vendor')
    assert hasattr(test_object, 'sysctl_path') == False


# Generated at 2022-06-23 02:38:32.998320
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    v = VirtualSysctlDetectionMixin()
    v.module = FakeModule()
    v.module.get_bin_path = lambda x: '/bin/sysctl'
    v.detect_sysctl()
    assert v.sysctl_path == '/bin/sysctl'

    v.module.get_bin_path = lambda x: None
    v.detect_sysctl()
    assert v.sysctl_path is None



# Generated at 2022-06-23 02:38:42.757767
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    # Use a mutable type to track what we are supposed to have
    # seen as we go through the test.
    class FakeAnsibleModule(object):
        def __init__(self):
            self.virtual_product_facts = dict()
            self.run_command_seen = set()
            self.fail_json_seen = set()
            self.warn_from_none_seen = set()
            self.warn_from_dict_seen = set()
            self.debug_from_dict_seen = set()

        def fail_json(self, **kwargs):
            self.fail_json_seen.add(kwargs)

        def warn(self, from_dict, from_none):
            self.warn_from_none_seen.add(from_none)

# Generated at 2022-06-23 02:38:55.647071
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import ansible.module_utils.facts.virtual.freebsd as virtual_bsd_module
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class TestModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = virtual_bsd_module.virtual_get_facts()
            self.sysctl_path = None
            self.module = None

        def get_bin_path(self, executable):
            return None

        def run_command(self, executable_path):
            return 1, 'Parallels', ''

    # test
    module_test = TestModule()
    virtual_product_facts = module_test.detect_virt_product('hw.product')

    assert virtual_product_facts['virtualization_role'] == 'guest'
   

# Generated at 2022-06-23 02:39:06.436862
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class LinuxModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''

        def get_bin_path(self, name, required=False):
            return name

        def run_command(self, cmd, check_rc=False):
            return self.run_command_rc, self.run_command_out, ''

    class VirtualSysctlDetectionMixinClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = LinuxModule()

    vdm = VirtualSysctlDetectionMixinClass()
    virtual_product_facts = vdm.detect_virt_product('machdep.hypervisor')


# Generated at 2022-06-23 02:39:08.888707
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    try:
        VirtualSysctlDetectionMixin()
    except:
        raise AssertionError('Failure when constructing VirtualSysctlDetectionMixin')

# Generated at 2022-06-23 02:39:19.257880
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class PuppetModule(object):

        def __init__(self):
            self.module = self

        def get_bin_path(self, path):
            if path == 'sysctl':
                return '/sbin/sysctl'
        def run_command(self, command, *args, **kwargs):
            if command == '/sbin/sysctl -n hw.model':
                return 0, 'VirtualBox\n', ''
            elif command == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1\n', ''

    vm = VirtualSysctlDetectionMixin()
    vm.module = PuppetModule()
    vm.module.run_command = vm.module.run_command
    vm.module.get_bin_path = vm.module.get_bin_path

    assert vm

# Generated at 2022-06-23 02:39:23.791890
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    obj = VirtualSysctlDetectionMixin()
    obj.module = MagicMock()
    obj.module.get_bin_path.return_value = "/sbin/sysctl"
    obj.detect_sysctl()
    assert obj.sysctl_path == "/sbin/sysctl"


# Generated at 2022-06-23 02:39:30.945398
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, arg):
            return '/bin/sysctl'

    class Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    x = Test()
    x.detect_sysctl()

    assert x.sysctl_path == '/bin/sysctl'


# Generated at 2022-06-23 02:39:35.477719
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MagicMock()
    module.get_bin_path.return_value = "/usr/bin/sysctl"
    VSDetection = VirtualSysctlDetectionMixin()
    VSDetection.module = module
    VSDetection.detect_sysctl()
    assert VSDetection.sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-23 02:39:47.119096
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.run_commands_called = []

        def run_command(self, args):
            self.run_commands_called.append(args)
            return (0, 'OpenBSD', '')

    class VirtualSysctlDetectionMixinStub(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = ModuleStub()
            self.sysctl_path = '/sbin/sysctl'

    sysctl = VirtualSysctlDetectionMixinStub()
    sysctl.detect_sysctl()
    result = sysctl.detect_virt_vendor('hw.machine_arch')
    assert result['virtualization_tech_guest'] == set(['vmm'])

# Generated at 2022-06-23 02:39:57.596257
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """
    This function test the detect_virt_vendor method of class VirtualSysctlDetectionMixin
    """
    import os
    import sys
    import tempfile
    import textwrap
    import unittest
    from ansible.module_utils import basic
    from ansible_collections.notmintest.not_a_real_collection.plugins.module_utils.tests.unit.compat import mock

    # load the module under test
    sys.path.append(os.path.join(sys.path[0], 'ansible_collections', 'notmintest', 'not_a_real_collection', 'plugins', 'module_utils'))
    import virtualbox_guest as module_under_test


# Generated at 2022-06-23 02:40:06.247794
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_return = [0, '', '']
        def run_command(self, cmd):
            return self.run_command_return
        def get_bin_path(self, program, opt_dirs=[]):
            return ""

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    virt_detection = FakeSysctlDetectionMixin()
    virt_detection.module = FakeModule()
    virtual_product_facts = virt_detection.detect_virt_product('hw.vendor')
    assert 'virtualization_type' in virtual_product_facts
    assert 'virtualization_role'

# Generated at 2022-06-23 02:40:18.339456
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MyClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.facts = dict()
            self.facts['virtualization_role'] = 'guest'
            self.facts['virtualization_type'] = 'kvm'
            self.facts['virtual'] = True
            self.facts['virtualization_tech_guest'] = set()

        def detect_sysctl(self):
            self.sysctl_path = '/usr/bin/sysctl'
        def module_run_command(self, cmd):
            if cmd == '/usr/bin/sysctl -n kern.vm_guest':
                return 0, 'KVM', ''
            if cmd == '/usr/bin/sysctl -n security.jail.jailed':
                return 0, '0', ''

    my_obj = My

# Generated at 2022-06-23 02:40:25.221783
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda command, check_rc=True: (0, "VirtualBox", "")
            self.get_bin_path = lambda key, opt_dirs=[] : "/usr/bin/sysctl"

    fake = VirtualSysctlDetectionMixin()
    result = fake.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:40:33.833139
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    virtual_detection = VirtualSysctlDetectionMixin()
    test_dict = dict()
    test_dict['virtualization_type'] = None
    test_dict['virtualization_role'] = None
    test_dict['virtualization_product'] = None
    test_dict['virtualization_vendor'] = None
    test_dict['virtualization_host_type'] = None
    test_dict['virtualization_host_role'] = None
    test_dict['virtualization_host_product'] = None
    test_dict['virtualization_host_vendor'] = None
    test_dict['virtualization_host_facts'] = None
    test_dict['virtualization_guest_facts'] = None
    test_dict['virtualization_system_facts'] = None
    test_dict['virtualization_full_facts'] = None
   

# Generated at 2022-06-23 02:40:43.145587
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule:
        def __init__(self):
            self.sysctl_path = None

        def get_bin_path(self, name):
            return self.sysctl_path

    class FakeArgs(object):
        pass

    from ansible.module_utils.facts.system.base import VirtualSysctlDetectionMixin
    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin(module, args=FakeArgs)
    module.sysctl_path = 'fake_sysctl_path'
    mixin.detect_sysctl()
    assert mixin.sysctl_path == 'fake_sysctl_path'
    module.sysctl_path = None
    mixin.detect_sysctl()
    assert not mixin.sysctl_path



# Generated at 2022-06-23 02:40:47.763760
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    host = VirtualSysctlDetectionMixin()
    host.module = MockModule(params={'sysctl_path': '/usr/sbin/sysctl'})
    host.detect_sysctl()
    assert host.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-23 02:40:56.000397
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin() is not None
    assert VirtualSysctlDetectionMixin().sysctl_path is None
    assert VirtualSysctlDetectionMixin().detect_sysctl() is None
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw')['virtualization_type'] == 'kvm'
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw')['virtualization_role'] == 'guest'
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw')['virtualization_tech_guest'] == set(['kvm'])
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw')['virtualization_tech_host'] == set()

# Generated at 2022-06-23 02:41:05.332440
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, *args):
            self.sysctl_path = '/sbin/sysctl'

        def get_bin_path(self, *args):
            return self.sysctl_path
    class FakeModuleInstance(object):
        def get_bin_path(self, *args):
            return self.sysctl_path

        def run_command(self, *args):
            if 'kvm' in args[0]:
                return 0, 'kvm', ''
            elif 'vmware' in args[0]:
                return 0, 'VMware', ''
            elif 'virtualbox' in args[0]:
                return 0, 'VirtualBox', ''
            elif 'xen' in args[0]:
                return 0, 'XenPV', ''

# Generated at 2022-06-23 02:41:09.318208
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class MockModule(object):
        def get_bin_path(self, command):
            return {}

        def run_command(self, command):
            return {}

    obj = VirtualSysctlDetectionMixin()
    obj.module = MockModule()

    assert obj.detect_sysctl() == None
    return

# Generated at 2022-06-23 02:41:21.414980
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import tempfile
    from ansible.module_utils.facts.virtual.openbsd_virtual import VirtualSysctlDetectionMixin

    class FakeModule(object):
        def __init__(self):
            self.module = self

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd):
            return 0, '', ''

    mod = FakeModule()
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl()
    assert v.sysctl_path is not None

    mod.run_command = lambda cmd: 0, 'OpenBSD', ''
    v = VirtualSysctlDetectionMixin()
    vfacts = v.detect_virt_vendor('hw.vendor')

# Generated at 2022-06-23 02:41:29.880533
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda *args: None

        def get_bin_path(self, name):
            return "/usr/bin/virtual-host-cmd"

        def run_command(self, cmd):
            return (0, "QEMU", "")

    class FakeVirtVendor(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = FakeModule()

    virt_vendor_test = FakeVirtVendor()
    rc, out, err = virt_vendor_test.detect_virt_vendor("kern.vm_guest")
    assert(rc == 0)
    assert(out['virtualization_type'] == 'kvm')

# Generated at 2022-06-23 02:41:35.656896
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    obj = VirtualSysctlDetectionMixin()
    obj.module = FakeAnsibleModule()
    obj.detect_sysctl()
    assert obj.sysctl_path == '/usr/bin/sysctl'

test_VirtualSysctlDetectionMixin_detect_sysctl()

# Generated at 2022-06-23 02:41:46.324895
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule():
        def get_bin_path(self, path):
            return "/usr/bin/%s" % path

        def run_command(self, path):
            return (0, "KVM", "")

    fake_module = FakeModule()
    openbsd_version = VirtualSysctlDetectionMixin()
    results = openbsd_version.detect_virt_product('hw.model')
    assert results
    assert results['virtualization_role'] == 'guest'
    assert results['virtualization_type'] == 'kvm'


# Generated at 2022-06-23 02:41:58.514028
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockSUT():
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == "%s -n %s" % (self.sysctl_path, 'hw.product'):
                return 0, 'VirtualBox', ''
            if cmd == "%s -n %s" % (self.sysctl_path, 'hw.machine'):
                return 0, 'i386', ''
            if cmd == "%s -n %s" % (self.sysctl_path, 'kern.hostuuid'):
                return 0, '1dbbffc1-8d61-11e2-bcfd-0800200c9a66', ''

    c = VirtualSysctlDetectionMixin()
    c.module = Mock

# Generated at 2022-06-23 02:42:08.605321
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import platform
    import tempfile
    import shutil
    import os

    fd, sysctl_path = tempfile.mkstemp()
    os.write(fd, '#!/bin/sh\necho ""\n')
    os.close(fd)
    os.chmod(sysctl_path, 0o755)
    platform_system = platform.system
    platform.system = lambda: 'FreeBSD'
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = DummyModule()
    vsdm.module.get_bin_path = lambda s: sysctl_path
    vsdm.detect_sysctl()
    assert vsdm.sysctl_path == sysctl_path
    os.remove(sysctl_path)


# Generated at 2022-06-23 02:42:20.100521
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Env(object):
        def get_bin_path(self, program):
            return '/bin/' + program
        run_command=lambda self, command: (0, "", "")

    class ModuleTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.virtual_facts = {}
            self.module = Env()

        def run_command(self, what):
            return self.module.run_command(what)

    class ObjectTest(object):
        pass
    obj = ObjectTest()
    obj.module = Env()
    obj.virtual_facts = {}
    mix = VirtualSysctlDetectionMixin()
    mix.detect_sysctl(obj)
    assert obj.sysctl_path == '/bin/sysctl'

    obj = ModuleTest()

# Generated at 2022-06-23 02:42:28.997949
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinMock(object):
        def __init__(self, module):
            self.module = module

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

    class VirtualSysctlDetectionMixinMockModule(object):
        def __init__(self, module_name='VirtualSysctlDetectionMixinMockModule'):
            self.module_name = module_name

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if 'security.jail.jailed' in cmd:
                if '1' in cmd:
                    rc = 0
                    out = '1'
                else:
                    rc = 1

# Generated at 2022-06-23 02:42:35.672427
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule:
        def get_bin_path(bin):
            if bin == 'sysctl':
                return '/fake/path/to/sysctl'
            else:
                return None

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    fake_module = FakeModule()
    fake_class = FakeClass(fake_module)

    assert fake_class.sysctl_path == '/fake/path/to/sysctl'


# Generated at 2022-06-23 02:42:44.032639
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class BSDMachine(object):
        pass

    machine_obj = BSDMachine()
    machine_obj.module = BSDMachine()
    machine_obj.module.run_command = lambda x: (0, 'OpenBSD', '')
    machine_obj.detect_sysctl = lambda: setattr(machine_obj, 'sysctl_path', '/sbin/sysctl')
    machine_obj.get_bin_path = lambda x: '/sbin/sysctl'

    virtual_vendor_facts = machine_obj.detect_virt_vendor('misc.pc_sys')

    assert virtual_vendor_facts['virtualization_type'] == 'vmm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:42:50.609104
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class NewSysctlMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None

    mixin = NewSysctlMixin()
    mixin.detect_sysctl()
    assert mixin.sysctl_path

    mixin.sysctl_path = None
    mixin.detect_virt_product('machdep.hypervisor')
    assert mixin.sysctl_path
    assert 'virtualization_tech_guest' in mixin.detect_virt_product('machdep.hypervisor')
    assert 'virtualization_tech_host' in mixin.detect_virt_product('machdep.hypervisor')

    assert 'virtualization_tech_guest' in mixin.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-23 02:42:56.479480
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import platform
    import tempfile

    # Create a mixin instance with a tempfile path to sysctl
    sysctl_path = tempfile.mktemp()
    mixin = VirtualSysctlDetectionMixin()

    # If the system is not FreeBSD, return
    if platform.system() != 'FreeBSD':
        return
    # Set sysctl_path to the tempfile path
    mixin.sysctl_path = sysctl_path
    # Verify the path is set
    assert mixin.sysctl_path == sysctl_path

# Generated at 2022-06-23 02:42:58.761523
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()


# Generated at 2022-06-23 02:43:10.282147
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    VirtualSysctlDetectionMixinFake = VirtualSysctlDetectionMixin()

    assert VirtualSysctlDetectionMixinFake.detect_virt_product('hw.model') == {
        'virtualization_type': 'virtualbox',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'virtualbox'},
        'virtualization_tech_host': set()
    }

    assert VirtualSysctlDetectionMixinFake.detect_virt_product('security.jail.jailed') == {
        'virtualization_type': 'jails',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'jails'},
        'virtualization_tech_host': set()
    }

    assert VirtualSysctlDetectionMixinFake.detect_

# Generated at 2022-06-23 02:43:19.131835
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class SystemModule(object):
        def get_bin_path(self, executable):
            if executable == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        class NoFailRunCmd(object):
            def __init__(self, rc, out, err):
                self.rc = rc
                self.out = out
                self.err = err

            def run(self, cmd, check_rc=False):
                return self.rc, self.out, self.err

        def run_command(self, cmd, check_rc=False):
            if cmd == '/sbin/sysctl -n hw.vendor':
                return self.NoFailRunCmd(0, 'QEMU\n', '').run(cmd, check_rc=check_rc)
            else:
                return None

# Generated at 2022-06-23 02:43:21.394867
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # Initialize test class
    v = VirtualSysctlDetectionMixin()

    assert repr(v) == "<VirtualSysctlDetectionMixin>"

# Generated at 2022-06-23 02:43:32.313055
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Obj:
        def __init__(self):
            self.module = Obj()
            self.module.run_command = lambda x: (0, 'KVM', None)
            self.module.get_bin_path = lambda x: '/bin/sysctl'

        def detect_sysctl(self):
            pass

    class Test(VirtualSysctlDetectionMixin):
        pass

    obj = Obj()
    t = Test()
    t.module = obj
    t.detect_sysctl = obj.detect_sysctl
    t.module.get_bin_path = obj.module.get_bin_path

# Generated at 2022-06-23 02:43:40.124043
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    try :
        import __builtin__ as builtins
    except ImportError:
        import builtins
    module = builtins.__dict__['ansible_module_instance']
    module.run_command = lambda command: (0, '/sbin/sysctl', '')
    module.get_bin_path = lambda name: '/sbin/sysctl'
    module.exit_json = lambda **ans: True
    module.fail_json = lambda **ans: True
    sysctl_path = '/sbin/sysctl'
    obj = VirtualSysctlDetectionMixin()
    obj.module = module
    obj.detect_sysctl()
    assert obj.sysctl_path == sysctl_path


# Generated at 2022-06-23 02:43:43.216730
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v is not None

if __name__ == '__main__':
    # Run unit tests for this class
    test_VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:43:52.601623
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MyFakeModule():
        def __init__(self):
            self.params = {}
            self.exit_json = {}
            self.fail_json = {}
            self.exit_args = {}
            self.fail_args = {}

        def get_bin_path(self, path, optional=True):
            return '/usr/bin/sysctl'


# Generated at 2022-06-23 02:44:04.188408
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    facts = {}
    facts['virtualization_type'] = None
    facts['virtualization_role'] = None
    vmm_out = """hv_vendor: OpenBSD
hv_version: bhyve bhyve-20160501
hv_features: 0x
hv_pagesize: 0x1000
hv_tsc_freq: 0x1147dbd00
hv_tsc_mfn: 0x0
hv_timekeep_mfn: 0x0
hv_timekeep_gfn: 0x3fca00
hv_tlbflush: bhyve_tlbflush"""

# Generated at 2022-06-23 02:44:13.562481
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from collections import namedtuple
    # Create a FakeModule class for running unit tests
    class FakeModule:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda **x: namedtuple("FakeExitJson", x.keys())(**x)
        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'
        def run_command(self, args, check_rc=True, close_fds=True, executable=None, run_in_check_mode=False, use_unsafe_shell=False):
            class FakeReturnCode:
                def __init__(self, returncode):
                    self.returncode = returncode
           

# Generated at 2022-06-23 02:44:22.056698
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class BSDModule(object):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return self.sysctl_path

        def run_command(self, command):
            return 0, 'cat /etc/motd\n', ''

    class Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = BSDModule()

    t = Test()
    t.detect_sysctl()
    assert t.sysctl_path == '/sbin/sysctl'



# Generated at 2022-06-23 02:44:34.791047
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # mocks
    class RuntimeOS(object):
        pass
    class Mixin(object):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    # create instance of the class to test
    class module(object):
        def __init__(self):
            self.run_command = lambda *a, **kw: (0, 'VirtualBox', '')
            self.get_bin_path = lambda *a, **kw: '/usr/local/bin/sysctl'

    class VM(RuntimeOS, VirtualSysctlDetectionMixin, Mixin):
        def __init__(self, module):
            Mixin.__init__(self, module)

    # create test instance
    vm = VM(module())

    # run the code
    ret = vm.detect

# Generated at 2022-06-23 02:44:39.382210
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mixin = VirtualSysctlDetectionMixin()
    result = mixin.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' in result['virtualization_tech_guest']
    assert len(result['virtualization_tech_guest']) == 1
    assert len(result['virtualization_tech_host']) == 0
