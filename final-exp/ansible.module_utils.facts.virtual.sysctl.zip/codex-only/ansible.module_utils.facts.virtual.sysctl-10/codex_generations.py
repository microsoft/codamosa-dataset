

# Generated at 2022-06-23 02:34:38.152527
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.collector.virtual import VirtualSysctlDetectionMixin
    assert VirtualSysctlDetectionMixin.__bases__[0].__name__ == "object"

# Generated at 2022-06-23 02:34:41.673418
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = VirtualSysctlDetectionMixin()
    assert module.detect_sysctl() == None
    assert module.sysctl_path == module.module.get_bin_path('sysctl')


# Generated at 2022-06-23 02:34:53.635971
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    fixture = VirtualSysctlDetectionMixin()
    # BSD Jails
    key = 'security.jail.jailed'
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'jails',
                'virtualization_tech_guest': set(['jails']), 'virtualization_tech_host': set()}
    assert fixture.detect_virt_product(key) == expected
    # Jail on a Jail
    key = 'security.jail.jailed'
    expected = {'virtualization_role': 'guest', 'virtualization_type': 'jails',
                'virtualization_tech_guest': set(['jails']), 'virtualization_tech_host': set()}
    assert fixture.detect_virt_product(key) == expected
    # FreeBSD hypervisor
   

# Generated at 2022-06-23 02:35:02.040037
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    assert isinstance(mixin, object)
    assert hasattr(mixin, 'detect_sysctl')
    assert hasattr(mixin, 'detect_virt_product')
    assert hasattr(mixin, 'detect_virt_vendor')
    assert VirtualSysctlDetectionMixin.__doc__.strip()
    assert VirtualSysctlDetectionMixin.detect_sysctl.__doc__.strip()
    assert VirtualSysctlDetectionMixin.detect_virt_product.__doc__.strip()
    assert VirtualSysctlDetectionMixin.detect_virt_vendor.__doc__.strip()

# Generated at 2022-06-23 02:35:11.917752
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinModule:
        class VirtualSysctlDetectionMixinTest:
            def __init__(self):
                self.sysctl_path = '/sbin/sysctl'
        def __init__(self):
            self.module = self.VirtualSysctlDetectionMixinTest()
            self.module.run_command = self.run_command_test
    class TestVirtualSysctlDetectionMixinObject(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass
    class RunCommandResult:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

    virtual_sysctl_detection_mixin_object = TestVirtualSysctlDetectionMixinObject()
    virtual_sysctl_

# Generated at 2022-06-23 02:35:13.979131
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_vsmixin = VirtualSysctlDetectionMixin()
    assert(test_vsmixin != None)

# Generated at 2022-06-23 02:35:20.500961
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual import OpenBSDVirtual

    # Test for VMM on OpenBSD
    openbsd_virtual = OpenBSDVirtual()
    openbsd_virtual.detect_sysctl = lambda: True
    openbsd_virtual.module = DummyModule()
    openbsd_virtual.module.run_command = lambda *args, **kw: [0, 'OpenBSD', '']
    result = openbsd_virtual.detect_virt_vendor('hw.model')
    assert result == {'virtualization_tech_guest': set(['vmm']),
                      'virtualization_tech_host': set(),
                      'virtualization_type': 'vmm',
                      'virtualization_role': 'guest'}

    # Test for V

# Generated at 2022-06-23 02:35:25.795882
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    cls = VirtualSysctlDetectionMixin()
    cls.module = MagicMock()
    cls.module.bin_path = {'sysctl': '/sbin'}
    cls.module.run_command.return_value = (0, '', '')

    cls.detect_sysctl()
    assert cls.sysctl_path == '/sbin'



# Generated at 2022-06-23 02:35:33.519418
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self, is_virtual, machine_id, jail_id, jail_name):
            self.is_virtual = is_virtual
            self.machine_id = machine_id
            self.jail_id = jail_id
            self.jail_name = jail_name
            self.virtual_product_facts = {}
            self.virtual_vendor_facts = {}
            self.__name__ = 'freebsd_virtual'

        def get_bin_path(self, path):
            if path == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None


# Generated at 2022-06-23 02:35:38.758130
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Class(object):
        def get_bin_path(self, path):
            self.path = path
            return "/usr/sbin/" + path

        def run_command(self, command):
            self.command = command
            class Test(object):
                stdout = "KVM"
            return 0, Test(), None

    class TestModule(object):
        pass

    test = Class()
    module = TestModule()
    test.module = module
    result = test.detect_virt_product("machdep.hypervisor")
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:35:40.244901
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    target = VirtualSysctlDetectionMixin()
    assert target is not None

# Generated at 2022-06-23 02:35:45.289644
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    detection_mixin = VirtualSysctlDetectionMixin()
    detection_mixin.detect_sysctl()
    assert 'detect_sysctl' in dir(detection_mixin)
    assert 'detect_virt_product' in dir(detection_mixin)
    assert 'detect_virt_vendor' in dir(detection_mixin)

# Generated at 2022-06-23 02:35:49.867273
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = MockModule()

    testclass = TestClass()
    testclass.detect_sysctl()
    assert testclass.sysctl_path == "/bin/sysctl"


# Generated at 2022-06-23 02:35:57.033958
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virttestlib = VirtualSysctlDetectionMixin()
    virttestlib.module = AnsibleModuleStub()
    # Set sysctl installed in case of detection
    virttestlib.sysctl_path = '/sbin/sysctl'
    virttestlib.module.run_command = LambdaStub(0, 'QEMU', '')
    result = virttestlib.detect_virt_vendor('machdep.hypervisor')
    assert_result = {'virtualization_type': 'kvm',
                     'virtualization_role': 'guest',
                     'virtualization_tech_guest': set(['kvm']),
                     'virtualization_tech_host': set(),
                    }
    assert result == assert_result


# Generated at 2022-06-23 02:36:03.261960
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import BsdSystemFacts
    bsd = BsdSystemFacts()
    bsd.detect_sysctl()
    assert bsd.sysctl_path is not None


# Generated at 2022-06-23 02:36:12.895721
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def __init__(self):
            self.bin_path = '/usr/bin'
            self.fake_paths = {}

        def get_bin_path(self, binary):
            if binary in self.fake_paths:
                return self.fake_paths[binary]
            else:
                return None

    class FakeDetectSysctl(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    module = FakeModule()

    # Test normal operation
    module.fake_paths = {'sysctl': '/usr/bin/sysctl'}
    m = FakeDetectSysctl(module)
    m.detect_sysctl()

# Generated at 2022-06-23 02:36:21.891943
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from lib.ansible.module_utils.facts.virtual.base import VirtualSysctlDetectionMixin as class_to_test

    obj = class_to_test()
    obj.module = True
    obj.module.get_bin_path = lambda a: '/path/to/sysctl'
    obj.detect_sysctl()
    assert obj.sysctl_path == '/path/to/sysctl'


# Generated at 2022-06-23 02:36:32.057105
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # create mixin object
    mixin = VirtualSysctlDetectionMixin()

    # set an OS type
    mixin.kernel = "FreeBSD"

    # set values for 'sysctl -n hw.model'
    mixin.module = {'run_command': lambda x, *args, **kwargs: (0, 'QEMU', '')}

    virt_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
    }
    result = mixin.detect_virt_vendor('hw.model')
    for key, value in result.items():
        assert key in virt_facts
        assert value == virt_facts[key]



# Generated at 2022-06-23 02:36:40.942337
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from mock import MagicMock
    from ansible.module_utils.facts.system.BSD import VirtualSysctlDetectionMixin
    facts = VirtualSysctlDetectionMixin()
    facts.module = MagicMock()
    facts.sysctl_path = '/usr/bin/sysctl'

    facts.module.run_command.return_value = (0, 'kvm_guest', '')
    qemu_result = facts.detect_virt_product('machdep.hypervisor')
    facts.module.run_command.assert_called_with('/usr/bin/sysctl -n machdep.hypervisor')

# Generated at 2022-06-23 02:36:46.175050
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def get_bin_path(self, binary):
            return "/usr/sbin/sysctl"

        def run_command(self, binary):
            return 0, "sysctl output", ""

    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.detect_sysctl()

    assert mixin.sysctl_path == module.get_bin_path("sysctl")


# Generated at 2022-06-23 02:36:57.361011
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def get_bin_path(self, executable):
            return executable

        def run_command(self, command):
            if command == 'sysctl -n kern.vm_guest':
                return 0, 'VMware', ''
            if command == 'sysctl -n security.jail.jailed':
                return 0, '1', ''
            if command == 'sysctl -n security.jail.jailed' and command == 'sysctl -n kern.vm_guest':
                return 0, '1', ''
            if command == 'sysctl -n kern.somestuff' and command == 'sysctl -n security.jail.jailed':
                return 0, '1', ''

# Generated at 2022-06-23 02:37:05.312550
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    sample = VirtualSysctlDetectionMixin()
    sample.sysctl_path = '/sbin/sysctl'

    # Pretend we ran sysctl and the output was 'QEMU'.
    sample.module = MockModule(dict(run_command=MockCommand(stdout='QEMU')))
    virtual_facts = sample.detect_virt_vendor('hw.model')
    assert virtual_facts == dict(virtualization_tech_guest=set(['kvm']),
                                 virtualization_tech_host=set([]),
                                 virtualization_type='kvm',
                                 virtualization_role='guest')

    # Pretend we ran sysctl and the output was 'OpenBSD'.
    sample.module = MockModule(dict(run_command=MockCommand(stdout='OpenBSD')))
    virtual_

# Generated at 2022-06-23 02:37:14.181331
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleStub(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n vm.vmm.vendor':
                return 0, "QEMU", ""
            else:
                return 0, "", ""

    plugin = VirtualSysctlDetectionMixin()
    plugin.module = ModuleStub()
    assert plugin.detect_virt_vendor('vm.vmm.vendor')['virtualization_type'] == 'kvm'
    assert plugin.detect_virt_vendor('vm.vmm.vendor')['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:37:23.530855
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.openbsd.virtualization import Virtualization
    instance = Virtualization()
    instance.detect_sysctl = lambda: True
    instance.module.run_command = lambda cmd: (0, 'KVM', '')
    assert instance.detect_virt_product('virtualization.product.name') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(['kvm'])
    }


# Generated at 2022-06-23 02:37:25.076333
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_mixin = VirtualSysctlDetectionMixin()
    assert test_mixin is not None

# Generated at 2022-06-23 02:37:25.825531
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:37:29.877564
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    f = VirtualSysctlDetectionMixin()
    f.module.get_bin_path = lambda x: "/usr/bin/sysctl"
    f.detect_sysctl()
    assert f.sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-23 02:37:35.973272
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={})
    vm_detect = VirtualSysctlDetectionMixin()
    setattr(module, 'run_command', mock_run_command)
    setattr(vm_detect, 'module', module)
    vm_detect.detect_sysctl()
    assert vm_detect.sysctl_path == '/sbin/sysctl'



# Generated at 2022-06-23 02:37:37.640486
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    print(mixin)

# Generated at 2022-06-23 02:37:40.644235
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = AnsibleModule({})
    sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    sysctl_detection_mixin.detect_sysctl()


# Generated at 2022-06-23 02:37:48.020197
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class A(object):
        def get_bin_path(self, arg):
            return True
        def run_command(self, arg):
            return True
    class B(A, VirtualSysctlDetectionMixin):
        pass
    assert B().detect_virt_vendor('key') == {'virtualization_type': None,
                                             'virtualization_role': None,
                                             'virtualization_tech_guest': set(),
                                             'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:37:54.955209
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(object):
        def get_bin_path(self, arg):
            return "/usr/bin/sysctl"

    module = TestModule
    class VirtualSysctlDetectionMixinClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    virtual_sysctl_detection_mixin_object = VirtualSysctlDetectionMixinClass(module)
    virtual_sysctl_detection_mixin_object.detect_sysctl()


# Generated at 2022-06-23 02:38:04.686376
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin:
        module = ''
        sysctl_path = ''
        def detect_sysctl(self):  pass
    class Module:
        def get_bin_path(self, path): return ''
        def run_command(self, path): return (0, 'kvm', '')
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = Module()
    facts = mixin.detect_virt_product('machdep.hypervisor_name')
    assert facts == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-23 02:38:15.594231
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch
    from ansible.module_utils.facts import Virtualization

    virt_facts = Virtualization()

    rc = 0
    out = 'QEMU'
    err = ''
    run_command_mock = patch('ansible.module_utils.facts.virtual.VirtualSysctlDetectionMixin.run_command')
    with run_command_mock as run_command_mock:
        run_command_mock.return_value = (rc, out, err)
        virt_facts.detect_virt_vendor('machdep.hypervisor')
        assert virt_facts.get_virtual_facts()['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:38:24.000769
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl = "/usr/sbin/sysctl"
            self.module = AnsibleModule()
            self.module.add_dummy_module_arguments(dict(
                virtualization_type="",
                virtualization_role="",
                virtualization_use_old_facts="",
                virtualization_technologies=[]
            ))
            self.module.run_command = _run_command

    def _run_command(self, cmd):
        if cmd == "/usr/sbin/sysctl -n hw.product":
            return 0, "KVM/QEMU Virtual CPU version 1.0 (OpenBSD)", ""

# Generated at 2022-06-23 02:38:34.879037
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """ Unit test for the method VirtualSysctlDetectionMixin.detect_virt_product of class VirtualSysctlDetectionMixin. """
    class FakeModule(object):
        def __init__(self):
            self.rc = 0
            self.err = ''
            self.out = ''

        def get_bin_path(self, dirname):
            return True

        def run_command(self, cmd):
            return self.rc, self.out, self.err

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    vd_mixin_kvm_host = FakeVirtualSysctlDetectionMixin()
    vd_mixin_kvm_host.out = 'KVM'
    assert vd_mix

# Generated at 2022-06-23 02:38:46.488450
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    vb = VirtualSysctlDetectionMixin()
    vb.module = AnsibleModule(argument_spec={})
    vb.detect_sysctl = MagicMock(return_value=True)
    vb.module.run_command = MagicMock(return_value=(0, 'VirtualBox', ''))
    result = vb.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'virtualbox'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_tech_guest'] == set(['virtualbox'])
    vb.module.run_command = MagicMock(return_value=(0, 'VMware', ''))
    result = vb.detect_virt_

# Generated at 2022-06-23 02:38:56.295163
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeRunner:
        class FakeModule:
            def get_bin_path(self, path):
                return '/bin/sysctl'

        def __init__(self, module):
            self.module = self.FakeModule()

    class FakeClass:
        def __init__(self):
            self.runner = FakeRunner(self)
            self.sysctl_path = None

    class TestClass(VirtualSysctlDetectionMixin, FakeClass):
        def __init__(self):
            pass
    test_class = TestClass()

    # VMware
    test_class.sysctl_path = '/bin/sysctl'
    test_class.runner.run_command = lambda command: (0, 'foo Foo VMware', '')
    virtual_product_facts = test_class.detect_virt_product("vm.version")


# Generated at 2022-06-23 02:39:06.266512
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    def test_module_run_command(self, cmd, daemonize=False, executable=None,
                                use_unsafe_shell=False):
        return 0, "", ""

    class TestModule(object):
        def __init__(self):
            self.run_command = test_module_run_command

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()

    obj = TestClass()
    obj.detect_sysctl()
    assert obj.sysctl_path is None
    virtual_product_facts = obj.detect_virt_product("hw.product")
    assert virtual_product_facts['virtualization_tech_guest'] == set()
    assert virtual_product_facts['virtualization_tech_host'] == set()
    virtual_

# Generated at 2022-06-23 02:39:14.426607
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """
    Test detect_virt_product method
    """
    from ansible.module_utils.facts.system.distribution import Distribution
    from ansible.module_utils.facts import Default
    import os
    import unittest

    class VirtualSysctlDetectionMixinTest(unittest.TestCase):
        class FakeOptions(object):
            def __init__(self):
                self.fact_path = None
                self.gather_subset = None

        class FakeModule(object):
            def __init__(self):
                self.module_args = {}
                self.options = FakeOptions()

            def get_bin_path(self, cmd):
                return os.path.sep + 'path' + os.path.sep + cmd


# Generated at 2022-06-23 02:39:25.596515
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mock_module = MockModule()
    sysctl_detection = VirtualSysctlDetectionMixin()
    sysctl_detection.module = mock_module

    # Test with a non-existing sysctl path
    sysctl_detection.sysctl_path = None
    assert sysctl_detection.detect_virt_vendor('key') == {}

    # Test with an existing sysctl path
    sysctl_detection.sysctl_path = 'sysctl'
    mock_module.run_command.return_value = (0, 'OpenBSD', '')

# Generated at 2022-06-23 02:39:34.856321
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """ Test VirtualSysctlDetectionMixin.detect_sysctl """
    # Test that detects sysctl binary in the right places
    vis = VirtualSysctlDetectionMixin()
    vis.module = MockModule("sysctl", "/usr/bin/sysctl", "")
    vis.detect_sysctl()
    assert(vis.sysctl_path == "/usr/bin/sysctl")

    # Test that detects sysctl binary in the right places
    vis = VirtualSysctlDetectionMixin()
    vis.module = MockModule("sysctl", "", "")
    vis.detect_sysctl()
    assert(vis.sysctl_path == "")


# Generated at 2022-06-23 02:39:41.720358
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """Unit test for constructor of class VirtualSysctlDetectionMixin"""
    test_virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert test_virtual_sysctl_detection_mixin is not None
    assert isinstance(test_virtual_sysctl_detection_mixin, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:39:52.337725
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    class TestModule(basic.AnsibleModule):
        pass
    module = TestModule(
        argument_spec={},
        supports_check_mode=True
    )
    class VirtualSysctlDetectionMixin_mock:
        @classmethod
        def detect_sysctl(self):
            self.sysctl_path = module.get_bin_path('sysctl')

    VirtualSysctlDetectionMixin_mock.detect_sysctl()
    assert VirtualSysctlDetectionMixin_mock.sysctl_path == module.get_bin_path('sysctl')


# Generated at 2022-06-23 02:40:02.260792
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    detect_sysctl_mixin = VirtualSysctlDetectionMixin()

    # Method detect_sysctl should return True for FreeBSD
    detect_sysctl_mixin.detect_virt_product = detect_sysctl_mixin.detect_sysctl
    assert True == detect_sysctl_mixin.detect_virt_product

    # Method detect_virt_product should return True once
    virtual_product_facts = detect_sysctl_mixin.detect_virt_product('kern.vm_guest')
    virtualization_type = virtual_product_facts.get('virtualization_type')
    assert 'kvm' == virtualization_type or 'VMware' == virtualization_type or \
           'virtualbox' == virtualization_type or 'xen' == virtualization_type or \
           'Hyper-V' == virtual

# Generated at 2022-06-23 02:40:08.446790
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    sys.modules['ansible'] = {}
    sys.modules['ansible.module_utils'] = {}
    sys.modules['ansible.module_utils.facts'] = {}
    sys.modules['ansible.module_utils.basic'] = {}
    import ansible.module_utils.facts.virtual.virtualsysctl as virtualsysctl
    from ansible.module_utils.facts.virtual.virtualsysctl import VirtualSysctlDetectionMixin
    module = virtualsysctl
    module.run_command = lambda x: (0, '', '')
    v = VirtualSysctlDetectionMixin()
    v.module = module
    assert v.detect_virt_product('hw.model') == {}


# Generated at 2022-06-23 02:40:18.765752
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # mock the module object
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = type('', (), {})()

        def get_bin_path(self, name, opts='', environ=None, check_mode=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'test', ''

    t = TestVirtualSysctlDetectionMixin()
    t.detect_sysctl()
    assert t.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:40:27.047007
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_inst = VirtualSysctlDetectionMixin()
    test_inst.module = FakeAnsibleModule()
    test_inst.sysctl_path = "/bin/true"
    assert test_inst.detect_virt_vendor("security.jail.jailed") == {'virtualization_role': 'guest', 'virtualization_type': 'jails', 'virtualization_tech_guest': {'jails'}, 'virtualization_tech_host': set()}
    assert test_inst.detect_virt_vendor("hw.model") == {}
    assert test_inst.detect_virt_vendor("hw.machine_arch") == {}


# Generated at 2022-06-23 02:40:31.284021
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """Unit test for method detect_virt_vendor of class \
    VirtualSysctlDetectionMixin
    """
    obj = VirtualSysctlDetectionMixin()
    # Virtual sysctl
    # kern.vm_guest
    obj.sysctl_path = "/sbin/sysctl"
    obj.module.run_command = lambda x: (0, "qemu", "")
    assert obj.detect_virt_vendor('kern.vm_guest') == {
        "virtualization_type": "kvm",
        "virtualization_role": "guest",
        "virtualization_tech_guest": {"kvm"},
        "virtualization_tech_host": set()
    }
    obj.module.run_command = lambda x: (0, "OpenBSD", "")
    assert obj.det

# Generated at 2022-06-23 02:40:36.153019
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    assert isinstance(obj, VirtualSysctlDetectionMixin)
    assert hasattr(obj, 'detect_sysctl')
    assert hasattr(obj, 'detect_virt_product')
    assert hasattr(obj, 'detect_virt_vendor')

if __name__ == '__main__':
    test_VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:40:44.000949
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/usr/bin/sysctl'
    test_module = TestModule()
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = test_module
    vsdm.detect_sysctl()
    assert vsdm.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:40:46.696302
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:40:48.627025
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MockModule()
    mixin.detect_sysctl()



# Generated at 2022-06-23 02:40:50.222733
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:40:55.292014
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    # check if VirtualSysctlDetectionMixin is registered correctly
    obj = VirtualSysctlDetectionMixin()
    assert obj.platform == 'openbsd'
    assert obj.distribution == 'OpenBSD'
    assert obj.distribution_version == '6.1'

# Generated at 2022-06-23 02:41:04.187271
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class MyVirtualSystem(VirtualSysctlDetectionMixin):
        def __init__(self, output):
            self.sysctl_path = ''
            self.sysctl_output = ''
            self.sysctl_output = output
            self.module = self
            self.sysctl_output_key0 = ''
            self.sysctl_output_key1 = ''
            self.sysctl_output_key2 = ''
            self.sysctl_output_key3 = ''

        def get_bin_path(self, executable):
            return self.sysctl_path


# Generated at 2022-06-23 02:41:09.733293
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin'''
    a = VirtualSysctlDetectionMixin()
    a.detect_virt_vendor('machdep.cpu.brand_string')
    a.detect_virt_vendor('machdep.hypervisor')
    a.detect_virt_vendor('machdep.hv_support')


# Generated at 2022-06-23 02:41:21.510822
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import platform
    import os
    import tempfile
    from ansible.module_utils.basic import AnsibleModule

    class FakeModule:
        def __init__(self, *args, **kwargs):
            return

        def get_bin_path(self, binary):
            if binary == 'sysctl':
                return binary
            else:
                return None

        def run_command(self, command):
            if command == 'sysctl -n security.jail.jailed':
                out = '1'
            elif command == 'sysctl -n hw.model':
                out = platform.machine()
            elif command == 'sysctl -n hw.machine':
                out = platform.processor()
            else:
                return (1, '', 'test error')
            return (0, out, '')

    module

# Generated at 2022-06-23 02:41:29.364314
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v_sys_d_mix=VirtualSysctlDetectionMixin()
    # Please make sure this function returns an empty dict if there's no sysctl
    assert v_sys_d_mix.detect_virt_product('test_key') == {}
    assert v_sys_d_mix.detect_virt_vendor('test_key') == {}
    # Please make sure detect_sysctl is called
    # Please make sure detect_virt_product is called if sysctl is detected
    # Please make sure detect_virt_vendor is called if sysctl is detected

    # Please make sure detect_sysctl is called
    # Please make sure detect_virt_product is called if sysctl is detected
    # Please make sure detect_virt_vendor is called if sysctl is detected

# Generated at 2022-06-23 02:41:33.393601
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    v = VirtualSysctlDetectionMixin()
    v.sysctl_path = 'sysctl'
    v.module = AnsibleModuleMock()
    r = v.detect_virt_vendor('hw.product')
    assert(r['virtualization_type'] == 'vmm')


# Generated at 2022-06-23 02:41:42.145382
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TrueMock(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, 'VirtualBox', ''

    class FalseMock(object):
        def __init__(self, *args, **kwargs):
            self.args = args
            self.kwargs = kwargs

        def get_bin_path(self, *args, **kwargs):
            return None

        def run_command(self, *args, **kwargs):
            return 0, '', ''


# Generated at 2022-06-23 02:41:45.193184
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # Test a successful mixin instantiation.
    mixin = VirtualSysctlDetectionMixin()
    assert isinstance(mixin, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:41:54.989801
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTest:
        def __init__(self, key):
            self.sysctl_path = 'test'
            self.key = key

        def detect_sysctl(self):
            return

        def run_command(self, cmd):
            if self.key == '/proc/sys/xen/independent_wallclock':
                self.result = ["0", "", ""]
            elif self.key == '/proc/cpuinfo':
                self.result = ["", "", ""]
            elif self.key == '/proc/self/status':
                self.result = ["", "", ""]
            elif self.key == 'security.jail.jailed':
                self.result = ["1", "", ""]
            return self.result

    v_test = VirtualSysctlDetectionMix

# Generated at 2022-06-23 02:42:06.376138
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class module(object):
        def get_bin_path(self, param):
            return "/usr/bin/sysctl"

    class self(object):
        def __init__(self):
            self.module = module()
            self.sysctl_path = ""

    class VirtualSysctlDetectionMixinHelper(self, VirtualSysctlDetectionMixin):
        def __init__(self):
            super(VirtualSysctlDetectionMixinHelper, self).__init__()

    helper = VirtualSysctlDetectionMixinHelper()
    helper.detect_sysctl()

    assert helper.sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-23 02:42:16.310321
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.plugins.module_utils.facts.virtual import VirtualSysctlDetectionMixin

    class TestVirtualSysctlDetectionMixin(unittest.TestCase):
        def test_virtual_sysctl_detection_mixin(self):
            v = VirtualSysctlDetectionMixin()
            v.module = MagicMock()
            v.module.run_command = MagicMock()
            v.module.get_bin_path = MagicMock()
            v.module.get_bin_path.return_value = 'bin/path'
            v.module.run_command.return_value = (0, 'Success', '')

            # Test detect

# Generated at 2022-06-23 02:42:17.327432
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:42:24.515230
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mock_module = MockAnsibleModule()
    mock_class = MockVirtualSysctlDetectionMixin()
    mock_class.detect_virt_vendor('machdep.xen.guest')
    assert_equal(mock_class.virtual_vendor_facts['virtualization_tech_host'], set())
    assert_equal(mock_class.virtual_vendor_facts['virtualization_tech_guest'], set(['xen']))
    assert_equal(mock_class.virtual_vendor_facts['virtualization_type'], 'xen')
    assert_equal(mock_class.virtual_vendor_facts['virtualization_role'], 'guest')


# Generated at 2022-06-23 02:42:25.955035
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:42:35.166990
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinObject(object):
        def __init__(self):
            self.sysctl_path = None
            self.module = None
            self.virtual_subsystem = 'sysctl'
        def detect_sysctl(self):
            self.sysctl_path = '/usr/bin/sysctl'
        def run_command(self, command):
# Output of kvm virtualization
            if command == "%s -n %s" % (self.sysctl_path, 'hw.model'):
                return (0, 'QEMU Virtual CPU version 2.5+', '')
            elif command == "%s -n %s" % (self.sysctl_path, 'virtualization.virtualization'):
                return (0, 'KVM (type: 3)', '')

# Generated at 2022-06-23 02:42:43.459237
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    expected = '/usr/bin/sysctl'
    module = FakeModule()
    toBeTested = VirtualSysctlDetectionMixin()
    toBeTested.module = module
    toBeTested.detect_sysctl()
    assert toBeTested.sysctl_path == expected
    expected = set(["kvm"])
    assert toBeTested.detect_virt_product("hw.model")["virtualization_tech_guest"] == expected
    assert toBeTested.detect_virt_vendor("hw.machine")["virtualization_type"] == "kvm"
    assert toBeTested.detect_virt_vendor("hw.machine")["virtualization_role"] == "guest"



# Generated at 2022-06-23 02:42:57.125601
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(
        argument_spec = dict(
            params = dict(required=False, type='dict')),
        supports_check_mode = True)

    results = dict(
        changed = False,
        ansible_facts = dict())

    vm = VirtualSysctlDetectionMixin()

    # Test 1: Fake data
    vm.sysctl_path = '/path/to/sysctl'
    key = '/fake/key'
    out = """
VirtualBox
"""
    rc = 0
    vm.module = module
    vm.module.run_command = Mock(return_value=(rc, out, ''))
    # Tests
    res = vm.detect_virt_product(key)

# Generated at 2022-06-23 02:43:09.366842
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class Args:
        def __init__(self):
            self.apiversion = '2.4'

    class Module:
        def __init__(self):
            self.params = Args()
            self.check_mode = False
            self.exit_json = exit_json
            self.fail_json = fail_json

    class AnsibleModule(object):
        def __init__(self, module):
            self.params = Args()
            self.check_mode = False
            self.exit_json = exit_json
            self.fail_json = fail_json

        def get_bin_path(self, executable):
            return '/usr/bin/%s' % executable


# Generated at 2022-06-23 02:43:18.445216
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class DummyModule:
        def run_command(self, command):
            return (0, '', '')

        def get_bin_path(self, name):
            return "/sbin/sysctl"

    test_module = DummyModule()
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = test_module
    assert vsdm.detect_virt_product('machdep.cpu.brand_string') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    assert vsdm.detect_virt_vendor('kern.vm_guest') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

# Generated at 2022-06-23 02:43:28.018515
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual import VirtualSysctlDetectionMixin, VirtualSysctlModule

    mixin = VirtualSysctlDetectionMixin()

    class FakeModule(object):
        def __init__(self):
            self.module = None

        def get_bin_path(self, arg):
            return "/bin/sysctl"

        def run_command(self, arg):
            return 0, "VMware", None
    mixin.module = FakeModule()

    result = mixin.detect_virt_product("vm.vmware.witness")
    assert "VMware" in result.get('virtualization_tech_guest', None)
    assert result.get('virtualization_type', None) == "VMware"
    assert result.get('virtualization_role', None) == "guest"

   

# Generated at 2022-06-23 02:43:38.220824
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    class MockModule(object):
        def get_bin_path(self, foo, *args, **kwargs):
            return '/bin/sysctl'

    class MockArgs(object):
        def __init__(self):
            self.connection = 'foo'
            self.become = False
            self.become_method = 'foo'
            self.become_user = 'foo'
            self.module_name = 'foo'
            self.module_args = 'foo'
            self.no_log = 'foo'
            self.output_path = 'foo'
            self.private_data_dir = 'foo'
            self.verbosity = 'foo'
            self.version = 'foo'

    class MockPlayContext(object):
        def __init__(self):
            self.check_mode = 'foo'

# Generated at 2022-06-23 02:43:46.562407
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class BSD:
        def __init__(self):
            pass

        sysctl_path = "/usr/sbin/sysctl"

    class ModuleTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = BSD()

    bsd = ModuleTest()
    assert bsd.detect_virt_vendor('hw.model') == {'virtualization_tech_host': set(),
                                                  'virtualization_tech_guest': set(),
                                                  'virtualization_role': 'guest',
                                                  'virtualization_type': 'kvm'}



# Generated at 2022-06-23 02:43:55.655712
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest

    import sys
    sys.modules['ansible'] = None
    sys.modules['ansible.module_utils'] = None
    sys.modules['ansible.module_utils.facts'] = None
    sys.modules['ansible.module_utils.facts.virtual'] = None
    import ansible.module_utils.facts.virtual as virtual

    class FreeBSDKernelModule(object):
        def __init__(self):
            self.name = None
            self.sysctl_path = None
            self.result = {'ansible_facts': {}}
            self.parsed = False
            self.failed = False
            self.changed = False
            self.msg = ''
            self.rc = 0


# Generated at 2022-06-23 02:44:06.737950
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FauxModule(object):
        def get_bin_path(self, name):
            return '/usr/sbin/sysctl'
        def run_command(self, cmd):
            return (0, 'OpenBSD', '')

    prompt_re = [
        "If you expect to find a hypervisor, please file a bug",
        re.compile(r"[\r\n]?\[Y\/n\]\s*$"),
        re.compile(r"\[confirm\]\s*$")
    ]

    def test_failure(cmd, rc, out, err):
        return (1, '', '')

    fails_rc_1_with_exception = dict(failed=True, rc=1, cmd=cmd)
    sysctl_path = '/usr/sbin/sysctl'

# Generated at 2022-06-23 02:44:16.739095
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(argument_spec={})
    class_instance = VirtualSysctlDetectionMixin()
    class_instance.module = module
    class_instance.sysctl_path = '/usr/bin/sysctl'
    virtual_facts = class_instance.detect_virt_product('hw.model')
    assert ('virtualization_tech_host' in virtual_facts)
    assert ('virtualization_tech_guest' in virtual_facts)
    assert ('virtualization_role' in virtual_facts)
    assert ('virtualization_type' in virtual_facts)
    assert virtual_facts['virtualization_tech_host'] == set()
    assert len(virtual_facts['virtualization_tech_guest']) >= 1
    assert virtual_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:44:25.073316
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    methods = [
        {
            'name': 'detect_sysctl',
            'return': (True, 'daemon doesnt matter since we mock' ),
            'return_args': (('/sbin/sysctl',), {}),
            'call_args': ('/sbin/sysctl',),
            'get_bin_path_args': ('sysctl',)
        },
    ]
    args = {}
    mocker = MockerTestCase(VirtualSysctlDetectionMixin, methods=methods, arguments=args)
    mocker.mock()
    mocker.detect_sysctl()
    mocker.assert_called('detect_sysctl')
    mocker.assert_called('get_bin_path')


# Generated at 2022-06-23 02:44:36.384850
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_args = ['security.jail.jailed: 1']
    test_sysctl_path = '/usr/sbin/sysct'
    virtual_sysctl_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_mixin.sysctl_path = test_sysctl_path
    virtual_sysctl_mixin.module = MockModule(test_args)
    virtual_vendor = virtual_sysctl_mixin.detect_virt_vendor('security.jail.jailed')
    assert virtual_vendor['virtualization_type'] == 'jails'
    assert virtual_vendor['virtualization_role'] == 'guest'
    assert len(virtual_vendor['virtualization_tech_host']) == 0