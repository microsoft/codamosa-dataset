

# Generated at 2022-06-23 02:34:46.368623
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mock_module = MagicMock()
    mock_module.get_bin_path.return_value = "/sbin/sysctl"
    mock_module.run_command.return_value = (0, "QEMU", None)

    s = VirtualSysctlDetectionMixin()
    s.module = mock_module

    detect_virt_vendor_facts = s.detect_virt_vendor('hw.product')
    assert detect_virt_vendor_facts == {'virtualization_role': 'guest', 'virtualization_type': 'kvm',
                                        'virtualization_tech_host': set([]),
                                        'virtualization_tech_guest': {'kvm'}}

# Generated at 2022-06-23 02:34:50.554788
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Setup
    obj = VirtualSysctlDetectionMixin()
    obj.module = MockModule()
    obj.module.get_bin_path = Mock(return_value='/sbin/sysctl')

    # Test
    obj.detect_sysctl()

    # Assert
    obj.sysctl_path.should.equal('/sbin/sysctl')


# Generated at 2022-06-23 02:34:52.962126
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert sysctl_detection_mixin

# Generated at 2022-06-23 02:34:59.368969
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.collector.openbsd import OpenBSDCollector
    openbsd_fact_instance = OpenBSDCollector()

    class Caller:
        pass

    instance = VirtualSysctlDetectionMixin()
    instance.module = Caller()
    instance.module.get_bin_path = lambda x: '/sbin'
    instance.detect_sysctl()
    assert instance.sysctl_path == '/sbin/sysctl'



# Generated at 2022-06-23 02:35:08.267072
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = dict()

        def get_bin_path(self, name, opt_dirs=[]):
            return ''

        def run_command(self, cmd):
            return(0, 'QEMU', '')

    sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    module = MockModule()
    sysctl_detection_mixin.module = module

# Generated at 2022-06-23 02:35:14.536226
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_class = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:35:25.010165
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def get_bin_path(self, name):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return (0, 'KVM', '')

    class Facts(object):
        pass

    class System(object):
        def __init__(self):
            self.module = Module()
            self.facts = Facts()

    system = System()
    sysctl_detect = VirtualSysctlDetectionMixin()
    sysctl_detect.detect_sysctl()
    sysctl_detect.module = system.module
    sysctl_detect.facts = system.facts
    sysctl_detect.detect_virt_product('hw.model')
    assert sysctl_detect.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:35:36.401429
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''
    Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
    '''
    # Create a test object
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = '/sbin/sysctl'
    obj.sysctl_cmd = 'sysctl'
    obj.module = Mock()

    # Create expected results
    expected_out_qemu = dict(virtualization_type = 'kvm', virtualization_role = 'guest', virtualization_tech_guest = set(['kvm']), virtualization_tech_host = set())
    expected_out_vmm = dict(virtualization_type = 'vmm', virtualization_role = 'guest', virtualization_tech_guest = set(['vmm']), virtualization_tech_host = set())
   

# Generated at 2022-06-23 02:35:47.075245
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.sysctl_path = '/usr/sbin/sysctl'

    test_vendor_key = 'vm.product'

    virtual_vendor_facts = mixin.detect_virt_vendor(test_vendor_key)

    guest_tech = set(['kvm'])

    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert virtual_vendor_facts['virtualization_tech_guest'] == guest_tech
    assert virtual_vendor_facts['virtualization_tech_host'] == set()


# Generated at 2022-06-23 02:35:48.453337
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    a = VirtualSysctlDetectionMixin()
    assert a


# Generated at 2022-06-23 02:35:53.604560
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule({})
    virtual_mixin = VirtualSysctlDetectionMixin()
    virtual_mixin.module = module

    # Test when sysctl is not installed
    virtual_mixin.sysctl_path = None
    virtual_mixin.detect_sysctl()
    assert virtual_mixin.sysctl_path is None

    # Test when sysctl is installed
    virtual_mixin.sysctl_path = '/usr/bin/sysctl'
    virtual_mixin.detect_sysctl()
    assert virtual_mixin.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:35:59.664446
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    '''
    Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
    '''
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    VDM = VirtualSysctlDetectionMixin()
    return_dict = VDM.detect_virt_product('machdep.guest')
    assert type(return_dict) is dict
    return_dict = VDM.detect_virt_product('security.jail.jailed')
    assert type(return_dict) is dict


# Generated at 2022-06-23 02:36:09.327751
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def __init__(self):
            self.bin_path = '/bin/:/usr/bin:/usr/local/bin'

        def get_bin_path(self, path):
            paths = self.bin_path.split(':')
            for p in paths:
                if p:
                    if '%s/%s' % (p, path) == '/bin/sysctl':
                        return '/bin/sysctl'
            return path

    class FakeObj(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    obj = FakeObj()
    obj.detect_sysctl()
    assert obj.sysctl_path == '/bin/sysctl'

    class FakeModule2(object):
        def __init__(self):
            self

# Generated at 2022-06-23 02:36:16.389676
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetect
    test_obj = VirtualSysctlDetect()
    test_obj.detect_sysctl = lambda: None
    test_obj.module.run_command = lambda x: (0, "kvm\n", "")
    virt_facts = test_obj.detect_virt_product("hw.model")
    assert virt_facts['virtualization_type'] == 'kvm'
    assert virt_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:36:27.883753
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def __init__(self):
            self._module = None
            self._bin_path = '/bin'

        def get_bin_path(self, executable, warnings=True):
            return self._bin_path + '/' + executable

        def run_command(self, cmd):
            assert cmd == '/bin/sysctl -n kern.vm_guest'
            return (0, 'KVM, FreeBSD', 'error')

    mock = MockModule()
    v = VirtualSysctlDetectionMixin()
    v.module = mock
    assert v.detect_virt_product('kern.vm_guest') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}


# Generated at 2022-06-23 02:36:36.466782
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import random
    class VirtualSysctlDetectionMixin_test():
        def __init__(self):
            self.sysctl_path = "/usr/sbin/sysctl"
            self.virtualization_type = None
            self.virtualization_role = None

        def detect_sysctl(self):
            pass

        def run_command(self, cmd):
            return(0, random.choice(["OpenBSD", "QEMU"]), None)

    v = VirtualSysctlDetectionMixin_test()
    v.detect_virt_vendor('this.variable.doesnt.exist-1337')
    assert(v.virtualization_type == 'vmm' or v.virtualization_type == 'kvm')

# Generated at 2022-06-23 02:36:43.337169
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virt_vendor_dict = {'openbsd': 'OpenBSD', 'qemu': 'QEMU'}
    key = 'hw.vmm.vendor'

    class module(object):
        def run_command(command, check_rc=True):
            return 0, virt_vendor_dict.get(command.split()[-1]), ''

    class FakeSysctl(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = module()

    fact = FakeSysctl().detect_virt_vendor(key)

# Generated at 2022-06-23 02:36:52.028650
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule:
        def __init__(self):
            self.fail_json = lambda **kwargs: None

        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, command):
            return (0, 'QEMU', '')

    class MockClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    test_class = MockClass()
    test_class.detect_virt_vendor("hw.model")

    assert test_class.module.__dict__['virtualization_type'] == 'kvm'
    assert test_class.module.__dict__['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:36:54.148958
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vssdetection = VirtualSysctlDetectionMixin()
    assert vssdetection is not None

# Generated at 2022-06-23 02:37:01.548653
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = type('FakeModule', (object,), {})
    module.get_bin_path = lambda self, _: '/usr/bin/sysctl'
    module.run_command = lambda self, _: (0, '', '')
    VSDM = VirtualSysctlDetectionMixin()
    VSDM.module = module
    assert VSDM.detect_sysctl()
    for key in ['hw.model', 'security.jail.jailed', 'hw.machine_arch']:
        assert VSDM.detect_virt_product(key)
        assert VSDM.detect_virt_vendor(key)

# Generated at 2022-06-23 02:37:08.148007
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        class Module:
            def __init__(self):
                pass

            def run_command(self, command):
                return 0

            def get_bin_path(self, binary):
                pass
    # The __new__() function is called before __init__(), but it should be
    # created as an instance of this class.
    try:
        _ = TestClass()
    except:
        assert False, 'The class should be created as an instance.'


# vim: filetype=python

# Generated at 2022-06-23 02:37:16.127934
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    sys.modules['ansible'] = __import__('mock')
    from ansible.module_utils.facts import virtual_sysctl_detection_mixin
    class_instance = virtual_sysctl_detection_mixin.VirtualSysctlDetectionMixin()
    class_instance.sysctl_path = 'mock_sysctl_path'
    class_instance.module = object()
    class_instance.module.get_bin_path = object()
    class_instance.module.run_command = object()
    class_instance.module.get_bin_path.return_value = 'mock_bin_path'
    class_instance.module.run_command.return_value = (0, 'kvm', None)
    out = class_instance.detect_virt_product('mock_key')


# Generated at 2022-06-23 02:37:27.223234
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # For testing, we need to enter the class and call the method without actually running
    # the module.  This is an option that seems to work, though it requires that we have
    # an empty dictionary for self.facts, which we create below.
    fake_self = {'facts': {}, 'module': 'fake_module'}
    # setup virtual_vendor_facts to match the output of sysctl -n hw.product
    VirtualSysctlDetectionMixin.detect_sysctl = lambda self: 'fake_sysctl'
    class FakeModule(object):
        def __init__(self, sysctl_path):
            self.sysctl_path = sysctl_path
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'

# Generated at 2022-06-23 02:37:37.748220
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.bsd import VirtualSysctlDetectionMixin
    tester = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:37:43.767230
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Obj(object):
        def __init__(self):
            self.sysctl_path = None
            self.module = Obj()
            self.test_args = None
            self.changed = False

    class Module:
        def get_bin_path(self, command):
            return command

    obj = Obj()
    obj.detect_sysctl()
    assert obj.sysctl_path == "sysctl"



# Generated at 2022-06-23 02:37:48.464068
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class PublicVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        pass
    assert (issubclass(PublicVirtualSysctlDetectionMixin, VirtualSysctlDetectionMixin))
    assert (PublicVirtualSysctlDetectionMixin(None) is not None)



# Generated at 2022-06-23 02:37:58.030881
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    class DummyModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}

        def exit_json(self, **kwargs):
            self.facts = kwargs
            self.exit_args = kwargs
            self.exit_called = True

        def fail_json(self, **kwargs):
            self.exit_args = kwargs
            self.fail_called = True

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            out = 'OpenBSD'
            return 0, out, ''

    my_obj = VirtualSysctlDetectionMixin()
    my_obj.module = Dummy

# Generated at 2022-06-23 02:38:05.726507
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_vendor_facts = {}

    guest_tech = set()
    host_tech = set()
    guest_tech.add('kvm')
    virtual_vendor_facts['virtualization_type'] = 'kvm'
    virtual_vendor_facts['virtualization_role'] = 'guest'

    virtual_vendor_facts['virtualization_tech_guest'] = guest_tech
    virtual_vendor_facts['virtualization_tech_host'] = host_tech

    assert VirtualSysctlDetectionMixin().detect_virt_vendor('hw.model') == virtual_vendor_facts


# Generated at 2022-06-23 02:38:17.391988
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = MockModule()

    class MockModule:
        def get_bin_path(self, cmd):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            return (rc, out, err)

    rc, out, err = 0, '', ''
    test_virtual_sysctl_detection_mixin = TestVirtualSysctlDetectionMixin()
    test_virtual_sysctl_detection_mixin.module.run_command.return_value = (rc, out, err)
    test_virtual_sysctl_detection_mixin.detect_sysctl()
    assert test_virtual_sysctl_det

# Generated at 2022-06-23 02:38:26.589161
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class module_mock:
        def get_bin_path(self, module):
            return '/sbin/sysctl'
    class mixin_mock(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    mixin_mock_obj = mixin_mock(module_mock())
    mixin_mock_obj.detect_sysctl()
    assert '/sbin/sysctl' == mixin_mock_obj.sysctl_path


# Generated at 2022-06-23 02:38:38.172117
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class test_module_detect_virt_vendor(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

    virtual_sysctl_detection_mixin_class_ins = test_module_detect_virt_vendor()
    virtual_sysctl_detection_mixin_class_ins.module = AnsibleModule(argument_spec={})
    virtual_vendor_facts = virtual_sysctl_detection_mixin_class_ins.detect_virt_vendor("kern.vm_guest")
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:38:48.595136
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class OpenBSDSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            super(OpenBSDSysctlDetectionMixinTest, self).detect_sysctl()
            self.sysctl_path = '/sbin/sysctl'

    class OpenBSDSysctlDetectionMixinTestModule(object):
        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, 'QEMU', None

    module = OpenBSDSysctlDetectionMixinTestModule()
    fact_class = OpenBSDSysctlDetectionMixinTest(module)
    assert fact_class.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-23 02:38:55.646883
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.basic import AnsibleModule

    class Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = AnsibleModule(
                argument_spec=dict(),
            )

    t = Test()
    t.detect_sysctl()

    assert t.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:39:06.335911
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class TestModule(object):
        def __init__(self, run_command_output, get_bin_path_output):
            self.run_command_output = run_command_output
            self.get_bin_path_output = get_bin_path_output

        def run_command(self, cmd):
            return self.run_command_output

        def get_bin_path(self, cmd, required=False):
            return self.get_bin_path_output


# Generated at 2022-06-23 02:39:12.958483
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MagicMock()
    module.get_bin_path = MagicMock(return_value='path')
    virt_sysctl_test = VirtualSysctlDetectionMixin()
    virt_sysctl_test.module = module
    virt_sysctl_test.detect_sysctl()
    assert virt_sysctl_test.sysctl_path == 'path'



# Generated at 2022-06-23 02:39:25.124846
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    x = VirtualSysctlDetectionMixin()
    x.sysctl_path = ''
    assert x.detect_virt_product('') == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}
    x.sysctl_path = '/sbin'
    assert x.detect_virt_product('hw.model') == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}
    x.sysctl_path = '/sbin'
    assert x.detect_virt_product('kern.hostname') == {'virtualization_tech_guest': set([]), 'virtualization_tech_host': set([])}
    x.sysctl_path = '/sbin'
    assert x.detect_virt_

# Generated at 2022-06-23 02:39:33.305202
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule(object):
        def get_bin_path(self, program):
            return program
    class TestDetectVirtSysctl(VirtualSysctlDetectionMixin):
        def __init__(self, _module):
            self.module = _module
            self.virtual_facts = {}
    for key in ['security.jail.jailed', 'machdep.hypervisor', 'machdep.virtual_guest']:
        test = TestDetectVirtSysctl(TestModule())
        test.detect_sysctl()
        assert test.sysctl_path == 'sysctl'


# Generated at 2022-06-23 02:39:44.846032
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    '''test class for detect_virt_product'''
    my_obj = VirtualSysctlDetectionMixin()
    my_obj.module = MagicMock()
    my_obj.module.get_bin_path.return_value = '/sbin/sysctl'
    my_obj.module.run_command.return_value = (0, '', '')
    assert my_obj.detect_virt_product('kvm key') == dict()
    my_obj.module.run_command.return_value = (0, 'KVM', '')
    assert my_obj.detect_virt_product('kvm key') == dict(virtualization_type='kvm', virtualization_role='guest')
    my_obj.module.run_command.return_value = (0, 'kvm', '')
    assert my

# Generated at 2022-06-23 02:39:49.488151
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    '''
    unit test for constructor of class VirtualSysctlDetectionMixin
    '''
    vscd_obj = VirtualSysctlDetectionMixin()
    assert isinstance(vscd_obj, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:39:58.671060
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.bsd import VirtualSysctlDetectionMixin
    test_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    test_string = 'KVM (for Virtual Machines)'
    # Need to mock out module.run_command, so we make our own run_command method
    def test_run_command(self_module, command):
        return (0, test_string, '')
    # Add our run_command method to the test_sysctl_detection_mixin
    # and then call the detect_virt_product method
    test_sysctl_detection_mixin.run_command = test_run_command
    test_sysctl_detection_mixin.run_command = test_run_command
    test_sysctl_detection_mixin.detect_

# Generated at 2022-06-23 02:40:03.104931
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    temp = VirtualSysctlDetectionMixin()
    assert temp.detect_virt_product('hw.model') == {
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': set(),
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm'
    }



# Generated at 2022-06-23 02:40:06.925928
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class BSDModule:
        def get_bin_path(self, command):
            return '/sbin/sysctl'
    class BSDPlatform:
        def __init__(self):
            self.module = BSDModule()
    bsdplatform = BSDPlatform()
    bsdplatform.detect_sysctl()
    assert bsdplatform.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:40:08.452739
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    f = VirtualSysctlDetectionMixin()
    assert f

# Generated at 2022-06-23 02:40:13.896211
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Test that detect_sysctl() always return something
    # VirtualSysctlDetectionMixin is an abstract class, so we need to use the
    # built-in function when to create an instance.
    obj = when('')
    obj.detect_sysctl()
    assert obj.sysctl_path

# Generated at 2022-06-23 02:40:24.391569
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansibledetail.ansible_module_facts import AnsibleModuleFacts
    import os
    import shutil
    import stat

    # Setup temp testing dir
    test_dir = '/tmp/ansible_test_dir'
    if not os.path.exists(test_dir):
        os.mkdir(test_dir)

    # Setup temp test files
    sysctl_exec = """#!/bin/sh
echo $1
"""
    sysctl_path = '%s/sysctl' % test_dir

    sysctl_file = open(sysctl_path, 'w')
    sysctl_file.write(sysctl_exec)
    sysctl_file.close()

    os.chmod(sysctl_path, os.stat(sysctl_path).st_mode | stat.S_IEXEC)

# Generated at 2022-06-23 02:40:34.907001
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys

    class FakeModule(object):
        def __init__(self):
            self.params = {
                'system_vendor': 'QEMU'
            }

        def get_bin_path(self, name, required=False):
            if name == 'sysctl':
                return sys.executable

        def run_command(self, cmd):
            return (0, self.params['system_vendor'], '')

        def fail_json(self, **kwargs):
            pass

    class FakeSystem(object):
        def __init__(self):
            self.module = FakeModule()

    class FakeVirtualizationMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass

    vsc = FakeVirtualizationMixin()
    vsc.detect_virt_vendor

# Generated at 2022-06-23 02:40:37.867433
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection = VirtualSysctlDetectionMixin()
    # Unit test to test the constructor of class VirtualSysctlDetectionMixin
    assert isinstance(virtual_sysctl_detection, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:40:40.241756
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtualSysctlDetectionMixin = VirtualSysctlDetectionMixin()
    assert isinstance(virtualSysctlDetectionMixin, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:40:48.808039
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def __init__(self):
            self.bin_path = True

        def get_bin_path(self, path):
            return self.bin_path


# Generated at 2022-06-23 02:40:54.116732
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    assert VirtualSysctlDetectionMixin.detect_virt_vendor(None, '') == {
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([]),
        'virtualization_type': 'kvm'
    }

# Generated at 2022-06-23 02:41:03.250711
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    with open('unit-tests/fixtures/FreeBSD_sysctl_out.txt') as fh:
        sysctl_out = fh.read()

    class FakeModule:
        def __init__(self):
            self.path = None
            self.run_command_result = [0, sysctl_out, None]
            self.run_command_rc = 0

        def get_bin_path(self, name):
            return 'sysctl'

        def run_command(self, command):
            return self.run_command_result
    fake_module = FakeModule()
    virtual_sysctl_detection = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection.module = fake_module
    virtual_sysctl_detection.detect_sysctl()

# Generated at 2022-06-23 02:41:12.858302
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = {}

        def get_bin_path(self, executable):
            return ''

        def run_command(self, command):
            return self.run_command_results[command]

    class FakeMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # OpenBSD
    test_module = FakeModule()
    test_mixin = FakeMixin(test_module)
    # On OpenBSD, sysctl reports hw.product is OpenBSD and hw.vendor is OpenBSD
    test_module.run_command_results['%s -n hw.vendor' % test_mixin.sysctl_path] = (0, 'OpenBSD', '')

# Generated at 2022-06-23 02:41:22.995478
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
        def get_bin_path(self, command):
            return '/usr/bin/%s' % command

    class FakeOsRelease(object):
        def __init__(self):
            self.distinction = {}
        def to_dict(self):
            return self.distinction

    class FakeFacts(VirtualSysctlDetectionMixin, object):
        def __init__(self):
            self.distro = FakeOsRelease()
            self.module = FakeModule()
            self.sysctl_path = None

    fake_facts = FakeFacts()
    fake_facts.detect_sysctl()
    assert fake_facts.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:41:30.721958
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command_results = [(0, 'KVM', ''),
                                        (0, '', ''),
                                        (0, 'Bochs', ''),
                                        (0, 'VMware', ''),
                                        (0, 'VirtualBox', ''),
                                        (0, 'HVM domU', ''),
                                        (0, 'XenPVHVM', ''),
                                        (0, 'Hyper-V', ''),
                                        (0, 'Parallels', ''),
                                        (0, 'RHEV Hypervisor', ''),
                                        (0, '1', ''),
                                        (1, '', '')]

        def get_bin_path(self, name):
            return 'sysctl'


# Generated at 2022-06-23 02:41:41.695442
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = FakeModule()
    sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    sysctl_detection_mixin.module = module
    sysctl_detection_mixin.sysctl_path = '/sbin/sysctl'

    # Fake kvm virtualization product test
    module.run_command_rc = 0
    module.run_command_out[0] = 'KVM'
    guest_tech = set(['kvm'])
    virtual_product_facts = sysctl_detection_mixin.detect_virt_product('kern.vm_guest')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:41:45.765547
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Test(object):
        module = AnsibleModuleMock()
        sysctl_path = None

        def detect_sysctl(self):
            self.sysctl_path = 'sysctl'

        def detect_virt_product(self, key):
            return self.detect_virt_product(key)

        def detect_virt_vendor(self, key):
            return self.detect_virt_vendor(key)

    class AnsibleModuleMock(object):
        class run_command(object):
            def __init__(self, cmd, stderr=-2, rc=-1, stdout=''):
                self.cmd = cmd
                self.rc = rc
                self.stdout = stdout
                self.stderr = stderr


# Generated at 2022-06-23 02:41:55.341300
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.exit_json = lambda v, **kwargs: True

    class test_object(object):
        def __init__(self):
            self.sysctl_path = '/bin/sysctl'

        def run_command(self, *args, **kwargs):
            command = args[0]

            if command == '/bin/sysctl -n hw.model':
                return (0, 'C', '')

            return (1, '', '')

        def get_bin_path(self, *args, **kwargs):
            return '/bin/' + args[0]

    test = VirtualSysctlDetectionMixin()
    test.module = test_module
    test.get_bin_path = test_

# Generated at 2022-06-23 02:41:58.666230
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_sysctl()
    assert mixin.sysctl_path is not None


# Generated at 2022-06-23 02:42:08.716085
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestObject(VirtualSysctlDetectionMixin):
        def __init__(self):
            super(TestObject, self).__init__()
            self.sysctl_path = '$sysctl_path'
            self.module = TestModule()

    test_obj = TestObject()
    # Key matches 'kvm'
    test_obj.module.run_command = mock_run_command("(KVM|kvm)", 0)
    assert test_obj.detect_virt_product('') == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_host': set(),
        'virtualization_tech_guest': {'kvm'}
    }
    # Key matches 'VMware'
    test_obj.module.run_command

# Generated at 2022-06-23 02:42:20.146259
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs
        @staticmethod
        def get_bin_path(name):
            return name

        def run_command(self, name):
            return 0, 'SmartDC - SmartOS PVHVM guest', ''

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, **kwargs):
            self.module = FakeModule(**kwargs)

    fake_class = FakeClass()
    result = fake_class.detect_virt_product('hw.product')
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'kvm'
    assert 'kvm' in result['virtualization_tech_guest']

# Generated at 2022-06-23 02:42:32.272922
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import copy

    class Module(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, b, required=False, opt_dirs=None):
            return b

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            return self.rc, self.out, self.err

    module = Module(0, 'KVM with emulated SCSI', '')
    detector = VirtualSysctlDetectionMixin()
    results = dict()

    for key in ['kern.vm_guest', 'security.jail.jailed']:
        result = detector.detect_virt_product

# Generated at 2022-06-23 02:42:42.488772
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestVirtualSysctlDetectionMixin(object):
        def __init__(self):
            self.module = type('module', (object, ), {})()
            self.module.run_command = lambda x: (0, 'KVM', '')
            self.module.get_bin_path = lambda x: '/usr/bin/sysctl'

    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'
    v.detect_virt_product('hw.model')
    assert v.sysctl_path == '/usr/bin/sysctl'
    v.detect_virt_vendor('hw.vendor')
    assert v.sysctl_path == '/usr/bin/sysctl'

# Generated at 2022-06-23 02:42:49.925789
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    mock_module = MockModule()
    mock_module.run_command = MagicMock(return_value=(0, 'VMware', ''))
    mock_module.get_bin_path = MagicMock(return_value='/usr/bin/sysctl')

    mixin = VirtualSysctlDetectionMixin()

    mixin.module = mock_module
    mixin.sysctl_path = None
    mixin.detect_sysctl()
    assert mixin.sysctl_path == 'sysctl'

    mixin.module = mock_module
    mixin.sysctl_path = '/usr/local/bin/sysctl'
    mixin.detect_sysctl()
    assert mixin.sysctl_path == '/usr/local/bin/sysctl'


# Generated at 2022-06-23 02:43:00.563351
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.bin_path = dict(sysctl='/sbin/sysctl')
        def get_bin_path(self, binary):
            return self.bin_path[binary]
        def run_command(self, command):
            return None

    class FakeParent(object):
        def __init__(self):
            self.module = FakeModule()

    p = FakeParent()
    p.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl.__get__(p)
    p.detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor.__get__(p)

    r = p.detect_virt_vendor('hw.model')

    assert p.sysctl_path

# Generated at 2022-06-23 02:43:11.580992
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = MockModule()
    virtual_sysctl_detection_mixin.module.run_command = Mock(return_value=(0, 'QEMU', ''))
    result = virtual_sysctl_detection_mixin.detect_virt_vendor('vm.vmm.vendor')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' in result['virtualization_tech_guest']
    assert 0 == len(result['virtualization_tech_host'])

# Generated at 2022-06-23 02:43:21.879666
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def __init__(self):
            self.bin_path = '/bin/'

        def get_bin_path(self, path):
            return '%s%s' % (self.bin_path, path)

        def run_command(self, cmd):
            if cmd == '/bin/sysctl -n hw.product':
                return 0, 'OpenBSD', ''
            elif cmd == '/bin/sysctl -n hw.vendor':
                return 0, 'QEMU', ''
            else:
                raise Exception('bad run_command')

    class FakeFacts(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = None

    f = FakeFacts()
    f.detect_virt

# Generated at 2022-06-23 02:43:25.388407
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    fixture = VirtualSysctlDetectionMixin()
    fixture.module = MockModule("sysctl", [ "sysctl" ])
    fixture.detect_sysctl()
    assert fixture.sysctl_path == "sysctl"


# Generated at 2022-06-23 02:43:36.056945
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = self

        def get_bin_path(self, arg, *args, **kwargs):
            return 'path/to/dummy/sbin/' + arg

        def run_command(self, arg, *args, **kwargs):
            if arg.startswith('path/to/dummy/sbin/sysctl -n kern.vm_guest'):
                return 0, 'XenPVHVM', None
            else:
                return 0, 'path/to/dummy/sbin/', None

    t = TestModule()
    t.detect_sysctl()
    assert t
    out = t.detect_virt_product('kern.vm_guest')

# Generated at 2022-06-23 02:43:40.317826
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    try:
        obj = VirtualSysctlDetectionMixin()
        assert obj
    except NameError:
        raise AssertionError("Failed to instantiate VirtualSysctlDetectionMixin class.")

# Generated at 2022-06-23 02:43:50.057331
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # Setup the mocks
    class MockModule(object):
        def __init__(self):
            self.run_command_args = []

        def get_bin_path(self, arg):
            return "/bin/sysctl"

        def run_command(self, command, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False):
            self.run_command_args.append(command)
            if command[2] == 'hw.model':
                return 0, "Darwin", ""
            elif command[2] == 'hw.memsize':
                return 0, "16.00 GB", ""

# Generated at 2022-06-23 02:43:56.707392
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.system.base import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.collector import BaseFactCollector
    class MyCollector(BaseFactCollector, VirtualSysctlDetectionMixin):
        name = 'virtual'
        _fact_ids = set(['virtual'])

    c = MyCollector()
    assert isinstance(c, MyCollector)
    assert isinstance(c, BaseFactCollector)
    assert isinstance(c, VirtualSysctlDetectionMixin)
    assert hasattr(c, 'detect_sysctl')

# Generated at 2022-06-23 02:43:57.831306
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v is not None

# Generated at 2022-06-23 02:44:05.501835
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    facts = {}
    facts['virtualization_type'] = ''
    facts['virtualization_role'] = ''
    facts['virtualization_tech_guest'] = set()
    facts['virtualization_tech_host'] = set()

    facts['system'] = 'OpenBSD'
    m = VirtualSysctlDetectionMixin()
    facts = m.detect_virt_vendor('machdep.cpu_vendor')
    assert facts['virtualization_type'] == 'vmm'
    assert facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:44:09.248695
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModuleMock({})
    obj = VirtualSysctlDetectionMixin()
    obj.module = module

    obj.detect_sysctl()
    assert obj.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:44:20.970836
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            if cmd.endswith('kern.vm_guest'):
                return (0, "FreeBSD", "")
            elif cmd.endswith('security.jail.jailed'):
                return (0, "0", "")
            else:
                return (1, "error", "")

        def fail_json(self, **args):
            pass

    obj = VirtualSysctlDetectionMixin()

    obj.module = MockModule()
    obj.warnings = []
    facts = obj.detect_virt_product('kern.vm_guest')
    # Check the values are correct
    assert facts['virtualization_type']

# Generated at 2022-06-23 02:44:31.707258
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Mixin():
        def __init__(self):
            self.module = ''
            self.sysctl_path = ''
        def get_bin_path(self, arg1):
            return arg1

    mixin = VirtualSysctlDetectionMixin()

    # First check when get_bin_path returns true
    class Module:
        @staticmethod
        def get_bin_path(arg1):
            if arg1 == 'sysctl':
                return '/sbin/sysctl'

        @staticmethod
        def run_command(arg1):
            pass

    mixin.detect_sysctl()
    mixin.module = Module()
    assert mixin.sysctl_path == '/sbin/sysctl'

    # Now check when get_bin_path returns None

# Generated at 2022-06-23 02:44:39.712941
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from units.compat.mock import MagicMock
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import BsdHardware
    module = MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.run_command.return_value = (0, '', '')
    bsd_fact = BsdHardware(module)
    bsd_detected = VirtualSysctlDetectionMixin()
    bsd_detected.detect_sysctl()
    assert bsd_detected.sysctl_path == '/sbin/sysctl'
