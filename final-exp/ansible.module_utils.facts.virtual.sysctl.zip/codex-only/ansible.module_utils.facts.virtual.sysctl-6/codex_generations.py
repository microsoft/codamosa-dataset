

# Generated at 2022-06-23 02:34:44.917805
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import BSDVirtualSysctlDetectionMixin
    module = type('module', (), {})()
    module.get_bin_path = lambda _: '/usr/bin/sysctl'
    module.run_command = lambda _: (0, 'QEMU', None)
    module.exit_json = lambda _: None
    mod = BSDVirtualSysctlDetectionMixin()
    mod.module = module
    mod.detect_virt_product('hw.model')
    assert mod.virtual_facts['virtualization_type'] == 'kvm'
    assert mod.virtual_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:34:56.234709
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    obj = VirtualSysctlDetectionMixin()

    # Testing a KVM host
    obj.module = MockModule()
    obj.module.run_command.return_value = (0, 'KVM', '')
    obj.module.get_bin_path.return_value = 'sysctl'

    actual_facts = obj.detect_virt_product('hw.model')
    assert actual_facts == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set([])}

    obj.module = MockModule()
    obj.module.run_command.return_value = (0, 'kvm', '')
    obj.module.get_bin_path.return_value = 'sysctl'



# Generated at 2022-06-23 02:35:03.745045
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Initialization
    virtual_vendor_facts = {}
    guest_tech = set()
    host_tech = set()

    # Testing when the vendor is QEMU
    virtual_vendor_facts['virtualization_type'] = 'kvm'
    virtual_vendor_facts['virtualization_role'] = 'guest'
    guest_tech.add('kvm')
    virtual_vendor_facts['virtualization_tech_guest'] = guest_tech
    virtual_vendor_facts['virtualization_tech_host'] = host_tech

    result = VirtualSysctlDetectionMixin.detect_virt_vendor("hw.model")

    # Assertion
    assert result == virtual_vendor_facts

# Generated at 2022-06-23 02:35:04.835112
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:35:07.898947
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule(argument_spec={})
    obj = VirtualSysctlDetectionMixin()
    key = 'vm.vmm.name'
    rc, out, err = obj.module.run_command("%s -n %s" % (obj.sysctl_path, key))
    assert rc == 0


# Generated at 2022-06-23 02:35:09.246955
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert(VirtualSysctlDetectionMixin())

# Generated at 2022-06-23 02:35:15.290360
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    test_VirtualSysctlDetectionMixin = TestVirtualSysctlDetectionMixin()
    test_VirtualSysctlDetectionMixin.detect_sysctl()
    assert test_VirtualSysctlDetectionMixin.sysctl_path is not None


# Generated at 2022-06-23 02:35:26.740936
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from collections import namedtuple
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    class BSDModule(object):
        def __init__(self, run_command):
            self._run_command = run_command
        def run_command(self, command):
            return self._run_command(command)
        def get_bin_path(self, command):
            return '/sbin/sysctl'
    command_results = {
        '/sbin/sysctl -n kern.vm_guest': (0, 'QEMU', ''),
        '/sbin/sysctl -n kern.vm_guest invalid': (1, '', 'invalid key: invalid'),
        '/sbin/sysctl -n hw.model': (0, 'OpenBSD', ''),
    }
   

# Generated at 2022-06-23 02:35:32.868075
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = type('module', (object,), {'run_command': lambda _args: [0, 'OpenBSD', '']})()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.detect_sysctl = lambda: None
    expected_out = {'virtualization_tech_guest': set(['vmm']), 'virtualization_role': 'guest',
                    'virtualization_tech_host': set([]), 'virtualization_type': 'vmm'}
    assert mixin.detect_virt_vendor('machdep.guest') == expected_out

# Generated at 2022-06-23 02:35:42.381662
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from modules.ansible.module_utils.facts.virtual.freebsd.vmm import VirtualSysctlDetectionMixin

    class FakeModule(object):
        def get_bin_path(self, prog):
            return '/bin/sysctl'

        def run_command(self, prog):
            return 0, '', ''

    class FakeObject(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = FakeModule()
            self.detect_sysctl()

    t = FakeObject()
    assert t.sysctl_path == '/bin/sysctl'


# Generated at 2022-06-23 02:35:51.732937
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class MockModule(object):
        def __init__(self):
            self.run_command_count = 0
            self.params = {'paths': dict(sysctl='/sbin/sysctl')}

        def get_bin_path(self, arg):
            return self.params['paths'][arg]

        def run_command(self, args):
            self.run_command_count += 1
            if self.run_command_count == 1:
                return (0, 'QEMU', '')
            if self.run_command_count == 2:
                return (0, 'OpenBSD', '')

        class ModuleExit(Exception):
            pass

    # Mock module object
    module = MockModule()

    # Init the class
    virtual_sysctl = VirtualSysctlDetectionMixin()

    # Detect

# Generated at 2022-06-23 02:36:02.207053
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda a, **kwargs: None
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: (0, 'OpenBSD', None)
            self.get_bin_path = lambda **kwargs: '/usr/bin/sysctl'

    class FakeModule2(object):
        def __init__(self):
            self.exit_json = lambda a, **kwargs: None
            self.fail_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: (0, 'QEMU', None)
            self.get_bin_path = lambda **kwargs: '/usr/bin/sysctl'


# Generated at 2022-06-23 02:36:05.299030
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            pass

    test = TestClass()
    assert test

# Generated at 2022-06-23 02:36:14.813812
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def run_command(self, command):
            if command == 'ctl -n machdep.cpu.vendor':
                return 0, 'QEMU', None
            elif command == 'ctl -n kern.hostuuid':
                return 0, '000c2957-01e8-ea1b-dc7d-003048d47b70', None
        def get_bin_path(self, command):
            return 'ctl'
    class FakeInsanity:
        pass
    class FakeDistro:
        def get_command_units():
            return ''
    insanity = FakeInsanity()
    insanity.module = FakeModule()
    insanity.distro = FakeDistro()
    virtual = VirtualSysctlDetectionMixin()
    virtual.module = FakeModule()
    virtual.insanity

# Generated at 2022-06-23 02:36:27.211916
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Fake:
        def __init__(self):
            self.module = FakeModule()

    class FakeModule:
        def __init__(self):
            self.run_command = FakeRunCommand()
            self.get_bin_path = FakeGetBinPath()

    class FakeRunCommand:
        def __init__(self):
            self.results = []
            self.results.append((0, 'kvm', ''))
            self.results.append((0, 'VMware', ''))
            self.results.append((0, 'VirtualBox', ''))
            self.results.append((0, 'Parallels', ''))
            self.results.append((0, 'HVM domU', ''))
            self.results.append((0, 'XenPVHVM', ''))

# Generated at 2022-06-23 02:36:36.895665
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class DummyModule(object):
        class DummyError(object): 
            pass
        def __init__(self):
            self.fail_json = self.DummyError("fail_json")
            self.exit_json = self.DummyError("exit_json")
            pass
        def get_bin_path(self, param):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            output = ''
            if cmd == '/sbin/sysctl -n hw.model':
                output = 'Intel(R) Xeon(TM) CPU          E5-2680  @ 2.70GHz'
            return (0, output, '')
    testobj = VirtualSysctlDetectionMixin()
    testobj.module = DummyModule()
    testobj.detect_sysctl()


# Generated at 2022-06-23 02:36:39.358370
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert virtual_sysctl_detection_mixin.sysctl_path is None


# Generated at 2022-06-23 02:36:46.772357
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = AnsibleModule
    module.type = 'shell'
    module.get_bin_path = lambda x : 'sysctl'
    module.run_command = lambda x : (0, 'QEMU', '')
    assert VirtualSysctlDetectionMixin().detect_virt_vendor('hw.model') == {
            'virtualization_type': 'kvm',
            'virtualization_role': 'guest',
            'virtualization_tech_host': set(),
            'virtualization_tech_guest': set(['kvm'])
    }


# Generated at 2022-06-23 02:36:57.892266
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    VirtualSysctlDetectionMixin.detect_sysctl = lambda x: None
    class MockMod(object):
        def get_bin_path(x, y):
            return '/bin/sysctl'
        def run_command(x, y):
            if y == '/bin/sysctl -n kern.vm_guest':
                return 0, 'kvm', None
            elif y == '/bin/sysctl -n security.jail.jailed':
                return 0, '1', None
            else:
                return 0, '', None

    class MockFac(object):
        def get_option(x, y):
            return None
    mod = MockMod()
    fac = MockFac()
    facter = VirtualSysctlDetectionMixin()
    facter.module = mod

# Generated at 2022-06-23 02:37:01.578367
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    myclass = VirtualSysctlDetectionMixin()
    assert myclass.sysctl_path is None
    assert myclass.detect_virt_product('hw.model') == {}
    assert myclass.detect_virt_vendor('hw.product') == {}

# Generated at 2022-06-23 02:37:03.095089
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin
    assert callable(VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:37:11.969094
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_detect_virt_product(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'
            self.module = FakeModule()
    c = VirtualSysctlDetectionMixin_detect_virt_product()
    result = c.detect_virt_product('hw.model')
    assert sorted(result.keys()) == sorted(['virtualization_role','virtualization_tech_guest','virtualization_tech_host','virtualization_type'])
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'virtualbox'
    assert sorted(result['virtualization_tech_guest']) == sorted(['virtualbox'])

# Generated at 2022-06-23 02:37:17.519316
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import ansible.module_utils.facts.system.virtual.detect_sysctl
    o = ansible.module_utils.facts.system.virtual.detect_sysctl
    o.sysctl_path = 'test'

    o.detect_sysctl()
    assert o.sysctl_path == 'test'


# Generated at 2022-06-23 02:37:28.482413
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestModule(object):
        def get_bin_path(self, prog):
            return '/usr/bin/sysctl'
        def run_command(self, cmd):
            return (0, 'OpenBSD', '')
    class TestClass(object):
        def __init__(self):
            self.module = TestModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl.im_func
    mixin.detect_virt_vendor = VirtualSysctlDetectionMixin.detect_virt_vendor.im_func
    testClass = TestClass()
    for var in mixin.__dict__:
        if var not in ['detect_sysctl', 'detect_virt_vendor']:
            set

# Generated at 2022-06-23 02:37:40.002961
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.collector import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector.openbsd import OpenBSDVirtualSysctlDetectionMixin

    class testModule:
        _module = None
        argv = None
        params = {}
        fail_json = None
        fail_json_msg = None
        command_results = []
        def get_bin_path(self, path, required=True):
            if path == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None
        def run_command(self, cmd, check_rc=True):
            if cmd == "/sbin/sysctl -n security.jail.jailed":
                return

# Generated at 2022-06-23 02:37:49.746159
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Prepare mock module
    module = type('', (), dict(run_command=lambda *args, **kwargs: (0, 'QEMU', '')))

    # Prepare mock class
    class MockSysctl(object):
        sysctl_path = 'mock_sysctl'

    # Perform test
    result = VirtualSysctlDetectionMixin().detect_virt_vendor('hw.model')

    # Assertion
    assert not 'virtualization_tech_host' in result
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:37:58.757052
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # mock out FreeBSDModule
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.base import BaseVirtualFacts

    class FakeFreeBSDModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_called_value = ''
            self.get_bin_path_called = False
            self.get_bin_path_called_value = ''

        def get_bin_path(self, parameter_content):
            self.get_bin_path_called = True
            self.get_bin_path_called_value = parameter_content
            return self.get_bin_path_called_value


# Generated at 2022-06-23 02:38:10.309394
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, arg, *args, **kwargs):
            return '/bin/sysctl'

        def run_command(self, cmd, *args, **kwargs):
            return self.rc, self.out, self.err

    class TestClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    tm = TestModule(0, '', '')
    tc = TestClass(tm)
    tc.detect_sysctl()
    assert 'sysctl_path' in tc
    assert tc.sysctl_path == '/bin/sysctl'

    t

# Generated at 2022-06-23 02:38:15.450032
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    testobj = VirtualSysctlDetectionMixin()
    testobj.module = FakeModule()
    testobj.module.get_bin_path = lambda x: '/sbin/sysctl'
    testobj.detect_sysctl()
    assert testobj.sysctl_path == '/sbin/sysctl'



# Generated at 2022-06-23 02:38:24.105677
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import sys
    import os
    import tempfile
    import stat

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg1, required=False):
            return arg1

        def run_command(self, cmd):
            output = cmd.split(' ')[1]
            if '/' in output:
                open(output, 'w').close()
                os.chmod(output, stat.S_IRUSR | stat.S_IWUSR | stat.S_IXUSR)
            return 0

    class FakeAnsibleModule(object):
        def __init__(self):
            self.tempdir = tempfile.mkdtemp()

# Generated at 2022-06-23 02:38:34.970478
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import BsdSystemFacts
    from ansible.module_utils.facts import ansible_facts

    # Test against VMware without a known virt type
    VMware = VirtualSysctlDetectionMixin()
    VMware.detect_sysctl = lambda: True
    VMware.module = BsdSystemFacts(dict(), ansible_facts, False)
    VMware.module.run_command = lambda x, y: (0, 'VMware', None)
    virtual_product_facts = dict(VMware.detect_virt_product('hw.model'))

    assert virtual_product_facts['virtualization_type'] == 'VMware'

# Generated at 2022-06-23 02:38:40.906097
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    class BSD(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    bsd = BSD()
    assert(bool(bsd.sysctl_path) == False)



# Generated at 2022-06-23 02:38:46.259227
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    class ModuleTest(object):
        def get_bin_path(self, argv):
            return argv

        def run_command(self, argv):
            return 0, 'QEMU', ''

    class MixinTest(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = ModuleTest()


    virtual_product = MixinTest()
    virtual_product.detect_virt_vendor('hw.model')
    assert virtual_product.virtualization_type == 'kvm'

# Generated at 2022-06-23 02:38:54.459522
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class TestVirtualSysctlDetectionMixin(object):
        def get_bin_path(self, arg):
            return ''

    test_class = TestVirtualSysctlDetectionMixin()
    test_class.sysctl_path = None
    virtual_sysctl_detection_mixin_instance = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin_instance.module = test_class
    virtual_sysctl_detection_mixin_instance.detect_sysctl()
    assert test_class.sysctl_path == ''



# Generated at 2022-06-23 02:39:05.358117
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    obj = VirtualSysctlDetectionMixin()
    obj.detect_sysctl = mock_detect_sysctl
    obj.module = mock_object
    obj.module.run_command = mock_run_command
    obj.module.get_bin_path = mock_get_bin_path
    # return when key is hp
    result = obj.detect_virt_product('hp')
    assert result == {'virtualization_tech_host': set(), 'virtualization_tech_guest': set()}
    # return when key is security.jail.jailed
    result = obj.detect_virt_product('security.jail.jailed')

# Generated at 2022-06-23 02:39:13.812588
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    """
    Method Unit Test: detect_virt_product
    """

    # Initialize the class
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.detect_sysctl = detect_sysctl_stub
    virtual_sysctl_detection_mixin.module = module_stub

    # Run the unit test
    virt_product_facts = virtual_sysctl_detection_mixin.detect_virt_product('machdep.hypervisor')
    assert virt_product_facts['virtualization_type'] == 'kvm'
    assert virt_product_facts['virtualization_role'] == 'guest'
    assert 'kvm' in virt_product_facts['virtualization_tech_guest']

# Generated at 2022-06-23 02:39:25.326994
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    if sys.version_info[0] == 2:
        import __builtin__ as builtins
    else:
        import builtins
    builtins.module = sys.modules[__name__]
    builtins.__file__ = __file__
    builtins.__name__ = __name__

    class MyModule():
        def __init__(self):
            pass

        def run_command(self, command):
            if command == "sysctl -n machdep.cpu.vendor":
                return 0, 'QEMU', None
            elif command == "sysctl -n machdep.cpu.brand_string":
                return 0, 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', None

# Generated at 2022-06-23 02:39:26.687605
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    o = VirtualSysctlDetectionMixin()
    assert isinstance(o, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:39:37.029019
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible_collections.community.general.tests.unit.compat import unittest
    from ansible_collections.community.general.plugins.modules.system import openbsd_virtual_vendor
    import ansible.module_utils.basic
    import ansible.module_utils.facts.virtual.openbsd_virtual as virt

    module = openbsd_virtual_vendor
    module.ANSIBLE_MODULE_ARGS = dict(gather_subset='!all,!any')

    module.run_command = lambda x: (0, 'QEMU', '')
    module.get_bin_path = lambda x: 'sysctl'


# Generated at 2022-06-23 02:39:38.268515
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    pass


# Generated at 2022-06-23 02:39:41.001735
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_product_facts = VirtualSysctlDetectionMixin()
    assert virtual_product_facts

# Generated at 2022-06-23 02:39:43.224716
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    facts = VirtualSysctlDetectionMixin()
    assert facts

# Generated at 2022-06-23 02:39:55.387392
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinMock(VirtualSysctlDetectionMixin):

        def detect_sysctl(self):
            self.sysctl_path = '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''

    virtualSysctlDetectionMixinMock = VirtualSysctlDetectionMixinMock()

    virtual_vendor_facts = virtualSysctlDetectionMixinMock.detect_virt_vendor('machdep.hypervisor_vendor')

    assert virtual_vendor_facts.get('virtualization_type') == 'kvm'
    assert virtual_vendor_facts.get('virtualization_role') == 'guest'
    assert 'kvm' in virtual_vendor_facts.get('virtualization_tech_guest')

# Generated at 2022-06-23 02:40:05.130082
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mock_module = MockModule()
    mock_get_bin_path = MockGetBinPath()
    mock_get_bin_path.set_result("mock_sysctl_path")
    mock_module.get_bin_path = mock_get_bin_path.get_bin_path
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = mock_module
    virtual_sysctl_detection_mixin.detect_sysctl()
    assert("mock_sysctl_path" == virtual_sysctl_detection_mixin.sysctl_path)
    assert(mock_get_bin_path.get_bin_path_called_count == 1)


# Generated at 2022-06-23 02:40:08.728893
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        pass
    test_class = TestClass()
    assert hasattr(test_class, 'detect_sysctl')
    assert hasattr(test_class, 'detect_virt_product')

# Generated at 2022-06-23 02:40:20.670919
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule:
        def run_command(self, command, check_rc=True):
            return 0, 'KVM', ''

        def get_bin_path(self, binary):
            return binary

    class FakeFacts:
        def __init__(self):
            self.product_facts = {}

    module = FakeModule()
    facter = FakeFacts()
    facts = VirtualSysctlDetectionMixin()
    facts.detect_virt_product('hw.model')
    facts.detect_virt_product('machdep.hypervisor')
    facts.detect_virt_product('kern.hostuuid')
    facts.detect_virt_product('machdep.dmi.system-uuid')
    facts.detect_virt_product('hw.model')
    facts.detect_virt

# Generated at 2022-06-23 02:40:32.127249
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    sys.path.append('/')
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    import ansible.module_utils.facts.system.bsd

    current_instance = ansible.module_utils.facts.system.bsd.BSDHardware()
    current_instance.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl.__get__(current_instance)

    # We need to temporarily reinitialize the 'ansible' module, as it has global
    # state which can't be cleanly reset.

# Generated at 2022-06-23 02:40:41.011010
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import ansible.constants

    class FakeModule(object):
        def get_bin_path(self, path):
            return '/usr/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'VirtualBox', None

    class Fake(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    ansible.constants.ANSIBLE_LIBRARY = '/path/to/ansible/library'
    fake = Fake(FakeModule())
    facts = fake.detect_virt_product('hw.model')
    assert facts['virtualization_type'] == 'virtualbox'
    assert facts['virtualization_role'] == 'guest'
    assert 'virtualbox' in facts['virtualization_tech_guest']

    facts = fake.detect

# Generated at 2022-06-23 02:40:51.815134
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Unit tests need sysctl.py
    import sysctl

    sysctl_detection = sysctl.Sysctl()
    if sysctl_detection.detect_sysctl():
        # Prepare the parameters
        sysctl_params = {}
        sysctl_params['sysctl_path'] = sysctl_detection.sysctl_path
        sysctl_params['module'] = sysctl_detection.module
        sysctl_params['kernel'] = sysctl_detection.kernel

        # Build the an instance of class VirtualSysctlDetectionMixin
        detection_mixin = VirtualSysctlDetectionMixin()

        # Inject the parameters into the detection_mixin
        detection_mixin.sysctl_path = sysctl_params['sysctl_path']
        detection_mixin.module = sysctl_params['module']
        detection

# Generated at 2022-06-23 02:40:59.328970
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MockModule(object):
        def get_bin_path(self, exe):
            return "/usr/bin/testbin"

    virtual_product_facts = VirtualSysctlDetectionMixin()
    virtual_product_facts.module = MockModule()
    virtual_product_facts.detect_sysctl()
    assert virtual_product_facts.sysctl_path == "/usr/bin/testbin"


# Generated at 2022-06-23 02:41:03.528499
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    instance = VirtualSysctlDetectionMixin()
    instance.sysctl_path = False
    instance.module = {
        'get_bin_path': lambda x: '/usr/sbin/sysctl'
    }
    instance.detect_sysctl()
    assert instance.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-23 02:41:10.817117
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestClass(object):
        def __init__(self):
            self.get_bin_path_results = {}
            self.module = self
            self.virtualization_facts = {'virtualization_type': ''}

        def get_bin_path(self, key):
            return self.get_bin_path_results[key]

        def run_command(self, command):
            return (0, '', '')

    # Test 1
    test_class_instance = TestClass()
    test_class_instance.get_bin_path_results = {'sysctl': 'sysctl'}
    test_class_instance.virtualization_facts = {'virtualization_type': ''}
    virtual_sysctl_detection_mixin_instance = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection

# Generated at 2022-06-23 02:41:21.048054
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Set up class to be tested and variables used by the unit test
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class Module():
        def __init__(self):
            self.params = {'filter': 'virtual'}

        def get_bin_path(self, executable, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            out = ''
            err = ''
            if cmd == '/sbin/sysctl -n security.jail.jailed':
                out = '1'
                rc = 0
            elif cmd == '/sbin/sysctl -n security.jail.jailed':
                out = '0'
                rc = 0

# Generated at 2022-06-23 02:41:28.173245
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import OpenBSDGuest

    test_class = OpenBSDGuest()
    updated_attributes = {'sysctl_path': '/sbin/sysctl'}
    test_class.__dict__.update(updated_attributes)

    expected_result = {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    result = test_class.detect_virt_product('hw.model')
    assert result == expected_result



# Generated at 2022-06-23 02:41:33.569470
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda x: x
        def get_bin_path(self, path):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if re.match('/sbin/sysctl -n kern.emul.*', cmd):
                return 0, 'QEMU\n', ''
            elif re.match('/sbin/sysctl -n kern.vm_guest.*', cmd):
                return 0, 'OpenBSD', ''
            else:
                return 1, '', ''

    class FakeVirtDetect(object):
        def __init__(self, module):
            self.sysctl_path = None
            self.module = module

    module = FakeModule()
    detect = FakeV

# Generated at 2022-06-23 02:41:40.994254
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Without real sysctl we cannot run this test
    from ansible.module_utils.basic import AnsibleModule
    import os

    m = AnsibleModule(
        argument_spec={},
    )

    # Prepare class instance
    v = VirtualSysctlDetectionMixin()
    v.module = m
    v.sysctl_path = os.path.realpath('/sbin/sysctl')

    # Check sysctl path
    v.detect_sysctl()
    assert v.sysctl_path == os.path.realpath('/sbin/sysctl'), 'sysctl path not detected'


# Generated at 2022-06-23 02:41:52.354686
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sysctl
    class FakeModule(object):
        def __init__(self):
            self._facts = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            key = re.sub('/sbin/sysctl -n ', '', cmd)
            return 0, sysctl.sysctl[key], ''

        def set_fact(self, key, value):
            self._facts[key] = value

        def exit_json(self, ansible_facts):
            self._facts.update(ansible_facts)

    module = FakeModule()
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl()
    v.detect_virt_product('hw.model')
    v.detect_virt

# Generated at 2022-06-23 02:41:54.480276
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()

    assert isinstance(mixin, object)


# Generated at 2022-06-23 02:41:58.961732
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MockModule(object):
        def __init__(self, params):
            self.params = params
        def get_bin_path(self, bin_path):
            return True

    # no params
    params = {}
    obj = VirtualSysctlDetectionMixin()
    obj.module = MockModule(params)
    obj.detect_sysctl()

    assert obj.sysctl_path is not None



# Generated at 2022-06-23 02:42:10.569609
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestModule(object):
        pass

    class TestSystem(object):
        pass

    test_module = TestModule()
    test_module.run_command = lambda cmd: [0, "HVM domU", ""]
    test_module.get_bin_path = lambda x: "/usr/bin/sysctl"
    test_system = TestSystem()
    test_system.detect_sysctl = lambda: True

    facts = VirtualSysctlDetectionMixin()
    facts.module = test_module
    facts.system = test_system
    facts.facts = dict()

    ansible_virtualization_facts = facts.detect_virt_product("dummy")
    assert ansible_virtualization_facts['virtualization_type'] == 'xen'

# Generated at 2022-06-23 02:42:21.324384
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_stdout = 'QEMU'
            self.run_command_stderr = ''

        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, command, check_rc=True):
            self.run_command_called = True
            return self.run_command_rc, self.run_command_stdout, self.run_command_stderr

    module = FakeModule()
    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = module
            self.virtual_vendor_facts

# Generated at 2022-06-23 02:42:31.222843
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Object(object):
        pass

    facts = Object()
    facts.module = Object()
    facts.module.get_bin_path = lambda x: '/sbin/sysctl'
    facts.module.run_command = lambda x: (0, 'KVM', '')
    vd = VirtualSysctlDetectionMixin()
    vd.detect_virt_product('hw.model')
    assert vd.virtual_product_facts['virtualization_type'] == 'kvm'
    assert vd.virtual_product_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:42:39.055084
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = AnsibleModule(supports_check_mode=True)
    for t in [('hv_vendor_info', 'Hyper-V'), ('hypervisor_vendor', 'Hyper-V'), ('security.jail.jailed', '1')]:
        sysctl = VirtualSysctlDetectionMixin()
        sysctl.module = module
        virtual_product_facts = sysctl.detect_virt_product(t[0])
        assert virtual_product_facts['virtualization_type'] == t[1]
        assert virtual_product_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:42:49.073749
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Test():
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'
            self.virtualization_type = 'xen'
            self.virtualization_role = 'guest'

        def get_bin_path(self, arg):
            return self.sysctl_path

        def run_command(self, arg):
            if arg == '/sbin/sysctl -n kern.hostuuid':
                return 0, 'VirtualBox', ''
            if arg == '/sbin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            return -1, '', ''

    module = Test()
    virtual_facts = VirtualSysctlDetectionMixin()
    virtual_facts.detect_sysctl()
    assert virtual_facts.detect_

# Generated at 2022-06-23 02:42:50.574773
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v

# Generated at 2022-06-23 02:42:57.816251
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule():
        def __init__(self):
            self.params = {}
            self.args = {}
            self.other_args = {}
        def get_bin_path(self,name):
            return '/sbin/' + name
    class TestClass():
        def __init__(self):
            self.sysctl_path = None
            self.module = TestModule()
    data = TestClass()
    VirtualSysctlDetectionMixin.detect_sysctl(data)
    assert '/sbin/sysctl' == data.sysctl_path


# Generated at 2022-06-23 02:43:03.411296
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    v = VirtualSysctlDetectionMixin()
    v.module = FakeAnsibleModule()
    v.detect_sysctl()
    assert v.sysctl_path == '/bin/sysctl'


# Unit tests for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:43:11.125579
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            pass

        @staticmethod
        def get_bin_path(binary):
            return binary

        @staticmethod
        def run_command(binary):
            if binary == 'sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version 1.1.2', None
            if binary == 'sysctl -n security.jail.jailed':
                return 0, '1', None

        def set_module_args(self, module_name):
            pass

    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = None

    fact_collector = FakeSysctlDetectionMixin()
    facts = {}

# Generated at 2022-06-23 02:43:19.762297
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTester(object):
        def __init__(self, module):
            self.module = module
            self.module.exit_json = lambda **kwargs: None

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

    class FakeModule(object):
        def __init__(self):
            self.exit_json = lambda **kwargs: None
            self.run_command = lambda **kwargs: [0, '', '']
            self.get_bin_path = lambda **kwargs: '/usr/sbin/sysctl'

    module = FakeModule()
    mixin = VirtualSysctlDetectionMixinTester(module)
    mixin.detect_virt_product('kern.vm_guest')

# Generated at 2022-06-23 02:43:28.135094
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    from ansible_collections.ansible.community.plugins.module_utils.facts.system.virt.freebsd_sysctl import VirtualSysctlDetectionMixin

    class FakeModule(object):
        @staticmethod
        def get_bin_path(name, opts=None, required=False):
            return "/usr/bin/sysctl"

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    det = FakeVirtualSysctlDetectionMixin()
    det.detect_sysctl()

    assert det.sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-23 02:43:38.326098
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    obj = VirtualSysctlDetectionMixin()
    obj.module = FakeModule()
    obj.sysctl_path = True
    result = obj.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result
    obj.sysctl_path = False
    result = obj.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'guest'
    assert result['virtualization_role'] == 'guest'
    assert 'virtualization_tech_host' in result
    assert 'virtualization_tech_guest' in result


# Generated at 2022-06-23 02:43:48.357662
# Unit test for constructor of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:43:57.019109
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # input arguments used for instantiating the test object
    args = dict(
        paths=dict(
            command='/usr/bin/sysctl -n hw.product',
            rc=0,
            out='OpenBSD',
            err='',
        ),
    )
    testobj = VirtualSysctlDetectionMixin()
    # setting module arguments and state
    setattr(testobj.module, 'run_command', mock_run_command)
    testobj.module.run_command.side_effect = lambda x: args['paths'][x]

    # execute the method under test
    virtual_vendor_facts = testobj.detect_virt_vendor('hw.product')

    # validate that method run_command is invoked with the appropriate arguments

# Generated at 2022-06-23 02:44:07.774411
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils._text import to_bytes

    # This dict simulates the module object
    mixinsysctl_mock = {
        'get_bin_path': lambda _: '/sbin/sysctl',
        'run_command': lambda _: (0, to_bytes('OpenBSD'), '')
    }
    sysctl_mixin = VirtualSysctlDetectionMixin()
    sysctl_mixin.module = mixinsysctl_mock
    result = sysctl_mixin.detect_virt_vendor('hw.model')

    assert result['virtualization_type'] == 'vmm'
    assert result['virtualization_role'] == 'guest'
    assert 'kvm' not in result

# Generated at 2022-06-23 02:44:10.481071
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert isinstance(virtual_sysctl_detection_mixin, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:44:14.594850
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """Test constructor of VirtualSysctlDetectionMixin class"""
    test_module = VirtualSysctlDetectionMixin()
    assert isinstance(test_module, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:44:24.250814
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    """
    Test for detect_virt_vendor of class VirtualSysctlDetectionMixin
    """
    obj = VirtualSysctlDetectionMixin()

    obj.sysctl_path = '/sbin/sysctl'
    obj.module = 'obj'
    obj.module.run_command = Mock()
    obj.module.run_command.return_value = (0, 'QEMU', '')

    assert obj.detect_virt_vendor('kern.vm_guest') == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_host': set([]),
        'virtualization_tech_guest': set(['kvm'])
    }


# Generated at 2022-06-23 02:44:34.289740
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class Opts(object):
        module = None
        sysctl_path = None
    class Module(object):
        def get_bin_path(self, path):
            return None
        def run_command(self, command):
            if command == 'sysctl -n kern.vm_guest':
                return 0, 'OpenBSD', 'Test err'
            if command == 'sysctl -n hw.model':
                return 0, 'QEMU', 'Test err'
            return (1, '', '')
    class SysctlFacts(VirtualSysctlDetectionMixin, Opts):
        def __init__(self):
            self.module = Module()
    sysctl_facts = SysctlFacts()

# Generated at 2022-06-23 02:44:34.888710
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    pass

# Generated at 2022-06-23 02:44:43.450812
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class VirtualSysctlDetectionMixinInstance(VirtualSysctlDetectionMixin):

        def __init__(self, module):
            self.module = module

    class AnsibleModuleMock():

        def get_bin_path(self, command):
            return "/path/to/sysctl"

        def run_command(self, command):
            return 0, "Hypervisor: QEMU", ""

        def exit_json(self, meta=None, changed=False, msg=None):
            pass

        def fail_json(self, meta=None, msg=None):
            pass

    module = AnsibleModuleMock()
    mixin = VirtualSysctlDetectionMixinInstance(module)
    mixin.detect_sysctl()

    assert mixin.sysctl_path == "/path/to/sysctl"


# Unit