

# Generated at 2022-06-23 02:34:46.081528
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin

    class FakeModuleClass(object):
        def __init__(self):
            self.path = []
            self.path.append('./')

        def get_bin_path(self, name):
            return '/bin/'+name

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    f = FakeClass(FakeModuleClass())
    f.detect_sysctl()
    assert(f.sysctl_path == '/bin/sysctl')


# Generated at 2022-06-23 02:34:56.252221
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    test_case_name = "test_VirtualSysctlDetectionMixin_detect_sysctl"
    print("\nTest case: %s" % test_case_name)

    # Create a stub object of class VirtualSysctlDetectionMixin
    class StubVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    # Create a stub object of module
    class StubModule:
        def __init__(self):
            pass

        def get_bin_path(self, bin):
            return bin

    # Create a stub AnsibleModule object
    module = StubModule()
    # Create a stub VirtualSysctlDetectionMixin object
    vmixin = StubVirtualSysctlDetectionMixin(module)

    # Set up sysctl_path


# Generated at 2022-06-23 02:34:57.630058
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    f = VirtualSysctlDetectionMixin()
    assert f is not None

# Generated at 2022-06-23 02:35:08.951561
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # test when host is a FreeBSD jail
    jail_host = {"sysctl_path": "/sbin/sysctl", "rc": 0, "out": "1", "err": ""}
    jail_virtual_product_facts = VirtualSysctlDetectionMixin()
    jail_virtual_product_facts.module = MockModule(jail_host)
    jail_virtual_product_facts.detect_sysctl()
    jail_result = jail_virtual_product_facts.detect_virt_product('security.jail.jailed')
    assert jail_result['virtualization_type'] == 'jails'
    assert jail_result['virtualization_role'] == 'guest'
    assert jail_result['virtualization_tech_guest'] == set(['jails'])

# Generated at 2022-06-23 02:35:20.080809
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Create a class that inherits from VirtualSysctlDetectionMixin and where we
    # will override some methods
    class MyClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
            self.sysctl_path = None
        def detect_sysctl(self):
            self.sysctl_path = "/sbin/sysctl"
        def run_command(self, cmd):
            if cmd == "/sbin/sysctl -n hw.model":
                return 0, "", ""
            elif cmd == "/sbin/sysctl -n security.jail.jailed":
                return 0, "1", ""
            else:
                return -1, "", ""
    # Instantiation of the class to test
    myclass = MyClass()
    # We call the method we

# Generated at 2022-06-23 02:35:29.395869
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Mod():
        def get_bin_path(self, name):
            return '/bin/sysctl'
        def run_command(self, cmd):
            return (0, '', '')
    class VSDM(VirtualSysctlDetectionMixin):
        module = Mod()

    print(VSDM().detect_virt_product('hw.product'))
    assert(VSDM().detect_virt_product('hw.product') ==
           {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()})

# Generated at 2022-06-23 02:35:37.872585
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name, opt_dirs=[]):
            self.get_bin_path_calls.append((name, opt_dirs))
            return '/bin/sysctl'

        def run_command(self, cmd, check_rc=True):
            self.run_command_calls.append((cmd, check_rc))
            if cmd == '/bin/sysctl -n security.jail.jailed':
                return (0, '1', None)
            elif cmd == '/bin/sysctl -n hw.product':
                return (0, 'VirtualBox', None)


# Generated at 2022-06-23 02:35:49.825962
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd.detect_virtualization import VirtualSysctlDetectionMixin
    import re
    class FakeModule(object):
        def __init__(self):
            self.virtual_facts = {}
        def get_bin_path(self, path):
            return '/sbin/sysctl'
        def run_command(self, command):
            if re.match('.*hw\.model.*', command):
                return 0, 'QEMU Virtual CPU version (cpu64-rhel6)', ''
            if re.match('.*security\.jail\.jailed.*', command):
                return 0, '1', ''

# Generated at 2022-06-23 02:35:56.039944
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    virtualization_platform = VirtualSysctlDetectionMixin()
    test_key = 'hw.model'
    result_dict = virtualization_platform.detect_virt_vendor(test_key)
    assert result_dict['virtualization_type'] == 'vmm'
    assert result_dict['virtualization_role'] == 'guest'
    assert sorted(list(result_dict['virtualization_tech_guest'])) == ['vmm']
    assert sorted(list(result_dict['virtualization_tech_host'])) == []


# Generated at 2022-06-23 02:36:08.091730
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:36:09.315314
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    v = VirtualSysctlDetectionMixin()
    assert v

# Generated at 2022-06-23 02:36:12.599897
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class obj(object):
        def __init__(self):
            self.sysctl_path = None

    vm = obj()
    vm.module = MockModule()
    vm.detect_sysctl()
    return vm.sysctl_path


# Generated at 2022-06-23 02:36:26.364504
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class VirtualSysctlDetectionMixinStub:
        pass
    class ModuleStub:
        def __init__(self):
            self.params = {}
            self.exit_json = lambda self, **kwargs: None

            self.run_command = lambda self, **kwargs: (0, '', '')
            self.get_bin_path = lambda self, **kwargs: '/sbin/sysctl'
    module = ModuleStub()
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixinStub()
    virtual_sysctl_detection_mixin.module = module
    virtual_sysctl_detection_mixin.detect_sysctl()
    assert virtual_sysctl_detection_mixin.sysctl_path == module.get_bin_path('sysctl')

#

# Generated at 2022-06-23 02:36:36.169241
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    facts = {}
    vm = VirtualSysctlDetectionMixin()
    vm.detect_sysctl()
    assert vm.sysctl_path is not None
    virtual_product_facts = vm.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    virtual_product_facts = vm.detect_virt_product('security.jail.jailed')
    assert virtual_product_facts['virtualization_role'] == 'guest'
    assert virtual_product_facts['virtualization_type'] == 'jails'
    virtual_vendor_facts = vm.detect_virt_vendor('machdep.hypervisor_vendor')

# Generated at 2022-06-23 02:36:43.735746
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestFacts:
        def __init__(self, module=None):
            self.module = module

    class TestModule:
        def __init__(self, params=None):
            self.params = params

        def get_bin_path(self, path):
            return 'sysctl'

        def run_command(self, cmd):
            return 0, 'VirtualBox', None

    test_module = TestModule()
    test_facts = TestFacts(test_module)
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.detect_virt_product('hw.model')
    assert test_facts.sysctl_path == 'sysctl'

# Generated at 2022-06-23 02:36:47.729748
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    openbsd_facts = VirtualSysctlDetectionMixin()
    openbsd_facts.sysctl_path = '/sbin/sysctl'
    results = openbsd_facts.detect_virt_product('hw.model')
    # TODO: test more edge cases?
    assert results['virtualization_type'] == 'xen'
    assert results['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:36:48.848531
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:36:59.274736
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    '''
    This method is to test virtual vendor detection through sysctl command
    '''
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))))
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin
    def run_command(self, command):
        print(command)
        if self.sysctl_path:
            return (0, 'QEMU', '')
        else:
            return (1, '', 'sysctl path not found')

    VirtualSysctlDetectionMixin.run_command = run_command
    VirtualSysctlDetectionMixin.detect_

# Generated at 2022-06-23 02:37:08.879000
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    '''Test the detect_virt_product method of class VirtualSysctlDetectionMixin
    '''

    class FakeModule(object):
        '''Class to fake a module
        '''

        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_calls = []
            self.fail_json_results = []
            self.fail_json_calls = []
            self.warn_results = []
            self.warn_calls = []

        def run_command(self, command):
            self.run_command_calls.append(command)
            return self.run_command_results.pop(0)


# Generated at 2022-06-23 02:37:15.943822
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # create a dummy class
    class MyfauxModule(object):
        sysctl_path = None

        # mock the get_bin_path function to return sysctl_path
        def get_bin_path(self, cmd):
            return self.sysctl_path

        # mock the run_command function to return rc, out, err
        def run_command(self, args):
            if self.sysctl_path is None:
                return 1, '', 'Error: command not found'
            else:
                return 0, self.sysctl_out, ''

    # create a MyfauxModule object
    m = MyfauxModule()

    # create a VirtualSysctlDetectionMixin object
    v = VirtualSysctlDetectionMixin()
    v.module = m

    # test the path doesn't exist
    m.sysctl

# Generated at 2022-06-23 02:37:22.185297
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    detected_facts = {}
    detected_facts.update({'virtualization_type': 'VMware', 'virtualization_role': 'guest'})
    detected_facts.update({'virtualization_tech_guest': set(['VMware']), 'virtualization_tech_host': set([])})
    assert VirtualSysctlDetectionMixin().detect_virt_product('hw.model') == detected_facts


# Generated at 2022-06-23 02:37:29.933109
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    # Mock module
    class MockModule():
        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

    class MockOs():
        class Platform():
            return ""

    class MockAnsibleModule():
        _module = None
        _result = None
        def __init__(self):
            self._module = MockModule()
            self._result = {
                'changed': False,
                'failed': False,
                'ansible_facts': {},
            }
        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'
        def run_command(self, cmd, ignore_rc=False, data=None, binary_data=False):
            return 0, '', ''

# Generated at 2022-06-23 02:37:37.896484
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.collector.openbsd import OpenBSDVirtualizationCollector
    fact_collector = FactCollector(None)
    openbsd_virtualization = OpenBSDVirtualizationCollector(
        fact_collector,
        fact_collector.collect(),
        fact_collector
    )

    openbsd_virtualization.detect_sysctl()
    assert openbsd_virtualization.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:37:48.870406
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Create a mock class that uses the above method
    class MockModule:
        def __init__(self):
            # By default, return a hypervisor
            self.run_command_rc = 0
            self.run_command_out = 'QEMU'
        def get_bin_path(self, *args):
            return 'sysctl'
        def run_command(self, *args):
            return (self.run_command_rc, self.run_command_out, '')

    class MockSystem:
        def __init__(self):
            pass

    system = MockSystem()
    module = MockModule()

    # Create an object of the class
    virt_product_obj = VirtualSysctlDetectionMixin()

    # Try with the hypervisor command
    system_facts = virt_product_obj.detect_virt

# Generated at 2022-06-23 02:37:51.070937
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    instance = VirtualSysctlDetectionMixin()
    assert isinstance(instance, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:37:59.379904
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    '''Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin'''

    class VirtualSysctlDetectionMixinObject(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class FakeModule(object):
        def get_bin_path(self, sysctl):
            return sysctl if sysctl == 'sysctl' else None

        def run_command(self, cmd):
            return -1, '', ''

    module = FakeModule()
    virtual_sysctl_detection_mixin_object = VirtualSysctlDetectionMixinObject(module)
    assert virtual_sysctl_detection_mixin_object.detect_sysctl() is None


# Generated at 2022-06-23 02:38:03.764633
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class A(VirtualSysctlDetectionMixin):
        pass

    a = A()
    a.module = MockModule()
    a.detect_sysctl()
    assert a.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-23 02:38:15.775795
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils import basic

    class FakeModule(object):
        def get_bin_path(self, arg):
            return "/sbin/sysctl"

        def run_command(self, cmd):
            return (0, "KVM", "")

    class FakeOS(object):
        distribution = None
        distribution_version = None

    vm = VirtualSysctlDetectionMixin()
    vm.module = FakeModule()
    vm.distribution = FakeOS()

    facts = vm.detect_virt_product("hw.model")
    assert facts == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': set(['kvm']),
        'virtualization_tech_host': set([])
    }

#

# Generated at 2022-06-23 02:38:21.532300
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = FakeModule()
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = None
    obj.module = module
    obj.detect_sysctl()
    assert obj.sysctl_path == '/bin/sysctl'



# Generated at 2022-06-23 02:38:30.498047
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def get_bin_path(self, arg):
            return 'path/to/sysctl'

        def run_command(self, cmd):
            return (0, 'OpenBSD', '')

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = MockModule()
    result = mixin.detect_virt_vendor('machdep.svm_guest')
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_type'] == 'vmm'
    assert 'vmm' in result['virtualization_tech_guest']

# Generated at 2022-06-23 02:38:40.722650
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule:
        def __init__(self):
            pass

        def get_bin_path(self, app):
            return app

        def run_command(self, args):
            if "kvm" in args:
                return 0, "KVM", ""
            if "jail" in args:
                return 0, "1", ""
            if "vendor" in args:
                return 0, "OpenBSD", ""
            return 0, "", ""

    class FakeFacts():
        def __init__(self):
            self.virtual_facts = { 'virtualization_role': "guest",
                                   'virtualization_type': "unknown" }
            self.virtual = "unknown"
            self.virtual_guest = "unknown"
            self.virtual_host = "unknown"
            self.virtual_tech

# Generated at 2022-06-23 02:38:41.939031
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vdm = VirtualSysctlDetectionMixin()
    assert vdm != None

# Generated at 2022-06-23 02:38:49.175322
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    first_class = VirtualSysctlDetectionMixin()
    first_class.detect_sysctl()
    virtual_facts = first_class.detect_virt_product('hw.model')
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_facts['virtualization_tech_host'] == set()
    virtual_facts = first_class.detect_virt_vendor('hw.model')
    assert virtual_facts['virtualization_type'] == 'kvm'
    assert virtual_facts['virtualization_role'] == 'guest'
    assert virtual_facts['virtualization_tech_guest'] == set(['kvm'])

# Generated at 2022-06-23 02:38:54.147188
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    f = VirtualSysctlDetectionMixin()
    assert hasattr(f, 'detect_sysctl')
    assert hasattr(f, 'detect_virt_product')
    assert hasattr(f, 'detect_virt_vendor')

# Generated at 2022-06-23 02:39:05.069044
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleStub():
        class run_command():
            returncode = 0
            stdout = "QEMU"
            stderr = ""
        def get_bin_path(bin_name):
            return '/usr/bin/sysctl'
    class SystemFreeBSD():
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    class FreeBSDVirtSubclass(SystemFreeBSD, VirtualSysctlDetectionMixin):
        pass

    fbsd_inst = FreeBSDVirtSubclass(ModuleStub())

    result = fbsd_inst.detect_virt_vendor('security.jail.jailed')
    if result['virtualization_tech_guest'].pop() != 'vmm':
        raise AssertionError

# Generated at 2022-06-23 02:39:13.564991
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
        def fail_json(self, *args, **kwargs):
            raise RuntimeError()
        def get_bin_path(self, *args, **kwargs):
            return 'sysctl'
        def run_command(self, *args, **kwargs):
            return (0, 'sysctl_out', 'sysctl_err')

    am = AnsibleModuleMock()
    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = am

    vsdm.detect_sysctl()
    # Test detect_virt_product
    virtual_product_facts = vsdm.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:39:19.191822
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    '''Test method detect_sysctl'''
    myclass = VirtualSysctlDetectionMixin()
    myclass.module = FakeModule()
    myclass.detect_sysctl()
    assert myclass.sysctl_path == "/bin/sysctl"


# Generated at 2022-06-23 02:39:24.840162
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class MockModule:
        def get_bin_path(self, name):
            return name

    class MockClass(VirtualSysctlDetectionMixin):
        def __init__(self, m):
            self.module = m

    mc = MockClass(MockModule())
    mc.detect_sysctl()
    assert mc.sysctl_path == "sysctl"



# Generated at 2022-06-23 02:39:33.875273
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.freebsd import VirtualFacts
    from ansible.module_utils.facts.virtual.freebsd.get_virtual_facts.utils import VirtualSysctlDetectionMixin
    module = AnsibleModule(argument_spec={})
    virtual_facts_instance = VirtualFacts(module)
    result = VirtualSysctlDetectionMixin().detect_virt_product("security.jail.jailed")
    assert result == {'virtualization_type': 'jails', 'virtualization_role': 'guest'}


# Generated at 2022-06-23 02:39:42.988081
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual import VirtualCollector

    class BSDModule(AnsibleModule):
        def run_command(self, cmd):
            class RC(object):
                stdout = 'KVM'
                stderr = ''
                rc = 0
            return RC(), '', ''

    class FakeVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = '/bin/sysctl'

    am = BSDModule(dict(ANSIBLE_MODULE_ARGS='foo'))
    FakeVirtualSysctlDetectionMixin().populate(am)
    out = am.ansible_facts['virtualization_facts']


# Generated at 2022-06-23 02:39:55.289343
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Mock detect_virt_vendor
    virtual_vendor_facts = {'virtualization_type': None, 'virtualization_role': None, 'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}
    key = 'kern.vm_guest'
    module = MockModule(dict(sysctl_path='', command_result=(0, 'QEMU', '')))
    identifier = VirtualSysctlDetectionMixin()
    identifier.module = module
    virtual_vendor_facts = identifier.detect_virt_vendor(key)
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'

# Generated at 2022-06-23 02:39:58.953985
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    try:
        VirtualSysctlDetectionMixin()
    except NameError:
        print ("FAILED: to create class VirtualSysctlDetectionMixin")


# Generated at 2022-06-23 02:40:07.106033
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, string_to_test):
            self.sysctl_path = '/sbin/sysctl'
            self.module = TestModule(string_to_test)

        def detect_sysctl(self):
            pass

    class TestModule(object):
        def __init__(self, string_to_test):
            self.string_to_test = string_to_test

        def get_bin_path(self, cmd, required = False):
            return self.sysctl_path

        def run_command(self, cmd, check_rc=True):
            return (0, self.string_to_test, '')

    # Test data
    # (input, expected_result)

# Generated at 2022-06-23 02:40:17.244119
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    class TestModule(object):
        def get_bin_path(self, path):
            return '/usr/local/bin/sysctl'

        def run_command(self, command):
            rc = 1
            out = 'KVM dom0'
            err = ''
            return rc, out, err

    class TestObject(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = TestModule()
            self.sysctl_path = None

    x = TestObject()
    x.detect_sysctl()

    assert x.sysctl_path == '/usr/local/bin/sysctl'


# Generated at 2022-06-23 02:40:25.308394
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    klass = type('VirtualSysctlDetectionMixin', (object,), {})
    # We don't want this to run, as it raises an exception
    klass.detect_sysctl = lambda x: None

    kvm_guest = type('VirtualSysctlDetectionMixin', (klass,), {'sysctl_path': '/sbin/sysctl', 'module': type('Module', (object,), {'run_command': lambda x: ('', 'KVM', '')})})
    assert kvm_guest().detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_tech_guest': set(['kvm']), 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:40:32.986814
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(object):
        pass

    testclass = TestClass()
    testclass.sysctl_path = None
    testclass.module = None
    testclass.run_command = None

    p = VirtualSysctlDetectionMixin()

    p.detect_sysctl()

    # Now if we see sysctl_path is set, then all is good.
    assert(testclass.sysctl_path is not None)

    p.detect_virt_product('kern.vm_guest')

    assert(testclass.sysctl_path is not None)

    p.detect_virt_vendor('kern.vm_guest')

    assert(testclass.sysctl_path is not None)

# Generated at 2022-06-23 02:40:35.288624
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert isinstance(virtual_sysctl_detection_mixin, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:40:43.638124
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    VSDM = VirtualSysctlDetectionMixin()
    test_vendor = {'virtualization_type': 'kvm', 'virtualization_role': 'guest', 'virtualization_thick_hypervisor': True}
    test_vendor['virtualization_tech_guest'] = set(['kvm'])
    test_vendor['virtualization_tech_host'] = set()
    assert test_vendor == VSDM.detect_virt_vendor('hw.model')


# Generated at 2022-06-23 02:40:50.934415
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    import json
    import mock
    sys.modules['_ansible_module_generated_by_ansible_v2_0_0'] = mock.MagicMock(
        AnsibleModule=mock.MagicMock(
            argument_spec=dict(),
            params=dict(),
            check_mode=True,
            debug=True,
        )
    )

    class TestModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = sys.modules['_ansible_module_generated_by_ansible_v2_0_0']

    tm = TestModule()
    tm.detect_sysctl = mock.MagicMock(return_value=None)
    result = tm.detect_virt_vendor('security.jail.jailed')


# Generated at 2022-06-23 02:41:00.633629
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule:
        class TestParams:
            pass
        params = TestParams

        class TestRun():
            class Result():
                def __init__(self, rc, stdout, stderr):
                    self.rc = rc
                    self.stdout = stdout
                    self.stderr = stderr

            def __init__(self, rc, stdout, stderr):
                self.result = [TestModule.TestRun.Result(rc, stdout, stderr)]

        def get_bin_path(self, command, required=False, opt_dirs=[]):
            return command


# Generated at 2022-06-23 02:41:04.236058
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils import facts
    from ansible.module_utils.facts.virtual.freebsd import VirtualVirtualBSD
    freebsd_virtual_obj = VirtualVirtualBSD(facts.get_module())
    freebsd_virtual_obj.detect_virt_product('hw.model')

# Generated at 2022-06-23 02:41:11.096904
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # arrange
    class FakeVSMDModule(object):
        @staticmethod
        def run_command(cmd):
            rc, out, err = 1, '', ''
            if 'security.jail.jailed' in cmd:
                rc, out, err = 0, '1', ''
            if 'security.jail.enforce_statfs' in cmd:
                rc, out, err = 0, '2', ''
            if 'kern.vm_guest' in cmd:
                rc, out, err = 0, 'QEMU', ''
            return rc, out, err

    class FakeVSMDModuleMethod(object):
        @staticmethod
        def get_bin_path(binary, required=False):
            return '/bin/sysctl'

    obj = VirtualSysctlDetectionMixin()
    obj.module

# Generated at 2022-06-23 02:41:21.894085
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = 'VMWare'
            self.run_command_err = ''
            self.get_bin_path_rc = 0
            self.get_bin_path_path = '/usr/local/bin/sysctl'

        def get_bin_path(self, key):
            return self.get_bin_path_path

        def run_command(self, cmd):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()

    facts_dict = mixin.detect_virt_vendor('hw.model')


# Generated at 2022-06-23 02:41:30.179776
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule:
        def __init__(self):
            self.exit_json_called = False
            self.exit_json_called_with = False

        def exit_json(self, changed=False, ansible_facts={}):
            self.exit_json_called = True
            self.exit_json_called_with = dict(changed=changed, ansible_facts=ansible_facts)

        def get_bin_path(self, arg):
            return '/sbin/sysctl'

        def run_command(self, arg):
            return 0, 'QEMU', ''

    my_obj = VirtualSysctlDetectionMixin()
    my_obj.module = FakeModule()
    my_obj.sysctl_path = None
    my_obj.detect_virt_vendor('hw.model')
   

# Generated at 2022-06-23 02:41:41.427119
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils._text import to_bytes

    fixture_params = {
        'OBSD_FOUND_SYSCTL': True,
    }

    from ansible.module_utils import basic
    from ansible.module_utils import virtualization
    from ansible.module_utils import openbsd_common

    class FakeModule:
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, arg):
            if self.params.get('OBSD_FOUND_SYSCTL') is True:
                return to_bytes('/usr/sbin/sysctl')
            else:
                return None

        def run_command(self, arg):
            return 0, 'KVM', ''

    fixture_module = FakeModule(fixture_params)

   

# Generated at 2022-06-23 02:41:51.906902
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.freebsd.system import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import Facts
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.utils import get_file_content

    key_vendor = 'kern.vm_guest'
    key_product = 'hw.model'
    sysctl_path = '/sbin/sysctl'
    out_vendor = 'QEMU'
    out_product = 'VirtualBox'

    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, *args):
            pass

        def run_command(self, cmd):
            return (0, out_vendor, None)


# Generated at 2022-06-23 02:41:55.982034
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtualization_mixin = VirtualSysctlDetectionMixin()
    virtualization_mixin.module = AnsibleModuleMock()
    virtualization_mixin.detect_virt_product('test.test.test')
    virtualization_mixin.detect_virt_vendor('test.test.test')

# Generated at 2022-06-23 02:42:02.779427
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.freebsd import VirtualSysctlDetectionMixin
    class VirtualSysctlDetectionMixinTestImpl(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = None
    mixin_obj = VirtualSysctlDetectionMixinTestImpl()
    mixin_obj.detect_sysctl()


# Generated at 2022-06-23 02:42:13.963048
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixinObj

    # Test should return guest_facts that has
    #   virtualization_type = 'xen'
    #   virtualization_role = 'guest'
    #   virtualization_tech_guest = ['xen']
    #   virtualization_tech_host = []
    class TestFacts:
        def __init__(self):
            self.sysctl_path = 'sysctl_path'
            self.module = MagicMock()

    class TestFactsModule:
        def get_bin_path(self, value):
            return 'sysctl_path'


# Generated at 2022-06-23 02:42:23.663157
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeVirtModule():
        def __init__(self):
            self.exit_json = False
            self.failed = True

        def get_bin_path(self, command):
            return '/usr/sbin/sysctl'

        def run_command(self, command):
            my_stdout = ''
            my_rc = 0
            if 'security.jail.jailed' in command:
                my_stdout = '1'
            elif 'hw.product' in command:
                my_stdout = 'VMware vCenter Server'
            elif 'hw.machine' in command:
                my_stdout = 'VMWare Virtual Platform'
            elif 'hw.model' in command:
                my_stdout = 'VirtualBox'
            elif 'hw.vendor' in command:
                my

# Generated at 2022-06-23 02:42:30.210527
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class fake_module(object):
        def __init__(self):
            self.sysctl_path = '/sbin/sysctl'

    class fake_VirtualSysctlDetectionMixin(object):
        def __init__(self, module):
            self.module = module

    f_vsm = fake_VirtualSysctlDetectionMixin(fake_module())
    f_vsm.sysctl_path = None
    f_vsm.detect_sysctl()
    assert f_vsm.sysctl_path == fake_module().sysctl_path


# Generated at 2022-06-23 02:42:37.578296
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.virtual.openbsd import VirtualOpenBSD

    fake_obj = VirtualOpenBSD(collector)
    fake_obj.sysctl_path = 'sysctl'
    setattr(fake_obj, 'run_command', test_VirtualSysctlDetectionMixin_run_command)
    output_facts = fake_obj.detect_virt_vendor('kern.hostname')
    assert output_facts['virtualization_type'] == 'vmm'


# Generated at 2022-06-23 02:42:48.905783
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    sysctl_path = '/usr/sbin/sysctl'
    class Mixin:
        def __init__(self):
            self.sysctl_path = sysctl_path
        def run_command(self, command):
            return (0, 'VMware', '')

    mixin = Mixin()
    mixin.detect_sysctl = VirtualSysctlDetectionMixin.detect_sysctl
    mixin.detect_virt_product = VirtualSysctlDetectionMixin.detect_virt_product
    module = type('Module', (), {})
    module.get_bin_path = lambda x: sysctl_path
    module.run_command = lambda x, y: (x, y, z)
    mixin.module = module

    mixin.detect_virt_product('machdep.hypervisor')

# Generated at 2022-06-23 02:42:51.264220
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts import virtual

    m = virtual()
    assert m.detect_sysctl()


# Generated at 2022-06-23 02:42:58.380494
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    detect_sysctl_mock = VirtualSysctlDetectionMixin()
    detect_sysctl_mock.module = Mock()
    detect_sysctl_mock.module.get_bin_path = Mock(return_value="/usr/bin/sysctl")

    detect_sysctl_mock.detect_sysctl()

    assert detect_sysctl_mock.module.get_bin_path.called
    assert detect_sysctl_mock.sysctl_path == "/usr/bin/sysctl"


# Generated at 2022-06-23 02:43:10.113877
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class Testklass(VirtualSysctlDetectionMixin):
        pass
    Testklass = Testklass()
    Testklass.module = 'Test'
    assert Testklass.detect_sysctl() == Testklass.sysctl_path
    assert Testklass.detect_virt_product('security.jail.jailed') == {'virtualization_type': 'jails',
                                                                     'virtualization_role': 'guest',
                                                                     'virtualization_tech_guest': set(['jails']),
                                                                     'virtualization_tech_host': set()}

# Generated at 2022-06-23 02:43:15.835340
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = "/usr/bin/sysctl"
    obj.module = MockAnsibleModule()
    results = obj.detect_virt_product("hw.model")
    assert results == {
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm',
        'virtualization_tech_guest': {'kvm'}
    }, results


# Generated at 2022-06-23 02:43:25.833864
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    test_mixin = VirtualSysctlDetectionMixin()
    test_mixin.sysctl_path = '/sbin/sysctl'

    test_mixin.module = FakeModule()

    # Test vendor as QEMU
    rc, out, err = test_mixin.module.run_command("%s -n hw.model_virtual" % test_mixin.sysctl_path)
    assert rc == 0
    assert re.match('(QEMU).*', out)

    # Test vendor as OpenBSD
    rc, out, err = test_mixin.module.run_command("%s -n hw.model_virtual" % test_mixin.sysctl_path)
    assert rc == 0
    assert re.match('(OpenBSD).*', out)



# Generated at 2022-06-23 02:43:30.477567
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    assert detect_virt_product() == {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set()
    }


# Generated at 2022-06-23 02:43:42.233897
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_Test(VirtualSysctlDetectionMixin):
        def __init__(self):
            class TestModule:
                def __init__(self):
                    self.params = dict()
                    self.params['gather_subset'] = '!all'
                def get_bin_path(self, command, required=True):
                    return "test_bin_path/%s" % command
                def run_command(self, command):
                    return 0, "test_run_command_out", "test_run_command_err"
            self.module = TestModule()
    test_mixin = VirtualSysctlDetectionMixin_Test()
    test_mixin.sysctl_path = "test_sysctl_path"


# Generated at 2022-06-23 02:43:50.289985
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.openbsd import VirtualSysctlDetectionMixin
    class implementation(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None
    i = implementation()
    i.sysctl_path = "/usr/sbin/sysctl"
    i.detect_sysctl()
    assert i.sysctl_path == "/usr/sbin/sysctl"

# Unit tests for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:43:57.438023
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.sysctl_path = "/usr/bin/sysctl"
    mixin.module = MyFakeAnsibleModule()
    virtual_vendor_facts = mixin.detect_virt_vendor('hw.model')
    assert virtual_vendor_facts['virtualization_type'] == 'kvm'
    assert virtual_vendor_facts['virtualization_role'] == 'guest'
    assert virtual_vendor_facts['virtualization_tech_guest'] == set(['kvm'])
    assert virtual_vendor_facts['virtualization_tech_host'] == set([])


# Generated at 2022-06-23 02:44:03.174785
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def get_bin_path(self, binary):
            return '/usr/bin/'+binary

    m = FakeModule()

    c = VirtualSysctlDetectionMixin()
    c.module = m

    assert c.sysctl_path is None
    c.detect_sysctl()
    assert c.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:44:13.945815
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
    # AnsibleModule is not available on this platform
    # pylint: disable=E0602
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual
    from ansible.module_utils.facts.virtual.openbsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.virtual.openbsd import OpenBSDVirtual

    class TestOpenBSDVirtual(OpenBSDVirtual, VirtualSysctlDetectionMixin):
        def detect_virt(self):
            self.virtual_facts = {}
            self.virtual_facts.update(self.detect_virt_vendor('hw.model'))

# Generated at 2022-06-23 02:44:21.350998
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class DummyModule(object):
        def __init__(self):
            self.run_command_called_times = 0
            self.run_command_program = None
            self.run_command_args = None
            self.run_command_check_rc = False
            self.run_command_kwargs = None
            self.run_command_result = None

        def run_command(self, program, args, check_rc=False, **kwargs):
            self.run_command_called_times += 1
            self.run_command_program = program
            self.run_command_args = args
            self.run_command_check_rc = check_rc
            self.run_command_kwargs = kwargs
            return self.run_command_result


# Generated at 2022-06-23 02:44:31.622042
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    if not VirtualSysctlDetectionMixin.detect_virt_vendor:
        return
    from ansible.module_utils.facts.system.bsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.system.bsd.sysctl import BSD
    module = BSD(dict())
    assert module.detect_virt_vendor("machdep.vm_guest")['virtualization_tech_guest'] == set(['kvm'])
    assert module.detect_virt_vendor("machdep.vm_guest")['virtualization_type'] == 'kvm'
    assert module.detect_virt_vendor("machdep.vm_guest")['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:44:38.927410
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    vm = VirtualSysctlDetectionMixin()
    vm.sysctl_path = True
    vm.module = MagicMock()
    vm.module.run_command.return_value = 0, 'QEMU', ''
    vm.detect_sysctl = MagicMock()
    result = vm.detect_virt_vendor('machdep.hypervisor_vendor')
    assert result == {'virtualization_role': 'guest',
                      'virtualization_type': 'kvm',
                      'virtualization_tech_host': set(),
                      'virtualization_tech_guest': set(['kvm'])}
