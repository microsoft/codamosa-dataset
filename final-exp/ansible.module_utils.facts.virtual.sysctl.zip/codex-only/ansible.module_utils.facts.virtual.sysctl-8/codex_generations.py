

# Generated at 2022-06-23 02:34:39.108683
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Test(object):
        def __init__(self):
            self.facts = {}

        def get_bin_path(self, key):
            return '/sbin/sysctl'

    class VSDMM(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = Test()

    v = VSDMM()
    v.detect_sysctl()
    assert v.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:34:41.872127
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()
    mixin.detect_virt_vendor("security.jail.osreldate")



# Generated at 2022-06-23 02:34:53.792657
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    #  This is a virtualization_type used to test
    vt = 'test_virtualization_type'
    #  This is a virtualization_role used to test
    vr = 'virtualization_role'
    #  This is a class that is extended by VirtualSysctlDetectionMixin.
    class VirtualSysctlDetectionMixin_obj(object):
        def __init__(self):
            self.sysctl_path = 'path'
            self.module = MagicMock()
            self.module.get_bin_path.return_value = self.sysctl_path
            self.module.run_command.return_value = [0, 'QEMU', '']

    VOSM = VirtualSysctlDetectionMixin_obj()
    #  This is a dict that is returned from detect_virt_vendor, it

# Generated at 2022-06-23 02:34:59.034869
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = MockModule()
    obj = VirtualSysctlDetectionMixin()
    obj.module = module
    obj.detect_sysctl = Mock()
    obj.detect_virt_vendor('vm.vmtotal')
    module.run_command.assert_called_once_with('/bin/sysctl -n vm.vmtotal')


# Generated at 2022-06-23 02:35:02.629492
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    vdm = VirtualSysctlDetectionMixin()
    assert isinstance(vdm, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:35:03.987277
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass(VirtualSysctlDetectionMixin):
        pass
    assert VirtualSysctlDetectionMixin is not None

# Generated at 2022-06-23 02:35:12.718858
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.type = 'UNSET'
        def get_bin_path(self, b):
            return '/usr/bin/sysctl'
        def run_command(self, cmd):
            if b'/usr/bin/sysctl -n hw.model' in cmd:
                out = 'QEMU Virtual CPU version 0.12.5'
                return (0, out, '')
            elif b'/usr/bin/sysctl -n security.jail.jailed' in cmd:
                out = '1'
                return (0, out, '')
            elif b'/usr/bin/sysctl -n security.bsd.see_other_uids' in cmd:
                out = '1'
                return (0, out, '')
           

# Generated at 2022-06-23 02:35:23.483913
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    v = VirtualSysctlDetectionMixin()
    v.sysctl_path = '/usr/bin/sysctl'
    v.module = MockModule()
    # mock what run_command will return

    # test hyperv
    v.module.run_command.return_value = (0, 'Hyper-V', '')
    result = v.detect_virt_product('machdep.hyperv.features')
    assert 'Hyper-V' in result['virtualization_tech_guest']
    assert result['virtualization_type'] == 'Hyper-V'
    assert result['virtualization_role'] == 'guest'

    # test parallels
    v.module.run_command.return_value = (0, 'Parallels', '')

# Generated at 2022-06-23 02:35:35.312974
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class FakeModule(object):
        def __init__(self, virtual_product_facts):
            self.virtual_product_facts = virtual_product_facts
        def get_bin_path(self, *args):
            return '/bin/sysctl'
        def run_command(self, *args):
            key = args[0].split()[-1]
            if key in self.virtual_product_facts:
                return (0, self.virtual_product_facts[key], None)
            else:
                return (1, None, None)

    # Test with no defined sysctl key - expect None to be returned
    test_instance = VirtualSysctlDetectionMixin()
    test_module = FakeModule({})
    test_instance.module = test_module

    virtual_product_facts = test_instance.detect_virt_

# Generated at 2022-06-23 02:35:40.508137
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    import tempfile
    from ansible.module_utils.facts.os.virt_sysctl import VirtualSysctlDetectionMixin
    class TestClass:
        def __init__(self):
            self.module = TestModule()
    test_class = TestClass()
    test_class.detect_virt_vendor("")


# Generated at 2022-06-23 02:35:47.123119
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()

    class MockModule(object):
        def get_bin_path(self, executable):
            return '/sbin/sysctl'

        def run_command(self, command):
            return (0, 'KVM', '')

    t = TestVirtualSysctlDetectionMixin()

    assert t.sysctl_path == '/sbin/sysctl'

# Generated at 2022-06-23 02:35:49.608196
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    vsdm = VirtualSysctlDetectionMixin()
    return_value = vsdm.detect_sysctl()
    assert return_value is not None


# Generated at 2022-06-23 02:35:52.803673
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert hasattr(VirtualSysctlDetectionMixin(), 'detect_sysctl')
    assert hasattr(VirtualSysctlDetectionMixin(), 'detect_virt_product')
    assert hasattr(VirtualSysctlDetectionMixin(), 'detect_virt_vendor')

# Generated at 2022-06-23 02:35:54.953994
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    c = VirtualSysctlDetectionMixin()
    assert issubclass(type(c), object)

# Generated at 2022-06-23 02:36:03.044324
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    sysctl_path = "/sbin/sysctl"
    module = ansible.module_utils.basic.AnsibleModule()

    linux_sys = VirtualSysctlDetectionMixin()
    setattr(linux_sys, 'sysctl_path', sysctl_path)
    assert linux_sys.sysctl_path == sysctl_path

    linux_sys2 = VirtualSysctlDetectionMixin()
    setattr(linux_sys2, 'module', module)
    linux_sys2.detect_sysctl()
    assert linux_sys2.sysctl_path == sysctl_path


# Generated at 2022-06-23 02:36:09.018462
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestModule:
        pass

    setattr(TestModule, 'run_command', run_command)
    setattr(TestModule, 'get_bin_path', get_bin_path)

    v = VirtualSysctlDetectionMixin()
    v.module = TestModule()

    assert v.sysctl_path is None
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'



# Generated at 2022-06-23 02:36:17.789527
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    class TestModule:
        def __init__(self):
            self.run_command = None
            self.get_bin_path = None

    class TestOSModule:
        def __init__(self):
            self.system = None
            self.distribution = None
            self.release = None

    class TestRunCommandModule:
        def __init__(self):
            self.rc = None
            self.out = None
            self.err = None

        def run_command(self):
            return self.rc, self.out, self.err


# Generated at 2022-06-23 02:36:28.523774
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import os
    import sys
    import unittest

    sys.path.append(os.path.join(os.path.dirname(__file__), '..', '..'))
    from lib.ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts import AnsibleModule

    virtual_vendor_facts = {}
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = AnsibleModule(argument_spec={})
    mixin.detect_sysctl()

    # Testing OpenBSD
    rc, out, err = mixin.module.run_command("echo 'OpenBSD'")
    if rc == 0:
        virtual_vendor_facts = mixin.detect_virt_vendor('hw.model')
    assert virtual_vendor_

# Generated at 2022-06-23 02:36:32.449411
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.params = {}
            self.params['name'] = None

        def get_bin_path(self, binary):
            return '/sbin/sysctl'

        def run_command(self, command):
            return (0, 'VirtualBox', None)

    class FakeClass(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    class FakeClass2(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()

    class FakeClass3(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()


# Generated at 2022-06-23 02:36:39.457896
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    try:
        import libs
        import module_utils
    except:
        import ansible.module_utils as module_utils
        module_utils.basic = None

        class VirtualSysctlDetectionMixin():
            pass

    vsdm = VirtualSysctlDetectionMixin()
    vsdm.module = type('', (), {})()
    vsdm.module.basic = module_utils.basic
    vsdm.module.get_bin_path = lambda x: 'test_bin_path'

    vsdm.detect_sysctl()
    assert vsdm.sysctl_path == 'test_bin_path'

# Generated at 2022-06-23 02:36:47.767607
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = AnsibleModule(argument_spec={})
    test_obj.sysctl_path = "/usr/sbin/kvm"
    test_obj.module.run_command = MagicMock(return_value=(0, "KVM", ""))
    result = test_obj.detect_virt_product("")
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_guest'] == set(['kvm'])
    assert result['virtualization_tech_host'] == set()



# Generated at 2022-06-23 02:36:55.329915
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = AnsibleModule(argument_spec={})
    class DummyClass(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module
            self.sysctl_path = None

    # A dummy function to seperate these tests from the class test
    def dummy_func():
        pass

    # Test that functions called by constructor get called properly
    with patch.object(DummyClass, "detect_sysctl", autospec=True) as mock_detect_sysctl:
        mock_detect_sysctl.side_effect = dummy_func
        inst = DummyClass(module)
        assert mock_detect_sysctl.called is True

    # Test that syctl_path is assigned properly

# Generated at 2022-06-23 02:36:57.231130
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:37:01.755444
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    m = VirtualSysctlDetectionMixin()
    assert getattr(m, "detect_sysctl", None) is not None
    assert getattr(m, "detect_virt_product", None) is not None
    assert getattr(m, "detect_virt_vendor", None) is not None

# Generated at 2022-06-23 02:37:09.020411
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    import unittest
    import ansible.module_utils.facts.virtual.freebsd as freebsd

    class VirtualSysctlDetectionMixinTestCase(unittest.TestCase):
        def setUp(self):
            self.test_class = VirtualSysctlDetectionMixin()
            self.test_class.module = freebsd

        def test_detect_sysctl_non_freebsd(self):
            platform_mock = unittest.mock.MagicMock()
            platform_mock.system.return_value = 'Darwin'
            platform_mock.release.return_value = '15.6.0'

# Generated at 2022-06-23 02:37:09.894357
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_class = VirtualSysctlDetectionMixin()
    assert test_class is not None

# Generated at 2022-06-23 02:37:21.759797
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import sys
    from ansible.module_utils.facts.virt.freebsd import VirtualSysctlDetectionMixin

    class FakeModule(object):
        def __init__(self, params):
            self.params = params

        def get_bin_path(self, path, opts=None, required=False):
            return "/usr/sbin/sysctl"

        def run_command(self, args):
            out = "Unknown"
            if args == "/usr/sbin/sysctl -n kern.vm_guest":
                out = "QEMU"
            if args == "/usr/sbin/sysctl -n kern.vm_guest":
                out = "OpenBSD"
            return 0, out, ''


# Generated at 2022-06-23 02:37:27.761005
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestModule:
        def get_bin_path(self, binary):
            return binary

    class TestObject(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    module = TestModule()
    test_object = TestObject(module)
    test_object.detect_sysctl()
    assert test_object.sysctl_path is not None


# Generated at 2022-06-23 02:37:34.835864
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    module = FakeModule()
    v = VirtualSysctlDetectionMixin()
    v.module = module

    v.sysctl_path = None
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'

    module.run_command.returncode = 1
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'

    module.run_command.returncode = 0
    v.detect_sysctl()
    assert v.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:37:45.987828
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    import platform
    platform.system = lambda: 'FreeBSD'
    t = VirtualSysctlDetectionMixin()
    t.module = MockModule()
    t.sysctl_path = True
    t.module.run_command = Mock(side_effect=[(0, 'QEMU', 'stderr'), (1, 'NONE', 'stderr')])
    assert t.detect_virt_vendor('security.jail.jailed') == {
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
        'virtualization_role': 'guest',
        'virtualization_type': 'kvm'}

# Generated at 2022-06-23 02:37:50.852101
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    VirtualSysctlDetectionMixin.detect_virt_product.__code__ = None

    x = VirtualSysctlDetectionMixin()
    assert x.detect_virt_product('hw.model') == {'virtualization_tech_guest': set(), 'virtualization_tech_host': set()}


# Generated at 2022-06-23 02:37:56.342743
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():

    # Return values for test only
    created_object = VirtualSysctlDetectionMixin()
    self_module = 'fake'
    self_module.get_bin_path = lambda x: '/usr/bin/sysctl'
    created_object.module = self_module
    self_sysctl_path = created_object.detect_sysctl()
    assert self_sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:38:04.611442
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    mock_module = type('MockModule', (object,), {})()
    mock_module.get_bin_path = lambda _: '/usr/bin/sysctl'

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = mock_module

    mixin.detect_sysctl()
    assert (mixin.sysctl_path == '/usr/bin/sysctl')

    mock_module.get_bin_path = lambda _: None
    mixin.detect_sysctl()
    assert (mixin.sysctl_path is None)


# Generated at 2022-06-23 02:38:15.497995
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible.module_utils.facts.system.virtual import VirtualSysctlDetectionMixin
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.virtual

    class ModuleFake(object):
        def __init__(self):
            self.run_command_called_count = 0
            self.params = dict()

        def get_bin_path(self, *args, **kwargs):
            return "/bin/sysctl"

        def run_command(self, args, check_rc=True):
            self.run_command_called_count += 1
            return 0, "0", ""

    class FakeFactsCollector(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    m = ModuleFake()


# Generated at 2022-06-23 02:38:20.886418
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Object(object):
        def __init__(self):
            self.sysctl_path = None
            self.module = AnsibleModule()
            self.module.get_bin_path = mock_get_bin_path
    o = Object()
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl(o)
    assert o.sysctl_path == '/usr/bin/sysctl'


# Generated at 2022-06-23 02:38:26.216190
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Run method detect_virt_vendor of class VirtualSysctlDetectionMixin with
    # proper arguments to test
    # for expected result
    result = {'virtualization_type':'kvm', 'virtualization_role':'guest'}
    # Compare the actual result with expected result
    assert result == detect_virt_vendor('hw.model')


# Generated at 2022-06-23 02:38:37.847155
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = MagicMock()
    virtual_sysctl_detection_mixin.sysctl_path = None
    virtual_sysctl_detection_mixin.module.get_bin_path.return_value = True
    virtual_sysctl_detection_mixin.module.run_command.return_value = (0, 'KVM', '')

    virtualization_facts = virtual_sysctl_detection_mixin.detect_virt_product('hw.vmm.vm_guest')

    virtual_sysctl_detection_mixin.module.get_bin_path.assert_called_with('sysctl')
    virtual_sysctl_detection_mixin.module.run_command

# Generated at 2022-06-23 02:38:45.760440
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class test_class():
        def __init__(self):
            self.sysctl_path = None
            self.module = None
    test_object = test_VirtualSysctlDetectionMixin_detect_virt_vendor.test_class()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = test_object
    mixin.detect_sysctl = lambda self: setattr(self, 'sysctl_path', '/sbin/sysctl')
    mixin.detect_virt_vendor('vendor.virtualization.product')
    assert test_object.virtualization_type == 'kvm'
    assert test_object.virtualization_role == 'guest'
    assert test_object.virtualization_tech_guest == set(['kvm'])
    assert test_object.virtualization

# Generated at 2022-06-23 02:38:56.011706
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.sysctl.freebsd import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixinFreeBSD
    from ansible.module_utils.facts.sysctl.netbsd import VirtualSysctlDetectionMixin as VirtualSysctlDetectionMixinNetBSD

    def get_bin_path(self, name):
        return "/usr/sbin/sysctl" if name == 'sysctl' else None

    def run_command(self, cmd):
        if cmd == '/usr/sbin/sysctl -n security.jail.jailed':
            return 0, '1', None
        if cmd == '/usr/sbin/sysctl -n hw.machine':
            return 0, 'OpenBSD', None
       

# Generated at 2022-06-23 02:39:03.425515
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Mock the module, then let VirtualSysctlDetectionMixin.detect_sysctl() set the sysctl_path
    # and let the test assert on the value of the sysctl_path attribute.
    module = MockModule()
    mixin = VirtualSysctlDetectionMixin()

    mixin.module = module
    mixin.detect_sysctl()

    assert mixin.sysctl_path == "/path/to/sysctl"


# Generated at 2022-06-23 02:39:08.751512
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        module = None
        class RunResult:
            stdout = 'out'
            stderr = 'err'
            rc = 'rc'
        def run_command(self, command):
            return self.RunResult()
    obj = FakeSysctlDetectionMixin()
    assert obj.sysctl_path == 'out'



# Generated at 2022-06-23 02:39:15.973712
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class Mixin():
        def get_bin_path(self, cmd):
            if cmd == 'sysctl': return('/usr/bin/sysctl')
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = Mixin()
    mixin.detect_sysctl()
    assert mixin.sysctl_path == '/usr/bin/sysctl'
    mixin.module = None
    assert not mixin.sysctl_path



# Generated at 2022-06-23 02:39:26.297205
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import shutil

    sysctl_path = '/sbin/sysctl'
    # First test with sysctl not available
    shutil.rmtree(sysctl_path, True)
    test_obj = VirtualSysctlDetectionMixin()
    test_obj.sysctl_path = sysctl_path
    test_obj.module = MagicMock()
    test_obj.module.get_bin_path.return_value = None
    test_obj.detect_sysctl()
    assert test_obj.sysctl_path is None

    # Stub out a sysctl command, so we can verify the arguments are passed properly

# Generated at 2022-06-23 02:39:36.677404
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from mock import MagicMock
    import sys

    class OptModule():
        def __init__(self):
            self.params = {}
            self.exit_json = MagicMock()
            self.run_command = MagicMock()
            self.get_bin_path = MagicMock()

    opt_module = OptModule()

    # No virtualization detected
    opt_module.run_command.return_value = (0, "", "")
    virtual_vendor_facts = VirtualSysctlDetectionMixin().detect_virt_vendor('hw.model')
    assert virtual_vendor_facts['virtualization_tech_guest'] == set()
    assert virtual_vendor_facts['virtualization_tech_host'] == set()
    assert 'virtualization_type' not in virtual_vendor_facts

# Generated at 2022-06-23 02:39:45.837221
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def __init__(self, bin_path_value):
            self.bin_path_value = bin_path_value

        def get_bin_path(self, name, **kwargs):
            if name == 'sysctl':
                return self.bin_path_value

    mixin = VirtualSysctlDetectionMixin()

    # test sysctl found
    fake_module = FakeModule('/usr/sbin/sysctl')
    mixin.module = fake_module
    mixin.detect_sysctl()
    assert mixin.sysctl_path ==  '/usr/sbin/sysctl'


# Generated at 2022-06-23 02:39:56.755793
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    try:
        # In Python 3, int() returns a subclass of int, so the Mock object we
        # return in the except block does not work when the isinstance function
        # is called in VirtualSysctlDetectionMixin.detect_virt_vendor.
        # In Python 2, int() returns the int type, and the isinstance function
        # will catch Mock objects, allowing us to return one.
        raise TypeError
    except:
        class Mock(object):
            def __init__(self, return_value):
                self.return_value = return_value

            def __call__(self, *args, **kwargs):
                return self.return_value

        module = Mock(Mock(Mock(Mock(Mock(Mock({}))))))

# Generated at 2022-06-23 02:40:02.077053
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    result = VirtualSysctlDetectionMixin()
    status, out, err = result.detect_virt_product('hw.model')
    assert result.virtualization_type == 'kvm'
    assert result.virtualization_role == 'guest'
    assert result.virtualization_tech_guest == set(['kvm'])
    assert result.virtualization_tech_host == set()


# Generated at 2022-06-23 02:40:07.760333
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    fixture = VirtualSysctlDetectionMixin()
    assert fixture is not None

# Generated at 2022-06-23 02:40:17.507571
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    x = VirtualSysctlDetectionMixin()
    x.module = FakeAnsibleModule()
    x.detect_sysctl = lambda: setattr(x, 'sysctl_path', 'sysctl')
    x.module.run_command = lambda cmd: (0, "QEMU", "")
    out = x.detect_virt_vendor('machdep.cpu_vendor')
    assert "kvm" in out['virtualization_tech_guest']
    assert out['virtualization_type'] == 'kvm'
    assert out['virtualization_role'] == 'guest'



# Generated at 2022-06-23 02:40:25.504614
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_vendor_facts = {}
    class MockModule:
        def __init__(self, params={}):
            self.params = params
            for key, value in params.items():
                setattr(self, key, value)
        def run_command(self, cmd):
            return (0, 'OpenBSD', '')
        def get_bin_path(self, parameter, required=False):
            return '/usr/bin/sysctl'
    class MockOpenBSD_vmm:
        def __init__(self, params={}):
            self.module = MockModule(params={'openbsd_virtualization_vendor_key': 'machdep.fakevendor'})
            self.sysctl_path = self.module.get_bin_path('sysctl')

# Generated at 2022-06-23 02:40:30.734998
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    assert hasattr(virtual_sysctl_detection_mixin, 'detect_sysctl')
    assert hasattr(virtual_sysctl_detection_mixin, 'detect_virt_product')
    assert hasattr(virtual_sysctl_detection_mixin, 'detect_virt_vendor')

# Generated at 2022-06-23 02:40:38.540263
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():

    # Create mock module
    module = type('module', (object,), {'run_command': run_command})()

    # Create mock sysctl command
    sysctl_path = 'sysctl'

    class FakeVirtVendorDetectionMixin(object):
        sysctl_path = sysctl_path

    # Create object and call method
    obj_virt_vendor = VirtualSysctlDetectionMixin()
    obj_virt_vendor.module = module
    obj_virt_vendor.detect_sysctl = FakeVirtVendorDetectionMixin.detect_sysctl
    obj_virt_vendor.detect_virt_vendor('hw.vmm.vendor')

# Generated at 2022-06-23 02:40:49.919082
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Test_VirtualSysctlDetectionMixin():
        def __init__(self):
            self.sysctl_path = None

        def get_bin_path(self, key):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            self.cmd = cmd
            return 0, 'VirtualBox', ''

    _module = Test_VirtualSysctlDetectionMixin()
    _mixin = VirtualSysctlDetectionMixin()
    facts = _mixin.detect_virt_product('machdep.cpu.brand_string')
    exp = {
            'virtualization_role': 'guest',
            'virtualization_type': 'virtualbox',
            'virtualization_tech_host': set(),
            'virtualization_tech_guest': {'virtualbox'}
        }
   

# Generated at 2022-06-23 02:40:50.907546
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    test_case = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:40:58.872692
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = AnsibleModule(argument_spec={})
    bin_path = dict(default='/sbin:/usr/sbin:/usr/local/sbin:/usr/local/bin:/usr/bin:/bin', type='str')
    module.params = dict(bin_path=bin_path)

    # Test if sysctl_path is defined.
    virt_obj = VirtualSysctlDetectionMixin()
    virt_obj.module = module
    virt_obj.detect_sysctl()
    assert virt_obj.sysctl_path is not None
    assert virt_obj.sysctl_path == "/sbin/sysctl"

    # Test if sysctl is not found

# Generated at 2022-06-23 02:41:10.424845
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        pass

    tc = TestVirtualSysctlDetectionMixin()
    tc.sysctl_path = '/usr/sbin/sysctl'

    result = tc.detect_virt_product('hw.model')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'
    assert result['virtualization_tech_host'] == set()
    assert result['virtualization_tech_guest'] == set(['kvm'])

    result = tc.detect_virt_product('hw.product')
    assert result['virtualization_type'] == 'VMware'

# Generated at 2022-06-23 02:41:19.068117
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class TestVirtualSysctlDetectionMixin:
        module = None

        class TestModule:
            def __init__(self):
                self.params = {
                    'module_name': 'system',
                    'module_path': 'ansible/modules/system'
                }

        def get_bin_path(self, name, opt_dirs=[]):
            return '/bin/' + name

    test_object = TestVirtualSysctlDetectionMixin()
    VirtualSysctlDetectionMixin.detect_sysctl(test_object)
    assert test_object.sysctl_path == test_object.get_bin_path('sysctl')



# Generated at 2022-06-23 02:41:24.567059
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == "sysctl":
                return executable

    v = VirtualSysctlDetectionMixinTest()
    v.module = MockModule()
    v.detect_sysctl()
    assert v.sysctl_path == "sysctl"



# Generated at 2022-06-23 02:41:25.469482
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:41:28.240784
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from .. import DetectionTool
    class Tool(VirtualSysctlDetectionMixin, DetectionTool):
        def __init__(self, module):
            DetectionTool.__init__(self, module)
    tool = Tool(None)
    assert tool is not None


# Generated at 2022-06-23 02:41:31.962036
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    mixin = VirtualSysctlDetectionMixin()
    assert isinstance(mixin, VirtualSysctlDetectionMixin)
    assert hasattr(mixin, 'detect_sysctl')
    assert hasattr(mixin, 'detect_virt_product')
    assert hasattr(mixin, 'detect_virt_vendor')
# end of unit test for constructor of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:41:41.983524
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class ObjType(object):
        def __init__(self):
            self.sysctl_path = '/bin/sysctl'
            self.module = ModuleMock()
        def detect_sysctl(self):
            pass

    class ModuleMock:
        def __init__(self):
            self.run_command_results = (0, '', '')
        def get_bin_path(self, name):
            return '/bin/'+name if name == 'sysctl' else None
        def run_command(self, cmd):
            return self.run_command_results

    obj = ObjType()


# Generated at 2022-06-23 02:41:45.093492
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule()
    virt_sysctl = VirtualSysctlDetectionMixin()
    assert virt_sysctl

# Generated at 2022-06-23 02:41:55.004265
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.system.bsd import OpenBSDVirtualSysctlDetectionMixin
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    import os

    class EnvironmentModuleMock(object):
        def __init__(self):
            self.module = None
            self.run_command = None

    class StubModule(object):
        def __init__(self):
            self.params = {}
            self.facts = {}
            self.run_command = None
            self.get_bin_path = None
            self._result = {}

    class TestVirtualSysctlDetectionMixin(OpenBSDVirtualSysctlDetectionMixin):
        pass

    test_env_module = EnvironmentModuleMock()
    test_module = TestVirtualSysctlDetectionMix

# Generated at 2022-06-23 02:42:07.007275
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class DummyModule(object):
        def run_command(cmd):
            if re.match('(KVM|kvm|Bochs|SmartDC).*', cmd):
                return (0, 'KVM', '')
            if re.match('(HVM domU|XenPVH|XenPV|XenPVHVM).*', cmd):
                return (0, 'HVM domU', '')
            if cmd.rstrip() == 'Hyper-V':
                return (0, 'Hyper-V', '')
            if cmd.rstrip() == 'VirtualBox':
                return (0, 'VirtualBox', '')
            if cmd.rstrip() == 'Parallels':
                return (0, 'Parallels', '')

# Generated at 2022-06-23 02:42:18.710185
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    class TestClass():
        def __init__(self):
            self.module = Bunch()
        def detect_sysctl(self):
            pass


    tc = TestClass()
    obj = VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:42:25.902592
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import ansible.module_utils.basic as basic
    import ansible.module_utils.facts.virtual.freebsd as freebsd_virtual
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.run_command = lambda cmd: (0, '/bin/sysctl', None)
    vsd = freebsd_virtual.VirtualSysctlDetectionMixin()
    vsd.module = module
    vsd.detect_sysctl()
    assert vsd.sysctl_path == '/bin/sysctl'


# Generated at 2022-06-23 02:42:32.315677
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule:
        def __init__(self):
            self.sysctl_path = None
        def get_bin_path(self, name, required=False):
            if name == 'sysctl':
                return '/sbin/sysctl'
            return None

    testobj = VirtualSysctlDetectionMixin()
    testobj.module = FakeModule()
    testobj.detect_sysctl()
    assert testobj.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:42:40.367471
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = FakeModule()
    vc = VirtualSysctlDetectionMixin()
    vc.module = module

    # sysctl is found
    vc.module.run_command.return_value = (0, '', '')
    vc.detect_sysctl()
    assert vc.sysctl_path == '/fake/sysctl'

    # sysctl is not found
    vc.module.run_command.return_value = (1, '', '')
    vc.detect_sysctl()
    assert vc.sysctl_path == None


# Generated at 2022-06-23 02:42:48.129881
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    facts = {}
    with open(__file__ + ".detect_virt_vendor.out", "r") as output:
        class_instance = VirtualSysctlDetectionMixin()
        class_instance.module = MagicMock()
        class_instance.module.run_command.return_value = 0, output.read(), ''
        virtual_vendor_facts = class_instance.detect_virt_vendor('hw.model')
        assert virtual_vendor_facts['virtualization_type'] == 'kvm'
        assert virtual_vendor_facts['virtualization_role'] == 'guest'
        assert virtual_vendor_facts['virtualization_tech_guest'] == { 'kvm' }


# Generated at 2022-06-23 02:42:54.094013
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    """This unit test is to test if the method detect_sysctl
    of class VirtualSysctlDetectionMixin returns the right value.
    """
    test_object = VirtualSysctlDetectionMixin()
    test_object.module = FakeModule()
    test_object.detect_sysctl()
    assert test_object.sysctl_path == 'fake_sysctl_bin_path'


# Generated at 2022-06-23 02:43:02.917954
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    '''
    Test method detect_virt_product of class VirtualSysctlDetectionMixin

    This test creates a fake object and sets some values required
    by the method. Afterwards it calls the method to be tested.
    '''
    module = FakeModule()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.sysctl_path = None

    rc = 0
    out = "KVM"
    err = "Error"
    module.run_command_results = [rc, out, err]
    result = mixin.detect_virt_product('machdep.dmi.system-manufacturer')
    assert result['virtualization_type'] == 'kvm'
    assert "kvm" in result['virtualization_tech_guest']

# Generated at 2022-06-23 02:43:10.943165
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = type('Module', (object,), {})()
    module.get_bin_path = lambda key: '/sbin/sysctl'
    module.run_command = lambda cmd: (0, 'Hyper-V\n', '')

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module

    guesser = type('Guesser', (object,), dict((k, v) for k, v in VirtualSysctlDetectionMixin.__dict__.items() if
        not k.startswith('_')))()

    guesser.module = module
    guesser.detect_virt_product = mixin.detect_virt_product('sysctl_key')
    facts = guesser.detect_virt_product('sysctl_key')


# Generated at 2022-06-23 02:43:21.377287
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_vendor_facts = {
        'virtualization_type': 'kvm',
        'virtualization_role': 'guest',
        'virtualization_tech_guest': {'kvm'},
        'virtualization_tech_host': set(),
    }

    class VirtualSysctlDetectionMixin_TEST(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.module = None

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'QEMU', ''


# Generated at 2022-06-23 02:43:26.337316
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    m.sysctl_path = 'sysctl'
    m.module = MagicMock()
    m.module.run_command.return_value = (0, 'QEMU', '')
    assert m.detect_virt_vendor('hw.model')['virtualization_type'] == 'kvm'

# Generated at 2022-06-23 02:43:30.973424
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    d = VirtualSysctlDetectionMixin()
    assert isinstance(d.module, object)
    assert d.sysctl_path is None
    assert d.detect_virt_product is not None
    assert d.detect_virt_vendor is not None
    assert d.detect_sysctl is not None

# Generated at 2022-06-23 02:43:42.325064
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixin_test(object):
        def __init__(self):
            self.module = object
            class Sub_Obj(object):
                def get_bin_path(self, path):
                    if path == 'sysctl':
                        return '/sbin/sysctl'
                    return ''
                def run_command(self, command):
                    if command == '/sbin/sysctl -n machdep.cpu.features':
                        return 0, 'SSE4.2 SSE4.1 SSE3 SSSE3 SSE2 SSE FXSR MMX CMOV AMD_SYSCALL AMD_3DNOW AMD_3DNOWEXT AMD_MMXEXT AMD_XOP', ''

# Generated at 2022-06-23 02:43:43.967992
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    obj = VirtualSysctlDetectionMixin()
    assert obj is not None

# Generated at 2022-06-23 02:43:51.781972
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin

# Generated at 2022-06-23 02:44:01.154807
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    import sys
    class FakeModule(object):
        def __init__(self):
            self.module = self
        def get_bin_path(self, name):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if cmd.startswith('/sbin/sysctl -n hw.model'):
                return (0, 'OpenBSD', '')
            elif cmd.startswith('/sbin/sysctl -n security.jail.osreldate'):
                return (0, '5', '')
            elif cmd.startswith('/sbin/sysctl -n security.jail.jailed'):
                return (0, '1', '')

# Generated at 2022-06-23 02:44:11.706584
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtual_vendor_facts_dict = dict()
    virtual_vendor_facts_dict['virtualization_type'] = 'kvm'
    virtual_vendor_facts_dict['virtualization_role'] = 'guest'
    virtual_vendor_facts_dict['virtualization_tech_guest'] = set(['kvm'])
    virtual_vendor_facts_dict['virtualization_tech_host'] = set()

    class ModuleMock():
        def __init__(self, **kwargs):
            self.kwargs = kwargs
            self.bin_path = "/bin/sysctl"
            self.rc = 0
            self.out = "OpenBSD"
            self.err = ""
            self.virtualization_facts_dict = virtual_vendor_facts_dict
            return


# Generated at 2022-06-23 02:44:22.468713
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class VirtualSysctlDetectionMixinTester():
        def __init__(self):
            self.sysctl_path = None
            self.module = None

    class VirtualSysctlDetectionMixinTesterModule():
        def __init__(self):
            self.run_command_result_map = {
                "sysctl -n security.jail.jailed": (0, '1', ''),
                "sysctl -n hw.model": (0, 'Apple MacBookPro8,1', ''),
            }

        def get_bin_path(self, arg):
            return "/usr/local/bin/%s" % arg

        def run_command(self, arg):
            return self.run_command_result_map[arg]

    virtual_sysctl_detection_mixin_tester = VirtualSysctlDet

# Generated at 2022-06-23 02:44:35.131994
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    facts = {}
    virtual_product = VirtualSysctlDetectionMixin()
    virtual_product.module = FakeModule(facts)

    # Set the sysctl executable
    virtual_product.sysctl_path = '/usr/bin/sysctl'

    # Fake the sysctl output to match what is returned by OpenBSD
    virtual_product.module.run_command = FakeRunCommand(rc=0, out='OpenBSD\n')

    # Run the function with a sysctl key that exists
    virtual_product.detect_virt_vendor('kern.vm_guest')

    # We should have got the expected result
    assert 'virtualization_type' in globals()
    assert 'virtualization_role' in globals()
    assert globals()['virtualization_type'] == 'vmm'