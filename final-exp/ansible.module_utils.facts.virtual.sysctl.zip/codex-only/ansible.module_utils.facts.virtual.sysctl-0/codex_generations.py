

# Generated at 2022-06-23 02:34:40.884578
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    detection_mixin = VirtualSysctlDetectionMixin()
    detection_mixin.detect_virt_product = 'vm.product'
    detection_mixin.detect_virt_vendor = 'vm.vendor'
    detection_mixin.detect_sysctl()
    assert detection_mixin.sysctl_path is not None
    assert detection_mixin.sysctl_path != 0
    assert detection_mixin.detect_virt_product is not None
    assert detection_mixin.detect_virt_product != 0
    assert detection_mixin.detect_virt_vendor is not None
    assert detection_mixin.detect_virt_vendor != 0

# Generated at 2022-06-23 02:34:52.958506
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class ModuleMock:
        def __init__(self):
            self.run_command_value = (0, 'QEMU', '')
            self.get_bin_path_value = ''

        def run_command(self, cmd):
            return self.run_command_value

        def get_bin_path(self, cmd):
            return self.get_bin_path_value

    class VirtSysctlDetectMock(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    test_obj = VirtSysctlDetectMock(ModuleMock())

    test_obj.sysctl_path = True
    virtual_facts = test_obj.detect_virt_vendor('hw.model')
    assert virtual_facts['virtualization_type'] == 'kvm'


# Generated at 2022-06-23 02:34:56.341525
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    instance = VirtualSysctlDetectionMixin()
    instance.module = FakeModule()
    instance.detect_sysctl()
    assert instance.sysctl_path == '/usr/sbin/sysctl'


# Generated at 2022-06-23 02:34:57.724507
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    result = VirtualSysctlDetectionMixin()
    assert result is not None

# Generated at 2022-06-23 02:35:05.625970
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    module = MockModule()
    module.run_command.return_value = (0, 'KVM', '')
    detection = VirtualSysctlDetectionMixin()
    detection.module = module

    facts = detection.detect_virt_product('hw.model')
    assert facts['virtualization_type'] == 'kvm'
    assert facts['virtualization_role'] == 'guest'
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts



# Generated at 2022-06-23 02:35:10.449530
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    a = VirtualSysctlDetectionMixin()
    a.module = module
    a.detect_sysctl()
    assert a.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:35:15.232145
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    import platform
    (dist, version, id) = platform.dist()
    if id == 'FreeBSD':
        v = VirtualSysctlDetectionMixin()
        v.detect_virt_product('kern.vm_guest')
        v.detect_virt_vendor('kern.vm_guest')

# Generated at 2022-06-23 02:35:25.582947
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # Given
    class FakeFacts:
        def __init__(self):
            self.facts = {}

    class FakeModule:
        def __init__(self):
            self.params = {}
            self.facts = FakeFacts().facts

        def get_bin_path(self, executable=None, opt_dirs=None, default=None):
            return "/usr/sbin/sysctl"

        def run_command(self, cmd, check_rc=True):
            return 0, '/usr/sbin/sysctl -n hw.vendor: QEMU', ''

    # When
    obj = VirtualSysctlDetectionMixin()
    obj.module = FakeModule()
    obj.detect_virt_vendor('hw.vendor')

    # Then
    assert 'virtualization_type' in obj.module

# Generated at 2022-06-23 02:35:28.875334
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    mixin = VirtualSysctlDetectionMixin()
    assert hasattr(mixin, 'detect_sysctl')
    assert hasattr(mixin, 'detect_virt_product')
    assert hasattr(mixin, 'detect_virt_vendor')

# Generated at 2022-06-23 02:35:35.893204
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class BSD():
        sysctl_path = None
        module = FakeModule()

        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin_path('sysctl')

        def module(self):
            return self.module

    bsd = BSD()
    bsd.detect_virt_product('hw.model')

    expected_dict = {'virtualization_tech_host': set(),
                     'virtualization_tech_guest': set(['virtualbox']),
                     'virtualization_type': 'virtualbox',
                     'virtualization_role': 'guest'}

    assert dict(expected_dict) == dict(bsd.virtual_product_facts)


# Generated at 2022-06-23 02:35:42.429311
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    v = VirtualSysctlDetectionMixin()
    v.detect_sysctl = lambda: None
    v.module = mock = type('mock', (object,), {'get_bin_path': lambda x: '/usr/bin/sysctl', 'run_command': lambda x: (0, '', '')})
    v.detect_virt_product('machdep.wise.vendor')
    assert mock.run_command.called



# Generated at 2022-06-23 02:35:44.599835
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    fixture = VirtualSysctlDetectionMixin()

    assert fixture.sysctl_path is None


# Generated at 2022-06-23 02:35:51.658841
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    virtfact = VirtualSysctlDetectionMixin()
    virtfact.module = FakeAnsibleModule()
    virtfact.detect_sysctl = FakeMethod("/usr/bin/sysctl")
    virtfact.module.run_command = FakeRunCommand("0", "QEMU", "")
    facts = virtfact.detect_virt_vendor("hw.model")
    assert facts['virtualization_type'] == "kvm"
    assert facts['virtualization_role'] == "guest"


# Generated at 2022-06-23 02:35:54.291563
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    o = VirtualSysctlDetectionMixin()
    assert o

# Generated at 2022-06-23 02:35:56.840087
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    # Create an un-instantiated class to test constructor
    x = VirtualSysctlDetectionMixin()
    assert(x)

# Generated at 2022-06-23 02:36:03.807261
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    m = VirtualSysctlDetectionMixin()
    m.module = FakeAnsibleModule()
    m.detect_virt_vendor('hw.model')
    out = dict(virtualization_type='kvm', virtualization_role='guest',
               virtualization_tech_guest=['kvm'], virtualization_tech_host=[])
    assert out == m.facts


# Generated at 2022-06-23 02:36:11.343086
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = FakeOsModule()
    sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    sysctl_detection_mixin.module = module
    sysctl_detection_mixin.detect_sysctl()
    assert sysctl_detection_mixin.sysctl_path == 'sysctl'

    sysctl_detection_mixin.module.get_bin_path = lambda bin_name: None
    sysctl_detection_mixin.detect_sysctl()
    assert sysctl_detection_mixin.sysctl_path == None



# Generated at 2022-06-23 02:36:16.623635
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    obj = VirtualSysctlDetectionMixin()
    obj.sysctl_path = None
    virtual_product_facts = obj.detect_virt_product('hw.model')
    obj.sysctl_path = '/sbin/sysctl'
    virtual_product_facts1 = obj.detect_virt_product('hw.model')
    assert virtual_product_facts == virtual_product_facts1


# Generated at 2022-06-23 02:36:19.454638
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    instance = VirtualSysctlDetectionMixin()
    assert isinstance(instance, VirtualSysctlDetectionMixin)

# Generated at 2022-06-23 02:36:30.705179
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # check path
    from ansible.module_utils.facts.system.virtual.bsd import VirtualSysctlDetectionMixin
    import os
    class os_path_exists_mock():
        def __init__(self, path):
            self.path = path
        def __call__(self, path):
            return path == self.path
    os_path_exists_orig = os.path.exists
    os.path.exists = os_path_exists_mock('/sbin/sysctl')
    v = VirtualSysctlDetectionMixin()
    assert v.sysctl_path == '/sbin/sysctl'
    os.path.exists = os_path_exists_mock('/usr/bin/sysctl')
    v = VirtualSysctlDetectionMixin()
    assert v

# Generated at 2022-06-23 02:36:39.772850
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestClass:
        def __init__(self, module):
            self.module = module
        def detect_sysctl(self):
            self.sysctl_path = '/bin/sysctl'
    t = TestClass()
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = t
    mixin.detect_sysctl()
    # kvm
    assert mixin.detect_virt_product('hw.model') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}
    # VMware
    assert mixin.detect_virt_product('hw.model') == {'virtualization_type': 'VMware', 'virtualization_role': 'guest'}
    # VirtualBox

# Generated at 2022-06-23 02:36:45.042002
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    virtual_sysctl_detection_mixin.module = FakeAnsibleModule()
    virtual_sysctl_detection_mixin.detect_sysctl()

    assert virtual_sysctl_detection_mixin.sysctl_path == '/usr/sbin/sysctl'



# Generated at 2022-06-23 02:36:53.365956
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin as SubClass

# Generated at 2022-06-23 02:37:02.694071
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class module(object):
        def __init__(self, sysctl_path):
            self.sysctl_path = sysctl_path

        def get_bin_path(self, executable):
            return self.sysctl_path

        def run_command(self, executable):
            self.executable = executable
            return (0, '', '')

    class SystemVirtDetect(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    mod = module('/bin/sysctl')
    test = SystemVirtDetect(mod)
    assert mod.sysctl_path == '/bin/sysctl'
    assert mod.executable == '/bin/sysctl -n hw.product'

# Generated at 2022-06-23 02:37:11.619945
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    from ansible_collections.ansible.community.tests.unit.compat import unittest
    from ansible_collections.ansible.community.tests.unit.compat.mock import Mock
    from ansible_collections.ansible.community.tests.unit.compat.mock import patch

    class TestVirtualSysctlDetectionMixin(unittest.TestCase, VirtualSysctlDetectionMixin):
        def __init__(self, methodName, module, args=None, fqdn=None, hostname=None):
            super(TestVirtualSysctlDetectionMixin, self).__init__(methodName)
            self.module = module
            self.args = args
            self.fqdn = fqdn
            self.hostname = hostname

    # Construct module
    module = Mock()
    module

# Generated at 2022-06-23 02:37:22.492758
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class VirtualSysctlDetectionMixinTest(VirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            self.sysctl_path = '/sbin/sysctl'
            self.module = args[0]

    class Args():
        def __init__(self, *args, **kwargs):
            self.run_command = kwargs['run_command'] if 'run_command' in kwargs else 'echo -n QEMU'

    class Module():
        def get_bin_path(self, key):
            if key == 'sysctl':
                return '/sbin/sysctl'
            else:
                return None

        def run_command(self, cmd):
            return Args.run_command(self, cmd)

    module = Module()

    virtual_sys

# Generated at 2022-06-23 02:37:30.193798
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # Dummy module class for testing
    class DummyModule:
        def get_bin_path(self, path):
            return path

        def run_command(self, command):
            # sysctl -n hw.model
            if command == 'sysctl -n hw.model':
                return 0, 'QEMU Virtual CPU version (cpu64-rhel6)', ''
            # sysctl -n hw.machine
            elif command == 'sysctl -n hw.machine':
                return 0, 'amd64', ''
            elif command == 'sysctl -n security.jail.jailed':
                return 0, '1', ''
            # sysctl -n hw.class
            elif command == 'sysctl -n hw.class':
                return 0, 'VGA', ''
            # sysctl -

# Generated at 2022-06-23 02:37:40.110150
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import virtual
    from ansible.module_utils.facts.virtual import BSDVirtualSysctlDetectionMixin

    class VirtualSysctlDetectionMixinTest(BSDVirtualSysctlDetectionMixin):
        def __init__(self, *args, **kwargs):
            super(VirtualSysctlDetectionMixinTest, self).__init__(*args, **kwargs)
            self.facts['virtualization'] = virtual.VirtualInfo(self.module)

    test = VirtualSysctlDetectionMixinTest()

    test.module = MockAnsibleModule()
    test.module.run_command.return_value = (0, '', '')

    test.sysctl_path = '/usr/bin/sysctl'

    test.facts = {}


# Generated at 2022-06-23 02:37:46.129921
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class FakeModule(object):
        def get_bin_path(self,name):
            return "path/to/%s" % name

        def run_command(self,path):
            return 0, "", ""

    class FakeTestSyscDet(VirtualSysctlDetectionMixin):
        def __init__(self, module=None):
            self.module = FakeModule()

    facts = FakeTestSyscDet()
    assert facts.detect_sysctl() is None
    assert facts.detect_virt_product('desired_key') == {}
    assert facts.detect_virt_vendor('desired_key') == {}

# vim: set filetype=python :

# Generated at 2022-06-23 02:37:51.651555
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = MockAnsibleModule()
    module.run_command_os.return_value = (0, 'FreeBSD 11.0-RELEASE-p3', '')
    sysctl = VirtualSysctlDetectionMixin()
    sysctl.module = module
    sysctl.detect_sysctl()
    assert sysctl.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:38:00.427141
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class MockModule:
        def __init__(self):
            self.params = {}

        def get_bin_path(self, path):
            if path == 'sysctl':
                return '/sbin/sysctl'
            return path

        def run_command(self, command):
            if command == '/sbin/sysctl -n hw.model':
                return 0, 'VirtualBox', ''
            return 0, '', ''

    class Mock(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    mock = Mock(MockModule())
    mock.detect_sysctl()
    virtual_facts = mock.detect_virt_product('hw.model')
    assert virtual_facts['virtualization_tech_guest'] == set(('virtualbox',))
   

# Generated at 2022-06-23 02:38:12.408676
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import ansible.module_utils.facts.system.virtual
    import ansible.module_utils.facts.system.virtual.openbsd
    module_path = ansible.module_utils.facts.system.virtual.__name__
    module_class = getattr(ansible.module_utils.facts.system.virtual, 'OpenBSDVirtual')
    class_path = ansible.module_utils.facts.system.virtual.openbsd.__name__
    class_name = module_class.__name__
    mixin_name = VirtualSysctlDetectionMixin.__name__
    mixin_path = module_class.__bases__[0].__module__

    assert '.'.join([class_path, class_name]) == '.'.join([module_path, class_name])

# Generated at 2022-06-23 02:38:18.812519
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class TestClass:
        pass

    test_obj = VirtualSysctlDetectionMixin()
    test_obj.module = TestClass()
    test_obj.module.get_bin_path = lambda _: '/bin/sysctl'
    test_obj.module.run_command = lambda _: (0, '', '')
    test_obj.detect_sysctl()
    assert test_obj.sysctl_path == '/bin/sysctl'

# Generated at 2022-06-23 02:38:29.983064
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def __init__(self):
            self.run_command_result = (0, "OpenBSD", "")

        def get_bin_path(self, name):
            return "/usr/bin/sysctl"

        def run_command(self, args):
            return self.run_command_result

    class FakeSystem(object):
        def __init__(self):
            self.module = FakeModule()

    class TestClass(VirtualSysctlDetectionMixin, FakeSystem):
        pass

    tc = TestClass()
    result = tc.detect_virt_vendor("hw.vmm.name")

# Generated at 2022-06-23 02:38:32.740587
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    VirtDetect = type('VirtDetect', (VirtualSysctlDetectionMixin,), {})
    vd = VirtDetect()
    assert vd.sysctl_path is None

# Generated at 2022-06-23 02:38:34.266208
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Can't test this - it just assigns to an attribute
    pass


# Generated at 2022-06-23 02:38:43.041820
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class FakeModule(object):
        def get_bin_path(self, path):
            return '/sbin/sysctl'

    class FakeVirtSysctlFacts(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = FakeModule()
            self.detect_sysctl()

    virt_sysctl_facts = FakeVirtSysctlFacts()
    assert virt_sysctl_facts.sysctl_path == '/sbin/sysctl'

# Unit tests for method detect_virt_product of class VirtualSysctlDetectionMixin
#
# To add more tests, please see the comments in the VirtModuleTestCase.py
# file at lib/ansible_test/modules/system/virt.
#

# Generated at 2022-06-23 02:38:51.364921
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class FakeModule(object):
        def __init__(self):
            self.run_command = lambda x: (0, x, None)
            self.get_bin_path = lambda x: x
    class FakeClass(object):
        def __init__(self):
            self.module = FakeModule()
            self.sysctl_path = 'sysctl'

    obj = FakeClass()
    obj.__class__ = VirtualSysctlDetectionMixin

    # Test KVM system
    assert obj.detect_virt_product('kern.hostuuid') == {'virtualization_type': 'kvm', 'virtualization_role': 'guest'}

    # Test VMware system

# Generated at 2022-06-23 02:39:02.567861
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Mixin:
        def run_command(self, cmd):
            cmd = cmd.split()
            return 'sysctl' == cmd[0], cmd[2], None

        def get_bin_path(self, cmd):
            return 'sysctl'


# Generated at 2022-06-23 02:39:12.187881
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'
        def run_command(self, cmd):
            if cmd == '/sbin/sysctl -n machdep.cpu.brand_string':
                return 0, "QEMU Virtual CPU version (cpu64-rhel6)", ""
            elif cmd == '/sbin/sysctl -n machdep.vmm.name':
                return 0, "OpenBSD 6.0 (GENERIC) #0: Mon Jun 12 14:31:38 MDT 2017", ""
            else:
                return 123, "", "Unexpected command"
    class MockSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def detect_sysctl(self):
            self.sysctl_path = self.module.get_bin

# Generated at 2022-06-23 02:39:20.906287
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    # Initialise object with default values
    module = AnsibleModule({})

    collect_facts = VirtualSysctlDetectionMixin()
    # Override attributes of created object
    collect_facts.module = module
    collect_facts.sysctl_path = None
    collect_facts.detect_sysctl()

    # Check values of attributes
    assert collect_facts.sysctl_path == '/sbin/sysctl'


# Generated at 2022-06-23 02:39:24.496234
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    test_class = VirtualSysctlDetectionMixin()
    assert not test_class.sysctl_path
    test_class.detect_sysctl()
    assert test_class.sysctl_path

# Generated at 2022-06-23 02:39:26.126486
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    foo = VirtualSysctlDetectionMixin()

    assert(foo)


# Generated at 2022-06-23 02:39:36.481536
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    v = VirtualSysctlDetectionMixin()
    # rc, out, err values on line above are not used in detect_virt_product
    (rc, out, err) = (0, '', '')

    rc, out, err = (0, 'VMware', '')
    facts = v._VirtualSysctlDetectionMixin__detect_virt_product(rc, out, err, 'security.jail.jailed')
    assert 'virtualization_type' not in facts
    assert 'virtualization_role' not in facts
    assert 'virtualization_tech_guest' in facts
    assert 'virtualization_tech_host' in facts
    assert 'VMware' in facts['virtualization_tech_guest']
    assert not facts['virtualization_tech_host']

# Generated at 2022-06-23 02:39:47.430274
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    v_sysctl_detection_mixin = VirtualSysctlDetectionMixin()

    import os
    import tempfile

    # ---------------------------
    # KVM and VMware
    # ---------------------------
    # We test that these two show up, as well as that we get the correct
    # virtualization_type and role.

# Generated at 2022-06-23 02:39:57.852678
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module:
        class Run_command:
            def __init__(self, command, cwd=None, shell=True, data=None, stdin=None, stdout=-1, stderr=-1, timeout=None,
                         sudo=False, follow=False, environment_update=None, check_rc=True):
                self.command = command
                self.cwd = cwd
                self.shell = shell
                self.data = data
                self.stdin = stdin
                self.stdout = stdout
                self.stderr = stderr
                self.timeout = timeout
                self.sudo = sudo
                self.follow = follow
                self.environment_update = environment_update
                self.check_rc = check_rc

# Generated at 2022-06-23 02:40:05.294427
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class Module:
        def get_bin_path(self, name):
            return "/usr/bin/sysctl"

        def run_command(self, command_line):
            return (0, "KVM", "")

    class System(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = Module()

    system = System()
    virtual_product_facts = system.detect_virt_product('hw.model')
    assert virtual_product_facts['virtualization_type'] == 'kvm'
    assert virtual_product_facts['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:40:16.766637
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    class TestModule:
        args = {}

        def get_bin_path(self, path):
            return '/sbin/sysctl'

        def run_command(self, cmd):
            return 0, 'Foo', None

    test_object = TestVirtualSysctlDetectionMixin(TestModule())
    assert 'virtualization_type' not in test_object.detect_virt_vendor('machdep.hypervisor.vendor')
    assert 'virtualization_type' in test_object.detect_virt_vendor('machdep.hypervisor.vendor')


# Generated at 2022-06-23 02:40:26.908538
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from ansible.module_utils.facts import VirtualSysctlDetectionMixin
    class FakeModule(object):
        def __init__(self):
            self.params = dict()
            self.exit_json = object()

        def get_bin_path(self, param1):
            if param1 == 'sysctl':
                return param1

        def run_command(self, param1):
            if param1 == 'sysctl -n hw.model':
                return 0, 'OpenBSD', ''
            if param1 == 'sysctl -n hw.model':
                return 0, 'VirtualBox', ''
            return 0, '', ''

    virtual_sysctl_detection_mixin = VirtualSysctlDetectionMixin()
    fake_module = FakeModule()

# Generated at 2022-06-23 02:40:27.887435
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    # TODO: Make this test actually test the output of detect_virt_product
    true = True
    false = False
    assert True

# Generated at 2022-06-23 02:40:38.648842
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    m = VirtualSysctlDetectionMixin()
    m.detect_sysctl = lambda: True
    m.sysctl_path = '/sbin/sysctl'
    m.module = MockModule()
    facts = m.detect_virt_product('hw.model')
    assert not facts.get('virtualization_role')
    assert not facts.get('virtualization_type')
    assert not facts['virtualization_tech_host']
    assert not facts['virtualization_tech_guest']

    # Virtual product tests
    #
    # When product is a guest:
    #   * virtualization_role is set to guest
    #   * virtualization_type is set to product
    #
    # When product is a host:
    #   * virtualization_role is set to host
    #   * virtualization_type is set

# Generated at 2022-06-23 02:40:48.100656
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    module = type('', (), {
        'run_command': (lambda self, cmd: (0, 'QEMU', '')),
        'get_bin_path': (lambda self, cmd: '/sbin/sysctl'),
    })

    obj = type('obj', (VirtualSysctlDetectionMixin,), {
        'module': module(),
    })

    obj.detect_sysctl = lambda self: None

    result = obj.detect_virt_vendor('machdep.cpu.brand_string')
    assert result['virtualization_type'] == 'kvm'
    assert result['virtualization_role'] == 'guest'


# Generated at 2022-06-23 02:40:58.827421
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def run_command(self, cmd):
            if cmd == "sysctl -n kern.vm_guest":
                return 0, "QEMU", ""
            elif cmd == "sysctl -n kern.vm_guest foo":
                return 1, "", ""
            else:
                return 1, "", ""

        def get_bin_path(self, arg):
            return "sysctl"

    class Fake(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module

    fact_name = 'virtual_vendor'
    key = 'kern.vm_guest'
    module = FakeModule()
    virtual_facts = {}

    fake = Fake(module)
    fake.detect_virt_vendor(key)

# Generated at 2022-06-23 02:41:10.422012
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    class DummyModule:
        # Dummy variable to create an instance of DummyModule
        dummy = 1
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd):
            if cmd == 'sysctl -n hw.model':
                return 0, 'Intel(R) Core(TM) i5-2520M CPU @ 2.50GHz', ''
            elif cmd == 'sysctl -n hw.machine':
                return 0, 'amd64', ''
            else:
                return 1, '', ''

    detect_sysctl = VirtualSysctlDetectionMixin()
    detect_sysctl.module = DummyModule()
    detect_sysctl.detect_sysctl()
    assert detect_sysctl.sysctl_path == 'sysctl'
    virt_product_facts

# Generated at 2022-06-23 02:41:17.898306
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    expected_facts = {'virtualization_role': 'guest', 'virtualization_type': 'xen', 'virtualization_tech_guest': set(['xen']), 'virtualization_tech_host': set([])}
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeAnsibleModule()
    mixin.module.run_command = FakeCommand()
    mixin.detect_virt_product('hw.product')
    assert expected_facts == mixin.module.exit_args['ansible_facts']


# Generated at 2022-06-23 02:41:27.730995
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """
    Runs VirtualSysctlDetectionMixin tests
    """
    class Module(object):
        def get_bin_path(self, path, required=False):
            return '/bin/%s' % path
        def run_command(self, cmd):
            return (1, None, None)
    loader = Module()
    virtual_sysctl_facts = VirtualSysctlDetectionMixin()

    # Test constructor to see if it properly assignes values to all class
    # variables
    assert hasattr(virtual_sysctl_facts, 'module')
    assert hasattr(virtual_sysctl_facts, 'sysctl_path')

    virtual_sysctl_facts.detect_sysctl()
    assert virtual_sysctl_facts.sysctl_path == '/bin/sysctl'
    assert virtual_sysctl_facts.detect_

# Generated at 2022-06-23 02:41:37.467152
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_lines = {}

        def get_bin_path(self, arg, *args, **kwargs):
            return '/bin/sysctl'

        def run_command(self, args, *kwargs):
            return self.run_command_lines[args]

    class MockFactsCollectorModule(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = MockModule()
            self.sysctl_path = None

    m = MockFactsCollectorModule()
    m.module.run_command_lines = {'/bin/sysctl -n hw.product': (0, 'OpenBSD', '')}

# Generated at 2022-06-23 02:41:42.853406
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    """ Constructor of class VirtualSysctlDetectionMixin
    """
    module = AnsibleModule(argument_spec={})
    class_instance = VirtualSysctlDetectionMixin()
    assert isinstance(class_instance, VirtualSysctlDetectionMixin)


# Generated at 2022-06-23 02:41:53.347448
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    # pylint: disable=missing-docstring
    class FakeModule(object):
        def get_bin_path(self, key):
            return "/usr/bin/sysctl"

        def run_command(self, cmd):
            return 0, "QEMU", None

    mixin = VirtualSysctlDetectionMixin()
    mixin.module = FakeModule()
    virtual_vendor_facts = mixin.detect_virt_vendor("machdep.cpu.brand_string")
    assert 'virtualization_type' in virtual_vendor_facts
    assert 'virtualization_role' in virtual_vendor_facts
    assert 'virtualization_tech_guest' in virtual_vendor_facts
    assert 'virtualization_tech_host' in virtual_vendor_facts

# Generated at 2022-06-23 02:41:54.023942
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert True

# Generated at 2022-06-23 02:42:06.334225
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FakeModule(object):
        def run_command(self, command):
            if command == 'sysctl -n kern.vm_guest':
                return 0, 'OpenBSD', ''
            if command == 'sysctl -n hw.model':
                return 0, 'QEMU', ''
            return 1, 'Unknown', ''

    class FakeOS(object):
        pass

    virtual_vendor_facts = {}

    test_module = FakeModule()
    test_os = FakeOS()
    test_os.sysctl_path = None

    v = VirtualSysctlDetectionMixin()
    virt_vendor_facts = v.detect_virt_vendor('kern.vm_guest', test_module, test_os, virtual_vendor_facts)

# Generated at 2022-06-23 02:42:16.270288
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class TestVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        module = None

    m = TestVirtualSysctlDetectionMixin()

    # Virtualization type
    assert m.detect_virt_product('hw.model') == {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    assert m.detect_virt_product('hw.model') == {
        'virtualization_type': '',
        'virtualization_role': ''
    }

    assert m.detect_virt_product('security.jail.jailed') == {
        'virtualization_type': '',
        'virtualization_role': ''
    }


# Generated at 2022-06-23 02:42:26.943315
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    mod = VirtualSysctlDetectionMixin()
    mod.module = MagicMock()
    key = 'hw.model'

    # Test returned values against expected known values
    mod.module.run_command = MagicMock(return_value=(0, 'KVM', ''))
    facts = mod.detect_virt_product(key)
    assert facts['virtualization_role'] == 'guest'
    assert facts['virtualization_type'] == 'kvm'
    assert 'kvm' in facts['virtualization_tech_guest']
    mod.module.run_command.assert_called_with('sysctl -n hw.model')

    mod.module.run_command = MagicMock(return_value=(0, 'VMware', ''))
    facts = mod.detect_virt_product(key)
    assert facts

# Generated at 2022-06-23 02:42:38.153734
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils.basic import AnsibleModule
    from ansible.module_utils.facts.virtual.freebsd import VirtualSysctlDetectionMixin

    class MyModule(AnsibleModule, VirtualSysctlDetectionMixin):

        def __init__(self, *args, **kwargs):
            super(MyModule, self).__init__(*args, **kwargs)

    sysctl_path = '/usr/sbin/sysctl'

    mymodule = MyModule()
    mymodule.sysctl_path = sysctl_path
    # Physical Machine
    mymodule.sysctl_data = {
        'security.jail.jailed': '0',
        'hw.machine_arch': 'amd64'
    }

# Generated at 2022-06-23 02:42:46.729870
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class BSDModule(object):
        def __init__(self, params):
            self.params = params
            self.virtual_facts = {}
            self.virtual_facts['virtualization_tech_guest'] = set()
            self.virtual_facts['virtualization_tech_host'] = set()
            self.run_command_rc = 0
            self.rc = 0
            self.run_command_out = ''
            self.run_command_err = ''
            self.run_command_called = 0

        def get_bin_path(self, executable):
            return '/bin/' + executable

        def run_command(self, command):
            self.run_command_called += 1
            return self.run_command_rc, self.run_command_out, self.run_command_err


# Generated at 2022-06-23 02:42:57.585891
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    m = AnsibleModule(
        argument_spec=dict(),
    )

    class FooVirtualSysctlDetectionMixin(VirtualSysctlDetectionMixin):
        """
        A subclass of VirtualSysctlDetectionMixin that allows us to mock the
        sysctl(8) command output.
        """
        def __init__(self, module,
                     sysctl_kern_ostype_out=None,
                     sysctl_hw_model_out=None,
                     sysctl_security_jail_jailed_out=None,
        ):
            self.module = module
            self.sysctl_kern_ostype_out = sysctl_kern_ostype_out
            self.sysctl_hw_model_out = sysctl_hw_model_out
            self.sysctl_security_jail_jailed_

# Generated at 2022-06-23 02:42:59.347562
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    assert VirtualSysctlDetectionMixin


# Generated at 2022-06-23 02:43:06.003945
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    import mock
    import tempfile

    # Prepare
    module = mock.MagicMock()
    module.get_bin_path.return_value = tempfile.mkdtemp()

    # Run
    obj = VirtualSysctlDetectionMixin()
    obj.detect_sysctl()

    # Assert
    assert isinstance(obj.sysctl_path, basestring)


# Generated at 2022-06-23 02:43:12.599264
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    module = None
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.sysctl_path = '/sbin/sysctl'
    assert mixin.sysctl_path == '/sbin/sysctl'

    module = None
    mixin = VirtualSysctlDetectionMixin()
    mixin.module = module
    mixin.sysctl_path = None
    assert mixin.sysctl_path == None


# Generated at 2022-06-23 02:43:16.974696
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    from ansible.module_utils.basic import AnsibleModule
    mod = AnsibleModule(
        argument_spec=dict()
    )
    virt_sysctl_detect = VirtualSysctlDetectionMixin()
    virt_sysctl_detect.detect_sysctl()

if __name__ == '__main__':
    test_VirtualSysctlDetectionMixin()

# Generated at 2022-06-23 02:43:26.825936
# Unit test for method detect_sysctl of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_sysctl():
    class mixin:
        def get_bin_path(self, module):
            return '/usr/bin/sysctl'

        def run_command(self, cmd):
            if cmd == '/usr/bin/sysctl -n machdep.cpu.brand_string':
                return 0, 'Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz', ''
            if cmd == '/usr/bin/sysctl -n security.jail.jailed':
                return 0, '1', ''
            if cmd == '/usr/bin/sysctl -n security.jail.enforce_statfs':
                return 0, '0', ''
            if cmd == '/usr/bin/sysctl -n security.jail.enforce_statfs':
                return 0, '1', ''

# Generated at 2022-06-23 02:43:37.201665
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    class BSDModule:
        def get_bin_path(self, binary):
            return 'bin/' + binary

        def run_command(self, command):
            if command == 'bin/sysctl -n hw.virtual_guest':
                return 0, 'KVM', None
            elif command == 'bin/sysctl -n security.jail.jailed':
                return 0, '1', None
            return 1, None, None

    class VirtualSysctlDetectionMixinTester(VirtualSysctlDetectionMixin):
        def __init__(self):
            self.module = BSDModule()
            self.sysctl_path = None

    v = VirtualSysctlDetectionMixinTester()
    result = v.detect_virt_product('hw.virtual_guest')

# Generated at 2022-06-23 02:43:48.050274
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    mixin = VirtualSysctlDetectionMixin()

    if not mixin.sysctl_path:
        mixin.module = FakeModule({'run_command': (1, '', ''),
                                   'get_bin_path': (1, '', '')})
        assert not mixin.detect_virt_vendor('')

    mixin.module = FakeModule({'run_command': (0, 'OpenBSD', ''),
                               'get_bin_path': (1, '', '')})
    s = mixin.detect_virt_vendor('')
    assert s['virtualization_tech_guest'] == set(['vmm'])
    assert s['virtualization_tech_host'] == set()
    assert s['virtualization_type'] == 'vmm'

# Generated at 2022-06-23 02:43:58.228734
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    class FreebsdModule(object):
        def get_bin_path(self, exec_name, required=False, opt_dirs=[]):
            class fake_obj(object):
                def __init__(self, rc, out, err):
                    self.rc = rc
                    self.stdout = out
                    self.stderr = err
            if exec_name == 'sysctl':
                return '/sbin/sysctl'
            return None

        def run_command(self, cmd):
            if 'sysctl -n kern.vm_guest':
                return (0, 'QEMU', None)

            return (0, '', None)

    class VirtualSysctlDetectionMixin_(VirtualSysctlDetectionMixin):
        def __init__(self, module):
            self.module = module


# Generated at 2022-06-23 02:44:08.948128
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    from ansible.module_utils import basic
    from ansible.module_utils.common.os.bsd import virtual
    class MyVirtualSysctlDetectionMixin(basic.AnsibleModule, VirtualSysctlDetectionMixin):
        pass

    m = MyVirtualSysctlDetectionMixin(
        argument_spec={},
    )


# Generated at 2022-06-23 02:44:18.445013
# Unit test for constructor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin():
    '''Unit test for constructor of class VirtualSysctlDetectionMixin'''
    try:
        virtual_sysctl = VirtualSysctlDetectionMixin()
    except:
        assert False, "Unable to instantiate class VirtualSysctlDetectionMixin"

    virtual_sysctl.module = AnsibleModuleMock()
    virtual_sysctl.module.run_command.return_value = (0, '', '')
    virtual_sysctl.module.get_bin_path.return_value = '/some/sysctl/path'

    virtual_sysctl.detect_virt_product('machdep.cpu.features')
    virtual_sysctl.detect_virt_product('security.jail.jailed')
    virtual_sysctl.detect_virt_vendor('hw.vendor')
    virtual_sysctl.det

# Generated at 2022-06-23 02:44:30.103525
# Unit test for method detect_virt_vendor of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_vendor():
    from collections import namedtuple
    from ansible.module_utils.facts.virt.freebsd import VirtualSysctlDetectionMixin

    # Set up mock objects
    sysctl = namedtuple('sysctl', ['bin_path', 'rc', 'stdout', 'stderr'])
    sysctl.bin_path = 'test_bin_path'
    sysctl.rc = 0
    sysctl.stdout = 'QEMU'
    sysctl.stderr = ''
    sysctl.run_command = lambda command: (sysctl.rc, sysctl.stdout, sysctl.stderr)

    # Test with VirtualSysctlDetectionMixin.detect_virt_vendor
    virtualization_type = 'kvm'
    virtualization_role = 'guest'

# Generated at 2022-06-23 02:44:39.126106
# Unit test for method detect_virt_product of class VirtualSysctlDetectionMixin
def test_VirtualSysctlDetectionMixin_detect_virt_product():
    import sys
    if sys.version_info[0] >= 3:
        import unittest.mock as mock
    else:
        import mock
    import shutil
    import tempfile
    import os
    import os.path
    import ansible.module_utils.basic
    class FakeModule(object):

        def __init__(self):
            self.exit_json = mock.MagicMock()
            self.fail_json = mock.MagicMock()
            self.params = {}

        def run_command(self, args, check_rc=True):
            return 0, 'Hyper-V', ''

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/sysctl'
