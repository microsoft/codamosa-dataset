

# Generated at 2022-06-24 03:14:15.520563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY3 is True
    assert pyinfo.PY2 is not True
    assert pyinfo.binary_type is bytes
    assert pyinfo.class_types is type
    assert pyinfo.integer_types is int
    assert pyinfo.maxsize > 0
    assert pyinfo.string_types is str
    assert pyinfo.text_type is str


# Generated at 2022-06-24 03:14:18.636623
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:14:21.271536
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in dir(PyInfo):
        if not attr.startswith("__"):
            assert (getattr(PyInfo, attr) is not None)

# Generated at 2022-06-24 03:14:32.204532
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check if all expected attributes and members are set
    assert hasattr(PyInfo, "PY2")
    assert hasattr(PyInfo, "PY3")
    assert hasattr(PyInfo, "string_types")
    assert hasattr(PyInfo, "text_type")
    assert hasattr(PyInfo, "binary_type")
    assert hasattr(PyInfo, "integer_types")
    assert hasattr(PyInfo, "class_types")

    # check is attribute has expected type
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-24 03:14:39.692430
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:14:46.680761
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert not isinstance(b"binary", PyInfo.string_types)
    assert isinstance("string", PyInfo.text_type)
    assert not isinstance(u"unicode", PyInfo.text_type)
    assert not isinstance(b"binary", PyInfo.text_type)
    assert isinstance(b"binary", PyInfo.binary_type)
    assert not isinstance("string", PyInfo.binary_type)
    assert not isinstance(u"unicode", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-24 03:14:55.878312
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:03.238775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    @classmethod
    def _test_classmethod(cls):
        assert cls == PyInfo

    PyInfo._test_classmethod()

    if PyInfo.PY3:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(100, PyInfo.integer_types)
    else:  # PyInfo.PY2
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(100, PyInfo.integer_types)



# Generated at 2022-06-24 03:15:06.252309
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:15:10.409755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True, "PyInfo.PY2 or PyInfo.PY3 is False"
    assert PyInfo.PY2 is False or PyInfo.PY3 is False, "PyInfo.PY2 and PyInfo.PY3 are True"


test_PyInfo()

# Generated at 2022-06-24 03:15:11.771349
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True
    pass


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-24 03:15:17.287305
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == ((2 ** 32 - 1) if (
            sys.platform.startswith("java")) else ((2 ** 31 - 1) if (
            sys.maxsize < (2 ** 31)) else (2 ** 63 - 1)))

# Generated at 2022-06-24 03:15:27.156228
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert type("a") is PyInfo.text_type
        assert type("a".encode()) is PyInfo.binary_type
        assert type(1) in PyInfo.integer_types
        assert type(1) is not PyInfo.integer_types
        assert type(int) in PyInfo.class_types

    elif PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert type("a") is PyInfo.text_type
        assert type("a".encode()) is PyInfo.binary_type
        assert type(1) in PyInfo.integer_types
        assert type(1) is not PyInfo.integer_types
        assert type(int) in PyInfo.class_types



# Generated at 2022-06-24 03:15:29.517387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == sys.version_info[0] == 2
    assert PyInfo().PY3 == sys.version_info[0] == 3

# Generated at 2022-06-24 03:15:38.716804
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == int
        assert PyInfo.class_types == type

if __name__ == "__main__":
    test_PyInfo()
    print("everything passed")

# Generated at 2022-06-24 03:15:44.820785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0


# Run unit tests
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:53.853719
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("Hello Py3!", str)
        assert not isinstance("Hello Py2!", str)
        assert not isinstance("Hello Py2!", bytes)
        assert isinstance("Hello Py3!", PyInfo.string_types)
        assert isinstance("Hello Py2!", (str, bytes))
    else:
        assert isinstance("Hello Py2!", basestring)
        assert not isinstance("Hello Py3!", basestring)
        assert isinstance("Hello Py2!", PyInfo.string_types)
        assert isinstance("Hello Py3!", (str, unicode))

# Generated at 2022-06-24 03:16:02.509344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Checking the module PyInfo")

    my_pyinfo = PyInfo()
    print("Python version is Python2 or Python3:", my_pyinfo.PY2 or my_pyinfo.PY3)
    print("string_types is", my_pyinfo.string_types)
    print("text_type is", my_pyinfo.text_type)
    print("binary_type is", my_pyinfo.binary_type)
    print("integer_types is", my_pyinfo.integer_types)
    print("class_types is", my_pyinfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:12.140925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,), "PyInfo.string_types should be '%s', but got '%s'" % ((str,), PyInfo.string_types)
        assert PyInfo.text_type == str, "PyInfo.text_type should be '%s', but got '%s'" % (str, PyInfo.text_type)
        assert PyInfo.binary_type == bytes, "PyInfo.binary_type should be '%s', but got '%s'" % (bytes, PyInfo.binary_type)
        assert PyInfo.integer_types == (int,), "PyInfo.integer_types should be '%s', but got '%s'" % ((int,), PyInfo.integer_types)

# Generated at 2022-06-24 03:16:14.454405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None



# Generated at 2022-06-24 03:16:20.046827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()
    assert pyi.PY2 is True or pyi.PY2 is False
    assert pyi.PY3 is True or pyi.PY3 is False


# Return if given object is ***string***

# Generated at 2022-06-24 03:16:24.051032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert 1 in PyInfo.string_types
    assert '1' in PyInfo.string_types
    assert 1.0 in PyInfo.string_types
    assert u'1' in PyInfo.string_types
    assert u'123' in PyInfo.string_types


test_PyInfo()

# Generated at 2022-06-24 03:16:26.756208
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> import sys
    >>> assert (sys.version_info[0] == 2) == PyInfo.PY2
    >>> assert (sys.version_info[0] == 3) == PyInfo.PY3
    """
    pass

# Generated at 2022-06-24 03:16:34.434082
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert not (PyInfo.PY3 and PyInfo.PY2)
    assert not (PyInfo.PY2 and not PyInfo.PY3)
    assert not (PyInfo.PY3 and not PyInfo.PY2)

    max_size = sys.maxsize
    assert max_size == sys.maxsize

    maxsize = PyInfo.maxsize
    assert maxsize == sys.maxsize



# Generated at 2022-06-24 03:16:43.775712
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    py_info = PyInfo()
    if sys.version_info[0] == 3:
        assert isinstance(py_info.string_types, tuple)
        assert isinstance(py_info.string_types[0], str)
        assert isinstance(py_info.text_type, str)
        assert isinstance(py_info.binary_type, bytes)
        assert isinstance(py_info.integer_types, tuple)
        assert isinstance(py_info.integer_types[0], int)
        assert isinstance(py_info.class_types, (type, tuple))
        assert isinstance(py_info.class_types[0], type)
        assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-24 03:16:45.147307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:16:55.863517
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert sys.maxsize == PyInfo.maxsize

    assert int in PyInfo.integer_types
    assert str in PyInfo.string_types
    assert unicode in PyInfo.string_types
    assert bytes in PyInfo.string_types
    assert type in PyInfo.class_types
    assert PyInfo.class_types == (type,)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
    else:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:17:03.462235
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    @attention: This function is not a testcase,
                just for PyInfo class testing
    '''
    if PyInfo.PY3:
        assert str == PyInfo.string_types[0]
        assert str == PyInfo.text_type
        assert bytes == PyInfo.binary_type
        assert int == PyInfo.integer_types[0]
        assert type == PyInfo.class_types
        assert sys.maxsize == PyInfo.maxsize

    else:  # PY2
        assert basestring == PyInfo.string_types[0]
        assert unicode == PyInfo.text_type
        assert str == PyInfo.binary_type
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert 1 << 31 == PyInfo.maxsize
       

# Generated at 2022-06-24 03:17:07.920065
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True
    assert pi.PY3 is False
    assert pi.string_types == (basestring,)
    assert pi.text_type == unicode
    assert pi.binary_type == str
    assert pi.integer_types == (int, long)
    assert pi.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:17:14.219967
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (str, unicode)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:17:18.943210
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize == 2 ** 63 - 1


if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-24 03:17:24.339736
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PyInfo.PY2 is %r" % PyInfo.PY2)
    print("PyInfo.PY3 is %r" % PyInfo.PY3)

    print("PyInfo.string_types is %r" % PyInfo.string_types)
    print("PyInfo.text_type is %r" % PyInfo.text_type)
    print("PyInfo.binary_type is %r" % PyInfo.binary_type)
    print("PyInfo.integer_types is %r" % PyInfo.integer_types)
    print("PyInfo.class_types is %r" % PyInfo.class_types)

    print("PyInfo.maxsize is %r" % PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:30.920848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:17:37.742223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

    assert isinstance('abc', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'abc', PyInfo.string_types)
    else:
        assert not isinstance(u'abc', PyInfo.string_types)

    assert isinstance(u'abc', PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.text_type)
    else:
        assert not isinstance('abc', PyInfo.text_type)

    assert isinstance('abc', PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance(u'abc', PyInfo.binary_type)
    else:
        assert not isinstance(u'abc', PyInfo.binary_type)



# Generated at 2022-06-24 03:17:47.096138
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.class_types)


# Test cases for PyInfo class

# Generated at 2022-06-24 03:17:54.814488
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    # Test for string types
    types = PyInfo.string_types
    for t in types:
        assert t in [str, unicode]
    # Test for text type
    assert PyInfo.text_type in [str, unicode]
    # Test for binary type
    assert PyInfo.binary_type in [str, bytes]
    # Test for integer types
    types = PyInfo.integer_types
    for t in types:
        assert t in [int, long]
    # Test for class types
    types = PyInfo.class_types
    for t in types:
        assert t in [type, types.ClassType]
    # Test for max size

# Generated at 2022-06-24 03:18:00.402315
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    print(PyInfo.PY2)
    print(PyInfo.maxsize)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


test_PyInfo()

# Generated at 2022-06-24 03:18:04.691289
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:  # pragma: no cover
        # Python v2.x
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # pragma: no cover
        # Python v3.x
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


# EOF

# Generated at 2022-06-24 03:18:10.780496
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 == False

    assert sys.version_info[0] == 2

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance('abc', PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:18:14.688019
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> assert(PyInfo.PY2 or PyInfo.PY3)
    >>> assert(isinstance(PyInfo.maxsize, int))
    """

# Generated at 2022-06-24 03:18:21.842063
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:18:26.183571
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
    elif sys.version_info[0] == 3:
        assert PyInfo.PY3 is True
        assert PyInfo.PY2 is False

# Generated at 2022-06-24 03:18:29.142322
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        ''.encode('ascii')
    except UnicodeEncodeError:
        assert PyInfo.PY2
    else:
        assert PyInfo.PY3

# Generated at 2022-06-24 03:18:35.718647
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


import unittest
import sys



# Generated at 2022-06-24 03:18:42.888126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:18:46.296382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == (1 << 31) - 1
    else:
        assert PyInfo.maxsize == (1 << 63) - 1



# Generated at 2022-06-24 03:18:56.268326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance("abcde", PyInfo.string_types)
        assert isinstance(u"abcde", PyInfo.string_types)
        assert isinstance(b"abcde", PyInfo.binary_type)
        assert isinstance(123456, PyInfo.integer_types)
        assert isinstance(long(123456), PyInfo.integer_types)
        assert isinstance(dict, PyInfo.class_types)
        assert isinstance(PyInfo, PyInfo.class_types)
        assert not hasattr(PyInfo, "text_type")
    else:
        assert isinstance("abcde", PyInfo.string_types)
        assert isinstance(b"abcde", PyInfo.binary_type)

# Generated at 2022-06-24 03:19:01.769163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


test_PyInfo()

# Generated at 2022-06-24 03:19:08.139801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.PY2 is sys.version_info[0] == 2
    assert info.PY3 is sys.version_info[0] == 3


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_PyInfo()
    print("done")

# Generated at 2022-06-24 03:19:10.649398
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:20.606817
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
        assert not isinstance('str', PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:31.053157
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(test_PyInfo, PyInfo.class_types)
    assert len(bytes(PyInfo.maxsize)) == len(PyInfo.maxsize.to_bytes(len(PyInfo.maxsize), 'little'))
    assert len(bytes(PyInfo.maxsize)) == (PyInfo.maxsize.bit_length() + 7) // 8


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:34.102294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pprint
    pprint.pprint(PyInfo.__dict__)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:39.478540
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None

    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None

    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None

    assert PyInfo.maxsize is not None

# Generated at 2022-06-24 03:19:45.995701
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)
    else:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int,)
        assert pyinfo.class_types == (type,)

# Generated at 2022-06-24 03:19:53.142258
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:19:58.951161
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test PyInfo.PY2
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    # Test PyInfo.PY3
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test PyInfo.maxsize
    assert PyInfo.maxsize == (1 << 31) - 1


# Test is_string

# Generated at 2022-06-24 03:20:05.151482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 2:
        assert PyInfo.string_types is (basestring,)
    else:
        assert PyInfo.string_types is (str,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:12.846345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert "abc" in PyInfo.string_types
    assert u"abc" in PyInfo.string_types
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.string_types)
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(str, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:16.067372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert 2 == PyInfo.PY2
    assert 3 == PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:26.392892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(0, PyInfo.string_types)
    assert not isinstance(2.5, PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(0, PyInfo.text_type)
    assert not isinstance(2.5, PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(0, PyInfo.binary_type)
    assert not isinstance(2.5, PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0xffffffff, PyInfo.integer_types)
    assert not isinstance(0.0, PyInfo.integer_types)


# Generated at 2022-06-24 03:20:35.102305
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:20:40.069676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert hasattr(PyInfo, 'PY2')
    assert hasattr(PyInfo, 'PY3')
    assert hasattr(PyInfo, 'text_type')
    assert hasattr(PyInfo, 'binary_type')
    assert hasattr(PyInfo, 'maxsize')


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 03:20:49.383754
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    if p.PY2:
        assert isinstance(p.maxsize, long)
    else:
        assert isinstance(p.maxsize, int)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:56.417698
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:21:05.472304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Unknown version of Python"

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert not isinstance(3, PyInfo.string_types)
    assert not isinstance(3.0, PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(None, PyInfo.text_type)
    assert not isinstance(3, PyInfo.text_type)
    assert not isinstance(3.0, PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(None, PyInfo.binary_type)

# Generated at 2022-06-24 03:21:10.907485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # This constructor should be called from py2 and py3
    assert PyInfo.PY2 or PyInfo.PY3

    # Check for attributes
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-24 03:21:16.964141
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] == PyInfo.text_type or PyInfo.string_types[0] == PyInfo.binary_type

    assert len(PyInfo.integer_types) == 2

    assert len(PyInfo.class_types) == 2

    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-24 03:21:20.149593
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyInfo = PyInfo()
    assert pyInfo.PY2, pyInfo.PY2
    assert pyInfo.PY3, pyInfo.PY3

# Generated at 2022-06-24 03:21:25.361184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    return True



# Generated at 2022-06-24 03:21:36.679515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('', PyInfo.string_types)
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance('12345', PyInfo.string_types)

    if PyInfo.PY2:
        assert PyInfo.string_types == (str, unicode, basestring)
        assert not isinstance('', PyInfo.binary_type)
    else:
        assert PyInfo.string_types == (str,)
        assert isinstance('', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.1, PyInfo.integer_types)

# Generated at 2022-06-24 03:21:40.323841
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert(isinstance(1, PyInfo.integer_types))
        assert(isinstance('hello', PyInfo.string_types))
    else:
        assert(isinstance('hello', PyInfo.string_types))

# Generated at 2022-06-24 03:21:48.187931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    class Dummy(object):
        pass

    dummy = Dummy()
    dummy.__class__ = type

    for x in [
        "",
        "abc",
        b"abc",
        1,
        1.0,
        1 << 31,
        1 << 63,
        dummy,
    ]:
        assert type(x) in PyInfo.class_types
        assert type(x) in PyInfo.integer_types
        assert type(x) in PyInfo.string_types
        assert type(x) in PyInfo.text_type
        assert type(x) in PyInfo.binary_type

# Generated at 2022-06-24 03:21:52.875372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance('str', PyInfo.text_type)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:00.916436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("string_types:", PyInfo.string_types)
    print("text_type:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)
    print("maxsize:", PyInfo.maxsize)


# test_PyInfo()



# Generated at 2022-06-24 03:22:09.405967
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('Jarek', PyInfo.string_types)
        assert isinstance(b'Jarek', PyInfo.binary_type)
        assert isinstance(u'Jarek', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance('Jarek', PyInfo.string_types)
        assert isinstance('Jarek', PyInfo.binary_type)
        assert isinstance(u'Jarek', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:13.631358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type(''.decode('utf-8')) is PyInfo.text_type
    assert type(''.encode('utf-8')) is PyInfo.binary_type
    assert type(1 << 63 - 1) is PyInfo.integer_types[-1]
    assert type(type) is PyInfo.class_types[-1]

# Generated at 2022-06-24 03:22:23.284349
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_PyInfo_with_PY3():
        assert PyInfo.PY2 == False
        assert PyInfo.PY3 == True
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

    def test_PyInfo_with_PY2():
        sys.version_info[0] = 2
        reload(pyinfo)
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False
        PY2_string_types = PyInfo.string_types
        assert PY2_string_types == (basestring,)

# Generated at 2022-06-24 03:22:31.716264
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

    assert PyInfo.maxsize == sys.maxsize

    assert isinstance(PyInfo.string_types, tuple)
    assert u'foo' in PyInfo.string_types
    assert 'foo' in PyInfo.string_types

    assert isinstance(PyInfo.string_types, tuple)
    assert u'foo' in PyInfo.string_types
    assert 'foo' in PyInfo.string_types

    assert PyInfo.text_type == unicode  # noqa: F821
    assert isinstance(u'foo', PyInfo.text_type)
    assert not isinstance('foo', PyInfo.text_type)

    assert PyInfo.binary_type == str
    assert isinstance(b'foo', PyInfo.binary_type)

# Generated at 2022-06-24 03:22:41.420599
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2 or x.PY3
    assert len(x.string_types) == 1
    if x.PY3:
        assert x.string_types == (str,)
    else:
        assert x.string_types == (basestring,)
    assert len(x.integer_types) == 2
    if x.PY3:
        assert x.integer_types == (int,)
    else:
        assert x.integer_types == (int, long)
    assert len(x.class_types) == 2
    if x.PY3:
        assert x.class_types == (type,)
    else:
        assert x.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:22:45.666304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)



# Generated at 2022-06-24 03:22:52.958919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert hasattr(pyinfo, 'PY2')
    assert hasattr(pyinfo, 'PY3')
    assert hasattr(pyinfo, 'binary_type')
    assert hasattr(pyinfo, 'text_type')
    assert hasattr(pyinfo, 'string_types')
    assert hasattr(pyinfo, 'integer_types')
    assert hasattr(pyinfo, 'class_types')
    assert pyinfo.PY2 or pyinfo.PY3

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:02.062665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert not isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert not isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:04.361209
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()


if __name__ == '__main__':

    test_PyInfo()

# Generated at 2022-06-24 03:23:14.997628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    if not PyInfo.PY2:
        assert not isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:22.312809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.maxsize) is int
    if PyInfo.PY2:
        assert PyInfo.maxsize > (1 << 31) - 1
    else:
        assert PyInfo.maxsize == (1 << 31) - 1

    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'str', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert not isinstance(b'bytes', PyInfo.text_type)
    assert isinstance(b'bytes', PyInfo.string_types)
    assert isinstance(u'bytes', PyInfo.string_types)
    assert isinstance(u'bytes', PyInfo.binary_type)



# Generated at 2022-06-24 03:23:24.000047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-24 03:23:30.240032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-24 03:23:30.828044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-24 03:23:32.555069
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2



# Generated at 2022-06-24 03:23:36.601682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(b"str", PyInfo.binary_type)
    assert isinstance(u"str", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:42.467223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test class and instance
    assert isinstance(PyInfo, object)
    assert isinstance(PyInfo, (type, types.ClassType))
    assert isinstance(PyInfo, (type, types.ClassType))
    assert isinstance(PyInfo(), object)

    # Test attributes
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # Test constants
    assert PyInfo.PY2 is not True

# Generated at 2022-06-24 03:23:52.418343
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2  # or PY3
    assert PyInfo.PY3  # or not PY3
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type  # str or unicode
    assert type(PyInfo.binary_type) is type  # bytes or str
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple


del sys, types

# ----------------------------------------------------------------------------
# Patch py3k warnings
# ----------------------------------------------------------------------------
if PyInfo.PY3:
    import warnings

    warnings.filterwarnings("ignore", ".*mimetools has been removed",
                            DeprecationWarning)

# Generated at 2022-06-24 03:23:56.523621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo.PY2 or PyInfo.PY3
        assert PyInfo.PY2 != PyInfo.PY3
        assert PyInfo.maxsize > 0
    except:
        print(PyInfo.PY2)
        print(PyInfo.PY3)
        print(PyInfo.maxsize)



# Generated at 2022-06-24 03:23:57.819477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:24:01.183943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-24 03:24:08.662926
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

