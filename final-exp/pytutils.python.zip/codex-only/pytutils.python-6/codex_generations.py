

# Generated at 2022-06-24 03:14:11.014389
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    This also shows the attributes available in class PyInfo
    """
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == (2 ** 63) - 1 if (sys.version_info[0] == 2) else sys.maxsize


test_PyInfo()

# Generated at 2022-06-24 03:14:22.106448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert (isinstance(pyinfo.string_types, tuple))
    assert (isinstance(pyinfo.class_types, tuple))
    assert (isinstance(pyinfo.integer_types, tuple))
    assert (isinstance(pyinfo.maxsize, int))
    if pyinfo.PY2:
        assert (pyinfo.string_types == (basestring,))
        assert (pyinfo.text_type is unicode)
        assert (pyinfo.binary_type is str)
        assert (isinstance(pyinfo.class_types, tuple))
        assert (isinstance(pyinfo.integer_types, tuple))
    else:
        assert (pyinfo.string_types == (str,))
        assert (pyinfo.text_type is str)

# Generated at 2022-06-24 03:14:25.980188
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance('s', PyInfo.integer_types)
    assert isinstance('s', PyInfo.string_types)
    assert isinstance('s', PyInfo.text_type)
    assert isinstance(b'b', PyInfo.binary_type)
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-24 03:14:32.952457
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        b = chr(0x41)
        assert isinstance(b, PyInfo.binary_type)
        assert not isinstance(b, PyInfo.text_type)
        if sys.version_info[1] < 7:
            assert isinstance(b, PyInfo.string_types)
        else:
            assert not isinstance(b, PyInfo.string_types)
    else:  # PY3
        b = bytes(0x41)
        assert isinstance(b, PyInfo.binary_type)
        assert not isinstance(b, PyInfo.text_type)
        assert not isinstance(b, PyInfo.string_types)

    t = u'A'
    assert not isinstance(t, PyInfo.binary_type)

# Generated at 2022-06-24 03:14:38.213769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3
    # string_types = basestring,
    # text_type = unicode
    # binary_type = str
    # integer_types = (int, long)
    # class_types = (type, types.ClassType)
    # maxsize = int((1 << 31) - 1)

# Generated at 2022-06-24 03:14:41.279137
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(b'', bytes)
        assert isinstance('', str)
        assert isinstance(1, int)
    else:
        assert isinstance(b'', str)
        assert isinstance(u'', unicode)
        assert isinstance(1, (int, long))

# Generated at 2022-06-24 03:14:52.468645
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert type('str') in PyInfo.string_types
    if PyInfo.PY3:
        assert type('str') in PyInfo.string_types
        assert type(u'unicode') in PyInfo.string_types
    assert type(3) in PyInfo.integer_types

# Generated at 2022-06-24 03:14:56.027754
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type("") in PyInfo.string_types
    assert type("") == PyInfo.text_type
    assert isinstance("", PyInfo.binary_type)
    assert type(1) in PyInfo.integer_types
    assert type(int) in PyInfo.class_types



# Generated at 2022-06-24 03:15:02.059005
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:15:12.244538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo"""
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert False, "You are using a language other than Python 2 or 3."



# Generated at 2022-06-24 03:15:19.970109
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info
    assert isinstance(py_info, PyInfo)
    assert isinstance(py_info.PY2, bool)
    assert isinstance(py_info.PY3, bool)
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)
    assert py_info.PY2 == py_info.PY3 == False
    assert py_info.string_types == (basestring,)
    assert py_info.text_

# Generated at 2022-06-24 03:15:24.876300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.binary_type)



# Generated at 2022-06-24 03:15:28.202605
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == 2147483647


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:15:29.878679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:33.894585
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)

    assert isinstance(111, PyInfo.integer_types)
    assert isinstance(long(111), PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-24 03:15:43.867897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-24 03:15:54.544500
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('python version:', PyInfo.PY3, PyInfo.PY2)
    assert PyInfo.PY3 or PyInfo.PY2

    if PyInfo.PY3:
        assert isinstance('123', PyInfo.string_types)
        assert isinstance(b'123', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance(u'123', PyInfo.string_types)
        assert isinstance('123', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    print('test_PyInfo OK')


# test_PyInfo()

# Generated at 2022-06-24 03:16:05.045466
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 and PY3 do not exist at this point
    py2 = sys.version_info[0] == 2
    py3 = sys.version_info[0] == 3

    # After the constructor, PY2 and PY3 should exist
    assert py2 == PyInfo.PY2
    assert py3 == PyInfo.PY3

    # Test text_type
    assert isinstance(u'test', PyInfo.text_type)
    assert not isinstance(b'test', PyInfo.text_type)
    assert isinstance('test', PyInfo.text_type)

    # Test binary_type
    assert isinstance(b'test', PyInfo.binary_type)
    assert not isinstance(u'test', PyInfo.binary_type)
    assert isinstance('test', PyInfo.binary_type)

# Generated at 2022-06-24 03:16:09.914229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert issubclass(type(sys.version_info), tuple)
    assert issubclass(type(types.ClassType), type)
    assert issubclass(type(types.NoneType), type)
    assert issubclass(type(types.TypeType), type)
    assert issubclass(type(object), type)



# Generated at 2022-06-24 03:16:12.024687
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version is expected to be either Python 2 or Python 3"


# Generated at 2022-06-24 03:16:14.454170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('python version {}'.format(PyInfo.PY2))


# Unit test to check values in class PyInfo

# Generated at 2022-06-24 03:16:20.289309
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)


# for unittest
if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:25.311469
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # These tests need to be in a function to avoid errors on Python 2.6
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert "".encode("utf-8").__class__ is PyInfo.binary_type
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(2**100, PyInfo.integer_types)



# Generated at 2022-06-24 03:16:37.243928
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_true, assert_false, assert_equal
    from .PyInfo import PyInfo

    if sys.version_info[0] == 2:
        assert_true(PyInfo.PY2)
        assert_false(PyInfo.PY3)
        assert_equal(PyInfo.string_types, (basestring,))
        assert_equal(PyInfo.text_type, unicode)
        assert_equal(PyInfo.binary_type, str)
        assert_equal(PyInfo.integer_types, (int, long))
        assert_equal(PyInfo.class_types, (type, types.ClassType))
        assert_equal(PyInfo.maxsize, sys.maxsize)


# Generated at 2022-06-24 03:16:45.251551
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    if PyInfo.PY3:
        # Python 3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        # Python 2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-24 03:16:53.057237
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, (int, long))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:01.546202
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename.startswith("test_") and basename.endswith(".py"):
        # It's a unit test.
        exec (open(sys.argv[0]).read())
    else:
        # It's an inteactive usage.
        import doctest

        doctest.testmod()

# Generated at 2022-06-24 03:17:09.526989
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(0.0, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:19.811980
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_equal(x, y):
        assert x == y, "Expected {}, got {}".format(x, y)
        return x

    assert_equal(PyInfo.PY2, sys.version_info[0] == 2)
    assert_equal(PyInfo.PY3, sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert_equal(PyInfo.string_types, (basestring,))
        assert_equal(PyInfo.text_type, unicode)
        assert_equal(PyInfo.binary_type, str)
        assert_equal(PyInfo.integer_types, (int, long))
        assert_equal(PyInfo.class_types, (type, types.ClassType))


# Generated at 2022-06-24 03:17:23.051055
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 1 or PyInfo.PY2 == 0
    assert PyInfo.PY3 == 1 or PyInfo.PY3 == 0
    assert (PyInfo.PY2 or PyInfo.PY3) == 1



# Generated at 2022-06-24 03:17:28.217119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY3
    assert PyInfo.PY2
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.text_type == unicode

# Generated at 2022-06-24 03:17:33.679896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":  # pragma: no-cover
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 03:17:39.455436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('-' * 50)
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types, tuple)
    print(PyInfo.text_type, str, unicode)
    print(PyInfo.binary_type, bytes, str)
    print(PyInfo.integer_types, int, long)
    print(PyInfo.class_types, type, types.ClassType)
    print(PyInfo.maxsize, sys.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:49.422117
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # StringType
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(unicode(""), PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)

    # TextType
    assert isinstance("", PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(unicode(""), PyInfo.text_type)
    else:
        assert not isinstance("", PyInfo.text_type)

    # BinaryType
    assert isinstance(b"", PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance("", PyInfo.binary_type)
    else:
        assert not isinstance("", PyInfo.binary_type)

    # IntegerType
   

# Generated at 2022-06-24 03:17:57.731283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize < 0


# Test variable PyInfo.PY3

# Generated at 2022-06-24 03:18:04.341254
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:09.368136
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for k in dir(PyInfo):
        if k.startswith('_'):
            continue
        else:
            assert k in ("PY2", "PY3", "string_types", "text_type", "binary_type", "integer_types", "maxsize")
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-24 03:18:17.858672
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3  # Cannot be both true
    if PyInfo.PY3:
        for x in PyInfo.string_types:
            assert isinstance("a", x)
        for x in PyInfo.integer_types:
            assert isinstance(5, x)
    else:
        for x in PyInfo.string_types:
            assert isinstance(u"a", x)

# Generated at 2022-06-24 03:18:24.986656
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 is True or PyInfo().PY2 is False
    assert PyInfo().PY3 is True or PyInfo().PY3 is False
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().class_types, tuple)
    assert isinstance(PyInfo().maxsize, int)
    if PyInfo().PY2:
        assert isinstance(PyInfo().string_types[0], type)
        assert issubclass(PyInfo().text_type, PyInfo().string_types[0])
        assert isinstance(PyInfo().integer_types[0], type)

# Generated at 2022-06-24 03:18:30.845791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
    else:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:18:39.034009
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test if it is a singleton
    if PyInfo.PY2:
        assert(PyInfo().PY2 == True)
        assert(PyInfo().PY3 == False)
        assert(PyInfo.PY2 == True)
        assert(PyInfo.PY3 == False)

        assert(PyInfo().string_types == (basestring,))
        assert(PyInfo().text_type == unicode)
        assert(PyInfo().binary_type == str)
        assert(PyInfo().integer_types == (int, long))
        assert(PyInfo().class_types == (type, types.ClassType))
    else:
        assert(PyInfo().PY2 == False)
        assert(PyInfo().PY3 == True)
        assert(PyInfo.PY2 == False)

# Generated at 2022-06-24 03:18:46.896444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b"test", PyInfo.string_types)
        assert isinstance("test", PyInfo.string_types)
        assert isinstance(b"test".decode("utf-8"), PyInfo.text_type)
        assert isinstance("test", PyInfo.text_type)
        assert isinstance(b"test", PyInfo.binary_type)
        assert isinstance(b"test", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-24 03:18:51.413167
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)

# Generated at 2022-06-24 03:18:57.043568
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from tests.unit.base.types import get_object_attrs_exam

    @decorators.singleton
    class TestClass:
        pass

    obj = TestClass()
    for attr in get_object_attrs_exam(obj):
        print('%s: %s' % (attr['name'], attr['value']))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:05.354689
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test", PyInfo.text_type)

    assert isinstance(b"test", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:07.483148
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3



# Generated at 2022-06-24 03:19:15.144495
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('test', PyInfo.string_types)
    assert isinstance('test', PyInfo.text_type)
    assert isinstance(b'test', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert PyInfo.maxsize >= (1 << 31) - 1
    assert PyInfo.maxsize <= (1 << 63) - 1


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:19:18.261653
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == sys.version_info[0] == 2

    assert PyInfo().PY3 == sys.version_info[0] == 3

# test for string_types

# Generated at 2022-06-24 03:19:24.418538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info, PyInfo), 'py_info should be an instance of `PyInfo`'
    assert py_info.maxsize == sys.maxsize, 'maxsize of py_info should be sys.maxsize'
    if PyInfo.PY3:
        assert py_info.string_types == (str, ), 'string_types of py_info should (str, )'
        assert py_info.text_type == str, 'text_type of py_info should str'
        assert py_info.binary_type == bytes, 'binary_type of py_info should bytes'
        assert py_info.integer_types == (int, ), 'integer_types of py_info should (int, )'

# Generated at 2022-06-24 03:19:27.385976
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

# Generated at 2022-06-24 03:19:35.946324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing static attributes of class PyInfo")
    pyinfo = PyInfo()
    assert pyinfo.PY2 == True
    assert pyinfo.PY3 == False
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    assert pyinfo.maxsize == (1 << 63) - 1



# Generated at 2022-06-24 03:19:37.563282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-24 03:19:46.064302
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global pyinfo
    pyinfo = PyInfo()

    assert type(pyinfo.PY2) is bool
    assert type(pyinfo.PY3) is bool

    if pyinfo.PY3:
        assert type(pyinfo.string_types) is tuple
        assert type(pyinfo.text_type) is type
        assert type(pyinfo.binary_type) is type
        assert type(pyinfo.integer_types) is tuple
        assert type(pyinfo.class_types) is tuple

        assert type(pyinfo.maxsize) is int
    else:
        assert type(pyinfo.string_types) is tuple
        assert type(pyinfo.text_type) is type
        assert type(pyinfo.binary_type) is type
        assert type(pyinfo.integer_types) is tuple

# Generated at 2022-06-24 03:19:51.529677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (sys.version_info[0] == 2)
    assert p.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 2:
        assert p.maxsize == sys.maxint
    else:
        assert p.maxsize == sys.maxsize

# Generated at 2022-06-24 03:20:03.096621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import json
    import types

    js_str = json.dumps(PyInfo.__dict__)

    vars = json.loads(js_str)
    assert '__dict__' not in vars
    assert vars['PY2'] == PyInfo.PY2
    assert vars['PY3'] == PyInfo.PY3

    assert isinstance(vars['string_types'], list)
    assert isinstance(PyInfo.string_types, tuple)

    if PyInfo.PY2:
        assert len(vars['string_types']) == 2
        assert vars['string_types'][0] == 'basestring'
        assert vars['string_types'][1] == '__builtin__.unicode'
        assert isinstance(PyInfo.text_type, type)
       

# Generated at 2022-06-24 03:20:12.361229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_type)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_type)
        assert isinstance(type(PyInfo), PyInfo.class_type)
    else:  # PY2
        assert not isinstance(u"", PyInfo.string_type)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert not isinstance(1, PyInfo.integer_type)
        assert not isinstance(type(PyInfo), PyInfo.class_type)


# Generated at 2022-06-24 03:20:20.865674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.text_type)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert 1 << 31 == 2147483648
        assert isinstance(1 << 31, PyInfo.integer_types)
        assert not isinstance(1 << 63, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(type(sys), PyInfo.class_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.string_types)

# Generated at 2022-06-24 03:20:29.857095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_cases = [
        (PyInfo.PY2, "PY2"),
        (PyInfo.PY3, "PY3"),
        (PyInfo.string_types, "string_types"),
        (PyInfo.text_type, "text_type"),
        (PyInfo.binary_type, "binary_type"),
        (PyInfo.integer_types, "integer_types"),
        (PyInfo.class_types, "class_types"),
        (PyInfo.maxsize, "maxsize"),
    ]

    for case, name in test_cases:
        print(name, type(case), case)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:38.607463
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    print()
    print("py_info = PyInfo()")
    print("py_info.PY2 = {}".format(py_info.PY2))
    print("py_info.PY3 = {}".format(py_info.PY3))
    print("py_info.string_types = {}".format(py_info.string_types))
    print("py_info.text_type = {}".format(py_info.text_type))
    print("py_info.binary_type = {}".format(py_info.binary_type))
    print("py_info.integer_types = {}".format(py_info.integer_types))
    print("py_info.class_types = {}".format(py_info.class_types))

# Generated at 2022-06-24 03:20:49.184820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo.PY2
    except Exception:
        assert PyInfo.PY3
    try:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    except Exception:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    import os
    import sys

# Generated at 2022-06-24 03:20:54.997251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:21:04.337560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    if PyInfo.PY2:
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.integer_types, type)
        assert isinstance(PyInfo.class_types, type)
        assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:21:07.665866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:21:18.220886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert True is (PyInfo.string_types == (basestring,))
        assert True is (PyInfo.text_type == unicode)
        assert True is (PyInfo.binary_type == str)
        assert True is (PyInfo.integer_types == (int, long))
        assert True is (PyInfo.class_types == (type, types.ClassType))
    else:
        assert True is (PyInfo.string_types == (str,))
        assert True is (PyInfo.text_type == str)
        assert True is (PyInfo.binary_type == bytes)
        assert True is (PyInfo.integer_types == (int,))
        assert True is (PyInfo.class_types == (type,))

    return True

# Generated at 2022-06-24 03:21:22.422155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    assert py_info.binary_type == bytes
    assert py_info.text_type == str
    assert py_info.class_types == type

# Generated at 2022-06-24 03:21:28.669118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert (
        isinstance("abc", PyInfo.string_types)
        and isinstance("abc", PyInfo.text_type)
        and isinstance("abc".encode("utf-8"), PyInfo.binary_type)
        and isinstance(123, PyInfo.integer_types)
        and isinstance(int, PyInfo.class_types)
    )

# Generated at 2022-06-24 03:21:38.411737
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types[0], str)
        assert PyInfo.string_types[0] == "abcd"
        assert isinstance(PyInfo.text_type, str)
        assert PyInfo.text_type == "abcd"
        assert isinstance(PyInfo.binary_type, bytes)
        assert PyInfo.binary_type == b"abcd"
        assert isinstance(PyInfo.integer_types[0], int)
        assert PyInfo.integer_types[0] == 123
        assert isinstance(PyInfo.class_types[0], type)
        assert PyInfo.class_types[0] == float
        assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:21:45.123378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:21:49.963299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test constructor of class PyInfo")
    assert PyInfo.PY3 or PyInfo.PY2
    assert not PyInfo.PY3 or not PyInfo.PY2
    print("Pass!")



# Generated at 2022-06-24 03:22:00.644850
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PyInfo.PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:22:07.134805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (2 == sys.version_info[0])
    assert info.PY3 == (3 == sys.version_info[0])

    assert info.maxsize > 0


# Main module execution

# Generated at 2022-06-24 03:22:10.919251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.maxsize)
    print(PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:14.926996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    if py_info.PY2:
        assert isinstance(py_info.binary_type, types.TypeType)
        assert str in py_info.string_types
    else:
        assert py_info.string_types is str
        assert py_info.binary_type is bytes


py_info = PyInfo()

# Generated at 2022-06-24 03:22:19.895039
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pyinfo = PyInfo()
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-24 03:22:30.614800
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY2:
        assert not isinstance(None, PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert isinstance("", PyInfo.binary_type)

        assert not isinstance(None, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

        assert not isinstance(None, PyInfo.class_types)
        assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-24 03:22:32.787674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
    elif PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)


# import builtins
# globals().update(vars(builtins))

# Generated at 2022-06-24 03:22:39.402529
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:47.258913
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None
    assert PyInfo.PY2 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:50.967028
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert sys.version_info[0] == 2 != sys.version_info[0] == 3



# Generated at 2022-06-24 03:23:00.149556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('hello', PyInfo.string_types)
        assert isinstance('hello', PyInfo.text_type)
        assert not isinstance('hello', PyInfo.binary_type)
        assert isinstance(b'hello', PyInfo.binary_type)
        assert not isinstance(b'hello', PyInfo.text_type)
    else:
        """
        >>> isinstance(b'hello', PyInfo.string_types)
        False
        >>> isinstance(u'hello', PyInfo.string_types)
        True
        >>> isinstance(u'hello', PyInfo.binary_type)
        False
        >>> isinstance('hello', PyInfo.binary_type)
        True
        >>> isinstance('hello', PyInfo.text_type)
        False
        """


# Generated at 2022-06-24 03:23:10.773208
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True, "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.PY3 is False, "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.string_types == (basestring,), "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.text_type == unicode, "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.binary_type == str, "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.integer_types == (int, long), "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.class_types == (type, types.ClassType), "Test failed in unit test for constructor of class PyInfo"
    assert PyInfo.maxsize == 2147

# Generated at 2022-06-24 03:23:17.831823
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('PY2: {}'.format(PyInfo.PY2))
    print('PY3: {}'.format(PyInfo.PY3))
    print('string_types: {}'.format(PyInfo.string_types))
    print('text_type: {}'.format(PyInfo.text_type))
    print('binary_type: {}'.format(PyInfo.binary_type))
    print('integer_types: {}'.format(PyInfo.integer_types))
    print('class_types: {}'.format(PyInfo.class_types))
    print('maxsize: {}'.format(PyInfo.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:20.372400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert not PyInfo.PY2 or PyInfo.PY3 is False
    assert not PyInfo.PY3 or PyInfo.PY2 is False
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type(1), PyInfo.class_types)

# Generated at 2022-06-24 03:23:28.704583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from sys import maxunicode

    assert PyInfo.PY2 or PyInfo.PY3

    for t in PyInfo.string_types:
        assert isinstance("text", t)
    for t in PyInfo.binary_types:
        assert isinstance(b"binary", t)
    for t in PyInfo.text_types:
        assert isinstance("text", t)
    for t in PyInfo.integer_types:
        assert isinstance(1, t)
    assert isinstance(maxunicode, PyInfo.integer_types)
    for t in PyInfo.class_types:
        assert isinstance(PyInfo, t)

# Generated at 2022-06-24 03:23:33.827505
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-24 03:23:36.743429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test = PyInfo()
    assert test.PY3 == (sys.version_info[0] == 3)
    assert test.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-24 03:23:45.397008
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if the constructor is getting a Attribute Error
    # Due to there is no attribute for sys
    with pytest.raises(AttributeError):
        del sys.version_info
        PyInfo()
        sys.version_info = sys.version_info
    # Python 2.7.13
    sys.version_info = (2, 7, 13, 'final', 0)
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str

    # Python 3.5
    sys.version_info = (3, 5, 0, 'alpha', 1)
    pyinfo = PyInfo()
    assert not pyinfo.PY

# Generated at 2022-06-24 03:23:56.314152
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    if pyinfo.PY2:
        assert isinstance(pyinfo.string_types, tuple)
        assert isinstance(pyinfo.text_type, type)
        assert issubclass(pyinfo.text_type, basestring)
        assert isinstance(pyinfo.binary_type, type)
        assert issubclass(pyinfo.binary_type, basestring)
        assert isinstance(pyinfo.integer_types, tuple)
        assert isinstance(pyinfo.class_types, tuple)
        assert isinstance(pyinfo.maxsize, (int, long))

    if pyinfo.PY3:
        assert isinstance(pyinfo.string_types, tuple)
        assert isinstance(pyinfo.text_type, type)

# Generated at 2022-06-24 03:23:58.667441
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:24:00.813510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    print(PyInfo.PY2)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:24:07.076889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> print(pyinfo.PY2)
    False
    >>> print(pyinfo.PY3)
    True

    >>> if PyInfo.PY3:
    ...     print("yes")
    ... else:
    ...     print("no")
    yes

    >>> if PyInfo.PY2:
    ...     print("yes")
    ... else:
    ...     print("no")
    no

    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()