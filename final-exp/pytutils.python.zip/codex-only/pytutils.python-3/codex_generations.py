

# Generated at 2022-06-24 03:14:18.073131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    str_int_class = "str", int, classmethod
    assert PyInfo.class_types == (type,)

    assert PyInfo.integer_types == (int, long)
    assert PyInfo.string_types == (str, unicode)


# Convert a string type to unicode type in Python 2

# Generated at 2022-06-24 03:14:19.951816
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize is not None

# Generated at 2022-06-24 03:14:26.728765
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == True or PyInfo.PY2 == False)
    assert(PyInfo.PY3 == True or PyInfo.PY3 == False)
    assert(PyInfo.PY2 != PyInfo.PY3)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert(PyInfo.string_types == (basestring,))
        assert(PyInfo.text_type == unicode)
        assert(PyInfo.binary_type == str)

# Generated at 2022-06-24 03:14:29.737412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)



# Generated at 2022-06-24 03:14:34.898721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:14:37.429414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:14:44.375074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == ((PyInfo.maxsize > 2 ** 32) and (
        PyInfo.maxsize < 2 ** 64))

# Generated at 2022-06-24 03:14:52.098259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 is False
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


# endregion

# region py2&py3 compatibility for functions

from functools import reduce



# Generated at 2022-06-24 03:15:00.003537
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert pytest.raises(AttributeError, lambda: PyInfo.maxsize)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:06.144147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not False
    assert PyInfo.PY3 is not False
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-24 03:15:14.825549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    if a.PY2:
        print("Running Python 2")
    elif a.PY3:
        print("Running Python 3")

    assert isinstance(a.string_types, tuple) and len(a.string_types) == 1
    assert isinstance(a.string_types[0], type)
    assert isinstance(a.text_type, type)

    assert isinstance(a.binary_type, type)
    assert isinstance(a.integer_types, tuple) and len(a.integer_types) == 2
    assert isinstance(a.class_types, tuple) and len(a.class_types) == 2
    assert isinstance(a.maxsize, int)

# Generated at 2022-06-24 03:15:21.086780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)

        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(u'', PyInfo.text_type)

        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:27.580432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)

    assert info.PY2 != info.PY3  # 1 is True and 0 is False

    if info.PY2:
        assert isinstance(info.maxsize, int) or isinstance(info.maxsize, long)
        assert isinstance(info.string_types, tuple)
        assert isinstance(info.text_type, unicode)
        assert isinstance(info.binary_type, str)
        assert isinstance(info.integer_types, tuple)
        assert isinstance(info.class_types, tuple)

    if info.PY3:
        assert isinstance(info.maxsize, int)
        assert isinstance(info.string_types, tuple)
       

# Generated at 2022-06-24 03:15:29.868581
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class _PyInfoTest(PyInfo):
        pass


if __name__ == "__main__":
    import unittest

    unittest.main()

# Generated at 2022-06-24 03:15:34.600423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance([], PyInfo.class_types)  # Not sure
    assert not isinstance(True, PyInfo.class_types)
    assert isinstance(str, PyInfo.class_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-24 03:15:40.697911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:47.564916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert PyInfo.maxsize > 0
    if (PyInfo.PY3):
        assert PyInfo.maxsize > 2147483647
    if (PyInfo.PY3):
        assert PyInfo.text_type == str
    else:
        assert PyInfo.text_type == unicode


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:53.935868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.class_types == (type,)
    elif PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:15:59.109376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('Text', PyInfo.string_types)
    assert isinstance(u'Text', PyInfo.string_types)
    assert isinstance(b'Text', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:09.645540
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is isinstance(u'\u3042', unicode)
    if PyInfo.PY2:
        assert not PyInfo.PY3
        assert str is basestring
        assert str is not unicode

    assert PyInfo.PY3 is isinstance('\u3042', str)
    if PyInfo.PY3:
        assert not PyInfo.PY2
        assert unicode is not basestring
        assert str is unicode

    assert PyInfo.string_types is not str
    assert PyInfo.string_types is not basestring
    assert PyInfo.text_type is not unicode
    assert PyInfo.binary_type is not str
    assert PyInfo.binary_type is not basestring
    assert PyInfo.integer_types is not int
    assert PyInfo.integer

# Generated at 2022-06-24 03:16:19.085685
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)

        assert PyInfo.maxsize == (1 << 63) - 1
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

       

# Generated at 2022-06-24 03:16:26.267277
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Create a global object PyInfo
pyinfo = PyInfo()

# Generated at 2022-06-24 03:16:32.506702
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(len, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:42.735223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    type_str = type("string")
    type_unicode = type(u"unicode")
    type_bytes = type(b"bytes")
    type_int = type(1)
    type_long = type(1)
    type_class = type(PyInfo)

    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert PyInfo.string_types == (type_unicode, type_str) if PyInfo.PY2 else (type_str,)
    assert PyInfo.text_type == type_unicode if PyInfo.PY2 else type_str
    assert PyInfo.binary_type == type_bytes if PyInfo.PY2 else type_str

# Generated at 2022-06-24 03:16:53.986752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for constructor of class PyInfo"""

    assert isinstance(PyInfo.string_types, tuple)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
    else:
        assert PyInfo.string_types == (basestring,)

    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    if PyInfo.PY3:
        assert PyInfo.integer_types == (int,)
    else:
        assert PyInfo.integer_types == (int, long)

    assert isinstance(PyInfo.maxsize, int)

    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-24 03:16:59.269771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.binary_type)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:17:07.758802
# Unit test for constructor of class PyInfo
def test_PyInfo():
    ## Test version
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    ## Test string_type
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert type(PyInfo.string_types[0]) == str
    else:
        assert len(PyInfo.string_types) == 1
        assert issubclass(PyInfo.string_types[0], str)

    ## Test text_type
    ## Check type
    if PyInfo.PY2:
        assert PyInfo.text_type == unicode
    else:
        assert PyInfo.text_type == str

    ## Test binary_type
    ## Check type

# Generated at 2022-06-24 03:17:15.808413
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True and PyInfo.PY3 is False
    assert type(PyInfo.string_types) is tuple and type(PyInfo.string_types[0]) is type
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple and type(PyInfo.integer_types[0]) is type
    assert type(PyInfo.class_types) is tuple and type(PyInfo.class_types[0]) is type
    assert type(PyInfo.maxsize) is int


# Generated at 2022-06-24 03:17:19.392498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert all(isinstance(a, PyInfo.text_type) for a in PyInfo.string_types)
    assert all(isinstance(a, PyInfo.text_type) for a in PyInfo.string_types)
    assert all(isinstance(a, PyInfo.integer_types) for a in [PyInfo.maxsize])



# Generated at 2022-06-24 03:17:28.811996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert len(PyInfo.class_types) == 2
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary

# Generated at 2022-06-24 03:17:39.126257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    print('p.PY2={0}'.format(p.PY2))
    print('p.PY3={0}'.format(p.PY3))
    print('p.string_types={0}'.format(p.string_types))
    print('p.text_type={0}'.format(p.text_type))
    print('p.binary_type={0}'.format(p.binary_type))
    print('p.integer_types={0}'.format(p.integer_types))
    print('p.class_types={0}'.format(p.class_types))
    print('p.maxsize={0}'.format(p.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:42.430438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:17:44.356052
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True



# Generated at 2022-06-24 03:17:48.863817
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1



# Generated at 2022-06-24 03:17:56.381720
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert type(PyInfo.maxsize) == int

    if PyInfo.PY3:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)

    else:  # PyInfo.PY2
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type

# Generated at 2022-06-24 03:18:07.163614
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if 'PYTHON_EMBEDDED_TEST' in os.environ:
        return
    assert PyInfo.PY2 or not PyInfo.PY2
    assert PyInfo.PY3 or not PyInfo.PY3
    assert type(''.encode()) in PyInfo.binary_type
    assert type(u''.encode()) in PyInfo.binary_type
    assert type(b''.decode()) in PyInfo.text_type
    assert type(''.decode()) in PyInfo.text_type
    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-24 03:18:18.068407
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for PY2
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    # test for PY3
    PyInfo.PY2 = False
    PyInfo.PY3 = True

    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)


# Generated at 2022-06-24 03:18:25.489421
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from six import PY2, PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)

    if PY2:
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, long)  # or int
    elif PY3:
        assert isinstance(PyInfo.integer_types, type)
        assert isinstance(PyInfo.class_types, type)
        assert isinstance(PyInfo.maxsize, int)
    else:
        raise RuntimeError()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:28.879471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Test the PyInfo.PY2 and PyInfo.PY3

# Generated at 2022-06-24 03:18:32.853840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for item in ["PY2", "PY3", "string_types", "text_type", "binary_type", "integer_types", "class_types", "maxsize"]:
        assert item in dir(PyInfo)


test_PyInfo()

# Generated at 2022-06-24 03:18:39.701809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_init(self):
            for name in dir(PyInfo):
                if name.startswith('__'):
                    continue
                self.assertIsNotNone(getattr(PyInfo, name))

    unittest.main()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:50.662564
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == (2 == sys.version_info[0]))
    assert(PyInfo.PY3 == (3 == sys.version_info[0]))

    assert(isinstance('abc', PyInfo.string_types))
    assert(not isinstance(u'abc', PyInfo.string_types))

    if PyInfo.PY3:
        assert(isinstance('abc', PyInfo.binary_type))
        assert(isinstance(b'abc', PyInfo.binary_type))
        assert(isinstance('abc', PyInfo.text_type))
        assert(isinstance(u'abc', PyInfo.text_type))
    else:  # PY2
        assert(isinstance('abc', PyInfo.binary_type))

# Generated at 2022-06-24 03:18:59.809305
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _PyInfo = PyInfo()

    assert _PyInfo.PY2 is True or _PyInfo.PY2 is False
    assert _PyInfo.PY3 is True or _PyInfo.PY3 is False

    assert isinstance(_PyInfo.string_types, tuple)
    assert isinstance(_PyInfo.text_type(), _PyInfo.string_types)
    assert isinstance(_PyInfo.binary_type(), _PyInfo.string_types)
    assert isinstance(_PyInfo.integer_types, tuple)
    assert isinstance(1, _PyInfo.integer_types)
    assert isinstance(_PyInfo.class_types, tuple)
    assert isinstance(int, _PyInfo.class_types)

    assert isinstance(_PyInfo.maxsize, int)

# Generated at 2022-06-24 03:19:09.730714
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from .mock import Mock
    import sys

    # Test for PY3
    sys.version_info = (3, 4, 1)
    info = PyInfo()
    assert info.PY2 is False
    assert info.PY3 is True
    assert info.string_types == (str,)
    assert info.text_type == str
    assert info.binary_type == bytes
    assert info.integer_types == (int,)
    assert info.class_types == (type,)
    assert info.maxsize == sys.maxsize

    # Test for PY2
    sys.version_info = (2, 7, 8)
    info = PyInfo()
    assert info.PY2 is True
    assert info.PY3 is False
    assert info.string_types == (basestring,)
    assert info.text

# Generated at 2022-06-24 03:19:15.548657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    print(p.PY2)
    print(p.PY3)
    print(p.string_types)
    print(p.text_type)
    print(p.binary_type)
    print(p.integer_types)
    print(p.class_types)
    print(p.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:19.724526
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3  # It's Python 2 or Python 3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:19:28.603000
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (
        PyInfo.PY2 is True or PyInfo.PY3 is True
    ), 'Both PY2 and PY3 are false. Something is wrong.'
    assert PyInfo.PY2 != PyInfo.PY3, (
        'Exactly one of PY2 or PY3 should be true. Both are true.')
    if PyInfo.PY2:
        assert PyInfo.PY3 is False, 'PY2 is true and PY3 is also true.'
    else:
        assert PyInfo.PY2 is False, 'PY3 is true and PY2 is also true.'



# Generated at 2022-06-24 03:19:30.040478
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3

# Generated at 2022-06-24 03:19:41.680869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert isinstance(type, type)
        assert isinstance(int, type)
        assert isinstance(str, type)
        assert isinstance(bytes, type)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_

# Generated at 2022-06-24 03:19:53.380676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert (isinstance('hi', PyInfo.string_types))
        assert (isinstance('hi', PyInfo.binary_type))
        assert (isinstance(u'hi', PyInfo.text_type))
        assert (isinstance(1, PyInfo.integer_types))
        assert (isinstance(type, PyInfo.class_types))
    else:
        assert (isinstance('hi', PyInfo.string_types))
        assert (isinstance('hi', PyInfo.binary_type))
        assert (isinstance(u'hi', PyInfo.text_type))
        assert (isinstance(1, PyInfo.integer_types))
        assert (isinstance(type, PyInfo.class_types))
        assert (isinstance(Exception, PyInfo.class_types))

# Generated at 2022-06-24 03:19:59.697759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == basestring, "PY2 test fail"
        assert PyInfo.text_type == unicode, "PY2 test fail"
        assert PyInfo.binary_type == str, "PY2 test fail"
        assert PyInfo.integer_types == (int, long), "PY2 test fail"
        assert PyInfo.class_types == (type, types.ClassType), "PY2 test fail"
    else:
        assert PyInfo.string_types == str, "PY3 test fail"
        assert PyInfo.text_type == str, "PY3 test fail"
        assert PyInfo.binary_type == bytes, "PY3 test fail"
        assert PyInfo.integer_types == int, "PY3 test fail"

# Generated at 2022-06-24 03:20:08.066393
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3


# Generated at 2022-06-24 03:20:15.327485
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Addition of class instance
    @functools.wraps(MyClass.__add__)
    def __add__(self, other):
        return MyClass.__add__(self, other)

    # Subtraction of class instance
    @functools.wraps(MyClass.__sub__)
    def __sub__(self, other):
        return MyClass.__sub__(self, other)

    # Multiplication of a class instance
    @functools.wraps(MyClass.__mul__)
    def __mul__(self, other):
        return MyClass.__mul__(self, other)

    # Division of a class instance
    @functools.wraps(MyClass.__truediv__)
    def __truediv__(self, other):
        return My

# Generated at 2022-06-24 03:20:24.066195
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
    elif PyInfo.PY3:
        assert not isinstance(b"", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.binary_type)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:29.248366
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:20:38.033354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert str == PyInfo.text_type
        assert str == PyInfo.binary_type
        assert int in PyInfo.integer_types
        assert long in PyInfo.integer_types
        assert type in PyInfo.class_types
        assert types.ClassType in PyInfo.class_types
        assert str in PyInfo.string_types
        assert unicode in PyInfo.string_types
        assert isinstance("", PyInfo.string_types)
    else:
        assert str == PyInfo.text_type
        assert bytes == PyInfo.binary_type
        assert int in PyInfo.integer_types
        assert type in PyInfo.class_types
        assert str in PyInfo.string_types
        assert isinstance("", PyInfo.string_types)
        assert type("") is PyInfo.text

# Generated at 2022-06-24 03:20:44.510744
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert not isinstance(u'abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:50.008357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> import sys
    >>> isinstance(PyInfo.text_type, type)
    True
    >>> isinstance(PyInfo.binary_type, type)
    True
    >>> isinstance(PyInfo.maxsize, int)
    True
    >>>
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:20:51.609912
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:20:59.139120
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    # Overwrite the private variables in class PyInfo
    info.PY2 = True
    info.PY3 = False
    info.string_types = (basestring,)
    info.text_type = unicode
    info.binary_type = str

    # Check if the values of PyInfo is as expected
    assert info.PY2
    assert not info.PY3
    assert info.string_types == (basestring,)
    assert info.text_type == unicode
    assert info.binary_type == str

# Generated at 2022-06-24 03:21:03.863225
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-24 03:21:11.624737
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    import logging
    log = logging.getLogger('test')
    log.debug('sys.version_info[0] = {}'.format(sys.version_info[0]))
    if PyInfo.PY3:
        log.debug('PyInfo.PY3')
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        log.debug('PyInfo.PY2')
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types

# Generated at 2022-06-24 03:21:19.865506
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-24 03:21:28.545088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _test_PY3():
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

    def _test_PY2():
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

    if PyInfo.PY3:
        _test_PY3()

# Generated at 2022-06-24 03:21:32.341759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> print(PyInfo.PY2)
    True
    >>> print(PyInfo.PY3)
    False
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:21:42.737380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if not PyInfo.PY3:  # PY2
        assert set(PyInfo.string_types) == {basestring}
        assert set(PyInfo.integer_types) == {int, long}
        assert set(PyInfo.class_types) == {type, types.ClassType}
    else:
        assert set(PyInfo.string_types) == {str}
       

# Generated at 2022-06-24 03:21:50.633804
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # Verify that ``PyInfo.string_types`` and ``PyInfo.integer_types`` are
    # indeed tuples
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize >= sys.maxsize
        assert PyInfo.maxsize >= (1 << 31)


if __name__ == '__main__':
    import sys
    import doctest
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-24 03:22:00.993463
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.class_types)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:22:02.958608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not (PyInfo.PY3 or PyInfo.PY2):
        raise Exception("Error in PyInfo definition.")



# Generated at 2022-06-24 03:22:07.301110
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('foo', PyInfo.string_types)
        assert not isinstance(u'foo', PyInfo.string_types)
    else:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.string_types)



# Generated at 2022-06-24 03:22:11.993082
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        def testPy2(self):
            self.assertEqual(PyInfo.PY2, True)
            pass

        def testPy3(self):
            self.assertEqual(PyInfo.PY3, False)
            pass

    unittest.main()



# Generated at 2022-06-24 03:22:18.679009
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:22:26.366916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    if PyInfo.PY3:
        assert issubclass(str, PyInfo.string_types)
    else:
        assert issubclass(str, PyInfo.binary_type)
        assert issubclass(unicode, PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)


test_PyInfo()

# Generated at 2022-06-24 03:22:27.678388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-24 03:22:35.704016
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    pi = PyInfo()

    if pi.PY2:
        assert (
            pi.string_types
            == (basestring,)
        ), "Class attr string_type different from Py2"

        assert pi.text_type == unicode, "Class attr text_type different from Py2"

        assert pi.binary_type == str, "Class attr binary_type different from Py2"

        assert (
            pi.integer_types == (int, long)
        ), "Class attr integer_types different from Py2"

        assert (
            pi.class_types == (type, types.ClassType)
        ), "Class attr class_types different from Py2"

        assert pi.maxsize <= sys.maxsize, "Class attr maxsize different from Py2"


# Generated at 2022-06-24 03:22:41.448133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    assert isinstance(PyInfo.maxsize, int)

    if platform.python_implementation() != 'PyPy' and sys.version_info >= (3, 0):
        # PyPy Python 3 produces an OverflowError
        assert len(PyInfo.maxsize * PyInfo.maxsize) == 0

    with pytest.raises(TypeError):
        PyInfo.maxsize * 's'

# Generated at 2022-06-24 03:22:48.252018
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:57.012674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None
    assert isinstance(PyInfo.maxsize, int), type(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:02.899498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 in (True, False)
    assert PyInfo.PY3 in (True, False)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:13.498993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int


if __name__ == "__main__":
    import os.path
    import sys

    sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(__file__))))

    import test

    test.test_main()

# Generated at 2022-06-24 03:23:23.083960
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.string_types)

# Generated at 2022-06-24 03:23:26.196873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2



# Generated at 2022-06-24 03:23:34.494657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('1', PyInfo.string_types)
        assert isinstance('1', PyInfo.text_type)
        assert isinstance(b'1', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:  # PY2
        assert isinstance('1', PyInfo.string_types)
        assert isinstance(u'1', PyInfo.text_type)
        assert isinstance(b'1', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-24 03:23:35.887463
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3



# Generated at 2022-06-24 03:23:39.367830
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(string_types, tuple)
    assert isinstance(text_type(''), text_type)
    assert isinstance(binary_type(''), binary_type)
    assert isinstance(integer_types, tuple)
    assert isinstance(class_types, tuple)
    assert isinstance(maxsize, int)
    assert maxsize == sys.maxsize



# Generated at 2022-06-24 03:23:49.086198
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(b"a", PyInfo.text_type)

    assert isinstance(b"a", PyInfo.binary_type)
    assert not isinstance("a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)

    assert isinstance(bool, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:23:56.923700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", type)
        assert isinstance("", object)
        assert isinstance(None, PyInfo.string_types) is False
        assert isinstance(None, PyInfo.text_type) is False
        assert isinstance(None, type) is False
        assert isinstance(None, object) is True
        assert isinstance(b"", PyInfo.string_types) is False
        assert isinstance(b"", bytes) is True
        assert isinstance(1, PyInfo.integer_types) is True
        assert isinstance(1, int) is True

# Generated at 2022-06-24 03:24:03.013101
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and (not PyInfo.PY3)
    assert isinstance(True, PyInfo.integer_types)
    assert isinstance(False, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(3.14159, PyInfo.integer_types)
    assert isinstance(3.14159, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:24:08.678772
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("a", PyInfo.string_types)
    assert not isinstance("a", PyInfo.class_types)
    assert isinstance(list, PyInfo.class_types)
    assert isinstance(2, PyInfo.integer_types)
    assert not isinstance(2, PyInfo.text_type)
    assert isinstance("a", PyInfo.text_type)
    assert not isinstance("a", PyInfo.binary_type)
    assert isinstance(b"b", PyInfo.binary_type)


pyinfo = PyInfo()

# Generated at 2022-06-24 03:24:15.171929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(3, PyInfo.class_types)


test_PyInfo()