

# Generated at 2022-06-24 03:14:19.736404
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from h2o.frame import H2OFrame, H2OVec
    assert PyInfo.PY2 == (type("") is str)
    assert PyInfo.PY3 == (type("") is bytes)
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 1
    assert len(PyInfo.class_types) == 1
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize > (1 << 60)
    assert PyInfo.maxsize > len(H2OFrame(python_obj=[[1]] * int(PyInfo.maxsize / 4)))  # it should be able to handle that size
    assert PyInfo.maxsize > len(H2OVec(python_obj=[1] * int(PyInfo.maxsize / 4)))  # it should be

# Generated at 2022-06-24 03:14:25.952100
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    py_info.string_types = (basestring, )
    py_info.text_type = unicode
    py_info.binary_type = str
    py_info.integer_types = (int, long)
    py_info.class_types = (type, types.ClassType)
    py_info.maxsize = sys.maxsize
    print(py_info.string_types, py_info.text_type, py_info.binary_type)
    print(py_info.integer_types, py_info.class_types, py_info.maxsize)
    print(py_info.PY2, py_info.PY3)



# Generated at 2022-06-24 03:14:29.995395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-24 03:14:36.605316
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert len(PyInfo.string_types) == 1
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types

    print(PyInfo.maxsize)


# Test code

# Generated at 2022-06-24 03:14:41.002295
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3
    if PyInfo.PY2:
        assert(PyInfo.maxsize == int((1 << 31) - 1))
        assert(not PyInfo.PY3)
    elif PyInfo.PY3:
        assert(PyInfo.maxsize == int((1 << 63) - 1))

# Generated at 2022-06-24 03:14:52.432896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert isinstance(PyInfo.maxsize, int)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types

# Generated at 2022-06-24 03:14:53.738986
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """

    :return:
    """
    obj = PyInfo()
    assert isinstance(obj, object)

# Generated at 2022-06-24 03:15:02.987424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo()
    assert py2.PY2
    assert not py2.PY3
    assert py2.string_types == (basestring,)
    assert py2.text_type == unicode
    assert py2.binary_type == str
    assert py2.integer_types == (int, long)
    assert py2.class_types == (type, types.ClassType)
    assert py2.maxsize >= 2 ** 31 - 1

    py3 = PyInfo()
    assert not py3.PY2
    assert py3.PY3
    assert py3.string_types == (str,)
    assert py3.text_type == str
    assert py3.binary_type == bytes
    assert py3.integer_types == (int,)
    assert py3.class_types == (type,)

# Generated at 2022-06-24 03:15:08.879835
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if isinstance(u"", PyInfo.text_type):
        pass
    if PyInfo.maxsize == sys.maxsize:
        pass
    if isinstance(1, PyInfo.integer_types):
        pass
    if isinstance(b"", PyInfo.binary_type):
        pass

# Generated at 2022-06-24 03:15:14.999921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

    assert isinstance(9223372036854775807, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:20.656801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:24.595074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("a", PyInfo.string_types)
    assert isinstance("a", text_type)
    assert isinstance("a".encode("utf-8"), binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, class_types)

# Generated at 2022-06-24 03:15:30.266892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:36.967472
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types[0](), str)
    assert isinstance(PyInfo.text_type(), str)
    assert isinstance(PyInfo.binary_type(), bytes)
    assert isinstance(PyInfo.integer_types[0](), int)
    assert isinstance(PyInfo.class_types[0](), type)

    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:45.576400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # '__name__' attribute is not supported in Python 3.
    pyi = PyInfo()
    assert(pyi.PY2)
    assert(not pyi.PY3)
    assert(isinstance(pyi.maxsize, (int, long)))

    pyi = PyInfo()
    assert((pyi.PY2, pyi.PY3) == (not pyi.PY3, pyi.PY3))
    assert(isinstance(pyi.maxsize, (int, long)))

    pyi = PyInfo()
    assert((pyi.PY2, pyi.PY3) == (not pyi.PY3, pyi.PY3))
    pyi.setup()

# Generated at 2022-06-24 03:15:56.301979
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print('PyInfo.PY2 is true')
    if PyInfo.PY3:
        print('PyInfo.PY3 is true')
    if PyInfo.string_types:
        print('PyInfo.string_types is true')
    if PyInfo.text_type:
        print('PyInfo.text_type is true')
    if PyInfo.binary_type:
        print('PyInfo.binary_type is true')
    if PyInfo.integer_types:
        print('PyInfo.integer_types is true')
    if PyInfo.class_types:
        print('PyInfo.class_types is true')
    if PyInfo.maxsize:
        print('PyInfo.maxsize is true')


test_PyInfo()

# Generated at 2022-06-24 03:16:01.817132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Ref: https://github.com/faif/python-patterns/blob/master/pythonic/pyinfo.py
    def test_pyinfo(self, version_info=(2, 5, 0, 'final', 0), maxsize=15):
        PyInfo.PY2 = True
        PyInfo.PY3 = False
        sys.version_info = version_info
        PyInfo.maxsize = maxsize
        assert PyInfo.PY2 == self.PY2 and \
               PyInfo.PY3 == self.PY3 and \
               PyInfo.maxsize == self.maxsize
    l = [2, 3]

# Generated at 2022-06-24 03:16:06.569347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2 is True and PyInfo.PY3 is False:
        # Python 2
        pass
    elif PyInfo.PY2 is False and PyInfo.PY3 is True:
        # Python 3
        pass
    else:
        raise AssertionError('Invalid PyInfo.PY2 or PyInfo.PY3')

# Generated at 2022-06-24 03:16:14.799823
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # call unsupported class
    try:
        # noinspection PyUnresolvedReferences
        PyInfo.PY4
        assert False
    except AttributeError:
        assert True

    # check PY3
    if PyInfo.PY3:
        for attr in ["string_types", "text_type", "binary_type",
                     "integer_types", "class_types", "maxsize"]:
            try:
                value = getattr(PyInfo, attr)
                assert value is not None
            except AttributeError:
                assert False

    # check PY2

# Generated at 2022-06-24 03:16:22.092685
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:16:32.389894
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 3)
    assert PyInfo.PY3 == (sys.version_info[0] == 2)

    if PyInfo.PY3:
        assert isinstance('', str)
        assert isinstance(b'', bytes)
        assert isinstance(1, int)
        assert isinstance(lambda: 1, type(lambda: 1))
        assert sys.maxsize == PyInfo.maxsize

    else:
        assert isinstance('', basestring)
        assert isinstance(b'', str)
        assert isinstance(1, (int, long))
        assert isinstance(lambda: 1, (type(lambda: 1), types.ClassType))
        assert sys.maxsize == PyInfo.maxsize


# Generated at 2022-06-24 03:16:42.675128
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,), repr(PyInfo.string_types)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,), repr(PyInfo.integer_types)
        assert PyInfo.class_types == (type,), repr(PyInfo.class_types)
        assert PyInfo.maxsize < sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,), repr(PyInfo.string_types)
        assert PyInfo.text_type == unicode


# Generated at 2022-06-24 03:16:46.068563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

# Generated at 2022-06-24 03:16:49.517541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test PyInfo.__init__
    test_pyinfo = PyInfo()
    assert test_pyinfo is not None



# Generated at 2022-06-24 03:17:00.420845
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.string_types)

# Generated at 2022-06-24 03:17:05.099515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)
    assert PyInfo.binary_type == (bytes if PyInfo.PY3 else str)
    assert PyInfo.text_type == (str if PyInfo.PY3 else unicode)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:17:09.662181
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types) is True
        assert isinstance('a', PyInfo.string_types) is True
    else:
        assert isinstance(1, PyInfo.integer_types) is True
        assert isinstance('a', PyInfo.string_types) is True

# Generated at 2022-06-24 03:17:16.840441
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:23.000260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:17:29.639665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert PyInfo.maxsize == (1 << 31) - 1
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31

        try:
            len(X())
        except OverflowError:
            # 32-bit
            assert PyInfo.maxsize == (1 << 31) - 1
        else:
            # 64-bit
            assert PyInfo.maxsize == (1 << 63) - 1
        del X


test_PyInfo()



# Generated at 2022-06-24 03:17:39.216066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class MyTest(object):
        pass

    # PY2
    from six import PY2
    assert PY2 == sys.version_info[0] == 2

    # PY3
    from six import PY3
    assert PY3 == sys.version_info[0] == 3

    # string_types
    from six import string_types
    if PY2:
        assert string_types == (basestring,)
    else:
        assert string_types == (str,)

    # text_type
    from six import text_type
    if PY2:
        assert text_type is unicode
    else:
        assert text_type is str

    # binary_type
    from six import binary_type
    if PY2:
        assert binary_type is str
    else:
        assert binary_

# Generated at 2022-06-24 03:17:41.714042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 1000000



# Generated at 2022-06-24 03:17:47.795248
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('text', PyInfo.string_types)
    assert isinstance(b'byte', PyInfo.string_types)
    assert isinstance('text', PyInfo.text_type)
    assert isinstance(b'byte', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:51.303800
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(PyInfo(), PyInfo.class_types)

# Generated at 2022-06-24 03:17:56.966059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str".encode("utf-8"), PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)



# Generated at 2022-06-24 03:18:04.124556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:18:07.625422
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _pi = PyInfo()
    assert _pi.PY2 or _pi.PY3
    assert _pi.PY2 ^ _pi.PY3
    assert _pi.maxsize
    assert _pi.string_types
    assert _pi.text_type
    assert _pi.binary_type
    assert _pi.integer_types
    assert _pi.class_types


# Test for the introspection of PyInfo

# Generated at 2022-06-24 03:18:17.111633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    pyinfo = PyInfo
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int,)
        assert pyinfo.maxsize == sys.maxsize
    else:  # PY2
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)


# Generated at 2022-06-24 03:18:26.031593
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance('s', PyInfo.string_types)
    assert not isinstance(b's', PyInfo.string_types)
    assert isinstance(b's', PyInfo.binary_type)
    assert not isinstance(u's', PyInfo.binary_type)
    assert isinstance('s', PyInfo.text_type)
    assert not isinstance(b's', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(str, PyInfo.class_types)

# Generated at 2022-06-24 03:18:34.347049
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    result = pyinfo.PY2
    assert result is not False


# Import the required modules.
if PyInfo.PY3:
    # Python 3
    import http.client as httplib
    import urllib.parse as urllib
    from http.server import BaseHTTPRequestHandler, HTTPServer
    from queue import Queue
    from socketserver import ThreadingMixIn
else:  # Python 2.7
    import httplib
    import urllib
    from BaseHTTPServer import BaseHTTPRequestHandler, HTTPServer
    from Queue import Queue
    from SocketServer import ThreadingMixIn


# Function for exception handling

# Generated at 2022-06-24 03:18:37.356476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)



# Generated at 2022-06-24 03:18:43.072509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.binary_type == str
    assert isinstance(1, PyInfo.integer_types)
    assert PyInfo.maxsize == 2147483647
    if not sys.platform.startswith("java"):
        p = 2 ** 31
        assert PyInfo.maxsize == p
    class X(object):
        pass
    assert isinstance(X, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()
    print('PyInfo unit test passed.')

# Generated at 2022-06-24 03:18:45.689077
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-24 03:18:48.128591
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('text', PyInfo.string_types)
    assert PyInfo.maxsize > 2 ** 32


# Falsy values in Python 2
PY2_FALSY = (0, 0.0, 0j, {}, [], (), set(), "", "False", "None")



# Generated at 2022-06-24 03:18:57.955945
# Unit test for constructor of class PyInfo
def test_PyInfo():
    inst = PyInfo()
    # PY2
    assert inst.PY2 is True or inst.PY2 is False
    assert inst.PY2 != inst.PY3
    # PY3
    assert inst.PY3 is True or inst.PY3 is False
    # string_types
    assert isinstance(inst.string_types, tuple)
    assert int in inst.string_types and (str or unicode) in inst.string_types and not bool in inst.string_types
    # text_type
    assert isinstance(inst.text_type, type)
    assert inst.text_type in inst.string_types
    # binary_type
    assert isinstance(inst.binary_type, type)
    assert inst.binary_type in inst.string_types
    # integer_types
    assert isinstance

# Generated at 2022-06-24 03:19:04.924422
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    import os
    import sys

    basename = os.path.basename(sys.argv[0])
    if basename.startswith("test_") and callable(locals()[basename[5:]]):
        locals()[basename[5:]]()
    else:
        print("Nothing to test.")

# Generated at 2022-06-24 03:19:10.941150
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # python 3.5.2
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:19:13.263981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import six
    assert six.PY2 == PyInfo.PY2
    assert six.PY3 == PyInfo.PY3



# Generated at 2022-06-24 03:19:22.422140
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # **************************
    # test class PyInfo
    # **************************
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert Py

# Generated at 2022-06-24 03:19:31.664861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyInfo = PyInfo()
    assert pyInfo.PY2 is True or pyInfo.PY3 is True
    assert isinstance(
        pyInfo.string_types,
        (tuple, list)
    ) is True
    assert isinstance(
        pyInfo.text_type,
        str
    ) is True
    assert isinstance(
        pyInfo.binary_type,
        str
    ) is True
    assert isinstance(
        pyInfo.integer_types,
        (tuple, list)
    ) is True
    assert isinstance(
        pyInfo.class_types,
        (tuple, list)
    ) is True
    assert isinstance(
        pyInfo.maxsize,
        int
    ) is True



# Generated at 2022-06-24 03:19:42.817815
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert type(info.PY2) == bool
    assert type(info.PY3) == bool
    assert type(info.string_types) == tuple
    assert type(info.text_type) == type
    assert type(info.binary_type) == type
    assert type(info.integer_types) == tuple
    assert type(info.class_types) == tuple


if __name__ == "__main__":

    # Unit test
    test_PyInfo()

    # Show information
    info = PyInfo()
    print("Python version: %d" % sys.version_info[0])
    print("PyInfo.PY2: %s" % info.PY2)
    print("PyInfo.PY3: %s" % info.PY3)

# Generated at 2022-06-24 03:19:44.741347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:19:46.464300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-24 03:19:50.817277
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.maxsize == ((1 << 63) - 1)
    else:
        assert PyInfo.maxsize == ((1 << 31) - 1)



# Generated at 2022-06-24 03:19:53.231229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:20:03.537646
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types[0], type)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types[0], type)

# Generated at 2022-06-24 03:20:13.563213
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:16.821935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo.PY3
    except AssertionError:
        assert PyInfo.PY2


# Testcase for assertion that all variables are of the correct type

# Generated at 2022-06-24 03:20:19.814910
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # None of the following should fail.
    PyInfo()
    assert PyInfo.PY2 or PyInfo.PY3

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:21.661024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test PyInfo"""
    pass


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:28.219513
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("Python version is 2.x")
    elif PyInfo.PY3:
        print("Python version is 3.x")
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        raise Exception()
    print("Success")


test_PyInfo()

# Generated at 2022-06-24 03:20:37.728661
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'd', PyInfo.text_type)
        assert isinstance(b'd', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('d', PyInfo.text_type)
        assert isinstance(b'd', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:41.008047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    if PyInfo.PY2:
        print(PyInfo.maxsize, type(PyInfo.maxsize))
    else:
        print(PyInfo.maxsize, type(PyInfo.maxsize))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:51.922836
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo"""
    sys.version = '2.7.1'
    py_info = PyInfo()
    if py_info.PY3:
        assert (py_info.string_types == str)
        assert (py_info.text_type == str)
        assert (py_info.binary_type == bytes)
        assert (py_info.integer_types == int)
        assert (py_info.class_types == type)
        assert (py_info.maxsize == sys.maxsize)
    else:
        assert (py_info.string_types == basestring)
        assert (py_info.text_type == unicode)
        assert (py_info.binary_type == str)
        assert (py_info.integer_types == (int, long))

# Generated at 2022-06-24 03:20:58.169452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types[0], PyInfo.text_type)
    assert isinstance(PyInfo.binary_type(), PyInfo.text_type)
    assert isinstance(PyInfo.integer_types[0], int)
    if PyInfo.PY2:
        assert isinstance(PyInfo.class_types[0], type)
        assert isinstance(PyInfo.class_types[1], types.ClassType)



# Generated at 2022-06-24 03:21:06.580340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    Run doctest on module's class PyInfo.
    '''
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY3:
        assert pyinfo.string_types == (str, )
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int, )
        assert pyinfo.class_types == (type, )
        assert pyinfo.maxsize == sys.maxsize
    else:  # PY2
        assert pyinfo.string_types == (basestring, )
        assert pyinfo.text_type == unicode
        assert py

# Generated at 2022-06-24 03:21:17.112169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:21:25.118647
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)


# Generated at 2022-06-24 03:21:28.775404
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(b"str", PyInfo.binary_type)
    assert not isinstance("str", PyInfo.binary_type)


# Determine the type of the variable

# Generated at 2022-06-24 03:21:37.780074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False, "PyInfo.PY2 is not False"
    assert PyInfo.PY3 is True, "PyInfo.PY3 is not True"
    assert PyInfo.string_types == (str,), "PyInfo.string_types is not (str,)"
    assert PyInfo.text_type == str, "PyInfo.text_type is not str"
    assert PyInfo.binary_type == bytes, "PyInfo.binary_type is not bytes"
    assert PyInfo.integer_types == (int,), "PyInfo.integer_types is not (int,)"
    assert PyInfo.class_types == (type,), "PyInfo.class_types is not (type,)"
    # assert PyInfo.maxsize == 9223372036854775807, "PyInfo.maxsize is

# Generated at 2022-06-24 03:21:43.833634
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pytest import raises

    with raises(ValueError):
        # noinspection PyArgumentList
        PyInfo(PY2=0, PY3=0, string_types='string_types', text_type='text_type',
               binary_type='binary_type', integer_types='integer_types', class_types='class_types',
               maxsize='maxsize')

# Generated at 2022-06-24 03:21:52.907354
# Unit test for constructor of class PyInfo
def test_PyInfo():

    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)

        assert type(pyinfo.text_type()) == str
        assert type(pyinfo.binary_type()) == bytes

        assert pyinfo.integer_types == (int,)
        assert pyinfo.class_types == (type,)
    else:  # PY2
        assert pyinfo.string_types == (basestring,)

        assert type(pyinfo.text_type()) == unicode
        assert type(pyinfo.binary_type()) == str

        assert pyinfo.integer_types == (int, long)

# Generated at 2022-06-24 03:22:02.997999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.maxsize == 9223372036854775807

    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] == basestring
    assert PyInfo.binary_type == bytes
    assert PyInfo.text_type == str
    assert len(PyInfo.integer_types) == 2
    assert PyInfo.integer_types[0] == int
    assert PyInfo.integer_types[1] == long
    assert len(PyInfo.class_types) == 2
    assert PyInfo.class_types[0] == type
    assert PyInfo.class_types[1] == types.ClassType

    assert isinstance(str(PyInfo), str)
    # assert isinstance(re

# Generated at 2022-06-24 03:22:04.362991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == True or PyInfo.PY2 == True

# Generated at 2022-06-24 03:22:08.421764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )

# Generated at 2022-06-24 03:22:17.300125
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    # test string_types
    assert isinstance("", info.string_types)

    # test text_type
    assert isinstance("", info.text_type)

    # test binary_type
    assert isinstance("".encode(), info.binary_type)

    # test integer_types
    assert isinstance(1, info.integer_types)

    # test class_types
    assert isinstance(PyInfo, info.class_types)

    # test maxsize
    if sys.maxsize == info.maxsize:
        assert isinstance(sys.maxsize, int)

# Generated at 2022-06-24 03:22:24.938743
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)

    assert isinstance(u"abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)

    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    pytest.main(['-l', __file__])

# Generated at 2022-06-24 03:22:30.864775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test for the PyInfo class constructor
    """
    assert type(PyInfo.maxsize) in PyInfo.integer_types, 'PyInfo.maxsize is not a valid number'



# Generated at 2022-06-24 03:22:39.492229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:22:48.488805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == str
    else:
        assert len(PyInfo.string_types) == 2
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.string_types[1] == unicode
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:57.611999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from anaconda_project.internal.py2_compat import test_PyInfo_impl
    test_PyInfo_impl.test_PyInfo(PyInfo)


# Substitute for the 'six' library.
if PyInfo.PY2:
    input = raw_input  # noqa
    range = xrange  # noqa
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    integer_types = PyInfo.integer_types

    exec("def reraise(tp, value, tb): raise tp, value, tb")

# Generated at 2022-06-24 03:23:04.951547
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test whether static variables are sane
    p = PyInfo()
    assert PyInfo.PY2 == p.PY2
    assert PyInfo.PY3 == p.PY3
    if p.PY3:
        assert isinstance("", p.string_types)
        assert isinstance(b"", bytes)
        assert isinstance("", p.text_type)
        assert isinstance(b"", p.binary_type)
        assert isinstance(10, p.integer_types)
        assert isinstance(int, p.class_types)
        assert isinstance(type, p.class_types)

        assert p.maxsize > (1 << 63)
    else:  # PY2
        assert isinstance("", p.string_types)
        assert isinstance("", p.text_type)

# Generated at 2022-06-24 03:23:09.577677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    print(PyInfo.maxsize)
    print(PyInfo.PY2)
    print(PyInfo.integer_types)



# Generated at 2022-06-24 03:23:15.410709
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance("1", PyInfo.string_types)
    isinstance(b"2", PyInfo.binary_type)
    isinstance(1, PyInfo.integer_types)
    isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert PyInfo.maxsize > 2 ** 32



# Generated at 2022-06-24 03:23:20.443245
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:26.107787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.class_types)



# Generated at 2022-06-24 03:23:35.182760
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    # Ensure that we are running on the expected Python version
    # (specified in tox.ini, see [travis] section)
    py_implementation = platform.python_implementation()
    py_version = platform.python_version()
    if py_implementation != "CPython":
        raise ValueError("The Python version running this test is not CPython")
    if py_version != os.environ.get("TRAVIS_PYTHON_VERSION", py_version):
        raise ValueError("The Python version running this test is not "
                         "the same as specified by TRAVIS_PYTHON_VERSION")

    # Check reading PY2 and PY3
    if PyInfo.PY3:
        assert PyInfo.PY2 is False
    else:
        assert PyInfo.PY2 is True



# Generated at 2022-06-24 03:23:44.234649
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test = PyInfo()
    assert test.PY2 == (sys.version_info[0] == 2)
    assert test.PY3 == sys.version_info[0] == 3
    assert test.PY2 != test.PY3
    if test.PY2:
        assert test.string_types == (basestring,)
        assert test.text_type == unicode
        assert test.binary_type == str
        assert test.integer_types == (int, long)
        assert test.class_types == (type, types.ClassType)
    else:  # PY2
        assert test.string_types == (str,)
        assert test.text_type == str
        assert test.binary_type == bytes
        assert test.integer_types == (int, )

# Generated at 2022-06-24 03:23:52.859984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
    else:  # PY2
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-24 03:23:55.008753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p1 = PyInfo()
    assert p1.PY2 == True
    p2 = PyInfo()
    assert p2.PY2 == True

# Generated at 2022-06-24 03:23:58.668335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("11", PyInfo.string_types)
    assert "11" is not PyInfo.text_type
    assert b"11" is PyInfo.binary_type
    assert 11 is not PyInfo.integer_types
    assert type is PyInfo.class_types
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:24:04.058583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:24:06.101583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:24:10.049881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        # The 'string_types' class is obsolete in python 3
        assert PyInfo.string_types == (str,)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])