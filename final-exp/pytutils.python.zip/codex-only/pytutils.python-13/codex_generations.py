

# Generated at 2022-06-24 03:14:19.942194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types

    if py2:
        assert isinstance('', string_types)
        assert isinstance(u'', string_types)
        assert isinstance('', text_type)
        assert isinstance(u'', text_type)
        assert not isinstance('', binary_type)
        assert not isinstance(u'', binary_type)
    elif py3:
        assert isinstance('', string_types)
        assert isinstance('', text_type)

# Generated at 2022-06-24 03:14:25.667613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> print PyInfo.PY2
    True
    >>> print PyInfo.PY3
    False
    >>> print isinstance('abc', PyInfo.string_types)
    True
    >>> print isinstance(b'abc', PyInfo.binary_type)
    True
    >>> print isinstance(u'abc', PyInfo.text_type)
    True
    >>> print isinstance(1, PyInfo.integer_types)
    True
    >>> print isinstance(int, PyInfo.class_types)
    True
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:14:30.562755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(lambda x: x, PyInfo.class_types)

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:14:40.722509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)

# Generated at 2022-06-24 03:14:49.140408
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Info(PyInfo):
        pass
    assert isinstance(Info.PY2, bool)
    assert isinstance(Info.PY3, bool)
    assert isinstance(Info.string_types, tuple)
    assert isinstance(Info.text_type, type)
    assert isinstance(Info.binary_type, type)
    assert isinstance(Info.integer_types, tuple)
    assert isinstance(Info.class_types, tuple)
    assert isinstance(Info.maxsize, int)

# Generated at 2022-06-24 03:14:58.360083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert PyInfo.maxsize == (1 << 63) - 1


"""
Tests that verify which methods in the PyInfo class are working correctly.
This is necessary because the methods of this class change depending on the
version of Python.
"""



# Generated at 2022-06-24 03:15:02.811077
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:13.994005
# Unit test for constructor of class PyInfo
def test_PyInfo():
    success = True
    if not hasattr(sys, 'version_info'):
        print("'sys' object has no attribute 'version_info'")
        success = False
    if not hasattr(sys, 'platform'):
        print("'sys' object has no attribute 'platform'")
        success = False
    if PyInfo.PY2:
        if PyInfo.PY3 is True:
            print("PyInfo.PY3 is True when expected False")
            success = False
        if PyInfo.PY2 is False:
            print("PyInfo.PY2 is False when expected True")
            success = False

# Generated at 2022-06-24 03:15:20.846118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # noinspection PyUnresolvedReferences
    from server.py2and3.PyInfo import PyInfo

    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert PyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-24 03:15:27.328446
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert not isinstance(b'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert not isinstance('a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(object, PyInfo.class_types)



# Generated at 2022-06-24 03:15:33.215621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo."""
    assert hasattr(PyInfo, 'PY2')
    assert hasattr(PyInfo, 'PY3')
    assert hasattr(PyInfo, 'string_types')
    assert hasattr(PyInfo, 'text_type')
    assert hasattr(PyInfo, 'binary_type')
    assert hasattr(PyInfo, 'integer_types')
    assert hasattr(PyInfo, 'class_types')
    assert hasattr(PyInfo, 'maxsize')


# Unit tests for PyInfo.PY2

# Generated at 2022-06-24 03:15:42.930307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert not isinstance(b'abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert not isinstance(b'abc', PyInfo.text_type)
    assert not isinstance(u'abc', PyInfo.binary_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert PyInfo.maxsize > 0


test_PyInfo()

# Generated at 2022-06-24 03:15:53.592247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    with pytest.raises(AttributeError):
        PyInfo.PY4
    with pytest.raises(AttributeError):
        PyInfo.PY5
    with pytest.raises(AttributeError):
        PyInfo.PY6
    with pytest.raises(AttributeError):
        PyInfo.PY7
    with pytest.raises(AttributeError):
        PyInfo.PY8

if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename == "__main__.py":
        print("{}: Calling module as script.".format(sys.argv[0]))
        test_PyInfo()

# Generated at 2022-06-24 03:16:00.314769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(3, PyInfo.string_types)

        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance('', PyInfo.text_type)

        assert isinstance('', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.binary_type)

        assert isinstance(3, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:04.284947
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:16:12.179260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


test_PyInfo()



# Generated at 2022-06-24 03:16:13.547014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:16:19.092833
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert issubclass(types.StringType, PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
    else:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert not issubclass(types.StringType, PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)


if PyInfo.PY2:
    import __builtin__ as builtins

    str = unicode


# Generated at 2022-06-24 03:16:28.036645
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("----------test_PyInfo----------")
    assert PyInfo.PY2 or PyInfo.PY3, "Should be either PY2 or PY3"

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,), "Should be string_types == (str,)"
        assert PyInfo.text_type == str, "Should be text_type == str"
        assert PyInfo.binary_type == bytes, "Should be binary_type == bytes"
        assert PyInfo.integer_types == (int,), "Should be integer_types == (int,)"
        assert PyInfo.class_types == (type,), "Should be class_types == (type,)"


# Generated at 2022-06-24 03:16:33.482742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert issubclass(type(1), PyInfo.integer_types)
    assert issubclass(type(1), PyInfo.integer_types)

# Generated at 2022-06-24 03:16:40.159360
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test validity of instance attributes:
    for key, value in PyInfo.__dict__.items():
        if not key.startswith("__"):
            print(key, value)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:44.014178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:16:53.024809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print('This is in Python2')
    elif PyInfo.PY3:
        print('This is in Python3')

    print('string_types = ', repr(PyInfo.string_types))
    print('text_type = ', repr(PyInfo.text_type))
    print('binary_type = ', repr(PyInfo.binary_type))
    print('integer_types = ', repr(PyInfo.integer_types))
    print('class_types = ', repr(PyInfo.class_types))
    print('maxsize = ', repr(PyInfo.maxsize))



# Generated at 2022-06-24 03:17:02.714091
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assertEqual(x, y):
        if x != y:
            raise Exception("%s != %s" % (x, y))

    assert os.environ.get("TRAVIS", "").lower() != "true"  # This test cannot be run on travis
    assertEqual(PyInfo.PY2, not PyInfo.PY3)
    assertEqual(PyInfo.string_types, (str,) if PyInfo.PY3 else (unicode, str))
    assertEqual(PyInfo.text_type, str if PyInfo.PY3 else unicode)
    assertEqual(PyInfo.binary_type, bytes if PyInfo.PY3 else str)
    assertEqual(PyInfo.integer_types, (int,) if PyInfo.PY3 else (int, long))
    assertE

# Generated at 2022-06-24 03:17:05.861025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:17:16.888589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.maxsize) == int

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert type(PyInfo.text_type) == str
        assert type(PyInfo.binary_type) == bytes
        assert type(PyInfo.integer_types) == tuple
        assert type(PyInfo.class_types) == tuple
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert type(PyInfo.text_type) == unicode
        assert type(PyInfo.binary_type) == str
        assert type(PyInfo.integer_types) == tuple

# Generated at 2022-06-24 03:17:20.844399
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:17:26.764690
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 + PyInfo.PY3 == 1

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:17:34.305882
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(b"a", PyInfo.binary_type)
    assert isinstance(b"a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(u"a", PyInfo.text_type)

    # __len__(self, /)
    # Return len(self).
    assert PyInfo.maxsize == maxsize

# Generated at 2022-06-24 03:17:41.087455
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 == False

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        expected_maxsize = int((1 << 31) - 1)
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31


# Generated at 2022-06-24 03:17:50.413167
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:17:56.539404
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:18:05.501157
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert type(pyinfo.string_types) is tuple
    assert (
        pyinfo.text_type is bytes
        or pyinfo.text_type is str
        or pyinfo.text_type is unicode
    )
    assert (
        pyinfo.binary_type is str
        or pyinfo.binary_type is bytes
        or pyinfo.binary_type is unicode
    )
    assert type(pyinfo.integer_types) is tuple

# Generated at 2022-06-24 03:18:09.254714
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert type(info.string_types) is tuple
    assert type(info.text_type) is str
    assert type(info.binary_type) is str
    assert type(info.integer_types) is tuple
    assert type(info.class_types) is tuple
    assert info.maxsize == sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:11.484142
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info, object)



# Generated at 2022-06-24 03:18:19.541888
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY2 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:18:23.970104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)


# The main program for PyInfo unit test

# Generated at 2022-06-24 03:18:29.882893
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-24 03:18:34.577180
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        sanity = (PyInfo.PY2 or PyInfo.PY3) and not (PyInfo.PY2
                                                    and PyInfo.PY3)
        assert sanity
    except AssertionError:
        print("Failed sanity")
        sys.exit(1)
    print("Succeeded sanity")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:41.321443
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert '2' in sys.version
    assert '3' in sys.version
    assert isinstance(True, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance("abc", str)
        assert isinstance(b"abc", bytes)
    else:  # PY2
        assert isinstance("abc", basestring)
        assert isinstance(u"abc", unicode)
        assert isinstance(b"abc", str)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:51.792741
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test boolean fields
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test string_types, text_type, binary_type
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes

    # Test integer_types
    if PyInfo.PY2:
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:19:01.093717
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                assert PyInfo.maxsize == int((1 << 31) - 1)
            else:
                assert PyInfo.maxsize == int((1 << 63) - 1)
            del X

    # PY

# Generated at 2022-06-24 03:19:08.997625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:19.224843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if (PyInfo.PY3 and not isinstance(b"a", PyInfo.binary_type)):
        raise Exception("test_PyInfo: " + "non-binary string")
    elif ((not PyInfo.PY3) and not isinstance("a", PyInfo.text_type)):
        raise Exception("test_PyInfo: " + "non-string")
    elif (PyInfo.PY3 and not isinstance(b"a", PyInfo.string_types)):
        raise Exception("test_PyInfo: " + "non-string")
    elif ((not PyInfo.PY3) and not isinstance("a", PyInfo.string_types)):
        raise Exception("test_PyInfo: " + "non-string")

# Generated at 2022-06-24 03:19:23.398451
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:19:33.476816
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:19:43.382153
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    assert info.maxsize > 0

    if info.PY2:
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
    else:
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:45.103953
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# -----------------------------------------------------------------------------
# PyInfo : class
# -----------------------------------------------------------------------------

# Generated at 2022-06-24 03:19:50.828367
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert type(b'abc') == type(PyInfo.binary_type('abc'))
    assert type(u'abc') == type(PyInfo.text_type('abc'))
    assert type(1) == type(PyInfo.integer_types[0](1))
    assert isinstance(Exception, PyInfo.class_types)



# Generated at 2022-06-24 03:19:58.535699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2

    assert isinstance(PyInfo.string_types, tuple)
    assert str in PyInfo.string_types
    if PyInfo.PY2:
        assert unicode in PyInfo.string_types
    assert not int in PyInfo.string_types

    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.text_type == str
    assert PyInfo.text_type != unicode

    assert isinstance(PyInfo.binary_type, type)
    assert PyInfo.binary_type == bytes
    assert PyInfo.binary_type != str

    assert isinstance(PyInfo.integer_types, tuple)
    assert int in PyInfo.integer_types
    assert not str in PyInfo.integer_types

# Generated at 2022-06-24 03:20:08.022111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, (tuple, list))
        assert isinstance(PyInfo.string_types, (tuple, list))
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, (tuple, list))
        assert isinstance(PyInfo.class_types, (tuple, list))
        assert isinstance(PyInfo.maxsize, (int, long))
    elif PyInfo.PY3:
        assert isinstance(PyInfo.string_types, (tuple, list))
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-24 03:20:12.799823
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:20:20.540429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize >= 0

    if PyInfo.PY2:
        assert str is PyInfo.text_type
    else:
        assert PyInfo.PY3
        assert str is PyInfo.binary_type
        assert str is not PyInfo.text_type


# import all submodules
__all__ = []
for _submodule, _submodule_name, _submodule_is_package in pkgutil.iter_modules(
    __path__, __name__ + "."
):
    if _submodule_is_package:
        __all__.append(_submodule_name)
    else:
        __all__.append(_submodule_name.rsplit(".", 1)[-1])

# Generated at 2022-06-24 03:20:28.251753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert hasattr(pyinfo, 'PY2')
    assert hasattr(pyinfo, 'PY3')
    assert hasattr(pyinfo, 'string_types')
    assert hasattr(pyinfo, 'text_type')
    assert hasattr(pyinfo, 'binary_type')
    assert hasattr(pyinfo, 'integer_types')
    assert hasattr(pyinfo, 'class_types')
    assert hasattr(pyinfo, 'maxsize')
    assert pyinfo.PY2 != pyinfo.PY3



# Generated at 2022-06-24 03:20:30.328303
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 is not False
    assert p.PY3 is not True

# Generated at 2022-06-24 03:20:39.031058
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(b'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(long(1), PyInfo.integer_types)

    def f(): pass
    class C: pass

    assert isinstance(f, PyInfo.class_types)
    assert isinstance(C, PyInfo.class_types)


# Generated at 2022-06-24 03:20:47.262722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

    if PyInfo.PY2:
        assert PyInfo.maxsize < (1 << 31)
    else:
        assert PyInfo.maxsize >= (1 << 31)


# ############################################################
# Test case classes, each of which belongs to one or more groups
# ############################################################


# Generated at 2022-06-24 03:20:52.797326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.text_type)
        assert not isinstance('abc', PyInfo.binary_type)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.text_type)
        assert isinstance('abc', PyInfo.binary_type)
        assert not isinstance(b'abc', PyInfo.binary_type)

# Generated at 2022-06-24 03:20:58.362955
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert isinstance("asd", PyInfo.string_types)
    assert isinstance("asd", PyInfo.text_type)
    assert not isinstance("asd", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-24 03:21:06.666052
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)

    if PyInfo.PY2:
        assert isinstance(u"abc", PyInfo.string_types)
        assert isinstance("abc", PyInfo.binary_type)
        assert isinstance(b"abc", PyInfo.binary_type)

# Generated at 2022-06-24 03:21:16.358979
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.text_type)
    assert not isinstance("foo", PyInfo.text_type)
    assert isinstance(b"foo", PyInfo.binary_type)
    assert not isinstance(u"foo", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:21:26.390811
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from . import PyInfo
    from .cpython_compat import PY2, PY3

    if PY3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True

        assert type(PyInfo.maxsize) is int

        assert type("") in PyInfo.string_types
        assert type("") is PyInfo.text_type
        assert type(b"") is PyInfo.binary_type
        assert type(1) in PyInfo.integer_types
        assert type(PyInfo) in PyInfo.class_types
    else:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False

        assert type(PyInfo.maxsize) in (int, long)

        assert type("") in PyInfo.string_types
        assert type(u"")

# Generated at 2022-06-24 03:21:37.580377
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # class_types
    c = PyInfo
    assert c.PY2 == sys.version_info[0] == 2
    assert c.PY3 == sys.version_info[0] == 3
    if c.PY3:
        assert c.string_types == (str,)
        assert c.text_type == str
        assert c.binary_type == bytes
        assert c.integer_types == (int,)
        assert c.class_types == (type,)
        assert c.maxsize == sys.maxsize
    else:  # PY2
        assert c.string_types == (basestring,)
        assert c.text_type == unicode
        assert c.binary_type == str
        assert c.integer_types == (int, long)

# Generated at 2022-06-24 03:21:43.375477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:21:45.419140
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# =============================================================================
# 13.1. bool Objects
# =============================================================================

# Generated at 2022-06-24 03:21:52.131869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == type(2 ** 31 - 1)


# This class is for compatibility between Python 2 and Python 3
# acess to dictionary

# Generated at 2022-06-24 03:21:55.589499
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:22:04.461325
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:22:10.572625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test = PyInfo()
    # test.PY2
    assert test.PY2 is not False
    # test.PY3
    assert test.PY3 is not False
    # test.string_types
    assert test.string_types
    # test.text_type
    assert test.text_type
    # test.binary_type
    assert test.binary_type
    # test.integer_types
    assert test.integer_types
    # test.class_types
    assert test.class_types
    # test.maxsize
    assert test.maxsize

# Generated at 2022-06-24 03:22:17.013188
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test constructor of class PyInfo
    pi = PyInfo()
    assert pi is not None

    # Test read-only property PY2
    pi.PY2 = False
    assert pi.PY2 is True
    pi.PY2 = True
    assert pi.PY2 is True

    # Test read-only property PY3
    pi.PY3 = False
    assert pi.PY3 is True
    pi.PY3 = True
    assert pi.PY3 is True

    # Test read-only property maxsize on 32-bit system
    pi.maxsize = 0
    assert pi.maxsize == 2147483647



# Generated at 2022-06-24 03:22:25.985259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    info = PyInfo()
    assert PyInfo.__name__ == "PyInfo"
    assert PyInfo.__doc__ == "Class PyInfo"
    assert PyInfo.__module__ == "pyinfo.__init__"
    assert isinstance(info, PyInfo)
    assert info.PY2 or info.PY3
    assert info.string_types is PyInfo.string_types
    assert info.text_type is PyInfo.text_type
    assert info.binary_type is PyInfo.binary_type
    assert info.integer_types is PyInfo.integer_types
    assert info.class_types is PyInfo.class_types
    assert info.maxsize is PyInfo.maxsize

# Generated at 2022-06-24 03:22:30.347038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-24 03:22:33.945611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None

    assert PyInfo.maxsize is not None
    assert PyInfo.string_types is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.text_type is not None
    assert PyInfo.class_types is not None



# Generated at 2022-06-24 03:22:43.205060
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(b'abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(u'abc', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-24 03:22:48.469126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, str)
    assert isinstance(py_info.binary_type, str)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-24 03:22:53.892822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert PyInfo.maxsize == sys.maxsize


# Test stub for function in PyInfo
test_PyInfo()



# Generated at 2022-06-24 03:23:01.446215
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert isinstance(py_info, object)

    if sys.version_info[0] == 2:
        assert py_info.PY2 is True
        assert py_info.PY3 is False
        assert "long" in str(py_info.maxsize)
        assert "long" in str(py_info.integer_types)
    elif sys.version_info[0] == 3:
        assert py_info.PY2 is False
        assert py_info.PY3 is True
        assert (not "long") in str(py_info.maxsize)
        assert (not "long") in str(py_info.integer_types)


test_PyInfo()

# Generated at 2022-06-24 03:23:07.396430
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test python
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    # test string_types
    assert isinstance('abc', PyInfo.string_types) is True
    assert isinstance('', PyInfo.string_types) is True
    assert isinstance(u'abc', PyInfo.string_types) is True
    assert isinstance(u'', PyInfo.string_types) is True
    assert isinstance(b'abc', PyInfo.string_types) is False
    assert isinstance(b'', PyInfo.string_types) is False

    # test text_type
    assert isinstance('abc', PyInfo.text_type) is PyInfo.PY2
    assert isinstance(u'abc', PyInfo.text_type) is PyInfo.PY3

    # test binary_type


# Generated at 2022-06-24 03:23:15.976948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    tmp = (1, 2, 3)
    assert str(tmp) == '1,2,3'
    assert str(tmp[0]) == '1'
    assert str(tmp[1]) == '2'
    assert str(tmp[2]) == '3'
    assert str('abc') == "abc"
    assert isinstance(tmp[0], int)
    assert isinstance(tmp[1], int)
    assert isinstance(tmp[2], int)
    assert isinstance(tmp, tuple)
    assert isinstance(str, type)
    assert sys.maxsize == 2**31-1  # 32-bit



# Generated at 2022-06-24 03:23:17.473211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3



# Generated at 2022-06-24 03:23:22.308024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("maxsize:", PyInfo.maxsize)
    print("text_type:", type(PyInfo.text_type))
    print("binary_type:", type(PyInfo.binary_type))


# test for python verion

# Generated at 2022-06-24 03:23:30.459578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert pyinfo.string_types[0] is str or pyinfo.string_types[0] is basestring
    assert pyinfo.text_type is str or pyinfo.text_type is unicode
    assert pyinfo.integer_types[0] is int or pyinfo.integer_types[0] is long
    assert pyinfo.class_types[0] is type or pyinfo.class_types[0] is types.ClassType


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:40.449138
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 or pyinfo.PY3
    assert not (pyinfo.PY2 and pyinfo.PY3)

    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.string_types[0], type)
    assert isinstance('hello', pyinfo.string_types)

    assert isinstance(pyinfo.text_type, type)
    assert isinstance('hello', pyinfo.text_type)

    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(b'hello', pyinfo.binary_type)

    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.integer_types[0], type)
    assert isinstance(42, pyinfo.integer_types)



# Generated at 2022-06-24 03:23:49.150121
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("ABC", PyInfo.string_types)
        assert isinstance(u"ABC", PyInfo.string_types)
        assert not isinstance(b"ABC", PyInfo.string_types)

        assert isinstance(u"ABC", PyInfo.text_type)
        assert not isinstance(b"ABC", PyInfo.text_type)

        assert isinstance(b"ABC", PyInfo.binary_type)

        assert isinstance(123, PyInfo.integer_types)
        assert not isinstance(123.45, PyInfo.integer_types)

        assert isinstance(dict, PyInfo.class_types)
        assert isinstance(dict(), PyInfo.class_types)

        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:23:54.151048
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.maxsize)
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:58.682917
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-24 03:24:07.209193
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.text_type)
        assert not isinstance("a", PyInfo.text_type)
        assert isinstance("a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:24:12.823406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

