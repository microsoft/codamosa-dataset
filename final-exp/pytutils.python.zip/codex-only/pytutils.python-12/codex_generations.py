

# Generated at 2022-06-24 03:14:12.126857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize
    print("PyInfo class is ok")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:14:15.100125
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-24 03:14:20.174576
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:14:21.504227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2



# Generated at 2022-06-24 03:14:32.227996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance("string", PyInfo.string_types)
        assert isinstance("string", PyInfo.text_type)
        assert not (isinstance("string", PyInfo.binary_type))
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert isinstance("string", PyInfo.string_types)
        assert isinstance(u"string", PyInfo.text_type)
        assert not isinstance(b"string", PyInfo.text_type)
       

# Generated at 2022-06-24 03:14:42.580705
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    import pyinfo

    if pyinfo.PyInfo.PY3:
        assert isinstance("", pyinfo.PyInfo.string_types)
        assert not isinstance(b"", pyinfo.PyInfo.string_types)
        assert isinstance("", pyinfo.PyInfo.text_type)
        assert isinstance(b"", pyinfo.PyInfo.binary_type)
        assert isinstance(0, pyinfo.PyInfo.integer_types)
        assert not isinstance(0.01, pyinfo.PyInfo.integer_types)
        assert isinstance(str, pyinfo.PyInfo.class_types)
        assert not isinstance("", pyinfo.PyInfo.class_types)

# Generated at 2022-06-24 03:14:53.739143
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:15:00.880480
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(classmethod, PyInfo.class_types)


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 03:15:08.750974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:13.057135
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance("", PyInfo.string_types)
    isinstance(u"", PyInfo.string_types)
    isinstance(b"", PyInfo.binary_type)
    isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:17.040278
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2
    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None

# Generated at 2022-06-24 03:15:20.532486
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-24 03:15:29.988453
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance('abc', PyInfo.text_type)
        assert not isinstance(b'abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.integer_types)
        assert not isinstance(True, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
        assert not isinstance(1, PyInfo.class_types)
        assert not isinstance(True, PyInfo.class_types)
    elif PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)

# Generated at 2022-06-24 03:15:39.353982
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def func(arg1, arg2):
        if arg1 >= 1:
            if arg1 == 1 and arg2 >= 1:
                print(arg2)
            else:
                print("error")
        else:
            print("error")

    print("*** PyInfo class unit test start ***")
    print("Python Version:", sys.version)
    print("PyInfo.string_types:", PyInfo.string_types)
    print("PyInfo.binary_type:", type(PyInfo.binary_type))
    print("PyInfo.text_type:", type(PyInfo.text_type))
    print("PyInfo.integer_types:", PyInfo.integer_types)
    print("PyInfo.class_types:", PyInfo.class_types)
    print("PyInfo.maxsize:", PyInfo.maxsize)

# Generated at 2022-06-24 03:15:46.446222
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Is Python 2: {0}".format(PyInfo.PY2))
    print("Is Python 3: {0}".format(PyInfo.PY3))
    print("String types: {0}".format(PyInfo.string_types))
    print("Text type: {0}".format(PyInfo.text_type))
    print("Binary type: {0}".format(PyInfo.binary_type))
    print("Integer types: {0}".format(PyInfo.integer_types))
    print("Class types: {0}".format(PyInfo.class_types))
    print("Sys max size: {0}".format(PyInfo.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:47.887203
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:15:58.304952
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    if PyInfo.PY2:
        print('Python2: OK')
    else:
        print('Python3: OK')

    if PyInfo.PY2:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.text_type)
        assert isinstance('foo', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance('foo', PyInfo.text_type)
        assert isinstance(b'foo', PyInfo.binary_type)
        assert isinstance

# Generated at 2022-06-24 03:16:09.320307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import io
    import io as io2

    def f():
        pass

    assert PyInfo.PY2 or PyInfo.PY3
    assert (PyInfo.PY2 and not PyInfo.PY3) or (not PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('foo', PyInfo.string_types) and isinstance(u'foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.text_type)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types) and isinstance(2**32 + 1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types) and isinstance(2**64 + 1, PyInfo.integer_types)


# Generated at 2022-06-24 03:16:12.741993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-24 03:16:18.225390
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo

    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False

    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    elif PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    # Run unit tests
    test_PyInfo()

# Generated at 2022-06-24 03:16:24.874998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:16:30.737326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert 1, PyInfo.integer_types
    assert type(int) is PyInfo.class_types

# Generated at 2022-06-24 03:16:34.827071
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)
    assert isinstance(info.maxsize, int)


if __name__ == "__main__":
    # Run all unit tests
    for func in [eval(f) for f in dir() if f.startswith('test_')]:
        print('Unit test:', func.__name__)
        func()

# Generated at 2022-06-24 03:16:42.847799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """ Unit test for the class PyInfo. """
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-24 03:16:50.977855
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assertEqual(x, y):
        assert x == y, '%r == %r' % (x, y)

    assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
    # assertEqual(PyInfo.PY3, sys.version_info[0] == 3)  # Why failed?

    if PyInfo.PY3:
        assertEqual(PyInfo.string_types, (str,))
        assertEqual(PyInfo.text_type, str)
        assertEqual(PyInfo.binary_type, bytes)
        assertEqual(PyInfo.integer_types, (int,))
        assertEqual(PyInfo.class_types, (type,))
        assertEqual(PyInfo.maxsize, sys.maxsize)

# Generated at 2022-06-24 03:16:54.539880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check the class attributes
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-24 03:17:02.928257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import platform

    print("Python-%s %s %s %s %s" % (sys.version, platform.platform(), platform.architecture()[0], platform.machine(), platform.node()))

    print("PY2: %s" % PyInfo.PY2)
    print("PY3: %s" % PyInfo.PY3)

    from distutils.sysconfig import get_python_inc
    print("Python headers directory: %s" % get_python_inc())


# --- main ---
if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:06.564808
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types != ()
    assert PyInfo.text_type != ()
    assert PyInfo.binary_type != ()
    assert PyInfo.integer_types != ()
    assert PyInfo.class_types != ()

# Generated at 2022-06-24 03:17:12.252974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(5, PyInfo.integer_types)
    assert isinstance(lambda x: x, PyInfo.class_types)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:17:22.156809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check_attrs(obj):
        PY2 = sys.version_info[0] == 2
        PY3 = sys.version_info[0] == 3

        # Required attrs
        for attr in [
                'PY2',
                'PY3',
        ]:
            if not hasattr(obj, attr):
                raise Exception(
                    'Required attr not found: {}'.format(attr))

        # attr 'PY2'
        if not isinstance(getattr(obj, 'PY2'), bool):
            raise Exception('Required attr {} is not bool: {}'.format(
                'PY2', getattr(obj, 'PY2')))

        # attr 'PY3'

# Generated at 2022-06-24 03:17:26.086716
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        isinstance("", PyInfo.string_types)
        isinstance("", PyInfo.binary_type)
    else:
        isinstance("", PyInfo.string_types)
        isinstance("", PyInfo.text_type)
        isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-24 03:17:36.049421
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equals
    from nose.tools import assert_true
    from nose.tools import assert_false
    from nose.tools import assert_is_instance
    from nose.tools import assert_in
    from nose.tools import assert_raises

    pi = PyInfo()
    assert_is_instance(pi, PyInfo)

    assert_equals(pi.PY2, False)
    assert_equals(pi.PY3, True)

    assert_in(str, pi.string_types)
    assert_equals(pi.text_type, str)
    assert_equals(pi.binary_type, bytes)
    assert_in(int, pi.integer_types)
    assert_in(type, pi.class_types)
    assert_true(pi.maxsize > 1000)



# Generated at 2022-06-24 03:17:36.723994
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Generated at 2022-06-24 03:17:42.923552
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:49.048117
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize
    print("test_PyInfo() success!")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:56.515918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    if a.PY2:
        assert type(a.string_types) == tuple
        assert type(a.string_types[0]) == type(basestring)

        assert type(a.text_type) == unicode
        assert type(a.binary_type) == type(str)
        assert type(a.integer_types) == tuple
        assert type(a.integer_types[0]) == type(int)
        assert type(a.integer_types[1]) == type(long)
        assert type(a.class_types) == tuple
        assert type(a.class_types[0]) == type
        assert type(a.class_types[1]) == types.ClassType
        assert type(a.maxsize) == type(int((1 << 63) - 1))


# Generated at 2022-06-24 03:18:04.748788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)

    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)



# Generated at 2022-06-24 03:18:06.886625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:18:11.607046
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3



# Generated at 2022-06-24 03:18:22.410997
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # import sys
    # print(sys.version_info[0])

    # print(PyInfo.PY2)
    # print(PyInfo.PY3)

    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)


# Generated at 2022-06-24 03:18:32.658413
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class p(PyInfo):
        pass

    if sys.version_info[0] == 2:
        assert p.PY2 == True
        assert p.PY3 == False
        assert p.string_types == (basestring,)
        assert p.text_type == unicode
        assert p.integer_types == (int, long)
        assert p.class_types == (type, types.ClassType)
        assert p.maxsize >= 2147483647
    else:
        assert p.PY2 == False
        assert p.PY3 == True

# Generated at 2022-06-24 03:18:41.338128
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("sys.version_info", sys.version_info)
    print("PyInfo.PY2", PyInfo.PY2)
    print("PyInfo.PY3", PyInfo.PY3)
    print("PyInfo.string_types", PyInfo.string_types)
    print("PyInfo.text_type", PyInfo.text_type)
    print("PyInfo.binary_type", PyInfo.binary_type)
    print("PyInfo.integer_types", PyInfo.integer_types)
    print("PyInfo.class_types", PyInfo.class_types)
    print("PyInfo.maxsize", PyInfo.maxsize)



# Generated at 2022-06-24 03:18:50.283778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(u"".encode("utf8"), PyInfo.binary_type)
        assert isinstance(42, PyInfo.integer_types)

# Generated at 2022-06-24 03:18:51.652998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    tt = PyInfo
    assert tt.text_type == str



# Generated at 2022-06-24 03:18:56.588433
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_type(obj, PyInfo):
        for attr, type_ in PyInfo.__dict__.items():
            if attr.startswith('__') or isinstance(attr, types.FunctionType):
                continue
            assert isinstance(obj, type_)

    test_type(1, PyInfo)
    test_type(str(1), PyInfo)

# Generated at 2022-06-24 03:19:02.693776
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    assert isinstance("Type", info.string_types)
    assert isinstance(info.text_type(), info.string_types)
    assert isinstance(info.binary_type(), bytes)
    assert isinstance(1, info.integer_types)
    assert isinstance(info, info.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:10.990155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    True
    >>> PyInfo.PY3
    False
    >>> isinstance('123', PyInfo.string_types)
    True
    >>> isinstance(b'123', PyInfo.binary_type)
    True
    >>> isinstance(2**31-1, PyInfo.integer_types)
    True
    >>> isinstance(object, PyInfo.class_types)
    True
    >>> PyInfo.text_type is unicode
    True
    >>> PyInfo.maxsize
    9223372036854775807
    """



# Generated at 2022-06-24 03:19:20.845838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from bson import tz_util
    from bson.py3compat import b, u
    from bson.tz_util import utc

    # Ensure that if this test fails we have the right version of Python.
    # I don't know of a better way to test this.
    assert sys.version_info[:2] == (2, 7) or sys.version_info[:2] == (3, 5)

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)


# Generated at 2022-06-24 03:19:25.241832
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-24 03:19:31.993833
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is False
    assert info.PY3 is True

# Generated at 2022-06-24 03:19:41.681131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == int(sys.version_info[0]) == 2
    assert PyInfo.PY3 == int(sys.version_info[0]) == 3
    if PyInfo.PY3:
        assert PyInfo.maxsize == 2 ** 63 - 1
    else:
        # Jython always uses 32 bits.
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == 2 ** 31 - 1
        else:
            if 2 ** 31 - 1 == int(sys.maxsize) ** 2:
                assert PyInfo.maxsize == 2 ** 31 - 1
            else:
                assert PyInfo.maxsize == 2 ** 63 - 1

# Generated at 2022-06-24 03:19:47.600739
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance('', PyInfo.text_type)
    else:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.text_type)
    assert PyInfo.PY2 != PyInfo.PY3

# Generated at 2022-06-24 03:19:50.401730
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)


test_PyInf

# Generated at 2022-06-24 03:19:58.193536
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pymongo.errors import InvalidOperation

    class SomeClass(object):
        pass

    x = PyInfo()
    assert isinstance('', x.string_types)
    assert isinstance(u'', x.string_types)
    assert isinstance(b'', x.string_types)
    assert not isinstance(SomeClass, x.string_types)
    assert isinstance(u'', x.text_type)
    assert not isinstance('', x.text_type)
    assert isinstance(b'', x.binary_type)
    assert not isinstance(u'', x.binary_type)
    assert isinstance(1, x.integer_types)
    assert isinstance(long(1), x.integer_types)
    assert not isinstance(1.2, x.integer_types)
    assert isinstance

# Generated at 2022-06-24 03:20:03.918272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3


# Test creation of class PyInfo as singleton

# Generated at 2022-06-24 03:20:11.336586
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:20:15.399740
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "PY2 or PY3 should be True"
    assert not PyInfo.PY2 or not PyInfo.PY3, "PY2 and PY3 cannot be True at same time"



# Generated at 2022-06-24 03:20:24.463275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3
    if pi.PY2:
        assert isinstance(u'', pi.text_type)
        assert isinstance('', pi.binary_type)
        assert isinstance(1, pi.integer_types)
        assert issubclass(type, pi.class_types)
        assert isinstance('', pi.string_types)
    else:
        assert isinstance('', pi.text_type)
        assert isinstance(b'', pi.binary_type)
        assert isinstance(1, pi.integer_types)
        assert issubclass(type, pi.class_types)
        assert isinstance('', pi.string_types)



# Generated at 2022-06-24 03:20:33.832806
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:38.568715
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    assert PyInfo.string_types == (str, unicode)
    assert PyInfo.text_type == (unicode if PyInfo.PY2 else str)
    assert PyInfo.binary_type == (bytes if PyInfo.PY3 else str)

# Generated at 2022-06-24 03:20:43.652578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    if p.PY2:
        assert type(u'abc') == unicode
        assert type(b'abc') == str

    if p.PY3:
        assert type(u'abc') == str
        assert type(b'abc') == bytes


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:54.834594
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types[0], str)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types[0], int)
        assert isinstance(PyInfo.class_types[0], type)
    else:
        assert isinstance(PyInfo.string_types[0], basestring)
        assert isinstance(PyInfo.text_type, unicode)
        assert isinstance(PyInfo.binary_type, str)

# Generated at 2022-06-24 03:20:59.423919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:21:03.754690
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-24 03:21:09.363271
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == True or PyInfo().PY3 == True

    assert type('string') in PyInfo().string_types
    assert type(u'string') in PyInfo().string_types

    assert type(0) in PyInfo().integer_types

# Generated at 2022-06-24 03:21:11.137155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().maxsize, int) \
        or isinstance(PyInfo().maxsize, long)

# Generated at 2022-06-24 03:21:12.989045
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert isinsta

# Generated at 2022-06-24 03:21:18.469636
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types



# Generated at 2022-06-24 03:21:24.645882
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or not PyInfo.PY2
    assert PyInfo.PY3 or not PyInfo.PY3
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.text_type)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert issubclass(type(str), PyInfo.class_types)



# Generated at 2022-06-24 03:21:28.269402
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert (isinstance('', PyInfo.string_types))
    assert (isinstance(u'', PyInfo.string_types))

    assert (isinstance('', PyInfo.text_type))
    assert (isinstance(u'', PyInfo.text_type))

# Generated at 2022-06-24 03:21:32.788912
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, unicode)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:21:39.647891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:21:48.362464
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(expected, actual, msg=None):
        if expected is not actual:
            raise AssertionError(
                "expected %s, not %s" % (expected, actual))

    check(PyInfo.PY2, not PyInfo.PY3)
    check(PyInfo.string_types, (str, basestring))
    check(PyInfo.text_type, str)
    check(PyInfo.binary_type, bytes)
    check(PyInfo.integer_types, (int, long))
    check(PyInfo.class_types, (type, types.ClassType))
    check(PyInfo.maxsize, sys.maxsize)


# Generated at 2022-06-24 03:21:54.768771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'a', PyInfo.text_type)
        assert isinstance('a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(Exception, PyInfo.class_types)

# Generated at 2022-06-24 03:21:58.333492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:07.538579
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check PyInfo.PY2 and PyInfo.PY3
    assert (PyInfo.PY2 ^ PyInfo.PY3)

    # Check PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type,
    # PyInfo.integer_types and PyInfo.class_types
    if PyInfo.PY3:
        assert (PyInfo.string_types == (str,))
        assert (PyInfo.text_type == str)
        assert (PyInfo.binary_type == bytes)
        assert (PyInfo.integer_types == (int,))
        assert (PyInfo.class_types == (type,))
    else:
        assert (PyInfo.string_types == (basestring,))
        assert (PyInfo.text_type == unicode)

# Generated at 2022-06-24 03:22:11.717826
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:19.895559
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-24 03:22:30.614140
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:22:34.851964
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int



# Generated at 2022-06-24 03:22:41.080671
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:22:43.110454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type, PyInfo.integer_types, PyInfo.class_types, PyInfo.maxsize)



# Generated at 2022-06-24 03:22:53.259892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('x', PyInfo.string_types)
    assert isinstance('x', PyInfo.text_type)
    assert isinstance(b'x', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert PyInfo.maxsize > 0
    assert sys.maxsize == PyInfo.maxsize, \
        '{} != {}'.format(sys.maxsize, PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:58.198112
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(12345, PyInfo.integer_types)

    def foo():
        pass

    assert isinstance(foo, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:05.433604
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_value(name, value, expected_value):
        assert value == expected_value, '{} not equal to {}'.format(value, expected_value)

    test_value('PY2', PyInfo.PY2, sys.version_info[0] == 2)
    test_value('PY3', PyInfo.PY3, sys.version_info[0] == 3)

    if PyInfo.PY3:
        test_value('string_types[0]', PyInfo.string_types[0], str)
        test_value('text_type', PyInfo.text_type, str)
        test_value('binary_type', PyInfo.binary_type, bytes)
        test_value('integer_types[0]', PyInfo.integer_types[0], int)

# Generated at 2022-06-24 03:23:09.622241
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 03:23:15.928392
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types[0], type)
    else:
        assert not issubclass(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:23:22.128090
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class_types = (type, types.ClassType)  # types only exists on PY2
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == class_types



# Generated at 2022-06-24 03:23:30.569659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("abcd", PyInfo.string_types)
        assert isinstance(u"abcd", PyInfo.text_type)
        assert isinstance(b"abcd", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

    else:
        assert isinstance(b"abcd", PyInfo.string_types)
        assert isinstance(u"abcd", PyInfo.text_type)
        assert isinstance(b"abcd", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:23:33.790211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == True if sys.version_info[0] == 3 else False
    assert PyInfo.PY2 == True if sys.version_info[0] == 2 else False

# Generated at 2022-06-24 03:23:39.312557
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-24 03:23:47.677170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-24 03:23:56.562837
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert id(PyInfo.string_types[0]) == id(str)
    assert PyInfo.string_types[0] is str
    assert id(PyInfo.text_type) == id(str)
    assert PyInfo.text_type is str
    assert id(PyInfo.binary_type) == id(bytes)
    assert PyInfo.binary_type is bytes
    assert id(PyInfo.integer_types[0]) == id(int)
    assert PyInfo.integer_types[0] is int
    assert id(PyInfo.class_types[0]) == id(type)
    assert PyInfo.class_types[0] is type
    assert PyInfo.string_types[0] is str
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-24 03:24:01.269592
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-24 03:24:08.662722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

