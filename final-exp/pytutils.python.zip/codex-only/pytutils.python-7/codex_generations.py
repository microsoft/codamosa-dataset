

# Generated at 2022-06-24 03:14:17.447012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    print(dir(PyInfo))
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


# Main function

# Generated at 2022-06-24 03:14:26.137911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> i = PyInfo()
    >>> if i.PY3:
    ...     i.string_types == (str,)
    ...     i.text_type == str
    ...     i.binary_type == bytes
    ...     i.integer_types == (int,)
    ...     i.class_types == (type,)
    ...     i.maxsize == 281474976710655
    ... else:
    ...     i.string_types == (basestring,)
    ...     i.text_type == unicode
    ...     i.binary_type == str
    ...     i.integer_types == (int, long)
    ...     i.class_types == (type, types.ClassType)
    ...     i.maxsize == 9223372036854775807
    True
    >>>
    """

# Generated at 2022-06-24 03:14:32.074676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(PyInfo.text_type(""), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(b""), PyInfo.string_types)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:14:42.557222
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert "str" in pyinfo.string_types
    assert "unicode" in pyinfo.string_types
    assert "str" in pyinfo.class_types
    assert "unicode" in pyinfo.class_types
    assert "int" in pyinfo.class_types
    assert "long" in pyinfo.class_types
    assert "bytes" in pyinfo.binary_type
    assert "str" in pyinfo.binary_type
    assert pyinfo.binary_type == pyinfo.binary_type
    assert "str" in pyinfo.text_type
    assert "unicode" in pyinfo.text_

# Generated at 2022-06-24 03:14:53.461160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = sys.version_info[0] == 2
    assert PyInfo.PY2 == py2
    assert PyInfo.PY3 != py2

    if py2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode

        # On Python 2.7, PyInfo.text_type is str,
        # which is a superclass of unicode.
        assert issubclass(str, unicode)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert not issubclass(str, unicode)

    assert PyInfo.binary_type == bytes


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:14:58.196465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _ = PyInfo()
    print(type(PyInfo.PY2))
    print(type(PyInfo.PY3))
    print(type(PyInfo.string_types))
    print(type(PyInfo.text_type))
    print(type(PyInfo.binary_type))
    print(type(PyInfo.integer_types))
    print(type(PyInfo.class_types))
    print(type(PyInfo.maxsize))



# Generated at 2022-06-24 03:15:05.308073
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance(str, PyInfo.string_types)
        assert isinstance(str(), PyInfo.string_types)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert isinstance(int, PyInfo.integer_types)
        assert isinstance(int(), PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(type(''), PyInfo.class_types)

        assert PyInfo.maxsize >= sys.maxsize

# Generated at 2022-06-24 03:15:10.098244
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)

    assert sys.version_info[0] == 2
    assert sys.version_info[0] == 3



# Generated at 2022-06-24 03:15:11.540468
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 is True or PyInfo().PY3 is True



# Generated at 2022-06-24 03:15:17.877885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('s') is str
        assert type('s') is not types.UnicodeType
        assert type(u's') is types.UnicodeType
        assert type(u's') is not str
        assert PyInfo.maxsize == (2 ** 31) - 1

    elif PyInfo.PY3:
        assert type('s') is str
        assert type(u's') is str
        assert PyInfo.maxsize == (2 ** 63) - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:27.832416
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    # sys.version_info[0] == 2
    # sys.version_info[0] = 3
    # sys.version_info[0] == 2
    sys.version_info[0] = 2

    pyinfo = PyInfo()
    assert pyinfo.PY2 == True
    assert pyinfo.PY3 == False
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.maxsize == int((1 << 31) - 1)

    # PY3
    # sys.version_info[0] == 2
    # sys.version_info[0] = 3
    # sys.version_info[0

# Generated at 2022-06-24 03:15:32.402479
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    """
    Test the constructor of the class PyInfo.
    :return: none
    """
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert isinstance(pyinfo.string_types, tuple) is True
    if pyinfo.PY3:
        assert pyinfo.text_type is str
        assert pyinfo.binary_type is bytes
        assert isinstance(pyinfo.integer_types, tuple) is True
        assert pyinfo.class_types is type
        assert pyinfo.maxsize > 0
    else:  # PY2
        assert pyinfo.text_type is unicode
        assert pyinfo.binary_type is str
        assert isinstance(pyinfo.integer_types, tuple) is True
        assert pyinfo

# Generated at 2022-06-24 03:15:33.431699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:15:40.885596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        def test_string_types(self):
            self.assertEqual(isinstance('str', PyInfo.string_types), True)
            if not PyInfo.PY3:
                self.assertEqual(isinstance(u'unicode', PyInfo.string_types), True)

        def test_text_type(self):
            self.assertEqual(isinstance('str', PyInfo.text_type), True)

        def test_binary_type(self):
            self.assertEqual(isinstance('str', PyInfo.binary_type), True)
            if not PyInfo.PY3:
                self.assertEqual(isinstance(u'unicode', PyInfo.text_type), True)


# Generated at 2022-06-24 03:15:46.940405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class_types = PyInfo.class_types
    assert isinstance(class_types, tuple)
    assert isinstance(class_types[0], (type, types.ClassType))
    assert len(class_types) == 2
    assert type(class_types[0]) is class_types[1]


# Module aliases
py2 = PyInfo.PY2
py3 = PyInfo.PY3

string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types

maxsize = PyInfo.maxsize

# Generated at 2022-06-24 03:15:55.136087
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:00.822088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None and PyInfo.PY2 is not None
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.text_type is not None
    assert isinstance(PyInfo.binary_type, type)
    assert PyInfo.binary_type is not None
    assert isinstance(PyInfo.integer_types, tuple)
    assert PyInfo.integer_types is not None
    assert isinstance(PyInfo.class_types, tuple)
    assert PyInfo.class_types is not None
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize is not None


# Main function

# Generated at 2022-06-24 03:16:10.165963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pinfo = PyInfo()
    assert isinstance(pinfo, PyInfo)
    assert len(pinfo.string_types) == 1
    assert callable(pinfo.string_types[0])
    assert isinstance(pinfo, PyInfo)

    assert isinstance(pinfo.text_type, PyInfo.string_types[0])
    assert isinstance(pinfo.binary_type, PyInfo.string_types[0])
    assert len(pinfo.integer_types) == 2
    assert isinstance(pinfo.text_type, PyInfo.string_types[0])
    assert isinstance(pinfo.binary_type, PyInfo.string_types[0])
    assert len(pinfo.integer_types) == 2

# Generated at 2022-06-24 03:16:19.696095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = type(None)
    assert PyInfo.PY2 == (a is types.NoneType)
    assert PyInfo.PY3 == (a is type(None))

    a = str("")
    assert PyInfo.PY2 == (a is types.StringType)
    assert PyInfo.PY3 == (a is str)

    a = str("A")
    assert PyInfo.PY2 == (a is types.StringType)
    assert PyInfo.PY3 == (a is str)

    a = str("ABC")
    assert PyInfo.PY2 == (a is types.StringType)
    assert PyInfo.PY3 == (a is str)

    a = str(u"")
    assert PyInfo.PY2 == (a is types.UnicodeType)

# Generated at 2022-06-24 03:16:27.538147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    for s in ["a", u"a"]:
        assert isinstance(s, PyInfo.string_types)
    assert isinstance(u"a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)

# Generated at 2022-06-24 03:16:36.616733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal, assert_true
    assert_equal(PyInfo.PY2, False)
    assert_equal(PyInfo.PY3, True)
    assert_true(type(PyInfo.string_types) is tuple)
    assert_true(type(PyInfo.text_type) is str)
    assert_true(type(PyInfo.binary_type) is bytes)
    assert_true(type(PyInfo.integer_types) is tuple)
    assert_true(type(PyInfo.class_types) is tuple)
    assert_true(type(PyInfo.maxsize) is int)
    assert_true(PyInfo.maxsize > 0)



# Generated at 2022-06-24 03:16:39.242299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.__dict__


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:44.911063
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    for cls in PyInfo.string_types + PyInfo.integer_types + \
            (PyInfo.maxsize,):
        print('isinstance(1,' + str(cls) + '):', isinstance(1, cls))
    if PyInfo.PY3:
        assert isinstance(1, (int,))
    else:
        assert isinstance(1, (int, long))
    assert isinstance(1, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:52.821834
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("test", PyInfo.string_types)
        assert not isinstance(b"test", PyInfo.string_types)
        assert isinstance(u"test", PyInfo.string_types)
    else:
        assert isinstance("test", PyInfo.string_types)
        assert isinstance(b"test", PyInfo.string_types)
        assert not isinstance(u"test", PyInfo.string_types)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:16:59.719824
# Unit test for constructor of class PyInfo
def test_PyInfo():  # pragma: no cover
    p = PyInfo()
    assert p.PY2 or p.PY3
    assert (not p.PY2) or (not p.PY3)
    if p.PY2:
        assert isinstance(u'', p.text_type)
    if p.PY3:
        assert isinstance(b'', p.binary_type)

# Generated at 2022-06-24 03:17:01.527335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-24 03:17:04.004613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize != sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:07.819168
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple

# Generated at 2022-06-24 03:17:14.801708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X(object):

        def __len__(self):
            return 1 << 31

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    assert isinstance(1 << 63, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    try:
        len(X())
    except OverflowError:
        # 32-bit : no raise
        pass
    else:
        # 64-bit : raise
        raise
    del X

# Generated at 2022-06-24 03:17:21.660066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('s', PyInfo.string_types)
    assert isinstance(b'b', PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance('s', PyInfo.text_type)

# Generated at 2022-06-24 03:17:26.801778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Uncomment the following lines to print PyInfo's values
    # for k, v in PyInfo.__dict__.items():
    #     if k[:2] != '__':
    #         print('%s: %s' % (k, v))
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:36.341022
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert hasattr(py_info, "PY2") and hasattr(py_info, "PY3")
    assert type(py_info.PY2) is bool and type(py_info.PY3) is bool
    assert py_info.PY2 + py_info.PY3 == 1

    assert hasattr(py_info, "string_types") and hasattr(py_info, "text_type")
    assert type(py_info.string_types) is tuple and type(py_info.text_type) is type
    assert type(py_info.string_types[0]) is type
    assert py_info.string_types[0] == py_info.text_type


# Generated at 2022-06-24 03:17:46.636080
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        if PyInfo.PY2:
            from StringIO import StringIO
            from urllib import urlopen, urlencode
            from urlparse import parse_qsl
            from urlparse import urlparse
            from urlparse import urlunparse
        else:
            from io import StringIO
            from urllib.parse import parse_qsl
            from urllib.parse import urlparse
            from urllib.parse import urlunparse
            from urllib.request import urlopen
            from urllib.parse import urlencode
    except ImportError:
        return


# Generated at 2022-06-24 03:17:49.676110
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str

# Generated at 2022-06-24 03:17:57.136076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:00.890595
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:18:07.778737
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert set(PyInfo.string_types) == set([str, unicode])
    assert set([PyInfo.text_type]) == set([unicode])
    assert set([PyInfo.binary_type]) == set([str])
    assert set(PyInfo.integer_types) == set([int, long])
    assert set(PyInfo.class_types) == set([type, types.ClassType])
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == int((1 << 31) - 1)
    else:
        assert PyInfo.maxsize == int((1 << 31) - 1) or PyInfo.maxsize == int((1 << 63) - 1)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:15.532583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (sys.version_info[0] == 2)
    assert p.PY3 == (sys.version_info[0] == 3)
    assert p.string_types == (str, unicode)
    assert p.text_type == unicode
    assert p.binary_type == str
    assert p.integer_types == (int, long)
    assert p.class_types == (type, types.ClassType)
    assert p.maxsize == sys.maxsize

# Generated at 2022-06-24 03:18:21.140259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:18:30.318541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    test_PyInfo()
    print("Done")

# Generated at 2022-06-24 03:18:36.344378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is not True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 31 - 1, PyInfo.integer_types)
    assert isinstance(2 ** 63 - 1, PyInfo.integer_types)

# Generated at 2022-06-24 03:18:38.381841
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)



# Generated at 2022-06-24 03:18:42.631471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:18:48.709805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:18:52.029764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import struct

    # We need this to distinguish 32-bit from 64-bit Python
    # and from Jython 2.
    assert struct.calcsize("P") * 8 == PyInfo.maxsize.bit_length()



# Generated at 2022-06-24 03:18:53.574393
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is Fal

# Generated at 2022-06-24 03:19:03.580329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    # check string_types
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    # check text_type
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    # check binary_type
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)
    # check integer_types
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:05.623312
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:19:08.925956
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.integer_types == (int, long)
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-24 03:19:11.873583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types

# Generated at 2022-06-24 03:19:21.533657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(99999, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:31.628424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    if pi.PY2:
        assert pi.PY3 == False
    else:
        assert pi.PY3 == True

    assert isinstance("test", pi.string_types)
    assert isinstance(u"test", pi.string_types)
    assert not isinstance(1, pi.string_types)

    assert isinstance("test", pi.text_type)
    assert isinstance(u"test", pi.text_type)
    assert not isinstance(1, pi.text_type)

    assert isinstance("test", pi.binary_type)
    assert not isinstance(u"test", pi.binary_type)
    assert not isinstance(1, pi.binary_type)

    assert isinstance(1, pi.integer_types)

# Generated at 2022-06-24 03:19:35.892520
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2
    assert type("") is str
    assert isinstance(1, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:45.609712
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance('', PyInfo.integer_types)

# Generated at 2022-06-24 03:19:55.880856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:01.533807
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-24 03:20:11.077030
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    # Test of properties
    assert type(PyInfo.string_types) is tuple
    for item in PyInfo.string_types:
        assert type(item) is type
    assert type(PyInfo.string_types[0]) is str

    assert type(PyInfo.text_type) is type
    assert type(PyInfo.text_type()) is str

    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.binary_type()) is bytes

    assert type(PyInfo.integer_types) is tuple
    for item in PyInfo.integer_types:
        assert type(item) is type
    assert type(PyInfo.integer_types[0]) is int

    assert type(PyInfo.class_types) is tuple

# Generated at 2022-06-24 03:20:19.884553
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # Some tests will fail in Jython 2.7
    if not sys.platform.startswith("java"):
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.maxsize > 0


# Unix timestamps, in seconds
# See: https://en.wikipedia.org/wiki/Unix_time
if PyInfo.PY3:

    def timestamp(dt):
        """Returns the number of seconds since the epoch, floating point."""
        return time.mktime(dt.timetuple()) + dt.microsecond / 1000000.0


else:

    def timestamp(dt):
        """Returns the number of seconds since the epoch, floating point."""

# Generated at 2022-06-24 03:20:21.377132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.str == str

    # TODO: complete the test

# Generated at 2022-06-24 03:20:27.670932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-24 03:20:37.008946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2

    py_str = str if not py2 else (str, unicode)
    py_int = int if not py2 else (int, long)
    py_class = type if not py2 else (type, types.ClassType)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], py_str)

    assert isinstance(PyInfo.text_type, py_str)

    assert isinstance(PyInfo.binary_type, bytes)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], py_int)

    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], py_class)

# Generated at 2022-06-24 03:20:39.251507
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test if PyInfo can be built:", end=' ')
    assert PyInfo() is not None
    print("OK.")

# Generated at 2022-06-24 03:20:41.396880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Current python version is:", pyinfo.PY2)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:48.098127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 2 ** 63 - 1

test_PyInfo()

# Generated at 2022-06-24 03:20:51.146929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:20:54.376543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False

# Generated at 2022-06-24 03:21:02.849766
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,), type(PyInfo.string_types)
        assert PyInfo.text_type == unicode, type(PyInfo.text_type)
        assert PyInfo.binary_type == str, type(PyInfo.binary_type)
        assert PyInfo.integer_types == (int, long), type(PyInfo.integer_types)
        assert PyInfo.class_types == (type, types.ClassType), type(PyInfo.class_types)
        assert isinstance(PyInfo.maxsize, (int, long)), type(PyInfo.maxsize)

    else:  # py3
        assert PyInfo.string_types == (str,), type(PyInfo.string_types)

# Generated at 2022-06-24 03:21:11.050894
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isPy2 = sys.version_info[0] == 2
    assert isPy2 == PyInfo.PY2

    isPy3 = sys.version_info[0] == 3
    assert isPy3 == PyInfo.PY3

    x = "abc"
    if PyInfo.PY3:
        assert isinstance(x, PyInfo.string_types)
        assert not isinstance(x, PyInfo.text_type)
        assert isinstance(x, PyInfo.binary_type)
    else:
        # PY2
        assert isinstance(x, PyInfo.string_types)
        assert isinstance(x, PyInfo.text_type)
        assert not isinstance(x, PyInfo.binary_type)

    x = "abc".encode("utf-8")

# Generated at 2022-06-24 03:21:16.707753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:21:21.839169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    if (PyInfo.PY2 and PyInfo.PY3):
        pytest.fail('Only one of "PyInfo.PY2 and PyInfo.PY3" should be True')

    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-24 03:21:25.556759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 or PyInfo.PY3)
    assert(PyInfo.string_types)
    assert(PyInfo.text_type)
    assert(PyInfo.binary_type)
    assert(PyInfo.integer_types)
    assert(PyInfo.class_types)

# Generated at 2022-06-24 03:21:36.403991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from .utils import eq_, ok_

    if PyInfo.PY2:
        ok_(PyInfo.PY3 is not True)
        ok_(PyInfo.binary_type is not PyInfo.text_type)
        ok_(PyInfo.string_types != PyInfo.class_types)
    else:
        ok_(PyInfo.PY2 is not True)
        ok_(PyInfo.class_types != PyInfo.string_types)

    eq_(
        PyInfo.string_types,
        (
            str,
            str,
            types.StringType,
            types.UnicodeType,
            types.StringTypes,
            types.UnicodeType,
            types.StringTypes,
            types.StringType,
        ),
    )

# Generated at 2022-06-24 03:21:45.871765
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)

        assert isinstance(PyInfo.text_type, type)

        assert isinstance(PyInfo.binary_type, type)

        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.integer_types[0], type)

        assert isinstance(PyInfo.class_types, type)

        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:21:47.735265
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
 

# Generated at 2022-06-24 03:21:51.918311
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.string_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.maxsize, int)



# Generated at 2022-06-24 03:22:00.324318
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert str in PyInfo.string_types
    assert unicode in PyInfo.string_types
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert int in PyInfo.integer_types
    assert long in PyInfo.integer_types
    assert PyInfo.class_types == (type,) if PyInfo.PY3 else (type, types.ClassType)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:08.741556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3
    assert pi.PY2 ^ pi.PY3
    assert isinstance("", pi.string_types)
    assert isinstance(u"", pi.string_types)
    assert isinstance(b"", pi.binary_type)
    assert isinstance(1, pi.integer_types)

# Generated at 2022-06-24 03:22:14.716616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 31) - 1)


# Test function that uses PyInfo

# Generated at 2022-06-24 03:22:15.710152
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3

# Generated at 2022-06-24 03:22:17.685337
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("s", PyInfo.string_types)
    assert isinstance("s", PyInfo.string_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:21.962457
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes



# Generated at 2022-06-24 03:22:27.944651
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:31.022117
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    assert isinstance(obj, object)
    assert obj.PY2 == sys.version_info[0] == 2
    assert obj.PY3 == sys.version_info[0] == 3



# Generated at 2022-06-24 03:22:40.997522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:22:43.066001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types



# Generated at 2022-06-24 03:22:44.063465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # verify
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:22:45.928854
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Creating a class util to print a json

# Generated at 2022-06-24 03:22:51.239024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:57.425380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        # Some astroturf property
        assert PyInfo.bleh

    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-24 03:23:04.805195
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    if 2 == sys.version_info[0]:
        assert isinstance("", PyInfo.string_types) is True
        assert isinstance(u"", PyInfo.string_types) is False
        assert isinstance(1, PyInfo.integer_types) is True

# Generated at 2022-06-24 03:23:12.155482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:18.014416
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert hasattr(PyInfo, 'PY2')
    assert hasattr(PyInfo, 'PY3')
    assert hasattr(PyInfo, 'string_types')
    assert hasattr(PyInfo, 'text_type')
    assert hasattr(PyInfo, 'binary_type')
    assert hasattr(PyInfo, 'integer_types')
    assert hasattr(PyInfo, 'class_types')
    assert hasattr(PyInfo, 'maxsize')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:21.902798
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # In PY2, maxsize is int
    if PY2:
        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.maxsize, (int, long))


# ================================================================
#                   Paths
# ================================================================



# Generated at 2022-06-24 03:23:31.729991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTestCase(unittest.TestCase):
        def test_py_number(self):
            self.assertTrue(PyInfo.PY2 or PyInfo.PY3)

            self.assertTrue(PyInfo.PY2 != PyInfo.PY3)

        def test_string_types(self):
            for cls in PyInfo.string_types:
                self.assertTrue(isinstance(cls(), PyInfo.string_types))

        def test_text_type(self):
            self.assertTrue(isinstance(PyInfo.text_type(), PyInfo.string_types))
            self.assertTrue(isinstance(PyInfo.text_type(), PyInfo.text_type))


# Generated at 2022-06-24 03:23:38.669089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:41.201622
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance(u'hello', PyInfo.string_types)
    assert isinstance(b'hello', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:44.465535
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Just make sure it's really defined
    if not PyInfo.PY2:
        assert PyInfo.PY3
    if not PyInfo.PY3:
        assert PyInfo.PY2

# Generated at 2022-06-24 03:23:54.156576
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_cases = [
        ("PY2", PyInfo.PY2),
        ("PY3", PyInfo.PY3),
        ("string_types", PyInfo.string_types),
        ("text_type", PyInfo.text_type),
        ("binary_type", PyInfo.binary_type),
        ("integer_types", PyInfo.integer_types),
        ("class_types", PyInfo.class_types),
        ("maxsize", PyInfo.maxsize),
    ]

    for (name, attr) in test_cases:
        if not isinstance(attr, type(None)):
            assert_that(attr, not_none)
        assert_that(attr, instance_of(type(None)))


if __name__ == '__main__':
    # Unit test
    test_PyInfo()

# Generated at 2022-06-24 03:23:58.407482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (str, unicode)
        assert isinstance('', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert PyInfo.string_types == (str, )
        assert isinstance('', PyInfo.text_type)
        a

# Generated at 2022-06-24 03:24:02.475099
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.binary_type)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.integer_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:24:03.930300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(repr(PyInfo.string_types))
    print(PyInfo.maxsize)

# Generated at 2022-06-24 03:24:11.758868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == str if PyInfo.PY2 else str
    assert PyInfo.binary_type == bytes if PyInfo.PY2 else str
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int, )
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type, )