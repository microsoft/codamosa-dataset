

# Generated at 2022-06-24 03:14:20.905646
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)

    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    assert isinstance('a', PyInfo.text_type)
    assert isinstance("", PyInfo.text_type)

    assert not isinstance(b"a", PyInfo.text_type)
    assert not isinstance(b'a', PyInfo.text_type)

# Generated at 2022-06-24 03:14:28.849843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if python version is 2
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)

    # Check if python version is 3
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)

# Generated at 2022-06-24 03:14:30.260747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 or PyInfo.PY3)


# Tests for constructor of class PyInfo

# Generated at 2022-06-24 03:14:39.043012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert isinstance(b"byte", PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)
    assert issubclass(PyInfo.integer_types, PyInfo.integer_types)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo.integer_types, PyInfo.class_types)

# Generated at 2022-06-24 03:14:42.174013
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from simplescn.common.pyinfo import PyInfo
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert isinstance('a', PyInfo.text_type)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:14:49.217773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    local_vars = vars()
    for member in dir(PyInfo):
        obj = getattr(PyInfo, member)
        if not member.startswith("_") and not inspect.ismethod(obj):
            local_vars.pop(member, None)
            assert locals() == local_vars, member


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:14:52.397337
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)



# Generated at 2022-06-24 03:14:56.712269
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:03.046677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(' ', PyInfo.string_types)
    assert isinstance(u' ', PyInfo.string_types)
    assert isinstance(b' ', PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:11.112376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:12.150944
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2==True
    assert PyInfo.PY3==False

# Generated at 2022-06-24 03:15:17.156120
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


pyinfo = PyInfo()

if pyinfo.PY2:
    # Fix up situations where the pytest-cov plugin messes with sys.path on
    # Python 2. See https://bitbucket.org/ned/coveragepy/issue/293
    site_packages = next(
        i for i in sys.path if "site-packages" in i
    )
    sys.path.insert(0, site_packages)

# Generated at 2022-06-24 03:15:26.894461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == 2147483647


# Methods of class PyInfo
# def add_metaclass(metaclass):
# def is_class(x):
# def is_integer(x):
# def is_text(x):
# def is_python_identifier(x):
# def is_single_integer(x):
# def is_typed_tuple(x):
# def is_typed_tuple_of(x, type_):


# Generated at 2022-06-24 03:15:32.333042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:42.202234
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import platform
    from itertools import product
    from nose.tools import assert_true, assert_raises

    py_major, py_minor = [int(version) for version in platform.python_version_tuple()[:2]]

    for major, minor in product(range(0, py_major), range(0, py_minor)):
        if major > 0:
            PY2 = True
            PY3 = False
            integer_types = (int, long)
            class_types = (type, types.ClassType)
            maxsize = (1 << 31) - 1
        else:
            PY2 = False
            PY3 = True
            integer_types = (int,)
            class_types = (type,)
            maxsize = sys.maxsize

# Generated at 2022-06-24 03:15:45.361262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass
    # assert PyInfo.PY3 == False
    # assert PyInfo.PY2 == True
    # assert PyInfo.maxsize == 9223372036854775807
    # assert PyInfo.maxsize == PyInfo.maxsize



# Generated at 2022-06-24 03:15:54.463140
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:16:01.632333
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:16:11.451957
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    if not PyInfo.PY3:
        assert isinstance(u"", PyInfo.string_types)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance("", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:15.889634
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    my_str = 'test str'
    assert type(my_str) in PyInfo.string_types



# Generated at 2022-06-24 03:16:25.762772
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize > 0


if PyInfo.PY2:
    builtin_module_names = (
        "__builtin__",
        "__main__",
        "exceptions",
        "gc",
        "imp",
        "marshal",
        "posix",
        "signal",
        "sys",
        "_thread",
        "_weakref",
        "__phello__.embedded",
    )

# Generated at 2022-06-24 03:16:36.018606
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )

# Generated at 2022-06-24 03:16:44.676104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.text_type == PyInfo.string_types[0]
        assert PyInfo.binary_type is not PyInfo.text_type
    else:
        assert PyInfo.text_type is not PyInfo.string_types[0]
        assert PyInfo.binary_type is PyInfo.string_types[0]

    if PyInfo.PY2:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)

# Generated at 2022-06-24 03:16:55.441969
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def checkType(instance, expected_type):
        if not isinstance(instance, expected_type):
            raise TypeError("Expected type: [%s] was: [%s]" %
                            (expected_type, type(instance)))

    checkType(PyInfo.PY2, bool)
    checkType(PyInfo.PY3, bool)

    for instance in PyInfo.string_types:
        checkType(instance, type)
    checkType(PyInfo.text_type, type)
    checkType(PyInfo.binary_type, type)

    for instance in PyInfo.integer_types:
        checkType(instance, type)

    for instance in PyInfo.class_types:
        checkType(instance, type)
    checkType(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:16:59.462335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert PY2 == info.PY2
    assert PY3 == info.PY3



# Generated at 2022-06-24 03:17:07.939896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple

    assert type(PyInfo.maxsize) == int

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:17:08.548446
# Unit test for constructor of class PyInfo
def test_PyInfo():
    return



# Generated at 2022-06-24 03:17:13.193841
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("sys.version_info:", sys.version_info)
    assert PyInfo.PY2 != PyInfo.PY3

    str1 = "abc123ABC"
    byte1 = bytes(str1, encoding="utf-8")

    # Iterable Class
    isinstance(str1, PyInfo.string_types)
    isinstance(byte1, PyInfo.binary_type)

    print("maxsize:", PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:19.517752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert 'abc'.encode() == PyInfo.binary_type(b'abc')

# Generated at 2022-06-24 03:17:29.225613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type) is False
    assert isinstance(u"", PyInfo.text_type) is True
    assert len(PyInfo.string_types) == 2
    assert len(PyInfo.text_type) == 6
    assert len(PyInfo.binary_type) == 5
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2
    assert isinstance(1 << 63, PyInfo.integer_types) is True
    assert isinstance(1 << 64, PyInfo.integer_types) is False

# Generated at 2022-06-24 03:17:33.249921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:17:40.545445
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('aaa', PyInfo.string_types)
        assert isinstance('aaa', PyInfo.text_type)
        assert not isinstance('aaa', PyInfo.binary_type)
        assert not isinstance(b'aaa', PyInfo.string_types)
        assert not isinstance(b'aaa', PyInfo.text_type)
        assert isinstance(b'aaa', PyInfo.binary_type)
        assert 3 == PyInfo.maxsize == sys.maxsize

    else:  # PY2
        assert isinstance('aaa', PyInfo.string_types)
        assert isinstance(u'aaa', PyInfo.text_type)
        assert not isinstance('aaa', PyInfo.binary_type)
        assert isinstance(b'aaa', PyInfo.string_types)
       

# Generated at 2022-06-24 03:17:45.873219
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-24 03:17:53.576996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types) is True
    assert isinstance("", PyInfo.text_type) is True
    assert isinstance("", PyInfo.binary_type) is True
    assert isinstance(0, PyInfo.integer_types) is True
    if PyInfo.PY2:
        assert isinstance(0, PyInfo.maxsize)
    if PyInfo.PY3:
        assert isinstance(0, PyInfo.class_types) is True
    assert isinstance(PyInfo, PyInfo.class_types) is True

# Generated at 2022-06-24 03:17:57.977858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2 is True

    assert isinstance("str", PyInfo.string_types)

    assert isinstance("unicode", PyInfo.text_type)


test_PyInfo()

# Generated at 2022-06-24 03:18:03.559320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert PyInfo.PY2 == (2 == sys.version_info[0])


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:07.314543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:18:17.111879
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(PyInfo.text_type(b'', 'utf-8'), PyInfo.text_type)
    else:
        assert isinstance('', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(PyInfo.text_type(b'', 'utf-8'), PyInfo.text_type)



# Generated at 2022-06-24 03:18:20.648194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)



# Generated at 2022-06-24 03:18:27.459132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types



# Generated at 2022-06-24 03:18:30.892745
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import ccxt

    for name, value in ccxt.base.pyinfo.__dict__.items():
        if name[0] != "_":
            assert isinstance(getattr(ccxt.base.pyinfo, name), bool) is True

# Generated at 2022-06-24 03:18:33.671083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:18:40.582724
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:50.662242
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test PY2, PY3
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # Test maxsize
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, integer_types)
        assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:54.153874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types or PyInfo.text_type
    assert PyInfo.binary_type or PyInfo.integer_types
    assert PyInfo.class_types or PyInfo.maxsize

# Generated at 2022-06-24 03:18:58.719912
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-24 03:19:05.511911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('abc', PyInfo.string_types)
    assert not isinstance(b'abc', PyInfo.string_types)
    assert isinstance('abc', PyInfo.text_type)
    assert not isinstance(b'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert not isinstance('abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:14.480849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)

# Generated at 2022-06-24 03:19:20.409888
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:19:29.230897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from six.moves import builtins
    import sys
    import types

    if PyInfo.PY2:
        print(PyInfo.string_types)
        print(PyInfo.text_type)
        print(PyInfo.binary_type)
        print(PyInfo.integer_types)
        print(PyInfo.class_types)
        print(PyInfo.maxsize)
    else:
        print(PyInfo.string_types)
        print(PyInfo.text_type)
        print(PyInfo.binary_type)
        print(PyInfo.integer_types)
        print(PyInfo.class_types)
        print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:41.185134
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type("") == PyInfo.text_type
    else:
        assert type("") == PyInfo.string_types
    if PyInfo.PY2:
        assert type(u"") == PyInfo.text_type
    else:
        assert type(u"") == PyInfo.string_types
    if PyInfo.PY2:
        assert type(5) == PyInfo.integer_types

# Generated at 2022-06-24 03:19:50.419260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3

    assert info.maxsize > 0
    assert isinstance(info.maxsize, int)

    assert isinstance(info.string_types, tuple)
    assert len(info.string_types) > 0
    for t in info.string_types:
        assert isinstance('', t)

    assert isinstance('', info.binary_type)
    assert isinstance('', info.text_type)

    assert isinstance(0, info.integer_types)
    assert not isinstance(0.0, info.integer_types)

    assert isinstance(type, info.class_types)

# Generated at 2022-06-24 03:19:54.908956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type(''), PyInfo.class_types)


test_PyInfo()

# Generated at 2022-06-24 03:20:04.486472
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('sys.version_info:', sys.version_info)
    pi = PyInfo()
    print('pi.PY2:', pi.PY2)
    print('pi.PY3:', pi.PY3)
    print('pi.string_types:', pi.string_types)
    print('pi.text_type:', pi.text_type)
    print('pi.binary_type:', pi.binary_type)
    print('pi.integer_types:', pi.integer_types)
    print('pi.class_types:', pi.class_types)
    print('pi.maxsize:', pi.maxsize)



# Generated at 2022-06-24 03:20:07.195907
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True




# Generated at 2022-06-24 03:20:16.364757
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance('str', PyInfo.text_type)
        assert isinstance(b'bytes', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.text_type)
        assert isinstance('str', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:22.743280
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    assert isinstance(a.class_types, tuple)
    assert isinstance(a.maxsize, int)
    assert isinstance(a.integer_types, tuple)
    assert isinstance(a.string_types, tuple)
    assert type(a.text_type) == type
    assert type(a.binary_type) == type
    assert type(a.PY2) == bool
    assert type(a.PY3) == bool

# Generated at 2022-06-24 03:20:33.087456
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)

        assert isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(b'abc', PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:34.023777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().maxsize > 0

# Generated at 2022-06-24 03:20:42.078083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test class types
    if PyInfo.PY2:
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.class_types == type

    # test strings
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:20:53.248996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(PyInfo.text_type(u""), PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert 1 < PyInfo.maxsize <= (1 << 63) - 1


try:
    import urlparse
except ImportError:
    import urllib.parse as urlparse



# Generated at 2022-06-24 03:20:57.971575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance('',  PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)



# Generated at 2022-06-24 03:21:02.568887
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert PyInfo.maxsize > 0

    if PyInfo.PY2:
        assert type(PyInfo.maxsize) == long


# Hack to avoid circular dependency with module command.py

# Generated at 2022-06-24 03:21:04.130933
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None



# Generated at 2022-06-24 03:21:14.416549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize

    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:21:22.543858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 59, PyInfo.integer_types)
    assert isinstance(list, PyInfo.class_types)
    assert PyInfo.maxsize > 0


# End

# Generated at 2022-06-24 03:21:27.756924
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    # python 2.7.10
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:21:33.878214
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:21:37.112340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:21:45.697901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2  # assume this file is only called "test_py3_compat.py"

    from moha.template.template_util import PyInfo
    assert isinstance(PyInfo, type)
    assert isinstance(PyInfo(), object)

    assert PyInfo.PY2
    assert PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    test_PyInfo()
    print('Test passed')

# Generated at 2022-06-24 03:21:53.053598
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(5, PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)
    assert PyInfo.maxsize < (1 << 63)
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(5, PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)
    assert PyInfo.maxsize >= (1 << 63)
    print("test PyInfo : OK")


test_PyInfo()

# Generated at 2022-06-24 03:22:02.534133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY2 is True or py_info.PY3 is True
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.string_types[0](), str)
    assert isinstance(py_info.text_type(), str)
    assert isinstance(py_info.binary_type(), bytes)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.integer_types[0](), int)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.class_types[0], type)
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-24 03:22:05.581164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("This is Python 2")
    elif PyInfo.PY3:
        print("This is Python 3")
    else:
        print("I don't know what's your Python version")


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:12.040436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(5, PyInfo.integer_types)
        assert not isinstance(5, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
        import cPickle

        assert not isinstance(cPickle, PyInfo.class_types)
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
    elif PyInfo.PY3:
        assert not isinstance(5, PyInfo.integer_types)
        assert not isinstance(5, PyInfo.class_types)
        import pickle

        assert not isinstance(pickle, PyInfo.class_types)
        assert isinstance('', PyInfo.string_types)

# Generated at 2022-06-24 03:22:22.863283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PY2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert not PyInfo.PY2
        assert PyInfo.PY3
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types[0] == int

# Generated at 2022-06-24 03:22:27.545358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


# Generated at 2022-06-24 03:22:32.527148
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version cannot be determined"
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance('abc'.encode('utf-8'), PyInfo.binary_type)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:22:36.285207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:22:42.004223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

# Generated at 2022-06-24 03:22:52.034034
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == bool(sys.version_info[0] == 2)
    assert PyInfo.PY3 == bool(sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance(PyInfo.maxsize, int)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:23:00.879053
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo
    """
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:23:03.758173
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from hypothesis import given
    from hypothesis.strategies import integers

    @given(x=integers())
    def test_integer_types(x):
        assert isinstance(x, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:14.441839
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types
    maxsize = PyInfo.maxsize

    assert (py2 and not py3) or (not py2 and py3)

    assert isinstance("", string_types)
    assert isinstance(u"", string_types)
    assert not isinstance(b"", string_types)
    assert not isinstance(1, string_types)
    assert not isinstance(PyInfo, string_types)

    assert isinstance("", text_type)

# Generated at 2022-06-24 03:23:23.166890
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(u"foo", PyInfo.string_types)
        assert isinstance(b"foo", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance(u"foo", PyInfo.string_types)
        assert isinstance(b"foo", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:34.365514
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
    else:
        # Python 3
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert isinstance("", PyInfo.string_types)
        asse

# Generated at 2022-06-24 03:23:43.553457
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:48.877157
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == ((1 << 63) - 1)

# Generated at 2022-06-24 03:23:53.243847
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)

# Generated at 2022-06-24 03:23:57.727861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:24:03.614654
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3
    assert isinstance("", pyinfo.string_types)
    assert isinstance("", pyinfo.text_type)
    assert isinstance("", pyinfo.binary_type)
    assert isinstance(1, pyinfo.integer_types)
    assert isinstance(PyInfo, pyinfo.class_types)
    assert isinstance(sys.maxsize, pyinfo.integer_types)  # noqa


PYINFO = PyInfo()



# Generated at 2022-06-24 03:24:14.369695
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance("abc", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(2 ** 63, PyInfo.integer_types)
        assert isinstance(str, PyInfo.class_types)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance("abc", PyInfo.text_type)