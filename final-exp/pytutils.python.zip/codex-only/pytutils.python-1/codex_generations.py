

# Generated at 2022-06-24 03:14:12.073169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:14:20.793340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(b"foo", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, type(PyInfo))

    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize > (1 << 32)


# Selection of the implementation to use

if PyInfo.PY2:
    from .py2 import *
elif PyInfo.PY3:
    from .py3 import *
else:
    raise SystemError("Unknown Python version")

# Generated at 2022-06-24 03:14:32.155815
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import os
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
       

# Generated at 2022-06-24 03:14:40.600176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert type(PyInfo.maxsize) == int



# Generated at 2022-06-24 03:14:47.160628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

    # check relationship between various types
    assert isinstance(PyInfo.text_type(), str)  # PY2: unicode, PY3: str
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    assert not isinstance(PyInfo.text_type(), PyInfo.binary_type)
    assert not isinstance(PyInfo.binary_type(), PyInfo.text_type)

    # check relationship between various types
    assert isinstance(PyInfo.integer_types, tuple)  # PY2: long

# Generated at 2022-06-24 03:14:49.217200
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    pyinfo = PyInfo()
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert pyinfo.maxsize > 0
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-24 03:14:51.492411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    values = (int, long) if PyInfo.PY2 else (int,)
    assert isinstance(PyInfo.maxsize, values)



# Generated at 2022-06-24 03:15:01.773037
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.binary_type
    assert PyInfo.text_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

    if PyInfo.PY3:
        assert issubclass(PyInfo.binary_type, PyInfo.text_type)
    else:
        assert PyInfo.binary_type is not PyInfo.text_type
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == PyInfo.binary_type(-1).__index__()
            assert PyInfo.maxsize + 1 == PyInfo.binary_type(0).__index__()

# Generated at 2022-06-24 03:15:09.891761
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(object(), PyInfo.string_types)
        assert not isinstance(object(), PyInfo.text_type)
        assert not isinstance(object(), PyInfo.binary_type)
    elif PyInfo.PY3:
        assert not isinstance(object(), PyInfo.string_types)
        assert isinstance(object(), PyInfo.text_type)
        assert isinstance(object(), PyInfo.binary_type)
    else:
        assert False



# Generated at 2022-06-24 03:15:11.868610
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X(PyInfo):
        pass

    x = X()
    assert (x.PY2 and not x.PY3) or (x.PY3 and not x.PY2)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:17.619345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 or PyInfo.PY3)
    assert type('a') in PyInfo.string_types
    assert type(u'a') in PyInfo.string_types
    assert type(b'a') in PyInfo.binary_type
    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-24 03:15:24.513395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:33.144773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)


# ---------------------------------------------------------------
# PY2
# ---------------------------------------------------------------
if PyInfo.PY2:
    def raises(errcode):
        return errcode in {errno.EACCES, errno.EPERM, errno.ENOENT, errno.ENOTDIR}

    def bytes_from_hex(hex):
        return hex.decode("hex")

    def long_from_hex(hex):
        return long(hex, 16)

    import urlparse
    urlparse_loc = urlparse.urlparse
    urlparse_query_loc = urlparse.urlparse
    urljoin_loc = urlparse.urljoin
    urlparse_qs_loc = urlparse.parse_qsl


# Generated at 2022-06-24 03:15:40.471335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is not False
    assert pyinfo.PY3 is not False
    assert pyinfo.string_types is not False
    assert pyinfo.text_type is not False
    assert pyinfo.binary_type is not False
    assert pyinfo.integer_types is not False
    assert pyinfo.class_types is not False
    assert pyinfo.maxsize is not False


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-24 03:15:47.300171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import tempfile
    import os

    if PyInfo.PY2:
        assert type(PyInfo.text_type('')) == unicode
        assert type(PyInfo.string_types[0]('')) == str
    elif PyInfo.PY3:
        assert type(PyInfo.text_type('')) == str
        assert type(PyInfo.string_types[0]('')) == str

    assert PyInfo.binary_type != bytes
    assert type(PyInfo.binary_type(b'')) == bytes

    assert isinstance(2147483647, PyInfo.integer_types)

    fd, file_name = tempfile.mkstemp()
    os.close(fd)
    assert PyInfo.is_file(file_name)



# Generated at 2022-06-24 03:15:54.018275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_PyInfo(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

    unittest.main()

# Generated at 2022-06-24 03:16:04.434936
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is sys.version_info[0] == 2
    assert pyinfo.PY3 is sys.version_info[0] == 3
    assert pyinfo.maxsize > 0
    #assert pyinfo.__doc__ == 'PyInfo'
    assert pyinfo.__dict__ == {}
    assert pyinfo.__module__ == "tests.test_pyinfo"
    assert pyinfo.__weakref__ is None
    assert pyinfo.__slots__ == ()
    assert pyinfo.__weakref__ is None
    assert pyinfo.__class__.__doc__ == "Descriptor for a class attribute."
    assert pyinfo.type_of(pyinfo) is type
    assert pyinfo.type_of(123) is int

# Generated at 2022-06-24 03:16:13.456629
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == (str if PyInfo.PY3 else unicode)
    assert PyInfo.binary_type == (bytes if PyInfo.PY3 else str)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (sys.maxsize if PyInfo.PY3 else (sys.maxint if PyInfo.PY2 else sys.maxsize))

# Generated at 2022-06-24 03:16:16.430136
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:19.770926
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not (PyInfo.PY3 and PyInfo.PY2)
    assert sys.platform.startswith("java")


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:16:25.046165
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    if PyInfo.PY2:
        assert PyInfo.maxsize == 2147483647
        assert PyInfo.maxsize == sys.maxint
    elif PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:33.048767
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
    else:
        assert isinstance("", PyInfo.text_type)

    class A:
        pass

    assert isinstance(A, PyInfo.class_types)
    assert isinstance(A(), A)

# Generated at 2022-06-24 03:16:43.196324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        from unittest import TestCase
    except ImportError:
        TestCase = object
    import sys

    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3
    tint = int if PY3 else (int, long)

    class T(TestCase):
        def test1(self):
            self.assertIsInstance(PyInfo.maxsize, tint)
            self.assertGreaterEqual(PyInfo.maxsize, 2)

        def test2(self):
            self.assertIsInstance(PyInfo.class_types, tuple)
            self.assertIsInstance(PyInfo.string_types, tuple)
            self.assertIsInstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-24 03:16:49.962686
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str,) if PyInfo.PY3 else (str, unicode)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int,) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (type,) if PyInfo.PY3 else (type, types.ClassType)

# Generated at 2022-06-24 03:16:56.026327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    a = PyInfo.string_types[0]
    assert isinstance(a, type)
    assert isinstance('' if PyInfo.PY2 else b'', a)

    a = PyInfo.text_type
    assert isinstance(a, type)
    assert isinstance('' if PyInfo.PY2 else u'', a)

    a = PyInfo.binary_type
    assert isinstance(a, type)

# Generated at 2022-06-24 03:16:59.150782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert not isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:04.514211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, (tuple, list))
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, (tuple, list))
    assert isinstance(PyInfo.class_types, (tuple, list))
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:17:10.404348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.PY2
    assert not info.PY3
    assert info.string_types == (basestring,)
    assert info.text_type == unicode
    assert info.binary_type == str
    assert info.integer_types == (int, long)
    assert info.class_types == (type, types.ClassType)
    assert info.maxsize == sys.maxsize



# Generated at 2022-06-24 03:17:18.134717
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2)
    assert(not PyInfo.PY3)
    assert(PyInfo.maxsize > 0)
    assert(PyInfo.maxsize == 0x7FFFFFFF if sys.platform == 'win32' else 0x7FFFFFFFFFFFFFFF)
    assert(PyInfo.maxsize == max(int, *PyInfo.integer_types)(-1))



# Generated at 2022-06-24 03:17:19.020173
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # do nothing
    pass



# Generated at 2022-06-24 03:17:20.108589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:17:21.714452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        raise AssertionError("PY2 must be True")



# Generated at 2022-06-24 03:17:22.235392
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True



# Generated at 2022-06-24 03:17:29.554797
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:17:37.124925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(dict, PyInfo.class_types)
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-24 03:17:42.765963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2 and not PyInfo.PY3
    py3 = not PyInfo.PY2 and PyInfo.PY3
    py34 = not PyInfo.PY2 and PyInfo.PY3 and sys.version_info[1] >= 4
    assert py2 or py3
    assert py2 or py34

# Generated at 2022-06-24 03:17:47.985732
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


__all__ = ['PyInfo']

# Generated at 2022-06-24 03:17:53.237915
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert bool(pyinfo.PY2)
    assert bool(pyinfo.PY3)
    assert bool(pyinfo.string_types)
    assert bool(pyinfo.text_type)
    assert bool(pyinfo.binary_type)
    assert bool(pyinfo.integer_types)
    assert bool(pyinfo.class_types)
    assert bool(pyinfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:01.414920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:18:08.667354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True or pi.PY2 is False
    assert pi.PY3 is True or pi.PY3 is False
    assert isinstance(pi.string_types, tuple)
    assert isinstance(pi.text_type, type)
    assert isinstance(pi.binary_type, type)
    assert isinstance(pi.integer_types, tuple)
    assert isinstance(pi.maxsize, int)

# Generated at 2022-06-24 03:18:13.188204
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    if info.PY3:
        print("This is python 3")
    else:
        print("This is python 2")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:21.641778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3, "Both PY2 and PY3 is False, something is wrong"
    assert len(PyInfo.string_types) == 1, "string_types is not 1, something is wrong"
    assert len(PyInfo.integer_types) == 1 if PyInfo.PY3 else 2, "integer_types is not 1 or 2, something is wrong"
    assert len(PyInfo.class_types) == 1 if PyInfo.PY3 else 2, "class_types is not 1 or 2, something is wrong"
    assert PyInfo.maxsize >= 1, "maxsize is less than 1, something is wrong"



# Generated at 2022-06-24 03:18:28.808210
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert isinstance(PyInfo.maxsize, int)


# Local Variables:
# compile-command: "cd .. ; python -m unittest pyinfo"
# End:

# Generated at 2022-06-24 03:18:32.441235
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is bool(sys.version_info[0] == 2)
    assert PyInfo.PY3 is bool(sys.version_info[0] == 3)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:18:36.503408
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == text_type
    assert PyInfo.binary_type == binary_type
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

    assert PyInfo is not None


if __name__ == "__main__":
    import sys
    import doctest

    sys.exit(doctest.testmod().failed)

# Generated at 2022-06-24 03:18:42.722338
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.PY2 is False
    assert info.PY3 is True

    assert isinstance("abc", info.string_types)
    assert type("abc") is info.text_type

    assert isinstance(b"abc", info.binary_type)

    assert isinstance(1, info.integer_types)
    assert isinstance(1 << 31, info.integer_types)
    assert isinstance(1 << 63, info.integer_types)

    assert type(int) is info.class_types

    assert info.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:18:48.033277
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)

# Generated at 2022-06-24 03:18:49.383889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:18:52.295957
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:18:58.589314
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance('', PyInfo.integer_types)
    assert isinstance(2, PyInfo.integer_types)
    assert not isinstance(2, PyInfo.string_types)


test_PyInfo()

# Generated at 2022-06-24 03:19:04.078556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:19:09.832677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance('str', PyInfo.text_type)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-24 03:19:18.174151
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

    else:  # PY2
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:21.603018
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.maxsize)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)



# Generated at 2022-06-24 03:19:29.207035
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
    else:
        assert b"".__class__ is PyInfo.binary_type
    assert isinstance(1, PyInfo.integer_types)
    assert type(int) is PyInfo.class_types
    assert issubclass(int, (object,))

# Generated at 2022-06-24 03:19:41.137440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal
    assert_equal(PyInfo.PY2, sys.version_info[0] == 2)
    assert_equal(PyInfo.PY3, sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert_equal(PyInfo.maxsize, (1 << 63) - 1)
    else:
        # PyInfo.maxsize is 2**31-1 under PY3 on 32 bit machine
        assert_equal(PyInfo.maxsize, sys.maxsize)


if PyInfo.PY2:
    def exec_(code, globs=None, locs=None):
        """Execute code in a namespace.
        code: string,
        globs: dictionary,
        locs: dictionary,
        """

# Generated at 2022-06-24 03:19:42.541541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2
    assert not x.PY3



# Generated at 2022-06-24 03:19:45.584286
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Not python 2.x or 3.x"


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:56.552991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)

    assert isinstance(b"a", PyInfo.binary_type)
    assert not isinstance(u"a", PyInfo.binary_type)

    assert isinstance(PyInfo, PyInfo.class_types)

    assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    import pytest

    pytest.main([__file__, "-v", "--capture=no"])

# Generated at 2022-06-24 03:19:59.154242
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:20:06.439188
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.text_type)
        assert isinstance(u'a', PyInfo.text_type)
        assert PyInfo.maxsize == 2147483647
    else:
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance(u'a', PyInfo.text_type)
        assert PyInfo.maxsize == 9223372036854775807


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:13.780570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # import unittest
    #
    # class TestPyInfo(unittest.TestCase):
    #     pass
    #
    # test_cases = [
    #     ()
    # ]
    #
    # for args in test_cases:
    #     setattr(TestPyInfo, 'test_%s' % str(args),
    #             lambda self, args=args: self.assertEqual(
    #                 func(*args),
    #                 expected_result
    #             ))
    #
    # unittest.main()
    pass


if __name__ == '__main__':
    def func(x):
        pass


    def expected_result(x):
        pass


    test_PyInfo()

# Generated at 2022-06-24 03:20:18.710733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    with pytest.raises(AttributeError):
        PyInfo.__dict__.setdefault(
            "string_type",
            "basestring"),
    with pytest.raises(AttributeError):
        PyInfo.__dict__.setdefault(
            "binary_type",
            b"bytes"),
    with pytest.raises(AttributeError):
        PyInfo.__dict__.setdefault(
            "integer_types",
            (int,
             long)),
    with pytest.raises(AttributeError):
        PyInfo.__dict__.setdefault(
            "class_types",
            (type,
             types.ClassType)),
    with pytest.raises(AttributeError):
        PyInfo.__dict__.setdefault(
            "maxsize",
            sys.maxsize),

# Generated at 2022-06-24 03:20:20.612243
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:20:26.052104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:34.584386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.binary_type)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-24 03:20:37.975219
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert issubclass(type, PyInfo.class_types)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:44.475027
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for PyInfo.string_types
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)

    # Test for PyInfo.text_type
    assert isinstance(u'abc', PyInfo.text_type)

    # Test for PyInfo.binary_type
    assert isinstance('abc', PyInfo.binary_type)

    # Test for PyInfo.integer_types
    assert isinstance(1, PyInfo.integer_types)

    # Test for PyInfo.class_types
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-24 03:20:50.144595
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 is False and p.PY3 is True
    assert p.string_types == (str,)
    assert p.text_type == str
    assert p.binary_type == bytes
    assert p.integer_types == (int,)
    assert p.class_types == (type,)
    assert p.maxsize == sys.maxsize



# Generated at 2022-06-24 03:20:52.490880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


__all__ = ["PyInfo"]

# Generated at 2022-06-24 03:20:55.649483
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test Py3
    assert PyInfo.PY3
    assert PyInfo.text_type == str
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)



# Generated at 2022-06-24 03:20:57.070929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:21:03.401786
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert isinstance(info.string_types, tuple)
    assert isinstance(info.string_types[0], type)
    assert info.text_type == info.string_types[0]
    assert info.binary_type == info.string_types[1]
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.integer_types[0], type)
    assert isinstance(info.integer_types[1], type)
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-24 03:21:11.321003
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert not isinstance(u'a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert not isinstance(1, PyInfo.class_types)
    elif PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types)
        assert not isinstance(b'a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:21:11.930294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-24 03:21:15.873493
# Unit test for constructor of class PyInfo
def test_PyInfo():
    attrs = ("PY2", "PY3", "string_types", "text_type", "binary_type",
             "integer_types", "class_types", "maxsize")
    for attr in attrs:
        assert getattr(PyInfo, attr, None) is not None


if __name__ == "__main__":
    import nose

    nose.main()

# Generated at 2022-06-24 03:21:20.293183
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)

# Generated at 2022-06-24 03:21:24.559163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestCase(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_PyInfo(self):
            pass

    unittest.main()


if __name__ == "__main__":
    test_PyInfo()
    print("Done.")

# Generated at 2022-06-24 03:21:30.963956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, str)
    assert isinstance(info.binary_type, str)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)
    assert isinstance(info.maxsize, int)
    #
    assert info.string_types[0] == info.text_type or info.string_types[0] == info.binary_type
    assert info.integer_types[0] == int or info.integer_types[0] == long
    assert info.class_types[0] == type or info.class_types[0] == types.ClassType


pyinfo = PyInfo()

# Generated at 2022-06-24 03:21:41.275571
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:21:44.640019
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    # assert string_types is not None
    if PyInfo.PY2:
        assert type(u"") == unicode
    else:
        assert type(u"") == str

# Generated at 2022-06-24 03:21:50.183206
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# pytest -s -v test_pyinfo.py
if __name__ == "__main__":
    import pytest

    pytest.main([__file__, "-s", "-v"])

# Generated at 2022-06-24 03:21:58.415204
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is not False
    assert PyInfo.PY3 is True
    assert PyInfo.PY3 is not False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:00.738811
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:22:09.751743
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('abc', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'abc', PyInfo.string_types)
    else:
        assert not isinstance(u'abc', PyInfo.string_types)

    assert isinstance(b'abc', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:15.603101
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


# print("PyInfo Done.")

# Generated at 2022-06-24 03:22:17.970891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:22:24.428364
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(None, PyInfo.class_types)
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(['str'], PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, float)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:26.806951
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:30.920603
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # assert type(PyInfo.PY2) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple



# Generated at 2022-06-24 03:22:41.189058
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize == sys.maxsize
    if PyInfo.PY2:
        assert isinstance('string', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:43.748171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:22:47.263899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    tests = []
    if PyInfo.PY2:
        tests.append(isinstance(types.ClassType(), PyInfo.class_types))
    tests.append(isinstance(type(dict()), PyInfo.class_types))
    assert(tests == [True, True])

# Generated at 2022-06-24 03:22:50.967928
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in dir(PyInfo):
        if attr.isupper():
            assert isinstance(getattr(PyInfo, attr), bool)


__all__ = ["PyInfo"]

# Generated at 2022-06-24 03:22:55.386906
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    print(pyinfo.text_type)  # noqa
    print(pyinfo.integer_types)  # noqa
    print(pyinfo.class_types)  # noqa
    print(pyinfo.maxsize)  # noqa


test_PyInfo()

# Generated at 2022-06-24 03:22:59.111076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.text_type == str
    assert PyInfo.string_types == (str, unicode)
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)



# Generated at 2022-06-24 03:23:09.776731
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from datetime import date, datetime
    from decimal import Decimal
    from fractions import Fraction

    assert isinstance('', text_type)
    assert isinstance('', string_types)
    assert isinstance(b'', binary_type)
    assert isinstance(1, integer_types)
    assert isinstance(1, integer_types)
    assert isinstance(1.1, float)
    assert isinstance(Decimal('1.1'), Decimal)
    assert isinstance(Fraction(11, 10), Fraction)
    assert isinstance(date(2010, 1, 1), date)
    assert isinstance(datetime(2010, 1, 1, 1, 2, 3), datetime)
    assert isinstance([], list)
    assert isinstance({}, dict)
    assert isinstance(set(), set)
    assert isinstance

# Generated at 2022-06-24 03:23:16.438108
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("\n--- Testing PyInfo class ---")
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("string_types:", PyInfo.string_types)
    print("text_type:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)
    print("maxsize:", PyInfo.maxsize)
    print("--- Testing PyInfo class ---\n")



# Generated at 2022-06-24 03:23:21.932898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(None, PyInfo.string_types) is False


if __name__ == '__main__':
    test_PyInfo()

    print('PyInfo.PY2: %s' % PyInfo.PY2)
    print('PyInfo.PY3: %s' % PyInfo.PY3)
    print('PyInfo.maxsize: %s' % PyInfo.maxsize)

# Generated at 2022-06-24 03:23:31.762635
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert (
        PyInfo.string_types == basestring
    ) or (
        PyInfo.string_types == str
    )
    assert type(PyInfo.string_types) == tuple

    assert (
        PyInfo.text_type == unicode
    ) or (
        PyInfo.text_type == str
    )
    assert type(PyInfo.text_type()) == PyInfo.text_type

    assert (
        PyInfo.binary_type == str
    ) or (
        PyInfo.binary_type == bytes
    )
    assert type(PyInfo.binary_type()) == PyInfo.binary_type


# Generated at 2022-06-24 03:23:41.619424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)

        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)

    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

        assert isinstance("", PyInfo.text_type)
        assert isinstance(u"", PyInfo.text_type)

        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)



# Generated at 2022-06-24 03:23:47.361897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)

# Generated at 2022-06-24 03:23:54.636198
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:24:03.444059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    # string_types
    assert info.string_types is not None
    assert isinstance("abc", info.string_types)
    assert isinstance(u"abc", info.string_types)

    # text_type
    assert info.text_type is not None
    assert isinstance("abc", info.text_type)
    assert isinstance(u"abc", info.text_type)

    # binary_type
    assert info.binary_type is not None
    assert isinstance("abc", info.binary_type)
    assert isinstance(b"abc", info.binary_type)

    # integer_types
    assert info

# Generated at 2022-06-24 03:24:11.069380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # __doc__
    assert PyInfo.__doc__

    # PY2
    assert PyInfo.PY2

    # PY3
    assert PyInfo.PY3

    # string_types
    assert PyInfo.string_types
    assert PyInfo.string_types == (str,) if PyInfo.PY3 else (basestring,)

    # text_type
    assert PyInfo.text_type
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode

    # binary_type
    assert PyInfo.binary_type
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str

    # integer_types
    assert PyInfo.integer_types
    assert PyInfo.integer_types == (int,) if PyInfo.PY3 else (int, long)

   