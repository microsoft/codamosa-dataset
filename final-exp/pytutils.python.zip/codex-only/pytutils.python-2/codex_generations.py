

# Generated at 2022-06-24 03:14:14.793548
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert PyInfo.maxsize == 2 ** 32 - 1 or PyInfo.maxsize == 2 ** 63 - 1

#-----------------------

# Generated at 2022-06-24 03:14:20.080641
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == 2
    assert pyinfo.PY3 == 3
    assert pyinfo.string_types == basestring
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    assert pyinfo.maxsize == sys.maxsize



# Generated at 2022-06-24 03:14:26.774275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    maxsize = PyInfo.maxsize
    assert type(maxsize) == int
    if PyInfo.PY3:
        assert maxsize > 0
        assert maxsize > (1 << 32)
    else:
        if sys.platform.startswith("java"):
            assert maxsize > 0
            assert maxsize < (1 << 32)
        else:
            assert maxsize > 0

# Generated at 2022-06-24 03:14:32.586987
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PyInfo.PY2:", PyInfo.PY2)
    print("PyInfo.PY3:", PyInfo.PY3)
    print("PyInfo.string_types:", PyInfo.string_types)
    print("PyInfo.text_type:", PyInfo.text_type)
    print("PyInfo.binary_type:", PyInfo.binary_type)
    print("PyInfo.integer_types:", PyInfo.integer_types)
    print("PyInfo.class_types", PyInfo.class_types)
    print("PyInfo.maxsize:", PyInfo.maxsize)



# Generated at 2022-06-24 03:14:34.860484
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-24 03:14:39.004644
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("Test", PyInfo.string_types)
    else:
        assert isinstance("Test", PyInfo.string_types)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0
    assert isinstance(666, PyInfo.integer_types)

# Generated at 2022-06-24 03:14:43.421255
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == 9223372036854775807


# Unit test coverage to 100%

# Generated at 2022-06-24 03:14:48.901263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == len(PyInfo.integer_types) == 2
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:14:59.746353
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.maxsize > 0

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)

    assert isinstance('a', PyInfo.text_type)
    assert not isinstance(u'a', PyInfo.text_type)
    assert not isinstance(b'a', PyInfo.text_type)

    assert not isinstance('a', PyInfo.binary_type)
    assert not isinstance(u'a', PyInfo.binary_type)
    assert isinstance(b'a', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:10.598809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3
    if PY3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary

# Generated at 2022-06-24 03:15:13.791354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert not p.PY2
    assert p.PY3
    assert isinstance('', p.string_types)
    assert isinstance('', p.text_type)
    assert isinstance(b'', p.binary_type)
    assert isinstance(1, p.integer_types)
    assert isinstance(p, p.class_types)

# Generated at 2022-06-24 03:15:20.743586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type(u'string') in PyInfo.string_types
        assert type(b'binary') == PyInfo.binary_type
        assert type(1) in PyInfo.integer_types

# Generated at 2022-06-24 03:15:30.108802
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:  # pragma: no cover (py2 only)
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, basestring)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, long)
    elif PyInfo.PY3:  # pragma: no cover (py3 only)
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-24 03:15:34.801434
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2


if __name__ == "__main__":
    if PyInfo.PY2:
        import doctest

        doctest.testmod()
    else:
        test_PyInfo()

# Generated at 2022-06-24 03:15:39.834806
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class C(object):
        pass

    def f():
        pass

    assert isinstance(9 ** 19, PyInfo.integer_types)
    assert isinstance(C, PyInfo.class_types)
    assert isinstance(f, PyInfo.class_types)


# TODO(jhrishida): Rename to 'is_compat'

# Generated at 2022-06-24 03:15:47.167957
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == 2147483647
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert isinstance('toto', PyInfo.string_types)
    assert isinstance(u'toto', PyInfo.string_types)
    assert not isinstance(b'byte', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:54.901499
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    # print(info.PY2)
    # print(info.PY3)
    # print(info.string_types)
    # print(info.text_type)
    # print(info.binary_type)
    # print(info.integer_types)
    # print(info.class_types)
    # print(info.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:00.970862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-24 03:16:07.297608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert 'string_types' in dir(PyInfo)
    assert 'text_type' in dir(PyInfo)
    assert 'binary_type' in dir(PyInfo)
    assert 'integer_types' in dir(PyInfo)
    assert 'class_types' in dir(PyInfo)
    assert 'maxsize' in dir(PyInfo)


__all__ = ['PyInfo']

# Generated at 2022-06-24 03:16:15.283043
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert(isinstance(b"", PyInfo.binary_type))
        assert(isinstance(u"", PyInfo.text_type))
        assert(isinstance(0, PyInfo.integer_types))
    else:
        assert(isinstance(b"", PyInfo.binary_type))
        assert(isinstance("", PyInfo.text_type))
        assert(isinstance(0, PyInfo.integer_types))


if PyInfo.PY2:
    import mock
    import io


# Generated at 2022-06-24 03:16:25.159079
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.maxsize, int)
    assert isinstance(info.string_types, tuple)
    assert len(info.string_types) > 1
    assert isinstance(info.text_type, type)


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename == "__main__.py":
        print("{} is being executed directly".format(sys.argv[0]))
    else:
        print("{} is being imported".format(sys.argv[0]))

# Generated at 2022-06-24 03:16:31.396136
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.maxsize == 2**31 - 1 or PyInfo.maxsize == 2**63 - 1

# Generated at 2022-06-24 03:16:41.119563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types[0], (str, unicode, types.ClassType))
    assert isinstance(PyInfo.text_type, (str, unicode, types.ClassType))
    assert isinstance(PyInfo.binary_type, (str, unicode, types.ClassType))
    assert isinstance(PyInfo.integer_types[0], (int, long, types.ClassType))
    assert isinstance(PyInfo.class_types[0], (type, types.ClassType))
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)



# Generated at 2022-06-24 03:16:47.916589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.maxsize == (sys.maxsize)
    else:
        assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-24 03:16:53.304431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:02.738379
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_equal(value1, value2):
        assert value1 == value2

    assert_equal(PyInfo.PY2, is_py2)
    assert_equal(PyInfo.PY3, is_py3)

    assert_equal(PyInfo.string_types, string_types)
    assert_equal(PyInfo.text_type, text_type)
    assert_equal(PyInfo.binary_type, binary_type)
    assert_equal(PyInfo.integer_types, integer_types)
    assert_equal(PyInfo.class_types, class_types)

    assert_equal(PyInfo.maxsize, maxsize)


PyInfo = PyInfo()
is_py2 = PyInfo.PY2
is_py3 = PyInfo.PY3

string_types = PyInfo.string_

# Generated at 2022-06-24 03:17:03.228900
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-24 03:17:11.480199
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert isinstance(x.string_types, tuple)
    assert isinstance(x.string_types[0], (str, unicode))
    assert isinstance(x.text_type, (str, unicode))
    assert isinstance(x.binary_type, (str, bytes))
    assert isinstance(x.integer_types, tuple)
    assert isinstance(x.integer_types[0], (int, long))
    assert isinstance(x.class_types, tuple)
    assert isinstance(x.class_types[0], (type, types.ClassType))
    assert isinstance(x.maxsize, (int, long))
    assert isinstance(x.PY2, bool)
    assert isinstance(x.PY3, bool)



# Generated at 2022-06-24 03:17:20.229558
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(__doc__)
    print("Constructor of class PyInfo")
    print("===============")
    print("The variable PY2 is", PyInfo.PY2)
    print("The variable PY3 is", PyInfo.PY3)
    print("The variable maxsize is", PyInfo.maxsize)
    print("The variable string_types is", PyInfo.string_types)
    print("The variable text_type is", PyInfo.text_type)
    print("The variable binary_type is", PyInfo.binary_type)
    print("The variable integer_types is", PyInfo.integer_types)
    print("The variable class_types is", PyInfo.class_types)
    print("==============="
          )
    print()


if __name__ == "__main__":
    test_Py

# Generated at 2022-06-24 03:17:22.595352
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:17:29.807360
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == ((sys.version_info[0] == 2) and (basestring,) or (str,))
    assert PyInfo.text_type == ((sys.version_info[0] == 2) and (unicode) or (str))
    assert PyInfo.binary_type == ((sys.version_info[0] == 2) and (str) or (bytes))
    assert PyInfo.integer_types == ((sys.version_info[0] == 2) and (int, long) or (int,))

# Generated at 2022-06-24 03:17:31.369763
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()



# Generated at 2022-06-24 03:17:35.643006
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:38.931664
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:47.095718
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:17:51.798214
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:18:01.662243
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version  is not 2.x nor 3.x."

    assert len(PyInfo.string_types) == 1, "Should be 1 string type."
    assert len(PyInfo.integer_types) == 2, "Should be 2 integer types."
    assert len(PyInfo.class_types) == 2, "Should be 2 class types."
    assert isinstance(PyInfo.maxsize, int), "Max size must be a integer."

    assert len(PyInfo.binary_type(b'a')) == 1, "Should be 1 byte."
    assert len(PyInfo.text_type(u'a')) == 1, "Should be 1 text."

# Generated at 2022-06-24 03:18:10.889406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test(type_, value, expected):
        assert isinstance(value, type_) == expected

    test(PyInfo.string_types, "a", True)
    test(PyInfo.string_types, u"a", True)
    test(PyInfo.string_types, b"a", False)

    test(PyInfo.text_type, "a", False)
    test(PyInfo.text_type, u"a", True)
    test(PyInfo.text_type, b"a", False)

    test(PyInfo.binary_type, "a", False)
    test(PyInfo.binary_type, u"a", False)
    test(PyInfo.binary_type, b"a", True)

    test(PyInfo.integer_types, 1, True)

# Generated at 2022-06-24 03:18:21.861251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3
    #
    # if PY3:
    #     string_types = str,
    #     text_type = str
    #     binary_type = bytes
    #     integer_types = int,
    #     class_types = type,
    # else:  # PY2
    #     string_types = basestring,
    #     text_type = unicode
    #     binary_type = str
    #     integer_types = (int, long)
    #     class_types = (type, types.ClassType)
    assert isinstance(PyInfo.PY2, object)
    assert isinstance(PyInfo.PY3, object)

# Generated at 2022-06-24 03:18:23.770401
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Return true if object is a string.

# Generated at 2022-06-24 03:18:29.259068
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])

# Test the constructor of class PyInfo
test_PyInfo()


# Test the PyInfo class
if __name__ == '__main__':
    print(PyInfo.string_types)
    print(PyInfo.integer_types)
    print(PyInfo.binary_type)
    print(PyInfo.maxsize)

# Generated at 2022-06-24 03:18:36.397778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 in (True, False)
    assert PyInfo.PY3 in (True, False)
    assert not PyInfo.PY2 or PyInfo.PY3
    assert not PyInfo.PY3 or PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:18:43.860134
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import datetime
    if PyInfo.PY2:
        assert 2 in PyInfo.integer_types
        assert isinstance(2, PyInfo.integer_types)
    else:
        assert 2 in PyInfo.integer_types
        assert isinstance(2, PyInfo.integer_types)
    # text_type
    assert isinstance(u"This is a unicode string", PyInfo.text_type)
    assert isinstance(u"This is a unicode string".encode('utf-8'), PyInfo.binary_type)
    # string_types
    assert isinstance("This is a unicode string", PyInfo.string_types)
    assert isinstance("This is a unicode string", PyInfo.string_types)
    # class_types
    assert isinstance(int, PyInfo.class_types)
    assert isinstance

# Generated at 2022-06-24 03:18:54.296123
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# For convenience
PyInfo = PyInfo()


if PyInfo.PY3:
    # Python 3
    def b(s):
        return s.encode("latin-1")


    def u(s):
        return s


    if sys.version_info[1] >= 5:
        from collections.abc import MutableMapping
    else:
        from collections import MutableMapping


else:
    # Python 2
    def b(s):
        return s


    def u(s):
        return unicode(s, "unicode_escape")


    from collections import MutableMapping



# Generated at 2022-06-24 03:19:03.820881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:14.386671
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    from module_info.infos import PyInfo
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:19:22.530070
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert u'' == PyInfo.text_type()
    assert isinstance(b'', PyInfo.binary_type)
    assert b'' == PyInfo.binary_type()
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:29.643139
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0


# Unit tests for main function

# Generated at 2022-06-24 03:19:41.337678
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:51.654402
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_PY2():
        assert isinstance("sample string", PyInfo.string_types)
        assert isinstance(u"sample unicode string", PyInfo.text_type)
        assert isinstance(b"sample bytes", PyInfo.binary_type)
        assert isinstance(int(10), PyInfo.integer_types)

    def test_PY3():
        assert isinstance("sample string", PyInfo.string_types)
        assert isinstance("sample unicode string", PyInfo.text_type)
        assert isinstance(b"sample bytes", PyInfo.binary_type)
        assert isinstance(10, PyInfo.integer_types)

    if PyInfo.PY2:
        test_PY2()
    else:
        test_PY3()

# Generated at 2022-06-24 03:19:54.525904
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:20:02.528503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "impossible result"
    assert isinstance("", PyInfo.string_types), "text is not a string"
    assert isinstance(u"", PyInfo.string_types), "unicode text is not a string"
    assert isinstance(b"", PyInfo.binary_type), "bytes is not a binary type"
    assert isinstance(1, PyInfo.integer_types), "int is not an integer type"
    if not PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types), "long is not an integer type"



# Generated at 2022-06-24 03:20:09.548839
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] == str

    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes

    assert len(PyInfo.integer_types) == 1
    assert PyInfo.integer_types[0] == int

    assert len(PyInfo.class_types) == 1
    assert PyInfo.class_types[0] == type

    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:20:16.434091
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test properties
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(print, PyInfo.class_types)
    assert isinstance(print, PyInfo.class_types)

    # Test maxsize
    assert len(bytearray(PyInfo.maxsize)) == PyInfo.maxsize
    assert len(bytearray(PyInfo.maxsize + 1)) != Py

# Generated at 2022-06-24 03:20:24.015560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    import sys
    if sys.version_info[0] == 3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == int
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:20:33.786944
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

    if not PyInfo.PY3:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:20:35.039263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3



# Generated at 2022-06-24 03:20:44.102492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test sys.version_info
    assert sys.version_info[0] == 3

    # test PY2
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    # test string_types
    assert isinstance('test', PyInfo.string_types) is True
    assert isinstance(1, PyInfo.string_types) is False

    # test text_type
    assert isinstance('test', PyInfo.text_type) is True

    # test binary_type
    assert isinstance(b'\xb3', PyInfo.binary_type)

    # test integer_types
    assert isinstance(1, PyInfo.integer_types) is True
    assert isinstance('test', PyInfo.integer_types) is False
    assert isinstance(1.0, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:55.291878
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1

    if PyInfo.PY2:
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert len(PyInfo.integer_types) == 2
        assert len(PyInfo.class_types) == 2
    else:  # PY3
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert len(PyInfo.integer_types) == 1
        assert PyInfo.integer_types[0] == int
        assert len(PyInfo.class_types) == 1

# Generated at 2022-06-24 03:20:57.918551
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type(), PyInfo.text_type())
    assert isinstance(PyInfo.binary_type(), PyInfo.binary_type())

# Generated at 2022-06-24 03:21:00.453550
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:21:07.934757
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert GyInfo.PY2 == 2
    assert GyInfo.PY3 == 3

    assert GyInfo.string_types == (basestring,)
    assert GyInfo.text_type == unicode
    assert GyInfo.binary_type == str
    assert GyInfo.integer_types == (int, long)
    assert GyInfo.class_types == (type, types.ClassType)

    assert GyInfo.maxsize == int((1 << 31) - 1)  # 32-bit

# Generated at 2022-06-24 03:21:13.293247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(1.1, PyInfo.string_types)



# Generated at 2022-06-24 03:21:18.371322
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.text_type == str
    assert PyInfo.string_types == (str,)

    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)

    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:21:22.698574
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:21:30.941787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('abc', PyInfo.string_types) is True
    assert isinstance(u'abc', PyInfo.string_types) is True
    assert isinstance(123, PyInfo.integer_types) is True

# Generated at 2022-06-24 03:21:38.276220
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    if not sys.platform.startswith("java"):
        assert isinstance(2 ** 31, PyInfo.integer_types)
    assert isinstance(22, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-24 03:21:42.475286
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert isinstance('', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:21:51.003747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == isinstance(b"", PyInfo.binary_type)
    assert PyInfo.PY2 == isinstance(u"", PyInfo.text_type)
    assert PyInfo.PY3 == isinstance(b"", PyInfo.text_type)
    assert PyInfo.PY3 == isinstance(u"", PyInfo.binary_type)
    assert PyInfo.PY2 != isinstance(b"", PyInfo.text_type)
    assert PyInfo.PY2 != isinstance(u"", PyInfo.binary_type)
    assert PyInfo.PY3 != isinstance(b"", PyInfo.binary_type)
    assert PyInfo.PY3 != isinstance(u"", PyInfo.text_type)

# Generated at 2022-06-24 03:22:01.338051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    if info.PY2:
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
    else:
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)

# Generated at 2022-06-24 03:22:10.139338
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # basic cases
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    # Python 2 cases
    # . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . . .
    # test string_types
    assert isinstance("a string", PyInfo.string_types)
    assert isinstance(u"a unicode string", PyInfo.string_types)

# Generated at 2022-06-24 03:22:11.328892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfor.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:22:11.842710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()

# Generated at 2022-06-24 03:22:22.685476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    print('PyInfo.string_types', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    print('PyInfo.text_type', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    print('PyInfo.binary_type', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    print('PyInfo.integer_types', PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    print('PyInfo.class_types', PyInfo.class_types)
    print('PyInfo.maxsize', PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:22:32.520300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.string_types == basestring, "Python-2"  # Python-2
    assert PyInfo.string_types == str, "Python-3"  # Python-3
    assert PyInfo.text_type == unicode, "Python-2"  # Python-2
    assert PyInfo.text_type == str, "Python-3"  # Python-3
    assert PyInfo.binary_type == str, "Python-2"  # Python-2
    assert PyInfo.binary_type == bytes, "Python-3"  # Python-3
    assert PyInfo.integer_types == (int, long), "Python-2"  # Python-2

# Generated at 2022-06-24 03:22:39.834049
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-24 03:22:43.787436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-24 03:22:54.900273
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(TYPE_STR, bytes)
        assert isinstance(TYPE_STR, bytes)
        assert isinstance(TYPE_INT, int)
        assert isinstance(TYPE_INT, int)
    else:
        assert isinstance(TYPE_STR, basestring)
        assert isinstance(TYPE_STR, basestring)
        assert isinstance(TYPE_INT, int)
        assert isinstance(TYPE_INT, int)


TYPE_STR = 'string'
TYPE_INT = 1
TYPE_FLOAT = 1.0
TYPE_TUPLE = ('a', 'b', 'c')
TYPE_LIST = ['a', 'b', 'c']
TYPE_DICT = {'a': 'a', 'b': 'b', 'c': 'c'}

# Generated at 2022-06-24 03:23:02.417042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:04.403820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:23:14.108839
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(type, PyInfo.class_types)
    assert PyInfo.maxsize >= 0
    print('Test pass')

# Generated at 2022-06-24 03:23:18.633431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert (pyinfo.PY2 or pyinfo.PY3) and not (pyinfo.PY2 and pyinfo.PY3)
    assert type(pyinfo.maxsize) == int
    assert type(pyinfo.string_types) == tuple
    assert type(pyinfo.integer_types) == tuple
    assert type(pyinfo.class_types) == tuple


# Test your code
test_PyInfo()

# Generated at 2022-06-24 03:23:27.144229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PyInfo.PY2 =", PyInfo.PY2)
    print("PyInfo.PY3 =", PyInfo.PY3)
    print("PyInfo.string_types =", PyInfo.string_types)
    print("PyInfo.text_type =", PyInfo.text_type)
    print("PyInfo.binary_type =", PyInfo.binary_type)
    print("PyInfo.integer_types =", PyInfo.integer_types)
    print("PyInfo.class_types =", PyInfo.class_types)
    pri

# Generated at 2022-06-24 03:23:31.131881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi is not None



# Generated at 2022-06-24 03:23:41.075932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    if pi.PY2:
        assert isinstance('str', pi.string_types)
        assert isinstance(u'unicode', pi.string_types)
        assert isinstance(u'unicode', pi.text_type)
        assert isinstance('str', pi.binary_type)
        assert isinstance(1, pi.integer_types)

# Generated at 2022-06-24 03:23:49.182829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:53.243609
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:23:54.487477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2

# Generated at 2022-06-24 03:24:01.816103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-24 03:24:07.873708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == 9223372036854775807