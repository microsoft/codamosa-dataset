

# Generated at 2022-06-24 03:14:10.768995
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
    else:
        assert not PyInfo.PY2
        assert PyInfo.PY3



# Generated at 2022-06-24 03:14:17.558738
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
    else:
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)

# Generated at 2022-06-24 03:14:22.252674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types

# Generated at 2022-06-24 03:14:32.277916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.string_types[0], type)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.integer_types[0], type)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.class_types[0], type)
    assert isinstance(pyinfo.maxsize, int)
    if pyinfo.PY2:
        assert pyinfo.string_types[0] is basestring
        assert pyinfo.text_type is unicode
        assert pyinfo.binary_type is str

# Generated at 2022-06-24 03:14:34.137574
# Unit test for constructor of class PyInfo
def test_PyInfo():
    return True


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:14:36.489443
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pprint import pprint

    pprint(PyInfo.__dict__)


# -------------------------------------------------------------------------------
# class Path
# -------------------------------------------------------------------------------


# Generated at 2022-06-24 03:14:39.189967
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-24 03:14:40.570307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3

# Generated at 2022-06-24 03:14:48.560468
# Unit test for constructor of class PyInfo
def test_PyInfo():

    pypi = PyInfo()

    assert pypi.PY2 != pypi.PY3
    assert pypi.PY2 is True
    assert pypi.PY3 is False

    assert (int, long) in pypi.integer_types
    assert (int, str) not in pypi.integer_types
    assert (int, ) in pypi.integer_types
    assert isinstance(1, pypi.integer_types) is True

# Generated at 2022-06-24 03:14:56.560192
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PI = PyInfo()
    assert PI.PY2 or PI.PY3
    assert isinstance('', PI.string_types)
    assert isinstance(PI.text_type(), PI.string_types)
    assert isinstance(b'', PI.binary_type)
    assert isinstance(PI.maxsize, PI.integer_types)
    assert isinstance(object, PI.class_types)


test_PyInfo()

# Generated at 2022-06-24 03:15:04.107344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') in PyInfo.binary_type
        assert type(1) in PyInfo.integer_types

# Generated at 2022-06-24 03:15:14.108198
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 != PyInfo.PY3

    for item in PyInfo.string_types:
        assert isinstance('', item)
        assert not isinstance('', tuple(set(PyInfo.string_types) - set([item])))

    assert isinstance('', PyInfo.text_type)
    assert not isinstance('', PyInfo.binary_type)

    for item in PyInfo.integer_types:
        assert isinstance(0, item)
        assert not isinstance(0, tuple(set(PyInfo.integer_types) - set([item])))


# Generated at 2022-06-24 03:15:18.109954
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for PyInfo"""
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
    else:
        assert isinstance(PyInfo.string_types, type)


if __name__ == '__main__':
    from wpull.testing.integration import run_as_module
    run_as_module(__file__)

# Generated at 2022-06-24 03:15:21.860320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, )
    assert PyInfo.binary_type == bytes
    assert PyInfo.maxsize == (1 << 63) - 1


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:26.304783
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)

# Generated at 2022-06-24 03:15:30.464203
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", basestring)
        assert not isinstance("", str)
        assert isinstance("", PyInfo.string_types)
    else:
        assert isinstance("", str)
        assert not isinstance("", basestring)
        assert isinstance("", PyInfo.string_types)



# Generated at 2022-06-24 03:15:34.488574
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or not PyInfo.PY3
    assert PyInfo.PY2 or not PyInfo.PY2



# Generated at 2022-06-24 03:15:37.920415
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.MAXSIZE)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:46.105708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert ~PyInfo.string_types == (int, float, list, dict, tuple, set)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert ~PyInfo.text_type == (int, float, list, dict, tuple, set, str, bytes)
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes
    assert ~PyInfo.binary_type == (int, float, list, dict, tuple, set, str, unicode)
    assert PyInfo.integer_

# Generated at 2022-06-24 03:15:56.529429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2147483647, PyInfo.integer_types)
    if PyInfo.PY3:
        assert not isinstance(2147483648, PyInfo.integer_types)
    else:
        assert isinstance(2147483648, PyInfo.integer_types)

    assert isinstance(lambda: None, PyInfo.class_types)
    assert isinstance([1], PyInfo.class_types)
    assert isinstance({}, PyInfo.class_types)

# Generated at 2022-06-24 03:16:07.298089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2  # tested on Py2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 31) - 1)


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename == "__main__.py":
        print("{}: Calling doctest.testmod()".format(basename))
        doctest.testmod()

# Generated at 2022-06-24 03:16:15.283336
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:16:25.730390
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str,) or PyInfo.string_types == (unicode,)
    assert isinstance(PyInfo.text_type(), str) or isinstance(PyInfo.text_type(), unicode)
    assert isinstance(PyInfo.binary_type(), str) or isinstance(PyInfo.binary_type(), bytes)
    assert isinstance(PyInfo.integer_types[0], int) or isinstance(PyInfo.integer_types[1], long)
    assert isinstance(PyInfo.class_types[0](), type) or isinstance(PyInfo.class_types[1](), types.ClassType)
    assert PyInfo.maxsize == 2147483647 or PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:16:36.969476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check all values are different
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types != PyInfo.text_type
    assert PyInfo.binary_type != PyInfo.integer_types
    assert PyInfo.class_types != PyInfo.maxsize
    # Check all values are correct
    assert PyInfo.PY3
    assert PyInfo.integer_types == (int,)
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:45.301148
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class MyClass(object):
        pass

    class TestClass(object):

        def test_string_types(self):
            assert isinstance('a', PyInfo.string_types)
            assert isinstance(b'a', PyInfo.string_types)

        def test_text_type(self):
            assert isinstance('a', PyInfo.text_type)
            if not PyInfo.PY3:
                assert isinstance(u'a', PyInfo.text_type)

        def test_binary_type(self):
            assert isinstance(b'a', PyInfo.binary_type)

        def test_integer_types(self):
            assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:51.511497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.text_type == unicode

    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.text_type == str

# Generated at 2022-06-24 03:17:02.149897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # PY3
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:17:08.563074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("test", PyInfo.string_types)
    if PyInfo.PY2:
        assert not isinstance("test", PyInfo.text_type)
    else:
        assert isinstance("test", PyInfo.text_type)
    assert isinstance(b"test", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:17:14.837733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.text_type)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.string_types)

        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.string_types)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

        assert isinstance(type, PyInfo.class_types)
        assert isinstance(PyInfo, PyInfo.class_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)


# Generated at 2022-06-24 03:17:19.484507
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:17:21.618913
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:17:23.122129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2, "Python version not supported."



# Generated at 2022-06-24 03:17:25.175286
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-24 03:17:33.497781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:17:38.080181
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:48.374540
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestConstructor(unittest.TestCase):
        def test_constructor(self):
            if PyInfo.PY2:
                self.assertIsInstance(PyInfo.string_types, tuple)
                self.assertEqual(PyInfo.text_type, unicode)
                self.assertEqual(PyInfo.binary_type, str)
                self.assertIsInstance(PyInfo.integer_types, tuple)
                self.assertIsInstance(PyInfo.class_types, tuple)
            else:
                self.assertIsInstance(PyInfo.string_types, tuple)
                self.assertEqual(PyInfo.text_type, str)
                self.assertEqual(PyInfo.binary_type, bytes)
                self.assertIsInstance(PyInfo.integer_types, tuple)
               

# Generated at 2022-06-24 03:17:53.841288
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:18:03.204667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):
        def test_PY2(self):
            import sys

            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)

        def test_PY3(self):
            import sys

            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

        def test_string_types(self):
            import sys

            self.assertEqual(PyInfo.string_types, (basestring,) if PyInfo.PY2 else (str,))

        def test_text_type(self):
            import sys

            self.assertEqual(PyInfo.text_type, unicode if PyInfo.PY2 else str)


# Generated at 2022-06-24 03:18:06.677735
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    py_info = PyInfo()
    assert py_info.maxsize > 0

# Generated at 2022-06-24 03:18:15.228981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.maxsize)
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    x = PyInfo.text_type
    print(x)
    x = PyInfo.binary_type
    print(x)
    x = PyInfo.string_types
    print(x)
    x = PyInfo.integer_types
    print(x)
    x = PyInfo.class_types
    print(x)
    # test_PyInfo()

# Generated at 2022-06-24 03:18:21.789051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-24 03:18:26.132884
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
    else:
        assert PyInfo.PY3
        assert not PyInfo.PY2


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:35.893983
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == (1 << 31) - 1
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                # 32-bit
                assert PyInfo.maxsize == (1 << 31) - 1
           

# Generated at 2022-06-24 03:18:41.797970
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert type(PyInfo.text_type) == types.ClassType
        assert type(PyInfo.binary_type) == types.ClassType
        assert type(PyInfo.maxsize) == types.LongType
    elif PyInfo.PY3:
        assert type(PyInfo.text_type) == type
        assert type(PyInfo.binary_type) == type
        assert type(PyInfo.maxsize) == type(1)

# Generated at 2022-06-24 03:18:52.296186
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    def _equal(name, obj):
        assert getattr(PyInfo, name) is obj

    _equal("PY2", sys.version_info[0] == 2)
    _equal("PY3", sys.version_info[0] == 3)
    _equal("string_types", (basestring,) if PyInfo.PY2 else (str,))
    _equal("text_type", unicode if PyInfo.PY2 else str)
    _equal("binary_type", str if PyInfo.PY2 else bytes)

# Generated at 2022-06-24 03:19:01.170335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (PyInfo.PY2 is False)
    if PyInfo.PY3:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance('', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-24 03:19:08.071467
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
    if PyInfo.PY3:
        pass  # Every string is text_type

    # string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

# Generated at 2022-06-24 03:19:16.407705
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
        assert not isinstance(b'bytes', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.text_type)
        assert not isinstance('str', PyInfo.text_type)
        assert not isinstance(b'bytes', PyInfo.text_type)
        assert isinstance(b'bytes', PyInfo.binary_type)
        assert not isinstance('str', PyInfo.binary_type)
        assert not isinstance(u'unicode', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:19.559092
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:19:29.550452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _PyInfo = PyInfo
    _PY2 = _PyInfo.PY2
    _PY3 = _PyInfo.PY3
    _string_types = _PyInfo.string_types
    _text_type = _PyInfo.text_type
    _binary_type = _PyInfo.binary_type
    _integer_types = _PyInfo.integer_types
    _class_types = _PyInfo.class_types
    _maxsize = _PyInfo.maxsize
    assert _PY2 != _PY3
    assert isinstance('', _string_types)
    assert isinstance(u'', _string_types)
    assert isinstance(_text_type(), _string_types)
    assert isinstance(_binary_type(), _string_types)
    assert isinstance(0, _integer_types)


# Generated at 2022-06-24 03:19:35.787613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:19:38.592038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False
    assert PyInfo.PY2 is True


if __name__ == '__main__':
    # Unit test
    test_PyInfo()

# Generated at 2022-06-24 03:19:43.757528
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# Test the static methods of class PyInfo

# Generated at 2022-06-24 03:19:55.452417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3
    if PyInfo.PY3:
        assert str == PyInfo.string_types[0]
        assert str == PyInfo.text_type
        assert bytes == PyInfo.binary_type
        assert int == PyInfo.integer_types[0]
        assert type == PyInfo.class_types[0]
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert basestring == PyInfo.string_types[0]
        assert unicode == PyInfo.text_type
        assert str == PyInfo.binary_type
        assert int == PyInfo.integer_types[0]
        assert type == PyInfo.class_types[0]
       

# Generated at 2022-06-24 03:20:05.772406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:20:10.951595
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:16.664813
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize > 1 << 31
    print("PyInfo test OK")



# Generated at 2022-06-24 03:20:27.283271
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


if PyInfo.PY3:
    def b(x):  # pragma: no cover
        """
        Converts a string to a bytes type. Returns the argument
        if it's already bytes, otherwise converts it to bytes
        using utf-8 encoding.
        """
        return x.encode("utf-8") if isinstance(x, str) else x

    def u(x):  # pragma: no cover
        """
        Converts a string to a text type. Returns the argument
        if it's already text, otherwise converts it to text
        using utf-8 encoding.
        """
        return x if isinstance(x, str) else x.decode("utf-8")
else:
    import codecs

# Generated at 2022-06-24 03:20:34.071243
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), object)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:20:37.577618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:20:42.148113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


py2_test = pytest.mark.skipif(PyInfo.PY3, reason='only for Py2')
py3_test = pytest.mark.skipif(PyInfo.PY2, reason='only for Py3')


# Create a temporary python file and return the absolute path

# Generated at 2022-06-24 03:20:53.302164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: (...) -> None
    assert PyInfo.PY2 is bool(sys.version_info[0] == 2)
    assert PyInfo.PY3 is bool(sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-24 03:20:54.779990
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Just create an instance, nothing else to do
    pyinfo = PyInfo()



# Generated at 2022-06-24 03:20:58.995301
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    interpreter_name = sys.version.split()[0]
    assert (interpreter_name == "Python/3" and PyInfo.PY3) or \
           (interpreter_name == "Python/2" and PyInfo.PY2)

# Generated at 2022-06-24 03:21:06.534227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print

# Generated at 2022-06-24 03:21:17.113255
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert(PyInfo.PY2 is False)
        assert(isinstance('', PyInfo.string_types))
        assert(isinstance('', PyInfo.text_type))
        assert(isinstance(b'', PyInfo.binary_type))
        assert(isinstance(1, PyInfo.integer_types))
        assert(isinstance(type, PyInfo.class_types))
    else:  # PY2
        assert(PyInfo.PY3 is False)
        assert(isinstance(u'', PyInfo.string_types))
        assert(isinstance(u'', PyInfo.text_type))
        assert(isinstance('', PyInfo.binary_type))

# Generated at 2022-06-24 03:21:19.442788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:21:21.014905
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    not_py2 = not PyInfo.PY2
    not_py3 = not PyInfo.PY3
    assert not_py2 or not_py3
    assert not (not_py2 and not_py3)

# Generated at 2022-06-24 03:21:29.132005
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    # Run unit test for class PyInfo
    test_PyInfo()

# Generated at 2022-06-24 03:21:32.932999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type("a") in PyInfo.string_types
    assert type(u"a") in PyInfo.string_types
    assert type(u"a") is PyInfo.text_type
    assert typ

# Generated at 2022-06-24 03:21:39.832877
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import six

    # Check
    assert PyInfo.PY2 == six.PY2
    assert PyInfo.PY3 == six.PY3
    assert PyInfo.string_types == six.string_types
    assert PyInfo.text_type == six.text_type
    assert PyInfo.binary_type == six.binary_type
    assert PyInfo.integer_types == six.integer_types
    assert PyInfo.class_types == six.class_types
    assert PyInfo.maxsize == six.maxsize

# Generated at 2022-06-24 03:21:49.034178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert PyInfo.PY2 == (2 == sys.version_info[0])

    py2_string_types = basestring
    py2_text_type = unicode
    py2_binary_type = str
    py2_integer_types = (int, long,)
    py2_class_types = (type, types.ClassType)

    py3_string_types = str
    py3_text_type = str
    py3_binary_type = bytes
    py3_integer_types = int
    py3_class_types = type

    if PyInfo.PY3:
        assert PyInfo.string_types == py3_string_types
        assert PyInfo.text_type == py3_text_type
       

# Generated at 2022-06-24 03:21:56.874720
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == sys.version_info[0] == 2
    assert pi.PY3 == sys.version_info[0] == 3
    if pi.PY3:
        assert isinstance("abc", pi.string_types)
        assert isinstance(b"abc", pi.binary_type)
        assert isinstance(1, pi.integer_types)
        assert isinstance(int, pi.class_types)
    else:  # PY2
        assert isinstance("abc", pi.string_types)
        assert isinstance(b"abc", pi.binary_type)
        assert isinstance(1, pi.integer_types)
        assert isinstance(int, pi.class_types)
        if sys.platform.startswith("java"):
            assert pi.maxsize

# Generated at 2022-06-24 03:22:02.828759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 is True
    assert PyInfo().PY3 is False

    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False

    assert PyInfo() == PyInfo
    assert isinstance(PyInfo(), PyInfo)

# Generated at 2022-06-24 03:22:06.099419
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)


if __name__ == '__main__':
    test_PyInfo()
    print('Done')

# Generated at 2022-06-24 03:22:15.235257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    fileName = os.path.basename(__file__)

    # check PY2
    assert PyInfo.PY2 == (sys.version_info[0] == 2), fileName + ": PyInfo.PY2 defines wrong version"

    # check PY3
    assert PyInfo.PY3 == (sys.version_info[0] == 3), fileName + ": PyInfo.PY3 defines wrong version"

    # check string_types
    assert PyInfo.string_types == (basestring,), fileName + ": PyInfo.PY3 defines wrong string types for PY2"
    assert PyInfo.string_types == (str,), fileName + ": PyInfo.PY3 defines wrong string types for PY3"

    # check text_type
    assert PyInfo.text_type == unicode

# Generated at 2022-06-24 03:22:23.658183
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('ABC', PyInfo.string_types)
    assert not isinstance(b'ABC', PyInfo.string_types)
    assert isinstance(u'ABC', PyInfo.string_types)
    assert not isinstance(u'ABC'.encode('utf-8'), PyInfo.string_types)
    assert isinstance('ABC', PyInfo.text_type)
    assert not isinstance(b'ABC', PyInfo.text_type)
    assert isinstance(u'ABC', PyInfo.text_type)
    assert not isinstance(u'ABC'.encode('utf-8'), PyInfo.text_type)
    assert isinstance(b'ABC', PyInfo.binary_type)
    assert not isinstance('ABC', PyInfo.binary_type)


# Generated at 2022-06-24 03:22:32.118986
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from copy import copy

    print(PyInfo.__dict__)
    print(PyInfo.text_type)
    print(type(PyInfo.text_type))
    print(type(PyInfo.text_type()))

    import sys
    import types
    import builtins

    print('--- %d %d' % (types.ClassType, type))
    print('--- %d %d' % (builtins.ClassType, type))
    print('--- %d %d' % (types.TypeType, type))
    print('--- %d %d' % (builtins.TypeType, type))

    print('--- %d %d' % (builtins.object, object))
    print('--- %d %d' % (types.ObjectType, object))

# Generated at 2022-06-24 03:22:41.784849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test for constructor of class PyInfo")

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_typs == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_typs == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-24 03:22:48.446615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("test_string", PyInfo.string_types)
    assert isinstance("test_string", PyInfo.text_type)
    assert not isinstance("test_string", PyInfo.binary_type)

    assert isinstance(-5, PyInfo.integer_types)

# Generated at 2022-06-24 03:22:56.075511
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test", PyInfo.text_type)
    assert isinstance(b"test", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(type(123), PyInfo.class_types)
    assert not isinstance(123, PyInfo.maxsize)

# Generated at 2022-06-24 03:23:03.899479
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    obj = PyInfo()
    assert obj is not None
    if obj.PY2:
        assert isinstance(obj.string_types, tuple)
        assert isinstance(obj.string_types[0], type)
        assert isinstance(obj.text_type, type)
        assert isinstance(obj.binary_type, type)
        assert isinstance(obj.integer_types, tuple)
        assert isinstance(obj.integer_types[0], type)
        assert isinstance(obj.integer_types[1], type)
        assert isinstance(obj.class_types, tuple)
        assert isinstance(obj.class_types[0], type)
        assert isinstance(obj.class_types[1], type)
        assert isinstance(obj.maxsize, long)
    else:
        assert isinstance

# Generated at 2022-06-24 03:23:12.693072
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # If the constructor is properly called, these won't fail
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:23:19.802282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-24 03:23:22.948231
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:23:27.037486
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-24 03:23:31.546707
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:39.982266
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(b"a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance("a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:23:44.969790
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:23:54.652834
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)

    assert isinstance(10, PyInfo.integer_types)
    assert not isinstance(10.0, PyInfo.integer_types)
    assert not isinstance("", PyInfo.integer_types)
    assert not isinstance(b"", PyInfo.integer_types)

# Generated at 2022-06-24 03:23:56.626009
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:24:04.615812
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3

    if py2:
        assert type(PyInfo.text_type) == unicode
        assert type(PyInfo.binary_type) == str
        assert type(PyInfo.integer_types[0]) == int
        assert type(PyInfo.integer_types[1]) == long
        assert type(PyInfo.class_types[0]) == type
        assert type(PyInfo.class_types[1]) == types.ClassType
    elif py3:
        assert type(PyInfo.text_type) == str
        assert type(PyInfo.binary_type) == bytes
        assert type(PyInfo.integer_types[0]) == int
        assert type(PyInfo.class_types[0]) == type

# Generated at 2022-06-24 03:24:15.268186
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert PyInfo.string_types == (basestring, str) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
