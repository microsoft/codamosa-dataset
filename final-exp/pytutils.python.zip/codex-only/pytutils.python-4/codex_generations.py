

# Generated at 2022-06-24 03:14:16.926191
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Unit test for constructor of class PyInfo
    import sys

    assert(sys.version_info[0] == 2)
    assert(sys.platform == 'win32')
    assert(sys.version_info[0] != 3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:14:24.392417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(False, PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(False, PyInfo.integer_types)

# Generated at 2022-06-24 03:14:26.656668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-24 03:14:32.983542
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import os
    import sys
    import unittest

    sys.path.insert(
        0, os.path.abspath(
            os.path.normpath(
                os.path.join(os.path.dirname(__file__), '..')
            )
        )
    )

    unittest.TextTestRunner(verbosity=2).run(
        unittest.TestLoader().loadTestsFromNames(['tests.py_info']))

# Generated at 2022-06-24 03:14:37.697959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type == str


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:14:44.575318
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "The PY2 or PY3 tag should be set"
    assert(isinstance("", PyInfo.text_type)), \
        "PyInfo.text_type should be text type"
    assert(isinstance(b"", PyInfo.binary_type)), \
        "PyInfo.binary_type should be binary type"
    maxint = PyInfo.maxsize
    assert(isinstance(maxint, PyInfo.integer_types)), \
        "PyInfo.maxsize should be integer type"

    # Check PyInfo.long_type
    assert(isinstance(long(maxint), PyInfo.integer_types)), \
        "PyInfo.long_type should be integer type"

# Generated at 2022-06-24 03:14:51.798974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:14:57.446659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(types.ClassType, PyInfo.class_types)
    if PyInfo.PY3:
        assert isinstance(type, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:15:06.524275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "PY2 or PY3 is False"
    if PyInfo.PY2:
        assert not PyInfo.PY3, "PY3 should not be True for PY2"
    else:
        assert not PyInfo.PY2, "PY2 should not be True for PY3"

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
    else:
        assert not isinstance(u"", PyInfo.text_type)

    assert isinstance

# Generated at 2022-06-24 03:15:11.962781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int(2 ** 63 - 1)



# Generated at 2022-06-24 03:15:19.834563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    sys.version_info = (2, 7, 5, 'final', 0)
    assert PyInfo.PY2
    assert not(PyInfo.PY3)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance(42, PyInfo.integer_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert PyInfo.maxsize == (2 ** 31) - 1
    sys.version_info = (3, 4, 0, 'final', 0)
    assert not(PyInfo.PY2)
    assert PyInfo.PY3
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-24 03:15:24.763035
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (PyInfo.text_type is unicode)
    assert PyInfo.PY2 != (PyInfo.text_type is str)
    assert PyInfo.PY3 != (PyInfo.text_type is unicode)
    assert PyInfo.PY3 == (PyInfo.text_type is str)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:30.109035
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 2
    assert PyInfo.PY3 == 3
    assert PyInfo.string_types == basestring
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-24 03:15:36.908369
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


if __name__ == '__main__':
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)

# Generated at 2022-06-24 03:15:43.358843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3, "You are using an old version of Python"
    assert pi.string_types, "string_types is missing"
    assert pi.text_type, "text_type is missing"
    assert pi.binary_type, "binary_type is missing"
    assert pi.integer_types, "integer_types is missing"
    assert pi.class_types, "class_types is missing"
    assert pi.maxsize, "maxsize is missing"



# Generated at 2022-06-24 03:15:53.894925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-24 03:16:02.168280
# Unit test for constructor of class PyInfo
def test_PyInfo():
    instance = PyInfo()
    assert not hasattr(instance, 'PY2')
    assert not hasattr(instance, 'PY3')
    assert instance.string_types == (str,)
    assert instance.text_type == str
    assert instance.binary_type == bytes
    assert instance.integer_types == (int,)
    assert instance.class_types == (type,)
    assert not hasattr(instance, 'maxsize')


if __name__ == '__main__':
    if PyInfo.PY2:
        test_PyInfo()
    else:
        print('This code can only be executed in Python 2 environment')

# Generated at 2022-06-24 03:16:09.597409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types[0], types.StringType)

    assert isinstance(PyInfo.string_types[0], str)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types[0], int)
    assert isinstance(PyInfo.class_types[0], type)

# Generated at 2022-06-24 03:16:16.580948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("Hello", PyInfo.string_types)
    assert isinstance(u"Hello", PyInfo.string_types)
    assert isinstance(b"Hello", PyInfo.binary_type)
    assert isinstance(b"Hello", PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(10, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:20.210500
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == (2 if PyInfo.PY2 else 1)
    assert len(PyInfo.class_types) == (2 if PyInfo.PY2 else 1)



# Generated at 2022-06-24 03:16:25.794080
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    with pytest.raises(TypeError):
        PyInfo()

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:16:34.694108
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.string_types)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(b"abc".decode("utf-8"), PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:16:44.857842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:16:54.020143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple) and len(PyInfo.string_types) == 1
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple) and len(PyInfo.integer_types) == 1
    assert isinstance(PyInfo.class_types, tuple) and len(PyInfo.class_types) == 1
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types[0])

# Generated at 2022-06-24 03:17:02.762483
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes
    if PyInfo.PY2:
        assert PyInfo.integer_types == (int, long)
    else:
        assert PyInfo.integer_types == (int,)
    if PyInfo.PY2:
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.class_types == (type,)

   

# Generated at 2022-06-24 03:17:12.085120
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize >= (1 << 32)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename.startswith("test_") and callable(locals()[basename]):
        locals()[basename]()
    else:
        print("usage: python pyinfo.py test_PyInfo")

# Generated at 2022-06-24 03:17:21.994335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    PyInfo()
    """

    pyi = PyInfo()

    assert pyi.PY2 is True or pyi.PY2 is False
    assert pyi.PY3 is True or pyi.PY3 is False

    assert pyi.PY2 is not pyi.PY3

    str_class = str if pyi.PY2 is False else basestring
    assert isinstance(pyi.string_types, tuple)
    assert pyi.string_types[0] is str_class

    assert isinstance(pyi.text_type, type)
    assert pyi.text_type is str if pyi.PY2 is False else unicode

    assert isinstance(pyi.binary_type, type)

# Generated at 2022-06-24 03:17:27.354338
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)


# Use it like below.
# import PyInfo
# is_py2 = PyInfo.PY2
# is_py3 = PyInfo.PY3

# Generated at 2022-06-24 03:17:36.641169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("string", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("sss", PyInfo.string_types)
    assert not isinstance(123, PyInfo.string_types)

    assert isinstance("Hello", PyInfo.text_type)
    assert isinstance("世界", PyInfo.text_type)
    assert not isinstance("123", PyInfo.text_type)

    assert isinstance(b"Hello", PyInfo.binary_type)
    assert isinstance(b'\xe4\xb8\x96\xe7\x95\x8c', PyInfo.binary_type)
    assert not isinstance("Hello", PyInfo.binary_type)

# Generated at 2022-06-24 03:17:47.172660
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (sys.version_info[0] == 2)
    assert p.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 3:
        assert p.string_types == (str,)
        assert p.text_type == str
        assert p.binary_type == bytes
        assert p.integer_types == (int,)
        assert p.class_types == (type,)
    else:
        # PY2
        assert p.string_types == (basestring,)
        assert p.text_type == unicode
        assert p.binary_type == str
        assert p.integer_types == (int, long)
        assert p.class_types == (type, types.ClassType)



# Generated at 2022-06-24 03:17:54.878357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> from PyInfo import PyInfo
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    >>> pyinfo.string_types
    (<type 'basestring'>,)
    >>> pyinfo.text_type
    <type 'unicode'>
    >>> pyinfo.binary_type
    <type 'str'>
    >>> pyinfo.integer_types
    (<type 'int'>, <type 'long'>)
    >>> pyinfo.class_types
    (<type 'type'>, <type 'classobj'>)
    >>> pyinfo.maxsize
    9223372036854775807
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 03:18:03.988778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # print(PyInfo.PY2)
    # print(PyInfo.PY3)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    # print(PyInfo.string_types)
    # print(PyInfo.text_type)
    # print(PyInfo.binary_type)
    # print(PyInfo.integer_types)
    # print(PyInfo.class_types)
    # print(PyInfo.string_types)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-24 03:18:08.787185
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:15.805932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:18:25.931381
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int) is True
    if PyInfo.PY2:
        assert PyInfo.string_types == tuple((str, unicode))
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == tuple((int, long))
        assert PyInfo.class_types == tuple((type, types.ClassType))
        assert PyInfo.maxsize

# Generated at 2022-06-24 03:18:30.940436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.maxsize == 2147483647
    assert PyInfo.PY3 is True or PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:18:39.480182
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:18:45.399745
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(long(1), PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:18:55.612376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import six
    if six.PY2:
        assert six.PyInfo.PY2 and not six.PyInfo.PY3
        # string_types should be basestring, unicode and str
        assert isinstance('', six.string_types)
        assert isinstance(u'', six.string_types)
        assert not isinstance(b'', six.string_types)
        # text_type should be unicode
        assert not isinstance('', six.text_type)
        assert isinstance(u'', six.text_type)
        assert not isinstance(b'', six.text_type)
        # binary_type should be str
        assert isinstance('', six.binary_type)
        assert not isinstance(u'', six.binary_type)

# Generated at 2022-06-24 03:19:04.457859
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_string_types(self):
            for _type in PyInfo.string_types:
                self.assertTrue(isinstance('', _type))

        def test_text_type(self):
            self.assertEqual(PyInfo.text_type, str)

        def test_binary_type(self):
            self.assertEqual(PyInfo.binary_type, bytes)

        def test_integer_types(self):
            for _type in PyInfo.integer_types:
                self.assertTrue(isinstance(1, _type))

        def test_class_types(self):
            for _type in PyInfo.class_types:
                self.assertTrue(isinstance(TestPyInfo, _type))


# Generated at 2022-06-24 03:19:13.804466
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert 0 < PyInfo.maxsize < 1 << 31
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance('', PyInfo.string_types) or \
        isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(42, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

# Generated at 2022-06-24 03:19:22.856984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:25.618343
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:19:32.281614
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == bool(sys.version_info[0] == 2)
    assert PyInfo.PY3 == bool(sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:33.729401
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None



# Generated at 2022-06-24 03:19:38.214184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    python_version = sys.version_info[0]
    if python_version == 3:
        assert PyInfo.PY3
    elif python_version == 2:
        assert PyInfo.PY2
    else:
        raise Exception("Python version %d is unsupported!" % python_version)

# Generated at 2022-06-24 03:19:47.799837
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:19:50.686733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)



# Generated at 2022-06-24 03:19:57.419936
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:20:07.498515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert isinstance("", str)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.binary_type)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:20:12.173684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-24 03:20:19.040141
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert PyInfo.maxsize > 0


# Function for getting info for python version

# Generated at 2022-06-24 03:20:21.303149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from expecter import expect

    expect(PyInfo.PY2) == True
    expect(PyInfo.string_types) == (basestring,)

# Generated at 2022-06-24 03:20:31.491280
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Testing PyInfo...', end='')
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.text_type == unicode
    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.binary_type == str
    assert isinstance(PyInfo.binary_type, type)
    assert PyInfo.integer_types == (int, long)
    assert isinstance(PyInfo.integer_types, tuple)
    assert PyInfo.class_types == (type, types.ClassType)
    assert isinstance(PyInfo.class_types, tuple)
    print('Passed')


# Test functions of class PyInfo

# Generated at 2022-06-24 03:20:36.789485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(999, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:40.170233
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    assert PyInfo.PY3 == True
    assert PyInfo.PY2 != True


# test for the constructor for class pyinfo
test_PyInfo()

# Generated at 2022-06-24 03:20:41.003224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-24 03:20:46.877824
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.class_types)
    print(PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:20:50.321880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    # assert PyInfo.PY2 == False
    # assert PyInfo.PY3 == True
    # assert PyInfo.string_types == (str,)
    # assert PyInfo.text_type == str
    # assert PyInfo.binary_type == bytes
    # assert PyInfo.integer_types == (int,)
    # assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:21:01.101706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type checks
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:21:09.669309
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.string_types)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:21:19.138896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance(5, PyInfo.string_types)
    else:  # PY2
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(5, PyInfo.integer_types)
        assert not isinstance(5, PyInfo.class_types)


# Decorator  for converting functions with unicode arguments to Python 2

# Generated at 2022-06-24 03:21:22.297516
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-24 03:21:22.900049
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, "Test failure"

# Generated at 2022-06-24 03:21:27.863745
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:21:30.886531
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# FOR TESTING
if __name__ == '__main__':
    print("test_PyInfo")
    test_PyInfo()

# Generated at 2022-06-24 03:21:34.872427
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:21:43.840625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance(PyInfo.string_types, (list, tuple))
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, (list, tuple))
    assert isinstance(PyInfo.class_types, (list, tuple))

    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types[0], type)

    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:21:52.907700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from jsonpath_rw import PyInfo

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.text_type == str
        assert isinstance(PyInfo.text_type, type)
        assert PyInfo.binary_type == bytes
        assert isinstance(PyInfo.binary_type, type)
        assert PyInfo.integer_types == (int,)
        assert isinstance(PyInfo.integer_types[0], type)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:21:56.446727
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.maxsize > 2**31 - 1
    else:  # PY2
        assert PyInfo.maxsize < 2**32 - 1


# Generated at 2022-06-24 03:22:05.035014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type(), str)
    assert isinstance(PyInfo.binary_type(), bytes)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    if PyInfo.PY3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
    else:  # Py2
        assert PyInfo.PY2 is True
      

# Generated at 2022-06-24 03:22:14.019996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(5, PyInfo.integer_types)
    assert isinstance(5, int)

# Generated at 2022-06-24 03:22:17.830033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert issubclass(type, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-24 03:22:23.219165
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:22:27.864535
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert (PyInfo.PY2 or PyInfo.PY3)
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance(PyInfo.string_types, tuple)
    assert len(PyInfo.string_types) == 1
    assert issubclass(PyInfo.string_types[0], object)
    if PyInfo.PY2:
        assert str in PyInfo.string_types
        assert unicode in PyInfo.string_types
    else:
        assert str in PyInfo.string_types
    assert isinstance(PyInfo.integer_types, tuple)
    assert issubclass(PyInfo.integer_types[0], object)

# Generated at 2022-06-24 03:22:34.201652
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-24 03:22:44.631956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test results of PyInfo class."""
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(None, PyInfo.string_types) is False
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.text_type) is False
        assert isinstance(None, PyInfo.text_type) is False
        assert isinstance('', PyInfo.binary_type) is False
        assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-24 03:22:50.413297
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        x = 2 ** 63 - 1
  

# Generated at 2022-06-24 03:22:55.656379
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize == (1 << 63) - 1


test_PyInfo()

# Generated at 2022-06-24 03:23:03.694095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _test_PyInfo_PY3():
        assert PyInfo.PY3
        assert not PyInfo.PY2
        assert 1 in PyInfo.integer_types
        assert "a" in PyInfo.string_types
        assert b"a" in PyInfo.binary_type
        assert "a" in PyInfo.text_type
        assert type in PyInfo.class_types
        assert PyInfo.maxsize == sys.maxsize

    def _test_PyInfo_PY2():
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert 1 in PyInfo.integer_types

# Generated at 2022-06-24 03:23:05.362047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:23:15.744846
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert "basestring" in repr(PyInfo.string_types)
        assert len(PyInfo.integer_types) == 2
        assert "int" in repr(PyInfo.integer_types)
        assert "long" in repr(PyInfo.integer_types)
        assert "type" in repr(PyInfo.class_types)
        assert "ClassType" in repr(PyInfo.class_types)
    else:
        assert len(PyInfo.string_types) == 1
        assert "str" in repr(PyInfo.string_types)
        assert len(PyInfo.integer_types) == 1
        assert "int" in repr(PyInfo.integer_types)

# Generated at 2022-06-24 03:23:22.911920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, (int, long))

# Generated at 2022-06-24 03:23:31.020665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert PyInfo.maxsize == sys.maxsize if PyInfo.PY3 else int((1 << 31) - 1) if sys.platform.startswith("java")\
        else int((1 << 63) - 1) if len([1]) == 1 << 63 else int((1 << 31) - 1)

# Generated at 2022-06-24 03:23:39.081266
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance(u'hello', PyInfo.string_types)
    assert isinstance(u'hello'.encode('utf-8'), PyInfo.binary_type)
    assert isinstance(u'hello', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    if PyInfo.PY2:
        assert isinstance(1 << 30, PyInfo.integer_types)

test_PyInfo()

# Generated at 2022-06-24 03:23:39.777848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

# Generated at 2022-06-24 03:23:44.574166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:48.109848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-24 03:23:57.779690
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type("") is PyInfo.string_types[0]
        assert type(u"") is PyInfo.text_type
        assert type("") is PyInfo.binary_type
        assert type(1) is PyInfo.integer_types[0]

# Generated at 2022-06-24 03:24:03.071942
# Unit test for constructor of class PyInfo
def test_PyInfo():

    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert isinstance("a", PyInfo.binary_type)

    else:  # Py3
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)
        assert isinstance("a".encode("utf-8"), PyInfo.binary_type)

# Generated at 2022-06-24 03:24:12.272053
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY2:
        assert info.string_types == basestring, 'incorrect string type, which is %s' % info.string_types
        assert info.text_type == unicode, 'incorrect text type, which is %s' % info.text_type
        assert info.binary_type == str, 'incorrect binary type, which is %s' % info.binary_type
        assert info.integer_types == (int, long), 'incorrect integer types, which is %s' % info.integer_types
        assert info.class_types == (type, types.ClassType), 'incorrect class types, which is %s' % info.class_types
    else:
        assert info.string_types == str, 'incorrect string type, which is %s' % info.string_types