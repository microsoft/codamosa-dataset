

# Generated at 2022-06-24 03:14:11.302377
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:14:22.106492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance("", PyInfo.string_types)
    assert isinstance("a", PyInfo.string_types)
    assert isinstance("a" + "b" + "c", PyInfo.string_types)
    assert isinstance("a" + "b" + "c".encode("ascii", "ignore"), PyInfo.string_types)
    assert isinstance(u"a" + u"b" + u"c", PyInfo.string_types)
    assert isinstance(u"a" + u"b" + "c".encode("ascii", "ignore"), PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert isinstance("a", PyInfo.text_type)
    assert isinstance

# Generated at 2022-06-24 03:14:22.850448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-24 03:14:32.297868
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:14:38.971773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (
        str,
    )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

    assert PyInfo.maxsize > 0



# Generated at 2022-06-24 03:14:44.800362
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # print(PyInfo.__dict__)
    print(PyInfo.PY2, PyInfo.PY3)      # True False
    print(PyInfo.string_types)         # (<type 'str'>,)
    print(PyInfo.text_type)            # <type 'str'>
    print(PyInfo.binary_type)          # <type 'bytes'>
    print(PyInfo.integer_types)        # (<type 'int'>,)
    print(PyInfo.class_types)          # (<type 'type'>,)
    print(PyInfo.maxsize)              # 9223372036854775807


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:14:54.871845
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.string_types)
        assert isinstance(1234, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert isinstance(type(1), PyInfo.class_types)

        assert isinstance('abc', PyInfo.text_type)
        assert isinstance(b'abc', PyInfo.binary_type)
    else:
        assert isinstance(u'abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(1234, PyInfo.integer_types)
        assert isinstance(long(1234), PyInfo.integer_types)

# Generated at 2022-06-24 03:15:00.567755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance("str", PyInfo.string_types)
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(type, PyInfo.string_types)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)


if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_PyInfo()

# Generated at 2022-06-24 03:15:10.687858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:15:14.070898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 or PyInfo.PY3)
    assert(PyInfo.PY2 and not PyInfo.PY3) or (PyInfo.PY3 and not PyInfo.PY2)
    assert(PyInfo.maxsize > 0)

# Generated at 2022-06-24 03:15:19.915258
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

    for i in range(-10, 10):
        if i < 0:
            assert -i <= PyInfo.maxsize
        else:
            assert i <= PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:25.147492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-24 03:15:33.764018
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # This test will only work if run with an interpreter that has a
    # maxsize either at the default value or set to a specific value.
    maxsize = PyInfo.maxsize
    maxsize_default = (1 << 63) - 1 if sys.maxsize > (1 << 32) - 1 else (1 << 31) - 1
    if maxsize != maxsize_default:
        return

    from subprocess import Popen, PIPE

    p = Popen([sys.executable, "-B", "-E",
               "-c", "import sys; print(sys.maxsize)"],
              stdin=PIPE, stdout=PIPE, stderr=PIPE, universal_newlines=True)

    output, _ = p.communicate()

# Generated at 2022-06-24 03:15:43.759452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY3
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    # PY2
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    # string_types
    assert str in PyInfo.string_types
    if PyInfo.PY2:
        assert basestring in PyInfo.string_types
    # text_type
    assert PyInfo.text_type == str
    # binary_type
    assert PyInfo.binary_type == bytes
    # integer_types
    assert int in PyInfo.integer_types
    if PyInfo.PY2:
        assert long in PyInfo.integer_types
    # class_types
    assert type in PyInfo.class_types

# Generated at 2022-06-24 03:15:44.419991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo()



# Generated at 2022-06-24 03:15:54.981611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert isinstance('a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:15:58.964382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:00.713494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2



# Generated at 2022-06-24 03:16:09.735788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 and PY3 are boolean value(True or False)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    # string_types, text_type and binary_type are tuple
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, tuple)
    assert isinstance(PyInfo.binary_type, tuple)
    # integer_types and class_types are tuple
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # maxsize is integer
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:16:11.074239
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:16:13.248239
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False



# Generated at 2022-06-24 03:16:18.777577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    if pi.PY2:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
    else:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)



# Generated at 2022-06-24 03:16:20.174087
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:21.666775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:22.976538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()  # noqa



# Generated at 2022-06-24 03:16:33.010787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test constructor
    p = PyInfo()
    assert(isinstance(p, object))

    # Test member variable PY2
    if sys.version_info[0] == 2:
        assert(p.PY2)
    else:
        assert(not p.PY2)

    # Test member variable PY3
    if sys.version_info[0] == 3:
        assert(p.PY3)
    else:
        assert(not p.PY3)

    # Test member variable string_types
    if sys.version_info[0] == 3:
        assert(p.string_types == (str,))
    else:
        assert(p.string_types == (basestring,))

    # Test member variable text_type

# Generated at 2022-06-24 03:16:39.733176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pprint import pprint
    pprint(vars(PyInfo))
    if sys.version_info[0] == 2:
        print('Py2')
    else:
        print('Py3')
    print('maxsize:', PyInfo.maxsize)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    test_PyInfo()
    print(__name__, 'ok')

# Generated at 2022-06-24 03:16:49.030161
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2
    assert not py_info.PY3
    assert py_info.string_types == (basestring,)
    assert py_info.text_type is unicode
    assert py_info.binary_type is str
    assert py_info.integer_types == (int, long)
    assert py_info.class_types == (type, types.ClassType)
    assert py_info.maxsize == sys.maxsize
    assert not hasattr(py_info, '_PyInfo__maxsize')

    assert py_info.string_types == (str,)
    assert py_info.text_type is str
    assert py_info.binary_type is bytes
    assert py_info.integer_types == (int,)
    assert py_info.class_

# Generated at 2022-06-24 03:16:53.427887
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 is True or p.PY3 is True
    assert p.maxsize > 0
    assert isinstance(p.maxsize, int)
    assert p.string_types == str or p.string_types == (str, )
    assert p.text_type == str or p.text_type == unicode
    assert p.binary_type == bytes or p.binary_type == str
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)

# Generated at 2022-06-24 03:16:55.467163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types



# Generated at 2022-06-24 03:17:05.974852
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3, "Wrong Python version"
    assert isinstance("", PyInfo.string_types), "Wrong string type"
    assert isinstance(b"", PyInfo.binary_type), "Wrong binary type"
    assert isinstance(u"", PyInfo.text_type), "Wrong text type"
    assert isinstance(0, PyInfo.integer_types), "Wrong integer type"
    assert isinstance(object, PyInfo.class_types), "Wrong class type"
    len_X = PyInfo.maxsize + 1
    assert len_X == 1 << 31, "Wrong maxsize"
    print("Test of class PyInfo passed sucessfully")

if PyInfo.PY2 and __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:09.338471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> from pyinfo import PyInfo
    >>> PyInfo()
    """

    # This is not a unit test. It just verifies that PyInfo has the
    # attributes PY2 and PY3, which are set correctly in the constructor.
    pass

# Generated at 2022-06-24 03:17:13.989259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:22.807491
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    if info.PY2:
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
    else:  # PY3
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-24 03:17:26.941774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:17:36.422829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # drop the first argument, it is a path to the current module
    assert sys.argv[1:]

    # do not import any other modules

    # check that all global variables are available
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize > 0

    # check that all global variables are the correct types
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)

# Generated at 2022-06-24 03:17:41.818338
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:17:50.771553
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert str == PyInfo.text_type
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert bytes == PyInfo.binary_type
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:58.583488
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is not PyInfo.PY2
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance(object(), PyInfo.class_types), type(object())
    assert PyInfo.maxsize > 0
    print("Passed all tests for constructor of class PyInfo")


# Test for code for Python 2.X and 3.X

# Generated at 2022-06-24 03:18:02.121524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    type(PyInfo.PY2) == bool
    type(PyInfo.PY3) == bool
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    type(PyInfo.maxsize) == int

# Generated at 2022-06-24 03:18:11.220166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 2:
        assert PyInfo.maxsize == (1 << sys.maxint.bit_length())
        # PY2
        assert isinstance("str", PyInfo.string_types)
        assert isinstance(u"unicode", PyInfo.string_types)
        assert not isinstance(bytearray("bytes"), PyInfo.string_types)
        # Check type of string types
        assert isinstance(PyInfo.string_types, types.TupleType)

        assert isinstance(u"unicode", PyInfo.text_type)
        assert not isinstance("str", PyInfo.text_type)

# Generated at 2022-06-24 03:18:19.581983
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert 2**31-1 == PyInfo.maxsize
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    # logging.basicConfig(level=logging.DEBUG, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    test_PyInfo()

# Generated at 2022-06-24 03:18:24.001147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-24 03:18:34.031225
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    if pyinfo.PY2:
        assert isinstance("", pyinfo.string_types)
        assert isinstance(u"", pyinfo.string_types)
        assert not isinstance(b"", pyinfo.string_types)
        assert isinstance(u"", pyinfo.text_type)
        assert not isinstance("", pyinfo.text_type)
        assert not isinstance(b"", pyinfo.text_type)
        assert isinstance(b"", pyinfo.binary_type)
        assert not isinstance("", pyinfo.binary_type)
        assert isinstance(1, pyinfo.integer_types)
        assert not isinstance(1.0, pyinfo.integer_types)
        assert isinstance(1, int)

# Generated at 2022-06-24 03:18:42.131332
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31


# Generated at 2022-06-24 03:18:47.165079
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-24 03:18:57.146438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    tester = unittest.TestCase()

    tester.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
    tester.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)
    if PyInfo.PY3:
        tester.assertEqual(PyInfo.string_types, (str,))
        tester.assertEqual(PyInfo.text_type, str)
        tester.assertEqual(PyInfo.binary_type, bytes)
        tester.assertEqual(PyInfo.integer_types, (int,))
        tester.assertEqual(PyInfo.class_types, (type,))

        tester.assertEqual(PyInfo.maxsize, sys.maxsize)

# Generated at 2022-06-24 03:19:05.535411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    # PY2 and PY3
    def test_string_types():
        for x in PyInfo.string_types:
            assert isinstance("a", x)

    def test_text_type():
        assert isinstance("a", PyInfo.text_type)

    def test_binary_type():
        assert isinstance(b"a", PyInfo.binary_type)

    def test_integer_types():
        for x in PyInfo.integer_types:
            assert isinstance(1, x)

    def test_class_types():
        for x in PyInfo.class_types:
            assert isinstance(int, x)

    # PY2
    def test_maxsize_PY2():
        assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:19:11.231853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    assert pyinfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:19:21.039824
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for PyInfo.PY2
    if not PyInfo.PY2:
        raise AssertionError("PyInfo.PY2 is {}".format(PyInfo.PY2))

    # Test for PyInfo.PY3
    if not PyInfo.PY3:
        raise AssertionError("PyInfo.PY3 is {}".format(PyInfo.PY3))

    # Test for PyInfo.string_types
    if not isinstance('', PyInfo.string_types):
        raise AssertionError("PyInfo.string_types is {}".format(PyInfo.string_types))

    # Test for PyInfo.text_type
    if not isinstance('', PyInfo.text_type):
        raise AssertionError("PyInfo.text_type is {}".format(PyInfo.text_type))

# Generated at 2022-06-24 03:19:28.076036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:34.013519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:19:44.126286
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"str", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(u"str", PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)
    assert isinstance("str", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:19:46.676515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:53.340782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if PyInfo.PY2:
        print("Python 2.x")
    else:
        print("Python 3.x")

    assert PyInfo.PY2 != PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:19:58.750688
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type(''))
    assert isinstance(PyInfo.binary_type, type(''))
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-24 03:20:05.382387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2, PyInfo.PY3) == (True, False)
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 4611686018427387903

# Generated at 2022-06-24 03:20:10.951093
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    if pyinfo.PY2:
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:20:17.289429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:25.210155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 == False
    # PY3 == True
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True

    # string_types = str,
    # text_type = str
    # binary_type = bytes
    # integer_types = int,
    # class_types = type,
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)



# Generated at 2022-06-24 03:20:30.899038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.binary_type == str
    assert PyInfo.text_type == unicode
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == 9223372036854775807


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:38.071025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(None, types.NoneType)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
    elif PyInfo.PY3:
        assert isinstance(None, type(None))
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:44.990361
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)



# Generated at 2022-06-24 03:20:50.995446
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (2 == sys.version_info[0])
    assert PyInfo.PY3 is (3 == sys.version_info[0])
    assert PyInfo.PY2 is not PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 03:20:55.002427
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, str)
    assert isinstance(pyinfo.binary_type, str)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)



# Generated at 2022-06-24 03:20:59.233853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    if info.PY2:
        assert info.binary_type == types.StringType
    else:
        assert info.binary_type == types.BytesType

# Generated at 2022-06-24 03:21:04.131328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()  # No exception should be raised


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:21:14.416466
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from django.utils.six import PY2
    from django.utils.six import PY3
    from django.utils.six import string_types
    from django.utils.six import text_type
    from django.utils.six import binary_type
    from django.utils.six import integer_types
    from django.utils.six import class_types

    assert isinstance(PY2, bool)
    assert isinstance(PY3, bool)

    assert isinstance(string_types, tuple)
    assert all(isinstance(item, type) for item in string_types)
    assert all(issubclass(item, basestring) for item in string_types)

    assert isinstance(text_type, type)
    assert issubclass(text_type, basestring)

    assert isinstance

# Generated at 2022-06-24 03:21:18.860205
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)


if __name__ == "__main__":
    sys.exit(pytest.main([__file__]))

# Generated at 2022-06-24 03:21:24.347829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    class TestClass(object):
        pass

    class TestClass2(object):
        def __len__(self):
            return 1 << 31

    class TestClass3(object):
        pass

    TestClass.__class__ = type
    TestClass2.__class__ = type
    TestClass3.__class__ = types.ClassType

    py2 = sys.version_info[0] == 2
    py3 = sys.version_info[0] == 3

    assert PyInfo.PY2 == py2
    assert PyInfo.PY3 == py3

    if py2:
        assert PyInfo.maxsize == sys.maxint
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode

# Generated at 2022-06-24 03:21:29.789715
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X():
        pass

    print("PyInfo.maxsize:", PyInfo.maxsize)
    print("sys.maxsize:", sys.maxsize)
    print("isinstance(0, integer_types):", isinstance(0, PyInfo.integer_types))
    print("isinstance(0x7ffffffff, PyInfo.integer_types):", isinstance(0x7ffffffff, PyInfo.integer_types))
    print("isinstance(0x800000000, PyInfo.integer_types):", isinstance(0x800000000, PyInfo.integer_types))
    print("isinstance(X, PyInfo.class_types):", isinstance(X, PyInfo.class_types))
    print("isinstance(0, PyInfo.class_types):", isinstance(0, PyInfo.class_types))

# Generated at 2022-06-24 03:21:35.005638
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert type(py_info.string_types) is tuple
    assert type(py_info.text_type) is str
    assert type(py_info.binary_type) is str
    assert type(py_info.integer_types) is tuple
    assert type(py_info.class_types) is tuple
    assert type(py_info.maxsize) is int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:21:43.963227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # check types
    text_type('')
    text_type('test')
    binary_type(b'')
    binary_type(b'test')
    isinstance('', string_types)
    isinstance('test', string_types)
    isinstance(b'', string_types)
    isinstance(b'test', string_types)
    isinstance(123, integer_types)

# Generated at 2022-06-24 03:21:48.604213
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    print(pyinfo.PY2)
    print(pyinfo.PY3)
    print(pyinfo.string_types)
    print(pyinfo.binary_type)
    print(pyinfo.integer_types)
    print(pyinfo.class_types)
    print(pyinfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:21:49.418160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:21:54.500677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)
    assert len(PyInfo().string_types) == 1
    assert len(PyInfo().integer_types) == 2
    assert len(PyInfo().class_types) == 2

# Generated at 2022-06-24 03:22:05.374040
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    # string_types
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert not isinstance(2, PyInfo.string_types)
    # text_type
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance(2, PyInfo.text_type)
    # integer_types
    assert isinstance(2, PyInfo.integer_types)
    assert not isinstance(2.0, PyInfo.integer_types)
    assert not isinstance('', PyInfo.integer_types)
    # class_types
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-24 03:22:10.101484
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is str
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple

    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-24 03:22:14.784938
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:16.289968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:22:18.196055
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # You can not create object of class PyInfo
    try:
        PyInfo()
    except TypeError as error:
        print(error)
    else:
        raise Exception("That should not happen!")



# Generated at 2022-06-24 03:22:24.427066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None

    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:30.686633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:22:35.445201
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == True or PyInfo.PY3 == True)



# Generated at 2022-06-24 03:22:44.973051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    if not PyInfo.PY3:
        assert len(PyInfo.string_types) == 2
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    if not PyInfo.PY3:
        assert len(PyInfo.integer_types) == 2
    assert isinstance(PyInfo.class_types, tuple)
    if not PyInfo.PY3:
        assert len(PyInfo.class_types) == 2
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:46.701220
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance('a', PyInfo.string_types)

# Generated at 2022-06-24 03:22:57.744984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == "__main__":
    import sys

    my_name = os.path.splitext(os.path.basename(sys.argv[0]))[0]

# Generated at 2022-06-24 03:23:03.465325
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)

    # in Python, type and types.ClassType are not the same.
    assert set(PyInfo.class_types) == set((type, types.ClassType))
    assert not (type == types.ClassType)

    # PyInfo.maxsize is a long
    assert isinstance(PyInfo.maxsize, long)

# Generated at 2022-06-24 03:23:09.926361
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 is True or py_info.PY3 is True
    assert (py_info.PY2 is True and py_info.PY3 is False) or (
        py_info.PY2 is False and py_info.PY3 is True
    )
    assert py_info.maxsize >= 0

# Generated at 2022-06-24 03:23:11.224517
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3



# Generated at 2022-06-24 03:23:19.046516
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert pyinfo.maxsize == int((1 << 31) - 1)

    elif sys.version_info[0] == 2:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31

        try:
            len(X())
        except OverflowError:
            # 32-bit
            assert pyinfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-24 03:23:28.369132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert PyInfo.PY3 is not True or PyInfo.PY2 is not True

    assert isinstance("", PyInfo.string_types) is not None
    assert isinstance(u"", PyInfo.string_types) is not None

    assert isinstance("", PyInfo.text_type) is not None
    assert isinstance(u"", PyInfo.string_types) is not None

    assert isinstance("", PyInfo.binary_type) is not None
    assert isinstance(b"", PyInfo.binary_type) is not None

    assert isinstance(0, PyInfo.integer_types) is not None
    assert isinstance(0, PyInfo.integer_types) is not None


# Generated at 2022-06-24 03:23:34.900234
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert pyinfo.string_types is tuple
    assert pyinfo.text_type is unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types is tuple
    assert pyinfo.class_types is tuple


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:40.819872
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    assert isinstance("", info.string_types)
    assert isinstance("", info.binary_type) or isinstance("", info.text_type)
    assert isinstance(1, info.integer_types)
    assert isinstance(len, info.class_types)
    del info
    assert not "info" in globals()  # Delete check


test_PyInfo()
del test_PyInfo

# Generated at 2022-06-24 03:23:46.849133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == PyInfo.PY2 or sys.version_info[0] == PyInfo.PY3, "PY2/PY3 flag wrong"

    assert type(PyInfo.string_types) == type(tuple())
    assert type(PyInfo.text_type) == type(type(None))
    assert type(PyInfo.binary_type) == type(type(None))
    assert type(PyInfo.integer_types) == type(tuple())
    assert type(PyInfo.maxsize) == type(int)

# Generated at 2022-06-24 03:23:49.206020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type(u"") is str
    else:
        assert type(u"") is unicode


# Generated at 2022-06-24 03:23:52.440970
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-24 03:24:01.691792
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3


# Generated at 2022-06-24 03:24:08.610564
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)