

# Generated at 2022-06-24 03:14:14.357673
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance('', PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert PyInfo.maxsize == pyInfo.maxsize

# Generated at 2022-06-24 03:14:22.414597
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_string_type(self):
            self.assertTrue(isinstance('', PyInfo.PyInfo.string_types))
            self.assertTrue(isinstance(u'', PyInfo.PyInfo.string_types))
            self.assertFalse(isinstance(9, PyInfo.PyInfo.string_types))

        def test_text_type(self):
            self.assertFalse(isinstance('', PyInfo.PyInfo.text_type))
            self.assertTrue(isinstance(u'', PyInfo.PyInfo.text_type))
            self.assertFalse(isinstance(9, PyInfo.PyInfo.text_type))


# Generated at 2022-06-24 03:14:30.130022
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance(u'hello', PyInfo.string_types)
    assert isinstance(u'hello', PyInfo.text_type)
    assert isinstance(b'hello', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:14:34.938301
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.PY2, bool)
    assert PyInfo.PY3 + PyInfo.PY2 == 1


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:14:38.810294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-24 03:14:42.544287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:14:51.410985
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)

    if info.maxsize > 2**32:
        assert isinstance(info.maxsize, int)
    else:
        assert isinstance(info.maxsize, int)

    assert info.PY2 != info.PY3

# Generated at 2022-06-24 03:14:54.827860
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("maxsize:", PyInfo.maxsize)
    print("string_types:", PyInfo.string_types)
    print("text_types:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:01.868921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from sys import maxsize
    from sys import version_info
    from sys import platform

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        if platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        elif version_info.maxsize == (1 << 31) - 1:
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            assert PyInfo.maxsize == int((1 << 63) - 1)
    else:
        assert PyInfo.string_types == (str,)

# Generated at 2022-06-24 03:15:09.893178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 31) - 1


if __name__ == '__main__':
    pass

# Generated at 2022-06-24 03:15:18.295355
# Unit test for constructor of class PyInfo

# Generated at 2022-06-24 03:15:25.221727
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.string_types)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(u"", PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:15:33.788036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from string import ascii_lowercase
    from numbers import Integral

    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance(b'binary', PyInfo.binary_type)

    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(u'unicode', PyInfo.text_type)
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(b'binary', PyInfo.binary_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b'binary', PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)

# Generated at 2022-06-24 03:15:40.156440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-24 03:15:46.727814
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # we need to explicitly import this here to make sure we
    # can import it from the module
    from pyvalidate.validation_exception import ValidationException as VE

    assert not VE("a") is VE("a")  # compare references
    assert not VE("a") == VE("a")  # compare references
    assert VE("a") != VE("a")  # compare references

    assert VE("a") is not VE("a")  # compare references
    assert VE("a") is not VE("b")  # compare references
    assert VE("a") != VE("b")  # compare references


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:15:53.719345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize > 0


# Convert the value to text
if PyInfo.PY2:
    def to_text(value, encoding="utf-8"):
        if isinstance(value, str):
            return value.decode(encoding)
        return value
else:
    def to_text(value, encoding="utf-8"):
        return str(value)

# Generated at 2022-06-24 03:15:56.464892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class_type = PyInfo.class_types
    assert isinstance(int, class_type)
    assert isinstance(str, class_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:15:59.203729
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

# Generated at 2022-06-24 03:16:05.494702
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-24 03:16:06.243106
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


test_PyInfo()

# Generated at 2022-06-24 03:16:14.613923
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    if info.PY3:
        assert isinstance('', info.string_types)
        assert not isinstance(b'', info.string_types)
        assert isinstance('', info.text_type)
        assert not isinstance(b'', info.text_type)
        assert isinstance(b'', info.binary_type)
        assert not isinstance('', info.binary_type)
        assert isinstance(1, info.integer_types)
        assert isinstance(1, info.integer_types)
        assert isinstance(type('i', (object,), {}), info.class_types)

# Generated at 2022-06-24 03:16:21.178963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:16:25.284304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
    else:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:16:34.302195
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types[0] == basestring
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types[0] == int
    assert pyinfo.integer_types[1] == long
    assert pyinfo.class_types[0] == type
    assert pyinfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-24 03:16:44.830260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest2

    class PyInfoTestCase(unittest2.TestCase):
        def test_PyInfo(self):
            self.assertTrue(isinstance(PyInfo.PY2, bool))
            self.assertTrue(isinstance(PyInfo.PY3, bool))
            self.assertTrue(isinstance(PyInfo.string_types, tuple))
            self.assertTrue(str in PyInfo.string_types)
            self.assertTrue(isinstance(PyInfo.text_type, str))
            self.assertTrue(isinstance(PyInfo.binary_type, bytes))
            self.assertTrue(isinstance(PyInfo.class_types, tuple))
            self.assertTrue(type in PyInfo.class_types)
            self.assertTrue(isinstance(PyInfo.integer_types, tuple))
           

# Generated at 2022-06-24 03:16:51.805730
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    try:
        PyInfo.PY2 = False
        assert False
    except AttributeError:
        pass

    try:
        PyInfo.PY3 = False
        assert False
    except AttributeError:
        pass


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:16:58.428584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.maxsize)
    assert (PyInfo.maxsize)
    assert (PyInfo.text_type)
    assert (PyInfo.string_types)
    assert (PyInfo.PY2)
    assert (PyInfo.PY3)



# Generated at 2022-06-24 03:17:06.746849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    # determine whether system is Python2 or Python3
    assert PyInfo.PY2 ^ PyInfo.PY3 == True

    if PyInfo.PY3:
        # all static attributes are text_type, string_types, binary_type, integer_types and class_types
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.string_types, tuple)
        assert PyInfo.string_types == (str,)
        assert isinstance(PyInfo.binary_type, type)
        assert PyInfo.binary_type == bytes
        assert isinstance(PyInfo.integer_types, tuple)
        assert PyInfo.integer_types == (int,)
        assert isinstance(PyInfo.class_types, tuple)
        assert PyInfo.class_types == (type,)
        assert PyInfo

# Generated at 2022-06-24 03:17:17.743464
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Test for variable PY2
    assert isinstance(PyInfo.PY2, bool)

    # Test for variable PY3
    assert isinstance(PyInfo.PY3, bool)

    # Test for variable string_types
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.string_types == (str, unicode)

    # Test for variable text_type
    assert PyInfo.text_type == str

    # Test for variable binary_type
    assert PyInfo.binary_type == bytes

    # Test for variable integer_types
    assert isinstance(PyInfo.integer_types, tuple)
    assert PyInfo.integer_types == (int, long)

    # Test for variable class_types
    assert isinstance(PyInfo.class_types, tuple)
    assert PyInfo.class_types

# Generated at 2022-06-24 03:17:25.788880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3

    # Test string_types
    assert isinstance("a", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)

    # Test text_type
    assert isinstance("a", PyInfo.text_type)
    assert isinstance("", PyInfo.text_type)

    # Test binary_type
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)

    # Test integer_types
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.0, PyInfo.integer_types)

    # Test class_types
    assert isinstance(Exception, PyInfo.class_types)

    # Test maxsize
   

# Generated at 2022-06-24 03:17:34.508012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # PyInfo.PY3
        assert PyInfo.string_types == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == int
        assert PyInfo.class_types == type



# Generated at 2022-06-24 03:17:38.433545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    for i in PyInfo.string_types:
        assert isinstance('a', i)

    for i in PyInfo.integer_types:
        assert isinstance(0, i)

    for i in PyInfo.class_types:
        assert isinstance(i, i)

# Generated at 2022-06-24 03:17:42.869565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)

# Generated at 2022-06-24 03:17:51.644640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.PY3
        assert not PyInfo.PY2
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-24 03:17:57.337182
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import platform

    assert PyInfo.PY2 or PyInfo.PY3
    assert platform.python_version_tuple()[0] == '2' if PyInfo.PY2 else '3'


# Generated at 2022-06-24 03:18:04.126240
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY3
    assert PyInfo.PY3
    assert PyInfo.maxsize > 2 ** 31
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)


# Generated at 2022-06-24 03:18:08.193189
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert not isinstance(b"a", PyInfo.text_type)
        assert isinstance(b"a", PyInfo.binary_type)
    else:
        assert isinstance(b"a", PyInfo.text_type)
        assert isinstance(b"a", PyInfo.binary_type)

    assert isinstance(b"a", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-24 03:18:17.148680
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        from StringIO import StringIO  # noqa
    except ImportError:
        from io import StringIO  # noqa
    try:
        from unittest import TestCase
    except ImportError:
        from unittest2 import TestCase

    out = StringIO()
    sys.stdout = out
    print("PY2 = ", PyInfo.PY2)
    print("PY3 = ", PyInfo.PY3)
    # print("string_types = ", PyInfo.string_types)
    print("text_type = ", PyInfo.text_type)
    print("binary_type = ", PyInfo.binary_type)
    print("integer_types = ", PyInfo.integer_types)
    print("class_types = ", PyInfo.class_types)

# Generated at 2022-06-24 03:18:18.917803
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:18:29.109299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _test_PyInfo(pypi):
        # Test with assert
        assert isinstance(pypi.PY2, bool)
        assert isinstance(pypi.PY3, bool)
        assert isinstance(pypi.string_types, tuple)
        assert isinstance(pypi.text_type, type)
        assert isinstance(pypi.binary_type, type)
        assert isinstance(pypi.integer_types, type)
        assert isinstance(pypi.class_types, type)
        assert not isinstance(pypi.maxsize, type)

        # Test with print
        print(pypi.PY2)
        print(pypi.PY3)
        print(pypi.string_types)

# Generated at 2022-06-24 03:18:34.321176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(22, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-24 03:18:38.076932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 # True or False
    assert PyInfo.PY3 # True or False



# Generated at 2022-06-24 03:18:43.106933
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from PyInfo import PyInfo
    assert PyInfo().PY2 is True
    assert PyInfo().PY3 is False
    assert PyInfo().string_types == (basestring,)
    assert PyInfo().text_type == unicode
    assert PyInfo().binary_type == str
    assert PyInfo().integer_types == (int, long)
    assert PyInfo().class_types == (type, types.ClassType)
    assert type(PyInfo().maxsize) == long
    assert PyInfo().maxsize == (1 << 31) - 1

# Generated at 2022-06-24 03:18:53.716299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Assert that py3 string_types are strings and text_type
    assert isinstance('string', PyInfo.string_types) is True
    assert isinstance(u'string', PyInfo.string_types) is True
    assert isinstance(b'string', PyInfo.string_types) is False
    assert isinstance(b'', PyInfo.string_types) is False
    assert isinstance('', PyInfo.string_types) is True
    assert isinstance(u'', PyInfo.string_types) is True
    assert isinstance(1, PyInfo.string_types) is False

    assert isinstance('string', PyInfo.text_type) is True
    assert isinstance(u'string', PyInfo.text_type) is True
    assert isinstance(b'string', PyInfo.text_type) is False

# Generated at 2022-06-24 03:18:58.274344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(DottedDict, PyInfo.class_types)
    assert PyInfo.maxsize <= float("inf")

# Generated at 2022-06-24 03:19:05.313412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY3 ^ PyInfo.PY2
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    if not PyInfo.PY3:
        assert isinstance(1 << 31, PyInfo.integer_types)
    assert isinstance(str, PyInfo.class_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == '__main__':
    test

# Generated at 2022-06-24 03:19:15.782411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import decimal
    assert PyInfo.PY3 is True
    assert isinstance("s", PyInfo.string_types)
    assert isinstance("s", PyInfo.text_type) is False
    assert isinstance("s", PyInfo.binary_type)
    assert isinstance("s", PyInfo.integer_types) is False
    assert isinstance(str, PyInfo.class_types)

    assert isinstance(1, PyInfo.string_types) is False
    assert isinstance(1, PyInfo.text_type) is False
    assert isinstance(1, PyInfo.binary_type) is False
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

    assert isinstance(1.5, PyInfo.string_types) is False

# Generated at 2022-06-24 03:19:19.891566
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test():
        func(PyInfo.PY2, PyInfo.PY3)

    def func(a, b):
        assert isinstance(a, bool)
        assert isinstance(b, bool)

    test()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:19:29.569794
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 and not PyInfo.PY3) or (not PyInfo.PY2 and PyInfo.PY3)
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert (PyInfo.maxsize == int((1 << 31) - 1) or
                PyInfo.maxsize == int((1 << 63) - 1))
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
       

# Generated at 2022-06-24 03:19:41.339324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    assert py_info.string_types == (basestring,) if py_info.PY2 else (str,)
    assert py_info.text_type == unicode if py_info.PY2 else str
    assert py_info.binary_type == str if py_info.PY2 else bytes
    assert py_info.integer_types == (
        int,
        long,
    ) if py_info.PY2 else (int,)
    assert py_info.class_types == (type, types.ClassType) if py_info.PY2 else (
        type,
    )
    assert py_

# Generated at 2022-06-24 03:19:50.322680
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2_info = PyInfo
    assert py2_info.PY2
    assert not py2_info.PY3
    assert py2_info.string_types == (basestring,)
    assert py2_info.text_type == unicode
    assert py2_info.binary_type == str
    assert py2_info.integer_types == (int, long)
    assert py2_info.class_types == (type, types.ClassType)
    assert py2_info.maxsize == sys.maxsize


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:19:56.805694
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(None, PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:07.188802
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type, )
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:20:11.621784
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _ = PyInfo()


# Replace built-in zip, range and map to one that works with both python 2 & 3

# Generated at 2022-06-24 03:20:20.334114
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):
        def test_PyInfo_1(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

        def test_PyInfo_2(self):
            if PyInfo.PY2:
                self.assertEqual(PyInfo.string_types, (basestring,))
                self.assertEqual(PyInfo.text_type, unicode)
                self.assertEqual(PyInfo.binary_type, str)
                self.assertEqual(PyInfo.integer_types, (int, long))

# Generated at 2022-06-24 03:20:23.001044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
    else:
        assert isinstance(b'', PyInfo.binary_type)



# Generated at 2022-06-24 03:20:30.227777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert pyinfo.PY2 is False or pyinfo.PY3 is False

    assert pyinfo.string_types is not None
    assert pyinfo.text_type is not None
    assert pyinfo.binary_type is not None
    assert pyinfo.integer_types is not None
    assert pyinfo.class_types is not None


##### Main #####
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:36.098956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.maxsize, (int, long))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:36.858043
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-24 03:20:43.358460
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test case for constructor of class PyInfo
    """
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.binary_type)

    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
    else:
        assert not isinstance("", PyInfo.text_type)

    from astrobject.magic import MagicClass
    assert isinstance(MagicClass, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:20:54.526206
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    from pytz.exceptions import PyInfo

    assert isinstance(sys.version_info, tuple)
    assert isinstance(sys.version_info[0], int)
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)

    if sys.version_info[0] == 2:
        assert isinstance(PyInfo.string_types[0](), basestring)
        assert isinstance(PyInfo.text_type(), unicode)
        assert isinstance(PyInfo.binary_type(), type(str()))

# Generated at 2022-06-24 03:20:55.956707
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:21:05.170658
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert not isinstance('', PyInfo.text_type)

        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)

        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.integer_types)

    el

# Generated at 2022-06-24 03:21:10.012975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-24 03:21:16.732944
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in ("PY2", "PY3", "string_types", "binary_type", "integer_types", "class_types"):
        assert isinstance(getattr(PyInfo, attr), tuple)
        for v in getattr(PyInfo, attr):
            assert isinstance(v, type)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:21:24.083948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Make sure a single instance is created
    assert id(PyInfo.PY2) == id(PyInfo.PY2)
    assert id(PyInfo.PY3) == id(PyInfo.PY3)

    for orig in (PyInfo.string_types, PyInfo.text_type,
                 PyInfo.binary_type, PyInfo.integer_types,
                 PyInfo.class_types):
        new = type(orig)()
        assert orig is new


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:21:25.333723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3



# Generated at 2022-06-24 03:21:28.147484
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import doctest
    doctest.testmod()



# Generated at 2022-06-24 03:21:37.958928
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert issubclass(str, PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.binary_type)

        assert issubclass(bytes, PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.string_types)

        assert issubclass(int, PyInfo.integer_types)
        assert isinstance(10, PyInfo.integer_types)

        assert issubclass(int, PyInfo.integer_types)
        assert isinstance(10, PyInfo.integer_types)

        assert issubclass(type, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)


# Generated at 2022-06-24 03:21:46.451330
# Unit test for constructor of class PyInfo
def test_PyInfo():
    actual = PyInfo.PY2
    expected = sys.version_info[0] == 2
    assert actual == expected

    actual = PyInfo.PY3
    expected = sys.version_info[0] == 3
    assert actual == expected

    if PyInfo.PY3:
        actual = type(PyInfo.string_types[0])
        expected = str
        assert actual == expected

        actual = type(PyInfo.string_types[-1])
        expected = str
        assert actual == expected

        actual = type(PyInfo.text_type)
        expected = str
        assert actual == expected

        actual = type(PyInfo.binary_type)
        expected = bytes
        assert actual == expected

        actual = type(PyInfo.integer_types[0])
        expected = int
        assert actual == expected

        actual

# Generated at 2022-06-24 03:21:48.954604
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('1', PyInfo.string_types)
    assert isinstance(u'1', PyInfo.text_type)



# Generated at 2022-06-24 03:21:50.067702
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-24 03:21:59.678947
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    assert PyInfo.string_types == (types.StringType,) if PyInfo.PY2 else (str, )
    assert PyInfo.text_type == types.UnicodeType if PyInfo.PY2 else str
    assert PyInfo.binary_type == types.StringType if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int, )
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type, )

# Generated at 2022-06-24 03:22:04.602351
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo, PyInfo)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.text_type, type)



# Generated at 2022-06-24 03:22:13.384515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.string_types[0] == basestring
    assert isinstance(PyInfo.text_type, unicode)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert PyInfo.integer_types[0] == int
    assert PyInfo.integer_types[1] == long
    assert isinstance(PyInfo.class_types, tuple)
    assert PyInfo.class_types[0] == type
    assert PyInfo.class_types[1] == types.ClassType
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize == 214748364

# Generated at 2022-06-24 03:22:16.488436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

# Generated at 2022-06-24 03:22:18.222245
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3


if __name__ == "__main__":
    import nose

    nose.runmodule()

# Generated at 2022-06-24 03:22:26.457468
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert (isinstance("", PyInfo.string_types)
                and isinstance(u"", PyInfo.string_types)
                and not isinstance(b"", PyInfo.string_types))
        assert (isinstance("", PyInfo.text_type)
                and isinstance(u"", PyInfo.text_type)
                and not isinstance(b"", PyInfo.text_type))
        assert (isinstance(b"", PyInfo.binary_type)
                and not isinstance("", PyInfo.binary_type)
                and not isinstance(u"", PyInfo.binary_type))


# Generated at 2022-06-24 03:22:27.825584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3
    info = PyInfo()
    assert info.PY2 is PY2
    assert info.PY3 is PY3

# Generated at 2022-06-24 03:22:33.067847
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:40.917533
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.bina

# Generated at 2022-06-24 03:22:43.170621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for item in ['PY2', 'PY3']:
        assert hasattr(PyInfo, item)

    assert PyInfo.PY3 == True or PyInfo.PY2 == True
    assert PyInfo.PY3 == False or PyInfo.PY2 == False



# Generated at 2022-06-24 03:22:50.456525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (len(PyInfo.string_types) == 2)
    assert (PyInfo.string_types == (str, basestring))
    assert (PyInfo.text_type == str)
    assert (PyInfo.binary_type == bytes)
    assert (PyInfo.integer_types == (int, long))
    assert (PyInfo.class_types == (type, types.ClassType))
    assert (PyInfo.maxsize == sys.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:23:00.064155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Python 2.x
    assert(PyInfo.PY2)
    assert(not PyInfo.PY3)
    assert(PyInfo.string_types == (basestring,))
    assert(PyInfo.text_type == unicode)
    assert(PyInfo.binary_type == str)
    assert(PyInfo.integer_types == (int, long))
    assert(PyInfo.class_types == (type, types.ClassType))

    # Python 3.x
    import sys
    sys.version_info = (3, 0, 0, 'final', 0)
    reload(sys)
    assert(PyInfo.PY2 is False)
    assert(PyInfo.PY3 is True)
    assert(PyInfo.string_types == (str,))
    assert(PyInfo.text_type == str)

# Generated at 2022-06-24 03:23:10.709262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class MyInt(int):
        pass

    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert PyInfo.PY2 == (not PyInfo.PY3)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(MyInt(), PyInfo.integer_types)

    assert isinstance('x', PyInfo.string_types)
    assert isinstance(u'x', PyInfo.string_types)
    assert not isinstance(MyInt(), PyInfo.string_types)

    assert isinstance(b'x', PyInfo.binary_type)
    assert not isinstance('x', PyInfo.binary_type)
    assert not isinstance(MyInt(), PyInfo.binary_type)

# Generated at 2022-06-24 03:23:12.864144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2  # Since our CI only support python3
    assert PyInfo.PY3

# Generated at 2022-06-24 03:23:20.514522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    if PyInfo.PY3:
        assert not isinstance(b"", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.class_types)
        assert not isinstance("", PyInfo.integer_types)
        assert not isinstance(1, PyInfo.binary_type)

# Generated at 2022-06-24 03:23:26.199044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-24 03:23:29.550664
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2


#  Test for checking if the constructor of class PyInfo works well in python 2

# Generated at 2022-06-24 03:23:35.743894
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-24 03:23:37.489418
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2



# Generated at 2022-06-24 03:23:46.022276
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test sys.version_info
    assert type(sys.version_info) == tuple
    assert type(sys.version_info[0]) == int
    assert type(sys.version_info[1]) == int
    assert type(sys.version_info[2]) == int
    assert type(sys.version_info[3]) == str
    assert type(sys.version_info[4]) == int

    # test sys.maxsize
    assert type(sys.maxsize) == int
    assert type(sys.maxsize) == int

    # test PyInfo.PY2
    assert type(PyInfo.PY2) == bool
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    # test PyInfo.PY3
    assert type(PyInfo.PY3) == bool


# Generated at 2022-06-24 03:23:56.378329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY3
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    # PY2
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 ^ PyInfo.PY3

# Generated at 2022-06-24 03:24:04.711386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance("1", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    if PyInfo.PY3:
        assert isinstance("1", PyInfo.text_type)
        assert not isinstance(1, PyInfo.text_type)
        assert isinstance(b"1", PyInfo.binary_type)
        assert not isinstance("1", PyInfo.binary_type)

    else:  # PY2
        assert isinstance(u"1", PyInfo.text_type)
        assert not isinstance("1", PyInfo.text_type)

# Generated at 2022-06-24 03:24:11.662991
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(list, PyInfo.class_types)