

# Generated at 2022-06-24 03:14:20.793149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test the instance
    # PyInfo is a Singleton class
    assert id(PyInfo()) == id(PyInfo())
    assert isinstance(PyInfo(), types.InstanceType)

    # Test the attribute PY2
    assert isinstance(PyInfo.PY2, bool)
    assert not PyInfo.PY2 or (PyInfo.PY2 and PyInfo.PY3)
    if PyInfo.PY2:
        assert sys.version_info[0] == 2
    if PyInfo.PY3:
        assert sys.version_info[0] == 3

    # Test the attribute PY3
    assert isinstance(PyInfo.PY3, bool)
    assert not PyInfo.PY3 or (PyInfo.PY3 and PyInfo.PY2)

# Generated at 2022-06-24 03:14:32.157305
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
    elif PyInfo.PY3:
        assert isinstance(1, PyInfo.integer_types)

    # noinspection PyUnresolvedReferences
    from .utils import TestCase

    class TestPyInfo(TestCase):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_PyInfo(self):
            with self.assertRaises(AttributeError):
                PyInfo.PY4

            # self.assertTrue(PyInfo.PY2 or PyInfo.PY3)
            # TODO: verify that this test will pass on

# Generated at 2022-06-24 03:14:34.823606
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert (pyinfo.PY2 == (sys.version_info[0] == 2))


# Check if pyinfo instance is singleton

# Generated at 2022-06-24 03:14:40.007263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert PyInfo.PY2 == PyInfo.PY3 == False

# Generated at 2022-06-24 03:14:46.819419
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test001_PyInfo_PY2(self):
            self.assertIs(PyInfo.PY2, sys.version_info[0] == 2)

        def test002_PyInfo_PY3(self):
            self.assertIs(PyInfo.PY3, sys.version_info[0] == 3)

        def test003_PyInfo_string_types(self):
            self.assertIsInstance(PyInfo.string_types, tuple)
            self.assertIsInstance(PyInfo.string_types[0], type)


# Generated at 2022-06-24 03:14:52.219579
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == bool(sys.version_info[0] == 2)
    assert PyInfo.PY3 == bool(sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == int
        assert PyInfo.class_types == type
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:14:53.795842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


SYSTEM_ENCODING = sys.getdefaultencoding()



# Generated at 2022-06-24 03:15:03.002270
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('text', PyInfo.string_types)
        assert isinstance('text'.encode(), PyInfo.binary_type)
        assert isinstance(b'binary', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('text', PyInfo.string_types)
        assert isinstance(u'text', PyInfo.text_type)

# Generated at 2022-06-24 03:15:13.659378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    my_string = 'bob'
    my_byte_string = b'bob'
    my_integer = 1234
    my_class = PyInfo

    assert isinstance(my_string, str)
    assert isinstance(my_string, PyInfo.string_types)
    assert isinstance(my_byte_string, bytes)
    assert isinstance(my_byte_string, PyInfo.binary_type)
    assert isinstance(my_integer, int)
    assert isinstance(my_integer, PyInfo.integer_types)
    assert isinstance(my_class, type)
    assert isinstance(my_class, PyInfo.class_types)

    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:15:22.637791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    if PyInfo.PY3:
        # Check type of attrs
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

   

# Generated at 2022-06-24 03:15:31.587505
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance('abc', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-24 03:15:39.604429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Class Attrs
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    # Property Methods
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-24 03:15:44.609081
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.integer_types == (int, long)
        assert len(PyInfo.__dict__) == 8
    else:
        assert PyInfo.integer_types == (int,)
        assert len(PyInfo.__dict__) == 7


# I wrap 'import' so that I can handle exceptions thrown on import
# and re-raise them with a better message (one that includes the
# module that failed to import).

# Generated at 2022-06-24 03:15:48.138699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:15:49.548102
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-24 03:15:53.677648
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-24 03:16:00.816159
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def validate(obj):
        assert isinstance(obj.PY2, bool)
        assert isinstance(obj.PY3, bool)

        assert isinstance(obj.string_types, tuple)
        assert isinstance(obj.text_type, type)
        assert isinstance(obj.binary_type, type)
        assert isinstance(obj.integer_types, tuple)
        assert isinstance(obj.class_types, tuple)

        assert isinstance(obj.maxsize, int)

    validate(PyInfo)



# Generated at 2022-06-24 03:16:04.733752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    if sys.version_info.major == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
    if sys.version_info.major == 3:
        assert PyInfo.PY3
        assert not PyInfo.PY2

# Generated at 2022-06-24 03:16:13.645794
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)

        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)

        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:16:14.602559
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-24 03:16:19.492012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 2
    assert PyInfo.PY3 == False
    assert PyInfo.maxsize < 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:16:26.629795
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)

# Generated at 2022-06-24 03:16:36.100977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(u'abc', PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)
    if not PyInfo.PY2:
        assert not isinstance(1, (int, long))

    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert not PyInfo.PY3
        assert set(integer_types) == {int, long}
    else:
        assert set(integer_types) == {int}



# Generated at 2022-06-24 03:16:43.560968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type('') == str
        assert type(b'') == bytes
        assert type(1) == int
        assert type(1) == int
        assert type('') == str
        assert type('') == str
        assert type('') == str
    else:
        assert type('') == str
        assert type(b'') == str
        assert type(1) == int
        assert type(1) == int
        assert type('') == str
        assert type('') == str
        assert type('') == str



# Generated at 2022-06-24 03:16:50.534326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert (str,) == PyInfo.string_types
    assert str == PyInfo.text_type
    assert '123' == PyInfo.text_type('123')
    assert (int, long) == PyInfo.integer_types
    assert (type, types.ClassType) == PyInfo.class_types

    assert 2147483647 == PyInfo.maxsize

# Generated at 2022-06-24 03:16:53.763515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert str in PyInfo.string_types
        assert PyInfo.maxsize == (1 << 63) - 1
    else:
        assert str in PyInfo.string_types
        assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:00.868201
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 is True) or (PyInfo.PY3 is True)
    assert (isinstance(True, PyInfo.integer_types) is True)
    assert (isinstance(True, PyInfo.class_types) is True)
    assert (isinstance('True', PyInfo.string_types) is True)
    assert (isinstance(u'True', PyInfo.string_types) is True)
    assert (isinstance(b'True', PyInfo.binary_type) is True)



# Generated at 2022-06-24 03:17:06.758329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("123", PyInfo.string_types)
    assert isinstance(u"123", PyInfo.string_types)
    assert isinstance(b"123", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, (int, long))
    assert isinstance(long(123), (int, long))
    assert isinstance(type, (type, types.ClassType))
    import sys
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-24 03:17:11.441017
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == ()
    assert PyInfo.text_type == ()
    assert PyInfo.binary_type == ()
    assert PyInfo.integer_types == ()
    assert PyInfo.class_types == ()
    assert PyInfo.maxsize == ()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:18.426467
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:17:24.090575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    assert isinstance(1 << 63, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    assert isinstance(1 << 63, PyInfo.integer_types)

    if PyInfo.PY3:
        assert not isinstance(1, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-24 03:17:25.262067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Shortcut to Python info
pyi = PyInfo

# Generated at 2022-06-24 03:17:35.966069
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    if pyinfo.PY3:
        assert pyinfo.maxsize == sys.maxsize
        assert pyinfo.maxsize == sys.maxsize
    else:
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            maxsize = int((1 << 31) - 1)
            assert pyinfo.maxsize == maxsize
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                # 32-bit
                maxsize = int((1 << 31) - 1)
                assert pyinfo.maxsize == maxsize

# Generated at 2022-06-24 03:17:40.902228
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import types
    import sys
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.binary_type, str)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-24 03:17:46.789803
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:17:49.163116
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-24 03:17:55.677732
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    assert PyInfo.string_types is (str, unicode) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types is (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types is (type, types.ClassType) if PyInfo.PY2 else (type,)

# Generated at 2022-06-24 03:17:57.225371
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo().PY3:
        pass
    else:
        assert not PyInfo().PY3

    assert PyInfo().PY2 + PyInfo().PY3 == 1

# Generated at 2022-06-24 03:18:05.123943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, object)
    assert isinstance(p.binary_type, object)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)



# Generated at 2022-06-24 03:18:10.043418
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )



# Generated at 2022-06-24 03:18:16.630899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance('hello', PyInfo.text_type)
    assert isinstance(b'hello', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-24 03:18:26.721838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from six.moves import xrange

    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize


if PyInfo.PY2:
    exec("def reraise(tp, value, tb=None):\n raise tp, value, tb")
else:
    def reraise(tp, value, tb=None):
        assert isinstance(tp, type)
        assert isinstance(value, BaseException)

# Generated at 2022-06-24 03:18:35.806650
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # class type check
    assert isinstance(PyInfo.binary_type, PyInfo.class_types)
    assert isinstance(PyInfo.string_types, PyInfo.class_types)
    assert isinstance(PyInfo.integer_types, PyInfo.class_types)
    assert isinstance(PyInfo.text_type, PyInfo.class_types)
    assert isinstance(PyInfo.class_types, PyInfo.class_types)

    # value check
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.text_type)
    assert isinstance(123456, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

    # value check

# Generated at 2022-06-24 03:18:43.536432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-24 03:18:54.001085
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_string_types = PyInfo.string_types
    assert isinstance("test", test_string_types)
    assert not isinstance(3, test_string_types)

    test_text_type = PyInfo.text_type
    assert isinstance("test", test_text_type)
    assert isinstance("unicode", test_text_type)
    assert not isinstance(3, test_text_type)

    test_binary_type = PyInfo.binary_type
    class CustomStringType:

        def __str__(self):
            return "str"

        def __bytes__(self):
            return b"bytes"

    assert isinstance("test", test_binary_type)
    assert isinstance("unicode", test_binary_type)
    assert isinstance(CustomStringType(), test_binary_type)
   

# Generated at 2022-06-24 03:19:02.777448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (type(PyInfo.PY2), type(PyInfo.PY3)) == (bool, bool)
    assert (PyInfo.PY2, PyInfo.PY3) == (True, False)
    assert (PyInfo.PY2, PyInfo.PY3) != (False, True)
    assert (PyInfo.string_types, type(PyInfo.text_type)) == ((tuple,), str)
    assert (PyInfo.binary_type, type(PyInfo.integer_types)) == (str, tuple)
    assert (type(PyInfo.class_types), type(PyInfo.maxsize)) == (tuple, int)



# Generated at 2022-06-24 03:19:13.565869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import java.lang
    obj = PyInfo()
    assert obj.PY2 == (sys.version_info[0] == 2)
    assert obj.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 2:
        assert obj.string_types == (basestring,)
        assert obj.text_type == unicode
        assert obj.binary_type == str
        assert obj.integer_types == (int, long)
        assert obj.class_types == (type, java.lang.Class)
    else:  # sys.version_info[0] == 3
        assert obj.string_types == (str,)
        assert obj.text_type == str
        assert obj.binary_type == bytes
        assert obj.integer_types == (int,)

# Generated at 2022-06-24 03:19:22.641676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # The following is to check the types of "PyInfo.maxsize", which should be "int"
    assert isinstance(PyInfo.maxsize, int), "type of PyInfo.maxsize should be int"
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize, "PyInfo.maxsize should equal to sys.maxsize"
    else:
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1), (
                "PyInfo.maxsize is incorrect for python 2.x + java"
            )
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t)
            class X(object):

                def __len__(self):
                    return 1 << 31


# Generated at 2022-06-24 03:19:33.025470
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check for all members of class PyInfo
    assert hasattr(PyInfo, 'PY2')
    assert hasattr(PyInfo, 'PY3')
    assert hasattr(PyInfo, 'string_types')
    assert hasattr(PyInfo, 'text_type')
    assert hasattr(PyInfo, 'binary_type')
    assert hasattr(PyInfo, 'integer_types')
    assert hasattr(PyInfo, 'class_types')
    assert hasattr(PyInfo, 'maxsize')
    # Check for specific members of class PyInfo
    assert PyInfo.PY2 in [True, False]
    assert PyInfo.PY3 in [True, False]
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)

# Generated at 2022-06-24 03:19:43.378213
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(long(1), PyInfo.integer_types)

# Generated at 2022-06-24 03:19:51.403865
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)


# This is used for testing only.
py_info = PyInfo()
# pyinfo = PyInfo()

# Generated at 2022-06-24 03:20:00.596279
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type(), PyInfo.text_type)
    assert isinstance(PyInfo.binary_type(), PyInfo.binary_type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()
    print("Unit tests for PyInfo class passed.")

# Generated at 2022-06-24 03:20:08.557275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, int)

    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)


if __name__ == "__main__":
    import sys
    import doctest

    if len(sys.argv) > 1:
        # If any commandline arguments are provided, then run the test
        # suite instead of the doctest.
        print("Running test suite...")
        import test
    else:
        print("Starting Doctest...")
        doctest.testmod()
        print("Finished Doctest.")

# Generated at 2022-06-24 03:20:13.125451
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)

    if PY3:
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)


# Convert text to bytes with specified encoding

# Generated at 2022-06-24 03:20:18.224207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    print(p)
    assert p.PY2 or p.PY3
    assert not p.PY2 or not p.PY3
    assert p.string_types
    assert p.text_type
    assert p.binary_type
    assert p.integer_types
    assert p.class_types
    assert p.maxsize

# Generated at 2022-06-24 03:20:23.313171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

    assert issubclass(str, PyInfo.text_type)
    assert issubclass(int, PyInfo.integer_types)
    assert issubclass(type, PyInfo.class_types)

# Generated at 2022-06-24 03:20:29.736557
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    info = PyInfo()
    assert sys.version_info[0] == 2 and info.PY2
    assert not info.PY3

    assert info.maxsize == sys.maxsize

    assert info.string_types == (basestring,)
    assert info.text_type == unicode
    assert info.binary_type == str
    assert info.integer_types == (int, long)
    assert info.class_types == (type, types.ClassType)

# Generated at 2022-06-24 03:20:34.522510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == (1 << 31) - 1 if not PyInfo.PY3 else sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:20:38.934223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

elif __name__ == '__live_coding__':
    def _test_PyInfo():
        import doctest
        doctest.testmod()
        print('Test done!')

# Generated at 2022-06-24 03:20:48.404665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:20:49.517924
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True, 'PY3 should be True'



# Generated at 2022-06-24 03:20:52.346247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    testpy = PyInfo()
    if not testpy.PY2 and not testpy.PY3:
        raise AssertionError



# Generated at 2022-06-24 03:21:02.325889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    myPyInfo = PyInfo()
    if myPyInfo.PY2:
        assert myPyInfo.string_types == (basestring,)
        assert myPyInfo.text_type == unicode
        assert myPyInfo.binary_type == str
        assert myPyInfo.integer_types == (int, long)
        assert myPyInfo.class_types == (type, types.ClassType)
        assert myPyInfo.maxsize == (1 << 31) - 1
    else:
        assert myPyInfo.string_types == (str,)
        assert myPyInfo.text_type == str
        assert myPyInfo.binary_type == bytes
        assert myPyInfo.integer_types == (int,)
        assert myPyInfo.class_types == (type,)
        assert myPyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-24 03:21:07.821433
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Running unit test for class PyInfo")
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


test_PyInfo()


if (PyInfo.PY2):
    print("Running in python 2.7")
elif (PyInfo.PY3):
    print("Running in python 3.4")

# Generated at 2022-06-24 03:21:18.811236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test class PyInfo.
    """
    import sys
    import platform

    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(0, PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(PyInfo, PyInfo.integer_types)


# Generated at 2022-06-24 03:21:25.229178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize == sys.maxsize
    if PyInfo.PY2:
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.text_type == unicode
        assert PyInfo.string_types == (basestring,)
    else:  # PY3
        assert PyInfo.class_types == (type,)
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.text_type == str
        assert PyInfo.string_types == (str,)


unknown = '<unknown>'



# Generated at 2022-06-24 03:21:31.549358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    # Test PY2
    if pyinfo.PY2 is True:
        assert pyinfo.PY3 is False
    else:
        assert pyinfo.PY2 is False

    # Test string_types
    assert pyinfo.string_types == (
        basestring,
        str,
    )

    # Test text_type
    assert pyinfo.text_type == (
        unicode
        if pyinfo.PY2 else
        str
    )

    # Test binary_type
    assert pyinfo.binary_type == (
        str
        if pyinfo.PY2 else
        bytes
    )

    # Test integer_types
    assert pyinfo.integer_types == (
        int,
        long,
    )

    # Test class_types
    assert pyinfo

# Generated at 2022-06-24 03:21:40.048701
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True or pi.PY3 is True, "Either PY2 or PY3 must be True"
    assert pi.PY2 is False or pi.PY3 is False, "Both PY2 and PY3 cannot be True"

    assert type(pi.maxsize) == int

    assert len(pi.string_types) == 1
    assert type(pi.string_types[0]) == type
    assert type(pi.binary_type) == type
    assert type(pi.integer_types) == tuple
    assert len(pi.integer_types) == 2
    assert type(pi.class_types) == tuple
    assert len(pi.class_types) == 2



# Generated at 2022-06-24 03:21:49.229897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 2:
        assert isinstance("a", pyinfo.string_types)
        assert not isinstance(b"a", pyinfo.string_types)
        assert isinstance(u"a", pyinfo.text_type)
        assert isinstance(1, pyinfo.integer_types)
        assert pyinfo.maxsize == sys.maxsize
        assert isinstance(int, pyinfo.class_types)

    if sys.version_info[0] == 3:
        assert not isinstance("a", pyinfo.string_types)

# Generated at 2022-06-24 03:21:56.238250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    assert a.PY2 == (sys.version_info[0] == 2)
    assert a.PY3 == (sys.version_info[0] == 3)
    if a.PY3:
        assert a.string_types == (str,)
        assert a.text_type == str
        assert a.binary_type == bytes
        assert a.integer_types == (int,)
        assert a.class_types == (type,)
        assert a.maxsize == sys.maxsize
    else:
        assert a.string_types == (basestring,)
        assert a.text_type == unicode
        assert a.binary_type == str
        assert a.integer_types == (int, long)
        assert a.class_types == (type, types.ClassType)


# Generated at 2022-06-24 03:22:05.580123
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert (PyInfo.integer_types == (int, long))
        assert (PyInfo.class_types == (type, types.ClassType))



# Generated at 2022-06-24 03:22:14.397898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for item in dir(PyInfo):
        if item.startswith("_"):
            continue
        item_value = getattr(PyInfo, item)
        assert isinstance(item_value, object), "not object"
        assert isinstance(item_value, PyInfo.class_types), "not class"

    assert isinstance(PyInfo.string_types, tuple), "not tuple"
    assert isinstance(PyInfo.string_types[0], PyInfo.class_types), "not class"

    assert isinstance(PyInfo.text_type, PyInfo.class_types), "not class"
    assert isinstance(PyInfo.binary_type, PyInfo.class_types), "not class"
    assert isinstance(PyInfo.integer_types, tuple), "not tuple"

# Generated at 2022-06-24 03:22:20.378339
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PyInfo.PY2:", PyInfo.PY2)
    print("PyInfo.PY3:", PyInfo.PY3)
    print("PyInfo.string_types:", PyInfo.string_types)
    print("PyInfo.text_type:", PyInfo.text_type)
    print("PyInfo.binary_type:", PyInfo.binary_type)
    print("PyInfo.integer_types:", PyInfo.integer_types)
    print("PyInfo.class_types:", PyInfo.class_types)
    print("PyInfo.maxsize:", PyInfo.maxsize)


# Reference
# https://github.com/python/cpython/blob/3.7/Lib/six.py
# https://docs.python.org/2/library/sys.html#sys.version

# Generated at 2022-06-24 03:22:27.854520
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def class_types_test():
        assert isinstance(str, PyInfo.class_types)
        assert not isinstance(str, PyInfo.class_types)  # Not Python 2

    class_types_test()

    def string_types_test():
        assert isinstance('', PyInfo.string_types) or \
            isinstance(u'', PyInfo.string_types)  # Python 2 or 3

    string_types_test()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-24 03:22:35.836710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0] is basestring
    elif PyInfo.PY3:
        assert len(PyInfo.string_types) == 1
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0] is str

# Generated at 2022-06-24 03:22:44.519230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-24 03:22:53.668657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    pyinfo = PyInfo()
    if sys.version_info[0] == 2:
        assert pyinfo.PY2 and pyinfo.string_types == (basestring,) and pyinfo.text_type == unicode and \
               pyinfo.binary_type == str and pyinfo.integer_types == (int, long) and pyinfo.class_types == (type, types.ClassType)
    if sys.version_info[0] == 3:
        assert pyinfo.PY3 and pyinfo.string_types == (str,) and pyinfo.text_type == str and \
               pyinfo.binary_type == bytes and pyinfo.integer_types == (int,) and pyinfo.class_types == (type, )

# Generated at 2022-06-24 03:22:59.501859
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
    elif PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(b"a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)

# Generated at 2022-06-24 03:23:10.166570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.string_types)
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.string_types)

    assert isinstance("abc", PyInfo.text_type)
    assert not isinstance(b"abc", PyInfo.text_type)

    assert isinstance(b"abc", PyInfo.binary_type)
    assert not isinstance("abc", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("abc", PyInfo.integer_types)

    assert isinstance(types, PyInfo.class_types)

# Generated at 2022-06-24 03:23:18.194230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    >>> assert PyInfo.PY2 or PyInfo.PY3
    >>> assert isinstance('', PyInfo.string_types)
    >>> assert (not isinstance(u'', PyInfo.string_types))
    >>> assert isinstance(b'', PyInfo.binary_type)
    >>> assert (not isinstance('', PyInfo.binary_type))
    >>> assert isinstance(1, PyInfo.integer_types)
    >>> assert (not isinstance(1, PyInfo.string_types))
    >>> assert isinstance(object(), PyInfo.class_types)
    >>> assert (not isinstance(1, PyInfo.class_types))
    '''

# vvv ONLYTEST vvv
if __name__ == '__main__':
    import doctest
    doctest.testmod()
# ^^^ ONLY

# Generated at 2022-06-24 03:23:27.204624
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


is_PY2 = PyInfo.PY2

is_PY3 = PyInfo.PY3

string_types = PyInfo.string_types

text_type = PyInfo.text_type

binary_type = PyInfo.binary_type

integer_types = PyInfo.integer_types

class_types

# Generated at 2022-06-24 03:23:37.559942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert 'PY2' in globals()
    assert 'PY3' in globals()
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert not PyInfo.PY2 or not PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

    assert 'PY2' in sys.modules[__name__].__dict__
    assert 'PY3' in sys.modules[__name__].__dict__
    assert PyInfo.PY2 == sys.modules[__name__].__dict__['PY2']
    assert PyInfo.PY3 == sys.modules[__name__].__dict__['PY3']

# Generated at 2022-06-24 03:23:44.283250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-24 03:23:50.193834
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)



# Generated at 2022-06-24 03:23:54.815701
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY3
    False
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY3
    False
    """
    pass

# Generated at 2022-06-24 03:24:01.334181
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.binary_type == str
    assert PyInfo.text_type == unicode
    assert PyInfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-24 03:24:12.167637
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)