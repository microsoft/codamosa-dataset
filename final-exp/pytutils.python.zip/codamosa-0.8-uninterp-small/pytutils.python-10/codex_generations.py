

# Generated at 2022-06-26 02:49:18.526401
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert isinstance(py_info_0, PyInfo)

# Generated at 2022-06-26 02:49:24.811120
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert py_info_1.PY2 == PyInfo.PY2
    assert py_info_1.PY3 == PyInfo.PY3
    assert py_info_1.string_types == PyInfo.string_types
    assert py_info_1.text_type == PyInfo.text_type
    assert py_info_1.binary_type == PyInfo.binary_type
    assert py_info_1.integer_types == PyInfo.integer_types
    assert py_info_1.class_types == PyInfo.class_types
    assert py_info_1.maxsize == PyInfo.maxsize

test_case_0()

# Generated at 2022-06-26 02:49:26.111071
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:27.905864
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test 0: ", test_case_0())
    print("Successful")


# Generated at 2022-06-26 02:49:36.397627
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == sys.version_info[0] == 2
    assert py_info_0.PY3 == sys.version_info[0] == 3
    assert py_info_0.string_types == (basestring,) if sys.version_info[0] == 2 else (str,)
    assert py_info_0.text_type == unicode if sys.version_info[0] == 2 else str
    assert py_info_0.binary_type == str if sys.version_info[0] == 2 else bytes
    assert py_info_0.integer_types == (int, long) if sys.version_info[0] == 2 else (int,)

# Generated at 2022-06-26 02:49:40.740415
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == 9223372036854775807

# Generated at 2022-06-26 02:49:44.711050
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()


if __name__ == '__main__':
    test_case_0()  # runs only the test case with index 0
    #test_PyInfo()  # runs all the test cases in the file

# Generated at 2022-06-26 02:49:45.707335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('test PyInfo constructor')
    test_case_0()
    pass

# Generated at 2022-06-26 02:49:56.725729
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for constructor()
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == sys.version_info[0] == 2
    assert py_info_0.PY3 == sys.version_info[0] == 3
    if py_info_0.PY3:
        assert py_info_0.string_types == (str,)
        assert py_info_0.text_type == str
        assert py_info_0.binary_type == bytes
        assert py_info_0.integer_types == (int,)
        assert py_info_0.class_types == (type,)
        assert py_info_0.maxsize == sys.maxsize
    else:  # PY2
        assert py_info_0.string_types == (basestring,)
        assert py

# Generated at 2022-06-26 02:49:58.273198
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()


# Generated at 2022-06-26 02:50:08.630896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
#     assert py_info_0.PY2
#     assert py_info_0.PY3
#     assert py_info_0.PY2 == py_info_0.PY3



if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:50:11.938890
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == True
    assert PyInfo().PY3 == False

    # Test passed
    print("Test Passed")

if __name__ == "__main__":
    test_PyInfo()
    test_case_0()

# Generated at 2022-06-26 02:50:21.912687
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # Test attribute value
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3

    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
        assert py_info.integer_types == (int,)
        assert py_info.class_types == (type,)
        assert py_info.maxsize == sys.maxsize
    else:  # PY2
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
       

# Generated at 2022-06-26 02:50:27.577883
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


if __name__ == "__main__":
    script_dir = os.path.dirname(os.path.realpath(__file__))
    pyautogui.PAUSE = 0.1
    pyautogui.FAILSAFE = True
    test_PyInfo()
    unittest.main()

# Generated at 2022-06-26 02:50:28.565911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:50:35.447810
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    # Test if the PyInfo constants are correct
    assert py_info_0.PY3 == False
    assert py_info_1.PY2 == True
    assert py_info_0.PY2 == True
    assert py_info_1.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_1.string_types == (basestring,)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_1.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == 9223372036854775807

# Generated at 2022-06-26 02:50:38.155127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check if maxsize is defined
    py_info_0 = PyInfo()
    assert hasattr(py_info_0, 'maxsize')


# Generated at 2022-06-26 02:50:44.966546
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:51.262569
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    if (py_info_0.PY2):
        assert True
    else:
        assert False
    if (py_info_1.PY3):
        assert False
    else:
        assert True
    assert py_info_0.text_type == str
    assert py_info_1.binary_type == bytes
    assert py_info_0.maxsize == 2**63

# Generated at 2022-06-26 02:50:52.434173
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()



# Generated at 2022-06-26 02:51:11.996227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print((py_info_0.PY3))
    assert(py_info_0.PY3 == py_info_1.PY3)
    assert(py_info_0.maxsize == py_info_1.maxsize)
    assert(py_info_0.binary_type == py_info_1.binary_type)
    assert(py_info_0.string_types == py_info_1.string_types)
    assert(py_info_0.text_type == py_info_1.text_type)
    assert(py_info_0.integer_types == py_info_1.integer_types)
    assert(py_info_0.class_types == py_info_1.class_types)


# Generated at 2022-06-26 02:51:15.332282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

################################################################################

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:16.856604
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:19.602972
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-26 02:51:26.399357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("\n---Unit test for PyInfo---")
    new_PyInfo = PyInfo()
    print(new_PyInfo.PY3)
    print(new_PyInfo.PY2)
    print(new_PyInfo.string_types)
    print(new_PyInfo.text_type)
    print(new_PyInfo.binary_type)
    print(new_PyInfo.integer_types)
    print(new_PyInfo.class_types)
    print(new_PyInfo.maxsize)
    print("\n")


# Generated at 2022-06-26 02:51:28.860103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test if the instantiation is succeed
    if PyInfo():
        assert True
    else:
        assert False
    # Test if the class can be called
    if PyInfo:
        assert True
    else:
        assert False

# Generated at 2022-06-26 02:51:36.524758
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    print("*** {{class:PyInfo,method:constructor()}} ***")
    print("Test attributes of class PyInfo")
    print(py_info.PY2)
    print(py_info.PY3)
    print(py_info.string_types)
    print(py_info.text_type)
    print(py_info.binary_type)
    print(py_info.integer_types)
    print(py_info.class_types)
    print(py_info.maxsize)

# Generated at 2022-06-26 02:51:37.981070
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:45.480450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == True or py_info.PY2 == False
    assert type(py_info.string_types) == tuple
    assert type(py_info.text_type) == str or type(py_info.text_type) == unicode
    assert type(py_info.binary_type) == str or type(py_info.binary_type) == bytes
    assert type(py_info.integer_types) == tuple
    assert type(py_info.class_types) == tuple
    assert type(py_info.maxsize) == int

# Generated at 2022-06-26 02:51:54.514821
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:52:12.619089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert sys.maxsize == PyInfo.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:52:13.726881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None



# Generated at 2022-06-26 02:52:20.337884
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Tests for PyInfo class and its PY2, PY3, maxsize, string_types, text_type, binary_type, integer_types, class_types attributes."""

    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:52:26.544823
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    assert PyInfo.PY2 or PyInfo.PY3


PY2 = PyInfo.PY2
PY3 = PyInfo.PY3
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types
maxsize = PyInfo.maxsize

# Generated at 2022-06-26 02:52:35.099201
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:46.538031
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.maxsize < sys.maxsize
    else:
        assert PyInfo.maxsize == sys.maxsize

    if PyInfo.PY2:
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
    else:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-26 02:52:50.358461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:57.376182
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert maxsize == sys.maxint
    else:
        assert maxsize == sys.maxsize


if __name__ == '__main__':
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-26 02:53:00.012739
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo, PyInfo)

# Generated at 2022-06-26 02:53:09.588041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:53:32.435351
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:39.628103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, int)
    else:
        assert PyInfo.maxsize == 2147483647

test_PyInfo()

# Generated at 2022-06-26 02:53:49.456049
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2
    assert PyInfo.PY3 or PyInfo.PY2

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert (
        isinstance(PyInfo.maxsize, int)
        or isinstance(PyInfo.maxsize, long)
    )



# Generated at 2022-06-26 02:54:01.466993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.string_types == (basestring,) if pyinfo.PY2 else (str,)
    assert pyinfo.text_type == unicode if pyinfo.PY2 else str
    assert pyinfo.binary_type == str if pyinfo.PY2 else bytes
    assert pyinfo.integer_types == (int, long) if pyinfo.PY2 else (int,)
    assert pyinfo.class_types == (type, types.ClassType) if pyinfo.PY2 else (type,)

# Generated at 2022-06-26 02:54:12.539477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if PyInfo.PY2:
        expected = {
            "PY2": True,
            "PY3": False,
            "string_types": (basestring,),
            "text_type": unicode,
            "binary_type": str,
            "integer_types": (int, long),
            "class_types": (type, types.ClassType),
            "maxsize": sys.maxsize,
        }

# Generated at 2022-06-26 02:54:16.061133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# ------------------------------------------------------------- #
#                   Functional Programming                     #
# ------------------------------------------------------------- #

# Generated at 2022-06-26 02:54:21.789682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)


maketrans = _identity if PyInfo.PY3 else bytes.maketrans
# maketrans is an alias of bytes.maketrans in PY3, so it should not be byte literal
# "maketrans" should be used to avoid this issue.



# Generated at 2022-06-26 02:54:32.220886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> str(PyInfo.PY2)
    'True'
    >>> str(PyInfo.PY3)
    'False'
    >>> str(PyInfo.string_types)
    "(<type 'basestring'>,)"
    >>> str(PyInfo.text_type)
    "<type 'unicode'>"
    >>> str(PyInfo.binary_type)
    "<type 'str'>"
    >>> str(PyInfo.integer_types)
    "(<type 'int'>, <type 'long'>)"
    >>> str(PyInfo.class_types)
    "(<type 'type'>, <type 'classobj'>)"
    >>> str(PyInfo.maxsize)
    '9223372036854775807'
    """
    pass



# Generated at 2022-06-26 02:54:40.982692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import struct

    CChar = struct.Struct("c")
    CUChar = struct.Struct("B")

    b = CChar.pack(b"")
    B = CUChar.unpack(b)[0]

    def s(p):
        if CChar.unpack(p)[0] == b"":
            return None
        else:
            return p

    class A(object):

        def __len__(self):
            return 1 << 31

    try:
        len(A())
        X = int((1 << 63) - 1)
    except OverflowError:
        X = int((1 << 31) - 1)

    print("Python 2 = %s" % PyInfo.PY2)
    print("Python 3 = %s" % PyInfo.PY3)
    assert PyInfo.PY2 or Py

# Generated at 2022-06-26 02:54:51.661827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo"""
    assert PyInfo.PY2 or PyInfo.PY3, "Cannot determine a valid python version"
    assert PyInfo.maxsize > 0, "Cannot determine a valid maximum integer"
    assert isinstance("", PyInfo.string_types), "String is not valid"
    assert isinstance("", PyInfo.text_type), "Text type is not valid"
    assert isinstance("", PyInfo.binary_type), "Binary type is not valid"
    assert isinstance(1, PyInfo.integer_types), "Integer type is not valid"
    assert isinstance(PyInfo, PyInfo.class_types), "Class type is not valid"


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:41.656935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.string_types)
    else:
        assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)
    if PyInfo.PY2:
        assert isinstance(types.ClassType, PyInfo.class_types)
   

# Generated at 2022-06-26 02:55:45.016348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-26 02:55:53.346119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Simple unit test of PyInfo.
    """

    p = PyInfo()

    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    if p.PY3:
        assert isinstance(p.string_types, tuple)
        assert isinstance(p.text_type, types.TypeType)
        assert isinstance(p.binary_type, types.TypeType)
        assert isinstance(p.integer_types, tuple)
        assert isinstance(p.class_types, tuple)
    else:  # PY2
        assert isinstance(p.string_types, tuple)
        assert isinstance(p.text_type, types.TypeType)
        assert isinstance(p.binary_type, types.TypeType)

# Generated at 2022-06-26 02:55:59.328997
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert "basestring" in dir()
    assert "unicode" in dir()
    assert "long" in dir()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:04.211425
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    with pytest.raises(AttributeError):
        PyInfo.string_types = 1
    with pytest.raises(AttributeError):
        PyInfo.text_type = 1
    with pytest.raises(AttributeError):
        PyInfo.binary_type = 1
    with pytest.raises(AttributeError):
        PyInfo.integer_types = 1
    with pytest.raises(AttributeError):
        PyInfo.class_types = 1
    with pytest.raises(AttributeError):
        PyInfo.maxsize = 1


# Isolated functions

# Generated at 2022-06-26 02:56:13.551179
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


# Generated at 2022-06-26 02:56:22.256241
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(), PyInfo.string_types)
    assert isinstance(PyInfo.integer_types, tuple)
    # Python 2.x
    assert isinstance(PyInfo.class_types, tuple)
    # Python 3.x
    assert isinstance(PyInfo.class_types, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:56:26.102327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


# ______________________________________________________________________________
# Global functions


# Generated at 2022-06-26 02:56:30.660541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    print(PyInfo.PY2)
    print(PyInfo.maxsize)
    pass


if __name__ == '__main__':
    print(__file__)
    print(os.getcwd())
    test_PyInfo()

# Generated at 2022-06-26 02:56:42.903501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False, "pyinfo.PY2 is not boolean"
    assert pyinfo.PY3 is True or pyinfo.PY3 is False, "pyinfo.PY3 is not boolean"
    assert (
        pyinfo.PY2 is False and pyinfo.PY3 is True
    ) or (
        pyinfo.PY2 is True and pyinfo.PY3 is False
    ), "pyinfo.PY2 and pyinfo.PY3 are both true or both false"

# Generated at 2022-06-26 02:58:20.177060
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:58:23.985931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


# Helper function to test whether a function raises a defined error

# Generated at 2022-06-26 02:58:30.473975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('hello', PyInfo.string_types)
        assert isinstance(u'hello', PyInfo.text_type)
        assert not isinstance('hello', PyInfo.binary_type)
        assert isinstance(b'hello', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(Slave, PyInfo.class_types)
    else:
        assert isinstance('hello', PyInfo.string_types)
        assert isinstance('hello', PyInfo.text_type)
        assert isinstance(b'hello', PyInfo.binary_type)
        assert not isinstance('hello', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:58:38.141387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    info = PyInfo()
    assert info.string_types
    assert info.integer_types
    assert info.maxsize
    if PyInfo.PY2:
        assert info.text_type == unicode
    else:
        assert info.text_type == str
    if PyInfo.PY2:
        assert info.binary_type == str
    else:
        assert info.binary_type == bytes


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:58:49.937428
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('\nTest 2.1: Constructor of class PyInfo is used.')

    pi = PyInfo()

    print('\nTest 2.2.1-2: Type of pi.PY2 is', type(pi.PY2))
    print('\nTest 2.2.3-4: Value of pi.PY2 is', pi.PY2)
    print('\nTest 2.2.5-6: Type of pi.PY3 is', type(pi.PY3))
    print('\nTest 2.2.7-8: Value of pi.PY3 is', pi.PY3)
    print('\nTest 2.2.9-10: Type of pi.string_types is', type(pi.string_types))

# Generated at 2022-06-26 02:59:00.618911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p, PyInfo)
    assert p.string_types == (basestring,)
    assert p.integer_types == (int, long)
    assert p.class_types == (type, types.ClassType)
    assert p.PY2
    assert p.maxsize == 2147483647
    assert not p.PY3

    p = PyInfo()
    assert isinstance(p, PyInfo)
    assert p.string_types == (str,)
    assert p.integer_types == (int,)
    assert p.class_types == (type,)
    assert not p.PY2
    assert p.maxsize > 2147483647
    assert p.PY3

    print('test_PyInfo() passed!')



# Generated at 2022-06-26 02:59:04.386651
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:59:10.819260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert (basestring,) == PyInfo.string_types
    assert (int, long) == PyInfo.integer_types
    assert (type, types.ClassType) == PyInfo.class_types

# Generated at 2022-06-26 02:59:17.756438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)

    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)

    assert isinstance(pyinfo.maxsize, int)