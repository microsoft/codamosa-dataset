

# Generated at 2022-06-26 02:49:22.564710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # instantiate the logger
    logger = logging.getLogger(__name__)
    logger.debug('Test module: %s', __name__)
    test_case_0()


if __name__ == '__main__':
    logging.basicConfig(level=logging.DEBUG)
    # execute only if run as the entry point into the program
    test_PyInfo()

# Generated at 2022-06-26 02:49:32.886713
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=no-self-use
    """
    Test that the constructor of class PyInfo works as expected.
    """
    import trafficgeneratorapis.gen_utils as gen_utils

    py_info_0 = PyInfo()
    py_info_1 = gen_utils.PyInfo()

    assert py_info_0.binary_type == py_info_1.binary_type
    assert py_info_0.integer_types == py_info_1.integer_types
    assert py_info_0.maxsize == py_info_1.maxsize
    assert py_info_0.string_types == py_info_1.string_types
    assert py_info_0.text_type == py_info_1.text_type
    assert py_info_0.PY2 == py_info

# Generated at 2022-06-26 02:49:38.101184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert isinstance(py_info.PY2, bool)
    assert isinstance(py_info.PY3, bool)
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)


# Generated at 2022-06-26 02:49:48.441848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    if not ((py_info_1.PY2 == True and py_info_1.PY3 == False)):
        raise RuntimeError("Invalid behaviour when running single test case 'test_PyInfo'")
    if py_info_1.string_types == None:
        raise RuntimeError("Invalid behaviour when running single test case 'test_PyInfo'")
    if py_info_1.text_type == None:
        raise RuntimeError("Invalid behaviour when running single test case 'test_PyInfo'")
    if py_info_1.binary_type == None:
        raise RuntimeError("Invalid behaviour when running single test case 'test_PyInfo'")

# Generated at 2022-06-26 02:49:58.312747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == 9223372036854775807

    py_info_1 = PyInfo()
    assert py_info_1.PY2 == False
    assert py_info_1.PY3 == True

# Generated at 2022-06-26 02:50:01.878232
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Test constructor of class PyInfo')
    try:
        py_info = PyInfo()
        assert py_info is not None
    except Exception as e:
        print(e)


# Generated at 2022-06-26 02:50:03.509989
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()



test_py_info_0 = PyInfo()
test_PyInfo()


# Generated at 2022-06-26 02:50:12.583215
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Testing constructor of PyInfo...', end='')
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int
    print('Passed.')


#################################################
# testAll and main
#################################################


# Generated at 2022-06-26 02:50:18.234020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.string_types() == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types() == (int,)
    assert PyInfo.class_types() == (type,)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-26 02:50:19.909781
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Constructor for class PyInfo
    py_info = PyInfo()

test_case_0()

# Generated at 2022-06-26 02:50:23.725141
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_obj_0 = PyInfo()

# Generated at 2022-06-26 02:50:32.128693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    print(py_info_0)
    assert py_info_0.PY2 is True
    assert py_info_0.PY3 is False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    if sys.platform.startswith("java"):
        assert py_info_0.maxsize == 2147483647
    else:
        class X(object):
            def __len__(self):
                return 1 << 31
        try:
            len(X())
        except OverflowError:
            assert py_

# Generated at 2022-06-26 02:50:41.242419
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.maxsize > 0

    if py_info.PY2:
        assert isinstance(py_info.string_types, tuple)
    else:
        assert isinstance(py_info.string_types, type)
        assert isinstance(py_info.string_types, type(str))

    assert isinstance(py_info.integer_types, tuple)

    if py_info.PY2:
        assert isinstance(py_info.class_types, tuple)
    else:
        assert isinstance(py_info.class_types, type)
        assert isinstance(py_info.class_types, type(type))

    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.text_type, type)

   

# Generated at 2022-06-26 02:50:50.529094
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:50:51.758647
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


test_case_0()

test_PyInfo()

# Generated at 2022-06-26 02:51:00.081597
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == (sys.version_info[0] == 2)
    assert py_info_0.PY3 == (sys.version_info[0] == 3)
    if py_info_0.PY3:
        assert py_info_0.string_types == (str,)
        assert py_info_0.text_type == str
        assert py_info_0.binary_type == bytes
        assert py_info_0.integer_types == (int,)
        assert py_info_0.class_types == (type,)

        assert py_info_0.maxsize == sys.maxsize
    else:  # PY2
        assert py_info_0.string_types == (basestring,)
        assert py_info_

# Generated at 2022-06-26 02:51:01.467988
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:02.459470
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:51:12.725419
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
        assert py_info.integer_types == (int,)
        assert py_info.maxsize == sys.maxsize
        assert py_info.class_types == (type,)
    else:
        assert py_info.PY3 == py_info.PY2 != True
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_

# Generated at 2022-06-26 02:51:22.505976
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert isinstance(py_info_1, PyInfo)
    assert py_info_1.PY2 == py_info_1.PY3 == False
    assert py_info_1.binary_type == str
    assert py_info_1.string_types == (basestring,)
    assert py_info_1.text_type == unicode
    assert py_info_1.class_types == (type, types.ClassType)
    assert py_info_1.integer_types == (int, long)
    assert py_info_1.maxsize == (1 << 31) - 1


# Generated at 2022-06-26 02:51:26.482170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY3 is True
    assert pyinfo.PY2 is False



# Generated at 2022-06-26 02:51:28.428236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if hasattr(sys, 'maxsize'):
        assert PyInfo.PY2 or PyInfo.PY3
        assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-26 02:51:34.335809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:37.711626
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 and PY3 must be `true` and `false` respectively
    assert PyInfo().PY2 ^ PyInfo().PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:41.845853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )



# Generated at 2022-06-26 02:51:44.887663
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert "unicode" not in dir(PyInfo)

    assert type("") in PyInfo.string_types
    assert isinstance(u"", PyInfo.text_type)
    assert type(b"") == PyInfo.binary_type
    assert isinstance(0, PyInfo.integer_types)
    assert type(PyInfo) in PyInfo.class_types


test_PyInfo()

# Generated at 2022-06-26 02:51:49.131805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:51:56.439403
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 1

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert issubclass(PyInfo.string_types[0], PyInfo.text_type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)



# Generated at 2022-06-26 02:52:07.668723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from bpylist import pp

    # type of string_types should be tuple
    assert isinstance(PyInfo.string_types, tuple)

    # type of class_types should be tuple
    assert isinstance(PyInfo.class_types, tuple)

    # type of text_type should be type
    assert isinstance(PyInfo.text_type, type)

    # type of binary_type should be type
    assert isinstance(PyInfo.binary_type, type)

    # type of integer_types should be type
    assert isinstance(PyInfo.integer_types, tuple)

    # type of maxsize should be int
    assert isinstance(PyInfo.maxsize, int)

    # PY3 should be True or False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False

    # PY2

# Generated at 2022-06-26 02:52:14.499119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def raise_if(flag):
        if flag is True:
            raise Exception('must not raise!')
    pyinfo = PyInfo()
    if pyinfo.PY2:
        assert pyinfo.PY3 is False
        assert isinstance("123", pyinfo.string_types)
        assert isinstance(b"123", pyinfo.binary_type)
        assert isinstance(u'123', pyinfo.text_type)
        assert isinstance(123, pyinfo.integer_types)
        assert isinstance(int, pyinfo.class_types)
        raise_if(isinstance("123", pyinfo.binary_type))
        raise_if(isinstance("123", pyinfo.text_type))
        raise_if(isinstance("123", pyinfo.integer_types))

# Generated at 2022-06-26 02:52:22.153596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-26 02:52:30.312634
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:38.822966
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance("", PyInfo.integer_types)
        assert type("") == PyInfo.text_type
        assert not type("") == PyInfo.class_types

        assert isinstance(b"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.integer_types)
        assert not type(b"") == PyInfo.text_type
        assert not type(b"") == PyInfo.class_types

        assert not isinstance(1, PyInfo.string_types)
        assert not isinstance(1, PyInfo.binary_type)

# Generated at 2022-06-26 02:52:41.554583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:52:45.866326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == (1 << 31) - 1


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:53.974376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance('hello', PyInfo.text_type)
    assert isinstance(b'hello', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-26 02:52:57.020833
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info, PyInfo)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:07.615805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attribute, expected_value in {
        "PY2": sys.version_info[0] == 2,
        "PY3": sys.version_info[0] == 3,
    }.items():
        actual_value = getattr(PyInfo, attribute)
        if actual_value != expected_value:
            raise Exception("value of attribute {} is {} instead of {}".format(attribute, actual_value, expected_value))


if __name__ == "__main__":
    print("version_info = {}".format(sys.version_info))
    test_PyInfo()
    print("OK")

# Generated at 2022-06-26 02:53:19.645519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Fake(object):
        PY2 = True
        PY3 = False
        string_types = (str, unicode)
        text_type = str
        binary_type = unicode
        integer_types = (int, long)
        class_types = (type, types.ClassType)
        maxsize = (1 << 31) - 1
    assert isinstance(PyInfo.PY2, bool) and PyInfo.PY2
    assert isinstance(PyInfo.PY3, bool) and not PyInfo.PY3
    assert len(PyInfo.string_types) == 2 and isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-26 02:53:31.499481
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass
    # if PyInfo.PY2:
    #     assert isinstance(PyInfo.string_types, types.TupleType)
    #     assert PyInfo.string_types == (str, types.UnicodeType)
    #     assert isinstance(PyInfo.text_type, types.StringType)
    #     assert PyInfo.text_type == unicode
    #     assert isinstance(PyInfo.binary_type, types.StringType)
    #     assert PyInfo.binary_type == str
    #     assert isinstance(PyInfo.integer_types, types.TupleType)
    #     assert PyInfo.integer_types == (long, int)
    #     assert isinstance(PyInfo.class_types, types.TupleType)
    #     assert PyInfo.class_types == (types.TypeType

# Generated at 2022-06-26 02:53:47.963343
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-26 02:53:54.539238
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode

# Generated at 2022-06-26 02:53:58.711633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    if py_info.PY3:
        assert (
            py_info.string_types == (str,)
            and py_info.text_type == str
            and py_info.binary_type == bytes
            and py_info.integer_types == (int,)
            and py_info.class_types == (type,)
            and py_info.maxsize == sys.maxsize
        )
    else:
        assert (
            py_info.string_types == (basestring,)
            and py_info.text_type == unicode
            and py_info.binary_type == str
            and py_info.integer_types == (int, long)
            and py_info.class_types == (type, types.ClassType)
        )



# Generated at 2022-06-26 02:54:10.459658
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('test', PyInfo.string_types)
    assert isinstance(u'test', PyInfo.string_types)
    assert isinstance(b'test', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize >= (1 << 31) - 1


# Generated at 2022-06-26 02:54:20.659779
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)


# Definition of varible str
if PyInfo.PY3:
    str = str
else:
    str = unicode

# Class definition of utf8

# Generated at 2022-06-26 02:54:22.572448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

# Generated at 2022-06-26 02:54:32.474239
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from datetime import datetime
    from datetime import timedelta

    def str1(*args, **kwargs):
        return 'str1'

    def str2(*args, **kwargs):
        return u'str2'

    def int1(*args, **kwargs):
        return 1

    def int2(*args, **kwargs):
        return 2

    def int3(*args, **kwargs):
        return 2147483647

    def int4(*args, **kwargs):
        return 2147483648

    def float1(*args, **kwargs):
        return 0.1

    def float2(*args, **kwargs):
        return 0.2

    def float3(*args, **kwargs):
        return 1.7976931348623157e+308


# Generated at 2022-06-26 02:54:41.023851
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:54:49.242522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('b', PyInfo.string_types)
    assert isinstance(u'b', PyInfo.string_types)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance([], PyInfo.class_types)


# Decorator for test function running under both Python2 and Python3

# Generated at 2022-06-26 02:54:53.627372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    print(info.PY2)
    print(info.PY3)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:21.067116
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance((1 << 31) - 1, PyInfo.maxsize)

# Generated at 2022-06-26 02:55:25.663340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    py_info = PyInfo()
    assert py_info.PY2
    assert py_info.string_types == (basestring,)
    assert py_info.text_type == unicode
    assert py_info.binary_type == str
    assert py_info.integer_types == (int, long)
    assert py_info.class_types == (type, types.ClassType)
    assert py_info.maxsize == (1 << 63) - 1
    """
    pass


py_info = PyInfo()



# Generated at 2022-06-26 02:55:29.326860
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance("", PyInfo.string_types)
    elif PyInfo.PY3:
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance("", PyInfo.string_types)

# Generated at 2022-06-26 02:55:38.452580
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.maxsize == PyInfo.maxsize
    if PyInfo.PY3:
        assert sys.maxsize == 9223372036854775807
    else:
        if sys.platform.startswith("java"):
            assert sys.maxsize == 2147483647
        else:
            assert sys.maxsize == 9223372036854775807


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:55:44.656328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert (PyInfo.PY3 == (3 == sys.version_info[0]))
    assert (PyInfo.PY2 == (2 == sys.version_info[0]))

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)

    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)


# Generated at 2022-06-26 02:55:46.067667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Run test when python version is 2
    sys.version_info = (2, 7, 12, 'final', 0)
    assert PyInfo().PY2 is True
    assert PyInfo().PY3 is False
    assert PyInfo().string_typ

# Generated at 2022-06-26 02:55:53.127605
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert eval("PyInfo.PY2") == PyInfo.PY2
    assert eval("PyInfo.PY3") == PyInfo.PY3
    assert eval("PyInfo.string_types") == PyInfo.string_types
    assert eval("PyInfo.text_type") == PyInfo.text_type
    assert eval("PyInfo.binary_type") == PyInfo.binary_type
    assert eval("PyInfo.integer_types") == PyInfo.integer_types
    assert eval("PyInfo.class_types") == PyInfo.class_types
    assert eval("PyInfo.maxsize") == PyInfo.maxsize

    print("Unit test for constructor of class PyInfo: PASS")


# Unit test function

# Generated at 2022-06-26 02:55:57.203016
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:04.619131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') in PyInfo.string_types

        assert type('') is not PyInfo.text_type
        assert type(u'') is PyInfo.text_type
        assert type(b'') is not PyInfo.text_type

        assert type('') is not PyInfo.binary_type
        assert type(u'') is not PyInfo.binary_type
        assert type(b'') is PyInfo.binary_type

        assert type(1) in PyInfo.integer_types

# Generated at 2022-06-26 02:56:13.641394
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    pyinfo = PyInfo()

    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)
        if pyinfo.maxsize == sys.maxsize:
            assert sys.platform.startswith(
                "java"
            ), "Jython always uses 32 bits, other Python 2 platforms 64 bits"
        else:
            assert pyinfo.maxsize == int((1 << 31) - 1)
    elif pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
       

# Generated at 2022-06-26 02:56:55.007808
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)



# Generated at 2022-06-26 02:57:04.257841
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    assert PyInfo.string_types is (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.integer_types is (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types is (type, types.ClassType) if PyInfo.PY2 else (type,)



# Generated at 2022-06-26 02:57:10.981357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


if __name__ == "__main__":
    # Run described unit test
    sys.path.append(os.path.join(os.path.dirname(__file__), os.pardir, os.pardir))
    import test
    test.run_test(test_PyInfo)

# Generated at 2022-06-26 02:57:21.144158
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_false, assert_true
    import sys

    if sys.version_info[0] == 2:
        assert_false(PyInfo.PY3)
        assert_true(PyInfo.PY2)
        assert_true(isinstance(PyInfo.string_types, tuple))
        assert_true(isinstance(PyInfo.text_type, str))
        assert_true(isinstance(PyInfo.binary_type, str))
        assert_true(isinstance(PyInfo.integer_types, tuple))
        assert_true(isinstance(PyInfo.class_types, tuple))
        assert_true(isinstance(PyInfo.maxsize, int))
    elif sys.version_info[0] == 3:
        assert_false(PyInfo.PY2)

# Generated at 2022-06-26 02:57:27.347406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    if py_info.PY2:
        assert type('a') in py_info.string_types
        assert 'a' in py_info.string_types
    if py_info.PY3:
        assert type('a') == py_info.string_types[0]
        assert 'a' in py_info.string_types
    assert isinstance('a', py_info.string_types)

    assert type('a') == py_info.text_type
    assert isinstance('a', py_info.text_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:57:36.206116
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-26 02:57:41.210747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-26 02:57:46.618132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().maxsize, integer_types)
    assert isinstance(PyInfo().PY2, bool)
    assert isinstance(PyInfo().PY3, bool)
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().class_types, tuple)

# Generated at 2022-06-26 02:57:55.770246
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("1", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance("1", PyInfo.text_type)
    assert not isinstance(b"1", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("1", PyInfo.integer_types)
    assert issubclass(type, PyInfo.class_types)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:58:06.539503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # test maxsize attribute
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, integer_types)
        assert PyInfo.maxsize >= 2**31
    else:
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.maxsize >= 2**63

    # class_types only contains type object
    assert isinstance(PyInfo.class_types, tuple)
    assert len(PyInfo.class_types) == 1
    assert isinstance(PyInfo.class_types[0], type)
    if PyInfo.PY2:
        assert issubclass(PyInfo.class_types[0], types.ClassType)