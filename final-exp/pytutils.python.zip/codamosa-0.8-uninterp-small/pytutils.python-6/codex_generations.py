

# Generated at 2022-06-26 02:49:15.304109
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()



# Generated at 2022-06-26 02:49:23.467622
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test the constructor of class PyInfo
    py_info_0 = PyInfo()
    # Test the accessor of class PyInfo, for attribute PY2
    assert py_info_0.PY2 == True
    # Test the accessor of class PyInfo, for attribute PY3
    assert py_info_0.PY3 == False
    # Test the accessor of class PyInfo, for attribute string_types
    assert py_info_0.string_types == (basestring,)
    # Test the accessor of class PyInfo, for attribute text_type
    assert py_info_0.text_type == unicode
    # Test the accessor of class PyInfo, for attribute binary_type
    assert py_info_0.binary_type == str
    # Test the accessor of class PyInfo, for attribute integer_types
   

# Generated at 2022-06-26 02:49:33.362144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Given
    py_info_0 = PyInfo()

    # When
    # Then
    print("py_info_0.PY2 is", type(py_info_0.PY2), py_info_0.PY2)
    assert type(py_info_0.PY2) == bool
    print("py_info_0.PY3 is", type(py_info_0.PY3), py_info_0.PY3)
    assert type(py_info_0.PY3) == bool
    print("py_info_0.string_types is", type(py_info_0.string_types), py_info_0.string_types)
    assert type(py_info_0.string_types) == tuple

# Generated at 2022-06-26 02:49:34.477628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:35.901269
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info  # constructor should return an instance


# Generated at 2022-06-26 02:49:37.252194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2


# Generated at 2022-06-26 02:49:40.950509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test 0
    tr_0 = test_case_0()

# Unit tests for PyInfo

# Generated at 2022-06-26 02:49:43.845885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == sys.version_info[0] == 2)
    assert(PyInfo.PY3 == sys.version_info[0] == 3)

# Generated at 2022-06-26 02:49:50.004580
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == 9223372036854775807
if __name__ == '__main__':
    test_case_0()
    test_PyInfo()

# Generated at 2022-06-26 02:49:51.502131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()


# Generated at 2022-06-26 02:49:58.146345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> pyinfo
    <PyInfo object>
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:50:07.258107
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
    else:
        assert isinstance('', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)



# Generated at 2022-06-26 02:50:14.565400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:50:25.048501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


# Test Pub/Sub pattern with pyzmq
import zmq
import time


pyzmq_version = zmq.pyzmq_version()
zmq_version = zmq.zmq_version()
print("pyzmq version {0}, libzmq version {1}".format(pyzmq_version, zmq_version))

# Mangled unique address
# context = zmq.Context(1)

# context = zmq.Context.instance()
context = zmq.Context.instance()
print("Context created")

# Socket to talk to server
print("Connecting to hello world server...")
socket = context.socket(zmq.PUB)
print("Socket initialized")
# socket.setsockopt(zm

# Generated at 2022-06-26 02:50:32.208719
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:50:34.982085
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


# Return an iterator of all of the objects in a given object's hierarchy

# Generated at 2022-06-26 02:50:46.836143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    # noinspection PyUnresolvedReferences
    assert isinstance("", PyInfo.string_types)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    # noinspection PyUnresolvedReferences
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance

# Generated at 2022-06-26 02:50:54.109577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo

    if pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.maxsize > 0
    else:  # PY2
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)


test_PyInfo()

# Generated at 2022-06-26 02:51:01.053380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-26 02:51:07.130051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert type('1') in PyInfo.string_types
    assert type(u'1') == PyInfo.text_type
    assert type(b'1') == PyInfo.binary_type
    assert type(1) in PyInfo.integer_types
    assert type(type) in PyInfo.class_types
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:23.466311
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.text_type)
        assert not isinstance("abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance("abc", PyInfo.binary_type)
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(u"abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.string_types)

# Generated at 2022-06-26 02:51:27.920658
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 + PyInfo.PY2 == 1
    assert PyInfo.PY2 + len(PyInfo.string_types) == 2
    assert (PyInfo.PY3 + PyInfo.maxsize) == 4
    assert PyInfo.PY3 + PyInfo.binary_type == b''
    assert (PyInfo.PY2 + str) == b''



# Generated at 2022-06-26 02:51:28.965130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()



# Generated at 2022-06-26 02:51:32.834554
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert(pyinfo.PY2 == (sys.version_info[0] == 2))
    assert(pyinfo.PY3 == (sys.version_info[0] == 3))
    assert(pyinfo.maxsize == sys.maxsize)

# Generated at 2022-06-26 02:51:43.679592
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=too-many-statements, too-many-branches, pointless-statement
    import math
    from .  import pyinfo

    # test is_Py2
    assert pyinfo.is_py2() == PyInfo.PY2

    # test is_Py3
    assert pyinfo.is_py3() == PyInfo.PY3

    # test is_string
    assert pyinfo.is_string("abc")
    assert not pyinfo.is_string(123)

    # test is_text
    assert pyinfo.is_text("abc")
    assert pyinfo.is_text(u"abc")
    assert not pyinfo.is_text(123)

    # test is_binary
    assert pyinfo.is_binary(b"abc")

# Generated at 2022-06-26 02:51:52.942931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize in (2147483647, 9223372036854775807)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2


# Generated at 2022-06-26 02:51:56.329850
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Since this is just a class for storing information about the Python
    # version, the unit test is just a test that the constructor actually ran.
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-26 02:52:02.059246
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:52:10.292335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo().PY2
        assert not PyInfo().PY3
        assert PyInfo().string_types == (basestring,)
        assert PyInfo().text_type == unicode
        assert PyInfo().binary_type == str
        assert PyInfo().integer_types == (int, long)
    else:
        assert not PyInfo().PY2
        assert PyInfo().PY3
        assert PyInfo().string_types == (str,)
        assert PyInfo().text_type == str
        assert PyInfo().binary_type == bytes
        assert PyInfo().integer_types == (int,)

# Generated at 2022-06-26 02:52:15.723216
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int or type(PyInfo.maxsize) == long

# Generated at 2022-06-26 02:52:35.062774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    if PyInfo.PY2:
        assert obj.string_types == (basestring,)
        assert obj.text_type == unicode
        assert obj.binary_type == str
        assert obj.integer_types == (int, long)
        assert obj.class_types == (type, types.ClassType)

        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert obj.maxsize == int((1 << 31) - 1)
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31


# Generated at 2022-06-26 02:52:41.471203
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Type test for PyInfo.PY2
    assert isinstance(PyInfo.PY2, bool)
    # Type test for PyInfo.PY3
    assert isinstance(PyInfo.PY3, bool)
    if PyInfo.PY3:
        # Type test for PyInfo.string_types
        assert isinstance(PyInfo.string_types, tuple)
        # Type test for PyInfo.string_types[0]
        assert isinstance(PyInfo.string_types[0], type)
        # Type test for PyInfo.text_type
        assert isinstance(PyInfo.text_type, type)
        # Type test for PyInfo.binary_type
        assert isinstance(PyInfo.binary_type, type)
        # Type test for PyInfo.integer_types

# Generated at 2022-06-26 02:52:46.502289
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type == str and PyInfo.binary_type == bytes
    assert PyInfo.maxsize == 2 ** 63 - 1


__all__ = "PyInfo", "test_PyInfo"

# Generated at 2022-06-26 02:52:48.391260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

# Generated at 2022-06-26 02:52:52.483047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert(pi.PY2 or pi.PY3)
    assert(pi.maxsize > 0)



# Generated at 2022-06-26 02:52:59.258942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo().PY2) is bool
    assert type(PyInfo().PY3) is bool
    assert isinstance('', PyInfo().string_types)
    assert isinstance('', PyInfo().text_type)
    assert isinstance(b'', PyInfo().binary_type)
    assert type(1) in PyInfo().integer_types
    assert type(1) in PyInfo().integer_types
    assert type(type('')) in PyInfo().class_types
    assert isinstance(PyInfo().maxsize, int)

# Generated at 2022-06-26 02:53:07.578154
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(b"bytes", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert issubclass(str, PyInfo.string_types[0])
    assert issubclass(str, PyInfo.text_type)
    assert isinstance(str, PyInfo.class_types)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-26 02:53:16.987738
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize > 0
    if PyInfo.maxsize > (1 << 32):
        assert PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(b'bytes', PyInfo.string_types)
    else:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)

# Generated at 2022-06-26 02:53:25.501723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert PyInfo.PY3 or PyInfo.PY2
    if PyInfo.PY3:
        assert not PyInfo.PY2
        assert (1 << 31) - 1 <= PyInfo.maxsize <= 1 << 63 - 1
    else:
        assert not PyInfo.PY3
        assert (1 << 31) - 1 <= PyInfo.maxsize <= 1 << 63 - 1


# jinja2/sandbox.py
# Copyright (C) 2008-2012 Armin Ronacher and contributors.
#
# Some rights reserved.
#
# Redistribution and use in source and binary forms

# Generated at 2022-06-26 02:53:34.339589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    pyinfo = PyInfo()

    # Test that PyInfo.PY2 and PyInfo.PY3 are correct
    assert (
        pyinfo.PY2,
        pyinfo.PY3,
    ) == (
        sys.version_info[0] == 2,
        sys.version_info[0] == 3,
    )

    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)

        assert pyinfo.maxsize > 0

    else:  # PY3
        assert pyinfo.string_

# Generated at 2022-06-26 02:54:02.454282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test(assert_expression):
        try:
            assert assert_expression
        except AssertionError:
            traceback.print_exc()
            return False
        else:
            return True

    # PY2=True
    assert test(PyInfo.PY2 == True)
    assert test(PyInfo.PY3 == False)
    assert test(PyInfo.string_types == (basestring,))
    assert test(PyInfo.text_type == unicode)
    assert test(PyInfo.binary_type == str)
    assert test(PyInfo.integer_types == (int, long))
    assert test(PyInfo.class_types == (type, types.ClassType))

    # PY3=True
    PyInfo.PY2 = False
    PyInfo.PY3 = True
    assert test

# Generated at 2022-06-26 02:54:08.498866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-26 02:54:12.798494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('s', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(True, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__, '--color=no'])

# Generated at 2022-06-26 02:54:22.887155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)

        if sys.platform.startswith("java"):
            assert pyinfo.maxsize == int((1 << 31) - 1)
        else:
            try:
                len(X())
            except OverflowError:
                assert pyinfo.maxsize == int((1 << 31) - 1)
            else:
                assert pyinfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-26 02:54:24.857699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-26 02:54:27.708956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:54:30.301489
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-26 02:54:34.447275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-26 02:54:42.200211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == (int(2) == int(sys.version_info[0]))
    assert py_info.PY3 == (int(3) == int(sys.version_info[0]))
    if not py_info.PY3:
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
        assert py_info.integer_types == (int, long)
    assert not (py_info.PY2 and py_info.PY3)


binary_type = PyInfo.binary_type
text_type = PyInfo.text_type
string_types = PyInfo.string_types
integer_types = PyInfo.integer_types

# Generated at 2022-06-26 02:54:49.275340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    # Test PY2 and PY3
    if sys.version_info.major == 2:
        print(info.PY2)
        print(info.string_types)

    elif sys.version_info.major == 3:
        print(info.PY3)
        print(info.string_types)


test_PyInfo()

# Generated at 2022-06-26 02:55:39.118254
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test Python version
    assert PyInfo.PY3 is not PyInfo.PY2

    # Test string types
    if PyInfo.PY3:
        assert 'a' in PyInfo.string_types
        assert u'a' in PyInfo.string_types
        assert b'a' not in PyInfo.string_types
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
    else:
        assert 'a' in PyInfo.string_types
        assert u'a' in PyInfo.string_types
        assert b'a' not in PyInfo.string_types
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str

    # Test integer types
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:55:42.253434
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # It's class, no need for unit test
    pass


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:51.400213
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Max size of integer
    print(PyInfo.maxsize)
    # String type
    print(isinstance("i am a string", PyInfo.string_types))
    # Text type
    print(isinstance("i am a string", PyInfo.text_type))
    # Binary type
    print(isinstance(b"i am a string", PyInfo.binary_type))
    # Int type
    print(isinstance(1, PyInfo.integer_types))
    # Class type
    print(isinstance(PyInfo, PyInfo.class_types))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:02.736615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(0.0, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)


# Generated at 2022-06-26 02:56:13.170565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', str)
        assert not isinstance('', basestring)
        assert isinstance(b'', bytes)
        assert not isinstance(b'', str)
        assert isinstance(4, int)
        assert not isinstance(4, long)
        assert not isinstance(4, (int, long))
        assert isinstance(type, type)
        assert not isinstance(type, types.ClassType)
    else:  # PY2
        assert not isinstance('', str)
        assert isinstance('', basestring)
        assert not isinstance(b'', bytes)
        assert isinstance(b'', str)
        assert not isinstance(4, int)
        assert isinstance(4, long)
        assert isinstance(4, (int, long))

# Generated at 2022-06-26 02:56:23.497619
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert issubclass(PyInfo.string_types, basestring)
        assert issubclass(PyInfo.text_type, unicode)
        assert issubclass(PyInfo.binary_type, str)
        assert issubclass(PyInfo.integer_types, (int, long))
        assert issubclass(PyInfo.class_types, (type, types.ClassType))
    elif PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.text_type)
        assert isinstance(b'123', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:32.663169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

        assert isinstance(int, PyInfo.class_types)
    else:  # PY2
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-26 02:56:39.867751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:56:47.693674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:55.280650
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("1", PyInfo.string_types)
        assert isinstance(u"1", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert not isinstance(1, PyInfo.class_types)
    else:
        assert isinstance("1", PyInfo.string_types)
        assert not isinstance(u"1", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.class_types)
        assert not isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:58:30.196442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-26 02:58:39.802288
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_raises
    from nose.tools import assert_true, assert_false
    from nose.tools import assert_equal, assert_not_equal

    pyinfo = PyInfo()
    assert_equal(pyinfo.PY2, False)

    assert_true(isinstance('123', pyinfo.string_types))
    assert_false(isinstance(123, pyinfo.string_types))

    assert_true(isinstance(123, pyinfo.integer_types))
    assert_true(isinstance(2**32, pyinfo.integer_types))
    assert_false(isinstance('123', pyinfo.integer_types))

    assert_true(isinstance(type(3), pyinfo.class_types))

# Generated at 2022-06-26 02:58:50.621857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert type(sys.maxsize) == int
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
    else:  # PY2
        assert PyInfo.maxsize == 2147483647 if sys.platform.startswith(
            "java"
        ) else 9223372036854775807
        assert PyInfo.string

# Generated at 2022-06-26 02:58:59.175758
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert type(pyinfo.string_types) is type
    assert type(pyinfo.text_type) is type
    assert type(pyinfo.binary_type) is type
    assert type(pyinfo.integer_types) is type
    assert type(pyinfo.class_types) is type
    assert type(pyinfo.maxsize) is int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:59:05.343025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_true(x):
        assert x

    assert_true(PyInfo.PY2 is not PyInfo.PY3)
    assert_true(isinstance("", PyInfo.string_types))
    assert_true(isinstance(u"", PyInfo.string_types))
    assert_true(isinstance(b"", PyInfo.binary_type))
    assert_true(isinstance(1, PyInfo.integer_types))

# Generated at 2022-06-26 02:59:10.890904
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # The assertion that follows is a compilation check.
    # The left side of the `or` is for Python 2, the right for Python 3
    assert PyInfo.PY2 or PyInfo.PY3, "either PY2 or PY3 must be True"

