

# Generated at 2022-06-26 02:49:19.024983
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print ("Test PyInfo constructor")
    py_info_0 = PyInfo()
    assert py_info_0 is not None

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:21.104863
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert isinstance(x, PyInfo)


# Generated at 2022-06-26 02:49:31.716383
# Unit test for constructor of class PyInfo
def test_PyInfo():

    obj = PyInfo()
    assert isinstance(obj, PyInfo)

    assert obj.PY2 == True or obj.PY2 == False
    assert obj.PY3 == True or obj.PY3 == False

    if obj.PY2:
        assert isinstance(obj.string_types, tuple)
        assert isinstance(obj.string_types[0], type)
        assert isinstance(obj.text_type, type)
        assert obj.binary_type == str
        assert isinstance(obj.integer_types, tuple)
        assert isinstance(obj.integer_types[0], type)
        assert isinstance(obj.class_types, tuple)
        assert isinstance(obj.class_types[0], type)
        assert isinstance(obj.maxsize, long)


# Generated at 2022-06-26 02:49:33.796818
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY3 == True, "Invalid constructor of class PyInfo"
    assert PyInfo().PY2 == False, "Invalid constructor of class PyInfo"


# Generated at 2022-06-26 02:49:34.608386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:49:40.677656
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # Check the value of attribute PY2
    assert py_info.PY2 == True
    # Check the value of attribute PY3
    assert py_info.PY3 == False
    # Check the value of attribute string_types
    assert py_info.string_types == (basestring,)
    # Check the value of attribute text_type
    assert py_info.text_type == unicode
    # Check the value of attribute binary_type
    assert py_info.binary_type == str
    # Check the value of attribute integer_types
    assert py_info.integer_types == (int, long)
    # Check the value of attribute class_types
    assert py_info.class_types == (type, types.ClassType)
    # Check the value of attribute maxsize
    assert py

# Generated at 2022-06-26 02:49:46.644170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    methods_0 = dir(PyInfo)
    assert "PY2" in methods_0
    assert "PY3" in methods_0
    assert "string_types" in methods_0
    assert "text_type" in methods_0
    assert "binary_type" in methods_0
    assert "integer_types" in methods_0
    assert "class_types" in methods_0
    assert "maxsize" in methods_0
    test_case_0()

# Generated at 2022-06-26 02:49:48.724676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info, PyInfo)

# Generated at 2022-06-26 02:49:50.728931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0 != None
    assert py_info_0.PY2 == False

# Generated at 2022-06-26 02:50:01.425064
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Create instance of class PyInfo
    py_info_0= PyInfo()
    # Assert if the python version is 2.7
    assert py_info_0.PY2 == True
    # Assert if the python version is 2.7
    assert py_info_0.PY3 == False
    # Assert if the python string type is basestring
    assert py_info_0.string_types == (basestring, )
    # Assert if the python unicode type is unicode
    assert py_info_0.text_type == unicode
    # Assert if the python binary type is str
    assert py_info_0.binary_type == str
    # Assert if the python integer type is int, long
    assert py_info_0.integer_types == (int, long)
    # Assert if

# Generated at 2022-06-26 02:50:07.755300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:13.523911
# Unit test for constructor of class PyInfo

# Generated at 2022-06-26 02:50:15.223966
# Unit test for constructor of class PyInfo
def test_PyInfo():

    py_info_0 = PyInfo()




# Generated at 2022-06-26 02:50:23.669674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY2 == True or py_info.PY3 == True 
    if py_info.PY2:
        assert py_info.text_type == unicode
        assert py_info.string_types == tuple(basestring)
        assert py_info.integer_types == tuple((int, long))
    else:
        assert py_info.text_type == str
        assert py_info.string_types == tuple((str))
        assert py_info.integer_types == tuple((int))
    
    assert py_info.maxsize == sys.maxsize

test_PyInfo()

# Generated at 2022-06-26 02:50:25.807775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_2 = PyInfo()
    assert(isinstance(py_info_2, PyInfo))
    # test constructor arguments


# Generated at 2022-06-26 02:50:31.763954
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    assert py_info.maxsize == sys.maxsize
    assert py_info.integer_types == (int, long) == (int, long)
    assert py_info.string_types == (str, unicode) == (str, unicode)


# Generated at 2022-06-26 02:50:33.933492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:36.442346
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

if __name__ == "__main__":
    test_PyInfo()
    print("Test finished")

# Generated at 2022-06-26 02:50:38.733461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info_0 = PyInfo()
    except Exception as e:
        print(e)


# Generated at 2022-06-26 02:50:43.765503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

"""
"""

# Generated at 2022-06-26 02:51:05.360607
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for Constructor
    py_info_0 = PyInfo()

    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)

    assert py_info_0.maxsize == 2147483647


# class PyInfo
# |  Methods defined here:
# |
# |  __init__(self)
# |
# |  __module__ = 'xdev_app_server.utils.py_info

# Generated at 2022-06-26 02:51:07.203713
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for i in range(100):
        py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:08.884431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()

if __name__ == '__main__':
    test_case_0()
    test_PyInfo()

# Generated at 2022-06-26 02:51:11.459373
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:13.400509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

	

# Generated at 2022-06-26 02:51:15.878506
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:16.970325
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()



# Generated at 2022-06-26 02:51:20.939067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    py_info_2 = PyInfo()
    # Constructor could be called twice
    assert py_info_1 is not None
    assert py_info_2 is not None
    return py_info_1



# Generated at 2022-06-26 02:51:21.886147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info is not None


# Generated at 2022-06-26 02:51:24.712542
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_0 = PyInfo()
    py_info_0 = PyInfo()
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:44.160549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:51:47.573434
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Start testing constructor of class PyInfo')
    py_info_0 = PyInfo()
    assert py_info_0.PY2 is True
    assert py_info_0.PY3 is False
    pass


# Generated at 2022-06-26 02:51:55.645225
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # Assertion: py_info.__class__ == PyInfo
    assert py_info.__class__ == PyInfo
    # Assertion: py_info.PY2 == True
    assert py_info.PY2 == True
    # Assertion: py_info.PY3 == False)
    assert py_info.PY3 == False
    # Assertion: py_info.string_types == (basestring,)
    assert py_info.string_types == (basestring,)
    # Assertion: py_info.text_type == unicode
    assert py_info.text_type == unicode
    # Assertion: py_info.binary_type == str
    assert py_info.binary_type == str
    # Assertion: py_info

# Generated at 2022-06-26 02:51:56.730143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:52:07.899676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Start to test PyInfo")
    print("Test if PyInfo.PY2 is True")
    assert PyInfo.PY2 == True
    print("Test if PyInfo.PY3 is False")
    assert PyInfo.PY3 == False
    print("Test if PyInfo.maxsize = sys.maxsize")
    assert PyInfo.maxsize == sys.maxsize
    print("Test if PyInfo.string_types is either basestring or unicode")
    assert PyInfo.string_types == (basestring,),(unicode,)
    print("Test if PyInfo.text_type is unicode")
    assert PyInfo.text_type == unicode
    print("Test if PyInfo.binary_type is str")
    assert PyInfo.binary_type == str

# Generated at 2022-06-26 02:52:09.313432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:10.236505
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    return py_info_0


# Generated at 2022-06-26 02:52:14.345189
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY3, "test"
    assert py_info_0.PY2, "test"
    assert py_info_0.string_types[0], "test"
    assert py_info_0.text_type, "test"
    assert py_info_0.binary_type, "test"
    assert py_info_0.integer_types[0], "test"
    assert py_info_0.maxsize, "test"

# Generated at 2022-06-26 02:52:15.538684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("test_PyInfo")
    test_case_0()


# Generated at 2022-06-26 02:52:17.599572
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("\n*** PyInfo tests ***")
    test_case_0()


# Run the PyInfo unit tests
test_PyInfo()

# Generated at 2022-06-26 02:53:03.550304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = object()
    def check_type(x, type_class, name):
        if not isinstance(x, type_class):
            raise TypeError("{0} is not of type {1}".format(x, type_class))
    # test constructor
    check_type(py_info_0, object, "py_info_0")
    # test class type
    check_type(PyInfo, type, "PyInfo")

    # test instance attribute
    check_type(py_info_0.PY2, bool, "py_info_0.PY2")
    check_type(py_info_0.PY3, bool, "py_info_0.PY3")


# Generated at 2022-06-26 02:53:04.819171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert isinstance(py_info_1, PyInfo)


# Generated at 2022-06-26 02:53:07.541939
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3



# Generated at 2022-06-26 02:53:09.738880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo, object)


# Generated at 2022-06-26 02:53:13.245914
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # init class
    test_case_0()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:21.464527
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == False)
    assert(PyInfo.PY3 == True)
    assert(PyInfo().PY2 == False)
    assert(PyInfo().PY3 == True)
    assert(PyInfo.integer_types == (int,))
    assert(PyInfo.maxsize == 9223372036854775807)
    assert(PyInfo.binary_type == bytes)
    assert(PyInfo.class_types == (type,))
    assert(PyInfo.string_types == (str,))
    assert(PyInfo.text_type == str)
    assert(PyInfo().integer_types == (int,))
    assert(PyInfo().maxsize == 9223372036854775807)
    assert(PyInfo().binary_type == bytes)

# Generated at 2022-06-26 02:53:24.935953
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("test_PyInfo")
    test_case_0()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:27.246167
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:30.514770
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:53:39.908488
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    # Assert #1 for type of PY2
    assert isinstance(py_info_0.PY2, bool)
    print("Test #1 passed")

    # Assert #2 for type of PY3
    assert isinstance(py_info_0.PY3, bool)
    print("Test #2 passed")

    # Assert #3 for type of maxsize
    assert isinstance(py_info_0.maxsize, int)
    print("Test #3 passed")

    # Assert #4 for type of string_types
    if py_info_0.PY2:
        assert isinstance(py_info_0.string_types, types.TupleType)
    else:
        assert isinstance(py_info_0.string_types, tuple)

# Generated at 2022-06-26 02:54:22.711549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is False
    assert info.PY3 is True
    assert info.string_types == str
    assert info.text_type == str
    assert info.binary_type == bytes
    assert info.integer_types == int
    assert info.class_types == type
    assert info.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:54:27.921659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:33.227721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == sys.maxsize


if PyInfo.PY3:
    def is_py3x():
        return True

    def is_py2x():
        return False

    def is_pyxx():
        return True


else:
    def is_py2x():
        return True

    def is_py3x():
        return False

    def is_pyxx():
        return True



# Generated at 2022-06-26 02:54:39.834774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (basestring, )
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int, )
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type, )

# Generated at 2022-06-26 02:54:47.980899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for constructor of class PyInfo."""
    # Instance of PyInfo
    py_info = PyInfo()
    # Test if py_info is an instance of class PyInfo
    assert isinstance(py_info, PyInfo)


if __name__ == "__main__":
    # Unit test
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-26 02:54:52.899178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type("") in PyInfo.string_types
    assert type(u"") in PyInfo.string_types
    assert type(b"") in PyInfo.binary_type
    assert type(PyInfo.maxsize) in PyInfo.integer_types
    assert type(int) in PyInfo.class_types
    if PyInfo.PY3:
        assert type(str) == PyInfo.text_type
        assert type(bytes) == PyInfo.binary_type
    else:
        assert type(unicode) == PyInfo.text_type
        assert type(str) == PyInfo.binary_type

# Generated at 2022-06-26 02:55:00.529982
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:55:03.024257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

# Generated at 2022-06-26 02:55:13.452903
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abcd", PyInfo.string_types)
    assert isinstance(PyInfo.maxsize, int)
    if PyInfo.PY2:
        assert isinstance(u"abcd", PyInfo.text_type)
    else:
        assert isinstance("abcd", PyInfo.text_type)
    assert isinstance(b"abcd", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(object, PyInfo.class_types)
    else:
        assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:21.430055
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:42.266190
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo

    import sys

    for name in """PY2 PY3 string_types text_type binary_type integer_types
    class_types maxsize""".split():
        assert hasattr(info, name), (name, info)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:45.727058
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for k, v in list(vars(PyInfo).items()):
        if k == k.upper():
            assert v



# Generated at 2022-06-26 02:56:49.823630
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> import sys
    >>> assert PyInfo.PY2 == (sys.version_info[0] == 2)
    >>> assert PyInfo.PY3 == (sys.version_info[0] == 3)
    >>> assert PyInfo.string_types
    >>> assert PyInfo.text_type
    >>> assert PyInfo.binary_type
    >>> assert PyInfo.integer_types
    >>> assert PyInfo.class_types
    >>> assert PyInfo.maxsize
    """


# Check for a Python interpreter too old for the installed setuptools
# package, as per "packaging" PEP 426.

# Generated at 2022-06-26 02:56:55.620764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(isinstance(PyInfo.PY2, bool) is True)
    assert(isinstance(PyInfo.PY3, bool) is True)

    assert(isinstance(PyInfo.string_types, tuple) is True)
    for s in PyInfo.string_types:
        assert(isinstance(s, type) is True)

    assert(isinstance(PyInfo.text_type, type) is True)
    assert(isinstance(PyInfo.binary_type, type) is True)

    assert(isinstance(PyInfo.integer_types, tuple) is True)
    for i in PyInfo.integer_types:
        assert(isinstance(i, type) is True)

    assert(isinstance(PyInfo.class_types, tuple) is True)

# Generated at 2022-06-26 02:57:02.900452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import pytest
    import sys

    pytest.main(["-v", "--tb=long", "{}".format(sys.argv[0])])

# Generated at 2022-06-26 02:57:13.593584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if platform.python_version() == "2.7.10":
        assert PyInfo.PY2 == True, "PY2 must be True."
        assert PyInfo.PY3 == False, "PY3 must be False."
        assert type(PyInfo.string_types) == tuple, "The type of string_types must be tuple."
        assert PyInfo.text_type == str, "text_type must be str."
        assert PyInfo.binary_type == str, "binary_type must be str."
        assert type(PyInfo.integer_types) == tuple, "The type of integer_types must be tuple."
        assert type(PyInfo.class_types) == tuple, "The type of class_types must be tuple."

# Generated at 2022-06-26 02:57:25.606938
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types
    maxsize = PyInfo.maxsize

    # Basic attributes
    assert py2 ^ py3
    assert isinstance("", text_type)
    assert isinstance(b"", binary_type)
    assert isinstance(0, integer_types)
    assert isinstance(type, class_types)
    assert isinstance(maxsize, integer_types)
    assert maxsize > 0


if __name__ == '__main__':
    nose.runmodule()

# Generated at 2022-06-26 02:57:30.376551
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Testing to see if we can instantiate an object
    try:
        PyInfo()
    except NameError:
        pass
    except AttributeError:
        pass
    except TypeError:
        pass

# Generated at 2022-06-26 02:57:34.501899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.string_types is str
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types is int
    assert PyInfo.class_types is type
    assert PyInfo.maxsize > 2 ** 30



# Generated at 2022-06-26 02:57:46.384176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(b'', bytes)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.binary_type)