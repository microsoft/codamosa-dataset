

# Generated at 2022-06-26 02:49:21.066871
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()



if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:23.193372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:24.343076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()





# Generated at 2022-06-26 02:49:25.977649
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()




# Generated at 2022-06-26 02:49:27.316512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info


# Generated at 2022-06-26 02:49:29.665669
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert_equals("<class 'misc.PyInfo'>", PyInfo().__class__.__name__)
    print('Tested PyInfo class')


# Generated at 2022-06-26 02:49:37.750474
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (PyInfo.PY2 == False)
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.PY2 == sys.version_info[0] == 2

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-26 02:49:48.410455
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    # assert PyInfo.maxsize == 170141183460469231731687303715884105727
    assert py_info_0.PY2 == PyInfo.PY2
    assert py_info_0.PY3 == PyInfo.PY3
    assert py_info_0.string_types == PyInfo.string_types
    assert py_info_0.text_type == PyInfo.text_type

# Generated at 2022-06-26 02:49:49.735580
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()



# Generated at 2022-06-26 02:49:51.050281
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing class constructor")
    test_case_0()


test_PyInfo()

# Generated at 2022-06-26 02:50:01.108617
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info.PY2, bool)
    assert isinstance(py_info.PY3, bool)
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-26 02:50:11.684385
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("x", PyInfo.string_types)
    assert isinstance("x", PyInfo.text_type)
    assert not isinstance("x", PyInfo.binary_type)

    assert isinstance("x", text_type)
    assert PyInfo.PY2 or isinstance("x", str)

    assert isinstance(b"x", PyInfo.string_types)
    assert isinstance(b"x", PyInfo.binary_type)
    assert not isinstance(b"x", PyInfo.text_type)

    assert isinstance(b"x", bytes)
    assert PyInfo.PY3 or isinstance(b"x", str)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, int)

# Generated at 2022-06-26 02:50:16.512700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from ctypes import sizeof, c_int, c_int64
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.maxsize <= ((1 << 63) - 1)
    assert PyInfo.maxsize <= ((1 << 31) - 1)
    assert sizeof(c_int) == 4
    assert sizeof(c_int64) == 8

# Generated at 2022-06-26 02:50:18.557571
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    for attr in (
        "string_types",
        "text_type",
        "binary_type",
        "integer_types",
        "class_types",
    ):
        assert hasattr(PyInfo, attr)
        assert isinstance(getattr(PyInfo, attr), tuple)


test_PyInfo()

# Generated at 2022-06-26 02:50:20.166263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-26 02:50:28.472476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-26 02:50:31.962450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2, PyInfo.PY3
    (True, False)
    >>> isinstance(1, PyInfo.integer_types)
    True
    >>> isinstance(1, PyInfo.string_types)
    False
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:50:38.194007
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-26 02:50:53.020565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int


# A dict subclass that remembers the order entries were added.
if hasattr(dict, "fromkeys"):  # New in version 2.2.
    class OrderedDict(dict):

        def __init__(self, items=None):
            dict.__init__(self)
            if items is None:
                items = []
            self.__keys = []

# Generated at 2022-06-26 02:51:05.360794
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("foo", PyInfo.string_types)
    assert not isinstance(u"foo", PyInfo.string_types)
    assert not isinstance(b"foo", PyInfo.string_types)

    assert isinstance(u"foo", PyInfo.text_type)
    assert not isinstance("foo", PyInfo.text_type)
    assert not isinstance(b"foo", PyInfo.text_type)

    assert isinstance(b"foo", PyInfo.binary_type)
    assert not isinstance(u"foo", PyInfo.binary_type)
    assert not isinstance("foo", PyInfo.binary_type)



# Generated at 2022-06-26 02:51:20.313075
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.text_type)
    assert isinstance(b'str', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(set, PyInfo.class_types)
    assert isinstance(set, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:51:21.945326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()
    assert pyi.PY2 is True or pyi.PY3 is True

# Generated at 2022-06-26 02:51:28.741378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    # assert not hasattr(PyInfo, "maxint")
    assert isinstance(PyInfo.maxsize, int)
    assert len(repr(PyInfo.maxsize)) > 4
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize == 2 ** 63 - 1 or PyInfo.maxsize == 2 ** 31 - 1

# Generated at 2022-06-26 02:51:40.094508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type  == str
        assert PyInfo.binary_type  == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type  == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:51:43.495202
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type(PyInfo.text_type()) == str
        assert type(PyInfo.binary_type()) == bytes
    else:
        assert type(PyInfo.text_type()) == unicode
        assert type(PyInfo.binary_type()) == str

# Generated at 2022-06-26 02:51:46.039013
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-26 02:51:52.866104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance("a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(22, PyInfo.integer_types)
    assert isinstance(type(None), PyInfo.class_types)
    if PyInfo.PY2:
        assert PyInfo.maxsize == 9223372036854775807
    assert PyInfo.maxsize >= 2 ** 31 - 1



# Generated at 2022-06-26 02:52:04.214339
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (
        sys.version_info[0] == 2
    ), "PyInfo.PY2 is not equal to the python version"
    assert PyInfo.PY3 == (
        sys.version_info[0] == 3
    ), "PyInfo.PY3 is not equal to the python version"

    if PyInfo.PY3:
        assert PyInfo.binary_type == bytes, (
            "PyInfo.binary_type is not equal to the python bytes type"
        )
        assert PyInfo.text_type == str, (
            "PyInfo.text_type is not equal to the python str type"
        )
        assert PyInfo.integer_types == (int,), (
            "PyInfo.integer_types is not equal to the python int type"
        )
        assert Py

# Generated at 2022-06-26 02:52:09.696000
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:15.656130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3


# Get the real path of python
PYTHON_DIRECTORY = os.path.dirname(os.path.realpath(__file__))
# Get Root Directory
ROOT_DIRECTORY = os.path.join(PYTHON_DIRECTORY, '../')
# Get Directory of modules
MODULE_DIRECTORY = os.path.join(ROOT_DIRECTORY, 'modules')
# Get Directory of data
DATA_DIRECTORY = os.path.join(ROOT_DIRECTORY, 'data')
# Get Directory of result
RESULT_DIRECTORY = os.path.join(ROOT_DIRECTORY, 'result')
# Get

# Generated at 2022-06-26 02:52:26.788155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass
    # assert PyInfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-26 02:52:36.526668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if (PyInfo.PY2 is True or PyInfo.PY3 is True) is False:
        raise AssertionError("PyInfo.PY2 or PyInfo.PY3 is not True.")
    if PyInfo.string_types is None:
        raise AssertionError("PyInfo.string_types is None.")
    if PyInfo.text_type is None:
        raise AssertionError("PyInfo.text_type is None.")
    if PyInfo.binary_type is None:
        raise AssertionError("PyInfo.binary_type is None.")
    if PyInfo.integer_types is None:
        raise AssertionError("PyInfo.integer_types is None.")
    if PyInfo.class_types is None:
        raise AssertionError("PyInfo.class_types is None.")

# Generated at 2022-06-26 02:52:41.191277
# Unit test for constructor of class PyInfo

# Generated at 2022-06-26 02:52:45.568360
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2

    assert isinstance(2, PyInfo.integer_types)
    assert not isinstance(2.0, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:49.106281
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert not isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:57.714742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:53:02.304327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3


# [ref] http://stackoverflow.com/questions/2246910/how-to-determine-current-script-encoding

# Generated at 2022-06-26 02:53:11.065519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    # Python 2
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert len(PyInfo.string_types) == 1
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0] == basestring

        assert isinstance(PyInfo.text_type, type)
        assert PyInfo.text_type == unicode

        assert isinstance(PyInfo.binary_type, type)
        assert PyInfo.binary_type == str

        assert isinstance(PyInfo.integer_types, tuple)
        assert len(PyInfo.integer_types) == 2

# Generated at 2022-06-26 02:53:18.544569
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from io import StringIO

    class NullIO(object):
        def write(self, s):
            pass

    if sys.version_info[0] == 2:
        sys.stdout = NullIO()
        sys.stdout = sys.__stdout__
    elif sys.version_info[0] == 3:
        sys.stdout = StringIO()
        print("Testing PyInfo.__init__()...")
        sys.stdout = sys.__stdout__

# Generated at 2022-06-26 02:53:25.648042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info is not None


if __name__ == '__main__':
    # test_PyInfo()
    py_info = PyInfo()

# Generated at 2022-06-26 02:53:48.744795
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:53:54.836905
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2



# Generated at 2022-06-26 02:54:03.228577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

        class A:
            pass

        assert isinstance(A, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:08.683896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3


# Check if unit test fails
if PyInfo.PY3 or not PyInfo.PY2:
    raise AssertionError("PyInfo.PY2 is not working correctly")

# Generated at 2022-06-26 02:54:10.542133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info2 = PyInfo()
    assert type(info2) == PyInfo



# Generated at 2022-06-26 02:54:19.588583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types is (basestring,)
    assert pyinfo.text_type is unicode
    assert pyinfo.binary_type is str
    assert pyinfo.integer_types is (int, long)
    assert pyinfo.class_types is (type, types.ClassType)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:54:29.231724
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        import builtins
    except ImportError:
        import __builtin__ as builtins

    assert issubclass(PyInfo.text_type, builtins.unicode)  # PY2
    assert PyInfo.text_type == str  # PY3
    assert PyInfo.binary_type == bytes
    assert PyInfo.string_types == str
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.integer_types == int
    assert PyInfo.maxsize > 1000000000

# Generated at 2022-06-26 02:54:37.723606
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("123", PyInfo.string_types)
    if not PyInfo.PY2:
        assert isinstance(b"123", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert str(type(123)) in ("<class 'int'>", "<type 'int'>")
    assert isinstance(type(123), PyInfo.class_types)

# Generated at 2022-06-26 02:54:40.096945
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == (1 << 63) - 1
    else:
        assert PyInfo.maxsize == (1 << 31) - 1



# Generated at 2022-06-26 02:54:51.511129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check types
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.integer_types[1], type)

    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize

# Generated at 2022-06-26 02:55:35.100503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        def setUp(self):
            pass

    unittest.main()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:42.446737
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple) and isinstance(
        PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple) and isinstance(
        PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple) and isinstance(
        PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:47.766174
# Unit test for constructor of class PyInfo
def test_PyInfo():

    if (PyInfo.PY2 and PyInfo.PY3) or (not PyInfo.PY2 and not PyInfo.PY3):
        raise AssertionError("Test failed: PyInfo is wrong")



# Generated at 2022-06-26 02:55:54.165082
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # __init__
    # check if attributes are assigned correctly
    info = PyInfo()
    assert info.PY2
    assert not info.PY3
    assert isinstance(info.string_types, tuple)
    assert info.string_types == (basestring,)
    assert isinstance(info.text_type, unicode)
    assert info.text_type == unicode
    assert isinstance(info.binary_type, str)
    assert info.binary_type == str
    assert isinstance(info.integer_types, tuple)
    assert info.integer_types == (int, long)
    assert isinstance(info.class_types, tuple)
    assert info.class_types == (type, types.ClassType)
    assert isinstance(info.maxsize, long)
    assert info.maxsize == 92233

# Generated at 2022-06-26 02:56:01.142228
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:12.829034
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Python version:", sys.version)
    print("Python PyInfo.PY2:", PyInfo.PY2)
    print("Python PyInfo.PY3:", PyInfo.PY3)
    print("Python PyInfo.string_types:", PyInfo.string_types)
    print("Python PyInfo.text_type:", PyInfo.text_type)
    print("Python PyInfo.binary_type:", PyInfo.binary_type)
    print("Python PyInfo.binary_type:", PyInfo.binary_type)
    print("Python PyInfo.integer_types:", PyInfo.integer_types)
    print("Python PyInfo.class_types:", PyInfo.class_types)
    print("Python PyInfo.maxsize:", PyInfo.maxsize)



# Generated at 2022-06-26 02:56:23.371692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        # Attempt to create an instance of class PyInfo
        pi = PyInfo()
    except:
        raise AssertionError("Failed to create instance of class PyInfo")

    # Check that attributes are set correctly
    if sys.version_info[0] == 3:
        assert pi.PY2 == False
        assert pi.PY3 == True
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)
    else:
        assert pi.PY2 == True
        assert pi.PY3 == False
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_

# Generated at 2022-06-26 02:56:32.999152
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert str in PyInfo.string_types

        assert isinstance(PyInfo.text_type, type)
        assert PyInfo.text_type == unicode

        assert isinstance(PyInfo.binary_type, type)
        assert PyInfo.binary_type == str

        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.integer_types[0], type)
        assert int in PyInfo.integer_types
        assert long in PyInfo.integer_types


# Generated at 2022-06-26 02:56:43.894376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        PyInfo().string_types

    py2 = PyInfo()
    py2.PY2 = True

    assert py2.PY2 is True
    py2.PY3 = False

    assert py2.PY3 is False
    py2.PY2 = False

    assert py2.PY2 is False
    py2.PY3 = True

    assert py2.PY3 is True
    assert py2.string_types[0] is types.StringType
    assert py2.text_type is types.UnicodeType
    assert py2.binary_type is types.StringType
    assert py2.integer_types[0] is types.IntType
    assert py2.integer_types[1] is types.LongType

# Generated at 2022-06-26 02:56:53.272541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType,)
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-26 02:58:38.586581
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal, assert_true, assert_false
    if PyInfo.PY2:
        assert_true(isinstance(u'', PyInfo.text_type))
        assert_false(isinstance(u'', PyInfo.binary_type))
    if PyInfo.PY3:
        assert_true(isinstance('', PyInfo.string_types))
        assert_true(isinstance('', PyInfo.text_type))
    else:
        assert_false(isinstance('', PyInfo.text_type))
        assert_true(isinstance('', PyInfo.binary_type))



# Generated at 2022-06-26 02:58:48.436387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("", PyInfo.string_types)  # noqa
    assert isinstance(u"", PyInfo.string_types)  # noqa
    assert isinstance(None, PyInfo.text_type.__class__)
    assert isinstance(None, PyInfo.binary_type.__class__)
    assert isinstance(None, PyInfo.integer_types.__class__)
    assert isinstance(None, PyInfo.class_types.__class__)
    assert isinstance(None, PyInfo.maxsize.__class__)

# Generated at 2022-06-26 02:58:52.009184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("It's Python2.")
    else:
        print("It's Python3.")

# Generated at 2022-06-26 02:58:58.120463
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    assert py2 ^ py3    # exactly one is true
    integer_types = PyInfo.integer_types
    assert isinstance(PyInfo.maxsize, integer_types)


# ======================= Primitive Type Conversion ==========================


# Generated at 2022-06-26 02:59:02.974632
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if not PyInfo.PY3:
        assert PyInfo.maxsize == ((1 << 31) - 1)

# Generated at 2022-06-26 02:59:07.510270
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:59:18.513589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if PyInfo.PY2:
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert PyInfo.integer_