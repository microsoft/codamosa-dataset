

# Generated at 2022-06-26 02:49:24.149915
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert True == py_info.PY2
    assert False == py_info.PY3
    assert (str, ) == py_info.string_types
    assert str == py_info.text_type
    assert str == py_info.binary_type
    assert (int, long) == py_info.integer_types
    assert (type, types.ClassType) == py_info.class_types
    assert (1 << 31) -1 == py_info.maxsize


test_case_0()

# Generated at 2022-06-26 02:49:26.560978
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Create an object of the PyInfo class
    py_info = PyInfo()

test_case_0()
test_PyInfo()

# Generated at 2022-06-26 02:49:27.636908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:49:29.236787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    print(py_info)

test_PyInfo()

# Generated at 2022-06-26 02:49:31.862189
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing constructor of class PyInfo")
    py_info_0 = PyInfo()
    assert py_info_0 is not None


test_case_0()
test_PyInfo()

# Generated at 2022-06-26 02:49:39.001772
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert isinstance(py_info_0, PyInfo)
    assert py_info_0.PY2 == sys.version_info[0] == 2
    assert py_info_0.PY3 == sys.version_info[0] == 3
    # Start of  "if"
    if py_info_0.PY3:
        assert py_info_0.string_types == str
        assert py_info_0.text_type == str
        assert py_info_0.binary_type == bytes
        assert py_info_0.integer_types == int
        assert py_info_0.class_types == type
        assert py_info_0.maxsize == sys.maxsize
    # End of "if"
    # Start of "else"

# Generated at 2022-06-26 02:49:41.615575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # assert
    print("py_info:")
    print(py_info.__dict__)

# Generated at 2022-06-26 02:49:43.330279
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


test_PyInfo()

# Generated at 2022-06-26 02:49:47.083577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if PyInfo create a PyInfo object
    py_info = PyInfo()

    # Check if the PyInfo object is of the appropriate type
    if type(py_info) is not object:
        raise TypeError('PyInfo is not a PyInfo object')


# Generated at 2022-06-26 02:49:48.512144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert test_case_0() == None



# Generated at 2022-06-26 02:49:54.737961
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:02.249934
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert py_info_1.PY2 == False
    assert py_info_1.PY3 == True
    assert py_info_1.string_types == (str,)
    assert py_info_1.text_type == str
    assert py_info_1.binary_type == bytes
    assert py_info_1.integer_types == (int,)
    assert py_info_1.class_types == type
    assert py_info_1.maxsize == (1 << 63) - 1

# Generated at 2022-06-26 02:50:07.710175
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    py_info.PY2
    py_info.PY3
    py_info.string_types
    py_info.text_type
    py_info.binary_type
    py_info.integer_types
    py_info.class_types
    py_info.maxsize

# Generated at 2022-06-26 02:50:09.913139
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.__class__.__bases__ == (object,)



# Generated at 2022-06-26 02:50:11.353169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Do nothing.
    return


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:12.818405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:17.669423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_0.binary_type
    py_info_0.integer_types
    py_info_0.class_types
    py_info_0.string_types
    py_info_0.text_type
    py_info_0.maxsize


# Generated at 2022-06-26 02:50:21.198454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


if __name__ == '__main__':
    print("<------------------Test of constructor of class PyInfo-------------------->")
    test_PyInfo()
    print("<------------------Test of constructor of class PyInfo-------------------->")

# Generated at 2022-06-26 02:50:31.065570
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # test py2
    sys.version_info = (2, 7, 10, 'final', 0)
    py_info = PyInfo()
    assert py_info.PY2 == True
    assert py_info.PY3 == False
    assert py_info.string_types == (basestring,)
    assert py_info.text_type == unicode
    assert py_info.integer_types == (int, long)
    assert py_info.class_types == (type, types.ClassType)
    assert py_info.maxsize == (1 << 31) - 1

    # test py3
    sys.version_info = (3, 6, 9, 'final', 0)
    py_info = PyInfo()
    assert py_info.PY2 == False
    assert py_info.PY3 == True


# Generated at 2022-06-26 02:50:33.525851
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()


# Generated at 2022-06-26 02:50:51.114299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("s", PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance("s", PyInfo.text_type)
        assert isinstance("s", PyInfo.binary_type)
    else:
        assert isinstance("s".decode("utf-8"), PyInfo.text_type)
        assert isinstance("s".encode("utf-8"), PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:50:55.405775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)

# Generated at 2022-06-26 02:51:00.559751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize



# Generated at 2022-06-26 02:51:11.268898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    assert type(PyInfo.maxsize) == int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:19.424644
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance('abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:24.178202
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:51:26.790442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-26 02:51:30.368570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from qtpy.QtWidgets import QApplication

    app = QApplication(sys.argv)
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type)
    print(PyInfo.maxsize)
    sys.exit(app.exec_())


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:40.048799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(b'bytes', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(classmethod, PyInfo.class_types)
    else:  # PY2
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(classmethod, PyInfo.class_types)

# Generated at 2022-06-26 02:51:49.411501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # The constructor of class PyInfo should be private
    with pytest.raises(TypeError):
        PyInfo()

    # Then, let's test if the static members are what we expect
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:52:05.432287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo
    assert info.PY2 or info.PY3
    if info.PY3:
        assert isinstance('', info.string_types)
        assert isinstance(b'', info.binary_type)
        assert isinstance(0, info.integer_types)
        assert isinstance(type, info.class_types)

# Generated at 2022-06-26 02:52:13.143029
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, "PY2 should be True"
    assert not PyInfo.PY3, "PY3 should be False"
    assert PyInfo.string_types[0] == basestring, \
        "PyInfo.string_types[0] should be basestring"
    assert PyInfo.text_type == unicode, "PyInfo.text_type should be unicode"
    assert PyInfo.binary_type == str, \
        "PyInfo.binary_type should be str"
    assert PyInfo.integer_types[0] == int, \
        "PyInfo.integer_types[0] should be int"
    assert PyInfo.integer_types[1] == long, \
        "PyInfo.integer_types[1] should be long"
    assert PyInfo.class_types[0]

# Generated at 2022-06-26 02:52:19.139111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 is not PyInfo.PY3)
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.string_types)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:29.913821
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance('abc', PyInfo.text_type)
    assert not isinstance(u'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert not isinstance('abc', PyInfo.binary_type)
    assert not isinstance(b'abc', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:32.550192
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Basic smoke test of constructor.
    PyInfo()
    # The class itself is tested by test_pyinfo.
    # Invoking the module as a script runs all of the tests.



# Generated at 2022-06-26 02:52:40.225664
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert issubclass(int, PyInfo.integer_types)
    assert issubclass(long, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(long, PyInfo.class_types)
    assert int(PyInfo.maxsize) >= 0
    assert int(PyInfo.maxsize) > 0
    print("Test of class PyInfo in module {} OK".format(__name__))



# Generated at 2022-06-26 02:52:44.634416
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    '''
    pass


# Generated at 2022-06-26 02:52:49.194693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


# print(test_PyInfo.__doc__)

# Generated at 2022-06-26 02:52:56.913159
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

    def f():
        pass

    assert isinstance(f, PyInfo.class_types)

    try:
        len([1] * PyInfo.maxsize)
    except OverflowError:
        pass

# Generated at 2022-06-26 02:53:09.195523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:53:37.587102
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert "unicode" in repr(PyInfo.text_type)
    assert "str" in repr(PyInfo.string_types)
    assert "basestring" not in repr(PyInfo.string_types)
    assert "int" in repr(PyInfo.integer_types)
    assert "long" in repr(PyInfo.integer_types)
    assert "bytes" in repr(PyInfo.binary_type)
    assert "str" in repr(PyInfo.binary_type)
    assert "type" in repr(PyInfo.class_types)
    assert "ClassType" in repr(PyInfo.class_types)
    assert "types" in repr(PyInfo.class_types)

# Generated at 2022-06-26 02:53:48.270221
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.maxsize == sys.maxsize

    assert PyInfo.PY3, PyInfo.PY2
    assert not PyInfo.PY2 or PyInfo.PY3
    assert not PyInfo.PY3 or PyInfo.PY2


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:53:54.906465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.class_types

# Generated at 2022-06-26 02:54:03.250592
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance('abc', PyInfo.text_type)
    assert not isinstance(u'abc', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert isinstance(b'abc', PyInfo.binary_type)
    assert not isinstance('abc', PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:07.929555
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Constructor of class PyInfo should execute without exception
    PyInfo()


# Local Variables: ***
# mode: python ***
# py-indent-offset: 4 ***
# End: ***

# Generated at 2022-06-26 02:54:12.204363
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types[0], str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types[0], int)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)
    return True

# Generated at 2022-06-26 02:54:22.686479
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        # check for string_type
        assert isinstance("hello", PyInfo.string_types)

        # check for class_types
        assert isinstance(int, PyInfo.class_types)

        # check for text_type
        assert isinstance("hello", PyInfo.text_type)

        # check for integer_types
        assert isinstance(1, PyInfo.integer_types)

        # check for maxsize
        assert PyInfo.maxsize == sys.maxsize

        # check for binary_type
        assert isinstance(b"hello", PyInfo.binary_type)
    else:
        # check for string_type
        assert isinstance("hello", PyInfo.string_types)

        # check for class_types
        assert isinstance(int, PyInfo.class_types)

        #

# Generated at 2022-06-26 02:54:29.942694
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    assert pyinfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:54:34.060549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-26 02:54:39.872804
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-26 02:55:20.223706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True



# Generated at 2022-06-26 02:55:29.554570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert (
        isinstance(b"a".decode("utf-8"), PyInfo.text_type)
    )  # Don't use isinstance(u"a", PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)


# Generated at 2022-06-26 02:55:40.208275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.maxsize) is int
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)

    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY3 != PyInfo.PY2

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, PyInfo.class_types)
    assert isinstance(PyInfo.binary_type, PyInfo.class_types)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:55:51.662941
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Foo(object):
        pass

    assert PyInfo.PY2 != PyInfo.PY3
    assert types.FunctionType in PyInfo.class_types
    assert Foo in PyInfo.class_types
    assert types.InstanceType not in PyInfo.class_types
    assert Foo() not in PyInfo.class_types

    assert isinstance("a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(u"a", PyInfo.text_type)
    assert not isinstance(b"a", PyInfo.text_type)
    assert not isinstance(u"a", PyInfo.binary_type)
    assert not isinstance("a", (PyInfo.text_type, PyInfo.binary_type))


# Generated at 2022-06-26 02:56:01.600721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("string", PyInfo.string_types)
        assert not isinstance("string", PyInfo.text_type)
        assert isinstance("string", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:03.367937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3



# Generated at 2022-06-26 02:56:11.841524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:21.264670
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == 2147483647
    else:
        if sys.version_info[0] == 2:
            assert PyInfo.maxsize == (1 << 63) - 1 or PyInfo.maxsize == (1 << 31) - 1
        else:
            assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-26 02:56:23.342837
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-26 02:56:32.974254
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        # Python 2
        assert isinstance(PyInfo.string_types[0](), basestring)
        assert isinstance(PyInfo.text_type(), unicode)
        assert isinstance(PyInfo.binary_type(), str)

        assert isinstance(PyInfo.integer_types[0](), (int, long))
        assert isinstance(PyInfo.class_types[0](), (type, types.ClassType)   )
    elif sys.version_info[0] == 3:
        # Python 3
        assert isinstance(PyInfo.string_types[0](), str)
        assert isinstance(PyInfo.text_type(), str)
        assert isinstance(PyInfo.binary_type(), bytes)


# Generated at 2022-06-26 02:58:17.517232
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(list, PyInfo.class_types)
    assert isinstance(list(), PyInfo.class_types)
    assert isinstance(None, PyInfo.class_types)
    assert PyInfo.maxsize > 0
    assert (1 << 63) - 1 == PyInfo.maxsize
    assert PyInfo.maxsize == PyInfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:58:28.359749
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:58:39.304713
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('== Python version test of "PyInfo.py" ==')
    print('Python Version:', sys.version_info)
    print('Python Version String:', sys.version)
    print('Is PY2:', PyInfo.PY2)
    print('Is PY3:', PyInfo.PY3)
    print('python\'s maxsize:', PyInfo.maxsize)
    print('python\'s type() function:', PyInfo.class_types)
    print('python\'s string type:', PyInfo.string_types)
    print('python\'s text type:', PyInfo.text_type)
    print('python\'s binary type:', PyInfo.binary_type)
    print('python\'s integer types:', PyInfo.integer_types)
    print('== End of Python version test ==\n')

# Generated at 2022-06-26 02:58:46.884285
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-26 02:58:52.010023
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])


# Unit test

# Generated at 2022-06-26 02:58:54.086752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)



# Generated at 2022-06-26 02:58:59.585051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == True
    assert PyInfo.PY2 == False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:59:02.471041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is sys.version_info[0] == 3


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_PyInfo()

# Generated at 2022-06-26 02:59:11.690849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # for PY2
    assert isinstance(PyInfo.string_types[0], basestring)
    assert isinstance(PyInfo.text_type(''), unicode)
    assert isinstance(PyInfo.binary_type(''), str)
    assert isinstance(PyInfo.integer_types[0], (int, long))
    assert isinstance(PyInfo.integer_types[1], (int, long))
    assert isinstance(PyInfo.class_types[0], (type, types.ClassType))
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == int(2147483647)
    else:
        assert PyInfo.maxsize == int(9223372036854775807)
        # 64-bit

    # for PY3

# Generated at 2022-06-26 02:59:18.853968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("s", PyInfo.string_types)
    assert isinstance(u"s", PyInfo.string_types)

    assert isinstance("s", PyInfo.text_type)
    assert not isinstance(b"s", PyInfo.text_type)

    assert not isinstance("s", PyInfo.binary_type)
    assert isinstance(b"s", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)