

# Generated at 2022-06-26 02:49:19.884534
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """ PyInfo() constructor test """
    py_info = PyInfo()


# Generated at 2022-06-26 02:49:22.020558
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for scenarios covered by configurations: ['4', '4']
    test_case_0()

# Generated at 2022-06-26 02:49:32.537908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Unit test for constructor of class PyInfo

    """
    # test case 0

    # PyInfo
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == int((1 << 63) - 1)


if __name__ == "__main__":
    import nose

    nose.runmodule()

# Generated at 2022-06-26 02:49:33.454556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:49:39.191622
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY3 == sys.version_info[0] == 3
    assert py_info_0.PY2 == sys.version_info[0] == 2

# Generated at 2022-06-26 02:49:40.951612
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()



# Generated at 2022-06-26 02:49:46.223287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    测试构造函数
    '''
    # 判断系统是32位还是64位
    if sys.maxsize > 2 ** 32:
        print('64位系统')
    else:
        print('32位系统')
    test_case_0()



# Generated at 2022-06-26 02:49:49.675750
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info_0 = PyInfo()
    except Exception as e:
        assert False, "Could not call constructor of class PyInfo"


# Generated at 2022-06-26 02:49:50.593586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:49:52.058151
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo()) == type(PyInfo())



# Generated at 2022-06-26 02:49:58.965158
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test if an instance of PyInfo is created
    py_info_1 = PyInfo()
    assert py_info_1



# Generated at 2022-06-26 02:50:02.882288
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    assert py_info_0 is not py_info_1
    assert py_info_0 == py_info_1

# Unit tests for class attributes

# Generated at 2022-06-26 02:50:12.901994
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    assert py_info_0.PY2 == py_info_1.PY2
    assert py_info_0.PY3 == py_info_1.PY3
    assert py_info_0.string_types == py_info_1.string_types
    assert py_info_0.text_type == py_info_1.text_type
    assert py_info_0.binary_type == py_info_1.binary_type
    assert py_info_0.integer_types == py_info_1.integer_types
    assert py_info_0.class_types == py_info_1.class_types
    assert py_info_0.maxsize == py_info_1.maxsize

# Unit

# Generated at 2022-06-26 02:50:15.428626
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()



if __name__ == "__main__":
    test_case_0()
    test_PyInfo()

# Generated at 2022-06-26 02:50:16.066170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()

# Generated at 2022-06-26 02:50:17.073280
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:50:19.457878
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    print(py_info_0.PY2)
    print(py_info_0.PY3)


# Generated at 2022-06-26 02:50:20.734340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info, PyInfo)

# Generated at 2022-06-26 02:50:24.297173
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert(py_info_0.PY2)
    assert(py_info_0.PY3)
    assert(py_info_0.string_types)
    assert(py_info_0.text_type)
    assert(py_info_0.binary_type)
    assert(py_info_0.integer_types)
    assert(py_info_0.class_types)
    assert(py_info_0.maxsize)

# Generated at 2022-06-26 02:50:31.066048
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY3 == True
    assert py_info_0.PY2 == False
    assert isinstance(py_info_0.maxsize, int) 
    assert isinstance(py_info_0.string_types, tuple)
    assert isinstance(py_info_0.text_type, type)
    assert isinstance(py_info_0.binary_type, type)
    assert isinstance(py_info_0.class_types, tuple)
    assert isinstance(py_info_0.integer_types, tuple)


# Generated at 2022-06-26 02:50:46.933721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Current Python version:', sys.version)  # Current Python version: 3.6.0 (v3.6.0:41df79263a11, Dec 22 2016,
    # 17:23:13) [MSC v.1900 32 bit (Intel)]
    test_case_0()



if __name__ == '__main__':
    test_PyInfo()


'''
Hint:

This class is used to test current Python version, then do something different based on different Python version. 

'''

# Generated at 2022-06-26 02:50:51.875544
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    print(py_info_0)
    print(py_info_1)

    assert py_info_0 == py_info_1

    assert py_info_0.maxsize == py_info_1.maxsize

# Unit tests for properties of class PyInfo

# Generated at 2022-06-26 02:50:53.431825
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert isinstance(py_info_0, PyInfo)


# Generated at 2022-06-26 02:51:05.578613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for general purpose
    py_info_0 = PyInfo()
    # Test for call to constructor using keyword arguments
    # Test for class method of class PyInfo
    py_info_0 = PyInfo()
    # Test for class static attribute of class PyInfo
    py_info_0 = PyInfo()

if __name__ == "__main__":
    import os.path
    import sys
    import test_case_0

    if len(sys.argv) != 2:
        raise Exception("Invalid number of arguments")
    if not os.path.exists(sys.argv[1]):
        raise Exception("Test file does not exist")


# Generated at 2022-06-26 02:51:07.768327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info_0 = PyInfo()
    except Exception as e:
        assert False
    else:
        assert True

# Generated at 2022-06-26 02:51:10.969324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()
    assert True

# Generated at 2022-06-26 02:51:14.000470
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == sys.version_info[0] == 2


# Generated at 2022-06-26 02:51:17.707083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Executing test_PyInfo()...')
    py_info_0 = PyInfo()
    print('Exitting test_PyInfo()...')


# Generated at 2022-06-26 02:51:19.647098
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test type of return value of constructor
    assert type(PyInfo()) == PyInfo
    

# Generated at 2022-06-26 02:51:28.495486
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)

    if py_info.PY3:
        assert type(py_info.string_types) is tuple
        assert str in py_info.string_types
        assert (py_info.text_type == str) or py_info.text_type == str
        assert py_info.binary_type == bytes
        assert type(py_info.integer_types) is tuple
        assert int in py_info.integer_types
        assert type(py_info.class_types) is tuple
        assert type in py_info.class_types

    else:
        assert type(py_info.string_types)

# Generated at 2022-06-26 02:51:49.449387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

    if(py_info_0.PY2):
        sys.exit(0)
    else:
        sys.exit(1)
    

# Generated at 2022-06-26 02:51:49.981629
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-26 02:51:50.846984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:51:52.426523
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Constructor
    py_info_0 = PyInfo()

    # destructor
    del py_info_0

# Generated at 2022-06-26 02:51:53.625857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert py_info_0 is not None


# Generated at 2022-06-26 02:51:57.579074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

test_PyInfo()

### Local Variables:
### eval: (if (fboundp 'eu-rename-buffer) (eu-rename-buffer))
### End:

# Generated at 2022-06-26 02:52:08.469386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print ('Test for constructor in class PyInfo')
    assert callable(PyInfo)
    py_info_1 = PyInfo()
    assert isinstance(py_info_1, PyInfo)
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True or py_info_0.PY2 == False
    assert py_info_0.PY3 == True or py_info_0.PY3 == False
    assert all(isinstance(element, type(str())) for element in py_info_0.string_types)
    assert isinstance(py_info_0.text_type, type(str()))
    assert isinstance(py_info_0.binary_type, type(str()))

# Generated at 2022-06-26 02:52:09.245119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-26 02:52:15.648891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

    # test if the variable to string is correct
    print((py_info_0.PY2))
    print((py_info_0.PY3))
    print((py_info_0.string_types))
    print((py_info_0.text_type))
    print((py_info_0.binary_type))
    print((py_info_0.integer_types))
    print((py_info_0.class_types))
    print((py_info_0.maxsize))

test_PyInfo()

# Generated at 2022-06-26 02:52:24.544862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()
    test_PyInfo_00()
    test_PyInfo_01()
    test_PyInfo_02()


if __name__ == '__main__':
    # test_PyInfo()
    py_info = PyInfo()

# Generated at 2022-06-26 02:52:46.858550
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pickle
    assert isinstance(pickle.dumps(PyInfo()),
                      PyInfo.binary_type), 'should be an instance of binary_type'
    return


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:52.557598
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    # test_PyInfo


# https://www.python.org/dev/peps/pep-0453/#id15

# Generated at 2022-06-26 02:52:59.714594
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert type("") in PyInfo.string_types
    assert type(u"") in PyInfo.string_types
    assert type("") is PyInfo.binary_type
    assert type(u"") is PyInfo.text_type
    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-26 02:53:10.116946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from xtls.tools import sizeof

    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert sizeof(PyInfo.string_types[0]) > 1
    assert sizeof(PyInfo.text_type) > 1
    assert sizeof(PyInfo.binary_type) > 1
    assert len(PyInfo.integer_types) == 2
    assert sizeof(PyInfo.integer_types[0]) > 1
    assert sizeof(PyInfo.integer_types[1]) > 1
    assert len(PyInfo.class_types) == 2
    assert sizeof(PyInfo.class_types[0]) > 1
    assert sizeof(PyInfo.class_types[1]) > 1

    # Test that at least one valid number is large.

# Generated at 2022-06-26 02:53:17.025028
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or not PyInfo.PY2
    assert PyInfo.PY3 or not PyInfo.PY3

    assert PyInfo.PY3 != PyInfo.PY2
    assert PyInfo.PY3
    assert sys.version_info[0] == 3


# Convert Unicode to String

# Generated at 2022-06-26 02:53:23.457782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-26 02:53:30.222829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:53:30.735473
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-26 02:53:37.441349
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)



# Generated at 2022-06-26 02:53:47.677723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:54:30.426984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', bytes)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-26 02:54:39.704354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert isinstance('a'.encode(), PyInfo.binary_type)
    else:
        assert not isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance('a', PyInfo.string_types)
        assert not isinstance(u'a', PyInfo.text_type)
        assert isinstance('a'.encode(), PyInfo.binary_type)

# Generated at 2022-06-26 02:54:51.384059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_isinstance():
        # test Py3
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.text_type)
        assert isinstance(int, PyInfo.class_types)
        assert not isinstance(type, PyInfo.class_types)
        assert isinstance(1, PyInfo.string_types)
        assert not isinstance(b"1", PyInfo.string_types)

    def test_is():
        assert not b"1" is PyInfo.text_type
        assert u"1" is PyInfo.text_type
        assert isinstance(1, PyInfo.text_type)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-26 02:55:00.629435
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 is True or py_info.PY3 is True

    assert type(py_info.string_types) is tuple
    assert type(py_info.text_type) is type
    assert type(py_info.binary_type) is type
    assert type(py_info.integer_types) is tuple
    assert type(py_info.class_types) is tuple
    assert type(py_info.maxsize) is int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:11.523974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert issubclass(type(int), PyInfo.class_types)
    assert issubclass(type(str), PyInfo.class_types)
    # TODO: how to create class type in py3?
    # assert issubclass(type(PyInfo), PyInfo.class_types)


pyinfo = PyInfo()

# Generated at 2022-06-26 02:55:20.957346
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.maxsize == 2147483647
    assert PyInfo.string_types == (basestring, )
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-26 02:55:24.240119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyIn

# Generated at 2022-06-26 02:55:24.856835
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2



# Generated at 2022-06-26 02:55:37.020003
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    assert PyInfo.PY3 is (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance('foo', PyInfo.string_types)
        assert not isinstance('foo', PyInfo.binary_type)
        assert isinstance('foo', PyInfo.text_type)
        assert not isinstance(b'foo', PyInfo.string_types)
        assert isinstance(b'foo', PyInfo.binary_type)
        assert not isinstance(b'foo', PyInfo.text_type)
    else:
        assert isinstance('foo', PyInfo.string_types)
        assert not isinstance('foo', PyInfo.binary_type)
        assert isinstance(u'foo', PyInfo.string_types)

# Generated at 2022-06-26 02:55:43.609787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("====test_PyInfo()====")
    print("PY2={0}, PY3={1}".format(PyInfo.PY2, PyInfo.PY3))
    print("string_types={0}".format(PyInfo.string_types))
    print("text_type={0}, binary_type={1}".format(PyInfo.text_type, PyInfo.binary_type))
    print("integer_types={0}".format(PyInfo.integer_types))
    print("class_types={0}".format(PyInfo.class_types))
    print("maxsize={0}".format(PyInfo.maxsize))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:57:11.346181
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Testing Py3
    _sys = sys
    sys = types.ModuleType('sys')
    sys.version_info = (3, 7, 1, 'final', 0)
    pyinfo_class = PyInfo()
    assert pyinfo_class.PY3 is True
    assert pyinfo_class.string_types == (str,)
    assert pyinfo_class.text_type == str
    assert pyinfo_class.binary_type == bytes
    assert pyinfo_class.integer_types == (int,)
    assert pyinfo_class.class_types == (type,)
    assert pyinfo_class.maxsize == sys.maxsize
    assert pyinfo_class.PY2 is False

    # Testing Py2
    sys = _sys
    pyinfo_class = PyInfo()
    assert pyinfo_class.PY2 is True

# Generated at 2022-06-26 02:57:21.357500
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test if __init__ method has been overwritten
    assert hasattr(PyInfo, '__init__') == False

    # Test correct values
    class_types = (type, )
    string_types = (basestring, str)
    text_type = (unicode, str)
    binary_type = (str, bytes)
    integer_types = (int, long)
    maxsize = sys.maxsize

    if sys.version_info[0] == 3:
        class_types = type
        string_types = str
        text_type = str
        binary_type = bytes
        integer_types = int
        maxsize = sys.maxsize

    dict_PyInfo = PyInfo.__dict__
    assert dict_PyInfo['PY2'] == sys.version_info[0] == 2
    assert dict_

# Generated at 2022-06-26 02:57:25.445646
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 is False
    assert isinstance(PyInfo, object)
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-26 02:57:35.814434
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY3 == (not info.PY2)
    assert info.PY2 == sys.version_info[0] == 2
    assert info.PY3 == sys.version_info[0] == 3
    assert info.string_types == (str,) if info.PY3 else (basestring,)
    assert info.text_type == str if info.PY3 else unicode
    assert info.binary_type == bytes if info.PY3 else str
    assert info.integer_types == (int,) if info.PY3 else (int, long)
    assert info.class_types == (type,) if info.PY3 else (type, types.ClassType)
    if info.PY3:
        assert info.maxsize == sys.maxsize

# Generated at 2022-06-26 02:57:46.675956
# Unit test for constructor of class PyInfo
def test_PyInfo():

    i1 = PyInfo.PY2
    i2 = PyInfo.PY3
    assert i1 or i2

    # assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types, types.TupleType)
    assert isinstance((PyInfo.string_types)[0], types.TypeType)

    assert isinstance(PyInfo.text_type, types.TypeType)

    assert isinstance(PyInfo.binary_type, types.TypeType)

    # assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types, types.TupleType)
    assert isinstance((PyInfo.integer_types)[0], types.TypeType)

    # assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:57:48.122437
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2



# Generated at 2022-06-26 02:57:54.962211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is True
    assert info.PY3 is False

    info.PY2 = False
    assert info.PY2 is False

    # unit test for function length_to_int()
    length_to_int(5)

    # unit test for function length_to_long()
    length_to_long(5)

# Generated at 2022-06-26 02:58:03.709949
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(repr(PyInfo), str)
        assert 'Py2' in repr(PyInfo)
    else:
        assert isinstance(repr(PyInfo), str)
        assert 'Py3' in repr(PyInfo)

    assert PyInfo.PY2 ^ PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:58:08.658014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    # If either PY2 or PY3 is true, all other attributes should also be true
    if PyInfo.PY2:
        assert PyInfo.string_types
        assert PyInfo.text_type
        assert PyInfo.binary_type
        assert PyInfo.integer_types
        assert PyInfo.class_types
        assert PyInfo.maxsize
    elif PyInfo.PY3:
        assert PyInfo.string_types
        assert PyInfo.text_type
        assert PyInfo.binary_type
        assert PyInfo.integer_types
        assert PyInfo.class_types
        assert PyInfo.maxsize

# Generated at 2022-06-26 02:58:10.202655
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

