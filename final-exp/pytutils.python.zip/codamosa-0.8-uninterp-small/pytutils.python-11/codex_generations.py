

# Generated at 2022-06-26 02:49:25.239399
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # print('\n')
    py_info_1 = PyInfo()

    # To test PyInfo.PY2:

    # To test PyInfo.PY3:

    # To test PyInfo.string_types:

    # To test PyInfo.text_type:

    # To test PyInfo.binary_type:

    # To test PyInfo.integer_types:

    # To test PyInfo.class_types:

    # To test PyInfo.maxsize:



# Generated at 2022-06-26 02:49:26.209972
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:49:35.224670
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    assert py_info_0.PY2 == py_info_1.PY2
    assert py_info_0.PY3 == py_info_1.PY3
    assert py_info_0.string_types == py_info_1.string_types
    assert py_info_0.text_type == py_info_1.text_type
    assert py_info_0.binary_type == py_info_1.binary_type
    assert py_info_0.integer_types == py_info_1.integer_types
    assert py_info_0.class_types == py_info_1.class_types
    assert py_info_0.maxsize == py_info_1.maxsize

# Generated at 2022-06-26 02:49:40.090728
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert py_info_1
    assert py_info_1.PY2
    assert not py_info_1.PY3
    assert py_info_1.string_types == (basestring,)
    assert py_info_1.text_type == unicode
    assert py_info_1.binary_type == str
    assert py_info_1.integer_types == (int, long)
    assert py_info_1.class_types == (type, types.ClassType)
    assert py_info_1.maxsize == ((1 << 31) - 1)

# Generated at 2022-06-26 02:49:46.529307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Tests for the constructor of class PyInfo
    """
    # Constructor test case decorator
    def constructor_case(cls, testcase):
        def test(self):
            self.assertEqual(testcase, cls())
        return test

    # Constructor test cases
    @constructor_case(PyInfo, py_info_0)
    class constructor_TestCase(unittest.TestCase):
        pass

    # Constructor unit test
    unittest.main()

# Generated at 2022-06-26 02:49:52.104680
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().__class__ is PyInfo
    assert isinstance(PyInfo(), PyInfo)
    assert isinstance(PyInfo(), object)
    assert PyInfo.__class__ is type
    assert PyInfo.__class__.__class__ is type

    assert type(PyInfo()) is PyInfo
    assert type("") is str
    assert type(1) is int


# Generated at 2022-06-26 02:49:54.649731
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Running unit test for constructor of class PyInfo")
    test_case_0()

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:49:55.665715
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

test_PyInfo()

# Generated at 2022-06-26 02:49:57.576271
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

    assert isinstance(py_info_0, PyInfo)

# Generated at 2022-06-26 02:50:09.099157
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert PyInfo.maxsize == int((1 << 31) - 1) if PyInfo.PY2 else sys.maxsize

# Generated at 2022-06-26 02:50:16.420892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test class PyInfo with constructor"""

    test_case_0()

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:20.692023
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test case with valid parameter
    pyInfoTest = PyInfo()

    # Test case with invalid parameter
    try:
        pyInfoTest = PyInfo(1)
    except TypeError:
        print('Constructor throws error with invalid parameters.')
    else:
        raise AssertionError('Constructor does not throw error with invalid parameters.')



# Generated at 2022-06-26 02:50:22.073870
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo(py_info_0)


# Generated at 2022-06-26 02:50:26.060301
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    py_info_2 = PyInfo()
    py_info_3 = PyInfo()
    py_info_4 = PyInfo()


# Generated at 2022-06-26 02:50:27.416526
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Test for correct type of class PyInfo

# Generated at 2022-06-26 02:50:33.869497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == True, 'test_PyInfo failed: it expects {0} but it got {1}'.format(True, py_info.PY2)
    assert py_info.PY3 == False, 'test_PyInfo failed: it expects {0} but it got {1}'.format(False, py_info.PY2)
    assert py_info.class_types == (type, types.ClassType), 'test_PyInfo failed: it expects {0} but it got {1}'.format((type, types.ClassType), py_info.class_types)
    assert py_info.binary_type == str, 'test_PyInfo failed: it expects {0} but it got {1}'.format(str, py_info.binary_type)
    assert py

# Generated at 2022-06-26 02:50:42.002231
# Unit test for constructor of class PyInfo
def test_PyInfo():

    py_info_0 = PyInfo()
    if (py_info_0.PY2 != True): raise Exception()
    if (py_info_0.PY3 != False): raise Exception()
    if (py_info_0.string_types != (basestring,)): raise Exception()
    if (py_info_0.text_type != unicode): raise Exception()
    if (py_info_0.binary_type != str): raise Exception()
    if (py_info_0.integer_types != (int, long)): raise Exception()
    if (py_info_0.class_types != (type, types.ClassType)): raise Exception()
    if (py_info_0.maxsize != 9223372036854775807): raise Exception()
    #print ("PyInfo: test_case_0:

# Generated at 2022-06-26 02:50:43.450616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:50:46.634451
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        test_case_0()
        assert True
    except AssertionError:
        assert False


# Generated at 2022-06-26 02:50:50.569742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == "__main__":
    import sys
    import nose2

    sys.argv.append("--verbose=2")
    sys.argv.append("--nologcapture")
    nose2.main()

# Generated at 2022-06-26 02:51:07.240580
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,), "string_types : %s" % PyInfo.string_types
        assert PyInfo.binary_type == bytes, "binary_type : %s" % PyInfo.binary_type
        assert PyInfo.integer_types == (int,), "integer_types : %s" % PyInfo.integer_types
    else:
        assert PyInfo.string_types == (basestring,), "string_types : %s" % Py

# Generated at 2022-06-26 02:51:10.758857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        PyInfo()
    except:
        assert (False)
    assert (True)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:12.544954
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo() is not None

# Generated at 2022-06-26 02:51:23.871020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == sys.version_info[0] == 2)
    assert (PyInfo.PY3 == sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert (PyInfo.string_types == (str,))
        assert (PyInfo.text_type == str)
        assert (PyInfo.binary_type == bytes)
        assert (PyInfo.integer_types == (int,))
        assert (PyInfo.class_types == (type,))
        assert (PyInfo.maxsize == sys.maxsize)
    else:
        assert (PyInfo.string_types == (basestring,))
        assert (PyInfo.text_type == unicode)
        assert (PyInfo.binary_type == str)

# Generated at 2022-06-26 02:51:27.129103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == "__main__":
    import doctest
    import os
    import sys
    os.chdir(os.path.dirname(sys.argv[0]))
    doctest.testmod(sys.modules[__name__])

# Generated at 2022-06-26 02:51:32.717111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        with pytest.raises(TypeError):
            PyInfo.text_type(b"")
        assert type(PyInfo.text_type("")) == PyInfo.text_type
        assert type(PyInfo.string_types[0]("")) == PyInfo.string_types[0]
    else:
        assert isinstance("", PyInfo.text_type)



# Generated at 2022-06-26 02:51:40.806221
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance("a", PyInfo.string_types) is True
    assert isinstance(u"a", PyInfo.text_type) is True
    assert isinstance(b"a", PyInfo.binary_type) is True
    assert isinstance(1, PyInfo.integer_types) is True
    assert isinstance(type, PyInfo.class_types) is True
    assert (1 << 31) - 1 == PyInfo.maxsize



# Generated at 2022-06-26 02:51:50.087272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Exceute code
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types

    # Compare
    if sys.version_info[0] == 2:
        assert py2
        assert not py3
        assert isinstance('', string_types)
        assert isinstance(u'', string_types)
        assert isinstance('', string_types)
        assert not isinstance(1, string_types)
        assert not isinstance(b'', string_types)
        assert isinstance(u'', text_type)

# Generated at 2022-06-26 02:51:53.317723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for PyInfo constructor method."""
    pyinfo = PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3



# Generated at 2022-06-26 02:52:00.964547
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(3, PyInfo.integer_types)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-26 02:52:15.803844
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=W0212
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types


test_PyInfo()

# Generated at 2022-06-26 02:52:25.741657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> assert PyInfo.PY2 != PyInfo.PY3

    >>> assert isinstance(PyInfo.string_types, tuple)
    >>> assert isinstance(PyInfo.string_types[0], type)

    >>> assert isinstance(PyInfo.text_type, type)

    >>> assert isinstance(PyInfo.binary_type, type)

    >>> assert isinstance(PyInfo.integer_types, tuple)
    >>> assert isinstance(PyInfo.integer_types[0], type)

    >>> assert isinstance(PyInfo.class_types, tuple)
    >>> assert isinstance(PyInfo.class_types[0], type)

    >>> assert isinstance(PyInfo.maxsize, int)
    >>> assert PyInfo.maxsize > 0

    """


if __name__ == "__main__":
    import doctest

# Generated at 2022-06-26 02:52:32.429025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2
    assert not PyInfo().PY3
    assert PyInfo().string_types == (basestring,)
    assert PyInfo().text_type == unicode
    assert PyInfo().binary_type == str
    assert PyInfo().integer_types == (int, long)
    assert PyInfo().class_types == (type, types.ClassType)
    assert PyInfo().maxsize == sys.maxsize


#
# This function finds the python interpreter on the system.
#

# Generated at 2022-06-26 02:52:36.698103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-26 02:52:43.750110
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None

# Generated at 2022-06-26 02:52:51.017505
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('test', PyInfo.string_types), 'test'
        assert not isinstance(b'test', PyInfo.string_types), 'test'
        assert isinstance(u'test', PyInfo.text_type), 'test'
        assert not isinstance(b'test', PyInfo.text_type), 'test'
        assert isinstance(b'test', PyInfo.binary_type), 'test'
        assert not isinstance(u'test', PyInfo.binary_type), 'test'
        assert isinstance(1, PyInfo.integer_types), 'test'
        assert not isinstance(1.0, PyInfo.integer_types), 'test'
    else:
        assert isinstance('test', PyInfo.string_types), 'test'

# Generated at 2022-06-26 02:53:00.896403
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert len(PyInfo.string_types) == 1
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0] == str
        assert isinstance(PyInfo.text_type, type)
        assert PyInfo.text_type == str
        assert isinstance(PyInfo.binary_type, type)
        assert PyInfo.binary_type == bytes
        assert isinstance(PyInfo.integer_types, tuple)
        assert len(PyInfo.integer_types) == 1
        assert isinstance

# Generated at 2022-06-26 02:53:08.092853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(PyInfo.text_type, type(str))
    assert isinstance(PyInfo.binary_type, type(str))
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Test all code branches
test_PyInfo()

# Generated at 2022-06-26 02:53:19.578149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    py2 = sys.version_info[0] == 2
    py3 = sys.version_info[0] == 3

    assert py_info.PY2 == py2
    assert py_info.PY3 == py3

    str_ = py_info.text_type
    bytes_ = py_info.binary_type
    str_list = [str_]
    bytes_list = [bytes_]

    assert py_info.string_types == tuple(str_list)
    assert py_info.integer_types == (int,)
    assert py_info.class_types == (type,)

    assert py_info.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:31.464682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.maxsize == 9223372036854775807
    assert isinstance("A", PyInfo.string_types)
    assert isinstance("A", PyInfo.text_type)
    assert isinstance(u"A", PyInfo.string_types)
    assert isinstance(u"A", PyInfo.text_type)
    assert isinstance("A", PyInfo.string_types)
    assert isinstance("A", PyInfo.binary_type)
    assert isinstance(b"A", PyInfo.string_types)
    assert isinstance(b"A", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:01.985854
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 != PyInfo.PY2

    assert len(PyInfo.string_types) == 1
    assert issubclass(PyInfo.string_types[0], basestring)
    if PyInfo.PY3:
        assert PyInfo.string_types[0] is str
    else:
        assert PyInfo.string_types[0] is basestring

    assert len(PyInfo.integer_types) == 2
    assert issubclass(PyInfo.integer_types[0], (int, long))
    assert issubclass(PyInfo.integer_types[1], (int, long))
    if PyInfo.PY3:
        assert PyInfo.integer_types[0] is int
    else:
        assert PyInfo.integer_types[0] is int
        assert PyInfo.integer_

# Generated at 2022-06-26 02:54:08.976752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("Hello World!", PyInfo.string_types)
    assert isinstance("Hello World!", PyInfo.text_type)
    assert not isinstance("Hello World!", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:54:19.588630
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().string_types[0], type)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().integer_types[0], type)
    assert isinstance(PyInfo().class_types, tuple)
    assert isinstance(PyInfo().class_types[0], type)
    assert isinstance(PyInfo().maxsize, int)

# Generated at 2022-06-26 02:54:29.229039
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type(1), PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:54:40.805070
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        test_string_types = basestring,
        test_text_type = unicode
        test_binary_type = str
        test_integer_types = (int, long)
        test_class_types = (type, types.ClassType)
    else:
        test_string_types = str,
        test_text_type = str
        test_binary_type = bytes
        test_integer_types = int,
        test_class_types = type,

    assert PyInfo.string_types == test_string_types
    assert PyInfo.text_type == test_text_type
    assert PyInfo.binary_type == test_binary_type
    assert PyInfo.integer_types == test_integer_types
    assert PyInfo.class_types == test_class_types


#

# Generated at 2022-06-26 02:54:49.139041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types[0] == (str, )
    else:  # PY2
        assert PyInfo.string_types[0] == (basestring, )

# Generated at 2022-06-26 02:55:01.515381
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2 and not PyInfo.PY3:
        raise ValueError('Error: Python version should be 2 or 3!')
    # test maxsize
    if not isinstance(PyInfo.maxsize, int):
        raise ValueError('Error: PyInfo.maxsize should be integer!')
    # test string_types
    if not isinstance(PyInfo.string_types, tuple):
        raise ValueError('Error: PyInfo.string_types should be tuple of string!')
    for char_type in PyInfo.string_types:
        if not isinstance(char_type, type):
            raise ValueError('Error: PyInfo.string_types should be tuple of string!')
    # test text_type

# Generated at 2022-06-26 02:55:04.782536
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert isinstance('foo', PyInfo.string_types)



# Generated at 2022-06-26 02:55:14.196794
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Python 2
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

    # Python 3
    PyInfo.PY2 = False
    PyInfo.PY3 = True
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)

# Generated at 2022-06-26 02:55:22.888700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    if (PyInfo.PY2):
        assert(isinstance("a", PyInfo.string_types))
        assert("a" == PyInfo.text_type("a"))
        assert("a" == PyInfo.binary_type("a"))
    # PY3
    elif (PyInfo.PY3):
        assert(isinstance("a", PyInfo.string_types))
        assert("a" == PyInfo.text_type("a"))
        assert(b"a" == PyInfo.binary_type("a"))



# Generated at 2022-06-26 02:56:10.492981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 == True
    elif sys.version_info[0] == 3:
        assert PyInfo.PY3 == True



# Generated at 2022-06-26 02:56:21.263490
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-26 02:56:30.356862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert isinstance(u"abc", PyInfo.text_type)
    else:  # PY3
        assert not isinstance(1, PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.text_type)
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:33.158920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo
    i = PyInfo()
    assert isinstance(i, PyInfo)



# Generated at 2022-06-26 02:56:36.645185
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


pyinfo = PyInfo()

# Classes
# ------------------------------------------------------------------------------

# Generated at 2022-06-26 02:56:45.229864
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:56:46.014739
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _ = PyInfo()

# Generated at 2022-06-26 02:56:52.200078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 and not PyInfo.PY3)

    assert(isinstance('', PyInfo.string_types))
    assert(isinstance(u'', PyInfo.string_types))
    assert(isinstance(1, PyInfo.integer_types))

# Generated at 2022-06-26 02:56:59.519044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert PyInfo.maxsize == 2 ** 63 - 1 or PyInfo.maxsize == 2 ** 31 - 1
    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-26 02:57:07.462388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)
        assert not isinstance(b'a', PyInfo.string_types)

        assert isinstance(u'a', PyInfo.text_type)
        assert not isinstance('a', PyInfo.text_type)
        assert not isinstance(b'a', PyInfo.text_type)

        assert isinstance(b'a', PyInfo.binary_type)
        assert not isinstance('a', PyInfo.binary_type)
        assert not isinstance(u'a', PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(2 ** 64, PyInfo.integer_types)
        assert not isinstance

# Generated at 2022-06-26 02:58:57.511112
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # if sys.maxsize == 2**31-1:
    #     assert PyInfo.maxsize == 2**31-1
    # else:
    #     assert PyInfo.maxsize == 2**63-1
    assert PyInfo.maxsize == sys.maxsize
    if sys.version_info[0] == 2:
        assert type(PyInfo.text_type()) == unicode
    else:
        assert type(PyInfo.text_type()) == str

# Generated at 2022-06-26 02:59:06.136819
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3, \
        'Error: PyInfo.PY2, PyInfo.PY3 should be different'
    assert PyInfo.string_types != PyInfo.class_types, \
        'Error: PyInfo.string_types, PyInfo.class_types should be different'
    assert PyInfo.text_type != PyInfo.binary_type, \
        'Error: PyInfo.text_type, PyInfo.binary_type should be different'
    assert PyInfo.integer_types != PyInfo.class_types, \
        'Error: PyInfo.integer_types, PyInfo.class_types should be different'

# Generated at 2022-06-26 02:59:16.415682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert 1, 0

    assert isinstance("1", PyInfo.string_types)
    assert isinstance("中文", PyInfo.string_types)
    assert isinstance(u"中文", PyInfo.string_types)
    assert isinstance("1", PyInfo.text_type)
    assert isinstance("中文", PyInfo.text_type)
    assert isinstance(u"中文", PyInfo.text_type)
    assert isinstance("1", PyInfo.binary_type)
    assert isinstance("中文", PyInfo.binary_type)
    assert isinstance(u"中文", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)