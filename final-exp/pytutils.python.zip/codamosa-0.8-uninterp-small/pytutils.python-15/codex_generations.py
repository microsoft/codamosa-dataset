

# Generated at 2022-06-26 02:49:24.139722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    if py_info.PY3:
        assert py_info.string_types == (str,)
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
        assert py_info.integer_types == (int,)
        assert py_info.class_types == (type,)

        assert py_info.maxsize == sys.maxsize
    else: # PY2
        assert py_info.string_types == (basestring,)
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
        assert py_info.integer_

# Generated at 2022-06-26 02:49:30.917669
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test Constructor")
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == basestring
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1
    print("End Test")


# Generated at 2022-06-26 02:49:38.386104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    tester = PyInfo()
    assert tester.PY3 == sys.version_info[0] == 3
    assert tester.PY2 == sys.version_info[0] == 2

    # Python 2
    if sys.version_info[0] == 2:
        assert isinstance(tester.string_types, tuple)
        assert isinstance(tester.binary_type, str)
        assert isinstance(tester.text_type, unicode)
        assert isinstance(tester.integer_types, tuple)
        assert isinstance(sys.maxsize, long)
        assert tester.maxsize == sys.maxsize

    # Python 3
    else:
        assert isinstance(tester.string_types, type)
        assert isinstance(tester.binary_type, bytes)

# Generated at 2022-06-26 02:49:41.184476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print ('Unit test for constructor of class PyInfo')
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:48.091160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY3 == False
    assert py_info_0.PY2 == True
    assert py_info_0.maxsize == 2147483647
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.binary_type == str
    assert py_info_0.text_type == unicode
    assert py_info_0.class_types == (type, types.ClassType)


# Generated at 2022-06-26 02:49:49.390523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()



# Generated at 2022-06-26 02:49:59.423036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert (py_info_1.PY2 == True),"AssertionError : expected True, got %s" %py_info_1.PY2
    assert (py_info_1.PY3 == False),"AssertionError : expected False, got %s" %py_info_1.PY3
    assert (py_info_1.string_types == (basestring,)),"AssertionError : expected (basestring,), got %s" %py_info_1.string_types
    assert (py_info_1.text_type == unicode),"AssertionError : expected unicode, got %s" %py_info_1.text_type

# Generated at 2022-06-26 02:50:00.836539
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()



# Generated at 2022-06-26 02:50:01.984438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:50:09.013893
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert py_info_0.PY3 == False
    assert py_info_0.PY2 == True
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.maxsize == 9223372036854775807
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode

# Generated at 2022-06-26 02:50:21.593146
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Python version: %s" % sys.version)
    if not PyInfo.PY3:
        print("PY2 string_types: %s" % repr(PyInfo.string_types))
        print("PY2 text_type: %s" % repr(PyInfo.text_type))
        print("PY2 binary_type: %s" % repr(PyInfo.binary_type))
        print("PY2 integer_types: %s" % repr(PyInfo.integer_types))
        print("PY2 class_types: %s" % repr(PyInfo.class_types))
    else:
        print("PY3 string_types: %s" % repr(PyInfo.string_types))
        print("PY3 text_type: %s" % repr(PyInfo.text_type))
       

# Generated at 2022-06-26 02:50:31.329040
# Unit test for constructor of class PyInfo

# Generated at 2022-06-26 02:50:33.560221
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:36.839067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-26 02:50:48.513459
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    if PyInfo.PY2:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == (1 << 31) - 1 if sys.platform.startswith("java") else (1 << 63) - 1
    else:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer

# Generated at 2022-06-26 02:50:54.161993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:51:00.733654
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:51:02.458289
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("foo", PyInfo.string_types)
        asser

# Generated at 2022-06-26 02:51:12.724907
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test constructor of class PyInfo
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

    # Test string_types of class PyInfo
    assert (sys.version_info[0] == 2 and PyInfo.string_types == (basestring,)) or (
        sys.version_info[0] == 3 and PyInfo.string_types == (str,))

    # Test text_type of class PyInfo
    assert (sys.version_info[0] == 2 and PyInfo.text_type == unicode) or (
        sys.version_info[0] == 3 and PyInfo.text_type == str)

    # Test binary_type of class PyInfo

# Generated at 2022-06-26 02:51:18.968909
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-26 02:51:27.956224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-26 02:51:39.271409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 != pi.PY3
    assert isinstance(pi.string_types, tuple)
    assert isinstance(pi.text_type, type)
    assert isinstance(pi.binary_type, type)
    assert isinstance(pi.integer_types, tuple)
    assert isinstance(pi.class_types, tuple)
    assert isinstance(pi.maxsize, int)


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename.endswith(".py"):
        import pytest

        if len(sys.argv) == 1:
            print(__doc__.strip())
            sys.exit(1)

# Generated at 2022-06-26 02:51:42.196044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-26 02:51:46.330853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type) is False
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(isinstance, PyInfo.class_types)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:51:55.014729
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert type(PyInfo.string_types[0]) == type
        assert PyInfo.text_type == str
        assert type(PyInfo.text_type) == type
        assert PyInfo.binary_type == bytes
        assert type(PyInfo.binary_type) == type
        assert PyInfo.integer_types == (int,)
        assert type(PyInfo.integer_types[0]) == type
        assert PyInfo.class_types == (type,)
        assert type(PyInfo.class_types[0]) == type

# Generated at 2022-06-26 02:52:06.672507
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 or PyInfo().PY3, "Invalid Python version: %s" % sys.version
    assert isinstance(PyInfo().string_types, tuple), "Invalid string type: %s" % PyInfo().string_types
    assert isinstance(PyInfo().text_type, str), "Invalid text type: %s" % PyInfo().text_type
    assert isinstance(PyInfo().binary_type, bytes), "Invalid binary type: %s" % PyInfo().binary_type
    assert isinstance(PyInfo().integer_types, tuple), "Invalid integer type: %s" % PyInfo().integer_types
    assert isinstance(PyInfo().class_types, tuple), "Invalid class type: %s" % PyInfo().class_types

# Generated at 2022-06-26 02:52:09.733520
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:10.727494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, PyInfo.PY3



# Generated at 2022-06-26 02:52:16.292376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:52:26.307611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    pytest.main(__file__)

# Generated at 2022-06-26 02:52:47.737216
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert (py_info.PY2 is True or py_info.PY2 is False)
    assert (py_info.PY3 is True or py_info.PY3 is False)

    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)

    assert isinstance(py_info.maxsize, int)
    assert py_info.maxsize > 0


# Test for the function is_string

# Generated at 2022-06-26 02:52:52.948224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize > 0
    assert PyInfo.PY3 or PyInfo.PY2


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-26 02:52:55.014848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-26 02:52:57.514131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize <= sys.maxsize
    else:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:53:09.462143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.string_types)
    assert not isinstance(b"str", PyInfo.string_types)
    assert not isinstance(b"str", PyInfo.string_types)
    assert not isinstance(u"str", PyInfo.string_types)
    assert isinstance(b"str", PyInfo.binary_type)
    assert isinstance(u"str", PyInfo.text_type)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(3, PyInfo.integer_types)
    assert not isinstance(3, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)



# Generated at 2022-06-26 02:53:16.990517
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2 is False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:53:25.503901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    the_py_info = PyInfo()
    assert the_py_info
    assert the_py_info.PY2 != the_py_info.PY3
    assert type(the_py_info.string_types) == tuple
    assert type(the_py_info.text_type) == type
    assert type(the_py_info.binary_type) == type
    assert type(the_py_info.integer_types) == tuple
    assert type(the_py_info.maxsize) == int
    assert type(the_py_info.class_types) == tuple
    if the_py_info.PY2:
        assert the_py_info.string_types == (basestring,)
        assert the_py_info.text_type == unicode
        assert the_py_info.binary_type

# Generated at 2022-06-26 02:53:33.125493
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert issubclass(PyInfo.text_type, basestring)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# Get Python version (major, minor, fix)

# Generated at 2022-06-26 02:53:39.678675
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert len(PyInfo.string_types) == 1
    assert isinstance(PyInfo.integer_types, tuple)
    assert len(PyInfo.integer_types) == 2
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.class_types, tuple)
    assert len(PyInfo.class_types) == 2
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:50.818827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    if py2:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, unicode)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

        assert isinstance(PyInfo.maxsize, long)
    elif py3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:54:20.128530
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class SubClass(PyInfo):
        pass

    sub_class = SubClass()
    assert sub_class.PY2 or sub_class.PY3
    assert isinstance(sub_class.string_types, tuple)
    assert isinstance(sub_class.text_type, type)
    assert isinstance(sub_class.binary_type, type)
    assert isinstance(sub_class.integer_types, tuple)
    assert isinstance(sub_class.class_types, tuple)
    assert isinstance(sub_class.maxsize, int)


PyInfo = PyInfo()

# Generated at 2022-06-26 02:54:31.105441
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:39.667329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check_type():
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.integer_types, tuple)

        if not PyInfo.PY2:
            assert isinstance(PyInfo.maxsize, int)

    check_type()
    if PyInfo.PY2:
        reload(sys)
        sys.setdefaultencoding('utf8')
        import __builtin__
        reload(__builtin__)
        check_type()
    del check_type

# Generated at 2022-06-26 02:54:47.250545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY2 is not False
    assert PyInfo.PY3 is not True
    assert PyInfo.PY3 is not False
    assert isinstance("", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:54:53.304178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    if not PyInfo.PY3:
        assert isinstance(u'', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    if not PyInfo.PY3:
        assert isinstance(long(1), PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)


# ==============================================================================
# Initialization
# ==============================================================================
__all__ = ('config', 'PyInfo')

logger = logging.getLogger(__name__)




# Generated at 2022-06-26 02:54:58.681465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyIn

# Generated at 2022-06-26 02:55:04.094917
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)


# Helpers for reading/writing packed binary data to/from byte strings
#
# NB: These functions don't depend on the byte order or size of the host
# machine's native words. All words are encoded and decoded in little-endian
# byte order, regardless of the byte order of the machine.
#
# Format string syntax:
#
#   Format string syntax is a subset of the format string syntax of the
#   built-in "struct" module in Python 2.7.
#
#   A format string consists of zero or more conversion specifications and
#   ordinary characters.
#
#   Each conversion specifier is introduced by a '%' character and ends with
#   a conversion type.
#
#   Ordinary characters (including '%') are copied verbatim.
#
# Supported conversion

# Generated at 2022-06-26 02:55:11.560205
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test the attributes of class PyInfo
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:13.046538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2



# Generated at 2022-06-26 02:55:23.335582
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str,) if PyInfo.PY3 else (basestring,)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int,) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (type,) if PyInfo.PY3 else (type, types.ClassType)

# Generated at 2022-06-26 02:56:13.145994
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert id(type(PyInfo.PY2)) == id(bool)
    assert id(type(PyInfo.PY3)) == id(bool)
    assert id(type(PyInfo.string_types)) == id(tuple)
    assert id(type(PyInfo.text_type)) == id(type)
    assert id(type(PyInfo.binary_type)) == id(type)
    assert id(type(PyInfo.integer_types)) == id(tuple)
    assert id(type(PyInfo.class_types)) == id(tuple)
    assert id(type(PyInfo.maxsize)) == id(int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:19.275127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for python version >= 2.6 as reported by pankaj
    from sys import version_info
    assert version_info[0] == 2 or version_info[1] >= 6


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:31.410999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    PY2 = info.PY2
    PY3 = info.PY3
    if PY2:
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        if not sys.platform.startswith("java"):
            assert info.class_types == (type, types.ClassType)

    if PY3:
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:43.156007
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert len(PyInfo.class_types) == 2
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary

# Generated at 2022-06-26 02:56:51.949042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2
    assert not PyInfo().PY3
    assert PyInfo().string_types == (basestring,)
    assert PyInfo().text_type == unicode
    assert PyInfo().binary_type == str
    assert PyInfo().integer_types == (int, long)
    assert PyInfo().class_types == (type, types.ClassType)
    assert PyInfo().maxsize == (1 << 63) - 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:57:03.342997
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    False
    >>> PyInfo.PY3
    True
    >>> len(PyInfo.string_types)
    1
    >>> PyInfo.text_type
    <class 'str'>
    >>> PyInfo.binary_type
    <class 'bytes'>
    >>> len(PyInfo.integer_types)
    2
    >>> PyInfo.class_types
    (<class 'type'>,)
    >>> PyInfo.maxsize
    <built-in function maxsize>
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:57:09.290317
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check for the __doc__ string
    assert len(PyInfo.__doc__) > 0
    # check for the __init__ function
    assert len(PyInfo.__init__.__doc__) > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:57:20.333389
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    if platform.python_implementation() == 'Jython':
        assert PyInfo.maxsize == 2147483647
    else:
        assert PyInfo.maxsize < 0xFFFFFFFFFFFFFFFF

# Generated at 2022-06-26 02:57:28.166965
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test PyInfo.PY2
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    # Test PyInfo.PY3
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test PyInfo.string_types
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    # Test PyInfo.text_type
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    # Test PyInfo.binary_type

# Generated at 2022-06-26 02:57:36.383119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _pi = PyInfo()
    _pi2 = PyInfo()

    assert PyInfo.PY2 is True  # noqa
    assert PyInfo.PY3 is False  # noqa

    assert _pi is _pi2

    if _pi.PY2 is True:
        assert str is unicode  # noqa
        assert basestring is _pi.string_types  # noqa
        assert str is _pi.binary_type  # noqa
        assert unicode is _pi.text_type  # noqa
        assert unicode is _pi.string_types  # noqa
        assert long is _pi.integer_types  # noqa
        assert int is _pi.integer_types  # noqa
        assert types.ClassType is _pi.class_types  # noqa

# Generated at 2022-06-26 02:59:17.273296
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type, PyInfo.integer_type, PyInfo.class_types)
    print(type('asd'), type(b'asd'), type(1.1), type(1))


if __name__ == '__main__':
    test_PyInfo()