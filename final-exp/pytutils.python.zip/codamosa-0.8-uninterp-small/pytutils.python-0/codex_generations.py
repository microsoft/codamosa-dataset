

# Generated at 2022-06-26 02:49:19.100578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:49:19.675852
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True

# Generated at 2022-06-26 02:49:28.283214
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY3 == False
    assert PyInfo.PY2 == True
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 2147483647

    print('Test PyInfo finished')
    return


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:29.878320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY3 == True, "Constructor of class PyInfo is broken."



# Generated at 2022-06-26 02:49:37.840150
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:49:40.709112
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:45.442575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = None
    try:
        py_info_0 = PyInfo()
    except Exception as err:
        pytest.fail('The constructor of PyInfo failed: ' + str(err))
    finally:
        if py_info_0 is not None:
            py_info_0 = None


# Test for class PyInfo

# Generated at 2022-06-26 02:49:46.301088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()



# Generated at 2022-06-26 02:49:49.308498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == '__main__':
    test_PyInfo()
    # test_case_0()

# Generated at 2022-06-26 02:49:52.227486
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    with pytest.raises(AttributeError, msg="Unable to get attribute 'PY3'"):
        print(py_info_0.PY3)


# Generated at 2022-06-26 02:50:00.564746
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert sys.version_info[0] == 2
    if PyInfo.PY3:
        assert sys.version_info[0] == 3


if __name__ == "__main__":
    """Run all unit tests."""
    import doctest

    print(doctest.testmod())

# Generated at 2022-06-26 02:50:11.278163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("".encode("utf8"), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance(int, PyInfo.class_types)
    # maxsize must be greater than zero
    assert PyInfo.maxsize > 0
    # maxsize must about sys.maxsize
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-26 02:50:15.509638
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True) == (sys.version_info[0] == 2)
    assert (PyInfo.PY3 == True) == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:50:18.020299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Get python info
_py_info = PyInfo()
del PyInfo


# Generated at 2022-06-26 02:50:25.723981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3

    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:50:30.724685
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is type

# Generated at 2022-06-26 02:50:33.138272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-26 02:50:38.235716
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert issubclass(PyInfo.text_type, str)
    assert PyInfo.binary_type is bytes
    assert issubclass(PyInfo.integer_types, int)
    assert issubclass(PyInfo.class_types, type)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:50:46.685960
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """ Only useful for manual checking """
    if PyInfo.PY2:
        print("Python 2")
    else:
        print("Python 3")
    print("PyInfo.maxsize: %s" % PyInfo.maxsize)

# Generated at 2022-06-26 02:50:55.871966
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    if PyInfo.PY2:
        assert type(b"string") is str
        assert type(b"string") is PyInfo.binary_type
        assert type("string") is PyInfo.text_type
        assert (isinstance("string", PyInfo.string_types)) is True
        assert type(PyInfo.maxsize) is long
        assert (isinstance(PyInfo.maxsize, PyInfo.integer_types))

    # PY3
    elif PyInfo.PY3:
        assert type(b"string") is bytes
        assert type(b"string") is PyInfo.binary_type
        assert type("string") is str
        assert type("string") is PyInfo.text_type
        assert (isinstance("string", PyInfo.string_types)) is True

# Generated at 2022-06-26 02:51:07.076626
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert (info.PY2 and info.PY3) is False
    assert (isinstance(info.string_types, tuple) and
            isinstance(info.text_type, type) and
            isinstance(info.binary_type, type) and
            isinstance(info.integer_types, tuple) and
            isinstance(info.class_types, tuple) and
            isinstance(info.maxsize, int))
    if info.PY2:
        assert (info.string_types == (basestring,) and
                info.text_type == unicode and
                info.binary_type == str and
                info.integer_types == (int, long) and
                info.class_types == (type, types.ClassType))

# Generated at 2022-06-26 02:51:12.883924
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert PyInfo.text_type is str or PyInfo.text_type is unicode
    assert PyInfo.binary_type is str or PyInfo.binary_type is bytes
    assert str(PyInfo.maxsize * 2).startswith("-") == False


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:24.180067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert isinstance(u"T", PyInfo.text_type)
        assert isinstance(b"T", PyInfo.binary_type)
        assert PyInfo.maxsize == sys.maxsize
        assert not isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:51:28.494781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('test', PyInfo.string_types)
    assert isinstance(u'test', PyInfo.text_type)
    assert isinstance('test', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-26 02:51:31.959573
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-26 02:51:34.294277
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Execution of the main script
if __name__ == "__main__":
    pass

# Generated at 2022-06-26 02:51:44.700476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("some string", PyInfo.string_types)
        assert not isinstance("some string", PyInfo.text_type)
        assert not isinstance("some string", PyInfo.binary_type)
        assert not isinstance("some string", PyInfo.integer_types)
        assert not isinstance("some string", PyInfo.class_types)

        assert isinstance(u"asdf", PyInfo.string_types)
        assert isinstance(u"asdf", PyInfo.text_type)
        assert not isinstance(u"asdf", PyInfo.binary_type)
        assert not isinstance(u"asdf", PyInfo.integer_types)
        assert not isinstance(u"asdf", PyInfo.class_types)


# Generated at 2022-06-26 02:51:53.874722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert not isinstance(u'unicode', PyInfo.binary_type)


# Generated at 2022-06-26 02:52:06.137411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose import tools as nt

    nt.assert_in(PyInfo.PY2, (True, False))
    nt.assert_in(PyInfo.PY3, (True, False))
    nt.assert_equal(PyInfo.maxsize, sys.maxsize)

    if PyInfo.PY3:
        # string_types = str,
        nt.assert_is_instance('', PyInfo.string_types)
        nt.assert_is_instance('', PyInfo.string_types)
        nt.assert_is_instance('test', PyInfo.string_types)
        nt.assert_is_instance('test', PyInfo.string_types)
        nt.assert_is_instance(u'test', PyInfo.string_types)
        nt.assert_is_instance

# Generated at 2022-06-26 02:52:07.102032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2
    assert info.PY3 is False



# Generated at 2022-06-26 02:52:25.824130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True
    assert pi.PY3 is False
    assert pi.string_types is (basestring,)
    assert pi.text_type is unicode
    assert pi.binary_type is str
    assert pi.integer_types is (int, long)
    assert pi.class_types is (type, types.ClassType)

    # Jython always uses 32 bits.
    if sys.platform.startswith("java"):
        assert pi.maxsize == int((1 << 31) - 1)
    else:
        assert pi.maxsize == int((1 << 63) - 1)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:52:35.730704
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

        # test maxsize
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                assert PyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-26 02:52:43.548275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-26 02:52:50.253885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class FakePythonVersion(object):
        pass

    sys.version_info = FakePythonVersion()
    sys.version_info.major = 2
    py2 = PyInfo()
    assert py2.PY2 is True
    assert py2.PY3 is False

    sys.version_info.major = 3
    py3 = PyInfo()
    assert py3.PY2 is False
    assert py3.PY3 is True

    assert py2.binary_type is str
    assert py2.class_types is (type, types.ClassType)

    assert py3.binary_type is bytes
    assert py3.class_types is type



# Generated at 2022-06-26 02:52:58.585736
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check __new__ is not implemented
    with pytest.raises(TypeError):
        PyInfo()

    # Check __init__ is not implemented
    with pytest.raises(TypeError):
        PyInfo.__new__(PyInfo)

    # Check method is not implemented
    with pytest.raises(TypeError):
        PyInfo.__new__(PyInfo).test()

    # Check attribute is not implemented
    with pytest.raises(AttributeError):
        PyInfo.__new__(PyInfo).test



# Generated at 2022-06-26 02:53:09.702072
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (
        sys.version_info[0] == 2
    ), "Failed to initialize static variable PY2"
    assert PyInfo.PY3 == (
        sys.version_info[0] == 3
    ), "Failed to initialize static variable PY3"

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0].__name__ == "basestring"
    else:  # PY3
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0].__name__ == "str"


# Generated at 2022-06-26 02:53:17.643835
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-26 02:53:22.001375
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    test_info = PyInfo()
    assert (sys.version_info[0] == 2 and test_info.PY2) or \
        (sys.version_info[0] == 3 and test_info.PY3)



# Generated at 2022-06-26 02:53:27.081440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-26 02:53:37.221230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:58.794640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert str in PyInfo.string_types
    else:
        assert not PyInfo.PY3

# Generated at 2022-06-26 02:54:11.285987
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        from unittest import TestCase
    except:
        from unittest2 import TestCase

    class Test(TestCase):
        def test_py26(self):
            self.assertEqual(PyInfo.PY2, True)
            self.assertEqual(PyInfo.PY3, False)

        def test_py3(self):
            self.assertEqual(PyInfo.PY2, False)
            self.assertEqual(PyInfo.PY3, True)

        def test_string_types(self):
            self.assertTrue(isinstance("", PyInfo.string_types))
            self.assertTrue(isinstance(u"", PyInfo.string_types))

            self.assertFalse(isinstance(b"", PyInfo.string_types))

# Generated at 2022-06-26 02:54:22.421638
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.maxsize >= 0
    assert len(PyInfo.string_types) >= 1 and PyInfo.string_types[0] == basestring
    assert len(PyInfo.integer_types) >= 2 and PyInfo.integer_types[0] == int and PyInfo.integer_types[1] == long
    assert len(PyInfo.class_types) >= 2 and PyInfo.class_types[0] == type and PyInfo.class_types[1] == types.ClassType
    assert len(PyInfo.binary_type) >= 1 and PyInfo.binary_type[0] == str

# Generated at 2022-06-26 02:54:27.480925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo
    assert info.PY2 or info.PY3
    assert isinstance(info.maxsize, int) or info.maxsize == sys.maxsize


if __name__ == "__main__":

    test_PyInfo()

# Generated at 2022-06-26 02:54:39.845088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> p = PyInfo()
    >>> assert isinstance(p, object)
    >>> p = PyInfo()
    >>> assert p.PY2 is False or p.PY2 is True
    >>> assert p.PY3 is False or p.PY3 is True
    >>> assert isinstance(p.string_types, tuple)
    >>> assert isinstance(p.text_type, type)
    >>> assert isinstance(p.binary_type, type)
    >>> assert isinstance(p.integer_types, tuple)
    >>> assert isinstance(p.class_types, tuple)
    >>> assert isinstance(p.maxsize, int)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:54:49.180958
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type == type("")
    assert PyInfo.binary_type == type(b"")
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)


__all__ = ['PyInfo']

# Generated at 2022-06-26 02:55:00.826705
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('test', PyInfo.string_types)
    else:
        assert isinstance('test', PyInfo.string_types)
    assert isinstance('test', PyInfo.text_type)
    assert isinstance(b'test', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, int)
    assert isinstance(1.0, float)
    assert isinstance(1.0, numbers.Real)
    assert type is PyInfo.class_types
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-26 02:55:12.972992
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Ensure expected class variables have been created
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    # Ensure expected class variables have been created
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    # Ensure expected maxsize value has been calculated

# Generated at 2022-06-26 02:55:22.223692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 or p.PY3

    assert type(p.string_types) is tuple
    assert type(p.text_type) is type
    assert type(p.binary_type) is type
    assert type(p.integer_types) is tuple
    assert type(p.class_types) is tuple

    if "__pypy__" in sys.builtin_module_names:
        assert p.PY3
    elif "PyPy" in sys.version:
        assert p.PY2

# Generated at 2022-06-26 02:55:26.051618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)

# Generated at 2022-06-26 02:56:08.415746
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, (int, long))
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)



# Generated at 2022-06-26 02:56:10.776433
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    assert PyInfo.PY3 == (3 == sys.version_info[0])

# Generated at 2022-06-26 02:56:22.639829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

        assert isinstance(PyInfo.maxsize, int)
        assert isinstance(sys.maxsize, int)
    else:  # PY2
        assert PyInfo.string_

# Generated at 2022-06-26 02:56:30.508771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool

    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple

    assert type(PyInfo.maxsize) is int



# Generated at 2022-06-26 02:56:42.801491
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, \
        "Unknow python version."

    if PyInfo.PY2:
        assert isinstance("", str)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(1, int)
        assert isinstance(1, PyInfo.integer_types)
    elif PyInfo.PY3:
        assert isinstance("", bytes)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(1, int)
        assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-26 02:56:48.639866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        del sys.version_info
    except AttributeError:
        sys.version_info = (3, 0, 0, 'final', 0)

    global PyInfo
    PyInfo = imp.reload(PyInfo)
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:56:55.479753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:57:02.543567
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert len(PyInfo.integer_types) == 1
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-26 02:57:11.520020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'b', PyInfo.text_type)
    assert isinstance(b'b', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:57:24.787858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Type(s) defined in the class
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if sys.version_info[0] == 2:
        assert isinstance(PyInfo.string_types, tuple)
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert isinstance(PyInfo.integer_types, tuple)
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long

# Generated at 2022-06-26 02:59:05.464753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, long)
    else:
        assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-26 02:59:07.610591
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-26 02:59:15.928860
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

