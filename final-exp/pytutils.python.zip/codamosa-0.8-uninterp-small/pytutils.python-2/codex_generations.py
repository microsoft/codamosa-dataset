

# Generated at 2022-06-26 02:49:18.872765
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:19.752385
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:49:23.842622
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    if py_info.PY2 is False:
        print("Test case 0 PASSED")
    else:
        print("Test case 0 FAILED")


# Generated at 2022-06-26 02:49:26.209595
# Unit test for constructor of class PyInfo
def test_PyInfo():
    case_0 = test_case_0()
    


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:35.224788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass # construct PyInfo
    # Python 2
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    # Unit test for public instance variable maxsize of class PyInfo
    # Python 2
    assert PyInfo.maxsize == (1 << 31) - 1
    # Python 3
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_

# Generated at 2022-06-26 02:49:36.305478
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:37.389507
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:40.950086
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert isinstance(py_info_0, PyInfo)



# Generated at 2022-06-26 02:49:47.925838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test the case where we pass in a number
    py_info_0 = PyInfo()

    # Test the case where we pass in strings
    py_info_1 = PyInfo()

    # Test the case where we pass in lists of numbers
    py_info_2 = PyInfo()

    # Test the case where we pass in lists of strings
    py_info_3 = PyInfo()

    # Test the case where we pass in lists of lists of numbers
    py_info_4 = PyInfo()

    # Test the case where we pass in lists of lists of strings
    py_info_5 = PyInfo()



# Generated at 2022-06-26 02:49:49.950103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('test_PyInfo ...')

    # Test case 0
    test_case_0()



test_PyInfo()

# Generated at 2022-06-26 02:50:03.164136
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(10, PyInfo.integer_types)

# Generated at 2022-06-26 02:50:08.839180
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert ((PyInfo.PY2 is True) or (PyInfo.PY3 is True))
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.class_types

# Generated at 2022-06-26 02:50:13.238521
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)


# It is just a alias for PyInfo
PY = PyInfo

# Generated at 2022-06-26 02:50:24.090959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    if sys.version_info[0] == 2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(types.ClassType, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

# Generated at 2022-06-26 02:50:32.312618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert ('str' in PyInfo.string_types)
        assert (isinstance('str', PyInfo.string_types))

        assert ('str' not in PyInfo.integer_types)
        assert (isinstance(1, PyInfo.integer_types))

        if sys.platform == 'darwin':
            assert (PyInfo.maxsize == 9223372036854775807)
        else:
            assert (PyInfo.maxsize == 2147483647)  # 32-bit
    else:
        assert (isinstance('str', PyInfo.string_types))
        assert (isinstance('str', PyInfo.text_type))

        assert (isinstance(1, PyInfo.integer_types))

        assert (sys.maxsize == 9223372036854775807)




# Generated at 2022-06-26 02:50:38.846238
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-26 02:50:47.034214
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("> test_PyInfo")
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    print("< test_PyInfo")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:50:51.680423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == (1 << 63) - 1
    elif PyInfo.PY3:
        assert PyInfo.maxsize == (1 << 31) - 1
    else:
        raise ValueError("unsupported version of Python " + sys.version)


test_PyInfo()

# Generated at 2022-06-26 02:50:55.824722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if six.PY2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
    else:
        assert PyInfo.PY3
        assert not PyInfo.PY2

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(six.u('a'), PyInfo.string_types)

# Generated at 2022-06-26 02:51:07.423564
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert not isinstance(b'abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    # assert isinstance(b'abc' , PyInfo.string_types)
    assert isinstance('abc', PyInfo.text_type)
    assert not isinstance(b'abc', PyInfo.text_type)
    assert not isinstance(123, PyInfo.text_type)
    assert not isinstance(123.45, PyInfo.text_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123456789012345678901234567890, PyInfo.integer_types)
   

# Generated at 2022-06-26 02:51:19.258234
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True
    assert PyInfo.maxsize == sys.maxsize
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:28.197228
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for class attribute PY2
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
    else:
        assert PyInfo.PY2 is False

    # Test for class attribute PY3
    if sys.version_info[0] == 3:
        assert PyInfo.PY3 is True
    else:
        assert PyInfo.PY3 is False

    # Test for class attribute string_types
    assert isinstance(PyInfo.string_types, tuple)

    if sys.version_info[0] == 2:
        assert PyInfo.string_types[0] == basestring
    else:
        assert PyInfo.string_types[0] == str

    # Test for class attribute text_type

# Generated at 2022-06-26 02:51:31.719747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize < 2**63


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:39.271432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:48.843266
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # We are always running in Python
    assert PyInfo.PY2 or PyInfo.PY3

    # Correct number of bits and correct maxsize
    if sys.maxsize < (1 << 32):
        assert PyInfo.maxsize == 2147483647
    else:
        assert PyInfo.maxsize == 9223372036854775807

    # Test the string types
    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test".encode("utf-8"), PyInfo.string_types)
    assert not isinstance(5, PyInfo.string_types)

    # Test the text type
    assert isinstance("test", PyInfo.text_type)
    assert not isinstance("test".encode("utf-8"), PyInfo.text_type)

# Generated at 2022-06-26 02:51:51.671200
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        PyInfo()
        assert False
    except TypeError:
        pass

    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.maxsize <= sys.maxsize
    else:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:51:57.272442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert PyInfo.maxsize == (1 << 63) - 1
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-26 02:52:05.242400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    a = PyInfo.string_types
    b = PyInfo.text_type
    c = PyInfo.binary_type
    d = PyInfo.integer_types
    e = PyInfo.class_types
    assert isinstance(a, tuple) is True
    assert isinstance(b, str) is True
    assert isinstance(c, str) is True
    assert isinstance(d, tuple) is True
    assert isinstance(e, tuple) is True



# Generated at 2022-06-26 02:52:07.192763
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(2**64, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:11.026167
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b'\x00', PyInfo.binary_type)
        assert isinstance(u"foo", PyInfo.text_type)
    else:
        assert isinstance(b'\x00', PyInfo.binary_type)
        assert isinstance('\x00', PyInfo.string_types)
        assert isinstance(b'\x00', PyInfo.string_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:52:26.353720
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-26 02:52:32.331166
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert(PyInfo.PY2)
    assert(not PyInfo.PY3)
    assert(PyInfo.string_types == (basestring,))
    assert(PyInfo.text_type == unicode)
    assert(PyInfo.binary_type == str)
    assert(PyInfo.integer_types == (int, long))
    assert(PyInfo.class_types == (type, types.ClassType))



# Generated at 2022-06-26 02:52:36.862331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is not None
    assert info.PY3 is not None
    assert info.string_types is not None
    assert info.text_type is not None
    assert info.binary_type is not None
    assert info.integer_types is not None
    assert info.class_types is not None
    assert info.maxsize is not None



# Generated at 2022-06-26 02:52:45.695239
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize in (1 << 63, 1 << 31)

# Generated at 2022-06-26 02:52:49.889246
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:57.410599
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if isinstance(0, PyInfo.integer_types):
        assert True
    else:
        assert False

    if isinstance(0, PyInfo.class_types):
        assert False
    else:
        assert True

    print()
    print(PyInfo.PY3)
    print(PyInfo.PY2)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:09.462740
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # py2
    str_type = u"Unicode string for python2"
    assert isinstance(str_type, str)
    assert isinstance(str_type, PyInfo.string_types)
    assert not isinstance(str_type, PyInfo.binary_type)

    # py3
    str_type = "Unicode string for python3"
    assert isinstance(str_type, str)
    assert isinstance(str_type, PyInfo.string_types)
    assert not isinstance(str_type, PyInfo.binary_type)

    bin_type = b"Binary string for python3"
    assert isinstance(bin_type, bytes)
    assert isinstance(bin_type, PyInfo.binary_type)
    assert not isinstance(bin_type, PyInfo.string_types)

    num

# Generated at 2022-06-26 02:53:20.343902
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Assert PyInfo.PY2 is True
    assert (PyInfo.PY2 is True)
    # Assert PyInfo.PY3 is False
    assert (PyInfo.PY3 is False)
    # Assert PyInfo.string_types equals (basestring,)
    assert (PyInfo.string_types == (basestring,))
    # Assert PyInfo.text_type equals unicode
    assert (PyInfo.text_type == unicode)
    # Assert PyInfo.binary_type equals str
    assert (PyInfo.binary_type == str)
    # Assert PyInfo.integer_types equals (int, long)
    assert (PyInfo.integer_types == (int, long))
    # Assert PyInfo.class_types equals (type, types.ClassType)

# Generated at 2022-06-26 02:53:27.467388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3
    assert isinstance("", pyinfo.string_types)
    assert isinstance("", pyinfo.text_type)
    assert isinstance(b"", pyinfo.binary_type)
    assert isinstance(1, pyinfo.integer_types)

# Generated at 2022-06-26 02:53:36.485095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=protected-access
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 2:
        assert PyInfo().string_types == (basestring,)
        assert PyInfo().text_type == unicode
        assert PyInfo().binary_type == str
        assert PyInfo().integer_types == (int, long)
        assert PyInfo().class_types == (type, types.ClassType)

        assert PyInfo.string_types == (basestring,)

# Generated at 2022-06-26 02:53:58.661138
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == sys.maxsize
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-26 02:54:02.324540
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:54:12.883388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3

    if py2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == sys.maxsize
    elif py3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:54:22.911498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 << 32, PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(types.ClassType, PyInfo.class_types)


# Generated at 2022-06-26 02:54:25.501560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X(object):
        pass
    assert isinstance("1", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(X(), PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(X(), object)

# Generated at 2022-06-26 02:54:29.645679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.class_types

# Generated at 2022-06-26 02:54:35.716556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version[0] == '2')
    assert PyInfo.PY3 == (sys.version[0] == '3')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:54:38.934124
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # https://stackoverflow.com/questions/43800616/python-type-checking
    import doctest
    doctest.testmod()


# test_PyInfo()

# Generated at 2022-06-26 02:54:49.929870
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2: %s" % PyInfo.PY2)
    print("PY3: %s" % PyInfo.PY3)
    print("maxsize: %d" % PyInfo.maxsize)
    print("text_type: %s" % PyInfo.text_type)
    print("binary_type: %s" % PyInfo.binary_type)
    print("string_types: %s" % PyInfo.string_types)
    print("integer_types: %s" % PyInfo.integer_types)
    print("class_types: %s" % PyInfo.class_types)



# Generated at 2022-06-26 02:55:01.185235
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print("maxsize: ", PyInfo.maxsize)
    # Output:
    # False
    # True
    # (<class 'str'>,) <class 'str'> <class 'bytes'> (<class 'int'>,) (<class 'type'>,)
    # maxsize:  9223372036854775807


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:51.565358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:02.821012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(unicode(""), PyInfo.text_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:13.195348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize == 9223372036854775807

    # PY3
    assert PyInfo.PY2 == False
    assert PyInfo.PY3 == True


# Generated at 2022-06-26 02:56:20.574529
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.string_types[0]) is str
    # assert type(PyInfo.text_type) is str
    # assert type(PyInfo.binary_type) is bytes
    assert type(PyInfo.integer_types[0]) is int
    assert type(PyInfo.class_types[0]) is type
    # assert type(PyInfo.maxsize) is int


# Unit test this file

# Generated at 2022-06-26 02:56:28.438502
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from datetime import datetime

    assert isinstance(datetime.now(), object)
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:32.739847
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(5, PyInfo.integer_types)
    assert not isinstance(5.5, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-26 02:56:43.010025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):
        def test_PyInfo(self):
            self.assertEqual(
                PyInfo.text_type,
                str if PyInfo.PY3 else unicode
            )
            self.assertEqual(
                PyInfo.binary_type,
                bytes if PyInfo.PY3 else str
            )

    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(TestPyInfo))

    # Run the test
    unittest.TextTestRunner(verbosity=2).run(suite)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:48.818178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, (int, long))
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.integer_types, tuple)
    elif PyInfo.PY3:
        assert isinstance(PyInfo.maxsize, int)
        assert isinstance(PyInfo.class_types, type)
        assert isinstance(PyInfo.integer_types, type)
    else:
        assert False, "What kind of Python version is this?"

# Generated at 2022-06-26 02:56:55.497782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:57:04.453327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert 'str' in PyInfo.string_types
    assert 'unicode' in PyInfo.string_types
    assert PyInfo.text_type == 'str'
    assert PyInfo.binary_type == 'bytes'
    assert (1 or 2) in PyInfo.integer_types

# Generated at 2022-06-26 02:58:50.884602
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:59:00.727440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance(u"abc", PyInfo.text_type)
    assert isinstance("abc", PyInfo.binary_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:59:08.844611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import sysconfig

    # Check sys.version_info
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if PyInfo.PY2:
        # Check Python 2
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert isinstance(PyInfo.integer_types[0], int)
        assert isinstance(PyInfo.integer_types[1], long)

# Generated at 2022-06-26 02:59:15.661659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()