

# Generated at 2022-06-26 02:49:22.530054
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()
    # Test Exception here
    try:
        raise TypeError
    except:
        print('Type Error Exception Caught')
    try:
        raise NotImplementedError
    except:
        print('Not Implemented Error Exception Caught')
    try:
        raise StopIteration
    except:
        print('Stop Iteration Exception Caught')
    return 0

print('Testing PyInfo class')
test_PyInfo()

# Generated at 2022-06-26 02:49:25.016074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # TODO: Constructor test for class PyInfo
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:30.686309
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        print("")
        print("Running test test_PyInfo(TestPyInfo)...")
        print("")
        test_case_0()
        print("")
        print("passed all tests for PyInfo")
        print("")
    except:
        print("")
        print("failed one or more tests for PyInfo")
        print("")
        raise


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:32.639798
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

if __name__ == '__main__':
    test_PyInfo()
    print("PASS")

# Generated at 2022-06-26 02:49:33.772888
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:34.549623
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()


# Generated at 2022-06-26 02:49:39.532922
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False
    assert py_info_0.string_types == (basestring,)
    assert py_info_0.text_type == unicode
    assert py_info_0.binary_type == str
    assert py_info_0.integer_types == (int, long)
    assert py_info_0.class_types == (type, types.ClassType)
    assert py_info_0.maxsize == 2147483647

# Generated at 2022-06-26 02:49:43.065448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing PyInfo constructor.")

    py_info_0 = PyInfo()

if __name__=="__main__":
    test_PyInfo()
    print("All simple test cases passed.")

# Generated at 2022-06-26 02:49:44.356769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:49:45.405037
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

#test_case_0()

# Generated at 2022-06-26 02:49:51.997215
# Unit test for constructor of class PyInfo
def test_PyInfo():
   py_info_0 = PyInfo()
   assert py_info_0 is not None


# Generated at 2022-06-26 02:49:55.665774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        test_case_0()
    
    except Exception as exception:
        print('Failed!')
        print(exception)
            
    else:
        print('Passed!')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:49:57.226526
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
   
test_PyInfo()

# Generated at 2022-06-26 02:49:59.748660
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2
    assert not py_info_0.PY3



# Generated at 2022-06-26 02:50:02.043614
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:50:12.289129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    assert py_info_0.PY2 == py_info_1.PY2
    assert py_info_0.PY3 == py_info_1.PY3
    assert py_info_0.string_types == py_info_1.string_types
    assert py_info_0.text_type == py_info_1.text_type
    assert py_info_0.binary_type == py_info_1.binary_type
    assert py_info_0.integer_types == py_info_1.integer_types
    assert py_info_0.class_types == py_info_1.class_types
    assert py_info_0.maxsize == py_info_1.maxsize

# Generated at 2022-06-26 02:50:15.555959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info_0 =  PyInfo()
    except Exception as e:
        assert False, "Exception when creating object: " + str(e)
    else:
        assert True


# Generated at 2022-06-26 02:50:17.752780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Calls the constructor of class PyInfo,
    # to check if it reacts as expected.
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:26.297057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # Checking PY2
    assert py_info.PY2 == 0
    # Checking PY3
    assert py_info.PY3 == 0
    # Checking maxsize
    assert py_info.maxsize == 0
    # Checking string_types
    assert py_info.string_types == 0
    # Checking text_type
    assert py_info.text_type == 0
    # Checking binary_type
    assert py_info.binary_type == 0
    # Checking integer_types
    assert py_info.integer_types == 0
    # Checking class_types
    assert py_info.class_types == 0

# Generated at 2022-06-26 02:50:27.262011
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

test_PyInfo()

# Generated at 2022-06-26 02:50:37.665565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# Generated at 2022-06-26 02:50:47.067463
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_2 = PyInfo()
    py_info_2.PY2
    py_info_2.PY3
    py_info_2.string_types
    py_info_2.text_type
    py_info_2.binary_type
    py_info_2.integer_types
    py_info_2.class_types
    py_info_2.maxsize


if __name__ == "__main__":
    test_case_0()
    test_PyInfo()

# Generated at 2022-06-26 02:50:49.673380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info = PyInfo()
    except Exception as e:
        print("Test PyInfo error")
        raise e

# Generated at 2022-06-26 02:50:52.548449
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        py_info_0 = PyInfo()
        py_info_0 = PyInfo()
        py_info_0 = PyInfo()
        py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:55.777062
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Inside test_PyInfo')
    assert py_info_0.PY2 == True
    assert py_info_0.PY3 == False

# Generated at 2022-06-26 02:50:59.487278
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test constructor with valid parameters
    a = PyInfo()


# Execute unit test
test_case_0()
test_PyInfo()

# Generated at 2022-06-26 02:51:02.244251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("*"*50)
    print("test_PyInfo")

    test_case_0()

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:04.898461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    py_info_1 = PyInfo()
    
    


#Unit test for constant attribute for class PyInfo

# Generated at 2022-06-26 02:51:13.290887
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        # Unit test for constructor of class PyInfo
        py_info_0 = PyInfo()
    except Exception as e:
        assert 1==0



# Generated at 2022-06-26 02:51:14.926747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p_0 = PyInfo()


# Generated at 2022-06-26 02:51:26.209502
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert str(info.PY2) == 'True'
    assert str(info.PY3) == 'False'

# Generated at 2022-06-26 02:51:28.495185
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type(), PyInfo.text_type)
    assert isinstance(PyInfo.binary_type(), PyInfo.binary_type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:51:39.836968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    for item in PyInfo.string_types:
        assert isinstance(item, type)

    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    for item in PyInfo.integer_types:
        assert isinstance(item, type)

    assert isinstance(PyInfo.class_types, tuple)
    for item in PyInfo.class_types:
        assert isinstance(item, type)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:51:44.580796
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2, 'Error: run this unit test in Python 3 environment'
    assert PyInfo.PY3, 'Error: run this unit test in Python 3 environment'
    assert PyInfo.maxsize == 9223372036854775807, 'Error: maxsize should be 2^63 -1'


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:49.090881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == string_types
    assert PyInfo.text_type == text_type
    assert PyInfo.binary_type == binary_type
    assert PyInfo.integer_types == integer_types
    assert PyInfo.class_types == class_types



# Generated at 2022-06-26 02:51:51.336254
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type == unicode
    assert PyInfo.string_types == (basestring, unicode)

# Generated at 2022-06-26 02:51:53.835859
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types

# Generated at 2022-06-26 02:51:57.488100
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert pyinfo.maxsize is sys.maxsize

# Generated at 2022-06-26 02:52:08.394115
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )

        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:52:17.557570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Type check
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert all(map(lambda item: isinstance(item, type), PyInfo.string_types))

    assert isinstance(PyInfo.class_types, tuple)
    assert all(map(lambda item: isinstance(item, type), PyInfo.class_types))

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.maxsize, int)

    # Value check
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)

# Generated at 2022-06-26 02:52:48.472712
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p1 = PyInfo()
    assert p1.PY2 is sys.version_info[0] == 2
    assert p1.PY3 is sys.version_info[0] == 3
    assert p1.string_types == (basestring,)
    assert p1.string_types == (str,)
    assert p1.string_types == (str,)
    assert p1.text_type == (unicode,)
    assert p1.text_type == (str,)
    assert p1.binary_type == (str,)
    assert p1.binary_type == (bytes,)
    assert p1.integer_types == (int, long)
    assert p1.integer_types == (int,)
    assert p1.class_types == (type, types.ClassType)

# Generated at 2022-06-26 02:52:59.855617
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-26 02:53:06.830042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY3 is not True or PyInfo.PY2 is not True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:53:18.313132
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2

    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

    try:
        n = PyInfo.maxsize + 1
    except OverflowError:
        pass
    else:
        assert 0, n


#--------------------
# The following code is copy from six.py
#--------------------

# Generated at 2022-06-26 02:53:30.385575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def get_version_info():
        return sys.version_info

    def get_string_types():
        return str,

    def get_text_type():
        return str

    def get_binary_type():
        return bytes

    def get_integer_types():
        return int,

    def get_class_types():
        return type,

    def get_maxsize():
        return sys.maxsize

    if sys.version_info[0] == 2:
        expected_version_info = get_version_info()
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert expected_version_info[0] == 2

        expected_string_types = get_string_types()
        assert PyInfo.string_types == expected_string_types

        expected_text_type = get_text

# Generated at 2022-06-26 02:53:34.339822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance(sys.maxsize, int)



# Generated at 2022-06-26 02:53:38.398957
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:53:50.244913
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo
    assert obj.PY2 or obj.PY3, "PY2 or PY3 should be True"
    assert obj.string_types, "string_types should not be empty"
    assert obj.text_type, "text_type should not be empty"
    assert obj.binary_type, "binary_type should not be empty"
    assert obj.integer_types, "integer_types should not be empty"
    assert obj.class_types, "class_types should not be empty"
    assert isinstance(obj.maxsize, int), "maxsize should be integer"


# pylint: disable=exec-used
for name in dir(PyInfo):
    if name.isupper():
        exec("{} = PyInfo.{}".format(name, name))

# Generated at 2022-06-26 02:54:00.987104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    False
    >>> PyInfo.PY3
    True
    >>> PyInfo.string_types
    (<class 'str'>,)
    >>> PyInfo.text_type
    <class 'str'>
    >>> PyInfo.binary_type
    <class 'bytes'>
    >>> PyInfo.integer_types
    (<class 'int'>,)
    >>> PyInfo.class_types
    (<class 'type'>,)
    >>> PyInfo.maxsize
    9223372036854775807
    """
    pass


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    pass

# Generated at 2022-06-26 02:54:08.720972
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type(PyInfo.maxsize) is int
        assert PyInfo.maxsize < 2147483647
    else:
        assert type(PyInfo.maxsize) is int
        assert PyInfo.maxsize >= 2147483647


if __name__ == "__main__":
    sys.exit(unittest.main())

# Generated at 2022-06-26 02:54:50.563340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-26 02:54:58.680706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.text_type)
    assert isinstance("str", PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(10, PyInfo.class_types)

# Generated at 2022-06-26 02:55:01.929918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.string_types == (basestring, unicode)

    # Check if maxsize is the same as sys.maxsize
    assert PyInfo.maxsize == sys.maxsize


# Tests for other modules
test_PyInfo()

# Generated at 2022-06-26 02:55:08.268923
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:15.254693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert isinstance('abc', str)
        assert isinstance(b'abc', bytes)
        assert not isinstance('abc', bytes)
        assert not isinstance(b'abc', str)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert isinstance('abc', basestring)
        assert isinstance(b'abc', basestring)
        assert not isinstance('abc', types.StringType)
        assert not isinstance(b'abc', types.StringType)
        assert not isinstance('abc', types.UnicodeType)
        assert not isinstance(b'abc', types.UnicodeType)
    assert PyInfo.text_type == str

# Generated at 2022-06-26 02:55:25.149329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert sys.version_info[0] == PyInfo.PY2 or sys.version_info[0] == PyInfo.PY3
    if sys.version_info[0] == 3:
        assert isinstance(PyInfo.string_types[0], str)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types[0], int)
        assert isinstance(PyInfo.class_types[0](), type)

        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.string_types[0], basestring)
        assert isinstance(PyInfo.text_type, unicode)

# Generated at 2022-06-26 02:55:29.326648
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert 'str' in PyInfo.string_types
    assert 'unicode' in PyInfo.string_types
    assert 'bytes' in PyInfo.string_types
    assert 'int' in PyInfo.integer_types
    assert 'long' in PyInfo.integer_types


# Test for function type_name

# Generated at 2022-06-26 02:55:31.584164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY2 is False

# Generated at 2022-06-26 02:55:34.182503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:55:41.146657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:57:07.276226
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_p = PyInfo()
    assert test_p.PY2 is True or test_p.PY2 is False
    assert test_p.PY3 is True or test_p.PY3 is False

    if test_p.PY3:
        assert isinstance(test_p.string_types, tuple)
        assert test_p.string_types == (str,)
        assert isinstance(test_p.text_type, type)
        assert test_p.text_type == str
        assert isinstance(test_p.binary_type, type)
        assert test_p.binary_type is bytes
        assert isinstance(test_p.integer_types, tuple)
        assert test_p.integer_types == (int,)
        assert isinstance(test_p.class_types, tuple)
        assert test

# Generated at 2022-06-26 02:57:19.486601
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type is not PyInfo.binary_type

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    # sanity check for maxsize
    if PyInfo.PY3:
        assert PyInfo.maxsize > (1 << 32)
    elif sys.platform.startswith("java"):
        assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-26 02:57:25.344194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False


if PyInfo.PY3:
    def u(x):
        return x

else:

    def u(x):
        if isinstance(x, PyInfo.binary_type):
            return PyInfo.text_type(x, "utf-8")
        if isinstance(x, PyInfo.text_type):
            return x
        rai

# Generated at 2022-06-26 02:57:35.021458
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    if sys.version_info < (2, 7):
        from unittest2 import TestCase
    else:
        from unittest import TestCase

    class TestPyInfo(TestCase):
        def test_py2(self):
            if sys.version_info[0] == 2:
                self.assertTrue(PyInfo.PY2)
                self.assertFalse(PyInfo.PY3)
            else:
                self.assertTrue(PyInfo.PY3)
                self.assertFalse(PyInfo.PY2)

    TestPyInfo.run()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:57:46.561669
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # PY3
    if sys.version_info[0] == 3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance('str', PyInfo.string_types)
        assert isinstance('str', PyInfo.text_type)
        assert isinstance(b'bytes', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(True, bool)

# Generated at 2022-06-26 02:57:57.163265
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert not isinstance(True, PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance(True, PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)


# Generated at 2022-06-26 02:58:07.476706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('asdf', PyInfo.string_types)
        assert isinstance(b'asdf', PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
        assert isinstance(list, PyInfo.class_types)
    else:
        assert isinstance('asdf', PyInfo.string_types)
        assert isinstance(u'asdf', PyInfo.text_type)
        assert isinstance(b'asdf', PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
        assert isinstance(list, PyInfo.class_types)
        assert isinstance(types.ClassType, PyInfo.class_types)


# Generated at 2022-06-26 02:58:17.492362
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 is True or PyInfo().PY3 is True
    assert PyInfo().text_type == basestring if PyInfo().PY2 else str
    assert PyInfo().binary_type == str if PyInfo().PY2 else bytes
    if PyInfo().PY2:
        assert isinstance(1, PyInfo().integer_types) is True
        assert isinstance(1, PyInfo().string_types) is True
    else:
        assert isinstance(1, PyInfo().integer_types) is True
        assert isinstance(1, PyInfo().string_types) is False
    assert PyInfo().maxsize is not None


# Provides a shortcut to the constructor of class PyInfo

# Generated at 2022-06-26 02:58:26.912571
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test parameters
    a = PyInfo()

    # Check parameters
    if a.PY2:
        assert a.PY3 == False
        assert a.text_type == unicode
        assert a.binary_type == str
        assert a.integer_types == (int, long)
        assert a.class_types == (type, types.ClassType)
    else:
        assert a.PY3 == True
        assert a.text_type == str
        assert a.binary_type == bytes
        assert a.integer_types == (int,)
        assert a.class_types == (type,)

# Generated at 2022-06-26 02:58:36.155302
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int