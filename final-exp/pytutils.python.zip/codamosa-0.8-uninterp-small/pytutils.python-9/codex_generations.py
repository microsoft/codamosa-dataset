

# Generated at 2022-06-26 02:49:20.317481
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if the following lines raise an exception or not
    try:
        PyInfo()
    except Exception as e:
        assert False, "Constructor of class 'PyInfo' raised an exception: " + str(e)



# Generated at 2022-06-26 02:49:21.774843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()



# Generated at 2022-06-26 02:49:25.195714
# Unit test for constructor of class PyInfo

# Generated at 2022-06-26 02:49:28.151183
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # input parameter
    # expected output

    py_info_0 = PyInfo()
    py_info_1 = PyInfo()

    # Testing if py_info_0 == py_info_1



# Generated at 2022-06-26 02:49:29.034327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:49:30.189881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()



# Generated at 2022-06-26 02:49:31.475971
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # py_info = PyInfo()
    pass


# Generated at 2022-06-26 02:49:33.797494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing class PyInfo")
    test_case_0()
    print("All test cases passed")

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:34.934036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Module level function


# Generated at 2022-06-26 02:49:36.003256
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()


# Generated at 2022-06-26 02:49:43.067624
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo
    print(pi.PY2, pi.PY3, pi.string_types, pi.text_type, pi.binary_type, pi.integer_types,
          pi.class_types, pi.maxsize)



# Generated at 2022-06-26 02:49:50.194820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo().PY2:
        assert type("abc") == str
        assert type("abc") == PyInfo().text_type
        assert type("abc") != PyInfo().binary_type
        assert type("abc") != PyInfo().string_types

        assert type("abc") != PyInfo().integer_types
        assert type("abc") != PyInfo().class_types

        assert type("abc") != PyInfo().integer_types
        assert type("abc") != PyInfo().class_types

        assert type("abc") != PyInfo().integer_types
        assert type("abc") != PyInfo().class_types

        assert type("abc") != PyInfo().integer_types
        assert type("abc") != PyInfo().class_types

        assert sys.maxsize == PyInfo().maxsize



# Generated at 2022-06-26 02:50:00.745998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert not isinstance(u'a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert not isinstance('a', PyInfo.text_type)
        assert isinstance('a', PyInfo.binary_type)
        assert not isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:50:09.810811
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert isinstance(PyInfo.binary_type, type)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


pyinfo = PyInfo()

# Generated at 2022-06-26 02:50:12.931411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3
    if pyinfo.PY2:
        assert type(u'xx') == pyinfo.text_type
    else:
        assert type('xx') == pyinfo.text_type



# Generated at 2022-06-26 02:50:18.179223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    import sys
    import nose

    argv = sys.argv[:]
    argv.append("--verbose")
    argv.append("--nocapture")
    nose.main(argv=argv, defaultTest=__file__)

# Generated at 2022-06-26 02:50:28.652454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(u"", PyInfo.string_types)
    if PyInfo.PY2:  # pragma: no cover
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
    else:  # pragma: no cover
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(0, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo

# Generated at 2022-06-26 02:50:39.068908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from datetime import datetime

    print("Python version is {}.{}.{}".format(*sys.version_info))
    assert PyInfo.PY2 is not True or PyInfo.PY3 is not True
    assert isinstance("", PyInfo.string_types) is True
    assert isinstance(u"", PyInfo.string_types) is True
    assert isinstance(b"", PyInfo.binary_type) is True
    assert isinstance(b"", PyInfo.string_types) is False
    assert isinstance(1, PyInfo.integer_types) is True

# Generated at 2022-06-26 02:50:50.771578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == False
    assert PyInfo.PY2 == True
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 9223372036854775807


if __name__ == "__main__":
    test_PyInfo()
    print("OK")

# Generated at 2022-06-26 02:50:52.876001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert pyinfo.PY2 is not pyinfo.PY3

# Generated at 2022-06-26 02:51:02.710857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> from pyskip.pyskip.utils.pyinfo import PyInfo
    >>> info = PyInfo()
    >>> assert info is not None
    >>> assert info.PY2 or info.PY3
    >>> assert info.maxsize is not None
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:51:12.908843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    if PyInfo.PY2:
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == max(sys.maxsize, sys.maxint)
    else:
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_

# Generated at 2022-06-26 02:51:24.179369
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import six

    # what type of Python?
    assert PyInfo.PY3 or PyInfo.PY2

    # string_types tests
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)

    if PyInfo.PY3:
        assert not isinstance(b"", six.string_types)
        assert isinstance("", six.string_types)
    else:
        assert isinstance(b"", six.string_types)
        assert isinstance("", six.string_types)

    # text_type tests
    assert isinstance("", PyInfo.text_type)
    if PyInfo.PY3:
        assert not isinstance(b"", PyInfo.text_type)
        assert not isinstance(b"", six.text_type)

# Generated at 2022-06-26 02:51:29.847745
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


# Generated at 2022-06-26 02:51:37.972325
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    print("Python version: %d.%d.%d" % sys.version_info[:3])
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:48.022034
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert(PyInfo.string_types == (str,))
        assert(PyInfo.text_type == str)
        assert(PyInfo.binary_type == bytes)
        assert(PyInfo.integer_types == (int,))
        assert(PyInfo.class_types == (type,))
    else:
        assert(PyInfo.string_types == (basestring,))
        assert(PyInfo.text_type == unicode)
        assert(PyInfo.binary_type == str)
        assert(PyInfo.integer_types == (int, long))
        assert(PyInfo.class_types == (type, types.ClassType))


PY2 = PyInfo.PY2
PY3 = PyInfo.PY3

string_types = PyInfo.string_types


# Generated at 2022-06-26 02:51:55.886745
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])
    if basename.endswith(".py"):
        cmd = ["pytest", "--cov", basename[:-3], "--cov-report", "term-missing"]
        os.execvp("pytest", cmd)
    elif basename == "pytest":
        print("Testing pytest_minver ...")

# Generated at 2022-06-26 02:52:00.126853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.class_types
    assert PyInfo.binary_type



# Generated at 2022-06-26 02:52:10.257740
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class PyInfoTest(object):

        def __init__(self):
            self.string_types = (str, unicode)
            self.text_types = (unicode,)
            self.binary_types = (str,)
            self.integer_types = (int, long)
            self.maxsize = int((1 << 63) - 1)

    if PyInfo.PY3:
        assert PyInfo.string_types == PyInfoTest.string_types
        assert PyInfo.text_type == PyInfoTest.text_types
        assert PyInfo.binary_type == PyInfoTest.binary_types
        assert PyInfo.integer_types == PyInfoTest.integer_types
        assert PyInfo.maxsize == PyInfoTest.maxsize

# Generated at 2022-06-26 02:52:19.527827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert "foo" in PyInfo.string_types
    assert u"foo" in PyInfo.string_types

    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.string_types)

    assert isinstance("foo", PyInfo.text_type)
    assert not isinstance(u"foo", PyInfo.text_type)

    assert isinstance("foo", PyInfo.binary_type)
    assert not isinstance(b"foo", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(1 << 63, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:37.484923
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)

        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)

        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(type(object), PyInfo.class_types)

    else:  # PY2
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)


# Generated at 2022-06-26 02:52:46.680848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:58.586042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(2, PyInfo.integer_types)
        assert isinstance(long(2), PyInfo.integer_types)
        assert isinstance(type(1), PyInfo.class_types)
    elif PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(2, PyInfo.integer_types)
        assert isinstance(type(1), PyInfo.class_types)
    else:
        raise Exception("Unknown Python version")

# Generated at 2022-06-26 02:53:09.701839
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2_string_types = basestring,
    py2_integer_types = (int, long)
    py2_class_types = (type, types.ClassType)

    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == 2147483647
    assert PyInfo.string_types == py2_string_types
    assert PyInfo.integer_types == py2_integer_types
    assert PyInfo.class_types == py2_class_types

    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, unicode)
    assert isinstance(PyInfo.binary_type, str)


if __name__ == "__main__":
    print(PyInfo.PY2)

# Generated at 2022-06-26 02:53:13.164469
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:20.899418
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"str", PyInfo.string_types)
    assert isinstance(u"str", PyInfo.text_type)
    assert isinstance("str", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance(int, PyInfo.class_types)
    else:  # PyInfo.PY2
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(types.ClassType, PyInfo.class_types)



# Generated at 2022-06-26 02:53:32.397694
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-26 02:53:39.824635
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from . import PyInfo

    assert PyInfo.PY2 or PyInfo.PY3

    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)

    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)

    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)

    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.binary_type)



# Generated at 2022-06-26 02:53:47.204060
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3

# Generated at 2022-06-26 02:53:52.206329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.string_types
    assert PyInfo.integer_types
    assert PyInfo.class_types


if PyInfo.PY3:
    def u(s):
        return s

    def b(s):
        return s.encode("latin-1")

    def unichr(s):
        return chr(s)


else:
    def u(s):
        return unicode(s, "unicode_escape")

    def b(s):
        return s

    unichr = unichr


BOM_UTF8 = b("\xef\xbb\xbf")
BOM_UTF16_LE = b("\xff\xfe")
BOM_UTF16_BE = b("\xfe\xff")

# Generated at 2022-06-26 02:54:14.157968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == ((1 << 63) - 1)

# Generated at 2022-06-26 02:54:22.046248
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.binary_type == bytes
        assert PyInfo.text_type == str
        assert PyInfo.integer_types == (int,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.binary_type == str
        assert PyInfo.text_type == unicode
        assert PyInfo.integer_types == (int, long)


test_PyInfo()



# Generated at 2022-06-26 02:54:32.300368
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.class_types)
    else:  # PY2
        assert isinstance('', PyInfo.string_types)

# Generated at 2022-06-26 02:54:35.263955
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(2, PyInfo.integer_types)
    assert not isinstance("2", PyInfo.integer_types)



# Generated at 2022-06-26 02:54:40.477988
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert type("abc") in PyInfo.string_types
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:54:49.728282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(u'', PyInfo.text_type)


test_PyInfo()

# Generated at 2022-06-26 02:54:56.524883
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2
    assert not info.PY3

    info = PyInfo()
    assert not info.PY2
    assert info.PY3


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-26 02:55:00.479131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Do not need to write unit tests for all types, only one type is needed,
    # because all types will be the same class and pass the test.
    assert isinstance("string", PyInfo.string_types)
    assert isinstance("string", PyInfo.string_types)
    assert isinstance("string", PyInfo.text_type)
    assert isinstance("string", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-26 02:55:12.298935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY2 is True
    for stype in PyInfo.string_types:
        assert isinstance('str', stype)
    for itype in PyInfo.integer_types:
        assert isinstance(1, itype)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance('str', PyInfo.text_type)
    assert isinstance(int, PyInfo.class_types)
    if PyInfo.PY2:
        assert isinstance(types.ClassType, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:55:15.852534
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:56:03.536770
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)
    assert isinstance('a', PyInfo().string_types)
    assert isinstance(u'a', PyInfo().string_types)
    assert not isinstance(b'a', PyInfo().string_types)
    assert isinstance(b'a', PyInfo().binary_type)
    assert isinstance(3, PyInfo().integer_types)
    assert not isinstance(3, PyInfo().class_types)
    assert isinstance(int, PyInfo().class_types)

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:11.085513
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:22.770509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)
        assert not isinstance(1, PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.binary_type)
        assert not isinstance(1, PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:30.827244
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('s', PyInfo.string_types)
    assert isinstance(u't', PyInfo.text_type)
    assert isinstance(b'x', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:56:40.960897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance('a', PyInfo.string_types) is True
    assert isinstance('a'.encode(), PyInfo.binary_type) is True
    assert isinstance(12, PyInfo.integer_types) is True
    assert isinstance(12, PyInfo.integer_types) is True
    assert isinstance(object, PyInfo.class_types) is True
    assert isinstance(Exception, PyInfo.class_types) is True
    assert isinstance(RuntimeError, PyInfo.class_types) is True

# Generated at 2022-06-26 02:56:53.197461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert isinstance('a string', PyInfo.string_types)
        assert isinstance(b'a string', PyInfo.binary_type)
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(float, PyInfo.class_types)
    else:  # Python 2
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert isinstance(u'a string', PyInfo.string_types)
        assert isinstance(u'a string', PyInfo.text_type)

# Generated at 2022-06-26 02:57:05.016498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:57:12.932285
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:57:25.370998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test for constructor of class PyInfo
    """

    def test_for_python_version(py_info_instance, exp_py_ver):
        """
        Test for python version
        """
        if py_info_instance.PY2:
            assert exp_py_ver == 2
        else:
            assert exp_py_ver == 3

    def test_for_string_types(py_info_instance):
        """
        Test for string types
        """
        assert isinstance(py_info_instance.string_types, tuple)

        i = 0
        while i < len(py_info_instance.string_types):
            assert isinstance(py_info_instance.string_types[i], type)
            i += 1


# Generated at 2022-06-26 02:57:33.521696
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.string_types)
    assert isinstance(b"foo", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:59:16.607868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.1, float)
    assert isinstance(True, bool)
    assert isinstance(None, type(None))
    assert isinstance(lambda x: x + 1, types.LambdaType)
    _class = type('TestClass', (object,), {})
    assert isinstance(_class, types.TypeType)
    if PyInfo.PY2:
        assert isinstance(_class, PyInfo.class_types)
