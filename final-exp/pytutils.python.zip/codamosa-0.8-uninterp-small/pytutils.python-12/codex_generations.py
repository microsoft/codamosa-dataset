

# Generated at 2022-06-26 02:49:29.089083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    py_info_1 = PyInfo()
    py_info_2 = PyInfo()
    py_info_3 = PyInfo()
    py_info_4 = PyInfo()
    assert py_info_0 == py_info_1
    assert py_info_0 != py_info_2
    assert py_info_0 != py_info_3
    assert py_info_0 != py_info_4
    assert type(py_info_0) == type(py_info_1)
    assert type(py_info_0) != type(py_info_2)
    assert type(py_info_0) != type(py_info_3)
    assert type(py_info_0) != type(py_info_4)


# Generated at 2022-06-26 02:49:31.348743
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''!
    @brief Unit test for constructor of class PyInfo
    '''
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:49:34.479043
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

if __name__ == "__main__":
    g = globals()
    for k, v in g.items():
        if k.startswith("test_") and hasattr(v, "__call__"):
            v()

# Generated at 2022-06-26 02:49:39.683706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == 2
    assert py_info_0.PY3 == 3
    assert py_info_0.string_types == (str,)
    assert py_info_0.text_type == str
    assert py_info_0.binary_type == bytes
    assert py_info_0.integer_types == (int,)
    assert py_info_0.class_types == (type,)
    assert py_info_0.maxsize == sys.maxsize
    del py_info_0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:41.183297
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()


# Generated at 2022-06-26 02:49:42.342006
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:49:47.692044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    py_info_1.PY2
    py_info_1.PY3
    py_info_1.string_types
    py_info_1.text_type
    py_info_1.binary_type
    py_info_1.integer_types
    py_info_1.class_types
    py_info_1.maxsize
# This method is for generating testable code in unit test.

# Generated at 2022-06-26 02:49:49.907666
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        py_info_0 = PyInfo()
    except Exception as e:
        assert False, 'Did not catch exception in constructor of class PyInfo'

# Generated at 2022-06-26 02:50:00.191901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check the value of attribute PY2
    assert(PyInfo.PY2 != PyInfo.PY3)
    # Check the value of attribute PY3
    assert(PyInfo.PY3 == PyInfo.PY3)
    # Check the types of attribute string_types
    assert(isinstance(PyInfo.string_types, tuple))
    # Check the types of attribute text_type
    assert(issubclass(PyInfo.text_type, object))
    # Check the types of attribute binary_type
    assert(issubclass(PyInfo.binary_type, object))
    # Check the types of attribute integer_types
    assert(isinstance(PyInfo.integer_types, tuple))
    # Check the types of attribute class_types
    assert(isinstance(PyInfo.class_types, tuple))
    # Check the

# Generated at 2022-06-26 02:50:11.128720
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert py_info.maxsize == int((1 << 31) - 1)
    else:
        try:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):
                def __len__(self):
                    return 1 << 31

            len(X())
            # 32-bit
            assert py_info.maxsize == int((1 << 31) - 1)
            del X
        except OverflowError:
            # 64-bit
            assert py_info

# Generated at 2022-06-26 02:50:17.581043
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_1 = PyInfo()
    assert isinstance(py_info_1, PyInfo)


# Generated at 2022-06-26 02:50:26.896628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 is False
    assert py_info_0.PY3 is True
    assert py_info_0.string_types == (str,)
    assert py_info_0.text_type == str
    assert py_info_0.binary_type == bytes
    assert py_info_0.integer_types == (int,)
    assert py_info_0.class_types == (type,)
    assert py_info_0.maxsize == sys.maxsize


if __name__ == '__main__':
    print(sys.version_info)
    test_case_0()
    test_PyInfo()

# Generated at 2022-06-26 02:50:28.608171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def constructor_0():
        # Test if constructor is working
        assert PyInfo()



# Generated at 2022-06-26 02:50:29.716934
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:30.860549
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Run tests that are also in class PyInfo
    test_case_0()



# Generated at 2022-06-26 02:50:33.329344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:50:34.937983
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('test_PyInfo')


# Generated at 2022-06-26 02:50:42.226053
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # test case for string_types
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
    else: # PY2
        assert PyInfo.string_types == (basestring,)

    # test case for text_type
    if PyInfo.PY3:
        assert PyInfo.text_type == str
    else: # PY2
        assert PyInfo.text_type == unicode

    # test case for binary_type
    if PyInfo.PY3:
        assert PyInfo.binary_type == bytes
    else: # PY2
        assert PyInfo.binary_type == str

    # test case for integer_types
    if PyInfo.PY3:
        assert PyInfo.integer_types == (int,)

# Generated at 2022-06-26 02:50:51.680281
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    py_info = PyInfo()
    if py_info.PY2:
        assert py_info.string_types == (basestring,)
        assert py_info.integer_types == (int, long)
        assert py_info.class_types == (type, types.ClassType)
    else:
        assert py_info.string_types == (str,)
        assert py_info.integer_types == (int,)
        assert py_info.class_types == (type,)

if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-26 02:50:53.092603
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_PyInfo_0 = PyInfo()
    print("Test passed")


# Generated at 2022-06-26 02:51:02.710811
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestCase(unittest.TestCase):

        def test(self):
            assert PyInfo.PY3 if sys.version_info[0] == 3 else PyInfo.PY2
            assert "PyInfo" in repr(PyInfo)

    unittest.main()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:08.486586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("123", PyInfo.string_types)
    assert isinstance(u"123", PyInfo.string_types)
    assert isinstance(b"123", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(long(123), PyInfo.integer_types)
    assert isinstance(str, PyInfo.class_types)

# Generated at 2022-06-26 02:51:12.340288
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    >>> import sys
    >>> sys.version_info[0]
    2
    '''
    return


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:51:14.689408
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False



# Generated at 2022-06-26 02:51:17.064842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None  # PY2 is not False



# Generated at 2022-06-26 02:51:22.381601
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert not isinstance("", PyInfo.string_types)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0


# Wrap Python2's cmp function in a version that works on Py3

# Generated at 2022-06-26 02:51:30.106934
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert (isinstance('', PyInfo.string_types))
        assert (isinstance(b'', PyInfo.binary_type))
        assert (isinstance(1, PyInfo.integer_types))

# Generated at 2022-06-26 02:51:32.197583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-26 02:51:35.274353
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, "PyInfo is PY3"
    assert PyInfo.PY3 != PyInfo.PY2, "PY3 != PY2"

# Generated at 2022-06-26 02:51:44.620161
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance('str', PyInfo.binary_type)
    assert isinstance(b'bstr', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:05.585066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, \
        "PyInfo.PY2 (%s) or PyInfo.PY3 (%s) must be true" % (
            PyInfo.PY2, PyInfo.PY3)
    assert isinstance('abc', PyInfo.string_types), \
        "'abc' must be a string type"
    assert isinstance(u'abc', PyInfo.string_types), \
        "u'abc' must be a string type"
    assert isinstance('abc', PyInfo.text_type), \
        "'abc' must be a text type"
    assert isinstance(u'abc', PyInfo.text_type), \
        "u'abc' must be a text type"

# Generated at 2022-06-26 02:52:13.257076
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Call the C++ constructor.

    pyinfo = PyInfo()
    assert type(pyinfo) == PyInfo

    # Test the PY2 and PY3 member variables.

    if sys.version_info[0] == 2:
        assert pyinfo.PY2 == True
        assert pyinfo.PY3 == False
    else:
        assert pyinfo.PY2 == False
        assert pyinfo.PY3 == True

    # Test the string_types member variable.

    assert isinstance(pyinfo.string_types, tuple)
    for s in pyinfo.string_types:
        assert isinstance(s, (type, types.ClassType))

    # Test the text_type member variable.

    assert isinstance(pyinfo.text_type, (type, types.ClassType))

    # Test the binary_type member

# Generated at 2022-06-26 02:52:21.598414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert isinstance(PyInfo, type)


# Backward compatibility
# Keeps backward compatibility with previous versions of
# this package while the 'py' module is deprecated.

PY2 = PyInfo.PY2
PY3 = PyInfo.PY3
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types
maxsize = PyInfo.maxsize


# Generated at 2022-06-26 02:52:24.098931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> x = PyInfo()
    >>> x.PY2
    True
    >>> x.PY3 
    False
    """
    pass



# Generated at 2022-06-26 02:52:34.589539
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    if not PyInfo.PY2:
        # Python 2.6 has int type
        assert int in PyInfo.integer_types
        assert long not in PyInfo.integer_types

    if not PyInfo.PY2:
        # Python 2.6 has type type
        assert type in PyInfo.class_types
        assert types.ClassType not in PyInfo.class_types


# Unit

# Generated at 2022-06-26 02:52:41.792469
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo().PY3:
        return None

    assert PyInfo().string_types == str
    assert PyInfo().text_type == str
    assert PyInfo().binary_type == bytes
    assert PyInfo().integer_types == int
    assert PyInfo().class_types == type
    assert PyInfo().maxsize > 0

    # print(PyInfo().maxsize)
    assert PyInfo().maxsize > 0

# Generated at 2022-06-26 02:52:44.485321
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 or pyinfo.PY3



# Generated at 2022-06-26 02:52:48.634792
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def setUp(self):
            pass

        def test_PY2(self):
            pass

        def tearDown(self):
            pass

    unittest.main(verbosity=2)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:49.454792
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-26 02:53:00.381753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


# pylint: disable=invalid-name

# Generated at 2022-06-26 02:53:30.386153
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)

    else:  # PyInfo.PY3
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:53:37.776476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
    else:
        assert False


# The main purpose of class PluginInfo is to define some constant strings

# Generated at 2022-06-26 02:53:46.720130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True, "PyInfo.PY2 or PyInfo.PY3 is not True"
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.string_types)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(12, PyInfo.integer_types)

# Generated at 2022-06-26 02:53:50.516493
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.string_types)

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:53:58.319609
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert PyInfo.text_type is str
        assert PyInfo.maxsize == sys.maxsize
        assert type(PyInfo.maxsize) is int
    else:
        assert PyInfo.text_type is unicode
        assert type(PyInfo.maxsize) is int
        assert PyInfo.maxsize < sys.maxsize



# Generated at 2022-06-26 02:54:11.252137
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.string_types == (basestring,)
    assert isinstance('a', PyInfo.string_types) is True
    assert isinstance(u'a', PyInfo.string_types) is True
    # PY3
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.string_types == (basestring,)
    assert isinstance('a', PyInfo.string_types) is True

# Generated at 2022-06-26 02:54:22.420799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    print(type(pyinfo.PY2))
    print(pyinfo.PY2)
    print(type(pyinfo.PY3))
    print(pyinfo.PY3)
    print(type(pyinfo.string_types))
    print(pyinfo.string_types)
    print(type(pyinfo.text_type))
    print(pyinfo.text_type)
    print(type(pyinfo.binary_type))
    print(pyinfo.binary_type)
    print(type(pyinfo.integer_types))
    print(pyinfo.integer_types)
    print(type(pyinfo.class_types))
    print(pyinfo.class_types)
    print(type(pyinfo.maxsize))
    print(pyinfo.maxsize)




# Generated at 2022-06-26 02:54:24.927326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-26 02:54:33.273524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2 or not (sys.version_info[0] == 2)
    assert py_info.PY3 == sys.version_info[0] == 3 or not (sys.version_info[0] == 3)
    assert py_info.string_types == str or not py_info.PY3
    assert py_info.text_type == str or not py_info.PY3
    assert py_info.binary_type == str or not py_info.PY3
    assert py_info.integer_types == (int, long) or not py_info.PY3
    assert py_info.class_types == (type, types.ClassType) or not py_info.PY3
    assert py_

# Generated at 2022-06-26 02:54:36.861256
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.integer_types
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:22.185420
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str,) or PyInfo.string_types == (
        basestring,)
    assert PyInfo.text_type == str or PyInfo.text_type == unicode
    assert PyInfo.binary_type == bytes or PyInfo.binary_type == str
    assert PyInfo.integer_types == (int,) or PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type,) or PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-26 02:55:27.756203
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(True, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


PY2 = PyInfo.PY2
PY3 = PyInfo.PY3

string_types = PyInfo.string_types
integer_types = PyInfo.integer_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
class_types = PyInfo.class_types
maxsize = PyInfo.maxsize

if PY3:
    maketrans = str.maketrans
else:  # PY2
    from string import maketr

# Generated at 2022-06-26 02:55:36.320929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from types import MethodType
    from nose.tools import eq_
    from nose.tools import ok_

    class Clazz:
        pass

    if PyInfo.PY2:
        eq_(PyInfo.maxsize, sys.maxint)
        ok_(isinstance(Clazz, PyInfo.class_types))
    else:
        eq_(PyInfo.maxsize, sys.maxsize)
        ok_(not isinstance(Clazz, PyInfo.class_types))

# Generated at 2022-06-26 02:55:39.983702
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True) or \
        (PyInfo.PY3 == True) and (PyInfo.PY2 != True) and (PyInfo.PY3 != True)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:55:48.917722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    maxsize = PyInfo.maxsize
    if PyInfo.PY2:
        from __builtin__ import type
    else:
        from builtins import type
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-26 02:55:53.240510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert isinstance(x, PyInfo)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:56:01.799971
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY2
    True
    >>> pyinfo.PY3
    False
    >>> pyinfo.string_types
    (<type 'basestring'>,)
    >>> pyinfo.text_type
    <type 'unicode'>
    >>> pyinfo.binary_type
    <type 'str'>
    >>> pyinfo.integer_types
    (<type 'int'>, <type 'long'>)
    """
    pass


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:56:09.554584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python version: ' + str(sys.version_info.major) + '.' \
          + str(sys.version_info.minor) + '.' + str(sys.version_info.micro))
    print('32 bit platform: ' + str(PyInfo.maxsize < 2**32))
    print('Path to Python:  ' + sys.executable)

# Generated at 2022-06-26 02:56:22.137410
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:56:29.659914
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


# Unit test of module

# Generated at 2022-06-26 02:58:07.373252
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("unicode", PyInfo.string_types)
    assert not isinstance(b"binary", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)

    assert isinstance(b"binary", PyInfo.binary_type)
    assert not isinstance("unicode", PyInfo.binary_type)
    assert not isinstance(u"unicode", PyInfo.binary_type)

    assert isinstance(u"unicode", PyInfo.text_type)
    assert not isinstance(b"binary", PyInfo.text_type)
    assert not isinstance("unicode", PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:58:15.330222
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", (PyInfo.string_types))
    assert isinstance("", (PyInfo.text_type,))
    assert isinstance(b"", (PyInfo.binary_type,))
    assert isinstance(1, (PyInfo.integer_types))
    assert isinstance(str, (PyInfo.class_types,))

# Generated at 2022-06-26 02:58:27.462539
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert 2 ** 31 == PyInfo.maxsize

        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)

        assert isinstance('a', PyInfo.binary_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert not isinstance(u'a', PyInfo.binary_type)
    else:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance('a', PyInfo.text_type)

        assert 2 ** 63 == PyInfo.maxsize

# Generated at 2022-06-26 02:58:36.383019
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.__name__ == 'PyInfo'
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, text_type)
    assert isinstance(PyInfo.binary_type, binary_type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:58:44.667544
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert isinstance(i.PY2, bool)
    assert isinstance(i.PY3, bool)
    assert isinstance(i.string_types, tuple)
    assert isinstance(i.text_type, str)
    assert isinstance(i.binary_type, str)
    assert isinstance(i.integer_types, tuple)

# Generated at 2022-06-26 02:58:49.762747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python version: ', PyInfo.PY2, PyInfo.PY3)

    print('maximum int:', PyInfo.maxsize)
    print('string types:', PyInfo.string_types)
    print('text type:', PyInfo.text_type)
    print('binary type:', PyInfo.binary_type)
    print('integer types:', PyInfo.integer_types)
    print(type(PyInfo.maxsize))



# Generated at 2022-06-26 02:59:00.572191
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import py
    import sys

    if sys.version_info[0] == 2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)
        assert isinstance(2**63, PyInfo.integer_types)
        assert not isinstance(0.1, PyInfo.integer_types)
        assert isinstance(u"b", PyInfo.text_type)
        assert isinstance("c", PyInfo.binary_type)
        assert not isinstance(1.0, PyInfo.integer_types)
        assert isinstance(str, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(float, PyInfo.class_types)

# Generated at 2022-06-26 02:59:06.515091
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstan

# Generated at 2022-06-26 02:59:13.836539
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Given
    pyinfo = PyInfo()

    # When-Then
    assert pyinfo.PY2 is False
    assert pyinfo.PY3 is True
    assert pyinfo.string_types == (str,)
    assert pyinfo.text_type == str
    assert pyinfo.binary_type == bytes
    assert pyinfo.integer_types == (int,)
    assert pyinfo.class_types == (type,)
    assert pyinfo.maxsize == sys.maxsize


# Required to run tests on python 2.7 and 3.x

# Generated at 2022-06-26 02:59:19.502054
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is (sys.version_info[0] == 3)
    assert PyInfo.PY2 is (sys.version_info[0] == 2)

    if PyInfo.PY2:
        assert PyInfo.maxsize is (1 << 63) - 1

        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.string_types)

        assert not isinstance(b"", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.string_types)

    elif PyInfo.PY3:
        assert PyInfo.maxsize is sys.maxsize

        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.string_types)
