

# Generated at 2022-06-26 02:49:23.336012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('\n_____________________________________________________________________\n')
    print('\n#####################################################################\n')
    print('Testing create a PyInfo object:\n\n')
    py_info_0 = PyInfo()
    print(py_info_0)
    print('\n#####################################################################\n')
    print('_____________________________________________________________________\n')

# Parameterized testing of methods in class PyInfo

# Generated at 2022-06-26 02:49:25.556955
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Constructor without parameters
    # Pass
    py_info_1 = PyInfo()

test_PyInfo()

# Generated at 2022-06-26 02:49:26.515596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()


# Generated at 2022-06-26 02:49:28.995227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def testBody():
        print("\nTesting py_info")
        # test_case_0()
        test_case_0()

    testBody()

# test_PyInfo()

# Generated at 2022-06-26 02:49:31.940207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert py_info_0.PY3 == True
    assert py_info_0.PY2 == False
    assert py_info_0.maxsize == 9223372036854775807


# Generated at 2022-06-26 02:49:35.005759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert(py_info_0.PY2 is True)
    assert(py_info_0.PY3 is False)
    assert(py_info_0.maxsize == 2147483647)


# Generated at 2022-06-26 02:49:37.250536
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# These tests verify that the class definitions we made work correctly.
# They don't test that the JNI code works correctly; for that we need to
# instrument the class definitions.


# Generated at 2022-06-26 02:49:38.463127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0 is not None


# Generated at 2022-06-26 02:49:40.317467
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()


# Generated at 2022-06-26 02:49:41.757328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

x = PyInfo()


# Generated at 2022-06-26 02:49:47.655065
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:49.542207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.text_type == bytes


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:54.778466
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2 and PyInfo.PY3:
        raise RuntimeError("You are correct")
    isinstance('', PyInfo.string_types)
    isinstance(u'', PyInfo.string_types)
    isinstance(b'', PyInfo.binary_type)
    isinstance(2, PyInfo.integer_types)
    isinstance(int, PyInfo.class_types)



# Generated at 2022-06-26 02:49:58.925118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Unit test for constructo of class PyInfo.")
    print("Should print 2 and 3 respectively.")
    print(PyInfo.PY2)
    print(PyInfo.PY3)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:50:04.947444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-26 02:50:13.755135
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import yaml

    yaml_obj = yaml.load('''
    PY2: true
    PY3: false
    string_types:
        - basestring
    text_type: unicode
    binary_type: str
    integer_types:
        - int
        - long
    class_types:
        - type
        - types.ClassType
    ''')
    assert PyInfo.PY2 == yaml_obj['PY2']
    assert PyInfo.PY3 == yaml_obj['PY3']
    assert PyInfo.string_types == tuple(yaml_obj['string_types'])
    assert PyInfo.text_type == yaml_obj['text_type']
    assert PyInfo.binary_type == yaml_obj['binary_type']

# Generated at 2022-06-26 02:50:19.396856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None
    assert PyInfo.PY2 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.maxsize is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None


if __name__ == "__main__":
    pass

# Generated at 2022-06-26 02:50:24.956699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # sys.version_info
    assert(isinstance(PyInfo.string_types, tuple))
    assert(isinstance(PyInfo.text_type, type))
    assert(isinstance(PyInfo.binary_type, type))
    assert(isinstance(PyInfo.integer_types, tuple))
    assert(isinstance(PyInfo.class_types, tuple))



# Generated at 2022-06-26 02:50:27.894537
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.maxsize is not None
    assert PyInfo.integer_types is not None



# Generated at 2022-06-26 02:50:29.753756
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 1 or PyInfo.PY3 == 1


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:40.089277
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)

    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)

    print(PyInfo.maxsize)
    print(sys.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:45.566965
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("{}\n".format(PyInfo.PY2))
    print("{}\n".format(PyInfo.PY3))
    pr

# Generated at 2022-06-26 02:50:51.377208
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-26 02:50:56.798950
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    if PyInfo.PY3:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
    else:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-26 02:51:07.608590
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY3 == (pyinfo.PY2 == False)

    if pyinfo.PY3:
        assert isinstance("a", pyinfo.string_types)
        assert isinstance("a", pyinfo.text_type)
        assert isinstance(b"a", pyinfo.binary_type)
        assert isinstance(1, pyinfo.integer_types)

        assert not isinstance("a", pyinfo.binary_type)
        assert not isinstance(b"a", pyinfo.text_type)
    else:
        assert isinstance("a", pyinfo.string_types)
        assert isinstance("a", pyinfo.text_type)
        assert isinstance("a", pyinfo.binary_type)
        assert isinstance(1, pyinfo.integer_types)
       

# Generated at 2022-06-26 02:51:14.364306
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:51:24.442125
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # test function
    if isinstance(True, PyInfo.bool_types):
        pass
    if isinstance(1, PyInfo.integer_types):
        pass
    if isinstance(1, PyInfo.numeric_types):
        pass
    if isinstance(1.0, PyInfo.numeric_types):
        pass

    if isinstance(b"abc", PyInfo.string_types):
        pass
    if isinstance("abc", PyInfo.string_types):
        pass

    if isinstance(b"abc", PyInfo.binary_type):
        pass
    if isinstance("abc", PyInfo.text_type):
        pass


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:51:33.600760
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:  # PY2
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)


# Generated at 2022-06-26 02:51:42.608964
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check all members are True or False
    assert all(isinstance(b, bool) for b in PyInfo.__dict__.values())


if __name__ == '__main__':
    # Run unit tests
    import sys, unittest

    class PyInfoTest(unittest.TestCase):
        pass

    # Add all functions beginning with 'test'
    for attr_name in dir():
        if attr_name.startswith('test'):
            func = getattr(PyInfoTest, attr_name)

            setattr(PyInfoTest, attr_name, func)

    unittest.main()

# Generated at 2022-06-26 02:51:44.464531
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform
    assert PyInfo.PY2 or PyInfo.PY3

    if platform.python_implementation().lower() != "jython":
        assert isinstance(PyInfo.maxsize, int)


# Point of entry for testing

# Generated at 2022-06-26 02:52:06.054769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-26 02:52:09.314947
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = sys.version_info[0] == 2
    assert py2 == PyInfo.PY2
    assert not py2 == PyInfo.PY3
    assert not PyInfo.PY2 == py2

# Generated at 2022-06-26 02:52:17.235908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (types.StringType,)
    assert PyInfo.maxsize == 2147483647
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (types.TypeType, types.ClassType)

    sys.version_info[0] = 3
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (types.StringType,)
    assert PyInfo.maxsize == 2147483647
    assert PyInf

# Generated at 2022-06-26 02:52:26.002733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.0, PyInfo.integer_types)
    assert isinstance(type(sys), PyInfo.class_types)
    assert isinstance(xrange, PyInfo.class_types)
    assert isinstance(sys.maxsize, PyInfo.integer_types)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-26 02:52:26.924411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Unit test has no assert
    PyInfo()

# Generated at 2022-06-26 02:52:34.070357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert (p.PY2 is True and p.PY3 is False)
    assert (p.string_types == (basestring,))
    assert (p.text_type == unicode)
    assert (p.binary_type == str)
    assert (p.integer_types == (int, long))

    # The following is for 32-bit CPython
    assert (p.maxsize == 2147483647)
    assert (p.class_types == (type, types.ClassType))

# Generated at 2022-06-26 02:52:43.548249
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _pyinfo = PyInfo()
    assert isinstance(_pyinfo.PY2, bool)
    assert isinstance(_pyinfo.PY3, bool)
    assert isinstance(_pyinfo.string_types, tuple)
    assert isinstance(_pyinfo.text_type, str)
    assert isinstance(_pyinfo.binary_type, str)
    assert isinstance(_pyinfo.integer_types, tuple)
    assert isinstance(_pyinfo.class_types, tuple)
    assert isinstance(_pyinfo.maxsize, int)

# Generated at 2022-06-26 02:52:46.052194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-26 02:52:57.548413
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import string
    pyinfo = PyInfo()

    assert pyinfo.maxsize == sys.maxsize
    assert pyinfo.PY2 == (sys.version[0] == '2')
    assert pyinfo.PY3 == (sys.version[0] == '3')
    assert isinstance("A", pyinfo.string_types)
    assert isinstance(b"A", pyinfo.binary_type)
    assert isinstance(1, pyinfo.integer_types)
    assert isinstance(string.ascii_lowercase, pyinfo.text_type)
    assert isinstance(string, pyinfo.class_types)


test_PyInfo()

# Generated at 2022-06-26 02:53:05.658197
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.class_types is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-26 02:53:33.905368
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert type(PyInfo.string_types) is tuple
    assert str in PyInfo.string_types
    assert unicode in PyInfo.string_types
    assert basestring not in PyInfo.string_types
    assert type(PyInfo.text_type) is unicode
    assert type(PyInfo.binary_type) is str
    assert type(PyInfo.integer_types) is tuple
    assert int in PyInfo.integer_types
    assert long in PyInfo.integer_types
    assert PyInfo.integer_types == PyInfo.integer_types[1:] == (long,)
    assert type(PyInfo.class_types) is tuple
    assert int in PyInfo.integer_types
    assert type(1) in PyInfo.class_types

# Generated at 2022-06-26 02:53:37.318587
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:53:48.464511
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        import pkg_resources
        pkg_resources.require(six.__name__)
    except (ImportError, pkg_resources.VersionConflict):
        pass
    else:
        # The import of six might have changed the values.
        for k in dir(PyInfo):
            if not k.isupper():
                continue
            v = getattr(PyInfo, k)
            if isinstance(v, (tuple, list)):
                assert v
            else:
                assert v


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:53:51.123062
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-26 02:53:59.726308
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:11.712032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert PyInfo.PY2 and PyInfo.string_types == (basestring, )
    assert PyInfo.PY2 and PyInfo.text_type == unicode

    assert PyInfo.PY3 and PyInfo.string_types == (str, )
    assert PyInfo.PY3 and PyInfo.text_type == str

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-26 02:54:17.626993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 or p.PY3
    assert p.string_types
    assert p.text_type
    assert p.binary_type
    assert p.integer_types
    assert p.class_types
    assert p.maxsize

# Generated at 2022-06-26 02:54:24.118082
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance("hello", PyInfo.string_types)
        assert isinstance("hello", PyInfo.text_type)
        assert isinstance(b"hello", PyInfo.binary_type)
        assert isinstance(100, PyInfo.integer_types)

        assert PyInfo.maxsize > 0
    else:  # PY2
        assert isinstance("hello", PyInfo.string_types)
        assert isinstance(u"hello", PyInfo.text_type)
        assert isinstance("hello", PyInfo.binary_type)
        assert isinstance(100, PyInfo.integer_types)

        assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:54:27.361805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:54:33.883861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('foo', PyInfo.string_types)
        assert not isinstance(u'foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.text_type)
        assert not isinstance('foo', PyInfo.text_type)
    else:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.string_types)
        assert not isinstance(u'foo', PyInfo.text_type)
        assert isinstance('foo', PyInfo.text_type)
    assert isinstance(42, PyInfo.integer_types)
    assert not isinstance(42.0, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)



# Generated at 2022-06-26 02:55:18.217417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-26 02:55:25.203695
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    x = PyInfo()
    assert isinstance(x, object)

    assert platform.python_implementation() == "CPython"

    pyinfo = PyInfo()
    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)



# Generated at 2022-06-26 02:55:30.904268
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == (str if PyInfo.PY3 else unicode)
    assert PyInfo.binary_type == (bytes if PyInfo.PY3 else str)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-26 02:55:41.957675
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.text_type)
        assert isinstance('abc', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:55:52.453979
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import inspect

    def assert_is(expect, actual):
        assert expect is actual, '%r is not %r' % (actual, expect)

    def assert_is_not(expect, actual):
        assert expect is not actual, '%r is %r' % (actual, expect)

    def assert_is_none(actual):
        assert actual is None, '%r is not None' % actual

    def assert_is_not_none(actual):
        assert actual is not None, '%r is None' % actual

    def assert_equal(expect, actual):
        value = (expect, actual)
        assert expect == actual, '%r != %r' % value

    def assert_not_equal(expect, actual):
        value = (expect, actual)

# Generated at 2022-06-26 02:56:02.473790
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PI = PyInfo()
    assert PI.PY2 == True or PI.PY2 == False
    assert PI.PY3 == True or PI.PY3 == False
    assert PI.string_types == (str, basestring)
    assert PI.text_type == str or PI.text_type == unicode
    assert PI.binary_type == bytes or PI.binary_type == str
    assert PI.integer_types == (int, long) or PI.integer_types == (int,)
    assert PI.class_types == (type, types.ClassType) or PI.class_types == (type,)


if __name__ == '__main__':
    test_PyInfo()
    print("All tests passed!")

# Generated at 2022-06-26 02:56:10.881485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance(PyInfo.PY2, bool)
    isinstance(PyInfo.PY3, bool)

    isinstance(PyInfo.string_types, tuple)
    isinstance(PyInfo.text_type, type)
    isinstance(PyInfo.binary_type, type)
    isinstance(PyInfo.integer_types, tuple)
    isinstance(PyInfo.class_types, tuple)
    isinstance(PyInfo.maxsize, int)


# Class for unit test

# Generated at 2022-06-26 02:56:19.486773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None and PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-26 02:56:26.611076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-26 02:56:29.811768
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-26 02:58:05.027311
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 or PyInfo.PY3)
    assert(isinstance('', PyInfo.text_type))
    if PyInfo.PY2:
        assert(8 * struct.calcsize("P") == 64)
    assert(max(1 << 31, 1 << 63) == PyInfo.maxsize)


# test for PyInfo.pyinfo

# Generated at 2022-06-26 02:58:17.441453
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring, )
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)
        assert pyinfo.maxsize == 9223372036854775807
    else:
        assert pyinfo.string_types == (str, )
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int, )
        assert pyinfo.class_types == (type, )
        assert pyinfo.maxsize == 9223372036854775807

# Generated at 2022-06-26 02:58:28.330913
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-26 02:58:29.248509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test code 'if PyInfo.PY2/3'"""

# Generated at 2022-06-26 02:58:39.536332
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("\nTesting PyInfo constructor")
    print("Python version: " + sys.version)

    print("PY2:\t\t" + str(PyInfo.PY2))
    print("PY3:\t\t" + str(PyInfo.PY3))

    print("\nstring_types:")
    for t in PyInfo.string_types:
        print("\t" + str(t))

    print("\ntext_type: " + str(PyInfo.text_type))
    print("binary_type: " + str(PyInfo.binary_type))

    print("\ninteger_types:")
    for t in PyInfo.integer_types:
        print("\t" + str(t))

    print("\nmaxsize: " +  str(PyInfo.maxsize))

# Generated at 2022-06-26 02:58:50.490184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize

    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
       

# Generated at 2022-06-26 02:59:00.618307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert (type(PyInfo.string_types[0]) is str)
        assert (type(PyInfo.text_type) is unicode)
        assert (type(PyInfo.binary_type) is str)
        assert (type(PyInfo.integer_types[0]) is int)
        assert (type(PyInfo.class_types[0]) is type)

    else:
        assert(type(PyInfo.string_types[0]) is str)
        assert(type(PyInfo.text_type) is str)
        assert(type(PyInfo.binary_type) is bytes)
        assert(type(PyInfo.integer_types[0]) is int)
        assert(type(PyInfo.class_types[0]) is type)

# Generated at 2022-06-26 02:59:03.675378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (2 == PyInfo.PY2 + PyInfo.PY3)
    assert PyInfo.PY3 == (3 == PyInfo.PY2 + PyInfo.PY3)



# Generated at 2022-06-26 02:59:12.284656
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    print(py_info.PY3, py_info.PY2)
    print(py_info.string_types, py_info.text_type, py_info.binary_type, py_info.integer_types, sep='\n')
    print(py_info.maxsize)
    print(type(py_info.maxsize))


if __name__ == "__main__":
    test_PyInfo()