

# Generated at 2022-06-26 02:49:20.756924
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Assert if the constructor of class PyInfo is changed

    check_PyInfo = inspect.getfullargspec(test_case_0).args
    assert check_PyInfo == ['self'], 'Constructor of class PyInfo is changed, please update this test case.'

# Generated at 2022-06-26 02:49:24.483857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("test_PyInfo started.")

    py_info_0 = PyInfo()

    print("test_PyInfo completed.")




if __name__ == '__main__':

    test_case_0()

    test_PyInfo()

# Generated at 2022-06-26 02:49:26.442197
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3


# Generated at 2022-06-26 02:49:34.268512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == PyInfo().PY2
    assert py_info_0.PY3 == PyInfo().PY3
    assert py_info_0.string_types == PyInfo().string_types
    assert py_info_0.text_type == PyInfo().text_type
    assert py_info_0.binary_type == PyInfo().binary_type
    assert py_info_0.integer_types == PyInfo().integer_types
    assert py_info_0.class_types == PyInfo().class_types
    assert py_info_0.maxsize == sys.maxsize

# Generated at 2022-06-26 02:49:35.711763
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test constructors with various parameters
    # Test no parameters
    test_case_0()


# Generated at 2022-06-26 02:49:37.035902
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:49:40.107515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:49:48.899986
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3

    if py_info.PY3:
        assert py_info.string_types == (str, )
        assert py_info.text_type == str
        assert py_info.binary_type == bytes
        assert py_info.integer_types == (int, )
        assert py_info.class_types == (type, )

        assert py_info.maxsize == sys.maxsize
    else:  # PY2
        assert py_info.string_types == (basestring, )
        assert py_info.text_type == unicode
        assert py_info.binary_type == str
        assert py

# Generated at 2022-06-26 02:49:58.764251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert (py_info_0.PY2) == (sys.version_info[0] == 2)
    assert (py_info_0.PY3) == (sys.version_info[0] == 3)
    if py_info_0.PY3:
        assert (py_info_0.string_types) == (str,)
        assert (py_info_0.text_type) == str
        assert (py_info_0.binary_type) == bytes
        assert (py_info_0.integer_types) == (int,)
        assert (py_info_0.class_types) == (type,)
        assert (py_info_0.maxsize) == sys.maxsize
    else:
        assert (py_info_0.string_types)

# Generated at 2022-06-26 02:50:10.289953
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for constructor of class PyInfo
    obj = PyInfo()
    if not (isinstance(obj, PyInfo) and isinstance(obj, object)):
        raise AssertionError()
    obj = PyInfo()
    if (obj.PY2 != isinstance(2, PyInfo.integer_types)):
        raise AssertionError()
    obj = PyInfo()
    if (obj.PY3 != isinstance(2, PyInfo.integer_types)):
        raise AssertionError()
    obj = PyInfo()
    if not (obj.PY2 != obj.PY3):
        raise AssertionError()
    obj = PyInfo()
    if isinstance(obj, int):
        raise AssertionError()
    obj = PyInfo()
    if isinstance(obj, int):
        raise

# Generated at 2022-06-26 02:50:16.558006
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()
    return



# Generated at 2022-06-26 02:50:17.217298
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

# Generated at 2022-06-26 02:50:18.179152
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()



# Generated at 2022-06-26 02:50:21.253595
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Constructor without argument
    py_info = PyInfo()

    print(py_info.maxsize)
    print(py_info.string_types)

    if py_info.PY2:
        print("PY2")

    pass



# Generated at 2022-06-26 02:50:27.368780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.string_types == (str, )
    assert py_info.binary_type == bytes
    assert py_info.text_type == str
    assert py_info.integer_types == (int, )
    assert py_info.class_types == (type, )
    assert py_info.maxsize == 9223372036854775807

# Generated at 2022-06-26 02:50:28.324224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo(), PyInfo


# Generated at 2022-06-26 02:50:29.460461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test case 0
    test_case_0()



# Generated at 2022-06-26 02:50:40.053589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 == sys.version_info[0] == 2
    assert py_info_0.PY3 == sys.version_info[0] == 3

    if py_info_0.PY3:
        assert py_info_0.string_types == (str,)
        assert py_info_0.text_type == str
        assert py_info_0.binary_type == bytes
        assert py_info_0.integer_types == (int,)
        assert py_info_0.class_types == (type,)
        assert py_info_0.maxsize == sys.maxsize
    else:  # PY2
        assert py_info_0.string_types == (basestring,)
        assert py_info_0.text_

# Generated at 2022-06-26 02:50:43.843700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()



# Generated at 2022-06-26 02:50:46.470032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Unit testing
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:50:59.194094
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:51:07.941968
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    assert py_info_0.PY2 is True or py_info_0.PY2 is False
    assert py_info_0.PY3 is True or py_info_0.PY3 is False
    assert isinstance(py_info_0.string_types, tuple)
    assert isinstance(py_info_0.text_type, type)
    assert isinstance(py_info_0.binary_type, type)
    assert isinstance(py_info_0.integer_types, tuple)
    assert isinstance(py_info_0.class_types, tuple)
    assert py_info_0.maxsize == 2147483647

# Generated at 2022-06-26 02:51:10.969562
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()

# Generated at 2022-06-26 02:51:12.746404
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()


# Generated at 2022-06-26 02:51:14.688721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()


# Generated at 2022-06-26 02:51:16.159506
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True


# Generated at 2022-06-26 02:51:17.203347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_case_0()

# Generated at 2022-06-26 02:51:20.843815
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Test PyInfo")
    print("\tProgress: ", test_case_0())
    print("")
    # !!! Add more tests here
    # !!! Remember to test all branches
    # !!! Enumerate the cases in comments
    

# Generated at 2022-06-26 02:51:29.173281
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    py_info_0 = PyInfo()
    assert py_info.PY2 == py_info_0.PY2
    assert py_info.PY3 == py_info_0.PY3
    assert py_info.string_types == py_info_0.string_types
    assert py_info.text_type == py_info_0.text_type
    assert py_info.binary_type == py_info_0.binary_type
    assert py_info.integer_types == py_info_0.integer_types
    assert py_info.class_types == py_info_0.class_types
    assert py_info.maxsize == py_info_0.maxsize


test_case_0()
test_PyInfo()

# Reference:
# https

# Generated at 2022-06-26 02:51:40.580035
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info_0 = PyInfo()
    #
    # Check the data attributes of PyInfo class
    #
    assert py_info_0.PY2 == sys.version_info[0] == 2
    assert py_info_0.PY3 == sys.version_info[0] == 3
    if py_info_0.PY2:
        assert py_info_0.string_types == (basestring,)
        assert py_info_0.text_type == unicode
        assert py_info_0.binary_type == str
        assert py_info_0.integer_types == (int, long)
        assert py_info_0.class_types == (type, types.ClassType)

# Generated at 2022-06-26 02:51:54.235781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:02.273318
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        # PyInfo.PY2 == True
        print(PyInfo.string_types)
        assert PyInfo.string_types == (__builtins__.basestring,)
        assert isinstance(PyInfo.maxsize, __builtins__.long)
    else:
        # PyInfo.PY3 == True
        print(PyInfo.string_types)
        assert PyInfo.string_types == (__builtins__.str,)
        assert isinstance(PyInfo.maxsize, __builtins__.int)

# Generated at 2022-06-26 02:52:05.377893
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not (PyInfo.PY2 or PyInfo.PY3):
        raise Exception("Bad version of Python")


test_PyInfo()

# Generated at 2022-06-26 02:52:08.120269
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # same string
    assert PyInfo.PY2 != PyInfo.PY3
    # different string
    assert PyInfo.PY2 == 2
    assert PyInfo.PY3 == 3



# Generated at 2022-06-26 02:52:12.551575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes

# Generated at 2022-06-26 02:52:16.927820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-26 02:52:26.000169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
    else:
        assert isinstance("", bytes)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance(int, types.ClassType)
        assert isinstance(int, type)

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:52:30.589144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:52:39.015233
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.class_types)
    elif PyInfo.PY2:
        assert isinstance("", (str, unicode))
        assert not isinstance("", str)
        assert not isinstance("", unicode)
        assert isinstance(0, (int, long))
        assert isinstance(0, (type, types.ClassType))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:52:42.759519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from faker.utils.pyinfo import PyInfo

    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-26 02:53:05.923191
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1 and PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode and PyInfo.binary_type == str
        assert len(PyInfo.integer_types) == 2 and \
            PyInfo.integer_types[0] == int and PyInfo.integer_ty

# Generated at 2022-06-26 02:53:07.319199
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-26 02:53:16.956315
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> from __pkginfo__ import PyInfo

    >>> PyInfo.PY2
    True
    >>> PyInfo.PY3
    False

    >>> PyInfo.string_types
    (<type 'basestring'>,)
    >>> PyInfo.text_type
    <type 'unicode'>
    >>> PyInfo.binary_type
    <type 'str'>
    >>> PyInfo.maxsize
    9223372036854775807L
    """



# Generated at 2022-06-26 02:53:24.950193
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import io
    import unittest

    class TestCase(unittest.TestCase):

        def test_maxsize(self):
            import sys

            if sys.maxsize == 9223372036854775807:
                self.assertEqual(sys.maxsize, PyInfo.maxsize)
            elif sys.maxsize == 2147483647:
                self.assertEqual(sys.maxsize, PyInfo.maxsize)

    unittest.main(module=__name__, argv=[sys.argv[0]],
                  testRunner=unittest.TextTestRunner(
                      stream=io.StringIO()),
                  exit=False)

# Generated at 2022-06-26 02:53:34.140444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-26 02:53:40.453233
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for PyInfo.

    Check that PyInfo instance has all attributes.
    """
    pyinfo = PyInfo()
    assert hasattr(pyinfo, "PY2")
    assert hasattr(pyinfo, "PY3")
    assert hasattr(pyinfo, "string_types")
    assert hasattr(pyinfo, "text_type")
    assert hasattr(pyinfo, "binary_type")
    assert hasattr(pyinfo, "integer_types")
    assert hasattr(pyinfo, "class_types")
    assert hasattr(pyinfo, "maxsize")


# Global instance of PyInfo, that is used in other modules
PY3 = PyInfo.PY3
pyinfo = PyInfo()

# Generated at 2022-06-26 02:53:51.056151
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('PyInfo string', PyInfo.string_types)
    assert not isinstance(u'PyInfo unicode', PyInfo.string_types)
    assert isinstance('PyInfo text', PyInfo.text_type)
    assert isinstance(b'PyInfo binary', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:54:00.289885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _test_isinstance(PyInfo.PY2, bool)
    _test_isinstance(PyInfo.PY3, bool)

    _test_isinstance(PyInfo.string_types, tuple)
    _test_isinstance(PyInfo.text_type, type)
    _test_isinstance(PyInfo.binary_type, type)
    _test_isinstance(PyInfo.maxsize, int)
    _test_isinstance(PyInfo.integer_types, tuple)
    _test_isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-26 02:54:11.972253
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:  # Python 2
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)


# Generated at 2022-06-26 02:54:14.007272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-26 02:55:02.148092
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.binary_type)

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.string_types)

    PyInfo.maxsize += 1
    if PyInfo.PY2:
        assert not isinstance(PyInfo.maxsize, PyInfo.integer_types)
    if PyInfo.PY3:
        assert isinstance(PyInfo.maxsize, PyInfo.integer_types)



# Generated at 2022-06-26 02:55:13.346946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    print("PyInfo: Python version", sys.version_info[0])
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert PyInfo.maxsize < 0
    elif sys.version_info[0] == 3:
        assert PyInfo.PY3
        assert PyInfo.maxsize >= 0
    else:
        assert False, "unexpected Python version: " + sys.version_info[0]
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types

    assert isinstance(b"abc", PyInfo.binary_type)

# Generated at 2022-06-26 02:55:22.536633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:55:26.449840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.maxsize == (1 << 63) - 1:
        assert PyInfo.maxsize == (1 << 63) - 1
    else:
        assert PyInfo.maxsize == (1 << 31) - 1


if __name__ == "__main__":
    # Unit test for PyInfo
    test_PyInfo()

# Generated at 2022-06-26 02:55:39.187665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-26 02:55:51.299384
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == (sys.version_info[0] == 2))
    assert(PyInfo.PY3 == (sys.version_info[0] == 3))

    if PyInfo.PY3:
        assert(PyInfo.string_types == (str,))
        assert(PyInfo.text_type == str)
        assert(PyInfo.binary_type == bytes)
        assert(PyInfo.integer_types == (int,))
        assert(PyInfo.class_types == (type,))
    else:  # PyInfo.PY2
        assert(PyInfo.string_types == (basestring,))
        assert(PyInfo.text_type == unicode)
        assert(PyInfo.binary_type == str)
        assert(PyInfo.integer_types == (int, long))


# Generated at 2022-06-26 02:56:02.474130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert len(PyInfo.string_types) == 1

    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.text_type == str

    assert isinstance(PyInfo.binary_type, type)
    assert PyInfo.binary_type == bytes

    assert isinstance(PyInfo.integer_types, tuple)
    assert len(PyInfo.integer_types) == 2

    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize == 2147483647

    assert isinstance(PyInfo.class_types, tuple)
    assert len(PyInfo.class_types) == 1

# Generated at 2022-06-26 02:56:13.097653
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)


if PyInfo.PY3:
    def is_string(obj):
        return isinstance(obj, str)
    from urllib.parse import quote, quote_plus, unquote_plus, quote_from_bytes
    from base64 import b64encode, b64decode, b32encode, b32decode, a85encode, a85decode, \
        b16encode, b16decode, standard_b64encode, urlsafe_b64encode, urlsafe_b64

# Generated at 2022-06-26 02:56:23.475700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY3:
        assert isinstance("a", info.string_types)
        assert isinstance("a", info.text_type)
        assert isinstance("a", info.binary_type)
        assert not isinstance("a", info.integer_types)
        assert not isinstance("a", info.class_types)

        assert not isinstance(1, info.string_types)
        assert not isinstance(1, info.text_type)
        assert not isinstance(1, info.binary_type)
        assert isinstance(1, info.integer_types)
        assert not isinstance(1, info.class_types)

        assert not isinstance(object, info.string_types)
        assert not isinstance(object, info.text_type)

# Generated at 2022-06-26 02:56:26.726397
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:58:01.871194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    print(PyInfo.maxsize)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)



# Generated at 2022-06-26 02:58:08.993715
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    if not info.PY2:
        assert info.string_types == (str, )
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int, )
        assert info.class_types == (type, )
    else:
        assert info.string_types == (basestring, )
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
    # TODO: test info.maxsize

# Generated at 2022-06-26 02:58:13.171019
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()
    print("Test passed!")

# Generated at 2022-06-26 02:58:19.556436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    assert info.string_types == (str, ) if info.PY3 else (basestring, )
    assert isinstance("", info.string_types)
    assert info.text_type == str if info.PY3 else unicode
    assert isinstance("", info.text_type)
    assert info.binary_type == bytes if info.PY3 else str
    assert isinstance(b"", info.binary_type)
    assert info.integer_types == (int, long) if info.PY3 else (int, long, )
    assert isinstance(42, info.integer_types)
    assert info.max

# Generated at 2022-06-26 02:58:29.080866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance(u'u', PyInfo.string_types)
        assert not isinstance(b'b', PyInfo.string_types)
    else:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance(u'u', PyInfo.string_types)
        assert isinstance(b'b', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(-1, PyInfo.integer_types)
    assert not isinstance(1.2, PyInfo.integer_types)
    assert not isinstance(1 + 0.2j, PyInfo.integer_types)


# Generated at 2022-06-26 02:58:35.136006
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(">>>Python:%d, PY2:%s, PY3:%s" % (PyInfo.PY2, PyInfo.PY2, PyInfo.PY3))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-26 02:58:37.752840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from utils.pytest import raises
    from nose.plugins.skip import SkipTest

    with raises(TypeError):
        PyInfo()


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-26 02:58:49.761577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(u"a", PyInfo.text_type)
    else:
        assert not isinstance(u"a", PyInfo.text_type)

    assert isinstance(b"a", PyInfo.binary_type)
    if PyInfo.PY2:
        assert not isinstance("a", PyInfo.binary_type)
    else:
        assert isinstance("a", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-26 02:58:52.476412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0

# Generated at 2022-06-26 02:58:54.431011
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

