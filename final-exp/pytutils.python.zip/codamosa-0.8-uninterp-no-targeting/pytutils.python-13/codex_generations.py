

# Generated at 2022-06-21 22:18:06.480599
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:18:15.704247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:17.541062
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2



# Generated at 2022-06-21 22:18:28.564000
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not (PyInfo.PY3 and PyInfo.PY2)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:38.315011
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.text_type == str
    assert PyInfo.string_types == (str,)
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == int((1 << 31) - 1)
    else:
        try:
            x = 1 << 63
        except TypeError:
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            assert PyInfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-21 22:18:39.754705
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# from six

# Generated at 2022-06-21 22:18:43.707267
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)

    assert not isinstance('a', PyInfo.binary_type)
    assert not isinstance(b'a', PyInfo.text_type)

    class A:
        pass
    assert not isinstance(A, PyInfo.class_types)



# Generated at 2022-06-21 22:18:50.158200
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:55.657106
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print('You are using Python 2!')
    elif PyInfo.PY3:
        print('You are using Python 3!')
    else:
        print('You are using neither Python 2 nor Python 3!')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:07.080662
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # --------------- do not modify the code below ----------------
    from tests.unit_test import UnitTest

    unit_test = UnitTest()
    # --------------- do not modify the code above ----------------

    # write your test cases here
    unit_test.add_assertion_test_case(PyInfo.PY2 == True)
    unit_test.add_assertion_test_case(PyInfo.PY3 == False)
    unit_test.add_assertion_test_case(PyInfo.string_types == (basestring,))
    unit_test.add_assertion_test_case(PyInfo.text_type == unicode)
    unit_test.add_assertion_test_case(PyInfo.binary_type == str)

# Generated at 2022-06-21 22:19:11.922965
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo is not None



# Generated at 2022-06-21 22:19:13.638552
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:19:15.083387
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p, PyInfo)



# Generated at 2022-06-21 22:19:22.048935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == (1 << 31) - 1
        assert isinstance(u'\u2019', PyInfo.text_type)
        assert isinstance(b'\u2019', PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
    else:
        assert PyInfo.maxsize == (1 << 63) - 1
        assert isinstance('\u2019', PyInfo.string_types)
        assert isinstance(b'\u2019', PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)



# Generated at 2022-06-21 22:19:28.832676
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)
    assert isinstance(info.maxsize, int)



# Generated at 2022-06-21 22:19:29.910414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), PyInfo)


# Unit tests for PyInfo

# Generated at 2022-06-21 22:19:34.874569
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(long(1), PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


IS_PYPY = hasattr(sys, "pypy_version_info")



# Generated at 2022-06-21 22:19:42.039777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is False if pyinfo.PY3 else True
    assert pyinfo.PY2 is not pyinfo.PY3
    assert isinstance("abc", pyinfo.string_types)
    assert isinstance("abc", pyinfo.text_type)
    assert isinstance("abc", pyinfo.binary_type)
    assert isinstance(123, pyinfo.integer_types)
    assert isinstance(pyinfo, pyinfo.class_types)
    assert pyinfo.maxsize > 0


# ------------------------------
# Helper for unit testing
# ------------------------------

__all__ = []



# Generated at 2022-06-21 22:19:47.945094
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    module_name = py_info.__class__.__module__
    assert module_name in ('__main__', 'typhoon.helper.python'), \
        "Module name: " + module_name
    assert py_info.__class__.__name__ == 'PyInfo', \
        "Class name: " + py_info.__class__.__name__


# Unit test
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:49.748510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:57.050919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert i.PY3 or i.PY2, "Only either PY3 or PY2 can be true."

# Generated at 2022-06-21 22:20:01.640643
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pysnooper

    def test_conditions(pyinfo):
        assert pyinfo.PY2 != pyinfo.PY3
        assert isinstance(pyinfo.PY2, bool)
        assert isinstance(pyinfo.PY3, bool)

        assert isinstance(pyinfo.string_types, tuple)
        assert isinstance(pyinfo.string_types[0], type)

        assert pyinfo.text_type == str if pyinfo.PY3 else unicode
        assert isinstance(pyinfo.text_type, type)

        assert pyinfo.binary_type == bytes if pyinfo.PY3 else str
        assert isinstance(pyinfo.binary_type, type)

        assert isinstance(pyinfo.integer_types, tuple)
        assert isinstance(pyinfo.integer_types[0], type)



# Generated at 2022-06-21 22:20:10.062643
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)
    assert isinstance(pyinfo.string_types, tuple)
    assert callable(pyinfo.text_type)
    assert callable(pyinfo.binary_type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-21 22:20:18.783210
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2, \
        "Please set PY3 or PY2 in class PyInfo."
    assert (not PyInfo.PY3) or (not PyInfo.PY2), \
        "Please don't set both PY3 and PY2 in class PyInfo."

    assert isinstance("A", PyInfo.string_types)
    assert isinstance(b"A", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

    assert isinstance(int(PyInfo.maxsize), PyInfo.integer_types)

# Generated at 2022-06-21 22:20:27.672187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(9223372036854775807, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-21 22:20:32.868412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.maxsize)

    print(PyInfo.PY2)
    print(PyInfo.PY3)

    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)



# Generated at 2022-06-21 22:20:43.568545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('ABC', PyInfo.string_types)
    assert isinstance(u'ABC', PyInfo.string_types)
    assert not isinstance(b'ABC', PyInfo.string_types)

    assert isinstance('ABC', PyInfo.text_type)
    assert not isinstance(u'ABC', PyInfo.text_type)
    assert not isinstance(b'ABC', PyInfo.text_type)

    assert not isinstance('ABC', PyInfo.binary_type)
    assert not isinstance(u'ABC', PyInfo.binary_type)
    assert isinstance(b'ABC', PyInfo.binary_type)

    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:49.336781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(list, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(list, PyInfo.class_types)



# Generated at 2022-06-21 22:20:52.324873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize == (1 << 63) - 1
    assert len(PyInfo.string_types) == 1
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert len(PyInfo.integer_types) == 1
    assert len(PyInfo.class_types) == 1



# Generated at 2022-06-21 22:20:58.360000
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (
        sys.version_info[0] == 2
    ), "Test failed when constructing class PyInfo"
    assert PyInfo.PY3 == (
        sys.version_info[0] == 3
    ), "Test failed when constructing class PyInfo"
    assert PyInfo.string_types == (
        basestring,
    ), "Test failed when constructing class PyInfo"
    assert PyInfo.text_type == unicode, "Test failed when constructing class PyInfo"
    assert PyInfo.binary_type == str, "Test failed when constructing class PyInfo"
    assert PyInfo.integer_types == (
        int,
        long,
    ), "Test failed when constructing class PyInfo"

# Generated at 2022-06-21 22:21:10.699149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2
    assert not pi.PY3



# Generated at 2022-06-21 22:21:12.814679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:21:20.326378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2 :
        print("Py2")
    else:
        print("Py3")
    print("string_types:", PyInfo.string_types)
    print("text_type:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)
    print("maxsize:", PyInfo.maxsize)
    print("---")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:25.728532
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:32.822582
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:34.155344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:21:40.252069
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pydev_runfiles.pydev_runfiles import pyinfo

    assert pyinfo.PY2
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-21 22:21:48.174883
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', (PyInfo.text_type, PyInfo.binary_type))
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    if not PyInfo.PY2:
        import builtins

        assert isinstance(builtins.int, PyInfo.class_types)

    # Check maxsize
    if hasattr(sys, "maxsize"):
        # Python 3.2+
        assert PyInfo.maxsize == sys.maxsize
    try:
        # Python 3.1
        import sysconfig
    except ImportError:
        pass

# Generated at 2022-06-21 22:21:57.971382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance('', PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:22:05.551972
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.class_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    # maxsize is a long number
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:30.524937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(str(object()), PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance(str(object()), str)
        assert not isinstance(1, str)
        assert isinstance(1, int)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:32.626075
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:22:39.613386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2)
    assert not (PyInfo.PY3)
    assert (type(PyInfo.string_types) == tuple)
    assert (type(PyInfo.text_type) == str)
    assert (type(PyInfo.binary_type) == str)
    assert (type(PyInfo.integer_types) == tuple)
    assert (type(PyInfo.class_types) == tuple)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:22:44.918408
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-21 22:22:49.882593
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:22:59.932724
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert isinstance("s", PyInfo.string_types)
        assert isinstance(u"s", PyInfo.string_types)
        assert isinstance(b"s", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:05.366491
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _pyinfo = PyInfo()
    assert isinstance(_pyinfo.string_types[0], type)
    assert isinstance(_pyinfo.text_type, type)
    assert isinstance(_pyinfo.binary_type, type)
    assert isinstance(_pyinfo.integer_types[0], type)
    assert isinstance(_pyinfo.integer_types[1], type)



# Generated at 2022-06-21 22:23:10.039181
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance('hi', PyInfo.string_types)
    assert isinstance('hi', PyInfo.text_type)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:16.536063
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(
        'Python version: {0}.{1}.{2}'.format(
            PyInfo.PY3, PyInfo.PY2, PyInfo.PY3))

    print('sys.maxsize =',  PyInfo.maxsize)
    print('type(maxsize) =', type(PyInfo.maxsize))
    print('sys.version_info =', sys.version_info)

    assert 'int' in str(type(PyInfo.maxsize))
    assert 'int' in str(type(sys.version_info))

# Generated at 2022-06-21 22:23:18.185003
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:24:07.015943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert (not PyInfo.PY2) | PyInfo.PY3  # Exclusive or
    assert PyInfo.PY2 | (not PyInfo.PY3)  # Exclusive or

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# A mock object for pytest of Jupyter Notebook environment

# Generated at 2022-06-21 22:24:10.358497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
    else:
        assert isinstance('', PyInfo.string_types)



# Generated at 2022-06-21 22:24:21.017519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert type("") == PyInfo.text_type if PyInfo.PY3 else type("") == PyInfo.binary_type
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 63, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(list, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(float, PyInfo.class_types)
    # assert isinstance(type, types.ClassType) if PyInfo.PY2 else isinstance(int, types.ClassType)

# Generated at 2022-06-21 22:24:28.453363
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Python < 2.7.9, lexical_scope = function
    Python >= 2.7.9, lexical_scope = class
    """
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:24:35.221298
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    assert isinstance(PyInfo.string_types, tuple) is True
    assert isinstance(PyInfo.text_type(), basestring) is True
    assert isinstance(PyInfo.binary_type(), basestring) is True
    assert isinstance(PyInfo.integer_types, tuple) is True
    assert isinstance(PyInfo.class_types, tuple) is True

    assert isinstance(PyInfo.maxsize, int) is True
    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:44.789665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance(PyInfo.maxsize, int)
    assert all(isinstance(t, type) for t in PyInfo.string_types)
    assert all(isinstance(t, type) for t in PyInfo.class_types)
    assert isinstance(PyInfo.text_type('a'), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(b'a'), PyInfo.string_types)
    assert isinstance(PyInfo.integer_types[0], type)

# Functional test for constructor of class PyInfo

# Generated at 2022-06-21 22:24:51.442041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(Exception, PyInfo.class_types)
    assert isinstance("1", PyInfo.string_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:24:55.230389
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, PyInfo.integer_types)



# Generated at 2022-06-21 22:25:04.312209
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert "abc".__class__ == PyInfo.text_type
        assert isinstance(123, PyInfo.integer_types)
        assert "abc".__class__.__class__ == PyInfo.class_types
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert "abc".__class__ == PyInfo.text_type
        assert isinstance(123, PyInfo.integer_types)
        assert "abc".__class__.__class__ == PyInfo.class_types

# Generated at 2022-06-21 22:25:07.809790
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    if PyInfo.PY2:
        assert PyInfo.PY3 is False
    else:
        assert PyInfo.PY2 is False


test_PyInfo()

# Generated at 2022-06-21 22:26:44.353055
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)

    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:26:51.695294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from flexmock import flexmock, flexmock_teardown

    # Verify the maxsize
    assert PyInfo.maxsize > 9999

    # Verify version
    assert PyInfo.PY2 or PyInfo.PY3

    # Verify string types
    assert isinstance(u"", PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(1.0, PyInfo.string_types)

    # Verify text type
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

# Generated at 2022-06-21 22:27:02.174187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> print('PY2: %s' % PyInfo.PY2)
    >>> print('PY3: %s' % PyInfo.PY3)
    >>> print('string_types: %s' % PyInfo.string_types)
    >>> print('text_type: %s' % PyInfo.text_type)
    >>> print('binary_type: %s' % PyInfo.binary_type)
    >>> print('integer_types: %s' % PyInfo.integer_types)
    >>> print('class_types: %s' % PyInfo.class_types)
    >>> print('maxsize: %s' % PyInfo.maxsize)
    """
    pass


if __name__ == '__main__':
     import doctest
     doctest.testmod()

# Generated at 2022-06-21 22:27:13.078959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert "PyInfo" not in globals()
    from parameterized import parameterized
    from parameterized.utils import Base, get_attr

    def compare_object(key, expected, actual):
        assert get_attr(actual, key) == expected

    def _check_PyInfo(PY2, PY3, string_types, text_type, binary_type,
                      integer_types, class_types, maxsize):
        compare_object("PY2", PY2, PyInfo())
        compare_object("PY3", PY3, PyInfo())
        compare_object("string_types", string_types, PyInfo())
        compare_object("text_type", text_type, PyInfo())
        compare_object("binary_type", binary_type, PyInfo())

# Generated at 2022-06-21 22:27:17.751780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.maxsize) == int
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-21 22:27:22.597232
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    True
    >>> PyInfo.PY3
    False
    >>> PyInfo.string_types
    (<type 'basestring'>,)
    >>> PyInfo.text_type
    <type 'unicode'>
    >>> PyInfo.binary_type
    <type 'str'>
    >>> PyInfo.integer_types
    (<type 'int'>, <type 'long'>)
    >>> PyInfo.class_types
    (<type 'type'>, <type 'classobj'>)
    """
    pass



# Generated at 2022-06-21 22:27:25.657143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:27:31.326194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2, pi.PY2
    assert pi.PY3, pi.PY3

    assert isinstance('', pi.string_types)
    assert isinstance(u'', pi.string_types)

    assert isinstance(2, pi.integer_types)

    assert isinstance(object, pi.class_types)



# Generated at 2022-06-21 22:27:42.197084
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyspark.sql.types import ArrayType, StructType, StructField, StringType
    from pyspark.sql.types import LongType, IntegerType, DoubleType, DecimalType

    # Asserts for Py2
    if sys.version_info[0] == 2:
        # Assert for string_types
        try:
            assert isinstance('abc', PyInfo.string_types)
            assert not isinstance(b'abc', PyInfo.string_types)
        except Exception as e:
            raise e

        # Assert for text_type
        try:
            assert isinstance(u'abc', PyInfo.text_type)
        except Exception as e:
            raise e

        # Assert for binary_type

# Generated at 2022-06-21 22:27:48.540631
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test type of PyInfo.PY2, PyInfo.PY3, PyInfo.maxsize
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)

    # Test type of PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    if PyInfo.PY3:
        # Assert type of PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type in Py3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text