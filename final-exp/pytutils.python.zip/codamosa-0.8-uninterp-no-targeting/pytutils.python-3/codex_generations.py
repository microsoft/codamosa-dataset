

# Generated at 2022-06-21 22:18:08.852829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance({}, collections.Mapping)
    if PyInfo.PY2:
        assert isinstance("abs", collections.MutableSequence)
        assert isinstance("abs", collections.Sequence)
        assert isinstance("abs", collections.MutableSequence)
    else:
        assert not isinstance("abs", collections.MutableSequence)
        assert isinstance("abs", collections.Sequence)
        assert isinstance("abs", collections.MutableSequence)

    assert PY3
    assert not PY2
    assert isinstance("a", str)
    assert not isinstance("a", bytes)
    assert not isinstance("a", unicode)
    assert not isinstance("a", basestring)

    assert PY2
    assert not PY3
    assert not isinstance("a", str)

# Generated at 2022-06-21 22:18:19.568793
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("test", PyInfo.string_types)
        assert not isinstance(b"test", PyInfo.string_types)
        assert isinstance("test", PyInfo.text_type)
        assert not isinstance(b"test", PyInfo.text_type)
        assert not isinstance("test", PyInfo.binary_type)
        assert isinstance(b"test", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.1, PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
    else:  # PY3
        assert not isinstance("test", PyInfo.string_types)
        assert isinstance("test", PyInfo.text_type)
       

# Generated at 2022-06-21 22:18:23.684814
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0

    # assert not isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)



# Generated at 2022-06-21 22:18:29.831347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert not PyInfo.PY2 or not PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:18:41.271314
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if it works with Python 2.x and 3.x
    assert PyInfo.PY2 != PyInfo.PY3
    # Set a value for PyInfo.PY2
    PyInfo.PY2 = True

    # Check if it works with Python 2.x and 3.x
    assert PyInfo.PY2 != PyInfo.PY3
    # Set a value for PyInfo.PY3
    PyInfo.PY3 = True

    # Check if it works with Python 2.x and 3.x
    assert PyInfo.PY2 != PyInfo.PY3
    # Set a value for PyInfo.PY2
    PyInfo.PY2 = False

    # Check if it works with Python 2.x and 3.x
    assert PyInfo.PY2 != PyInfo.PY3
    #

# Generated at 2022-06-21 22:18:45.010586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.maxsize > 1 << 30
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-21 22:18:51.379164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert issubclass(PyInfo.string_types[0], object)

    assert isinstance(PyInfo.text_type, type)
    assert issubclass(PyInfo.text_type, object)

    assert isinstance(PyInfo.binary_type, type)
    assert issubclass(PyInfo.binary_type, object)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert issubclass(PyInfo.integer_types[0], object)


# Generated at 2022-06-21 22:18:57.493550
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == unicode

    assert type(PyInfo.binary_type) == str
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:18:58.540497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


# EOF

# Generated at 2022-06-21 22:19:05.482755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pytest import raises

    assert isinstance(PyInfo.text_type(''), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(''), PyInfo.string_types)
    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, PyInfo.integer_types)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 22:19:19.716778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == sys.version_info[0] == 2
    assert pi.PY3 == sys.version_info[0] == 3
    if pi.PY3:
        assert pi.string_types == (str,)
        assert isinstance("str", pi.string_types)
        assert isinstance("str", pi.text_type)
        assert not isinstance("str", pi.binary_type)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert isinstance(0, pi.integer_types)
        assert not isinstance(0, pi.class_types)
        assert isinstance(pi, pi.class_types)
        assert pi.maxsize == sys.maxsize

# Generated at 2022-06-21 22:19:30.463557
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert 0 < PyInfo.maxsize < 10**10000
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert not isinstance(b'bytes', PyInfo.string_types)
    assert isinstance(123, PyInfo.integer_types)
    assert not isinstance(123.456, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(object, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:39.100633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)
    assert not isinstance(b"abc", PyInfo.string_types)

    assert isinstance("abc", PyInfo.text_type)
    assert not isinstance(b"abc", PyInfo.text_type)

    assert isinstance(b"abc", PyInfo.binary_type)
    assert not isinstance("abc", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:48.519135
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance(PyInfo.maxsize, int)
        assert isinstance(PyInfo.maxsize + 1, int)

        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance('h', PyInfo.string_types)
        assert not isinstance(u'h', PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)
        assert not isinstance(PyInfo, PyInfo.string_types)


# Generated at 2022-06-21 22:19:55.512201
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types, "", "", "")
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.maxsize)
    print(PyInfo.class_types)



# Generated at 2022-06-21 22:19:59.266372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    x.PY2
    x.PY3
    x.maxsize
    x.string_types
    x.text_type
    x.binary_type
    x.integer_types
    x.class_types



# Generated at 2022-06-21 22:20:11.339071
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:22.233331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    maxsize = (1 << 31) - 1 if sys.platform.startswith("java") else (
        1 << 63 - 1 if (1 << 63 - 1) > (1 << 31) - 1 else (1 << 31) - 1)
    assert PyInfo.maxsize == maxsize


#
# Encoding from file name
#

# Platform-dependent part

if sys.platform == "win32":
    # Do not use the default encoding, but
    # the one used by the terminal
    # (console window or command prompt).
    # This is mostly because of git-bash.
    import ctypes
    import ctypes.wintypes
    kbuf = ctypes.create_unicode_buffer

# Generated at 2022-06-21 22:20:24.367701
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 is True
    assert py_info.PY3 is False

# Generated at 2022-06-21 22:20:29.126412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:20:40.899167
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:48.912569
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)


__all__ = ["PyInfo"]

# Generated at 2022-06-21 22:20:49.551626
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-21 22:20:58.407543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY2 != (sys.version_info[0] == 3)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY3 != (sys.version_info[0] == 2)
    if PyInfo.PY3:
        assert type("") == PyInfo.string_types
        assert type("") == PyInfo.text_type
        assert type(b"") == PyInfo.binary_type
        assert type(1) == PyInfo.integer_types
        assert type(PyInfo) == PyInfo.class_types
    else:
        assert type("") == PyInfo.string_types
        assert type(u"") == PyInfo.text_type

# Generated at 2022-06-21 22:21:07.939820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
    else:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(b'bytes', PyInfo.binary_type)

# Generated at 2022-06-21 22:21:17.145461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:21:21.348715
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        import __builtin__  # noqa
    except ImportError:
        pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:24.173386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, PyInfo.PY3
    assert PyInfo.string_types, PyInfo.text_type
    assert PyInfo.binary_type, PyInfo.integer_types
    assert PyInfo.class_types, PyInfo.maxsize



# Generated at 2022-06-21 22:21:27.827773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, type(tuple()))
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    asse

# Generated at 2022-06-21 22:21:30.585840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # nothing to unit test
    pass

#=======================================================================================================================
# PyTypeInfo
#=======================================================================================================================

# Generated at 2022-06-21 22:21:51.936944
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:59.860247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal

    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3

    assert_equal(PyInfo.PY2, PY2)
    assert_equal(PyInfo.PY3, PY3)

    if PY3:
        assert_equal(PyInfo.string_types, (str,))
        assert_equal(PyInfo.text_type, str)
        assert_equal(PyInfo.binary_type, bytes)
        assert_equal(PyInfo.integer_types, (int,))
        assert_equal(PyInfo.class_types, (type,))

        assert_equal(PyInfo.maxsize, sys.maxsize)

# Generated at 2022-06-21 22:22:06.986696
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    if not PyInfo.PY2:
        assert "".encode() == b""
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type(0), PyInfo.class_types)

# Generated at 2022-06-21 22:22:09.233893
# Unit test for constructor of class PyInfo
def test_PyInfo():  # pragma: no cover
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is True



# Generated at 2022-06-21 22:22:19.393994
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    if info.PY3:
        assert info.string_types is str
        assert info.text_type is str
        assert info.binary_type is bytes
        assert info.integer_types is int
        assert isinstance(info.maxsize, int)
    else:
        assert info.string_types is basestring
        assert info.text_type is unicode
        assert info.binary_type is str
        assert isinstance(info.maxsize, int)


# Utility function to make sure that the constructors of the PyIni class
# are not being tested.

# Generated at 2022-06-21 22:22:21.672600
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert (isinstance("a", PyInfo.string_types) and
            not isinstance(u"a", PyInfo.string_types))
    assert PyInfo.maxsize > (1 << 30)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:22:30.537395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 ^ PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
    else:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:40.324864
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # Test x is an instance of int in python 2 and 3
    x = PyInfo.maxsize + 1
    assert isinstance(x, PyInfo.integer_types)
    assert isinstance(x, int)

    # Unit test for binary types
    x = 'test'
    assert isinstance(x, PyInfo.string_types)
    x = bytes('test', encoding='utf-8')
    assert isinstance(x, PyInfo.binary_type)

    # Test type is class type
    print(PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)



# do not execute test code if imported
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:51.233990
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _verify():
        assert PyInfo.PY2 != PyInfo.PY3
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:01.660543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert isinstance("a", PyInfo.binary_type)

        assert not isinstance("a", PyInfo.text_type)
        assert isinstance(u"a", PyInfo.text_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:27.735838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.integer_types + (str,))
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int, type)



# Generated at 2022-06-21 22:23:36.910398
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.maxsize > 0

    assert isinstance(1, PyInfo.integer_types)
    assert PyInfo.text_type == PyInfo.string_types[0]
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(type(1), PyInfo.class_types)


if __name__ == "__main__":
    import __main__ as main

    main.main()

# Generated at 2022-06-21 22:23:42.670444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    if info.PY2:
        assert 'basestring' in dir(info)
        assert 'ClassType' in dir(info)
    else:
        assert 'basestring' not in dir(info)
        assert 'ClassType' not in dir(info)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:23:48.259401
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py = PyInfo()

    assert isinstance(py.string_types, tuple)
    assert isinstance(py.text_type, type)
    assert isinstance(py.binary_type, type)
    assert isinstance(py.integer_types, tuple)
    assert isinstance(py.class_types, tuple)

    assert isinstance(py.maxsize, int)

# Generated at 2022-06-21 22:23:56.780800
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyinfo import PyInfo
    ps = PyInfo()
    print(ps.PY2)
    print(ps.PY3)
    print(ps.string_types)
    print(ps.text_type)
    print(ps.binary_type)
    print(ps.integer_types)
    print(ps.class_types)
    print(ps.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# python3 pyinfo.py
# False
# True
# (<class 'str'>,)
# <class 'str'>
# <class 'bytes'>
# (<class 'int'>,)
# (<class 'type'>,)
# 9223372036854775807

# Generated at 2022-06-21 22:24:01.319475
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = os.environ.get("PY2", False)
    py3 = os.environ.get("PY3", False)

    if py3:
        assert PyInfo.PY3 is True
        assert PyInfo.PY2 is False
    elif py2:
        assert PyInfo.PY3 is False
        assert PyInfo.PY2 is True
    else:
        assert py2 is False
        assert py3 is False


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:11.536241
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "There must be only two Python version"
    assert PyInfo.PY2 != PyInfo.PY3, "There must be only two Python version"
    assert isinstance(PyInfo.string_types, tuple), "`string_types` should be tuple"
    assert isinstance(PyInfo.text_type, type), "`text_type` should be type"
    assert isinstance(PyInfo.binary_type, type), "`binary_type` should be type"
    assert isinstance(PyInfo.integer_types, tuple), "`integer_types` should be tuple"
    assert isinstance(PyInfo.class_types, tuple), "`class_types` should be tuple"
    assert isinstance(PyInfo.maxsize, int), "`maxsize` should be int"

# Generated at 2022-06-21 22:24:22.501918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.class_types)
        assert isinstance(PyInfo, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)

# Generated at 2022-06-21 22:24:34.375897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


# Generated at 2022-06-21 22:24:36.223935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:25:24.197230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:25:31.232708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check expected values are as expected
    assert PyInfo.PY3 == ((sys.version_info[0] == 3))
    assert PyInfo.PY2 == ((sys.version_info[0] == 2))

    if PyInfo.PY3:
        assert type(PyInfo.maxsize) == int
        assert sys.maxsize == PyInfo.maxsize
        assert type(PyInfo.string_types) == tuple
        assert tuple(str) == PyInfo.string_types
        assert type(PyInfo.text_type) == type
        assert str == PyInfo.text_type
        assert type(PyInfo.binary_type) == type
        assert bytes == PyInfo.binary_type
        assert type(PyInfo.integer_types) == tuple
        assert tuple(int) == PyInfo.integer_types

# Generated at 2022-06-21 22:25:33.548800
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is not False

# Generated at 2022-06-21 22:25:42.733154
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize

    else:  # PyInfo.PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:25:53.978810
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert type('a') is PyInfo.string_types[0]
    assert isinstance('', PyInfo.binary_type)
    assert type('a') is not PyInfo.binary_type
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert type(b'a') is PyInfo.binary_type
    assert isinstance(1, PyInfo.integer_types)
    assert type(1) is PyInfo.integer_types[0]
    assert isinstance(1, PyInfo.integer_types)
    assert type(1) is PyInfo.integer_types[0]
    assert isinstance(True, bool)


# Generated at 2022-06-21 22:25:55.960706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:26:00.114025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)



# Generated at 2022-06-21 22:26:07.477528
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Placeholder for assertion function

# Generated at 2022-06-21 22:26:15.089198
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test PyInfo class"""
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:26:22.290822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, PyInfo.string_types)
    assert isinstance(PyInfo.binary_type, PyInfo.string_types)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == "__main__":
    import doctest

    doctest.testmod()