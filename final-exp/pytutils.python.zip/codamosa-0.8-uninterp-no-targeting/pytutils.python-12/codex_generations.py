

# Generated at 2022-06-21 22:18:02.749067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is False
    assert pyinfo.PY3 is True
    assert pyinfo.string_types is tuple
    assert pyinfo.text_type is str
    assert pyinfo.binary_type is bytes
    assert pyinfo.integer_types is tuple
    assert pyinfo.class_types is tuple
    assert pyinfo.maxsize is sys.maxsize

# Generated at 2022-06-21 22:18:12.397585
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_type(obj, cls):
        assert isinstance(obj, cls), (obj, cls)

    if sys.version_info[0] == 3:
        assert_type(int, PyInfo.integer_types)
        assert_type(str, PyInfo.string_types)
        assert_type(str, PyInfo.text_type)
        assert_type(bytes, PyInfo.binary_type)
        assert not isinstance(str, PyInfo.binary_type)
        assert not isinstance(bytes, PyInfo.text_type)

    if sys.version_info[0] == 2:
        assert_type(long, PyInfo.integer_types)
        assert_type(unicode, PyInfo.string_types)
        assert_type(unicode, PyInfo.text_type)
        assert_

# Generated at 2022-06-21 22:18:19.770386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Start test_PyInfo()...")

    assert PyInfo.PY2 or PyInfo.PY3, "Python version not supported"
    assert isinstance(PyInfo.string_types, tuple), \
        "variable string_types must be a tuple"
    assert isinstance(PyInfo.text_type, object), \
        "variable text_type must be an object"
    assert isinstance(PyInfo.binary_type, object), \
        "variable binary_type must be an object"
    assert isinstance(PyInfo.integer_types, tuple), \
        "variable integer_types must be a tuple"
    assert isinstance(PyInfo.class_types, tuple), \
        "variable class_types must be a tuple"

# Generated at 2022-06-21 22:18:30.663751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('abc', PyInfo.string_types)
    assert not isinstance(b'abc', PyInfo.string_types)

    assert isinstance('abc', PyInfo.text_type)
    assert not isinstance(b'abc', PyInfo.text_type)

    assert isinstance(b'abc', PyInfo.binary_type)
    assert not isinstance('abc', PyInfo.binary_type)

    assert isinstance(123, PyInfo.integer_types)
    assert not isinstance(12.3, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert not isinstance('abc', PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:18:35.854206
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 is True or PyInfo().PY2 is False
    assert PyInfo().PY3 is True or PyInfo().PY3 is False
    assert isinstance(PyInfo().maxsize, int)


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-21 22:18:40.387716
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 ^ PyInfo.PY3)
    assert isinstance(set(), PyInfo.class_types)
    assert 'Hello' in PyInfo.string_types


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:18:46.434647
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int



# Generated at 2022-06-21 22:18:50.263108
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long,)
    assert PyInfo.class_types == (type, types.ClassType,)
    assert PyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:19:02.098202
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    for obj in PyInfo.string_types:
        assert isinstance('', obj)
        assert not isinstance(b'', obj)
        assert isinstance('a', obj)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(b'a', PyInfo.binary_type)
    for obj in PyInfo.integer_types:
        assert isinstance(1, obj)
        assert not isinstance(1.0, obj)
    assert isinstance(type(1), PyInfo.class_types)
    assert isinstance(type(1.0), PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:19:14.034997
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert not PyInfo.PY3
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert not PyInfo.PY2
        assert PyInfo.PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    print(PyInfo.maxsize)

# Generated at 2022-06-21 22:19:18.022525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:19:23.869030
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)

    if PyInfo.PY2:
        assert PyInfo.PY2 is True and PyInfo.PY3 is False
    else:
        assert PyInfo.PY2 is False and PyInfo.PY3 is True


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:32.185779
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:40.745285
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2, PyInfo.PY3)
    if PyInfo.PY2:
        print('Python 2.7')
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-21 22:19:47.295576
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False
    assert PyInfo.PY2 is True
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == long(1 << 63) - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:51.311096
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=missing-docstring
    assert PyInfo.PY3


# Utility method for getting Python version

# Generated at 2022-06-21 22:19:56.135431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY3 == (sys.version_info[0] == 3))
    assert (PyInfo.PY2 == (sys.version_info[0] == 2))
    assert (PyInfo.maxsize == sys.maxsize)
    assert (PyInfo.maxsize == (1 << sys.maxsize.bit_length() - 1))
    assert (PyInfo.string_types == (str,) if PyInfo.PY3 else (basestring,))
    assert (PyInfo.text_type == str if PyInfo.PY3 else unicode)
    assert (PyInfo.binary_type == bytes if PyInfo.PY3 else str)
    assert (PyInfo.integer_types == (int,) if PyInfo.PY3 else (int, long))

# Generated at 2022-06-21 22:19:58.648854
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 or PyInfo.PY3)
    assert(PyInfo.PY2 != PyInfo.PY3)



# Generated at 2022-06-21 22:20:05.206932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Print all public members at class PyInfo
    print("\nList of public members at class PyInfo:")
    print("\n".join("\t{0}={1}".format(item[0], item[1])
                    for item in vars(PyInfo).items()
                    if not item[0].startswith("_")))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:08.017002
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # input is a string
    assert PyInfo().PY2 is False
    assert PyInfo().PY3 is True



# Generated at 2022-06-21 22:20:11.386819
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-21 22:20:12.758283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True, 'should be Python3'



# Generated at 2022-06-21 22:20:19.144594
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == str
    assert type(PyInfo.binary_type) == str
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:20:21.182128
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:20:24.566530
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    # TODO: check PyInfo.string_types, PyInfo.text_type, PyInfo.binary_type, PyInfo.integer_types, PyInfo.class_types, PyInfo.maxsize

# Generated at 2022-06-21 22:20:30.132404
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

    assert isinstance(PyInfo.maxsize, int)
    assert len(str(PyInfo.maxsize)) >= 10



# Generated at 2022-06-21 22:20:40.185932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert not isinstance(b'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert not isinstance('a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

# Generated at 2022-06-21 22:20:50.985002
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = sys.version_info[0] == 2
    if py2:  # Python 2
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.text_type)
        assert isinstance("a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:  # Python 3
        assert isinstance("a", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert isinstance(b"a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:21:00.237461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Just testing if the constructor that assigns values to class attributes
    works.
    """
    assert PyInfo.PY2
    assert not PyInfo.PY3
    # On Python 2, isinstance(True, bool) is False, so I can't use it.
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], basestring)
    assert isinstance(PyInfo.text_type, basestring)
    assert isinstance(PyInfo.binary_type, basestring)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], integer_types)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:21:10.538309
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> import sys
    >>> sys.version_info[0]
    3
    >>> isinstance('', PyInfo.string_types)
    True
    >>> isinstance(PyInfo.text_type(), PyInfo.string_types)
    True
    >>> isinstance(PyInfo.binary_type(), PyInfo.string_types)
    False
    >>> isinstance(1, PyInfo.integer_types)
    True
    >>> isinstance(PyInfo, PyInfo.class_types)
    True
    >>> isinstance(object, PyInfo.class_types)
    True
    >>> isinstance([], PyInfo.class_types)
    False
    >>> PyInfo.maxsize > 0
    True
    """
    pass


if __name__ == '__main__':
    import doctest

    doctest.testmod

# Generated at 2022-06-21 22:21:25.772846
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 2 ** 32
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    if PyInfo.PY3:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(u'', (list, dict, tuple))

# Generated at 2022-06-21 22:21:29.063140
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.string_types[0]) == type



# Generated at 2022-06-21 22:21:32.242937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:21:38.366568
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == (1 << 63) - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:40.163033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:48.152625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert (isinstance(__name__, str) if PyInfo.PY3 else isinstance(__name__, basestring))


if PyInfo.PY3:
    def u_string(s):
        if not isinstance(s, PyInfo.binary_type):
            return s
        return s.decode('utf-8')

    def b_string(s):
        if not isinstance(s, PyInfo.binary_type):
            return s.encode('utf-8')
        return s
else:
    def u_string(s):
        if not isinstance(s, PyInfo.text_type):
            s = s.decode('utf-8')
        return s


# Generated at 2022-06-21 22:21:57.178378
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1 << 31, PyInfo.integer_types)
    assert isinstance(1 << 63, PyInfo.integer_types)



# Generated at 2022-06-21 22:22:08.942070
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == 9223372036854775807

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:19.543674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert type(PyInfo.string_types) == tuple
        assert type(PyInfo.string_types[0]) == type

        assert type(PyInfo.text_type) == type
        assert type(PyInfo.binary_type) == type
        assert type(PyInfo.integer_types) == tuple

        assert type(PyInfo.maxsize) == type(1)
    else:  # PY2
        assert type(PyInfo.string_types) == tuple
        assert type(PyInfo.string_types[0]) == type

        assert type(PyInfo.text_type) == str  # unicode


# Generated at 2022-06-21 22:22:23.038346
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()

    assert type(pyi.PY2) == bool
    assert type(pyi.PY3) == bool

# Generated at 2022-06-21 22:22:42.671956
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Test(object):
        def __init__(self, expected_type):
            self.expected_type = expected_type

        def __eq__(self, other):
            return isinstance(other, self.expected_type)

    assert Test(PyInfo.text_type) == "1"
    assert Test(PyInfo.binary_type) == b"1"

    assert Test(PyInfo.integer_types) == 42
    assert Test(PyInfo.string_types) == u"1"

    # Python 2.7
    assert Test(PyInfo.class_types) == Test

    # Python 3.3
    assert Test(PyInfo.class_types) == Test

    # Python 2.7, Python 3.3
    if not PyInfo.PY2:
        assert Test(PyInfo.integer_types) == 42



# Generated at 2022-06-21 22:22:47.912771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(
        'a',
        PyInfo.string_types) if PyInfo.PY3 else isinstance('a', PyInfo.string_types)


test_PyInfo()

# Generated at 2022-06-21 22:22:52.344056
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3

    assert type(PyInfo.string_types) == tuple

    assert type(PyInfo.text_type) == str

    assert type(PyInfo.binary_type) == bytes

    assert type(PyInfo.integer_types) == tuple

    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-21 22:22:55.475358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
    else:
        assert PyInfo.binary_type == str
        assert PyInfo.text_type == unicode

# Generated at 2022-06-21 22:22:59.608039
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


# To run unit tests, use:
# python -m unittest pytypes.py

# Generated at 2022-06-21 22:23:07.348891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("dummy", PyInfo.string_types)
    assert isinstance(b"dummy", PyInfo.binary_type)
    assert isinstance(u"dummy", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 61, PyInfo.integer_types)  # check 64-bit Python
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-21 22:23:10.280996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:23:18.212920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # currently this only tests that the values did not change
    # possibly this could be extended to a parsing test
    # the following results were produced with python 2.7 on Ubuntu 12.04
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert isinstance(PyInfo.maxsize, int)

    # the following results were produced with python 3.3 on Ubuntu 12.04
    PyInfo.PY2 = False
    PyInfo.PY3 = True
    assert PyInfo.PY2 == False


# Generated at 2022-06-21 22:23:28.438637
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = sys.version_info[0] == 2
    print("PY2=" + str(PyInfo.PY2))
    print("PY3=" + str(PyInfo.PY3))
    assert PyInfo.PY2 == py2
    assert PyInfo.PY3 != py2

    print("maxsize=" + str(PyInfo.maxsize))
    print("string_types=" + str(PyInfo.string_types))
    print("text_type=" + str(PyInfo.text_type))
    print("binary_type=" + str(PyInfo.binary_type))
    print("integer_types=" + str(PyInfo.integer_types))
    print("class_types=" + str(PyInfo.class_types))

    if py2:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:23:38.050344
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("foo", PyInfo.string_types)
        assert isinstance(u"foo", PyInfo.string_types)
        assert isinstance(b"foo", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
    else:
        assert isinstance("foo", PyInfo.string_types)
        assert isinstance(b"foo", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:01.531710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.binary_type)
    else:
        assert isinstance(b"", PyInfo.binary_type)
    assert len(PyInfo.integer_types) > 0
    assert len(PyInfo.class_types) > 0
    assert int(PyInfo.maxsize) > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:06.142104
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert isinstance(None, PyInfo.class_types)


# noinspection PyUnusedLocal

# Generated at 2022-06-21 22:24:12.433357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert isinstance(py_info.PY2, bool)
    assert isinstance(py_info.PY3, bool)
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-21 22:24:19.700646
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('unicode', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1000000000, PyInfo.integer_types)
    assert isinstance(2 ** 128, PyInfo.integer_types)
    assert isinstance(2 ** 256, PyInfo.integer_types)
    assert isinstance(2 ** 512, PyInfo.integer_types)
    assert isinstance(2 ** 2048, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:25.130602
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)

# Generated at 2022-06-21 22:24:35.280023
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.maxsize < (1 << 63)

    if PyInfo.PY2:
        # On PY2, string_types is tuple of basestring and unicode
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
    else:
        # On PY3, string_types is tuple of str
        assert isinstance('', PyInfo.string_types)

    # On PY2, text_type is unicode and binary_type is str
    # On PY3, text_type is str and binary_type is bytes
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-21 22:24:42.201931
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-21 22:24:49.119484
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert "Hello" in PyInfo.string_types
    assert isinstance("Hello", PyInfo.string_types)
    assert isinstance(b"Hello", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:58.276417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("test", PyInfo.string_types)
    assert isinstance(u"test", PyInfo.string_types)
    assert isinstance(b"test", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:09.066038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert not isinstance("a", PyInfo.binary_type)
        assert isinstance(b"a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:58.706565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # For every version of Python we test
    assert PyInfo.PY2 or PyInfo.PY3  # Is either PY2 or PY3 set
    assert PyInfo.PY2 ^ PyInfo.PY3  # Is either PY2 or PY3 set, but not both

    # For each attribute
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.string_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) is int


# For convenience in importing the library in Python 2 and Python 3
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type

# Generated at 2022-06-21 22:26:10.287782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)

        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:26:14.497424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False or PyInfo.PY2 is True
    assert PyInfo.PY3 is False or PyInfo.PY3 is True
    assert PyInfo.string_types, tuple
    assert PyInfo.text_type, str
    assert PyInfo.binary_type, str
    assert PyInfo.integer_types, tuple
    assert PyInfo.class_types, tuple
    assert PyInfo.maxsize, int

# Generated at 2022-06-21 22:26:25.084381
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pprint import pprint

    PY_INFO = PyInfo()
    pprint(vars(PY_INFO))
    assert PY_INFO.PY2 is True or PY_INFO.PY3 is True
    assert PY_INFO.PY2 is not PY_INFO.PY3

    # attr_name_list = ['PY2', 'PY3', '__dict__', '__weakref__', 'binary_type',
    #                   'class_types', 'integer_types', 'maxsize',
    #                   'string_types', 'text_type']
    # for attr_name in attr_name_list:
    #     if not hasattr(PY_INFO, attr_name):
    #         print('PyInfo has no attr <{}>'.format(attr_

# Generated at 2022-06-21 22:26:31.652628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test whether the constructor of class PyInfo is correct.
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types

# Generated at 2022-06-21 22:26:37.941721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:26:39.780822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert object() is not object()



# Generated at 2022-06-21 22:26:47.421039
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # noinspection PyUnresolvedReferences
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test", PyInfo.text_type)
    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    print("Test PyInfo constructs successfully")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:26:51.911888
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo
    assert info.PY2 ^ info.PY3
    assert isinstance("", info.string_types)
    assert isinstance(u"", info.string_types)
    assert isinstance(b"", info.binary_type)
    assert isinstance(1, info.integer_types)
    assert isinstance(1, info.integer_types)
    assert isinstance(long(1), info.integer_types)

# Generated at 2022-06-21 22:27:02.660395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class PyInfo(object):
        pass

    PyInfo.PY2 = sys.version_info[0] == 2
    PyInfo.PY3 = sys.version_info[0] == 3

    if PyInfo.PY3:
        PyInfo.string_types = str,
        PyInfo.text_type = str
        PyInfo.binary_type = bytes
        PyInfo.integer_types = int,
        PyInfo.class_types = type,

        PyInfo.maxsize = sys.maxsize
    else:  # PyInfo.PY2
        PyInfo.string_types = basestring,
        PyInfo.text_type = unicode
        PyInfo.binary_type = str
        PyInfo.integer_types = (int, long)