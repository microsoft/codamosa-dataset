

# Generated at 2022-06-21 22:18:01.615604
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:18:09.340764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-21 22:18:14.992974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("hello", PyInfo.string_types)
    assert isinstance(u"hello", PyInfo.text_type)
    assert isinstance(b"hello", PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-21 22:18:17.442964
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:18:21.177358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-21 22:18:32.295873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:18:41.500018
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (unicode, str)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-21 22:18:49.470874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(b"a", PyInfo.text_type)

    assert isinstance(b"a", PyInfo.binary_type)
    assert not isinstance("a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 << 33, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)
   

# Generated at 2022-06-21 22:18:57.450785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Integer types
    for v in (-sys.maxsize, -1, 0, 1, sys.maxsize):
        assert isinstance(v, PyInfo.integer_types)

    # String types
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    # Class types
    class X(object):
        pass

    assert isinstance(X, PyInfo.class_types)
    del X


# Create binary type

# Generated at 2022-06-21 22:19:00.846145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-21 22:19:09.256937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is True or info.PY3 is True
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, str)
    assert isinstance(info.binary_type, str)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)

# Generated at 2022-06-21 22:19:11.980093
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class_type = PyInfo.class_types
    assert isinstance(PyInfo, class_type)

# Generated at 2022-06-21 22:19:19.129775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 is not False
    assert pyinfo.PY3 is not True
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, str)
    assert isinstance(pyinfo.binary_type, str)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-21 22:19:29.075610
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)

    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:19:38.119386
# Unit test for constructor of class PyInfo
def test_PyInfo():

    def assert_string(s):
        assert s is PyInfo.string_types[0]

    def assert_text(s):
        assert s is PyInfo.text_type

    def assert_binary(s):
        assert s is PyInfo.binary_type

    def assert_int(s):
        assert s is PyInfo.integer_types[0]

    def assert_class(s):
        assert s is PyInfo.class_types[0]

    if PyInfo.PY2:
        assert_string(basestring)
        assert_text(unicode)
        assert_binary(str)
        assert_int(int)
        assert_class(types.ClassType)
        assert PyInfo.maxsize == 9223372036854775807
    else:
        assert_string(str)
        assert_text

# Generated at 2022-06-21 22:19:47.260527
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test the constructor of class PyInfo
    assert PyInfo
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('hello', PyInfo.string_types)
    assert isinstance(u'hello', PyInfo.text_type)
    assert isinstance(b'hello', PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:55.855250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:07.539067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 and not PyInfo.PY3)

    assert(isinstance("", PyInfo.string_types) and isinstance(b"", PyInfo.string_types))
    assert(isinstance("", PyInfo.string_types) and not isinstance(u"", PyInfo.string_types))
    assert(isinstance(u"", PyInfo.string_types) and isinstance(b"", PyInfo.string_types))
    assert(isinstance(u"", PyInfo.string_types) and not isinstance("", PyInfo.string_types))
    assert(isinstance("", PyInfo.text_type) and not isinstance(b"", PyInfo.text_type))

# Generated at 2022-06-21 22:20:12.749164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 is not None
    assert info.PY3 is not None
    assert info.string_types is not None
    assert info.text_type is not None
    assert info.binary_type is not None
    assert info.integer_types is not None
    assert info.class_types is not None
    assert info.maxsize is not None

# Generated at 2022-06-21 22:20:23.719985
# Unit test for constructor of class PyInfo
def test_PyInfo():

    if not PyInfo.PY2:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:20:33.226632
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("foo", PyInfo.text_type)
    assert isinstance(b"foo", PyInfo.binary_type)
    assert isinstance(42, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:43.895293
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.binary_type)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("", PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(max(1, 2, 3), PyInfo.integer_types)
    assert isinstance(min(1, 2, 3), PyInfo.integer_types)
    assert isinstance(1 << 63, PyInfo.integer_types)
    assert isinstance(1 << 200, PyInfo.integer_types)



# Generated at 2022-06-21 22:20:48.406230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from py_mini_racer import PyInfo

    assert (not PyInfo.PY2) is PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:56.281727
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:04.414868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    DATA = [
        (PyInfo.PY2, 2, '2'),
        (PyInfo.PY3, 3, '3'),
        (PyInfo.string_types, str, 'basestring'),
        (PyInfo.text_type, str, 'unicode'),
        (PyInfo.binary_type, bytes, 'str'),
        (PyInfo.integer_types, (int, long), '(int, long)'),
        (PyInfo.class_types, (type, types.ClassType), '(<type \'type\'>, <type \'type\'>)'),
        (PyInfo.maxsize, int((1 << 31) - 1), '2147483647')
    ]

    for i in range(1, len(DATA)):
        assert isinstance(DATA[i][0], DATA[i][1])

# Generated at 2022-06-21 22:21:10.530115
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 is True or p.PY3 is True
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)



# Generated at 2022-06-21 22:21:20.946508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:21:26.619920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert sys.version_info[0] == PyInfo.PY2 + PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:33.774405
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert "int" in str(PyInfo.PY2)
    assert "int" in str(PyInfo.PY3)

    assert "tuple" in str(PyInfo.string_types)
    assert "tuple" in str(PyInfo.integer_types)
    assert "tuple" in str(PyInfo.class_types)

    assert "str" in str(PyInfo.text_type)
    assert "str" in str(PyInfo.binary_type)

# Generated at 2022-06-21 22:21:38.425248
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True or PyInfo.PY3 is not True
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is str
    assert type(PyInfo.binary_type) is str
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-21 22:21:53.530084
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-21 22:22:00.385760
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import types
    from collections import Iterable
    from types import FunctionType
    from types import LambdaType
    from types import Generatored
    """
    Test for class PyInfo
    """

    if PyInfo.PY2:
        print('Now, in Python2.x')
        print(isinstance([], list))
        print(isinstance([], Iterable))
        print(isinstance((), tuple))
        print(isinstance((), Iterable))
        print(isinstance(set, types.BuiltinFunctionType))
        print(isinstance(lambda x: x, LambdaType))

# Generated at 2022-06-21 22:22:11.186836
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.text_type)
    assert isinstance(b"foo", PyInfo.binary_type)
    assert isinstance(42, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:17.856454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        # Checking string types
        assert isinstance('A', PyInfo.string_types)
        assert not isinstance(u'A', PyInfo.string_types)
        assert isinstance(b'A', PyInfo.string_types)

        # Checking text type
        assert not isinstance('A', PyInfo.text_type)
        assert isinstance(u'A', PyInfo.text_type)

        # Checking binary type
        assert isinstance('A', PyInfo.binary_type)
        assert not isinstance(u'A', PyInfo.binary_type)
        assert isinstance(b'A', PyInfo.binary_type)

        # Checking integer types
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.integer_types)

       

# Generated at 2022-06-21 22:22:24.684777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_true, assert_false, assert_equal
    assert_false(PyInfo.PY2)
    assert_true(PyInfo.PY3)
    assert_equal(PyInfo.string_types, (str,))
    assert_equal(PyInfo.text_type, str)
    assert_equal(PyInfo.binary_type, bytes)
    assert_equal(PyInfo.integer_types, (int,))
    assert_true(PyInfo.maxsize > 0)



# Generated at 2022-06-21 22:22:32.697355
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    assert pyinfo.string_types == (basestring,)
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)

    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str

    assert pyinfo.maxsize == sys.maxsize


if PyInfo.PY3:
    def int_types():
        return int,
else:  # PY2
    def int_types():
        return int, long

# Generated at 2022-06-21 22:22:39.662435
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize

    for i in [1, 2]:
        assert i in PyInfo.integer_types

    for i in ['1', '2', u'1', u'2']:
        assert i in PyInfo.string_types

    for i in [1, 2]:
        assert not i in PyInfo.string_types

    for i in [1, 2]:
        assert type(i) in PyInfo.class_types


test_PyInfo()

# Generated at 2022-06-21 22:22:46.893801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.text_type == unicode
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.text_type == str

    assert PyInfo.class_types == (type,) or PyInfo.class_types == (type, types.ClassType)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance("", PyInfo.integer_types)

# Generated at 2022-06-21 22:22:57.390432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.string_types)
    assert not isinstance(b"abc", PyInfo.string_types)

    assert isinstance("abc", PyInfo.text_type)
    assert not isinstance(u"abc", PyInfo.text_type)
    assert not isinstance(b"abc", PyInfo.text_type)

    assert isinstance(b"abc", PyInfo.binary_type)
    assert not isinstance("abc", PyInfo.binary_type)
    assert not isinstance(u"abc", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:04.297251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or not PyInfo.PY3
    assert PyInfo.PY2 or not PyInfo.PY2
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-21 22:23:29.716207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('text', PyInfo.string_types)
    assert isinstance(u'text', PyInfo.string_types)
    assert not isinstance(True, PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:39.483391
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()

    for _ in range(100):
        assert i.PY3 or i.PY2, 'PY3 or PY2 must be True'

        is_str = isinstance('test', i.string_types)
        assert is_str, 'test must be string_types'

        is_text = isinstance('test', i.text_type)
        assert is_text, 'test must be text_type'

        is_binary = isinstance(b'test', i.binary_type)
        assert is_binary, 'b\'test\' must be binary_type'

        assert i.maxsize, 'size of long must be greater then zero'

# Generated at 2022-06-21 22:23:49.977849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for Py2
    sys.version_info = (2, 7)
    reload(PyInfo)
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        maxsize = int((1 << 31) - 1)
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31


# Generated at 2022-06-21 22:23:56.074446
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert not PyInfo.PY2 or not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:24:00.615700
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:24:11.452778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Unit test for PyInfo
    :return:
    """
    print("Testing PyInfo")
    pyinfo = PyInfo()
    print("PyInfo.PY2: %s" % pyinfo.PY2)
    print("PyInfo.PY3: %s" % pyinfo.PY3)

    print("PyInfo.string_types: %s" % pyinfo.string_types)
    print("PyInfo.text_type: %s" % pyinfo.text_type)
    print("PyInfo.binary_type: %s" % pyinfo.binary_type)

    print("PyInfo.integer_types: %s" % pyinfo.integer_types)
    print("PyInfo.class_types: %s" % pyinfo.class_types)


# Generated at 2022-06-21 22:24:19.333498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None  # nosec
    assert PyInfo.PY3 is not None  # nosec
    assert PyInfo.string_types is not None  # nosec
    assert PyInfo.text_type is not None  # nosec
    assert PyInfo.binary_type is not None  # nosec
    assert PyInfo.maxsize is not None  # nosec


ATTR_NAME = r"[a-zA-Z_][a-zA-Z0-9_]*"



# Generated at 2022-06-21 22:24:24.318781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.class_types)
    print(PyInfo.integer_types)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:24:33.624184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()
    assert pyi.PY2 is not True
    assert pyi.PY3 is not True
    assert pyi.maxsize == sys.maxsize
    _assert_type_equal(pyi.string_types, tuple)
    _assert_type_equal(pyi.text_type, type)
    _assert_type_equal(pyi.binary_type, type)
    _assert_type_equal(pyi.integer_types, tuple)
    _assert_type_equal(pyi.class_types, tuple)



# Generated at 2022-06-21 22:24:41.394898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple) is True
    assert isinstance(PyInfo.text_type, type) is True
    assert isinstance(PyInfo.binary_type, type) is True
    assert isinstance(PyInfo.integer_types, tuple) is True
    assert isinstance(PyInfo.class_types, tuple) is True
    assert isinstance(PyInfo.maxsize, int) is True

# Generated at 2022-06-21 22:25:25.320542
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-21 22:25:26.834450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:25:38.562025
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is not False
    assert isinstance('a', PyInfo.string_types) is True
    assert isinstance(u'a', PyInfo.string_types) is True
    assert isinstance(b'a', PyInfo.binary_type) is True
    assert isinstance(1, PyInfo.integer_types) is True

# Generated at 2022-06-21 22:25:44.000769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    if PyInfo.PY3:
        assert "text" == PyInfo.text_type("text")
    else:  # PY2
        assert "text" != PyInfo.text_type("text")



# Generated at 2022-06-21 22:25:51.490165
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, (int, long))

# Generated at 2022-06-21 22:25:56.670809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-21 22:26:08.828342
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(u"abc", PyInfo.text_type)

    assert isinstance(123, PyInfo.integer_types)

    class Dummy:
        pass

    assert isinstance(Dummy, PyInfo.class_types)

    assert PyInfo.maxsize != 0


# Call function _test() if module is executed as main script
# (if you want to run unit tests)
if __name__ == "__main__":
    import inspect

    inps = inspect.getargspec(test_PyInfo.__wrapped__)
    args = list(inps.args)
    args.remove("self")

# Generated at 2022-06-21 22:26:13.161197
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

# Generated at 2022-06-21 22:26:20.586854
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Type check
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)


test_PyInfo()

# Generated at 2022-06-21 22:26:28.849478
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PyInfo.PY2: %s" % PyInfo.PY2)
    print("PyInfo.PY3: %s" % PyInfo.PY3)

    print("PyInfo.string_types: %s" % PyInfo.string_types)
    print("PyInfo.text_type: %s" % PyInfo.text_type)
    print("PyInfo.binary_type: %s" % PyInfo.binary_type)
    print("PyInfo.integer_types: %s" % PyInfo.integer_types)
    print("PyInfo.class_types: %s" % PyInfo.class_types)
    print("PyInfo.maxsize: %s" % PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()