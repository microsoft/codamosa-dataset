

# Generated at 2022-06-21 22:18:04.028078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


# Generated at 2022-06-21 22:18:10.054741
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type, types.TypeType)
    assert isinstance(PyInfo.binary_type, types.TypeType)
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types[0], types.TypeType)
    else:
        # Python3 raise TypeError if use types.ClassType
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.string_types[0] == str
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

# Generated at 2022-06-21 22:18:20.780288
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Foo:
        pass

    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance(42, PyInfo.integer_types)
        assert isinstance(long(42), PyInfo.integer_types)
        assert isinstance(Foo, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
        assert isinstance(42, PyInfo.integer_types)
        assert not isinstance(long(42), PyInfo.integer_types)

# Generated at 2022-06-21 22:18:22.495843
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

# Generated at 2022-06-21 22:18:31.830022
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check_type(py_info, target):
        if not isinstance(target, py_info.string_types):
            raise Exception("string_types failed")
        if not isinstance(target, py_info.integer_types):
            raise Exception("integer_types failed")

    check_type(PyInfo(), "test")
    check_type(PyInfo(), 123)
    if PyInfo().PY2 and sys.maxsize != PyInfo().maxsize:
        raise Exception("maxsize failed")
    if PyInfo().PY3:
        if sys.maxunicode != 0x10ffff:
            raise Exception("maxunicode failed")
        if len(u"\U0010FFFF") != 1:
            raise Exception("Unicode failed")

# Generated at 2022-06-21 22:18:43.074754
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # see PEP-0020
    assert "Zen of Python" != "Zen of Python"
    assert "Zen of Python" == u"Zen of Python"

    assert isinstance("Zen of Python", PyInfo.string_types)
    assert isinstance(u"Zen of Python", PyInfo.string_types)

    if PyInfo.PY3:
        assert type("Zen of Python") == str
        assert type(u"Zen of Python") == str
    else:
        assert type("Zen of Python") == str
        assert type(u"Zen of Python") == unicode

    assert isinstance("Zen of Python", PyInfo.text_type)
    assert isinstance(u"Zen of Python", PyInfo.text_type)

    assert isinstance("Zen of Python", PyInfo.binary_type)

# Generated at 2022-06-21 22:18:52.230074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test PyInfo."""
    from nose.tools import assert_equals, assert_is_instance

    pyinfo = PyInfo()
    assert_equals(isinstance(pyinfo, object), True)
    assert_equals(isinstance(pyinfo.PY2, bool), True)
    assert_equals(isinstance(pyinfo.PY3, bool), True)
    assert_equals(isinstance(pyinfo.string_types, tuple), True)
    assert_is_instance("hello", pyinfo.string_types)
    assert_equals(isinstance(pyinfo.text_type, type), True)
    assert_equals(isinstance("hello", pyinfo.text_type), True)
    assert_equals(isinstance(pyinfo.binary_type, type), True)

# Generated at 2022-06-21 22:19:03.373345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert "str" in PyInfo.string_types
        assert u"str" not in PyInfo.string_types
        assert "str" is PyInfo.text_type
        assert u"str" not in PyInfo.text_type
    else:
        assert "str" in PyInfo.string_types
        assert u"str" in PyInfo.string_types
        assert "str" not in PyInfo.text_type
        assert u"str" is PyInfo.text_type

    assert "str" is PyInfo.binary_type
    assert u"str" not  in PyInfo.binary_type

    assert 1 in PyInfo.integer_types

# Generated at 2022-06-21 22:19:15.748533
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types is type
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize in (2147483647, 9223372036854775807)

# Generated at 2022-06-21 22:19:23.380732
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def is_unicode(x):
        return isinstance(x, PyInfo.text_type)

    def is_binary(x):
        return isinstance(x, PyInfo.binary_type)

    def is_string(x):
        return isinstance(x, PyInfo.string_types)

    def is_int(x):
        return isinstance(x, int)

    print("PyInfo.PY2", PyInfo.PY2)
    print("PyInfo.PY3", PyInfo.PY3)
    print("is_unicode(u'foo')", is_unicode(u'foo'))
    print("is_binary(u'foo')", is_binary(u'foo'))
    print("is_string(u'foo')", is_string(u'foo'))

# Generated at 2022-06-21 22:19:32.419805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    if PyInfo.PY2:
        assert isinstance(PyInfo.binary_type, types.StringType)
        assert isinstance(PyInfo.text_type, types.UnicodeType)
    if PyInfo.PY3:
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.text_type, str)



# Generated at 2022-06-21 22:19:38.969949
# Unit test for constructor of class PyInfo
def test_PyInfo():  # noqa
    pyinfo = PyInfo()

    # string_types
    assert "str" in pyinfo.string_types
    # text_type
    assert pyinfo.text_type is not None
    # binary_type
    assert pyinfo.binary_type is not None
    # integer_types
    assert int in pyinfo.integer_types
    # class_types
    assert type in pyinfo.class_types
    # maxsize
    assert pyinfo.maxsize is not None

    # PY2
    assert pyinfo.PY2 is not None
    # PY3
    assert pyinfo.PY3 is not None

# Generated at 2022-06-21 22:19:48.415615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3  # exactly one of these should be true
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize in [2147483647, 9223372036854775807]


if __name__ == "__main__":
    import pytest

    pytest.main(args=[".", "--doctest-modules", "-v", "--capture=sys"])

# Generated at 2022-06-21 22:20:00.694842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    error = False

    # Define some variables that are used within the test.
    text = "hello, world"
    binary = b"hello, world"

    # Check the class definitions for PyInfo.PY2 and PyInfo.PY3.
    if PyInfo.PY2:
        assert isinstance(text, PyInfo.text_type)
        assert isinstance(binary, PyInfo.binary_type)
        assert not isinstance(binary, PyInfo.text_type)
        assert not isinstance(text, PyInfo.binary_type)
    elif PyInfo.PY3:
        assert isinstance(text, PyInfo.text_type)
        assert isinstance(binary, PyInfo.binary_type)
        assert not isinstance(binary, PyInfo.text_type)

# Generated at 2022-06-21 22:20:12.555010
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:20:19.277326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3
    assert pi.text_type is str or pi.text_type is unicode
    if pi.PY3:
        assert pi.maxsize == sys.maxsize
    assert pi.class_types is type or pi.class_types is types.ClassType
    assert pi.binary_type is bytes or pi.binary_type is str
    assert pi.string_types is basestring or pi.string_types is str



# Generated at 2022-06-21 22:20:24.851255
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(Test, PyInfo.class_types)



# Generated at 2022-06-21 22:20:30.097434
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert type(p.PY2) == bool
    assert type(p.PY3) == bool
    assert type(p.string_types) == tuple
    assert type(p.text_type) == str
    assert type(p.binary_type) == str
    assert type(p.integer_types) == tuple
    assert type(p.class_types) == tuple
    assert type(p.maxsize) == int



# Generated at 2022-06-21 22:20:37.739083
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 != pyinfo.PY3
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)
    assert isinstance(pyinfo.text_type, type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:44.253032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3

    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] == str  # type basestring is not available

    assert PyInfo.text_type == str

    assert len(PyInfo.integer_types) == 1
    assert PyInfo.integer_types[0] == int

    assert len(PyInfo.class_types) == 1
    assert PyInfo.class_types[0] == type

# Generated at 2022-06-21 22:20:57.161674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:04.914759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert issubclass(PyInfo.string_types[0], PyInfo.text_type)
        assert issubclass(PyInfo.binary_type, PyInfo.binary_type)
        assert isinstance(b"s", PyInfo.binary_type)
    else:
        assert issubclass(PyInfo.string_types[0], PyInfo.binary_type)
        assert issubclass(PyInfo.text_type, PyInfo.string_types[0])
        assert isinstance(u"s", PyInfo.text_type)
        assert isinstance("s", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types[0])

    assert issubclass(PyInfo.class_types[0], object)

# Generated at 2022-06-21 22:21:15.111919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:25.702329
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert not issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert not issubclass(int, PyInfo.string_types)

    assert issubclass(PyInfo.text_type, text_type)
    assert issubclass(PyInfo.binary_type, binary_type)

    assert not issubclass(PyInfo.binary_type, PyInfo.text_type)
    assert not issubclass(PyInfo.text_type, PyInfo.binary_type)
    assert not issubclass(PyInfo.string_types, PyInfo.binary_type)

# Generated at 2022-06-21 22:21:37.187012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(object):
        def setUp(self):
            pass

        def tearDown(self):
            pass

        def test_string_type(self):
            self.assertIsInstance('', PyInfo.string_types)
            self.assertIsInstance(u'', PyInfo.string_types)

        def test_text_type(self):
            self.assertIsInstance('', PyInfo.text_type)
            self.assertIsInstance(u'', PyInfo.text_type)

        def test_binary_type(self):
            self.assertIsInstance('', PyInfo.binary_type)
            self.assertNotIsInstance(b'', PyInfo.binary_type)


# Generated at 2022-06-21 22:21:41.931225
# Unit test for constructor of class PyInfo
def test_PyInfo():

    # TEST STRICTLY PYTHON 2 FUNCTIONALITY
    if not PyInfo.PY2:
        raise Exception("Incorrect python version running tests")

    # TEST STRICTLY PYTHON 3 FUNCTIONALITY
    if not PyInfo.PY3:
        raise Exception("Incorrect python version running tests")

# Generated at 2022-06-21 22:21:48.761764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    assert isinstance(obj.PY2, bool)
    assert isinstance(obj.PY3, bool)
    assert isinstance(obj.integer_types, tuple)
    assert isinstance(obj.maxsize, int)
    for item in ["string_types", "text_type", "binary_type",
                 "class_types", "integer_types", "maxsize"]:
        if item in (["string_types", "class_types"] if obj.PY3 else
                    []):
            assert isinstance(getattr(obj, item), tuple)
        elif item in (["string_types"] if obj.PY2 else []):
            assert isinstance(getattr(obj, item), tuple)
        else:
            assert isinstance(getattr(obj, item), type)



# Generated at 2022-06-21 22:21:58.382919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    if pyinfo.PY2 or pyinfo.PY3:
        assert pyinfo.PY2 ^ pyinfo.PY3

    assert pyinfo.maxsize

    if pyinfo.PY3:
        assert Callable(pyinfo.string_types)
        assert Callable(pyinfo.text_type)
        assert Callable(pyinfo.binary_type)
        assert Callable(pyinfo.integer_types)
        assert Callable(pyinfo.class_types)
    else:
        assert isinstance("", pyinfo.string_types)
        assert isinstance(u"", pyinfo.text_type)
        assert isinstance("", pyinfo.binary_type)
        assert isinstance(1, pyinfo.integer_types)

# Generated at 2022-06-21 22:22:08.220742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(PyInfo.text_type(u''), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(b''), PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(1, PyInfo.class_types) if PyInfo.PY2 else False
    assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:22:16.061158
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert not isinstance(b"a", PyInfo.text_type)
        assert isinstance(b"a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:30.022187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:22:31.235131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3



# Generated at 2022-06-21 22:22:37.806369
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)


import os
import re
import subprocess
import sys
import logging
import traceback

import click
import pkg_resources

logging.basicConfig()
logger = logging.getLogger('pip-licenses')

# Generated at 2022-06-21 22:22:45.795009
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:22:47.964682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-21 22:22:55.645192
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_cases = (
        (PyInfo.PY2, False),
        (PyInfo.PY3, True),
        (PyInfo.string_types, (str, basestring)),
        (PyInfo.text_type, (str, unicode)),
        (PyInfo.binary_type, (bytes, str)),
        (PyInfo.integer_types, (int, long, int)),
        (PyInfo.class_types, (type, types.ClassType, type)),
    )
    for t_class, t_type in test_cases:
        assert t_type is t_class



# Generated at 2022-06-21 22:23:06.487113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal
    assert_equal(PyInfo.PY2, sys.version_info[0] == 2)
    assert_equal(PyInfo.PY3, sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert_equal(PyInfo.maxsize, sys.maxsize)
        assert_equal(PyInfo.string_types, (str,))
        assert_equal(PyInfo.text_type, str)
        assert_equal(PyInfo.binary_type, bytes)
        assert_equal(PyInfo.integer_types, (int,))
        assert_equal(PyInfo.class_types, (type,))
    else:
        assert_equal(PyInfo.maxsize, 2147483647)

# Generated at 2022-06-21 22:23:16.184978
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "PY2 or PY3 is False"
    py_info = PyInfo()
    # string_types = (str, unicode)
    assert isinstance("Test", py_info.string_types)
    assert isinstance(u"Test", py_info.string_types)
    # text_type is str or unicode
    assert isinstance("Test", py_info.text_type)
    if type(u"Test") != str:  # PY2
        assert isinstance(u"Test", py_info.text_type)
    # binary_type is str or bytes
    assert isinstance("Test", py_info.binary_type)
    assert isinstance(b"Test", py_info.binary_type)
    # integer_types = (int,

# Generated at 2022-06-21 22:23:24.522428
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("test_str", PyInfo.string_types)
    assert isinstance(b"test_bytes", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:29.550844
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance("string", PyInfo.string_types)
    assert isinstance("string", PyInfo.text_type)
    assert isinstance(b"binary", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:55.673258
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:24:06.477501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    status = True
    try:
        if PyInfo.PY2:
            assert PyInfo.string_types is not None
            assert PyInfo.text_type is not None
            assert PyInfo.binary_type is not None
            assert PyInfo.integer_types is not None
            assert PyInfo.class_types is not None
            assert PyInfo.maxsize is not None
        else:
            assert PyInfo.string_types is not None
            assert PyInfo.text_type is not None
            assert PyInfo.binary_type is not None
            assert PyInfo.integer_types is not None
            assert PyInfo.class_types is not None
            assert PyInfo.maxsize is not None
    except AssertionError:
        status = False
        print("Fail to construct class PyInfo")

# Generated at 2022-06-21 22:24:13.638156
# Unit test for constructor of class PyInfo
def test_PyInfo():

    global PY2, PY3
    py2 = sys.version_info[0] == 2
    py3 = sys.version_info[0] == 3

    assert PY2 == py2
    assert PY3 == py3

    if PY2:
        assert isinstance('', basestring)
        assert isinstance('', str)
        assert not isinstance('', text_type)
        assert isinstance(u'', basestring)
        assert isinstance(u'', text_type)
        assert not isinstance(u'', str)
    else:
        assert isinstance('', str)
        assert isinstance(u'', str)
        assert not isinstance('', text_type)
        assert not isinstance(u'', text_type)

# Generated at 2022-06-21 22:24:24.179846
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert not isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(1 << 64, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:32.829136
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2
    assert isinstance("", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-21 22:24:43.519525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('' + '', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(u''.encode('utf-8'), PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(classmethod, PyInfo.class_types)
    assert isinstance(sys.maxsize, int)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:24:52.938142
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 or pyinfo.PY3
    assert not pyinfo.PY2 or not pyinfo.PY3

    assert isinstance("a", pyinfo.string_types)
    assert not isinstance(1, pyinfo.string_types)

    assert isinstance("a", pyinfo.text_type)
    assert not isinstance(1, pyinfo.text_type)

    assert isinstance(b"a", pyinfo.binary_type)
    assert not isinstance(1, pyinfo.binary_type)

    assert isinstance(3, pyinfo.integer_types)
    assert isinstance(3, pyinfo.integer_types)
    assert isinstance(3, pyinfo.integer_types)
    assert not isinstance("a", pyinfo.integer_types)

   

# Generated at 2022-06-21 22:25:04.625667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from typer.testing import TyperTestCase

    class TestPyInfo(TyperTestCase):
        def test_py2(self):
            if PyInfo.PY2:
                self.assertIsInstance(PyInfo.maxsize, (int, long))
                self.assertEqual(PyInfo.string_types, (basestring,))
                self.assertIsInstance(PyInfo.text_type, unicode)
                self.assertIsInstance(PyInfo.binary_type, str)
                self.assertEqual(PyInfo.integer_types, (int, long))
                self.assertEqual(PyInfo.class_types, (type, types.ClassType))

        def test_py3(self):
            if PyInfo.PY3:
                self.assertIsInstance(PyInfo.maxsize, int)
               

# Generated at 2022-06-21 22:25:12.374372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("text", PyInfo.string_types)
        assert not isinstance(b"bytes", PyInfo.string_types)
        assert isinstance("text", PyInfo.text_type)
        assert not isinstance(b"bytes", PyInfo.text_type)
        assert isinstance(b"bytes", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1.1, PyInfo.integer_types)
        assert isinstance(type(1), PyInfo.class_types)
        assert not isinstance(1, PyInfo.class_types)
    else:
        assert isinstance("text", PyInfo.string_types)
        assert isinstance(b"bytes", PyInfo.string_types)

# Generated at 2022-06-21 22:25:16.526049
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    for tp in PyInfo.string_types:
        assert isinstance(tp, type)



# Generated at 2022-06-21 22:25:59.294425
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)



# Generated at 2022-06-21 22:26:05.700556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:26:12.135413
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo.PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert type(pyinfo.string_types) is tuple
    assert type(pyinfo.text_type) is str
    assert type(pyinfo.binary_type) is str
    assert type(pyinfo.integer_types) is tuple
    assert type(pyinfo.class_types) is tuple
    assert type(pyinfo.maxsize) is int

# Generated at 2022-06-21 22:26:18.967547
# Unit test for constructor of class PyInfo
def test_PyInfo():
    length = len(PyInfo.__dict__)
    length_expect = 8

    if PyInfo.PY2:
        length_expect += 1

    assert length == length_expect, length

    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, int), type(PyInfo.maxsize)
    else:
        assert isinstance(PyInfo.maxsize, int), type(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-21 22:26:23.377651
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        def test_PyInfo(self):
            self.assertTrue(PyInfo.PY2 or PyInfo.PY3)

    unittest.main()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:26:30.562331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False or PyInfo.PY2 is True
    assert PyInfo.PY3 is False or PyInfo.PY3 is True

    if PyInfo.PY3:
        assert PyInfo.maxsize >= (1 << 31) - 1
        assert isinstance(b"str", PyInfo.binary_type)
        assert isinstance("str", PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
    else:  # PY2
        assert PyInfo.maxsize <= (1 << 31) - 1
        # If assert isinstance(b"str", PyInfo.binary_type) fails here, it
        # might be related to the following issue:
        # https://issues.apache.org/jira

# Generated at 2022-06-21 22:26:41.185503
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('xxx', PyInfo.string_types)
    else:
        assert not isinstance(b'xxx', PyInfo.string_types)

    if PyInfo.PY3:
        assert isinstance(b'xxx', PyInfo.binary_type)
    else:
        assert not isinstance(b'xxx', PyInfo.binary_type)

    if PyInfo.PY2:
        assert isinstance(u'xxx', PyInfo.text_type)
    else:
        assert not isinstance(u'xxx', PyInfo.text_type)

    if PyInfo.PY3:
        assert isinstance(b'xxx', PyInfo.binary_type)
    else:
        assert not isinstance(b'xxx', PyInfo.binary_type)

# Generated at 2022-06-21 22:26:48.432118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:26:50.369814
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:26:53.872054
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    import doctest

    doctest.testmod()