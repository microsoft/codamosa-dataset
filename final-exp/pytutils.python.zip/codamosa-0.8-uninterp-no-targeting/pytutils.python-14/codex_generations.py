

# Generated at 2022-06-21 22:18:10.745859
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(u'', PyInfo.string_types)

# Generated at 2022-06-21 22:18:18.736592
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, int)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-21 22:18:29.621975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:39.091892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:18:47.878066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert isinstance('f', PyInfo.string_types)
        assert not isinstance(b'f', PyInfo.binary_type)
        assert isinstance(u'f', PyInfo.text_type)
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(object, PyInfo.class_types)
    if PyInfo.PY3:
        assert isinstance('f', PyInfo.string_types)

# Generated at 2022-06-21 22:18:53.755621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-21 22:19:00.683836
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        not_exist_attributes = [
            "not_exist", "py2", "py3", "string_types",
            "text_type", "binary_type", "integer_types",
            "class_types", "maxsize"
        ]
        for attr in not_exist_attributes:
            getattr(PyInfo, attr)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:03.322345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-21 22:19:15.702170
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    sys.version_info = (2, 7, 3, 'final', 0)
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    # As of Jython 2.7b1
    assert pyinfo.maxsize == 2147483647

    sys.version_info = (3, 3, 1, 'final', 0)
    pyinfo = PyInfo()
    assert pyinfo.PY2 is False

# Generated at 2022-06-21 22:19:23.363897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY2:
        import __builtin__
    else:
        import builtins as __builtin__

    assert min(PyInfo.string_types) == __builtin__.basestring
    assert min(PyInfo.integer_types) == __builtin__.int
    assert min(PyInfo.class_types) == __builtin__.type

    assert PyInfo.text_type == __builtin__.unicode if PyInfo.PY2 else __builtin__.str

# Generated at 2022-06-21 22:19:31.501963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == type(2**31)
    assert PyInfo.PY2 != PyInfo.PY3

# Generated at 2022-06-21 22:19:40.264452
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.string_types)
        assert not (isinstance(u"", PyInfo.binary_type))
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(10, PyInfo.integer_types)
    else:  # PyInfo.PY3
        assert not (isinstance("", PyInfo.string_types))
        assert isinstance("", PyInfo.binary_type)
        assert not (isinstance(u"", PyInfo.string_types))
        assert not (isinstance(u"", PyInfo.binary_type))
        assert isinstance(u"", PyInfo.text_type)

# Generated at 2022-06-21 22:19:43.426110
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types or PyInfo.text_type or PyInfo.binary_type
    assert PyInfo.integer_types or PyInfo.class_types

# Generated at 2022-06-21 22:19:47.197178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') in PyInfo.string_types
        assert type(0) in PyInfo.integer_types

# Generated at 2022-06-21 22:19:51.313328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 != pyinfo.PY3
    # assert pyinfo.maxsize > 0



# Generated at 2022-06-21 22:19:53.612461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

# Generated at 2022-06-21 22:19:57.053523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)



# Generated at 2022-06-21 22:20:01.640422
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types is str, 'PyInfo.string_types is str'
        assert PyInfo.text_type is str, 'PyInfo.text_type is str'
        assert PyInfo.binary_type is bytes, 'PyInfo.binary_type is bytes'
        assert PyInfo.integer_types is int, 'PyInfo.integer_types is int'
        assert PyInfo.class_types is type, 'PyInfo.class_types is type'
    else:
        assert PyInfo.string_types is basestring, 'PyInfo.string_types is basestring'
        assert PyInfo.text_type is unicode, 'PyInfo.text_type is unicode'
        assert PyInfo.binary_type is str, 'PyInfo.binary_type is str'
        assert Py

# Generated at 2022-06-21 22:20:13.626287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('\nPython version: {0} {1}'.format(
        PyInfo.PY2, PyInfo.PY3))
    print('PyInfo.maxsize: {0}'.format(PyInfo.maxsize))
    print('PyInfo.string_types: {0}'.format(PyInfo.string_types))
    print('PyInfo.text_type: {0}'.format(PyInfo.text_type))
    print('PyInfo.text_type is unicode: {0}'.format(
        PyInfo.text_type is unicode))
    print('PyInfo.binary_type: {0}'.format(PyInfo.binary_type))
    print('PyInfo.binary_type is str: {0}'.format(
        PyInfo.binary_type is str))

# Generated at 2022-06-21 22:20:18.615408
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.PY3 is True
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.PY2 is True
        assert PyInfo.maxsize == (1 << 31) - 1
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


#

# Generated at 2022-06-21 22:20:31.423794
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:41.793543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:20:51.706057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=invalid-name
    assert not hasattr(PyInfo, 'x')
    try:
        'PY2' in PyInfo.__dict__
    except Exception:  # pylint: disable=broad-except
        raise AssertionError('PY2 is not defined in PyInfo')

    try:
        'PY3' in PyInfo.__dict__
    except Exception:  # pylint: disable=broad-except
        raise AssertionError('PY3 is not defined in PyInfo')

    if PyInfo.maxsize > 2 ** 32 - 1:
        raise AssertionError('maxsize of PyInfo is greater than 2**32 - 1')


# Example of usage of PyInfo in real code

# Generated at 2022-06-21 22:20:53.090017
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

# Generated at 2022-06-21 22:20:58.772157
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
       

# Generated at 2022-06-21 22:21:09.031935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert PyInfo.text_type == str or PyInfo.text_type == unicode
    assert PyInfo.binary_type == str or PyInfo.binary_type == bytes
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)



# Generated at 2022-06-21 22:21:13.755091
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # if PY2, test_result must be 'True'
    test_result = isinstance(PyInfo.PY3, bool) and not PyInfo.PY3
    print("test_result", test_result)

# Generated at 2022-06-21 22:21:22.558938
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)

    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)



# Generated at 2022-06-21 22:21:34.343752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2 or not PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

    assert type('a') in PyInfo.string_types
    assert type(u'a') in PyInfo.string_types
    assert type(r'a') not in PyInfo.string_types

    assert type('') in PyInfo.string_types
    assert type(u'') in PyInfo.string_types
    assert type(r'') not in PyInfo.string_types

    assert type(True) not in PyInfo.string_types
    assert type(1.0) not in PyInfo.string_types
    assert type(1) not in PyInfo.string_types
    assert type(object) not in PyInfo.string_types



# Generated at 2022-06-21 22:21:44.572762
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check_and_assert(expected, actual):
        assert isinstance(expected, type(actual))
        assert actual == expected

    # Python 2 and 3 has assumed different string types
    check_and_assert(type(''), PyInfo.text_type)
    check_and_assert((str, basestring), PyInfo.string_types)
    check_and_assert('abc'.encode(), PyInfo.binary_type)

    # Python 2 and 3 has different integer types
    check_and_assert((int, long), PyInfo.integer_types)
    check_and_assert((type, types.ClassType), PyInfo.class_types)

    if PyInfo.PY2:
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert len(PyInfo.maxsize * ' ') == sys.max

# Generated at 2022-06-21 22:21:58.064954
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check we've imported all of the Python 3.x definitions
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)

# Generated at 2022-06-21 22:22:04.341791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert issubclass(PyInfo.integer_types, int)
    if PyInfo.PY2:
        assert not PyInfo.maxsize > (1 << 31) - 1
    elif PyInfo.PY3:
        assert PyInfo.maxsize >= (1 << 31) - 1

# Generated at 2022-06-21 22:22:10.590155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        def test_sysversion(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

    unittest.main()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:22:15.206790
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)

    s = 'a'
    t = u'a'
    assert isinstance(s, PyInfo.binary_type)
    assert isinstance(t, PyInfo.text_type)



# Generated at 2022-06-21 22:22:20.832392
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:22:27.432563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# global instance
pyinfo = PyInfo()

# Generated at 2022-06-21 22:22:33.433668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 or p.PY3
    if p.PY2:
        assert p.maxsize == 9223372036854775807
    elif p.PY3:
        assert p.maxsize == sys.maxsize
    else:
        assert 0
    assert isinstance("", p.string_types)
    assert isinstance(u"", p.text_type)
    assert isinstance(b"", p.binary_type)
    assert isinstance(1, p.integer_types)



# Generated at 2022-06-21 22:22:41.696535
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

    else:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:47.863792
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check PY2
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
    else:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True

    # check string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(1.0, PyInfo.string_types)

    # check text_type
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)
    assert not isinstance

# Generated at 2022-06-21 22:22:58.057621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('test', PyInfo.string_types)
        assert isinstance(u'test', PyInfo.string_types)
        assert isinstance(u'test', PyInfo.text_type)
        assert isinstance('test', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:22.464833
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert 2 == PyInfo.PY2
    assert 3 == PyInfo.PY3
    assert 'text' == PyInfo.text_type
    assert int == PyInfo.integer_types
    assert type == PyInfo.class_types


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:28.207392
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    # assert PyInfo.string_types == (str)
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    # Python3.4 Maxsize is 9223372036854775807
    assert PyInfo.maxsize == 9223372036854775807



# Generated at 2022-06-21 22:23:29.753298
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-21 22:23:38.738977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global py2, py3, txt
    if PyInfo.PY2:
        py2 = True
        py3 = False
        txt = 'Py 2.7.10'
    if PyInfo.PY3:
        py2 = False
        py3 = True
        txt = 'Py 3.5.2'

    assert py2 and not py3
    assert py3 and not py2
    assert txt == 'Py 2.7.10' or txt == 'Py 3.5.2'
    print(txt)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:23:49.210208
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()

    if PyInfo.PY2:
        assert isinstance('', pyi.string_types)  # noqa
        assert isinstance(u'', pyi.text_type)  # noqa
        assert isinstance('', pyi.binary_type)  # noqa
        assert isinstance(1, pyi.integer_types)  # noqa
        assert isinstance(int, pyi.class_types)  # noqa
        assert isinstance(types.ClassType, pyi.class_types)  # noqa
    elif PyInfo.PY3:
        assert isinstance('', pyi.string_types)  # noqa
        assert isinstance('', pyi.text_type)  # noqa
        assert isinstance(b'', pyi.binary_type)  # no

# Generated at 2022-06-21 22:23:58.030702
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('string', PyInfo.string_types)

    if PyInfo.PY2:
        assert not isinstance(b'string', PyInfo.string_types)
        assert not isinstance(u'string', PyInfo.string_types)
    else:
        assert isinstance(b'string', PyInfo.string_types)
        assert isinstance(u'string', PyInfo.string_types)

    assert isinstance('string', PyInfo.text_type)

    if PyInfo.PY2:
        assert not isinstance(b'string', PyInfo.text_type)
        assert isinstance(u'string', PyInfo.text_type)

# Generated at 2022-06-21 22:24:01.362799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:11.523984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    # Test if running as module or not
    if __package__ is None:
        import os
        path = os.path.join(os.path.dirname(__file__), '..')
        sys.path.append(os.path.abspath(path))
        from pycompss.util.serializer.py_info import PyInfo
        from pycompss.util.serializer import Serial

# Generated at 2022-06-21 22:24:17.509897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance('a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-21 22:24:25.743046
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pylint: disable=protected-access
    pyinfo = PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3

    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)

        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert pyinfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:25:07.893454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:25:19.197510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not True or PyInfo.PY3 is not True

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)

    assert isinstance(u'abc', PyInfo.text_type)
    assert not isinstance('abc', PyInfo.text_type)

    assert isinstance(b'abc', PyInfo.binary_type)
    assert not isinstance('abc', PyInfo.binary_type)
    assert not isinstance(u'abc', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:23.757290
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:25:25.277936
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2, "This is Python 2"



# Generated at 2022-06-21 22:25:35.345358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # 以下测试通过
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    # test if maxsize is a 32-bit or 64-bit integer

# Generated at 2022-06-21 22:25:39.836752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types[0] is str
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.class_types[0] is type
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:25:44.511886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().string_types[0], type)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().integer_types[0], type)
    assert isinstance(PyInfo().class_types, tuple)
    assert isinstance(PyInfo().class_types[0], type)
    assert isinstance(PyInfo().maxsize, int)

# Generated at 2022-06-21 22:25:47.006111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:25:50.950966
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.string_types)



# Generated at 2022-06-21 22:25:52.754497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:27:30.518930
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-21 22:27:39.465266
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not (PyInfo.PY2 is None and PyInfo.PY3 is None)
    assert all(isinstance(x, bool) for x in (PyInfo.PY2, PyInfo.PY3))

    assert all(
        isinstance(x, tuple)
        and all(isinstance(y, type) for y in x)
        for x in (
            PyInfo.string_types,
            PyInfo.integer_types,
            PyInfo.class_types,
        )
    )
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:27:45.420753
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert len(PyInfo.string_types) == 1
    assert isinstance("abc", PyInfo.string_types)
    assert len(PyInfo.integer_types) == 2
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:27:50.218088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 or p.PY3
    assert type(p.string_types) == tuple
    assert type(p.text_type) == str
    assert type(p.integer_types) == tuple
    assert type(p.maxsize) == int



# Generated at 2022-06-21 22:28:01.276406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyinfo import PyInfo
    pi = PyInfo
    attrs = dir(PyInfo)
    for attr in attrs:
        assert getattr(pi, attr) == getattr(PyInfo, attr)


if __name__ == "__main__":
    import pyinfo
    assert pyinfo.is_python2() == PyInfo.PY2
    assert pyinfo.is_python3() == PyInfo.PY3
    assert pyinfo.is_python_bellow(3, 5, 7) == PyInfo.PY3
    assert pyinfo.is_python_bellow(3, 6, 7) == True

    assert pyinfo.maxsize == PyInfo.maxsize

    assert pyinfo.string_types == PyInfo.string_types
    assert pyinfo.text_type == PyInfo.text_type