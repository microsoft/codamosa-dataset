

# Generated at 2022-06-21 22:18:04.123069
# Unit test for constructor of class PyInfo
def test_PyInfo():
    inf = PyInfo()
    assert isinstance(inf.PY2, bool)
    assert isinstance(inf.PY3, bool)
    assert isinstance(inf.string_types, tuple)
    assert isinstance(inf.text_type, type)
    assert isinstance(inf.binary_type, type)
    assert isinstance(inf.integer_types, tuple)
    assert isinstance(inf.class_types, tuple)
    assert isinstance(inf.maxsize, int)



# Generated at 2022-06-21 22:18:05.788020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)



# Generated at 2022-06-21 22:18:13.103781
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test is PY3
    assert PyInfo.PY3 is True

    # test is PY2
    assert PyInfo.PY2 is False

    # test maxsize
    PyInfo.maxsize

    # test string_types
    assert PyInfo.string_types is not None

    # test binary_type
    assert PyInfo.binary_type is not None

    # test integer_types
    assert PyInfo.integer_types is not None

    # test text_type
    assert PyInfo.text_type is not None

    # test class_types
    assert PyInfo.class_types is not None

# Generated at 2022-06-21 22:18:20.225596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class Test(unittest.TestCase):
        def test_general(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)
            self.assertEqual(PyInfo.string_types, (str,))
            self.assertEqual(PyInfo.text_type, str)
            self.assertEqual(PyInfo.binary_type, bytes)
            self.assertEqual(PyInfo.integer_types, (int,))
            self.assertEqual(PyInfo.class_types, (type,))
            self.assertEqual(PyInfo.maxsize, sys.maxsize)
            pass

    unittest.main()

# Generated at 2022-06-21 22:18:29.535541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert isinstance(PyInfo.class_types, (type, types.ClassType))

# Generated at 2022-06-21 22:18:35.907159
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:18:46.024204
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Make sure class PyInfo has basic properties right."""
    if PyInfo.PY2:
        assert issubclass(str, PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert issubclass(int, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert issubclass(long, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:54.833335
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance('', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)
    assert sys.maxsize <= PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:18:58.216590
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, 'Either PY2 or PY3 should be True'


if __name__ == '__main__':
    pytest.main()

# Generated at 2022-06-21 22:19:02.397196
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.maxsize > 0



# Generated at 2022-06-21 22:19:15.326935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3

    assert pyinfo.integer_types == (int, long)
    assert isinstance(4, pyinfo.integer_types)
    assert not isinstance(4.0, pyinfo.integer_types)
    assert pyinfo.maxsize == ((1 << 63) - 1)

    assert isinstance('test', pyinfo.string_types)
    assert isinstance(u'test', pyinfo.string_types)
    assert isinstance(b'test', pyinfo.binary_type)
    assert isinstance(1, pyinfo.integer_types)



# Generated at 2022-06-21 22:19:22.194438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert PyInfo.string_types == (str,) or PyInfo.string_types == (str, unicode)
    assert PyInfo.text_type == str or PyInfo.text_type == unicode
    assert PyInfo.binary_type == bytes or PyInfo.binary_type == str
    assert PyInfo.integer_types == (int,) or PyInfo.integer_types == (int, long)
    if PyInfo.PY3:
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:19:31.149838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('s', PyInfo.string_types)
    assert isinstance(u's', PyInfo.string_types)
    assert isinstance('s', PyInfo.string_types)
    assert isinstance('s', PyInfo.string_types)
    assert isinstance(sys.maxsize, PyInfo.integer_types)
    assert isinstance(int.__reduce__, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(1, PyInfo.class_types)
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:19:34.685588
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

    if PyInfo.PY2:
        # This fails in Py3.7
        isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    import pytest

    pytest.main()

# Generated at 2022-06-21 22:19:39.023122
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type is not None
    assert PyInfo.string_types is not None
    assert PyInfo.class_types is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:45.572352
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_PyInfo()

# Generated at 2022-06-21 22:19:52.439490
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # assert that equality operator works
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (
        type,
    )

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:03.790564
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert "basestring" in str(PyInfo.string_types), str(PyInfo.string_types)
        assert "str" not in str(PyInfo.string_types), str(PyInfo.string_types)
        assert "unicode" in str(PyInfo.text_type), str(PyInfo.text_type)
        assert "str" in str(PyInfo.binary_type), str(PyInfo.binary_type)
        assert "type" in str(PyInfo.class_types), str(PyInfo.class_types)
    else:
        assert "str" in str(PyInfo.string_types), str(PyInfo.string_types)
        assert "basestring" not in str(PyInfo.string_types), str(PyInfo.string_types)

# Generated at 2022-06-21 22:20:11.877290
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY2 is False
    assert isinstance('', PyInfo.string_types)
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(), bytes)
    assert isinstance(0, PyInfo.integer_types)
    assert issubclass(PyInfo.class_types, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:15.179943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:20:29.674858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    # not isinstance(b'a', PyInfo.string_types)

    assert isinstance('a', PyInfo.text_type)
    # not isinstance(b'a', PyInfo.text_type)
    assert isinstance(u'a', PyInfo.text_type)

    assert isinstance(b'a', PyInfo.binary_type)
    # not isinstance(u'a', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:35.893076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None
    return

# Generated at 2022-06-21 22:20:38.457846
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-21 22:20:46.914799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0

    assert isinstance('f', PyInfo.string_types)
    assert not isinstance(b'f', PyInfo.string_types)
    assert isinstance('f', PyInfo.text_type)
    assert not isinstance(b'f', PyInfo.text_type)
    assert isinstance(b'f', PyInfo.binary_type)
    assert not isinstance('f', PyInfo.binary_type)

    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, PyInfo.class_types)

# Generated at 2022-06-21 22:20:54.211697
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.maxsize == (1 << 63) - 1
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:21:03.117047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2
    assert pyinfo.PY3

    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert pyinfo.maxsize == int((1 << 31) - 1)
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31

        try:
            len(X())
        except OverflowError:
            # 32-bit
            assert pyinfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:21:12.316384
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert PyInfo.string_types == (
        basestring,
    ) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert PyInfo.maxsize == (1 << 31) - 1 if PyInfo.PY2 else sys.maxsize



# Generated at 2022-06-21 22:21:15.036777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Invalid version of Python"


print("Unit test passed")

# Generated at 2022-06-21 22:21:23.994684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 1



# Generated at 2022-06-21 22:21:29.255033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert issubclass(PyInfo.string_types[0], basestring)
    assert issubclass(PyInfo.text_type, basestring)
    assert issubclass(PyInfo.binary_type, str)
    assert issubclass(PyInfo.integer_types[0], (int, long))

# Generated at 2022-06-21 22:21:45.251122
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert hasattr(PyInfo, "PY2")
    assert hasattr(PyInfo, "PY3")
    assert hasattr(PyInfo, "string_types")
    assert hasattr(PyInfo, "text_type")
    assert hasattr(PyInfo, "binary_type")
    assert hasattr(PyInfo, "integer_types")
    assert hasattr(PyInfo, "class_types")
    assert hasattr(PyInfo, "maxsize")

    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:21:51.213596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert not (PyInfo.PY2 is True and PyInfo.PY3 is True)
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:58.728405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True) or (PyInfo.PY3 == True)
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:10.180635
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)

# Generated at 2022-06-21 22:22:16.356526
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.class_types)
    assert PyInfo.maxsize == int((1 << 31) - 1)
    if __debug__:
        assert str(PyInfo) == "<class '__main__.PyInfo'>"
    else:
        assert str(PyInfo) == "<class 'sizeof.PyInfo'>"

# Generated at 2022-06-21 22:22:21.877543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:22:30.711819
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    @pytest.mark.parametrize("given,expected", [("abc", True), (123, False), (1.0, False)])
    def test_string_types(given, expected):
        assert (isinstance(given, PyInfo.string_types) == expected)

    @pytest.mark.parametrize("given,expected", [("abc", True), (123, False), (1.0, False)])
    def test_text_type(given, expected):
        assert (isinstance(given, PyInfo.text_type) == expected)


# Generated at 2022-06-21 22:22:41.573291
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


# Generated at 2022-06-21 22:22:52.840224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:03.529815
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from sys import maxsize
    from types import ClassType

    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.maxsize, int)
    assert maxsize == PyInfo.maxsize

    assert isinstance(PyInfo.string_types, tuple)
    assert "a" in PyInfo.string_types

    assert isinstance(PyInfo.text_type, type)
    assert isinstance("a", PyInfo.text_type)

    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(b"a", PyInfo.binary_type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:23:27.724915
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(set, PyInfo.class_types)



# Generated at 2022-06-21 22:23:34.229149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize == sys.maxsize

    if PyInfo.PY2:
        assert type(u"") == PyInfo.text_type
    else:
        assert type("") == PyInfo.text_type

    if PyInfo.PY2:
        pass
    else:
        assert type(b"") == PyInfo.binary_type

# Generated at 2022-06-21 22:23:36.387975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Unit tests for class PyInfo

# Generated at 2022-06-21 22:23:47.114957
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTestCase(unittest.TestCase):

        def test_PY2(self):
            self.assertEqual(
                sys.version_info[0],
                2)

        def test_PY3(self):
            self.assertEqual(
                sys.version_info[0],
                3)

        def test_string_types(self):
            self.assertEqual(
                PyInfo.string_types,
                (basestring,))

        def test_text_type(self):
            self.assertEqual(
                PyInfo.text_type,
                unicode)

        def test_binary_type(self):
            self.assertEqual(
                PyInfo.binary_type,
                str)


# Generated at 2022-06-21 22:23:56.524807
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    assert info.string_types == (basestring if info.PY2 else str,)
    assert info.text_type == (unicode if info.PY2 else str)
    assert info.binary_type == (str if info.PY2 else bytes)
    assert info.integer_types == (int, long if info.PY2 else int)
    assert info.class_types == (type, types.ClassType if info.PY2 else type)

# Generated at 2022-06-21 22:23:57.747671
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


pyinfo = PyInfo()



# Generated at 2022-06-21 22:24:09.507263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def get_size(size):
        return bin(size).count('1')

    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.string_types)
    assert isinstance(u'foo', PyInfo.text_type)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 63, PyInfo.integer_types)
    assert isinstance(2 ** 64, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert get_size(sys.maxsize) == get

# Generated at 2022-06-21 22:24:12.260381
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    PyInfo.string_types
    PyInfo.text_type
    PyInfo.binary_type
    PyInfo.integer_types
    PyInfo.class_types
    PyInfo.maxsize



# Generated at 2022-06-21 22:24:16.236087
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyI

# Generated at 2022-06-21 22:24:17.989943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:25:03.801586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    testsuite = []
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance("a", PyInfo.text_type)
        assert not isinstance("a", PyInfo.binary_type)
        assert isinstance("a", PyInfo.class_types)

        testsuite.append("assert not isinstance(b'a', PyInfo.string_types)")
        testsuite.append("assert isinstance(b'a', PyInfo.binary_type)")
        testsuite.append("assert not isinstance(b'a', PyInfo.class_types)")
        testsuite.append("assert not isinstance(b'a', PyInfo.text_type)")

        testsuite.append("assert isinstance(1, PyInfo.integer_types)")

# Generated at 2022-06-21 22:25:11.980912
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3 is True
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)  # noqa
        assert isinstance(u'a', PyInfo.string_types)  # noqa
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'a', PyInfo.binary_type)


# Generated at 2022-06-21 22:25:14.959989
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # "Python {0}.{1}.{2}".format(*sys.version_info[:3])
    assert False


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:25:19.506739
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    print(i.PY2)
    print(i.PY3)
    print(i.string_types)
    print(i.text_type)
    print(i.binary_type)
    print(i.integer_types)
    print(i.class_types)
    print(i.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:28.391924
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY3
    assert py_info.PY2 is False

    assert isinstance("", py_info.string_types)
    assert isinstance(u"", py_info.string_types)

    assert isinstance("", py_info.text_type)
    assert isinstance(u"", py_info.text_type)
    assert isinstance(b"", py_info.binary_type)

    assert isinstance(1, py_info.integer_types)

# Generated at 2022-06-21 22:25:39.762380
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring if sys.version_info[0] == 2 else str,)
    assert PyInfo.text_type == (unicode if sys.version_info[0] == 2 else str)
    assert PyInfo.binary_type == (str if sys.version_info[0] == 2 else bytes)
    assert PyInfo.integer_types == (
        (int, long) if sys.version_info[0] == 2 else int
    )
    assert PyInfo.class_types == (
        (type, types.ClassType) if sys.version_info[0] == 2 else type
    )


# Generated at 2022-06-21 22:25:41.476425
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# if __name__ == '__main__':
#     test_PyInfo()

# Generated at 2022-06-21 22:25:43.254044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 and not PyInfo.PY3) or (
        not PyInfo.PY2 and PyInfo.PY3
    ), "Error in detecting Python version"

# Generated at 2022-06-21 22:25:44.080812
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True

# Generated at 2022-06-21 22:25:51.187047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo)
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.maxsize)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:27:35.311162
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:27:45.420348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type(), PyInfo.string_types[0])

# Generated at 2022-06-21 22:27:46.631850
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-21 22:27:51.414921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    if obj.PY2:
        sys.stdout.write("Python 2")
    elif obj.PY3:
        sys.stdout.write("Python 3")


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:28:02.705346
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_pyinfo_attrs():
        for attr in ['PY2', 'PY3', 'string_types', 'text_type', 'binary_type', 'integer_types', 'class_types', 'maxsize']:
            assert hasattr(PyInfo, attr)

    test_pyinfo_attrs()
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)