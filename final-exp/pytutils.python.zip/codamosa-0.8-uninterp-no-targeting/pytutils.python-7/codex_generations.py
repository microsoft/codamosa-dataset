

# Generated at 2022-06-21 22:18:09.927385
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.text_type)
        assert isinstance(u'abc', PyInfo.text_type)
        assert not isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(b'abc', PyInfo.string_types)
        assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:20.636996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types is string_types, pyinfo.string_types
    assert pyinfo.text_type is text_type, pyinfo.text_type
    assert pyinfo.binary_type is bytes, pyinfo.binary_type
    assert pyinfo.integer_types is integer_types, pyinfo.integer_types
    assert pyinfo.class_types is class_types, pyinfo.class_types
    assert pyinfo.maxsize is sys.maxsize
    assert eval(repr(pyinfo)) == pyinfo
    assert str(pyinfo) == "PyInfo(PY2, PY3='False')"
    assert isinstance(pyinfo, PyInfo)


test_PyInfo()

# Generated at 2022-06-21 22:18:28.833929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert type(i.string_types) is tuple
    assert type(i.string_types[0]) is type
    assert type(i.text_type) is type
    assert type(i.binary_type) is type
    assert type(i.integer_types) is tuple
    assert type(i.integer_types[0]) is type
    assert type(i.class_types) is tuple
    assert type(i.class_types[0]) is type
    assert type(i.maxsize) is type(9223372036854775807)

# Generated at 2022-06-21 22:18:40.239458
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == sys.version_info[0] == 2
    assert PyInfo().PY3 == sys.version_info[0] == 3

    if PyInfo().PY2:
        assert isinstance(PyInfo().string_types, tuple)
        assert isinstance(PyInfo().string_types[0], type(basestring))
        assert isinstance(PyInfo().integer_types, tuple)
        assert isinstance(PyInfo().integer_types[0], type(int))
        assert isinstance(PyInfo().integer_types[1], type(long))
    else:
        assert isinstance(PyInfo().string_types, tuple)
        assert isinstance(PyInfo().string_types[0], type(str))
        assert isinstance(PyInfo().integer_types, tuple)

# Generated at 2022-06-21 22:18:48.634840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo.PY2 == (sys.version_info[0] == 2)
        assert PyInfo.PY3 == (sys.version_info[0] == 3)
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        # assert PyInfo.maxsize == sys.maxsize
    except Exception:
        if PyInfo.PY3:
            raise
        else:

            class X(object):

                def __len__(self):
                    return 1 << 31


# Generated at 2022-06-21 22:18:56.241391
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (getattr(PyInfo, 'PY2', None) is None)
    assert PyInfo.PY2 is not None

    assert PyInfo.maxsize in [2147483647, 9223372036854775807]
    assert PyInfo.maxsize > 100000
    assert PyInfo.maxsize > PyInfo.maxsize >> 1

    assert 1 < PyInfo.maxsize <= PyInfo.maxsize + 1


# noinspection PyStatementEffect

# Generated at 2022-06-21 22:19:01.585069
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)

    pyinfo.PY2
    pyinfo.PY3


if __name__ == '__main__':
    pytest.main([__file__])

# Generated at 2022-06-21 22:19:13.942998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:19:22.545081
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert not isinstance(b'abc', PyInfo.string_types)

    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.text_type)
        assert isinstance(b'abc', PyInfo.binary_type)
    else:
        assert isinstance(u'abc', PyInfo.text_type)
        assert isinstance('abc', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:27.463569
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:19:35.347284
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:19:44.611961
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestCase(unittest.TestCase):
        def test_data(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

            self.assertIs(
                isinstance("str", PyInfo.string_types),
                PyInfo.PY2,
            )
            self.assertIs(
                isinstance("str", PyInfo.string_types),
                not PyInfo.PY3,
            )

            self.assertIs(isinstance("str", PyInfo.text_type), PyInfo.PY3)
            self.assertIs(isinstance("str", PyInfo.binary_type), PyInfo.PY3)



# Generated at 2022-06-21 22:19:51.872257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance('str'.decode('utf-8'), PyInfo.string_types)
        assert isinstance(u'u_str', PyInfo.string_types)
        assert isinstance('str', PyInfo.binary_type)
        assert isinstance(u'u_str', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
    elif PyInfo.PY3:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance('str'.encode('utf-8'), PyInfo.string_types)
        assert isinstance(b'b_str', PyInfo.string_types)

# Generated at 2022-06-21 22:20:01.663314
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:13.669822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:18.650628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Input:
    #   name = str():
    # Output:
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False

#   assert PyInfo.string_types == (str,) or PyInfo.string_types == (basestring,)
#   assert PyInfo.text_type == str or PyInfo.text_type == unicode
#   assert PyInfo.binary_type == str or PyInfo.binary_type == bytes
#   assert PyInfo.integer_types == (int,) or PyInfo.integer_types == (int, long)
#   assert PyInfo.class_types == (type,) or PyInfo.class_types == (type, types.ClassType)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:28.892772
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:33.983586
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    print(sys.version_info)
    print(info.PY2)
    print(info.PY3)
    print(info.maxsize)

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:20:41.384455
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 2, 'The major version of Python 2 must be 2, not %s' % (PyInfo.PY2)
    assert isinstance('a', PyInfo.string_types), 'PyInfo.string_types is wrong'
    assert not isinstance(b'a', PyInfo.string_types), 'PyInfo.string_types is wrong'
    assert len('abc') == 3, 'PyInfo.maxsize is wrong'
    assert len('a' * 4) == 4, 'PyInfo.maxsize is wrong'

# Generated at 2022-06-21 22:20:52.033509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance("", str)
        assert isinstance(b"", bytes)
        assert isinstance(1, int)
        assert not isinstance(1, long)
        assert isinstance(type(None), type)
    else:  # PY2
        assert isinstance("", basestring)
        assert isinstance(b"", str)
        assert isinstance(1, (int, long))
        assert isinstance(type(None), (type, types.ClassType))


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:21:04.854218
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == PY2
    assert PyInfo.PY3 == PY3
    assert PyInfo.string_types == STRING_TYPES
    assert PyInfo.text_type == TEXT_TYPE
    assert PyInfo.binary_type == BINARY_TYPE
    assert PyInfo.integer_types == INTEGER_TYPES
    assert PyInfo.class_types == CLASS_TYPES
    assert PyInfo.maxsize == MAXSIZE


STRING_TYPES = PyInfo.string_types
TEXT_TYPE = PyInfo.text_type
BINARY_TYPE = PyInfo.binary_type
INTEGER_TYPES = PyInfo.integer_types
CLASS_TYPES = PyInfo.class_types
MAXSIZE = PyInfo.maxsize
PY2 = PyInfo.PY2

# Generated at 2022-06-21 22:21:13.468119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (not PyInfo.PY3)
    assert PyInfo.PY3 == (not PyInfo.PY2)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # Default value of maxsize is defined in Python docs.
    assert PyInfo.maxsize == (1 << 31) - 1
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-21 22:21:22.384941
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    if PyInfo.PY2:
        assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance("a", PyInfo.text_type)

    assert isinstance(b"a", PyInfo.binary_type)
    if PyInfo.PY2:
        assert not isinstance("a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:34.252508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = PyInfo.PY2
    PY3 = PyInfo.PY3

    if PY2:
        str_type = basestring
        int_type = (int, long)
    else:
        str_type = str
        int_type = int

    assert isinstance("", PyInfo.string_types)
    assert isinstance("", str_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, int_type)

    if PY2:
        assert isinstance(object, PyInfo.class_types)
        assert isinstance(object, types.ClassType)

# Generated at 2022-06-21 22:21:40.753077
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:47.847892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

    assert PyInfo.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:49.749512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == (PyInfo.PY3 == False))



# Generated at 2022-06-21 22:21:57.107689
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check_attr(attr):
        if not hasattr(PyInfo, attr):
            raise Exception("PyInfo has no attribute '%s'" % attr)

    attrs = [
        'PY2',
        'PY3',
        'string_types',
        'text_type',
        'binary_type',
        'integer_types',
        'class_types',
        'maxsize'
    ]

    for attr in attrs:
        check_attr(attr)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:08.891896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True or pi.PY3 is True
    if pi.PY2:
        assert pi.PY3 is False
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)
    else:  # PY3
        assert pi.PY2 is False
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)

# Generated at 2022-06-21 22:22:11.379194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-21 22:22:22.744644
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), PyInfo)



# Generated at 2022-06-21 22:22:31.478010
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo

    assert py_info.PY2
    assert not py_info.PY3
    assert py_info.string_types == (basestring,)
    assert py_info.text_type is unicode
    assert py_info.binary_type is str
    assert py_info.integer_types == (int, long)
    assert py_info.class_types == (type, types.ClassType)
    # Depending of your machine the result will be 2,147,483,647 for 32 bit,
    # and 9,223,372,036,854,775,807 for 64 bit.
    print(py_info.maxsize)
    assert py_info.maxsize == sys.maxint


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:41.572519
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:47.513016
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python version: {}.{}.{}'.format(*sys.version_info[:3]))
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance('abc'.encode('utf-8'), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1000000000, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:48.312560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


start_time = time.time()



# Generated at 2022-06-21 22:22:54.133504
# Unit test for constructor of class PyInfo
def test_PyInfo():
    mi = PyInfo()
    assert mi.string_types == (str, basestring)
    assert mi.text_type == str
    assert mi.binary_type == str
    assert mi.integer_types == (int, long)
    assert mi.class_types == (type, types.ClassType)
    assert mi.maxsize == int((1 << 63) - 1)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:05.025523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check for PY3
    assert PyInfo.PY3 is True
    # Check for PY2
    assert PyInfo.PY2 is False
    # Check for string_types
    assert isinstance('test', PyInfo.string_types)
    # Check for text_type
    assert isinstance('test', PyInfo.text_type)
    # Check for binary_type
    assert isinstance(b'test', PyInfo.binary_type)
    # Check for integer_types
    assert isinstance(10, PyInfo.integer_types)
    # Check for class_types
    assert isinstance(PyInfo, PyInfo.class_types)
    # Check for maxsize
    assert PyInfo.maxsize == sys.maxsize


# For coverage testing
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:23:15.884899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(b'', bytes)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, int)
        assert isinstance(1, PyInfo.class_types)
        assert isinstance(1, type)
    else:  # PY2
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, int)
        assert isinstance(1, PyInfo.class_types)
        assert isinstance(1, type)



# Generated at 2022-06-21 22:23:23.764778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:23:27.594796
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(3, PyInfo.integer_types)
    else:
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(3, (int,))

# Generated at 2022-06-21 22:23:50.169992
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert not PyInfo.PY2
        assert PyInfo.PY3
        assert PyInfo.text_type == str
    except AssertionError:
        logging.error("Errors in class PyInfo")
        raise



# Generated at 2022-06-21 22:23:56.224289
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
    else:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)



# Generated at 2022-06-21 22:24:01.345366
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert not isinstance(b"a", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(0, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(type, PyInfo.class_types)
    assert PyInfo.maxsize == sys.maxsize


test_PyInfo()

# Generated at 2022-06-21 22:24:05.020320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:24:12.143180
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("foobar", PyInfo.string_types)
    assert isinstance(u"foobar", PyInfo.string_types)
    assert not isinstance(b"foobar", PyInfo.string_types)
    assert b"foobar" is not "foobar"
    assert isinstance(b"foobar", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:21.690169
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    print(a.PY2)

# py2, py3, str, int, float, type, unicode, str, tuple, list
# False, True, str, <class 'int'>, <class 'float'>, <class 'type'>, <class 'str'>, <class 'type'>, <class 'tuple'>, <class 'list'>
# True, False, <type 'unicode'>, <type 'int'>, <type 'float'>, <type 'type'>, <type 'unicode'>, <type 'str'>, <type 'tuple'>, <type 'list'>


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:24:29.863097
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)



# Generated at 2022-06-21 22:24:35.934979
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # None of these should fail
    pyinfo = PyInfo()
    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

    if sys.version_info[0] == 2:
        assert pyinfo.PY2 is True
        assert pyinfo.PY3 is False
    elif sys.version_info[0] == 3:
        assert pyinfo.PY3 is True
        assert pyinfo.PY2 is False

# Generated at 2022-06-21 22:24:46.249122
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    class A(object):
        pass
    a = A()
    if PyInfo.PY3:
        assert isinstance(a, type)
        assert isinstance(a, object)
    else:
        assert isinstance(a, (object, types.InstanceType))

    if PyInfo.PY3:
        assert isinstance(type, type)
        assert isinstance(A, type)
        assert isinstance(a, type)
    else:
        assert isinstance(type, (type, types.ClassType))
        assert isinstance(A, (type, types.ClassType))
        assert isinstance(a, (object, types.InstanceType))

    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-21 22:24:49.533527
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2

# Generated at 2022-06-21 22:25:31.620102
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert not bool(PyInfo.maxsize < (1 << 31))



# Generated at 2022-06-21 22:25:41.692861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert type(PyInfo.integer_types) == tuple
        assert PyInfo.integer_types == (int,)
        assert type(PyInfo.class_types) == tuple
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-21 22:25:45.576699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert 0 <= PyInfo.maxsize < 2 ** 64



# Generated at 2022-06-21 22:25:55.457977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:59.377557
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Python 2
    print(PyInfo.PY2, PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.binary_type)
    print(PyInfo.text_type)
    print(PyInfo.class_types)
    print(PyInfo.integer_types)
    print(PyInfo.maxsize)
    assert True


test_PyInfo()

# Generated at 2022-06-21 22:26:11.043044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    s = PyInfo.string_types[0]
    assert isinstance(u"", s)
    assert not isinstance(b"", s)

    t = PyInfo.text_type
    assert isinstance(u"", t)
    assert not isinstance(b"", t)

    b = PyInfo.binary_type
    assert not isinstance(u"", b)
    assert isinstance(b"", b)

    i = PyInfo.integer_types[0]
    assert isinstance(1, i)

# Generated at 2022-06-21 22:26:14.942284
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-21 22:26:24.809089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:26:31.467072
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:26:32.612081
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

