

# Generated at 2022-06-21 22:18:06.577454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(object, PyInfo.class_types)
    elif PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance

# Generated at 2022-06-21 22:18:15.766563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """ Test the PyInfo class """
    if PyInfo.PY2:
        if not isinstance(u"a", PyInfo.string_types):
            assert False
        if not isinstance(u"a", PyInfo.text_type):
            assert False
        if not isinstance(b"a", PyInfo.binary_type):
            assert False
        if not isinstance(1, PyInfo.integer_types):
            assert False
        if not isinstance(1, PyInfo.integer_types):
            assert False
        if not isinstance(int, PyInfo.class_types):
            assert False
    elif PyInfo.PY3:
        if not isinstance("a", PyInfo.string_types):
            assert False
        if not isinstance("a", PyInfo.text_type):
            assert False

# Generated at 2022-06-21 22:18:18.394339
# Unit test for constructor of class PyInfo
def test_PyInfo():
    b = PyInfo.PY2
    assert b


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:18:29.579199
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert isinstance(PyInfo.maxsize, int)
        assert isinstance(PyInfo.maxsize, long)
    else:
        assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:18:35.968730
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY3)
    print(PyInfo.PY2)
    print(PyInfo.maxsize)
    print(PyInfo.string_types)
    print(PyInfo.binary_type)
    print(PyInfo.text_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


if __name__ == "__main__":
    PyInfo()
    test_PyInfo()

# Generated at 2022-06-21 22:18:38.501511
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 or PyInfo.PY3, 'Only Python 2 and Python 3 are supported.'

# Generated at 2022-06-21 22:18:41.500460
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in PyInfo.__dict__:
        assert PyInfo.__dict__[attr] == getattr(PyInfo, attr)


# Constructing class PyInfo
PyInfo = PyInfo()



# Generated at 2022-06-21 22:18:49.482750
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    def test_py_info():
        # python 2.x
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            maxsize = int((1 << 31) - 1)

# Generated at 2022-06-21 22:18:57.901131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-21 22:19:09.455704
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(u"a", PyInfo.text_type)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)


# Generated at 2022-06-21 22:19:17.527384
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert not isinstance(b"a", PyInfo.text_type)
        assert isinstance(b"a", PyInfo.binary_type)
        assert not isinstance("a", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert not isinstance([], PyInfo.class_types)
    else:  # PY2
        assert isinstance("a", PyInfo.string_types)

# Generated at 2022-06-21 22:19:20.932174
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize



# Generated at 2022-06-21 22:19:26.129145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:19:27.780090
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True)


# Check if the stdlib is patched with backports

# Generated at 2022-06-21 22:19:32.929094
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert isinstance('', PyInfo.string_types)
    assert isinstance(PyInfo.text_type, PyInfo.class_types)
    assert isinstance(PyInfo.binary_type, PyInfo.class_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(PyInfo.class_types, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:19:41.314771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Unit test

# Generated at 2022-06-21 22:19:45.784857
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)
    assert isinstance(2 ** 31, PyInfo.integer_types)


test_PyInfo()

# Generated at 2022-06-21 22:19:51.469640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1000000000, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:56.669243
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    isinstance("", PyInfo.string_types) and not isinstance(None, PyInfo.string_types)

# Generated at 2022-06-21 22:19:58.877282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, basestring)

# vim:sw=4:ts=4:et:

# Generated at 2022-06-21 22:20:12.933324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 in (False, True)
    assert PyInfo.PY3 in (False, True)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:17.981642
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test Python2
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert PyInfo.string_types is (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types is (int, long)
        assert PyInfo.class_types is (type, types.ClassType)

    # Test Python3
    if sys.version_info[0] == 3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert PyInfo.string_types is (str)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes

# Generated at 2022-06-21 22:20:28.298672
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for Python version
    assert PyInfo.PY2 or PyInfo.PY3
    # test for string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    # test for text_type
    assert isinstance(PyInfo.text_type, type)
    assert not PyInfo.text_type is bytes
    # test for binary_type
    assert isinstance(PyInfo.binary_type, type)
    assert not PyInfo.binary_type is unicode
    # test for integer_types
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    # test for maxsize

# Generated at 2022-06-21 22:20:36.342853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(5, PyInfo.integer_types)
    assert not isinstance(5.1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-21 22:20:38.998450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:20:43.573433
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, (int, long))
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None

# Generated at 2022-06-21 22:20:49.337331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert sys.maxsize == PyInfo.maxsize


# Test the get_index function which returns the index of the first occurrence of an element in a sequence


# Generated at 2022-06-21 22:20:57.209409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)
    if pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)
    else:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:21:03.937465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:13.139804
# Unit test for constructor of class PyInfo
def test_PyInfo():
    max_size = sys.maxsize
    if PyInfo.PY2:
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.PY2 == False
        assert PyInfo.PY3 == True
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)

# Generated at 2022-06-21 22:21:29.454109
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:34.525080
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert issubclass(int, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:44.689365
# Unit test for constructor of class PyInfo
def test_PyInfo():
    #  PY2
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)

        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:49.891059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (2 == sys.version_info[0])
    assert p.PY3 == (3 == sys.version_info[0])


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:55.542699
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:57.396118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        from mxnet import _ctypes
    except ImportError:
        continue
    _ctypes.PyInfo()

# Generated at 2022-06-21 22:22:09.667059
# Unit test for constructor of class PyInfo
def test_PyInfo():

    pyinfo = PyInfo()

    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    assert pyinfo.string_types == (str, ) if pyinfo.PY3 else (basestring,)
    assert pyinfo.text_type == str if pyinfo.PY3 else unicode
    assert pyinfo.binary_type == bytes if pyinfo.PY3 else str
    assert pyinfo.integer_types == (int, ) if pyinfo.PY3 else (int, long)
    assert pyinfo.class_types == (type, ) if pyinfo.PY3 else (type, types.ClassType)

    # Test maxsize on PY2

# Generated at 2022-06-21 22:22:16.922150
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY2:
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert info.maxsize == int((1 << 31) - 1)
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                # 32-bit
                assert info.max

# Generated at 2022-06-21 22:22:23.958358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(2**10, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-21 22:22:32.661795
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_raises_attr_error(x):
        with pytest.raises(AttributeError):
            x

    assert PyInfo.PY2 or PyInfo.PY3
    assert_raises_attr_error(PyInfo.__dict__.__setitem__("PY2", True))
    assert_raises_attr_error(PyInfo.__dict__.__setitem__("PY3", True))
    assert_raises_attr_error(PyInfo.__dict__.__setitem__("PY2", False))
    assert_raises_attr_error(PyInfo.__dict__.__setitem__("PY3", False))

    assert_raises_attr_error(PyInfo.__dict__.__delitem__("PY2"))

# Generated at 2022-06-21 22:22:59.444050
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(u"a", PyInfo.text_type)

    assert isinstance(b"a", PyInfo.binary_type)
    assert not isinstance("a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

# Generated at 2022-06-21 22:23:04.539416
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"text_type", PyInfo.text_type)
    assert isinstance(b"binary_type", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:23:09.061678
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('s', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance('s', PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-21 22:23:16.066858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1.0, PyInfo.integer_types) is False
        assert isinstance('str', PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1.0, PyInfo.integer_types) is False
        assert isinstance('str', PyInfo.string_types)


# Generated at 2022-06-21 22:23:23.384914
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.maxsize) == int
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-21 22:23:30.884818
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert len(PyInfo.string_types) >= 2
    assert isinstance(b"", PyInfo.binary_type)
    assert len(PyInfo.binary_type) == 1
    assert isinstance(u"", PyInfo.text_type)
    assert len(PyInfo.text_type) == 1
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert len(PyInfo.integer_types) >= 2
    assert len(PyInfo.class_types) >= 2
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)

# Generated at 2022-06-21 22:23:36.489686
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-21 22:23:47.252941
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert not isinstance(0, PyInfo.class_types)
        assert isinstance(PyInfo, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)

# Generated at 2022-06-21 22:23:56.635485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyinform.pyInfo import PyInfo

    pyInfo = PyInfo()

    assert pyInfo.PY2 == (sys.version_info[0] == 2)
    assert pyInfo.PY3 == (sys.version_info[0] == 3)

    if pyInfo.PY3:
        assert pyInfo.maxsize == sys.maxsize
        assert pyInfo.string_types == (str,)
        assert pyInfo.text_type == str
        assert pyInfo.binary_type == bytes
        assert pyInfo.integer_types == (int,)
        assert pyInfo.class_types == (type,)
    else:  # PY2
        if sys.platform.startswith("java"):
            assert pyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:24:06.189636
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('a') in PyInfo.string_types
        assert type(u'a') in PyInfo.string_types
        assert type(b'a') not in PyInfo.string_types
    else:  # PY3
        assert type('a') not in PyInfo.string_types
        assert type(u'a') not in PyInfo.string_types
        assert type(b'a') in PyInfo.string_types

    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-21 22:24:46.325719
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:24:48.561226
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:51.958780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert not PyInfo.PY2
    assert PyInfo.PY3

# Generated at 2022-06-21 22:25:00.497640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("example", PyInfo.string_types)
    assert isinstance("example", PyInfo.string_types)
    assert isinstance(u"example", PyInfo.string_types)
    assert isinstance(b"example", PyInfo.binary_type)
    assert isinstance(123456, PyInfo.integer_types)
    assert isinstance(classmethod(lambda x: x), PyInfo.class_types)


if __name__ == "__main__":
    import nose

    nose.main()

# Generated at 2022-06-21 22:25:08.990144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('string', PyInfo.string_types)
        assert isinstance(u'string', PyInfo.string_types)
        assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:14.216752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:25:19.910999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert '%s' % type(PyInfo.string_types) == "<type 'tuple'>"
    assert type(PyInfo.text_type) is str
    assert type(PyInfo.binary_type()) is bytes
    assert '%s' % type(PyInfo.integer_types) == "<type 'tuple'>"
    assert '%s' % type(PyInfo.class_types) == "<type 'tuple'>"
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-21 22:25:29.215567
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert PyInfo.text_type == str
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert PyInfo.text_type == unicode
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:30.826683
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:25:40.546409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1 if PyInfo.PY2 else 1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:27:15.905748
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:27:21.408271
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)
    else:
        assert not isinstance('abc', PyInfo.string_types)
        assert isinstance('abc', str)
        assert isinstance(b'abc', PyInfo.string_types)
        assert isinstance(b'abc', bytes)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:27:33.672901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test of PyInfo.PY2
    assert type(PyInfo.PY2) is bool

    # Test of PyInfo.PY3
    assert type(PyInfo.PY3) is bool

    # Test of PyInfo.string_types
    assert type(PyInfo.string_types) is tuple

    # Test of PyInfo.text_type
    assert type(PyInfo.text_type) is type

    # Test of PyInfo.binary_type
    assert type(PyInfo.binary_type) is type

    # Test of PyInfo.integer_types
    assert type(PyInfo.integer_types) is tuple

    # Test of PyInfo.class_types
    assert type(PyInfo.class_types) is tuple

    # Test of PyInfo.maxsize
    assert type(PyInfo.maxsize) is int




# Generated at 2022-06-21 22:27:44.157050
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from sys import maxsize

    if PyInfo.PY3:
        assert PyInfo.PY2 is False
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == maxsize
    else:
        assert PyInfo.PY2 is True
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == maxsize




# Generated at 2022-06-21 22:27:45.935487
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == PyInfo.PY2 or sys.version_info[0] == PyInfo.PY3

# Generated at 2022-06-21 22:27:46.482400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-21 22:27:54.522141
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int