

# Generated at 2022-06-21 22:18:04.211471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(str, PyInfo.class_types)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:18:09.841445
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize > 0


# Module initialization
del test_PyInfo

# Generated at 2022-06-21 22:18:20.051144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (2 == sys.version_info[0])
    assert PyInfo.PY3 is (3 == sys.version_info[0])

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:18:30.898667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check the module loaded correctly
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, (int, long))

    # Check argument types
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)

# Generated at 2022-06-21 22:18:42.317528
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal, assert_is_instance
    import sys

    expected = ("PY2", "PY3", "string_types", "text_type", "binary_type",
                "integer_types", "class_types", "maxsize")
    assert_equal(set(expected), set(dir(PyInfo)))
    assert_is_instance(PyInfo.PY2, bool)
    assert_is_instance(PyInfo.PY3, bool)
    assert_is_instance(PyInfo.string_types, tuple)
    assert_is_instance(PyInfo.integer_types, tuple)
    assert_is_instance(PyInfo.class_types, tuple)
    assert_is_instance(PyInfo.maxsize, int)


# Generated at 2022-06-21 22:18:49.944828
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:18:57.747103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)

    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


# main
if __name__ == '__main__':
    # test_PyInfo()
    pass


# END - class_PyInfo

# Generated at 2022-06-21 22:19:06.810506
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )
    else:  # PY2
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:19:18.963006
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X(object):
        """Class with no __len__ method"""
        pass

    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(3, PyInfo.integer_types)
    assert not isinstance(None, PyInfo.integer_types)
    assert isinstance(None, PyInfo.class_types)
    assert not isinstance(3, PyInfo.class_types)
    assert isinstance('3', PyInfo.string_types)
    assert not isinstance(3, PyInfo.string_types)
    assert isinstance(u'3', PyInfo.text_type)
    assert not isinstance(b'3', PyInfo.text_type)
    assert isinstance(b'3', PyInfo.binary_type)
    assert not isinstance(u'3', PyInfo.binary_type)

# Generated at 2022-06-21 22:19:29.821230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:19:40.787421
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("str", PyInfo.string_types)
        assert isinstance(u"str", PyInfo.string_types)
        assert not isinstance(b"str", PyInfo.string_types)

        assert isinstance(u"str", PyInfo.text_type)
        assert not isinstance("str", PyInfo.text_type)
        assert not isinstance(b"str", PyInfo.text_type)

        assert isinstance(b"str", PyInfo.binary_type)
        assert not isinstance("str", PyInfo.binary_type)
        assert not isinstance(u"str", PyInfo.binary_type)

        assert isinstance(100, PyInfo.integer_types)
        assert not isinstance("100", PyInfo.integer_types)

# Generated at 2022-06-21 22:19:43.765679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)



# Generated at 2022-06-21 22:19:45.887509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)



# Generated at 2022-06-21 22:19:52.617736
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (basestring, )

    assert PyInfo.text_type == str if PyInfo.PY3 else unicode

    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str

    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)

    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (
        type, types.ClassType,
    )

    # if PyInfo.PY3:
    #     assert PyInfo.maxsize

# Generated at 2022-06-21 22:19:58.081151
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(long(1), PyInfo.integer_types)
    assert isinstance(int(1), PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:06.568223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:20:10.443966
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert len(PyInfo.string_types) == 1 and PyInfo.string_types[0] in (str, basestring)
    assert len(PyInfo.integer_types) == 2 and PyInfo.integer_types[0] in (int, long) and \
        PyInfo.integer_types[1] in (int, long)
    assert len(PyInfo.class_types) == 2 and PyInfo.class_types[0] in (type, types.ClassType) and \
        PyInfo.class_types[1] in (type, types.ClassType)
    assert len(PyInfo.binary_type) == 1 and PyInfo.binary_type[0] in (bytes, str)
    assert len(PyInfo.text_type) == 1 and PyInfo.text_type[0] in (str, unicode)



# Generated at 2022-06-21 22:20:14.404917
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY3 == (sys.version_info[0] == 3)
    assert pi.PY2 == (sys.version_info[0] == 2)

    assert isinstance("", pi.string_types)
    assert isinstance(b"", pi.binary_type)
    assert isinstance(u"", pi.text_type)
    assert isinstance(2, pi.integer_types)
    assert isinstance(int, pi.class_types)

    assert pi.maxsize == sys.maxsize


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:20:16.210806
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        PyInfo().foo

# Generated at 2022-06-21 22:20:26.631277
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)  # noqa

# Generated at 2022-06-21 22:20:32.869677
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:20:43.569149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
    else:
        assert not isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(list, PyInfo.class_types)
    assert not isinstance(list(), PyInfo.class_types)



# Generated at 2022-06-21 22:20:52.240879
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    s = "s"
    assert isinstance(s, PyInfo.string_types)

    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(s, PyInfo.integer_types)
    assert not isinstance(s, PyInfo.binary_type)
    assert not isinstance(s, PyInfo.text_type)



# Generated at 2022-06-21 22:20:54.759428
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:56.694629
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "No Python version detected"

# Generated at 2022-06-21 22:21:04.597283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:21:10.317214
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.binary_type is bytes
        assert PyInfo.text_type is str
        assert not PyInfo.maxsize > 1000
    else:
        assert PyInfo.binary_type is str
        assert PyInfo.text_type is unicode
        assert PyInfo.maxsize > 1000


# Test exceptions

# Generated at 2022-06-21 22:21:20.326407
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.string_types[0], type)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.integer_types[0], type)
    assert isinstance(pyinfo.maxsize, int)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.class_types[0], type)

# Generated at 2022-06-21 22:21:27.257410
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert type(pyinfo.string_types) is tuple
    assert type(pyinfo.text_type) is type
    assert type(pyinfo.binary_type) is type
    assert type(pyinfo.integer_types) is tuple
    assert type(pyinfo.class_types) is tuple


# noinspection PyUnresolvedReferences

# Generated at 2022-06-21 22:21:38.086628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == ('test_PyInfo' in sys.modules)
    assert PyInfo.binary_type == (
        types.BufferType if PyInfo.PY2 else types.BytesType)
    assert PyInfo.string_types == (
        (types.StringType, types.UnicodeType) if PyInfo.PY2 else (str, ))
    assert PyInfo.text_type == (
        types.UnicodeType if PyInfo.PY2 else str)
    assert PyInfo.integer_types == (
        (types.IntType, types.LongType) if PyInfo.PY2 else (int, ))
    assert PyInfo.class_types == (
        types.ClassType if PyInfo.PY2 else (type, ))

# Generated at 2022-06-21 22:21:48.853748
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:21:58.414977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test class PyInfo's constructor."""
    msg = ""
    try:
        assert PyInfo.PY2 is not None
    except AssertionError:
        msg += "PyInfo.PY2 is None\n"
    try:
        assert PyInfo.PY3 is not None
    except AssertionError:
        msg += "PyInfo.PY3 is None\n"
    try:
        assert PyInfo.string_types is not None
    except AssertionError:
        msg += "PyInfo.string_types is None\n"
    try:
        assert PyInfo.text_type is not None
    except AssertionError:
        msg += "PyInfo.text_type is None\n"

# Generated at 2022-06-21 22:22:10.139129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Don't use unittest.assertIsInstance because it would cause a circular import
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:20.067948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert not PyInfo.PY3
    else:
        assert not PyInfo.PY2
        assert PyInfo.PY3

    assert isinstance("foo", PyInfo.string_types)
    assert isinstance("foo", PyInfo.text_type)
    assert isinstance("foo", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert isinstance(test_PyInfo, PyInfo.class_types)



# Generated at 2022-06-21 22:22:29.296655
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test Python version compatibility.
    """

    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3

    text = PyInfo.text_type("")
    assert isinstance(text, PyInfo.string_types)

    if PyInfo.PY3:
        assert text.__class__ == str
    else:
        assert text.__class__ == unicode

    text_inherited = text.__class__("")
    assert isinstance(text_inherited, PyInfo.string_types)
    assert text_inherited.__class__ == text.__class__

    binary = PyInfo.binary_type("")
    assert isinstance(binary, bytes)
    assert isinstance(PyInfo.binary_type(text), bytes)

   

# Generated at 2022-06-21 22:22:33.796822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("test_PyInfo", PyInfo.string_types)
    assert isinstance(u"test_PyInfo", PyInfo.string_types)
    assert isinstance(b"test_PyInfo", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:35.697511
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types

    assert PyInfo.maxsize

# Generated at 2022-06-21 22:22:44.679477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def g(obj):
        if isinstance(obj, PyInfo.class_types):
            return obj.__bases__
        else:
            return type(obj)

    assert g(None) == type(None)
    assert g(NotImplemented) == type(NotImplemented)
    assert g(Ellipsis) == type(Ellipsis)
    assert g(False) == type(False)
    assert g(True) == type(True)
    assert g(1) == int
    assert g(1 << 65) == long
    assert g(1.0) == float
    assert g(1j) == complex
    assert g('') == str
    assert g(()) == tuple
    assert g(object()) == object
    assert g(PyInfo) == type


test_PyInfo()

# Generated at 2022-06-21 22:22:55.475184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 or PyInfo.PY3) is True
    assert (not PyInfo.PY2 or PyInfo.PY3) is True
    assert (PyInfo.PY2 or not PyInfo.PY3) is True
    assert (not PyInfo.PY2 or not PyInfo.PY3) is False

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(PyInfo.text_type(''), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(''), PyInfo.string_types)

# Generated at 2022-06-21 22:23:02.411785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 2147483647


tests = [test_PyInfo]

# Generated at 2022-06-21 22:23:33.005202
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance(PyInfo.maxsize, int)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

        assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:23:43.244442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == sys.version_info[0] == 3
    if PyInfo.PY2:
        assert sys.version_info[0] == 2

    assert isinstance(PyInfo.string_types[0], type)
    if PyInfo.PY2:
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str

# Generated at 2022-06-21 22:23:51.523868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True
    assert isinstance('test', PyInfo.string_types) is True
    assert isinstance(u'test', PyInfo.string_types) is True
    assert isinstance('test', PyInfo.text_type) is not True
    assert isinstance(u'text', PyInfo.text_type) is True
    assert isinstance(b'binary', PyInfo.binary_type) is True
    assert isinstance(1, PyInfo.integer_types) is True
    assert isinstance(int, PyInfo.class_types) is True

# Generated at 2022-06-21 22:23:58.934051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    True
    >>> PyInfo.PY3
    False
    >>> PyInfo.string_types
    (<type 'basestring'>,)
    >>> PyInfo.text_type
    <type 'unicode'>
    >>> PyInfo.binary_type
    <type 'str'>
    >>> PyInfo.integer_types == (int, long)
    True
    >>> PyInfo.class_types == (type, types.ClassType)
    True
    >>> PyInfo.maxsize > 0
    True
    """
    return 'PyInfo.__init__()'


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:24:10.869742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:24:20.531946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3
    assert isinstance(u'\u2603', PyInfo.text_type)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:32.055382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types
    pi = PyInfo()
    if pi.PY2:
        assert type(u"test") == pi.text_type
        assert type(u"test".encode("utf-8")) == pi.binary_type
        assert type(long(1)) == pi.integer_types[1]
        assert type(types.ClassType) == pi.class_types[1]
        if sys.platform.startswith("java"):
            assert pi.maxsize == int((1 << 31) - 1)
        else:
            class X(object):
                def __len__(self):
                    return 1 << 31
            try:
                len(X())
            except OverflowError:
                # 32-bit
                assert pi.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:24:43.686356
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple) is True
    assert isinstance(PyInfo.text_type, str) is True
    assert isinstance(PyInfo.binary_type, str) is True
    assert isinstance(PyInfo.integer_types, tuple) is True
    assert isinstance(PyInfo.class_types, tuple) is True

    if PyInfo.PY2:
        assert "basestring" in str(PyInfo.string_types) is True
        assert "unicode" in str(PyInfo.text_type) is True
        assert "str" in str(PyInfo.binary_type) is True
    else:
        assert "str" in str(PyInfo.string_types) is True
        assert "str" in str(PyInfo.text_type) is True
        assert "bytes" in str

# Generated at 2022-06-21 22:24:52.937867
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import string
    assert hasattr(PyInfo, 'PY2')
    assert hasattr(PyInfo, 'PY3')
    assert hasattr(PyInfo, 'string_types')
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert hasattr(PyInfo, 'binary_type')
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance('', PyInfo.binary_type)
    assert hasattr(PyInfo, 'text_type')
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert hasattr

# Generated at 2022-06-21 22:24:57.753406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)

# Generated at 2022-06-21 22:25:39.332283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert 'string' in PyInfo.string_types
    assert 'string' in PyInfo.text_type
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:44.662300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version should be 2 or 3"
    assert PyInfo.string_types, "string types should be defined for py2 and py3"
    assert PyInfo.text_type, "text type should be defined for py2 and py3"
    assert PyInfo.binary_type, "binary type should be defined for py2 and py3"
    assert PyInfo.integer_types, "integer types should be defined for py2 and py3"
    assert PyInfo.maxsize, "maxsize should be defined for py2 and py3"


# Unit tests for functions defined in this module

# Generated at 2022-06-21 22:25:55.703849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:59.937028
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    print(info.PY3)
    print(info.PY2)
    print(info.maxsize)
    print(info.binary_type)
    print(info.text_type)
    print(info.class_types)
    print(info.integer_types)
    print(info.string_types)


if __name__ == "__main__":
    test_PyInfo()
    print("\tTest Successfully")

# Generated at 2022-06-21 22:26:09.214125
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 or PyInfo.PY3 == bool(sys.version_info[0])
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:26:13.226422
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2 == False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize


"""

Errors =========

"""



# Generated at 2022-06-21 22:26:23.800469
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass
    # if not PyInfo.PY2:
    #     with pytest.raises(AssertionError):
    #         PyInfo.string_types = object
    #     with pytest.raises(AssertionError):
    #         PyInfo.text_type = object
    #     with pytest.raises(AssertionError):
    #         PyInfo.binary_type = object
    #     with pytest.raises(AssertionError):
    #         PyInfo.integer_types = object
    #     with pytest.raises(AssertionError):
    #         PyInfo.maxsize += 1
    # else:
    #     with pytest.raises(AssertionError):
    #         PyInfo.string_types = object
    #     with pytest.raises(Assert

# Generated at 2022-06-21 22:26:29.384726
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# For PY2/PY3 compatibility

# Generated at 2022-06-21 22:26:34.305252
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)

        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)

        assert isinstance("", PyInfo.binary_type)
        assert not isinstance(u"", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)

        assert isinstance("", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.text_type)

        assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-21 22:26:37.416293
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    print(p.string_types)
    print(p.integer_types)
    print(p.text_type)
    print(p.class_types)
    print(p.binary_type)

