

# Generated at 2022-06-21 22:17:59.036793
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == unicode

    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-21 22:18:05.278617
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str, unicode)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:18:14.573287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(123, PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(123, PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)

    assert isinstance(123, PyInfo.integer_types)
    assert not isinstance(1.2, PyInfo.integer_types)

    assert isinstance(str, PyInfo.class_types)
    assert not isinstance('a', PyInfo.class_types)



# Generated at 2022-06-21 22:18:21.276785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3  # exactly one of them
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:18:28.303898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check Python version
    PyInfo.PY2  # True for Python 2.X
    PyInfo.PY3  # True for Python 3.X

    # Check other constants
    isinstance("str", PyInfo.string_types)
    str is PyInfo.text_type
    isinstance(b"bytes", PyInfo.binary_type)
    isinstance(100, PyInfo.integer_types)
    isinstance(100, PyInfo.integer_types)



# Generated at 2022-06-21 22:18:34.896446
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info, PyInfo)
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-21 22:18:45.256550
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert (PyInfo.PY2 == (sys.version_info[0] == 2))
    except AssertionError:
        print("PyInfo.PY2: %s" % PyInfo.PY2)
        print("sys.version_info[0]: %s" % sys.version_info[0])
        raise
    try:
        assert (PyInfo.PY3 == (sys.version_info[0] == 3))
    except AssertionError:
        print("PyInfo.PY3: %s" % PyInfo.PY3)
        print("sys.version_info[0]: %s" % sys.version_info[0])
        raise


# Generated at 2022-06-21 22:18:50.911590
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test file.
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:18:57.020672
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:03.661950
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abcde', PyInfo.string_types)
        assert isinstance(b'abcde', PyInfo.binary_type)
        assert type(True) == types.BooleanType
    else:
        assert isinstance('abcde', PyInfo.string_types)
        assert isinstance(b'abcde', PyInfo.binary_type)
        assert type(True) == bool
    assert type(2) in PyInfo.integer_types

# Generated at 2022-06-21 22:19:15.701325
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(10**100, PyInfo.integer_types)



# Generated at 2022-06-21 22:19:18.962505
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for i in PyInfo.__dict__.keys():
        assert i in dir(PyInfo)

    assert PyInfo.maxsize == sys.maxint
    assert PyInfo.text_type == unicode



# Generated at 2022-06-21 22:19:19.509245
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-21 22:19:26.301577
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-21 22:19:34.432124
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.text_type) == len("test")
    assert len(PyInfo.binary_type) == len("test".encode("utf-8"))
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize == sys.maxsize or PyInfo.maxsize == 2 ** 31 - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:39.428607
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


# End of PyInfo



# Generated at 2022-06-21 22:19:47.335580
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2 ^ x.PY3
    if x.PY2:
        assert isinstance("123", x.string_types)
        assert isinstance(u"123", x.string_types)
        assert isinstance(123, x.integer_types)

# Generated at 2022-06-21 22:19:55.859717
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.string_types is str
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types is int
    assert PyInfo.class_types is type
    assert PyInfo.maxsize is 9223372036854775807



if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:58.827764
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.text_type == str
    assert info.binary_type == bytes
    assert info.integer_types == (int,)
    assert info.class_types == (type,)

# Generated at 2022-06-21 22:20:10.896430
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test cases for constructor of class PyInfo."""
    assert PyInfo.PY2 == (
        sys.version_info[0] == 2
    ), "PY2 in class PyInfo is not equal to (sys.version_info[0] == 2)"
    assert PyInfo.PY3 == (
        sys.version_info[0] == 3
    ), "PY3 in class PyInfo is not equal to (sys.version_info[0] == 3)"
    if PyInfo.PY3:
        assert (
            PyInfo.maxsize == sys.maxsize
        ), "Maxsize equals to sys.maxsize in case of Python 3"

# Generated at 2022-06-21 22:20:23.062129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo, type)
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:30.469896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == types.StringTypes
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:20:37.294878
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:48.172966
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('a', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert not isinstance(True, PyInfo.string_types)
    assert not isinstance(False, PyInfo.string_types)
    assert isinstance(None, type(None))

# Generated at 2022-06-21 22:20:50.601942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 or PyInfo.PY3) and not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-21 22:20:52.850901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.string_types is not None
    assert info.text_type is not None
    assert info.binary_type is not Non

# Generated at 2022-06-21 22:20:59.026117
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    assert isinstance(a.PY2, bool)
    assert isinstance(a.PY3, bool)
    assert isinstance(a.maxsize, int)

    assert int in a.integer_types
    assert long in a.integer_types

    if PyInfo.PY3:
        assert type in a.class_types
    else:
        assert type in a.class_types
        assert types.ClassType in a.class_types

# Generated at 2022-06-21 22:21:10.320515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)
    else:  # PY2
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object, PyInfo.class_types)

    assert PyInfo.maxsize is not None

# Generated at 2022-06-21 22:21:20.893677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert type("") == str
        assert type(u"") == str

        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:   # PY2
        assert type("") == str
        assert type(u"") == unicode

        assert PyInfo.string_types == (str, unicode)

# Generated at 2022-06-21 22:21:25.772131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == (str,) if PyInfo.PY2 else (bytes,)
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)

# Generated at 2022-06-21 22:21:44.953257
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert sys.version_info[0] == 3
        assert PyInfo.PY2 == False
        assert PyInfo.PY3 == True
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes

# Generated at 2022-06-21 22:21:56.726842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance('test', PyInfo.string_types)
    assert isinstance(u'test', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance('test', PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:05.347510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert issubclass(str, PyInfo.string_types)
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(), PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    try:
        assert isinstance(long(1), PyInfo.integer_types)
    except NameError:
        pass
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:22:12.619684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert isinstance(py_info.PY2, bool)
    assert isinstance(py_info.PY3, bool)
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, type)
    assert isinstance(py_info.binary_type, type)
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-21 22:22:24.078583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 is True or pi.PY2 is False
    assert pi.PY3 is True or pi.PY3 is False
    assert pi.maxsize > 0
    # string_types
    assert len(pi.string_types) == 1
    assert isinstance("", pi.string_types[0])
    assert isinstance("", pi.string_types)
    assert not isinstance(b"", pi.string_types[0])
    assert not isinstance(b"", pi.string_types)
    # text_type
    assert isinstance("", pi.text_type)
    assert not isinstance(b"", pi.text_type)
    # binary_type
    assert not isinstance("", pi.binary_type)

# Generated at 2022-06-21 22:22:30.237113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(None, (str, bytes))
    assert isinstance(u"", (str, bytes))
    assert isinstance(b"", (str, bytes))
    assert isinstance(1, (str, bytes))

# Generated at 2022-06-21 22:22:33.988872
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is True
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-21 22:22:43.386042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2
    assert not PyInfo().PY3

# Generated at 2022-06-21 22:22:54.004979
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert (
            PyInfo.maxsize == int((1 << 63) - 1)
        )  # correct for my 32-bit python 2.7.14
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:23:01.983407
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    if pyinfo.PY2:
        print("The current version is Python2.")

    if pyinfo.PY3:
        print("The current version is Python3.")

    print("The string types are " + str(pyinfo.string_types))

    print("The integer types are " + str(pyinfo.integer_types))

    print("The text type is " + pyinfo.text_type)

    print("The binary type is " + pyinfo.binary_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:23:24.050990
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print('PY2')
    else:
        print('PY3')


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:34.972075
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not (sys.version_info.major == 2 and sys.version_info.minor == 7):
        pyinfo = PyInfo()
        assert isinstance(pyinfo.string_types, tuple)
        assert isinstance(pyinfo.text_type, str)
        assert isinstance(pyinfo.binary_type, str)
        assert isinstance(pyinfo.integer_types, tuple)
        assert isinstance(pyinfo.class_types, tuple)
        assert isinstance(pyinfo.PY2, bool)
        assert isinstance(pyinfo.PY3, bool)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

    # PY2: True
    # PY3: True
    print(PyInfo.PY2)

# Generated at 2022-06-21 22:23:42.264305
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)

    else:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)

    class X:
        pass

    assert isinstance(X(), PyInfo.class_types)



# Generated at 2022-06-21 22:23:52.819204
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-21 22:24:00.558777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance("123", PyInfo.string_types)
    assert not isinstance(b"123", PyInfo.string_types)
    assert isinstance("123", PyInfo.text_type)
    assert not isinstance(b"123", PyInfo.text_type)
    assert isinstance(b"123", PyInfo.binary_type)
    assert not isinstance("123", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("123", PyInfo.integer_types)
    assert isinstance(dict, PyInfo.class_types)
    assert not isinstance([], PyInfo.class_types)
    assert PyInfo.maxsize > 0


# Generated at 2022-06-21 22:24:07.093996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    if PyInfo.PY2:
        string_types = basestring
    else:
        string_types = str
    assert isinstance('hello', string_types)


_sphinx_doc = """
:param str key:
    Can only be 'hello'
"""

_sphinx_doc2 = """
:param int key:
    Can only be 0
"""



# Generated at 2022-06-21 22:24:10.043524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:24:13.368657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    for a in [PyInfo.string_types, PyInfo.integer_types, PyInfo.class_types]:
        assert len(a) == 1
    assert PyInfo.maxsize > 0



# Generated at 2022-06-21 22:24:14.868763
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# End of file

# Generated at 2022-06-21 22:24:24.783616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("maxsize:", PyInfo.maxsize)
    print("string_types:", PyInfo.string_types)
    print("text_type:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)

    print(u"Test unicode:", isinstance(u"abc", PyInfo.string_types))
    print("Test str:", isinstance("abc", PyInfo.string_types))
    print("Test int:", isinstance(0, PyInfo.integer_types))



# Generated at 2022-06-21 22:25:06.592827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.integer_types) == tuple
    if PyInfo.PY3:
        assert type(PyInfo.text_type) == str
        assert type(PyInfo.binary_type) == bytes
        assert type(PyInfo.class_types) == tuple
    else:
        assert type(PyInfo.text_type) == unicode
        assert type(PyInfo.binary_type) == str
        assert type(PyInfo.class_types) == tuple


if __name__ == '__main__':
    sys.exit(0)

# Generated at 2022-06-21 22:25:14.406875
# Unit test for constructor of class PyInfo
def test_PyInfo():
    c = PyInfo()
    assert c.PY2 and not c.PY3
    assert c.string_types == (basestring,)
    assert c.text_type == unicode
    assert c.binary_type == str
    assert c.integer_types == (int, long)
    assert c.class_types == (type, types.ClassType)



# Generated at 2022-06-21 22:25:17.820667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:25:24.199143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (not PyInfo.PY3)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-21 22:25:30.075477
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)

    assert isinstance('a', PyInfo.binary_type)
    assert not isinstance('a', PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(PyInfo.__class__, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:33.697839
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)



# Generated at 2022-06-21 22:25:36.157445
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:42.453127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.integer_types)
    elif PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:53.899227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert type(pyinfo.PY2) == bool
    assert type(pyinfo.PY3) == bool
    if pyinfo.PY2:
        assert type(pyinfo.string_types) == tuple
        assert type(pyinfo.text_type) == str
        assert type(pyinfo.binary_type) == str
        assert type(pyinfo.integer_types) == tuple
        assert type(pyinfo.class_types) == tuple
    elif pyinfo.PY3:
        assert type(pyinfo.string_types) == tuple
        assert type(pyinfo.text_type) == str
        assert type(pyinfo.binary_type) == bytes
        assert type(pyinfo.integer_types) == tuple
        assert type(pyinfo.class_types) == tuple

# Generated at 2022-06-21 22:26:01.963192
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class MyClass(object):
        def __init__(self, method):
            self.method = method

        def __call__(self, *args, **kwargs):
            return self.method(*args, **kwargs)

    # if pi2.PY3:
    #     assert pi2.string_types == (str,)
    #     assert pi2.text_type == str

    assert pi2.string_types == (basestring,)
    assert pi2.text_type == unicode
    # _assert(pi2.binary_type == bytes)

    assert pi2.binary_type == str
    print("maxsize: {}".format(pi2.maxsize))



# Generated at 2022-06-21 22:27:44.700617
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        if sys.maxunicode != 1114111:
            assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:27:53.247205
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance('str', PyInfo.text_type)
    assert isinstance(b'byte', PyInfo.binary_type)
    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(types, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)