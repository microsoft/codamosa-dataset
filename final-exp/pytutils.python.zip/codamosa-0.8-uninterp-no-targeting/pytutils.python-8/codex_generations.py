

# Generated at 2022-06-21 22:18:08.978638
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        # assert PyInfo.string_types == (basestring,)
        assert type("") in PyInfo.string_types
        assert type("i") in PyInfo.string_types
        assert type("i".encode("utf8")) not in PyInfo.string_types
        # assert PyInfo.text_type == unicode
        assert type("") == PyInfo.text_type
        assert type("i") == PyInfo.text_type

# Generated at 2022-06-21 22:18:17.119203
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pyexpect
    expected = [u'PyInfo("2.7.12 (v2.7.12:d33e0cf91556, Jun 27 2016, 15:19:22) [MSC v.1500 32 bit (Intel)] on win32", [2, 7, 12, \'final\', 0], \'2.7.12 (v2.7.12:d33e0cf91556, Jun 27 2016, 15:19:22) [MSC v.1500 32 bit (Intel)] on win32\', \'MSC v.1500 32 bit (Intel)\', \'win32\', None)']
    pyexpect.check_repr(PyInfo)
    if __name__ == '__main__':
        pyexpect.print_diff(expected)


# Generated at 2022-06-21 22:18:27.090823
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert True
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type('') == ''
    assert PyInfo.binary_type('') == b''
    assert PyInfo.string_types == (str,) if PyInfo.PY3 else (basestring,)
    assert PyInfo.class_types == (type,) if PyInfo.PY3 else (type, types.ClassType)
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)


if PyInfo.PY2:
    import __builtin__ as builtins
else:
    import builtins



# Generated at 2022-06-21 22:18:29.492615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if PyInfo.PY3:
        assert PyInfo.text_type == str
    else:
        assert PyInfo.text_type == unicode

# Generated at 2022-06-21 22:18:32.352470
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-21 22:18:40.386836
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance(PyInfo.maxsize, int)

    assert isinstance("", PyInfo.string_types)
    assert PyInfo.text_type is not None
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-21 22:18:47.065275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for name, value in dict(
        PY2=False,
        PY3=True,
        string_types=(str,),
        text_type=str,
        binary_type=bytes,
        integer_types=(int,),
        class_types=(type,),
        maxsize=2 ** 63 - 1,
    ).items():
        if getattr(PyInfo, name) != value:
            raise AssertionError(
                "Expected value of {} is `{}`, but `{}`".format(
                    name, value, getattr(PyInfo, name)
                )
            )



# Generated at 2022-06-21 22:18:49.189209
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False
    assert PyInfo.PY2 is True
    assert PyInfo.maxsize == 2147483647
    assert sys.maxsize == 9223372036854775807

# Generated at 2022-06-21 22:18:57.081374
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for class_types attribute
    def f():
        pass

    assert isinstance(f, PyInfo.class_types), 'f is not instance of class_types'
    assert isinstance(int, PyInfo.class_types), "int is not instance of class_types"

    # Test for maxsize attribute
    value = PyInfo.maxsize / 2
    if value > sys.maxsize:
        value = sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:03.322382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:14.935828
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


# Assign the values of the members of class PyInfo to the name space of this module

# Generated at 2022-06-21 22:19:20.485184
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:28.920683
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.text_type(), PyInfo.text_type)
    assert isinstance(PyInfo.binary_type(), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    class A:
        pass

    t = type(A)
    assert isinstance(t, PyInfo.class_types)

    if PyInfo.PY3:
        t = A.__class__
        assert isinstance(t, PyInfo.class_types)



# Generated at 2022-06-21 22:19:36.754521
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('test', PyInfo.string_types)
        assert isinstance(b'test', PyInfo.binary_type)
        assert isinstance(Exception, PyInfo.integer_types)
        assert isinstance(Exception, PyInfo.class_types)
        assert PyInfo.maxsize > 0
    else:
        assert not isinstance('test', PyInfo.string_types)
        assert not isinstance(b'test', PyInfo.binary_type)
        assert not isinstance(Exception, PyInfo.integer_types)
        assert not isinstance(Exception, PyInfo.class_types)
        assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:19:46.390655
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == bool(
        sys.version_info[0] == 2
    ), "The value of field PY2 is wrong."
    assert PyInfo.PY3 == bool(
        sys.version_info[0] == 3
    ), "The value of field PY3 is wrong."
    assert PyInfo.string_types == types.StringTypes, "The value of field string_types is wrong."
    assert PyInfo.text_type == types.UnicodeType, "The value of field text_type is wrong."
    assert PyInfo.binary_type == types.BufferType, "The value of field binary_type is wrong."
    assert PyInfo.integer_types == types.IntType, "The value of field integer_types is wrong."

# Generated at 2022-06-21 22:19:51.065105
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:58.553775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(v):
        assert v

    assert 'import PyInfo'
    assert 'check(PyInfo.PY2)'
    assert 'check(PyInfo.PY3)'
    assert 'check(PyInfo.string_types)'
    assert 'check(PyInfo.text_type)'
    assert 'check(PyInfo.binary_type)'
    assert 'check(PyInfo.integer_types)'
    assert 'check(PyInfo.maxsize)'
    assert 'check(PyInfo.class_types)'



# Generated at 2022-06-21 22:20:09.023152
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:20:19.281394
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)

        assert isinstance(u"a", PyInfo.text_type)
        assert not isinstance("a", PyInfo.text_type)
        assert not isinstance(b"a", PyInfo.text_type)

        assert isinstance(b"a", PyInfo.binary_type)
        assert not isinstance("a", PyInfo.binary_type)
        assert not isinstance(u"a", PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:26.354999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-21 22:20:33.786901
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:43.985861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 in (True, False)
    assert PyInfo.PY3 in (True, False)
    assert PyInfo.PY2 != PyInfo.PY3
    
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)
    assert isinstance(types.FunctionType, PyInfo.class_types)
    assert isinstance(object(), PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:20:47.931333
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:56.482840
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from easydict import EasyDict
    assert EasyDict(PyInfo.__dict__) == EasyDict({
        '__class__': PyInfo,
        'PY2': sys.version_info[0] == 2,
        'PY3': sys.version_info[0] == 3,
        'string_types': basestring,
        'text_type': unicode,
        'binary_type': str,
        'integer_types': (int, long),
        'class_types': (type, types.ClassType),
        'maxsize': int((1 << 63) - 1),
    })


# Generated at 2022-06-21 22:21:03.000200
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('string', PyInfo.string_types)
    assert isinstance(u'string', PyInfo.string_types)
    assert isinstance('string', PyInfo.text_type)
    assert isinstance('string', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:12.741616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:21:25.000476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    try:
        PyInfo().PY2
    except AttributeError:
        pytest.fail("Error when constructing PyInfo class")
    try:
        PyInfo().PY3
    except AttributeError:
        pytest.fail("Error when constructing PyInfo class")
    try:
        PyInfo().string_types
    except AttributeError:
        pytest.fail("Error when constructing PyInfo class")
    try:
        PyInfo().text_type
    except AttributeError:
        pytest.fail("Error when constructing PyInfo class")
    try:
        PyInfo().binary_type
    except AttributeError:
        pytest.fail("Error when constructing PyInfo class")

# Generated at 2022-06-21 22:21:36.746548
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (basestring, )
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (
        type, ) if PyInfo.PY3 else (type, types.ClassType)

    print('Test %s ok' % PyInfo.__name__)



# Generated at 2022-06-21 22:21:39.203450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    check_instance_interface(PyInfo)
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 1



# Generated at 2022-06-21 22:21:42.057525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:21:59.670260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert PyInfo.maxsize == sys.maxsize if PyInfo.PY3 else (2 ** 31 - 1) if PyInfo.PY2 and (
        sys.platform.startswith("java")
    ) else (2 ** 32 - 1) if PyInfo.PY2 else (2 ** 31 - 1)

# Generated at 2022-06-21 22:22:10.671374
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("a", PyInfo.string_types)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b"a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:21.714171
# Unit test for constructor of class PyInfo
def test_PyInfo():

    test_string_types = isinstance('hello', PyInfo.string_types)
    test_text_type = isinstance(u'hello', PyInfo.text_type)
    test_binary_type = isinstance(b'hello', PyInfo.binary_type)
    test_integer_types = isinstance(1, PyInfo.integer_types)
    test_class_types = isinstance(int, PyInfo.class_types)
    test_maxsize = isinstance(PyInfo.maxsize, int)

    assert test_string_types
    assert test_text_type
    assert test_binary_type
    assert test_integer_types
    assert test_class_types
    assert test_maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:30.572994
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:22:32.568485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:22:35.548890
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", text_type)
    assert isinstance(b"", binary_type)
    assert isinstance(1, integer_types)

# Generated at 2022-06-21 22:22:39.746268
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.maxsize == 1 << 31 - 1

# Generated at 2022-06-21 22:22:44.467746
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring, )
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:22:52.343428
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test PyInfo.__init__()
    # assert PyInfo.PY2 is True or False
    # assert PyInfo.PY3 is True or False
    # assert isinstance(PyInfo.maxsize,int)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-21 22:22:57.966264
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)


# vi: ts=4 sw=4 et:

# Generated at 2022-06-21 22:23:27.700358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    if pyinfo.PY2:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)
    elif pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int,)
        assert pyinfo.class_

# Generated at 2022-06-21 22:23:29.182088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert len(PyInfo.__dict__.keys()) > 2


# Unit test PyInfo.PY2

# Generated at 2022-06-21 22:23:33.993777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert type(PyInfo.maxsize) == int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:39.483240
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-21 22:23:49.255584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert isinstance("A", PyInfo.string_types)
    assert not isinstance(b"A", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    if PyInfo.PY2:
        assert isinstance(long, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:55.435354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    test_list = [PyInfo.maxsize]

# Generated at 2022-06-21 22:23:59.106664
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-21 22:24:04.330252
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is True and PyInfo.PY3 is False
    assert PyInfo.PY3 is True and PyInfo.PY2 is False

# Generated at 2022-06-21 22:24:12.992072
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert not isinstance(1.0, PyInfo.class_types)
        assert isinstance(str, PyInfo.class_types)

# Generated at 2022-06-21 22:24:23.669412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:25:07.851274
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.binary_type == bytes
    assert PyInfo.class_types == (type,)
    assert PyInfo.integer_types == (int,)
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-21 22:25:11.900918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Make sure no instance can be constructed.
    with pytest.raises(TypeError):
        PyInfo()



# Generated at 2022-06-21 22:25:17.097283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert type(PyInfo.maxsize) == int
    else:
        assert isinstance(u'abc', PyInfo.string_types)
        assert type(PyInfo.maxsize) == long
    # end if
# end test_PyInfo


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:27.243231
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    if sys.version_info[0] == 2:  # PY2
        assert isinstance(PyInfo.string_types[0], types.TypeType)
        assert isinstance(PyInfo.text_type, types.TypeType)

        assert PyInfo.binary_type.__name__ == 'str'
        assert isinstance(PyInfo.integer_types[0], types.TypeType)
        assert isinstance(PyInfo.class_types[0], types.TypeType)
        assert isinstance(PyInfo.class_types[1], types.TypeType)
    else:  # PY3
        assert isinstance(PyInfo.string_types[0], type)
        assert isinstance(PyInfo.text_type, type)

        assert PyInfo.binary_type.__name__ == 'bytes'

# Generated at 2022-06-21 22:25:38.899319
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Instantiate
    x = PyInfo()
    # Check attribute PY3
    if x.PY3:
        assert x.PY2 == False
    else:
        assert x.PY2 == True
        # Check attribute string_types
    assert isinstance("", x.string_types)
    assert isinstance(b"", x.string_types)
        # Check attribute text_type
    assert isinstance("", x.text_type)
    assert not isinstance(b"", x.text_type)
        # Check attribute binary_type
    assert not isinstance("", x.binary_type)
    assert isinstance(b"", x.binary_type)
        # Check attribute integer_types
    assert isinstance(1, x.integer_types)
    # TODO: Check attribute maxsize
    # TODO

# Generated at 2022-06-21 22:25:42.955809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == 2 ** 63 - 1

# Generated at 2022-06-21 22:25:50.133117
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == PyInfo.PY3 or sys.version_info[0] == PyInfo.PY2
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types) or isinstance(1, PyInfo.integer_types)


# Unit tests for methods of class FileHelper

# Generated at 2022-06-21 22:25:59.129510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.string_types)

    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.string_types)


# The following functions are copied from code compiled from these three
# original source files:
#
# https://docs

# Generated at 2022-06-21 22:26:02.224774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3



# Generated at 2022-06-21 22:26:12.257255
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check if PyInfo is a data descriptor
    assert isinstance(PyInfo.PY2, property)
    assert isinstance(PyInfo.PY3, property)
    assert isinstance(PyInfo.string_types, property)
    assert isinstance(PyInfo.text_type, property)
    assert isinstance(PyInfo.binary_type, property)
    assert isinstance(PyInfo.integer_types, property)
    assert isinstance(PyInfo.class_types, property)
    assert isinstance(PyInfo.maxsize, property)

    # Check if PyInfo is immutable
    with pytest.raises(AttributeError):
        PyInfo.PY2 = True
    with pytest.raises(AttributeError):
        PyInfo.PY3 = True

# Generated at 2022-06-21 22:27:52.940406
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:27:58.853441
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple

