

# Generated at 2022-06-21 22:17:58.722456
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.min_size == 2
    assert PyInfo.maxsize == 2**31 - 1
    assert PyInfo.maxsize == 2 ** 31 - 1

# Generated at 2022-06-21 22:18:09.967155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (basestring, )
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)
    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (type, types.ClassType)

# Generated at 2022-06-21 22:18:14.916060
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    
    :return: 
    """
    py_info = PyInfo()
    assert(py_info.PY2 is True or py_info.PY2 is False)
    assert(py_info.PY3 is True or py_info.PY3 is False)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:18:21.303251
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import json
    import six

    # Test case
    if PyInfo.PY2:
        assert type(PyInfo.string_types[0]) == types.TypeType
        assert type(PyInfo.text_type) == types.TypeType
        assert type(PyInfo.binary_type) == types.TypeType
        assert type(PyInfo.integer_types[0]) == types.TypeType
        assert type(PyInfo.class_types[0]) == types.TypeType
    elif PyInfo.PY3:
        assert type(PyInfo.string_types[0]) == type
        assert type(PyInfo.text_type) == type
        assert type(PyInfo.binary_type) == type
        assert type(PyInfo.integer_types[0]) == type

# Generated at 2022-06-21 22:18:32.340996
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    # Test the `PY2` and `PY3` attributess
    assert py_info.PY2 == PyInfo.PY2
    assert py_info.PY3 == PyInfo.PY3

    # Test the `string_types` attribute
    if py_info.PY2:
        assert py_info.string_types == (basestring,)
    else:
        assert py_info.string_types == (str,)

    # Test the `text_type` attribute
    if py_info.PY2:
        assert py_info.text_type == unicode
    else:
        assert py_info.text_type == str

    # Test the `binary_type` attribute
    if py_info.PY2:
        assert py_info.binary_type

# Generated at 2022-06-21 22:18:41.544156
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(lambda: None, types.LambdaType)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:18:47.493135
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True and PyInfo.PY3 is False
    assert isinstance(u"unicode", PyInfo.string_types) is True
    assert isinstance("string", PyInfo.string_types) is True
    assert isinstance(b"bytes", PyInfo.string_types) is False
    assert isinstance(u"unicode", PyInfo.text_type) is True
    assert isinstance("string", PyInfo.text_type) is False
    assert isinstance(b"bytes", PyInfo.binary_type) is True
    assert isinstance(u"unicode", PyInfo.class_types) is False
    assert isinstance(int, PyInfo.class_types) is True
    assert isinstance(1, PyInfo.integer_types) is True

# Generated at 2022-06-21 22:18:52.280509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()
    assert pyi.PY2 == (sys.version_info[0] == 2)
    assert pyi.PY3 == (sys.version_info[0] == 3)

    assert pyi.PY2 or pyi.PY3 == True



# Generated at 2022-06-21 22:19:02.650038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()


"""
# Other Py2 - Py3 adjustments
*   for line in sys.stdin:
*   print 'Hello, world!'
*   dict.iteritems
*   dict.iterkeys
*   dict.itervalues
*   file
*   map
"""

# Generated at 2022-06-21 22:19:04.830874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for constructor of class PyInfo."""
    # coverage for test
    assert isinstance(PyInfo, object)



# Generated at 2022-06-21 22:19:17.689691
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:19:19.293689
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:24.472331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.class_types

# Generated at 2022-06-21 22:19:32.508381
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test object is created
    p = PyInfo()

    # Test object is of class PyInfo
    assert isinstance(p, PyInfo)

    # Test constructor inputs are of proper type
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)

    # Test constructor inputs have the correct values
    # PY2 and PY3 are either True or False
    if p.PY2:
        assert p.PY3 is False

# Generated at 2022-06-21 22:19:33.921199
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3



# Generated at 2022-06-21 22:19:41.919666
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:45.572791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-21 22:19:49.511846
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Cannot unittest these two flags.
    assert (PyInfo.PY2 or PyInfo.PY3)
    assert not (PyInfo.PY2 and PyInfo.PY3)

    # These flags must always be true.
    assert isinstance("string", PyInfo.string_types)  # noqa
    assert isinstance("string", PyInfo.text_type)  # noqa
    assert isinstance(b"string", PyInfo.binary_type)  # noqa
    assert isinstance(1, PyInfo.integer_types)  # noqa
    assert isinstance(object, PyInfo.class_types)  # noqa
    assert 1 < PyInfo.maxsize  # noqa


if PyInfo.PY2:
    import cStringIO as StringIO
else:
    import io as StringIO




# Generated at 2022-06-21 22:19:56.281964
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    for var in ['string_types', 'text_type', 'binary_type']:
        assert isinstance(getattr(PyInfo, var), type)
    for var in ['integer_types', 'class_types']:
        assert isinstance(getattr(PyInfo, var), tuple)



# Generated at 2022-06-21 22:19:59.213221
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False

# Generated at 2022-06-21 22:20:15.038791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)

    if pi.PY2:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)
    else:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)


test_PyInfo()



# Generated at 2022-06-21 22:20:20.830307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_constructor(self):
            self.assertIsNotNone(PyInfo())

    return unittest.TestLoader().loadTestsFromTestCase(TestPyInfo)


if __name__ == "__main__":
    unittest.TextTestRunner().run(test_PyInfo())

# Generated at 2022-06-21 22:20:30.064603
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True, "PY2 or PY3 should be True."

    if PyInfo.PY2:
        assert isinstance('', basestring), "should be basestring."
        assert not isinstance('', str), "should not be str."
        assert isinstance(u'', basestring), "should be basestring."
        assert not isinstance(u'', str), "should not be str."
        assert isinstance(2, (int, long)), "should be (int, long)."
        assert not isinstance(2, int), "should not be int."

# Generated at 2022-06-21 22:20:40.898414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PY2:
        assert isinstance(PyInfo.string_types[0], basestring)
        assert isinstance(PyInfo.text_type, unicode)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types[0], (int, long))
        assert isinstance(PyInfo.class_types[0], (type, types.ClassType))
    else:  # PY3
        assert isinstance(PyInfo.string_types[0], str)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types[0], int)
        assert isinstance(PyInfo.class_types[0], type)
    return True



# Generated at 2022-06-21 22:20:51.993384
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)

    assert not isinstance("", PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:00.320921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert PyInfo.string_types
    assert PyInfo.string_types == (basestring,)

    assert PyInfo.text_type
    assert PyInfo.text_type == unicode

    assert PyInfo.binary_type
    assert PyInfo.binary_type == str

    assert PyInfo.integer_types
    assert PyInfo.integer_types == (int, long)

    assert PyInfo.class_types
    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize
    assert PyInfo.maxsize == ((1 << 31) - 1)

# Generated at 2022-06-21 22:21:11.704250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)

        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.binary_type)

        assert not isinstance(u"", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert not isinstance(1, PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)

        assert not isinstance("", PyInfo.string_types)

# Generated at 2022-06-21 22:21:20.010207
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    print(pyinfo.PY2)
    print(pyinfo.PY3)
    print(pyinfo.string_types)
    print(pyinfo.text_type)
    print(pyinfo.binary_type)
    print(pyinfo.integer_types)
    print(pyinfo.class_types)
    print(pyinfo.maxsize)


# Generated at 2022-06-21 22:21:21.026716
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-21 22:21:25.460482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)

    assert isinstance(0, PyInfo.integer_types)

    try:
        assert isinstance(x, PyInfo.integer_types)
    except NameError:
        print("NameError is expected.")

    assert isinstance(PyInfo, type(PyInfo))


test_PyInfo()

# Generated at 2022-06-21 22:21:45.101461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    try:
        PyInfo.PY4
    except AttributeError:
        pass
    else:
        raise AssertionError("PyInfo's attribute \'PY4\' should not exist")

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert isinstance(PyInfo.binary_type, type)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:21:51.357417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:21:59.414730
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert "unicode" in dir(PyInfo)
    if PyInfo.PY3:
        assert type(PyInfo.unicode) == type(str)
    else:
        assert type(PyInfo.unicode) == type(unicode)

    assert type(PyInfo.string_types) == type(tuple())
    assert type(PyInfo.string_types[-1]) == type(str)

    assert type(PyInfo.integer_types) == type(tuple())
    assert type(PyInfo.integer_types[-1]) == type(int)

    assert type(PyInfo.class_types) == type(tuple())
    assert type(PyInfo.class_types[-1]) == type(type)

# Generated at 2022-06-21 22:22:03.699216
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)

    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)



# Generated at 2022-06-21 22:22:06.929814
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == basestring


if __name__ == "__main__":
    import pytest

    pytest.main(args=["-ra", __file__])

# Generated at 2022-06-21 22:22:15.264698
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class Test(unittest.TestCase):
        def test_py2(self):
            self.assertTrue(PyInfo.PY2)
            self.assertFalse(PyInfo.PY3)
            self.assertIsInstance("", PyInfo.string_types)
            self.assertIsInstance(u"", PyInfo.string_types)
            self.assertIsInstance("", PyInfo.binary_type)
            self.assertIsInstance("", PyInfo.text_type)
            self.assertIsInstance("", PyInfo.string_types)
            self.assertIsInstance(1, PyInfo.integer_types)
            self.assertIsInstance(long(1), PyInfo.integer_types)

        def test_py3(self):
            self.assertTrue(PyInfo.PY3)
           

# Generated at 2022-06-21 22:22:19.242926
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> print("Python %d.%d.%d" % (
    ...PyInfo.PY3, PyInfo.PY2, PyInfo.maxsize))
    Python 3.0.0
    """
    pass



# Generated at 2022-06-21 22:22:20.674934
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class X(object):
        pass
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    asse

# Generated at 2022-06-21 22:22:28.036304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert isinstance(u"a" + u"" + "b", PyInfo.text_type)
    assert isinstance(u"a" + u"" + b"b", PyInfo.text_type)
    assert isinstance(b"a" + u"" + "b", PyInfo.text_type)
    assert isinstance(b"a" + u"" + b"b", PyInfo.text_type)

    assert PyInfo.text_type(b"a") == "a"
    assert PyInfo.binary_type("a") == b"a"

    int_max_plus_1 = PyInfo.maxsize + 1
    assert isinstance(int_max_plus_1, int)

# Generated at 2022-06-21 22:22:30.994449
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == "__main__":
    import mindspore.common.dtype as mstype
    if mstype.bool_ == bool:
        print("Abel:", mstype.bool_)

# Generated at 2022-06-21 22:22:51.376885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-21 22:22:56.530885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:07.255942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert isinstance(PyInfo.string_types, tuple)
    for klass in PyInfo.string_types:
        assert issubclass(klass, object)

    assert isinstance(PyInfo.text_type, type)
    assert issubclass(PyInfo.text_type, object)

    assert isinstance(PyInfo.binary_type, type)
    assert issubclass(PyInfo.binary_type, object)

    assert isinstance(PyInfo.integer_types, tuple)
    for klass in PyInfo.integer_types:
        assert issubclass(klass, object)

    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-21 22:23:16.709880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test object creation
    def test_exists():
        assert PyInfo is not None

    # Test class attributes
    def test_PY2():
        assert PyInfo.PY2

    def test_PY3():
        assert not PyInfo.PY3

    def test_string_types():
        assert PyInfo.string_types == (basestring,)

    def test_text_type():
        assert PyInfo.text_type == unicode

    def test_binary_type():
        assert PyInfo.binary_type == str

    def test_integer_types():
        assert PyInfo.integer_types == (int, long)

    def test_class_types():
        assert PyInfo.class_types == (type, types.ClassType)


# Generated at 2022-06-21 22:23:27.404867
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = True or False
    assert isinstance(PyInfo.PY2, bool)
    # PY3 = True or False
    assert isinstance(PyInfo.PY3, bool)

    # maxsize: maximum number of Python objects
    assert PyInfo.maxsize > 0
    # string types: str, basestring
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    # text type: str or unicode
    assert isinstance(PyInfo.text_type(), PyInfo.string_types)
    # integer types: int, long
    assert isinstance(0, PyInfo.integer_types)
    # class types: type, types.ClassType
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-21 22:23:38.248115
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('xxx', PyInfo.string_types)
    assert isinstance(u'xxx', PyInfo.string_types)
    #
    assert isinstance('xxx', PyInfo.text_type)
    assert not isinstance(b'xxx', PyInfo.text_type)
    assert isinstance(u'xxx', PyInfo.text_type)
    #
    assert isinstance(b'xxx', PyInfo.binary_type)
    assert not isinstance('xxx', PyInfo.binary_type)
    #
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:42.961050
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:23:44.277128
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.maxsize > 0



# Generated at 2022-06-21 22:23:54.913889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    types_list = (str, type, types.ClassType, int, long)
    types_list_py2 = (str, basestring, types.ClassType, int, long)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:23:58.381395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

test_PyInfo()

# Generated at 2022-06-21 22:24:42.074350
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:24:48.650889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
    else:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)


if __name__ == '__main__':
    import pytest

    pytest.main()

# Generated at 2022-06-21 22:25:01.860279
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:25:06.559832
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # assert that PyInfo.PY2 is False
    assert PyInfo.PY2 is False
    # assert that PyInfo.PY3 is True
    assert PyInfo.PY3 is True


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:25:11.013578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):
        pass

    t = PyInfo()
    if t.PY2:
        PyInfoTest.assertTrue(t.maxsize > 10 ** 9, 'Maxsize too small')
    else:
        PyInfoTest.assertTrue(t.maxsize > 10 ** 18, 'Maxsize too small')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:18.626383
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert all(isinstance(s, type) for s in PyInfo.string_types)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert all(isinstance(s, type) for s in PyInfo.integer_types)
    assert all(isinstance(s, type) for s in PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:25:27.073768
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is unicode
    assert type(PyInfo.binary_type) is str
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == (1 << 31) - 1
    elif sys.maxsize < (1 << 62):
        assert PyInfo.maxsize == (1 << 31) - 1
    else:
        assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-21 22:25:38.686618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    from pyinfra_cli import PyInfo
    from six import string_types, text_type, binary_type, \
        integer_types, class_types, maxsize

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    assert PyInfo.string_types == string_types
    assert PyInfo.text_type == text_type
    assert PyInfo.binary_type == binary_type
    assert PyInfo.integer_types == integer_types
    assert PyInfo.class_types == class_types

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert PyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-21 22:25:45.086747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(1j, PyInfo.integer_types)
    assert not isinstance(1.0j, PyInfo.integer_types)
    assert PyInfo.maxsize > 1

    class A(object):
        pass

    assert isinstance

# Generated at 2022-06-21 22:25:55.838457
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance("abc", PyInfo.string_types)
    assert not isinstance("abc", PyInfo.binary_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert not isinstance(b"abc", PyInfo.string_types)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(3.14, PyInfo.integer_types) is False
    assert isinstance("abc", PyInfo.integer_types) is False
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance("abc".encode("utf-8"), PyInfo.string_types)
    assert isinstance("abc".encode("utf-8"), PyInfo.binary_type)


if __name__ == "__main__":
    test

# Generated at 2022-06-21 22:27:37.960196
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    print(pyinfo.PY3)
    print(pyinfo.string_types)

    assert pyinfo.PY3 == True
    assert pyinfo.string_types == (str,)


if __name__ == "__main__":
    # Run the unit test
    test_PyInfo()

# Generated at 2022-06-21 22:27:39.283039
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-21 22:27:47.049608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    # check if PY2 is not equal to PY3
    assert not pyinfo.PY2 == pyinfo.PY3
    # check if PY2 is equal to PY2
    assert pyinfo.PY2 == pyinfo.PY2
    assert pyinfo.PY3 == pyinfo.PY3
    # check if type string_types is tuple
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, str)
    # check if text_type is equal to str (in PY2)
    assert pyinfo.text_type == str
    assert isinstance(pyinfo.binary_type, str)
    # check if binary_type is equal

# Generated at 2022-06-21 22:27:54.473566
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)


if __name__ == "__main__":
    import pytest

    pytest.main([__file__])