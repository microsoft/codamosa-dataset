

# Generated at 2022-06-21 22:18:10.287050
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:18:12.667400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    # list.__class__
    assert isinstance(list.__class__, PyInfo.class_types)



# Generated at 2022-06-21 22:18:15.123916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3


if __name__ == '__main__':
    from pyinfo import PyInfo
    test_PyInfo()

# Generated at 2022-06-21 22:18:26.900397
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # String
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)

    # Text
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)

    # Binary type
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance('', PyInfo.binary_type)

    # Integer
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    # Class

# Generated at 2022-06-21 22:18:28.925448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:18:35.610696
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3, "PY2 XOR PY3"
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:18:40.532791
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(max, PyInfo.class_types)

# Generated at 2022-06-21 22:18:45.337059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:18:56.584616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3


# Generated at 2022-06-21 22:19:02.699002
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("".decode(), PyInfo.text_type)
    assert isinstance("".encode(), PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:19:17.974939
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types)
        assert not isinstance(b'a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance(b'a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert not isinstance('a', PyInfo.binary_type)
        assert isinstance(12, PyInfo.integer_types)
        assert not isinstance(2.0, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:27.948492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.string_types)
        assert isinstance(u'x', PyInfo.text_type)
        assert isinstance('x', PyInfo.binary_type)
        assert isinstance(str, PyInfo.class_types)
    else:
        assert isinstance(1, int)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance('x', PyInfo.string_types)
        assert isinstance('x', PyInfo.text_type)
        assert isinstance(b'x', PyInfo.binary_type)
        assert isinstance(str, PyInfo.class_types)

# Generated at 2022-06-21 22:19:30.117937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert not PyInfo.PY3
    elif PyInfo.PY3:
        assert not PyInfo.PY2
    else:
        assert False

# Generated at 2022-06-21 22:19:35.383492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:19:40.343362
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2 and PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:19:45.028111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    for x in PyInfo.string_types:
        assert isinstance('', x)

    for x in PyInfo.integer_types:
        assert isinstance(0, x)

    for x in PyInfo.class_types:
        assert isinstance(object, x)


# Generated at 2022-06-21 22:19:48.727088
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyInfo = PyInfo()

    assert pyInfo.PY2
    assert not pyInfo.PY3
    assert pyInfo.string_types
    assert pyInfo.text_type
    assert pyInfo.binary_type
    assert pyInfo.integer_types
    assert pyInfo.class_types
    assert pyInfo.maxsize


test_PyInfo()

# Generated at 2022-06-21 22:19:55.610290
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    >>> assert PyInfo.PY2 is not PyInfo.PY3
    >>> from collections import Iterable
    >>> assert isinstance(PyInfo.string_types, Iterable)
    >>> assert isinstance(PyInfo.integer_types, Iterable)
    >>> assert isinstance(PyInfo.class_types, Iterable)
    '''

    pass



# Generated at 2022-06-21 22:20:04.917599
# Unit test for constructor of class PyInfo
def test_PyInfo():
    '''
    Unit test for constructor of class PyInfo
    '''
    test_modules = []

    os.chdir("..")

    with open("requirements.txt", "r") as f:
        for line in f:
            line = line.strip()
            match = re.search("^(.*)==(.*)", line)
            if not match:
                continue
            pkg = match.group(1)
            test_modules.append(pkg)

    test_modules.append("sys")

    for test_module in test_modules:
        mod = __import__(test_module)
        assert mod is not None
        del mod

# Generated at 2022-06-21 22:20:16.019689
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True, 'Py2 or Py3 must be true'

    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(u'bar', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance('', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)


# Generated at 2022-06-21 22:20:25.249893
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance( b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:35.482119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_false
    from nose.tools import assert_true
    from nose.tools import assert_equal

    from nose.plugins.skip import SkipTest

    if PyInfo.PY3:
        raise SkipTest('PY3 test')
    else:
        assert_equal(PyInfo.PY2, True)
        assert_equal(PyInfo.PY3, False)

    if PyInfo.PY2:
        raise SkipTest('PY2 test')
    else:
        assert_equal(PyInfo.PY2, False)
        assert_equal(PyInfo.PY3, True)

    assert_true('str' in PyInfo.string_types)
    assert_true('unicode' in PyInfo.string_types)


# Generated at 2022-06-21 22:20:46.088484
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from tempfile import TemporaryDirectory

    with TemporaryDirectory() as test_dir:
        sys.path.append(test_dir)
        test_module_name = "TestModule"
        test_module_text = "class TestClass:\n\tpass\n"
        test_module_path = os.path.join(test_dir, test_module_name + ".py")

        with open(test_module_path, "w") as f:
            f.write(test_module_text)

        imp.load_source(test_module_name, test_module_path)

        test_module = sys.modules[test_module_name]
        test_class = getattr(test_module, "TestClass")

    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:20:55.537474
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:03.354555
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("s", PyInfo.string_types)
        assert isinstance("s", PyInfo.text_type)
        assert not isinstance("s", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:
        assert isinstance("s", PyInfo.string_types)
        assert isinstance("s", PyInfo.text_type)
        assert not isinstance("s", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)



# Generated at 2022-06-21 22:21:10.281710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == sys.version_info[0] == 2
    assert PyInfo().PY3 == sys.version_info[0] == 3
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert PyInfo().maxsize > 0
    assert isinstance(PyInfo().maxsize, int)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:21:18.143525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.maxsize)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:23.502831
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    getattr(sys, 'maxsize', None) = 2147483647
    getattr(sys, 'maxsize', None) = 9223372036854775807
    """
    assert PyInfo.PY2 or PyInfo.PY3
    maxsize = getattr(sys, 'maxsize', None)
    assert maxsize == PyInfo.maxsize

# Generated at 2022-06-21 22:21:33.633681
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2

    assert isinstance(PyInfo.maxsize, int)

    assert isinstance('a', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'a', PyInfo.string_types)
    else:
        assert not isinstance(b'a', PyInfo.string_types)

    assert isinstance('a', PyInfo.text_type)
    if PyInfo.PY2:
        assert not isinstance(u'a', PyInfo.text_type)
    else:
        assert isinstance(b'a', PyInfo.binary_type)



# Generated at 2022-06-21 22:21:39.683012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    if PyInfo.PY2:
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(3, PyInfo.integer_types)
        assert not isinstance(3.14, PyInfo.integer_types)
    assert PyInfo.maxsize >= (1 << 30)

# Generated at 2022-06-21 22:21:55.637018
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-21 22:22:02.630981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), object)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# ------------------------------------------------------------------------------
# String prefix detection
# ------------------------------------------------------------------------------



# Generated at 2022-06-21 22:22:10.264386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test for PyInfo class
    """
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:22:18.240548
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is False
    assert PyInfo.PY2 is True
    assert PyInfo.maxsize == 9223372036854775807
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.binary_type == str
    assert PyInfo.text_type == unicode
    assert PyInfo.string_types == (basestring,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:24.040975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(types.ClassType, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:22:31.828483
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Python version: {}.{}\n".format(PyInfo.PY3, PyInfo.PY2))
    print("string_types: {}\n".format(PyInfo.string_types))
    print("text_type: {}\n".format(PyInfo.text_type))
    print("binary_type: {}\n".format(PyInfo.binary_type))
    print("integer_types: {}\n".format(PyInfo.integer_types))
    print("class_types: {}\n".format(PyInfo.class_types))
    print("maxsize: {}\n".format(PyInfo.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:34.785221
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance("a", PyInfo.string_types)



# Generated at 2022-06-21 22:22:43.991443
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.string_types)

        assert isinstance(object, PyInfo.class_types)
        assert not isinstance(object(), PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)


# Generated at 2022-06-21 22:22:52.886476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is not PyInfo.PY3

    for item in PyInfo.string_types:
        assert isinstance("", item)

    assert type(PyInfo.text_type()) == PyInfo.text_type

    assert type(PyInfo.binary_type()) == PyInfo.binary_type

    for item in PyInfo.integer_types:
        assert isinstance(1, item)

    for item in PyInfo.class_types:
        assert isinstance(PyInfo, item)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:22:54.133145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-21 22:23:17.410225
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:23:26.334084
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY3 != PyInfo.PY2
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.maxsize) == int


if PyInfo.PY2:
    import __builtin__ as builtins
else:
    import builtins



# Generated at 2022-06-21 22:23:33.306691
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pi = PyInfo()
    >>> pi.PY2, pi.PY3
    (True, False)
    >>> pi.string_types, pi.text_type, pi.binary_type, pi.integer_types, pi.class_types
    (
        (<type 'basestring'>,),
        <type 'unicode'>,
        <type 'str'>,
        (<type 'int'>, <type 'long'>),
        (<type 'type'>, <type 'classobj'>)
    )
    """



# Generated at 2022-06-21 22:23:43.529584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # These should be true in both Python2 and Python3
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # The following type-variable should match the type in runtime.
    # The `in` for checking if type-variables are in the tuples is
    # necessary because I am not sure the tuple would always be ordered.
    if PyInfo.PY3:
        assert str in PyInfo.string_types
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert int in PyInfo.integer_types
        assert type in PyInfo

# Generated at 2022-06-21 22:23:49.302869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:23:55.788558
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    assert info.maxsize > 0
    assert isinstance("", (info.text_type, info.string_types))
    assert isinstance(b"", info.binary_type)
    assert isinstance(1, info.integer_types)
    if info.PY2:
        assert isinstance(1, info.integer_types)
    assert isinstance(object, info.class_types)



# Generated at 2022-06-21 22:24:02.151442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.class_types)
    assert isinstance(PyInfo, PyInfo.class_types)
    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-21 22:24:11.716229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True, \
        "[ERROR] class PyInfo: Either PY2 or PY3 should be True."
    assert isinstance(PyInfo.string_types, tuple) is True, \
        "[ERROR] class PyInfo: string_types should be a tuple."
    assert isinstance(PyInfo.text_type, str) is True, \
        "[ERROR] class PyInfo: text_type should be a str."
    assert isinstance(PyInfo.binary_type, str) is True, \
        "[ERROR] class PyInfo: binary_type should be a str."
    assert isinstance(PyInfo.integer_types, tuple) is True, \
        "[ERROR] class PyInfo: integer_types should be a tuple."



# Generated at 2022-06-21 22:24:19.236139
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-21 22:24:22.820685
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize



# Generated at 2022-06-21 22:25:11.760844
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:25:18.729316
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    # PY2 = sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3

    print(PyInfo.PY2)
    print(PyInfo.PY3)

    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:28.636467
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, integer_types)


try:
    unicode_literals
except NameError:
    unicode_literals = None
else:
    unicode_literals = unicode_literals.__doc__

if unicode_literals is not None:
    unicode_literals = unicode_literals.splitlines()
    assert unicode_literals[0].strip() == "This future statement is required to use unicode literals."
    unicode_literals = unicode_literals[1:]

# Generated at 2022-06-21 22:25:31.769788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Testing class PyInfo...")
    assert PyInfo.PY2 is not PyInfo.PY3

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:37.867960
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # noinspection PyUnresolvedReferences
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(type(object), PyInfo.class_types)


if __name__ == '__main__':
    pytest.main(['-l', __file__])

# Generated at 2022-06-21 22:25:44.749645
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:25:50.508398
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('s', PyInfo.string_types)
    assert isinstance(u'u', PyInfo.string_types)
    assert isinstance(b's', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-21 22:25:55.922999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert type(x.PY2) is bool
    assert type(x.PY3) is bool
    assert type(x.string_types) is tuple
    assert type(x.text_type) is type
    assert type(x.binary_type) is type
    assert type(x.integer_types) is tuple
    assert type(x.maxsize) is int

# Generated at 2022-06-21 22:25:59.860347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("A", PyInfo.string_types)
    assert isinstance(u"A", PyInfo.string_types)
    assert isinstance(b"A", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:26:03.695089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:27:43.595538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


__all__ = ["PyInfo"]

# Generated at 2022-06-21 22:27:44.430707
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

# Generated at 2022-06-21 22:27:48.138623
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(None, PyInfo.class_types)



# Generated at 2022-06-21 22:27:51.314244
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True
    assert pyinfo.PY3 is False
    assert pyinfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:28:01.124605
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


# Unit tests for func maxsize