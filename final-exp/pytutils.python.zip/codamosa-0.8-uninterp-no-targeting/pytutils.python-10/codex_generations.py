

# Generated at 2022-06-21 22:17:58.997810
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY3 == sys.version_info[0] == 3
    assert pyinfo.PY2 == sys.version_info[0] == 2


if __name__ == "__main__":
    import nose

    nose.runmodule()

# Generated at 2022-06-21 22:18:10.254329
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    # PY2
    assert py_info.PY2 == True
    assert py_info.PY3 == False
    assert py_info.string_types == (basestring,)
    assert py_info.text_type == unicode
    assert py_info.integer_types == (int, long)
    assert py_info.class_types == (type, types.ClassType)
    assert py_info.binary_type == str
    # PY3
    py_info = PyInfo()
    assert py_info.PY2 == False
    assert py_info.PY3 == True
    assert py_info.string_types == (str,)
    assert py_info.text_type == str
    assert py_info.integer_types == (int,)
    assert py_info

# Generated at 2022-06-21 22:18:14.561385
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:18:21.093828
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types) is False
    else:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-21 22:18:24.082943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert PyInfo.maxsize > 0


# Small helpers

# Generated at 2022-06-21 22:18:30.613842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)

# Generated at 2022-06-21 22:18:40.872346
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # assert isinstance('', str)
    assert isinstance('', PyInfo.text_type)
    assert isinstance('', PyInfo.string_types)
    # assert isinstance(b'', bytes)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)

    assert PyInfo.string_types == (str,)
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)

    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:18:43.941696
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# ---------------------------
# https://github.com/pallets/werkzeug/blob/master/src/werkzeug/_compat.py
# ---------------------------


# Generated at 2022-06-21 22:18:48.893706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)
    assert sys.maxsize == PyInfo.maxsize

# Generated at 2022-06-21 22:18:55.657807
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:19:07.670736
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert isinstance(u"", PyInfo.text_type)
        assert PyInfo.text_type == unicode
        assert PyInfo.maxsize == sys.maxint
        assert PyInfo.integer_types == (int, long)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.binary_type == bytes
        assert PyInfo.text_type == str
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.integer_types == (int,)
    else:
        raise RuntimeError("bad python version")

# Generated at 2022-06-21 22:19:11.996896
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Py2
    if sys.version_info[0] == 2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert PyInfo.class_types == (type, types.ClassType)
    # Py3
    if sys.version_info[0] == 3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert PyInfo.class_types == type

# Generated at 2022-06-21 22:19:17.739447
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)


# Used for testing

# Generated at 2022-06-21 22:19:26.583320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import operator
    import sys

    assert PyInfo().PY2 or PyInfo().PY3
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

    assert PyInfo().maxsize == sys.maxsize
    assert operator.isSequenceType(PyInfo().string_types)
    assert operator.isSequenceType(PyInfo().integer_types)
    assert operator.isSequenceType(PyInfo().class_types)

    py_info = PyInfo()
    for i in py_info.class_types:
        assert type(py_info.maxsize) == i



# Generated at 2022-06-21 22:19:33.579520
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> x = PyInfo()
    >>> assert x.PY2
    >>> assert not x.PY3
    >>> assert isinstance(x.string_types[0], str)
    >>> assert x.string_types[0] == str
    >>> assert isinstance(x.text_type, str)
    >>> assert isinstance(x.binary_type, str)
    >>> assert x.binary_type == str
    >>> assert isinstance(x.integer_types[0], int)
    >>> assert x.integer_types[0] == int
    >>> assert isinstance(x.class_types[0], type)
    >>> assert x.class_types[0] == type
    >>> assert isinstance(x.maxsize, int)
    >>>
    """



# Generated at 2022-06-21 22:19:34.699671
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-21 22:19:42.243199
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1

    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"b", PyInfo.string_types)
    assert isinstance(u"b".encode("utf-8"), PyInfo.binary_type)
    assert isinstance(u"b".encode("utf-8"), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:19:47.212752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-21 22:19:47.721407
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-21 22:19:53.126372
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    print(py_info.PY2)
    print(py_info.PY3)

    for name in dir(py_info):
        print(name, getattr(py_info, name))



# Generated at 2022-06-21 22:20:02.155619
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else type
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else int
    assert PyInfo.maxsize > 0
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else str
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:14.132829
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.string_types)
        assert not isinstance(b'foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.text_type)
        assert isinstance(b'foo', PyInfo.binary_type)
        assert not isinstance(u'foo', PyInfo.binary_type)
        assert isinstance(True, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:25.028337
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest
    import platform

    class PyInfoTest(unittest.TestCase):
        def test_PY3(self):
            import sys
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

        def test_PY2(self):
            import sys
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 2)

        def test_string_types(self):
            from six import string_types
            self.assertEqual(PyInfo.string_types, string_types)

        def test_text_type(self):
            from six import text_type
            self.assertEqual(PyInfo.text_type, text_type)

        def test_binary_type(self):
            from six import binary_

# Generated at 2022-06-21 22:20:26.353856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x
    print(x)



# Generated at 2022-06-21 22:20:31.278472
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test configuration of PyInfo
    assert PyInfo.PY3 is not PyInfo.PY2


del __builtins__['chr']
del __builtins__['ord']

try:
    cmp
except NameError:
    def cmp(a, b):
        return (a > b) - (a < b)

# Generated at 2022-06-21 22:20:42.040693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type("") is str
        assert type(b"") is bytes
        assert type(0) is int
        assert type(str) is type

        assert isinstance("", str)
        assert isinstance(b"", bytes)
        assert isinstance(0, int)
        assert isinstance(str, type)
    else:  # PY2
        assert type("") is str
        assert type(b"") is str
        assert type(0) is int
        assert type(str) is type

        assert isinstance("", basestring)
        assert isinstance(b"", basestring)
        assert isinstance(0, (int, long))
        assert isinstance(str, (type, types.ClassType))

    assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:20:43.450362
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.maxsize)
    print(isinstance(1, PyInfo.integer_types))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:20:49.005875
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = sys.version_info[0] == 2
    py3 = sys.version_info[0] == 3

    assert PyInfo.PY2 is py2
    assert PyInfo.PY3 is py3

    def get_types(obj):
        types = []
        for k in dir(obj):
            if not k.startswith("_"):
                types.append(getattr(obj, k))
        return types

    if py2:
        expected = PyInfo()
        expected.string_types = (expected.text_type, expected.binary_type)

        assert get_types(PyInfo) == get_types(expected)
    else:
        assert get_types(PyInfo) == get_types(PyInfo())

# Generated at 2022-06-21 22:20:56.831137
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # constructor
    assert PyInfo.PY2
    assert not PyInfo.PY3

    # test string_types
    assert isinstance(str(), PyInfo.string_types)
    assert not isinstance(int(), PyInfo.string_types)

    # test text_type
    assert isinstance(str(), PyInfo.text_type)
    assert not isinstance(int(), PyInfo.text_type)

    # test binary_type
    assert isinstance(str(), PyInfo.binary_type)
    assert not isinstance(int(), PyInfo.binary_type)

    # test integer_types
    assert isinstance(int(), PyInfo.integer_types)
    assert not isinstance(str(), PyInfo.integer_types)

    # test class_types
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-21 22:21:02.203475
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert (str, basestring) == PyInfo.string_types
    assert unicode == PyInfo.text_type
    assert str == PyInfo.binary_type
    assert (int, long) == PyInfo.integer_types
    assert (type, types.ClassType) == PyInfo.class_types
    assert 2147483647 == PyInfo.maxsize

# Generated at 2022-06-21 22:21:19.974534
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-21 22:21:26.131481
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
    else:
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:21:32.724109
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:21:39.972176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(cls, value):
        assert isinstance(value, cls)

    info = PyInfo()
    check(bool, info.PY2)
    check(bool, info.PY3)
    check(tuple, info.string_types)
    check(type, info.text_type)
    check(type, info.binary_type)
    check(tuple, info.integer_types)
    check(tuple, info.class_types)
    check(int, info.maxsize)


# Constructor of class PyInfo
pyinfo = PyInfo()

# Generated at 2022-06-21 22:21:46.533327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Create an object of class PyInfo and asserts its attributes
    """
    from pyinfo import PyInfo
    obj = PyInfo()
    assert obj.PY2 is True
    assert obj.PY3 is False
    assert obj.string_types == (basestring,)
    assert obj.text_type == unicode
    assert obj.binary_type == str
    assert obj.integer_types == (int, long)
    assert obj.class_types == (type, types.ClassType)
    assert obj.maxsize == sys.maxsize



# Generated at 2022-06-21 22:21:51.017830
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> assert PyInfo.PY2 == sys.version_info[0] == 2
    >>> assert PyInfo.PY3 == sys.version_info[0] == 3
    >>> assert PyInfo.maxsize == sys.maxsize
    """



# Generated at 2022-06-21 22:21:56.079493
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is False
    assert pyinfo.PY3 is True
    assert pyinfo.string_types == (str, )
    assert pyinfo.text_type == str
    assert pyinfo.binary_type == bytes
    assert pyinfo.integer_types == (int, )
    assert pyinfo.class_types == (type, )

# Generated at 2022-06-21 22:22:00.924030
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.maxsize)
    print(PyInfo.PY2)
    print(PyInfo.PY3)


# test_PyInfo()

# Generated at 2022-06-21 22:22:08.428262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:12.953092
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # The code above is too complicated to be executed.
    # The code below is just for unit testing.
    py2 = sys.version_info[0] == 2
    assert PyInfo.PY2 is py2
    assert PyInfo.PY3 is not py2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-21 22:22:35.456271
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:39.060441
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()

    assert isinstance(i, object)
    assert i.PY2 or i.PY3
    assert type(i.string_types) is tuple
    assert type(i.text_type) is type
    assert type(i.binary_type) is type
    assert type(i.integer_types) is tuple
    assert type(i.class_types) is tuple or type(i.class_types) is type
    assert type(i.maxsize) is int

# Generated at 2022-06-21 22:22:40.956377
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("python version is {0}".format(sys.version_info[0]))
    # assert PyInfo.PY2 is True


# Generated at 2022-06-21 22:22:45.845873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0



# Generated at 2022-06-21 22:22:56.860303
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (str, unicode) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == str if PyInfo.PY2 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY2 else str
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)

# Generated at 2022-06-21 22:23:07.625215
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)

        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)

        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance('', PyInfo.text_type)

        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-21 22:23:16.876750
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == int((1 << 31) - 1)
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31


# Generated at 2022-06-21 22:23:18.379350
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == 3


# Generated at 2022-06-21 22:23:22.030205
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize < (1 << 63)


test_PyInfo()

# Generated at 2022-06-21 22:23:33.087022
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:24:17.359929
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is str
    assert type(PyInfo.binary_type) is str
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:24:25.668946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance(b"abc", PyInfo.string_types)
        assert not isinstance(u"abc", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1.0, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.text_type)
        assert isinstance(PyInfo, PyInfo.class_types)

    else:
        assert not isinstance("abc", PyInfo.string_types)
        assert isinstance("abc", PyInfo.binary_type)
        assert isinstance

# Generated at 2022-06-21 22:24:32.379163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)



# Generated at 2022-06-21 22:24:42.993915
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, int)
    assert isinstance(PyInfo.PY3, int)
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
    else:
        assert isinstance(PyInfo.string_types, type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


# Generated at 2022-06-21 22:24:50.298616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(name, value):
        assert getattr(PyInfo, name) == value
        assert type(getattr(PyInfo, name)) in (bool, int)

    check("PY2", sys.version_info[0] == 2)
    check("PY3", sys.version_info[0] == 3)
    check("maxsize", (1 << 31) - 1)  # for 32-bit


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:25:00.802176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:25:08.215783
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:25:15.085127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(b"binary", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-21 22:25:26.110290
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert len(PyInfo.string_types) == 1
        assert type("") in PyInfo.string_types
    # Check if it works with long strings
    if not PyInfo.PY3:
        # This is the string used by pepb to define the text_type
        assert type("test") == PyInfo.text_type
    # If it is not a string type, it will always be binary type
    assert type(b"test") == PyInfo.binary_type
    assert type(u"test") == PyInfo.text_type
    # Check one of the integer types
    assert type(1) == PyInfo.integer_types[0]
    # Check class_types
    assert type(1) not in PyInfo.class_types
    assert type(test_PyInfo) in Py

# Generated at 2022-06-21 22:25:35.641119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:27:16.484974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pprint

    test_data = {
        'PY2': PyInfo.PY2,
        'PY3': PyInfo.PY3,
        'string_types': PyInfo.string_types,
        'text_type': PyInfo.text_type,
        'binary_type': PyInfo.binary_type,
        'integer_types': PyInfo.integer_types,
        'class_types': PyInfo.class_types,
        'maxsize': PyInfo.maxsize
    }

    print('Test Data:')
    pprint.pprint(test_data)

    assert test_data['PY2'] ^ test_data['PY3'] is True


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:27:19.773788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "PY2 or PY3 must be specified"
    assert PyInfo.text_type != PyInfo.binary_type, "text_type != binary_type"
    assert isinstance(PyInfo.maxsize, int), "maxsize is of type int"

# Generated at 2022-06-21 22:27:31.868391
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if __debug__:
        import sys

        assert isinstance(PyInfo.PY2, bool)
        assert isinstance(PyInfo.PY3, bool)

        if sys.version_info[0] == 2:
            assert PyInfo.PY2 and not PyInfo.PY3
            assert isinstance(PyInfo.string_types, tuple)
            assert isinstance(PyInfo.text_type, type)
            assert isinstance(PyInfo.binary_type, type)
            assert isinstance(PyInfo.integer_types, tuple)
            assert isinstance(PyInfo.class_types, tuple)
            assert isinstance(PyInfo.maxsize, int) or \
                   isinstance(PyInfo.maxsize, long)
        elif sys.version_info[0] == 3:
            assert not PyInfo.PY

# Generated at 2022-06-21 22:27:40.598690
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:27:41.938326
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

# Generated at 2022-06-21 22:27:44.166078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-21 22:27:49.507549
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:27:59.123273
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(2, PyInfo.integer_types) is True
        assert isinstance(2, PyInfo.class_types) is False
        assert isinstance(PyInfo, PyInfo.class_types) is True
        assert isinstance(PyInfo, PyInfo.integer_types) is False
    else:
        assert isinstance(2, PyInfo.integer_types) is True
        assert isinstance(2, PyInfo.class_types) is False
        assert isinstance(PyInfo, PyInfo.class_types) is True
        assert isinstance(PyInfo, PyInfo.integer_types) is False