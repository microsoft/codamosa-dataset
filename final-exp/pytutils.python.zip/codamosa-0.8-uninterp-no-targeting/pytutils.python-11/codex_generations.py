

# Generated at 2022-06-21 22:18:01.792256
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    print(info.text_type)
    print(info.PY3)
    print(info.PY2)



# Generated at 2022-06-21 22:18:02.797667
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert testinstance(PyInfo)



# Generated at 2022-06-21 22:18:12.435930
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test to check if constructor of class PyInfo work properly or not.
    """
    # Check version 2 of python
    sys.version_info = (2, 7, 5, 'final', 0)
    py2_info = PyInfo()
    assert py2_info.PY2 is True
    assert py2_info.PY3 is False
    assert py2_info.string_types == (basestring,)
    assert py2_info.text_type == unicode
    assert py2_info.binary_type == str
    assert py2_info.integer_types == (int, long)
    assert py2_info.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:18:19.769672
# Unit test for constructor of class PyInfo

# Generated at 2022-06-21 22:18:30.675992
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2 is True:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.integer_types[0], type)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.class_types[0], type)
        assert isinstance(PyInfo.maxsize, int)
    else:  # Py3
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert PyInfo.text_type is str
        assert Py

# Generated at 2022-06-21 22:18:40.583627
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('py2: ', PyInfo.PY2)
    print('py3: ', PyInfo.PY3)
    print('string_types: ', type(PyInfo.string_types))
    print('text_type: ', type(PyInfo.text_type))
    print('binary_type: ', type(PyInfo.binary_type))
    print('integer_types: ', type(PyInfo.integer_types))
    print('class_types: ', type(PyInfo.class_types))
    print('maxsize: ', PyInfo.maxsize)
    print(type(PyInfo.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:18:46.621778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, PyInfo.PY2
    assert PyInfo.PY3, PyInfo.PY3
    assert PyInfo.string_types, PyInfo.string_types
    assert PyInfo.text_type, PyInfo.text_type
    assert PyInfo.binary_type, PyInfo.binary_type
    assert PyInfo.integer_types, PyInfo.integer_types
    assert PyInfo.class_types, PyInfo.class_types
    assert PyInfo.maxsize, PyInfo.maxsize



# Generated at 2022-06-21 22:18:50.758820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert isinstance(b'', PyInfo.binary_type)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert not isinstance(0, PyInfo.string_types)
    assert not isinstance(0, PyInfo.class_types)
    assert isinstance(Object, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:18:56.618553
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-21 22:19:02.710339
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:19:18.024256
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == isinstance(object, (type, types.ClassType))
    assert PyInfo.PY3 == isinstance(object, type)
    assert PyInfo.PY3 == isinstance(string, text_type)
    assert PyInfo.PY2 == isinstance(string, (text_type, binary_type))
    assert PyInfo.PY3 == isinstance(string, binary_type)
    assert PyInfo.PY2 == isinstance(string, string_types)
    assert PyInfo.PY3 == isinstance(string, string_types)
    assert PyInfo.PY3 == isinstance(string, text_type)
    assert PyInfo.PY3 == isinstance(string, binary_type)
    assert PyInfo.PY2 == isinstance(string, integer_types)

# Generated at 2022-06-21 22:19:28.708983
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert hasattr(PyInfo, 'string_types')


# 常见文件类型文字描述

# Generated at 2022-06-21 22:19:32.470845
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert_equal(PyInfo.maxsize, sys.maxint)
    else:
        assert_equal(PyInfo.maxsize, sys.maxsize)


# Determine if the current platform is little endian

# Generated at 2022-06-21 22:19:38.401234
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2: {}".format(PyInfo.PY2))
    print("PY3: {}".format(PyInfo.PY3))
    print("string_types: {}".format(PyInfo.string_types))
    print("text_type: {}".format(PyInfo.text_type))
    print("binary_type: {}".format(PyInfo.binary_type))
    print("integer_types: {}".format(PyInfo.integer_types))
    p

# Generated at 2022-06-21 22:19:42.139562
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        long
    except NameError:
        assert PyInfo.PY3
        assert not PyInfo.PY2
    else:
        assert PyInfo.PY2
        assert not PyInfo.PY3



# Generated at 2022-06-21 22:19:48.019734
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Py2 & Py3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

    # str
    assert "".__class__ == PyInfo.text_type

    # bytes
    assert b"".__class__ == PyInfo.binary_type

    # int

# Generated at 2022-06-21 22:20:00.411596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_PyInfo():
        assert PyInfo.PY2 == sys.version_info[0] == 2
        assert PyInfo.PY3 == sys.version_info[0] == 3

        if PyInfo.PY3:
            assert PyInfo.string_types == (str,)
            assert PyInfo.text_type == str
            assert PyInfo.binary_type == bytes
            assert PyInfo.integer_types == (int,)
            assert PyInfo.class_types == (type,)

            assert PyInfo.maxsize == sys.maxsize
        else:
            assert PyInfo.string_types == (basestring,)
            assert PyInfo.text_type == unicode
            assert PyInfo.binary_type == str
            assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:12.373304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)

    if pyinfo.PY3:
        assert pyinfo.string_types == (str,)
        assert pyinfo.text_type == str
        assert pyinfo.binary_type == bytes
        assert pyinfo.integer_types == (int,)
        assert pyinfo.class_types == (type,)
        assert pyinfo.maxsize == sys.maxsize
    else:
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type == unicode
        assert pyinfo.binary_type == str
        assert pyinfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:18.734336
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert getattr(PyInfo, 'PY{}'.format(sys.version_info[0])) == True
    assert getattr(PyInfo, 'PY{}'.format(sys.version_info[0] + 1)) == False
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:20:28.970999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring, str)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-21 22:20:43.070217
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert not isinstance("a", PyInfo.binary_type)
        assert isinstance(5, PyInfo.integer_types)
        assert isinstance(5, int)
    else:  # PY2
        assert isinstance("a", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert isinstance("a", PyInfo.binary_type)
        assert isinstance(5, int)
        assert isinstance(5, PyInfo.integer_types)


__all__ = ["PyInfo"]

# Generated at 2022-06-21 22:20:50.695608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert PyInfo.PY3 is False
    if PyInfo.PY3:
        assert PyInfo.PY2 is False

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)


# Check if python version is version 2

# Generated at 2022-06-21 22:20:55.736760
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (type, types.ClassType)   # noqa

# Generated at 2022-06-21 22:21:01.567534
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "PY2 or PY3 should be set"
    assert PyInfo.string_types, "string_types should be set"
    assert PyInfo.integer_types, "integer_types should be set"
    assert PyInfo.class_types, "class_types should be set"
    assert PyInfo.maxsize, "maxsize should be set"


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:21:11.973166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None  # Just to test if we can get this
    assert PyInfo.PY2 is not None  # Just to test if we can get this

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:21:18.537817
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-21 22:21:21.724555
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(long(1), PyInfo.integer_types)

# Generated at 2022-06-21 22:21:29.597650
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:21:40.116160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(int(), PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(long(), PyInfo.integer_types)



# Generated at 2022-06-21 22:21:46.168209
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-21 22:22:02.004409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-21 22:22:12.353693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    # string_types
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(object(), PyInfo.string_types)

    # text_type
    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert not isinstance(object(), PyInfo.text_type)

    # binary_type
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance

# Generated at 2022-06-21 22:22:13.959629
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-21 22:22:16.125099
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:22:21.616161
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-21 22:22:26.527317
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert 'string_types' in dir(PyInfo)
    assert 'text_type' in dir(PyInfo)
    assert 'binary_type' in dir(PyInfo)
    assert 'integer_types' in dir(PyInfo)
    assert 'class_types' in dir(PyInfo)
    assert 'maxsize' in dir(PyInfo)



# Generated at 2022-06-21 22:22:32.473684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, list)
    assert PyInfo.text_type in PyInfo.string_types
    assert PyInfo.binary_type in PyInfo.string_types
    assert isinstance(PyInfo.integer_types, list)
    for x in PyInfo.integer_types:
        assert isinstance(x, (int, long))
    assert isinstance(PyInfo.class_types, list)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:22:35.025401
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


"""
from feed.py import PyInfo

test_PyInfo()
"""

# Generated at 2022-06-21 22:22:43.268862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:22:51.316860
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info, PyInfo)

    assert info.PY2 is not info.PY3
    if info.PY2:
        assert isinstance(info.string_types, tuple)
    if info.PY3:
        assert isinstance(info.string_types, str)

    if info.PY2:
        assert isinstance(info.text_type, unicode)
    if info.PY3:
        assert isinstance(info.text_type, str)

    assert isinstance(info.maxsize, int)

# Generated at 2022-06-21 22:23:12.198442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-21 22:23:20.786357
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().PY2, bool)
    assert isinstance(PyInfo().PY3, bool)
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().class_types, tuple)
    if PyInfo().PY2:
        assert isinstance(PyInfo().maxsize, long)
    else:
        assert isinstance(PyInfo().maxsize, int)


# Generated at 2022-06-21 22:23:28.200262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()

    assert pi.PY2 is True or pi.PY2 is False
    assert pi.PY3 is True or pi.PY3 is False
    assert isinstance(pi.string_types, tuple)
    assert isinstance(pi.text_type, type)
    assert isinstance(pi.binary_type, type)
    assert isinstance(pi.integer_types, tuple)
    assert isinstance(pi.class_types, tuple)
    assert isinstance(pi.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-21 22:23:38.468035
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3, \
        "Please make sure PyInfo is correctly initialized."

    if PyInfo.PY2:
        assert not isinstance(u"", PyInfo.binary_type), \
            "Please make sure PyInfo is correctly initialized."
        assert isinstance(u"", PyInfo.string_types), \
            "Please make sure PyInfo is correctly initialized."
    else:  # PyInfo.PY3
        assert isinstance(b"", PyInfo.binary_type), \
            "Please make sure PyInfo is correctly initialized."
        assert isinstance(b"", PyInfo.string_types), \
            "Please make sure PyInfo is correctly initialized."

test_PyInfo()

# Generated at 2022-06-21 22:23:48.976275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("test", PyInfo.string_types)
    assert isinstance(u"test", PyInfo.string_types)
    assert not isinstance(b"test", PyInfo.string_types)

    if PyInfo.PY2:
        assert isinstance("test", PyInfo.text_type)
        assert not isinstance(u"test", PyInfo.text_type)
        assert not isinstance(b"test", PyInfo.text_type)
    else:
        assert not isinstance("test", PyInfo.text_type)
        assert isinstance(u"test", PyInfo.text_type)
        assert not isinstance(b"test", PyInfo.text_type)

    assert isinstance(b"test", PyInfo.binary_type)


# Generated at 2022-06-21 22:23:57.290267
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2 == sys.version_info[0] == 2
    assert x.PY3 == sys.version_info[0] == 3

    if x.PY3:
        assert x.string_types == (str,)
        assert x.text_type == str
        assert x.binary_type == bytes
        assert x.integer_types == (int,)
        assert x.class_types == (type,)
    else:
        assert x.string_types == (basestring,)
        assert x.text_type == unicode
        assert x.binary_type == str
        assert x.integer_types == (int, long)
        assert x.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:24:08.818270
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert PyInfo.PY2 or isinstance(PyInfo.maxsize, int)

    # If a class is passed, PyInfo.is_text_type will return True
    class MyStr(str):
        pass

    assert PyInfo.is_text_type(MyStr())


# Generated at 2022-06-21 22:24:11.056527
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.integer_types
    assert PyInfo.class_types


test_PyInfo()

# Generated at 2022-06-21 22:24:22.330665
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class A(object):
        pass

    class B(A):
        pass

    class C(object):
        pass

    class D(object):
        def __len__(self):
            return 5

    if PyInfo.PY2:
        assert PyInfo.maxsize == sys.maxint
    else:
        assert PyInfo.maxsize == sys.maxsize

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)


# Generated at 2022-06-21 22:24:27.599583
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert not PyInfo.PY3
    assert PyInfo.PY2
    assert PyInfo.text_type == unicode
    assert PyInfo.integer_types == (int, long)



# Generated at 2022-06-21 22:25:10.662409
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    #assert PyInfo.string_types is basestring
    #assert PyInfo.text_type is unicode
    #assert PyInfo.binary_type is str
    #assert PyInfo.integer_types is int, long
    #assert PyInfo.class_types is type, types.ClassType
    assert PyInfo.maxsize is int((1 << 63) - 1)

# Generated at 2022-06-21 22:25:19.692524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == isinstance(2, PyInfo.integer_types)
    assert PyInfo.PY3 == isinstance(2, PyInfo.integer_types)
    assert PyInfo.PY2 == isinstance(u'', PyInfo.text_type)
    assert PyInfo.PY3 == isinstance('', PyInfo.text_type)
    assert PyInfo.PY2 == isinstance('', PyInfo.binary_type)
    assert PyInfo.PY3 == isinstance(b'', PyInfo.binary_type)
    assert PyInfo.PY2 == isinstance(u'', PyInfo.string_types)
    assert PyInfo.PY3 == isinstance('', PyInfo.string_types)
    assert PyInfo.PY2 == isinstance('', PyInfo.string_types)

# Generated at 2022-06-21 22:25:28.955622
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)
    if pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)
    else:  # PY2
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)

# Generated at 2022-06-21 22:25:35.592051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        print(PyInfo.PY3)
        print(PyInfo.PY2)
        print(PyInfo.string_types)
        print(PyInfo.text_type)
        print(PyInfo.binary_type)
        print(PyInfo.integer_types)
        print(PyInfo.class_types)
        print(PyInfo.maxsize)
    except AttributeError as e:
        print(e)

# Generated at 2022-06-21 22:25:42.662921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (str, types.UnicodeType)
    assert PyInfo.text_type == types.UnicodeType
    assert PyInfo.binary_type == types.StringType
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (types.TypeType, types.ClassType)
    if sys.platform.startswith("java"):
        assert PyInfo.maxsize == 2147483647
    else:
        assert PyInfo.maxsize == sys.maxint

# Generated at 2022-06-21 22:25:53.980029
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        for x in ["", b""]:
            assert isinstance(x, PyInfo.string_types)

        for x in [0, 0.0, 0j, [], {}, (), set(), frozenset()]:
            assert not isinstance(x, PyInfo.string_types)

        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types is tuple and int in PyInfo.integer_types
        assert PyInfo.class_types is tuple and type in PyInfo.class_types
        assert PyInfo.maxsize > 0

# Generated at 2022-06-21 22:26:00.800403
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert issubclass(PyInfo.string_types[0], str)

        assert isinstance(PyInfo.text_type, type)
        assert issubclass(PyInfo.text_type, str)

        assert isinstance(PyInfo.binary_type, type)
        assert issubclass(PyInfo.binary_type, bytes)

        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.integer_types[0], type)

# Generated at 2022-06-21 22:26:04.792889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(u'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.string_types)

    if PyInfo.PY3:
        assert isinstance(b"", bytes)
        assert not isinstance(b"", str)
        assert not isinstance(u"", bytes)
        assert isinstance(u"", str)
    else:
        assert isinstance(b"", str)
        assert not isinstance(b"", unicode)
        assert isinstance

# Generated at 2022-06-21 22:26:10.040793
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    ::

        >>> print(PyInfo.string_types)
        (<type 'str'>,)
        >>> print(PyInfo.text_type)
        <type 'str'>
        >>> print(PyInfo.binary_type)
        <type 'str'>
        >>> print(PyInfo.PY3)
        True
        >>> print(PyInfo.PY2)
        False
    """

# Generated at 2022-06-21 22:26:15.427834
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int, )
        assert PyInfo.class_types == (type, )



# Generated at 2022-06-21 22:27:46.899283
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), PyInfo)

# Generated at 2022-06-21 22:27:59.203479
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.__dict__["PY2"] is sys.version_info[0] == 2
    assert PyInfo.__dict__["PY3"] is sys.version_info[0] == 3

    if sys.version_info[0] == 3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # py2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
