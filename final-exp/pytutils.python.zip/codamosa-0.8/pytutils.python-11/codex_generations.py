

# Generated at 2022-06-12 08:09:34.218842
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 != PyInfo.PY3

    # Check that the string_types is a tuple of basestrings
    for _type in PyInfo.string_types:
        assert isinstance('', _type)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:09:40.601059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert str in PyInfo.string_types
    assert unicode not in PyInfo.string_types
    assert isinstance(1.0, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:09:46.186121
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)
    else:
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance(u'abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.string_types)

# Generated at 2022-06-12 08:09:55.540917
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)

# Generated at 2022-06-12 08:10:05.351988
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    assert isinstance(PyInfo.maxsize, int)


try:
    from lxml import etree
except ImportError:
    pass

# Generated at 2022-06-12 08:10:14.267097
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (basestring, str) if PyInfo.PY2 else (str, )
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int, )
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type, )
    assert PyInfo.maxsize == 2147483647 if PyInfo.PY2 else sys.maxsize

# Generated at 2022-06-12 08:10:16.055886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3



# Generated at 2022-06-12 08:10:17.411148
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Generated at 2022-06-12 08:10:23.155903
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize <= sys.maxsize

# Generated at 2022-06-12 08:10:30.202214
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)



# Generated at 2022-06-12 08:10:43.361989
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test PyInfo.PY2
    if not PyInfo.PY2:
        raise AssertionError("PyInfo.PY2 is not correct")

    # test PyInfo.PY3
    if not PyInfo.PY3:
        raise AssertionError("PyInfo.PY3 is not correct")

    # test PyInfo.string_types
    if not isinstance("abc", PyInfo.string_types):
        raise AssertionError("PyInfo.string_types is not correct")

    # test PyInfo.text_type
    if isinstance("abc", PyInfo.text_type):
        raise AssertionError("PyInfo.binary_type is not correct")

    # TODO: test PyInfo.binary_type failed in Py2
    # test PyInfo.binary_type
    # if not isinstance("

# Generated at 2022-06-12 08:10:50.458482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == '__main__':
    import nose

    nose.runmodule()

# Generated at 2022-06-12 08:10:58.280107
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for class PyInfo.
    """
    # Unit: test_construction
    pyinfo = PyInfo()

    # Check the class properties.
    assert pyinfo.PY2 is PyInfo.PY2
    assert pyinfo.PY3 is PyInfo.PY3
    assert pyinfo.string_types is PyInfo.string_types
    assert pyinfo.text_type is PyInfo.text_type
    assert pyinfo.binary_type is PyInfo.binary_type
    assert pyinfo.integer_types is PyInfo.integer_types
    assert pyinfo.maxsize is PyInfo.maxsize


if __name__ == '__main__':
    # Unit test
    test_PyInfo()

# Generated at 2022-06-12 08:11:08.043550
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

        assert isinstance(PyInfo.maxsize, (int, long))
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:11:17.508919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    n = PyInfo()  # create an object of type PyInfo
    # to access the properties of the object Pyinf
    assert n.PY2 == sys.version_info.major == 2
    assert n.PY3 == sys.version_info.major == 3
    assert (
        n.string_types == (basestring,)
        if n.PY2  # equivalent to if sys.version_info.major == 3
        else (str,)
    )
    assert (
        n.text_type == unicode if n.PY2 else str
    )  # equivalent to if sys.version_info.major == 3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:25.386037
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo().string_types == (basestring,)
        assert PyInfo().text_type == unicode
        assert PyInfo().binary_type == str
        assert PyInfo().integer_types == (int, long)
        assert PyInfo().class_types == (type, types.ClassType)
        assert PyInfo().maxsize == int((1 << 31) - 1)
    except:
        print("Test of class PyInfo failed")
        raise
    else:
        print("Test of class PyInfo passed")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:29.543512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3

    assert type(info.string_types) == tuple
    assert type(info.text_type) == str
    assert type(info.binary_type) == str
    assert type(info.integer_types) == tuple
    assert type(info.class_types) == tuple

    assert info.maxsize > 0

# Generated at 2022-06-12 08:11:35.437453
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:11:45.507565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance("", PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance

# Generated at 2022-06-12 08:11:51.241590
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(is_true):
        assert is_true

    # PY2
    check('_sre.SRE_Pattern' in dir(re))

    from cgi import FieldStorage
    # FieldStorage([fp[, headers[, environ[, keep_blank_values[, strict_parsing[, limit]]]]]])
    FieldStorage()


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:01.860236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-12 08:12:09.671974
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test if the class PyInfo is correctly initialized
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.binary_type == str
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert isinstance(PyInfo.maxsize, int)
        assert PyInfo.binary_type == bytes
    else:
        raise

# Generated at 2022-06-12 08:12:13.582123
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(u'abc', PyInfo.text_type)

    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-12 08:12:18.614946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, long)

# Generated at 2022-06-12 08:12:27.685020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(10, PyInfo.integer_types)
        assert not isinstance(10000000000, PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.text_type)


# Generated at 2022-06-12 08:12:35.100925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import nose
    import pdb
    pdb.set_trace()
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    # assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 9223372036854775807

# Generated at 2022-06-12 08:12:41.166496
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2

    import sys
    if sys.version_info.major == 2:
        assert PyInfo.PY2
    elif sys.version_info.major == 3:
        assert PyInfo.PY3
    else:
        raise ValueError(sys.version)


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-12 08:12:49.391465
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo()

    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
    else:
        assert isinstance("", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

    if PyInfo.PY2:
        assert isinstance(unicode, PyInfo.class_types)
    else:
        assert isinstance(str, PyInfo.class_types)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-12 08:12:57.031226
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert issubclass(str, PyInfo.string_types)
        assert isinstance(str(), PyInfo.string_types)
        assert issubclass(bytes, PyInfo.binary_type)
        assert isinstance(bytes(b'abc'), PyInfo.binary_type)
        assert issubclass(int, PyInfo.integer_types)
        assert isinstance(int(1), PyInfo.integer_types)
        assert issubclass(type, PyInfo.class_types)
        assert isinstance(type(str()), PyInfo.class_types)
    else:
        assert issubclass(str, PyInfo.string_types)
        assert issubclass(unicode, PyInfo.string_types)
        assert isinstance(str(), PyInfo.string_types)
        assert isinstance

# Generated at 2022-06-12 08:13:07.364113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("hello", PyInfo.string_types)
    assert not isinstance(b"hello", PyInfo.string_types)
    assert not isinstance(u"hello", PyInfo.string_types)
    assert isinstance(u"hello", PyInfo.text_type)
    assert not isinstance("hello", PyInfo.text_type)
    assert not isinstance(b"hello", PyInfo.text_type)
    assert isinstance(b"hello", PyInfo.binary_type)
    assert not isinstance("hello", PyInfo.binary_type)
    assert not isinstance(u"hello", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:18.180651
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), object)



# Generated at 2022-06-12 08:13:24.500397
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type in (str, unicode)
    assert PyInfo.binary_type in (str, bytes)
    assert PyInfo.string_types in ((str, unicode), (str, bytes))
    assert PyInfo.integer_types in ((int, long), (int,))
    assert PyInfo.class_types in ((type, types.ClassType), (type,))
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:32.198988
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:42.077945
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3  # check for correct assignment of PY2 and PY3

    # For PY3
    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], str)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.integer_types[0], int)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.class_types[0], type)
        assert isinstance(PyInfo.maxsize, int)

    # For PY2

# Generated at 2022-06-12 08:13:51.496892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Testing constructor of class PyInfo...')
    if not PyInfo.PY3:
        import inspect
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert isinstance(type(1), PyInfo.class_types)
    print('OK')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:57.918450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 and not PyInfo.PY3) or (not PyInfo.PY2 and PyInfo.PY3)
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:03.974683
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is str
    assert type(PyInfo.binary_type) is bytes
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:14:05.272547
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo is not None

# Generated at 2022-06-12 08:14:12.401078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo().string_types == (basestring,)
        assert PyInfo().text_type == unicode
        assert PyInfo().binary_type == str
        assert PyInfo().integer_types == (int, long)
        assert PyInfo().class_types == (type, types.ClassType)
    else:  # PY3
        assert PyInfo().string_types == (str,)
        assert PyInfo().text_type == str
        assert PyInfo().binary_type == bytes
        assert PyInfo().integer_types == (int,)
        assert PyInfo().class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:14:17.477842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert hasattr(PyInfo, 'string_types')
    assert hasattr(PyInfo, 'text_type')
    assert hasattr(PyInfo, 'binary_type')
    assert hasattr(PyInfo, 'integer_types')
    assert hasattr(PyInfo, 'class_types')
    assert hasattr(PyInfo, 'maxsize')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:38.935747
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    if p.PY2:
        assert type(p.string_types[0]) == str
    if p.PY3:
        assert type(p.string_types[0]) == str



# Generated at 2022-06-12 08:14:47.561033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2 == (sys.version_info[0] == 2)
    assert x.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 2:
        assert x.string_types == (basestring,)
        assert x.text_type == unicode
        assert x.binary_type == str
        assert x.integer_types == (int, long)
        assert (x.class_types == (type, types.ClassType)
                or x.class_types == (type,))
    else:
        assert x.string_types == (str,)
        assert x.text_type == str
        assert x.binary_type == bytes
        assert x.integer_types == (int,)

# Generated at 2022-06-12 08:14:50.619768
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert isinstance('a', PyInfo.binary_type) is True
        assert isinstance(1, PyInfo.integer_types) is True
    elif PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types) is True

# Generated at 2022-06-12 08:14:51.764399
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False



# Generated at 2022-06-12 08:15:00.754168
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def check(name, expected):
        assert getattr(PyInfo, name) is expected, name

    check('PY2', sys.version_info[0] == 2)
    check('PY3', sys.version_info[0] == 3)
    check('string_types', (str,) if PyInfo.PY3 else (basestring,))
    check('text_type', str if PyInfo.PY3 else unicode)
    check('binary_type', bytes if PyInfo.PY3 else str)
    check('integer_types', int if PyInfo.PY3 else (int, long))
    check('class_types', type if PyInfo.PY3 else (type, types.ClassType))


# Generated at 2022-06-12 08:15:04.583014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 != PyInfo.PY3

# Generated at 2022-06-12 08:15:07.489386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3

    import platform

    if platform.system() == "Windows":
        assert isinstance(1 << 63, int)
    else:
        assert isinstance(1 << 63, long)

# Generated at 2022-06-12 08:15:09.760390
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:15:14.388310
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.maxsize >= ((1 << 31) - 1)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)


# Unit test this module
if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:15:21.371405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(u'abc', PyInfo.string_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance(b'abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance('abc', PyInfo.binary_type)
        assert not isinstance(b'abc', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:16:19.189666
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:  # PY3
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types[0] == int
        assert PyInfo.class_types[0] == type



# Generated at 2022-06-12 08:16:27.493927
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance(PyInfo.PY2, bool)
    isinstance(PyInfo.PY3, bool)

    isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], string_types)

    isinstance(PyInfo.text_type, text_type)
    isinstance(PyInfo.binary_type, binary_type)

    isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], integer_types)

    isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], class_types)

    isinstance(PyInfo.maxsize, integer_types)

# Generated at 2022-06-12 08:16:36.210553
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)

        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)

        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance('', PyInfo.binary_type)

        assert isinstance(100, PyInfo.integer_types)
        assert isinstance(100, PyInfo.integer_types)

        assert isinstance(object, PyInfo.class_types)

    else:
        assert isinstance

# Generated at 2022-06-12 08:16:43.690826
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert py.builtin.callable(PyInfo.class_types)
    assert py.builtin.callable(PyInfo.integer_types)
    assert py.builtin.callable(PyInfo.string_types)
    assert py.builtin.callable(PyInfo.binary_type)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:16:48.833835
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:16:54.630877
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)

    assert not isinstance('a', PyInfo.binary_type)
    assert isinstance(b'a', PyInfo.binary_type)

    assert not isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    assert PyInfo.maxsize > 0

# Generated at 2022-06-12 08:16:58.995674
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
    else:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:17:01.601727
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("\n")
    print("Py2: %s" % PyInfo.PY2)
    print("PY3: %s" % PyInfo.PY3)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:17:02.722009
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True



# Generated at 2022-06-12 08:17:05.920615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY3:
        assert info.string_types == (str,)
        assert info.maxsize == sys.maxsize
    else:
        assert info.string_types == (basestring,)
        assert info.maxsize == (1 << 31) - 1

# Generated at 2022-06-12 08:19:10.370259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from six import assertRegex  # @UnresolvedImport

    if PyInfo.PY2:
        # for python 2.7
        assert type(PyInfo.string_types) == tuple
        assert type(PyInfo.text_type) == type(PyInfo.string_types[0])
        assert type(PyInfo.binary_type) == bytes
        assert type(PyInfo.integer_types) == tuple
        assert type(PyInfo.class_types) == tuple

    else:
        # for python 3.4
        assert type(PyInfo.string_types) == tuple
        assert type(PyInfo.text_type) == type(PyInfo.string_types[0])
        assert type(PyInfo.binary_type) == bytes
        assert type(PyInfo.integer_types) == tuple

# Generated at 2022-06-12 08:19:17.182506
# Unit test for constructor of class PyInfo
def test_PyInfo():
    o = PyInfo()

    assert isinstance(o.PY2, bool)
    assert isinstance(o.PY3, bool)

    assert isinstance(o.string_types, tuple)
    assert isinstance(o.text_type, type)
    assert isinstance(o.binary_type, type)
    assert isinstance(o.integer_types, tuple)
    assert isinstance(o.class_types, tuple)

    assert isinstance(o.maxsize, int)


py = PyInfo()

# Generated at 2022-06-12 08:19:18.717578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> info = PyInfo()
    >>> assert isinstance(info, object)
    """
    pass



# Generated at 2022-06-12 08:19:24.508796
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes

    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-12 08:19:30.151126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)