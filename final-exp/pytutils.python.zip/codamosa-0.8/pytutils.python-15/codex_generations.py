

# Generated at 2022-06-12 08:09:38.110414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)

    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:09:42.899962
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2
    assert not PyInfo().PY3
    assert PyInfo().string_types == (basestring,)
    assert PyInfo().text_type == unicode
    assert PyInfo().binary_type == str
    assert PyInfo().integer_types == (int, long)

    assert str(PyInfo().maxsize) == '9223372036854775807'

# Generated at 2022-06-12 08:09:44.327090
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


# test string types

# Generated at 2022-06-12 08:09:53.129885
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert getattr(PyInfo, 'string_types', NotImplemented) != NotImplemented
    assert getattr(PyInfo, 'text_type', NotImplemented) != NotImplemented
    assert getattr(PyInfo, 'binary_type', NotImplemented) != NotImplemented
    assert getattr(PyInfo, 'integer_types', NotImplemented) != NotImplemented
    assert getattr(PyInfo, 'class_types', NotImplemented) != NotImplemented
    assert getattr(PyInfo, 'maxsize', NotImplemented) != NotImplemented


# Default value of maxsize
MAXSIZE = 2147483647

# Generated at 2022-06-12 08:09:54.952279
# Unit test for constructor of class PyInfo
def test_PyInfo():  # noqa

    class PyInfoSubclass(PyInfo):
        pass

    # Check that subclassing is possible
    assert PyInfoSubclass()

# Generated at 2022-06-12 08:10:02.655341
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, basestring) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (
        type,)

    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-12 08:10:07.968318
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(classmethod, PyInfo.class_types)
    assert isinstance(classmethod(lambda: None), PyInfo.class_types)



# Generated at 2022-06-12 08:10:15.880082
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    False
    >>> PyInfo.PY3
    True
    >>> isinstance('', PyInfo.string_types)
    True
    >>> isinstance('', PyInfo.text_type)
    True
    >>> isinstance(b'', PyInfo.binary_type)
    True
    >>> isinstance(1, PyInfo.integer_types)
    True
    >>> isinstance(int, PyInfo.class_types)
    True
    >>> PyInfo.maxsize > 1 << 30
    True
    """
    pass



# Generated at 2022-06-12 08:10:25.145033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for class PyInfo"""
    # test version number
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert PyInfo.PY2 in [2, "2"]
    assert PyInfo.PY3 in [3, "3"]

    if PyInfo.PY2:
        pyv = 2
    else:
        pyv = 3

    # type tests
    assert isinstance(2, PyInfo.integer_types)
    if pyv == 2:
        assert isinstance(2, PyInfo.integer_types)
    else:
        assert not isinstanve(2, PyInfo.integer_types)
    assert isinstance("2", PyInfo.string_types)


# Generated at 2022-06-12 08:10:32.560589
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types[0], str)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types[0], int)
    assert isinstance(PyInfo.class_types[0], type)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert isinstance(PyInfo.maxsize, (int, long))

# Generated at 2022-06-12 08:10:40.342658
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("-----test_PyInfo()-----")
    print("PY2:", PyInfo.PY2)
    print("PY3:", PyInfo.PY3)
    print("string_types:", PyInfo.string_types)
    print("text_type:", PyInfo.text_type)
    print("binary_type:", PyInfo.binary_type)
    print("integer_types:", PyInfo.integer_types)
    print("class_types:", PyInfo.class_types)
    print("maxsize:", PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:48.508113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    inf = PyInfo()
    assert inf.PY2 == (sys.version_info[0] == 2)
    assert inf.PY3 == (sys.version_info[0] == 3)
    if inf.PY3:
        assert isinstance('', inf.string_types)
        assert not isinstance(b'', inf.string_types)
        assert not isinstance(u'', inf.string_types)
        assert isinstance('', inf.text_type)
        assert not isinstance(b'', inf.text_type)
        assert not isinstance(u'', inf.text_type)
        assert not isinstance('', inf.binary_type)
        assert isinstance(b'', inf.binary_type)
        assert not isinstance(u'', inf.binary_type)

# Generated at 2022-06-12 08:10:56.851980
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not False
    assert PyInfo.PY3 is not False

    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (str, unicode)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (type, types.ClassType)

    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:05.708142
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-12 08:11:16.229300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2 if PyInfo.PY2 else 1
    assert len(PyInfo.class_types) == 2 if PyInfo.PY2 else 1
    assert PyInfo.text_type is PyInfo.string_types[0]
    assert PyInfo.binary_type is not PyInfo.string_types[0]

    if PyInfo.PY2:
        assert type(PyInfo.text_type(u'')) is unicode
        assert type(PyInfo.binary_type(b'')) is str
    elif PyInfo.PY3:
        assert type(PyInfo.text_type(u'')) is str

# Generated at 2022-06-12 08:11:26.525565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("str", PyInfo.string_types)
        assert isinstance("str", PyInfo.text_type)
        assert not isinstance("str", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    elif PyInfo.PY2:
        assert isinstance("str", PyInfo.string_types)
        assert isinstance("str", PyInfo.text_type)
        assert isinstance("str", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
    else:
        assert False, "unexpected Python version"

# Generated at 2022-06-12 08:11:29.577808
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in ['PY2', 'PY3', 'string_types', 'text_type', 'binary_type',
                 'integer_types', 'class_types', 'maxsize']:
        assert hasattr(PyInfo, attr), "%s is missing" % attr

# Generated at 2022-06-12 08:11:31.868383
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is PY2
    assert PyInfo.PY3 is PY3
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:11:33.208487
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:11:36.567020
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:11:49.100565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PyInfo.PY3
    PyInfo.PY2
    isinstance('a', PyInfo.string_types)
    isinstance(u'a', PyInfo.string_types)
    PyInfo.text_type == bytes
    PyInfo.text_type == unicode
    PyInfo.binary_type
    PyInfo.class_types


try:
    from importlib import import_module
except ImportError:
    def import_module(module_name, package=None):
        module = __import__(module_name, fromlist=package)
        if package:
            module = getattr(module, package)
        return module



# Generated at 2022-06-12 08:11:57.660176
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:05.789494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True)

# Generated at 2022-06-12 08:12:17.108376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert not isinstance(None, PyInfo.string_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert not isinstance(None, PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(None, PyInfo.integer_types)

    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance

# Generated at 2022-06-12 08:12:26.861388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo, type)

    @pytest.mark.skipif(PyInfo.PY2, reason="The test does not run on PY2")
    def test_PY2():
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.string_types[0], type)
        assert issubclass(PyInfo.string_types[0], object)
        assert PyInfo.string_types[0].__module__ == "builtins"

        assert isinstance(PyInfo.text_type, type)
        assert issubclass(PyInfo.text_type, object)
        assert PyInfo.text_type.__module__ == "builtins"

        assert isinstance(PyInfo.binary_type, type)
        assert issubclass(PyInfo.binary_type, object)

# Generated at 2022-06-12 08:12:32.862769
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance("abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-12 08:12:38.158008
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    PyInfo() is a class to check the Python's version
    """
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance('abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:49.024145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from intent.utils.const import PyInfo
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2 or PyInfo.PY3
    assert (PyInfo.string_types == (str,)) or (PyInfo.string_types == (basestring,))
    assert (PyInfo.text_type == str) or (PyInfo.text_type == unicode)
    assert (PyInfo.binary_type == bytes) or (PyInfo.binary_type == str)
    assert (PyInfo.integer_types == (int, long)) or (PyInfo.integer_types == (int,))
    assert (PyInfo.class_types == (type, types.ClassType)) or (PyInfo.class_types == (type,))

# Generated at 2022-06-12 08:12:56.814436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)

        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)

        assert isinstance(100, PyInfo.integer_types)
        assert isinstance(100, int)
        assert isinstance(100, long)

    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)

        assert isinstance(b"", PyInfo.string_types)

# Generated at 2022-06-12 08:13:07.089998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    assert isinstance(PyInfo.maxsize, int)
    assert len(str(PyInfo.maxsize)) > 0

    assert isinstance(PyInfo.string_types[0], type)
    assert len(PyInfo.string_types) == 1

    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types[0], type)
    assert len(PyInfo.integer_types) == 2

    assert isinstance(PyInfo.class_types[0], type)
    if PyInfo.PY2:
        assert len(PyInfo.class_types) == 2

# Generated at 2022-06-12 08:13:19.475383
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:13:25.205543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
    else:
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)


# Generated at 2022-06-12 08:13:30.546864
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-12 08:13:41.220230
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('test', PyInfo.string_types)
    assert isinstance(u'test', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:51.267178
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-12 08:13:54.783848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_not_equal(a, b):
        assert a != b

    assert_not_equal(sys.version_info[0], 3)
    assert_not_equal(sys.platform.startswith("java"), True)

# Generated at 2022-06-12 08:13:57.901078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for PyInfo class"""
    pi = PyInfo()
    assert pi.maxsize > 0
    assert pi.string_types
    assert pi.text_type
    assert pi.binary_type
    assert pi.integer_types
    assert pi.class_types

# Generated at 2022-06-12 08:14:07.309669
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # test string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(b'', PyInfo.string_types)
    else:
        assert not isinstance(b'', PyInfo.string_types)

    # test text_type
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type)
    if PyInfo.PY2:
        assert not isinstance(b'', PyInfo.text_type)
    else:
        assert not isinstance(b'', PyInfo.text_type)

    # test binary_type

# Generated at 2022-06-12 08:14:08.537612
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)

# Generated at 2022-06-12 08:14:13.780970
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:14:42.068597
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.text

# Generated at 2022-06-12 08:14:49.583145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not (PyInfo.PY2 or PyInfo.PY3):
        raise ValueError(
            "PyInfo.PY2 and PyInfo.PY3 should NOT be both False")

    if PyInfo.PY2:
        if PyInfo.PY3:
            raise ValueError("PyInfo.PY2 and PyInfo.PY3 should NOT be both True")
    else:
        if not PyInfo.PY3:
            raise ValueError("PyInfo.PY3 should be True")

    if type(PyInfo.string_types) != tuple:
        raise ValueError("type(PyInfo.string_types) should be tuple")

    if type(PyInfo.integer_types) != tuple:
        raise ValueError("type(PyInfo.integer_types) should be tuple")


# Generated at 2022-06-12 08:14:51.292180
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.text_type == str or PyInfo.text_type == unicode



# Generated at 2022-06-12 08:14:57.243581
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    if sys.version_info[0] == 3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:15:07.182453
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:15:16.026617
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance('', PyInfo.text_type)
    assert not isinstance(u'', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:22.958742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0](), basestring)
    assert isinstance(PyInfo.text_type(), unicode)
    assert isinstance(PyInfo.binary_type(), str)
    assert isinstance(PyInfo.integer_types[0](), int)
    assert isinstance(PyInfo.class_types[0](), type)
    assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-12 08:15:31.501798
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check that the class PyInfo is instantiable but it's not supposed to
    # instantiate the object for the class PyInfo.
    try:
        PyInfo()
    except TypeError as e:
        assert "object() takes no parameters" in str(e), e

    # Every attribute of the class is supposed to be read-only
    try:
        PyInfo.PY2 = False
    except AttributeError as e:
        assert "can't set attribute" in str(e), e

    try:
        PyInfo.PY3 = False
    except AttributeError as e:
        assert "can't set attribute" in str(e), e

    try:
        PyInfo.string_types = False
    except AttributeError as e:
        assert "can't set attribute" in str(e), e


# Generated at 2022-06-12 08:15:34.322392
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:15:36.452076
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # if (p._PY3):
    #     print("Python 3")
    # else:
    #     print("Python 2")

    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize > 2**32 - 1
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:16:29.015933
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import six
    assert isinstance(PyInfo.PY2, type(True))
    assert isinstance(PyInfo.PY3, type(True))
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, six.string_types)
    assert isinstance(PyInfo.binary_type, six.string_types)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    return

# Generated at 2022-06-12 08:16:36.965051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Make sure each property is defined, and that its value
    # is truthy (non-None, non-zero, non-empty).
    assert isinstance(PyInfo.PY2, bool)
    assert PyInfo.PY2
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize

    # Each property must be a tuple or other sequence type.
    assert isinstance(PyInfo.string_types, (tuple, list, set, frozenset))
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, (tuple, list, set, frozenset))

# Generated at 2022-06-12 08:16:43.821830
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class UnitTest(unittest.TestCase):
        def test_PyInfo_PY3(self):
            self.assertEqual(
                PyInfo.PY3, sys.version_info[0] == 3,
                "PyInfo.PY2 is not set correctly"
            )

        def test_PyInfo_PY2(self):
            self.assertEqual(
                PyInfo.PY2, sys.version_info[0] == 2,
                "PyInfo.PY2 is not set correctly"
            )

        def test_PyInfo_string_types(self):
            if sys.version_info[0] == 3:
                self.assertEqual(
                    PyInfo.string_types, (str,),
                    "PyInfo.string_types is not set correctly"
                )

# Generated at 2022-06-12 08:16:50.847373
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert isinstance("abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance("abc", PyInfo.binary_type)
        assert not isinstance(b"abc", PyInfo.text_type)

        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1.0, PyInfo.integer_types)
        assert not isinstance(True, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:16:58.961359
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = sys.version_info[0] == 2
    # PY3 = sys.version_info[0] == 3
    assert PyInfo().PY3 == (3 == sys.version_info[0])
    assert PyInfo().PY2 == (2 == sys.version_info[0])

    # binary_type = bytes
    assert PyInfo().binary_type is bytes
    # string_types = basestring,
    assert (str, bytes) == tuple(PyInfo().string_types)
    assert PyInfo().text_type == str
    # integer_types = (int, long)
    assert (int, long) == tuple(PyInfo().integer_types)
    assert (type, types.ClassType) == tuple(PyInfo().class_types)
    # maxsize = sys.maxsize
    assert Py

# Generated at 2022-06-12 08:17:04.246607
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(u"abc", PyInfo.text_type)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:17:12.549428
# Unit test for constructor of class PyInfo
def test_PyInfo():  # pragma: no cover
    """Unit test for constructor of class PyInfo."""
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert pyinfo.string_types == (str,) or pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == str or pyinfo.text_type == unicode
    assert pyinfo.binary_type == bytes or pyinfo.binary_type == str
    assert pyinfo.integer_types == (int,) or pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type,) or pyinfo.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:17:18.571889
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert not isinstance(b'a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-12 08:17:21.107721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    sys.exit(pytest.main(sys.argv))

# Generated at 2022-06-12 08:17:26.955317
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)
    assert isinstance(b'bytes', PyInfo.string_types)
    assert isinstance('str', PyInfo.text_type)
    assert isinstance(b'bytes', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, int)
    assert isinstance(0, long)

if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:19:19.937285
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    from bs_common.py_info import PyInfo

    assert sys.version_info[0] == PyInfo.PY2 or sys.version_info[
        0] == PyInfo.PY3


if __name__ == '__main__':
    import os
    import bs_common.py_info

    print(os.path.dirname(bs_common.py_info.__file__))

# Generated at 2022-06-12 08:19:22.940560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int


test_PyInfo()

# Generated at 2022-06-12 08:19:30.505051
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

