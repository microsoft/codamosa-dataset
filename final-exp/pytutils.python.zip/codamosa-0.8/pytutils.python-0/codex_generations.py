

# Generated at 2022-06-12 08:09:39.106093
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)


# Use this class instead of 'str'
_str = PyInfo.string_types[0]


# noinspection PyPep8Naming

# Generated at 2022-06-12 08:09:40.963263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 2
    assert PyInfo.PY3 == 3



# Generated at 2022-06-12 08:09:48.653163
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)
    assert not isinstance(0, PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(0, PyInfo.text_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(0, PyInfo.string_types)

    assert isinstance(10, PyInfo.integer_types)
    assert not isinstance(10.1, PyInfo.integer_types)


# Generated at 2022-06-12 08:09:54.283247
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types is (str, unicode)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types is (int, long)
    assert PyInfo.class_types is (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:09:58.532935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize <= 2 ** 31 - 1
    assert PyInfo.maxsize >= 2 ** 63 - 1

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize != sys.maxsize

# Generated at 2022-06-12 08:10:01.470164
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert pyinfo.PY3 is not True or pyinfo.PY3 is True

# Generated at 2022-06-12 08:10:06.732158
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class py2object(object):
        pass
    pass
    if PyInfo.PY2:
        assert (type(py2object()) == types.InstanceType)
        assert (type(py2object) == types.ClassType)
        assert (type(1) == types.IntType)
    else:
        assert (type(py2object()) == object)
        assert (type(py2object) == type)
        assert (type(1) == int)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:07.339892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-12 08:10:18.316984
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import numpy as np
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert not PyInfo.PY3
        assert np.__version__ == "1.7.1"
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
    else:
        assert PyInfo.PY3
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert not isinstance(np.array(()), PyInfo.binary_type)
        assert isinstance(np.array(()), PyInfo.class_types)
    assert isinstance(np.array((1, 2, 3)), PyInfo.class_types)

# Generated at 2022-06-12 08:10:26.568734
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
    else:  # PyInfo.PY3
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(100000000000, PyInfo.integer_types)
    # In PyInfo.PY

# Generated at 2022-06-12 08:10:37.765323
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Enforce Py2, Py3
    Py2 = PyInfo.PY2
    Py3 = PyInfo.PY3
    # Use Python2 to run unit test
    if Py2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.maxsize == sys.maxsize
    # Use Python3 to run unit test
    else:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True

# Generated at 2022-06-12 08:10:42.913440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str,)
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    import pytest

    pytest.main([__file__, "-v", "-s"])

# Generated at 2022-06-12 08:10:53.823600
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check compatibility to python 2 and 3
    assert (PyInfo.PY2 == True or PyInfo.PY3 == True)
    # check the string types
    assert (isinstance("some text", PyInfo.string_types) == True)
    assert (isinstance(u"some text", PyInfo.string_types) == True)
    # check the default string type
    assert (isinstance("some text", PyInfo.text_type) == True)
    assert (isinstance(u"some text", PyInfo.text_type) == False)
    # check the binary type
    assert (isinstance("some text", PyInfo.binary_type) == True)
    assert (isinstance(b"some text", PyInfo.binary_type) == True)
    # check integer types

# Generated at 2022-06-12 08:10:57.417869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:10:59.767482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3



# Generated at 2022-06-12 08:11:09.120543
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(u"a", PyInfo.binary_type)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

    # Test for PyInfo.maxsize

# Generated at 2022-06-12 08:11:19.942770
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import types
    import sys

    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (basestring, )
    assert isinstance(PyInfo.text_type, type)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert isinstance(PyInfo.binary_type, type)
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert isinstance(PyInfo.integer_types, tuple)
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-12 08:11:23.019275
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    pytest.raises(TypeError, PyInfo)


if __name__ == '__main__':
    import pytest

    test_PyInfo()
    pytest.main([__file__])

# Generated at 2022-06-12 08:11:31.079603
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('123') in PyInfo.string_types
        assert type(b'123') not in PyInfo.string_types
        assert type(u'123') not in PyInfo.string_types

        assert type('123') is not PyInfo.text_type
        assert type(u'123') is PyInfo.text_type

        assert type('123') is PyInfo.binary_type
        assert type(b'123') is not PyInfo.binary_type

    if PyInfo.PY3:
        assert type('123') in PyInfo.string_types
        assert type(b'123') not in PyInfo.string_types
        assert type(u'123') not in PyInfo.string_types

        assert type('123') is PyInfo.text_type

# Generated at 2022-06-12 08:11:32.408792
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:44.579232
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:11:51.018849
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> print(PyInfo.PY2, PyInfo.PY3, PyInfo.string_types, PyInfo.text_type,
    ... PyInfo.binary_type, PyInfo.integer_types, PyInfo.class_types)
    True False (<class 'str'>,) <class 'str'> <class 'bytes'> (<class 'int'>,)
    (<class 'type'>,)
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:11:58.640797
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # noinspection PyUnresolvedReferences
    assert PyInfo.PY2
    # noinspection PyUnresolvedReferences
    assert not PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    # Test for class "PyInfo"
    for var_name in vars(PyInfo):
        # noinspection PyUnresolvedReferences
        var_value = getattr(PyInfo, var_name, None)
        if var_name in ('PY2', 'PY3'):
            assert isinstance(var_value, bool)
       

# Generated at 2022-06-12 08:12:07.148262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] is basestring
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert len(PyInfo.integer_types) == 2
    assert PyInfo.integer_types[0] is int
    assert PyInfo.integer_types[1] is long
    assert len(PyInfo.class_types) == 2
    assert PyInfo.class_types[0] is type
    assert PyInfo.class_types[1] is types.ClassType
    assert not PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:12:17.674772
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif sys.version_info[0] == 3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert Py

# Generated at 2022-06-12 08:12:18.985114
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# Unit test to check docstring of class PyInfo

# Generated at 2022-06-12 08:12:27.285102
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True or PyInfo.PY3 == True) and \
           (PyInfo.PY2 == False or PyInfo.PY3 == False)
    assert PyInfo.PY2 != PyInfo.PY3
    assert all([isinstance(x, PyInfo.string_types) for x in list('abc')])
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    if PyInfo.PY2:
        assert isinstance(lambda : True, PyInfo.class_types)
    assert PyInfo.maxsize >= (1 << 63) - 1

# Generated at 2022-06-12 08:12:33.761078
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)

    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)

    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:40.854455
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (str, unicode)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (type, types.ClassType)
    assert isinstance(PyInfo.maxsize, int)

test_PyInfo()

# Generated at 2022-06-12 08:12:52.092650
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert(info.PY2 or info.PY3)


try:
    import wx
    import wx.html
    import wx.lib.wxcairo
    haveWxPython = True
except Exception:
    haveWxPython = False

try:
    import pygtk
    pygtk.require('2.0')
    import gobject
    import cairo
    import pangocairo
    import gtk
    import gtk.glade
    haveGtkPython = True
except Exception:
    haveGtkPython = False

try:
    import matplotlib
    haveMplPython = True
except Exception:
    haveMplPython = False

# Construct the multiprocessing pool with specified number of cores

# Generated at 2022-06-12 08:13:10.595737
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:13:14.397650
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("test", PyInfo.string_types)
        assert isinstance(u"test", PyInfo.string_types)
    else:
        assert not isinstance("test", PyInfo.string_types)
        assert isinstance("test", PyInfo.string_types)



# Generated at 2022-06-12 08:13:19.830389
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:13:29.636694
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("maxsize={}".format(PyInfo.maxsize))
    print("string_types={}".format(PyInfo.string_types))
    print("type(bin_string)={}".format(type("bin_string")))
    print("type(u_string)=[{}]".format(type(u"u_string")))
    print("type(123)=[{}]".format(type(123)))
    print("type(long(123))=[{}]".format(type(long(123))))
    print("PyInfo.integer_types={}".format(PyInfo.integer_types))
    print("type(lambda x: x)={}".format(type(lambda x: x)))
    print("type(None)={}".format(type(None)))

# Generated at 2022-06-12 08:13:33.978429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, 'Python 2 is not detected.'
    assert PyInfo.PY3, 'Python 3 is not detected.'


# Reference: http://stackoverflow.com/a/14692747/2188572

# Generated at 2022-06-12 08:13:42.928774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_info(info):
        assert info
        assert 'PY%d' % sys.version_info[0] == info
        assert info in ('PY2', 'PY3')
        assert info.startswith('PY')
        assert info.endswith('2') or info.endswith('3')

    def assert_types(types):
        assert types
        assert types == (str,) or types == (str, unicode)

    def assert_type(type):
        assert type
        assert type == bytes or type == str or type == unicode

    def assert_integer_types(types):
        assert types
        assert types == (int,) or types == (int, long)

    def assert_maxsize(size):
        assert size
        assert size == 2147483647 or size == 92233720

# Generated at 2022-06-12 08:13:44.343774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:13:50.282055
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-12 08:13:52.963388
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 08:13:55.025231
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:14:23.406396
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize
    if PyInfo.PY2:
        assert isinstance(str(), PyInfo.text_type)
        # assert isinstance(basestring(), PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(100, PyInfo.integer_types)
        assert isinstance(True, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:28.710962
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert sys.version_info[0] == 2
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:32.051976
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 or info.PY3
    assert type(info.string_types) == tuple
    assert type(info.integer_types) == tuple
    assert type(info.maxsize) == int
    assert type(info.text_type('test')) == str
    assert type(info.binary_type(b'test')) == bytes

# Generated at 2022-06-12 08:14:37.535858
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:14:42.651294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    if info.PY2:
        assert sys.version_info[0] == 2
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)
        assert info.maxsize < 9223372036854775807
    else:  # PY2
        assert sys.version_info[0] == 3
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)
        assert info.maxsize < 922

# Generated at 2022-06-12 08:14:46.550710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Test for PyInfo
    """
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    if not PyInfo.PY3:
        assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-12 08:14:48.866347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:14:57.138140
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:15:07.059262
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.binary_type == bytes or PyInfo.binary_type == (str,)
    assert PyInfo.string_types == str or PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == str or PyInfo.text_type == unicode
    assert (
        PyInfo.integer_types == (int,)
        or PyInfo.integer_types == (int, long)
        or PyInfo.integer_types == (int, long)
    )
    assert PyInfo.class_types == (type, type) or PyInfo.class_types == (
        type,
        types.ClassType,
    )
    assert type(PyInfo.maxsize) == int



# Generated at 2022-06-12 08:15:15.910162
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:16:15.335668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY3 or not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert len(PyInfo.string_types) == 2
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:18.514975
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.binary_type == str
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:25.438297
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(list, PyInfo.class_types)
    assert (1 << 63) - 1 == PyInfo.maxsize

    print("PASS!")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:16:29.713677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()

    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)


if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-12 08:16:31.304763
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3 is False
    # assert False

# Generated at 2022-06-12 08:16:32.823521
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isinstance("", PyInfo.string_types)
    isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:36.810431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance("abc", PyInfo.string_types)
    assert isinstance(b"abc", PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:16:42.449657
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert isinstance(b"bytes", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:48.801324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check type
    print(type(PyInfo.PY2))
    print(type(PyInfo.PY3))

    # Check type
    print(type(PyInfo.string_types))
    print(type(PyInfo.text_type))
    print(type(PyInfo.binary_type))
    print(type(PyInfo.integer_types))
    print(type(PyInfo.class_types))
    print(type(PyInfo.maxsize))

# Generated at 2022-06-12 08:16:53.929899
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert not PyInfo.PY4
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-12 08:18:52.277421
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info.major == 2)
    assert PyInfo.PY3 == (sys.version_info.major == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert i

# Generated at 2022-06-12 08:18:56.727963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1



# Generated at 2022-06-12 08:19:05.512906
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test all members of PyInfo class
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)

    # Test all members of PyInfo class individually with data type
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple

# Generated at 2022-06-12 08:19:15.191009
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest
    import sys

    class TestClass(unittest.TestCase):

        def test_PY2(self):
            self.assertEqual(PyInfo.PY2, sys.version_info[0] == 2)

        def test_PY3(self):
            self.assertEqual(PyInfo.PY3, sys.version_info[0] == 3)

        def test_string_types(self):
            self.assertEqual(PyInfo.string_types, (basestring,) if PyInfo.PY2 else (str,))

        def test_text_type(self):
            self.assertEqual(PyInfo.text_type, unicode if PyInfo.PY2 else str)


# Generated at 2022-06-12 08:19:24.232836
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from python_compat import PY2, PY3, byte_to_chr
    if PY3:
        assert PyInfo.PY3
        assert not PyInfo.PY2
    else:
        assert not PyInfo.PY3
        assert PyInfo.PY2

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance

# Generated at 2022-06-12 08:19:30.504892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int(), PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()