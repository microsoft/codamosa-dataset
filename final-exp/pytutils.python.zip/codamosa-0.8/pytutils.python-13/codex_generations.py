

# Generated at 2022-06-12 08:09:37.163522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.maxsize > (1 << 31) - 1
    else:
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == (1 << 31) - 1
        else:
            assert PyInfo.maxsize >= (1 << 31) - 1
    assert type(PyInfo.maxsize) == int


# Unit testing

# Generated at 2022-06-12 08:09:46.221668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    PYINFO = PyInfo()

    if PYINFO.PY3:
        class Class:
            pass

        def f(): pass

        assert type(u's') == PYINFO.text_type
        assert type(u's'.encode('utf8')) == PYINFO.binary_type
        assert type(b's') == PYINFO.binary_type
        assert type(1) == PYINFO.integer_types
        assert type(1 << 64) == PYINFO.integer_types
        assert type([]) == list
        assert type(Class()) == type(Class)
        assert type(Class) == PYINFO.class_types
        assert type(f) == types.FunctionType


# If this fails, you are not using the same version of Python
# as you are running.

# Generated at 2022-06-12 08:09:51.233658
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:09:54.244516
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True if PyInfo.PY2 is False else False

    assert isinstance('string', PyInfo.string_types)
    assert isinstance(True, PyInfo.integer_types)



# Generated at 2022-06-12 08:10:01.252517
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)


# Run unittest
if __name__ == "__main__":
    import sys

    print("Testing %s %s" % (os.path.basename(sys.argv[0]), sys.version.split()[0]))

    test_PyInfo()

# Generated at 2022-06-12 08:10:08.226526
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    if PyInfo.PY2:
        assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(bytearray(b""), PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.binary_type)


# Generated at 2022-06-12 08:10:18.748900
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test PY2
    assert PyInfo.PY2
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(long(1), PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)

    # switch to PY3
    PyInfo.PY2 = False
    PyInfo.PY3 = True
    assert isinstance('foo', PyInfo.string_types)
    assert isinstance(b'foo', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:10:20.218319
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3



# Generated at 2022-06-12 08:10:26.241596
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY2 is not PyInfo.PY3
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int


pyinfo = PyInfo()

# Generated at 2022-06-12 08:10:36.101842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Make sure "PyInfo.PY2" and "not PyInfo.PY3" is true.
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    # Make sure "PyInfo.PY3" and "not PyInfo.PY2" is true.
    sys.version_info = (3, 0, 0, 'final', 0)
    reload(sys)
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False

    # Make sure "PyInfo.PY2" and "not PyInfo.PY3" is true.
    sys.version_info = (2, 7, 12, 'final', 0)
    reload(sys)
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False



# Generated at 2022-06-12 08:10:47.328845
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3, "Can't test PyInfo with python2"
    assert getattr(PyInfo, 'PY2', None) is None, "PY2 was not removed"
    assert PyInfo.string_types == (str,), "String types not assigned properly"
    assert PyInfo.text_type == str, "Text type is not str in PyInfo"
    assert PyInfo.binary_type == bytes, "Binary type is not bytes in PyInfo"
    assert PyInfo.integer_types == (int,), "Integer types not assigned properly"
    assert PyInfo.class_types == (type,), "Class types not assigned properly"
    assert PyInfo.maxsize == sys.maxsize, "Maxsize not assigned properly"

# Generated at 2022-06-12 08:10:52.639143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None


test_PyInfo()

# Generated at 2022-06-12 08:10:54.290367
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:11:00.718062
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    if PyInfo.PY2:
        assert PyInfo.PY3 is False
    elif PyInfo.PY3:
        assert PyInfo.PY2 is False

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, long)
    elif PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
       

# Generated at 2022-06-12 08:11:07.435509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(object, PyInfo.class_types)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:11:10.851914
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo
    for k, v in vars(PyInfo).items():
        if k.isupper():
            print('{} {}'.format(k, getattr(PyInfo, k)))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:16.661788
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.maxsize == 2**31-1 or PyInfo.maxsize == 2**63-1
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2


# Diagnostics: Global inlining of class PyInfo

# Generated at 2022-06-12 08:11:22.887244
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # get the ids of class PyInfo's attributes
    ids = [id(getattr(PyInfo, attr)) for attr in dir(PyInfo)]

    # run initialize twice
    from .pyinfo import PyInfo
    from .pyinfo import PyInfo

    # ids of PyInfo's attributes should be unchanged
    assert ids == [id(getattr(PyInfo, attr)) for attr in dir(PyInfo)]



# Generated at 2022-06-12 08:11:24.193291
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3



# Generated at 2022-06-12 08:11:30.197758
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('test_PyInfo', end='')
    from io import StringIO
    sys.stdout = StringIO()
    pi = PyInfo()
    pi.PY2
    pi.PY3
    pi.string_types
    pi.text_type
    pi.binary_type
    pi.integer_types
    pi.class_types
    print(pi.maxsize)
    sys.stdout = sys.__stdout__
    print('...passed')


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:43.788403
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == False
    assert PyInfo.PY2 == True
    assert PyInfo.maxsize == 9223372036854775807
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types) is True
    assert isinstance(1, PyInfo.integer_types) == True
    assert isinstance(1, PyInfo.integer_types) is not False
    assert isinstance(1, PyInfo.integer_types) != False
    assert isinstance(1, PyInfo.integer_types) is not None
    assert isinstance(1, PyInfo.integer_types) != None



# Generated at 2022-06-12 08:11:48.461024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:11:57.310112
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:03.015241
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:12:10.078126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert isinstance(u"test", PyInfo.text_type)
        assert not isinstance("test", PyInfo.text_type)
        assert not isinstance(b"test", PyInfo.text_type)
    else:
        assert isinstance("test", PyInfo.text_type)
        assert not isinstance(u"test", PyInfo.text_type)
        assert not isinstance(b"test", PyInfo.text_type)

    assert isinstance("test", PyInfo.string_types)
    assert isinstance(u"test", PyInfo.string_types)

# Generated at 2022-06-12 08:12:19.194825
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import textwrap

    print(textwrap.dedent("""\
        Python version:
            major: {0[0]}
            minor: {0[1]}
            micro: {0[2]}
            level: {0[3]}
            serial number: {0[4]}

        Python 3: {1.PY3}
        Python 2: {1.PY2}

        Type string_types: {1.string_types}
        Type text_type: {1.text_type}
        Type binary_type: {1.binary_type}
        Type integer_types: {1.integer_types}
        Type class_types: {1.class_types}

        sys.maxsize: {1.maxsize}
    """.format(sys.version_info, PyInfo())))



# Generated at 2022-06-12 08:12:26.052278
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from sfepy.base.testing import TestCommon
    info = PyInfo()
    ok = True
    if info.PY2:
        if info.maxsize != sys.maxint:
            ok = False
            output('PY2: wrong maxsize!')
    elif info.PY3:
        if info.maxsize != sys.maxsize:
            ok = False
            output('PY3: wrong maxsize!')
    tc = TestCommon()
    tc.assert_(ok)
    output('PyInfo checked.')


# Generated at 2022-06-12 08:12:35.776458
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for PY2
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert type(PyInfo.string_types) is tuple
    assert basestring in PyInfo.string_types
    assert basestring == PyInfo.text_type
    assert PyInfo.integer_types is (int, long)
    assert type(PyInfo.class_types) is tuple
    assert type in PyInfo.class_types
    assert types.ClassType in PyInfo.class_types
    assert sys.maxsize == PyInfo.maxsize


if __name__ == '__main__':
    tester = unittest.TextTestRunner()
    tester.run(
        unittest.TestSuite([
            test_PyInfo()
        ])
    )

# Generated at 2022-06-12 08:12:43.811370
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.string_types == string_types
    assert pyinfo.text_type == text_type
    assert pyinfo.binary_type == binary_type
    assert pyinfo.integer_types == integer_types
    assert pyinfo.class_types == class_types
    assert pyinfo.maxsize == maxsize


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:12:53.894428
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    with pytest.raises(AttributeError):
        PyInfo().unexist

    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:11.860847
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY3:
        assert isinstance(b'\xe7\xbd\x91\xe5\x9d\x80'.decode(), info.text_type)
        assert isinstance(b'\xe7\xbd\x91\xe5\x9d\x80', info.binary_type)
        assert isinstance(1.1, info.float)
        assert isinstance(1, info.integer_types)
        assert isinstance('abc', info.text_type)
        assert isinstance('abc', info.string_types)
        assert isinstance(dict, info.class_types)
    else:  # PY2
        assert isinstance(u'\xe7\xbd\x91\xe5\x9d\x80', info.text_type)

# Generated at 2022-06-12 08:13:16.392096
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2
    assert not info.PY3
    assert info.string_types == (basestring,)
    assert info.text_type == unicode
    assert info.binary_type == str
    assert info.integer_types == (int, long)
    assert info.class_types == (type, types.ClassType)
    assert info.maxsize == sys.maxsize

# Generated at 2022-06-12 08:13:21.853174
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.PY2 == sys.version_info[0] == 2
    if PyInfo.PY2:
        assert len((1 << 63) - 1) == len(PyInfo.maxsize)
    if PyInfo.PY3:
        assert len((1 << 63) - 1) != len(PyInfo.maxsize)

# Generated at 2022-06-12 08:13:25.599686
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('' + '', PyInfo.text_type)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:27.565942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 or PyInfo().PY3

########################################################################



# Generated at 2022-06-12 08:13:37.821243
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize > 2 ** 64
    assert PyInfo.PY3 and isinstance("", PyInfo.text_type)
    assert not PyInfo.PY3 and not isinstance("", PyInfo.text_type)



# Generated at 2022-06-12 08:13:43.692603
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

    if PyInfo.PY3:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:13:48.146873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import doctest

    failure_count, test_count = doctest.testmod(sys.modules[__name__])
    assert (test_count > 0)  # required for argparse to work
    assert failure_count == 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:54.231304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python version: {}.{}.{}'.format(PyInfo.PY2, PyInfo.PY3, PyInfo.PY3))
    print('Python maxsize: {}'.format(PyInfo.maxsize))
    # int object
    print('Python integer_types: {}'.format(PyInfo.integer_types))


# 将函数装饰为类的静态方法

# Generated at 2022-06-12 08:13:57.609816
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:14:26.469999
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY2:
        assert isinstance(info.string_types, tuple)
        assert isinstance(info.string_types[0], basestring)
        assert isinstance(info.text_type, unicode)
        assert isinstance(info.binary_type, str)
        assert isinstance(info.integer_types, tuple)
        assert isinstance(info.integer_types[0], int)
        assert isinstance(info.maxsize, int)
    else:
        assert isinstance(info.string_types, tuple)
        assert isinstance(info.string_types[0], str)
        assert isinstance(info.text_type, str)
        assert isinstance(info.binary_type, bytes)
        assert isinstance(info.integer_types, tuple)

# Generated at 2022-06-12 08:14:28.499041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("This is using Python2")
    else:
        print("This is using Python3")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:14:30.737865
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-12 08:14:35.294334
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert type(PyInfo.text_type('')) is PyInfo.text_type
    assert type(PyInfo.binary_type(b'')) is PyInfo.binary_type
    assert type(PyInfo.maxsize) is PyInfo.integer_types[0]

# Generated at 2022-06-12 08:14:44.369077
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for constructor of class PyInfo"""
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-12 08:14:48.612539
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types is (int, long)
    assert PyInfo.class_types is (type, types.ClassType)
    assert PyInfo.maxsize is pow(2, 63) - 1

# Generated at 2022-06-12 08:14:53.624200
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(None, PyInfo.string_types)
    assert not isinstance(1.1, PyInfo.string_types)
    assert not isinstance("", PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(True, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:15:03.196642
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not (PyInfo.PY3 and PyInfo.PY2)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 1
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
        assert isinstance(PyInfo.text_type, type)
    else:
        assert PyInfo.maxsize >= sys.maxsize
        assert isinstance(PyInfo.text_type, unicode)



# Generated at 2022-06-12 08:15:07.902842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


# Test function

# Generated at 2022-06-12 08:15:13.812522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:10.176103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False or PyInfo.PY2 is True
    assert PyInfo.PY3 is False or PyInfo.PY3 is True

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:16:18.441461
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test that class attribute PY2 correctly reflects Python version 2
    import sys

    assert sys.version_info[0] == 2 and hasattr(PyInfo, "PY2") and PyInfo.PY2
    assert sys.version_info[0] == 2 and hasattr(PyInfo, "PY3") and not PyInfo.PY3
    assert sys.version_info[0] == 2 and PyInfo.maxsize == sys.maxsize

    # Run unit test for make_sure_string_is_text()
    from pyclick.util import make_sure_string_is_text

    assert make_sure_string_is_text(b"abc") == "abc"
    assert make_sure_string_is_text(u"abc") == u"abc"

    # Test that class attribute PY3 correctly reflects Python version 3

# Generated at 2022-06-12 08:16:27.529268
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.string_types == (basestring,) if pyinfo.PY2 else (str,)
    assert pyinfo.text_type == unicode if pyinfo.PY2 else str
    assert pyinfo.binary_type == str if pyinfo.PY2 else bytes
    assert pyinfo.integer_types == (int, long) if pyinfo.PY2 else (int,)
    assert pyinfo.class_types == (type, types.ClassType) if pyinfo.PY2 else (type,)
    assert pyinfo.maxsize > 0

# Generated at 2022-06-12 08:16:35.350887
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-12 08:16:38.954194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)



# Generated at 2022-06-12 08:16:40.002825
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-12 08:16:46.482566
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:50.979785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert pyInfo.PY2 or pyInfo.PY3
    assert isinstance(pyInfo.string_types, tuple)
    assert isinstance(pyInfo.text_type, type)
    assert isinstance(pyInfo.binary_type, type)
    assert isinstance(pyInfo.integer_types, tuple)
    assert isinstance(pyInfo.class_types, tuple)
    assert isinstance(pyInfo.maxsize, int)


# Declare an instance of class PyInfo
pyInfo = PyInfo()



# Generated at 2022-06-12 08:16:58.820089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance("b", PyInfo.string_types)
    assert isinstance(u"c", PyInfo.text_type)
    assert isinstance("d", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.maxsize == (1 << 63) - 1:
        assert isinstance(1 << 31, PyInfo.integer_types)
    else:
        assert not isinstance(1 << 31, PyInfo.integer_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:17:07.041600
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Run unit test for PyInfo
    if PyInfo.PY2:
        assert isinstance('a string', PyInfo.string_types)
        assert isinstance(u'a unicode string', PyInfo.string_types)
        assert not isinstance(b'a bytestring', PyInfo.string_types)

        assert isinstance('a string', PyInfo.text_type)
        assert isinstance(u'a unicode string', PyInfo.text_type)
        assert not isinstance(b'a bytestring', PyInfo.text_type)

        assert isinstance(b'a byte string', PyInfo.binary_type)
        assert not isinstance('a string', PyInfo.binary_type)
        assert not isinstance(u'a unicode string', PyInfo.binary_type)


# Generated at 2022-06-12 08:19:11.556886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance([], PyInfo.maxsize.__class__)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:19:20.726970
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type("a") in PyInfo.string_types
    assert u"a" in PyInfo.string_types
    assert type("a") == PyInfo.text_type
    assert type(b"a") == PyInfo.binary_type
    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-12 08:19:31.759197
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("abc", PyInfo.string_types)
    assert not isinstance(u"abc", PyInfo.string_types)
    assert isinstance("abc", PyInfo.binary_type)
    assert not isinstance(u"abc", PyInfo.binary_type)
    assert isinstance(u"abc", PyInfo.text_type)
    assert not isinstance("abc", PyInfo.text_type)
    assert isinstance(100, PyInfo.integer_types)
    assert not isinstance(100.0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(str, PyInfo.class_types)


if __name__ == "__main__":
    print("Test complete")