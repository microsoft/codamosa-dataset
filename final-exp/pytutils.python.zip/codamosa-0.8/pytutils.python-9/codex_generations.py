

# Generated at 2022-06-12 08:09:40.833390
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert not isinstance(0, PyInfo.class_types)
    else:  # PY3
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)

# Generated at 2022-06-12 08:09:44.766611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(PyInfo.maxsize, (int, long))

# Generated at 2022-06-12 08:09:52.426522
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 is True or False
    assert py_info.PY3 is True or False
    assert isinstance(py_info.string_types, tuple)
    assert isinstance(py_info.text_type, str)
    assert isinstance(py_info.binary_type, (str, bytes))
    assert isinstance(py_info.integer_types, tuple)
    assert isinstance(py_info.class_types, tuple)
    assert isinstance(py_info.maxsize, int)



# Generated at 2022-06-12 08:09:56.503064
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:10:06.100777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check PY2 and PY3
    assert (PyInfo.PY2 or PyInfo.PY3) is True

    # Check string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types) is False

    # Check text_type
    assert isinstance('', PyInfo.text_type)
    assert isinstance(u'', PyInfo.text_type) is False
    assert isinstance(b'', PyInfo.text_type) is False

    # Check binary_type
    assert isinstance('', PyInfo.binary_type) is False
    assert isinstance(u'', PyInfo.binary_type) is False
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:10:17.027818
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    # Test all conditions
    if sys.version_info[0] == 2:
        assert isinstance('abc', basestring)
        assert not isinstance(b'abc', basestring)
        assert not isinstance(u'abc', basestring)
        assert isinstance(u'abc', unicode)
        assert not isinstance('abc', unicode)
        assert isinstance(b'abc', str)
        assert not isinstance('abc', str)
        assert isinstance(1, (int, long))
        assert not isinstance(1, (int))
        assert isinstance(True, int)
        assert isinstance(True, (int, long))
        assert isinstance(True, (int))
        assert isinstance(True, types.ClassType)

# Generated at 2022-06-12 08:10:24.787450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (
        type,
    )
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:10:34.503101
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest
    from .logging import capture_logging
    from .path import Path
    from .utils import StringIO

    with capture_logging() as logs:
        log = Path(StringIO())

    assert (
        "This is Python 2. Python 2 is no longer supported. "
        "Please install or upgrade to Python 3" in logs.logged_data
    )

    with pytest.raises(SystemExit) as exc_info:
        with capture_logging() as logs:
            assert PyInfo.PY2
            log = Path(StringIO())

    assert exc_info.value.args[0] == 1
    assert "Please install or upgrade to Python 3" in logs.logged_data



# Generated at 2022-06-12 08:10:38.780196
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize < (1 << 63)
    assert PyInfo.maxsize < (1 << 31)

# Generated at 2022-06-12 08:10:43.225677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2
    assert PyInfo.maxsize == 9223372036854775807


if __name__ == "__main__":
    import btoken

    test_PyInfo()  # Not to be deleted

# Generated at 2022-06-12 08:10:55.357977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(PyInfo.text_type(""), PyInfo.string_types)
    assert isinstance(PyInfo.binary_type(""), PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(unicode(""), PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:06.968064
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = PyInfo.PY2
    PY3 = PyInfo.PY3

    assert isinstance('str', PyInfo.string_types)
    assert isinstance(u'unicode', PyInfo.string_types)

    assert isinstance(False, PyInfo.integer_types)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(123456789, PyInfo.integer_types)
    assert isinstance(0x7FFFFFFF, PyInfo.integer_types)
    assert not isinstance(0x80000000, PyInfo.integer_types)
    assert not isinstance(1.2, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:12.196135
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.1, PyInfo.integer_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:17.781364
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)
    assert isinstance(info.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:19.121547
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

# Generated at 2022-06-12 08:11:28.874497
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b"string", PyInfo.binary_type)
        assert isinstance("string", PyInfo.text_type)
        assert not isinstance("string", PyInfo.binary_type)
        assert not isinstance(u"string", PyInfo.binary_type)
        assert isinstance(object, PyInfo.class_types)
        assert not isinstance(object, type(None))
    else:
        assert isinstance("string", PyInfo.binary_type)
        assert not isinstance("string", PyInfo.text_type)
        assert isinstance(u"string", PyInfo.text_type)
        assert not isinstance(u"string", PyInfo.binary_type)
        assert isinstance(object, type)
        assert not isinstance(object, type(None))


#

# Generated at 2022-06-12 08:11:39.570758
# Unit test for constructor of class PyInfo
def test_PyInfo():
    check = PyInfo()
    assert check.PY2 == sys.version_info[0] == 2
    assert check.PY3 == sys.version_info[0] == 3
    assert check.maxsize == sys.maxsize
    if sys.version_info[0] == 2:
        assert check.string_types == (basestring,)
        assert check.text_type == unicode
        assert check.binary_type == str
        assert check.integer_types == (int, long)
        assert check.class_types == (type, types.ClassType)
    elif sys.version_info[0] == 3:
        assert check.string_types == (str,)
        assert check.text_type == str
        assert check.binary_type == bytes
        assert check.integer_types == (int,)
        assert check

# Generated at 2022-06-12 08:11:48.644308
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance(b'b', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type('s'), PyInfo.class_types)
        assert PyInfo.maxsize > (1 << 32)
    else:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance(b'b', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type('s'), PyInfo.class_types)
        assert PyInfo.maxsize < (1 << 32)

test_PyInfo()

# Generated at 2022-06-12 08:11:56.375943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:  # PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:59.075113
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

# Generated at 2022-06-12 08:12:06.047189
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-12 08:12:17.290079
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance

# Generated at 2022-06-12 08:12:25.590568
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(len, PyInfo.class_types)


# ==========
# Decorators
# ==========

# Memoization
try:
    from functools import lru_cache
except ImportError:
    from backports.functools_lru_cache import lru_cache


# ==========
# Utilities
# ==========



# Generated at 2022-06-12 08:12:29.902431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert type(PyInfo.string_types[0]) is types.TypeType
        assert type(PyInfo.class_types[0]) is types.TypeType
    assert type(PyInfo.string_types[0]("")) is PyInfo.string_types[0]

# Generated at 2022-06-12 08:12:35.775348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types == (basestring,)
    assert pyinfo.text_type == unicode
    assert pyinfo.binary_type == str
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (type, types.ClassType)
    assert pyinfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:12:37.443813
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize <= sys.maxsize

# Generated at 2022-06-12 08:12:39.223822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


# Test for PyInfo.maxsize

# Generated at 2022-06-12 08:12:50.512042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type("test") is PyInfo.string_types[0]
        assert type("test") is PyInfo.text_type
        assert type("test".encode("utf-8")) is PyInfo.binary_type
        assert type(1) is PyInfo.integer_types[0]
        assert type(int) is PyInfo.class_types[0]
    else:  # Python 2
        assert type("test") is PyInfo.string_types[0]
        assert type(u"test") is PyInfo.text_type
        assert type("test") is PyInfo.binary_type
        assert type(1) is PyInfo.integer_types[0]
        assert type(1) is PyInfo.integer_types[1]

# Generated at 2022-06-12 08:12:57.583800
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:13:06.178510
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type is str
    assert isinstance("str", PyInfo.string_types)
    assert isinstance("str", PyInfo.text_type)
    assert isinstance(b"str", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(str, PyInfo.class_types)
    try:
        assert PyInfo.maxsize > 0
    except AssertionError:
        print("For CI test, please set the environment variable "
              "'TRAVIS_PYTHON_VERSION' and 'TOXENV'.")

# Generated at 2022-06-12 08:13:20.009145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert PyInfo.PY3 is False
    else:
        assert PyInfo.PY2 is False
    return True


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:29.494327
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("=== testing PyInfo ===")

    print("PY2: %s" % PyInfo.PY2)
    print("PY3: %s" % PyInfo.PY3)
    print("string_types: %s" % list(PyInfo.string_types))
    print("text_type: %s" % PyInfo.text_type)
    print("binary_type: %s" % PyInfo.binary_type)
    print("integer_types: %s" % list(PyInfo.integer_types))
    print("class_types: %s" % list(PyInfo.class_types))
    print("maxsize: %s" % PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:40.519762
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assertIsIn(type_, types):
        assert type_ in types

    assertIsIn(PyInfo.PY2, (True, False))
    assertIsIn(PyInfo.PY3, (True, False))
    assertIsIn(type(""), PyInfo.string_types)
    assertIsIn(type(b""), PyInfo.string_types)
    assertIsIn(type(u""), PyInfo.string_types)
    assertIsIn(type(""), PyInfo.text_type)
    assertIsIn(type(b""), PyInfo.binary_type)
    assertIsIn(type(0), PyInfo.integer_types)
    assertIsIn(type(0xFFFFFFFF), PyInfo.integer_types)
    assertIsIn(type(long(0)), PyInfo.integer_types)

# Generated at 2022-06-12 08:13:51.617250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert (type("") in PyInfo.string_types)
        assert (type(u"") in PyInfo.string_types)
        assert (type(b"") in PyInfo.string_types)
        assert (type(u"") is PyInfo.text_type)
        assert (type(b"") is PyInfo.binary_type)
        assert (type(1) in PyInfo.integer_types)

# Generated at 2022-06-12 08:13:57.963633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.text_type)
        assert isinstance("a", PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:07.312538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        elif sys.maxsize == int((1 << 31) - 1):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            assert PyInfo.maxsize == int((1 << 63) - 1)

    a = PyInfo()

    # Test attributes
    assert a.PY2 == (sys.version_info[0] == 2)


# Generated at 2022-06-12 08:14:14.095390
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, type)
        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.binary_type, type)

# Generated at 2022-06-12 08:14:19.361338
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    pytest.main(["--tb=native", "-s", "-v", "-x", "test_PyInfo.py"])

# Generated at 2022-06-12 08:14:27.054908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False

# Generated at 2022-06-12 08:14:29.833684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    # TODO: test PyInfo.maxsize



# Generated at 2022-06-12 08:14:51.801501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:14:55.367246
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:15:05.050722
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    # Check P3, P2
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is not pyinfo.PY2

    # Check maxsize
    assert (isinstance(pyinfo.maxsize, int) or
            isinstance(pyinfo.maxsize, long))

    # Check binary_type
    assert isinstance(pyinfo.binary_type, type)

    # Check text_type
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.text_type, (str, unicode))

    # Check class_types
    assert isinstance(pyinfo.class_types, tuple)

    # Check string_

# Generated at 2022-06-12 08:15:13.850139
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert len(PyInfo.string_types) == 1
    assert isinstance(PyInfo.string_types[0], type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert len(PyInfo.integer_types) == 2
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.integer_types[1], type)

    assert isinstance(PyInfo.class_types, tuple)
    assert len(PyInfo.class_types) == 2
   

# Generated at 2022-06-12 08:15:21.162109
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _PY2 = sys.version_info[0] == 2
    _PY3 = sys.version_info[0] == 3

    if _PY3:
        assert isinstance("", str)
        assert isinstance('', str)
        assert not isinstance("", bytes)
        assert isinstance(b'', bytes)

    else:  # PY2
        assert isinstance("", str)
        assert isinstance('', unicode)
        assert not isinstance("", unicode)
        assert isinstance(b'', str)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:15:30.054920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
        assert not isinstance(b'bytes', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.text_type)
        assert isinstance(b'bytes', PyInfo.binary_type)
        assert isinstance(42, PyInfo.integer_types)
        assert isinstance(2**31, PyInfo.integer_types)
        assert isinstance(2**31-1, PyInfo.integer_types)
        assert isinstance(2**63, PyInfo.integer_types)
        assert isinstance(2**63-1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
       

# Generated at 2022-06-12 08:15:35.610423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance("", PyInfo.string_types)
    else:
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance("", PyInfo.string_types)


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "--run-doctests":
        import doctest

        num_failures, _ = doctest.testmod()
        if num_failures > 0:
            sys.exit(1)

# Generated at 2022-06-12 08:15:37.586450
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("maxsize: {}".format(PyInfo.maxsize))
    assert PyInfo.PY2 != PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:15:43.422490
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.maxsize > 0
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type 

# Generated at 2022-06-12 08:15:48.649036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2

    if not PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') in PyInfo.string_types
        assert type(42) in PyInfo.integer_types
        assert type(42.1) in PyInfo.integer_types

    if not PyInfo.PY3:
        assert type(u'') in PyInfo.string_types
        assert type('') in PyInfo.string_types
        assert type(b'') in PyInfo.string_types
        assert type(42) in PyInfo.integer_types

# Generated at 2022-06-12 08:16:33.184374
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == sys.version_info[0] == 2


if __name__ == '__main__':
    import nose

    nose.main()

# Generated at 2022-06-12 08:16:37.520001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version not 2 or 3"
    assert 1 == len([x for x in [PyInfo.PY2, PyInfo.PY3] if x]), "Only one of PY2 or PY3 can be True"
    assert 'version_info' in dir(sys), "Python version must be accessible through sys.version_info"
    assert PyInfo.maxsize > 1, "maxsize must be greater than 1"

# Generated at 2022-06-12 08:16:43.952897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert PyInfo.binary_type == str
        assert PyInfo.class_types == (type, types.ClassType)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == basestring
        assert PyInfo.text_type == unicode
    else:  # PY3
        assert PyInfo.binary_type == bytes
        assert PyInfo.class_types == type
        assert PyInfo.integer_types == int
        assert PyInfo.maxsize == (1 << 63) - 1  # 64-bit


# Generated at 2022-06-12 08:16:51.864746
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    if info.PY3:
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)
        assert info.maxsize == sys.maxsize
    else:  # PY2
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)

# Generated at 2022-06-12 08:16:54.255063
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2  # or PyInfo.PY3


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 08:17:01.987508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from hypothesis import given
    from tests.bind_tests.hints import BoundPortedNodesPair
    from . import strategies

    @given(strategies.nodes_pairs)
    def test_basic(nodes_pair: BoundPortedNodesPair) -> None:
        bound, ported = nodes_pair

        assert isinstance(bound.PyInfo.PY2, bool)
        assert isinstance(ported.PyInfo.PY2, bool)
        assert bound.PyInfo.PY2 == ported.PyInfo.PY2

        assert isinstance(bound.PyInfo.PY3, bool)
        assert isinstance(ported.PyInfo.PY3, bool)
        assert bound.PyInfo.PY3 == ported.PyInfo.PY3


# Generated at 2022-06-12 08:17:08.650919
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == PyInfo.PY3 or PyInfo.PY2
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert type("") in PyInfo.string_types
    assert type("") is PyInfo.text_type
    assert type(b"") is PyInfo.binary_type
    assert type(1) in PyInfo.integer_types
    assert type(type) in PyInfo.class_types
    assert type(PyInfo) in PyInfo.class_types
    assert type(1) in PyInfo.class_types


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:17:14.628431
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print('[Python 2]')
    elif PyInfo.PY3:
        print('[Python 3]')
    print('string_types: %s' % PyInfo.string_types)
    print('text_type: %s' % PyInfo.text_type)
    print('binary_type: %s' % PyInfo.binary_type)
    print('integer_types: %s' % PyInfo.integer_types)
    print('class_types: %s' % PyInfo.class_types)
    print('maxsize: %d' % PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:17:22.273904
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(None, PyInfo.integer_types)

# Generated at 2022-06-12 08:17:23.409524
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(TypeError):
        PyInfo()

# Generated at 2022-06-12 08:19:21.874019
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test for global variable PY2 and PY3
    assert PyInfo.PY2 ^ PyInfo.PY3

    # test for global variable string_types
    assert isinstance(1, PyInfo.string_types) ^ \
        isinstance(u'a', PyInfo.string_types)

    # test for global variable text_type
    assert isinstance(u'a', PyInfo.text_type) ^ \
        isinstance('a', PyInfo.text_type)

    # test for global variable binary_type
    assert isinstance('a', PyInfo.binary_type) ^ \
        isinstance(b'a', PyInfo.binary_type)

    # test for global variable integer_types

# Generated at 2022-06-12 08:19:23.608616
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-12 08:19:28.131074
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:19:30.914751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)