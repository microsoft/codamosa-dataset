

# Generated at 2022-06-12 08:09:33.648644
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test PyInfo"""
    assert PyInfo().maxsize == sys.maxsize

# Generated at 2022-06-12 08:09:41.001263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance("", PyInfo.binary_type)
    else:
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)
    assert isinstance(object(), PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:09:41.924732
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == True

# Generated at 2022-06-12 08:09:49.140328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import json

    from metayara import PyInfo

    assert PyInfo.PY2
    assert not PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types[0] is basestring

        assert PyInfo.text_type is unicode

        assert PyInfo.binary_type is str

        assert PyInfo.integer_types[0] is int
        assert PyInfo.integer_types[1] is long

        assert PyInfo.class_types[0] is type
        assert PyInfo.class_types[1] is types.ClassType

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY3
        assert PyInfo.string_types[0] is str

        assert PyInfo.text_type is str

        assert PyInfo.binary_type is bytes

       

# Generated at 2022-06-12 08:09:57.364333
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:00.795923
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == (1 << 31) - 1
    elif PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:10:03.100438
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-12 08:10:05.413995
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    tests
    :return:
    """
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)



# Generated at 2022-06-12 08:10:14.756328
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)



# Generated at 2022-06-12 08:10:18.569345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert '__main__' == PyInfo.__name__
    print(PyInfo.PY3)
    print(PyInfo.PY2)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:27.842321
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    These are code snippet which are executed in IPython console.
    >>> import sys
    >>> sys.version_info
    sys.version_info(major=2, minor=7, micro=12, releaselevel='final', serial=0)
    >>> import sys
    >>> sys.version_info[0] == 2
    True
    >>> sys.version_info[0] == 3
    False
    >>> sys.maxsize
    9223372036854775807
    """
    pass

# Generated at 2022-06-12 08:10:37.105427
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check that all constants are set properly
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 ^ PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:46.885133
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Make sure that PY2 and PY3 are properly set
    assert PyInfo.PY2 + PyInfo.PY3 == 1, "PY2 = %s and PY3 = %s" % (
        PyInfo.PY2, PyInfo.PY3)

    # Check max size
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        if sys.platform.startswith("java"):
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            try:
                len(PyInfo.maxsize)
            except OverflowError:
                assert PyInfo.maxsize == int((1 << 31) - 1)
            else:
                assert PyInfo.maxsize == int((1 << 63) - 1)

   

# Generated at 2022-06-12 08:10:53.533734
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:56.026043
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


test_PyInfo()

# Generated at 2022-06-12 08:11:07.153545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:11:17.720692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.string_types)
        assert isinstance("abc", PyInfo.text_type)
        assert not isinstance(b"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance("abc", PyInfo.binary_type)
        assert isinstance(3, PyInfo.integer_types)
        assert isinstance(3, PyInfo.class_types)

# Generated at 2022-06-12 08:11:27.701872
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(23, PyInfo.integer_types)
        assert issubclass(type, PyInfo.class_types)
    else:  # PY2
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)

# Generated at 2022-06-12 08:11:37.953598
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _check(obj, typ):
        if isinstance(obj, typ):
            return "ok"
        else:
            return "type: %s, error" % str(type(obj))


# Generated at 2022-06-12 08:11:39.289863
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p, PyInfo)



# Generated at 2022-06-12 08:11:47.778593
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("Run in Python 2")
    else:
        print("Run in Python 3")

    if PyInfo.PY3:
        print("Run in Python 3")
    else:
        print("Run in Python 2")



# Generated at 2022-06-12 08:11:56.813759
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", str)
        assert isinstance("a", PyInfo.text_type)
        assert isinstance(b"a", bytes)
    else:
        assert isinstance("a", basestring)
        assert isinstance("a", PyInfo.text_type)
        assert isinstance("a", str)
        assert isinstance("a", PyInfo.binary_type)

    assert isinstance(123, PyInfo.integer_types)
    assert isinstance(123, int)
    assert isinstance(12.3, float)
    assert isinstance(1e-3, float)

    # class types
    assert isinstance(dict, type)
    assert isinstance(dict, PyInfo.class_types)
    assert not isinstance(dict, tuple)
    assert not isinstance

# Generated at 2022-06-12 08:12:07.115894
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(False, PyInfo.integer_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(str, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)

    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes

# Generated at 2022-06-12 08:12:17.641726
# Unit test for constructor of class PyInfo
def test_PyInfo():
    mi = PyInfo()
    assert mi.PY2 == sys.version_info[0] == 2
    assert mi.PY3 == sys.version_info[0] == 3

    if mi.PY3:
        assert mi.string_types == (str,)
        assert mi.text_type == str
        assert mi.binary_type == bytes
        assert mi.integer_types == (int,)
        assert mi.class_types == (type,)

        assert isinstance(mi.maxsize, int)
        assert len(mi.maxsize) == 64
    else:  # PY2
        assert mi.string_types == (basestring,)
        assert mi.text_type == unicode
        assert mi.binary_type == str
        assert mi.integer_types == (int, long)
        assert mi.class_

# Generated at 2022-06-12 08:12:20.870517
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3

if __name__ == "__main__":
    import doctest
    doctest.testmod()
    test_PyInfo()

# Generated at 2022-06-12 08:12:26.308296
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PyInfo.PY2 is False
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == 9223372036854775807



# Generated at 2022-06-12 08:12:36.282442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    # Type
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple

    # PY2
    if PyInfo.PY2:
        assert type(PyInfo.string_types[0]) is type
        assert type(PyInfo.text_type) is type
        assert type(PyInfo.binary_type) is type
        assert type(PyInfo.integer_types[0]) is type
        assert type(PyInfo.class_types[0]) is type or type(PyInfo.class_types[0]) is classobj
       

# Generated at 2022-06-12 08:12:38.492171
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    try:
        from setuptools import types as _types
    except ImportError:
        return

    assert isinstance(_types.ModuleType, PyInfo.class_types)

# Generated at 2022-06-12 08:12:46.825151
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY2 == PyInfo.PY2
    assert py_info.PY3 == PyInfo.PY3
    assert py_info.string_types == PyInfo.string_types
    assert py_info.text_type == PyInfo.text_type
    assert py_info.binary_type == PyInfo.binary_type
    assert py_info.integer_types == PyInfo.integer_types
    assert py_info.class_types == PyInfo.class_types
    assert py_info.maxsize == PyInfo.maxsize

# Generated at 2022-06-12 08:12:47.820618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0



# Generated at 2022-06-12 08:12:59.617659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)



# Generated at 2022-06-12 08:13:01.935024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0

# Generated at 2022-06-12 08:13:09.411127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(b"abc", PyInfo.string_types)
        assert isinstance("abc", PyInfo.text_type)
        assert not isinstance(b"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert not isinstance("abc", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.class_types)

# Generated at 2022-06-12 08:13:12.185563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, 'Python version is not 2 or 3'
    assert isinstance(PyInfo.string_types, tuple)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:16.101602
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("hello world", PyInfo.string_types)
    else:  # PY3
        assert isinstance("hello world", PyInfo.string_types)

    assert isinstance("hello world", PyInfo.text_type)
    assert isinstance(b"hello world", PyInfo.binary_type)

# Generated at 2022-06-12 08:13:26.801640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert "PyInfo" in repr(py_info)
    assert str(py_info) == "This is python version 3"
    assert py_info.maxsize == sys.maxsize
    assert py_info.PY3
    assert isinstance(py_info.binary_type, type)
    assert py_info.binary_type == bytes
    assert isinstance(py_info.string_types, tuple)
    assert py_info.string_types == (str, )
    assert isinstance(py_info.text_type, str)
    assert py_info.text_type == "str"
    assert isinstance(py_info.integer_types, tuple)
    assert py_info.integer_types == (int, )
    assert isinstance(py_info.class_types, tuple)

# Generated at 2022-06-12 08:13:29.636057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == True or PyInfo.PY3 == True, "Py2 or Py3 should be true"
    assert PyInfo.PY2 == False or PyInfo.PY3 == False, "Py2 and Py3 should be false"

# Generated at 2022-06-12 08:13:40.661875
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # ``string_types`` should be a tuple of string types
    x = PyInfo.string_types[0]("str")
    assert isinstance(x, PyInfo.string_types)

    # ``text_type`` should be a real string type, not a tuple
    assert not isinstance(PyInfo.text_type, tuple)

    # ``binary_type`` should be a real string type, not a tuple
    assert not isinstance(PyInfo.binary_type, tuple)

    # ``integer_types`` should be a tuple of integer types
    x = PyInfo.integer_types[0](5)
    assert isinstance(x, PyInfo.integer_types)

    # ``class_types`` should be a tuple of class types

# Generated at 2022-06-12 08:13:49.038646
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(12345, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:56.923412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    # isinstance
    assert isinstance('aaa', PyInfo.string_types)
    assert isinstance('aaa', PyInfo.text_type)
    assert isinstance(b'aaa', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

    # type
    assert type('aaa') is PyInfo.text_type
    assert type(b'aaa') is PyInfo.binary_type
    assert type(1) is int  # PyInfo.integer_types
    assert type(PyInfo) is type  # PyInfo.class_types

# Generated at 2022-06-12 08:14:22.957475
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = PyInfo.PY2
    PY3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types
    maxsize = PyInfo.maxsize



# Generated at 2022-06-12 08:14:26.676769
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert PyInfo.PY2 == True
    assert PyInfo.PY3 == False
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == 0x7FFFFFFF


# Generated at 2022-06-12 08:14:33.056513
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert "foo" in PyInfo.string_types
        assert u"foo" in PyInfo.string_types
        assert type("foo") in PyInfo.string_types
        assert type(u"foo") in PyInfo.string_types

        assert type("foo") is PyInfo.text_type
        assert type(u"foo") is PyInfo.text_type

        assert type(b"foo") is PyInfo.binary_type
        assert type(buffer("foo")) is PyInfo.binary_type
    else:
        assert "foo" in PyInfo.string_types
        assert "foo" in PyInfo.string_types
        assert type("foo") in PyInfo.string_types

# Generated at 2022-06-12 08:14:38.971052
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1, PyInfo.class_types)
    import numpy
    assert isinstance(numpy, PyInfo.class_types)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:14:43.750981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-12 08:14:44.663166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:14:46.232872
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        PyInfo().maxsize = 1
    assert PyInfo().maxsize > 0



# Generated at 2022-06-12 08:14:51.771959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.maxsize)
    if PyInfo.PY2:
        print(PyInfo.text_type)
        print(PyInfo.binary_type)
        print(PyInfo.integer_types)
        print(PyInfo.class_types)
    else:
        print(PyInfo.string_types)


test_PyInfo()


# 把字符串的所有空格变成“%20″

# Generated at 2022-06-12 08:15:00.754494
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert len(PyInfo.string_types) > 0
        for _ in PyInfo.string_types:
            assert isinstance(_, types.TypeType)

        assert isinstance(PyInfo.text_type, type)
        assert isinstance(PyInfo.text_type(), basestring)

        assert isinstance(PyInfo.binary_type, type)
        assert isinstance(PyInfo.binary_type(), basestring)

        assert isinstance(PyInfo.integer_types, tuple)
        assert len(PyInfo.integer_types) > 0

# Generated at 2022-06-12 08:15:07.014534
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:15:57.338842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:03.481501
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.PY2 is False
    assert isinstance('xxx', PyInfo.string_types)
    assert isinstance('xxx', PyInfo.text_type)
    assert not isinstance('xxx', PyInfo.binary_type)
    assert isinstance(u'xxx', PyInfo.string_types)
    assert isinstance(u'xxx', PyInfo.text_type)
    assert not isinstance(u'xxx', PyInfo.binary_type)
    assert not isinstance(b'xxx', PyInfo.string_types)
    assert not isinstance(b'xxx', PyInfo.text_type)
    assert isinstance(b'xxx', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:06.437867
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize

# Generated at 2022-06-12 08:16:10.972147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("".encode("utf-8"), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)


test_PyInfo()

# Generated at 2022-06-12 08:16:18.726898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)

    if PyInfo.PY2:
        assert isinstance("a string", PyInfo.string_types)
        assert isinstance(u"a string", PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)
    else:
        assert isinstance("a string", PyInfo.string_types)
        assert not isinstance(u"a string", PyInfo.string_types)
        assert not isinstance(1, PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert int in PyInfo.class_types
    assert type in PyInfo.class_types

# Generated at 2022-06-12 08:16:20.636560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python Version')
    print(sys.version)
    # print('Success!')



# Generated at 2022-06-12 08:16:24.340568
# Unit test for constructor of class PyInfo
def test_PyInfo():
    le = len(PyInfo.string_types)
    le2 = len(PyInfo.integer_types)
    if PyInfo.PY2:
        assert le == 1
        assert le2 == 2
    else:
        assert le == 1
        assert le2 == 1

# Generated at 2022-06-12 08:16:31.447997
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, integer_types)


integer_types = PyInfo.integer_types
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type


if PyInfo.PY3:
    def is_text(value):
        return isinstance(value, PyInfo.text_type)

# Generated at 2022-06-12 08:16:36.005707
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)

    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:16:43.692324
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)

    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types[0], types.ClassType)
        assert isinstance(PyInfo.text_type, types.UnicodeType)

        assert isinstance(PyInfo.binary_type, types.StringType)
        assert isinstance(PyInfo.integer_types[0], types.IntType)
        assert isinstance(PyInfo.integer_types[1], types.LongType)

# Generated at 2022-06-12 08:18:36.665678
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.binary_type, type)



# Generated at 2022-06-12 08:18:42.580515
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])
    assert PyInfo.PY2 == (2 == sys.version_info[0])
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        # on Python 2 PyInfo.integer_types == (int, long)
        # but on Python 3 PyInfo.integer_types == (int,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        #

# Generated at 2022-06-12 08:18:45.548535
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-12 08:18:54.027024
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == basestring or PyInfo.string_types == str, PyInfo.string_types
    assert PyInfo.text_type == unicode or PyInfo.text_type == str, PyInfo.text_type
    assert PyInfo.binary_type == str or PyInfo.binary_type == bytes, PyInfo.binary_type
    assert PyInfo.integer_types == (int, long) or PyInfo.integer_types == int, PyInfo.integer_types
    assert PyInfo.class_types == (type, types.ClassType) or PyInfo.class_types == type, PyInfo.class_types
    assert PyInfo.maxsize > 0

# Generated at 2022-06-12 08:18:57.529118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:18:58.716015
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

# Generated at 2022-06-12 08:19:04.169233
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    assert obj.PY2 is not None
    assert obj.PY3 is not None
    assert obj.string_types is not None
    assert obj.text_type is not None
    assert obj.binary_type is not None
    assert obj.integer_types is not None
    assert obj.class_types is not None
    assert obj.maxsize is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:19:13.670507
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)


# Generated at 2022-06-12 08:19:14.993059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

# Generated at 2022-06-12 08:19:17.407838
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # unit testing for the PyInfo class
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()