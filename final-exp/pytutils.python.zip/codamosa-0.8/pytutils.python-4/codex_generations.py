

# Generated at 2022-06-12 08:09:37.202126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None



# Generated at 2022-06-12 08:09:46.257819
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert info.maxsize == 2147483647
    else:
        if info.PY3:
            if sys.maxsize == 9223372036854775807:
                assert info.maxsize == sys.maxsize
            else:
                assert info.maxsize == 2147483647
        else:
            if sys.maxint == 9223372036854775807:
                assert info.maxsize == sys.maxint
            else:
                assert info.maxsize == 2147483647


test

# Generated at 2022-06-12 08:09:55.027022
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.PY2 is True or info.PY2 is False

    for string_type in info.string_types:
        assert isinstance("abc", string_type)

    for integer_type in info.integer_types:
        assert isinstance(1, integer_type)

    for class_type in info.class_types:
        assert isinstance(PyInfo, class_type)

    assert isinstance("abc", info.text_type)
    assert isinstance(b"abc", info.binary_type)


if __name__ == "__main__":
    import pytest

    pytest.main(args=[".", "--doctest-modules", "-v", "--capture=sys"])

# Generated at 2022-06-12 08:10:04.887245
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.string_types == (str, unicode) if PyInfo.PY2 else (str,)
    assert isinstance("test", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("test", PyInfo.integer_types)

    assert isinstance(b"test", PyInfo.binary_type)
    assert not isinstance("test", PyInfo.binary_type)

    assert isinstance("test", PyInfo.text_type)
    assert not isinstance(b"test", PyInfo.text_type)

    # Validate the platform specific maxsize

# Generated at 2022-06-12 08:10:10.084525
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3
    assert pyinfo.string_types
    assert pyinfo.text_type
    assert pyinfo.binary_type
    assert pyinfo.integer_types
    assert pyinfo.class_types
    assert pyinfo.maxsize

# Generated at 2022-06-12 08:10:19.720187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not PyInfo.PY2 or not PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str


assert PyInfo.text_type == str if PyInfo.PY3 else unicode
assert PyInfo.binary_type == bytes if PyInfo.PY3 else str



# Generated at 2022-06-12 08:10:24.447777
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == "__main__":
    import nose

    nose.main()

# Generated at 2022-06-12 08:10:34.938124
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    for t in PyInfo.string_types:
        assert isinstance('', t)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:10:39.022861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 is True
    assert p.PY3 is False
    assert p.string_types is (basestring,)
    assert p.text_type is unicode
    assert p.binary_type is str
    assert p.integer_types is (int, long)
    assert p.class_types is (type, types.ClassType)
    assert p.maxsize == sys.maxsize

# Generated at 2022-06-12 08:10:48.136260
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == ((basestring,) if PyInfo.PY2 else (str,))
    assert PyInfo.text_type == (unicode if PyInfo.PY2 else str)
    assert PyInfo.binary_type == (str if PyInfo.PY2 else bytes)
    assert PyInfo.integer_types == ((int, long) if PyInfo.PY2 else (int,))
    assert PyInfo.class_types == ((type, types.ClassType) if PyInfo.PY2 else (type,))

# Generated at 2022-06-12 08:10:59.059146
# Unit test for constructor of class PyInfo
def test_PyInfo():
    res_expect = {
        'PY2': True,
        'PY3': False,
        'string_types': (basestring,),
        'text_type': unicode,
        'binary_type': str,
        'integer_types': (int, long),
        'class_types': (type, types.ClassType),
    }
    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        res_expect['maxsize'] = int((1 << 31) - 1)
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31


# Generated at 2022-06-12 08:11:06.516837
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Tests for PyInfo"""

    # Make sure that PyInfo.PY2 is True for Python 2.x, otherwise False
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
    else:
        assert not PyInfo.PY2

    # Make sure that PyInfo.PY3 is True for Python 3.x, otherwise False
    if sys.version_info[0] == 3:
        assert PyInfo.PY3
    else:
        assert not PyInfo.PY3


# Generated at 2022-06-12 08:11:16.398825
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    d = dict(PY2=PyInfo.PY2, PY3=PyInfo.PY3)
    with pytest.raises(KeyError):
        d['PY4']
    with pytest.raises(KeyError):
        d['PYsomething']
    with pytest.raises(KeyError):
        d['PY-']
    with pytest.raises(KeyError):
        d['PY+']
    with pytest.raises(KeyError):
        d['PY']
    with pytest.raises(KeyError):
        d['Y']
    with pytest.raises(KeyError):
        d['+']
    with pytest.raises(KeyError):
        d['-']

# Generated at 2022-06-12 08:11:19.121573
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:28.876500
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('string', PyInfo.string_types)
        assert isinstance(u'unicode string', PyInfo.string_types)
        assert not isinstance('string', PyInfo.binary_type)
        assert not isinstance(u'unicode string', PyInfo.binary_type)
        assert not isinstance(b'binary string', PyInfo.string_types)
        assert isinstance(b'binary string', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:39.572541
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2_info = PyInfo()
    assert py2_info.PY2 is True
    assert py2_info.PY3 is False

    py2_info = PyInfo()
    assert isinstance(py2_info.string_types, tuple)
    assert isinstance(py2_info.text_type, unicode)
    assert isinstance(py2_info.binary_type, str)
    assert isinstance(py2_info.integer_types, tuple)
    assert isinstance(py2_info.integer_types[0], int)
    assert isinstance(py2_info.integer_types[1], long)
    assert isinstance(py2_info.class_types, tuple)

# Generated at 2022-06-12 08:11:45.241041
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:11:48.466883
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.string_types == (str,) if PyInfo.PY3 else (basestring,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:56.234308
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.maxsize == (1 << 31) - 1
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)


# Ensure compatibility with PyInfo
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types
maxsize = PyInfo.maxsize
maxint = maxsize


# Generated at 2022-06-12 08:12:01.665863
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:12:17.326862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] is basestring
    else:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] is str
    assert isinstance("", PyInfo.string_types[0])

    if PyInfo.PY2:
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.integer_types[0] is int
        assert PyInfo.integer_types[1] is long
    else:
        assert len(PyInfo.integer_types) == 1
        assert PyInfo.integer_types[0] is int
    assert isinstance(0, PyInfo.integer_types[0])


# Generated at 2022-06-12 08:12:22.434973
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('aaa', PyInfo.string_types)
    else:
        assert isinstance(b'aaa', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:12:29.026866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:35.635928
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('hi', PyInfo.string_types)
    assert isinstance(u'hi', PyInfo.string_types)
    assert isinstance(u'hi', PyInfo.text_type)
    assert isinstance(b'hi', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:38.480399
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert pyinfo.PY2 == (sys.version_info[0] == 2)



# Generated at 2022-06-12 08:12:47.585713
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Equivalence for the python2 and python3
    import six
    assert PyInfo.PY2 == (six.PY2 == True)
    assert PyInfo.PY3 == (six.PY3 == True)
    assert PyInfo.string_types == six.string_types
    assert PyInfo.text_type == six.text_type
    assert PyInfo.binary_type == six.binary_type
    assert PyInfo.integer_types == six.integer_types
    assert PyInfo.class_types == six.class_types


# Unit test
if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:55.910414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False, "PY3 should be either True or False"
    assert PyInfo.PY2 is True or PyInfo.PY2 is False, "PY2 should be either True or False"
    assert PyInfo.string_types is not None, "string_types should be either str or basestring"
    assert PyInfo.text_type is not None, "text_type should be either str or unicode"
    assert PyInfo.binary_type is not None, "binary_type should be either bytes or str"
    assert PyInfo.integer_types is not None, "integer_types should be either int or long"
    assert PyInfo.class_types is not None, "class_types should be either type or types.ClassType"

# Generated at 2022-06-12 08:13:03.220660
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('sys.version_info', sys.version_info)
    print('sys.platform', sys.platform)
    print('PyInfo.PY2', PyInfo.PY2)
    print('PyInfo.PY3', PyInfo.PY3)
    print('PyInfo.maxsize', PyInfo.maxsize)
    if PyInfo.maxsize <= (1 << 31) - 1:
        print('32 bit')
    else:
        print('64 bit')



# Generated at 2022-06-12 08:13:11.694784
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert str(PyInfo.PY2) == 'True'
        assert str(PyInfo.PY3) == 'False'
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(u'abc', PyInfo.string_types)
        assert issubclass(int, PyInfo.integer_types)
        assert issubclass(long, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:15.893086
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    assert isinstance('', PyInfo.string_types)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

    print(PyInfo.maxsize)



# Generated at 2022-06-12 08:13:32.567064
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    assert (pyinfo.string_types == (basestring,) and not pyinfo.PY3) or\
        (pyinfo.string_types == (str,) and pyinfo.PY3)
    assert (pyinfo.text_type == unicode and not pyinfo.PY3) or\
        (pyinfo.text_type == str and pyinfo.PY3)
    assert (pyinfo.binary_type == str and not pyinfo.PY3) or\
        (pyinfo.binary_type == bytes and pyinfo.PY3)

# Generated at 2022-06-12 08:13:36.530883
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2 == (sys.version_info[0] == 2)
    assert PyInfo().PY3 == (sys.version_info[0] == 3)
    assert PyInfo().maxsize == sys.maxsize

# Generated at 2022-06-12 08:13:44.435379
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == "__main__":
    import doctest

    doctest.testmod(
        name="doctest_pipeline_base", optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE
    )
    doctest.testmod(
        name="doctest_pipeline_base",
        module=doctest_pipeline_base,
        optionflags=doctest.ELLIPSIS | doctest.NORMALIZE_WHITESPACE,
    )

# Generated at 2022-06-12 08:13:55.032575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:13:56.959371
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(PyInfo(), PyInfo)



# Generated at 2022-06-12 08:14:01.125708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for attr in [
        'PY2',
        'PY3',
        'string_types',
        'text_type',
        'binary_type',
        'integer_types',
        'class_types',
        'maxsize'
    ]:
        assert hasattr(PyInfo, attr), 'Missing attribute: %s' % attr


# Export
__all__ = ['PyInfo']

# Generated at 2022-06-12 08:14:04.510600
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:14:12.402047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type("hello") in PyInfo.string_types
        assert type("hello") is PyInfo.text_type
        assert type("hello") is not PyInfo.binary_type
        assert type("hello") in PyInfo.class_types
        assert type(1) in PyInfo.integer_types
        assert type(1) in PyInfo.class_types
        assert type(object) in PyInfo.class_types
        assert len(PyInfo.string_types) == 1
    else:
        assert type("hello") in PyInfo.string_types
        assert type("hello") is PyInfo.text_type
        assert type("hello") is not PyInfo.binary_type
        assert type("hello") in PyInfo.class_types
        assert type(1) in PyInfo.integer_types
       

# Generated at 2022-06-12 08:14:16.324014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert (isinstance("a", PyInfo.string_types)
            == isinstance(u"a", PyInfo.string_types))
    assert not isinstance(u"a", PyInfo.binary_type)


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-12 08:14:22.164959
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if PyInfo.PY2:
    exec("""def reraise(tp, value, tb=None):
    raise tp, value, tb
""")  # noqa


else:
    def reraise(tp, value, tb=None):
        if value.__traceback__ is not tb:
            raise value.with_traceback(tb)
        raise value


_MISSING = object()



# Generated at 2022-06-12 08:14:45.638097
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


test_PyInfo()

# Generated at 2022-06-12 08:14:50.591910
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:14:51.233628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3



# Generated at 2022-06-12 08:14:59.843001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type is unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type is str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:15:09.761087
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance("", PyInfo.text_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)


# Generated at 2022-06-12 08:15:17.840993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def is_int_equal(a, b):
        print('a: ', a, 'b: ', b)

    is_int_equal(PyInfo.PY2, sys.version_info[0] == 2)
    is_int_equal(PyInfo.PY3, sys.version_info[0] == 3)
    # is_int_equal(PyInfo.PY26, sys.version_info[0:2] == (2, 6))
    # is_int_equal(PyInfo.PY27, sys.version_info[0:2] == (2, 7))
    # is_int_equal(PyInfo.PY3x, sys.version_info[0] == 3)
    # is_int_equal(PyInfo.PY34, sys.version_info[0:2] == (

# Generated at 2022-06-12 08:15:23.980414
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> class X(object):
    ...     def __len__(self):
    ...         return 1 << 31
    >>> try:
    ...     len(X())
    ... except OverflowError:
    ...     maxsize = int((1 << 31) - 1)
    ... else:
    ...     maxsize = int((1 << 63) - 1)
    >>> PyInfo.maxsize == maxsize
    True
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:15:28.915633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.__class__.__name__ == 'type'
    assert issubclass(PyInfo, object)

    pyinfo = PyInfo()
    assert pyinfo.__class__.__name__ == 'PyInfo'
    assert isinstance(pyinfo, object)
    assert isinstance(pyinfo, PyInfo)

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)

    if PyInfo.PY2:
        assert isinstance('', PyInfo.text_type)
        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)

   

# Generated at 2022-06-12 08:15:31.304902
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> p = PyInfo()
    >>> assert p.PY2 and not p.PY3
    >>> assert isinstance('', (str,))
    >>> assert p.maxsize > 0
    """
    pass



# Generated at 2022-06-12 08:15:37.013803
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        maxsize = sys.maxsize
    else:  # PY2
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            maxsize = int((1 << 31) - 1)
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):

                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                # 32-bit
                maxsize = int((1 << 31) - 1)

# Generated at 2022-06-12 08:16:25.642192
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b'', PyInfo.binary_type)
    else:
        assert isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:16:32.441210
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert not (PyInfo.PY2 is True and PyInfo.PY3 is True)

    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert issubclass(unicode, PyInfo.text_type)
        assert type(''.encode()) in PyInfo.binary_type
        assert issubclass(int, PyInfo.integer_types)

    elif PyInfo.PY3:
        assert type('', str) in PyInfo.string_types
        assert isinstance(str, PyInfo.text_type)
        assert issubclass(str, PyInfo.text_type)
        assert isinstance(bytes, PyInfo.binary_type)

# Generated at 2022-06-12 08:16:35.713801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:16:41.660576
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.string_types is (basestring,)
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:50.875424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # check string types
    for s in PyInfo.string_types:
        assert isinstance("Hello", s)
    assert not isinstance(b"Hello", s)

    # check text type
    assert isinstance("Hello", PyInfo.text_type)
    assert not isinstance(b"Hello", PyInfo.text_type)

    # check binary type
    assert isinstance(b"Hello", PyInfo.binary_type)
    assert not isinstance("Hello", PyInfo.binary_type)

    # check integer types
    for s in PyInfo.integer_types:
        assert isinstance(1, s)
        assert not isinstance(1.0, s)

    # check class types
    for s in PyInfo.class_types:
        assert isinstance(PyInfo, s)

# Generated at 2022-06-12 08:16:54.157679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (PyInfo.PY3 == False) == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (PyInfo.PY2 == False) == (sys.version_info[0] == 3)

# Generated at 2022-06-12 08:16:56.146790
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

# Generated at 2022-06-12 08:17:04.177850
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        print("Python 3")
        assert isinstance('a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance('a', PyInfo.binary_type)
        assert not isinstance(b'a', PyInfo.string_types)
        assert not isinstance(b'a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert PyInfo.maxsize > (1 << 32)
    else:  # PY2
        print("Python 2")
        assert isinstance('a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance('a', PyInfo.binary_type)

# Generated at 2022-06-12 08:17:12.441267
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert type(PyInfo.string_types) is tuple
    assert 'str' in PyInfo.string_types
    assert repr(PyInfo.string_types) == "(<class 'str'>,)"

    assert type(PyInfo.text_type) is type
    assert PyInfo.text_type is str
    assert repr(PyInfo.text_type) == "<class 'str'>"

    assert type(PyInfo.binary_type) is type
    assert PyInfo.binary_type is bytes
    assert repr(PyInfo.binary_type) == "<class 'bytes'>"

    assert type(PyInfo.integer_types) is tuple
    assert int in PyInfo.integer_types

# Generated at 2022-06-12 08:17:16.961744
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-12 08:19:18.630947
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("python version:", sys.version_info)
    print("PyInfo.PY2:", PyInfo.PY2)
    print("PyInfo.PY3:", PyInfo.PY3)

    if PyInfo.PY2:
        print("PyInfo.string_types:", PyInfo.string_types)
        print("PyInfo.text_type:", PyInfo.text_type)
        print("PyInfo.binary_type:", PyInfo.binary_type)
        print("PyInfo.integer_types", PyInfo.integer_types)
        print("PyInfo.class_types", PyInfo.class_types)
        print("PyInfo.maxsize", PyInfo.maxsize)
    else:
        print("PyInfo.string_types:", PyInfo.string_types)

# Generated at 2022-06-12 08:19:21.164877
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:19:27.653583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes

# Generated at 2022-06-12 08:19:35.889916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 is True or py_info.PY2 is False
    assert py_info.PY3 is True or py_info.PY3 is False
    assert py_info.string_types == (str,) or py_info.string_types == (str, unicode)
    assert py_info.text_type is str or py_info.text_type is unicode
    assert py_info.binary_type is bytes or py_info.binary_type is str
    assert py_info.integer_types == (int,) or py_info.integer_types == (int, long)
    assert py_info.class_types == (type,) or py_info.class_types == (type, types.ClassType)
