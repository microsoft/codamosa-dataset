

# Generated at 2022-06-12 08:09:40.531492
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        import unittest2
        unittest = unittest2
    except ImportError:
        import unittest

    class TestPyInfo(unittest.TestCase):

        def test_PY2(self):
            self.assertTrue(PyInfo.PY2)

        def test_PY3(self):
            self.assertFalse(PyInfo.PY3)

        def test_string_types(self):
            self.assertTrue(isinstance(PyInfo.string_types, tuple))

        def test_text_type(self):
            self.assertTrue(isinstance(PyInfo.text_type, type))

        def test_binary_type(self):
            self.assertTrue(isinstance(PyInfo.binary_type, type))


# Generated at 2022-06-12 08:09:45.823827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:09:49.793891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # create two instances of PyInfo
    py_info1 = PyInfo()
    py_info2 = PyInfo()

    # check that they are all the same
    assert py_info1 == py_info2
    assert py_info1 is py_info2



# Generated at 2022-06-12 08:09:53.216853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(u'', PyInfo.string_types)

# Generated at 2022-06-12 08:09:59.415053
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.integer_types == ((int, long,) if PyInfo.PY2 else (int,))
    assert PyInfo.string_types == ((basestring,) if PyInfo.PY2 else (str,))
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.class_types == ((type, types.ClassType) if PyInfo.PY2 else (type,))



# Generated at 2022-06-12 08:10:05.865994
# Unit test for constructor of class PyInfo
def test_PyInfo():
    a = PyInfo()
    if PyInfo.PY2:
        assert a.PY2
        assert a.string_types
        assert a.text_type
        assert a.binary_type
        assert a.integer_types
        assert a.class_types
        assert a.maxsize
    elif a.PY3:
        assert a.PY3
        assert a.string_types
        assert a.text_type
        assert a.binary_type
        assert a.integer_types
        assert a.class_types
        assert a.maxsize
    else:
        raise AssertionError()

# Generated at 2022-06-12 08:10:15.298118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    try:
        limit = 1.1 << (1 << 31)
    except (NameError, OverflowError):
        assert PyInfo.maxsize == 2147483647
    else:
        assert PyInfo.maxsize == 9223372036854775807
        del limit



# Generated at 2022-06-12 08:10:24.816550
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import re
    import sys

    assert sys.version_info[0] == 2 or sys.version_info[0] == 3

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False

        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance(1, PyInfo.string_types) == False

        assert isinstance('', PyInfo.text_type) == False
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(1, PyInfo.text_type) == False

        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.binary_type) == False

# Generated at 2022-06-12 08:10:31.056992
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo().string_types, tuple)
    assert isinstance(PyInfo().text_type, type)
    assert isinstance(PyInfo().binary_type, type)
    assert isinstance(PyInfo().integer_types, tuple)
    assert isinstance(PyInfo().class_types, tuple)
    assert isinstance(PyInfo().maxsize, int)

# Generated at 2022-06-12 08:10:41.614272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2 = True if sys.version_info[0] == 2 else False
    # PY3 = True if sys.version_info[0] == 3 else False

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PyInfo.PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_

# Generated at 2022-06-12 08:10:48.024340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:52.788402
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:10:57.666442
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:11:07.084314
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert type("a") is PyInfo.text_type
        assert type(b"a") is PyInfo.binary_type
        assert maxsize > (1 << 63) - 1
    else:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance("a", PyInfo.string_types)
        assert type("a") is PyInfo.binary_type
        assert type(b"a") is PyInfo.binary_type
        assert maxsize == (1 << 31) - 1



# Generated at 2022-06-12 08:11:08.664545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:11:13.945649
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)


if __name__ == '__main__':
    import pytest

    pytest.main([__file__])

# Generated at 2022-06-12 08:11:17.781057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert "basestring" in dir(PyInfo)
    else:
        assert "basestring" not in dir(PyInfo)
# EOF

# Generated at 2022-06-12 08:11:27.747429
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)
    else:
        assert not isinstance(u'', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
    else:
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)




# Generated at 2022-06-12 08:11:29.502891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == bool(0) == (PyInfo.PY3 == bool(1))



# Generated at 2022-06-12 08:11:31.425600
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:38.981027
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types



# Generated at 2022-06-12 08:11:40.871608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (3 == sys.version_info[0])



# Generated at 2022-06-12 08:11:50.726320
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2

    if py2:
        assert PyInfo.python_version == "2"
    else:
        assert PyInfo.python_version == "3"

    assert PyInfo.string_types == (str,) if py2 else (str, bytes)
    assert isinstance("abc", PyInfo.string_types)

    assert PyInfo.integer_types == (int,) if py2 else (int, long)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:55.146713
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:12:02.045017
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:08.312236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:10.407874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-12 08:12:16.413771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:26.715920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import random

    # Make sure maxsize is correct in both versions
    if sys.maxsize != PyInfo.maxsize:
        raise AssertionError("Bad maxsize: %r != %r" % (
            sys.maxsize, PyInfo.maxsize))

    # Make sure maxsize is really the max for the data type
    for _ in range(100):
        value = random.randrange(1, PyInfo.maxsize)
        if value > PyInfo.maxsize:
            raise AssertionError(
                "maxsize is %r, but %r fits" % (
                    PyInfo.maxsize, value))
        if value < PyInfo.maxsize:
            break

# Generated at 2022-06-12 08:12:34.616918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance("test", PyInfo.string_types)
    assert isinstance("test", PyInfo.text_type)
    assert isinstance(b"test", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

    assert type(PyInfo.maxsize) == PyInfo.integer_types
    assert PyInfo.maxsize >= 1 << 63
    assert PyInfo.maxsize < (1 << 64)

# Generated at 2022-06-12 08:12:50.339075
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    print(pyinfo.PY3)
    print(pyinfo.PY2)
    print(pyinfo.string_types)
    print(pyinfo.integer_types)
    print(pyinfo.text_type)
    print(pyinfo.binary_type)
    print(pyinfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:54.654796
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test for class PyInfo"""
    # test the environment
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize > 0
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)



# Generated at 2022-06-12 08:13:03.139942
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    False
    >>> PyInfo.PY3
    True
    >>> PyInfo.string_types
    (str,)
    >>> PyInfo.text_type
    <class 'str'>
    >>> PyInfo.binary_type
    <class 'bytes'>
    >>> PyInfo.integer_types
    (<class 'int'>,)
    >>> PyInfo.class_types
    (<class 'type'>,)
    >>> PyInfo.maxsize > (1 << 63) - 1
    True
    """


if __name__ == '__main__':
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:13:05.855047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:13:13.117453
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        if sys.version_info >= (3, 3):
            m = sys.maxsize
        else:
            m = sys.maxint
        assert PyInfo.maxsize == m
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        m = sys.maxint
        assert PyInfo.maxsize == m
        assert PyInfo.string_types == (basestring,)
        assert Py

# Generated at 2022-06-12 08:13:18.181143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 or pi.PY3
    assert pi.string_types is not None
    assert pi.text_type is not None
    assert pi.binary_type is not None
    assert pi.integer_types is not None
    assert pi.class_types is not None
    assert pi.maxsize is not None

# Generated at 2022-06-12 08:13:28.291933
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test constructor of class PyInfo"""
    expected_output = """
The class PyInfo has the following attributes:
    PY2 = True
    PY3 = False
    class_types = (type, types.ClassType)
    binary_type = str
    integer_types = (int, long)
    maxsize = 9223372036854775807
    string_types = (basestring,)
    text_type = unicode
"""
    computed_output = StringIO()
    with redirect_stdout(computed_output):
        print("The class PyInfo has the following attributes:")
        for attr, value in pyinfo.__dict__.items():
            print("  {0} = {1}".format(attr, value))
    assert expected_output == computed_output.getvalue()

# Generated at 2022-06-12 08:13:39.902291
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test getter functions
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert PyInfo.PY3 == True or PyInfo.PY3 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert  isinstance(PyInfo.maxsize, int)

    # Test setter functions
    original_values = {}

# Generated at 2022-06-12 08:13:45.535834
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-12 08:13:49.039080
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("PY2: ", end='')
    print(PyInfo.PY2)

    print("PY3: ", end='')
    print(PyInfo.PY3)

# Generated at 2022-06-12 08:14:10.537682
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.maxsize
    assert PyInfo.string_types
    assert PyInfo.class_types

# Generated at 2022-06-12 08:14:18.404588
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _test_is_string(s):
        return isinstance(s, (PyInfo.binary_type, PyInfo.text_type))

    s = 'str'
    if PyInfo.PY2:
        assert isinstance(s, PyInfo.string_types) and not isinstance(s, PyInfo.text_type)
        assert isinstance(s, PyInfo.string_types) and isinstance(s, PyInfo.binary_type)
    else:
        assert not isinstance(s, PyInfo.string_types) and not isinstance(s, PyInfo.binary_type)
        assert isinstance(s, PyInfo.string_types) and isinstance(s, PyInfo.text_type)

    s = b'bytes'

# Generated at 2022-06-12 08:14:24.583717
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:14:27.439417
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:14:31.921876
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(5, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:38.901496
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3
    assert PyInfo.PY2 or not PyInfo.PY2
    assert PyInfo.PY3 or not PyInfo.PY3
    assert PyInfo.string_types != ()
    assert PyInfo.text_type != ()
    assert PyInfo.binary_type != ()
    assert PyInfo.integer_types != ()
    assert PyInfo.class_types != ()
    assert PyInfo.maxsize != ()



# Generated at 2022-06-12 08:14:47.528032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)

        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.string_types)

        assert isinstance('', PyInfo.text_type)
        assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.binary_type)

# Generated at 2022-06-12 08:14:52.587774
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:01.548618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    PY2 = sys.version_info[0] == 2
    PY3 = sys.version_info[0] == 3

    if PY3:
        assert PyInfo.PY2 == False
        assert PyInfo.PY3 == True
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert isinstance(PyInfo.maxsize, int)

    else:  # PY2
        assert PyInfo.PY2 == True
        assert PyInfo.PY3 == False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:15:06.428862
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert (info.PY2 == True) or (info.PY3 == True)


"""
Returns unicode string, even if input is not unicode.

In Python 3, it simply returns the string.
In Python 2, if the string is a str, then it tries to decode using UTF-8.
"""



# Generated at 2022-06-12 08:16:00.411873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    assert PyInfo.string_types and PyInfo.string_types[0] != None
    assert PyInfo.text_type and PyInfo.text_type != None
    assert PyInfo.binary_type and PyInfo.binary_type != None
    assert PyInfo.integer_types and PyInfo.integer_types[0] != None
    assert PyInfo.class_types and PyInfo.class_types[0] != None
    assert PyInfo.maxsize != None

    assert PyInfo.string_types[0] == ((PyInfo.PY2 and basestring) or str)

    assert (PyInfo.text_type == ((PyInfo.PY2 and unicode) or str))


# Generated at 2022-06-12 08:16:01.672523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:09.192775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert (isinstance(u"a", PyInfo.string_types) and
            isinstance("a", PyInfo.string_types))
    assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.text_type)
    assert not isinstance("a", PyInfo.text_type)
    assert isinstance("a", PyInfo.binary_type)
    assert not isinstance(u"a", PyInfo.binary_type)

# Generated at 2022-06-12 08:16:17.739618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert not isinstance("", PyInfo.class_types)

    assert not isinstance(b"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.class_types)

    assert not isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.class_types)


# Generated at 2022-06-12 08:16:24.749925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if isinstance(PyInfo.string_types, tuple):
        assert isinstance('str', PyInfo.string_types)

    if isinstance(PyInfo.integer_types, tuple):
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:34.653754
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == int((1 << 31) - 1)

# Generated at 2022-06-12 08:16:38.733578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == sys.version_info[0] == 2
    assert p.PY3 == sys.version_info[0] == 3
    assert p.integer_types == (int, long) if p.PY2 else (int,)
    assert p.string_types == (basestring,) if p.PY2 else (str,)
    assert p.text_type == unicode if p.PY2 else str
    assert p.binary_type == str if p.PY2 else bytes
    assert p.maxsize == sys.maxsize if p.PY3 else (
        (1 << 63) - 1 if (1 << 31) < sys.maxsize else (1 << 31) - 1
    )

# Generated at 2022-06-12 08:16:49.027255
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False

    assert isinstance('', PyInfo.string_types)
    assert isinstance(bytes(b''), PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
    else:
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)

    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:55.837570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert not isinstance(b"a", PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)
    assert not isinstance(object, PyInfo.class_types)
    assert isinstance(u"a", PyInfo.text_type)
    assert not isinstance(b"a", PyInfo.text_type)



# Generated at 2022-06-12 08:17:03.902447
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # If all assertions are successful, then the constructor of class PyInfo
    # works fine.
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.class_types)
    assert isinstance

# Generated at 2022-06-12 08:18:59.873236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

# Generated at 2022-06-12 08:19:01.475897
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


# Unit Test for function binary_type

# Generated at 2022-06-12 08:19:10.261217
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if sys.version_info[0] == 2:
        assert PyInfo.PY2
        assert not PyInfo.PY3
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        if sys.platform.startswith("java"):  # Jython
            assert PyInfo.maxsize == 2147483647
        else:  # CPython
            if sys.maxsize == 2147483647:
                assert PyInfo.maxsize == 2147483647
            else:  # 64 bit
                assert PyInfo.maxsize == 9223372036854775807
    else:
        assert not PyInfo.PY2

# Generated at 2022-06-12 08:19:19.970735
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    text_type = getattr(PyInfo, "text_type", None)
    if text_type is not None:
        assert isinstance("", text_type)

    binary_type = getattr(PyInfo, "binary_type", None)
    if binary_type is not None:
        assert isinstance("", binary_type)

    integer_types = getattr(PyInfo, "integer_types", None)
    if integer_types is not None:
        assert isinstance(0, integer_types)

    class_types = getattr(PyInfo, "class_types", None)

# Generated at 2022-06-12 08:19:31.222420
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2 is True or (PyInfo.PY3 is True and sys.version_info[0] == 3)
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert isinstance("str", PyInfo.text_type) is False
    assert isinstance(u"unicode", PyInfo.text_type)
    assert isinstance(b"bytes", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(long(1), PyInfo.integer_types)
    assert isinstance(dict, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)


test