

# Generated at 2022-06-12 08:09:37.862047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# Determine the name of the calling function

# Generated at 2022-06-12 08:09:41.834352
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test constructor of class PyInfo."""
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:09:49.095892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class Test(unittest.TestCase):
        def test_Python_version(self):
            self.assertTrue(PyInfo.PY3 ^ PyInfo.PY2)

        def test_string_types(self):
            self.assertTrue(isinstance("", PyInfo.string_types))

        def test_text_type(self):
            self.assertTrue(isinstance("", PyInfo.text_type))

        def test_integer_types(self):
            self.assertTrue(isinstance(1, PyInfo.integer_types))
            self.assertTrue(PyInfo.PY2 or isinstance(1, int))

        def test_class_types(self):
            self.assertTrue(isinstance(string_types, PyInfo.class_types))


# Generated at 2022-06-12 08:09:54.548398
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:09:56.448148
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


# Run unit tests
if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:06.035361
# Unit test for constructor of class PyInfo
def test_PyInfo():
    text_type = PyInfo.text_type
    string_types = PyInfo.string_types
    assert isinstance('xyz', text_type) and isinstance('', text_type)
    assert not isinstance(None, text_type)

    # Test for text_type.
    assert isinstance('xyz', text_type) and isinstance('', text_type)
    assert not isinstance(None, text_type)

    # Test for string_types.
    assert isinstance('xyz', string_types) and isinstance('', string_types)
    assert not isinstance(None, string_types)

    # Test for binary_type.
    assert isinstance(b'xyz', PyInfo.binary_type) and isinstance(b'', PyInfo.binary_type)

# Generated at 2022-06-12 08:10:12.742961
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert 'basestring' in str(PyInfo.string_types)
    else:
        assert PyInfo.string_types == (str,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:17.196892
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)



# Generated at 2022-06-12 08:10:24.621615
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (str, unicode)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode

    # maxsize is the theoretical maximum size of list, string, and
    # other container.  It is not necessarily the real maximum size
    # because the OS or Python may limit smaller values.  The OS
    # limit can be obtained as follows:
    #
    #   import resource
    #   resource.getrlimit(resource.RLIMIT_STACK)
    #
    # The Python limit can be obtai

# Generated at 2022-06-12 08:10:34.966155
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('#' * 50)
    print('# unit test for pyinfos.PyInfo')
    import sys
    import types

    assert PyInfo.PY2 is (sys.version_info[0] == 2)
    assert PyInfo.PY3 is (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == type
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode

# Generated at 2022-06-12 08:10:46.941939
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
        assert isinstance(long(1), PyInfo.integer_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert not isinstance('', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:56.404710
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert PyInfo.PY2 is not PyInfo.PY3

    assert issubclass(str, PyInfo.text_type)
    assert issubclass(bytes, PyInfo.binary_type)

    assert issubclass(str, PyInfo.string_types)
    assert issubclass(bytes, PyInfo.string_types)
    assert not issubclass(int, PyInfo.string_types)

    if PyInfo.PY2:
        assert issubclass(unicode, PyInfo.text_type)
        assert issubclass(unicode, PyInfo.string_types)

# Generated at 2022-06-12 08:11:07.225886
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test Python version
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test string_types
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    # Test text_type
    assert isinstance("a", PyInfo.text_type)
    assert not isinstance(b"a", PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

    # Test binary_type
    assert not isinstance("a", PyInfo.binary_type)

# Generated at 2022-06-12 08:11:17.828299
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_version = sys.version_info[0]

    if py_version == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False

        assert any(isinstance(e, PyInfo.string_types) for e in ('1', '2'))

        assert isinstance(PyInfo.text_type(''), unicode)
        assert isinstance(PyInfo.binary_type(''), str)

        assert any(isinstance(e, PyInfo.integer_types) for e in (1, 2))

        assert isinstance(int, PyInfo.class_types)
    else:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True

        assert any(isinstance(e, PyInfo.string_types) for e in ('1', '2'))

# Generated at 2022-06-12 08:11:25.253681
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_type(name, value):
        assert isinstance(value, tuple)
        for v in value:
            assert isinstance(v, type)

    test_type('string_types', PyInfo.string_types)
    test_type('integer_types', PyInfo.integer_types)
    test_type('class_types', PyInfo.class_types)
    assert isinstance(PyInfo.text_type(), str)
    assert isinstance(PyInfo.binary_type(), str)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:11:31.766197
# Unit test for constructor of class PyInfo
def test_PyInfo():
    o1 = PyInfo()
    o2 = PyInfo()
    assert not (o1 is o2)

    assert PyInfo.string_types == (str,) or PyInfo.string_types == (
        basestring,)

    assert (PyInfo.text_type == str) or (PyInfo.text_type == unicode)

    assert (PyInfo.binary_type == bytes) or (PyInfo.binary_type == str)

    assert (PyInfo.maxsize ==
            sys.maxsize) or (PyInfo.maxsize == int((1 << 31) - 1)) or (
                PyInfo.maxsize == int((1 << 63) - 1))


if __name__ == '__main__':
    test_PyInfo()
    # pytest.main()

# Generated at 2022-06-12 08:11:33.434918
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:11:41.105701
# Unit test for constructor of class PyInfo
def test_PyInfo():

    import six

    assert PyInfo.PY2 and not PyInfo.PY3
    assert PyInfo.string_types == (six.string_types,), "Failed to determine string types."
    assert PyInfo.maxsize == sys.maxsize
    assert PyInfo.text_type == six.text_type
    assert PyInfo.binary_type == six.binary_type
    assert PyInfo.integer_types == (six.integer_types,), "Failed to determine integer types."
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:11:47.776912
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert issubclass(info.string_types[0], str)
    assert isinstance(info.text_type(), str)
    assert isinstance(info.binary_type(), bytes)
    assert isinstance(info.integer_types[0], int)
    assert isinstance(info.class_types[0], type)

if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:50.069175
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:59.503799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> pyinfo.PY2
    False
    >>> pyinfo.PY3
    True
    >>> pyinfo.text_type
    <class 'str'>
    >>> pyinfo.binary_type
    <class 'bytes'>
    >>> pyinfo.integer_types
    (<class 'int'>,)
    >>> pyinfo.string_types
    (<class 'str'>,)
    >>> pyinfo.maxsize
    9223372036854775807
    """
    from doctest import testmod
    testmod()



# Generated at 2022-06-12 08:12:05.485407
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Only run on Python 3
    if PyInfo.PY2:
        return

    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == str
    assert type(PyInfo.binary_type) == bytes
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

# Generated at 2022-06-12 08:12:14.121751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import platform

    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(sys, PyInfo.class_types)

    if sys.maxsize > (1 << 32):
        assert PyInfo.maxsize > (1 << 32)
    if platform.python_implementation() == 'PyPy':
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:12:18.223466
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (2 ** 63) - 1

# Generated at 2022-06-12 08:12:21.530741
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

# Generated at 2022-06-12 08:12:28.675704
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', (str, basestring))
        assert isinstance(u'', (str, basestring))
        assert isinstance(u'', unicode)
        assert isinstance(b'', str)
    else:  # PY3
        assert isinstance('', str)
        assert isinstance(u'', str)
        assert isinstance(b'', bytes)

    assert isinstance(1, (int, long))
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, int)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(1, (int, long, object))
    assert isinstance(1, (int, long, PyInfo.integer_types, object))


# Generated at 2022-06-12 08:12:34.989856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY3 is True
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)
    assert isinstance(pyinfo.maxsize, int)

# Generated at 2022-06-12 08:12:40.991231
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo

    # check attribute type
    assert isinstance(info.string_types, tuple)
    assert isinstance(info.text_type, type)
    assert isinstance(info.binary_type, type)
    assert isinstance(info.integer_types, tuple)
    assert isinstance(info.class_types, tuple)

    # check boolean attribute
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)

    # check maxsize
    assert isinstance(info.maxsize, int)

# Generated at 2022-06-12 08:12:50.784010
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        assert isinstance('', (basestring,))
        assert not isinstance(u'', (str,))
        assert isinstance(1, (int, long))

# Generated at 2022-06-12 08:12:53.554911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert isinstance(PyInfo.string_types, tuple)

# Generated at 2022-06-12 08:13:09.373762
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:14.220785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.maxsize) is int

# Generated at 2022-06-12 08:13:20.009618
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:24.555125
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert type(PyInfo.maxsize) is long
    elif PyInfo.PY3:
        assert type(PyInfo.maxsize) is int


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:26.049119
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:13:32.835111
# Unit test for constructor of class PyInfo
def test_PyInfo():  # pragma: no cover
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    for a_type in PyInfo.string_types:
        assert isinstance(a_type, type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    for a_type in PyInfo.integer_types:
        assert isinstance(a_type, type)

    assert isinstance(PyInfo.class_types, tuple)
    for a_type in PyInfo.class_types:
        assert isinstance(a_type, type)


# Generated at 2022-06-12 08:13:39.377479
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:47.233014
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(object, PyInfo.class_types)
    assert 1 in PyInfo.integer_types


# Unit-test for class PyInfo
if __name__ == "__main__":
    import nose

    nose.main(defaultTest=__name__)

# Generated at 2022-06-12 08:13:51.215371
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:54.742145
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert isinstance(info.PY2, bool)
    assert isinstance(info.PY3, bool)
    assert isinstance(info.string_types, tuple)

# Generated at 2022-06-12 08:14:23.696042
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.binary_type)
    assert not isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.integer_types)

    assert isinstance(b"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.integer_types)

    assert not isinstance(u"", PyInfo.string_types)
    assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(u"", PyInfo.text_type)

# Generated at 2022-06-12 08:14:27.951705
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-12 08:14:33.912432
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY2 is False, "PyInfo.PY2 must be boolean"
    assert PyInfo.PY3 is True or PyInfo.PY3 is False, "PyInfo.PY3 must be boolean"
    assert PyInfo.PY2 != PyInfo.PY3, "PyInfo.PY2 and PyInfo.PY3 must be distinct"
    assert PyInfo.string_types is not None, "PyInfo.string_types must be defined"
    assert PyInfo.text_type is not None, "PyInfo.text_type must be defined"
    assert PyInfo.binary_type is not None, "PyInfo.binary_type must be defined"
    assert PyInfo.integer_types is not None, "PyInfo.integer_types must be defined"
    assert PyInfo

# Generated at 2022-06-12 08:14:43.044405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    from .ternary import Ternary

    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3
    if PyInfo.PY3:
        assert type(PyInfo.string_types) == tuple
        assert len(PyInfo.string_types) == 1 and PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert len(PyInfo.integer_types) == 1
        assert PyInfo.integer_types[0] == int
        assert PyInfo.class_types == type
        assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:14:50.183265
# Unit test for constructor of class PyInfo
def test_PyInfo():

    if PyInfo.PY2:
        assert isinstance('string', PyInfo.string_types)
        assert isinstance(u"unicode", PyInfo.string_types)

        assert isinstance(b"bytes", PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:53.093952
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info
    # noinspection PyTypeChecker
    assert isinstance(py_info.PY2, bool)
    # noinspection PyTypeChecker
    assert isinstance(py_info.PY3, bool)
    assert py_info.maxsize
    assert isinstance(py_info.maxsize, int)

# Generated at 2022-06-12 08:14:59.523692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY2 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:15:06.695368
# Unit test for constructor of class PyInfo
def test_PyInfo():
    with pytest.raises(AttributeError):
        PyInfo.test = 'test'

    assert PyInfo.PY2 == PyInfo.PY3 == False
    assert isinstance('test', PyInfo.string_types)
    assert 'test' == PyInfo.text_type('test')
    assert 'test' == PyInfo.binary_type(b'test')
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize == ((1 << 31) - 1)

# Generated at 2022-06-12 08:15:15.372567
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for PY2
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    # Test for PY3
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        # Test for string_types
        assert isinstance('test', PyInfo.string_types)
        # Test for text_type
        assert isinstance('test', PyInfo.text_type)
        # Test for binary_type
        assert isinstance(b'test', PyInfo.binary_type)
        # Test for integer_types
        assert isinstance(1, PyInfo.integer_types)
        # Test for class_types
        assert isinstance(int, PyInfo.class_types)
        # Test for maxsize

# Generated at 2022-06-12 08:15:19.405945
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:16:16.908458
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    if pi.PY2:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)
    else:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)

# Generated at 2022-06-12 08:16:26.951194
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (
        sys.version_info[0] == 2
    ), "The value of attribute PY2 is not consistent with the version of Python"
    assert PyInfo.PY3 == (
        sys.version_info[0] == 3
    ), "The value of attribute PY3 is not consistent with the version of Python"
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,), "The value of attribute string_types is not consistent with the version of Python"
        assert PyInfo.text_type == str, "The value of attribute text_type is not consistent with the version of Python"
        assert PyInfo.binary_type == bytes, "The value of attribute binary_type is not consistent with the version of Python"

# Generated at 2022-06-12 08:16:30.774687
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.binary_type == bytes
    assert p.PY3 == True
    p = PyInfo()
    assert p.integer_types == (int, long)
    assert p.PY3 == False

# Generated at 2022-06-12 08:16:33.344938
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-12 08:16:39.845467
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2 if PyInfo.PY2 else 1
    assert len(PyInfo.class_types) == 1 if PyInfo.PY2 else 2
    assert PyInfo.maxsize > 0



# Generated at 2022-06-12 08:16:48.018322
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class TestPyInfo(unittest.TestCase):
        pass

    global_namespace = globals().copy()
    local_namespace = {}
    for name in global_namespace:
        if name.startswith('test_'):
            test = global_namespace[name]
            if (isinstance(test, types.FunctionType)
                    and test.__name__ == name):
                test = staticmethod(test)
                setattr(TestPyInfo, name, test)
    del global_namespace
    del local_namespace
    unittest.main()

# Generated at 2022-06-12 08:16:53.253268
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-12 08:17:00.534801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(b'abc', PyInfo.binary_type)
    else:
        assert isinstance(u'abc'.encode('utf-8'), PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)

# Generated at 2022-06-12 08:17:02.831474
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0


# Decorator of function to print function arguments

# Generated at 2022-06-12 08:17:04.415981
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py = PyInfo()
    assert py.PY2 or py.PY3, "Cannot get python version"


test_PyInfo()

# Generated at 2022-06-12 08:19:06.728969
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-12 08:19:08.525374
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:19:16.172332
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert isinstance(i.PY2, bool)
    assert isinstance(i.PY3, bool)
    assert isinstance(i.string_types, tuple)
    assert isinstance(i.text_type, type)
    assert isinstance(i.binary_type, type)
    assert isinstance(i.integer_types, tuple)
    assert isinstance(i.class_types, tuple)
    assert isinstance(i.maxsize, int)


if __name__ == "__main__":
    pytest.main([__file__])

# Generated at 2022-06-12 08:19:23.325358
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('s') == PyInfo.string_types[0]
        assert type(u'u') == PyInfo.text_type
        assert type(b'b') == PyInfo.binary_type
        assert isinstance(2, PyInfo.integer_types)

# Generated at 2022-06-12 08:19:32.995274
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    assert sys.version_info[0] == 2 or sys.version_info[0] == 3
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)