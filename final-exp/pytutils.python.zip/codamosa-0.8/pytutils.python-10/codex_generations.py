

# Generated at 2022-06-12 08:09:40.049855
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> isinstance("", PyInfo.text_type)
    True
    >>> isinstance("", PyInfo.binary_type)
    False
    >>> isinstance("", PyInfo.string_types)
    True
    >>> isinstance(u"", PyInfo.string_types)
    True
    >>> isinstance(1, PyInfo.integer_types)
    True
    >>> isinstance(1L, PyInfo.integer_types)
    True
    >>> def f(): pass
    >>> isinstance(f, PyInfo.class_types)
    True
    >>> class C(object): pass
    >>> isinstance(C, PyInfo.class_types)
    True
    """

if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:09:48.203461
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:09:56.847266
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.maxsize) == int
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)

    if PyInfo.PY2:
        assert type(PyInfo.string_types[0]) == str
        assert type(PyInfo.text_type) == unicode
        assert type(PyInfo.binary_type) == str
        assert type(PyInfo.integer_types[0]) == int
        assert type(PyInfo.class_types[0]) == type

    if PyInfo.PY3:
        assert type(PyInfo.string_types[0]) == str

# Generated at 2022-06-12 08:10:06.286937
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
        assert isinstance(PyInfo.maxsize, int)
    elif PyInfo.PY3:
        assert isinstance(PyInfo.string_types, tuple)

# Generated at 2022-06-12 08:10:06.925681
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass



# Generated at 2022-06-12 08:10:17.868294
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == (sys.version_info[0] == 2))
    assert(PyInfo.PY3 == (sys.version_info[0] == 3))

    if sys.platform.startswith("java"):
        # Jython always uses 32 bits.
        assert(PyInfo.maxsize == int((1 << 31) - 1))
    else:
        # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
        class X(object):

            def __len__(self):
                return 1 << 31

        try:
            len(X())
        except OverflowError:
            # 32-bit
            assert(PyInfo.maxsize == int((1 << 31) - 1))

# Generated at 2022-06-12 08:10:24.564454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.PY2 == isinstance("", basestring)
    assert PyInfo.PY3 == isinstance("", str)

    assert PyInfo.PY2 == isinstance(u"", unicode)
    assert PyInfo.PY3 == isinstance(u"", str)

    assert PyInfo.PY2 == isinstance(123, (int, long))
    assert PyInfo.PY3 == isinstance(123, int)



# Generated at 2022-06-12 08:10:27.171033
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Just to see if it runs
    PyInfo()


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:36.694386
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert type(PyInfo.PY2) is bool
    assert not PyInfo.PY3
    assert type(PyInfo.PY3) is bool

    assert PyInfo.string_types == (basestring,)
    assert type(PyInfo.string_types) is tuple

    assert PyInfo.text_type is unicode
    assert type(PyInfo.text_type) is type

    assert PyInfo.binary_type is str
    assert type(PyInfo.binary_type) is type

    assert PyInfo.integer_types == (int, long)
    assert type(PyInfo.integer_types) is tuple

    assert PyInfo.class_types == (type, types.ClassType)
    assert type(PyInfo.class_types) is tuple

    assert PyInfo.maxsize == 92233

# Generated at 2022-06-12 08:10:46.572254
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)


# Generated at 2022-06-12 08:10:58.013757
# Unit test for constructor of class PyInfo
def test_PyInfo():
    expected_text_type = "unicode" if PyInfo.PY2 else "str"
    expected_binary_type = "str" if PyInfo.PY2 else "bytes"
    expected_integer_type = int
    expected_class_type = types.ClassType if PyInfo.PY2 else type
    expected_string_type = basestring if PyInfo.PY2 else str

    assert PyInfo.text_type == expected_text_type
    assert PyInfo.binary_type == expected_binary_type
    assert PyInfo.integer_types == (expected_integer_type, )
    assert PyInfo.class_types == (expected_class_type, )
    assert PyInfo.string_types == (expected_string_type, )


# Generated at 2022-06-12 08:11:04.908681
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert PyInfo.string_types == str
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == int
    assert PyInfo.class_types == type
    assert sys.maxsize == PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:09.440424
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)
    # assert PyInfo.PY2


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:14.039121
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert isinstance("2", PyInfo.string_types)
    assert isinstance(2, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:21.538695
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    Unit test for constructor of class PyInfo
    """
    assert PyInfo().PY2 is True
    assert PyInfo().PY3 is False
    assert PyInfo().string_types == (basestring,)
    assert PyInfo().text_type is unicode
    assert PyInfo().binary_type is str
    assert PyInfo().integer_types == (int, long)
    assert PyInfo().class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:11:30.328874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("test_PyInfo. Start.")
    assert PyInfo.PY2 or PyInfo.PY3
    print("PY_INFO.PY2 = {}".format(PyInfo.PY2))
    print("PY_INFO.PY3 = {}".format(PyInfo.PY3))
    print("PY_INFO.string_types = {}".format(PyInfo.string_types))
    print("PY_INFO.text_type = {}".format(PyInfo.text_type))
    print("PY_INFO.binary_type = {}".format(PyInfo.binary_type))
    print("PY_INFO.integer_types = {}".format(PyInfo.integer_types))
    print("PY_INFO.class_types = {}".format(PyInfo.class_types))

# Generated at 2022-06-12 08:11:37.530789
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)
    assert isinstance(p.string_types, tuple)
    assert isinstance(p.text_type, type)
    assert isinstance(p.binary_type, type)
    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.class_types, tuple)
    assert isinstance(p.maxsize, int)



# Generated at 2022-06-12 08:11:40.596095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:11:50.493411
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None
    assert PyInfo.PY2 is not None

    if PyInfo.PY3:
        assert 'type' in PyInfo.string_types
        assert 'str' in PyInfo.string_types
        assert 'bytes' in PyInfo.string_types
        assert 'unicode' not in PyInfo.string_types

        assert 'int' in PyInfo.integer_types
        assert 'long' not in PyInfo.integer_types

        assert 'type' in PyInfo.class_types
        assert 'classobj' not in PyInfo.class_types

        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.text_type)
    else:  # PY2
        assert 'type' in PyInfo.string_types
        assert 'str'

# Generated at 2022-06-12 08:11:58.383948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 is not PyInfo.PY3

    # test PY2
    if PyInfo.PY2:
        assert isinstance('str', PyInfo.string_types)
        assert isinstance(u'unicode', PyInfo.string_types)
        assert not isinstance(b'byte', PyInfo.string_types)
        assert isinstance('str', PyInfo.text_type)
        assert isinstance(u'unicode', PyInfo.text_type)
        assert not isinstance(b'byte', PyInfo.text_type)
        assert isinstance(b'byte', PyInfo.binary_type)
        assert not isinstance('str', PyInfo.binary_type)
        assert not isinstance(u'unicode', PyInfo.binary_type)

# Generated at 2022-06-12 08:12:10.142182
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2
    assert not info.PY3
    assert info.string_types == tuple([basestring])
    assert info.text_type == unicode
    assert info.binary_type == str
    assert info.integer_types == tuple([int, long])
    assert info.class_types == tuple([type, types.ClassType])


# Support for Python 2.7
if not hasattr(str, "format"):
    from string import Template

    class FormattedString(str):
        """
        A Template subclass that simply assumes that none of the placeholders
        are named, and substitutes them accordingly.
        """


# Generated at 2022-06-12 08:12:18.257304
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert len(PyInfo.__slots__) == 7
    assert PyInfo.maxsize != 0
    assert PyInfo.string_types == (str, ) if PyInfo.PY3 else (str, unicode)
    assert PyInfo.text_type == str if PyInfo.PY3 else unicode
    assert PyInfo.binary_type == bytes if PyInfo.PY3 else str
    assert PyInfo.integer_types == (int, ) if PyInfo.PY3 else (int, long)
    assert PyInfo.class_types == (type, ) if PyInfo.PY3 else (type, types.ClassType)


# TODO:
# test_PyInfo()

# Generated at 2022-06-12 08:12:21.940284
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.maxsize > 0


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:12:27.609778
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = (2, 7, 8, 'final', 0)
    sys.version_info = py2
    from pytoolbox.util.py_info import PyInfo
    assert PyInfo.PY2
    assert not PyInfo.PY3

    py3 = (3, 4, 2, 'final', 0)
    sys.version_info = py3
    from pytoolbox.util.py_info import PyInfo
    assert not PyInfo.PY2
    assert PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:36.443946
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Assert the following:
    #   1. sys.version_info[0] == 2, PY2 and PY3 are all True
    #   2. string_types, int_types and class_types are as expected
    #   3. maxsize is as expected
    assert (sys.version_info[0] == 2)
    assert (PyInfo.PY2 and PyInfo.PY3)
    assert (PyInfo.string_types == (basestring,))
    assert (PyInfo.integer_types == (int, long))
    assert (PyInfo.class_types == (type, types.ClassType))
    assert (PyInfo.maxsize == (1 << 31) - 1)



# Generated at 2022-06-12 08:12:38.018100
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.binary_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:49.346782
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types[0], type)

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)


# Definition of constants in module.
PY3 = PyInfo

# Generated at 2022-06-12 08:12:57.005067
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.class_types)
    else:  # PY3
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)

# Generated at 2022-06-12 08:13:03.928609
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-12 08:13:12.168822
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)

    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)
    assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance(u'', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)


# Generated at 2022-06-12 08:13:28.636925
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == basestring if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:38.616342
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.PY2, bool)
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(PyInfo.PY3, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:44.881856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    o = PyInfo()
    assert o.PY2 == (sys.version_info[0] == 2)
    assert o.PY3 == (sys.version_info[0] == 3)
    assert o.string_types == (basestring, ) if o.PY2 else (str,)
    assert o.binary_type is str or o.binary_type is bytes
    if not sys.platform.startswith("java"):
        assert o.integer_types == (int, long) if o.PY2 else (int, )
        assert o.maxsize == int((1 << 31) - 1) if o.PY2 else sys.maxsize


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:13:49.434731
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:13:58.178647
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:14:05.321131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert sys.maxsize == PyInfo.maxsize
    else:
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == (1 << 31) - 1
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):
                def __len__(self):
                    return 1 << 31

            try:
                len(X())
            except OverflowError:
                # 32-bit
                assert PyInfo.maxsize == (1 << 31) - 1
           

# Generated at 2022-06-12 08:14:13.105770
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(u"abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert issubclass(type(int), PyInfo.class_types)
        assert issubclass(type(type), PyInfo.class_types)
    else:
        assert isinstance("abc", PyInfo.string_types)
        assert not isinstance(u"abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert isinstance(b"abc", PyInfo.binary_type)

# Generated at 2022-06-12 08:14:15.138716
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

# Generated at 2022-06-12 08:14:22.996760
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    test_args = (
        'test string',
        True,
        False,
        None,
        0,
        1,
        2.0,
        '',
        [],
        (),
        {},
        set(),
        frozenset(),
        object,
        list,
        tuple,
        dict,
        set,
        frozenset,
    )

# Generated at 2022-06-12 08:14:28.462382
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Python version not recognized."
    if PyInfo.PY3:
        assert isinstance('', PyInfo.string_types), "String type error."
        assert isinstance(b'', PyInfo.binary_type), "Binary type error."
        assert isinstance(0, PyInfo.integer_types), "Integer type error."
        assert isinstance(lambda: 0, PyInfo.class_types), "Class type error."
    else:
        assert isinstance('', PyInfo.string_types), "String type error."
        assert isinstance(b'', PyInfo.binary_type), "Binary type error."
        assert isinstance(0, PyInfo.integer_types), "Integer type error."

# Generated at 2022-06-12 08:14:52.861491
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print((
        'PyInfo.PY2:', PyInfo.PY2, 'PyInfo.PY3:', PyInfo.PY3, 'maxsize:',
        PyInfo.maxsize, 'PyInfo.string_types:', PyInfo.string_types,
        'PyInfo.text_type:', PyInfo.text_type, 'PyInfo.binary_type:',
        PyInfo.binary_type, 'PyInfo.integer_types:', PyInfo.integer_types))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:59.563717
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert 'PY2' in PyInfo.__dict__
    assert 'PY3' in PyInfo.__dict__
    assert 'string_types' in PyInfo.__dict__
    assert 'text_type' in PyInfo.__dict__
    assert 'binary_type' in PyInfo.__dict__
    assert 'integer_types' in PyInfo.__dict__
    assert 'class_types' in PyInfo.__dict__
    assert 'maxsize' in PyInfo.__dict__
    assert PyInfo.PY2 ^ PyInfo.PY3 is True

# Generated at 2022-06-12 08:15:05.939766
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    import six

    assert PyInfo.text_type == six.text_type
    assert PyInfo.string_types == six.string_types
    assert PyInfo.class_types == six.class_types

    if PyInfo.PY3:
        assert PyInfo.binary_type == six.binary_type
        assert PyInfo.integer_types == six.integer_types
    else:
        assert PyInfo.maxsize == six.maxsize

# Generated at 2022-06-12 08:15:12.940964
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyquickhelper.loghelper import run_unittest
    import unittest

    class TestPyInfo(unittest.TestCase):

        def test_constructor(self):
            pyinf = PyInfo()
            assert 'PyInfo' in str(type(pyinf))

    unittest.main(module=__name__, argv=sys.argv, exit=False)


if __name__ == "__main__":
    import pyensae
    pyensae.fLOG(
        __file__,
        output="remark.txt" if sys.version_info[0] >= 3 else None)
    test_PyInfo()

# Generated at 2022-06-12 08:15:14.603993
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 and not PyInfo.PY3


# Unit test main function

# Generated at 2022-06-12 08:15:21.493963
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:30.371703
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type('abc') in PyInfo.string_types
        assert type(u'abc') == PyInfo.text_type
        assert type('abc') == PyInfo.binary_type
        assert type(1) in PyInfo.integer_types

# Generated at 2022-06-12 08:15:37.144420
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    for version in [2, 3]:
        if PyInfo.PY2:
            assert isinstance("", PyInfo.text_type)
            assert isinstance("", PyInfo.binary_type)
            assert not issubclass(unicode, str)
            assert not issubclass(str, unicode)
        else:
            assert isinstance("", PyInfo.text_type)
            assert isinstance(b"", PyInfo.binary_type)
            assert not issubclass(str, bytes)
            assert not issubclass(bytes, str)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:43.646842
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Can't recognize the version of Python interpreter"

    if PyInfo.PY3:
        assert isinstance(u'a', str)
        assert isinstance(b'a', bytes)
        assert isinstance(b'a'.decode('utf8'), str)
        assert isinstance(1, int)
        assert isinstance(int, type)
        assert isinstance(int(1), int)
        assert isinstance(PyInfo.maxsize, int)
        assert not isinstance(1, long)
        assert not isinstance(int, types.ClassType)
        assert not isinstance(int(1), long)
        assert not isinstance(1 << 63, int)
    else:  # PY2
        assert isinstance(u'a', unicode)
       

# Generated at 2022-06-12 08:15:49.155196
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    # Type checks
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:36.183721
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (PyInfo.PY3 is False)
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)

# Generated at 2022-06-12 08:16:43.692287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('test', PyInfo.string_types)
        assert isinstance(u'test', PyInfo.text_type)
        assert isinstance(u'test'.encode('utf-8'), PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(0, PyInfo.integer_types)
        assert not isinstance(object, PyInfo.class_types)
        assert isinstance(object, types.InstanceType)
        assert PyInfo.maxsize == (1 << 31) - 1
    else:  # PY3
        assert isinstance('test', PyInfo.string_types)
        assert isinstance('test', PyInfo.text_type)
        assert isinstance(b'test', PyInfo.binary_type)

# Generated at 2022-06-12 08:16:49.350273
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)



# Generated at 2022-06-12 08:16:52.662115
# Unit test for constructor of class PyInfo
def test_PyInfo():
    version_info = (2, 7, 2, 'final', 0)
    sys.version_info = version_info

    pyinfo = PyInfo()
    assert pyinfo.PY2, 'PY2 should be true.'
    assert not pyinfo.PY3, 'PY3 should be false.'



# Generated at 2022-06-12 08:17:00.847565
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert sys.version_info[0] == PyInfo.PY2 or sys.version_info[0] == PyInfo.PY3

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    if sys.version_info[0] == 2:
        assert isinstance(long(1), PyInfo.integer_types)
    else:
        assert not isinstance(type, PyInfo.integer_types)

    assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:17:01.917922
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:17:03.936905
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # pyInfo = PyInfo()
    # print(type(pyInfo))
    assert PyInfo.PY2
    assert PyInfo.PY3

# Generated at 2022-06-12 08:17:12.175223
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check that the attributes defined in the class are really there
    if PyInfo.PY3:
        assert 'string_types' in PyInfo.__dict__.keys()
        assert 'text_type' in PyInfo.__dict__.keys()
        assert 'binary_type' in PyInfo.__dict__.keys()
        assert 'integer_types' in PyInfo.__dict__.keys()
        assert 'class_types' in PyInfo.__dict__.keys()
        assert 'PY2' in PyInfo.__dict__.keys()
        assert 'PY3' in PyInfo.__dict__.keys()
        assert 'maxsize' in PyInfo.__dict__.keys()
    else:  # PY2
        assert 'string_types' in PyInfo.__dict__.keys()

# Generated at 2022-06-12 08:17:18.643481
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)

    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.string_types)
    else:  # PY3
        assert not isinstance(u"", PyInfo.string_types)

    assert isinstance(u"", PyInfo.text_type)

    assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(int(1), PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)

    assert PyInfo.maxsize >= (1 << 32)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:17:24.157369
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int if PyInfo.PY2 else int)



# Generated at 2022-06-12 08:19:18.832667
# Unit test for constructor of class PyInfo
def test_PyInfo():  # pragma: no cover
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isin

# Generated at 2022-06-12 08:19:24.723143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert type(PyInfo.maxsize) is int
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:19:34.521045
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert type(PyInfo.string_types[0]) == type
    assert len(PyInfo.integer_types) == 2
    assert type(PyInfo.integer_types[0]) == type
    assert type(PyInfo.integer_types[1]) == type
    assert len(PyInfo.class_types) == 2
    assert type(PyInfo.class_types[0]) == type
    assert type(PyInfo.class_types[1]) == type
    assert type(PyInfo.text_type()) == type(PyInfo.string_types[0]())
    assert type(PyInfo.binary_type()) == type(PyInfo.string_types[0]())