

# Generated at 2022-06-12 08:09:37.466339
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("foo", PyInfo.string_types)
        assert isinstance(b"foo", PyInfo.binary_type)
        assert isinstance(3, PyInfo.integer_types)
        assert issubclass(type, PyInfo.class_types)
        assert isinstance(3, PyInfo.integer_types)

# Generated at 2022-06-12 08:09:46.461798
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # String type
    if PyInfo.PY2:
        assert type("str") == str
        assert type("str".decode("UTF-8")) == unicode
    else:
        assert type("str") == str
        assert type("str".encode("UTF-8")) == bytes

    # Max size
    if PyInfo.PY2:
        if sys.platform.startswith("java"):
            # Jython always uses 32 bits.
            assert PyInfo.maxsize == int((1 << 31) - 1)
        else:
            # It's possible to have sizeof(long) != sizeof(Py_ssize_t).
            class X(object):
                def __len__(self):
                    return 1 << 31


# Generated at 2022-06-12 08:09:54.548831
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.maxsize > (1 << 31) - 1
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
    else:  # Python 2
        assert PyInfo.maxsize <= (1 << 31) - 1
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)


#
# The following functions are adapted from the urllib3 project.
# Source: https://github.com/urllib3/urllib3/blob/master/urllib3/packages/six.py
#


# Generated at 2022-06-12 08:10:00.436317
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


# Generated at 2022-06-12 08:10:07.841725
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('foo', PyInfo.string_types)
        assert not isinstance('foo', PyInfo.text_type)
        assert not isinstance(b'foo', PyInfo.string_types)
        assert not isinstance(b'foo', PyInfo.binary_type)
        assert not isinstance(0, PyInfo.integer_types)
        assert not isinstance(0, PyInfo.class_types)
    else:
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance('foo', PyInfo.text_type)
        assert isinstance(b'foo', PyInfo.string_types)
        assert isinstance(b'foo', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:18.568853
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert (PyInfo.string_types == (basestring,)
            ) == (sys.version_info[0] == 2)
    assert (PyInfo.text_type is unicode) == (sys.version_info[0] == 2)
    assert (PyInfo.binary_type is str
            ) == (sys.version_info[0] == 2)
    assert (PyInfo.integer_types == (int, long)) == (sys.version_info[0] == 2)
    assert (PyInfo.class_types == (type, types.ClassType)
            ) == (sys.version_info[0] == 2)

# Generated at 2022-06-12 08:10:26.453776
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Testing for namespace '__builtin__'
    assert 'TypeError' in dir(__builtins__)

    # Testing for object '__builtin__'
    assert type(__builtins__) is types.ModuleType

    # Testing for object '__builtins__.basestring'
    assert type(__builtins__.basestring) is type

    # Testing for object '__builtins__.TypeError'
    assert type(__builtins__.TypeError) is type

    # Testing for namespace 'sys'
    assert 'exc_info' in dir(sys)

    # Testing for method 'sys.exc_info'
    assert type(sys.exc_info) is types.MethodType

    # Testing for object 'sys'
    assert type(sys) is types.ModuleType



# Generated at 2022-06-12 08:10:30.829591
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3  # Should be running on python 3
    assert isinstance("", PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)


# Test method of class PyInfo

# Generated at 2022-06-12 08:10:38.780229
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Unsupported python version"
    assert PyInfo.text_type is not bytes and PyInfo.text_type is not str, \
        "text_type should be str in Python 3, and unicode in Python 2"
    assert PyInfo.string_types is not str and PyInfo.string_types is not unicode, \
        "string_types should be a tuple"
    assert isinstance(u"", PyInfo.text_type), "text_type must be a sub class of str"
    assert not isinstance(1, PyInfo.string_types), "string_types must be a class of str"

# Generated at 2022-06-12 08:10:48.001852
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("unicode_string", PyInfo.string_types)
    assert isinstance("unicode_string", PyInfo.text_type)
    assert not isinstance("unicode_string", PyInfo.binary_type)
    assert isinstance("ascii_string", PyInfo.string_types)
    assert isinstance("ascii_string", PyInfo.binary_type)
    assert not isinstance("ascii_string", PyInfo.text_type)
    assert isinstance(b"binary_string", PyInfo.binary_type)
    assert isinstance(b"binary_string", PyInfo.string_types)
    assert not isinstance(b"binary_string", PyInfo.text_type)
    assert isinstance(u"unicode_string", PyInfo.string_types)

# Generated at 2022-06-12 08:10:58.824771
# Unit test for constructor of class PyInfo
def test_PyInfo():
    t = PyInfo()
    assert isinstance(t.PY2, bool)
    assert isinstance(t.PY3, bool)
    assert isinstance(t.string_types, tuple)
    assert issubclass(t.string_types[0], object)
    assert isinstance(t.text_type, object)
    assert issubclass(t.binary_type, object)
    assert isinstance(t.integer_types, tuple)
    assert issubclass(t.integer_types[0], object)
    assert isinstance(t.class_types, tuple)
    assert issubclass(t.class_types[0], object)
    assert isinstance(t.maxsize, int)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:03.152079
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:05.662485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-12 08:11:09.241499
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None



# Generated at 2022-06-12 08:11:11.240590
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert not (PyInfo.PY3 and PyInfo.PY2)

# Generated at 2022-06-12 08:11:22.395342
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:29.967204
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> assert PyInfo.PY2 or PyInfo.PY3
    >>> assert isinstance('abc', PyInfo.string_types)
    >>> assert isinstance(u'abc', PyInfo.string_types)
    >>> assert isinstance(b'', PyInfo.binary_type)
    >>> assert isinstance(100, PyInfo.integer_types)
    >>> assert isinstance(100L, PyInfo.integer_types)
    >>> assert isinstance(type, PyInfo.class_types)
    >>> assert isinstance(Exception, PyInfo.class_types)
    """


if __name__ == '__main__':
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:11:31.607905
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo



# Generated at 2022-06-12 08:11:42.256844
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check PY2 and PY3
    assert PyInfo.PY2 != PyInfo.PY3

    # Check string_types
    assert isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.string_types)
    assert not isinstance(42, PyInfo.string_types)

    # Check text_type
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    # Check binary_type
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)

    # Check integer_types
    assert isinstance(42, PyInfo.integer_types)
    assert not isinstance("", PyInfo.integer_types)

    # Check class_types

# Generated at 2022-06-12 08:11:49.875757
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True and PyInfo.PY3 == False) or \
           (PyInfo.PY2 == False and PyInfo.PY3 == True)
    assert str in PyInfo.string_types
    assert unicode in PyInfo.string_types
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert int in PyInfo.integer_types
    assert isinstance(PyInfo.maxsize, (int, long))
    assert type in PyInfo.class_types
    assert types.ClassType in PyInfo.class_types

# Generated at 2022-06-12 08:11:59.730057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)
    assert isinstance(u"a", PyInfo.string_types)
    assert isinstance(b"a", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:08.312195
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.class_types[0], type)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types[0])

# Generated at 2022-06-12 08:12:11.899793
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        # noinspection PyUnresolvedReferences
        assert callable(PyInfo.__init__)
    except AssertionError as e:
        print()
        print("    " + str(e))

# Generated at 2022-06-12 08:12:20.198259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test_pyinfo(result):
        if sys.platform.startswith("java"):
            assert (
                result.maxsize == int((2 ** 31) - 1)
            ), "Unit test for PyInfo is failed!"
        else:
            assert result.maxsize == sys.maxsize, "Unit test for PyInfo is failed!"

        assert (
            type(result.string_types[0]) == str
        ), "Unit test for PyInfo is failed!"
        assert result.text_type == str, "Unit test for PyInfo is failed!"
        assert result.binary_type == bytes, "Unit test for PyInfo is failed!"
        assert (
            type(result.integer_types[0]) == int
        ), "Unit test for PyInfo is failed!"

# Generated at 2022-06-12 08:12:25.550268
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2
    assert not pyinfo.PY3

# Generated at 2022-06-12 08:12:30.209241
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance(PyInfo.maxsize, int)
    else:
        assert isinstance(PyInfo.maxsize, long)

# Generated at 2022-06-12 08:12:36.281976
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(3, PyInfo.integer_types)

# Generated at 2022-06-12 08:12:39.930259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.maxsize) == int
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.PY2) == bool

# Generated at 2022-06-12 08:12:51.295620
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:12:55.965645
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type is bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == 9223372036854775807


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:13:12.960323
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test maxsize
    if sys.maxsize == 9223372036854775807:
        assert PyInfo.maxsize == 9223372036854775807
    else:
        assert PyInfo.maxsize == 2147483647

    # test PY2
    assert type(PyInfo.PY2) is bool
    assert PyInfo.PY2 is False

    # test PY3
    assert type(PyInfo.PY3) is bool
    assert PyInfo.PY3 is True

    # test string_types
    assert type(PyInfo.string_types) is tuple
    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] is str

    # test text_type
    assert PyInfo.text_type is str

    # test binary_type
   

# Generated at 2022-06-12 08:13:18.081383
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2
    assert PyInfo.maxsize == (1 << 31) - 1


# TODO: Refactor it to use pytest.
if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:27.383471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types is not None
    assert "basestring" in PyInfo.string_types or "str" in PyInfo.string_types
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert "int" in PyInfo.integer_types or "long" in PyInfo.integer_types
    assert PyInfo.class_types is not None
    assert "type" in PyInfo.class_types or "types.ClassType" in PyInfo.class_types
    assert PyInfo.maxsize is not None
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:33.289435
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') not in PyInfo.string_types
        assert type('') is not PyInfo.text_type
        assert type(u'') is PyInfo.text_type
        assert type(b'') is PyInfo.binary_type
        assert type('') is not PyInfo.binary_type
        assert type(u'') is not PyInfo.binary_type
        assert type(b'') is PyInfo.binary_type
        assert type(1) in PyInfo.integer_types

# Generated at 2022-06-12 08:13:41.149160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance(u's', PyInfo.text_type)
        assert isinstance(b's', PyInfo.binary_type)
        assert 1 in PyInfo.integer_types
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance('s', PyInfo.string_types)
        assert isinstance('s', PyInfo.text_type)
        assert isinstance(b's', PyInfo.binary_type)
        assert 1 in PyInfo.integer_types
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:13:47.044345
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize == sys.maxsize or PyInfo.maxsize == 2147483647 or PyInfo.maxsize == 9223372036854775807, \
        "The value of maxsize of PyInfo is not correct"


# Decorator to unit test function using input and expected output

# Generated at 2022-06-12 08:13:52.665236
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test string_types
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)

    # test integer_types
    assert isinstance(1, PyInfo.integer_types)
    if not PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)

    # test class_types
    assert isinstance(PyInfo, PyInfo.class_types)



# Generated at 2022-06-12 08:13:54.231242
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


test_PyInfo()

# Generated at 2022-06-12 08:13:58.957859
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-12 08:14:03.109960
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:14:28.845670
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check constructor of class PyInfo
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:14:30.806036
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.PY2 == (sys.version_info[0] == 2)

# Generated at 2022-06-12 08:14:40.538265
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert PyInfo.PY2 == True, "You should be using Python 2.7"
    except:
        raise Exception("Python 2.7 required")
    try:
        assert PyInfo.PY3 == False, "You should be using Python 2.7"
    except:
        raise Exception("Python 2.7 required")

    try:
        assert type(PyInfo.string_types) == tuple, "PyInfo.string_types should be a tuple"
    except:
        raise Exception("PyInfo.string_types is not a tuple")
    try:
        assert type(PyInfo.text_type) == str, "PyInfo.text_type should be a string"
    except:
        raise Exception("PyInfo.text_type is not a string")

# Generated at 2022-06-12 08:14:48.445570
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # Py3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-12 08:14:48.941482
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass

# Generated at 2022-06-12 08:14:57.219491
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance('', PyInfo.string_types)
    assert isinstance('test', PyInfo.string_types)
    assert isinstance(u'test', PyInfo.string_types)
    assert not isinstance(b'test', PyInfo.string_types)

    assert isinstance('test', PyInfo.text_type)
    assert isinstance(u'test', PyInfo.text_type)
    assert not isinstance(b'test', PyInfo.text_type)

    assert isinstance(b'test', PyInfo.binary_type)
    assert isinstance('test', PyInfo.binary_type)
    assert not isinstance(u'test', PyInfo.binary_type)

    assert isinstance(10, PyInfo.integer_types)
    assert isinstance

# Generated at 2022-06-12 08:15:07.153739
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class A(object):

        def __str__(self):
            return "str"

        def __unicode__(self):
            return "unicode"

    class B(object):

        def __str__(self):
            return "str"

        def __bytes__(self):
            return "bytes"

    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert PyInfo.string_types is PyInfo.string_types
    assert type(A()) is not PyInfo.string_types
    assert issubclass(type(A()), PyInfo.string_types)
    assert isinstance(A(), PyInfo.string_types)
    assert u'abc' is PyInfo.text_type

# Generated at 2022-06-12 08:15:12.719418
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

# Generated at 2022-06-12 08:15:20.301032
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.maxsize == sys.maxsize
    else:  # PyInfo.PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize >= sys.maxsize

# Generated at 2022-06-12 08:15:29.331005
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class C(object):
        pass

    class D(C):
        pass

    class TestPyInfo(unittest.TestCase):
        def test_class_types(self):
            self.assertTrue(issubclass(PyInfo.class_types, tuple))
            self.assertTrue(type in PyInfo.class_types)
            self.assertTrue(type in PyInfo.class_types)
            self.assertTrue(type(C) in PyInfo.class_types)
            self.assertFalse(C in PyInfo.class_types)
            self.assertFalse(D in PyInfo.class_types)

        def test_string_types(self):
            self.assertTrue(issubclass(PyInfo.string_types, tuple))

# Generated at 2022-06-12 08:16:19.832780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyinfo import PyInfo
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)

# Generated at 2022-06-12 08:16:25.551874
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 2
    assert PyInfo.PY3 == 3

    assert PyInfo.string_types == (basestring, )
    assert PyInfo.text_type == text_type
    assert PyInfo.binary_type == binary_type
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, )

    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:16:28.623679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY2:
        assert (32, sys.maxsize) == (32, info.maxsize)
    else:
        assert (64, sys.maxsize) == (64, info.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:31.304783
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test constructor of class PyInfo
    assert PyInfo.PY2 is sys.version_info[0] == 2
    assert PyInfo.PY3 is sys.version_info[0] == 3

# Generated at 2022-06-12 08:16:36.904677
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(PyInfo.text_type(""), PyInfo.string_types[0])
    assert isinstance(PyInfo.binary_type(""), PyInfo.string_types[0])
    assert isinstance(PyInfo.integer_types[0](), int)
    assert isinstance(PyInfo.class_types[0](), type)
    assert isinstance(PyInfo.maxsize, int)


test_PyInfo()

# Generated at 2022-06-12 08:16:39.259546
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2, "wrong PY2"
    assert not PyInfo.PY3, "wrong PY3"



# Generated at 2022-06-12 08:16:49.507448
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # type: () -> None
    """Tests for constructor of class PyInfo."""

    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)

    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(u"", PyInfo.string_types[0])

# Generated at 2022-06-12 08:16:57.039217
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test PY2
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types[0] is basestring
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert len(PyInfo.integer_types) == 2
    assert PyInfo.integer_types[0] is int
    assert PyInfo.integer_types[1] is long
    assert len(PyInfo.class_types) == 2
    assert PyInfo.class_types[0] is type
    assert PyInfo.class_types[1] is types.ClassType
    assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-12 08:17:04.519402
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Python version: " + sys.version)
    print("Python 2: %d, Python 3: %d" % (PyInfo.PY2, PyInfo.PY3))
    print("maxsize: %d" % PyInfo.maxsize)
    print("string_types: %s" % PyInfo.string_types)
    print("text_type: %s" % PyInfo.text_type)
    print("binary_type: %s" % PyInfo.binary_type)
    print("integer_types: %s" % PyInfo.integer_types)
    print("class_types: %s" % PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:17:10.295625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('hello', PyInfo.string_types)
        assert isinstance(u'hello', PyInfo.text_type)
        assert isinstance('hello', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
    else:  # PY3
        assert isinstance('hello', PyInfo.string_types)
        assert isinstance('hello', PyInfo.text_type)
        assert isinstance(b'hello', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:19:14.871355
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class MyClass(object):
        pass

    my_class = MyClass()
    # Boolean
    assert isinstance(True, PyInfo.integer_types) == PyInfo.PY2
    assert isinstance(True, PyInfo.integer_types) is (not PyInfo.PY3)
    assert isinstance(True, PyInfo.class_types) == PyInfo.PY3
    assert isinstance(True, PyInfo.class_types) is (not PyInfo.PY2)
    # String
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    # List
    assert isinstance([], PyInfo.string_types) is False
    assert isinstance([], PyInfo.text_type) is False

# Generated at 2022-06-12 08:19:22.696367
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import raises
    from io import BytesIO

    assert PyInfo.PY2 or PyInfo.PY3

    s = "hello, world"
    b = b"hello, world"
    u = u"hello, world"  # PY2: unicode string
    i = 1

    print("Text type:", PyInfo.text_type)
    print("String types:", PyInfo.string_types)
    print("Binary types:", PyInfo.binary_type)
    print("Integer types:", PyInfo.integer_types)
    print("Class types:", PyInfo.class_types)

    assert isinstance(s, PyInfo.string_types)
    assert isinstance(b, PyInfo.binary_type)
    assert isinstance(u, PyInfo.string_types)

# Generated at 2022-06-12 08:19:24.456509
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo(), object)

