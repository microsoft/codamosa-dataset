

# Generated at 2022-06-12 08:09:40.378435
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:09:43.796626
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert not isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.string_types)
    else:
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:09:46.186423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert isinstance(pyinfo.maxsize, int)
    assert isinstance(pyinfo.PY2, bool)
    assert isinstance(pyinfo.PY3, bool)



# Generated at 2022-06-12 08:09:48.649476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:09:52.905848
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test all fields
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("s", PyInfo.string_types)
    assert isinstance("s".encode(), PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)



# Generated at 2022-06-12 08:09:57.469355
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if info.PY2:
        assert type(u'abc') == info.text_type
    else:
        assert type('abc') == info.text_type

    if info.PY2:
        assert type(b'abc') == info.binary_type
    else:
        assert type(bytes([97, 98, 99])) == info.binary_type


# Should be removed when Python 2 support is removed
try:
    unicode
except NameError:
    unicode = str

# Generated at 2022-06-12 08:10:04.478548
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (basestring, ) if PyInfo.PY2 else (str, )
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int, )
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type, )

# Generated at 2022-06-12 08:10:14.983578
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check that all constants are the expected types
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

    # Check that the PY2 and PY3 constants are not the same
    assert PyInfo.PY2 ^ PyInfo.PY3

    # Check that the PY2 constant is true if and only if
    # the major version of sys.version_info is 2

# Generated at 2022-06-12 08:10:24.224754
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Unit test for class PyInfo")
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert isinstance(PyInfo.maxsize, (int, long))
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:10:30.741005
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:37.536694
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    # test that the contents of PY2 and PY3 make sense:
    assert sys.version_info[0] == 2 and PyInfo.PY2
    assert sys.version_info[0] == 3 and PyInfo.PY3

# Generated at 2022-06-12 08:10:43.409977
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 63) - 1

# Generated at 2022-06-12 08:10:53.608529
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.PY2, bool)  # type: ignore
    assert isinstance(PyInfo.PY3, bool)  # type: ignore
    assert PyInfo.PY2 != PyInfo.PY3  # type: ignore
    assert isinstance(PyInfo.string_types, tuple)  # type: ignore
    assert isinstance(PyInfo.text_type, type)  # type: ignore
    assert isinstance(PyInfo.binary_type, type)  # type: ignore
    assert isinstance(PyInfo.integer_types, tuple)  # type: ignore
    assert isinstance(PyInfo.class_types, tuple)  # type: ignore
    assert isinstance(PyInfo.maxsize, int)  # type: ignore

# Generated at 2022-06-12 08:10:54.524444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo



# Generated at 2022-06-12 08:10:58.247373
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2 and PyInfo.PY3
    assert PyInfo.text_type is str
    assert PyInfo.integer_types is int
    assert PyInfo.class_types is type
    assert PyInfo.maxsize == (1 << 63) - 1


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:11:08.531932
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import platform

    print("Python version %s %s %s" % (platform.python_implementation(), platform.python_version(), platform.python_compiler()))
    if PyInfo.PY2:
        assert issubclass(str, PyInfo.string_types)
        assert isinstance("hi", PyInfo.string_types)
        assert isinstance(u"hi", PyInfo.string_types)
        assert isinstance(u"hi", PyInfo.text_type)
        assert not (isinstance("hi", PyInfo.binary_type))
        assert isinstance(-1, PyInfo.integer_types)
        assert isinstance(5, PyInfo.integer_types)
        assert isinstance(long(5), PyInfo.integer_types)
        assert isinstance(long(-5), PyInfo.integer_types)

# Generated at 2022-06-12 08:11:19.289612
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    # Test for constructor of class PyInfo
    assert PyInfo.PY2 != PyInfo.PY3
    assert type(PyInfo.PY2) is bool
    assert type(PyInfo.PY3) is bool
    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
    elif sys.version_info[0] == 3:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
    # Test for integer_types
    assert type(1) in PyInfo.integer_types

# Generated at 2022-06-12 08:11:28.981376
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:38.758498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.string_types)
        assert isinstance('', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.string_types)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(u'', PyInfo.text_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0, PyInfo.class_types)



# Generated at 2022-06-12 08:11:43.106512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize



# Generated at 2022-06-12 08:11:56.527868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test for constructor of class PyInfo"""
    if not PyInfo.PY2:
        assert PyInfo.PY3 is True
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
    else:
        assert PyInfo.PY2 is True
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

    assert type("") in PyInfo.string_types
    assert type(u"") in PyInfo.string_types
    assert type(b"") in PyInfo.string_types


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:11:58.831075
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:12:04.181508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)


if __name__ == "__main__":
    import test_snippet

    if test_snippet.need_run(globals(), __file__):
        test_snippet.run(globals())

# Generated at 2022-06-12 08:12:05.004190
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3



# Generated at 2022-06-12 08:12:14.572417
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert isinstance(u'abc', PyInfo.string_types)
        assert isinstance('abc', PyInfo.binary_type)

# Generated at 2022-06-12 08:12:16.178173
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _ = PyInfo()
    _ = PyInfo.maxsize

test_PyInfo()

# Generated at 2022-06-12 08:12:21.947341
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b'a', PyInfo.string_types)
        assert isinstance(u'a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert not isinstance(u'a', PyInfo.binary_type)
        assert isinstance(u'a', PyInfo.text_type)
        assert not isinstance(b'a', PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
    else:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(u'a', PyInfo.text_type)


# Generated at 2022-06-12 08:12:26.237945
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.string_types is basestring
    assert PyInfo.text_type is unicode
    assert PyInfo.binary_type is str
    assert PyInfo.integer_types is (int, long)
    assert PyInfo.class_types is (type, types.ClassType)
    assert PyInfo.maxsize is (1 << 31) - 1



# Generated at 2022-06-12 08:12:31.703866
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


# Unit test

# Generated at 2022-06-12 08:12:37.750915
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
    else:
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)

    assert isinstance("", PyInfo.text_type)
    assert isi

# Generated at 2022-06-12 08:12:50.338708
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.class_types

# Generated at 2022-06-12 08:12:53.312287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert sys.version_info[0] == 2


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:12:54.227193
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True

# Generated at 2022-06-12 08:12:58.527057
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert PyInfo.string_types == (str, )
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int, )
    assert PyInfo.class_types == (type, )
    assert PyInfo.maxsize == 2147483647

# Generated at 2022-06-12 08:13:05.617584
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print("Py2:", PyInfo.PY2)
    print("Py3:", PyInfo.PY3)
    print('string_types:', PyInfo.string_types)
    print('text_type:', PyInfo.text_type)
    print('binary_type:', PyInfo.binary_type)
    print('integer_types:', PyInfo.integer_types)
    print('class_types:', PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:13.053038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print()
    print("Testing PyInfo():")

    print("PyInfo.PY2 = ", PyInfo.PY2)
    print("PyInfo.PY3 = ", PyInfo.PY3)

    print("PyInfo.string_types = ", PyInfo.string_types)
    print("PyInfo.text_type = ", PyInfo.text_type)
    print("PyInfo.binary_type = ", PyInfo.binary_type)
    print("PyInfo.integer_types = ", PyInfo.integer_types)
    print("PyInfo.class_types = ", PyInfo.class_types)
    print("PyInfo.maxsize = ", PyInfo.maxsize)

    # Test check_type()

# Generated at 2022-06-12 08:13:22.553287
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PyInfo.PY2 = sys.version_info[0] == 2
    # PyInfo.PY3 = sys.version_info[0] == 3
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY2:
        # PyInfo.string_types = basestring,
        # PyInfo.text_type = unicode
        # PyInfo.binary_type = str
        # PyInfo.integer_types = (int, long)
        # PyInfo.class_types = (type, types.ClassType)
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type

# Generated at 2022-06-12 08:13:30.237765
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool

    py2 = not PyInfo.PY2

    if py2:
        assert PyInfo.maxsize > 0
        assert type(PyInfo.maxsize) == int

    for attr in (
        "string_types",
        "text_type",
        "binary_type",
        "integer_types",
        "class_types",
    ):
        assert type(getattr(PyInfo, attr)) == tuple



# Generated at 2022-06-12 08:13:37.447560
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:44.251405
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type) is False
    assert isinstance(u'a', PyInfo.text_type) is False
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-12 08:14:07.537809
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True
    assert PyInfo.PY2 is False
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize == sys.maxsize

# Generated at 2022-06-12 08:14:12.520012
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    ::

        PyInfo()
        from tdda.constraints.pycompat import PyInfo
        PyInfo.PY2   # is it Python 2?
        PyInfo.PY3   # is it Pythub 3?
        PyInfo.string_types    # sequence of string types
        PyInfo.text_type       # string type
        PyInfo.binary_type     # bytes type
        PyInfo.integer_types   # sequence of integer types
        PyInfo.maxsize         # maximum integer size
    """



# Generated at 2022-06-12 08:14:20.182530
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Overwrite PyInfo class variable string_types by converting a string to tuple
    # to check if it is converted back to tuple by class variable PY2 reflecting correct
    # python version number
    if sys.version_info[0] == 2:
        PyInfo.string_types = "abcd"
    else:
        PyInfo.string_types = [2, 3]
    # Overwrite PyInfo class variable binary_type by converting a string to tuple
    # to check if it is converted back to tuple by class variable PY3 reflecting correct
    # python version number
    if sys.version_info[0] == 3:
        PyInfo.binary_type = "abcd"
    else:
        PyInfo.binary_type = [2, 3]
    # Overwrite PyInfo class variable integer_types by converting a string to tuple
    # to

# Generated at 2022-06-12 08:14:21.337001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:23.416734
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import pytest

    with pytest.raises(AttributeError):
        PyInfo.PY1

    with pytest.raises(AttributeError):
        PyInfo.PY4



# Generated at 2022-06-12 08:14:24.482363
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:14:30.863625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:14:40.289498
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not PyInfo.PY2
    assert PyInfo.PY2 is (not PyInfo.PY3)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance('', PyInfo.string_types)
    assert not isinstance(b'', PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(list, PyInfo.class_types)

# Generated at 2022-06-12 08:14:48.510023
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type('') in PyInfo.string_types
        assert type(b'') in PyInfo.string_types
        assert type(b'') not in PyInfo.text_type
    else:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types


PY3 = PyInfo.PY3
PY2 = PyInfo.PY2
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types

if PY3:
    from io import StringIO

    from functools import reduce

    from itertools import zip_longest



# Generated at 2022-06-12 08:14:56.717259
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is True

    # ? Python 3 has two integer type: int and long, but seems long is not
    # exists now
    assert type(-1) in PyInfo.integer_types

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)

    assert isinstance(u'', PyInfo.text_type)
    assert not isinstance('', PyInfo.text_type)
    assert isinstance(1, PyInfo.text_type)

    assert isinstance(b'', PyInfo.binary_type)
    assert not isinstance('', PyInfo.binary_type)
    assert not isinstance(1, PyInfo.binary_type)


# Generated at 2022-06-12 08:15:44.005227
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == 2
    assert pyinfo.PY3 == 3
    assert pyinfo.string_types == (str,)
    assert pyinfo.text_type == str
    assert pyinfo.binary_type == bytes
    assert pyinfo.integer_types == (int,)
    assert pyinfo.class_types == (type,)
    assert pyinfo.maxsize == 9223372036854775807



# Generated at 2022-06-12 08:15:45.995307
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    print("test_PyInfo() is success.")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:15:53.376063
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test for Py2
    os.environ["PYTHON"] = "Python2"
    if "Python2" in os.environ.get("PYTHON"):
        print(sys.version_info)
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert isinstance(1, PyInfo.integer_types) is True
        assert isinstance("", PyInfo.string_types) is True

    # Test for Py3
    os.environ["PYTHON"] = "Python3"
    if "Python3" in os.environ.get("PYTHON"):
        print(sys.version_info)
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True

# Generated at 2022-06-12 08:15:59.849423
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        return
    
    assert isinstance("foo", PyInfo.string_types)
    assert isinstance(u"foo", PyInfo.string_types)

    assert isinstance("foo", PyInfo.binary_type)
    assert not isinstance(u"foo", PyInfo.binary_type)

    assert not isinstance("foo", PyInfo.text_type)
    assert isinstance(u"foo", PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1.0, PyInfo.integer_types)

    assert isinstance(int, PyInfo.class_types)
    assert not isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:16:04.978982
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PyInfo should be a singleton
    assert PyInfo() is PyInfo()

    # PY3
    PyInfo.PY3 = True
    PyInfo.string_types = str,
    PyInfo.text_type = str
    PyInfo.binary_type = bytes
    PyInfo.integer_types = int,
    PyInfo.class_types = type,
    PyInfo.maxsize = sys.maxsize
    instance = PyInfo()
    assert instance.PY3 is True
    assert len(instance.string_types) == 1  # only one element
    assert instance.string_types[0] == str
    assert instance.text_type == str
    assert instance.binary_type == bytes
    assert len(instance.integer_types) == 1  # only one element
    assert instance.integer_types[0] == int

# Generated at 2022-06-12 08:16:11.083110
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:17.577364
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance("a", PyInfo.string_types)
    assert not isinstance(None, PyInfo.string_types)

    assert isinstance("a", PyInfo.text_type)
    assert not isinstance("a", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance("a", PyInfo.integer_types)

    assert isinstance(PyInfo, PyInfo.class_types)
    assert not isinstance("a", PyInfo.class_types)



# Generated at 2022-06-12 08:16:27.601315
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.integer_types == (int, long)


if __name__ == '__main__':
    print('PyInfo.PY2: ' + str(PyInfo.PY2))
    print('PyInfo.PY3: ' + str(PyInfo.PY3))
    print('PyInfo.string_types: ' + str(PyInfo.string_types))
    print('PyInfo.text_type: ' + str(PyInfo.text_type))
    print('PyInfo.binary_type: ' + str(PyInfo.binary_type))
    print('PyInfo.integer_types: ' + str(PyInfo.integer_types))
    print('PyInfo.class_types: ' + str(PyInfo.class_types))

# Generated at 2022-06-12 08:16:31.587507
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert PyInfo.text_type() == ''
    assert PyInfo.binary_type() == b''
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize == 2 ** 63 - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:16:38.559068
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()

    assert info.PY2 is True or info.PY3 is True
    assert info.PY2 is False or info.PY3 is False

    if info.PY2:
        assert info.string_types is not None
        assert info.text_type is not None
        assert info.binary_type is not None
        assert info.integer_types is not None
        assert info.class_types is not None

        assert (info.string_types == (basestring,))
        assert (info.text_type == unicode)
        assert (info.binary_type == str)
        assert info.integer_types == (int, long)
        assert info.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:18:29.959400
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from PyInfo import PyInfo

    pyinfo = PyInfo()

    assert pyinfo.PY2 == (2, 7, 8)
    assert pyinfo.PY3 == (3, 4, 2)
    assert pyinfo.string_types == (str, basestring, unicode)
    assert pyinfo.text_type == (unicode)
    assert pyinfo.binary_type == (bytes)
    assert pyinfo.integer_types == (int, long)
    assert pyinfo.class_types == (tuple, type, types.ClassType)
    assert pyinfo.maxsize == (2147483647)



# Generated at 2022-06-12 08:18:34.518313
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple

# Generated at 2022-06-12 08:18:36.529850
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-12 08:18:40.735971
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True

    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.text_type) is type
    assert type(PyInfo.binary_type) is type
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.class_types) is tuple

    assert type(PyInfo.maxsize) is int



# Generated at 2022-06-12 08:18:50.982058
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance('a', PyInfo.string_types)
        assert isinstance('a', PyInfo.text_type)
        assert not isinstance(b'a', PyInfo.string_types)
        assert not isinstance(b'a', PyInfo.text_type)
        assert isinstance(b'a', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(2 ** 63, PyInfo.integer_types)
        assert not isinstance(2 ** 64, PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
        assert PyInfo.maxsize == (1 << 63) - 1
    else:
        assert isinstance('a', PyInfo.string_types)

# Generated at 2022-06-12 08:18:55.231331
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Just to be sure it has the right type.
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.maxsize, int)
    assert 1 << 31 - 1 <= PyInfo.maxsize <= 1 << 63 - 1


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:18:59.930480
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.string_types
    assert isinstance('', PyInfo.string_types)
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance('abc'.decode('utf-8'), PyInfo.string_types)

    assert PyInfo.text_type
    assert isinstance('', PyInfo.text_type)
    if PyInfo.PY2:
        assert isinstance(u'', PyInfo.text_type)
    else:
        assert not isinstance(u'', PyInfo.text_type)

    assert PyInfo.binary_type
    assert isinstance('', PyInfo.binary_type)

# Generated at 2022-06-12 08:19:06.456775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = '''
    <class 'str'> <class 'obj_tricks.PyInfo'>
    False
    <class 'int'> <class 'obj_tricks.PyInfo'>
    False
    <class 'bytes'> <class 'obj_tricks.PyInfo'>
    <class 'str'> <class 'obj_tricks.PyInfo'>
    <class 'int'> <class 'int'>
    '''
    if PyInfo.PY3:
        assert info == str(PyInfo)
    else:
        assert info == PyInfo.__repr__()

# Generated at 2022-06-12 08:19:16.329093
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def _test(obj, expected):
        type_ = type(obj)
        if type_ == unicode:
            type_ = str
        assert isinstance(obj, expected)
        assert type(obj) == type_

    _test(PyInfo.PY2, bool)
    _test(PyInfo.PY3, bool)

    _test(PyInfo.string_types, tuple)
    _test(PyInfo.string_types[0], PyInfo.string_types[0])

    _test(PyInfo.text_type, type)
    _test(PyInfo.binary_type, type)
    _test(PyInfo.integer_types, tuple)
    _test(PyInfo.integer_types[0], PyInfo.integer_types[0])

    _test(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:19:17.481902
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check whether the code can be loaded correctly.
    PyInfo()