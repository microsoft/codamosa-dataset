

# Generated at 2022-06-12 08:09:39.993538
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Test whether the class constructor returns a singleton object
    obj1 = PyInfo()
    obj2 = PyInfo()
    assert obj1 is obj2
    # Test whether the class correctly identifies the python version
    assert pyinfo.PY2 == (sys.version_info[0] == 2)
    assert pyinfo.PY3 == (sys.version_info[0] == 3)
    # Test whether the class correctly defines the appropriate types
    assert isinstance('', pyinfo.string_types)
    assert isinstance(u'', pyinfo.text_type)
    assert isinstance(b'', pyinfo.binary_type)
    assert isinstance(0, pyinfo.integer_types)
    assert isinstance(int, pyinfo.class_types)

# Generated at 2022-06-12 08:09:47.250935
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Cannot instantiate class
    with pytest.raises(TypeError):
        PyInfo()

    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)
    if PyInfo.PY3:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
    else:  # PY2
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str

# Generated at 2022-06-12 08:09:49.088663
# Unit test for constructor of class PyInfo
def test_PyInfo():
    x = PyInfo()
    assert x.PY2 or x.PY3



# Generated at 2022-06-12 08:09:52.855520
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if sys.version_info[0] == 2:
        assert info.PY2 is True
        assert info.PY3 is False
    else:
        assert info.PY2 is False
        assert info.PY3 is True



# Generated at 2022-06-12 08:09:59.184513
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("a", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.string_types)
        assert not isinstance(b"a", PyInfo.string_types)
        assert isinstance(b"a", PyInfo.binary_type)
        assert not isinstance("a", PyInfo.binary_type)
    elif PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(u"a", PyInfo.string_types)
        assert isinstance(b"a", PyInfo.string_types)
        assert not isinstance("a", PyInfo.binary_type)

# Generated at 2022-06-12 08:10:03.947310
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('sample_text', PyInfo.string_types)
    assert isinstance(u'sample', PyInfo.text_type)
    assert isinstance(b'sample', PyInfo.binary_type)
    assert isinstance(9999, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)

# Generated at 2022-06-12 08:10:14.265898
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type, )
    else:  # PY2
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


if __name__ == '__main__':
    test_PyInfo()
    print('Tests Passed!')

# Generated at 2022-06-12 08:10:24.225312
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()

    assert py_info.PY2 is True or py_info.PY3 is True
    assert py_info.PY2 is False or py_info.PY3 is False
    assert py_info.PY2 is not py_info.PY3
    assert py_info.PY2 is True if sys.version_info[0] == 2 else False
    assert py_info.PY3 is True if sys.version_info[0] == 3 else False

    if PyInfo.PY2:
        assert isinstance(py_info.string_types, tuple)
        assert basestring in py_info.string_types
        assert isinstance(py_info.text_type, unicode)
        assert isinstance(py_info.binary_type, str)
        assert isinstance

# Generated at 2022-06-12 08:10:31.822220
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert isinstance("Hello World", PyInfo.text_type)
    assert isinstance(u"Hello World", PyInfo.text_type)
    assert isinstance(b"Hello World", PyInfo.binary_type)
    assert isinstance(3, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:37.039352
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.string_types == (str,)
    assert PyInfo.text_type == str
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)
    assert PyInfo.maxsize >= 2 ** 32

# Generated at 2022-06-12 08:10:48.256943
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert i.PY2 == sys.version_info[0] == 2
    assert i.PY3 == sys.version_info[0] == 3

    if i.PY3:
        assert i.string_types == (str,)
        assert i.text_type == str
        assert i.binary_type == bytes
        assert i.integer_types == (int,)
        assert i.class_types == (type,)
    else:
        assert i.string_types == (basestring,)
        assert i.text_type == unicode
        assert i.binary_type == str
        assert i.integer_types == (int, long)
        assert i.class_types == (type, types.ClassType)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:56.279830
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest.mock

    with unittest.mock.patch('sys.version_info', (2, 7, 15, 'final', 0)):
        pyinfo = PyInfo()
        assert pyinfo.PY2 is True
        assert pyinfo.PY3 is False
        assert pyinfo.string_types == (basestring,)
        assert pyinfo.text_type is unicode
        assert pyinfo.binary_type is str
        assert pyinfo.integer_types == (int, long)
        assert pyinfo.class_types == (type, types.ClassType)

    with unittest.mock.patch('sys.version_info', (3, 4, 9, 'final', 0)):
        pyinfo = PyInfo()
        assert pyinfo.PY2 is False
        assert pyinfo.PY3

# Generated at 2022-06-12 08:11:07.228046
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Testing PyInfo class:')
    print('PY2 = {0}'.format(PyInfo.PY2))
    print('PY3 = {0}'.format(PyInfo.PY3))
    print('string_types = {0}'.format(PyInfo.string_types))
    print('text_type = {0}'.format(PyInfo.text_type))
    print('binary_type = {0}'.format(PyInfo.binary_type))
    print('integer_types = {0}'.format(PyInfo.integer_types))
    print('class_types = {0}'.format(PyInfo.class_types))
    print('maxsize = {0}'.format(PyInfo.maxsize))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:11:10.556563
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("HelloWorld", PyInfo.string_types)
    assert isinstance(type, PyInfo.class_types)
    assert isinstance(tuple, PyInfo.class_types)

# Generated at 2022-06-12 08:11:16.228784
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("string", PyInfo.string_types)
    assert isinstance(b"string", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:11:26.879264
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # The following is just as simple test to make sure that the PyInfo
    # class definitions are correct for the current version of Python.

    print('Python version: {}.{}.{}'.format(*sys.version_info))

    print('PyInfo.PY2: ', PyInfo.PY2)
    print('PyInfo.PY3: ', PyInfo.PY3)

    if PyInfo.PY2:
        assert type('') in PyInfo.string_types
        assert type(u'') in PyInfo.string_types
        assert type(b'') not in PyInfo.string_types
    else:
        assert type('') in PyInfo.string_types
        assert type(u'') not in PyInfo.string_types
        assert type(b'') not in PyInfo.string_types


# Generated at 2022-06-12 08:11:27.833767
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert callable(PyInfo)



# Generated at 2022-06-12 08:11:38.140038
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert not isinstance(1, PyInfo.string_types)

    assert isinstance(b'a', PyInfo.binary_type)
    assert not isinstance(str(b'a'), PyInfo.binary_type)
    assert not isinstance(u'a', PyInfo.binary_type)
    assert not isinstance(u'a'.encode('utf8'), PyInfo.binary_type)

    assert isinstance('a', PyInfo.text_type)
    assert isinstance(u'a', PyInfo.text_type)
    assert not isinstance(1, PyInfo.text_type)

# Generated at 2022-06-12 08:11:48.046908
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert PyInfo.string_types == (str, unicode)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes

# Generated at 2022-06-12 08:11:55.612412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Test class PyInfo."""
    if PyInfo.PY3:
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(object(), PyInfo.class_types)
        assert isinstance(1 << 63, PyInfo.integer_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance(1 << 31, PyInfo.integer_types)


if __name__ == "__main__":
    raise SystemExit(unittest.main())

# Generated at 2022-06-12 08:12:09.023986
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


# make PyInfo available as psr.utils.pyinfo.PY2, etc.
PY2 = PyInfo.PY2
PY3 = PyInfo.PY3
string_types = PyInfo.string_types
text_type = PyInfo.text_type
binary_type = PyInfo.binary_type
integer_types = PyInfo.integer_types
class_types = PyInfo.class_types



# Generated at 2022-06-12 08:12:18.857248
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_isinstance(a, b):
        assert isinstance(a, b)
        assert isinstance(b, type)

    assert_isinstance(PyInfo.PY2, bool)
    assert_isinstance(PyInfo.PY3, bool)
    assert_isinstance(PyInfo.string_types, tuple)
    assert_isinstance(PyInfo.text_type, type)
    assert_isinstance(PyInfo.binary_type, type)
    assert_isinstance(PyInfo.integer_types, tuple)
    assert_isinstance(PyInfo.class_types, tuple)

    assert_isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.maxsize, int)

    assert_isinstance(PyInfo.string_types[0], type)

# Generated at 2022-06-12 08:12:26.492440
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert type(PyInfo.string_types) is tuple
    assert type(PyInfo.string_types[0]) is type
    assert PyInfo.text_type is str
    assert PyInfo.binary_type is bytes
    assert type(PyInfo.integer_types) is tuple
    assert type(PyInfo.integer_types[0]) is type
    assert type(PyInfo.integer_types[1]) is type
    assert type(PyInfo.class_types) is tuple
    assert type(PyInfo.class_types[0]) is type

# Generated at 2022-06-12 08:12:34.989447
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # If there is a warning for type hinting,
    # it means that the codebase is ready for Python 3.x
    # class X(object):
    #     def __len__(self):
    #         return 1 << 31
    #
    # try:
    #     len(X())
    # except OverflowError:
    #     # 32-bit
    #     maxsize = int((1 << 31) - 1)
    # else:
    #     # 64-bit
    #     maxsize = int((1 << 63) - 1)
    # del X

    # print(PyInfo.maxsize == 1 << 31)
    pass

# Generated at 2022-06-12 08:12:40.991123
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def is_string(x):
        if isinstance(x, str):
            return True
        elif isinstance(x, bytes):
            return True
        else:
            return False

    assert is_string(PyInfo.string_types) is True
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:48.671611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(b'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance(1, PyInfo.binary_type)
    assert not isinstance(1, PyInfo.text_type)



# Generated at 2022-06-12 08:12:52.661065
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    if PyInfo.PY2:
        assert int in PyInfo.integer_types
        assert long in PyInfo.integer_types
    elif PyInfo.PY3:
        assert int in PyInfo.integer_types

# Generated at 2022-06-12 08:13:03.009059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance("", PyInfo.binary_type)
    if PyInfo.PY2:
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:10.246635
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance(u"1", PyInfo.string_types)
        assert isinstance(b"1", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
    else:
        assert isinstance("1", PyInfo.string_types)
        assert isinstance(b"1", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)



# Generated at 2022-06-12 08:13:13.912160
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type == str
    assert PyInfo.string_types == (str,)
    assert PyInfo.binary_type == bytes
    assert PyInfo.integer_types == (int,)
    assert PyInfo.class_types == (type,)



# Generated at 2022-06-12 08:13:31.738125
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert PyInfo.PY3 is False
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif PyInfo.PY3:
        assert PyInfo.PY2 is False
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

# Generated at 2022-06-12 08:13:41.480910
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
        assert isinstance(PyInfo.maxsize, (int, long))
    else:  # PY3
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:13:52.522752
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def assert_instance(instance, class_):
        if not isinstance(instance, class_):
            raise AssertionError(
                '{!r} is not an instance of {!r}'.format(instance, class_))

    assert PyInfo.PY2 or PyInfo.PY3
    assert_instance(PyInfo.string_types, tuple)
    assert_instance(PyInfo.string_types[0], type)
    assert_instance(PyInfo.text_type, type)
    assert_instance(PyInfo.text_type(), PyInfo.string_types[0])
    assert_instance(PyInfo.binary_type, type)
    assert_instance(PyInfo.binary_type(), PyInfo.string_types[0])
    assert_instance(PyInfo.integer_types, tuple)

# Generated at 2022-06-12 08:13:53.859512
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# Python functions to replace C++ standard functions

# Generated at 2022-06-12 08:14:01.772300
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> import sys
    >>> sys.getrefcount(PyInfo)
    5
    >>> PyInfo.PY2
    False
    >>> PyInfo.PY3
    True
    >>> PyInfo.string_types
    (<class 'str'>,)
    >>> PyInfo.binary_type
    <class 'bytes'>
    >>> PyInfo.text_type
    <class 'str'>
    >>> PyInfo.integer_types
    (<class 'int'>,)
    >>> PyInfo.class_types
    (<class 'type'>,)
    >>> PyInfo.maxsize
    (1 << 63) - 1

    # In this case, the variables of PyInfo would be static.
    >>> import types
    >>> id(PyInfo.class_types) == id(types.TupleType)
    True
    """




# Generated at 2022-06-12 08:14:02.859486
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, "Should not be both."

# Generated at 2022-06-12 08:14:05.403576
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(True, PyInfo.integer_types)
    assert isinstance(True, PyInfo.integer_types) is False



# Generated at 2022-06-12 08:14:07.132246
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:14:10.610249
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test static variables
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None
    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:14:16.249948
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class C(object):
        pass

    assert isinstance("", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance("", PyInfo.binary_type)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance("", PyInfo.text_type)

    assert isinstance(C(), PyInfo.class_types)
    assert not isinstance(object(), PyInfo.class_types)

# Generated at 2022-06-12 08:14:43.997183
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)


# Generated at 2022-06-12 08:14:51.441471
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    assert getattr(obj, 'PY2') is True
    assert getattr(obj, 'PY3') is False
    assert isinstance(getattr(obj, 'string_types'), tuple)
    assert getattr(obj, 'string_types') == (basestring,)
    assert getattr(obj, 'text_type') == unicode
    assert getattr(obj, 'binary_type') == str
    assert isinstance(getattr(obj, 'integer_types'), tuple)
    assert getattr(obj, 'integer_types') == (int,long)
    assert isinstance(getattr(obj, 'class_types'), tuple)
    assert getattr(obj, 'class_types') == (type,types.ClassType)
    assert getattr(obj, 'maxsize') == 9223372036

# Generated at 2022-06-12 08:14:55.667916
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance('', PyInfo.binary_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:05.453392
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    if PyInfo.PY2 is True:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, unicode)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
    elif PyInfo.PY3 is True:
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-12 08:15:07.489332
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool



# Generated at 2022-06-12 08:15:16.312826
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def test():
        assert PyInfo.PY3 is True
        assert PyInfo.PY2 is False
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
        assert PyInfo.maxsize == sys.maxsize

    try:
        import builtins  # python 3
    except ImportError:
        import __builtin__ as builtins  # python 2

    setattr(builtins, "unicode", chr)
    test()
    setattr(builtins, "unicode", str)
    test()
    delattr(builtins, "unicode")
    test()


# End of class PyInfo
PyInfo = Py

# Generated at 2022-06-12 08:15:17.621263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    _info = PyInfo()
    _info.PY2 = False
    _info.PY3 = False

# Generated at 2022-06-12 08:15:24.708258
# Unit test for constructor of class PyInfo
def test_PyInfo():
    type(PyInfo)
    type(PyInfo.PY2)
    type(PyInfo.PY3)
    assert PyInfo.maxsize > 0
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert type(PyInfo.binary_type) == type('')
        assert type(PyInfo.text_type) == type(u'')
    else:
        assert PyInfo.string_types == (str,)
        assert type(PyInfo.binary_type) == type(b'')
        assert type(PyInfo.text_type) == type(u'')

# Generated at 2022-06-12 08:15:32.949127
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (sys.version_info[0] == 2)
    assert p.PY3 == (sys.version_info[0] == 3)
    assert p.string_types == (basestring if p.PY2 else str,)
    assert isinstance("", p.string_types)

    if p.PY3:
        assert p.text_type == str
        assert p.binary_type == bytes
        assert p.integer_types == int
        assert p.class_types == type
    else:
        assert p.text_type == unicode
        assert p.binary_type == str
        assert p.integer_types == (int, long)
        assert p.class_types == (type, types.ClassType)


# Decorator to skip a test if

# Generated at 2022-06-12 08:15:35.069787
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (not PyInfo.PY2)

    assert (
        PyInfo.maxsize
        if sys.maxsize == PyInfo.maxsize
        else (1 << 31) - 1
    ) == PyInfo.maxsize

# Generated at 2022-06-12 08:16:25.907130
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert type("") == str
        assert type(b"") == bytes
    else:  # PY2
        assert type("") == str
        assert type(b"") == str


if __name__ == "__main__":
    import pytest

    pytest.main([__file__, '-vv'])

# Generated at 2022-06-12 08:16:30.273263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert p.PY2 == (2 == sys.version_info[0])
    assert p.PY3 == (3 == sys.version_info[0])
    assert str in p.string_types
    assert type('') in p.string_types
    assert p.text_type == str if p.PY3 else unicode
    assert p.binary_type == bytes if p.PY3 else str
    assert int in p.integer_types
    assert type in p.class_types

# Generated at 2022-06-12 08:16:33.817056
# Unit test for constructor of class PyInfo
def test_PyInfo():
    obj = PyInfo()
    assert isinstance(obj, PyInfo)
    assert isinstance(obj.PY2, bool)
    assert isinstance(obj.PY3, bool)
    assert isinstance(obj.maxsize, int)
    assert isinstance(obj.text_type, type)

# Generated at 2022-06-12 08:16:39.188213
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == 1 or PyInfo.PY2 == 0
    assert PyInfo.PY3 == 1 or PyInfo.PY3 == 0
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-12 08:16:42.469347
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from unittest import TestCase

    class TestPyInfo(TestCase):

        def test_PyInfo(self):
            pass

    TestPyInfo.test_PyInfo()



# Generated at 2022-06-12 08:16:51.131147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global class_types
    global binary_type
    global integer_types
    global maxsize

    def class_types():
        return None


    def binary_type():
        return None


    def integer_types():
        return None


    def maxsize():
        return None


    PyInfo.class_types = class_types
    PyInfo.binary_type = binary_type
    PyInfo.integer_types = integer_types
    PyInfo.maxsize = maxsize
    pyinfo_obj = PyInfo()
    assert pyinfo_obj.text_type == None  # Unit test for exception case
    assert pyinfo_obj.string_types == None  # Unit test for exception case
    assert pyinfo_obj.class_types == None  # Unit test for exception case
    assert pyinfo_obj.binary_type == None 

# Generated at 2022-06-12 08:16:59.447188
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        print("Python 3 test")

        assert(isinstance("", PyInfo.string_types))
        assert(isinstance(b"", PyInfo.string_types))
        assert(not isinstance(1, PyInfo.string_types))

        assert(isinstance("", PyInfo.text_type))
        assert(not isinstance(b"", PyInfo.text_type))
        assert(not isinstance(1, PyInfo.text_type))

        assert(isinstance(b"", PyInfo.binary_type))
        assert(not isinstance("", PyInfo.binary_type))
        assert(not isinstance(1, PyInfo.binary_type))

        assert(isinstance(1, PyInfo.integer_types))

# Generated at 2022-06-12 08:17:02.607884
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == '__main__':
    import nose
    nose.runmodule()

# Generated at 2022-06-12 08:17:05.507785
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    if sys.version_info[0] == 2:
        assert info.PY2 == True
        assert info.PY3 == False
    else:  # PY2
        assert info.PY2 == False
        assert info.PY3 == True

# Generated at 2022-06-12 08:17:13.216460
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is False or PyInfo.PY3 is False
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:19:15.196095
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.__name__ == "PyInfo"
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert type(PyInfo.maxsize) == int
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-12 08:19:21.183476
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 != PyInfo.PY3

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, (int, long))


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:19:25.023873
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert PyInfo.maxsize == int((1 << 31) - 1)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:19:32.459128
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert not isinstance(u"", PyInfo.string_types)
    else:
        assert isinstance("", PyInfo.string_types)  # str
        assert isinstance(b"", PyInfo.string_types)  # bytes
        assert isinstance(u"", PyInfo.string_types)  # unicode
    assert not isinstance(None, PyInfo.string_types)

