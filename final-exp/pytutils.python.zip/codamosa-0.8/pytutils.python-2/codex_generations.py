

# Generated at 2022-06-12 08:09:40.297306
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert PyInfo.PY3 is False
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance(u'foo', PyInfo.text_type)
        assert isinstance(b'foo', PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(long(1), PyInfo.integer_types)
        assert isinstance(PyInfo, PyInfo.class_types)
    elif PyInfo.PY3:
        assert PyInfo.PY2 is False
        assert isinstance('foo', PyInfo.string_types)
        assert isinstance('foo', PyInfo.text_type)

# Generated at 2022-06-12 08:09:42.062684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


# Unittest for assert_type

# Generated at 2022-06-12 08:09:43.880250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True or PyInfo.PY3 is not True



# Generated at 2022-06-12 08:09:45.375272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3, 'Not Python2 or Python3'



# Generated at 2022-06-12 08:09:49.706535
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types is basestring or unicode or str
    assert PyInfo.integer_types is (int, long) or int
    assert PyInfo.maxsize is 2147483647 or 9223372036854775807

# Generated at 2022-06-12 08:09:55.606960
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    p = PyInfo()

    assert isinstance(p.PY2, bool)
    assert isinstance(p.PY3, bool)

    assert isinstance(p.integer_types, tuple)
    assert isinstance(p.string_types, tuple)

    assert isinstance(p.text_type(""), p.text_type)
    assert isinstance(p.binary_type(""), p.binary_type)

    assert isinstance(p.maxsize, int)



# Generated at 2022-06-12 08:09:56.848601
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:10:06.287435
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo().PY2
    assert not PyInfo().PY3

    # PY3
    if PyInfo().PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    # PY2
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:10:13.029712
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

# Generated at 2022-06-12 08:10:15.164101
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import doctest

    doctest.testmod(verbose=True)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:23.571177
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:10:30.829365
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not True
    assert PyInfo.PY2 is not False
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:10:41.226508
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(PyInfo.string_types[0], type)
    assert isinstance(u'foo', PyInfo.string_types[0])
    assert isinstance(b'foo', PyInfo.string_types[0])

    assert isinstance(PyInfo.text_type, type)
    assert isinstance(u'foo', PyInfo.text_type)

    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(b'foo', PyInfo.binary_type)

    assert isinstance(PyInfo.integer_types[0], type)
    assert isinstance(1, PyInfo.integer_types[0])

    assert isinstance(PyInfo.class_types[0], type)

# Generated at 2022-06-12 08:10:48.894856
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True

    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)

    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(u"", PyInfo.text_type)
    assert isinstance(u"", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.integer_types)

    assert isinstance(object, PyInfo.class_types)
    assert isinstance(type(object), PyInfo.class_types)

    assert isinstance(object(), PyInfo.class_types)

# Generated at 2022-06-12 08:10:56.489108
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types != []
    assert PyInfo.string_types != PyInfo.text_type
    assert PyInfo.string_types != PyInfo.binary_type
    assert PyInfo.string_types != PyInfo.integer_types
    assert PyInfo.string_types != PyInfo.class_types
    assert PyInfo.string_types != PyInfo.maxsize

    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not []
    assert PyInfo.class_types is not []
    assert PyInfo.maxsize is not None


# Get the name of a class without module prefix
# (i.e. strip everything till the last dot)

# Generated at 2022-06-12 08:11:07.295686
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from os import environ
    from nose.tools import assert_true, assert_equal

    assert_equal(type(PyInfo.string_types), tuple)
    assert_true(basestring in PyInfo.string_types)

    assert_equal(type(PyInfo.text_type), type)
    assert_equal(type(PyInfo.binary_type), type)
    assert_true(PyInfo.text_type is not str)

    assert_equal(type(PyInfo.integer_types), tuple)
    assert_true(int in PyInfo.integer_types)

    assert_equal(type(PyInfo.class_types), tuple)
    assert_true(type in PyInfo.class_types)

    assert_equal(type(PyInfo.maxsize), int)
    assert_true(PyInfo.maxsize > 0)



# Generated at 2022-06-12 08:11:12.893427
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        print("Testing PyInfo...")

        # Test PyInfo Class
        assert(PyInfo.PY2 == True or PyInfo.PY2 == False)
        assert(PyInfo.PY3 == True or PyInfo.PY3 == False)
        assert(PyInfo.PY2 != PyInfo.PY3)

        print("PyInfo class is correct.")
    except AssertionError:
        print("PyInfo class is incorrect.")
        sys.exit(1)

# Generated at 2022-06-12 08:11:18.567583
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (PyInfo.PY3 == (3 == sys.version_info[0]))
    assert PyInfo.PY2 == (PyInfo.PY2 == (2 == sys.version_info[0]))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:28.394755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import unittest

    class PyInfoTest(unittest.TestCase):

        def test_PY2(self):
            self.assertTrue(PyInfo.PY2 is True or PyInfo.PY2 is False)

        def test_PY3(self):
            self.assertTrue(PyInfo.PY3 is True or PyInfo.PY3 is False)

        def test_string_types(self):
            self.assertTrue(PyInfo.string_types[0] is str or PyInfo.string_types[0] is unicode)
            self.assertEqual(len(PyInfo.string_types), 1)

        def test_text_type(self):
            self.assertTrue(PyInfo.text_type is str or PyInfo.text_type is unicode)


# Generated at 2022-06-12 08:11:31.160143
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == sys.version_info[0] == 2
    assert PyInfo.PY3 == sys.version_info[0] == 3

# Generated at 2022-06-12 08:11:41.780111
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(2 ** 63, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:11:51.670395
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from _pytest.python import Module
    import os
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY2:
        assert str == Module("pytest")._importorskip("python.string_types")
        assert text_type == Module("pytest")._importorskip("python.text_type")
        assert binary_type == Module("pytest")._importorskip("python.binary_type")
        assert integer_types == Module("pytest")._importorskip("python.integer_types")
        assert class_types == Module("pytest")._importorskip("python.class_types")
        assert maxsize == Module("pytest")._importors

# Generated at 2022-06-12 08:11:57.312297
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY2 == (sys.version_info[0] == 2)
    assert info.PY3 == (sys.version_info[0] == 3)
    assert type(info.string_types) is tuple
    assert type(info.text_type) is str
    assert type(info.binary_type) is bytes
    assert type(info.integer_types) is tuple
    assert type(info.class_types) is tuple
    assert type(info.maxsize) is int

# Generated at 2022-06-12 08:12:07.439460
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(dict, PyInfo.class_types)
    else:
        assert "".__class__.__name__ == "str"
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(dict, PyInfo.class_types)

# Generated at 2022-06-12 08:12:08.780625
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:12:18.857567
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)
    assert py_info.string_types == (basestring,) if py_info.PY2 else (str,)
    assert py_info.text_type is unicode if py_info.PY2 else str
    assert py_info.binary_type is str if py_info.PY2 else bytes
    assert py_info.integer_types == (int, long) if py_info.PY2 else (int,)
    assert py_info.class_types == (type, types.ClassType) if py_info.PY2 else (type,)
    assert py_info.maxsize > 0

# Generated at 2022-06-12 08:12:25.663799
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == int((1 << 63) - 1)


if __name__ == "__main__":
    import doctest

    doctest.testmod(optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 08:12:29.993248
# Unit test for constructor of class PyInfo
def test_PyInfo():

    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.PY2 + PyInfo.PY3 == 1

# --------- test for constructor of class PyInfo --------- #


if __name__ == '__main__':
    test_PyInfo()
    print('PyInfo initialized')

# Generated at 2022-06-12 08:12:32.754238
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert not PyInfo.PY2

    assert int in PyInfo.integer_types
    assert str in PyInfo.string_types

# Generated at 2022-06-12 08:12:37.377556
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:12:55.359780
# Unit test for constructor of class PyInfo
def test_PyInfo():
    is_py2 = sys.version_info[0] == 2
    is_py3 = sys.version_info[0] == 3
    assert is_py2 ^ is_py3
    assert PyInfo.PY2 == is_py2
    assert PyInfo.PY3 == is_py3

    assert PyInfo.string_types == (basestring if is_py2 else str,)
    assert PyInfo.text_type == (unicode if is_py2 else str)
    assert PyInfo.binary_type == (str if is_py2 else bytes)
    assert PyInfo.integer_types == ((int, long) if is_py2 else (int,))
    assert PyInfo.class_types == ((type, types.ClassType) if is_py2 else (type,))

    assert PyInfo.maxsize == sys

# Generated at 2022-06-12 08:12:58.527139
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(PyInfo.maxsize, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:02.766869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert 1 << 31 == 2147483648
    assert 2147483648 > PyInfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:08.199116
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    if PyInfo.PY3:
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
    else:  # PY2:
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)



# Generated at 2022-06-12 08:13:14.027628
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(b"", PyInfo.binary_type)

    assert isinstance(10, PyInfo.integer_types)
    assert isinstance(100, PyInfo.integer_types)

# Generated at 2022-06-12 08:13:22.436934
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert isinstance("anystr", PyInfo.text_type)
        assert PyInfo.binary_type == bytes
        assert isinstance(b"anystr", PyInfo.binary_type)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:28.170868
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """Unit test to check that the PyInfo constructor runs without errors."""
    from baseplate import __dev_pyinfo__

    assert __dev_pyinfo__.PY3 is PyInfo.PY3
    assert __dev_pyinfo__.PY2 is PyInfo.PY2


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:36.238580
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance("", PyInfo.binary_type)
    else:
        assert isinstance("", PyInfo.string_types)
        assert not isinstance(b"", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)



# Generated at 2022-06-12 08:13:44.007149
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert PyInfo.string_types != PyInfo.text_type
    assert PyInfo.binary_type != PyInfo.text_type
    assert PyInfo.binary_type != PyInfo.string_types
    assert PyInfo.integer_types != PyInfo.string_types
    for typ in PyInfo.string_types:
        assert isinstance("", typ)
    for typ in PyInfo.integer_types:
        assert isinstance(0, typ)

# Generated at 2022-06-12 08:13:54.266189
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY3
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    x = PyInfo()
    assert not x.PY3
    assert x.PY2
    assert x.string_types == (basestring,)
    assert x.text_type == unicode
    assert x.binary_type == str
    assert x.integer_types == (int, long)
    assert x.class_types == (type, types.ClassType)



# Generated at 2022-06-12 08:14:19.863393
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3
    assert isinstance("x", PyInfo.text_type)
    assert isinstance(b"x", PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert not isinstance("1", PyInfo.integer_types)


# alias for PyInfo.integer_types
int_types = PyInfo.integer_types



# Generated at 2022-06-12 08:14:23.874445
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyi = PyInfo()
    assert pyi.PY2
    assert pyi.string_types
    assert pyi.text_type
    assert pyi.binary_type
    assert pyi.integer_types
    assert pyi.class_types
    assert pyi.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:27.193487
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:31.023833
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert isinstance('string', PyInfo.string_types)
    assert isinstance(u'string', PyInfo.text_type)
    assert isinstance('string', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:14:39.834923
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('test PyInfo class {}'.format(PyInfo.PY2))
    print('test PyInfo class {}'.format(PyInfo.PY3))
    print('test PyInfo class {}'.format(PyInfo.string_types))
    print('test PyInfo class {}'.format(PyInfo.text_type))
    print('test PyInfo class {}'.format(PyInfo.binary_type))
    print('test PyInfo class {}'.format(PyInfo.integer_types))
    print('test PyInfo class {}'.format(PyInfo.class_types))
    print('test PyInfo class {}'.format(PyInfo.maxsize))


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:46.860978
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()

    if PyInfo.PY2:
        assert p.string_types == (basestring,)
        assert p.text_type == unicode
        assert p.binary_type == str
        if sys.platform.startswith("java"):
            assert p.maxsize == int((1 << 31) - 1)
        else:
            assert p.maxsize == int((1 << 63) - 1)
    else:
        assert p.string_types == (str,)
        assert p.text_type == str
        assert p.binary_type == bytes
        assert p.maxsize == sys.maxsize

# Generated at 2022-06-12 08:14:50.367066
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize > 0
    assert PyInfo.maxsize > 0
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:53.894348
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 == True or PyInfo.PY2 == False)
    assert (PyInfo.PY3 == True or PyInfo.PY3 == False)


if __name__ == "__main__":
    import doctest

    doctest.testmod(verbose=True, optionflags=doctest.ELLIPSIS)

# Generated at 2022-06-12 08:14:58.155668
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)


test_PyInfo()

# Generated at 2022-06-12 08:15:01.819144
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> pyinfo = PyInfo()
    >>> isinstance(pyinfo.PY2, bool)
    True
    >>> isinstance(pyinfo.PY3, bool)
    True
    """


if __name__ == "__main__":
    import doctest
    doctest.testmod()

# Generated at 2022-06-12 08:15:55.195340
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert (str,) == PyInfo.string_types
        assert str == PyInfo.text_type
        assert bytes == PyInfo.binary_type
        assert (int,) == PyInfo.integer_types
        assert (type,) == PyInfo.class_types

        assert sys.maxsize == PyInfo.maxsize
    else:
        assert (basestring,) == PyInfo.string_types
        assert unicode == PyInfo.text_type
        assert str == PyInfo.binary_type
        assert (int, long) == PyInfo.integer_types

# Generated at 2022-06-12 08:16:00.385045
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-12 08:16:07.446865
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        print("Using Python 2")
        assert isinstance(u"abc", PyInfo.text_type)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
        assert not isinstance(123, PyInfo.class_types)
    else:
        print("Using Python 3")
        assert isinstance("abc", PyInfo.string_types)
        assert isinstance(b"abc", PyInfo.binary_type)
        assert isinstance(123, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:16.199188
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert PyInfo.string_types == (basestring,) if PyInfo.PY2 else (str,)
    assert PyInfo.text_type == unicode if PyInfo.PY2 else str
    assert PyInfo.binary_type == str if PyInfo.PY2 else bytes
    assert PyInfo.integer_types == (int, long) if PyInfo.PY2 else (int,)
    assert PyInfo.class_types == (type, types.ClassType) if PyInfo.PY2 else (type,)
    assert PyInfo.maxsize == PyInfo.maxsize


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:16:23.904709
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert not PyInfo.PY2
    assert PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert PyInfo.string_types == (str,)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, bytes)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert PyInfo.maxsize > 0


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:28.718166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is not None
    assert PyInfo.PY2 is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:33.306150
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert "basestring" in str(PyInfo)
    else:
        assert "str" in str(PyInfo)


if __name__ == "__main__":
    import os
    import sys
    import subprocess

    subprocess.call([os.environ.get('PYTHON', sys.executable), '-m', 'unittest', __file__])

# Generated at 2022-06-12 08:16:35.897911
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert "basestring" in dir(PyInfo)
    return True


if __name__ == "__main__":
    test_PyInfo()
    print("Everything passed")

# Generated at 2022-06-12 08:16:39.332278
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pass


# def main():
#     test_PyInfo()
#
#
# if __name__ == '__main__':
#     main()

# Generated at 2022-06-12 08:16:41.072845
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:18:33.623314
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.maxsize is not None
    assert PyInfo.string_types is not None


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:18:37.702288
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:18:39.446827
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:18:42.580000
# Unit test for constructor of class PyInfo
def test_PyInfo():
    test_pinfo = PyInfo()
    assert test_pinfo.PY3 is True
    assert test_pinfo.PY2 is False
    assert test_pinfo.string_types is (str,)
    assert test_pinfo.text_type is str
    assert test_pinfo.binary_type is bytes
    assert test_pinfo.integer_types is (int,)
    assert test_pinfo.class_types is (type,)
    assert test_pinfo.maxsize == sys.maxsize



# Generated at 2022-06-12 08:18:50.981621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    print(sys.version)

    print("PY2", PyInfo.PY2)
    print("PY3", PyInfo.PY3)

    print("string_types", PyInfo.string_types)
    print("text_type", PyInfo.text_type)
    print("binary_type", PyInfo.binary_type)
    print("integer_types", PyInfo.integer_types)
    print("class_types", PyInfo.class_types)

    print("maxsize", PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:18:54.958692
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY3 is not True
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.class_types is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.maxsize is not None

# Generated at 2022-06-12 08:18:57.202958
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.binary_type == bytes
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.binary_type == str



# Generated at 2022-06-12 08:19:02.072775
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(PyInfo, PyInfo.class_types)


MIME_TYPES = None



# Generated at 2022-06-12 08:19:10.875108
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # Test PY3
    if PyInfo.PY3:
        if Python.get_python_implementation() == "Jython":
            assert isinstance(PyInfo.maxsize, int)
            assert PyInfo.maxsize == (1 << 31) - 1
        else:
            assert isinstance(PyInfo.maxsize, int)
            assert PyInfo.maxsize == (1 << 63) - 1

        assert isinstance(PyInfo.string_types, tuple)
        assert PyInfo.string_types == (str,)
        assert isinstance(PyInfo.text_type, type)
        assert PyInfo.text_type == str

# Generated at 2022-06-12 08:19:17.071887
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 + PyInfo.PY3 == 1
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, str)
    assert isinstance(PyInfo.binary_type, str)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)