

# Generated at 2022-06-12 08:09:38.320552
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance(123, PyInfo.integer_types)
    if PyInfo.PY2:
        class A(object):
            pass
        assert isinstance(A, PyInfo.class_types)

# Generated at 2022-06-12 08:09:44.415630
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('Python version %s.%s.%s' % (sys.version_info[0], sys.version_info[1], sys.version_info[2]))

    print('Python version:', PyInfo.PY2)
    print('Python version:', PyInfo.PY3)
    if PyInfo.PY3:
        print('Python maxsize:', PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:09:50.012354
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert (PyInfo.PY2 ^ PyInfo.PY3) is True

    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(b'', PyInfo.string_types)

    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:09:57.442187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.maxsize == (1 << 63) - 1
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.string_types == (str,)
        assert PyInfo.integer_types == (int,)
        assert PyInfo.maxsize == (1 << 31) - 1
        assert PyInfo.class_types == (type,)



# Generated at 2022-06-12 08:10:03.260875
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == (sys.version_info[0] == 2)
    assert py_info.PY3 == (sys.version_info[0] == 3)
    if py_info.PY2:
        assert py_info.maxsize == (sys.maxsize, )  # XXX: looks like a bug to me
    else:
        assert py_info.maxsize == sys.maxsize

# Generated at 2022-06-12 08:10:13.364361
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.string_types) is tuple  # noqa
    assert type(PyInfo.text_type) is type  # noqa
    assert type(PyInfo.binary_type) is type  # noqa
    assert type(PyInfo.integer_types) is tuple  # noqa
    assert type(PyInfo.class_types) is tuple  # noqa
    assert type(PyInfo.maxsize) is int  # noqa
    assert type(PyInfo.PY2) is bool  # noqa
    assert type(PyInfo.PY3) is bool  # noqa


if __name__ == "__main__":
    import os

    basename = os.path.basename(sys.argv[0])

# Generated at 2022-06-12 08:10:15.652950
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:10:25.024816
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert len(PyInfo.string_types) == 1
    assert isinstance("", PyInfo.string_types[0])
    assert len(PyInfo.integer_types) == 2
    assert isinstance(1, PyInfo.integer_types[0])
    i = 1

# Generated at 2022-06-12 08:10:31.461613
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not None
    assert PyInfo.PY3 is not None

    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None

    assert PyInfo.maxsize is not None



# Generated at 2022-06-12 08:10:42.162296
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print('=== test_PyInfo ===')

    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False

    assert isinstance('', PyInfo.string_types) is True
    assert isinstance(u'', PyInfo.string_types) is True
    assert isinstance(b'', PyInfo.string_types) is False

    assert isinstance('', PyInfo.text_type) is False
    assert isinstance(u'', PyInfo.text_type) is True
    assert isinstance(b'', PyInfo.text_type) is False

    assert isinstance('', PyInfo.binary_type) is True
    assert isinstance(u'', PyInfo.binary_type) is False
    assert isinstance(b'', PyInfo.binary_type) is True


# Generated at 2022-06-12 08:10:54.167397
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 == sys.version_info[0] == 2
    assert pyinfo.PY3 == sys.version_info[0] == 3
    assert pyinfo.string_types == (basestring,) if pyinfo.PY2 else (str,)
    assert pyinfo.text_type == unicode if pyinfo.PY2 else str
    assert pyinfo.binary_type == str if pyinfo.PY2 else bytes
    assert pyinfo.integer_types == (int, long) if pyinfo.PY2 else (int,)
    assert pyinfo.class_types == (type, types.ClassType) if pyinfo.PY2 else (type,)

# Generated at 2022-06-12 08:10:59.788805
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert(not isinstance(1, PyInfo.integer_types))
        assert(isinstance(1, int))
        assert(isinstance(1, (int, long)))
        assert(isinstance(1, PyInfo.integer_types))
    elif PyInfo.PY3:
        assert(not isinstance(1, int))
        assert(isinstance(1, PyInfo.integer_types))
        assert(not isinstance(1, (int, long)))
        assert(not isinstance(1, PyInfo.integer_types))
    assert(PyInfo.maxsize == sys.maxsize)



# Generated at 2022-06-12 08:11:09.148751
# Unit test for constructor of class PyInfo
def test_PyInfo():
    def is_set(item):
        return type(item) == set

    def is_long(item):
        return type(item) == long

    def is_tuple(item):
        return type(item) == tuple

    # Check strings
    assert type('test') == type('test') == str
    assert type(u'test') == type(u'test') == type(u'test') == unicode

    # Check numbers
    assert type(1) == type(1) == int

# Generated at 2022-06-12 08:11:19.984264
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("", PyInfo.string_types)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(1, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)



# Generated at 2022-06-12 08:11:26.296693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)

    assert PyInfo.maxsize == sys.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:30.168969
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-12 08:11:41.107351
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == type
        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring, )
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)


# Generated at 2022-06-12 08:11:47.776880
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types == (str, basestring)
    assert PyInfo.text_type == (str, unicode)

    assert PyInfo.maxsize > 0

    if PyInfo.PY2:
        assert PyInfo.maxsize > (1 << 31) - 1
    else:
        assert PyInfo.maxsize <= (1 << 31) - 1 or (
            PyInfo.maxsize > (1 << 63) - 1
        )

# Generated at 2022-06-12 08:11:56.813436
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring, )
        assert isinstance('str', PyInfo.string_types)
        assert PyInfo.text_type == unicode
        assert isinstance(u'str', PyInfo.text_type)
        assert PyInfo.binary_type == str
        assert isinstance(b'str', PyInfo.binary_type)
        assert PyInfo.integer_types == (int, long)
        assert isinstance(1, PyInfo.integer_types)
        assert PyInfo.class_types == (type, types.ClassType)
        assert isinstance(int, PyInfo.class_types)
    elif PyInfo.PY3:
        assert PyInfo.string_types == (str, )

# Generated at 2022-06-12 08:12:07.116611
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # test the following
    # PY2
    # PY3
    # string_types
    # text_type
    # binary_type
    # integer_types
    # class_types
    # maxsize

    if PyInfo.PY2:
        assert not PyInfo.PY3
    elif PyInfo.PY3:
        assert not PyInfo.PY2

    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert not isinstance(b"", PyInfo.string_types)
    assert isinstance("", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

# Generated at 2022-06-12 08:12:13.773523
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert 1.0 == None
    else:
        assert not 1.0 == None

# Generated at 2022-06-12 08:12:20.975211
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if sys.version_info[0] == 2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    elif sys.version_info[0] == 3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_

# Generated at 2022-06-12 08:12:26.589733
# Unit test for constructor of class PyInfo
def test_PyInfo():
    isInPython2 = PyInfo.PY2
    isInPython3 = PyInfo.PY3
    assert(isInPython2 or isInPython3)
    assert(PyInfo.string_types)
    assert(PyInfo.text_type)
    assert(PyInfo.binary_type)
    assert(PyInfo.integer_types)
    assert(PyInfo.class_types)
    assert(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:12:33.360921
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.string_types)

# Generated at 2022-06-12 08:12:36.909995
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (PyInfo.PY2 is False)
    assert PyInfo.PY2 == (PyInfo.PY3 is False)

    assert len(PyInfo.string_types) == 1
    assert len(PyInfo.integer_types) == 2
    assert len(PyInfo.class_types) == 2

# Generated at 2022-06-12 08:12:47.539166
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(
        "", PyInfo.string_types) and isinstance(
        b"", PyInfo.string_types)
    assert isinstance(
        "", PyInfo.text_type) and not isinstance(
        b"", PyInfo.text_type)
    assert isinstance(
        b"", PyInfo.binary_type) and not isinstance(
        "", PyInfo.binary_type)

# Generated at 2022-06-12 08:12:55.419250
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3

    if PyInfo.PY2:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)
    else:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:05.855234
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple) and PyInfo.string_types
    assert isinstance(PyInfo.text_type, type) and PyInfo.text_type
    assert isinstance(PyInfo.binary_type, type) and PyInfo.binary_type
    assert isinstance(PyInfo.integer_types, tuple) and PyInfo.integer_types
    assert isinstance(PyInfo.class_types, tuple) and PyInfo.class_types
    assert isinstance(PyInfo.maxsize, integer_types)


# import path
import os
from os.path import dirname, abspath
from os.path import join as path_join

# path of current file
file_path = abspath(__file__)

# path of current directory
directory

# Generated at 2022-06-12 08:13:11.944118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2 and not PyInfo.PY3:
        raise RuntimeError("Unsupported python version %d.%d" % (sys.version_info[0], sys.version_info[1]))
    foo_str = "foo"
    if PyInfo.PY2:
        if not isinstance(foo_str, basestring):
            raise RuntimeError("Failed to detect python2")
    else:
        if not isinstance(foo_str, str):
            raise RuntimeError("Failed to detect python3")


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:21.470286
# Unit test for constructor of class PyInfo
def test_PyInfo():
    sys.stdout.write('test_PyInfo.................................')
    if PyInfo.PY2:
        assert isinstance('abd', PyInfo.string_types)
        assert isinstance(u'abd', PyInfo.text_type)
        assert isinstance(b'abd', PyInfo.binary_type)
        assert isinstance(0, PyInfo.integer_types)
        assert isinstance(2**31-1, PyInfo.integer_types)
        assert isinstance(2**31, PyInfo.integer_types)
        assert isinstance(2**63-1, PyInfo.integer_types)
        assert isinstance(2**63, PyInfo.integer_types)
        assert isinstance(1, PyInfo.class_types)
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:13:36.387698
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:38.740877
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:13:45.120208
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert len(PyInfo.integer_types) == 2
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert len(PyInfo.class_types) == 2
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert len(PyInfo.string_types) == 1
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type == str
        assert PyInfo.binary

# Generated at 2022-06-12 08:13:47.281224
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo()
    assert type(p.string_types) is tuple


# Generated at 2022-06-12 08:13:56.388610
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert not isinstance(b"", PyInfo.string_types)
        assert not isinstance("", PyInfo.string_types)
        assert not isinstance("", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance("", PyInfo.string_types)
    else:  # PY3
        assert isinstance(b"", PyInfo.binary_type)
        assert isinstance("", PyInfo.text_type)
        assert isinstance("", PyInfo.string_types)
        assert isinstance(b"", PyInfo.string_types)

# Generated at 2022-06-12 08:14:04.020976
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys

    if sys.version_info[0] == 2:
        assert PyInfo.PY2 is True
        assert PyInfo.PY3 is False
        assert PyInfo.string_types[0] == basestring
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types[0] == int
        assert PyInfo.integer_types[1] == long
        assert PyInfo.class_types[0] == type
        assert PyInfo.class_types[1] == types.ClassType
    else:
        assert PyInfo.PY2 is False
        assert PyInfo.PY3 is True
        assert PyInfo.string_types[0] == str
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes

# Generated at 2022-06-12 08:14:07.280566
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance('test', PyInfo.string_types)
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.class_types)
        assert isinstance('a', PyInfo.binary_type)



# Generated at 2022-06-12 08:14:12.549770
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == True or PyInfo.PY3 == False
    assert PyInfo.PY2 == True or PyInfo.PY2 == False
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


# Unit test

# Generated at 2022-06-12 08:14:13.633723
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Nothing to test
    pass


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:19.318605
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.integer_types)

    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(u"", PyInfo.binary_type)

    assert isinstance(b"", PyInfo.binary_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert isinstance(1, PyInfo.integer_types)
    assert not isinstance(1, PyInfo.string_types)

    assert PyInfo.PY2 or PyInfo.PY3



# Generated at 2022-06-12 08:14:41.308355
# Unit test for constructor of class PyInfo
def test_PyInfo():
    sys.version_info = (3, 2, 1)
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True
    assert PyInfo.maxsize == sys.maxsize

    sys.version_info = (2, 7, 13)
    assert PyInfo.PY2 is True
    assert PyInfo.PY3 is False
    assert PyInfo.maxsize == 9223372036854775807



# Generated at 2022-06-12 08:14:42.924187
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2

# Generated at 2022-06-12 08:14:47.593690
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

    assert isinstance(str(), PyInfo.string_types)
    assert not isinstance(str(), PyInfo.binary_type)

    assert isinstance(str().encode('utf-8'), PyInfo.binary_type)
    assert not isinstance(str().encode('utf-8'), PyInfo.string_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:14:51.146755
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert type(PyInfo.PY2) == bool
    assert type(PyInfo.PY3) == bool
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == type
    assert type(PyInfo.binary_type) == type
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple


# For converting python2 string to python3 string

# Generated at 2022-06-12 08:14:55.249454
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)
    assert isinstance("", PyInfo.string_types)
    assert isinstance(u"", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:15:03.026131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.PY2 ^ PyInfo.PY3 is True
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)


test_PyInfo()

# Generated at 2022-06-12 08:15:04.759820
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.maxsize)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:15:13.580103
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import sys
    import types

    assert PyInfo.PY2 is not PyInfo.PY3
    assert (
        sys.version_info[0] == 2
    ) == PyInfo.PY2, "PyInfo.PY2 not set correctly!"
    assert (
        sys.version_info[0] == 3
    ) == PyInfo.PY3, "PyInfo.PY3 not set correctly!"

    if PyInfo.PY3:
        assert str in PyInfo.string_types
        assert bytes in PyInfo.string_types
        assert not unicode in PyInfo.string_types
        assert not basestring in PyInfo.string_types
        assert type in PyInfo.class_types
        assert PyInfo.maxsize == sys.maxsize
    else:
        assert unicode in PyInfo.string_types

# Generated at 2022-06-12 08:15:19.405819
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(u'', PyInfo.text_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(int, PyInfo.class_types)
    assert PyInfo.maxsize >= 0
    if PyInfo.PY3:
        assert isinstance(int, PyInfo.class_types)
    else:  # PY2
        assert isinstance(int, PyInfo.class_types)

# Generated at 2022-06-12 08:15:24.881044
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.text_type)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:20.595225
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.class_types)
    else:  # PY3
        assert isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:16:26.987126
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    assert isinstance(i.PY2, bool)
    assert isinstance(i.PY3, bool)
    assert isinstance(i.maxsize, int)
    assert isinstance(i.string_types, tuple)
    assert isinstance(i.text_type, type)
    assert isinstance(i.integer_types, tuple)
    assert isinstance(i.class_types, tuple)
    assert isinstance(i, PyInfo)
    assert isinstance(i, object)

# Generated at 2022-06-12 08:16:36.175502
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import textwrap

    # type(string_types) == tuple
    # type(text_type) == str
    # type(binary_type) == str
    # type(integer_types) == tuple
    # type(class_types) == tuple
    # type(maxsize) == int
    assert type(PyInfo.string_types) == tuple
    assert type(PyInfo.text_type) == str
    assert type(PyInfo.binary_type) == str
    assert type(PyInfo.integer_types) == tuple
    assert type(PyInfo.class_types) == tuple
    assert type(PyInfo.maxsize) == int

    # isinstance(str, string_types) == True
    assert isinstance("", PyInfo.string_types)

    # isinstance(u"a", string_types) == True

# Generated at 2022-06-12 08:16:43.691485
# Unit test for constructor of class PyInfo
def test_PyInfo():
    p = PyInfo
    assert p.PY2 == True or p.PY3 == True

    if p.PY2:
        assert p.string_types[0] == basestring
        assert p.text_type == unicode
        assert p.binary_type == str
        assert p.integer_types[0] == int or p.integer_types[0] == long
        assert p.class_types[0] == type or p.class_types[1] == types.ClassType
    elif p.PY3:
        assert p.string_types[0] == str
        assert p.text_type == str
        assert p.binary_type == bytes
        assert p.integer_types[0] == int
        assert p.class_types[0] == type
    else:
        assert False

# Generated at 2022-06-12 08:16:51.725662
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance("123", PyInfo.string_types)
        assert isinstance("123", PyInfo.text_type)
        assert not isinstance("123", PyInfo.binary_type)
        assert isinstance("123", PyInfo.string_types)
        assert not isinstance("123", PyInfo.class_types)
    elif PyInfo.PY3:
        assert not isinstance("123", PyInfo.string_types)
        assert isinstance("123", PyInfo.text_type)
        assert not isinstance("123", PyInfo.binary_type)

        class MyClass(object):
            pass

        assert isinstance(MyClass(), PyInfo.class_types)
        assert isinstance(MyClass, PyInfo.class_types)

        class X:
            pass


# Generated at 2022-06-12 08:16:53.437092
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:56.322861
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance(PyInfo.maxsize, int)
        assert type(PyInfo.maxsize) == long

    else:
        assert isinstance(PyInfo.maxsize, int)


test_PyInfo()

# Generated at 2022-06-12 08:17:04.315089
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"A", PyInfo.string_types)
        assert isinstance("a", PyInfo.text_type)
        assert not isinstance(b"A", PyInfo.text_type)
        assert isinstance(11, PyInfo.integer_types)
        assert not isinstance(11, PyInfo.class_types)
    else:
        assert isinstance("a", PyInfo.string_types)
        assert not isinstance(b"A", PyInfo.string_types)
        assert isinstance(u"a", PyInfo.text_type)
        assert not isinstance("A", PyInfo.text_type)
        assert isinstance(11, (int, long))

# Generated at 2022-06-12 08:17:07.744182
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert isinstance("", PyInfo.text_type)
    assert isinstance("", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(0.0, (float,))

# Generated at 2022-06-12 08:17:12.175621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert PyInfo.maxsize == 9223372036854775807
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
    else:
        assert PyInfo.maxsize == sys.maxsize
        assert PyInfo.string_types == (str, )
        assert PyInfo.text_type == str



# Generated at 2022-06-12 08:19:14.693545
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()
    assert pyinfo.PY2 is True or pyinfo.PY2 is False
    assert pyinfo.PY3 is True or pyinfo.PY3 is False
    assert isinstance(pyinfo.string_types, tuple)
    assert isinstance(pyinfo.text_type, type)
    assert isinstance(pyinfo.binary_type, type)
    assert isinstance(pyinfo.integer_types, tuple)
    assert isinstance(pyinfo.class_types, tuple)

    if pyinfo.PY2:
        assert pyinfo.maxsize > 0
    elif pyinfo.PY3:
        assert pyinfo.maxsize > 0


# Generated at 2022-06-12 08:19:22.587621
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """tests constructor of class PyInfo"""
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type == str
        assert PyInfo.binary_type == bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)

        assert PyInfo.maxsize == sys.maxsize
    else:  # PY2
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type == unicode
        assert PyInfo.binary_type == str
        assert PyInfo.integer_types == (int, long)

# Generated at 2022-06-12 08:19:28.972037
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    assert type('python3') in PyInfo.string_types
    assert type('python3') == PyInfo.binary_type  # no unicode in Py2
    assert type(1) in PyInfo.integer_types
    # is it a "bug" that class_types is not a tuple?


# a bunch of helper functions

# Generated at 2022-06-12 08:19:30.849516
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # TODO
    pass


if __name__ == "__main__":
    test_PyInfo()