

# Generated at 2022-06-12 08:09:39.716633
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3
    if PyInfo.PY2:
        assert isinstance("", PyInfo.text_type)
        assert not isinstance("", PyInfo.binary_type)
        assert isinstance(u"", PyInfo.text_type)
        assert not isinstance(u"", PyInfo.binary_type)
        assert isinstance(b"", PyInfo.binary_type)
        assert not isinstance(b"", PyInfo.text_type)
        assert isinstance(3, PyInfo.integer_types)
        assert not isinstance(3.1, PyInfo.integer_types)
        assert isinstance(int, PyInfo.class_types)
        assert isinstance(types.ClassType, PyInfo.class_types)

# Generated at 2022-06-12 08:09:40.696131
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert False, "Unit tests not yet implemented for PyInfo."

# Generated at 2022-06-12 08:09:45.638998
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY2:
        assert isinstance('abc', PyInfo.string_types)
        assert isinstance(b'abc', PyInfo.binary_type)

    assert isinstance(1, PyInfo.integer_types)
    assert (PyInfo.maxsize > 2 ** 32) == (sys.maxsize > 2 ** 32)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:09:49.966272
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 or PyInfo.PY2
    assert isinstance("", PyInfo.string_types)
    assert isinstance(b"", PyInfo.binary_type)
    assert isinstance(0, PyInfo.integer_types)
    assert isinstance(object, PyInfo.class_types)

# Generated at 2022-06-12 08:09:56.049282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert isinstance("", PyInfo.string_types)
    assert not isinstance("", PyInfo.binary_type)
    assert isinstance("", PyInfo.text_type)
    assert isinstance(u"", PyInfo.text_type)
    assert not isinstance(b"", PyInfo.text_type)

    assert not isinstance(type, PyInfo.class_types)
    assert not isinstance(type(1), PyInfo.class_types)



# Generated at 2022-06-12 08:10:04.630285
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 != PyInfo.PY3  # assert PY2 is not PY3
    # assert PY2 or PY3  # Why not?
    assert isinstance('a', PyInfo.string_types)
    assert isinstance(u'a', PyInfo.string_types)
    assert isinstance(b'a', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1.0, PyInfo.integer_types)
    assert isinstance(types.FunctionType, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:15.163869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert type('') in PyInfo.string_types
    if PyInfo.PY2:
        assert type(u'') == PyInfo.text_type
        assert type('') == PyInfo.binary_type

# Generated at 2022-06-12 08:10:22.713801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert issubclass(PyInfo.text_type, PyInfo.string_types)
    assert issubclass(PyInfo.binary_type, PyInfo.string_types)
    assert not issubclass(PyInfo.string_types, PyInfo.text_type)
    assert not issubclass(PyInfo.string_types, PyInfo.binary_type)


if __name__ == "__main__":
    import doctest

    doctest.testmod()
    test_PyInfo()

# Generated at 2022-06-12 08:10:32.802444
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 ^ PyInfo.PY3
    if PyInfo.PY2:
        assert not isinstance(unicode('a'), PyInfo.string_types)
        assert not isinstance(unicode('a'), PyInfo.text_type)
        assert not isinstance(unicode('a'), PyInfo.binary_type)
    elif PyInfo.PY3:
        assert isinstance(bytes('a', encoding='ascii'), PyInfo.string_types)
        assert not isinstance(bytes('a', encoding='ascii'), PyInfo.text_type)
        assert isinstance(bytes('a', encoding='ascii'), PyInfo.binary_type)



# Generated at 2022-06-12 08:10:40.293678
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not PyInfo.PY3
    assert not isinstance(1, PyInfo.string_types)
    assert not isinstance("", PyInfo.integer_types)
    assert not isinstance("", PyInfo.class_types)
    if PyInfo.PY2:
        assert not isinstance(1, PyInfo.integer_types)
        assert not isinstance(1, PyInfo.class_types)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(1, PyInfo.class_types)

# Generated at 2022-06-12 08:10:49.439554
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if not PyInfo.PY3:
        assert isinstance("", PyInfo.string_types)
        assert isinstance(u"", PyInfo.string_types)
        assert isinstance(u"", PyInfo.text_type)
        assert isinstance("", PyInfo.binary_type)
        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:10:54.535412
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.string_types == (basestring,)
    assert PyInfo.text_type == unicode
    assert PyInfo.binary_type == str
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.class_types == (type, types.ClassType)
    assert PyInfo.maxsize == (1 << 31) - 1

# Generated at 2022-06-12 08:10:59.787742
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # Check types
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)

    # Check value
    assert PyInfo.PY2 != PyInfo.PY3



# Generated at 2022-06-12 08:11:08.404263
# Unit test for constructor of class PyInfo
def test_PyInfo():
    import inspect

    assert PyInfo.PY2 is True or PyInfo.PY2 is False, (
        'PyInfo.PY2 is not boolean')
    assert PyInfo.PY3 is True or PyInfo.PY3 is False, (
        'PyInfo.PY3 is not boolean')

    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

    assert isinstance(inspect.getdoc(PyInfo), str)



# Generated at 2022-06-12 08:11:19.166008
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert maxsize == sys.maxsize
        assert isinstance('GitPython', PyInfo.string_types)
        assert not isinstance(42, PyInfo.string_types)
        assert isinstance(42, PyInfo.integer_types)
        assert not isinstance('GitPython', PyInfo.integer_types)
    else:  # PY2
        assert maxsize != sys.maxsize
        assert isinstance(u'GitPython', PyInfo.string_types)
        assert not isinstance(42, PyInfo.string_types)
        assert isinstance(42, PyInfo.integer_types)


# Generated at 2022-06-12 08:11:28.910920
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pyinfo = PyInfo()

    assert pyinfo.PY3 == (3 == sys.version_info[0])
    assert pyinfo.PY2 == (2 == sys.version_info[0])
    assert pyinfo.text_type == str if pyinfo.PY3 else unicode
    assert pyinfo.binary_type == bytes if pyinfo.PY3 else str
    assert pyinfo.string_types == (str, basestring) if pyinfo.PY3 else (
        basestring, unicode)
    assert pyinfo.integer_types == (int,) if pyinfo.PY3 else (int, long)
    assert pyinfo.class_types == (type,) if pyinfo.PY3 else (type, types.ClassType)


__all__ = ('pyinfo_for_subprocess',)


# Generated at 2022-06-12 08:11:39.581129
# Unit test for constructor of class PyInfo
def test_PyInfo():
    pi = PyInfo()
    assert pi.PY2 == (sys.version_info[0] == 2)
    assert pi.PY3 == (sys.version_info[0] == 3)

    if pi.PY3:
        assert pi.string_types == (str,)
        assert pi.text_type == str
        assert pi.binary_type == bytes
        assert pi.integer_types == (int,)
        assert pi.class_types == (type,)
        assert pi.maxsize == sys.maxsize
    else:
        assert pi.string_types == (basestring,)
        assert pi.text_type == unicode
        assert pi.binary_type == str
        assert pi.integer_types == (int, long)
        assert pi.class_types == (type, types.ClassType)

# Generated at 2022-06-12 08:11:49.562817
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    if PyInfo.PY3:
        assert isinstance('abc', PyInfo.string_types)
        assert not isinstance(b'abc', PyInfo.string_types)

        assert isinstance('abc', PyInfo.text_type)
        assert not isinstance(b'abc', PyInfo.text_type)

        assert isinstance(b'abc', PyInfo.binary_type)
        assert not isinstance('abc', PyInfo.binary_type)

        assert isinstance(2 ** 32, PyInfo.integer_types)
        assert not isinstance(2.0 ** 32, PyInfo.integer_types)


# Generated at 2022-06-12 08:11:53.454480
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        raise Exception('Test Failed: sys.version_info[0] is %d' % sys.version_info[0])
    except Exception as e:
        assert PyInfo.PY2 or PyInfo.PY3, e.message


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:11:59.747597
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> PyInfo.PY2
    True
    >>> PyInfo.PY3
    False
    >>> isinstance('1', PyInfo.string_types)
    True
    >>> isinstance(u'2', PyInfo.string_types)
    True
    >>> isinstance(b'3', PyInfo.binary_type)
    True
    >>> isinstance(1, PyInfo.integer_types)
    True
    >>> isinstance(2 ** 64, PyInfo.integer_types)
    True
    >>> isinstance(str, PyInfo.class_types)
    True
    >>> PyInfo.maxsize
    2147483647
    """


if __name__ == '__main__':
    from doctest import testmod

    testmod()

# Generated at 2022-06-12 08:12:15.751047
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 is True or PyInfo.PY3 is False
    assert PyInfo.PY2 is True or PyInfo.PY2 is False
    assert PyInfo.maxsize > 0
    assert type(PyInfo.maxsize) is int
    if PyInfo.PY3:
        assert type(PyInfo.string_types) is tuple
        assert type(PyInfo.string_types[0]) is type
        assert PyInfo.string_types[0] is str
        assert type(PyInfo.text_type) is type
        assert PyInfo.text_type is str
        assert type(PyInfo.binary_type) is type
        assert PyInfo.binary_type is bytes
        assert type(PyInfo.integer_types) is tuple
        assert type(PyInfo.integer_types[0]) is type

# Generated at 2022-06-12 08:12:19.761502
# Unit test for constructor of class PyInfo
def test_PyInfo():
    print(PyInfo.PY2)
    print(PyInfo.PY3)
    print(PyInfo.string_types)
    print(PyInfo.text_type)
    print(PyInfo.binary_type)
    print(PyInfo.integer_types)
    print(PyInfo.class_types)
    print(PyInfo.maxsize)


if __name__ == "__main__":
    test_PyInfo()

# Generated at 2022-06-12 08:12:24.315455
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is not True
    assert PyInfo.PY2 is False
    assert PyInfo.PY3 is True


if __name__ == "__main__":
    import os

    basename = os.path.basename(__file__)
    pytest.main([basename, "-s", "--tb=native"])

# Generated at 2022-06-12 08:12:34.266881
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)

    # for test cases
    s = b'abc'  # str in PY2, bytes in PY3
    b = b'abc'
    i = 123

    if PyInfo.PY3:
        assert isinstance(s, PyInfo.string_types)
        assert isinstance(s, PyInfo.text_type)
        assert isinstance(b, PyInfo.binary_type)
        assert isinstance(i, PyInfo.integer_types)
    else:  # PY2
        assert isinstance(s, PyInfo.string_types)
        assert isinstance(s, PyInfo.binary_type)

# Generated at 2022-06-12 08:12:43.619684
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert(PyInfo.PY2 == (sys.version_info[0] == 2))
    assert(PyInfo.PY3 == (sys.version_info[0] == 3))
    if PyInfo.PY3:
        assert(PyInfo.string_types == (str,))
        assert(PyInfo.text_type == str)
        assert(PyInfo.binary_type == bytes)
        assert(PyInfo.integer_types == (int,))
        assert(PyInfo.class_types == (type,))
        assert(PyInfo.maxsize == (1 << 63) - 1)
    else:
        assert(PyInfo.string_types == (str, unicode))
        assert(PyInfo.text_type == unicode)
        assert(PyInfo.binary_type == str)

# Generated at 2022-06-12 08:12:53.793706
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py2 = PyInfo.PY2
    py3 = PyInfo.PY3
    string_types = PyInfo.string_types
    text_type = PyInfo.text_type
    binary_type = PyInfo.binary_type
    integer_types = PyInfo.integer_types
    class_types = PyInfo.class_types
    maxsize = PyInfo.maxsize

    assert isinstance(9, integer_types)
    assert not isinstance(9.0, integer_types)


# Generated at 2022-06-12 08:12:55.181640
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3


# Check if the given value is a text type

# Generated at 2022-06-12 08:13:05.537079
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from nose.tools import assert_equal

    assert_equal(PyInfo.PY2 ^ PyInfo.PY3, True)

    if PyInfo.PY2:
        assert_equal(issubclass(str, PyInfo.string_types), True)
        assert_equal(issubclass(PyInfo.text_type, PyInfo.string_types), True)
        assert_equal(issubclass(PyInfo.binary_type, PyInfo.string_types), True)
        assert_equal(issubclass(int, PyInfo.integer_types), True)
        assert_equal(issubclass(long, PyInfo.integer_types), True)
        assert_equal(issubclass(PyInfo.integer_types, tuple), True)
        assert_equal(issubclass(type, PyInfo.class_types), True)


# Generated at 2022-06-12 08:13:10.828659
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance('', PyInfo.text_type)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(u'', PyInfo.string_types)
    assert isinstance(1, PyInfo.integer_types)
    if PyInfo.PY2:
        from types import ClassType
        assert isinstance(ClassType, PyInfo.class_types)


test_PyInfo()

# Generated at 2022-06-12 08:13:15.020801
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3

    assert PyInfo.string_types
    assert PyInfo.text_type
    assert PyInfo.binary_type
    assert PyInfo.integer_types
    assert PyInfo.class_types
    assert PyInfo.maxsize


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:13:31.137245
# Unit test for constructor of class PyInfo
def test_PyInfo():
    global PyInfo

    class PyInfo(object):
        PY2 = True
        PY3 = False
        string_types = basestring,
        text_type = unicode
        binary_type = str
        integer_types = (int, long)
        class_types = (type, types.ClassType)
        maxsize = int((1 << 31) - 1)

    assert PyInfo.PY2
    assert not PyInfo.PY3
    assert PyInfo.maxsize == 2147483647
    assert PyInfo.integer_types == (int, long)
    assert PyInfo.strin

# Generated at 2022-06-12 08:13:37.009282
# Unit test for constructor of class PyInfo
def test_PyInfo():
    try:
        assert isinstance(PyInfo.__dict__, types.DictionaryType)
        assert isinstance(PyInfo.__doc__, types.StringType)
    except NameError:  # Python 3:
        assert isinstance(PyInfo.__dict__, dict)
        assert isinstance(PyInfo.__doc__, str)



# Generated at 2022-06-12 08:13:43.929978
# Unit test for constructor of class PyInfo
def test_PyInfo():
    i = PyInfo()
    # On PY2
    assert type(i.string_types) == tuple
    assert type(i.text_type) == unicode
    assert type(i.binary_type) == str
    assert type(i.integer_types) == tuple
    assert type(i.class_types) == tuple
    assert type(i.maxsize) == long
    # On PY3
    assert type(i.string_types) == tuple
    assert type(i.text_type) == str
    assert type(i.binary_type) == bytes
    assert type(i.integer_types) == tuple
    assert type(i.class_types) == type
    assert type(i.maxsize) == int



# Generated at 2022-06-12 08:13:45.957316
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.string_types
    assert PyInfo.text_type

# Generated at 2022-06-12 08:13:49.479059
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)



# Generated at 2022-06-12 08:13:53.703914
# Unit test for constructor of class PyInfo
def test_PyInfo():
    py_info = PyInfo()
    assert py_info.PY2 == sys.version_info[0] == 2
    assert py_info.PY3 == sys.version_info[0] == 3
    if py_info.PY3:
        assert py_info.maxsize == sys.maxsize
    return



# Generated at 2022-06-12 08:13:57.219686
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 is True or PyInfo.PY3 is True
    assert PyInfo.PY2 is not PyInfo.PY3
    assert PyInfo.string_types is not None
    assert PyInfo.text_type is not None
    assert PyInfo.binary_type is not None
    assert PyInfo.integer_types is not None
    assert PyInfo.class_types is not None
    assert PyInfo.maxsize is not None
    return



# Generated at 2022-06-12 08:13:58.481001
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    assert not PyInfo.PY3

# Generated at 2022-06-12 08:14:00.396877
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert not (PyInfo.PY2 and PyInfo.PY3)



# Generated at 2022-06-12 08:14:07.965608
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(2, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    elif PyInfo.PY3:
        assert isinstance('', PyInfo.string_types)
        assert isinstance('', PyInfo.text_type)
        assert isinstance(b'', PyInfo.binary_type)
        assert isinstance(2, PyInfo.integer_types)
        assert isinstance(type, PyInfo.class_types)
    else:
        raise RuntimeError("What's your Python version?")

# Generated at 2022-06-12 08:14:30.610949
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.text_type, type)



# Generated at 2022-06-12 08:14:40.289852
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY3:
        assert PyInfo.string_types == (str,)
        assert PyInfo.text_type is str
        assert PyInfo.binary_type is bytes
        assert PyInfo.integer_types == (int,)
        assert PyInfo.class_types == (type,)
    else:
        assert PyInfo.string_types == (basestring,)
        assert PyInfo.text_type is unicode
        assert PyInfo.binary_type is str
        assert PyInfo.integer_types == (int, long)
        assert PyInfo.class_types == (type, types.ClassType)

    assert isinstance('abc', PyInfo.string_types)
    assert isinstance(u'abc', PyInfo.text_type)
    assert isinstance(b'abc', PyInfo.binary_type)
    assert isinstance

# Generated at 2022-06-12 08:14:48.510679
# Unit test for constructor of class PyInfo
def test_PyInfo():
    info = PyInfo()
    assert info.PY3 is (sys.version_info > (3,))
    assert info.PY2 is not (sys.version_info > (3,))

    assert info.maxsize == sys.maxsize

    if sys.version_info > (3,):
        assert info.string_types == (str,)
        assert info.text_type == str
        assert info.binary_type == bytes
        assert info.integer_types == (int,)
        assert info.class_types == (type,)
    else:  # sys.version_info < (3,)
        assert info.string_types == (basestring,)
        assert info.text_type == unicode
        assert info.binary_type == str
        assert info.integer_types == (int, long)
        assert info.class_

# Generated at 2022-06-12 08:14:56.677403
# Unit test for constructor of class PyInfo
def test_PyInfo():
    if PyInfo.PY2:
        assert isinstance('', PyInfo.string_types)
        assert isinstance(u'', PyInfo.string_types)
        assert not isinstance(b'', PyInfo.string_types)

        assert isinstance(u'', PyInfo.text_type)
        assert not isinstance('', PyInfo.text_type)

        assert isinstance(b'', PyInfo.binary_type)
        assert not isinstance(u'', PyInfo.binary_type)

        assert isinstance(1, PyInfo.integer_types)

# Generated at 2022-06-12 08:14:58.781552
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert len(PyInfo.string_types) == 1
    assert PyInfo.string_types == (str,)
    assert PyInfo.PY3



# Generated at 2022-06-12 08:15:01.555891
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo().PY2
    assert PyInfo().PY3
    assert PyInfo().string_types
    assert PyInfo().text_type
    assert PyInfo().binary_type
    assert PyInfo().integer_types


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:15:05.978575
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.maxsize, (int, long))

# Generated at 2022-06-12 08:15:08.456597
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == (sys.version_info[0] == 3)


if __name__ == "__main__":
    import nose

    nose.runmodule()

# Generated at 2022-06-12 08:15:14.689418
# Unit test for constructor of class PyInfo
def test_PyInfo():
    """
    >>> info = PyInfo()
    >>> info.PY2
    True
    >>> info.PY3
    False
    >>> info.string_types
    (<type 'basestring'>,)
    >>> info.text_type
    <type 'unicode'>
    >>> info.binary_type
    <type 'str'>
    >>> info.integer_types
    (<type 'int'>, <type 'long'>)
    >>> info.class_types
    (<type 'type'>, <type 'classobj'>)
    >>> info.maxsize
    9223372036854775807
    """


if __name__ == "__main__":
    import doctest

    doctest.testmod()

# Generated at 2022-06-12 08:15:15.512013
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2
    ass

# Generated at 2022-06-12 08:16:15.265591
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("str", PyInfo.string_types)
    assert isinstance(u"unicode", PyInfo.string_types)
    assert type("str") is PyInfo.text_type
    assert type(u"unicode") is PyInfo.text_type
    assert type(b"bytes") is PyInfo.binary_type
    assert isinstance(100, PyInfo.integer_types)

# Generated at 2022-06-12 08:16:25.236704
# Unit test for constructor of class PyInfo
def test_PyInfo():
    from pyinfo import PyInfo
    from nose.tools import ok_
    ok_(isinstance(PyInfo.PY2, bool))
    ok_(isinstance(PyInfo.PY3, bool))
    ok_(isinstance(PyInfo.string_types, tuple))
    ok_(isinstance(PyInfo.text_type, type))
    ok_(isinstance(PyInfo.binary_type, type))
    ok_(isinstance(PyInfo.integer_types, tuple))
    ok_(isinstance(PyInfo.class_types, tuple))
    ok_(isinstance(PyInfo.maxsize, int))


# Execute only if run as a script
if __name__ == "__main__":
    import nose

    result = nose.runmodule()

# Generated at 2022-06-12 08:16:32.105869
# Unit test for constructor of class PyInfo
def test_PyInfo():
    # PY2
    if sys.version_info[0] == 2:
        assert PyInfo.PY3 is False
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, unicode)
        assert isinstance(PyInfo.binary_type, str)
        assert isinstance(PyInfo.integer_types, tuple)
        assert isinstance(PyInfo.class_types, tuple)
    # PY3
    else:
        assert PyInfo.PY2 is False
        assert isinstance(PyInfo.string_types, tuple)
        assert isinstance(PyInfo.text_type, str)
        assert isinstance(PyInfo.binary_type, bytes)
        assert isinstance(PyInfo.integer_types, tuple)

# Generated at 2022-06-12 08:16:35.598725
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.PY2, bool)
    assert isinstance(PyInfo.PY3, bool)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:16:42.090102
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 == (sys.version_info[0] == 2)
    assert PyInfo.PY3 == (sys.version_info[0] == 3)
    assert isinstance(PyInfo.maxsize, int)
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)

# Generated at 2022-06-12 08:16:44.298784
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert PyInfo.maxsize >= 0


test_PyInfo()

# Generated at 2022-06-12 08:16:47.267765
# Unit test for constructor of class PyInfo
def test_PyInfo():
    for symbol in PyInfo.__dict__:
        if not symbol.startswith('__'):
            assert hasattr(PyInfo, symbol)

# Generated at 2022-06-12 08:16:52.945773
# Unit test for constructor of class PyInfo
def test_PyInfo():
    class Test:  # noqa
        pass

    assert type('') in PyInfo.string_types
    assert type('some_string') in PyInfo.string_types
    assert '' in PyInfo.string_types
    assert 'some_string' in PyInfo.string_types

    assert type(u'unicode_string') in PyInfo.string_types
    assert u'unicode_string' in PyInfo.string_types

    assert type('') is PyInfo.text_type
    assert type("some_string") is PyInfo.text_type
    assert '' is PyInfo.text_type
    assert "some_string" is PyInfo.text_type

    assert u'unicode_string' is PyInfo.text_type

    assert type(bytes(b'binary_string')) is PyInfo.binary_type
   

# Generated at 2022-06-12 08:16:57.796693
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance(PyInfo.string_types, tuple)
    assert isinstance(PyInfo.text_type, type)
    assert isinstance(PyInfo.binary_type, type)
    assert isinstance(PyInfo.integer_types, tuple)
    assert isinstance(PyInfo.class_types, tuple)
    assert isinstance(PyInfo.maxsize, int)



# Generated at 2022-06-12 08:17:03.971118
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3 is True
    if PyInfo.PY2:
        assert sys.maxsize == PyInfo.maxsize
    else:
        assert sys.maxsize == PyInfo.maxsize * 2 + 1
    assert isinstance(True, bool)
    assert isinstance('', PyInfo.string_types)
    assert isinstance(b'', PyInfo.binary_type)
    assert isinstance(1, PyInfo.integer_types)
    assert isinstance(type, PyInfo.class_types)


if __name__ == '__main__':
    test_PyInfo()

# Generated at 2022-06-12 08:19:03.976147
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    assert isinstance("a", PyInfo.string_types)

# Generated at 2022-06-12 08:19:07.189180
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY2 or PyInfo.PY3
    try:
        assert len(b"abc") == 3
    except TypeError:
        pass
    else:
        assert False, "len(b\"abc\") should raise TypeError"



# Generated at 2022-06-12 08:19:17.071552
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.binary_type == bytes
    assert PyInfo.string_types == (str, )
    if sys.maxsize > 2 ** 32:
        assert PyInfo.maxsize == 2 ** 63 - 1
    else:
        assert PyInfo.maxsize == 2 ** 31 - 1


# TODO:
# decorators.py:     '''Method decorator.
# decorators.py:     '''Class decorator.
# decorators.py:     '''Property decorator.
# decorators.py:     '''Static method decorator.
# decorators.py:     '''Class method decorator.
# decorators.py:     '''Static property decorator.
# decorators.py:     '''Class property decorator.
# decorators.py:     '''Abstract method decorator.
# decorators.py:    

# Generated at 2022-06-12 08:19:23.829840
# Unit test for constructor of class PyInfo

# Generated at 2022-06-12 08:19:26.751023
# Unit test for constructor of class PyInfo
def test_PyInfo():
    assert PyInfo.PY3 == sys.version_info[0] == 3
    assert PyInfo.PY2 == sys.version_info[0] == 2

