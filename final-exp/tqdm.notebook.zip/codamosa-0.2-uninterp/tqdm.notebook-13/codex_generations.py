

# Generated at 2022-06-18 11:49:51.091004
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook

    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 4:
            break

# Generated at 2022-06-18 11:49:58.969076
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from IPython.display import display
    from IPython.display import clear_output
    import time
    import sys
    import os

    # Test 1: Test the method status_printer with a total
    #         and a description
    # Create a tqdm_notebook object
    tqdm_notebook_obj = tqdm_notebook(total=10, desc="Test 1")
    # Call the method status_printer
    container = tqdm_notebook_obj.status_printer(sys.stdout, 10, "Test 1")
    # Display the container
    display(container)
    # Update the container
    for i in range(10):
        time.sleep(0.1)
        tqdm_

# Generated at 2022-06-18 11:50:02.032984
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(5)):
        sleep(0.1)
        if i == 2:
            raise Exception("Test exception")


# Generated at 2022-06-18 11:50:13.484468
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
                if k == 50:
                    raise Exception("Boom!")


# Generated at 2022-06-18 11:50:24.776528
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_
    from IPython.html.widgets import ContainerWidget as HBox_
    from IPython.html.widgets import FloatProgressWidget as IProgress_
    from IPython.display import display
    from IPython.display import clear_output
    from IPython.core.display import display_html
    from IPython.core.display import display_javascript
    from IPython.core.display import display_markdown
    from IPython.core.display import display_png
    from IPython.core.display import display_svg
    from IPython.core.display import display_jpeg
    from IPython.core.display import display

# Generated at 2022-06-18 11:50:35.646354
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), total=10, leave=True):
        sleep(0.1)
    tqdm.reset(total=20)
    for i in tqdm(range(20), total=20, leave=True):
        sleep(0.1)
    tqdm.reset(total=30)
    for i in tqdm(range(30), total=30, leave=True):
        sleep(0.1)
    tqdm.reset(total=40)
    for i in tqdm(range(40), total=40, leave=True):
        sleep(0.1)
    tqdm.reset(total=50)

# Generated at 2022-06-18 11:50:40.787093
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        sleep(random())
    for i in tqdm_notebook(range(5), desc='2nd loop'):
        sleep(random())


# Generated at 2022-06-18 11:50:50.560780
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:51:02.093320
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method `status_printer` of class `tqdm_notebook`
    """
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm as auto_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10, desc="test")
    assert pbar.max == 10
    assert pbar.value == 0
    assert pbar.bar_style == ''
    assert pbar.layout.width == "20px"
    assert pbar.layout.display == 'inline-flex'
    assert pbar.layout.flex_flow == 'row wrap'

    # Test without total
    pbar = tqdm_notebook

# Generated at 2022-06-18 11:51:07.102565
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)


# Generated at 2022-06-18 11:51:32.996636
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    t = tqdm_notebook(range(3))
    t.reset(total=5)
    for i in t:
        sleep(0.1)
    t.reset()
    for i in t:
        sleep(0.1)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:51:39.832610
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    for _ in tqdm(range(5), desc='1st loop'):
        for _ in tqdm(range(5), desc='2nd loop', leave=False):
            for _ in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:51:51.304057
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm

    # Test with total
    with tqdm(total=10) as t:
        for i in range(5):
            sleep(0.1)
            t.update()
        t.reset(total=20)
        for i in range(10):
            sleep(0.1)
            t.update()
        t.reset(total=0)
        for i in range(5):
            sleep(0.1)
            t.update()

    # Test without total
    with tqdm() as t:
        for i in range(5):
            sleep(0.1)
            t.update()
        t.reset(total=20)
        for i in range(10):
            sleep(0.1)
            t.update()


# Generated at 2022-06-18 11:52:04.124114
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].max == 10
    assert pbar.children[2].value == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].max == 1
    assert pbar.children[2].value == ''

    # Test with desc
    pbar = tq

# Generated at 2022-06-18 11:52:14.114584
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    # Test display
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
        clear_output(wait=True)
    t.close()
    # Test display with error
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
        clear_output(wait=True)
        if i == 5:
            raise Exception
    t.close()

# Generated at 2022-06-18 11:52:25.704520
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            clear_output(wait=True)
            pbar.display(msg='test')
            pbar.display(msg='test2')
            pbar.display(msg='test3')
            pbar.display(msg='test4')
            pbar.display(msg='test5')
            pbar.display(msg='test6')
            pbar.display(msg='test7')
            pbar.display(msg='test8')
            pbar.display(msg='test9')

# Generated at 2022-06-18 11:52:36.511397
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10
    assert t.container.children[1].value == 10
    assert t.container.children[1].bar_style == 'success'
    assert t.container.children[1].max == 10
    assert t.container.children[1].min == 0

    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
        t.reset()
    assert t.n == 0
    assert t.container.children[1].value == 0
    assert t.container.children[1].bar_style == ''
    assert t.container.children[1].max == 10

# Generated at 2022-06-18 11:52:47.234139
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import display, clear_output
    from time import sleep
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    display(pbar)
    for i in range(100):
        pbar.value = i
        sleep(0.01)
    clear_output()
    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    display(pbar)
    for i in range(100):
        pbar.value = i
        sleep(0.01)
    clear_output()
    # Test with total and description
    pbar = tqdm_notebook.status_printer(None, total=100, desc="test")
    display(pbar)

# Generated at 2022-06-18 11:52:56.975289
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import random_sample
    from numpy.random import choice
    from numpy.random import shuffle
    from numpy.random import permutation
    from numpy.random import beta
    from numpy.random import binomial
    from numpy.random import chisquare
    from numpy.random import dirichlet
    from numpy.random import exponential
    from numpy.random import f
    from numpy.random import gamma
    from numpy.random import geometric
    from numpy.random import gumbel
    from numpy.random import hypergeometric
    from numpy.random import laplace
   

# Generated at 2022-06-18 11:53:01.351154
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:41.676370
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook

    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:53:43.977523
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:53:48.382343
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from random import random

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
            clear_output(wait=True)
            pbar.display()

# Generated at 2022-06-18 11:53:52.878141
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10), desc='1st loop'):
        sleep(0.01)
    for i in tqdm_notebook(range(5), desc='2nd loop'):
        sleep(0.01)

# Generated at 2022-06-18 11:53:59.853646
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from sys import stderr
    from re import search
    from random import random

    # Test 1: basic display
    with tqdm(total=10, file=stderr, desc="Test 1") as pbar:
        for i in range(10):
            pbar.set_description("Test 1: iteration %i" % i)
            sleep(random() / 5)
            pbar.update()
    # Test 2: display with error

# Generated at 2022-06-18 11:54:04.198466
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in t:
            sleep(0.1)
            t.set_description("test_tqdm_notebook___iter__")
            t.set_postfix(ordered_dict=dict(i=i))
            if i == 5:
                raise ValueError("i == 5")



# Generated at 2022-06-18 11:54:12.301642
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .std import TqdmTypeError

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10
    tqdm_notebook.status_printer(None, total=10)

    # Test the method status_printer of class tqdm_notebook
    # with a total of None
    tqdm_notebook.status_printer(None, total=None)

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10 and a description

# Generated at 2022-06-18 11:54:21.380851
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmNotebookDisplay(TestCase):
        def setUp(self):
            self.t = tqdm_notebook(total=10)

        def test_display(self):
            with patch('IPython.display.display') as mock_display:
                self.t.display()
                mock_display.assert_called_once_with(self.t.container)

        def test_display_close(self):
            with patch('IPython.display.display') as mock_display:
                self.t.display(close=True)
                mock_display.assert_called_once_with(self.t.container)


# Generated at 2022-06-18 11:54:30.728093
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)

    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)

    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)

    # Test

# Generated at 2022-06-18 11:54:39.535114
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError

    # Test display of tqdm_notebook
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test %i" % i)
            sleep(0.1)

    # Test display of tqdm_notebook
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test %i" % i)
            sleep(0.1)

    # Test display of tqdm_notebook

# Generated at 2022-06-18 11:55:39.178277
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm._utils import _term_move_up
    from tqdm._utils import _unicode

    # Test display of a progress bar
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test")
            pbar.update()
            sleep(0.1)

    # Test display of a progress bar with no total
    with tqdm(total=None) as pbar:
        for i in range(10):
            pbar.set_description("Test")
            pbar.update()
            sleep(0.1)

    # Test display of a progress bar with no total

# Generated at 2022-06-18 11:55:49.679899
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    tqdm.close()

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    tqdm

# Generated at 2022-06-18 11:55:52.010246
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.clear()
            t.update()


# Generated at 2022-06-18 11:56:01.797155
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.display import clear_output
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    clear_output()
    with tqdm_notebook(total=100, leave=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    clear_output()
    with tqdm_notebook(total=100, leave=True, ncols=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    clear_output()

# Generated at 2022-06-18 11:56:11.296825
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].max == 100
    assert pbar.children[2].value == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
   

# Generated at 2022-06-18 11:56:21.005202
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        for i in range(4):
            sleep(0.01)
            pbar.update()
    assert pbar.n == 3
    assert pbar.last_print_n == 3
    assert pbar.last_print_t == pbar.n
    assert pbar.total == 3
    assert pbar.dynamic_ncols
    assert pbar.ncols == 100
    assert pbar.unit == 'it'
    assert pbar.unit_scale == 1
    assert pbar.unit_divisor == 1
    assert pbar.miniters == 1
    assert pbar.mininterval == 0.1
    assert pbar.maxinterval == 10.0

# Generated at 2022-06-18 11:56:31.379048
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import TqdmTypeError

    # Test display
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.close()

    # Test display with error
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
        if i == 5:
            raise Exception("error")
    t.close()

    # Test display with error and leave
    t = tqdm(total=10, leave=True)
    for i in range(10):
        sleep(0.1)

# Generated at 2022-06-18 11:56:40.137294
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(5, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(5, desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 1:
            break
    for i in trange(5, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(5, desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 1:
            break

# Generated at 2022-06-18 11:56:49.576593
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm import tqdm
    from tqdm.notebook import tqdm_notebook
    from tqdm.auto import tqdm as tqdm_auto

    for tqdm_cls in [tqdm, tqdm_notebook, tqdm_auto]:
        with tqdm_cls(total=10) as t:
            assert repr(t) == t.__repr__()
            assert repr(t) == t.__repr__(pretty=False)
            assert repr(t) == t.__repr__(pretty=True)
            assert repr(t) == t.__repr__(pretty=None)
            t.update()
            assert repr(t) == t.__repr__()

# Generated at 2022-06-18 11:56:58.269614
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from IPython.display import clear_output
    from time import sleep

    # Test 1: no total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 0
    assert pbar.children[2].value == ''
    assert pbar.children[1].bar_style == 'info'

    # Test 2: with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
   