

# Generated at 2022-06-18 11:50:02.833868
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    from tqdm import tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear()
    tqdm_notebook.close()

# Generated at 2022-06-18 11:50:09.451855
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map

    def f(x):
        sleep(0.01)
        return x

    with tqdm(total=10) as pbar:
        process_map(f, range(10), max_workers=4, pbar=pbar)


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:50:21.512638
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset()
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)

# Generated at 2022-06-18 11:50:25.196410
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear()
            tqdm_notebook.close()
            break

# Generated at 2022-06-18 11:50:36.078486
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from random import randint
    from IPython.display import clear_output
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break
    clear_output()
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break
   

# Generated at 2022-06-18 11:50:47.550477
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    # Initialise
    with tqdm(total=10, leave=False, desc='Test') as pbar:
        # Print
        pbar.display()
        # Update
        pbar.update()
        # Clear
        clear_output(wait=True)
        # Print again
        pbar.display()
        # Update
        pbar.update()
        # Clear
        clear_output(wait=True)
        # Print again
        pbar.display()
        # Update
        pbar.update()
        # Clear
        clear_output(wait=True)
        # Print again
        pbar.display()


# Generated at 2022-06-18 11:50:59.618447
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib import tenumerate
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from tqdm.contrib.concurrent import thread_map_reduce
    from tqdm.contrib.concurrent import thread_map_combo
    from tqdm.contrib.concurrent import thread_map_async
    from tqdm.contrib.concurrent import thread_map_sync
    from tqdm.contrib.concurrent import thread_map_unordered
    from tqdm.contrib.concurrent import thread_map_unordered_barrier
    from tqdm.contrib.concurrent import thread_map_

# Generated at 2022-06-18 11:51:06.545962
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=100)
    for i in tqdm(range(100)):
        sleep(0.1)
    tqdm.reset(total=0)
    for i in tqdm(range(10)):
        sleep(0.1)

# Generated at 2022-06-18 11:51:10.978662
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")
        if i == 6:
            break


# Generated at 2022-06-18 11:51:14.277333
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:51:40.311500
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:51:51.917594
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _term_move_up

    # Test tqdm_notebook.display()
    t = tqdm_notebook(total=10)
    t.display()
    t.display(close=True)

    # Test tqdm_notebook.display() with msg
    t = tqdm_notebook(total=10)
    t.display(msg='test')
    t.display(msg='test', close=True)

    # Test tqdm_notebook.display() with bar_style
    t = tqdm_notebook(total=10)
    t.display(bar_style='success')
    t.display(bar_style='success', close=True)

# Generated at 2022-06-18 11:51:54.264149
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as t:
        t.clear()
        t.update()
        t.close()

# Generated at 2022-06-18 11:52:07.495823
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from random import random

    # Test display
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            sleep(random() / 10)
            pbar.update(1)
    clear_output()

    # Test display with error
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            sleep(random() / 10)
            pbar.update(1)
            if random() < 0.1:
                raise ValueError("Error!")
    clear_output()

    # Test display with error and leave

# Generated at 2022-06-18 11:52:11.930221
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
    assert pbar.displayed is False


# Generated at 2022-06-18 11:52:23.415244
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    # Test with total
    with tqdm_notebook(total=10) as t:
        assert t.total == 10
        t.reset(total=5)
        assert t.total == 5
        t.reset(total=15)
        assert t.total == 15
        t.reset(total=None)
        assert t.total is None
        t.reset(total=0)
        assert t.total == 0
        t.reset(total=None)
        assert t.total is None
        t.reset(total=10)
        assert t.total == 10
        t.reset(total=None)
        assert t.total is None
        t.reset(total=0)
        assert t.total == 0

# Generated at 2022-06-18 11:52:27.038040
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)


# Generated at 2022-06-18 11:52:38.091521
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmWarning
    from .std import TqdmSkipped
    from .std import TqdmClosed
    from .std import TqdmExperimentalWarning
    from .std import TqdmKeyError
    from .std import TqdmTypeError
    from .std import TqdmWarning
    from .std import TqdmDeprecationWarning
    from .std import TqdmMonitorWarning

# Generated at 2022-06-18 11:52:48.334574
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    # Test display
    with tqdm(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.display(str(i))
            pbar.update()

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.display(str(i))
            if i == 5:
                raise ValueError("Error!")
            pbar.update()

    # Test display with error and manual mode

# Generated at 2022-06-18 11:52:52.781635
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception()


# Generated at 2022-06-18 11:54:03.441539
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("test")
        else:
            continue

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:54:07.012746
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=5) as pbar:
        for i in range(5):
            sleep(0.5)
            pbar.update()

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:54:13.509386
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed
    from .utils import format_size
    from .utils import format_len
    from .utils import format_interval
    from .utils import format_interval_short
    from .utils import format_interval_long
    from .utils import format_interval_minimal
    from .utils import format_interval_guess
    from .utils import format_interval_guess_minimal

# Generated at 2022-06-18 11:54:22.393053
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import display
    from IPython.display import clear_output
    from IPython.display import HTML

    # Test 1
    pbar = tqdm_notebook.status_printer(None, total=10)
    display(pbar)
    pbar.children[1].value = 5
    pbar.children[0].value = 'Test 1'
    pbar.children[2].value = 'Test 1'
    clear_output(wait=1)

    # Test 2
    pbar = tqdm_notebook.status_printer(None, total=10)
    display(pbar)
    pbar.children[1].value = 5
    pbar.children[0].value = HTML('Test 2')
    pbar.children[2].value = HTML('Test 2')
    clear_output

# Generated at 2022-06-18 11:54:24.933756
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        t.clear()
        t.update()
        t.clear()
        t.update()
        t.clear()

# Generated at 2022-06-18 11:54:28.997157
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(4, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            for k in tnrange(50, desc='3nd loop'):
                sleep(0.01)


# Generated at 2022-06-18 11:54:36.003727
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = None

    # Test display of tqdm_notebook
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-1].value == ''

    # Test display of t

# Generated at 2022-06-18 11:54:41.332916
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)


# Generated at 2022-06-18 11:54:44.028331
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break


# Generated at 2022-06-18 11:54:47.094381
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(5)):
        sleep(0.1)


# Generated at 2022-06-18 11:55:52.196582
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:56:02.068810
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std

    # Test basic instantiation
    with tqdm_notebook(total=10) as t:
        assert isinstance(t, tqdm_notebook)
        assert not isinstance(t, tqdm_gui)
        assert not isinstance(t, tqdm_std)

    # Test basic instantiation with gui=False
    with tqdm_notebook(total=10, gui=False) as t:
        assert isinstance(t, tqdm_notebook)
        assert not isinstance(t, tqdm_gui)
        assert isinstance(t, tqdm_std)

    # Test basic

# Generated at 2022-06-18 11:56:11.489007
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib import tenumerate

    # Test tqdm_notebook
    for i in tqdm_notebook(tenumerate(range(5)), total=5, leave=True):
        sleep(0.01)
    for i in tqdm_notebook(tenumerate(range(5)), total=5, leave=False):
        sleep(0.01)

    # Test tqdm_notebook.reset
    for i in tqdm_notebook(tenumerate(range(5)), total=5, leave=True):
        sleep(0.01)
        if i[0] == 3:
            tqdm_notebook.reset(total=10)

# Generated at 2022-06-18 11:56:21.323672
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from random import random
    from sys import stderr

    # Test 1
    for i in tqdm(range(10), desc='1st loop', leave=False):
        sleep(random())
    # Test 2
    for i in tqdm(range(10), desc='2nd loop', leave=True):
        sleep(random())
    # Test 3
    for i in tqdm(range(10), desc='3rd loop', leave=True):
        sleep(random())
        if i == 5:
            break
    # Test 4
    for i in tqdm(range(10), desc='4th loop', leave=True):
        sleep(random())
        if i == 5:
            raise Exception()
    # Test 5

# Generated at 2022-06-18 11:56:31.586278
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:56:41.949536
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.utils import _supports_unicode
    from tqdm.auto import tqdm

    with tqdm(total=10) as pbar:
        pbar.update(5)
        hbox = pbar.container
        assert repr(hbox) == pbar.format_meter(**hbox._repr_json_(False))
        assert repr(hbox) == pbar.format_meter(**hbox._repr_json_(True))
        if _supports_unicode():
            assert repr(hbox) == pbar.format_meter(**hbox._repr_json_(None))
        else:
            assert repr(hbox) != pbar.format_meter(**hbox._repr_json_(None))


if __name__ == '__main__':
    test_Tq

# Generated at 2022-06-18 11:56:51.479348
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
            clear_output()
        clear_output()
    clear_output()

# Generated at 2022-06-18 11:56:59.517153
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 4:
            raise Exception("Test exception")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 4:
            raise KeyboardInterrupt("Test KeyboardInterrupt")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 4:
            raise StopIteration("Test StopIteration")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 4:
            raise GeneratorExit("Test GeneratorExit")

# Generated at 2022-06-18 11:57:08.715287
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from numpy.random import randint
    from numpy.random import uniform
    from numpy.random import normal
    from numpy.random import exponential
    from numpy.random import poisson
    from numpy.random import binomial
    from numpy.random import negative_binomial
    from numpy.random import geometric
    from numpy.random import hypergeometric
    from numpy.random import logseries
    from numpy.random import zipf
    from numpy.random import pareto
    from numpy.random import weibull
    from numpy.random import power
    from numpy.random import laplace
    from numpy.random import gumbel
    from numpy.random import logistic
    from numpy.random import ray

# Generated at 2022-06-18 11:57:18.135581
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset()
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)