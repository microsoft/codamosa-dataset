

# Generated at 2022-06-18 11:49:59.234698
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:50:09.925036
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from random import random

    # Test display()
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display()
        sleep(random())
    t.close()
    clear_output()

    # Test display(msg)
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(msg='msg')
        sleep(random())
    t.close()
    clear_output()

    # Test display(pos)
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(pos=i)
        sleep(random())
    t.close()
    clear_output()

    #

# Generated at 2022-06-18 11:50:21.977239
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            pbar.clear()
            pbar.write("test")
            pbar.update()
            pbar.clear()
            pbar.write("test2")
            pbar.update()
            pbar.clear()
            pbar.write("test3")
            pbar.update()
            pbar.clear()
            pbar.write("test4")
            pbar.update()
            pbar.clear()
            pbar.write("test5")
            pbar.update()
            pbar.clear()
            pbar.write("test6")
            pbar.update()
            pbar.clear()
           

# Generated at 2022-06-18 11:50:27.907708
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    pbar.reset(total=20)
    for i in range(20):
        sleep(0.1)
        pbar.update()
    pbar.close()

# Generated at 2022-06-18 11:50:39.638410
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test tqdm_notebook.status_printer
    """
    from tqdm.notebook import tqdm_notebook
    from tqdm.auto import tqdm
    from tqdm.utils import _term_move_up

    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)
    # Test with total and desc
    tqdm_notebook.status_printer(None, total=10, desc="desc")
    # Test without total and desc
    tqdm_notebook.status_printer(None, desc="desc")
    # Test with total, desc and ncols

# Generated at 2022-06-18 11:50:50.664598
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import trange
    from tqdm.notebook import tqdm_notebook
    for i in trange(3, desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        for j in tqdm_notebook(range(100), desc='3rd loop', leave=False):
            sleep(0.01)
        for j in tqdm_notebook(range(100), desc='4th loop', leave=False):
            sleep(0.01)
        for j in tqdm_notebook(range(100), desc='5th loop', leave=False):
            sleep(0.01)

# Generated at 2022-06-18 11:51:02.194876
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    total = 10
    pbar = tqdm_notebook.status_printer(None, total, "desc", None)
    assert pbar.children[0].value == "desc"
    assert pbar.children[1].max == total
    assert pbar.children[2].value == ""

    # Test without total
    pbar = tqdm_notebook.status_printer(None, None, "desc", None)
    assert pbar.children[0].value == "desc"
    assert pbar.children[1].max == 1
    assert pbar.children[1].bar_style == 'info'
    assert pbar.children[2].value == ""

    # Test with ncols

# Generated at 2022-06-18 11:51:12.257226
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
                if k == 50:
                    raise Exception("Test Exception")

if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-18 11:51:21.889177
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tqdm as tqdm_std
    from tqdm import trange as trange_std

    for i in trange(3, desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop'):
            sleep(0.01)

    for i in trange_std(3, desc='1st loop'):
        for j in tqdm_std(range(100), desc='2nd loop'):
            sleep(0.01)


# Generated at 2022-06-18 11:51:23.930143
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(5)):
        sleep(0.1)


# Generated at 2022-06-18 11:51:48.102288
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from numpy.random import randint
    for _ in tqdm_notebook(range(10)):
        sleep(random())
    for _ in tqdm_notebook(arange(10)):
        sleep(random())
    for _ in tqdm_notebook(randint(10, size=10)):
        sleep(random())
    for _ in tqdm_notebook(randint(10, size=10), leave=True):
        sleep(random())
    for _ in tqdm_notebook(randint(10, size=10), leave=False):
        sleep(random())

# Generated at 2022-06-18 11:51:59.225589
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std

    # Test tqdm_notebook.display()
    t = tqdm_notebook(total=10)
    t.display()
    t.display(close=True)

    # Test tqdm_notebook.display() with error
    t = tqdm_notebook(total=10)
    t.display()
    t.display(bar_style='danger')
    t.display(close=True)

    # Test tqdm_notebook.display() with error and leave
    t = tqdm_notebook(total=10, leave=True)
    t.display()
    t.display(bar_style='danger')
    t.display(close=True)

    # Test

# Generated at 2022-06-18 11:52:09.500077
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception()
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt()


# Generated at 2022-06-18 11:52:20.969033
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test with no total
    container = tqdm_notebook.status_printer(None)
    assert container.children[-2].max == 1
    assert container.children[-2].bar_style == 'info'

    # Test with total
    container = tqdm_notebook.status_printer(None, total=100)
    assert container.children[-2].max == 100
    assert container.children[-2].bar_style == ''

    # Test with total and ncols
    container = tqdm_notebook.status_printer(None, total=100, ncols=100)
    assert container.children[-2].max == 100
    assert container.children[-2].bar_style

# Generated at 2022-06-18 11:52:29.796276
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import trange
    from time import sleep
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for k in trange(50, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for k in trange(50, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:52:41.028621
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
                if random() < 0.1:
                    raise ValueError('Oops!')

# Generated at 2022-06-18 11:52:50.055492
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert pbar.max == 10
    assert pbar.value == 0
    assert pbar.bar_style == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert pbar.max == 1
    assert pbar.value == 1
    assert pbar.bar_style == 'info'

    # Test with desc
    pbar = tqdm_notebook.status_printer(None, total=10, desc="test")
    assert pbar.children[0].value == "test"

    # Test with ncols
    pbar = t

# Generated at 2022-06-18 11:53:00.420365
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.container.children[-2].style.bar_color == 'lightgreen'
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].min == 0
    assert pbar.container.children[-2].step == 1
    assert pbar.container.children[-2].description == ''

# Generated at 2022-06-18 11:53:10.020230
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(random() / 100)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(random() / 100)
                if random() < 0.1:
                    raise Exception()

# Generated at 2022-06-18 11:53:12.060268
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
        if i == 1:
            raise ValueError("Error in iteration")


# Generated at 2022-06-18 11:53:44.426127
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:53:46.837874
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:53:52.701005
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3rd loop', leave=True):
                sleep(0.01)
        tqdm_notebook.reset()

# Generated at 2022-06-18 11:53:59.636537
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmNotebookStatusPrinter(TestCase):
        def setUp(self):
            self.tqdm_notebook = tqdm_notebook
            self.tqdm_notebook.status_printer = tqdm_notebook.status_printer
            self.tqdm_notebook.status_printer.__self__ = tqdm_notebook

        def test_status_printer_no_total(self):
            with patch('sys.stderr', new=sys.stdout):
                self.assertEqual(
                    self.tqdm_notebook.status_printer(
                        None, total=None, desc=None, ncols=None),
                    None)


# Generated at 2022-06-18 11:54:07.822967
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm
    from tqdm.notebook import tqdm_notebook
    for cls in (tqdm, tqdm_notebook):
        with cls(total=10) as pbar:
            for i in range(10):
                pbar.update()
                sleep(.1)
        with cls(total=10) as pbar:
            for i in range(10):
                pbar.update(1)
                sleep(.1)
        with cls(total=10) as pbar:
            for i in range(10):
                pbar.update(i)
                sleep(.1)
        with cls(total=10) as pbar:
            for i in range(10):
                pbar.update(i + 1)


# Generated at 2022-06-18 11:54:11.756156
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:54:17.080538
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                if random() > 0.9:
                    raise Exception()


# Generated at 2022-06-18 11:54:21.339515
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.update(5)

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:54:28.122494
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:54:35.393599
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count

    # Test 1
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test 2
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    # Test 3
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(i + 1)



# Generated at 2022-06-18 11:55:05.210178
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    with tqdm_notebook(total=10, desc="test") as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            # pbar.refresh()
            # print("\r" + _term_move_up() + "test")
            # print("\r" + _term_move_up() + "test")
            # print("\r" + _term_move_up() + "test")
            # print("\r" + _term_move_up() + "test")
            # print("\r" + _term_move_up() + "test")
            # print("\r" +

# Generated at 2022-06-18 11:55:16.485448
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook.
    """
    from time import sleep
    from random import random
    from sys import version_info

    # Test with no total
    with tqdm_notebook(desc="Test 1") as pbar:
        for i in range(10):
            sleep(random() / 2)
            pbar.update()

    # Test with total
    with tqdm_notebook(total=10, desc="Test 2") as pbar:
        for i in range(10):
            sleep(random() / 2)
            pbar.update()

    # Test with total=None
    with tqdm_notebook(total=None, desc="Test 3") as pbar:
        for i in range(10):
            sleep(random() / 2)

# Generated at 2022-06-18 11:55:22.095833
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    tqdm_notebook().close()


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-18 11:55:32.539883
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError

    # Test with a range
    for i in trange(10):
        sleep(0.01)

    # Test with a list
    for i in tqdm(list(range(10))):
        sleep(0.01)

    # Test with a generator
    for i in tqdm(range(10)):
        sleep(0.01)

    # Test with a generator that raises StopIteration
    def gen():
        for i in range(10):
            yield i
            if i == 5:
                raise StopIteration
    for i in tqdm(gen()):
        sleep(0.01)

    # Test with a generator that

# Generated at 2022-06-18 11:55:42.382385
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.notebook import tqdm_notebook

    for cls in [tqdm, tqdm_notebook]:
        with cls(total=3, leave=True) as pbar:
            pbar.display(msg='test')
            sleep(0.1)
            pbar.display(msg='test', bar_style='info')
            sleep(0.1)
            pbar.display(msg='test', bar_style='success')
            sleep(0.1)
            pbar.display(msg='test', bar_style='warning')
            sleep(0.1)
            pbar.display(msg='test', bar_style='danger')
            sleep(0.1)

# Generated at 2022-06-18 11:55:48.399533
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(10, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            sleep(0.01)
    for i in tnrange(10, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-18 11:55:52.690852
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:56:02.595727
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map

    def display_test(bar):
        bar.display()
        bar.display(pos=0)
        bar.display(pos=1)
        bar.display(pos=0, close=True)
        bar.display(pos=1, close=True)
        bar.display(pos=0, bar_style='success')
        bar.display(pos=1, bar_style='success')
        bar.display(pos=0, bar_style='success', close=True)
        bar.display(pos=1, bar_style='success', close=True)
        bar.display(pos=0, bar_style='danger')
        bar.display(pos=1, bar_style='danger')
        bar.display

# Generated at 2022-06-18 11:56:11.970520
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:56:21.970188
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i)
    # Test display with msg
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, msg="test")
    # Test display with bar_style
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, bar_style="success")
    # Test display with close

# Generated at 2022-06-18 11:56:52.573186
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        tqdm_notebook.set_description('Finished loop %i' % i)

# Generated at 2022-06-18 11:56:56.470384
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:56:59.944989
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    with tqdm_notebook(total=10, desc="test", leave=True) as pbar:
        for _ in range(10):
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:09.157169
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning

    # Initialize tqdm
    t = tqdm_notebook(total=10)
    t.update(5)

    # Test __repr__
    assert t.container.__repr__() == t.container.__repr__(True)
    assert t.container.__repr__() == t.container.__repr__(False)
    assert t.container.__repr__() == t.container.__repr__(None)
    assert t.container.__repr__() == t.container.__repr__(1)

# Generated at 2022-06-18 11:57:18.554821
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from tqdm.contrib.concurrent import thread_map_reduce
    from tqdm.contrib.concurrent import thread_map_completed
    from tqdm.contrib.concurrent import thread_map_completed_reduce
    from tqdm.contrib.concurrent import thread_map_reduce_bar
    from tqdm.contrib.concurrent import thread_map_reduce_bar_completed
    from tqdm.contrib.concurrent import thread_map_reduce_bar_completed_reduce
    from tqdm.contrib.concurrent import thread_map_bar

# Generated at 2022-06-18 11:57:28.469314
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, HBox)
    assert len(pbar.children) == 3
    assert isinstance(pbar.children[0], HTML)
    assert isinstance(pbar.children[1], IProgress)
    assert isinstance(pbar.children[2], HTML)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0

    # Test without total
    pbar = tqdm_notebook.status_printer

# Generated at 2022-06-18 11:57:39.300166
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test method __repr__ of class TqdmHBox.
    """
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _range

    # Test with a simple bar
    bar = tqdm_notebook(_range(10), desc='test')
    bar.display()
    assert repr(bar.container) == 'test:  10%|█         | 1/10 [00:00<?, ?it/s]'

    # Test with a bar with a dynamic width
    bar = tqdm_notebook(_range(10), desc='test', ncols=100)
    bar.display()
    assert repr(bar.container) == 'test:  10%|█         | 1/10 [00:00<?, ?it/s]'

    # Test with a bar with

# Generated at 2022-06-18 11:57:42.238974
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:57:44.515085
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10), desc="test"):
        sleep(0.1)


# Generated at 2022-06-18 11:57:49.898476
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange

    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    print('Done.')


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:59:10.179332
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        sleep(random())
    for i in tqdm_notebook(range(5), desc='2nd loop'):
        sleep(random())


# Generated at 2022-06-18 11:59:13.528702
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:59:17.293638
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.container.children[-2].bar_style == 'success'


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:59:23.497912
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:59:26.263952
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

# Generated at 2022-06-18 11:59:33.154389
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == pbar.total
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == pbar.total
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        raise Exception
    assert pbar.n < pbar.total
    assert pbar.container.children[-2].bar_style == 'danger'
    assert pbar.container.children[-2].value == pbar.n