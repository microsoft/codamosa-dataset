

# Generated at 2022-06-18 11:49:40.954980
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .gui import tqdm_gui
    from .std import tqdm as std_tqdm
    from .utils import _range

    # Test with a range
    for cls in (tqdm_notebook, tqdm_gui):
        with cls(_range(10), leave=True) as pbar:
            assert pbar.total == 10
            assert pbar.n == 0
            assert pbar.ncols is None
            assert pbar.desc == ''
            assert pbar.unit == ''
            assert pbar.unit_scale is False
            assert pbar.dynamic_ncols is False
            assert pbar.miniters == 1
            assert pbar.mininterval == 0.1


# Generated at 2022-06-18 11:49:49.772662
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert container.children[0].value == ''
    assert container.children[1].value == 0
    assert container.children[2].value == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert container.children[0].value == ''
    assert container.children[1].value == 1
    assert container.children[2].value == ''

    # Test with desc
    container = tqdm_notebook.status_printer(None, total=10, desc='desc')
    assert container.children[0].value == 'desc'
    assert container.children

# Generated at 2022-06-18 11:49:58.241874
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            tqdm.write("cleared")
            t

# Generated at 2022-06-18 11:50:08.733581
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.total == 10
    assert t.ncols == '100%'
    assert t.container.layout.width == '100%'
    assert t.container.layout.display == 'inline-flex'
    assert t.container.layout.flex_flow == 'row wrap'
    assert t.container.children[-2].layout.flex == '2'
    assert t.container.children[-2].layout.width == '100%'
    assert t.container.children[-2].layout.height == '100%'

# Generated at 2022-06-18 11:50:20.547811
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:50:23.522698
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:50:33.993003
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from time import sleep
    from sys import stderr

    # Test display
    with tqdm(total=10, file=stderr, ncols=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, i, bar_style='success')
            pbar.display(i, i, bar_style='danger')
            pbar.display(i, i, bar_style='info')
            pbar.display(i, i, bar_style='warning')
            pbar.display(i, i, bar_style='')
            pbar.display(i, i, bar_style='success')
            pbar.display(i, i, bar_style='danger')
            pbar.display

# Generated at 2022-06-18 11:50:45.770671
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        pbar.clear()
        pbar.update(1)
        pbar.clear()
        pbar.update(2)
        pbar.clear()
        pbar.update(3)
        pbar.clear()
        pbar.update(4)
        pbar.clear()
        pbar.update(5)
        pbar.clear()
        pbar.update(6)
        pbar.clear()
        pbar.update(7)
        pbar.clear()
        pbar.update(8)
        pbar.clear()
        pbar.update(9)
        pbar.clear()
        pbar.update(10)
        pbar.clear()
        pbar.update(11)
        pbar.clear

# Generated at 2022-06-18 11:50:51.325723
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm
    from tqdm.notebook import tqdm_notebook

    for cls in (tqdm, tqdm_notebook):
        with cls(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()



# Generated at 2022-06-18 11:50:56.278565
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:51:18.864047
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tqdm as tqdm_std
    from tqdm import trange as trange_std

    for t in [tqdm, trange]:
        for i in t(range(10)):
            sleep(0.1)
        for i in t(range(10)):
            sleep(0.1)
            break
        for i in t(range(10)):
            sleep(0.1)
            raise Exception("Test exception")

    for t in [tqdm_std, trange_std]:
        for i in t(range(10)):
            sleep(0.1)

# Generated at 2022-06-18 11:51:22.329167
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)
    tqdm.close()



# Generated at 2022-06-18 11:51:30.820414
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with no total
    pbar = tqdm_notebook.status_printer(None, total=None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].bar_style == 'info'
    assert pbar.children[2].value == ''

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert p

# Generated at 2022-06-18 11:51:38.796138
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from time import sleep
    from sys import stderr
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stderr', stderr):
        with tqdm(total=10, file=stderr) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:51:49.966122
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=100)
    assert container.children[0].value == ''
    assert container.children[1].value == 0
    assert container.children[2].value == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert container.children[0].value == ''
    assert container.children[1].value == 1
    assert container.children[2].value == ''

    # Test with desc
    container = tqdm_notebook.status_printer(None, total=100, desc='desc')
    assert container.children[0].value == 'desc'
    assert container.children

# Generated at 2022-06-18 11:52:02.740353
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError

    # Test tqdm_notebook.close()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert not pbar.displayed

    # Test tqdm_notebook.close() with error
    try:
        with tqdm(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
                if i == 5:
                    raise Exception
    except Exception:
        pass
    assert pbar.displayed

    # Test tqdm_notebook

# Generated at 2022-06-18 11:52:14.640752
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 10

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 1

    # Test with desc
   

# Generated at 2022-06-18 11:52:26.111513
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        for i in range(4):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 3
    assert pbar.container.children[-2].style.bar_color == 'danger'
    with tqdm_notebook(total=3) as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 3
    assert pbar.container.children[-2].style.bar_color == 'success'
    with tqdm_notebook(total=3) as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:52:36.930150
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError
    from tqdm import TqdmKeyError
    from tqdm import TqdmDeprecationWarning

    # Test 1: update() with no arguments
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test 2: update() with a number
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    # Test 3: update() with a number greater than 1

# Generated at 2022-06-18 11:52:38.089572
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(10)):
        pass
    tqdm_notebook.clear()

# Generated at 2022-06-18 11:53:33.503608
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            tqdm.clear(True)
            tqdm.close()
            tqdm.clear(False)
            tqdm.close()
            tqdm.clear()
            tqdm.close()
            tqdm.clear(False)
            tqdm.close()
            tqdm.clear(True)
            tqdm.close()
            tqdm.clear()

# Generated at 2022-06-18 11:53:38.954298
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        tqdm.reset()
        tqdm.set_description('Finished loop %i' % i)
    tqdm.close()

# Generated at 2022-06-18 11:53:48.390336
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError

    # Test display()
    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)
        sleep(0.1)

    # Test display() with bar_style
    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)
            if j == 50:
                tqdm.write("Error!")
                tqdm.display(bar_style='danger')
        sleep(0.1)

    # Test display() with close

# Generated at 2022-06-18 11:53:51.455263
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:54:00.099519
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep

    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display()
        sleep(0.1)
        clear_output(wait=True)
    t.close()

    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(msg='{:d}'.format(i))
        sleep(0.1)
        clear_output(wait=True)
    t.close()

    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(msg='{:d}'.format(i), bar_style='success')
        sleep(0.1)

# Generated at 2022-06-18 11:54:08.317066
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    from tqdm.notebook import IProgress
    from tqdm.notebook import HTML
    from tqdm.notebook import HBox
    from tqdm.notebook import display
    from tqdm.notebook import escape
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import trange
    from tqdm.notebook import tqdm
    from tqdm.notebook import tnrange
    from tqdm.notebook import _range
    from tqdm.notebook import std_tqdm
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import TqdmHBox
    from tqdm.notebook import IProgress

# Generated at 2022-06-18 11:54:16.748250
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 4:
            break

# Generated at 2022-06-18 11:54:24.623840
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.01)



# Generated at 2022-06-18 11:54:26.604396
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)



# Generated at 2022-06-18 11:54:29.934916
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:55:03.106251
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm

    t = tqdm_notebook(total=10)
    for i in t:
        t.display(msg='{:.2f}'.format(i / 10))
        sleep(0.1)
    t.close()

    t = tqdm_notebook(total=10)
    for i in t:
        t.display(msg='{:.2f}'.format(i / 10), bar_style='success')
        sleep(0.1)
    t.close()

    t = tqdm_notebook(total=10)

# Generated at 2022-06-18 11:55:06.202385
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

# Generated at 2022-06-18 11:55:17.077212
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            break
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            break

# Generated at 2022-06-18 11:55:23.734709
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    from time import sleep
    from tqdm.notebook import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear()
    tqdm_notebook.close()

# Generated at 2022-06-18 11:55:33.830683
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.tests import pretest_posttest

    # Test 1: Test display of tqdm_notebook
    with pretest_posttest() as (pt, pt_):
        for _ in tqdm(range(2), desc='1st loop', leave=False):
            pt.display()
            sleep(0.5)
        pt.display(close=True)
        for _ in tqdm(range(2), desc='2nd loop', leave=False):
            pt.display()
            sleep(0.5)
        pt.display(close=True)

    # Test 2: Test display of tqdm_notebook with error

# Generated at 2022-06-18 11:55:38.092503
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test Exception")

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:48.698604
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    # Test reset
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)
        pbar.reset()
        for i in range(10):
            sleep(.1)
            pbar.update(10)
    # Test reset with total
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)

# Generated at 2022-06-18 11:55:58.083331
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    pbar.clear()
    assert pbar.n == 0
    assert pbar.last_print_n == 0
    assert pbar.total == 10
    assert pbar.last_print_t == 0
    assert pbar.dynamic_ncols == False
    assert pbar.ncols == None
    assert pbar.smoothing == 0.3
    assert pbar.avg_time == 0.1
    assert pbar.avg_size == 1

# Generated at 2022-06-18 11:56:07.719765
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_widget
    from IPython.html.widgets import ContainerWidget as HBox_widget
    from IPython.html.widgets import FloatProgressWidget as FloatProgress_widget
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import TqdmHBox
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import tqdm_note

# Generated at 2022-06-18 11:56:10.180629
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        tqdm_notebook.update()


# Generated at 2022-06-18 11:57:00.961468
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from tqdm.auto import tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:57:10.405233
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
    with tqdm_notebook(total=10, leave=False) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
    with tqdm_notebook(total=10, leave=True, ncols=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)

# Generated at 2022-06-18 11:57:19.718906
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:57:29.731586
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(100)):
        pass
    tqdm_notebook.clear()
    for _ in tqdm_notebook(range(100)):
        pass


if __name__ == '__main__':
    from time import sleep
    from tqdm import tqdm_notebook

    # Test
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop', leave=False):
            sleep(0.01)

# Generated at 2022-06-18 11:57:40.677227
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std

    # Test display method of class tqdm_notebook
    for cls in (tqdm_notebook, tqdm_gui, tqdm_std):
        # Test display method of class tqdm_notebook
        t = cls(total=10)
        t.display(msg='test')
        t.display(msg='test', bar_style='success')
        t.display(msg='test', bar_style='danger')
        t.display(msg='test', bar_style='warning')
        t.display(msg='test', bar_style='info')
        t.display(msg='test', bar_style='default')

# Generated at 2022-06-18 11:57:43.312740
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for _ in tqdm_notebook(range(10)):
        sleep(random() / 10)


# Generated at 2022-06-18 11:57:51.692003
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _term_move_up
    from .utils import _unicode

    # Test with tqdm_notebook
    t = tqdm_notebook(total=10, desc='test', leave=False)
    t.display()
    assert t.container.children[-2].bar_style == ''
    t.display(bar_style='success')
    assert t.container.children[-2].bar_style == 'success'
    t.display(bar_style='danger')
    assert t.container.children[-2].bar_style == 'danger'
    t.display(bar_style='info')

# Generated at 2022-06-18 11:57:53.765074
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tnrange
    for _ in tnrange(2):
        pass
    for _ in tnrange(2):
        pass

# Generated at 2022-06-18 11:58:01.064301
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook

    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 1:
            for k in tqdm_notebook(range(100), desc='3rd loop', leave=True):
                sleep(0.01)
            tqdm_notebook.reset()
            assert tqdm_notebook.n == 0
            assert tqdm_notebook.last_print_n == 0
            assert tqdm_notebook.dynamic_ncols
            assert tqdm_notebook.total is None

# Generated at 2022-06-18 11:58:03.157362
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test Exception")

if __name__ == "__main__":
    test_tqdm_notebook_update()