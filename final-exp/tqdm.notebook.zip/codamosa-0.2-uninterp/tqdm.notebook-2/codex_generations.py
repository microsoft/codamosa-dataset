

# Generated at 2022-06-18 11:49:53.573379
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    assert i == 2



# Generated at 2022-06-18 11:50:02.738010
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=None)
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=None)
        for i in range(10):
            sleep(0.1)
            pbar.update()
       

# Generated at 2022-06-18 11:50:06.041584
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")


# Generated at 2022-06-18 11:50:17.587834
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .utils import _range
    from .std import tqdm as std_tqdm

    # Test with total
    for total in [None, 10, 100]:
        for desc in [None, 'desc', 'desc with spaces']:
            for ncols in [None, 100, "100px", "100%"]:
                # Test with total
                pbar = tqdm_notebook.status_printer(
                    file=None, total=total, desc=desc, ncols=ncols)
                assert isinstance(pbar, TqdmHBox)
                assert isinstance(pbar.children[0], HTML)
                assert isinstance(pbar.children[1], IProgress)

# Generated at 2022-06-18 11:50:20.204510
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:50:30.928398
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
            clear_output(wait=True)
        clear_output(wait=True)


# Generated at 2022-06-18 11:50:42.623477
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.displayed
    assert pbar.container.children[-2].bar_style == 'success'

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        raise Exception()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.displayed
    assert pbar

# Generated at 2022-06-18 11:50:54.372661
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    # Test display
    for i in tqdm(range(10), desc='Test', leave=False):
        sleep(0.1)
    # Test display with no total
    for i in tqdm(range(10), desc='Test', leave=False, total=None):
        sleep(0.1)
    # Test display with bar_style
    for i in tqdm(range(10), desc='Test', leave=False, bar_style='success'):
        sleep(0.1)
    # Test display with bar_style and no total

# Generated at 2022-06-18 11:51:04.684090
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.std import tqdm as tqdm_std

    # Test tqdm_notebook.update()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test tqdm_notebook.update(n)
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)

# Generated at 2022-06-18 11:51:15.089977
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # create a TqdmHBox object
    tqdm_hbox = TqdmHBox()
    # set the pbar attribute
    tqdm_hbox.pbar = tqdm_notebook(total=100)
    # test the __repr__ method
    assert tqdm_hbox.__repr__() == tqdm_hbox.pbar.format_meter()
    # test the _repr_pretty_ method
    assert tqdm_hbox._repr_pretty_() == tqdm_hbox.pbar.format_meter(ascii=True)
    # test the _repr_json_ method
    assert tqdm_hbox._repr_json_() == tqdm_hbox.pbar.format_dict
    # test the _repr_json_ method

# Generated at 2022-06-18 11:51:33.406938
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=5)
        for i in range(3):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(3):
            sleep(0.1)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:51:44.457812
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    from tqdm import trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                time.sleep(0.01)
        print('\n')
    print('\n')
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for k in trange(100, desc='3nd loop', leave=True):
                time.sleep(0.01)
        print('\n')
    print('\n')

# Generated at 2022-06-18 11:51:55.967552
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:52:01.901138
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.auto import trange

    with tqdm_notebook(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.update()



# Generated at 2022-06-18 11:52:11.834838
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:52:23.256991
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    for i in tqdm(range(3), desc='1st loop'):
        sleep(0.01)
        for j in tqdm(range(3), desc='2nd loop'):
            sleep(0.01)
            for k in tqdm(range(3), desc='3nd loop'):
                sleep(0.01)
                for l in tqdm(range(3), desc='4nd loop'):
                    sleep(0.01)
                    for m in tqdm(range(3), desc='5nd loop'):
                        sleep(0.01)
                        for n in tqdm(range(3), desc='6nd loop'):
                            sleep(0.01)

# Generated at 2022-06-18 11:52:34.215483
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('IPython.display.display') as mock_display:
        with patch('IPython.display.clear_output') as mock_clear_output:
            t = tqdm_notebook(total=3)
            t.display()
            assert mock_display.call_count == 1
            assert mock_clear_output.call_count == 0
            t.display(close=True)
            assert mock_display.call_count == 1
            assert mock_clear_output.call_count == 0
            t.display(bar_style='success')
            assert mock_display.call_count == 1
            assert mock_clear_output.call_

# Generated at 2022-06-18 11:52:36.573585
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:52:45.882058
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:52:56.374573
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:53:22.253028
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
                if k == 50:
                    raise Exception()


# Generated at 2022-06-18 11:53:33.504031
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

if __name__ == '__main__':
    test

# Generated at 2022-06-18 11:53:42.936579
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _range

    # test tqdm_notebook.close()
    with tqdm_notebook(total=10) as pbar:
        for i in _range(10):
            pbar.update()
    assert not pbar.displayed

    # test tqdm_notebook.close() with error
    with tqdm_notebook(total=10) as pbar:
        for i in _range(10):
            pbar.update()
            if i == 5:
                raise ValueError
    assert not pbar.displayed

    # test tqdm_notebook.close() with error and leave=True

# Generated at 2022-06-18 11:53:50.058741
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tqdm as tqdm_std
    from tqdm import trange as trange_std
    for cls in [tqdm, trange]:
        with cls(total=10) as pbar:
            for i in pbar:
                sleep(0.01)
    for cls in [tqdm_std, trange_std]:
        with cls(total=10) as pbar:
            for i in pbar:
                sleep(0.01)

# Generated at 2022-06-18 11:53:59.230710
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test: %i" % i)
            pbar.update()
            sleep(0.1)

    # Test display with bar_style
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test: %i" % i)
            pbar.update()
            sleep(0.1)
            if i == 5:
                pbar.set_bar_style("danger")
            if i == 8:
                pbar.set_bar_style("success")

    # Test display with colour

# Generated at 2022-06-18 11:54:01.554995
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass

# Generated at 2022-06-18 11:54:09.565233
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    import sys
    from unittest import TestCase

    class TestTqdmHBox(TestCase):
        def test_TqdmHBox___repr__(self):
            # Test with a progress bar
            pbar = tqdm_notebook(total=10)
            pbar.update(5)
            container = pbar.container
            # Test with a container
            container2 = TqdmHBox(children=[])
            # Test with a container without pbar
            container3 = TqdmHBox(children=[])
            # Test with a container without pbar and without children
            container4 = TqdmHBox()

            # Test with a progress bar
            # Test with a container
            # Test with a container without pbar
            # Test with a container without pbar and without children
           

# Generated at 2022-06-18 11:54:18.488489
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm import tqdm
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _supports_unicode
    from tqdm._tqdm import format_sizeof
    from tqdm._tqdm_gui import _unicode

    # Test with tqdm
    for t in [tqdm, tqdm_notebook]:
        for i in t(range(10)):
            pass
        assert t.__repr__() == '  0%|          | 0/10 [00:00<?, ?it/s]'

        for i in t(range(10), desc='desc'):
            pass
        assert t.__repr__() == 'desc  0%|          | 0/10 [00:00<?, ?it/s]'


# Generated at 2022-06-18 11:54:25.479409
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm._utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            pbar.display(msg='{:d}'.format(i))
            pbar.display(msg='{:d}'.format(i), bar_style='success')
            pbar.display(msg='{:d}'.format(i), bar_style='danger')
            pbar.display(msg='{:d}'.format(i), bar_style='info')
            pbar.display(msg='{:d}'.format(i), bar_style='warning')

# Generated at 2022-06-18 11:54:29.894216
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:54:52.341664
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:55:02.310566
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=3) as pbar:
        assert pbar.total == 3
        pbar.update()
        pbar.update()
        pbar.update()
        assert pbar.n == 3
        assert pbar.n == pbar.total
        pbar.close()
        assert pbar.n == 3
        assert pbar.n == pbar.total
        pbar.reset()
        assert pbar.n == 0
        assert pbar.n != pbar.total
        pbar.reset(total=4)
        assert pbar.n == 0
        assert pbar.total == 4
        pbar.update()
        assert pbar.n == 1
        assert pbar.n != pbar.total
        pbar.update()
        assert pbar.n == 2
       

# Generated at 2022-06-18 11:55:09.334058
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        tqdm.reset()

if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:55:14.793927
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test")

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:17.823925
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:55:26.410609
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main
    from time import sleep
    from tqdm.auto import tqdm

    class TestTqdmNotebookDisplay(TestCase):
        def test_display(self):
            with tqdm(total=10) as pbar:
                for i in range(10):
                    sleep(0.01)
                    pbar.update()

    main(module='test_tqdm_notebook_display', exit=False)

if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:55:36.357371
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    assert pbar.max == 100
    assert pbar.value == 0
    assert pbar.bar_style == ''
    assert pbar.layout.width == '100%'

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert pbar.max == 1
    assert pbar.value == 1
    assert pbar.bar_style == 'info'
    assert pbar.layout.width == '20px'

    # Test with total and ncols

# Generated at 2022-06-18 11:55:46.920632
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[1], IProgress)
    assert container.children[1].max == 10

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[1], IProgress)
    assert container.children[1].max == 1
    assert container.children[1].bar_style == 'info'

    # Test with ncols

# Generated at 2022-06-18 11:55:50.977018
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:56:00.660028
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for _ in tqdm_notebook(range(3), desc='3rd loop'):
                sleep(0.01)
        sleep(0.01)
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for _ in tqdm_notebook(range(3), desc='3rd loop'):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:56:34.713816
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from numpy.random import randint
    from numpy.random import randn

    # Test iterable
    for i in tqdm_notebook(arange(10)):
        sleep(0.01 * random())

    # Test iterable with total
    for i in tqdm_notebook(arange(10), total=10):
        sleep(0.01 * random())

    # Test iterable with total and dynamic_ncols
    for i in tqdm_notebook(arange(10), total=10, dynamic_ncols=True):
        sleep(0.01 * random())

    # Test iterable with total and ncols

# Generated at 2022-06-18 11:56:44.662984
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm.utils import _term_move_up

    # Test basic display
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test")
            sleep(0.1)
            pbar.update()

    # Test display with nested bars
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test")
            with tqdm(total=10) as pbar2:
                for j in range(10):
                    pbar2.set_description("Test2")
                    sleep(0.1)
                    pbar2.update()

# Generated at 2022-06-18 11:56:53.769090
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from sys import stderr
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None

    for i in tqdm(range(3), file=stderr, desc='1st loop'):
        for j in tqdm(range(5), file=stderr, desc='2nd loop', leave=False):
            for k in tqdm(range(100), file=stderr, desc='3nd loop', leave=False):
                sleep(0.01)
        clear_output()
    clear_output()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:57:00.877960
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            clear_output(wait=True)
            pbar.display(msg='test')
            clear_output(wait=True)
            pbar.display(msg='test', bar_style='success')
            clear_output(wait=True)
            pbar.display(msg='test', bar_style='danger')
            clear_output(wait=True)
            pbar.display(msg='test', bar_style='info')
            clear_output(wait=True)

# Generated at 2022-06-18 11:57:07.781089
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm
    for _ in tqdm(range(3), desc='1st loop'):
        for _ in tqdm(range(3), desc='2nd loop', leave=True):
            for _ in tqdm(range(3), desc='3nd loop', leave=True):
                for _ in tqdm(range(3), desc='4nd loop', leave=True):
                    pass
                pass
            pass
        pass

if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-18 11:57:12.859975
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from sys import stderr
    t = tqdm_notebook(total=10, file=stderr)
    for i in range(10):
        sleep(0.1)
        t.display(i, bar_style='success')
    t.close()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:57:22.700137
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:57:24.879511
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:57:35.073969
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-18 11:57:45.360131
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tnrange
    from time import sleep
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.reset()
        assert tnrange.n == 0
        assert tnrange.last_print_n == 0
        assert tnrange.dynamic_ncols
        assert tnrange.total is None
        assert tnrange.container.children[-2].max == 1
        assert tnrange.container.children[-2].layout.width == "20px"
        assert tnrange.container.children[-2].bar_style == 'info'
        assert tnrange.container.children[-1].value == ''
        assert tnrange.container

# Generated at 2022-06-18 11:58:52.658864
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:59:02.192901
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test with a bar
    hbox = TqdmHBox()
    hbox.pbar = std_tqdm(total=10)
    hbox.pbar.n = 5
    assert hbox.__repr__() == hbox.__repr__(pretty=True)
    assert hbox.__repr__() == hbox.__repr__(pretty=False)
    assert hbox.__repr__() == hbox.__repr__(pretty=None)
    assert hbox.__repr__() == hbox.__repr__(pretty=True)
    assert hbox.__repr__() == hbox.__repr__(pretty=False)
    assert hbox.__repr__() == hbox.__repr__(pretty=None)
    assert hbox.__repr

# Generated at 2022-06-18 11:59:10.529854
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    from tqdm.std import tqdm
    from io import StringIO
    with StringIO() as f:
        pbar = tqdm(total=100, file=f)
        pbar.update(10)
        pbar.close()
        pbar.container = TqdmHBox(children=[None, None, None])
        pbar.container.pbar = pbar
        assert pbar.container.__repr__() == f.getvalue()
        assert pbar.container.__repr__(pretty=True) == f.getvalue()
        assert pbar.container._repr_json_() == pbar.format_dict
        assert pbar.container._repr_json_(pretty=True) == pbar.format_dict
        assert p

# Generated at 2022-06-18 11:59:17.787467
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10 and a description
    container = tqdm_notebook.status_printer(file=sys.stdout, total=10, desc="test")
    # Check that the container is an instance of ipywidgets.HBox
    assert isinstance(container, HBox)
    # Check that the container has three children
    assert len(container.children) == 3
    # Check that the first child is an instance of ipywidgets.HTML

# Generated at 2022-06-18 11:59:20.844237
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    t = tqdm(range(10))
    for i in t:
        sleep(0.1)
        if i == 5:
            t.reset()
    t.close()

# Generated at 2022-06-18 11:59:28.401152
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        clear_output()

    # Test display with error
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:59:31.893729
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test Exception")

if __name__ == '__main__':
    test_tqdm_notebook_update()