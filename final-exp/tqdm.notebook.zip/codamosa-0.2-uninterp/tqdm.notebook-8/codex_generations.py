

# Generated at 2022-06-18 11:49:54.965128
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test 1: no total
    # pbar = tqdm.status_printer(None)
    # pbar.value = 1
    # pbar.bar_style = 'info'
    # pbar.layout.width = "20px"
    # display(pbar)
    # sleep(1)
    # clear_output(wait=1)

    # Test 2: total
    pbar = tqdm.status_printer(None, total=10)
    pbar.value = 1
    display(pbar)
    sleep(1)
    clear_output(wait=1)

    # Test 3: total and ncols
    pbar = tqdm.status

# Generated at 2022-06-18 11:49:58.895046
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:50:03.625592
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
    t = tqdm_notebook(range(10))
    for i in t:
        sleep(0.1)
        if i == 5:
            t.reset(total=15)
    t.close()

# Generated at 2022-06-18 11:50:15.149555
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
    clear_output()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
    clear_output()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
    clear_output()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
    clear_output()

# Generated at 2022-06-18 11:50:21.460537
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)


# Generated at 2022-06-18 11:50:31.119716
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from unittest import TestCase
    from unittest.mock import Mock

    class TestTqdmNotebookStatusPrinter(TestCase):
        """
        Unit test for method status_printer of class tqdm_notebook
        """
        def test_status_printer(self):
            """
            Test status_printer
            """
            # Test with total
            tqdm_notebook.status_printer(Mock(), total=10)

            # Test without total
            tqdm_notebook.status_printer(Mock())

    TestTqdmNotebookStatusPrinter().test_status_printer()



# Generated at 2022-06-18 11:50:42.855492
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[0].value == ''
    assert pbar.children[2].value == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)

# Generated at 2022-06-18 11:50:47.091320
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update()
    tqdm.close()



# Generated at 2022-06-18 11:50:55.537996
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("test")

if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-18 11:51:05.605864
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm.auto import tqdm
    with tqdm(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10

    with tqdm(total=10, leave=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10

# Generated at 2022-06-18 11:51:28.358664
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:51:30.333451
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:51:40.988179
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, 10, 'step %i' % i)

    # Test display with bar style
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, 10, 'step %i' % i, bar_style='success')

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)

# Generated at 2022-06-18 11:51:52.615484
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import display
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML
    from IPython.html.widgets import VBox
    from IPython.html.widgets import IntProgress as IProgress
    from IPython.html.widgets import IntText as IText
    from IPython.html.widgets import Text as IText
    from IPython.html.widgets import Textarea as IText
    from IPython.html.widgets import ToggleButton as IToggleButton
    from IPython.html.widgets import Checkbox as ICheckbox
    from IPython.html.widgets import Button as IButton
    from IPython.html.widgets import RadioButtons as IRadioButtons

# Generated at 2022-06-18 11:52:05.613991
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.displayed
    assert pbar.container.visible
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].min == 0
    assert pbar.container.children[-2].layout.width == "100%"
    assert pbar.container.children[-1].value == ''

# Generated at 2022-06-18 11:52:17.620572
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import arange
    from numpy import zeros
    from numpy import ones
    from numpy import ndarray
    from numpy import linspace
    from numpy import logspace
    from numpy import meshgrid
    from numpy import mgrid
    from numpy import ogrid
    from numpy import random
    from numpy import random_integers
    from numpy import random_sample
    from numpy import random_integers
    from numpy import random_integers as randint
    from numpy import random_sample as rand
    from numpy import random_sample as randn
    from numpy import random_integers as randint

# Generated at 2022-06-18 11:52:28.438061
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
        clear_output(wait=True)
        sleep(0.01)
    clear_output(wait=True)
    sleep(0.01)

# Generated at 2022-06-18 11:52:39.703858
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from IPython.display import clear_output
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
    clear_output(wait=True)

# Generated at 2022-06-18 11:52:47.476452
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), total=10):
        sleep(0.1)
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.reset(total=20)
    for i in range(20):
        sleep(0.1)
        t.update()
    t.close()


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:52:49.345787
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:53:05.633716
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:13.116333
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from numpy.random import randint
    from numpy.random import randn
    from numpy.random import rand
    from numpy.random import random_sample
    from numpy.random import choice
    from numpy.random import permutation
    from numpy.random import shuffle
    from numpy.random import beta
    from numpy.random import binomial
    from numpy.random import chisquare
    from numpy.random import dirichlet
    from numpy.random import exponential
    from numpy.random import f
    from numpy.random import gamma
    from numpy.random import geometric
    from numpy.random import gumbel
    from numpy.random import hypergeometric
    from numpy.random import laplace
   

# Generated at 2022-06-18 11:53:23.318959
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[-2], IProgress)
    assert container.children[-2].max == 10
    assert container.children[-2].value == 0
    assert container.children[-2].bar_style == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[-2], IProgress)
    assert container.children[-2].max == 1

# Generated at 2022-06-18 11:53:34.524075
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.std import tqdm as tqdm_std
    from tqdm.notebook import tqdm as tqdm_notebook
    from tqdm._tqdm import TqdmTypeError

    # Test tqdm_notebook.display()
    for tqdm_cls in (tqdm_auto, tqdm_gui, tqdm_std, tqdm_notebook):
        with tqdm_cls(total=2) as pbar:
            pbar.display()
            pbar.display(msg='Hello')
            pbar.display(msg='World', bar_style='success')

# Generated at 2022-06-18 11:53:44.110732
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from .utils import _range
    from .std import TqdmTypeError, TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmWarning
    from .std import TqdmSkipped
    from .std import TqdmClosed
    from .std import TqdmSystemWarning

    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=TqdmDeprecationWarning)
        warnings.filterwarnings('ignore', category=TqdmExperimentalWarning)
        warnings.filterwarnings('ignore', category=TqdmMonitorWarning)
        warnings.filterwarnings

# Generated at 2022-06-18 11:53:51.964048
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].max == 10
    assert container.children[1].value == 0
    assert container.children[1].bar_style == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)

# Generated at 2022-06-18 11:53:58.760487
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook
    """
    from .gui import tqdm_gui

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 0
    assert pbar.children[1].max == 10
    assert pbar.children[2].value == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 1
    assert p

# Generated at 2022-06-18 11:54:06.900502
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10, desc="Test")
    assert pbar.children[0].value == "Test"
    assert pbar.children[1].max == 10
    assert pbar.children[2].value == ""

    # Test without total
    pbar = tqdm_notebook.status_printer(None, desc="Test")
    assert pbar.children[0].value == "Test"
    assert pbar.children[1].max == 1
    assert pbar.children[2].value == ""

    # Test with ncols

# Generated at 2022-06-18 11:54:13.429719
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:54:22.393429
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from IPython.display import clear_output
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        clear_output()
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        clear_output()

# Generated at 2022-06-18 11:54:56.280396
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10, leave=False) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10, leave=False, disable=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()

# Generated at 2022-06-18 11:55:00.651116
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:06.670063
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .gui import tqdm as tqdm_gui
    from .utils import _range

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    for _ in _range(10):
        pbar.value += 1
    assert pbar.value == 10

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    pbar.value = 1
    assert pbar.bar_style == 'info'

    # Test with ncols
    pbar = tqdm_notebook.status_printer(None, total=10, ncols=100)

# Generated at 2022-06-18 11:55:17.824395
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(20):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(20):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=10)
        for i in range(10):
            sleep(0.1)
            pbar.update()




# Generated at 2022-06-18 11:55:21.940222
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:55:25.892244
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:55:35.961157
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    from tqdm.std import tqdm
    from io import StringIO
    import sys
    import re
    import json

    # Test with a tqdm instance
    t = tqdm(total=100)
    t.update(10)
    t.refresh()
    hbox = TqdmHBox(children=[])
    hbox.pbar = t
    assert re.match(r'\r?\n?\s*10/100\s*\|#*\|\s*10%\s*', hbox.__repr__())
    assert re.match(r'\r?\n?\s*10/100\s*\|#*\|\s*10%\s*', repr(hbox))

# Generated at 2022-06-18 11:55:39.047061
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        tqdm_notebook.update()


# Generated at 2022-06-18 11:55:49.569093
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    from tqdm.utils import _unicode
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _environ_cols_wrapper
    from tqdm.utils import _range
    from tqdm.utils import _screen_shape
    from tqdm.utils import _unicode_len
    from tqdm.utils import _unicode_width

    # Test for method __repr__ of class TqdmHBox
    # Test for method __repr__ of class TqdmHBox
    # Test for method __repr__ of class TqdmHBox
    # Test for method __repr__ of class TqdmHBox
    # Test for method __re

# Generated at 2022-06-18 11:55:53.278179
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=100, leave=False) as t:
        for i in range(100):
            sleep(0.01)
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:56:52.192672
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    from time import sleep
    try:
        from ipywidgets import IntProgress
    except ImportError:
        from IPython.html.widgets import IntProgress
    try:
        from ipywidgets import HBox
    except ImportError:
        from IPython.html.widgets import ContainerWidget as HBox

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    assert isinstance(pbar.container, HBox)
    assert isinstance(pbar.container.children[1], IntProgress)
    assert pbar.container.children[1].value == 10
    assert pbar.container.children[1].max == 10

# Generated at 2022-06-18 11:56:56.897235
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest import TestCase

    class TestTqdmHBox(TestCase):
        def test_TqdmHBox___repr__(self):
            with redirect_stdout(StringIO()) as f:
                pbar = tqdm_notebook(total=10)
                print(pbar)
                pbar.close()
            self.assertEqual(f.getvalue(), '100%|██████████| 10/10 [00:00<00:00, ?it/s]\n')

    TestTqdmHBox().test_TqdmHBox___repr__()

# Generated at 2022-06-18 11:57:05.613472
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from IPython.display import clear_output
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        clear_output()
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            clear_output()
            sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            clear_

# Generated at 2022-06-18 11:57:08.389780
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:57:10.481843
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:57:13.794716
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test Exception")


# Generated at 2022-06-18 11:57:23.793034
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from IPython.display import clear_output
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
    clear_output(wait=True)

# Generated at 2022-06-18 11:57:33.884477
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(str(i))
            pbar.update()
        pbar.display(bar_style='success')

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(str(i))
            pbar.update()
            if i == 5:
                raise Exception("Error")
        pbar.display(bar_style='success')

    # Test display with error and leave


# Generated at 2022-06-18 11:57:41.963546
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:50.376214
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-1].value == ''
    assert pbar.container.children[-1].layout.visibility == 'hidden'