

# Generated at 2022-06-18 11:49:57.125734
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:50:07.310260
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # test with a default bar
    hbox = TqdmHBox()
    assert hbox.__repr__() == '\r|   0%|                                                                          |\r'
    # test with a bar with a description
    hbox.pbar = tqdm_notebook(total=10, desc='test')
    assert hbox.__repr__() == 'test:   0%|                                                                          |\r'
    # test with a bar with a description and a bar
    hbox.pbar.update(1)
    assert hbox.__repr__() == 'test:  10%|████                                                                       |\r'
    # test with a bar with a description and a bar and a message
    hbox.pbar.write('message')
    assert hbox.__repr__

# Generated at 2022-06-18 11:50:10.511313
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for _ in tqdm(range(10)):
        sleep(0.1)
    tqdm.close()

# Generated at 2022-06-18 11:50:22.591513
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange

    # Test 1
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    clear_output()

    # Test 2
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            if i == 5:
                pbar.set_description("Test 2")
    clear_output()

    # Test 3

# Generated at 2022-06-18 11:50:28.939202
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                clear_output(wait=True)


# Generated at 2022-06-18 11:50:34.138458
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:50:36.872548
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:50:48.343505
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test the method status_printer of class tqdm_notebook
    # with the default parameters
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10
    container = tqdm_notebook.status_printer(None, total=10)


# Generated at 2022-06-18 11:50:56.960447
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.auto import trange

    with tqdm_notebook(total=10) as pbar:
        for i in trange(5, leave=False):
            sleep(.5)
            pbar.update()
        for i in trange(5, leave=True):
            sleep(.5)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:50:58.520202
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as t:
        t.clear()

# Generated at 2022-06-18 11:51:22.678577
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    # Test 1: no error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    # Test 2: error
    try:
        with tqdm(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
                if i == 5:
                    raise Exception
    except:
        pass
    # Test 3: KeyboardInterrupt

# Generated at 2022-06-18 11:51:31.061708
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-18 11:51:33.310968
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.01)


# Generated at 2022-06-18 11:51:44.405591
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from io import StringIO
    from unittest import TestCase

    class TestTqdmNotebookStatusPrinter(TestCase):
        """
        Unit test for method status_printer of class tqdm_notebook
        """
        def test_status_printer(self):
            """
            Unit test for method status_printer of class tqdm_notebook
            """
            # pylint: disable=protected-access
            # pylint: disable=no-member
            # pylint: disable=no-self-use
            # pylint: disable=too-many-locals
            # pylint: disable=too-many-branches
            # pylint: disable=too-many-statements


# Generated at 2022-06-18 11:51:52.503059
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            break
    # NB: don't `finally: close()`
    # since this could be a shared bar which the user will `reset()`


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-18 11:52:04.870192
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:52:14.422274
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from sys import stderr
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def capture_stderr():
        old_stderr = stderr
        stderr = StringIO()
        try:
            yield stderr
        finally:
            stderr = old_stderr

    with capture_stderr() as stderr:
        for i in tqdm_notebook(range(10), file=stderr):
            sleep(random())
    assert "10/10" in stderr.getvalue()



# Generated at 2022-06-18 11:52:25.951371
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import clear_output, display
    from time import sleep
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('sys.stderr', new=sys.stdout):
        # Test with total
        pbar = tqdm_notebook.status_printer(None, total=10, desc='test')
        display(pbar)
        for i in range(10):
            sleep(0.1)
            pbar.value += 1
        clear_output(wait=True)

        # Test without total
        pbar = tqdm_notebook.status_printer(None, desc='test')
        display(pbar)
        for i in range(10):
            sleep(0.1)
            pbar.value += 1

# Generated at 2022-06-18 11:52:29.937950
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")


# Generated at 2022-06-18 11:52:38.039916
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
        if i == 5:
            break

# Generated at 2022-06-18 11:52:57.387296
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import random
    from tqdm.auto import trange
    with trange(10) as t:
        for i in t:
            sleep(random())
            t.set_description("description %i" % i)
            t.set_postfix({"loss": random(), "acc": random()})
            t.update()


# Generated at 2022-06-18 11:53:07.619433
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook

    # Test basic constructor
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test iterable-based constructor
    with tqdm_notebook(range(10)) as t:
        for i in t:
            sleep(0.1)

    # Test iterable-based constructor with total
    with tqdm_notebook(range(10), total=10) as t:
        for i in t:
            sleep(0.1)

    # Test iterable-based constructor with total=None

# Generated at 2022-06-18 11:53:17.193094
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
            pbar.set_description("test")
            pbar.set_postfix({"postfix": i})
            pbar.display(msg="test", pos=i, bar_style="success")
            pbar.display(msg="test", pos=i, bar_style="danger")
            pbar.display(msg="test", pos=i, bar_style="info")
            pbar.display(msg="test", pos=i, bar_style="warning")

# Generated at 2022-06-18 11:53:28.053162
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from sys import stderr
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None

    # Test 1
    with tqdm(total=10, file=stderr) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()

    # Test 2
    with tqdm(total=10, file=stderr) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            if i == 5:
                pbar.set_description("Test 2")
    clear_output()

    # Test 3

# Generated at 2022-06-18 11:53:38.225114
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=1) as t:
        t.update()
        t.close()
    with tqdm_notebook(total=1) as t:
        t.update()
        t.close()
        t.close()
    with tqdm_notebook(total=1) as t:
        t.update()
        t.close()
        t.close()
        t.close()
    with tqdm_notebook(total=1) as t:
        t.update()
        t.close()
        t.close()
        t.close()
        t.close()
    with tqdm_notebook(total=1) as t:
        t.update()
        t.close()
        t.close()
        t.close()
        t.close()


# Generated at 2022-06-18 11:53:47.667189
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 0
    assert pbar.children[2].value == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 1

# Generated at 2022-06-18 11:53:56.905914
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook
    """
    from .utils import _range
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError

    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_note

# Generated at 2022-06-18 11:54:04.396488
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tnrange
    for i in tnrange(2, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop', leave=True):
            for k in tnrange(100, desc='3nd loop'):
                pass
    for i in tnrange(2, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop', leave=True):
            for k in tnrange(100, desc='3nd loop'):
                pass
    for i in tnrange(2, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop', leave=True):
            for k in tnrange(100, desc='3nd loop'):
                pass

# Generated at 2022-06-18 11:54:08.412376
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for leave in [True, False]:
        for total in [None, 10]:
            for n in [0, 1, 5, 10]:
                t = tqdm_notebook(total=total, leave=leave)
                for _ in range(n):
                    sleep(0.01)
                    t.update()
                t.close()

# Generated at 2022-06-18 11:54:12.135751
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:54:35.102161
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(0.01)
            if j == 2:
                break
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-18 11:54:45.115684
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('IPython.display.display') as mock_display:
        with patch('IPython.display.clear_output') as mock_clear_output:
            t = tqdm_notebook(total=3)
            t.display()
            assert mock_display.call_count == 1
            assert mock_clear_output.call_count == 0
            t.display(close=True)
            assert mock_display.call_count == 1
            assert mock_clear_output.call_count == 0
            t.display(bar_style='success')
            assert mock_display.call_count == 1
            assert mock_clear_output.call_

# Generated at 2022-06-18 11:54:48.152434
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:54:59.452057
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10
    assert t.last_print_t == 1.0
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t.last_print_n
    assert t.n == t

# Generated at 2022-06-18 11:55:00.812940
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import trange
    for _ in trange(10):
        pass



# Generated at 2022-06-18 11:55:11.003510
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            tqdm.clear()
            tqdm.write("hello")
            tqdm.write("world")
            tqdm.clear()
            tqdm.write("done")
            tqdm.clear()
            tqdm.write("done")
            tqdm.clear()
            tqdm.write("done")
            tqdm.clear()

# Generated at 2022-06-18 11:55:17.777732
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.1)
    assert pbar.n == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:55:29.269227
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import allclose
    from numpy import ndarray
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import linspace
    from numpy import logspace
    from numpy import meshgrid
    from numpy import mgrid
    from numpy import ogrid
    from numpy import random
    from numpy import random_integers
    from numpy import random_sample
    from numpy import random_uniform
    from numpy import random_normal
    from numpy import random_randn
    from numpy import random_rand
    from numpy import random_randint
    from numpy import random

# Generated at 2022-06-18 11:55:33.785526
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random

    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update(10)
    assert pbar.n == 100


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:55:43.787825
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method `status_printer` of class `tqdm_notebook`.
    """
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test with total
    pbar = tqdm.status_printer(None, total=10)
    assert pbar.max == 10
    assert pbar.value == 0
    assert pbar.bar_style == ''
    assert pbar.layout.width == '100%'
    assert pbar.layout.display == 'inline-flex'
    assert pbar.layout.flex_flow == 'row wrap'
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == 0
    assert pbar.children[2].value == ''

# Generated at 2022-06-18 11:56:30.014825
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:56:34.092030
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:56:36.830184
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:56:46.824361
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:56:56.007681
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(random())

    with tqdm(total=100, leave=True) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(random())

    with tqdm(total=100, leave=True, ncols=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(random())


# Generated at 2022-06-18 11:56:58.779836
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.update(5)


# Generated at 2022-06-18 11:57:02.269917
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:11.717547
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=10)

# Generated at 2022-06-18 11:57:21.404368
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test method __repr__ of class TqdmHBox
    """
    from .gui import tqdm as tqdm_gui
    from .utils import _range
    from .std import tqdm as tqdm_std
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_size
    from .utils import format_speed
    from .utils import format_eta
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_size
    from .utils import format_speed

# Generated at 2022-06-18 11:57:31.463555
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook.
    """
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.std import tqdm as tqdm_std

    for tqdm_cls in [tqdm_auto, tqdm_gui, tqdm_std]:
        with tqdm_cls(total=10) as t:
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()

# Generated at 2022-06-18 11:58:16.537919
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from random import random

    # Test display()
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(i)
        sleep(0.1)
    t.close()

    # Test display(close=True)
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(i, close=True)
        sleep(0.1)

    # Test display(bar_style='danger')
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.display(i, bar_style='danger')
        sleep(0.1)
    t.close()

    # Test display(bar

# Generated at 2022-06-18 11:58:25.403810
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    from tqdm.std import tqdm
    import sys
    import re
    import os

    # Test with a tqdm instance
    pbar = tqdm(total=100)
    pbar.n = 50
    pbar.refresh()
    hbox = TqdmHBox(children=[])
    hbox.pbar = pbar

# Generated at 2022-06-18 11:58:33.404025
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(random() / 100.)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(random() / 100.)

# Generated at 2022-06-18 11:58:40.441850
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:58:42.144760
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:58:50.477284
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the `tqdm_notebook.status_printer` method.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert pbar.children[1].max == 10

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert pbar.children[1].max == 1
    assert pbar.children[1].bar_style == 'info'

    # Test with ncols
    pbar = tqdm_notebook.status_printer(None, total=10, ncols=100)
    assert pbar.layout.width == '100px'

# Generated at 2022-06-18 11:59:00.025906
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.set_description("Test")
            pbar.update()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.set_description("Test")
            pbar.update()
            pbar.set_description("Test2")

# Generated at 2022-06-18 11:59:08.238974
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .std import tqdm as std_tqdm
    from .utils import _range
    from .std import TqdmTypeError, TqdmKeyError

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[0].value == ''
    assert pbar.children[2].value == ''

    # Test without total
    p

# Generated at 2022-06-18 11:59:16.087989
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:59:20.000125
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].bar_style == 'success'


if __name__ == '__main__':
    test_tqdm_notebook()