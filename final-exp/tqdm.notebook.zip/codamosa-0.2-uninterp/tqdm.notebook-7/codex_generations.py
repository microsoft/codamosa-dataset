

# Generated at 2022-06-18 11:50:00.728105
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook
    """
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning

    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook


# Generated at 2022-06-18 11:50:08.838811
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
        if i == 5:
            break

# Generated at 2022-06-18 11:50:15.729372
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook

    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:50:20.152257
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("test")

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:50:30.879843
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-1].value == ''

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.close()

# Generated at 2022-06-18 11:50:39.232749
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from tqdm.notebook import tqdm
    with redirect_stdout(StringIO()) as f:
        for i in tqdm(range(10), desc='test', leave=True):
            pass
    assert f.getvalue() == 'test: 100%|██████████| 10/10 [00:00<00:00, ?it/s]\n'

if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-18 11:50:42.434639
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)


# Generated at 2022-06-18 11:50:50.068626
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(10), desc='1st loop', leave=False):
        for j in tqdm(range(5), desc='2nd loop', leave=True):
            for k in tqdm(range(100), desc='3nd loop', leave=True, miniters=10):
                sleep(0.01)
    print('done')


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:50:57.738153
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(5), total=5, leave=True):
        sleep(0.01)
    tqdm.reset()
    for i in tqdm(range(5), total=5, leave=True):
        sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:51:07.367334
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from sys import stderr
    t = tqdm_notebook(total=100, file=stderr)
    for i in range(10):
        sleep(.1)
        t.update()
    t.close()
    t = tqdm_notebook(total=100, file=stderr)
    for i in range(10):
        sleep(.1)
        t.update()
    t.close()
    t = tqdm_notebook(total=100, file=stderr)
    for i in range(10):
        sleep(.1)
        t.update()
    t.close()
    t = tqdm_notebook(total=100, file=stderr)

# Generated at 2022-06-18 11:51:22.381666
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-18 11:51:30.841856
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tnrange
    from tqdm.utils import _term_move_up

    with tnrange(10) as t:
        for i in t:
            sleep(0.1)
            t.set_description('Foobar')
            t.set_postfix(ordered_dict=dict(x=i))
            t.update()
            if i == 5:
                t.set_postfix(ordered_dict=dict(x=i), refresh=True)
                t.set_description('Foobar', refresh=True)
                t.update(2)
                t.set_postfix(ordered_dict=dict(x=i), refresh=True)
                t.set_description('Foobar', refresh=True)
                t.update(2)

# Generated at 2022-06-18 11:51:41.579748
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.notebook import tqdm as tqdm_notebook
    from tqdm.std import tqdm as tqdm_std
    from tqdm.utils import _term_move_up

    # Test tqdm_notebook.display()
    for tqdm_cls in (tqdm_auto, tqdm_gui, tqdm_notebook, tqdm_std):
        with tqdm_cls(total=10, leave=True) as t:
            for i in range(10):
                t.display(msg='msg' + str(i))
                sleep(0.1)

# Generated at 2022-06-18 11:51:53.203033
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:52:03.812077
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = None

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            if clear_output:
                clear_output(wait=True)
            else:
                sys.stderr.write(_term_move_up())
                sys.stderr.flush()



# Generated at 2022-06-18 11:52:06.947434
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:52:18.871512
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.last_print_n == 10
    assert pbar.last_print_t == 1.0
    assert pbar.last_print_refresh_t == 1.0
    assert pbar.total == 10
    assert pbar.dynamic_ncols
    assert pbar.ncols == 100
    assert pbar.unit == 'it'
    assert pbar.unit_scale == True
    assert pbar.unit_divisor == 1
    assert pbar.miniters == 1

# Generated at 2022-06-18 11:52:21.765165
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:52:32.476806
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _range

    # Test with a simple range
    for tqdm_cls in [tqdm_notebook, tqdm_gui, tqdm_std]:
        with tqdm_cls(total=10) as pbar:
            for i in _range(10):
                pbar.display(i)
                assert pbar.n == i + 1
                assert pbar.last_print_n == i + 1
                assert pbar.last_print_t == pbar.format_interval(pbar.last_print_n)
                assert pbar.last_print_n == i + 1

    # Test with a simple range and a custom bar format

# Generated at 2022-06-18 11:52:43.956891
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test the method status_printer of class tqdm_notebook
    with std_tqdm(total=10, file=sys.stdout) as t:
        t.container = tqdm_notebook.status_printer(t.fp, t.total, t.desc, t.ncols)
        t.display()
        t.update(1)
        t.display()
        t.update(1)
        t.display()
        t.update(1)
        t.display()
        t.update(1)
        t.display()
        t.update(1)
       

# Generated at 2022-06-18 11:52:59.512319
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:04.913765
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from random import random

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:53:10.085854
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        tqdm.reset(total=10)
    tqdm.close()

# Generated at 2022-06-18 11:53:19.885404
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            tqdm.reset()
            break
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            tqdm.reset(total=9)
            break

# Generated at 2022-06-18 11:53:30.980896
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import display
    from IPython.display import clear_output
    from IPython.display import HTML
    from IPython.display import Javascript
    from IPython.display import display_javascript
    from IPython.display import publish_display_data
    from IPython.display import publish_javascript
    from IPython.display import update_display
    from IPython.display import update_display_data
    from IPython.display import update_javascript
    from IPython.display import publish_display_data
    from IPython.display import publish_javascript
    from IPython.display import update_display
    from IPython.display import update_display_data
    from IPython.display import update_javascript
    from IPython.display import publish_display_data
    from IPython.display import publish_javascript
    from IPython.display import update

# Generated at 2022-06-18 11:53:40.727873
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    clear_output()

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            if i == 5:
                raise ValueError("Error!")
    clear_output()

    # Test display with error and leave

# Generated at 2022-06-18 11:53:46.576246
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
            clear_output(wait=True)
            assert pbar.n == i + 1
            assert pbar.n == pbar.last_print_n
        assert pbar.n == 10
        assert pbar.n == pbar.last_print_n


# Generated at 2022-06-18 11:53:51.191886
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:53.532983
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:53:56.496965
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)


# Generated at 2022-06-18 11:54:20.672688
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=5)
        for i in range(5):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=0)
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=None)

# Generated at 2022-06-18 11:54:24.130054
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:54:32.583560
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:54:42.296424
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    # should not raise exception
    tqdm_notebook(range(3)).close()
    tqdm_notebook(range(3), leave=True).close()
    tqdm_notebook(range(3), leave=False).close()
    tqdm_notebook(range(3), leave=False, total=3).close()
    tqdm_notebook(range(3), leave=False, total=4).close()
    tqdm_notebook(range(3), leave=False, total=3, disable=True).close()
    tqdm_notebook(range(3), leave=False, total=4, disable=True).close()

# Generated at 2022-06-18 11:54:52.986178
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    # Test with total=None
    with tqdm(total=None) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
        pbar.reset()
        for i in range(10):
            pbar.update()
            sleep(0.1)

    # Test with total=int
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
        pbar.reset()
        for i in range(10):
            pbar.update()
            sleep(0.1)

    # Test with total

# Generated at 2022-06-18 11:54:57.565005
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:55:05.045927
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:55:16.304441
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()

# Generated at 2022-06-18 11:55:23.746297
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
            tqdm.clear(leave=True)
        tqdm.clear(leave=True)
    tqdm.clear()
    print('done')

# Generated at 2022-06-18 11:55:26.721369
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Error")


# Generated at 2022-06-18 11:55:41.291006
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)


# Generated at 2022-06-18 11:55:48.570451
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
    clear_output()

# Generated at 2022-06-18 11:55:57.948407
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from .utils import _range
    for pretty in (False, True):
        for leave in (False, True):
            for ncols in (None, 100, "100px", "100%"):
                for desc in (None, "desc"):
                    for total in (None, 100):
                        for n in (0, 10, 100):
                            with tqdm(total=total, desc=desc, ncols=ncols,
                                      leave=leave) as t:
                                for _ in _range(n):
                                    t.update()
                                if pretty:
                                    assert repr(t.container) == t.format_meter(
                                        ascii=False)

# Generated at 2022-06-18 11:56:01.264273
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in pbar:
            sleep(0.1)
            pbar.set_description("Processing %i" % i)


# Generated at 2022-06-18 11:56:08.934068
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Processing %i" % i)
            pbar.set_postfix(OrderedDict(loss=i, other=i))
            sleep(0.1)
            pbar.update()
            clear_output(wait=True)
    pbar.close()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:56:17.763034
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=False):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=False):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(3), leave=False):
        sleep(0.1)


# Generated at 2022-06-18 11:56:29.111552
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange

    # Test display
    with tqdm(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.display(msg='test')
            pbar.display(msg='test', bar_style='success')
            pbar.display(msg='test', bar_style='danger')
            pbar.display(msg='test', bar_style='info')
            pbar.display(msg='test', bar_style='warning')
            pbar.display(msg='test', bar_style='')
            pbar.display(msg='test', bar_style=None)
            pbar.display(msg='test', bar_style='success')

# Generated at 2022-06-18 11:56:39.120998
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with no total
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].bar_style == 'info'
    assert container.children[1].layout.width == "20px"

    # Test with total
    container = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(container, TqdmHBox)

# Generated at 2022-06-18 11:56:48.814638
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tnrange
    from tqdm import tqdm
    from tqdm import trange
    from tqdm import tnrange

    for i in tqdm(range(10)):
        sleep(0.1)
    for i in trange(10):
        sleep(0.1)
    for i in tnrange(10):
        sleep(0.1)
    for i in tqdm(range(10)):
        sleep(0.1)
    for i in trange(10):
        sleep(0.1)
    for i in tnrange(10):
        sleep(0.1)



# Generated at 2022-06-18 11:56:57.616734
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    # Test the method status_printer of class tqdm_notebook
    # with total = None
    container = tqdm_notebook.status_printer(None, None, "Test", None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[0].value == "Test"
    assert container.children[1].bar_style == "info"
    assert container.children[1].max == 1
    assert container.children[1].value == 1
    assert container.children[2].value == ""

    #

# Generated at 2022-06-18 11:57:23.876592
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import trange
    from time import sleep
    from sys import stderr
    for i in trange(3, file=stderr):
        sleep(.1)
        stderr.write('\r{}/{}'.format(i + 1, 3))
    stderr.write('\n')

# Generated at 2022-06-18 11:57:27.338166
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
    tqdm.close()

# Generated at 2022-06-18 11:57:38.207625
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
    with tqdm_notebook(total=10, leave=False) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
    with tqdm_notebook(total=10, leave=False, disable=True) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

# Generated at 2022-06-18 11:57:47.660308
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from sys import stderr
    from random import random
    from os import get_terminal_size

    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None

    # Test bar
    bar = tqdm_notebook(total=10)
    for i in range(10):
        sleep(random())
        bar.update()
    bar.close()

    # Test bar with description
    bar = tqdm_notebook(total=10, desc="Test bar")
    for i in range(10):
        sleep(random())
        bar.update()
    bar.close()

    # Test bar with description and bar_format

# Generated at 2022-06-18 11:57:50.374662
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm.auto import trange
    with trange(10) as t:
        for i in t:
            sleep(0.1)
            if i == 5:
                raise ValueError()


# Generated at 2022-06-18 11:57:58.245586
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:58:01.656825
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)


# Generated at 2022-06-18 11:58:04.952966
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        tqdm.reset()

# Generated at 2022-06-18 11:58:14.128006
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset()
        for j in trange(5, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10)
        for j in trange(10, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10, desc='2nd loop')
        for j in trange(10, desc='2nd loop', leave=False):
            sleep(0.01)
        trange.reset(total=10, desc='2nd loop', leave=True)

# Generated at 2022-06-18 11:58:22.459778
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.ncols == 100
    assert pbar.container.layout.width == '100%'
    assert pbar.container.layout.display == 'inline-flex'
    assert pbar.container.layout.flex_flow == 'row wrap'
    assert pbar.container.children[-2].layout.flex == '2'
    assert pbar.container.children[-2].layout.width == '100%'
    assert pbar.container.children[-2].layout.height == '100%'

# Generated at 2022-06-18 11:59:29.812270
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError

    # Test with no total
    # DEPRECATED: replaced with an 'info' style bar
    # assert tqdm_notebook.status_printer(None) == \
    #     std_tqdm.status_printer(None)

    # Test with total
    # Test with no total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[1].max == 10

    # Test with no total
    pbar = tq