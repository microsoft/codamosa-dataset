

# Generated at 2022-06-18 11:49:57.430741
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
    t = tqdm_notebook(total=3)
    for i in range(3):
        sleep(0.1)
        t.update()
    t.reset(total=4)
    for i in range(4):
        sleep(0.1)
        t.update()
    t.close()

# Generated at 2022-06-18 11:50:03.035127
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        tqdm.reset()

if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:50:14.523298
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from tqdm.contrib import DummyTqdmFile
    from io import StringIO
    from time import sleep

    # Test with a dummy file
    with StringIO() as f:
        with tqdm(total=10, file=f) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
        assert f.getvalue() == ''

    # Test with a dummy file and manual mode
    with StringIO() as f:
        with tqdm(total=10, file=f, leave=True, manual=True) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
        assert f.getvalue() == ''

    # Test with a dummy file

# Generated at 2022-06-18 11:50:25.858641
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
            if j == 2:
                break
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
            if j == 2:
                raise Exception("Test exception")

# Generated at 2022-06-18 11:50:36.709949
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from .utils import _range
    from .std import TqdmTypeError
    from .std import TqdmKeyError
    from .std import TqdmDeprecationWarning
    from .std import TqdmExperimentalWarning
    from .std import TqdmMonitorWarning
    from .std import TqdmSynchronisationWarning
    from .std import TqdmWarning
    from .std import TqdmSkipped
    from .std import TqdmClosed
    from .std import TqdmSupportsFloat
    from .std import TqdmSupportsInt
    from .std import TqdmSupportsBytes
    from .std import TqdmSupportsUnicode
    from .std import TqdmSupportsAbsolute
    from .std import TqdmSupportsRelative

# Generated at 2022-06-18 11:50:46.001392
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from random import random
    from IPython.display import clear_output
    from tqdm.auto import tqdm as tqdm_auto
    for i in tqdm_auto(range(10), desc='1st loop', leave=False):
        for j in tqdm_auto(range(5), desc='2nd loop', leave=True):
            for k in tqdm_auto(range(100), desc='3nd loop'):
                sleep(0.01)
                if random() < 0.1:
                    clear_output()
                    break
    clear_output()
    print('done!')

# Generated at 2022-06-18 11:50:58.152429
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.gui import tqdm as tqdm_gui
    from tqdm.notebook import tqdm as tqdm_notebook
    from tqdm.std import tqdm as tqdm_std
    from tqdm.utils import _term_move_up

    # Test all bars

# Generated at 2022-06-18 11:51:07.951061
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            pbar.set_description("test")
            pbar.set_postfix({"test": i})
            pbar.display(bar_style="success")
            pbar.display(bar_style="danger")
            pbar.display(bar_style="info")
            pbar.display(bar_style="warning")
            pbar.display(bar_style="")
            pbar.display(bar_style="")
            pbar.display(bar_style="")
            pbar.display(bar_style="")
            pbar.display(bar_style="")

# Generated at 2022-06-18 11:51:18.153090
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:51:26.652908
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from IPython.display import clear_output

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
        clear_output(wait=True)
        sleep(0.01)
    clear_output(wait=True)
    sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:51:52.188729
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook.
    """
    # Test with a simple iterator
    with tqdm_notebook(iterable=range(10), total=10) as t:
        for i in t:
            assert i == t.n - 1
    # Test with a simple iterator and a wrong total
    with tqdm_notebook(iterable=range(10), total=20) as t:
        for i in t:
            assert i == t.n - 1
    # Test with a simple iterator and a wrong total and leave=True
    with tqdm_notebook(iterable=range(10), total=20, leave=True) as t:
        for i in t:
            assert i == t.n - 1
    # Test with a simple iterator and a wrong total and

# Generated at 2022-06-18 11:52:04.975855
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from pandas import Series
    from tqdm import tqdm_notebook as tqdm

    # Test iterables

# Generated at 2022-06-18 11:52:17.199145
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    from IPython.core.display import HTML

    # Test with no total
    with tqdm_notebook(desc="test", leave=True) as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update()
    clear_output()

    # Test with total
    with tqdm_notebook(total=3, desc="test", leave=True) as pbar:
        for i in range(3):
            sleep(0.1)
            pbar.update()
    clear_output()

    # Test with total and error

# Generated at 2022-06-18 11:52:28.011364
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                time.sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                time.sleep(0.01)

# Generated at 2022-06-18 11:52:35.699968
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from random import random
    from tqdm import trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            sleep(random() / 2)
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            sleep(random() / 2)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:52:46.597287
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
    clear_output()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
            if i == 5:
                pbar.close()
    clear_output()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
            if i == 5:
                pbar.reset()
    clear_output()

# Generated at 2022-06-18 11:52:56.511048
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(5), total=5):
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(5), total=5):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10), total=10):
        sleep(0.1)
    tqdm.reset(total=0)
    for i in tqdm(range(5), total=5):
        sleep(0.1)
    tqdm.reset(total=5)
    for i in tqdm(range(5), total=5):
        sleep(0.1)

# Generated at 2022-06-18 11:53:02.378814
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10, desc="Test") as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].bar_style == 'success'



# Generated at 2022-06-18 11:53:09.097927
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    tqdm.reset()
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    tqdm.reset(total=20)

# Generated at 2022-06-18 11:53:18.924243
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:53:56.827564
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm.auto import tqdm

    # Test display of tqdm_notebook
    with tqdm(total=10, desc='test', leave=False, disable=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.display(msg='test')
        pbar.display(msg='test', bar_style='success')
        pbar.display(msg='test', bar_style='danger')
        pbar.display(msg='test', bar_style='info')
        pbar.display(msg='test', bar_style='warning')
        pbar.display(msg='test', bar_style='danger')

# Generated at 2022-06-18 11:54:04.358089
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from sys import stderr
    from numpy.random import randint
    from numpy.random import rand
    from numpy.random import randn
    from numpy.random import choice
    from numpy.random import shuffle
    from numpy.random import sample
    from numpy.random import normal
    from numpy.random import uniform
    from numpy.random import binomial
    from numpy.random import beta
    from numpy.random import chisquare
    from numpy.random import gamma
    from numpy.random import f
    from numpy.random import poisson
    from numpy.random import exponential
    from numpy.random import multinomial
    from numpy.random import standard_t
    from numpy.random import vonmises

# Generated at 2022-06-18 11:54:06.487687
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 3:
            break


# Generated at 2022-06-18 11:54:10.380317
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)


# Generated at 2022-06-18 11:54:16.078988
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        tqdm_notebook.reset_states()
        tqdm_notebook.clear()
        tqdm_notebook.close()
        tqdm_notebook.close()
        tqdm_notebook.clear()
        tqdm_notebook.reset_states()
        tqdm_notebook.reset()
        tqdm_notebook.clear()
        tqdm_notebook.close()
        tqdm_notebook.close()
        tqdm_notebook.clear()
        tq

# Generated at 2022-06-18 11:54:24.192301
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import allclose

    # Test iterable
    for n in tqdm_notebook(range(10)):
        sleep(random())

    # Test iterable with total
    for n in tqdm_notebook(range(10), total=10):
        sleep(random())

    # Test iterable with total and dynamic_ncols
    for n in tqdm_notebook(range(10), total=10, dynamic_ncols=True):
        sleep(random())

    # Test iterable with total and ncols

# Generated at 2022-06-18 11:54:27.107560
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3)):
        sleep(.1)
        if i == 1:
            raise ValueError()


# Generated at 2022-06-18 11:54:31.318821
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:54:34.431338
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
            pbar.clear()
            time.sleep(0.1)

# Generated at 2022-06-18 11:54:44.215676
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-18 11:55:37.553153
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)



# Generated at 2022-06-18 11:55:48.142280
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from unittest import TestCase
    from unittest.mock import Mock

    class TestTqdmNotebookStatusPrinter(TestCase):
        """
        Unit test for method status_printer of class tqdm_notebook
        """
        def test_status_printer(self):
            """
            Test status_printer method of class tqdm_notebook
            """
            # Test with total
            tqdm_notebook.status_printer(Mock(), total=10)
            # Test without total
            tqdm_notebook.status_printer(Mock())

    test_tqdm_notebook_status_printer = TestTqdmNotebookStatusPrinter()
    test_tq

# Generated at 2022-06-18 11:55:57.400974
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from IPython.display import clear_output
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                clear_output(wait=True)
                sleep(0.01)


# Generated at 2022-06-18 11:56:07.033894
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from random import random
    from sys import stderr

    # Test 1
    with tqdm_notebook(total=10, file=stderr) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

    # Test 2
    with tqdm_notebook(total=10, file=stderr) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
            if i == 5:
                pbar.display(msg='{:.2f}'.format(random()))

    # Test 3

# Generated at 2022-06-18 11:56:16.026908
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test with a progress bar
    pbar = tqdm_notebook(total=100)
    pbar.update(10)
    assert repr(pbar.container) == pbar.format_meter(**pbar.format_dict)
    # Test with a progress bar with no total
    pbar = tqdm_notebook()
    pbar.update(10)
    assert repr(pbar.container) == pbar.format_meter(**pbar.format_dict)
    # Test with a progress bar with no total and no progress
    pbar = tqdm_notebook()
    assert repr(pbar.container) == pbar.format_meter(**pbar.format_dict)
    # Test with a progress bar with no total and no progress
    pbar = tqdm_notebook()

# Generated at 2022-06-18 11:56:27.329723
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[0].value == ''
    assert container.children[2].value == ''
    assert container.children[1].value == 0
    assert container.children[1].min == 0
    assert container.children[1].max == 1
    assert container.children[1].bar_style == 'info'
    assert container.children[1].layout.width == '20px'



# Generated at 2022-06-18 11:56:29.560331
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:56:32.714813
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:56:42.769016
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for _ in tqdm_notebook(range(3), desc='3rd loop'):
                sleep(0.01)
        sleep(0.01)
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for _ in tqdm_notebook(range(3), desc='3rd loop'):
                sleep(0.01)
        sleep(0.01)



# Generated at 2022-06-18 11:56:46.312075
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:58:50.141733
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        for i in range(5):
            pbar.update()
        pbar.clear()
        for i in range(5):
            pbar.update()

# Generated at 2022-06-18 11:58:53.155126
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(10), desc='test', leave=True):
        sleep(0.01)
        if i == 5:
            raise Exception()


# Generated at 2022-06-18 11:58:59.274246
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count

    def f(x):
        sleep(1)
        return x

    with trange(10) as t:
        list(process_map(f, range(10), max_workers=cpu_count(),
                         desc='Processing', total=10, use_tqdm=t))

# Generated at 2022-06-18 11:59:07.580893
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    from IPython.core.display import display

    # Test display
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        clear_output(wait=True)
        display(i)

    # Test display with total
    for i in tqdm_notebook(range(10), total=10):
        sleep(0.1)
        clear_output(wait=True)
        display(i)

    # Test display with total and desc
    for i in tqdm_notebook(range(10), total=10, desc="test"):
        sleep(0.1)
        clear_output(wait=True)
        display(i)

    # Test

# Generated at 2022-06-18 11:59:12.115895
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main
    from time import sleep

    class TestTqdmNotebookDisplay(TestCase):
        def test_display(self):
            with tqdm_notebook(total=10) as pbar:
                for i in range(10):
                    sleep(0.1)
                    pbar.update()

    main(module='test_tqdm_notebook_display', exit=False)

# Generated at 2022-06-18 11:59:16.496841
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        sleep(0.1)
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.1)
        if i == 2:
            break
    for i in tqdm(range(10), desc='1st loop'):
        sleep(0.1)
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.1)
            if j == 2:
                break
    for i in tqdm(range(10), desc='1st loop'):
        sleep(0.1)

# Generated at 2022-06-18 11:59:22.256971
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map

    # Test tqdm_notebook display
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test tqdm_notebook display with error
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            if i == 5:
                raise ValueError("Test error")

    # Test tqdm_notebook display with error in manual mode

# Generated at 2022-06-18 11:59:27.222658
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), leave=True):
        sleep(.1)
    tqdm_notebook.reset(total=10)
    for i in tqdm_notebook(range(10)):
        sleep(.1)
    tqdm_notebook.reset()
    for i in tqdm_notebook(range(5)):
        sleep(.1)
