

# Generated at 2022-06-18 11:49:38.716472
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt("Test KeyboardInterrupt")

# Generated at 2022-06-18 11:49:40.634935
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.01)


# Generated at 2022-06-18 11:49:49.423894
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm
    import time
    with tqdm(total=10, desc='test', leave=True) as pbar:
        for i in pbar:
            time.sleep(0.1)
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.desc == 'test'
    assert pbar.leave
    assert pbar.disable
    assert pbar.unit == ''
    assert pbar.unit_scale == 1
    assert pbar.miniters == 1
    assert pbar.ascii
    assert pbar.dynamic_ncols
    assert pbar.bar_format == '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    assert pbar

# Generated at 2022-06-18 11:49:53.573959
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:49:55.373714
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:50:00.201898
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            for k in tnrange(5, desc='3nd loop'):
                sleep(0.01)
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            for k in tnrange(5, desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:50:11.078062
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.test_utils import DiscreteFuncs
    from tqdm.utils import _term_move_up

    def test_display(bar, msg=None, pos=None,
                     # additional signals
                     close=False, bar_style=None, check_delay=True):
        if msg:
            bar.write(msg)
        if close:
            bar.close()

    def test_display_no_msg(bar, msg=None, pos=None,
                            # additional signals
                            close=False, bar_style=None, check_delay=True):
        pass


# Generated at 2022-06-18 11:50:19.370526
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc="test_tqdm_notebook_clear"):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear(i)
            break
    for i in tqdm_notebook(range(10), desc="test_tqdm_notebook_clear"):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear(i)
            break

# Generated at 2022-06-18 11:50:25.858814
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
        tqdm.reset()


# Generated at 2022-06-18 11:50:36.722580
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _term_move_up

    # Test the method status_printer of class tqdm_notebook
    # with the default parameters
    tqdm_notebook.status_printer(None)

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10
    tqdm_notebook.status_printer(None, 10)

    # Test the method status_printer of class tqdm_notebook
    # with a total of 10 and a description
    tqdm_notebook.status_printer(None, 10, "test")

    # Test the method status_printer

# Generated at 2022-06-18 11:51:05.220374
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count

    def f(x):
        sleep(0.01)
        return x

    with tqdm(total=100) as pbar:
        for i in process_map(f, range(100), max_workers=cpu_count()):
            pbar.update()

# Generated at 2022-06-18 11:51:07.083353
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear()
            break


# Generated at 2022-06-18 11:51:12.449228
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        clear_output(wait=True)
        tqdm_notebook.display(i)
    tqdm_notebook.display(close=True)

# Generated at 2022-06-18 11:51:22.064911
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map

    def f(x):
        sleep(0.01)
        return x

    # Test tqdm_notebook
    with tqdm(total=10, leave=False) as pbar:
        for i in process_map(f, range(10)):
            pbar.update()
        pbar.reset()
        for i in process_map(f, range(10)):
            pbar.update()

    # Test tqdm
    with tqdm(total=10, leave=False) as pbar:
        for i in process_map(f, range(10)):
            pbar.update()
        pbar.reset()

# Generated at 2022-06-18 11:51:28.597871
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        tqdm.reset()
    tqdm.close()


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:51:38.937645
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .std import tqdm
    from .utils import _range

    # Test with no total
    tqdm_notebook.status_printer(None, None, 'desc', None)

    # Test with total
    tqdm_notebook.status_printer(None, 10, 'desc', None)

    # Test with total and desc
    tqdm_notebook.status_printer(None, 10, 'desc', None)

    # Test with total and ncols
    tqdm_notebook.status_printer(None, 10, None, 100)

    # Test with total and ncols
    tqdm_notebook.status_printer(None, 10, 'desc', 100)

    # Test

# Generated at 2022-06-18 11:51:41.177457
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:51:44.512844
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:51:56.016643
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .std import tqdm
    from .utils import format_sizeof

    # Test with total
    total = 100
    pbar = tqdm_notebook.status_printer(total=total)
    assert pbar.children[1].max == total
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[1].layout.width is None

    # Test without total
    pbar = tqdm_notebook.status_printer()
    assert pbar.children[1].max == 1
    assert pbar.children[1].value == 1

# Generated at 2022-06-18 11:52:09.554206
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_timespan
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter

# Generated at 2022-06-18 11:52:50.085568
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_speed

    # Test with no total
    pbar = tqdm_notebook.status_printer(None, None, None)
    assert pbar.max == 1
    assert pbar.bar_style == 'info'

    # Test with total
    pbar = tqdm_notebook.status_printer(None, 100, None)
    assert pbar.max == 100
    assert pbar.bar_style == 'success'

    # Test with total and description

# Generated at 2022-06-18 11:53:00.182341
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(1, 5), desc='1st loop'):
        for j in tqdm(range(1, 5), desc='2nd loop'):
            for k in tqdm(range(1, 5), desc='3nd loop'):
                sleep(0.01)
        if i >= 2:
            break
    for i in tqdm(range(1, 5), desc='1st loop'):
        for j in tqdm(range(1, 5), desc='2nd loop'):
            for k in tqdm(range(1, 5), desc='3nd loop'):
                sleep(0.01)
        if i >= 2:
            break

# Generated at 2022-06-18 11:53:03.637069
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)


# Generated at 2022-06-18 11:53:09.168422
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        tqdm.reset()
    tqdm.close()

# Generated at 2022-06-18 11:53:12.670100
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:21.288174
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=True):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop'):
            for k in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:53:24.115395
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random() / 10)


# Generated at 2022-06-18 11:53:27.181382
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:53:37.487004
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            pbar.set_description("test")
            pbar.set_postfix({"test": i})
            pbar.display()
            pbar.clear()
            pbar.display()
            pbar.write("test")
            pbar.write("test", file=sys.stderr)
            pbar.write("test", file=sys.stdout)
            pbar.write("test", file=sys.stdout, end="")

# Generated at 2022-06-18 11:53:46.967849
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
            pbar.display(msg='{:.2f}'.format(random()))

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()
            pbar.display(msg='{:.2f}'.format(random()))
            if random() < 0.5:
                raise Exception("Error")

    # Test display with error and leave

# Generated at 2022-06-18 11:54:47.981484
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
            sleep(0.01)
        sleep(0.01)
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
            sleep(0.01)

# Generated at 2022-06-18 11:54:59.282765
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                if random() < 0.1:
                    break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:55:08.365578
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(20):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(20):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=10)

# Generated at 2022-06-18 11:55:20.535209
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest import TestCase
    from tqdm.notebook import TqdmHBox

    class TestTqdmHBox(TestCase):
        def test_repr(self):
            pbar = TqdmHBox()
            pbar.pbar = std_tqdm(total=10)
            pbar.pbar.n = 5

# Generated at 2022-06-18 11:55:31.120377
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO
    from unittest import TestCase

    class TestTqdmNotebookDisplay(TestCase):
        def test_display(self):
            # Test display() method
            with StringIO() as f:
                pbar = tqdm_notebook(total=10, file=f)
                pbar.display()
                self.assertEqual(f.getvalue(),
                                 '\r|{0}| 0/10 [00:00<?, ?it/s]'.format(' ' * 20))
                pbar.update()
                pbar.display()
                self.assertEqual(f.getvalue(),
                                 '\r|{0}| 1/10 [00:00<?, ?it/s]'.format('#' * 20))
                pbar.update(5)
                pbar

# Generated at 2022-06-18 11:55:40.865058
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3rd loop', leave=False):
                sleep(0.01)
        trange.reset()
        trange.set_description('new desc')
        for j in trange(5, desc='2nd loop'):
            for k in trange(50, desc='3rd loop', leave=False):
                sleep(0.01)
        trange.reset()
        trange.set_description('new desc')

# Generated at 2022-06-18 11:55:50.654913
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_
    from IPython.html.widgets import ContainerWidget as HBox_
    from IPython.html.widgets import FloatProgressWidget as IProgress_
    from IPython.html.widgets import Widget
    from IPython.html.widgets import widget_serialization

    # Test with IPython 3.x
    if IPY == 3:
        assert issubclass(HTML, HTML_)
        assert issubclass(HBox, HBox_)
        assert issubclass(IProgress, IProgress_)
        assert issubclass(Widget, Widget)

# Generated at 2022-06-18 11:56:00.351617
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .gui import tqdm as tqdm_gui

    def test_status_printer(total, desc, ncols):
        """
        Test status printer
        """
        # Initialize tqdm_notebook
        tqdm_notebook.status_printer(None, total, desc, ncols)

        # Initialize tqdm_gui
        tqdm_gui.status_printer(None, total, desc, ncols)

    # Test with total
    test_status_printer(10, "", None)
    test_status_printer(10, "", 100)
    test_status_printer(10, "", "100px")

# Generated at 2022-06-18 11:56:09.859518
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _range

    # Test with a range

# Generated at 2022-06-18 11:56:18.516672
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count

    def f(x):
        sleep(0.1)
        return x

    with trange(10) as t:
        for i in process_map(f, t, total=10, desc='1st loop', n_jobs=cpu_count()):
            pass

    with trange(10) as t:
        for i in process_map(f, t, total=10, desc='2nd loop', n_jobs=cpu_count()):
            pass
