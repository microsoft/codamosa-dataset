

# Generated at 2022-06-18 11:49:52.049615
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
            print(j)
        print(i)
        tqdm_notebook.clear(i)


# Generated at 2022-06-18 11:50:00.600319
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import arange
    from tqdm.auto import trange
    for _ in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop'):
            sleep(0.01)
        for i in trange(100, desc='3rd loop'):
            sleep(0.01)
            if random() < 0.1:
                break
    for _ in trange(10):
        pass
    for _ in trange(arange(10)):
        pass
    for _ in trange(10, desc='1st loop'):
        for _ in trange(100, desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-18 11:50:11.905513
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test display %i" % i)
            pbar.update()
            sleep(0.1)
        pbar.set_description("Test display done")
        pbar.close()

    # Test display with error
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.set_description("Test display error %i" % i)
            pbar.update()
            sleep(0.1)
            if i == 5:
                raise ValueError("Test display error")
        pbar

# Generated at 2022-06-18 11:50:19.419485
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            tqdm.clear(2)
            break
    tqdm.close()

# Generated at 2022-06-18 11:50:24.965717
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)


# Generated at 2022-06-18 11:50:35.752423
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10
    assert t.last_print_t == 1.0
    assert t.n == t.last_print_n
    assert t.total == 10
    assert t.dynamic_ncols
    assert t.unit == 'it'
    assert t.unit_scale
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.smoothing == 0.3
    assert t.avg_time == 0.1

# Generated at 2022-06-18 11:50:40.058872
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()



# Generated at 2022-06-18 11:50:43.181710
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        for i in range(4):
            sleep(0.01)
            pbar.update()


# Generated at 2022-06-18 11:50:51.326550
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for k in trange(50, desc='3nd loop'):
                sleep(0.01)
        if i >= 2:
            break
    for i in trange(5, desc='1st loop'):
        for j in trange(50, desc='2nd loop'):
            sleep(0.01)
        if i >= 2:
            break

# Generated at 2022-06-18 11:50:55.876572
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)


# Generated at 2022-06-18 11:51:17.899241
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import FormatCustomText, FormatCustomTextTest
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_eta
    from .utils import format_size
    from .utils import format_speed
    from .utils import format_stats
    from .utils import format_line
    from .utils import format_overhead
    from .utils import format_bar
    from .utils import format_width
    from .utils import format_interval_short
    from .utils import format_interval_long
    from .utils import format_interval_floating
    from .utils import format_interval_adaptive
    from .utils import format_interval_adaptive_short


# Generated at 2022-06-18 11:51:27.080578
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from tqdm import trange
    from tqdm.notebook import tqdm_notebook
    from tqdm.auto import tqdm as tqdm_auto

    # Test tqdm_notebook
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test tqdm_notebook with manual close
    with tqdm_notebook(total=10, leave=True) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

    # Test tqdm_notebook with manual close and error

# Generated at 2022-06-18 11:51:36.212815
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from random import random
    from sys import stderr
    from re import findall

    # Test display
    for i in tqdm_notebook(range(10), desc='1st loop', leave=False):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True,
                                   mininterval=0.01):
                sleep(0.01 * random())
                if k == 50:
                    break
            else:
                continue
            break
        else:
            continue
        break
    # Test close

# Generated at 2022-06-18 11:51:47.366557
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tnrange
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    with trange(10) as t:
        for i in t:
            sleep(0.1)
            t.set_description("test")
            t.set_postfix(ordered_dict=dict(a=i))
            t.update(2)
            if i == 3:
                t.set_postfix(ordered_dict=dict(a=i, b=i))
            if i == 6:
                t.set_postfix(ordered_dict=dict(a=i, b=i, c=i))

# Generated at 2022-06-18 11:51:58.513796
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from .utils import _range
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_number
    from .utils import format_time
    from .utils import format_size
    from .utils import format_speed
    from .utils import format_eta
    from .utils import format_stats
    from .utils import format_line
    from .utils import format_overline
    from .utils import format_underline
    from .utils import format_center
    from .utils import format_bold
    from .utils import format_block
    from .utils import format_width
    from .utils import format_ascii
    from .utils import format_dict
    from .utils import format_dict_html

# Generated at 2022-06-18 11:52:04.018349
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
            tqdm.write("cleared")
    tqdm.close()

# Generated at 2022-06-18 11:52:14.011125
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from unittest import TestCase
    from tqdm.notebook import tqdm_notebook

    class TestTqdmHBox(TestCase):
        def test_TqdmHBox___repr__(self):
            with redirect_stdout(StringIO()) as f:
                for i in tqdm_notebook(range(10)):
                    pass
            self.assertEqual(f.getvalue().strip(), '100%|██████████| 10/10 [00:00<00:00, ?it/s]')

    TestTqdmHBox().test_TqdmHBox___repr__()

# Generated at 2022-06-18 11:52:20.301877
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    for i in trange(3, desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop'):
            sleep(0.01)

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:52:31.103184
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook.
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10, desc='test')
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == 'test'
    assert pbar.children[1].max == 10
    assert pbar.children[2].value == ''
    # Test without total
    pbar = tqdm_notebook.status_printer(None, total=None, desc='test')
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[0].value == 'test'
    assert pbar.children[1].max == 1
    assert pbar.children[2].value

# Generated at 2022-06-18 11:52:36.720945
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:04.552676
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    with tqdm_notebook(total=2) as pbar:
        pbar.clear()
        pbar.update()
        pbar.clear()
        pbar.update()



# Generated at 2022-06-18 11:53:08.328257
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10, leave=False) as t:
        for i in range(10):
            sleep(0.1)
            t.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:18.235066
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import ndarray
    from numpy import zeros
    from numpy import ones
    from numpy import arange
    from numpy import linspace
    from numpy import logspace
    from numpy import geomspace
    from numpy import meshgrid
    from numpy import mgrid
    from numpy import ogrid
    from numpy import random
    from numpy import empty
    from numpy import empty_like
    from numpy import eye
    from numpy import identity
    from numpy import ones_like
    from numpy import zeros_like
    from numpy import full
    from numpy import full_like
    from numpy import tile


# Generated at 2022-06-18 11:53:29.084418
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:53:32.810703
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Error")


# Generated at 2022-06-18 11:53:42.364618
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib.concurrent import process_map

    # Test display
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test display with nested bars
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            with tqdm_notebook(total=10) as pbar2:
                for j in range(10):
                    sleep(0.1)
                    pbar2.update()
            pbar.update()

    # Test display with nested bars and errors

# Generated at 2022-06-18 11:53:46.094236
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test tqdm_notebook update")
        else:
            pass



# Generated at 2022-06-18 11:53:53.189039
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:54:00.252320
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    from time import sleep
    from sys import version_info
    from random import random

    # Test with no total
    with tqdm_notebook(desc="Test no total") as pbar:
        for i in range(10):
            sleep(random() / 5)
            pbar.update()

    # Test with total
    with tqdm_notebook(total=10, desc="Test total") as pbar:
        for i in range(10):
            sleep(random() / 5)
            pbar.update()

    # Test with total and dynamic_ncols

# Generated at 2022-06-18 11:54:06.363753
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
            break
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
            break
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()
            break

# Generated at 2022-06-18 11:54:22.321600
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)


# Generated at 2022-06-18 11:54:25.875930
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

# Generated at 2022-06-18 11:54:27.951815
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:54:35.724307
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:54:45.757913
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=False, disable=True):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), disable=True):
        sleep(0.1)

# Generated at 2022-06-18 11:54:57.176765
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_widget

    # Test for total=None
    container = tqdm_notebook.status_printer(None, total=None)
    assert isinstance(container, HBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML_widget)
    assert isinstance(container.children[1], FloatProgress)
    assert isinstance(container.children[2], HTML_widget)
    assert container.children[1].min == 0
    assert container.children[1].max == 1
    assert container.children[1].value == 1

# Generated at 2022-06-18 11:55:04.720635
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tqdm
    from tqdm.notebook import tqdm as tqdm_notebook
    from tqdm.utils import _term_move_up
    from time import sleep

    # Test with tqdm
    with tqdm(total=10) as pbar:
        for i in pbar:
            sleep(0.01)
            if i == 5:
                raise Exception("Test Exception")

    # Test with tqdm_notebook
    with tqdm_notebook(total=10) as pbar:
        for i in pbar:
            sleep(0.01)
            if i == 5:
                raise Exception("Test Exception")

    # Test with tqdm_notebook and manual update

# Generated at 2022-06-18 11:55:08.148105
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
        tqdm_notebook.clear(i)
        sleep(0.1)


# Generated at 2022-06-18 11:55:20.263826
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from unittest import TestCase
    from io import StringIO
    from sys import version_info

    class TestTqdmNotebookStatusPrinter(TestCase):
        """
        Unit test for method status_printer of class tqdm_notebook
        """
        def test_status_printer(self):
            """
            Unit test for method status_printer of class tqdm_notebook
            """
            # Test with total
            total = 10
            container = tqdm_notebook.status_printer(
                file=StringIO(), total=total)
            self.assertEqual(container.children[1].max, total)
            self.assertEqual(container.children[1].value, 0)

           

# Generated at 2022-06-18 11:55:30.824709
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(5)):
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(5)):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=10)
    for i in tqdm(range(10)):
        sleep(0.1)
    tqdm.reset(total=5)

# Generated at 2022-06-18 11:56:00.832050
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.auto import trange

    with tqdm_notebook(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.update()



# Generated at 2022-06-18 11:56:05.005169
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    t = tqdm_notebook(total=10)
    for i in range(10):
        sleep(0.1)
        t.update()
    t.reset(total=20)
    for i in range(20):
        sleep(0.1)
        t.update()
    t.close()

# Generated at 2022-06-18 11:56:07.673353
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    from .tests import test_clear
    test_clear(tqdm_notebook)

# Generated at 2022-06-18 11:56:11.213790
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:56:20.868417
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()
            t.clear()
            t.update()

# Generated at 2022-06-18 11:56:31.254040
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from numpy.random import random
    from numpy import arange, zeros
    from numpy.testing import assert_array_equal

    # Test 1
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test 2
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.close()

    # Test 3
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset()

    # Test 4


# Generated at 2022-06-18 11:56:33.565492
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:56:40.974041
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        if i >= 2:
            tqdm.clear(2)
            tqdm.clear(1)
            tqdm.clear(0)


# Generated at 2022-06-18 11:56:50.288799
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(3), desc='2nd loop', leave=False):
            for k in tqdm(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(3), desc='2nd loop'):
            for k in tqdm(range(3), desc='3nd loop'):
                sleep(0.01)
        sleep(0.01)


if __name__ == '__main__':
    test_tqdm

# Generated at 2022-06-18 11:56:58.826212
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)
    # Test with desc
    tqdm_notebook.status_printer(None, total=10, desc="test")
    # Test with ncols
    tqdm_notebook.status_printer(None, total=10, ncols=100)
    tqdm_notebook.status_printer(None, total=10, ncols="100px")
    tqdm_notebook.status_printer(None, total=10, ncols="100%")
    # Test without ncols


# Generated at 2022-06-18 11:57:53.802862
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(3), desc='3nd loop', leave=True):
                sleep(0.01)
                tqdm_notebook.clear()


# Generated at 2022-06-18 11:58:01.094738
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm.utils import _term_move_up

    # Test 1
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test 2
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    # Test 3
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(i)

    # Test 4

# Generated at 2022-06-18 11:58:05.406983
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:58:14.633808
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook
    """
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm_notebook
    # Test for method status_printer of class tqdm

# Generated at 2022-06-18 11:58:16.370688
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:58:25.190302
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook constructor
    """
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _supports_unicode, _environ_cols_wrapper

    # Test default
    with _environ_cols_wrapper(None):
        t = tqdm_notebook(total=10)
        assert isinstance(t, tqdm_notebook)
        t.close()

    # Test gui=True
    with _environ_cols_wrapper(None):
        t = tqdm_notebook(total=10, gui=True)
        assert isinstance(t, tqdm_notebook)
        t.close()

    # Test gui=False

# Generated at 2022-06-18 11:58:33.243092
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep

# Generated at 2022-06-18 11:58:40.182293
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from tqdm._tqdm import format_meter
    from tqdm.utils import _term_move_up
    from tqdm.std import TqdmTypeError

    # Test display()
    with tqdm(total=10) as pbar:
        pbar.display()
        assert pbar.displayed
        assert pbar.container.children[-2].value == format_meter(
            pbar.n, pbar.total, pbar.dynamic_ncols, pbar.desc,
            pbar.ascii, pbar.unit, pbar.unit_scale, pbar.rate, pbar.bar_format,
            pbar.postfix, pbar.unit_divisor, pbar.ncols)
        pbar.display

# Generated at 2022-06-18 11:58:48.701785
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:58:52.205229
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    t = tqdm_notebook(total=10)
    for i in range(10):
        sleep(0.1)
        t.display(msg='{:.2f}'.format(i / 10))
        clear_output(wait=True)
    t.close()