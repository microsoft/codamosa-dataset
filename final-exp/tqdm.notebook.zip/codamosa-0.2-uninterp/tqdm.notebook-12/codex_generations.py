

# Generated at 2022-06-18 11:49:49.555866
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout

    # Test with a progress bar
    pbar = tqdm_notebook(total=10)
    pbar.update(1)
    pbar.refresh()
    pbar.container.layout.width = "100px"
    pbar.container.layout.display = "inline-flex"
    pbar.container.layout.flex_flow = "row wrap"
    pbar.container.children[0].value = "Test"
    pbar.container.children[2].value = "Test"
    pbar.container.children[1].bar_style = "success"
    pbar.container.children[1].value = 1
    pbar.container.children[1].max = 10
    pbar.container.children[1].min = 0
   

# Generated at 2022-06-18 11:49:57.011318
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm.auto import tqdm
    for _ in tqdm(range(5), desc='1st loop'):
        for _ in tqdm(range(5), desc='2nd loop', leave=False):
            for _ in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
    for _ in tqdm(range(5), desc='1st loop'):
        for _ in tqdm(range(5), desc='2nd loop', leave=False):
            for _ in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:49:59.278212
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.clear()
            t.update(1)


# Generated at 2022-06-18 11:50:09.980510
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            if i == 5:
                pbar.clear()
                pbar.set_description("cleared")
                pbar.set_postfix({"postfix": "cleared"})
                pbar.set_postfix_str("cleared")
                pbar.set_postfix({"postfix": "cleared"}, refresh=False)
                pbar.set_postfix_str("cleared", refresh=False)
                pbar.refresh()
                pbar.set_postfix({"postfix": "cleared"}, refresh=True)
                pbar.set_

# Generated at 2022-06-18 11:50:15.978504
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm_notebook.clear()
            break

if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-18 11:50:27.022587
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.container.children[-2].bar_style == 'success'

    with tqdm_notebook(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 5
    assert pbar.container.children[-2].bar_style == 'danger'

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar

# Generated at 2022-06-18 11:50:29.353175
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:50:41.049599
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass
    for _ in tqdm_notebook(range(3)):
        pass

# Generated at 2022-06-18 11:50:43.683301
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()


# Generated at 2022-06-18 11:50:55.813960
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm.auto import tqdm
    from tqdm._tqdm import TqdmTypeError
    from tqdm._tqdm import TqdmKeyError
    from tqdm._tqdm import TqdmDeprecationWarning
    from tqdm._tqdm import TqdmExperimentalWarning

    with warnings.catch_warnings():
        warnings.filterwarnings('error', category=TqdmDeprecationWarning)
        warnings.filterwarnings('error', category=TqdmExperimentalWarning)
        try:
            tqdm.close()
        except TqdmDeprecationWarning:
            pass
        except TqdmExperimentalWarning:
            pass
        except TqdmTypeError:
            pass
        except TqdmKeyError:
            pass
        else:
            raise Assert

# Generated at 2022-06-18 11:51:17.441277
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception()

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:51:20.863553
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            sleep(0.1)


# Generated at 2022-06-18 11:51:24.377017
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()



# Generated at 2022-06-18 11:51:32.159353
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        sleep(random())
        if random() > 0.5:
            break
    for i in tqdm_notebook(range(10), desc='2nd loop'):
        sleep(random())
        if random() > 0.5:
            break
    for i in tqdm_notebook(range(10), desc='3rd loop'):
        sleep(random())
        if random() > 0.5:
            break
    for i in tqdm_notebook(range(10), desc='4th loop'):
        sleep(random())
        if random() > 0.5:
            break

# Generated at 2022-06-18 11:51:43.256836
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up

    # Test 1: test reset with total=None
    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(5):
            sleep(0.1)
            pbar.update()

    # Test 2: test reset with total=5
    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:51:54.640958
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from time import sleep
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
            clear_output(wait=True)
            pbar.display(msg='test')
            pbar.display(msg='test', bar_style='success')
            pbar.display(msg='test', bar_style='danger')
            pbar.display(msg='test', bar_style='warning')
            pbar.display(msg='test', bar_style='info')
            pbar.display(msg='test', bar_style='primary')

# Generated at 2022-06-18 11:52:07.856440
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=False):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10), leave=True):
        sleep(0.1)
        if i == 5:
            raise Exception
    for i in tqdm_notebook(range(10), leave=False):
        sleep

# Generated at 2022-06-18 11:52:19.640809
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test the method __repr__ of class TqdmHBox.
    """
    from tqdm.notebook import tqdm
    from tqdm.utils import _supports_unicode
    from tqdm.utils import _environ_cols_wrapper
    from tqdm.utils import _term_move_up
    from tqdm.utils import _unicode

    # Test the method __repr__ of class TqdmHBox
    with _environ_cols_wrapper(80):
        with tqdm(total=100) as t:
            t.update(10)
            assert t.__repr__() == '10/100 [#-------------------]  10%'
            t.update(10)

# Generated at 2022-06-18 11:52:30.565295
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test display
    t = tqdm(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
    t.close()

    # Test display with error
    t = tqdm(total=100)
    for i in range(10):
        t.update()
        sleep(0.01)
        if i == 5:
            raise Exception("Test exception")
    t.close()

    # Test display with error and leave
    t = tqdm(total=100, leave=True)
    for i in range(10):
        t.update()
        sleep(0.01)

# Generated at 2022-06-18 11:52:38.718323
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                clear_output(wait=True)
    clear_output(wait=True)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:53:05.414841
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm
    from time import sleep

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break

if __name__ == '__main__':
    test_tqdm_notebook

# Generated at 2022-06-18 11:53:09.952830
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from unittest import mock
    except ImportError:
        import mock
    from tqdm.notebook import tqdm_notebook
    with mock.patch('tqdm.notebook.tqdm_notebook.display') as display:
        for _ in tqdm_notebook(range(10)):
            pass
        assert display.call_count == 10


# Generated at 2022-06-18 11:53:11.849983
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:53:21.842816
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[0].value == ''
    assert pbar.children[2].value == ''
    assert pbar.layout.width == '100%'
    assert pbar.layout.display == 'inline-flex'

# Generated at 2022-06-18 11:53:33.033008
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:53:42.539470
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import trange
    for i in trange(10, desc='1st loop', leave=True):
        for j in trange(5, desc='2nd loop'):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
    for i in trange(10, desc='1st loop', leave=True):
        for j in trange(5, desc='2nd loop'):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
                if k == 50:
                    raise Exception()

# Generated at 2022-06-18 11:53:51.070292
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test the `tqdm_notebook.close` method.
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test with total
    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 5
    pbar.close()
    assert pbar.n == 5

    # Test without total
    with tqdm() as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 5
    pbar.close()
    assert pbar.n == 5

    # Test with total and error

# Generated at 2022-06-18 11:53:53.447029
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:54:01.644404
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(random() / 100.)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(random() / 100.)
            if random() < 0.1:
                break
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(random() / 100.)

# Generated at 2022-06-18 11:54:09.667366
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(0.01)
        if i == 4:
            raise Exception

# Generated at 2022-06-18 11:54:32.663000
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    from tqdm.utils import _term_move_up

    with trange(10) as t:
        for i in t:
            sleep(0.1)
            if i == 5:
                t.reset(total=20)
                t.set_description("New total")
                t.set_postfix(refresh=False)
                t.display(pos=i)
                t.write("\n" + _term_move_up())
                t.display(pos=i)
                t.write("\n" + _term_move_up())
                t.display(pos=i)
                t.write("\n" + _term_move_up())
                t.display(pos=i)

# Generated at 2022-06-18 11:54:42.296557
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:54:44.969620
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tqdm_notebook
    for _ in tqdm_notebook([1, 2, 3]):
        pass



# Generated at 2022-06-18 11:54:56.125901
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from numpy.random import randint
    from numpy.random import random
    from numpy.random import uniform
    from numpy.random import exponential
    from numpy.random import normal

    # Test 1: reset with total=None
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
            pbar.reset()
            sleep(0.1)
    assert pbar.n == 0

    # Test 2: reset with total=int
    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
            pbar.reset(total=50)
            sleep(0.1)


# Generated at 2022-06-18 11:55:04.434963
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].style.bar_color == 'lightblue'
    with tqdm_notebook(total=10, colour='red') as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].style.bar_color == 'red'

# Generated at 2022-06-18 11:55:15.528958
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    for i in range(10):
        pbar.value = i
        sleep(0.1)
    pbar.close()

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    for i in range(10):
        pbar.value = i
        sleep(0.1)
    pbar.close()

    # Test with description

# Generated at 2022-06-18 11:55:26.517653
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:55:36.447998
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    for i in trange(10):
        sleep(0.1)
        tqdm.update()
    for i in trange(10):
        sleep(0.1)
        tqdm.update(i)
    for i in trange(10):
        sleep(0.1)
        tqdm.update(i + 1)
    for i in trange(10):
        sleep(0.1)
        tqdm.update(i + 2)
    for i in trange(10):
        sleep(0.1)
        tqdm.update(i + 3)
    for i in trange(10):
        sleep(0.1)

# Generated at 2022-06-18 11:55:47.054694
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from tqdm import tqdm
    # Test 1
    for i in tqdm_notebook(range(10)):
        sleep(0.01)
    # Test 2
    for i in tqdm_notebook(range(10), desc='test'):
        sleep(0.01)
    # Test 3
    for i in tqdm_notebook(range(10), desc='test', leave=True):
        sleep(0.01)
    # Test 4
    for i in tqdm_notebook(range(10), desc='test', leave=False):
        sleep(0.01)
    # Test 5

# Generated at 2022-06-18 11:55:53.891424
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
                if k == 50:
                    raise Exception

# Generated at 2022-06-18 11:56:50.111398
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    from IPython.core.display import display
    from IPython.core.display import HTML

    # Create a progress bar
    pbar = tqdm_notebook(total=10)
    # Display it
    display(pbar)
    # Update it
    for i in range(10):
        pbar.update(1)
        sleep(0.1)
    # Close it
    pbar.close()

    # Create a progress bar
    pbar = tqdm_notebook(total=10)
    # Display it
    display(pbar)
    # Update it
    for i in range(10):
        pbar.update(1)
        sleep(0.1)
    # Clear

# Generated at 2022-06-18 11:56:53.901468
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:00.991497
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook
    """
    from .std import tqdm as std_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 10

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 1

    # Test with ncols

# Generated at 2022-06-18 11:57:10.441937
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    tqdm.reset()
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.1)
    tqdm.reset()

# Generated at 2022-06-18 11:57:19.764904
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange

    # Test display
    for i in trange(3, desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 1:
            tqdm.clear(1)
    # Test display
    for i in trange(3, desc='1st loop'):
        for j in tqdm(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 1:
            tqdm.clear(1)
    # Test display

# Generated at 2022-06-18 11:57:29.775921
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.display import clear_output
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                clear_output(wait=True)
    clear_output(wait=True)

# Generated at 2022-06-18 11:57:40.318409
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:57:42.657750
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:57:47.890822
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            pbar.set_description("test")
            pbar.set_postfix({"test": i})


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:57:55.918366
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with no total
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[1], IProgress)
    assert container.children[1].max == 1
    assert container.children[1].bar_style == 'info'
    assert container.children[1].layout.width == "20px"

    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[1], IProgress)
    assert container.children[1].max == 10