

# Generated at 2022-06-18 11:49:59.084885
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random
    from sys import stderr
    from os import get_terminal_size
    from IPython.display import clear_output
    from IPython.core.display import HTML

    # Test basic tqdm_notebook
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

    # Test tqdm_notebook with `leave=True`
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

    # Test tqdm_notebook with `leave=False`

# Generated at 2022-06-18 11:50:05.207222
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from multiprocessing import cpu_count

    def f(x):
        sleep(0.01)
        return x

    with tqdm(total=100) as pbar:
        for _ in process_map(f, range(100), max_workers=cpu_count()):
            pbar.update()

# Generated at 2022-06-18 11:50:11.393166
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)

# Generated at 2022-06-18 11:50:23.415974
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from IPython.display import clear_output
    from IPython.display import display as ipydisplay
    from IPython.display import HTML as ipyHTML
    from IPython.display import Javascript as ipyJavascript
    from IPython.display import display_javascript as ipydisplay_javascript
    from IPython.display import display_html as ipydisplay_html
    from IPython.display import display_markdown as ipydisplay_markdown
    from IPython.display import display_png as ipydisplay_png
    from IPython.display import display_jpeg as ipydisplay_jpeg
    from IPython.display import display_svg as ipydisplay_svg
    from IPython.display import display_pdf as ipydisplay_

# Generated at 2022-06-18 11:50:29.771440
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook constructor.
    """
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.last_print_n == 10
    assert pbar.last_print_t == pbar.last_print_t_



# Generated at 2022-06-18 11:50:32.996471
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()


# Generated at 2022-06-18 11:50:44.487603
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_
    from IPython.html.widgets import ContainerWidget as HBox_
    from IPython.html.widgets import FloatProgressWidget as IProgress_
    from IPython.html.widgets import Widget
    from IPython.html.widgets import DOMWidget
    from IPython.html.widgets import widget_serialization
    from IPython.html.widgets import widget_manager
    from IPython.html.widgets import widget
    from IPython.html.widgets import widget_box
    from IPython.html.widgets import widget_int
    from IPython.html.widgets import widget_float


# Generated at 2022-06-18 11:50:47.653110
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random() / 10)


# Generated at 2022-06-18 11:50:52.968303
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    assert pbar.n == 10


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:51:03.856689
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from sys import stderr
    from IPython.display import clear_output

    with tqdm_notebook(total=10, desc='test', file=stderr) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()

    with tqdm_notebook(total=10, desc='test', file=stderr, leave=True) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()

    with tqdm_notebook(total=10, desc='test', file=stderr, leave=True,
                       disable=True) as pbar:
        for i in range(10):
            sleep(0.1)

# Generated at 2022-06-18 11:51:28.980511
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break

# Generated at 2022-06-18 11:51:38.321737
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:51:49.441394
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test the method status_printer of class tqdm_notebook
    # with the default parameters
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)

    # Test the method status_printer of class tqdm_notebook
    # with a total
    container = tqdm_notebook.status_printer(None, total=100)

# Generated at 2022-06-18 11:52:01.980455
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook
    """
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test with total
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    clear_output(wait=True)

    # Test without total
    with tqdm() as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)
    clear_output(wait=True)

    # Test with total and description

# Generated at 2022-06-18 11:52:14.064425
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError
    from tqdm._tqdm_gui import _range

    # Test for TqdmTypeError
    try:
        tqdm(1)
    except TqdmTypeError:
        pass
    else:
        raise AssertionError()

    # Test for TqdmTypeError
    try:
        tqdm(1, 1)
    except TqdmTypeError:
        pass
    else:
        raise AssertionError()

    # Test for TqdmTypeError
    try:
        tqdm(1, 1, 1)
    except TqdmTypeError:
        pass
    else:
        raise Assert

# Generated at 2022-06-18 11:52:18.672979
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")


# Generated at 2022-06-18 11:52:22.372549
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        tqdm_notebook.update(1)


# Generated at 2022-06-18 11:52:26.162859
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    from tqdm.auto import tqdm
    t = tqdm(total=10)
    for i in range(10):
        time.sleep(0.1)
        t.update()
    t.close()

# Generated at 2022-06-18 11:52:36.981348
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)
        if i == 2:
            break
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            sleep(0.01)

# Generated at 2022-06-18 11:52:47.598883
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.last_print_n == 10
    assert t.last_print_t == 1.0
    assert t.total == 10
    assert t.dynamic_ncols
    assert t.ncols == 100
    assert t.desc == ''
    assert t.smoothing == 0.3
    assert t.ascii
    assert t.unit == 'it'
    assert t.unit_scale
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.maxinterval == 10.0
    assert t.leave

# Generated at 2022-06-18 11:53:09.247109
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm
    from .gui import tqdm_gui
    from .utils import _supports_unicode
    from .utils import _environ_cols_wrapper
    from .utils import _range

    # Test with default parameters
    tqdm_notebook.status_printer(None)

    # Test with total = None
    tqdm_notebook.status_printer(None, total=None)

    # Test with desc = None
    tqdm_notebook.status_printer(None, total=None, desc=None)

    # Test with ncols = None

# Generated at 2022-06-18 11:53:15.097519
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        tqdm.reset()
    tqdm.close()

# Generated at 2022-06-18 11:53:25.331751
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:53:27.879924
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:53:38.135369
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tnrange
    for _ in tnrange(3):
        sleep(0.1)
        tnrange(3).reset(total=3)
        for _ in tnrange(3):
            sleep(0.1)
        tnrange(3).reset()
        for _ in tnrange(3):
            sleep(0.1)
        tnrange(3).reset(total=3, leave=True)
        for _ in tnrange(3):
            sleep(0.1)
        tnrange(3).reset(leave=True)
        for _ in tnrange(3):
            sleep(0.1)
        tnrange(3).reset(total=3, leave=False)

# Generated at 2022-06-18 11:53:45.509361
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                clear_output(wait=True)
                sleep(0.01)
        clear_output(wait=True)
        sleep(0.01)
    clear_output(wait=True)
    sleep(0.01)



# Generated at 2022-06-18 11:53:52.846325
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test 1: reset with total=None
    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update(1)
        pbar.reset()
        for i in range(5):
            sleep(0.1)
            pbar.update(1)

    # Test 2: reset with total=5
    with tqdm(total=10) as pbar:
        for i in range(5):
            sleep(0.1)
            pbar.update(1)
        pbar.reset(total=5)
        for i in range(5):
            sleep(0.1)
            pbar.update(1)

    #

# Generated at 2022-06-18 11:53:54.812199
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:53:57.070663
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()

# Generated at 2022-06-18 11:54:04.388302
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from IPython.display import display
    from IPython.display import clear_output
    from time import sleep
    from tqdm.notebook import tqdm
    from tqdm.notebook import TqdmHBox
    from tqdm.notebook import HTML
    from tqdm.notebook import IProgress
    from tqdm.notebook import HBox

    # Test __repr__
    pbar = tqdm(total=10)
    display(pbar)
    for i in range(10):
        pbar.update(1)
        sleep(0.1)
    pbar.close()
    clear_output()

    # Test __repr__ with no total
    pbar = tqdm(total=None)
    display(pbar)
    for i in range(10):
        pbar

# Generated at 2022-06-18 11:54:51.449749
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(3)):
        sleep(0.1)
    tqdm.reset(total=3)
    for i in tqdm(range(3)):
        sleep(0.1)
    tqdm.reset(total=3)
    for i in tqdm(range(3)):
        sleep(0.1)
    tqdm.reset(total=3)
    for i in tqdm(range(3)):
        sleep(0.1)
    tqdm.reset(total=3)
    for i in tqdm(range(3)):
        sleep(0.1)
    tqdm.reset(total=3)

# Generated at 2022-06-18 11:55:01.798931
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:55:06.555379
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.write("Hello World!")
        tqdm.update()

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:17.731754
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from IPython.display import clear_output
    from tqdm.notebook import tqdm_notebook

    with redirect_stdout(StringIO()) as f:
        with tqdm_notebook(total=10) as pbar:
            print(pbar)
            clear_output()
            print(pbar)
            clear_output()
            pbar.update(1)
            print(pbar)
            clear_output()
            pbar.update(1)
            print(pbar)
            clear_output()
            pbar.update(1)
            print(pbar)
            clear_output()
            pbar.update(1)
            print(pbar)
            clear_output()
            pbar.update(1)


# Generated at 2022-06-18 11:55:22.666301
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:33.033595
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO
    from contextlib import redirect_stdout
    from tqdm.notebook import tqdm_notebook
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.std import tqdm as tqdm_std

    # Test with a manual tqdm
    with StringIO() as f:
        with redirect_stdout(f):
            t = tqdm_notebook(total=10)
            t.display()
            t.display(close=True)
            t.display(bar_style='success')
            t.display(bar_style='danger')
            t.display(bar_style='danger', close=True)
            t.display(bar_style='danger', close=True)

# Generated at 2022-06-18 11:55:39.392345
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                clear_output(wait=True)

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:55:45.445430
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test 1: no error
    for i in tqdm(range(3)):
        sleep(0.1)

    # Test 2: error
    for i in tqdm(range(3)):
        sleep(0.1)
        raise Exception


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:55:49.294159
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()



# Generated at 2022-06-18 11:55:59.054846
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test with default bar
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test with custom bar
    with tqdm(total=10, desc='Custom bar') as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test with custom bar and custom colour
    with tqdm(total=10, desc='Custom bar', colour='#00ff00') as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test with custom bar and custom colour

# Generated at 2022-06-18 11:56:31.255091
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from multiprocessing import Pool
    from threading import Thread

    def f(x):
        sleep(0.01)
        return x

    # Test reset() with total=None
    for cls in [tqdm, tqdm_notebook]:
        with cls(total=10) as pbar:
            for i in range(5):
                pbar.update()
            pbar.reset()
            for i in range(5):
                pbar.update()

    # Test reset() with total=int

# Generated at 2022-06-18 11:56:41.594291
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_widget
    from IPython.html.widgets import ContainerWidget
    from IPython.html.widgets import FloatProgressWidget
    from IPython.html.widgets import Widget
    from IPython.html.widgets import widget_serialization
    from IPython.html.widgets import widget_serialization
    from IPython.utils.traitlets import Unicode
    from IPython.utils.traitlets import Float
    from IPython.utils.traitlets import Int
    from IPython.utils.traitlets import Bool
    from IPython.utils.traitlets import Enum

# Generated at 2022-06-18 11:56:51.116269
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()
    assert t.n == 10
    assert t.container.children[-2].value == 10
    assert t.container.children[-2].bar_style == 'success'
    assert t.container.children[-2].layout.width == '100%'
    assert t.container.children[-2].layout.display == 'inline-flex'
    assert t.container.children[-2].layout.flex_flow == 'row wrap'
    assert t.container.children[-2].layout.flex == '2'
    assert t.container.children[-1].value == ''
    assert t.container.children[-1].layout.width

# Generated at 2022-06-18 11:56:56.135697
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    with tqdm_notebook(total=10, desc="test") as pbar:
        for i in range(10):
            pbar.display(msg="test")
            sleep(0.1)
            clear_output(wait=True)
            pbar.update()
    with tqdm_notebook(total=10, desc="test") as pbar:
        for i in range(10):
            pbar.display(msg="test", bar_style='success')
            sleep(0.1)
            clear_output(wait=True)
            pbar.update()

# Generated at 2022-06-18 11:57:04.407019
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm

    # Test display
    with tqdm(total=10, desc='test', leave=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test display with error
    with tqdm(total=10, desc='test', leave=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            if i == 5:
                raise Exception

    # Test display with KeyboardInterrupt
    with tqdm(total=10, desc='test', leave=False) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:57:13.615502
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
            if i == 5:
                pbar.display(bar_style='danger')
    clear_output()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:57:23.599300
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)

# Generated at 2022-06-18 11:57:27.419501
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10, desc="test") as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:33.086621
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Error")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt("Interrupted")

# Generated at 2022-06-18 11:57:36.776364
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)


# Generated at 2022-06-18 11:58:13.450993
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
            if i == 5:
                pbar.display(msg='{:.2f}'.format(i / 10))
            elif i == 7:
                pbar.display(msg='{:.2f}'.format(i / 10), bar_style='warning')
            elif i == 8:
                pbar.display(msg='{:.2f}'.format(i / 10), bar_style='danger')
            elif i == 9:
                pbar.display(msg='{:.2f}'.format(i / 10), bar_style='success')




# Generated at 2022-06-18 11:58:20.863752
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    tqdm.reset()
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:58:29.766460
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert container.children[0].value == ''
    assert container.children[1].value == 0
    assert container.children[2].value == ''
    assert container.children[1].max == 10
    assert container.children[1].bar_style == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert container.children[0].value == ''
    assert container.children[1].value == 1
    assert container.children[2].value == ''
    assert container.children[1].max == 1

# Generated at 2022-06-18 11:58:36.562500
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert pbar.max == 10
    assert pbar.value == 0
    assert pbar.bar_style == ''

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert pbar.max == 1
    assert pbar.value == 1
    assert pbar.bar_style == 'info'

    # Test with desc
    pbar = tqdm_notebook.status_printer(None, total=10, desc='test')
    assert pbar.children[0].value == 'test'

    # Test with ncols
    pbar = t

# Generated at 2022-06-18 11:58:41.988799
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .utils import _term_move_up
    from .std import TqdmTypeError

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[1].layout.width == "20px"
    assert pbar.children[1].layout.flex == '2'
    assert pbar.layout.width == "100%"
    assert pbar.layout.display == 'inline-flex'

# Generated at 2022-06-18 11:58:50.345270
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import TqdmTypeError
    from tqdm._utils import _term_move_up

    # Test display()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display()

    # Test display(msg)
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(msg='{:d}/{:d}'.format(i, 10))

    # Test display(msg, pos)

# Generated at 2022-06-18 11:58:54.141704
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-18 11:58:58.761238
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from tqdm.auto import tqdm
    from tqdm.notebook import tqdm_notebook
    for cls in [tqdm, tqdm_notebook]:
        with cls(total=10) as pbar:
            for i in range(10):
                time.sleep(0.1)
                pbar.update()


# Generated at 2022-06-18 11:59:06.957960
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        assert tqdm_notebook.n == 0
        assert tqdm_notebook.last_print_n == 0
        assert tqdm_notebook.dynamic_ncols == False
        assert tqdm_notebook.total == None
        assert tqdm_notebook.container.children[1].max == None
        assert tqdm_notebook.container.children[1].layout.width == "100%"
        assert tqdm_notebook.container.children[1].bar_style == ""
        assert tq

# Generated at 2022-06-18 11:59:09.709716
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
