

# Generated at 2022-06-18 11:50:03.565407
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    from tqdm.contrib.tests import pretest_posttest

    with pretest_posttest(False):
        for i in tqdm_notebook(range(5), desc='1st loop', leave=True):
            for j in tqdm_notebook(range(100), desc='2nd loop', leave=True):
                sleep(0.01)
            if i == 2:
                break
        for i in tqdm_notebook(range(5), desc='1st loop', leave=True):
            for j in tqdm_notebook(range(100), desc='2nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:50:15.106731
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    with tqdm_notebook(total=100, leave=True) as t:
        for i in range(100):
            sleep(random() / 100)
            t.update()
    assert t.n == 100
    assert t.last_print_n == 100
    assert t.last_print_t == 100
    assert t.n == t.last_print_n
    assert t.n == t.last_print_t
    assert t.n == t.total
    assert t.n == t.last_print_n
    assert t.n == t.last_print_t
    assert t.n == t.total
    assert t.n == t.last_print_n
    assert t.n == t.last_print_t

# Generated at 2022-06-18 11:50:26.372327
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop'):
            for k in tqdm(range(100), desc='3nd loop', leave=True):
                sleep(0.01)

# Generated at 2022-06-18 11:50:33.201077
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(0.1)
            clear_output(wait=True)
            pbar.display(msg='{:.2f}%'.format(pbar.n / pbar.total * 100))
        pbar.display(close=True)

# Generated at 2022-06-18 11:50:42.008495
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from unittest import TestCase, main
    from io import StringIO
    from contextlib import redirect_stdout

    class TestTqdmHBox(TestCase):
        def test_repr(self):
            with redirect_stdout(StringIO()) as f:
                t = tqdm_notebook(total=10)
                print(t)
                t.close()
            self.assertEqual(f.getvalue(), '  0%|          | 0/10 [00:00<?, ?it/s]\n')

    main(module='__main__', exit=False)

# Generated at 2022-06-18 11:50:53.343957
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up

    # Test display
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(str(i))
            pbar.update()

    # Test display with bar_style
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(str(i), bar_style='success')
            pbar.update()

    # Test display with bar_style and close

# Generated at 2022-06-18 11:50:57.737609
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Error")


# Generated at 2022-06-18 11:51:06.568500
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop'):
            for k in trange(100, desc='3nd loop'):
                sleep(0.01)
        if i == 2:
            break


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:51:17.057851
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._utils import _term_move_up
    from tqdm._utils import _range
    from tqdm._utils import _environ_cols_wrapper
    from tqdm._utils import _screen_shape
    from tqdm._utils import _unicode
    from tqdm._utils import _supports_unicode
    from tqdm._utils import _environ_cols_wrapper
    from tqdm._utils import _unicode
    from tqdm._utils import _supports_unicode
    from tqdm._utils import _term_move_up
    from tqdm._utils import _range
    from tqdm._utils import _screen_shape
    from tqdm._utils import _unicode
    from tqdm._utils import _supports_unicode

# Generated at 2022-06-18 11:51:26.265233
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError, TqdmKeyError

    # Test the method status_printer of class tqdm_notebook
    # with the default parameters
    tqdm_notebook.status_printer(None)

    # Test the method status_printer of class tqdm_notebook
    # with the parameters: total=10, desc='desc', ncols=100
    tqdm_notebook.status_printer(None, total=10, desc='desc', ncols=100)

    # Test the method status_printer of class tqdm_notebook
    # with the parameters: total=10, desc='desc', ncol

# Generated at 2022-06-18 11:51:45.754774
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:51:56.944930
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].max == 10
    assert container.children[1].value == 0
    assert container.children[1].bar_style == ''
    assert container.children[0].value == ''
    assert container.children[2].value == ''

    # Test without total
    container = tqdm_notebook.status

# Generated at 2022-06-18 11:52:10.500155
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
                if k == 50:
                    raise Exception()

# Generated at 2022-06-18 11:52:12.961648
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as pbar:
        pbar.clear()
        pbar.update()
        pbar.close()

# Generated at 2022-06-18 11:52:24.614732
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    from time import sleep
    from random import random
    from numpy import arange

    # Test with iterable
    for i in tqdm_notebook(arange(10)):
        sleep(0.01 * random())

    # Test with generator
    for i in tqdm_notebook((i for i in range(10))):
        sleep(0.01 * random())

    # Test with iterator
    for i in tqdm_notebook(iter(range(10))):
        sleep(0.01 * random())

    # Test with range
    for i in tqdm_notebook(range(10)):
        sleep(0.01 * random())

    # Test with enumerate

# Generated at 2022-06-18 11:52:26.899285
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:52:32.469706
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3rd loop'):
                sleep(0.01)
        tqdm_notebook.reset()


# Generated at 2022-06-18 11:52:38.616670
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map

    def f(x):
        sleep(0.01)
        return x

    with tqdm(total=10) as pbar:
        for _ in process_map(f, range(10), max_workers=4):
            pbar.update()

# Generated at 2022-06-18 11:52:43.431482
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.clear()


# Generated at 2022-06-18 11:52:51.207587
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)



# Generated at 2022-06-18 11:53:22.158085
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()


# Generated at 2022-06-18 11:53:26.619517
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    t = tqdm_notebook(total=100)
    for i in range(100):
        sleep(0.1)
        t.update(1)
    t.close()


# Generated at 2022-06-18 11:53:29.036572
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:53:39.089930
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.container.children[-2].style.bar_color == 'lightblue'
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.container.children[-2].style.bar_color == 'lightblue'
    with tqdm_notebook(total=10, leave=False) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update

# Generated at 2022-06-18 11:53:48.419745
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].max == 10
    assert container.children[1].value == 0
    assert container.children[1].bar_style == ''
    assert container.children[1].layout.width == '100%'
    assert container.children[1].layout.flex == '2'

# Generated at 2022-06-18 11:53:52.204524
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-18 11:53:59.004038
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.1)
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
        sleep(0.1)

# Generated at 2022-06-18 11:54:07.228520
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()
            t.clear()
            t.display()

# Generated at 2022-06-18 11:54:13.719591
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.tests.common import with_setup

    @with_setup(pretest=lambda: tqdm.pandas(tqdm_notebook))
    def inner():
        # Test process_map
        def nop(x):
            sleep(0.01)
            return x

        list(process_map(nop, range(10), max_workers=2))

        # Test manual tqdm
        with tqdm(total=10) as pbar:
            for _ in range(10):
                sleep(0.01)
                pbar.update()

        # Test pandas
        import pandas as pd
        df = pd.Data

# Generated at 2022-06-18 11:54:22.555319
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01 * random())
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=True):
            sleep(0.01 * random())
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01 * random())

# Generated at 2022-06-18 11:55:30.294105
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array, concatenate
    from numpy.testing import assert_array_equal

    # Test iterable
    for i in tqdm_notebook(range(10)):
        sleep(random())

    # Test iterable of iterables
    for i in tqdm_notebook([range(3), range(4), range(2)]):
        sleep(random())

    # Test iterable of iterables of iterables
    for i in tqdm_notebook([range(3), range(4), range(2)]):
        for j in tqdm_notebook([range(3), range(4), range(2)]):
            sleep(random())

    # Test total

# Generated at 2022-06-18 11:55:39.671188
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    from tqdm.utils import _unicode

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10, desc='Test')
    assert pbar.max == 10
    assert pbar.bar_style == ''
    assert pbar.description == 'Test'
    assert pbar.layout.width == '100%'
    assert pbar.layout.display == 'inline-flex'
    assert pbar.layout.flex_flow == 'row wrap'
    assert pbar.children[0].value == 'Test'
    assert pbar.children[1].style.bar_color == ''
   

# Generated at 2022-06-18 11:55:50.008074
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std
    from .utils import _range

    # Test with a simple iterator
    for cls in (tqdm_notebook, tqdm_gui, tqdm_std):
        for i in cls(iter([1, 2, 3])):
            pass

    # Test with a simple iterator and a manual close
    for cls in (tqdm_notebook, tqdm_gui, tqdm_std):
        for i in cls(iter([1, 2, 3])):
            pass
        i.close()

    # Test with a simple iterator and a manual close and a manual reset

# Generated at 2022-06-18 11:55:59.541092
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm.update(1)
        tqdm

# Generated at 2022-06-18 11:56:02.801091
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        tqdm_notebook.update()


# Generated at 2022-06-18 11:56:12.170060
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase

    class TestTqdmNotebookDisplay(TestCase):
        def test_display(self):
            from io import StringIO
            from contextlib import redirect_stdout

            with StringIO() as buf, redirect_stdout(buf):
                with tqdm_notebook(total=10) as pbar:
                    pbar.display(msg='test')
                    pbar.display(msg='test2')
                    pbar.display(msg='test3')
                    pbar.display(msg='test4')
                    pbar.display(msg='test5')
                    pbar.display(msg='test6')
                    pbar.display(msg='test7')
                    pbar.display(msg='test8')
                    pbar.display(msg='test9')

# Generated at 2022-06-18 11:56:14.120760
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tnrange
    for _ in tnrange(2):
        pass
    for _ in tnrange(2):
        pass

# Generated at 2022-06-18 11:56:25.273779
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tnrange
    from time import sleep
    for i in tnrange(5):
        sleep(0.1)
    tnrange(5).reset()
    for i in tnrange(5):
        sleep(0.1)
    tnrange(5).reset(total=10)
    for i in tnrange(10):
        sleep(0.1)
    tnrange(5).reset(total=10)
    for i in tnrange(10):
        sleep(0.1)
    tnrange(5).reset(total=10)
    for i in tnrange(10):
        sleep(0.1)
    tnrange(5).reset(total=10)
    for i in tnrange(10):
        sleep(0.1)
    tn

# Generated at 2022-06-18 11:56:29.806062
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from IPython.display import display
    from IPython.display import clear_output
    from IPython.display import HTML
    from IPython.display import Javascript
    from IPython.display import Image
    from IPython.display import SVG
    from IPython.display import Latex
    from IPython.display import Math
    from IPython.display import Markdown
    from IPython.display import Pretty
    from IPython.display import Video
    from IPython.display import Audio
    from IPython.display import FileLink
    from IPython.display import FileLinks
    from IPython.display import File
    from IPython.display import IFrame
    from IPython.display import YouTubeVideo
    from IPython.display import VimeoVideo

# Generated at 2022-06-18 11:56:40.082492
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    from time import sleep
    from IPython.display import clear_output
    from IPython.core.display import display
    from IPython.core.display import HTML
    from IPython.core.display import Javascript
    from IPython.core.display import SVG
    from IPython.core.display import Image
    from IPython.core.display import YouTubeVideo
    from IPython.core.display import Audio
    from IPython.core.display import Latex
    from IPython.core.display import Math
    from IPython.core.display import FileLink
    from IPython.core.display import FileLinks
    from IPython.core.display import Link
    from IPython.core.display import IFrame
    from IPython.core.display import display_html