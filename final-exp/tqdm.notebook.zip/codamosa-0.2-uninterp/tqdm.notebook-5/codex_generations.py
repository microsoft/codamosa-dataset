

# Generated at 2022-06-18 11:49:57.569273
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test method status_printer of class tqdm_notebook
    """
    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[1].layout.width == '100%'

    # Test without total
    pbar = tqdm_notebook.status_printer(None)
    assert isinstance(pbar, TqdmHBox)
    assert pbar.children[1].max == 1
    assert pbar.children[1].value == 1

# Generated at 2022-06-18 11:50:07.978637
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test 1: no error
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test 2: error
    try:
        with tqdm(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
                raise Exception
    except Exception:
        pass

    # Test 3: KeyboardInterrupt

# Generated at 2022-06-18 11:50:12.386399
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm
    from time import sleep
    with tqdm(total=10) as t:
        for i in t:
            sleep(0.01)
            if i == 5:
                raise Exception("Test exception")


# Generated at 2022-06-18 11:50:24.010110
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests the method `status_printer` of class `tqdm_notebook`
    """
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.gui import tqdm as gui_tqdm
    from tqdm.std import tqdm as std_tqdm
    from tqdm.notebook import tqdm as notebook_tqdm
    from tqdm.contrib import tqdm as contrib_tqdm

    # Test with a tqdm instance
    t = notebook_tqdm(total=100)
    t.status_printer(t.fp, total=100, desc="test", ncols=None)
    t.status_printer(t.fp, total=100, desc="test", ncols=100)
   

# Generated at 2022-06-18 11:50:33.296243
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tnrange
    from time import sleep
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
            if j == 5:
                break
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
            if j == 95:
                raise Exception()

# Generated at 2022-06-18 11:50:44.976490
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01)
                if k == 50:
                    break

# Generated at 2022-06-18 11:50:57.066666
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm import _tqdm_notebook
    from tqdm import tqdm as std_tqdm
    from tqdm import trange as std_trange
    from tqdm import tnrange as std_tnrange

    # Test tqdm_notebook constructor
    assert isinstance(tqdm_notebook(range(3)), _tqdm_notebook)
    assert isinstance(tqdm_notebook(range(3), file=sys.stdout), _tqdm_notebook)
    assert isinstance(tqdm_notebook(range(3), file=sys.stderr), _tqdm_notebook)
    assert isinstance(tqdm_notebook(range(3), file=None), _tqdm_notebook)

# Generated at 2022-06-18 11:51:06.337390
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(3), desc='2nd loop', leave=False):
            for k in tqdm(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(3), desc='2nd loop', leave=False):
            for k in tqdm(range(3), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:51:09.556802
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)


# Generated at 2022-06-18 11:51:19.522499
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_widget
    from IPython.html.widgets import ContainerWidget as HBox_widget
    from IPython.html.widgets import FloatProgressWidget as IProgress_widget

    # Test with IPython 4.x
    IPY = 4
    ipywidgets = __import__('ipywidgets')
    HTML = HTML_widget
    HBox = HBox_widget
    IProgress = IProgress_widget

    # Test with IPython 3.x
    IPY = 3
    ipywidgets = __import__('IPython.html.widgets')
    HTML = HTML_widget
    HBox = HBox_widget
    IProgress

# Generated at 2022-06-18 11:51:36.313676
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")
        if i == 6:
            break


# Generated at 2022-06-18 11:51:43.784360
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    try:
        from IPython.display import clear_output
    except ImportError:
        pass
    else:
        clear_output()
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()
    time.sleep(0.5)
    try:
        from IPython.display import clear_output
    except ImportError:
        pass
    else:
        clear_output()



# Generated at 2022-06-18 11:51:55.288826
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep

    # Test 1: no error
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()

    # Test 2: error
    try:
        with tqdm_notebook(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
                if i == 5:
                    raise ValueError
    except ValueError:
        pass
    clear_output()

    # Test 3: KeyboardInterrupt

# Generated at 2022-06-18 11:52:08.452904
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:52:17.303664
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.notebook import tqdm as tqdm_notebook
    from tqdm.std import tqdm as tqdm_std

    for tqdm_cls in [tqdm_auto, tqdm_notebook, tqdm_std]:
        with tqdm_cls(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()



# Generated at 2022-06-18 11:52:28.101190
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import array
    from numpy.random import randint
    from numpy.testing import assert_array_equal

    # Test iterable
    for i in tqdm_notebook(range(10)):
        sleep(0.01 * random())

    # Test iterator
    for i in tqdm_notebook(iter(range(10))):
        sleep(0.01 * random())

    # Test generator
    def gen():
        for i in range(10):
            yield i
            sleep(0.01 * random())
    for i in tqdm_notebook(gen()):
        pass

    # Test generator with exception
    def gen():
        for i in range(10):
            yield i
            sleep(0.01 * random())

# Generated at 2022-06-18 11:52:38.448893
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase
    from unittest.mock import patch

    class TestTqdmNotebookStatusPrinter(TestCase):
        def test_status_printer(self):
            # Test with total
            with patch('tqdm.notebook.display') as mock_display:
                tqdm_notebook.status_printer(None, total=10)
                mock_display.assert_called_once()
            # Test without total
            with patch('tqdm.notebook.display') as mock_display:
                tqdm_notebook.status_printer(None)
                mock_display.assert_called_once()

    TestTqdmNotebookStatusPrinter().test_status_printer()



# Generated at 2022-06-18 11:52:48.591978
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01)
                if k == 50:
                    raise Exception

# Generated at 2022-06-18 11:52:52.296979
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")


# Generated at 2022-06-18 11:53:03.013681
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook
    """
    from time import sleep
    from tqdm import tqdm_notebook as tqdm

    # Test with manual tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    # Test with iterable tqdm
    for i in tqdm(range(10)):
        sleep(0.1)

    # Test with iterable tqdm and error
    try:
        for i in tqdm(range(10)):
            sleep(0.1)
            raise Exception
    except Exception:
        pass

    # Test with iterable tqdm and KeyboardInterrupt

# Generated at 2022-06-18 11:53:38.865666
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm._utils import _term_move_up
    from tqdm._utils import _unicode

    # Test 1
    # Test display() with msg=''
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.display('')
            sleep(0.1)

    # Test 2
    # Test display() with msg=None
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.display()
            sleep(0.1)

    # Test 3
    # Test display() with msg='custom message'

# Generated at 2022-06-18 11:53:48.191563
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test method __repr__ of class TqdmHBox
    """
    # Test with pretty=False
    hbox = TqdmHBox()
    hbox.pbar = tqdm_notebook(total=10)
    assert hbox.__repr__() == hbox.__repr__(pretty=False)
    assert hbox.__repr__() == hbox.__repr__(pretty=True)
    assert hbox.__repr__() == hbox.__repr__(pretty=None)
    assert hbox.__repr__() == hbox.__repr__(pretty=1)
    assert hbox.__repr__() == hbox.__repr__(pretty=0)

# Generated at 2022-06-18 11:53:57.349272
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    import sys
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        tqdm_notebook.status_printer(sys.stdout, total=10, desc='test')
    assert out.getvalue()

# Generated at 2022-06-18 11:54:04.997195
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
        trange(3).reset()
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
        trange(3).reset(total=4)
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=True):
            sleep(0.01)
        trange(3).reset(total=5)

# Generated at 2022-06-18 11:54:11.559725
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=True):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:54:16.871029
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(3, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)
        trange(100, desc='2nd loop').reset()
    trange(3, desc='1st loop').reset()


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:54:24.709941
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm as tqdm_auto

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, pos=i)
    # Test display with bar_style
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.display(i, pos=i, bar_style='success')
    # Test display with bar_style and msg

# Generated at 2022-06-18 11:54:27.353333
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()


# Generated at 2022-06-18 11:54:34.941326
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm
    from .std import TMonitor

    # Test with a total
    pbar = tqdm_notebook.status_printer(None, 10, "test")
    assert pbar.children[0].value == "test"
    assert pbar.children[1].value == 0
    assert pbar.children[2].value == ""
    assert pbar.children[1].max == 10

    # Test without a total
    pbar = tqdm_notebook.status_printer(None, None, "test")
    assert pbar.children[0].value == "test"

# Generated at 2022-06-18 11:54:44.921966
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    from sys import stderr
    from os import devnull

    # Test bar display
    with open(devnull, 'w') as f:
        for i in tqdm(range(3), file=f, leave=False):
            sleep(.1)

    # Test bar update
    with open(devnull, 'w') as f:
        pbar = tqdm(range(3), file=f, leave=False)
        for i in pbar:
            sleep(.1)
            pbar.set_description("testing")
            pbar.set_postfix(ordered_dict=dict(a=1, b=2))

    # Test bar close
    with open(devnull, 'w') as f:
        p

# Generated at 2022-06-18 11:55:19.579376
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(5), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(0.01)
        tqdm_notebook.reset()
        assert tqdm_notebook.n == 0
        assert tqdm_notebook.last_print_n == 0
        assert tqdm_notebook.dynamic_ncols
        assert tqdm_notebook.ncols is None
        assert tqdm_notebook.total is None
        assert tqdm_notebook.unit_scale is True
        assert tqdm_notebook.unit == ''
        assert tqdm_notebook.desc == '1st loop'

# Generated at 2022-06-18 11:55:30.515569
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _term_move_up

    # Test tqdm_notebook.display()
    for cls in (tqdm, tqdm_notebook):
        with cls(total=10, leave=True) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.display(str(i))
        assert pbar.n == 10
        assert pbar.last_print_n == 10
        assert pbar.last_print_t == pbar.n
        assert pbar.dynamic_mess == str(pbar.n)

# Generated at 2022-06-18 11:55:39.987166
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_
    from IPython.html.widgets import ContainerWidget as HBox_
    from IPython.html.widgets import FloatProgressWidget as FloatProgress_

    # Test with IPython 2.x
    if IPY == 2:
        assert tqdm_notebook.status_printer(None, total=10) == \
            HBox_(children=[HTML_(), FloatProgress_(min=0, max=10), HTML_()])

    # Test with IPython 3.x

# Generated at 2022-06-18 11:55:48.656701
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.notebook import tqdm as tqdm_notebook
    for tqdm_cls in [tqdm_auto, tqdm_notebook]:
        with tqdm_cls(total=10) as pbar:
            for i in range(10):
                sleep(0.1)
                pbar.update()
            pbar.clear()
            pbar.write('cleared')
            pbar.close()

if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-18 11:55:51.968205
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook as tqdm
    from time import sleep
    for i in tqdm(range(10)):
        sleep(0.1)
        if i == 5:
            tqdm.clear()


# Generated at 2022-06-18 11:56:01.752957
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test with total
    pbar = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.children[1], IProgress)
    assert pbar.children[1].max == 100
    assert pbar.children[1].value == 0
    assert pbar.children[1].bar_style == ''
    assert pbar.children[1].layout.width == '100%'
    assert pbar.children[1].layout.flex == '2'
    assert pbar.children[1].layout.display

# Generated at 2022-06-18 11:56:11.295893
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook
    """
    # Test with total
    tqdm_notebook.status_printer(None, total=10)
    # Test without total
    tqdm_notebook.status_printer(None)
    # Test with description
    tqdm_notebook.status_printer(None, desc="Description")
    # Test with ncols
    tqdm_notebook.status_printer(None, ncols=100)
    # Test with ncols as string
    tqdm_notebook.status_printer(None, ncols="100px")
    # Test with ncols as string
    tqdm_notebook.status_printer(None, ncols="100%")
    # Test with ncol

# Generated at 2022-06-18 11:56:13.179020
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(.1)


# Generated at 2022-06-18 11:56:16.153928
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()



# Generated at 2022-06-18 11:56:19.632282
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        sleep(0.1)
        tqdm.update()


# Generated at 2022-06-18 11:56:53.195007
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tnrange
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.reset()
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.reset(total=100)
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.reset(total=100, leave=True)

# Generated at 2022-06-18 11:57:00.585353
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    try:
        from ipywidgets import IntProgress
    except ImportError:
        return
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(100), desc='2nd loop'):
            sleep(random() / 100.)
        if random() < .5:
            break
    for _ in tqdm_notebook(range(10), desc='3rd loop'):
        for _ in tqdm_notebook(range(5), desc='4th loop'):
            sleep(random() / 100.)
        if random() < .2:
            break

# Generated at 2022-06-18 11:57:10.040876
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import trange
    from tqdm.notebook import tqdm_notebook
    from tqdm.utils import _term_move_up

    # Test default bar
    with tqdm_notebook(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.update()
    # Test bar with no total
    with tqdm_notebook(total=None) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.update()
    # Test bar with no total and no progress tqdm status

# Generated at 2022-06-18 11:57:13.326960
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)


# Generated at 2022-06-18 11:57:23.253105
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook.
    """
    from time import sleep
    from sys import version_info
    from random import random

    # Test with tqdm_notebook(...) as t:
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(random() / 2)
            t.update()

    # Test with tqdm_notebook(...) as t:
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(random() / 2)
            t.update(1)

    # Test with tqdm_notebook(...) as t:

# Generated at 2022-06-18 11:57:29.079017
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm.auto import tqdm
    for i in tqdm(range(10), desc='1st loop'):
        sleep(0.01)
    for i in tqdm(range(5), desc='2nd loop'):
        sleep(0.01)
        if i == 2:
            tqdm.clear()
    for i in tqdm(range(10), desc='3rd loop'):
        sleep(0.01)

# Generated at 2022-06-18 11:57:40.149026
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std

    # Test tqdm_notebook.close()
    for tqdm_cls in (tqdm_notebook, tqdm_gui, tqdm_std):
        # Test no error
        t = tqdm_cls(total=10)
        for i in t:
            if i == 5:
                break
        t.close()
        # Test error
        t = tqdm_cls(total=10)
        for i in t:
            if i == 5:
                raise Exception
        try:
            t.close()
        except Exception:
            pass
        # Test leave=True
        t = tqdm_cls(total=10, leave=True)


# Generated at 2022-06-18 11:57:43.896698
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(0.1)
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-18 11:57:49.321157
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[-2].value == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].bar_style == 'success'



# Generated at 2022-06-18 11:57:57.268790
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm.contrib.concurrent import process_map
    from tqdm.contrib.concurrent import thread_map
    from tqdm.contrib.concurrent import thread_map_reduce
    from tqdm.contrib.concurrent import process_map_reduce
    from tqdm.contrib.concurrent import thread_map_reduce_bar
    from tqdm.contrib.concurrent import process_map_reduce_bar
    from tqdm.contrib.concurrent import thread_map_bar
    from tqdm.contrib.concurrent import process_map_bar
    from tqdm.contrib.concurrent import thread_map_unordered

# Generated at 2022-06-18 11:58:39.242672
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise ValueError("Error")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt("Error")

# Generated at 2022-06-18 11:58:41.329896
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:58:49.759238
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm._tqdm_notebook import tqdm_notebook_display as display

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
    clear_output()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            display(pbar)
    clear_output()
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            display(pbar, pos=i)
    clear_

# Generated at 2022-06-18 11:58:51.497887
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


# Generated at 2022-06-18 11:59:01.010877
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    from tqdm.notebook import tqdm_notebook
    from tqdm.notebook import IProgress
    from tqdm.notebook import HTML
    from tqdm.notebook import HBox

    # Create a TqdmHBox object
    pbar = IProgress(min=0, max=1)
    pbar.value = 1
    pbar.bar_style = 'info'
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])

    # Test the __repr__ method
    assert repr(container) == '\n'

    # Create a tqdm_notebook object
    pbar = tqdm_notebook(total=1)
   

# Generated at 2022-06-18 11:59:04.194893
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:59:12.486064
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .gui import tqdm as tqdm_gui
    from .gui import tgrange as tgrange_gui
    from .gui import tnrange as tnrange_gui
    from .gui import trange as trange_gui
    from .gui import tqdm_gui as tqdm_gui_gui
    from .gui import tgrange_gui as tgrange_gui_gui
    from .gui import tnrange_gui as tnrange_gui_gui
    from .gui import trange_gui as trange_gui_gui
    from .gui import tqdm_notebook as tqdm_notebook_gui
    from .gui import tgrange as tgrange_notebook
    from .gui import t

# Generated at 2022-06-18 11:59:19.120778
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    from IPython.display import clear_output
    from time import sleep

    # Test display
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.display(i)
    t.close()

    # Test display with msg
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.display(i, msg="test")
    t.close()

    # Test display with msg and bar_style
    t = tqdm(total=10)
    for i in range(10):
        sleep(0.1)
        t.display(i, msg="test", bar_style="success")
    t.close()

# Generated at 2022-06-18 11:59:24.059009
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise Exception("Test exception")
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt("Test KeyboardInterrupt")


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-18 11:59:31.707392
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .utils import _term_move_up
    from .std import tqdm as std_tqdm

    # Test the method status_printer of class tqdm_notebook
    # with the default parameters
    container = tqdm_notebook.status_printer(sys.stdout)
    assert isinstance(container, TqdmHBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[0].value == ''
    assert container.children[1].value == 0