

# Generated at 2022-06-18 11:50:05.364766
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(5)):
        sleep(0.1)


# Generated at 2022-06-18 11:50:16.920266
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import trange
    from tqdm.utils import _term_move_up
    from tqdm.contrib.concurrent import process_map

    try:
        from ipywidgets import IntProgress
    except ImportError:
        return

    def test_display(bar):
        bar.display()
        sleep(0.1)
        bar.display(bar_style='success')
        sleep(0.1)
        bar.display(bar_style='danger')
        sleep(0.1)
        bar.display(bar_style='info')
        sleep(0.1)
        bar.display(bar_style='warning')
        sleep(0.1)
        bar.display(bar_style='danger')
        sleep(0.1)

# Generated at 2022-06-18 11:50:20.360654
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)


# Generated at 2022-06-18 11:50:26.230071
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    for i in trange(3):
        sleep(0.1)
        if i == 1:
            trange.reset(total=10)
            for j in trange():
                sleep(0.1)
                if j == 5:
                    break

if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:50:35.361983
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop'):
            for k in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(3), desc='2nd loop'):
            for k in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-18 11:50:46.995768
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm.auto import tqdm
    from tqdm.contrib.concurrent import process_map

    # Test display of a single bar
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
    clear_output()

    # Test display of multiple bars
    with tqdm(total=10) as pbar:
        for i in process_map(lambda x: x**2, range(10)):
            pbar.update()
            sleep(0.1)
    clear_output()

    # Test display of a single bar with error

# Generated at 2022-06-18 11:50:58.975301
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert len(container.children) == 3
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].max == 10
    assert container.children[1].min == 0
    assert container.children[1].value == 0
    assert container.children[1].bar_style == ''
    assert container.children[1].layout.width == '100%'
    assert container.children[0].value == ''


# Generated at 2022-06-18 11:51:01.493508
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10)):
        sleep(random())


# Generated at 2022-06-18 11:51:11.336096
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import tqdm
    from tqdm.utils import _supports_unicode
    from tqdm._tqdm import format_meter
    from tqdm.auto import tqdm as auto_tqdm
    from tqdm.std import tqdm as std_tqdm

    # Test with tqdm_notebook
    t = tqdm(total=10)
    assert repr(t.container) == format_meter(**t.format_dict)
    t.close()

    # Test with tqdm_notebook and pretty=True
    t = tqdm(total=10)
    assert t.container._repr_pretty_(None) == format_meter(**t.format_dict)
    t.close()

    # Test with tqdm_notebook and pretty

# Generated at 2022-06-18 11:51:14.182021
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        for i in pbar:
            sleep(0.1)


# Generated at 2022-06-18 11:51:32.311356
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for _ in tqdm_notebook(range(3)):
        sleep(0.1)


# Generated at 2022-06-18 11:51:43.415109
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import tqdm

    # Test with a manual tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.5)
            pbar.update()

    # Test with a tqdm_notebook
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.5)
            pbar.update()

    # Test with a manual tqdm and an exception
    try:
        with tqdm(total=10) as pbar:
            for i in range(10):
                sleep(0.5)
                pbar.update()
                raise Exception
    except Exception:
        pass

    # Test with a tqdm_note

# Generated at 2022-06-18 11:51:54.923518
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm.auto import tqdm

    with tqdm(total=1, leave=True) as t:
        sleep(0.1)
        t.close()
        t.close()

    with tqdm(total=1, leave=True) as t:
        sleep(0.1)
        t.close()
        t.close()

    with tqdm(total=1, leave=False) as t:
        sleep(0.1)
        t.close()
        t.close()

    with tqdm(total=1, leave=False) as t:
        sleep(0.1)
        t.close()
        t.close()

    with tqdm(total=1, leave=True) as t:
        sleep(0.1)

# Generated at 2022-06-18 11:52:08.101344
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[1].max == 10
    assert container.children[1].value == 0
    assert container.children[1].bar_style == ''
    assert container.children[1].layout.width == "20px"
    assert container.layout.width == "100%"
    assert container.layout.display == 'inline-flex'
    assert container.layout.flex_flow

# Generated at 2022-06-18 11:52:19.937745
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10
    assert t.total == 10
    assert t.container.children[-2].value == 10
    assert t.container.children[-2].max == 10
    assert t.container.children[-2].bar_style == 'success'

    with tqdm_notebook(total=10) as t:
        for i in range(5):
            t.update()
    assert t.n == 5
    assert t.total == 10
    assert t.container.children[-2].value == 5
    assert t.container.children[-2].max == 10

# Generated at 2022-06-18 11:52:30.804059
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as HTML_
    from IPython.html.widgets import ContainerWidget as HBox_
    from IPython.html.widgets import FloatProgressWidget as IProgress_

    # Test with IPython 4.x
    IPY = 4
    ipywidgets = __import__('ipywidgets')
    HTML = HTML_
    HBox = HBox_
    IProgress = IProgress_
    display = __import__('IPython.display').display

    # Test with IPython 3.x
    IPY = 3
    ipywidgets = __import__('IPython.html.widgets')
    HTML = HTML_


# Generated at 2022-06-18 11:52:42.151629
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tnrange

    # Test tqdm_notebook.update()
    for i in tqdm(range(10), desc='1st loop'):
        sleep(.1)
    for i in tqdm(range(5), desc='2nd loop'):
        sleep(.1)
    tqdm.close()

    # Test tqdm_notebook.tnrange()
    for i in tnrange(10, desc='1st loop'):
        sleep(.1)
    for i in tnrange(5, desc='2nd loop'):
        sleep(.1)
    tqdm.close()

    # Test tqdm_notebook.

# Generated at 2022-06-18 11:52:50.692719
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01 * random())
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=True):
            for k in tqdm_notebook(range(100), desc='3nd loop'):
                sleep(0.01 * random())

# Generated at 2022-06-18 11:53:01.215808
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    from .std import tqdm as std_tqdm
    from .std import TqdmTypeError
    from .std import TqdmKeyError

    # Test the method status_printer of class tqdm_notebook
    # with a total
    container = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(container, TqdmHBox)
    assert isinstance(container.children[1], IProgress)
    assert container.children[1].max == 10

    # Test the method status_printer of class tqdm_notebook
    # without a total
    container = tqdm_notebook.status_printer(None)

# Generated at 2022-06-18 11:53:05.005742
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=100) as pbar:
        for i in pbar:
            sleep(0.01)
            pbar.set_description("Processing %i" % i)


# Generated at 2022-06-18 11:53:27.182245
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy import array

    # Test iterable
    for _ in tqdm_notebook(range(10)):
        sleep(random())

    # Test iterable with total
    for _ in tqdm_notebook(range(10), total=10):
        sleep(random())

    # Test iterable with total=None
    for _ in tqdm_notebook(range(10), total=None):
        sleep(random())

    # Test iterable with total=None and leave=True
    for _ in tqdm_notebook(range(10), total=None, leave=True):
        sleep(random())

    # Test iterable with total=None and leave=True and dynamic_ncols=True

# Generated at 2022-06-18 11:53:34.523757
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            break
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise ValueError()
    for i in tqdm_notebook(range(10)):
        sleep(0.1)
        if i == 5:
            raise KeyboardInterrupt()

# Generated at 2022-06-18 11:53:44.110574
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    # Test with manual tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.display(i)
            sleep(0.1)

    # Test with trange
    for i in trange(10, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.1)

    # Test with trange and error

# Generated at 2022-06-18 11:53:51.962769
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    from unittest import TestCase
    from unittest import main

    class TestTqdmNotebookStatusPrinter(TestCase):
        """
        Unit test for method status_printer of class tqdm_notebook.
        """
        def test_tqdm_notebook_status_printer(self):
            """
            Test method status_printer of class tqdm_notebook.
            """
            # Test with total = None
            tqdm_notebook_status_printer = tqdm_notebook.status_printer(
                file=sys.stdout, total=None, desc='desc', ncols=None)

# Generated at 2022-06-18 11:53:58.728143
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)
    for i in tqdm(range(5), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(5), desc='3nd loop', leave=False):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-18 11:54:05.261867
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    from time import sleep
    from random import random

    # Test with tqdm_notebook
    with tqdm(total=10, desc='test', leave=False) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

    # Test with tqdm
    with tqdm(total=10, desc='test', leave=False) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-18 11:54:08.602412
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    # Initialize tqdm_notebook
    tqdm_notebook.status_printer(None, total=10, desc='test', ncols=100)


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-18 11:54:11.807092
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(100), desc='3nd loop', leave=False):
                sleep(0.01)


# Generated at 2022-06-18 11:54:20.901678
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    with tqdm_notebook(total=10) as pbar:
        for i in trange(5, leave=False):
            sleep(0.5)
            pbar.update()
        pbar.set_description("testing...")
        for i in trange(5, leave=True):
            sleep(0.5)
            pbar.update()
        pbar.set_description("testing...done")
    print("\n" * pbar.n)  # move cursor down


# Generated at 2022-06-18 11:54:24.615058
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:54:44.509284
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    with tqdm_notebook(total=10) as t:
        for i in range(5):
            sleep(0.1)
            t.update()
        t.reset(total=20)
        for i in range(10):
            sleep(0.1)
            t.update()
        t.reset(total=0)
        for i in range(5):
            sleep(0.1)
            t.update()
        t.reset()
        for i in range(5):
            sleep(0.1)
            t.update()


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-18 11:54:47.570699
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()


# Generated at 2022-06-18 11:54:58.845650
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm.utils import _term_move_up
    from tqdm.auto import trange

    # Test display
    with tqdm(total=10) as pbar:
        for i in trange(10):
            sleep(0.1)
            pbar.display(str(i))
            pbar.display(str(i), pos=0)
            pbar.display(str(i), pos=1)
            pbar.display(str(i), pos=2)
            pbar.display(str(i), pos=3)
            pbar.display(str(i), pos=4)
            pbar.display(str(i), pos=5)

# Generated at 2022-06-18 11:55:01.721144
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import random
    from tqdm.notebook import tqdm

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(random())
            pbar.update()

# Generated at 2022-06-18 11:55:12.404341
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm._tqdm_notebook import tqdm_notebook_display as tqdm_display

    # Test display
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.display(msg='test')
            sleep(0.1)

    # Test display with bar_style
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.display(msg='test', bar_style='success')
            sleep(0.1)

    # Test display with close

# Generated at 2022-06-18 11:55:24.153722
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # Test with total
    container = tqdm_notebook.status_printer(None, total=10)
    assert container.children[0].value == ''
    assert container.children[1].value == 0
    assert container.children[2].value == ''
    assert container.children[1].max == 10
    assert container.children[1].bar_style == ''

    # Test without total
    container = tqdm_notebook.status_printer(None)
    assert container.children[0].value == ''
    assert container.children[1].value == 1
    assert container.children[2].value == ''
    assert container.children[1].max == 1

# Generated at 2022-06-18 11:55:34.178497
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm import trange
    from tqdm import tnrange
    from tqdm import TqdmSynchronisationWarning

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset()
        for i in range(10):
            sleep(0.1)
            pbar.update()

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()
        pbar.reset(total=20)
        for i in range(20):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-18 11:55:44.197476
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from numpy.random import randint
    from numpy import array
    from numpy import concatenate
    from numpy import allclose
    from numpy import ndarray
    from numpy import float64
    from numpy import int64
    from numpy import uint64
    from numpy import int32
    from numpy import uint32
    from numpy import int16
    from numpy import uint16
    from numpy import int8
    from numpy import uint8
    from numpy import bool_
    from numpy import bool
    from numpy import nan
    from numpy import inf
    from numpy import isinf
    from numpy import isnan
    from numpy import isneginf
    from numpy import isposinf
    from numpy import isfinite

# Generated at 2022-06-18 11:55:52.681865
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import tqdm_notebook as tqdm
    from tqdm._tqdm_notebook import tqdm_notebook_display as tqdm_display

    # Create a tqdm instance and display it
    t = tqdm(total=100)
    t.display()

    # Update the progress bar
    for i in range(10):
        sleep(0.1)
        t.update()

    # Clear the output and display the bar again
    clear_output()
    t.display()

    # Close the bar
    t.close()

    # Test the display method
    t = tqdm(total=100)
    tqdm_display(t)

    # Update the progress bar

# Generated at 2022-06-18 11:55:58.870975
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update()
    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[1].value == 10
    assert pbar.container.children[1].max == 10
    assert pbar.container.children[1].bar_style == 'success'

