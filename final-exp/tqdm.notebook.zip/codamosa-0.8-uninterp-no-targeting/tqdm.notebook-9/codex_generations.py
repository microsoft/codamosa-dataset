

# Generated at 2022-06-22 05:20:31.800026
# Unit test for function tnrange
def test_tnrange():
    """Test all functionality of tnrange"""
    import os
    import sys

    all_test_cases = (
        (0, 0),
        (0, None),
        (0, 100),
        (0, 10, 2),
        (0, 100, 10),
        (5, 10),
        (5, 10, 2)
    )
    for test_case in all_test_cases:
        # Create progressbar
        progressbar = tnrange(*test_case, leave=True, desc='Test')
        for i in progressbar:
            if i >= progressbar.total - 1:
                progressbar.reset(total=None)
                progressbar.close()
                break


# Test tqdm_notebook
if __name__ == "__main__":
    test_tnrange()
    # Test t

# Generated at 2022-06-22 05:20:38.482618
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from qtconsole.rich_jupyter_widget import RichJupyterWidget
    from qtconsole import qt_widget
    from qtconsole.rich_ipython_widget import RichIPythonWidget
    from qtconsole.inprocess import QtInProcessKernelManager
    from jupyter_core.application import JupyterApp
    from IPython.terminal.ipapp import load_default_config
    from IPython.terminal.ptinprocess import TerminalIPythonApp
    # import IPython.html.base.handlers as handlers

    # ipy3
    _custom_app_class = 'IPython.html.widgets.frontend_app.FrontendApp'
    app = load_default_config()

# Generated at 2022-06-22 05:20:48.320514
# Unit test for function tnrange
def test_tnrange():
    from random import shuffle
    from time import sleep
    from operator import add

    for _ in tnrange(4, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop', leave=True):
            for _ in tnrange(50, desc='3nd loop', leave=True, unit='it'):
                sleep(0.01)
        shuffle(range(100))

    with tnrange(8, desc='Load images') as t:
        for i in map(add, t, range(8)):
            sleep(0.1)


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-22 05:20:59.002785
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = TqdmHBox(children=[HTML("l"), IProgress(min=0, max=1), HTML("r")])
    pbar.pbar = pbar.children[1]  # pbar.pbar is needed inside pbar.__repr__
    d = {
        'n': 0,
        'total': None,
        'unit': 'it',
        'unit_scale': False,
        'desc': '',
        'dynamic_ncols': False,
    }
    assert pbar.__repr__() == pbar.__repr__(False) == pbar.format_meter(
        **d) == pbar.format_meter(**d, ascii=False)
    assert pbar._repr_json_() == d

# Generated at 2022-06-22 05:21:11.377742
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    """
    Unit test for the function tnrange
    """
    from nose.tools import assert_equal, assert_almost_equal
    from random import random

    from .std import format_interval
    from .utils import format_sizeof
    duration = 0.01

    for i in trange(10):
        assert_equal(i, i)
        sleep(duration)

    for i in trange(10, 20):
        assert_equal(i, i)
        sleep(duration)

    for i in trange(10, 20, 2):
        assert_equal(i, i)
        sleep(duration)

    for i in trange(20, 10, -2):
        assert_equal(i, i)
        sleep(duration)

    sum_ = 0

# Generated at 2022-06-22 05:21:15.890591
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=4) as pbar:
        for i in _range(4):
            pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-22 05:21:25.618043
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit tests for method `close` of class `tqdm_notebook`.
    """
    try:
        from unittest.mock import Mock
    except ImportError:  # Python < 3.3
        from mock import Mock

    for manual in [False, True]:
        for leave in [False, True]:
            bar = tqdm_notebook(total=10, leave=leave, manual=manual)
            for i in range(5):
                bar.update()
            bar.close()
            assert bar.container.children[-2].bar_style == ''

            bar = tqdm_notebook(total=10, leave=leave, manual=manual)
            for i in range(5):
                bar.update()
            try:
                raise ValueError
            except ValueError:
                bar.close

# Generated at 2022-06-22 05:21:34.069988
# Unit test for function tnrange
def test_tnrange():
    """Test function tnrange"""
    import sys

    if sys.version_info[0] < 3:
        assert list(tnrange(3)) == [0, 1, 2]
    else:
        assert list(tnrange(3)) == [0, 1, 2]

    with tqdm(total=3, leave=True) as t:
        assert list(tnrange(3)) == [0, 1, 2]
        t.update()  # try reset (already finished)



# Generated at 2022-06-22 05:21:36.663141
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in range(100):
        t = tnrange(1000)
        for j in range(1000):
            t.update()


# Generated at 2022-06-22 05:21:48.898351
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from sys import stdout
    # As it is an external widget, we need to pass a `progress_bar` value
    test = TqdmHBox(pbar=tqdm_notebook(
        ["a", "b", "c", "d"], file=StringIO(), leave=False, gui=True))
    assert repr(test) == test.__repr__(False) == test.__repr__(True) == \
        repr(test.pbar)  # Catch typos

    # Test style/formatting without HTML color
    test.colour = None
    assert repr(test) == test.__repr__(False) == test.__repr__(True) == \
        repr(test.pbar)  # Catch typos

    # Test style/formatting with HTML color
    test

# Generated at 2022-06-22 05:22:06.675639
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tqdm as _tqdm
    from time import sleep as _sleep

    total = 10
    for j in _tqdm(
            _range(total),
            desc="Test",
            leave=True,
            unit='step',
            unit_scale=True,
            mininterval=0.01,
    ):
        # to test the difference between manual and automatic updates
        if j == 2:
            for k in _range(2):
                _tqdm.update(total - j)
                _sleep(0.001)  # avoid 0
        _sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:22:18.356513
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from numpy.random import random as rand

    try:
        from IPython import get_ipython
        ip = get_ipython()
    except ImportError:
        return

    try:
        ip.magic("matplotlib inline")
    except AttributeError:
        pass

    t = tqdm_notebook(rand(5))
    assert TqdmHBox()._repr_json_() == {}
    assert isinstance(t.container, TqdmHBox)
    assert repr(t.container).endswith("| 0.00/5.00 [00:00<?, ?it/s]")
    t.close()
    t = tqdm_notebook(rand(5))
    assert isinstance(t.container, TqdmHBox)

# Generated at 2022-06-22 05:22:25.389717
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    list_of_datapoints = range(100)
    t = tqdm(list_of_datapoints)
    t.clear()


if __name__ == "__main__":
    import time
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
        for i in range(10):
            pbar.update()
            time.sleep(0.1)

# Generated at 2022-06-22 05:22:30.775078
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    for total in [None, 100]:
        bar = tqdm(total=total)
        for i in bar:
            sleep(0.01)
            if i == 10:
                bar.reset(total=10)
                assert bar.total == 10
            elif i > 10:
                break
        assert bar.n == 11
        bar.close()



# Generated at 2022-06-22 05:22:35.587503
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Check that `file` argument of tqdm_notebook is ignored
    # (avoid FutureWarnings coming from tqdm and ipywidgets)
    tnrange(1, file=None, leave=True)
    tnrange(1, file=sys.stderr, leave=True)
    tnrange(1, file=sys.stdout, leave=True)

# Generated at 2022-06-22 05:22:46.900982
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for the function tqdm_notebook.status_printer.
    """
    c = tqdm_notebook.status_printer(sys.stdout, 100, "desc", 50)
    # Test HTML object and pbar object
    assert isinstance(c, HBox)
    if IPY == 32:
        assert isinstance(c.children[-2], FloatProgressWidget)
    else:
        assert isinstance(c.children[-2], FloatProgress)
    # Test unicode and escaping
    c = tqdm_notebook.status_printer(sys.stdout, 100, "&", 50)
    assert c.children[0].value == "&amp;"
    # Test no total

# Generated at 2022-06-22 05:22:53.229599
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .std import tqdm as std_tqdm
    for n in range(2):  # test twice to make sure it's idempotent
        try:
            pbar = tqdm_notebook(total=1, leave=True)
            pbar.close()
        except:  # NOQA
            pbar = std_tqdm(total=1, leave=True)
            pbar.close()

# Generated at 2022-06-22 05:22:56.293982
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from unittest import TestCase
    assert hasattr(TqdmHBox([]), "close")

# Generated at 2022-06-22 05:23:06.597664
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from io import StringIO
    from subprocess import Popen, PIPE

    python_version_str = '.'.join(str(v) for v in sys.version_info[0:3])
    output = Popen(
        [sys.executable, '-c',
         str('import sys\n'
             'from tqdm import tqdm_notebook as t\n'
             'pbar = t(10)\n'
             'pbar.clear()\n'
             'sys.stderr.write("Done\\n")')],
        bufsize=1, stdout=PIPE, stderr=PIPE).communicate()[1]
    assert b'Done\n' == output


# Test if importing works

# Generated at 2022-06-22 05:23:09.848542
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange.
    """
    from .gui import tnrange_test  # NOQA
    tnrange_test(tnrange)

# Generated at 2022-06-22 05:23:36.674714
# Unit test for function tnrange
def test_tnrange():
    """Test tnrange"""
    try:
        import numpy as np  # NOQA
    except ImportError:
        np = None

    with tqdm(total=5) as pbar:
        for i in tnrange(pbar.total):
            pbar.update(1)

    with tqdm(total=5) as pbar:
        for i in tnrange(pbar.total, desc="One"):
            pbar.update(1)

    with tqdm(total=5) as pbar:
        for i in tnrange(pbar.total, desc="Two", leave=True):
            pbar.update(1)


# Generated at 2022-06-22 05:23:48.082103
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""
    from ipywidgets import Label
    import os
    import shutil
    import tempfile

    def get_container():
        """Return a `tqdm_notebook.status_printer` instance"""
        return tqdm_notebook.status_printer(sys.stderr, 42, '0123456789')

    # Test in ipython 4.0
    # Note: impossible to test on travis because travis uses old IPython
    if not (os.getenv('TRAVIS') == 'true' and sys.version_info[0] == 2):
        # Test file mode
        # On IPython 4.0, the widget is a HBox containing 3 Labels
        container = get_container()

# Generated at 2022-06-22 05:24:00.237513
# Unit test for function tnrange
def test_tnrange():
    """
    Just check that unit test don't crash with tnrange
    """

    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    def assert_raises_regex(*args, **kwargs):
        with pytest.raises(*args, **kwargs):
            yield

    with assert_raises_regex(ImportError, 'IProgress not found'):
        assert IPY == 0
        tnrange(1)
    with assert_raises_regex(ImportError, 'IProgress not found'):
        assert IPY == 2
        tnrange(1)
    with assert_raises_regex(ImportError, 'IProgress not found'):
        assert IPY == 3
        tnrange(1)

# Generated at 2022-06-22 05:24:11.943356
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import random
    import string
    total = random.randint(200, 400)

    tmp = _range(total)
    tmp2 = _range(total)
    for i in tqdm_notebook(tmp, desc='1st loop'):
        assert(i == tmp2[i])
        from time import sleep
        if i % 5 == 0:
            sleep(0.01)
            tmp.set_description('desc: %s' %
                                ''.join(random.choice(string.ascii_letters)
                                        for _ in range(25)))
    print("loop 2")
    for i in tqdm_notebook(tmp2, desc='2nd loop'):
        assert(i == tmp2[i])
        if i % 5 == 0:
            sleep(0.01)
            tmp.set

# Generated at 2022-06-22 05:24:15.156736
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    return repr(TqdmHBox(
        children=[HTML(), IProgress(max=10), HTML()],
        pbar=tqdm_notebook(total=10)))

# Generated at 2022-06-22 05:24:20.246636
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test clear method of class tqdm
    """
    # force use of the notebook bar
    with tqdm(total=1) as bar:
        bar.clear()
    # force use of the console bar
    with tqdm(total=1, dynamic_ncols=False) as bar:
        bar.clear()
    # force use of the notebook bar
    with tqdm(total=1, ncols=None) as bar:
        bar.clear()

# Generated at 2022-06-22 05:24:30.787278
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    from .tests.gui import skip_if_environ_not_set
    skip_if_environ_not_set("DISPLAY")
    from tqdm.auto import tqdm
    t = tqdm(["a", "b", "c", "d"], ncols=77, leave=False)
    try:
        for i in t:
            assert i in t.get_lock()._ignored_initargs["iterable"]
            assert set(t._sp(final=False).split("\r")[-1].split("  ")) ==\
                {"a", "b", "c", "d"}
            raise Exception("stop iteration")
    except Exception:
        pass

# Generated at 2022-06-22 05:24:41.350644
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.core.display import display
    from IPython.core.display import HTML
    from IPython.core.display import Javascript
    from IPython.display import IFrame
    from IPython.display import HTML


# Generated at 2022-06-22 05:24:52.868127
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(4), desc="1st loop", unit="iter"):
        for j in tqdm_notebook(range(15), desc="2nd loop", unit="it"):
            sleep(0.01)
        sleep(0.02)

    # Test with no total
    for i in tqdm_notebook(range(4), desc="1st loop", unit="iter"):
        for j in tqdm_notebook(range(15), desc="2nd loop", unit="it"):
            sleep(0.01)
        sleep(0.02)

    with tqdm_notebook(range(3)) as t:
        for i in t:
            t.set_description('A loop: {}'.format(i))

# Generated at 2022-06-22 05:24:55.623089
# Unit test for function tnrange
def test_tnrange():
    from time import sleep

    for _ in tnrange(4):
        sleep(1e-3)


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:25:18.362675
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from time import sleep
    from tqdm import tqdm_notebook as tn
    t = tn(total=100, leave=True, disable=False)
    for i in range(100):
        t.update()
        sleep(0.01)
    t.reset(total=10)
    for i in range(10):
        t.update()
        sleep(0.01)
    assert t.n == t.total


# Generated at 2022-06-22 05:25:20.741077
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in tqdm_notebook(range(10)):
        pass



# Generated at 2022-06-22 05:25:32.737075
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # First test without display
    with tqdm_notebook(total=1, unit='B', unit_scale=True, dynamic_ncols=False) as t:
        t.clear()
        t.clear(smoothing=0.5)
        t.start_t = t.last_print_t = t.start_t - t.dynamic_miniters * t.miniters
        t.clear(nolock=True)
        t.n = t.last_print_n = t.total
        t.clear(nolock=True, smoothing=0.5)

    # Second test with display
    with tqdm_notebook(total=1, unit='B', unit_scale=True, dynamic_ncols=False,
                       leave=True) as t:
        t.clear()

# Generated at 2022-06-22 05:25:36.236204
# Unit test for function tnrange
def test_tnrange():
    """Test of tnrange"""
    from time import sleep
    for i in tnrange(2, desc='1st loop'):
        for j in tnrange(2, desc='2nd loop', leave=True):
            sleep(0.01)
            assert i + j == 2

# Generated at 2022-06-22 05:25:46.808903
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    def status_printer_test(prog_bar, total, desc=None, ncols=None, **kwargs):
        return prog_bar.status_printer(
            None, total, desc, ncols, **kwargs)

    import IPython.display as display
    from unittest import TestCase


# Generated at 2022-06-22 05:25:49.204036
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    t = TqdmHBox()
    assert not t
    t.pbar = std_tqdm()
    assert t

# Generated at 2022-06-22 05:25:56.612499
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from IPython.lib import kernel
        kernel = kernel  # shut up pyflakes
    except ImportError:
        from IPython.kernel import kernelapp as kernel
    kernel.get_connection_file() is not None
    # Ctrl+C with short delay will break `display()`
    for i in tqdm_notebook(range(10), desc='test_tqdm_notebook_display'):
        time.sleep(.01)
        if i == 6:
            raise Exception("In test_tqdm_notebook_display()")

# Generated at 2022-06-22 05:26:07.276227
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    test_container = TqdmHBox()
    test_container.add_class('tqdm')
    assert test_container.__repr__() == 'TqdmHBox(children=(), layout=Layout(align_content=\'center\', align_items=\'center\', align_self=\'center\', border=\'solid\', flex=\'\', flex_flow=\'column\', justify_content=\'none\'))'
    assert test_container.__repr__(pretty=True) == 'TqdmHBox(children=(), layout=Layout(align_content=\'center\', align_items=\'center\', align_self=\'center\', border=\'solid\', flex=\'\', flex_flow=\'column\', justify_content=\'none\'))'
    assert test_container._repr_json_

# Generated at 2022-06-22 05:26:10.759536
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox(children='Some children')
    assert repr(hbox) == ''
    hbox.pbar = tqdm_notebook()
    assert repr(hbox) == '0it [00:00, ?it/s]'

# Generated at 2022-06-22 05:26:17.082953
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    tests the method clear of class tqdm_notebook
    """
    from tqdm import tqdm
    from time import sleep
    pbar = tqdm(total=100)
    # fill it a bit
    for i in range(50):
        pbar.update(i)
    pbar.clear()
    # then close
    pbar.close()

# Generated at 2022-06-22 05:26:51.034421
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Doesn't check bar rendering
    """
    import os
    if not os.isatty(sys.stdout.fileno()):
        return  # not in notebook
    from io import StringIO
    import sys
    from time import sleep
    from IPython.display import display

    s = StringIO()
    with std_tqdm(range(2), file=s) as pbar:
        pbar.display('')
        sleep(0.01)
        assert '\r   0/2' == s.getvalue()
        pbar.display(pos=1)
        sleep(0.01)
        assert '\r   1/2' in s.getvalue()
        pbar.display(pos=2)
        sleep(0.01)
        assert '\r   2/2' in s

# Generated at 2022-06-22 05:26:56.356743
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Test cases
    tc = [
        [True, True, True],
        [False, True, True],
        [True, False, False],
        [False, False, False]
    ]

    for test_case in tc:
        t = tqdm_notebook(
            total=10, leave=test_case[0], disable=test_case[1], ncols=100)
        t.close()
        assert t.container.children[-2].bar_style == ('success' if test_case[2] else "")

# Generated at 2022-06-22 05:27:03.559832
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('IPython.display.clear_output') as mock_display:
        with tqdm_notebook(total=100) as pbar:
            for i in range(100):
                pbar.update(2)
        mock_display.assert_called_once()


if __name__ == "__main__":
    from nose.tools import assert_equal
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:27:15.203304
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from collections import Counter

    tn = tqdm_notebook(desc="Counting", total=10, leave=False)
    for _ in tn:
        sleep(0.5)
    tn.reset(total=None)
    for _ in tn:
        sleep(0.5)
    tn.reset(total=10)
    for _ in tn:
        sleep(0.5)
    tn.reset(total=None)
    for _ in tn:
        sleep(0.5)

    tn2 = tqdm_notebook(desc="Counting", total=10, leave=False)
    for _ in tn2:
        sleep(0.5)
    tn2.reset(total=20)

# Generated at 2022-06-22 05:27:25.346823
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import display, clear_output
    from time import sleep
    t = tqdm_notebook(total=4)
    try:
        for i in range(6):
            if i < 4:
                t.update(1)
                sleep(0.01)
            else:
                clear_output()
                try:
                    t.display(msg='Error!', bar_style='danger')
                except ValueError:
                    sleep(0.01)
                t.close()
    except ValueError:
        sleep(0.01)
    clear_output()

if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:27:34.335892
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup tqdm_notebook with an unknown total
    import datetime
    with tqdm_notebook(total=None) as t:
        assert t.total is None
        # Do some iterations
        for i in range(10):
            t.update(1)
        # Sleep to generate some time difference between first use and
        # second use of tqdm_notebook
        time.sleep(0.1)
        # Reset tqdm_notebook and do new iterations
        for i in range(10, 20):
            t.reset(20)
            t.update(1)
        # Sleep again
        time.sleep(0.1)
        # Reset tqdm_notebook and do new iterations
        for i in range(20, 40):
            t.reset(40)
            t.update(1)


# Generated at 2022-06-22 05:27:36.538088
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    >>> from tqdm.notebook import tqdm as t
    >>> t(range(3)).update()
    """
    pass

# Generated at 2022-06-22 05:27:46.278671
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook([], desc="Desc", leave=True, ncols=100)

    # Test msg=None, just to make sure display doesn't crash
    t.display()

    # Test msg='' (base case) with no text
    t.display(msg='')
    # With text
    t.display(msg='Msg')

    # Test closing at the end
    t.close()

    # Test error
    t.display(bar_style='danger')

    # Test style changes
    t.display(bar_style='info')
    t.display(bar_style='success')

# Generated at 2022-06-22 05:27:55.190448
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Test _repr_json_
    assert TqdmHBox()._repr_json_() == {}  # no item
    # Test _repr_json_ with a pbar set
    pbar = IProgress(min=0, max=10)
    pbar.value = 3
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    pbar.layout.flex = '2'
    box = TqdmHBox(children=[HTML(), pbar, HTML()])
    box.pbar = proxy(pbar)

# Generated at 2022-06-22 05:27:57.393371
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=4, desc="test notebook", unit="B") as pbar:
        for i in range(4):
            pbar.update(1)

# Generated at 2022-06-22 05:28:30.232776
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # No total
    # t = tqdm_notebook(iterable='ABCDEFG', desc='test1')
    # assert t.n == 0
    # assert t.total is None
    # t.__iter__().__next__()
    # assert t.n == 1
    # assert t.total is None

    # Total
    t = tqdm_notebook(iterable='ABCDEFG', desc='test2', total=1)
    assert t.n == 0
    assert t.total == 1
    t.__iter__().__next__()
    assert t.n == 1
    assert t.total == 1

    # Test with error

# Generated at 2022-06-22 05:28:41.800204
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from sys import version_info
    from IPython.core.display import display, HTML

    def _html(h):
        return HTML(h.__repr__())

    h = TqdmHBox()
    display(_html(h))
    # test no value for any child
    assert h.children[0].value == ''
    assert h.children[1].bar_style == ''
    assert getattr(h.children[1], 'value', None) is None
    assert h.children[2].value == ''
    pbar = h.children[1]
    # test with arbitrary value
    h.pbar = pbar
    display(_html(h))
    pbar.bar_style = 'info'
    pbar.layout.width = '20px'
    display(_html(h))

# Generated at 2022-06-22 05:28:47.327132
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.kernel.zmq.kernelapp import IPKernelApp
    app = IPKernelApp.instance()
    app.initialize([])
    from IPython.core.interactiveshell import InteractiveShell
    from IPython.display import clear_output
    from IPython.display import display
    InteractiveShell.clear_output = clear_output
    ip = InteractiveShell.instance()
    ip.display_pub.publish = display
    ip.displayhook.session = ip._get_session()
    with ip:
        progress = tqdm_notebook(range(100))
        progress.clear(close=True)
        progress.clear(bar_style='success', ncols=100)
        progress.reset()
        progress.clear(bar_style='danger')
        progress.n = 10

# Generated at 2022-06-22 05:28:56.925841
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from os import path
    import sys
    from tempfile import NamedTemporaryFile
    from traitlets import HasTraits, Int
    from traitlets.config.configurable import LoggingConfigurable

    class Mock(HasTraits, LoggingConfigurable):
        test = Int()

        def __init__(self):
            HasTraits.__init__(self)
            LoggingConfigurable.__init__(self)

    def test_props(test):
        t = tqdm(test)
        f = t.display(msg="test %d" % test, pos=test,
                      close=False, bar_style=None, check_delay=False)
        return t, f

    test = 10
    with NamedTemporaryFile(mode='w') as f:
        fn = f.name
        sys.stdout

# Generated at 2022-06-22 05:29:04.699137
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .utils import test

    # Test that a unit test is still executed without error
    for _ in tqdm(range(100)):
        pass

    # Test that the clear method of tqdm_notebook has no effect
    x = tqdm(range(100))
    x.clear()
    test(x.__str__() == "10%|█         | 10/100 [00:00<00:00, 450.00it/s]",
         True)

# Generated at 2022-06-22 05:29:16.745492
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        import ipywidgets
    except ImportError:
        try:
            import IPython.html.widgets as ipywidgets
        except ImportError:
            return
    with ipywidgets.Output() as op:
        with tqdm_notebook(unit='B', unit_scale=True, miniters=1,
                           mininterval=0.01, desc='initial test') as t:
            assert t.desc == 'initial test'
            t.set_description('dynamic test')
            assert t.desc == 'dynamic test'
            t.set_postfix(ordered_dict=dict(a=1, b='2'))
            t.update(5)  # ignored, because miniters=1
            t.update(1)  # will be displayed
            t.refresh()

# Generated at 2022-06-22 05:29:26.720405
# Unit test for function tnrange
def test_tnrange():
    """Test for both tqdm and tnrange (same as tqdm)."""
    from .utils import _term_move_up
    for f in (tqdm, tnrange):
        f(range(8)).start()
        t = f(range(0, 9, 3), desc='Foo')
        for i in t:
            t.set_description('Bar %i' % i)
            # can print multiple times per iteration
            for j in range(5, -1, -1):
                t.postfix = [j]
                t.display()
            # also updates total iterations each time
            t.update(2 + int(i % 3))
        # testing `refresh` method: new line + move cursor up
        t.refresh()
        assert (t.n == max(t.total, 1))

# Generated at 2022-06-22 05:29:38.772568
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .gui import tgrange
    from .utils import format_sizeof

    try:  # Remove any previous test file
        import os
        import os.path
        path = 'tqdm_notebook_testfile'
        if os.path.isfile(path):
            os.remove(path)
    except:  # NOQA
        pass

    data = list(range(10))

    # Check error on manual tqdm
    t = tqdm_notebook(data)
    try:
        raise NotImplementedError()
    except:  # NOQA
        pass
    else:
        assert False, "Error not propagated properly"
    t.close()

    # Check error on iterable tqdm

# Generated at 2022-06-22 05:29:47.861803
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm._tqdm_notebook import tqdm as tqdm_notebook
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('tqdm._tqdm_notebook.display') as mock_display:
        with patch('tqdm._tqdm_notebook.clear_output') as mock_clear_output:
            tqdm_notebook(total=1).close()
            mock_display.assert_called_once_with(tqdm_notebook.container)
            mock_clear_output.assert_called_once_with(wait=1)

# Generated at 2022-06-22 05:29:57.078023
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Simple unit testing for tqdm.notebook.tqdm.
    """
    from os import devnull
    from time import sleep

    # Common attributes
    file = devnull
    dynamic_ncols = None

    # Test 1: no bar should be displayed
    bar = tqdm_notebook(iterable=range(8), total=8,
                        file=file, dynamic_ncols=dynamic_ncols)
    sleep(0.3)
    assert not bar.displayed

    # Test 2: progress bar should be displayed
    bar = tqdm_notebook(iterable=range(8), total=8,
                        file=file, dynamic_ncols=dynamic_ncols,
                        miniters=1, mininterval=0)
    sleep(0.3)
   