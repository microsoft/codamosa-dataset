

# Generated at 2022-06-22 05:20:20.672039
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit tests for tqdm_notebook_class
    """
    from ._tqdm_gui import tcls
    with tcls.disable():

        # Check construction of tqdm_notebook object
        t = tqdm_notebook(total=10, leave=False)
        t.update()
        t.close()
        t.reset()
        t.reset(total=None)
        t.reset(total=10)
        t.reset(total=None)
        t.reset()
        t.close()
        t.reset()

        t = tqdm_notebook(total=10, leave=True)
        t.update()
        t.close()
        t.reset()
        t.reset(total=None)
        t.reset(total=10)

# Generated at 2022-06-22 05:20:31.800085
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test reset method of tqdm_notebook
    with tqdm_notebook(total=2, leave=False) as pbar:
        assert pbar.total == 2
        assert pbar.displayed
        if pbar.ncols:
            assert pbar.container.layout.width == pbar.ncols
        else:
            assert pbar.container.layout.width is None
        pbar.reset(3)
        assert pbar.total == 3
        assert pbar.displayed
        if pbar.ncols:
            assert pbar.container.layout.width == pbar.ncols
        else:
            assert pbar.container.layout.width is None


# Generated at 2022-06-22 05:20:37.595975
# Unit test for function tnrange
def test_tnrange():
    list(tnrange(3))
    try:
        list(tnrange())  # empty iterable
        raise ValueError()
    except ValueError as e:
        if "is empty" not in str(e):
            raise
    list(tnrange(3, desc='Custom desc', leave=True, disable=False))



# Generated at 2022-06-22 05:20:40.768843
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests_tqdm import test_tqdm___iter__
    test_tqdm___iter__(tqdm_notebook)



# Generated at 2022-06-22 05:20:52.356163
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class FakeTqdm(object):
        format_dict = dict(desc='Desc',
                           n=10,
                           total=20,
                           elapsed=30,
                           unit='iB',
                           rate='1.0',
                           remaining='20s',
                           ascii=False,
                           bar_format='{desc}{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
                           )
        ncols = None

    hb = TqdmHBox()
    hb.pbar = FakeTqdm()
    # Test pretty mode
    assert hb._repr_json_(pretty=True) == hb.pbar.format_dict
    assert hb.__repr__(pretty=True) is not None
   

# Generated at 2022-06-22 05:20:55.812458
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import trange
    from contextlib import closing
    with closing(trange(3)) as t:
        assert t.n == 0
        t.update()
        assert t.n == 1
        t.update()
        assert t.n == 2
        for i in range(3):
            t.update()
        assert t.n == 5

# Generated at 2022-06-22 05:21:00.010205
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # init
    t = tqdm_notebook(0)
    # set to some values
    t.update(2)
    # assert
    assert t.n == 2
    # close
    t.close()

# Generated at 2022-06-22 05:21:04.623482
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    tn = tqdm_notebook(total=5, desc="Test", leave=False)
    for _ in range(5):
        tn.display(None, str(_))
        sleep(0.5)
    tn.close()
    return True

# Generated at 2022-06-22 05:21:08.901728
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    pbar = tqdm_notebook(total=1, leave=True)
    pbar.displayed = True  # fake
    pbar.close()
    assert pbar.displayed is False
    assert not pbar.disable



# Generated at 2022-06-22 05:21:10.601858
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit tests for tqdm_notebook
    """
    import doctest
    doctest.testmod()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-22 05:21:36.212631
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import TMonitor
    from .utils import FormatCustomTextTest
    with TMonitor(leave=True) as t:
        # basic test
        test = tqdm_notebook(total=4, desc="test bar")
        for _ in test:
            pass
        # nested test
        with tqdm_notebook(total=4, desc="test nested") as test:
            for _ in test:
                pass
        # with manual=True
        test = tqdm_notebook(total=4, desc="test manual=True")
        for _ in test:
            test.update()
        # with manual=True + nested
        with tqdm_notebook(total=4, desc="test nested manual=True") as test:
            for _ in test:
                test.update()
        # auto-disable + nested

# Generated at 2022-06-22 05:21:48.441272
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test method `close` of class `tqdm_notebook`"""
    from .utils import _supports_unicode
    if not _supports_unicode():
        return
    from .gui import tqdm_gui
    for TqdmType in [tqdm_notebook, tqdm_gui]:
        with TqdmType(total=10) as t:
            for _ in t:
                pass
        with TqdmType(total=10) as t:
            t.update()
        with TqdmType(total=10) as t:
            t.update()
            t.close()
        with TqdmType(total=10) as t:
            t.update()
            t.close()
        with TqdmType(total=10, leave=True) as t:
            t

# Generated at 2022-06-22 05:21:56.439383
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from tqdm.auto import tqdm
    from html import escape

    t = tqdm(total=9, desc='A', leave=False)
    t.update(1)
    assert(t._repr_pretty_(None, None) ==
           '  0%|A                    | 0/9 [00:00<?, ?it/s]')
    t.update(3)
    assert(t._repr_pretty_(None, None) ==
           ' 33%|A                    | 3/9 [00:00<00:00, 23.00it/s]')
    t.update(5)
    assert(t._repr_pretty_(None, None) ==
           '100%|A                    | 9/9 [00:00<00:00, 40.00it/s]')
    t.close()



# Generated at 2022-06-22 05:22:04.031719
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """
    Unit test for constructor of class tqdm_notebook
    """
    # Create a new instance
    t = tqdm_notebook(total=20, desc="Testing tqdm", ncols=50,
                      leave=True, disable=False)
    for i in t:
        tqdm_notebook.sleep(0.1)
    t.close()


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-22 05:22:10.800926
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=1)
    t.close()


if __name__ == '__main__':
    from time import sleep
    from random import randint
    from traceback import print_exc

    for _ in tqdm_notebook(range(10), leave=True):
        sleep(0.2)
        try:
            if randint(0, 1):
                raise KeyboardInterrupt
        except KeyboardInterrupt:
            print_exc()
            break

# Generated at 2022-06-22 05:22:15.566269
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = TqdmHBox()
    pbar.pbar = tqdm_notebook()
    pbar.pbar.desc = 'Hi'
    pbar.pbar.total = 10
    pbar._repr_json_()
    pbar.__repr__()
    pbar._repr_pretty_()

# Generated at 2022-06-22 05:22:26.173612
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Check method display

    def add_style_func(cls):
        def fget(self):
            try:
                return self.style
            except AttributeError:
                self.style = None
                return self.style

        def fset(self, style):
            self.style = style

        # based on https://github.com/ipython/ipywidgets/blob/47928d4f57ff056e8f6a4a6ddf9d1d91477425a5/ipywidgets/widgets/widget.py
        cls.style = property(fget, fset)

    # Monkey-patch class TqdmHBox
    if IPY:
        add_style_func(TqdmHBox)
        # Initialize ipywidgets
        test = tqdm_

# Generated at 2022-06-22 05:22:27.873826
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm import tqdm, trange
    for i in trange(10):
        pass

# Generated at 2022-06-22 05:22:36.611819
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import os
    for leave in [False, True]:
        for total in [None, 5]:
            for n in [0, 1, 4, 5]:
                with tqdm_notebook(total=total, leave=leave) as t:
                    t.update(n)
                if os.name == 'nt':
                    # Workaround to fix the hang in unit tests
                    # -- See https://travis-ci.org/tqdm/tqdm/jobs/436524151
                    continue
                assert (t.closed and not t.container.visible) == (not leave
                        and (total is None or n >= total))

# Generated at 2022-06-22 05:22:43.045055
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=1000) as t:
        # unit test that reset works with initial bars,
        # and that the bar is still reset to 1 before closing
        # (and that it is successfully removed)
        for _ in t:
            break
    t.reset()
    for _ in t:
        t.reset(1000)
        for _ in t:
            pass
        break



# Generated at 2022-06-22 05:23:07.373580
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    try:
        from IPython.display import clear_output
    except ImportError:
        return None
    # Tests a very basic usage of the `reset()` method
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.update(10)
    t.reset(total=200)
    for i in range(20):
        t.update(10)
    clear_output()


if __name__ == "__main__":
    # Unit test for method display of class tqdm_notebook
    test_tqdm_notebook_reset()
    t = tqdm_notebook(total=100)
    for i in range(10):
        t.update(10)
        t.display()

    # Test keep bar
    #

# Generated at 2022-06-22 05:23:18.624684
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    from time import sleep
    for close_on_error in [False, True]:
        for manual in [False, True]:
            for leave in [False, True]:
                for unit_scale in [False, True]:
                    for total in [0, 1, None]:
                        for leave in [False, True]:
                            t = tqdm_notebook(total=total, leave=leave,
                                              unit_scale=unit_scale,
                                              disable=not manual)
                            if total:
                                assert t.container.children[0].value == t.desc
                            sleep(0.5)
                            if close_on_error:
                                try:
                                    t.update(42)
                                except Exception:
                                    pass
                                finally:
                                    t.close()

# Generated at 2022-06-22 05:23:30.541058
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    import nose.tools

    # Skip test if IPython is not found
    if IProgress is None:
        raise nose.SkipTest("IProgress not found. Skipping tests")

    pbar = tqdm_notebook(total=100, unit='iB')
    assert pbar.container.children[0].value == ''
    print("")  # to flush print buffers
    assert pbar.container.children[2].value == ''
    pbar.write("Starting...")
    assert pbar.container.children[0].value == ''
    assert pbar.container.children[2].value == 'Starting...'
    pbar.update(5)
    assert "5/100" in pbar.container.children[2].value
    pbar.close()

# Generated at 2022-06-22 05:23:36.012883
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=3) as t:
        t.update()
        t.update()
    # Check if tqdm_notebook close properly
    # See https://github.com/tqdm/tqdm/issues/430
    assert t.n == t.total == 3
    assert t.last_print_t == t.t


# Generated at 2022-06-22 05:23:43.798185
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm([1, 2, 3], total=5, desc='Desc')
    t.display(check_delay=False)
    assert repr(t) == 'Desc: 0it [00:00, ?it/s]'
    t.update()
    assert repr(t) == 'Desc: 1it [00:00, ?it/s]'
    t.close()
    assert repr(t) == 'Desc: 3it [00:00, ?it/s]'


if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:23:55.145145
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Unit test for method `__repr__` of class `TqdmHBox`."""
    # simplification of actual tqdm_notebook.status_printer
    pbar = IProgress(min=0, max=1)
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])
    container.pbar = pbar

# Generated at 2022-06-22 05:24:01.643630
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        import IPython
        # get ipython version:
        ipython_version = [int(i) for i in IPython.__version__.split('.')]
        if ipython_version == [0, 12]:
            raise ImportError()
    except ImportError:
        import nose
        raise nose.SkipTest('ipython 0.13+ required')
    # TODO: actually test the method

# Generated at 2022-06-22 05:24:04.908764
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():

    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        for _ in range(3):
            pass
        clear_output(wait=True)
        assert pbar.displayed == True
        pbar.clear(nolock=True)
        assert pbar.displayed == False
        clear_output(wait=True)
        assert pbar.displayed == False

test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:24:13.691944
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    a = tqdm_notebook([])
    a.write("hi")
    a.close()
    assert a.displayed == False
    with tqdm_notebook([]) as a:
        a.write("hi")
    assert a.displayed == False
    with tqdm_notebook([], display=True) as a:
        a.write("hi")
    assert a.displayed == True
    with tqdm_notebook([], display=False) as a:
        a.write("hi")
    assert a.displayed == False

# Generated at 2022-06-22 05:24:23.366581
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tqdm as tqdm_pyg
    try:
        for _ in tqdm_notebook(range(1), desc='1st loop'):
            for _ in tqdm_notebook(range(1), desc='2nd loop'):
                for _ in tqdm_notebook(range(1), desc='3rd loop'):
                    for _ in tqdm_notebook(range(1), desc='4th loop'):
                        pass
    except Exception:
        pass

    # Test method clear of class tqdm_notebook

# Generated at 2022-06-22 05:24:55.922863
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Test tqdm_notebook constructor"
    t = tqdm_notebook(0, leave=True)
    assert t.displayed
    assert t.total == 0
    assert t.container.children[1].bar_style == 'info'
    assert t.container.children[1].value == 1
    assert not t.container.children[1].visible
    t.close()



# Generated at 2022-06-22 05:25:05.294067
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tnrange.
    """
    with tnrange(4) as t:
        for i in range(4):
            t.update()
    t.reset()
    with tnrange(4) as t:
        for i in range(4):
            t.update()
    t.reset()
    with tnrange(4) as t:
        for i in range(4):
            t.update()
    t.reset()
    with tnrange(4) as t:
        for i in range(4):
            t.update()


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-22 05:25:09.253566
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from random import random
    total = random() * 100
    progress = tqdm_notebook(total=total)
    for i in range(total):
        time.sleep(random() * .005)
        progress.update()
    progress.close()

# Generated at 2022-06-22 05:25:12.644014
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10) as t:
        assert t.total == 10
        for i in t:
            pass  # pragma: no cover

# Generated at 2022-06-22 05:25:23.023357
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = tqdm_notebook.status_printer(sys.stderr, desc='test', total=1)
    assert len(pbar.children) == 3
    assert all('Widget' in str(x) for x in pbar.children)
    assert all(isinstance(x, HTML) for x in pbar.children)
    assert pbar.children[-2].value == 'test'
    assert pbar.children[-1].value == ''
    assert pbar.children[-2]._dom_classes == ('widget-label', 'widget-label')
    assert pbar.children[-1]._dom_classes == ('widget-label', 'widget-label')

# Generated at 2022-06-22 05:25:28.615030
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    See https://github.com/tqdm/tqdm/issues/786
    """
    t = tqdm_notebook(total=5, desc='d', leave=True)
    t.reset(total=10)
    t.update(5)
    t.close()

# Generated at 2022-06-22 05:25:38.688405
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Check for manual tqdm
    with tqdm_notebook(0, leave=True, ascii=True) as t:
        t.update(1)
    assert 'OK' in t.desc

    # Check for auto tqdm
    with tqdm_notebook(1, leave=True, ascii=True) as t:
        t.update(2)
    assert 'OK' in t.desc

    # Check for manual tqdm with error
    with tqdm_notebook(2, leave=True, ascii=True) as t:
        t.update(1)
        raise Exception('test')
    assert 'ERROR' in t.desc
    assert 'test' in t.desc

    # Check for auto tqdm with error

# Generated at 2022-06-22 05:25:47.203698
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import trange
    from tqdm._utils import _term_move_up

    for _ in trange(0, 0, desc='bar-1', leave=True):
        sleep(1)
    for _ in trange(0, 0, desc='bar-2', leave=True):
        sleep(1)
    for _ in trange(1, desc='bar-3', leave=True):
        sleep(1)

    with open(DUMMY_FILE, 'w') as _file:
        fp = _file
        # Initialize tqdm notebook
        pbar = tqdm_notebook(total=5, desc='test', file=fp)
        assert pbar.unit_scale is False
        assert pbar.total == 5
        assert pbar.dynamic_n

# Generated at 2022-06-22 05:25:51.501851
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    import os
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
        os._exit(1)


# Generated at 2022-06-22 05:26:03.013960
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .std import tqdm
    t = tqdm_notebook(total=5)
    assert not t.disable
    t.close()
    assert t.disable

    t = tqdm_notebook(total=5, leave=True)
    t.close()
    assert not t.disable

    t = tqdm_notebook(total=5, leave=False)
    t.close()
    assert t.disable

    t = tqdm(total=5)
    t.close()
    assert t.disable

    t = tqdm(total=5, leave=True)
    t.close()
    assert not t.disable

    t = tqdm(total=5, leave=False)
    t.close()
    assert t.disable


# Generated at 2022-06-22 05:28:39.363917
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange.
    """
    from six.moves import xrange
    from nose.tools import assert_equal

    with tnrange(4) as t:
        for i in xrange(4):
            assert_equal(t.n, i)
            t.update()

    with tnrange(10, 2) as t:
        for i in xrange(2, 12, 2):
            assert_equal(t.n, i)
            t.update()

    with tnrange(0, 0) as t:
        assert_equal(t.n, 0)
        t.update()

    with tnrange(10, 10) as t:
        for i in xrange(10, 20):
            assert_equal(t.n, i)
            t.update()

   

# Generated at 2022-06-22 05:28:50.928091
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """

    # Setup default output
    file_kwarg = sys.stderr
    if file_kwarg is sys.stderr or file_kwarg is None:
        file = sys.stdout  # avoid the red block in IPython

    # Initialize parent class + avoid printing by using gui=True
    gui = True
    disable = False
    unit_scale = 1
    total = 10
    n = 5
    desc = 'Test'
    ncols = None
    leave = True
    minsample = 1
    smoothing = 1
    bar_format = '{desc} {percentage:3.0f}%|{bar}|{n_fmt}/{total_fmt}{postfix}'
    initial = None
    dynamic

# Generated at 2022-06-22 05:29:01.626463
# Unit test for function tnrange
def test_tnrange():
    """Test for function tnrange"""
    import time

    n = 10
    with tnrange(10) as t:
        for i in t:
            time.sleep(.5)
    if n < 0 or n > 10:
        raise ValueError("unexpected n value: %d" % n)
    with tnrange(n) as t:
        for i in t:
            time.sleep(.5)
            t.set_description('tnrange(%i)' % i)
    with tnrange(10, desc='tnrange(i)', leave=True) as t:
        for i in t:
            time.sleep(.5)
            t.set_description('tnrange for i in range(10)')
        t.set_description('Done.')

# Generated at 2022-06-22 05:29:07.245776
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    pbar = std_tqdm()
    hbox.pbar = pbar
    assert re.match(r'\s*[\d.%]+?/[\s\d.%]+?\s[\u25b2-\u25fc]\s+',
                    hbox.__repr__())

# Generated at 2022-06-22 05:29:19.096701
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    import numpy as np
    # make sure the size of bar is at least 10 pixels
    # use a trick to set the width of progress bar
    try:
        from IPython.display import HTML
        HTML('''
            <script>
                require(["base/js/utils"], function (utils) {
                    utils.load_extensions('widgets/notebook/js/extension');
                });
            </script>
        ''')
    except:
        pass

    # test with total
    n = 100
    display_here = True
    bar = tqdm_notebook(total=n, leave=False, desc='Testing display() with total',
                        display=display_here)
    assert len(bar.container.children) == 3

# Generated at 2022-06-22 05:29:29.836058
# Unit test for method close of class tqdm_notebook

# Generated at 2022-06-22 05:29:41.419401
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test reset with total
    bar = tqdm_notebook()
    bar.total = 10
    bar.update(2)
    bar.reset()
    assert bar.n == 0
    assert bar.n == 0
    # Test reset with total=None (unchanged)
    bar = tqdm_notebook()
    bar.total = 10
    bar.update(2)
    bar.reset()
    assert bar.n == 0
    assert bar.n == 0
    # Test reset with total=5
    bar = tqdm_notebook()
    bar.total = 10
    bar.update(2)
    bar.reset(total=5)
    assert bar.n == 0
    assert bar.total == 5

if __name__ == "__main__":
    test_tqdm_notebook_

# Generated at 2022-06-22 05:29:47.336385
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert tqdm_notebook.status_printer(None)
    assert tqdm_notebook.status_printer(None, 10, "", 100)
    assert tqdm_notebook.status_printer(None, 10, "", "100px")
    assert tqdm_notebook.status_printer(None, 10, "", "100%")



# Generated at 2022-06-22 05:29:57.516746
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # setup widget
    iterable = tnrange(5)
    iterable.update()
    iterable.clear()
    iterable.close()
    iterable.close()  # should not raise
    # test reset
    iterable.reset(2)
    assert iterable.n == 0
    assert iterable.total == 2
    assert iterable.container.pbar.max == 2
    iterable.update(3)
    assert iterable.n == 1
    assert iterable.container.pbar.value == 1
    iterable.reset(2)
    assert iterable.n == 0
    assert iterable.total == 2
    assert iterable.container.pbar.max == 2
    iterable.update(1)
    assert iterable.n == 1
    assert iterable.container.pbar.value == 1