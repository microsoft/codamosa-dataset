

# Generated at 2022-06-22 05:20:19.246961
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # reset with no total is deprecated
    with std_tqdm(total=10, leave=True, unit='iter', desc='test',
                  bar_format='{percentage:3.0f}%% {bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}, {rate_fmt}{postfix}]') as t:
        for _ in t:
            pass
        t.reset()
        for _ in t:
            pass

# Generated at 2022-06-22 05:20:31.408775
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    import sys
    try:
        from time import monotonic as time
    except ImportError:
        pass

    # tqdm.monitor_interval = 0  # don't let other instances influence our test
    # tqdm.monitor_interval = 0
    # with std_tqdm(total=3) as t:
    t = tqdm_notebook(total=3)
    t.clear()

# Generated at 2022-06-22 05:20:39.083854
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Test clear()
    try:
        import ipywidgets
    except ImportError:
        pass
    else:
        COUNT_MAX = 100
        pbar = tqdm_notebook(total=COUNT_MAX)
        for i in range(0, COUNT_MAX, 3):
            # clear each 3 iterations
            pbar.clear()
            pbar.update(3)
        pbar.close()


test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:20:47.637508
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for disable in [False, True]:
        for leave in [False, True]:
            for ncols in [None, 100]:
                for unit_scale in [True, False, 1, 10]:
                    with tqdm_notebook(disable=disable, leave=leave,
                                       ncols=ncols, unit_scale=unit_scale) as t:
                        t.total = 10
                        t.update(1)  # display bar
                        t.clear()
                        t.update()  # no more display



# Generated at 2022-06-22 05:20:57.452950
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    IPY = None
    try:
        from IPython import get_ipython
        IPY = get_ipython().__class__.__name__
    except (AttributeError, ImportError):
        pass

    from tqdm.notebook import tqdm_notebook
    from time import sleep

    hb = TqdmHBox(children=[])
    assert repr(hb) == ""

    hb = TqdmHBox(children=[])

# Generated at 2022-06-22 05:21:03.841590
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=None) as pbar:
        assert pbar.container.layout.width == "20px"

        pbar.reset(total=100)
        assert pbar.container.layout.width is None

        pbar.reset(total=None)
        assert pbar.container.layout.width == "20px"

# Generated at 2022-06-22 05:21:16.506257
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from unittest import TestCase

    class Dummy(object):
        # Dummy file
        def clear(self):
            pass

    class CheckTqdmNotebook(TestCase):
        def test_clear(self):
            with tqdm_notebook(total=10) as t:
                t.clear()

    CheckTqdmNotebook().test_clear()

if __name__ == "__main__":
    # Unit test for class tqdm_notebook
    import unittest

    class CheckTqdmNotebook(unittest.TestCase):
        """
        Test class tqdm_notebook
        """

        def test_class(self):
            """
            Test class
            """

# Generated at 2022-06-22 05:21:18.557788
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for _ in tqdm(range(10), clear=True):
        pass
    assert True

# Generated at 2022-06-22 05:21:26.928400
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """ Unit test for method clear of class tqdm_notebook
    """
    import io
    import sys
    import unittest
    from contextlib import contextmanager

    @contextmanager
    def captured_output():
        new_out, new_err = io.StringIO(), io.StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class TqdmNotebookClear(unittest.TestCase):
        """Tests for `tqdm.notebook.tqdm_notebook_clear`."""


# Generated at 2022-06-22 05:21:31.792313
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        with tqdm_notebook(total=0) as bar:
            bar.clear()
    except NotImplementedError:
        raise
    except Exception:
        raise AssertionError(
            "Class tqdm_notebook: The method clear is not properly implemented.")

# Generated at 2022-06-22 05:21:51.781184
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import io
    from contextlib import redirect_stdout
    with io.StringIO() as buf, redirect_stdout(buf):
        from tqdm.notebook import TqdmHBox
        pbar = TqdmHBox(children=[None] * 3, pbar=True)
        print(pbar)
        pbar.close()

# Generated at 2022-06-22 05:22:02.262858
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Default behavior leave=False: close() should hide the bar
    for leave in (False, True):
        for total in (None, 10):
            # We compare html rendering of the bar to find out if it's visible
            bar = tqdm_notebook(total=total, leave=leave)
            if total is None:
                # info style bar always has progress=0 even if value=1
                assert bar._repr_html_() == '<progress value="0">'
            else:
                assert bar._repr_html_() == '<progress value="0" max="10">'
            bar.update()
            if total is None:
                assert bar._repr_html_() == '<progress value="1">'

# Generated at 2022-06-22 05:22:06.851051
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tnrange
    from time import sleep

    for i in tnrange(4, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)

    for i in tnrange(4, desc='1st loop', leave=False):
        for j in tnrange(100, desc='2nd loop', leave=False):
            sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:22:15.474351
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for _ in range(3):
        with tqdm(total=200) as t:
            for i in range(100):
                t.update()
            t.reset()
            assert t.n == 0
            for i in range(100):
                t.update()
            t.reset(total=100)
            assert t.total == 100
            for i in range(100):
                t.update()
    t = tqdm(total=100)
    t.reset()  # Test without arguments


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:22:26.127221
# Unit test for function tnrange
def test_tnrange():
    from tqdm._tqdm import TqdmTypeError
    with tqdm(total=1) as pbar:
        for i in tnrange(5, total=10, desc="tnrange"):
            pbar.update()
        try:
            for i in tnrange(None, desc="missing `total` param"):
                pbar.update()
        except TqdmTypeError:
            pass
        else:
            assert False, "tnrange(None) should raise an Exception"
        try:
            for i in tnrange(total=None, desc="missing `total` param"):
                pbar.update()
        except TqdmTypeError:
            pass
        else:
            assert False, "tnrange(total=None) should raise an Exception"

# Generated at 2022-06-22 05:22:30.716730
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import trange
    from time import sleep as time_sleep

    with trange(10) as t:
        for i in t:
            assert i == t.n
            time_sleep(t.sleep_interval)
    assert i == t.n - 1


# Generated at 2022-06-22 05:22:42.739051
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from random import random
    from itertools import chain

    def random_ipython_display():
        if random() > 0.25:
            tqdm_notebook().display("")

        # ipywidgets 6.x
        if (getattr(IProgress, '_dom_classes', None) or [set()])[0] == set(
                ['p-Widget', 'jupyter-widgets', 'ipywidgets', 'widgets']):
            from ipywidgets import IntProgress, HBox, Layout, VBox, HTML
            # does not work with IntProgress() directly,
            # since it is not added to the DOM and thus does not get its properties
            # (max, min and value)
            pbar = HBox(children=[IntProgress(max=10)])

# Generated at 2022-06-22 05:22:53.786918
# Unit test for function tnrange
def test_tnrange():
    l = 10
    fmt1 = 'My bar1: {l_bar}{bar}{r_bar}'
    fmt2 = 'My bar2: {l_bar}{bar}{r_bar}'
    print('LEFT')
    with tqdm(total=l, ascii=True, desc='My bar1', bar_format=fmt1) as t:
        for i in _range(l):
            t.update()
        assert t.n == l
        t.set_description('New desc1')
        t.set_postfix(ordered_dict=dict(new=1))
        t.set_postfix(test=1, test2=2)
        t.update(0)

    print('RIGHT')

# Generated at 2022-06-22 05:22:58.093743
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    t = tqdm_notebook(total=10)
    for i in range(10):
        t.display(str(i))
    t.close()
    assert hasattr(t, 'container')



# Generated at 2022-06-22 05:23:09.136080
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=100) as t:
        for i in range(100):  # test with tqdm_notebook(total=100)
            sleep(0.1)
            t.update(1)
        assert t.n == t.total
    with tqdm_notebook(total=100) as t:
        for i in range(100):  # test with tqdm_notebook(total=100)
            sleep(0.1)
            t.update(1)
        assert t.n == t.total
    with tqdm_notebook(total=100, ncols=0) as t:
        for i in range(100):  # test with tqdm_notebook(total=100)
            sleep(0.1)
            t.update