

# Generated at 2022-06-22 05:20:23.980359
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test if html escaping works
    try:
        from IPython.display import publish_display_data, display
    except ImportError:  # pragma: no cover
        try:
            from IPython.kernel.zmq.tests.test_display_pub import publish_display_data
        except ImportError:
            publish_display_data = None

    # Output of the example from the docstring
    strout = r"""
    |/-------------------------------------------------------------------------\| 3/4 [00:10<00:05,  3.33s/it]
    |/                                                                         \| 4/4 [00:13<00:00,  3.32s/it]
    """
    # The output of the test

# Generated at 2022-06-22 05:20:36.270617
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.core.display import HTML_FORMATTERS
    from traitlets import Type

    container = TqdmHBox(children=[
        HTML(value="tqdm description"),
        IProgress(min=0, max=1),
        HTML(value="tqdm postfix"),
    ])
    container.pbar = container.children[-2]
    assert (repr(container) ==
            "[tqdm description<br><br><bar/><br>tqdm postfix]")

    # test auto-update of info (not decorator)
    pbar = container.pbar
    pbar.value = 1
    pbar.bar_style = 'info'

# Generated at 2022-06-22 05:20:48.428646
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    def _test_many(pretty=True):
        assert TqdmHBox().__repr__(pretty=pretty) == ""
        assert TqdmHBox(children=[HBox(), HBox()]).__repr__(pretty=pretty) == ""
        pbar = IProgress(min=0, max=1)
        pbar.value = 0
        pbar.bar_style = 'success'
        d = {'n': 1, 'total': 1, 'desc': 'test', 'ncols': 100, 'rate': 0.1, 'elapsed': 1.0}
        assert TqdmHBox(children=[pbar]).__repr__(pretty=pretty) == 'test:  0%|          | 0/1 [00:00<?, ?it/s]'
        pbar.value = 1

# Generated at 2022-06-22 05:20:58.867667
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from textwrap import dedent

    fp = StringIO()
    pbar = tqdm_notebook(desc='Testing...', ascii=True, file=fp)
    container = pbar.container
    container.pbar = proxy(pbar)

    # Test with ascii=True
    fp.truncate(0)
    fp.seek(0)
    print(container)
    assert str(fp.getvalue()).strip() == dedent("""\
        Testing...:   0%|          | 0/2 [00:00<?, ?it/s]
        Testing...: 100%|##########| 2/2 [00:00<00:00, 14.64it/s]
        """).strip()

    # Test with ascii=False
    fp

# Generated at 2022-06-22 05:21:11.204679
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import unittest
    import os

    class TestTqdmNotebook___iter__(unittest.TestCase):
        def setUp(self):
            self.range_result = list(range(50))
            self.tqdm_result = list(tqdm_notebook(self.range_result))
        def test_values_equal(self):
            self.assertEqual(self.range_result, self.tqdm_result)
        def test_last_value_equal(self):
            self.assertEqual(self.range_result[-1], self.tqdm_result[-1])

        def tearDown(self):
            del self.range_result
            del self.tqdm_result

    if __name__ == '__main__':
        unittest.main()


#

# Generated at 2022-06-22 05:21:23.123960
# Unit test for function tnrange
def test_tnrange():
    """Test function `tnrange`"""
    IPY = 0
    try:
        import ipywidgets
        IPY = 4
    except ImportError:
        try:
            import IPython.html.widgets
            IPY = 32
        except ImportError:
            IPY = 0
    if not IPY:
        return
    # Test function
    from .utils import FormatWarn
    from .utils import _supports_unicode
    with FormatWarn("ignore"):
        for i in tnrange(4, desc='1st loop'):
            assert i == i
            for j in tnrange(5, desc='2nd loop', leave=True):
                assert j == j
                for k in tnrange(30, desc='3nd loop'):
                    assert k == k
                    break

# Generated at 2022-06-22 05:21:25.837700
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    with tnrange(100) as t:
        for i in t:
            pass



# Generated at 2022-06-22 05:21:34.295102
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    import numpy as np
    from tqdm.notebook import trange
    for _ in trange(10):
        time.sleep(0.01)

    with trange(10) as bar:
        for i in bar:
            time.sleep(0.01)
            if not np.random.randint(0, 9):  # error 1 out of 10 times (probability 10%)
                # trigger error
                x = 1 / 0  # NOQA



# Generated at 2022-06-22 05:21:42.950613
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test `tqdm_notebook.__iter__()`"""
    # "Smoke test"
    with tqdm_notebook(total=3) as pbar:
        for _ in range(3):
            pbar.update(1)
    # Test if failing
    try:
        with tqdm_notebook(total=3) as pbar:
            for _ in range(4):
                pbar.update(1)
    except:  # NOQA
        pass
    else:
        raise RuntimeError("tqdm_notebook.__iter__() failed to raise exception")



# Generated at 2022-06-22 05:21:50.259442
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    t = tqdm_notebook(total=2, desc='notebook', ncols=80, position=0)
    assert t.unit_scale is True
    t.update(1)
    t.reset(total=3)
    assert t.unit_scale is True
    t.update(1)
    t.close()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-22 05:22:13.585441
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        global IPY
        IPY = 32
        try:
            import IPython.html.widgets as ipywidgets  # NOQA: F401
        except ImportError:
            pass
        from IPython.html.widgets import FloatProgressWidget as IProgress
        from IPython.html.widgets import ContainerWidget as HBox
        hbox = HBox()
        hbox.pbar = IProgress()
        from .std import TqdmTypeError
        from .std import TqdmKeyError
    except Exception:
        return

    # Dummy bar with no total (only for testing purpose)
    bar = tqdm_notebook(total=None)
    bar.total = 0
    bar.container = hbox
    bar.displayed = False
    # 0 iteration
    assert bar.displayed is False

# Generated at 2022-06-22 05:22:18.355452
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    for _ in tnrange(3, ncols=80):
        pass
    for _ in tnrange(2, 3, ncols=80):
        pass
    for _ in tnrange(2, 3, 1, ncols=80):
        pass

# Generated at 2022-06-22 05:22:25.389850
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Unit test for method `__repr__` of class `TqdmHBox`.
    """
    thb = TqdmHBox()
    assert thb.__repr__() == '\nHBox()'

    thb = TqdmHBox()
    thb.pbar = tqdm_notebook(total=10)
    assert thb.__repr__() == '\n0.00% [##]\nHBox()\n'



# Generated at 2022-06-22 05:22:33.259749
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in (False, True):
        for iterable in [range(5), range(5), range(5), range(5, 0, -1)]:
            tn = tqdm_notebook(iterable, leave=leave)
            for _ in tn:
                pass  # iterate the tqdm
            # the loop above should have closed the tqdm
            if leave:
                assert tn.container.children[-2].bar_style != ''
                tn._instances.clear()
            else:
                assert tn.container.children[-2].bar_style == ''
                assert tn.container.visible == False
                tn._instances.clear()

# Generated at 2022-06-22 05:22:40.486932
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test TqdmHBox representation"""
    # Test
    try:
        TqdmHBox().__repr__()
        TqdmHBox()._repr_pretty_()
        TqdmHBox()._repr_json_()
    except:  # NOQA
        raise
    else:
        success = True
    finally:
        # Clean
        pass

    # Check
    assert success


# Generated at 2022-06-22 05:22:51.025453
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import unittest
    import warnings
    import functools

    class TqdmNotebookClearTests(unittest.TestCase):
        def test_tqdm_notebook_clear(self):
            with warnings.catch_warnings(record=True) as w:
                # Cause all warnings to always be triggered.
                warnings.simplefilter("always")
                # Trigger a warning.
                tqdm_notebook.clear(self)
                # Verify some things
                self.assertEqual(len(w), 0)
                self.assertEqual(tqdm_notebook.clear(self), None)

    unittest.main(module=__name__, verbosity=2, exit=False)



# Generated at 2022-06-22 05:23:03.168092
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import tqdm
    from .utils import _term_move_up
    from .gui import _supports_unicode
    tqdm.tqdm_notebook.status_printer(tqdm.tqdm('foobar', bar_format='{desc}: {bar}'))
    tqdm.tqdm_notebook.status_printer(
        tqdm.tqdm('foobar', ncols=20), total=1000, ncols=20)
    tqdm.tqdm_notebook.status_printer(tqdm.tqdm('foobar', ncols=20), ncols=20)

# Generated at 2022-06-22 05:23:14.593340
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython import get_ipython
    except ImportError:
        return
    ip = get_ipython()
    if not ip or not ip.__class__.__name__ == 'ZMQInteractiveShell':
        return
    from ipywidgets import IntProgress
    from ipykernel.comm import Comm

    def comm_handler(comm, msg):
        if msg['content']['data']['event'] == 'update.tqdm':
            comm.send({'event': 'update', 'value': {'value': 0}})
    ip.kernel.comm_manager.register_target('update.tqdm', comm_handler)
    t = tqdm_notebook(total=5, miniters=1)
    t.update()

# Generated at 2022-06-22 05:23:17.269352
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for i in tqdm(range(3)):
        sleep(0.1)
        tqdm._instances = {}


# Generated at 2022-06-22 05:23:26.009603
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=5) as pbar:
        assert pbar.ncols is None  # test __init__
        assert '<bar/>' in pbar.format_dict['bar_format']  # test format_dict
        pbar.display('testing')
        pbar.display('testing', bar_style='success')
        pbar.display('testing', bar_style='info')
        pbar.display('warning', bar_style='warning')
        pbar.display('error', bar_style='danger')
        pbar.display()
        pbar.display('testing', close=True)

# Generated at 2022-06-22 05:23:48.632133
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    # Test IPython 2.x
    save_tqdm_gui = tqdm.gui
    try:
        tqdm.gui = lambda: True
        tqdm(no_delay=True)
    finally:
        tqdm.gui = save_tqdm_gui

    # Test IPython 4.x
    save_tqdm_gui = tqdm.gui
    save_tqdm_status_printer = tqdm.status_printer
    try:
        tqdm.gui = lambda: True
        tqdm.status_printer = tqdm_notebook.status_printer
        tqdm(no_delay=True)
    finally:
        tqdm.gui = save_tqdm_gui
        tqdm.status_printer

# Generated at 2022-06-22 05:24:00.805150
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    progress = tqdm_notebook(total=1000)
    progress.update(500)
    progress.close()
    assert isinstance(progress.container, TqdmHBox)
    assert progress.colour == 'blue'
    progress.colour = 'red'
    progress.colour = 'green'
    progress.colour = 'blue'
    progress.reset()
    progress.update()
    progress.update()
    progress.update()
    # Test danger style
    try:
        raise RuntimeError("Test")
    except RuntimeError:
        progress.close()
        assert progress.container.visible == False
    # Test success style

# Generated at 2022-06-22 05:24:12.543339
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import FormatCustom
    from .gui import tqdm as tqdm_gui

    for total in (None, 100):
        for leave in (False, True):
            for bar_style in ('success', 'info', 'warning', 'danger', 'info'):
                # Test leave=False
                with tqdm_notebook(total=total, leave=leave) as pbar:
                    pbar.update(pbar.total)
                    pbar.disp(bar_style=bar_style)

                # Test leave=True, then reset
                with tqdm_notebook(total=total,
                                   leave=True) as pbar:
                    pbar.update(pbar.total)
                    pbar.disp(bar_style=bar_style)

# Generated at 2022-06-22 05:24:22.796918
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=1) as t:
        t.display(close=True)
        t.display(msg="hi", bar_style='info')
        t.display(msg="hi", bar_style='success')
        t.display(msg="hi", bar_style='warning')
        t.display(msg="hi", bar_style='danger')

        t.display(msg="hi", pos=1)
        t.display(msg="hi", pos=0.3)
        t.display(msg="hi", pos=-1)

        t.display(msg="hi", close=True, bar_style='danger')

        # reset
        t.reset(total=2)

        t.display()
        t.display(msg="hi", bar_style='info')

# Generated at 2022-06-22 05:24:34.353130
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=15, desc='A')
    t.update(1)
    assert t.container.children[0].value == 'A'
    assert t.container.children[1].value == 1
    assert t.container.children[2].value == ''
    t.set_description('B')
    t.update(1)
    assert t.container.children[0].value == 'B'
    assert t.container.children[1].value == 2
    assert t.container.children[2].value == ''
    t.update(1, bar_style='danger')
    assert t.container.children[0].value == 'B'
    assert t.container.children[1].value == 3
    assert t.container.children[2].value == ''

# Generated at 2022-06-22 05:24:40.409270
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    tqdm_notebook(range(3), desc='test').clear()
    with tqdm_notebook(total=3, desc='test') as pbar:
        for _ in range(3):
            sleep(0.01)
            pbar.update()
        pbar.clear()

if __name__ == '__main__':
    test_tqdm_notebook_clear()
    print('Tests passed')

# Generated at 2022-06-22 05:24:44.891407
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    # create a tqdm object
    pbar = tnrange(10)

    # update the progressbar
    for i in range(10):
        pbar.update()
        time.sleep(0.2)
    # delete the progressbar
    pbar.close()

# Generated at 2022-06-22 05:24:56.809826
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from tqdm._utils import _term_move_up
    from IPython.display import clear_output

    class unit_test:
        # Test exception handling
        def __enter__(self):
            return self

        def __exit__(self, *exc_info):
            pass

        def write(self, x):
            if "Error" in x:
                raise ValueError("Error...")
            print(x)

    def uncolored_test():
        try:
            import colorama
            colorama.init()
        except ImportError:
            return

        class unit_test(unit_test):
            def write(self, x):
                x = re.sub(r"\x1b\[\d+m", "", x)

# Generated at 2022-06-22 05:25:07.907404
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    from IPython.display import clear_output

    clear_output(wait=True)
    s = StringIO()
    with redirect_stdout(s):
        h = TqdmHBox()
        h.pbar = std_tqdm()
        h.pbar.n = 1
        h.pbar.total = 1
        h.pbar.format_dict['bar_format'] = "{bar}"
        h.pbar.format_dict['bar_format'] = "{bar}"
        h.pbar.format_dict['bar_format'] = "{bar}"
        h.pbar.format_dict['bar_format'] = "{bar}"
        print(h)

# Generated at 2022-06-22 05:25:14.932107
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    t = tqdm_notebook(total=1, leave=True, desc='tqdm')
    try:
        sleep(0.5)
        t.reset(10)
        sleep(1)
    except KeyboardInterrupt:
        # bypass errors on exit
        pass

# Generated at 2022-06-22 05:25:46.857727
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .utils import ByteStringIO as _ByteStringIO
    from .utils import _term_move_up

    from os import devnull
    from contextlib import contextmanager

    # Mockup IPython/Jupyter outputs for testing
    class _Backend(object):
        def __init__(self):
            self.counter = 0
            self.content = ""
            self.is_markdown = False

        def write(self, x, update=False):
            if update:
                self.content = x
            else:
                self.content += x + "\n"

        def set_next_input(self, x):
            self.next_input = x

        @contextmanager
        def disabled(self):
            yield

    # define faked IPython/Jupyter outputs
    display = _Backend()
    clear_

# Generated at 2022-06-22 05:25:53.994600
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    # Avoid stderr showing `100%|##########| 4/4 [00:00<00:00,  3.38it/s]`
    import tempfile
    with tempfile.NamedTemporaryFile(mode='w+b') as tmpfile:
        for i in tqdm(_range(4), file=tmpfile):
            assert i in _range(4)


if __name__ == '__main__':  # pragma: no cover
    test_tnrange()

# Generated at 2022-06-22 05:26:04.141503
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from pytest import approx
    from time import sleep
    from numpy import mean
    from numpy.random import normal

    n = 1000000
    with tqdm(normal(size=n), desc="__iter__") as t:
        for i in t:
            if i > 5:
                raise ValueError("i > 5")
            if t.n > -2:
                break
            sleep(0.000001)
    assert mean(t.all_vals) < -1.5
    assert mean(t.all_vals) == approx(-1.5)
    # assert t.n == -2  # is -1 due to interruption
    assert t.n < 0



# Generated at 2022-06-22 05:26:11.461510
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    from tqdm import tqdm as st
    test_tqdm = tqdm_notebook(range(10))
    test_tqdm.clear = MagicMock()
    test_tqdm.close()
    test_tqdm.clear.assert_not_called()
    test_tqdm.clear = st.clear
    test_tqdm.close()

# Generated at 2022-06-22 05:26:24.009422
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from pandas import DataFrame
    from pandas.testing import assert_frame_equal

    it = tqdm_notebook.status_printer(None, total=10)

    assert DataFrame.from_dict({
        'desc': [repr(it.children[0].value)],
        'a': ['0.0'],
        'b': ['10.0'],
        'n': ['0'],
        'total': ['10'],
        'elapsed': ['00:00<00:00, ?'],
        'remaining': ['--:--<00:00, ?'],
        'speed': ['?it/s'],
        'bar': [repr(it.children[1].value)],
    }).equals(DataFrame.from_dict(it._repr_json_()))

# Generated at 2022-06-22 05:26:29.661746
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Ensures that bar is printed only once.
    """

    from tqdm import tqdm_notebook
    from tqdm import TqdmSynchronisationWarning
    t = tqdm_notebook(total=3)
    for i in range(3):
        t.display()
    for i in range(3):
        t.display()
    assert t.displayed

# Generated at 2022-06-22 05:26:34.503101
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from nose import tools as nt
    except ImportError:
        return
    t = tqdm_notebook(total=10)
    nt.assert_equal(t.displayed, False)
    t.clear()
    nt.assert_equal(t.displayed, True)

if __name__ == "__main__":
    from nose.core import runmodule
    runmodule()

# Generated at 2022-06-22 05:26:39.257319
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Initialization
    t = tqdm_notebook(["a", "b", "c", "d"])
    # Iterate on the iterable
    assert [next(t) for x in range(len(t))] == ["a", "b", "c", "d"]
    # Test exception handling


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 05:26:46.725928
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    t = tqdm_notebook(total=50)
    for _ in t:
        # raise error to check exception handling
        if _ == 25:
            raise KeyboardInterrupt
        # update text
        t.set_postfix(dict(file=_))
        # update colour
        t.set_postfix(dict(file=_), colour='yellow')
        time.sleep(0.01)
    t.close()

# Generated at 2022-06-22 05:26:52.044146
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.core.display import clear_output
    from IPython.core.display import display
    with std_tqdm(total=10) as pbar:
        container = TqdmHBox(children=[HTML(), FloatProgress(min=0, max=10), HTML()])
        clear_output()
        print(container)
        display(container)
        pbar.update(1)

# Generated at 2022-06-22 05:27:55.896102
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tnrange
    """
    from time import sleep

    total = 1000
    with tnrange(total) as t:
        for _ in t:
            sleep(0.01)



# Generated at 2022-06-22 05:28:07.418865
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import sys
    if sys.version_info[0] >= 3 and sys.version_info[1] >= 5:
        import unittest
        from unittest.mock import patch

        class TqdmNotebookClearTests(unittest.TestCase):
            @patch.object(TqdmHBox, 'close')
            @patch.object(TqdmHBox, 'clear_output')
            def test_clears_output_and_closes_hbox(self, mock_clear, mock_close):
                container = TqdmHBox()
                ipywidgets.widgets.interaction.Widget._widgets = {container}
                tqdm_widget = tqdm_notebook(unit='B', unit_scale=True, miniters=1, desc='Downloading', total=1000)
               

# Generated at 2022-06-22 05:28:13.491164
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test method __iter__ of class tqdm_notebook"""
    t = tqdm_notebook(range(3), desc="Easy!")
    assert hasattr(t, 'container') is True
    assert isinstance(t.container, TqdmHBox)
    assert hasattr(t.container, 'pbar') is True
    assert hasattr(t.container, 'children') is True

    # ensure repr works
    repr(t)

    # ensure __iter__ works
    assert list(t) == [0, 1, 2]
    # ensure __del__ works
    t.close()
    del t

    # test on exception
    def gen_failure():
        for _ in tqdm_notebook(range(3), desc="Failure!"):
            yield _
            raise ValueError

    t = gen_

# Generated at 2022-06-22 05:28:23.709817
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    from .utils import _term_move_up
    from IPython.display import clear_output

    with tqdm_notebook(total=100) as t:
        for i in range(10):
            t.set_description("Test %i" % i)
            for j in tqdm_notebook(range(5), total=5, leave=False):
                time.sleep(0.01)
            clear_output(wait=True)

            # Manually update the progress bar
            t.update(10)

    # Test cleanup on close
    t = tqdm_notebook(total=50)
    t.close()

    # Test reset
    with tqdm_notebook(total=10) as t:
        for i in range(5):
            t.update()

# Generated at 2022-06-22 05:28:30.461648
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    assert len(
        [x for x in dir(tqdm_notebook) if x.endswith('close')]) == 1


if __name__ == '__main__':
    from doctest import testmod
    from .tests import setup_root_logger
    setup_root_logger()
    testmod(name='notebook',
            globs={'tqdm_notebook': tqdm_notebook, 'trange': trange,
                   'tnrange': tnrange, 'tqdm': tqdm})

# Generated at 2022-06-22 05:28:41.589884
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.core.display import HTML as HTML_class
    t = TqdmHBox()
    assert t.__repr__() == '\r  0%|          | 0/1 [00:00<?, ?it/s]'
    t.pbar = tqdm_notebook(total=1)
    assert t.__repr__() == '\r  0%|          | 0/1 [00:00<?, ?it/s]'
    assert isinstance(t.__repr_json__(), dict)
    assert isinstance(t.__repr_json__(pretty=True), dict)
    assert isinstance(t._repr_pretty_(None), None)
    assert isinstance(t._repr_html_(), HTML_class)

# Generated at 2022-06-22 05:28:48.264279
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    l = [1, 2, 3]
    t = tqdm_notebook(l)
    l.append(4)
    assert t.__iter__()
    t.close()
    t.update = Mock()
    try:
        next(t)
    except StopIteration:
        pass
    assert t.update.call_count == 4



# Generated at 2022-06-22 05:28:50.961618
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook() as t:
        for _ in range(1, 4):
            t.update()
            t.clear()

# Generated at 2022-06-22 05:28:56.480443
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        TqdmHBox()
    except TypeError:
        pass
    else:
        raise AssertionError()

    try:
        TqdmHBox().__repr__()
    except TypeError:
        pass
    else:
        raise AssertionError()

    hb = TqdmHBox()
    with std_tqdm(total=1, disable=True) as pbar:
        hb.pbar = pbar
    assert hb.__repr__()



# Generated at 2022-06-22 05:29:08.439635
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    file = 'example_file'
    total = 5
    desc = 'desc'
    print_ncols = 5
    ret = tqdm_notebook.status_printer(file, total, desc, print_ncols)

    assert isinstance(ret, HBox)
    assert len(ret.children) == 3
    ltext, pbar, rtext = ret.children
    assert isinstance(ltext, HTML)
    assert isinstance(pbar, IProgress)
    assert isinstance(rtext, HTML)
    assert pbar.min == 0
    assert pbar.max == 5
    assert pbar.layout.width == "5px"
    assert ltext.value == 'desc'
    assert rtext.value == ''

    total = None
    print_ncols = 5
    ret = tq