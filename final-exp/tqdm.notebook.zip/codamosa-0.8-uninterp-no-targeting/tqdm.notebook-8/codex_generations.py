

# Generated at 2022-06-22 05:20:21.123313
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    try:
        from time import monotonic
    except ImportError:  # py<3.3
        from time import time as monotonic
    t = tqdm_notebook(total=1, leave=True)
    assert t._time() > monotonic()
    t.reset()
    assert t._time() == monotonic()
    t.total = 5
    sleep(1)
    t.reset()
    assert t._time() > monotonic()
    t.reset(total=10)
    assert t._time() == monotonic()
    t.reset(total=10)
    assert t._time() > monotonic()
    t.close()

# Generated at 2022-06-22 05:20:26.876875
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """
    # create a tqdm instance
    with tqdm_notebook(total=10) as pbar:
        # repeat ten times
        for i in range(10):
            # update the progress bar
            pbar.update()
    pass



# Generated at 2022-06-22 05:20:39.380071
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Unit test for `tqdm.notebook.tqdm.close()`"""
    try:
        from IPython.display import clear_output
    except ImportError:
        pytest.skip('Missing IPython.display.clear_output()')
    else:
        import os
        import sys
        import tempfile
        import traceback
        from io import TextIOWrapper
        # noinspection PyUnresolvedReferences
        from contextlib import closing

        # Setup error-raising tqdm
        _tqdm_notebook = tqdm_notebook(total=None)
        _tqdm_notebook.update = lambda n=1: n // 0  # NOQA: E731
        _tqdm_notebook.reset = lambda total=None: traceback.print_exc()
        _tq

# Generated at 2022-06-22 05:20:42.866208
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test that there is no issue with method clear of class tqdm_notebook.
    """
    # Create a tqdm_notebook object
    t = tqdm_notebook(total=10)
    # Call clear
    t.clear()


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-22 05:20:48.855165
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(None)
    if IProgress is not None:
        tqdm_notebook.status_printer(None, total=10, desc="test")

# Disable update of total in tqdm_notebook by default (backward compatibility)
setattr(tqdm_notebook, '_instant_dynamic_total', False)

# Generated at 2022-06-22 05:20:55.389393
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=1)
    assert t.displayed is False
    t.display()
    assert t.displayed is True
    t.display(close=True)
    assert t.displayed is False
    t = tqdm_notebook(total=1, leave=True)
    assert t.displayed is False
    t.display()
    assert t.displayed is True
    t.display(close=True)
    assert t.displayed is True
    t.close()
    assert t.displayed is False

# Generated at 2022-06-22 05:21:08.245410
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for `tqdm.notebook.TqdmHBox`

    Tests:
        - `__repr__`: returns `format_meter`
        - `_repr_pretty_`: calls `__repr__(True)`
        - `_repr_html_`: returns `format_dict`
        - `_repr_json_`: returns `format_dict`
    """
    from tqdm import TqdmTypeError

    hb = TqdmHBox()
    hb.pbar = pbar = tqdm_notebook(total=100)
    # default format
    assert repr(hb) == pbar.format_meter(**pbar.format_dict)
    # pretty returns "ascii" format
    assert repr(hb) == hb._

# Generated at 2022-06-22 05:21:20.423854
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm_gui

    # Test constructor
    with tqdm_notebook(total=10) as t:
        pass
    # Test configurable colors
    with tqdm_notebook(total=10, colour='purple') as t:
        pass
    # Test configurable colors
    with tqdm_notebook(total=10, colour='#00f900') as t:
        pass
    # Test reset
    t = tqdm_notebook(total=10)
    t.reset(total=100)
    t.write("%r" % t)
    t.close()
    # Test reset with unknown total
    t = tqdm_notebook(total=0)
    assert hasattr(t.container, 'layout') and t.container.layout.width == '20px'


# Generated at 2022-06-22 05:21:23.827107
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    itr = tqdm_notebook([1, 2, 3])
    try:
        itr.clear()
    except NotImplementedError:
        pass
    except:
        raise
    finally:
        itr.close()

# Generated at 2022-06-22 05:21:36.214499
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import format_sizeof
    from random import random
    from operator import add
    from time import sleep

    # Test iterables
    r = tqdm_notebook(range(10))
    assert isinstance(iter(r), type(r))
    r = tqdm_notebook(iter(range(10)))
    assert isinstance(iter(r), type(r))
    r = tqdm_notebook(list(range(10)))
    assert isinstance(iter(r), type(r))

    # Test int args
    r = tqdm_notebook(10)
    assert isinstance(iter(r), type(r))

    # Test exceptions and close
    r = tqdm_notebook(range(10))
    try:
        r.throw(Exception)
    except Exception:
        pass

# Generated at 2022-06-22 05:22:05.688203
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test for TqdmHBox.__repr__ in 'pretty mode' of IPython
    """
    # init with non-empty HBox
    std_tqdm(disable=True)
    hbox = TqdmHBox()
    assert(hbox._repr_pretty_(None) == hbox.__repr__(True))
    # init with empty HBox
    std_tqdm(disable=True)
    hbox = TqdmHBox(visible=False)
    assert(hbox._repr_pretty_(None) == hbox.__repr__(True))

# Generated at 2022-06-22 05:22:16.461339
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(total=10)
    for i in _range(5):
        t.update()

    t.reset()
    assert t.n == 0, "reset not working"
    assert t.last_print_n == 0, "reset not working"

    # The following is to test that the styles of the bar is reset as well
    for i in _range(4):
        t.update()
    t.close()
    assert t.container.children[-2].bar_style == 'success', \
        'reset not working, bar style not reset to default'

    # The following is to test that the total of the bar is reset
    t.reset()
    assert t.n == 0, "reset not working, total not reset"

# Generated at 2022-06-22 05:22:27.916130
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from random import random, randint
    from time import sleep
    from colorama import init as colorama_init
    colorama_init(strip=False)

    def test_close(total, desc, leave):
        o = tqdm_notebook(total=total, desc=desc, leave=leave)
        for _ in o:
            sleep(random() / 2)
            o.update(randint(1, 3))
        o.close()

    test_close(100, "test", False)
    test_close(100, "test", True)
    try:
        test_close(100, None, False)
        test_close(100, None, True)
    except ValueError:
        print("\x1b[31mNo desc: OK")



# Generated at 2022-06-22 05:22:31.900071
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    if IPY == 0:
        return  # Cannot test without IPython
    tqdm_hbox = TqdmHBox()
    setattr(tqdm_hbox, 'pbar', std_tqdm())
    tqdm_hbox.__repr__()

# Generated at 2022-06-22 05:22:43.961633
# Unit test for method status_printer of class tqdm_notebook

# Generated at 2022-06-22 05:22:54.918634
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test of __iter__ method of class tqdm_notebook
    """
    import math
    from time import sleep

    for i in tqdm_notebook(range(2)):
        for j in tqdm_notebook(range(3), desc='1st loop'):
            for k in tqdm_notebook(range(3), desc='2nd loop', leave=None):
                sleep(0.01)
                for l in tqdm_notebook(range(30), desc='3rd loop', leave=True):
                    sleep(0.01)
                    for m in tqdm_notebook(range(300),
                                           desc='4th loop', leave=False):
                        sleep(0.01)
                        math.sqrt(m * j * i * l * k)



# Generated at 2022-06-22 05:23:05.686557
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    test method __repr__ of class TqdmHBox.
    """
    if 'TqdmHBox' in globals():
        print("start test for class TqdmHBox.")
        #     import json
        #     import os

        #     # 1. create default TqdmHBox
        #     thb = TqdmHBox()
        #     # 2. assert __repr__ return dict
        #     # print("__repr__ return dict type: {}".format(type(thb.pbar.format_dict)))
        #     assert(type(thb.__repr__()) == dict)
        #     # 3. get __repr__ dict and save to local file
        #     dict_data = json.dumps(thb.__repr__(True))

        #     # 4

# Generated at 2022-06-22 05:23:13.489096
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Run the `tqdm_notebook.display` method in all possible states of progress.
    """
    try:
        from colorama import Fore, Style, init as colorama_init
        colorama_init(strip=False)
    except ImportError:
        class Style:
            BRIGHT, RESET_ALL = None, None

        class Fore:
            GREEN, YELLOW, RED = None, None, None

    def format_msg(bar, msg='', bar_style=None):
        if bar_style is None:  # no special color
            return msg
        if bar_style == 'danger':
            style = Fore.RED + Style.BRIGHT
        elif bar_style == 'success':
            style = Fore.GREEN + Style.BRIGHT

# Generated at 2022-06-22 05:23:23.900199
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from nose.tools import assert_equal, assert_false
    except ImportError:
        from nose2.tools import assert_equal, assert_false

    # Test close with leave=False (default)
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
    assert_equal(pbar.n, 10)
    assert_equal(pbar.last_print_n, 10)
    assert_false(pbar.displayed)

    # Test close with leave=True
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            pbar.update(1)
    assert_equal(pbar.n, 10)

# Generated at 2022-06-22 05:23:30.387860
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm as tqdm_auto
    import time
    for t in [tqdm_notebook, tqdm_auto]:
        for i in t([1, 2, 3]):
            time.sleep(0.05)
            t().clear()
        t().clear()
        time.sleep(0.1)
        t().clear()

# Generated at 2022-06-22 05:24:13.787965
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    for i in tqdm_notebook(range(3), desc='1st loop'):
        for j in tqdm_notebook(
                range(3), desc='2nd loop', leave=False, total=4):
            for k in tqdm_notebook(range(3), desc='3rd loop'):
                if k == 1:
                    tqdm.clear()
                    break
                time.sleep(0.1)



# Generated at 2022-06-22 05:24:23.403114
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    from numpy import linspace
    for _ in tnrange(10, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop', leave=False):
            for _ in trange(100):
                sleep(0.01)

    for _ in tnrange(10, desc='Training model', leave=True):
        for i in tnrange(100, desc='Epoch', leave=False):
            for b in tnrange(100, desc='Batch', leave=False):
                sleep(0.01)
    tnrange(10).objs
    tnrange(10, total=0).objs
    tnrange(10, total=2).objs
    tnrange(10, total=None).objs


# Generated at 2022-06-22 05:24:32.952434
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO
    f = StringIO()
    t = tqdm_notebook(total=1000, file=f, miniters=100, mininterval=0,
                      dynamic_ncols=False, ncols=100)
    t.display(bar_style='danger')
    t.display(bar_style='success')
    t.close()
    assert t.container.children[-2].style.bar_color == '#d62728'
    assert t.container.children[-2].style.bar_color == '#2ca02c'

# Generated at 2022-06-22 05:24:43.113426
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from sys import stdout

    n = 10

    total = None
    bar = tqdm_notebook(total=total)
    for i in range(n):
        bar.update(1)
    bar.close()
    assert bar.n == n
    assert bar.total is None

    total = n + 1
    bar = tqdm_notebook(total=total)
    for i in range(n):
        bar.update(1)
    bar.close()
    assert bar.n == n
    assert bar.total == total

    # test that order does not matter
    total = n + 1
    bar = tqdm_notebook()
    for i in range(n):
        bar.update(1)
        bar.total = total
    bar.close()
    assert bar.n == n

# Generated at 2022-06-22 05:24:47.203830
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as pbar:  # NOQA
        pbar.clear()
        pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:24:58.655193
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for `tnrange`.
    """
    v1, v2 = [], []
    with tnrange(6, desc='1st loop') as t:
        for i in t:
            v1.append(i)
    with tnrange(6, desc='2nd loop') as t:
        for i in t:
            v2.append(i)
            if i == 2:
                t.set_description('Testing:%i' % i)
    assert v1 == list(range(6)) and v1 == v2
    with tnrange(3, desc='') as t:
        for i in t:
            assert True
    with tnrange(3) as t:
        for i in t:
            assert True

# Generated at 2022-06-22 05:25:07.878669
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    t = tqdm_notebook(total=10)
    assert t.miniters == 1
    with tqdm_notebook(total=10, miniters=3) as t:
        assert t.miniters == 3
    with tqdm_notebook(total=None, miniters=3) as t:
        assert t.miniters == 3
        t.update(1)
    with tqdm_notebook(total=10, mininterval=0) as t:
        assert t.mininterval == 0
    with tqdm_notebook(total=10, mininterval=None) as t:
        assert t.mininterval == 0
        t.update(1)

# Generated at 2022-06-22 05:25:19.244050
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test with a value
    container = tqdm_notebook.status_printer(None, 50, 'Hello', ncols='100%')
    assert isinstance(container, TqdmHBox)
    ltext, pbar, rtext = container.children
    assert pbar.min == 0
    assert pbar.max == 50
    assert pbar.value == 0
    assert pbar.layout.width == "100%"
    assert ltext.value == 'Hello'
    assert rtext.value == ''
    assert pbar.bar_style == ''

    # Test with no value
    container = tqdm_notebook.status_printer(None)
    assert isinstance(container, TqdmHBox)
    ltext, pbar, rtext = container.children
    assert pbar.min == 0
   

# Generated at 2022-06-22 05:25:30.478780
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    >>> t = tqdm_notebook(total=2)
    >>> getattr(t.container, 'pbar').value == 0
    True
    >>> getattr(t.container, 'pbar').value == 1
    False
    >>> t.update()
    >>> getattr(t.container, 'pbar').value == 1
    True
    >>> getattr(t.container, 'pbar').value == 2
    False
    >>> t.update()
    >>> getattr(t.container, 'pbar').value == 2
    True
    >>> with TqdmHBox() as t:
    ...     assert(t.pbar is None)
    >>> t.pbar is None
    True
    """
    return None

# Generated at 2022-06-22 05:25:38.832797
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Create a new TQDM_NOTEBOOK object
    t = tqdm_notebook()
    # Check the reset method using the initial values of the class
    t.reset()
    assert t.n == 0
    assert t.total == None
    assert t.dynamic_ncols == True
    assert t.disable == False
    assert t.unit_scale == False
    assert t.unit == 'it'
    assert t.unit_divisor == 1000
    assert t.miniters == 1
    assert t.mininterval == 0.1
    assert t.interval == 0.1
    assert t.maxinterval == 10.0
    assert t.smoothing == 0.3
    assert t.avg_time == None
    assert t.last_print_t == None
    assert t.t0

# Generated at 2022-06-22 05:26:10.091630
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test tqdm_notebook.__iter__"""

    class TestIter(object):
        def __iter__(self):
            for i in tqdm_notebook(range(2), desc="my_bar"):
                yield i
            # using tqdm_notebook as an iterator
            for i in tqdm_notebook(range(2), desc="my_sub_bar"):
                yield i
            # using tqdm_notebook as an iterator with dynamic display
            for i in tqdm_notebook(range(4), desc="my_subsub_bar", leave=False):
                yield i
                # should not raise exception when widget not displayed
                # (ie: when loop is broken before the first iteration)

    TestIter()

# Generated at 2022-06-22 05:26:11.046370
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook.clear()

# Generated at 2022-06-22 05:26:15.748044
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(5)):
        sleep(0.1)
        assert i == tqdm_notebook.update()
        assert i == tqdm_notebook.n


# Generated at 2022-06-22 05:26:24.109234
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import TqdmDeprecationWarning
    import warnings
    warnings.simplefilter('error', TqdmDeprecationWarning)

    def error(msg):
        try:
            raise ValueError
        except ValueError:
            box = TqdmHBox(pbar=tqdm_notebook(total=10))
            box.__repr__()
        else:
            raise

    try:
        error("no error")
    except TqdmDeprecationWarning:
        assert True
    else:
        raise Exception("should have failed")

# Generated at 2022-06-22 05:26:31.661725
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    mock_pbar = type('MockPbar', (object, ), {
        'format_dict': {'total': 5, 'n': 3, 'unit': 'Unit',
                        'desc': 'Description', 'pos': 1,
                        'ascii': False, 'desc': 'desc'}
    })()
    hbox.pbar = mock_pbar
    assert hbox.__repr__() == '3/5 [=========>      ] desc | Unit'

test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:26:41.605741
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tqdm as tqdm_GUI
    from .gui import trange as trange_GUI
    from .std import tqdm as tqdm_std
    from .std import trange as trange_std
    from .utils import _range

    def disable_keyboardinterrupt_trap(tqdm_cls):
        '''mocked __exit__'''
        return tqdm_cls

    # Not needed in python 3.3+
    try:
        import unittest.mock as mock
    except ImportError:
        import mock


# Generated at 2022-06-22 05:26:52.279676
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tempfile import mkstemp
    from os import close, remove, path
    from random import randint
    from shutil import copyfileobj

    # Create original status file and copy for testing
    fd, original_file_name = mkstemp()
    close(fd)
    fd, test_file_name = mkstemp()
    close(fd)
    with open(original_file_name, "w") as original_file:
        original_file.write('{"bar_format": "{l_bar}<{bar}>{r_bar}"}')

    # Copy original status file to test status file
    with open(original_file_name, "r") as original_file:
        with open(test_file_name, "w") as test_file:
            copyfileobj(original_file, test_file)

# Generated at 2022-06-22 05:27:02.908509
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm as gtqdm

    for i in range(10):
        t = gtqdm(total=10)
        t.reset(total=20)
        t.reset(total=5)
        t.reset()  # total=None
        t.reset()  # total=None

    with gtqdm(total=10) as t:
        t.reset(total=5)
        t.reset(total=5)
        t.reset()  # total=None
        t.reset()  # total=None
        t.reset(total=15)

    for i in range(10):
        t = gtqdm(total=10)
        t.reset()  # total=None
        t.reset()  # total=None
        t.reset(total=5)


# Generated at 2022-06-22 05:27:08.843234
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    with tqdm_notebook(total=3) as t:
        t.update(2)
        time.sleep(1)
        t.update(1)
        time.sleep(2)
        # t.close() [not needed]


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:27:21.562954
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """ Unit test for method __iter__ of class tqdm_notebook """
    from .utils import _supports_unicode, _environ_cols_wrapper, _range
    from .std import tqdm as tqdm_std

    with tqdm_std(total=10) as t:
        for i in _range(4):
            t.update()
        # catching exception in the __iter__ method should work
        try:
            with tqdm_notebook(range(4), total=10, desc="tqdm_notebook", ascii=True) as t2:
                # iterate over a bad iterable to trigger an exception
                for __ in t2:
                    raise Exception
        except Exception:
            assert isinstance(t2, tqdm_notebook)
            # exception in iteration should have not

# Generated at 2022-06-22 05:27:50.371522
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox()._repr_pretty_ == TqdmHBox()._repr_html_


if __name__ == "__main__":  # pragma: no cover
    # Testing IPython/Jupyter Notebook widget

    tnrange(10, desc='1st loop')
    for i in tnrange(5, desc='2nd loop'):
        for j in tqdm(range(100000), desc='2nd inner loop', leave=False,
                      position=i):
            pass


# Generated at 2022-06-22 05:28:01.520000
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    global _range  # need to reassign _range as tnrange redefines it

    # Test status_printer

# Generated at 2022-06-22 05:28:10.165390
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    total, desc, unit, ncols = 100, 'desc', 'it', 100
    with tqdm_notebook(total=total, unit=unit, desc=desc, ncols=ncols) as t:
        for i in t:
            if i < 80:
                t.clear()  # clear previous text (if any)
                t.set_description('i=>%d' % i)
                t.refresh()
                continue
            if i >= 90:
                t.set_postfix(i=i)
                t.update()
                continue
            t.set_description_str('i=>%d' % i)
            t.update()
            if i > 10:
                t.close()
                break
    assert t.n == 11

# Generated at 2022-06-22 05:28:22.802094
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import trange, tqdm

    with tqdm(total=3, desc='Progress:') as pbar:
        assert pbar.container.layout.display == 'flex'
        assert pbar.container.layout.justify_content == 'space-between'
        assert 'Progress' in pbar.container.children[0].value
        assert pbar.container.children[1].min == 0
        assert pbar.container.children[1].max == 3

        pbar.display('')
        assert pbar.container.children[0].value == ''
        assert pbar.container.children[2].value == ''

        pbar.display()
        assert 'Progress' in pbar.container.children[0].value

# Generated at 2022-06-22 05:28:27.311838
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10, unit='B') as t:
        for i in range(5):
            t.update()



# Generated at 2022-06-22 05:28:31.638382
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for `tqdm.notebook.tnrange`.
    """
    import doctest
    doctest.testmod()



# Generated at 2022-06-22 05:28:43.169687
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from IPython.display import get_ipython
        ip = get_ipython()
        ip.kernel.do_one_iteration()
        ip.kernel.do_one_iteration()
    except:  # NOQA
        pass
    t = tqdm_notebook(total=10)
    t.update(8)
    t.close()
    t = tqdm_notebook(total=10)
    t.update(9)
    t.close()
    t = tqdm_notebook(total=10, leave=True)
    t.update(8)
    t.close()
    t = tqdm_notebook(total=10, leave=True)
    t.update(9)
    t.close()

# Generated at 2022-06-22 05:28:47.671249
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    pbar = tqdm_notebook(range(5), desc='test')
    pbar.clear()
    with patch("sys.stdout") as fake_stdout:
        pbar.display()
        assert ("\x1b" not in fake_stdout.getvalue()) and (
            "\x1b" not in sys.stdout.getvalue())


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:28:57.478248
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    test_i = TqdmHBox()
    assert test_i._repr_json_() == {}, "should return {} if no pbar"
    assert repr(test_i) == "", "should return '' if no pbar"
    test_i.pbar = tqdm_notebook(total=5)
    assert repr(test_i) == "  0%|          | 0/5 [00:00<?, ?it/s]",\
        "should return a string before the first update"
    test_i.pbar.update(1)
    assert repr(test_i) == "100%|##########| 5/5 [00:00<00:00, ?it/s]",\
        "should return a string (100%) after the last update"
    test_i.pbar.update(10)

# Generated at 2022-06-22 05:29:00.955723
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    bar = tqdm_notebook(range(5))
    bar.clear()
    bar.reset()



# Generated at 2022-06-22 05:29:53.408999
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.core.getipython import get_ipython
    from IPython.core.interactiveshell import InteractiveShell

    assert InteractiveShell == type(get_ipython())
    try:
        assert ipywidgets.version_info[:3] == (6, 0, 0)
    except NameError:
        pass

    # tqdm_notebok instance
    pbar = tqdm_notebook(total=100, unit='ticks')
    # Manually updating (otherwise is set to auto)
    pbar.n = 13
    # -1 is to place the progress bar at the "bottom" of the last display output
    #  (otherwise it's at the top, as default)
    pbar.display(pos=0)  # First display
