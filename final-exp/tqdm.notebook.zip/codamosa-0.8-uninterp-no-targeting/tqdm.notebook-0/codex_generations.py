

# Generated at 2022-06-22 05:20:19.362709
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    with tqdm(total=10) as t:
        for i in t:
            time.sleep(0.01)
            t.set_description("Desc: {0}".format(i))

    with tqdm(total=10, leave=True) as t:
        for i in t:
            time.sleep(1)
            t.set_description("Desc: {0}".format(i))

    try:
        with tqdm(total=10) as t:
            for i in t:
                time.sleep(1)
                t.set_description("Desc: {0}".format(i))
                if i > 5:
                    raise Exception("Boom!")
    except Exception:
        pass

    t = tqdm(total=10, leave=False)

# Generated at 2022-06-22 05:20:30.554223
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.auto import tqdm
    from tqdm.contrib import DummyTqdmFile

    with DummyTqdmFile() as f:
        tqdm_notebook.status_printer(f, total=10)
        for line in f.readlines():
            if tqdm.decode(line, errors='ignore', encoding='utf-8') == '<bar/>':
                break
        else:
            assert False, 'Not found the <bar/> token in the output !\n'
            'Perhaps the ipywidgets version is too old.'


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:20:37.821233
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    import warnings
    from io import StringIO
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        # Issue #918
        tmp = sys.stderr
        sys.stderr = StringIO()
        with tqdm_notebook(total=1e8) as bar:
            assert bar.ncols == 100
            assert bar.leave
            # Test auto-close of progressbar
            start_t = time.time()
            for i in range(1000000):
                pass
            assert (time.time() - start_t) < 0.2
            bar.reset(total=None)
            assert bar.ncols is None
            bar.total = None
            # Test close
            bar.close()
            bar.close()
        sys.stderr = tmp


# Generated at 2022-06-22 05:20:49.896686
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for `tqdm.notebook.tqdm.update(...)`.

    Test for the rare case when total=None and n=None, in which case
    `tqdm.notebook.tqdm` will fallback to a manual tqdm.
    """
    from .std import tqdm as std_tqdm
    std_tqdm.DEFAULT_FMT = '{l_bar}{bar}{r_bar}'
    t = tqdm_notebook(total=None, desc='test', leave=True,
                      bar_format="{l_bar} <-- {n_fmt}/{total_fmt} --> {r_bar}")
    try:
        for x in range(10):
            t.update(10)
    finally:
        t.close()

# Generated at 2022-06-22 05:20:59.726638
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from unittest import TestCase
    class TestTqdmNotebookClose(TestCase):
        def test_safe_mode(self):
            with tqdm_notebook(total=1) as pbar:
                pbar.n = 0.
                pbar.close()
                self.assertIsNone(getattr(pbar, '_instant_clear', None))

        def test_dangerous_mode(self):
            with tqdm_notebook(total=1) as pbar:
                pbar.n = 0.
                pbar.clear()  # dangerous but sometimes useful in manual mode
                pbar.close()
                self.assertIsNotNone(getattr(pbar, '_instant_clear', None))


# Generated at 2022-06-22 05:21:02.883065
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    from six.moves import xrange as range
    for _ in tqdm_notebook(range(1000)):
        pass



# Generated at 2022-06-22 05:21:15.627361
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import os
    import sys

    if sys.version_info >= (3, 3):
        t = tqdm_notebook(range(1), unit='', leave=True)
        t.reset(total=3)
        t.update(1)
        t.update(1)
        t.update(1)
        assert t._inst_last_print_t == t.last_print_t
        t.close()
        t = tqdm_notebook(range(1), unit='', leave=False)
        t.reset(total=3)
        t.update(1)
        t.update(1)
        t.update(1)
        assert t._inst_last_print_t == t.last_print_t
        t.close()



# Generated at 2022-06-22 05:21:25.460431
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from types import SimpleNamespace
    pbar = SimpleNamespace(
        n=100, total=100, desc='this is a desc', ncols=88, nmin=1,
        formatted_n=100, total_time=0.5, avg_time=0.5,
        rate='100.00', bar_format='{l_bar}<bar/>{r_bar}',
        rate_fmt='{rate:5.2f}',
        l_bar='', r_bar='', bar='',
        elapsed_s=False, elapsed=False)

# Generated at 2022-06-22 05:21:37.992622
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from .std import tqdm  # NOQA: F811
    from html.parser import HTMLParser
    from unittest import TestCase
    class HTMLParserTest(HTMLParser):
        def __init__(self, *args, **kwargs):
            self.data = []
            super(HTMLParserTest, self).__init__(*args, **kwargs)

        def handle_data(self, data):
            self.data.append(data)

    class TestTqdmHBox(TestCase):
        def setUp(self):
            self.hbox = TqdmHBox()

        def test_pretty(self):
            """
            Make sure that pretty representation does not crash
            (but does not test the content of the representation
            since it depends by the exact version of tqdm used)
            """

# Generated at 2022-06-22 05:21:39.595100
# Unit test for function tnrange
def test_tnrange():
    with tnrange(10) as t:
        for i in t:
            pass

# Generated at 2022-06-22 05:21:58.519691
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert list(tqdm_notebook(["a", "b", "c"])) == ["a", "b", "c"]
    assert list(tqdm_notebook(["d", "e", "f"], desc="FOO")) == ["d", "e", "f"]
    # Test for the error
    def f():
        raise Exception()
    try:
        for _ in tqdm_notebook(f(), desc="FOO"):
            pass
    except Exception:
        assert True
    else:
        assert False


# Generated at 2022-06-22 05:22:01.589403
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import io
    gui = tqdm_notebook(total=1)
    gui.display()
    gui.close()
    gui.container._repr_pretty_(io.StringIO(), False)

# Generated at 2022-06-22 05:22:12.939453
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests the method reset of class tqdm_notebook of module tqdm

    Run the following command from the project directory
        python -m tqdm.notebook.tqdm_notebook --test-tqdm-notebook-reset

    The method should reset the object, return the object and
    apply the new total to the progressbar.
    """
    from time import sleep

    # The tqdm_notebook object
    t = tqdm.tqdm_notebook()

    # The reset can be called with or without arguments
    t.reset()
    t.reset(total=100)

    # The method should return the object
    t = t.reset()

    # Tests if the new total was applied
    t.update(10)
    sleep(0.1)
    assert t.n == 10



# Generated at 2022-06-22 05:22:17.341683
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    total_loop = 1000
    loop_duration = 0.1
    progress_bar = tqdm_notebook(total=total_loop)
    for i in range(total_loop):
        progress_bar.update(1)
        sleep(loop_duration)
    progress_bar.close()

# Generated at 2022-06-22 05:22:28.415812
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook.
    """
    from unittest import TestCase, main

    class TestTqdmNotebookDisplay(TestCase):
        """
        Class for testing the display method.
        """
        def test_smoke(self):
            """
            Smoke test the tqdm_notebook display.
            """
            bar = tqdm_notebook(total=3)
            self.assertEqual(bar.colour, None)
            bar.colour = 'green'
            self.assertEqual(bar.colour, 'green')
            bar.update(1)
            bar.display()
            bar.clear()
            bar.update(2)
            bar.display()
            bar.close()


# Generated at 2022-06-22 05:22:35.888831
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm(range(2), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            sleep(0.01)

    # New bar with the same description but different total
    # and no `leave` prints in place of the previous bar
    for i in tqdm(range(2), desc='1st loop'):
        for j in tqdm(range(2), desc='2nd loop', leave=False):
            sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:22:47.169724
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from os import environ
    from sys import version_info
    from contextlib import contextmanager

    @contextmanager
    def _catch_warnings():
        try:  # Python >=3.6
            from warnings import catch_warnings
            with catch_warnings(record=True) as w:
                yield w
        except ImportError:  # Python <3.6
            from contextlib import _GeneratorContextManager
            from collections import deque

            class _WarningsContextManager(_GeneratorContextManager):
                """
                A context manager that copies and restores the state of
                warnings.catch_warnings.

                This is necessary because Python 2 compatibility
                disallows assigning to sys.modules.
                """

# Generated at 2022-06-22 05:22:57.346592
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=10, leave=False, desc='test') as t:
        for i in range(10):
            t.update()
    assert not t.container.children[-2].bar_style
    with tqdm_notebook(total=10, leave=False, desc='test') as t:
        for i in range(9):
            t.update()
    assert t.container.children[-2].bar_style == 'danger'
    try:
        with tqdm_notebook(total=10, leave=False, desc='test') as t:
            for i in range(9):
                t.update()
            raise Exception()
    except:
        pass
    assert not t.container.children[-2].bar_style

# Generated at 2022-06-22 05:22:58.899550
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test status printer.
    """
    # TODO: tests
    pass

# Generated at 2022-06-22 05:23:10.132639
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Check the IPython Notebook progress bar widget."""

    # noinspection PyShadowingNames
    def dummy_tqdm(t, desc, disable):
        """Dummy class with minimum required tqdm structure."""
        t.desc = desc
        t.disable = disable
        if not t.disable:
            t.container = tqdm_notebook.status_printer(None, t.total, desc)
            display(t.container)
        return t

    # Displayed
    dt = dummy_tqdm(tqdm_notebook(total=10), "test desc", False)
    assert (dt.container.pbar.bar_style == '')

    # No total
    dt = dummy_tqdm(tqdm_notebook(total=None), "test desc", False)

# Generated at 2022-06-22 05:23:54.642338
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test `close()` method of notebook class.
    """
    from time import sleep

    try:
        from IPython.display import clear_output

        t = tqdm_notebook(range(10), leave=True)
        for i in t:
            sleep(0.01)
            # clear_output(wait=True)
    finally:
        t.close()


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:24:02.390543
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import closing

    with closing(tqdm_notebook(total=1, leave=True)) as pbar:
        pbar.update(1)

    with closing(tqdm_notebook(total=1)) as pbar:
        pbar.update(1)

    with closing(tqdm_notebook(total=1, disable=True)) as pbar:
        pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:24:04.732022
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as pbar:
        pass
        assert not pbar.clear(True)


# Generated at 2022-06-22 05:24:15.563326
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        a = tqdm_notebook(total=100)
        for i in a:
            pass
    except KeyboardInterrupt:
        a.close()


if __name__ == '__main__':
    from time import sleep
    from random import randint, random

    for i in tqdm_notebook(range(100), desc='1st loop'):
        for j in tqdm_notebook(range(100), desc='2nd loop', leave=False):
            sleep(0.01)
        if random() > 0.9:
            break
    for i in tqdm_notebook(range(10), desc='3rd loop'):
        sleep(.1)
        tqdm_notebook.write("Done: {:d}".format(i))

# Generated at 2022-06-22 05:24:25.946998
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    assert repr(TqdmHBox()) == "{desc: '': 100%|##########| 5/5 [00:00<?, ?it/s]}"

# Generated at 2022-06-22 05:24:33.573195
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    pbar = IProgress(min=0, max=1)
    pbar.bar_style = 'info'
    container = TqdmHBox(children=[HTML(), pbar, HTML()])

    # Test __repr__
    assert isinstance(container.__repr__(), str)
    assert isinstance(container.__repr__(pretty=True), str)


if __name__ == '__main__':
    test_TqdmHBox()

# Generated at 2022-06-22 05:24:35.387152
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .tests import test_clear
    test_clear(tqdm_notebook)



# Generated at 2022-06-22 05:24:46.187914
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    import tqdm as tqdm_std
    from tqdm import trange
    from tqdm.contrib.concurrent import process_map

    def foo(x):
        time.sleep(0.01)
        return x

    def _test_tqdm_notebook_update():
        with trange(10) as t:
            for i in t:
                assert t.n == i
                time.sleep(0.01)

    # Test in a subprocess to avoid spurious failures due to interruption
    # in the main process (e.g. when using the "notebook" backend)
    process_map(_test_tqdm_notebook_update, range(4))

    # Test for issue https://github.com/tqdm/tqdm/issues/257

# Generated at 2022-06-22 05:24:57.965205
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    fp = tqdm_notebook.status_printer(None, 10, 'desc', ncols=100)
    assert isinstance(fp, TqdmHBox)
    assert hasattr(fp, 'pbar')
    assert hasattr(fp.pbar, 'max')

    fp = tqdm_notebook.status_printer(None, None, 'desc')
    assert fp.layout.width == "20px"
    assert fp.pbar.bar_style == 'info'

    fp = tqdm_notebook.status_printer(None, None, 'desc', ncols='100')
    assert fp.layout.width == "100%"
    assert fp.pbar.bar_style == 'info'


# Generated at 2022-06-22 05:25:07.417797
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests for `status_printer`.
    """
    if IProgress is None:
        return  # cannot test ipywidgets if ipywidgets unavailable

    # test for no total (should be deprecated)
    tn1 = tqdm_notebook(total=None)
    assert tn1.dynamic_ncols
    assert tn1.ncols == '100%'
    tn1.ncols = '20px'
    assert tn1.ncols == '20px'
    tn1.ncols = None  # autodetect
    assert tn1.ncols == '100%'

    # test with total
    tn2 = tqdm_notebook(total=10)
    assert tn2.dynamic_ncols
    assert tn

# Generated at 2022-06-22 05:25:38.565362
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import trange, tqdm
    import time
    import sys

    # Testing with a manual trange
    try:
        for i in trange(100, desc='1st loop'):
            for j in trange(5, desc='2nd loop', leave=False):
                for k in tqdm(range(100), desc='3nd loop', leave=False):
                    time.sleep(0.01)
    except:
        pass  # raise

    # Testing with a manual tqdm

# Generated at 2022-06-22 05:25:42.895040
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(2), desc='2nd loop'):
            for _ in tqdm_notebook(range(3), desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-22 05:25:54.483211
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .std import tqdm as std_tqdm
    from .std import xrange as std_xrange
    from .utils import _range

# Generated at 2022-06-22 05:26:02.764930
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    t = tqdm(total=100, desc='update')
    for _ in range(100):
        t.update()

    t.reset()
    assert t.n == 0
    assert t.container.children[-2].max == 100

    t = tqdm(iterable=range(100), desc='reset')
    for _ in t:
        pass

    t.reset()
    assert t.n == 0
    assert t.container.children[-2].max == 100

    t = tqdm(iterable=range(100), desc='reset_total')
    for _ in t:
        pass

    t.reset(new_total=400)
    assert t.n == 0
    assert t.container.children[-2].max == 400



# Generated at 2022-06-22 05:26:13.329797
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import io
    import sys
    import re

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # check if leaving the progressbar
    sys.stderr = io.StringIO()
    t = tqdm_notebook(total=100, leave=True)
    for i in t:
        if i >= 5:  # check if leaving the progressbar
            t.reset()
            break
    output = sys.stderr.getvalue()
    prog = re.compile('100%|>')
    assert True == prog.search(output)

    # check hiding the progressbar
    sys.stderr = io.StringIO()
    t = tqdm_notebook(total=100, leave=False)

# Generated at 2022-06-22 05:26:25.250471
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test with a changing total
    from contextlib import contextmanager
    from tqdm.auto import tqdm

    @contextmanager
    def tqdm_tot(*args, **kwargs):
        kwargs['total'] = None
        with tqdm(*args, **kwargs) as fp:
            fp.reset(total=3)
            yield fp

    with tqdm_tot() as fp:
        assert fp.total
        assert fp.ncols is None
        fp.update()
        assert fp.ncols is None
        fp.update()
        assert fp.ncols is None
        fp.update()
        assert fq.ncols is None



# Generated at 2022-06-22 05:26:32.323209
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Test `_repr_json_` method
    t = TqdmHBox(children=[1, 2, 3])
    t._repr_json_(None)
    t = TqdmHBox(children=[1, 2, 3])
    t.pbar = ""
    t._repr_json_(True)

    # Test `__repr__` method
    t = TqdmHBox(children=[1, 2, 3])
    str(t)
    t.pbar = object()
    str(t)

# Generated at 2022-06-22 05:26:42.004688
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from collections import Counter
    from os import listdir
    from random import random

    # test 3 tqdm_notebook instances:
    # 1. default parameter
    # 2. total = None
    # 3. total is overwritten by reset
    nb_test = 3
    nb_iter = 5
    nb_files = 5
    files = [open(file) for file in
             listdir(path='.')][:nb_files]

    # 1.
    def test_1():
        not_empty_files = 0
        for file in tqdm(files, desc="test 1"):
            if len(file.read()) > 0:
                not_empty_files += 1
        return not_empty_files

    # 2.
    def test_2():
        not_empty_files = 0

# Generated at 2022-06-22 05:26:47.231065
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tnrange

    for i in tnrange(10, desc='1st loop', leave=True):
        pass

    for i in tnrange(10, desc='2nd loop'):
        raise Exception('error!')


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:26:55.635250
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for method `__iter__` of class `tqdm.notebook.tqdm`."""
    from nose.tools import raises

    # Test that if an exception is raised, the progress bar gets stuck
    with tqdm_notebook(total=1) as pbar:
        pbar.update()
        try:
            raise Exception
        except:
            pass

    # Test that if an exception is raised, the progress bar gets red
    with raises(Exception):
        with tqdm_notebook(total=1) as pbar:
            pbar.update()
            raise Exception

