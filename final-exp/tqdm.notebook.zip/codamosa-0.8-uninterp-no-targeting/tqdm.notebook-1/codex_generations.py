

# Generated at 2022-06-22 05:20:32.103340
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit-tests for class `tqdm.notebook.TqdmHBox`.

    Returns
    -------
    errors : list
        List of exceptions raised when testing.
    """
    errors = []
    # class TqdmHBox(HBox):
    try:
        t = TqdmHBox()
        assert t._repr_json_() == {}
        assert t.__repr__() == "{}>"
        assert t.__repr__(pretty=True) == "{}>"
    except Exception as e:
        errors.append(e)

    return errors


# Generated at 2022-06-22 05:20:39.380024
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    # Only test that it works with tqdm_notebook default
    for _ in tnrange(3, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop', leave=True):
            for _ in tnrange(4, desc='3nd loop'):
                sleep(0.01)

if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:20:51.220356
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from random import random
    from time import sleep
    from unittest import TestCase
    from .gui import tqdm as tqdm_gui

    # Make a tqdm tqdm widget that does not display anything
    t = tqdm(total=10, disable=True)

    # Randomly update it
    for _ in range(10):
        t.update(int(5 * random()) + 1)

    # Reset it
    t.reset(total=5)

    # It should not have left the progress bar
    assert t.n == 5
    assert t.total == 5
    assert t.last_print_n == 5
    assert t.last_print_n == 5

    # Reset it
    t.reset()

    # It should not have left the progress bar
    assert t.n == 0
    assert t

# Generated at 2022-06-22 05:20:57.156794
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import io
    with io.StringIO() as s, redirect_stdout(s):
        with tqdm_notebook(total=10, desc="Test") as pbar:
            pbar.write("A")
            pbar.clear()
            pbar.write("B")
        assert "B" in s.getvalue()
        assert "A" not in s.getvalue()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:21:03.483366
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    # Initialize
    t = tqdm_notebook(total=4)
    # Update
    t.update()
    sleep(.1)
    t.update()
    sleep(.1)
    t.update()
    sleep(.1)
    # Close
    t.close()



# Generated at 2022-06-22 05:21:11.489622
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.auto import tqdm as tqdm_auto
    for t in [4, tqdm_auto(), None]:
        for n in [None, 100]:
            for desc in [None, "Hello World"]:
                for ncols in [None, 100, "100px", "100%", 100.0]:
                    tqdm_notebook.status_printer(t, total=n, desc=desc,
                                                 ncols=ncols)



# Generated at 2022-06-22 05:21:23.332890
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    from textwrap import dedent
    from unittest import TestCase, main
    from tqdm.notebook import tqdm_notebook
    from tqdm._tqdm import __version__ as tqdm_version

    class Tests(TestCase):

        def test_version(self):
            assert tqdm_version == '4.38.0'

        def test_tqdm(self):
            """
            Test `bar_format` including `desc` and `postfix`
            and `bar_format='{desc}: {percentage:3.0f}%|{bar}|'
            """

# Generated at 2022-06-22 05:21:33.794902
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in (True, False):
        for auto_update in (True, False):
            for disable in (True, False):
                for dynamic_ncols in (True, False):
                    for total in (None, False, 10):
                        # Instantiate a tqdm_notebook object
                        t = tqdm_notebook(total=total,
                                          disable=disable,
                                          leave=leave,
                                          dynamic_ncols=dynamic_ncols,
                                          auto_update=auto_update)
                        t.close()


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:21:45.859316
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .utils import format_sizeof
    from .std import format_interval


# Generated at 2022-06-22 05:21:52.439016
# Unit test for function tnrange
def test_tnrange():
    """
    Tests function tnrange.
    """
    from .tests import unittest

    class TnrangeTest(unittest.TestCase):
        def test_tnrange(self):
            with tnrange(6) as t:
                for _ in t:
                    pass

    unittest.main(argv=[''], verbosity=2, exit=False)

if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-22 05:22:19.438844
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import io
    import re
    from contextlib import redirect_stdout
    from textwrap import dedent

    # We fix a random seed for reproducibility
    from random import seed
    seed(42)
    from numpy.random import randint
    from numpy import power
    from tqdm._utils import _term_move_up

    hbox = TqdmHBox(children=[HTML(), IProgress(min=0, max=10), HTML()])
    hbox.pbar = std_tqdm()

    # As it is, there the bar is
    assert repr(hbox) == ''

    # Now we test all combinations of the widget formatting parameters
    for i in range(0, int(power(len(hbox.pbar.format_dict), 2))):
        hbox.pbar.reset()

        #

# Generated at 2022-06-22 05:22:29.821839
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import format_sizeof
    from sys import getsizeof
    from time import sleep

    from .std import tqdm

    pbar = tqdm_notebook(unit='byte')
    for _ in pbar:
        sleep(0.01)
        pbar.display(msg=format_sizeof(getsizeof(pbar)),
                     bar_style='info', check_delay=False)
        pbar.update()
        if pbar.n >= pbar.total / 2:
            pbar.display(msg=str(pbar.n),
                         bar_style='warning', check_delay=False)
        if pbar.n >= pbar.total:
            pbar.display(msg='Success!',
                         bar_style='success', check_delay=False)
            break

# Generated at 2022-06-22 05:22:33.707091
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10) as pbar:
        for i in range(5):
            pbar.update()
        pbar.reset(3)
        pbar.update()
        pbar.reset(5)
        for i in range(5):
            pbar.update()
    assert pbar.n == 5

# Generated at 2022-06-22 05:22:45.163636
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from .utils import format_sizeof
    from random import random

    # generation mode
    for _ in tqdm_notebook(range(10), total=10):
        for _ in tqdm_notebook(range(10)):
            pbar = tqdm_notebook(range(10), total=10, leave=False)
            for _ in pbar:
                pbar.reset(total=100)
                pbar.reset(total=0)  # reset to unknown total
                pbar.close()
                pbar.reset(total=None)

    # manual mode
    pbar = tqdm_notebook(total=10, leave=False)
    for i in range(10):
        pbar.update(1)

# Generated at 2022-06-22 05:22:48.343392
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test that clear() returns None.
    """
    t = tqdm_notebook(total=10, leave=True)
    for i in range(10):
        t.update()
    assert t.clear() is None

# Generated at 2022-06-22 05:22:55.101572
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    from time import sleep

    # total=None
    with tnrange(3, desc='1st loop') as t:
        for i in t:
            pass

    # total=3
    with tnrange(3, desc='2nd loop') as t:
        for i in t:
            pass

    # total=5
    with tnrange(5, desc='3rd loop') as t:
        for i in t:
            sleep(0.01)

# Generated at 2022-06-22 05:23:05.889396
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from warnings import filterwarnings
    filterwarnings('ignore', module=r'tqdm.std')
    with tqdm_notebook(total=10) as bar:
        # Do nothing - bar remains at 0%
        pass
    assert bar.n == 0
    bar.reset(total=100)
    assert bar.total == 100
    assert bar.n == 0
    bar.reset()
    assert bar.total is None
    assert bar.n == 0
    with tqdm_notebook(total=100) as bar:
        # Do nothing - bar remains at 0%
        pass
    assert bar.n == 0
    bar.reset(total=10)
    assert bar.total == 10
    assert bar.n == 0
    bar.reset()
    assert bar.total is None
    assert bar.n == 0


# Generated at 2022-06-22 05:23:09.064380
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.display import Markdown
    md = Markdown(str(TqdmHBox(children=[], pbar=Markdown(''))))
    assert re.match(r'<markdown>.*</markdown>', str(md))
    assert not re.search(r'\{.*\}', str(md))
    md = Markdown(str(TqdmHBox(children=[], pbar=Markdown('{bar}'))))
    assert re.match(r'<markdown>.*</markdown>', str(md))
    assert re.search(r'\{.*\}', str(md))

# Generated at 2022-06-22 05:23:19.785346
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    pbar = tqdm_notebook(total=100)
    for i in range(101):
        assert pbar.update(n=1) is None
        if i == 50:
            try:
                pbar.close()
            except AttributeError:
                pass
        sleep(0.01)


if __name__ == '__main__':
    from time import sleep

    # Test 1
    t = tqdm_notebook(total=100)
    for i in range(101):
        t.update(n=1)
        sleep(0.01)
    t.close()

    # Test 2
    t = tqdm_notebook(total=100)
    for i in range(101):
        t.update(n=1)

# Generated at 2022-06-22 05:23:27.926556
# Unit test for function tnrange
def test_tnrange():
    from sys import getsizeof
    from time import sleep
    from platform import python_version

    l = range(100)
    l = tnrange(len(l), desc="test")
    for i in l:
        sleep(0.01)
        l.set_postfix(mem_used=getsizeof(l), python=python_version())


# # Only run tests if not used as a module
# if __name__ == "__main__":
# 	test_tnrange()

# Generated at 2022-06-22 05:24:07.767744
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    notebook = tqdm_notebook(total=10)
    notebook.status_printer(total=10)
    notebook.status_printer(total=10, desc='test')
    notebook.status_printer(total=10, ncols=100)
    notebook.status_printer(total=10, ncols='100px')
    notebook.status_printer(total=10, ncols='100%')
    if IPY:
        notebook.status_printer(total=None)

if __name__ == "__main__":
    if IPY:
        test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:24:11.321915
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=1) as t:
        assert t.total == 1
        t.reset()
        assert t.total is None
        t.reset(total=2)
        assert t.total == 2

# Generated at 2022-06-22 05:24:20.985605
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Tests that tqdm_notebook is a subclass of tqdm and that
    clear does not raise an exception.
    """

    for cls in [tqdm_notebook]:
        with cls(total=3, file=sys.stdout) as pbar:
            pass

        with cls(total=3, file=sys.stdout, desc="xyz") as pbar:
            pass

        with cls(total=3, file=sys.stdout, ascii=True) as pbar:
            pass

        with cls(total=3, file=sys.stdout, ncols=200) as pbar:
            pass


# Generated at 2022-06-22 05:24:28.244221
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from nose.tools import assert_equal
    lst = list(range(3))
    bar = tqdm_notebook(lst, leave=True, ncols=100)
    assert_equal(bar.ncols, "100px")
    bar.reset()
    assert_equal(bar.ncols, "100px")
    bar.total = 5
    bar.reset()
    assert_equal(bar.ncols, None)  # bar width has no more unknown size

# Generated at 2022-06-22 05:24:30.046814
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    tnrange(3)


# Generated at 2022-06-22 05:24:40.679042
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import time
    class TqdmNotebook(tqdm_notebook):
        """
        Class for testing only, so that method status_printer is accessible.
        """
        def __init__(self, *args, **kwargs):
            kwargs['gui'] = False
            super(TqdmNotebook, self).__init__(*args, **kwargs)
    with TqdmNotebook(total=10, miniters=1) as pbar:
        # First iteration
        pbar.update()
        assert str(pbar) == '{desc}:   0%|          | 0/10 [00:00<?, ?it/s]'
        # Second iteration
        pbar.miniters += 1
        pbar.update()

# Generated at 2022-06-22 05:24:44.053024
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Unit test for method clear of class tqdm_notebook"""
    with tqdm_notebook(total=1) as t:
        t.clear()

# Generated at 2022-06-22 05:24:47.484658
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from inspect import isgenerator
    for args in [(4,), (0,), (-4,)]:
        assert isgenerator(iter(tqdm_notebook(args, leave=False))), args

# Generated at 2022-06-22 05:24:58.949023
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from IPython.display import clear_output
    from time import sleep
    from tqdm import trange, TqdmTypeError


# Generated at 2022-06-22 05:25:10.075290
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Unit test for method __repr__ of class TqdmHBox"""
    import collections
    from .std import _term_move_up
    from .utils import sizeof_fmt
    TqdmHBoxBase = collections.namedtuple("TqdmHBoxBase", "total n pos bar_format")
    pbar = TqdmHBoxBase(total=100, n=35, pos=1,
        bar_format='{l_bar}{bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]')
    tqdm_obj = TqdmHBox(children=[None, None, None])
    tqdm_obj.pbar = pbar

    # Unit test when `pbar.bar_format` contains '{bar

# Generated at 2022-06-22 05:26:09.136735
# Unit test for function tnrange
def test_tnrange():
    from .tests import pretest_posttest  # NOQA

    # Test
    with pretest_posttest(tnrange, leave=True, desc=None) as t:
        assert next(t) == 0
        t.set_description("WoW")
        assert next(t) == 1
        print("")
    return t


# Generated at 2022-06-22 05:26:12.699171
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=0, leave=False) as pbar:
        pbar.clear()
        assert pbar.container.children[-2].style.bar_color == ''

# Generated at 2022-06-22 05:26:24.860470
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests the static method tqdm_notebook.status_printer
    """
    # There is no test here because this is very specific to IPython.
    # We don't want to test the "correctness" of the bar but rather the
    # way it is displayed and how the description is handled.
    # We can test that manually by running the following code in a
    # notebook cell:

    from tqdm.notebook import tqdm_notebook
    from time import sleep
    # Initialize
    tqdm_notebook.status_printer(None, desc="Test")
    # Update
    progress = [1, 2, 3]

# Generated at 2022-06-22 05:26:34.663884
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook.clear()  # for doctests
    # for IPython < 5.3, ipywidgets was split into a separate package
    try:
        from ipywidgets import Layout, Box, Label, FloatProgress
    except ImportError:
        from IPython.html.widgets import Layout, Box, Label, FloatProgress

    # Get IPython to not display any output
    from IPython.utils.io import capture_output
    with capture_output() as io:
        tqdm_notebook.clear()  # for doctests
        # Initialize the progress bar
        bar = tqdm_notebook(total=42)

        # Check that display(bar) is called
        assert capture_output().stdout == ''

        # Initialize an empty container

# Generated at 2022-06-22 05:26:39.157760
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm._utils import _term_move_up
    a = tqdm_notebook(total=10, leave=True)
    for _ in range(3):
        a.update()
    assert a.total == 10
    assert a.n == 3
    a.reset()
    assert a.total == 10
    assert a.n == 0



# Generated at 2022-06-22 05:26:43.592089
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox()
    assert hbox.__repr__() == ''
    hbox.pbar = ''
    assert hbox.__repr__() == ''



# Generated at 2022-06-22 05:26:52.044162
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=5) as pbar:
        for i in range(5):
            pbar.update()
    try:
        with tqdm_notebook(total=5) as pbar:
            for i in range(10):
                pbar.update()
    except:
        pass
    pbar.close()
    with tqdm_notebook(total=5) as pbar:
        for i in range(10):
            pbar.update()
            if i == 4:
                raise Exception

if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-22 05:26:59.960841
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import sys

    try:
        t = tqdm_notebook([], file=sys.stderr)
        assert t.disable
    except (AttributeError, ImportError):
        pass
    else:
        t.disable = False
        t.close()


# Tested tqdm_notebook if it can be safely imported
try:
    tqdm_notebook([])
except (AttributeError, ImportError):
    tqdm_notebook = None

# Generated at 2022-06-22 05:27:03.653574
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    pbar = tqdm_notebook(total=10)
    for i in range(20):
        if i < 10:
            pbar.update()
        else:
            break
    pbar.close()

# Generated at 2022-06-22 05:27:15.312339
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    class CloseException(Exception):
        pass

    with tqdm_notebook(total=10) as t:
        for _ in t:
            if t.n == 5:
                raise CloseException()

    assert not t.displayed, 'tqdm_notebook.close() failed (1)'
    with tqdm_notebook(total=10, leave=True) as t:
        for _ in t:
            if t.n == 5:
                raise CloseException()

    assert not t.displayed, 'tqdm_notebook.close() failed (2)'
    with tqdm_notebook(total=10, leave=True, disable=True) as t:
        for _ in t:
            if t.n == 5:
                raise CloseException()
