

# Generated at 2022-06-22 05:20:20.810856
# Unit test for function tnrange
def test_tnrange():
    from .utils import format_interval
    from time import sleep
    for _ in tnrange(5, desc='1st loop'):
        for _ in tnrange(100, desc='2nd loop'):
            for _ in tnrange(300, desc='3nd loop'):
                sleep(0.01)
    for _ in tnrange(3, desc='1st loop'):
        for _ in tnrange(10, desc='2nd loop'):
            for _ in tnrange(20, desc='3nd loop'):
                sleep(0.01)

# Generated at 2022-06-22 05:20:30.095152
# Unit test for function tnrange
def test_tnrange():
    """
    A unit test to assure tnrange(*args, **kwargs)
    is equivalent to tqdm(xrange(*args), **kwargs)
    """
    L = list(range(10))
    for i, j in zip(tnrange(10), L):
        assert i == j
        assert i in L
    assert i == 9
    assert len(L) == 10
    assert L[0] == 0
    assert L[-1] == 9
    assert not L[-1] == 10



# Generated at 2022-06-22 05:20:32.134005
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook.status_printer(_, total=1), TqdmHBox)

# Generated at 2022-06-22 05:20:38.690673
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Simple `tqdm_notebook`
    list(tqdm_notebook(range(10)))

    # `tqdm_notebook` with a description
    list(tqdm_notebook(range(10), 'test'))

    # `tqdm_notebook` with non-iterable total
    list(tqdm_notebook(range(10), total=5))

    # `tqdm_notebook` with 0 delay
    with std_tqdm.external_write_mode():
        list(tqdm_notebook(range(10), delay=0))

    # `tqdm_notebook` with disable=False
    list(tqdm_notebook(range(10), disable=False))

    # `tqdm_notebook` with disable=None (=False)

# Generated at 2022-06-22 05:20:50.661639
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from IPython.display import clear_output
    from time import sleep
    from tqdm.auto import trange
    from shutil import get_terminal_size
    try:
        with trange(10) as t:
            for i in t:
                t.set_description("Updating: %d" % (i + 1))
                sleep(0.05)
    except ValueError:
        print("ValueError Exception displayed. Expected behavior")
    else:
        raise Exception("ValueError Exception not displayed")

# Generated at 2022-06-22 05:20:55.039220
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    t = tqdm_notebook(total=100, desc='tqdm_notebook test')
    for i in range(100):
        t.update(1)
        time.sleep(0.01)

# Generated at 2022-06-22 05:21:02.402709
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    for leave, total in [(False, None), (True, None), (True, 9)]:
        pbar = tqdm_notebook(leave=leave)
        if total is not None:
            pbar.total = total

        for _ in pbar:
            time.sleep(0.1)
    pbar.close()


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:21:06.063859
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=1) as pbar:
        pbar.update(1)

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:21:18.558474
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test the method `tqdm_notebook.display` that controls the
    display of the widget.
    Relies on `tqdm_notebook.__init__` being tested and correct.
    """
    from time import sleep
    from unittest import TestCase
    from tqdm.utils import _term_move_up

    N = 1000

    class MyTestCase(TestCase):
        def setUp(self):
            # Initialize a progress bar
            self.pbar = tqdm_notebook(total=N, leave=False)

    def test_misc(tc):
        # Test display without updating the bar
        tc.pbar.display()
        # Test update without displaying the bar
        tc.pbar.update()
        tc.pbar.update(tc.pbar.total)
        #

# Generated at 2022-06-22 05:21:27.613811
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=100, unit='B') as pbar:
        for i in range(10):
            pbar.update(10)
            sleep(.1)

    with tqdm_notebook(total=100, unit='B') as pbar:
        for i in range(100):
            pbar.update(1)
            sleep(.1)

    with tqdm_notebook(total=100, unit='B') as pbar:
        for i in range(1, 101):
            pbar.update(i)
            sleep(.1)

    with tqdm_notebook(total=10, desc='1st loop') as pbar:
        for i in range(10):
            pbar.update()
            sleep(.1)
        pbar

# Generated at 2022-06-22 05:21:47.876914
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test method display of class tqdm_notebook.
    """
    with tqdm(total=50000) as t:  # test with large value to avoid
                                  #  false-positive errors
        for i in range(1, t.total + 1):
            assert t.display(str(i)) == t.format_dict['n'] == i
            assert t.display(bar_style='success') == t.displayed
            assert t.display(pos=i) is None
            assert t.display(bar_style='success', check_delay=False) is None
            assert t.display(bar_style='danger') == t.displayed
            assert t.display(bar_style='info') == t.displayed
            assert t.display(close=True) is None
            t.displayed = False
           

# Generated at 2022-06-22 05:21:50.368611
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    l = tqdm_notebook(range(10), desc="test", leave=False)
    for _ in l:
        pass

# Generated at 2022-06-22 05:21:57.213821
# Unit test for function tnrange
def test_tnrange():
    import time
    with tnrange(4) as t:
        for i in t:
            assert i == t.n - 1
            time.sleep(0.1)
    time.sleep(0.3)

    with tnrange(10, 30, 2, desc='1st loop') as t:
        for i in t:
            assert i == t.n - 1
            time.sleep(0.05)
    time.sleep(0.3)

    with tnrange(10, desc='2nd loop') as t:
        for i in t:
            assert i == t.n - 1
            if i >= 3:
                t.set_description('Yeah!')
            time.sleep(0.1)


# Generated at 2022-06-22 05:22:06.600067
# Unit test for function tnrange
def test_tnrange():
    from .autonotebook import tnrange
    import inspect
    import random
    import time

    def test_f(i):
        time.sleep(random.random() / 10)
        return i * 2


# Generated at 2022-06-22 05:22:17.291206
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Testcase: travis-ci (travis-ci uses very old versions of ipython 3.2.2)
    try:
        # Testcase: ipywidgets 7.3.1 (compatible with ipython 4.x and 5.x)
        from ipywidgets import FloatProgress as IProgress
    except ImportError:
        try:
            # Testcase: travis-ci (travis-ci uses very old versions of ipython 3.2.2)
            from IPython.html.widgets import FloatProgressWidget as IProgress
        except ImportError:
            # Testcase: ipywidgets 6.0.0 (compatible with ipython 3.x)
            from IPython.html.widgets import FloatProgress as IProgress


# Generated at 2022-06-22 05:22:28.379037
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm.auto import tnrange, trange
    # Deferred import to make tests work without notebook

    # global in-notebook test
    for t in (tqdm, tnrange, trange):
        global_eval = globals()['tqdm'] == t
        for unit_scale, leave in [(1, False), (10, True)]:
            with t(total=10, unit_scale=unit_scale, leave=leave) as pbar:
                for n in pbar:
                    pass

            # check that total has been overwritten by 0
            assert pbar.total <= 0

            # check that progressbar was correctly updated
            if global_eval:
                assert pbar.container.children[1].value == pbar.total
            assert pbar.container.pbar.total == pbar.total
           

# Generated at 2022-06-22 05:22:32.305959
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    try:
        with tqdm_notebook(total=5) as pbar:
            for i in [1, 2, 3, 4, 5]:
                pbar.update(1)
                time.sleep(0.01)
    except:
        assert False
test_tqdm_notebook___iter__()

# Generated at 2022-06-22 05:22:41.501593
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    If total is reached, bar_style is not "danger", close is called

    if total is not reached, bar_style is "danger", close is not called
    """
    class DummyBar(tqdm_notebook):
        def __init__(self):
            super(DummyBar, self).__init__(disable=True)
            self.close_called = False

        def close(self):
            self.close_called = True

    db = DummyBar()
    db.total = 1
    db.n = 1
    db.close()
    assert db.close_called

    db = DummyBar()
    db.total = 1
    db.n = 1
    db.bar_style = 'danger'
    db.close()
    assert not db.close_called

    db = DummyBar

# Generated at 2022-06-22 05:22:52.874725
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Python 3.6+
    try:
        from IPython.core.interactiveshell import InteractiveShell
        get_ipython = InteractiveShell.get_ipython
    except (ImportError, AttributeError):  # Python < 3.6
        from IPython import get_ipython
    from IPython.display import clear_output
    description = 'Loading'
    total = 100
    ncols = '100px'
    tqdm_notebook.status_printer(_, total, description, ncols)

    # Python < 3.6
    try:
        InteractiveShell.get_ipython = None
    except NameError:
        pass
    print(get_ipython())
    try:
        InteractiveShell.get_ipython = get_ipython
    except NameError:
        pass
    tqdm_note

# Generated at 2022-06-22 05:23:04.819530
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import io
    import sys
    import json
    import copy
    # Modify sys.argv and sys.stdout to test the __repr__ method
    sys.argv = []
    buff = io.BytesIO()
    sys.stdout = buff

    # Start testing the constructor of class TqdmHBox
    test_pbar = TqdmHBox()
    test_pbar.pbar = tqdm_notebook()
    test_pbar.__repr__()
    test_pbar.__repr__(True)
    test_pbar._repr_json_()
    test_pbar._repr_json_(True)
    test_pbar._repr_pretty_(None)
    test_pbar.__json__() == test_pbar._repr_json_()
    data

# Generated at 2022-06-22 05:23:32.901318
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython import get_ipython
        ipython_level = get_ipython().__class__.__name__
    except Exception:
        ipython_level = "N/A"

    try:
        from traitlets import version_info as traitlets_version
    except ModuleNotFoundError:
        traitlets_version = "N/A"
    # from pprint import pprint
    # pprint(traitlets_version)


# Generated at 2022-06-22 05:23:44.630691
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm._instances.clear()
    t = tqdm_notebook(total=3)
    t.close()
    assert t.displayed  # #872
    t.reset()
    t.n = 4
    t.close()
    assert t.displayed  # #872
    t.reset()
    t.n = 3
    t.close()
    assert not t.displayed  # #872
    t.reset()
    t.total = None
    assert t.displayed  # #872
    t.close()
    assert t.displayed  # #872
    t.reset()
    assert t.displayed  # #872
    t.total = 4
    assert t.displayed  # #872
    t.close()
    assert not t.display

# Generated at 2022-06-22 05:23:54.130397
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import tqdm_notebook
    obj = tqdm_notebook()
    obj.close()
    obj.close()


if __name__ == '__main__':
    from time import sleep
    from tqdm.autonotebook import tqdm

    for _ in tqdm(range(3), total=4, desc="1st loop"):
        for _ in tqdm(range(10), desc='nested loop', leave=False):
            for _ in tqdm(range(100), desc='3rd loop', leave=False):
                sleep(0.01)
        sleep(0.1)
    print('end')

# Generated at 2022-06-22 05:24:05.551419
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test output of tqdm_notebook.status_printer method"""
    from unittest import TestCase
    from textwrap import dedent

    class TestTqdmNotebook(TestCase):
        """Test the stdout and stderr of tqdm_notebook.status_printer"""
        def test_status_printer_empty(self):
            """Test status_printer without parameters"""
            test_printer = tqdm_notebook.status_printer(fp=None)
            self.assertEqual(test_printer.children, ())

        def test_status_printer_minimal(self):
            """Test status_printer with minimal parameters"""
            test_printer = tqdm_notebook.status_printer(fp=None, total=1)

# Generated at 2022-06-22 05:24:16.233701
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from random import random
    from pytest import raises

    bar = tqdm_notebook(total=10)
    for __ in bar:
        sleep(random())
    bar.close()

    bar = tqdm_notebook(total=10)
    for __ in bar:
        # noinspection PyUnreachableCode
        if random() < 0.2:  # pragma: no cover
            break
        sleep(random())
    with raises(Exception):
        bar.close()


# Main unit test
if __name__ == '__main__':  # pragma: nocover
    from time import sleep
    from numpy.random import random
    bar = tqdm_notebook(total=5)
    for _ in bar:
        sleep(1)
    bar.close()


# Generated at 2022-06-22 05:24:19.725476
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook([1]):
        pass
    for _ in tqdm_notebook([]):  # test empty iterable
        pass
    for _ in tqdm_notebook([2, 3, 1]):
        raise ValueError()



# Generated at 2022-06-22 05:24:25.150974
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    class dummy:
        def __init__(self):
            self.val = None

        def __call__(self, val=None):
            self.val = val

    dummy_obj = dummy()

    with tqdm_notebook(desc='dummy') as d1:
        d1.container.close = dummy_obj
        d1.clear()

    assert (dummy_obj.val is None)

# Generated at 2022-06-22 05:24:34.963021
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for the `tqdm_notebook` class.
    """
    try:
        import ipywidgets
        IPY = 4
    except ImportError:  # pragma: no cover
        try:
            import IPython.html.widgets as ipywidgets
            IPY = 3
        except ImportError:
            try:
                from IPython.html.widgets import HTML
                from IPython.html.widgets import FloatProgressWidget as IProgress
                from IPython.html.widgets import HBox
                IPY = 2
            except ImportError:  # pragma: no cover
                IPY = 0
                IProgress = None
                HBox = object

# Generated at 2022-06-22 05:24:41.261891
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from .tests import test_tqdm

    class TqdmType(tqdm_notebook):
        @property
        def status_printer(self):
            return lambda *n, **kw: n[-1]

    test_tqdm(TqdmType)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-22 05:24:52.421107
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from difflib import context_diff
    def diff(a, b, fromfile='', tofile='', fromfiledate='', tofiledate='',
             n=20, lineterm=None):
        return list(context_diff(a.splitlines(1), b.splitlines(1),
                                 fromfile, tofile, fromfiledate, tofiledate,
                                 n, lineterm))

    from io import StringIO
    stream_out = StringIO()
    display = '\n'.join

# Generated at 2022-06-22 05:25:26.867923
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython import get_ipython
    ip = get_ipython()
    from IPython.core.interactiveshell import InteractiveShell
    if ip is None:  # pragma: no cover
        return
    if any([isinstance(ip, cls) for cls in [InteractiveShell,
                                            InteractiveShell.initialized()]]):
        from IPython.display import display
        display(TqdmHBox(children=[HTML(),
                                   IProgress(min=0, max=1),
                                   HTML()]))
test_TqdmHBox()

# Generated at 2022-06-22 05:25:34.657078
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    for total, n, ncols in [(None, None, None), (None, 6, None), (5, 2, 77)]:
        with tqdm_notebook(total=total, ncols=ncols) as t:
            t.update(n)
            # Test bar_style
            t.display('', bar_style='success')
            t.display('', bar_style='danger')
            t.display('', bar_style=None)


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:25:41.067553
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import time
    from tqdm import tnrange, trange, tqdm_notebook

    with tnrange(10) as t:
        for i in t:
            t.set_description('Fwrite: %d' % i)
            t.clear()
            t.close()  # or just del t
            tqdm_notebook.clear()
            tqdm_notebook.close()
            tqdm_notebook._instances.clear()

    with trange(10) as t:
        for i in t:
            t.set_description('Fwrite: %d' % i)
            t.clear()
            t.close()  # or just del t
            tqdm_notebook.clear()
            tqdm_notebook.close()
            tqdm_notebook._

# Generated at 2022-06-22 05:25:48.397674
# Unit test for function tnrange
def test_tnrange():
    from sys import version_info
    if version_info[0] >= 3:
        _range = range
    else:
        from builtins import xrange as _range
    try:
        assert list(tqdm(_range(10))) == list(_range(10))
    except AssertionError:
        raise AssertionError('tnrange is broken')


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:26:00.232709
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # import IPython.display as IPdisplay
    from time import sleep

    t = tqdm_notebook(total=100)
    for i in range(100):
        sleep(0.1)
        t.update()
    t.close()
    # IPdisplay.clear_output()

    t = tqdm_notebook(total=100)
    try:
        for i in range(100):
            sleep(0.1)
            t.update()
            raise Exception("error")
    except Exception:
        t.close()

    # IPdisplay.clear_output()

    t = tqdm_notebook(total=100)
    for i in range(100):
        sleep(0.1)
        t.update()
    t.close()

if __name__ == '__main__':
    test

# Generated at 2022-06-22 05:26:11.528789
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for d in [True, False]:
        with tqdm_notebook(total=10, desc='Test', unit='B', disable=d) as pbar:
            for i in range(10):
                pbar.update()
    # Expect a disable bar
    with tqdm_notebook(disable=True) as pbar:
        assert pbar.disable
    # Expect an empty bar
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            pass  # pragma: no cover
    # Expect an incorrect total bar (danger bar with non-completed progress)

# Generated at 2022-06-22 05:26:24.109476
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    # test 1: check that total=None does not crash anymore
    with tqdm_notebook(total=None) as pbar:
        for i in range(5):
            pbar.update()
            sleep(.5)

    # test 2: check that bar_style='danger' works now
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            try:
                if i > 5:
                    raise ValueError
                sleep(.5)
                pbar.update()
            except ValueError:
                pbar.bar_style = "danger"
                raise

    # test 3: check that set_description works now
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar

# Generated at 2022-06-22 05:26:35.219262
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys

    out = tqdm_notebook.status_printer(sys.stdout, total=None, desc="test desc")
    assert isinstance(out, TqdmHBox)

    out = tqdm_notebook.status_printer(
        sys.stdout, total=None, desc="test desc", ncols=100)
    assert isinstance(out, TqdmHBox)
    assert out.layout.width == "100px"

    out = tqdm_notebook.status_printer(
        sys.stdout, total=None, desc="test desc", ncols="100px")
    assert isinstance(out, TqdmHBox)
    assert out.layout.width == "100px"


# Generated at 2022-06-22 05:26:44.559549
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import unittest
    T = unittest.TestCase('__init__')
    t = tqdm_notebook(total=2)
    T.assertEqual(t.n, 0)
    t.update()
    with T.assertRaises(Exception):
        t.update(n=2)  # instead of t.update(n=1)
    T.assertRaises(Exception, t.update, 3)
    T.assertEqual(t.n, 1)
    t.close()

if __name__ == '__main__':
    test_tqdm_notebook_update()  # pragma: no cover

# Generated at 2022-06-22 05:26:55.286831
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython.display import clear_output
    except ImportError:
        pass

    # Unit test for method update of class tqdm_notebook
    with tqdm(total=10) as pbar:
        pbar.update()
        clear_output(wait=True)
        pbar.update()
        clear_output(wait=True)
        pbar.update()
        clear_output(wait=True)
        pbar.update()
        clear_output(wait=True)
        pbar.update()
        clear_output(wait=True)
        pbar.update()
        clear_output(wait=True)


del HBox, IProgress, HTML, IPY
del re, sys, std_tqdm
del proxy, display

# Generated at 2022-06-22 05:28:11.938481
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        from IPython.html.widgets import FloatProgress
        from IPython.html.widgets import Label, HBox
    except ImportError:
        from IPython.html.widgets import FloatProgressWidget as FloatProgress
        from IPython.html import ContainerWidget as HBox  # NOQA: F401
        from IPython.html import HTML as Label  # NOQA: F401
    from tqdm.notebook import TqdmHBox as HBox
    t = tqdm_notebook(total=1)
    assert isinstance(t.container, HBox)
    (ltext, pbar, rtext) = t.container.children
    assert isinstance(ltext, Label)
    assert isinstance(pbar, FloatProgress)
    assert isinstance(rtext, Label)

# Generated at 2022-06-22 05:28:22.951483
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # pylint: disable=protected-access
    # Simulate tqdm_notebook's internal _status_printer
    total = 10
    desc = 'tqdm_notebook tests'
    container = tqdm_notebook._status_printer(sys.stdout, total, desc)
    # Assertions
    if IPY < 4:  # No more HBox on IPython 4.x
        assert isinstance(container, HBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)
    assert container.children[0].value == desc
    assert container.children[1].value == 0
    assert container.children[1].min == 0

# Generated at 2022-06-22 05:28:32.731552
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from numpy.random import random  # NOQA

    # Test total=None
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop', leave=False):
            sleep(random())
        if i == 2:
            break
    for i in tnrange(5, desc='1st loop', leave=False):
        for j in tnrange(5, desc='2nd loop'):
            sleep(random())
        if i == 2:
            break

    # Test with total
    initial = tnrange(10, desc='1st loop')
    for i in initial:
        sleep(random())
        if i == 2:
            initial.reset(total=5)
            break
    sleep(1)
   

# Generated at 2022-06-22 05:28:43.427731
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm as tqdm_auto
    for k, v in {'tqdm': tqdm_notebook, 'tqdm_gui': tqdm_notebook,
                 'tqdm_auto': tqdm_auto}.items():
        try:
            import pytest
        except ImportError:
            from nose.tools import assert_raises

            def pytest_raises(*args):
                return assert_raises(*args)

        with pytest_raises(NotImplementedError):
            v.clear("123")


if __name__ == '__main__':
    # code to be run only if this file is NOT imported
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:28:46.631517
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    for total in [None, 120]:
        with tqdm_notebook(total=total) as pbar:
            for _ in range(10):
                pbar.display(msg='hello world')
            pbar.display(msg='', bar_style='success')
            pbar.display(msg='', close=True)

if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:28:53.448736
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import trange
    from random import random, randint
    t = tqdm_notebook(total=100)
    for i in trange(100):
        n = randint(0, 50)
        t.update(n)
        t.set_description('current: {0}'.format(i))
        t.set_postfix({'foo': random()})

# Generated at 2022-06-22 05:28:59.873142
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        import ipywidgets
    except ImportError:
        try:
            import IPython.html.widgets as ipywidgets  # NOQA: F401
        except ImportError:
            raise ImportError(
                "tqdm_notebook.clear or tqdm_notebook.tnrange "
                "require ipywidgets or IPython.html.widgets."
                "See https://ipywidgets.readthedocs.io/en/stable"
                "/user_install.html")
    try:
        from IPython.display import display  # , clear_output
    except ImportError:
        pass

    pbar = tqdm_notebook(total=100)
    display(pbar)
    for i in range(10):
        pbar.update(i)
        pbar

# Generated at 2022-06-22 05:29:11.605490
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Tests tqdm.notebook.tqdm.update() + .clear()
    """
    from .utils import _supports_unicode

    # Unit test for Python2
    if _supports_unicode:
        bar = tqdm_notebook(['a', 'b', 'c', 'd'])
        try:
            for char in bar:
                # should print lowercase ascii letters by default
                bar.set_description(char.upper())
                bar.update()
        finally:
            bar.close()

    # Unit test for Python3
    bar = tqdm_notebook(range(4), leave=True)

# Generated at 2022-06-22 05:29:17.996876
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    n = 1000
    with tqdm_notebook(total=n, desc='Testing tqdm_notebook', unit='it') as t:
        for i in range(n):
            assert hasattr(t, "update_to")
            t.update()
    assert t.n == n


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-22 05:29:18.894050
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(None)
    return True