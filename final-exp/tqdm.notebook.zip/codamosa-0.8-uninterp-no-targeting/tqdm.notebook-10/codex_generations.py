

# Generated at 2022-06-22 05:20:14.685498
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for constructor of class `TqdmHBox`.
    """
    t = tqdm_notebook(total=10, desc="test")
    t._instantiate(HBox, [t.status_printer], {})
    t.update(3)
    t.close()


if __name__ == '__main__':
    test_TqdmHBox()

# Generated at 2022-06-22 05:20:26.747948
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm
    tn = tqdm(range(3), leave=True)
    tn.close()
    tn.clear()
    tn.display()  # should not raise
    try:
        tnbar = tn.container.children[0]
        assert(tnbar.style.bar_color == "")
    except:
        pass


if __name__ == '__main__':
    from time import sleep
    l = list(range(5))
    for i in tqdm(l, desc='outer'):  # progress bar 1 (default leave=False)
        for _ in tqdm(range(50), desc='inner', leave=True):  # progress bar 2
            sleep(0.01)
    # leave the first bar

# Generated at 2022-06-22 05:20:30.535157
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    before_it = list(_range(10))
    it = tqdm_notebook(before_it, leave=False)
    after_it = list(it)
    assert(after_it == before_it)

# Generated at 2022-06-22 05:20:42.946727
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    d = {
        'n': 0,
        'total': 5,
        'unit': 'it',
        'unit_scale': True,
        'dynamic_ncols': False,
        'bar_format': u'{l_bar}<bar/>{r_bar}',
        'smoothing': 1.0,
        'ascii': False,
    }
    hbox = TqdmHBox(pbar=d)
    assert repr(hbox) == u'0/5it [<bar/>  0.00%]'

# Generated at 2022-06-22 05:20:45.521314
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    return tqdm_notebook

# Generated at 2022-06-22 05:20:57.061215
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import tqdm as std_tqdm
    from .utils import IS_PYPY
    tqdm_notebook.status_printer(None, total=1000, ncols=None)
    tqdm_notebook.status_printer(None, total=1000, ncols='100px')
    tqdm_notebook.status_printer(None, total=0, ncols=None)

    # Fallback to text bar if total is not provided
    if not IS_PYPY:  # pragma: no cover
        # tqdm_notebook.status_printer = std_tqdm.status_printer
        progress_bar = tqdm_notebook.status_printer(None, total=None, ncols=None)

# Generated at 2022-06-22 05:21:01.987154
# Unit test for function tnrange
def test_tnrange():
    for x in tnrange(4, 20, 2):  # tnrange = trange for test
        assert x in range(4, 20, 2)


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:21:14.649645
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    '''Test method close of class tqdm_notebook'''
    # with no error and leave=True, bar style should be 'success'
    tb = tqdm_notebook(total=100, leave=True)
    tb.close()
    assert tb.container.children[-2].bar_style == 'success'

    # with leave=False, close() should hide the bar (not visible)
    tb = tqdm_notebook(total=100, leave=False)
    tb.close()
    assert tb.container.visible == False
    assert tb.container.children[-2].bar_style == ''

    # with an exception in manual mode, bar style should be 'danger'
    tb = tqdm_notebook(total=100, leave=False)

# Generated at 2022-06-22 05:21:18.168352
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    for _ in tqdm_notebook(range(3)):
        sleep(.01)
        for _ in tqdm_notebook(range(500)):
            pass



# Generated at 2022-06-22 05:21:26.322974
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(4), desc='1st loop', mininterval=0.1):
        for j in tqdm_notebook(range(5), desc='2nd loop'):
            for k in tqdm_notebook(range(50), desc='3nd loop', leave=False):
                assert i == 0
                assert j == 0
                assert k == 0
                sleep(0.01)
                assert k == 0
                sleep(0.01)
                assert k == 1
            assert j == 0
            sleep(0.01)
            assert j == 1
        assert i == 0
        sleep(0.01)
        assert i == 1
    assert i == 3

# Generated at 2022-06-22 05:21:40.535748
# Unit test for function tnrange
def test_tnrange():
    "test that tnrange is working with default argument"
    for i in tnrange(3):
        assert i == 0 or i == 1 or i == 2

# Generated at 2022-06-22 05:21:52.587486
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Initialize TqdmHBox
    ltext = HTML()
    pbar = IProgress(min=0, max=1)
    pbar.value = 0.5
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])
    container.pbar = proxy(pbar)
    original_displayed = container.pbar.displayed

    # Test case 1: when progressbar is displayed
    container.pbar.displayed = True
    expected = '50%|███████████████████████        |  50 of 100 [00:00<?, ?it/s]'
    assert repr(container) == expected
    container.pbar.displayed = original_displayed

    # Test case 2: when progressbar is not displayed
    container.pbar.displayed = False
    expected

# Generated at 2022-06-22 05:22:02.667471
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Check if the method __iter__ of class tqdm_notebook returns the same result
    as the method __iter__ of class tqdm.
    """
    import numpy as np

    # generate parameters for class tqdm
    total = np.random.randint(10, 20)
    unit = 'letters'
    unit_scale = True
    unit_divisor = 1
    ascii = np.random.randint(0, 2)
    leave = np.random.randint(0, 2)
    desc = 'easy test'
    initial = np.random.randint(0, 2)
    miniters = np.random.randint(1, 3)
    mininterval = np.random.randint(1, 5)
    maxinterval = mininterval + np.random.rand

# Generated at 2022-06-22 05:22:08.394544
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in (True, False):
        for cont in (True, False):
            for i in tqdm_notebook(range(1), leave=leave):
                if not cont:
                    break
            tqdm_notebook(range(1), leave=leave, disable=True)


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:22:19.428000
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    tqdm_notebook.clear()
    tqdm_notebook.reset()
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False, miniters=1):
            for k in trange(100, desc='3nd loop', leave=False, mininterval=0.01):
                sleep(0.01)
    tqdm_notebook.clear()
    print("\n{}\n".format(tqdm_notebook))

# Generated at 2022-06-22 05:22:24.195680
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import json
    tqdm_notebook(total=2).__repr__()
    json.dumps(tqdm_notebook(total=2).__repr__(pretty=False))
    json.dumps(tqdm_notebook(total=2).__repr__(pretty=True))

# Generated at 2022-06-22 05:22:35.835107
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    from tqdm.tests import common
    for leave in [False, True, None]:
        for manual in [True, False]:
            for unit_scale, total in [(True, 10), (1, 10), (None, 0.10)]:
                for disable in [True, False]:
                    with common.CaptureStdout() as s:
                        with tqdm(
                                total=total, unit_scale=unit_scale,
                                leave=leave, manual=manual,
                                disable=disable) as t:
                            if not t.disable:
                                t.update()
                                sleep(0.5)
                                t.close()
                    if total and not disable:
                        assert (leave or not t.leave)
                        assert t.unit_scale == unit_scale

# Generated at 2022-06-22 05:22:42.328037
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook,
    that is ``for i in tqdm_notebook(...):``.
    Tests that the IPython widget can be used as a context manager.
    """
    l = range(10)
    with tqdm_notebook(l) as t:
        for i in t:
            assert i in l


# Generated at 2022-06-22 05:22:46.925016
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook(range(2)).close()


if __name__ == "__main__":
    # Unit test: run the following in Ipython with this file open
    # import tqdm.notebook as tqdm
    # tqdm.test_tqdm_notebook_close()
    pass

# Generated at 2022-06-22 05:22:52.946385
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(5):
            sleep(0.1)
            t.update()
        t.reset()
        t.leave = True
        for i in range(5):
            sleep(0.1)
            t.update()

# Generated at 2022-06-22 05:23:27.470949
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for total in [None, 3]:
        for leave in [False, True]:
            for displayed in [False, True]:
                for ncols in [None, '100%', 100]:
                    timerange = tqdm_notebook(total=total, desc='test', leave=leave,
                                              displayed=displayed, ncols=ncols)
                    for _ in timerange:
                        break
                    timerange.reset()
                    if not leave:
                        assert timerange.container.visible == False
                    assert timerange.n == 0
                    assert timerange.last_print_n == 0

# Generated at 2022-06-22 05:23:38.386972
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = std_tqdm()
    hbox = TqdmHBox(children=[], pbar=pbar)
    assert hbox.__repr__() == pbar.format_meter()


if __name__ == "__main__":  # pragma: no cover
    from ._tqdm_test import TestTqdmNested
    TestTqdmNested.extra_test_cases.append(test_TqdmHBox___repr__)
    TestTqdmNested.class_to_test = tqdm_notebook
    TestTqdmNested.setup_class()
    TestTqdmNested.test_nested_descs_and_positions()
    TestTqdmNested.test_nested_colspans()
    TestTqdmNested.test_n

# Generated at 2022-06-22 05:23:47.332185
# Unit test for function tnrange
def test_tnrange():
    with IProgress(min=0, max=100) as pbar:
        for i in tnrange(100, desc='1st loop'):
            pbar.value = i
            for j in tnrange(5, desc='2nd loop', leave=False):
                pbar.value = i + j / 5.
                for k in tnrange(50, desc='3nd loop', leave=False):
                    pbar.value = i + j / 5. + k / 250.
        with tnrange(10) as pbar2:
            for i in pbar2:
                pbar.value += 10

# Generated at 2022-06-22 05:23:58.530560
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    from tqdm.utils import _term_move_up as move_up

    # Check `tnrange`
    with tnrange(4) as t:
        for i in t:
            pass
    assert t.n == 4

    # Check `tnrange` with `leave` enabled
    with tnrange(4, leave=True) as t:
        for i in t:
            pass
    assert t.n == 4
    print("\n")
    sys.stdout.flush()

    # Check `tnrange` with `desc` enabled
    with tnrange(4, desc='Loading...') as t:
        for i in t:
            pass
    assert t.n == 4

    # Check `tnrange` with `desc` & `leave` enabled

# Generated at 2022-06-22 05:24:11.215447
# Unit test for function tnrange
def test_tnrange():
    """Simple unit test for function tnrange"""
    # xrange vs range
    try:
        xrange
    except NameError:
        xrange = range
    assert list(xrange(3, 6)) == list(range(3, 6)) == list(tnrange(3, 6, 1))
    assert list(xrange(4, 4)) == list(range(4, 4)) == list(tnrange(4, 4, 1))
    assert list(xrange(4, 4, -1)) == list(tnrange(4, 4, -1))
    # tqdm "iterable" vs tnrange
    assert list(tqdm(xrange(3, 6), 1)) == list(tqdm(range(3, 6), 1)) == \
        list(tnrange(3, 6, 1))

# Generated at 2022-06-22 05:24:16.708861
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .autonotebook import tqdm as tqdm_auto
    for tqdm_cls in [tqdm_notebook, tqdm_auto]:
        with tqdm_cls(total=10) as t:
            for i in t:
                if i == 5:
                    raise Exception("BOOM")



# Generated at 2022-06-22 05:24:18.365166
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(range(10)) as t:
        for _ in t:
            pass


# Generated at 2022-06-22 05:24:24.090726
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for the method status_printer of the class tqdm_notebook.
    """
    # Create a tqdm_notebook object
    tqdm_notebook_1 = tqdm_notebook.status_printer(
        None, total=10000, desc='Test status_printer method')

    # Test
    assert(isinstance(tqdm_notebook_1, TqdmHBox))



# Generated at 2022-06-22 05:24:28.241981
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for _ in tqdm_notebook(range(4)):
        pass
    for _ in tqdm_notebook(range(4), leave=True):
        pass



# Generated at 2022-06-22 05:24:32.886998
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test that tqdm_notebook.close does not raise an error.
    """
    for _ in tqdm_notebook([0, 1, 2]):
        pass
    tqdm_notebook([0, 1, 2]).close()

# Generated at 2022-06-22 05:26:59.807893
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Test of the TqdmHBox class
    """
    from IPython.utils.capture import capture_output
    TqdmHBox(['test'] * 3)
    # no exception is thrown so it's good
    try:
        with capture_output() as io:
            print(TqdmHBox(['test'] * 3))
        out = io.stdout
    except NameError:
        # Python2 support
        import sys
        import cStringIO
        io = cStringIO.StringIO()
        sys.stdout = io
        print(TqdmHBox(['test'] * 3))
        out = io.getvalue()
        sys.stdout = sys.__stdout__
    assert len(out) > 0

# Generated at 2022-06-22 05:27:04.796301
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    with tqdm_notebook(total=5, leave=True) as pbar:
        for _ in range(4):
            pbar.reset()
            pbar.update(1)
            sleep(0.2)


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:27:13.614590
# Unit test for function tnrange
def test_tnrange():
    """
        Test function for tnrange
    """
    from collections import Counter
    from random import randint
    from sys import stderr

    with tqdm(total=1000, file=stderr) as bar:
        for i in tnrange(100):
            for j in tnrange(10):
                for k in tnrange(10):
                    bar.update()
                    c = randint(97, 122)
                    assert c in Counter('abcdefghijklmnopqrstuvwxyz')
    assert bar.n == bar.total == 1000


# Generated at 2022-06-22 05:27:25.348109
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from unittest import TestCase
    test_case = TestCase()
    pbar = tqdm_notebook(total=2, bar_format='{n}')
    first_pbar = {'n': 0, 'l_bar': ' |', 'r_bar': '| ', 'bar': '-'}
    test_case.assertEqual(pbar.__repr__(), pbar.format_meter(**first_pbar))
    pbar.update(1)
    pbar.bar_format = '{l_bar}'
    second_pbar = {'n': 1, 'l_bar': ' |', 'r_bar': '| ', 'bar': '-'}
    test_case.assertEqual(pbar.__repr__(), pbar.format_meter(**second_pbar))


# Generated at 2022-06-22 05:27:32.472233
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    bar = tqdm_notebook(total=3)
    for i in range(1, 4):
        sleep(1)
        bar.update()
    assert bar.n == 3
    bar.reset(total=4)
    for i in range(1, 4):
        sleep(1)
        bar.update()
    assert bar.n == 3
    sleep(1)
    bar.update()
    assert bar.n == 4
    bar.reset()
    # assert bar.n == 0

# Generated at 2022-06-22 05:27:37.419238
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep

    with tqdm_notebook(total=100, leave=True) as t:
        for i in range(100):
            sleep(0.01)
            t.update(1)

# Uncomment for testing
# test_tqdm_notebook_close()

# Generated at 2022-06-22 05:27:41.504417
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as pbar:
        for i in range(4):
            if i == 2:
                pbar.update(-1)
            else:
                pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:27:51.919009
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from tqdm.auto import tqdm as tqdm_auto_module
    except ImportError:  # pragma: no cover
        return
    # monkey-patching
    _tqdm_auto = tqdm_auto_module

    def tqdm_auto_patch(*args, **kwargs):
        kwargs = kwargs.copy()
        # to make sure that no exception is thrown in IPython
        kwargs['gui'] = True
        return _tqdm_auto(*args, **kwargs)

    tqdm_auto_module = tqdm_auto_patch
    from tqdm.auto import tqdm as tqdm_auto
    from IPython import get_ipython


# Generated at 2022-06-22 05:28:02.685489
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from subprocess import call
    # Create and delete a progress bar
    t = tqdm_notebook(total=2,  gui=True)
    t.close()
    # Display the progress bar
    t = tqdm_notebook(total=2,  gui=True)
    t.display()
    t.close()
    # Create, display and delete a progress bar
    t = tqdm_notebook(total=2,  gui=True, desc="test_tqdm_notebook")
    t.display()
    t.close()
    # Test total=None
    t = tqdm_notebook(total=None,  gui=True)
    t.close()

    # Test error handling
    def buggy():
        t = tqdm_notebook(total=2,  gui=True)


# Generated at 2022-06-22 05:28:10.906721
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time

    time.sleep(0.001)
    with tqdm_notebook(total=100) as pbar:
        for i in range(5):
            time.sleep(0.01)
            pbar.update(5)

    try:
        with tqdm_notebook(total=100) as pbar:
            for i in range(5):
                time.sleep(0.01)
                pbar.update(5)
                raise Exception
    except Exception:
        assert pbar.n == 5  # test that the exceptions don't prevent loop from exiting
        # FIXME : this is not working for some reason:
        # assert pbar.bar_style == 'danger'

    with tqdm_notebook(total=0) as pbar:
        pbar.display()

# Generated at 2022-06-22 05:29:44.931893
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output
    from time import sleep
    for n in tqdm_notebook(range(3), desc="Browser"):
        sleep(1)
        clear_output()


if __name__ == '__main__':
    from time import sleep

    with tqdm_notebook(desc="Browser") as t:
        for n in range(3):
            sleep(1)
            t.clear()
            t.set_description(f"Browser: {n}")

# Generated at 2022-06-22 05:29:52.986117
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for constructor of class TqdmHBox.
    """
    # # Fails
    # t = TqdmHBox()
    # t.__repr__()

    pbar = IProgress(min=0, max=100)
    ltext = HTML()
    rtext = HTML()
    pbar.value = 0

    # DEPRECATED
    # ltext.value = ''
    # rtext.value = ''
    container = TqdmHBox(children=[ltext, pbar, rtext])
