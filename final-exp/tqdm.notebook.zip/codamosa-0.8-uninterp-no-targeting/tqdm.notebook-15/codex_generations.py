

# Generated at 2022-06-22 05:20:32.753410
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Unit test for tqdm_notebook.reset"""
    from time import sleep

    t = tqdm_notebook(total=10)
    for i in range(10):
        sleep(0.01)
        t.update()

    assert t.n == 10
    assert t.container.pbar.value == 10

    t.reset()
    assert t.n == 0
    assert t.container.pbar.value == 0

    t.reset(total=20)
    assert t.total == 20
    assert t.container.pbar.max == 20

    for i in range(20):
        sleep(0.01)
        t.update()
    # close bar
    t.close()

    assert t.n == 20
    assert t.container.pbar.value == 20

# Generated at 2022-06-22 05:20:37.303388
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    t = tqdm_notebook(range(10), display=False)
    for i in t:
        time.sleep(0.1)
        if i % 2:
            t.display(bar_style='success')
        if i == 5:
            t.display(bar_style='danger')
            raise Exception("oops")
    # t.close()  # not needed

if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:20:49.433786
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    container = TqdmHBox([HTML(), IProgress(min=0, max=10), HTML()])
    assert (repr(container)).startswith("  0%|")
    assert str(container).startswith("0%|")
    assert (repr(container)).endswith(" 100%|\n")
    assert str(container).endswith("100%|\n")

    container.pbar = tqdm()
    assert repr(container).startswith("   0%|")
    assert repr(container).endswith("  0it/s\n")
    assert str(container).startswith("0%|")
    assert str(container).endswith("0it/s\n")

    container.pbar.update(1)

# Generated at 2022-06-22 05:20:52.729115
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    box = TqdmHBox()
    assert box._repr_json_() == {}

# Generated at 2022-06-22 05:20:55.926882
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    TqdmHBox()
    TqdmHBox(None)
    TqdmHBox([])
    TqdmHBox([None])
    TqdmHBox([None for _ in _range(10)])



# Generated at 2022-06-22 05:21:08.964082
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tqdm_notebook(total=1)
    pbar.reset(total=2)
    assert pbar.total == 2
    pbar.reset()
    assert pbar.total == 2
    pbar.reset(total=3)
    assert pbar.total == 3
    # Test with total=0
    pbar.reset(total=2)
    assert pbar.total == 2
    pbar.reset(total=0)
    assert pbar.total == 0
    pbar.reset()
    assert pbar.total == 0


# see #532
if __name__ == "__main__":
    from .tests import test_tqdm
    test_tqdm(tqdm, verbose=True, nolint=True)
    test_tqdm_notebook_reset

# Generated at 2022-06-22 05:21:15.340519
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    import time
    t = tqdm_notebook(xrange(10))
    for i in t:
        time.sleep(0.1)
    del t
    t = tqdm_notebook(xrange(10))
    for i in t:
        break
    del t  # to trigger the display of the bar


# Generated at 2022-06-22 05:21:25.301464
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for kwargs in ({}, {'leave': True}):
        for total in (False, 1, 2):
            try:
                t = tqdm_notebook(total=total, **kwargs)
                t.update()
                t.close()
            except Exception as e:
                raise e


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    from os import getpid

    try:
        av = [getpid(), ipywidgets.__version__,
              ipywidgets.__file__.partition('site-packages')[2]]
    except NameError:
        av = [getpid(), 'IPY<4', '~']

# Generated at 2022-06-22 05:21:37.883381
# Unit test for function tnrange
def test_tnrange():
    try:
        from IPython.html.widgets import FloatProgress as ProgressBar
    except ImportError:
        from IPython.html.widgets import FloatProgressWidget as ProgressBar

    """
    try:
        from IPython.utils.io import capture_output
    except ImportError:
        from tqdm._tqdm_notebook import capture_output
    """

    def capture_output(func):
        def captured(*a, **k):
            return func(*a, **k)
        return captured

    def test_tnrange_int(l):
        with capture_output() as io:
            for i in tnrange(l, desc='Test', leave=True):
                pass
        assert isinstance(io.stdout_ch[-1], ProgressBar)

# Generated at 2022-06-22 05:21:44.985371
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():

    try:
        bar = tqdm_notebook()
        bar.start()
        for i in bar:
            if i > 150:
                raise Exception("Probably a bug in your code")
            if i % 5 == 0:
                bar.set_description_str("{0}".format(i))
            time.sleep(0.01)
        bar.close()
    except Exception as e:
        bar.close()
        raise e

# Generated at 2022-06-22 05:22:07.639193
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from IPython import get_ipython
    from IPython.display import HTML, display
    from IPython.core.display import Javascript, display_javascript
    import time
    import random


# Generated at 2022-06-22 05:22:18.484077
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output, get_ipython
    ip = get_ipython()
    if ip is None:
        return
    if not hasattr(ip, 'kernel'):
        return

    from time import sleep
    from random import randint
    t = tqdm_notebook(total=5)
    try:
        clear_output()
        t.display('1st')
        sleep(randint(1, 5))
        t.display('2nd')
        sleep(randint(1, 5))
        raise RuntimeError()
    except RuntimeError:
        t.display('bar_style=danger')
        sleep(randint(1, 5))
        t.display('close', close=True)
        sleep(randint(1, 5))
        clear_output()

# Generated at 2022-06-22 05:22:28.988537
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    l = tqdm_notebook(range(10), leave=True)
    for i in l:
        pass
    assert l.total == 10
    assert l.n == 10
    l.reset(total=42)
    assert l.total == 42
    assert l.n == 0
    assert l.container.children[-2].style.bar_color == 'auto'
    l.reset(total=0)
    assert l.total == 0
    assert l.n == 0
    assert l.container.children[-2].style.bar_color == 'auto'
    for i in l:
        pass
    assert l.total == 0
    assert l.n == 1
    assert l.container.children[-2].style.bar_color == 'success'

# Generated at 2022-06-22 05:22:32.306749
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    foo = TqdmHBox()
    foo.pbar = type('', (), {'format_dict': {}})()
    foo.__repr__()


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:22:35.548590
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:22:37.588632
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    return TqdmHBox(children=[HTML('<p>a'), HTML('b'), HTML('c')])

# Generated at 2022-06-22 05:22:45.564675
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .custom_pbar import CustomPbar
    pbar = CustomPbar(total=100)
    for _ in range(100):
        pbar.update(1)
    assert pbar.n == 100
    assert pbar.total == 100
    pbar.reset(total=10)
    assert pbar.n == 0
    assert pbar.total == 10
    for _ in range(10):
        pbar.update(1)
    assert pbar.n == 10
    assert pbar.total == 10



# Generated at 2022-06-22 05:22:49.362460
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import sys
    with tqdm_notebook(total=0, miniters=1, desc='foo_bar') as t:
        t.clear()
        assert t.n == 0



# Generated at 2022-06-22 05:22:50.490761
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for _ in tqdm_notebook(range(4)):
        _

# Generated at 2022-06-22 05:22:56.189035
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Initialise
    with tqdm_notebook(total=10, unit='B', unit_scale=True) as t:
        # Update
        for i in _range(10):
            t.update()
    # Close (useful to avoid IPython warning)
    t.close()


# Generated at 2022-06-22 05:23:18.576630
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import os
    import sys
    from IPython import get_ipython as ipy
    from queue import Queue, Empty as QueueEmpty
    from threading import Thread
    from time import sleep

    def get_output(q):
        """Put output of cell into queue"""
        q.put(ipy().run_cell("bar.close()"))
        q.put("done")

    # list of (type_error, i)
    errors = []

    # verify that a ValueError is raised when total = None and n < total
    for i in range(3):
        bar = tqdm_notebook(total=None, leave=True)

# Generated at 2022-06-22 05:23:26.276281
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = IProgress(min=0, max=1)
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])
    assert repr(container) == pbar.format_meter(ascii=False)


if __name__ == '__main__':
    from .utils import _test_tqdm_notebook
    _test_tqdm_notebook()

    # Run unit tests
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:23:28.891766
# Unit test for function tnrange
def test_tnrange():
    for i in tnrange(4, 0, -1):
        pass



# Generated at 2022-06-22 05:23:40.141899
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for constructor of class TqdmHBox
    """
    # Test no pbar
    obj = TqdmHBox()
    assert repr(obj) == '{}'
    assert obj._repr_json_() == {}
    assert repr(obj._repr_json_()) == '{}'
    assert repr(obj._repr_json_(True)) == '{}'
    # Test pbar
    pbar = IProgress()
    obj = TqdmHBox(pbar=pbar)
    assert repr(obj) == '??'
    # Test format_meter
    pbar.value = 1
    pbar.max = 1
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    assert repr(obj) == '???'
   

# Generated at 2022-06-22 05:23:45.587346
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    with tqdm_notebook(range(10), leave=False) as t:
        for i in t:
            t.set_description(str(i))
            clear_output()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:23:56.659055
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from io import StringIO
    # Create a file-like string to capture output
    output = StringIO()
    progress = tqdm_notebook(iterable=range(0, 100), file=output)
    for i in progress:
        assert i == progress.n
        # print a newline to force an update
        print('\n', end='', file=output)
        # sleep for 0.2s to slow down the iteration
        time.sleep(0.2)
    # expect the total number of iterations to be 100
    assert i == 99
    # expect the printed value to be 100
    assert progress.n == 100
    # expect no exceptions to be raised during progress bar updates


# Generated at 2022-06-22 05:24:09.358492
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        import unittest
    except ImportError:  # <2.7
        import unittest2 as unittest
    import sys
    if sys.version_info < (3,):
        from StringIO import StringIO
    else:
        from io import StringIO

    original_stdout = sys.stdout

    class TqdmNotebookCloseTest(unittest.TestCase):
        def test_tqdm_notebook_close_by_del(self):
            # tqdm.notebook.tqdm.close()
            sys.stdout = StringIO()
            with tqdm_notebook(total=10, desc="test-del", leave=True) as t:
                t.update()
                del t
            out = sys.stdout.getvalue()

# Generated at 2022-06-22 05:24:19.540328
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t1 = tqdm_notebook(total=10, desc="test",
                       unit="i", ascii=True, ncols=80,
                       disable=False, leave=True, file=sys.stdout)
    assert t1.total == 10
    assert t1.desc == "test"
    assert t1.unit == "i"
    assert t1.ascii == True
    assert t1.ncols == 80
    assert t1.disable == False
    assert t1.leave == True
    assert t1.file is sys.stdout

    # Test initialisation
    assert t1.format_dict["desc"] == "test"
    assert t1.format_dict["n_fmt"] == "10.00i"

# Generated at 2022-06-22 05:24:31.242842
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test tqdm_notebook close() method"""

# Generated at 2022-06-22 05:24:41.728211
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython import get_ipython  # to get IPython version
    if get_ipython is None:
        print("This test is designed for IPython")
        return
    print("Testing tqdm_notebook.display()")
    # the following code is based on the implementation of the tests in
    # test_notebook.py
    with tqdm_notebook(total=1, desc="Test bar", postfix="Test postfix") as pbar:
        assert pbar.total == 1  # min=0 and max=1
        pbar.display()  # display() is called by default on __iter__
        assert pbar.displayed  # check that the bar has been displayed
        pbar.display(msg="Test message", pos=0)  # msg is ignored
        assert pbar.displayed  # check that the bar

# Generated at 2022-06-22 05:25:02.876484
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Tests that IPython/Jupyter Notebook progressbar __repr__ is working"""
    h = TqdmHBox(children=[1, 2, 3])
    # Check fallback to ipywidgets.HBox
    assert h == [1, 2, 3]

    # Check __repr__ is json on a new instance, so user can see the widget
    pbar = IProgress(min=0, max=1)
    pbar.value = 0.5
    h = TqdmHBox(children=([], pbar, []))
    assert h == {'n': 0.5, 'total': 1}

    # Check __repr__ is pretty on a new instance, so user can see the widget
    pbar = IProgress(min=0, max=1)
    pbar.value = 0.5


# Generated at 2022-06-22 05:25:12.683947
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .tests import TestCase, __version__

    t = TestCase().assertEqual
    tqdm_gui = tqdm(total=3)
    tqdm_gui.n = 3
    # Strip version to test formatting on several versions
    repr_expected = tqdm_gui.__repr__().split('\n')
    repr_expected[0] = '100%|#######################################################################################################| 3/3'
    t(repr_expected, TqdmHBox(children=[None, None, None]).__repr__().split('\n'))
    tqdm_gui.container.pbar.bar_style = "info"
    tqdm_gui.container.pbar.value = 0
    tqdm_gui.container.pbar.max = 1
    tqdm_gui.container

# Generated at 2022-06-22 05:25:20.985548
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    from tqdm.notebook import trange
    n = 10000
    for _ in trange(n):
        for _ in trange(n):
            for _ in trange(n):
                for _ in trange(n):
                    time.sleep(1e-6)
    time.sleep(0.5)  # let the time to the widget to be displayed
    import requests

    try:
        requests.get('http://www.github.com')
    except Exception:
        pass

# Generated at 2022-06-22 05:25:32.948632
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from copy import copy
    from sys import version

    from ipywidgets import Layout
    from IPython.display import Javascript
    from tqdm import trange

    try:  # IPython < 6
        from traitlets import HasTraits, Unicode, Int
    except ImportError:
        from ipywidgets import HasTraits, Unicode, Int

    # Create a JavaScript function to update a TqdmHBox object directly

# Generated at 2022-06-22 05:25:37.351412
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    t = tqdm_notebook(total=10)
    for i in range(5):
        t.update(2)
    assert t.n == 10
    try:
        t.update()
    except:  # NOQA
        pass
    assert t.container.children[-2].bar_style == 'danger'
    t.close()



# Generated at 2022-06-22 05:25:44.994654
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import _term_move_up
    from IPython.display import clear_output
    t = tqdm_notebook(total=4, bar_format='{n}')
    for i in range(4):
        t.update(1)
        print('This is a line of stdout')
        print('This is another', file=sys.stderr)
        clear_output(wait=True)  # clear stdout/stderr
        t.display()
        print(_term_move_up() + 'this should be above')
    t.close()



# Generated at 2022-06-22 05:25:50.219972
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from collections import deque
    fp = deque()  # don't print outputs
    pbar = tqdm_notebook(total=2, file=fp)
    pbar.update()
    assert pbar.n == 1
    pbar.close()
    pbar.reset()
    assert pbar.n == 0
    pbar.close()



# Generated at 2022-06-22 05:26:01.488598
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    import sys
    try:
        from IPython.display import clear_output
    except ImportError:
        def clear_output():
            print('\r', end='')
            sys.stdout.flush()

    clear_output()  # Clear any previous output
    pbar = tqdm_notebook.status_printer(sys.stdout, 0, "Test Message")

    assert pbar.children[0].value == "Test Message"
    assert pbar.children[1].value == 0
    assert pbar.children[1].max == 0
    assert pbar.children[2].value == ''

# Note: if you want to run only the unit test, uncomment the following line:
# test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:26:10.845157
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # This is a unit test to solve issue #558
    with tqdm_notebook(total=10) as t:  # don't use range as it's incompatible with python 2
        for i in range(10):
            if i == 5:
                raise RuntimeError("test error")
            t.update()
            assert(t.n == i + 1)


if __name__ == '__main__':
    from time import sleep

    # Test basic usage
    with tqdm_notebook(total=50) as pbar:
        for i in range(50):
            sleep(0.1)
            pbar.update(1)

    # Test closing
    with tqdm_notebook(total=50) as pbar:
        for i in range(25):
            sleep(0.01)
            pbar.update

# Generated at 2022-06-22 05:26:14.786429
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # no exception
    list(tqdm_notebook(range(100)))
    # exception
    try:
        raise Exception
    except:
        pass
    list(tqdm_notebook(range(100)))

# Generated at 2022-06-22 05:26:47.282844
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from re import match
    from sys import stdout
    from time import sleep

    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update()
        pbar.clear()
        assert match(r"\r *\r$", stdout.getvalue())

    # Ensure initialisation and closing is called appropriately
    class Subclass(tqdm_notebook):
        initialised = False
        closed = False

        def __init__(self, *a, **kw):
            super(Subclass, self).__init__(*a, **kw)
            self.initialised = True

        def close(self):
            super(Subclass, self).close()
            self.closed = True


# Generated at 2022-06-22 05:26:55.264787
# Unit test for function tnrange
def test_tnrange():
    import time
    for i in tnrange(3, desc='1st loop'):
        time.sleep(0.1)
        for j in tnrange(100, desc='2nd loop'):
            time.sleep(0.01)
            for k in tqdm(tnrange(100, desc='3nd loop'), desc='4th loop',
                          leave=False, miniters=0):
                time.sleep(0.001)
                if k == 50:
                    break
if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:27:01.985484
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=3, bar_format="{desc}:{bar}") as t:
        t.set_description("test1")
        assert not t.displayed
        t.update()
        assert t.displayed
        t.set_description("test2")
        t.update()
        try:
            raise Exception("Raising for test purposes")
        except Exception:
            t.set_description("test3", refresh=True)
            t.update()
        t.close()

# Generated at 2022-06-22 05:27:07.892538
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    iterable = (x for x in range(20))
    from collections import Counter
    from random import seed, randint
    seed(0)
    counted = Counter([randint(0, 10) for _ in tqdm_notebook(iterable)])
    assert counted == Counter({0: 2, 1: 2, 2: 2, 3: 2, 4: 2, 5: 2, 6: 2, 7: 2,
                               8: 2, 9: 2, 10: 2})



# Generated at 2022-06-22 05:27:13.558225
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Tests tqdm_notebook.close()"""
    from time import sleep
    with tqdm_notebook(total=3, leave=False, position=0) as t:
        try:
            for _ in t:
                sleep(0.1)
                t.update()
        except:
            pass
        t.close()

# Generated at 2022-06-22 05:27:22.867724
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from .utils import closing
    from .std import TqdmExperimentalWarning
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", category=TqdmExperimentalWarning)
        with closing(tqdm_notebook(total=10)) as pbar:
            for _ in pbar:
                pbar.display(msg='Hello World!')
                sleep(1)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:27:28.287329
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import tqdm as _tqdm
    for i in _tqdm(tqdm_notebook(range(5)), total=5):
        assert i == i

if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:27:33.460778
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import enum
    class TestEnum(enum.Enum):
        a = 1
        b = 2
        c = 3

    with tqdm_notebook(TestEnum, total=4) as pbar:
        for _ in pbar:
            pbar.reset(total=3)
            for _ in pbar:
                pbar.reset(total=2)
                for _ in pbar:
                    pass


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:27:44.593320
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Setup tqdm_notebook
    t = tqdm_notebook(total=2, leave=False)
    t.display()
    # Check if displayed
    assert t.displayed
    # Check html escape
    t.display("<foo/>")
    assert "<foo/>" == t.container.children[0].value
    t.display("<foo/>|<bar/>")
    assert "<foo/>" == t.container.children[0].value
    assert "&lt;bar/&gt;" == t.container.children[2].value
    # Check bar style
    t.display(bar_style='success')
    assert 'success' == t.container.children[1].bar_style
    # Check close
    t.display(close=True)
    assert 'hidden' == t.container.layout.visibility

# Generated at 2022-06-22 05:27:53.948096
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Tests `tqdm.notebook.tqdm_notebook.close()` method.
    """
    from tqdm._tqdm import TqdmTypeError
    # Prepare IPython progress bar
    total = 2
    bar = IProgress(min=0, max=total)
    bar.value = 1
    bar.bar_style = 'info'
    # Setup
    t = tqdm_notebook(total=total)
    t.container = t.status_printer(t.fp, total=total)
    t.container.pbar = proxy(t)
    t.displayed = False
    t.colour = 'red'
    # Test

# Generated at 2022-06-22 05:28:46.008446
# Unit test for function tnrange

# Generated at 2022-06-22 05:28:56.846046
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import tnrange
    from .std import tqdm
    from .version import __version__
    from .utils import format_interval, format_sizeof
    from inspect import currentframe
    from sys import platform


# Generated at 2022-06-22 05:29:08.912026
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from collections import namedtuple
    import sys
    import os

    def _close_tqdm(t):
        t.close()
        return t.n

    t = tqdm_notebook(total=100, desc='test', leave=True, disable=True)
    assert t.n == 1
    assert _close_tqdm(t) == 1
    assert t.leave == True
    t = tqdm_notebook(total=100, desc='test', leave=None, disable=True)
    assert t.n == 1
    assert _close_tqdm(t) == 1
    assert t.leave == None
    t = tqdm_notebook(total=100, desc='test', leave=False, disable=True)
    assert t.n == 1

# Generated at 2022-06-22 05:29:20.558284
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox(children=[HTML(), HTML(), HTML()])
    hbox.layout.display = 'inline-flex'
    hbox.layout.flex_flow = 'row wrap'
    hbox.layout.width = '100px'
    hbox.pbar = proxy(tqdm_notebook(total=10, smoothing=0))
    hbox.pbar.n = 2
    assert re.match('\\|\s*2/10\s*\\|#\\s*4\s*\\|', str(hbox))

# Generated at 2022-06-22 05:29:31.501085
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from doctest import testmod
    from io import StringIO

    # Test coverage for tqdm_notebook method .update
    f = StringIO()
    for i in tqdm(range(10), file=f):
        pass

    # Test coverage for tqdm_notebook method .pos
    f = StringIO()
    for i in tqdm(range(10), file=f):
        i += 1  # avoid "is not used" warning

    # Test coverage for tqdm_notebook method .n
    f = StringIO()
    for i in tqdm(range(10), file=f):
        i += 1  # avoid "is not used" warning

    # Test coverage for tqdm_notebook method .refresh
    f = StringIO()

# Generated at 2022-06-22 05:29:43.846088
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from time import sleep

    a = 1.5 / 4

    for si in trange(4, ncols='100%'):
        sleep(a)
    for si in trange(4, ncols='100%', desc='Case 1.'):
        sleep(a)
    for si in trange(4, ncols='100%', desc='Case 2.'):
        sleep(a)
        if si == 3:
            raise ValueError("Raise an exception to see errors.")
    for si in trange(4, ncols='100%', desc='Case 3.'):
        sleep(a)
    for si in trange(4, ncols='100%', desc='Case 4.'):
        sleep(a)
        clear_output(wait=True)

# Generated at 2022-06-22 05:29:47.090377
# Unit test for function tnrange
def test_tnrange():
    list(tnrange(4))
    for _ in tnrange(1):
        pass
    for _ in tnrange(1, 10, 2):
        pass
    for _ in tnrange(1, 10, 2, desc='Foobar'):
        pass
    for _ in tnrange(1, 10, 2, desc='Foobar', leave=True):
        pass


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-22 05:29:57.233115
# Unit test for function tnrange
def test_tnrange():
    """Tests that `tnrange` returns expected output"""
    import subprocess
    p = subprocess.Popen('python -c "from tqdm._tqdm_notebook import tnrange, test_tnrange; test_tnrange()"',
                         shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout, stderr = p.communicate()
    # IPython 4.1.2+ doesn't have a base64 dependency
    if "No module named base64" in stderr.decode():
        return