

# Generated at 2022-06-22 05:20:29.613111
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    import time
    import inspect
    from random import randint
    from itertools import chain

    def f(tqdm_notebook_instance, tqdm_notebook_class):
        """
        Unit test function
        """
        # check that resetting to a lower value fails
        with tqdm_notebook_class(total=10) as t:
            try:
                t.reset(total=1)
            except ValueError:
                pass
            else:
                raise AssertionError("you should not be able to set the total"
                                     " to a lower value")
            assert(t.weight == float('inf'))

        # check resetting the total to `None`
        # resetting the total to `None` should

# Generated at 2022-06-22 05:20:42.285472
# Unit test for function tnrange
def test_tnrange():
    """
    Tests function `tnrange`.
    """
    import sys
    test = lambda *x, **y: map(sys.stderr.write, [''] + list(x))
    test(tnrange(10), tnrange(1))
    test(tnrange(10, 0), tnrange(1, 0))
    test(tnrange(10, 10), tnrange(1, 1))
    test(tnrange(10, 100, 10), tnrange(1, 10, 1))
    test(tnrange(100, 10, -10), tnrange(10, 1, -1))

    # Tests with just default arguments
    with tnrange() as t:
        for i in t:
            if i >= 10:
                break

# Generated at 2022-06-22 05:20:53.347130
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for desc in [None, 'Foobar', lambda: 'Foobar']:
        pbar = tqdm_notebook(["a", "b", "c", "d"], desc=desc, leave=False)
        for x in pbar:
            pbar.reset()
            pbar.update()


if __name__ == '__main__':
    tot = 10
    from time import sleep
    from random import random
    try:
        import pytest
    except ImportError:
        pass
    else:
        with pytest.raises(Exception):
            with tqdm_notebook(range(tot), disable=False) as pbar:
                for i in pbar:
                    pbar.update()
                    if random() < 0.5:
                        raise Exception("BOOM!")
    sleep(1)

# Generated at 2022-06-22 05:21:05.278447
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        iterable = xrange(1000)
    except NameError:  # pragma: no cover
        iterable = range(1000)
    for i in tqdm_notebook(iterable):
        assert i
    try:
        iterable = xrange(1000)
    except NameError:  # pragma: no cover
        iterable = range(1000)
    for i in trange(1000):
        assert i
    tqdm_notebook()

# Generated at 2022-06-22 05:21:17.839023
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: nocover
    try:
        from IPython import get_ipython  # NOQA
    except ImportError:
        return
    from time import sleep
    try:
        from pytest import raises
    except ImportError:
        return

    t = trange(2, ncols=80, desc="title")
    for _ in t:
        sleep(0.01)
    t.reset(total=4)
    for _ in t:
        sleep(0.01)

    t = trange(2, leave=True, desc="title")
    for _ in t:
        sleep(0.01)
    t.reset(total=4)
    for _ in t:
        sleep(0.01)

    t = trange(2, desc="title")

# Generated at 2022-06-22 05:21:24.164942
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=100)
    try:
        # start tqdm
        t.start()
        # test tqdm display
        t.display(bar_style='info')
        t.display(bar_style='danger')
        # test tqdm close
        t.close()
    except:  # NOQA
        pass
    finally:
        try:
            del t
        except:  # NOQA
            pass

# Generated at 2022-06-22 05:21:36.609474
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Dummy function
    def func(x, y=0):
        for i in tqdm_notebook(range(x), desc="1st loop", leave=False):
            for j in tqdm_notebook(range(y), desc="2nd loop", leave=False,
                                   bar_format="{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]"):
                pass
            print("end 2nd loop")
        print("end 1st loop")

    # Test once without unit-test mode
    # func(3, 5)

    # Test with unit-test mode
    import os
    import subprocess

# Generated at 2022-06-22 05:21:48.840961
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test if format_meter is called when str() or repr() are called on
    `tqdm_notebook.TqdmHBox`.
    """
    from .utils import format_meter
    from .utils import format_dict
    from .version import __version__
    from .gui import format_sizeof
    from .std import tqdm

    def fd(**kwargs):
        """Create format dict"""
        d = format_dict()
        d['ncols'] = kwargs.get('ncols')
        d['file'] = kwargs.get('file')
        d['desc'] = kwargs.get('desc')
        d['total'] = kwargs.get('total')
        d['n'] = kwargs.get('n')
        return d


# Generated at 2022-06-22 05:21:54.527365
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    with tqdm(total=3) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        for char in "abcd":
            pbar.update(1)
            time.sleep(0.1)



# Generated at 2022-06-22 05:22:06.102257
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class PBar(tqdm):
        def format_dict(self):
            return {
                "n": -1,
                "total": -1,
                "dynamic_ncols": False,
                "unit": "",
                "unit_scale": True,
                "desc": "desc",
                "pos": -1,
                "ncols": -1,
                "postfix": "",
                "bar_format": "{desc}{bar}{percentage}",
                "ascii": False,
            }
        @property
        def n(self):
            return -1
        @property
        def leave(self):
            return True

    hbox = TqdmHBox(None)
    pbar = PBar(disable=True)
    hbox.pbar = pbar
    assert hbox

# Generated at 2022-06-22 05:22:29.266433
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    import sys
    import sysconfig

    # In comment below:
    # npiproxy.py is required for tqdm_notebook because
    # numpy imports it and we need a proxy here for numpy
    # to be able to find it (because of a folder structure)
    # but it does not have any effect on std tqdm
    command = "python%s\nimport tqdm, sys, sysconfig\ntqdm.__repr__()"
    # "python%s\nimport tqdm, sys, sysconfig, npiproxy\ntqdm.__repr__()"
    new_env = {}
    new_env.update(os.environ)
    new_env.update({"TQDM_TEST_ENV": "1"})  # for np

# Generated at 2022-06-22 05:22:31.025886
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for n in tqdm_notebook(range(100)):
        pass



# Generated at 2022-06-22 05:22:42.275870
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm as tqdm_auto
    for i in tqdm_auto(range(1)):
        with tqdm_notebook(total=3 * 2 * 1, desc='A loop') as t:
            for j in tqdm_auto(range(3), desc='B loop', leave=False):
                for k in tqdm_auto(range(2), desc='C loop', leave=False):
                    for l in tqdm_auto(range(1), desc='D loop', leave=False):
                        t.clear()
                        t.write('Hello World!')
                        t.clear()


__all__ = ["tqdm_notebook", "tnrange", "tqdm", "trange"]

# Generated at 2022-06-22 05:22:51.289100
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from math import ceil
    from sys import stderr

    # list of (msg, signal)
    order = [
        ("msg=None", None),  # empty bar
        ("msg='foo'", 'foo'),  # empty bar + message
        ("msg='foo'", 'foo'),  # message only
        ("msg=''", ''),  # clear message
        ("msg='bar'", 'bar'),  # reset message
    ]
    for interval in (0, 0.5):
        print("====\ninterval =", interval, "\n====", file=stderr)
        with tqdm_notebook(total=len(order), leave=True, file=stderr) as t:
            for msg, signal in order:
                t.display(msg=signal)

# Generated at 2022-06-22 05:23:03.468118
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

# Generated at 2022-06-22 05:23:05.787825
# Unit test for function tnrange
def test_tnrange():
    """Test for tnrange"""
    from .tests import _test_tnrange
    _test_tnrange(tnrange)



# Generated at 2022-06-22 05:23:09.581806
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test that `tqdm.notebook.clear` can be called without error
    """
    try:
        tqdm_notebook(range(1)).clear()
    except:
        raise

if __name__ == '__main__':
    from unittest import main
    main()

# Generated at 2022-06-22 05:23:20.179543
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.utils import _term_move_up
    fp = sys.stderr
    pbar = tqdm_notebook.status_printer(fp, total=10, desc='testing')
    assert str(pbar) == '\rtesting:   0%|          | 0/10 [00:00<?, ?it/s]\n'
    assert repr(pbar).startswith('{')
    assert repr(pbar) == repr(pbar._repr_json_())
    pbar.update(3)
    assert str(pbar) == '\rtesting:  30%|███       | 3/10 [00:00<?, ?it/s]\n'
    assert repr(pbar) == repr(pbar._repr_json_())
    pbar.update(7)

# Generated at 2022-06-22 05:23:32.171081
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """
    Unit test for tqdm_notebook class. Check that non-empty bar is displayed.
    """
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # python 2.x
    from time import sleep
    from io import StringIO

    try:
        with patch('sys.stderr', new=StringIO()):
            with tqdm_notebook(total=1) as t:
                sleep(1)
                t.set_description('foo')
    except ImportError:  # #187
        print('WARNING: test_tqdm_notebook() requires `ipywidgets`')
        return
    assert 'foo' in t.container.children[-1].value

# Generated at 2022-06-22 05:23:38.437260
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    a = tqdm_notebook(range(3), desc='generated')
    sleep(0.01)
    print(next(a))
    sleep(0.01)
    print(next(a))
    sleep(0.01)
    print(next(a))
    sleep(0.01)


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-22 05:24:29.388202
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from tqdm import tqdm_notebook as tqdm_test

    # Tests:
    with tqdm_test(total=100, ncols=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)

    # Tests:
    with tqdm_test(total=100, ncols=100) as pbar:
        for i in range(100):
            sleep(0.01)
            pbar.update(1)
            pbar.set_description("Test")

# Generated at 2022-06-22 05:24:31.290886
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():

    tqdm_notebook.status_printer(None, total=10, ncols='20px')



# Generated at 2022-06-22 05:24:36.213769
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HTML
    from IPython.display import display
    from IPython.display import clear_output
    t = TqdmHBox(children=[HTML(), FloatProgress(), HTML()])
    display(t)
    print(t)
    clear_output()
    print(t)
    del t

# Generated at 2022-06-22 05:24:42.316442
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # TODO: test with multi-cols (probably can't work with current output hack)
    bar = tqdm_notebook("test", total=3, unit="B", unit_scale=False)
    bar.display()
    bar.update()
    bar.display("new_desc")
    bar.update()
    bar.display(bar_style="success")
    bar.update()
    bar.display(close=True)

# Generated at 2022-06-22 05:24:53.519278
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.testing.globalipapp import get_ipython
    get_ipython().magic('gui qt4')
    from IPython.utils.capture import capture_output
    from IPython.lib import guisupport
    from tqdm import tqdm_notebook as tqdm  # noqa
    from time import sleep
    import os

    status_printer = tqdm._instances[0].status_printer
    # Total tests
    # Test 0
    app = status_printer(None, 10, 'Testing 0', None)
    assert app.max == 10
    # Test 1
    app = status_printer(None, 100, 'Testing 1', None)
    assert app.max == 100
    # Test 2
    app = status_printer(None, None, 'Testing 2', 100)


# Generated at 2022-06-22 05:24:59.037887
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm.auto import tqdm, trange

    for total in [None, 10]:
        with tqdm(total=total, leave=True) as pbar:
            for i in trange(2, 3):
                pbar.reset(total=total)
                sleep(0.01)

    sleep(0.01)  # allow the error to occur if it is async



# Generated at 2022-06-22 05:25:04.129772
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test tqdm_notebook.status_printer method"""
    obj = tqdm_notebook.status_printer
    assert isinstance(obj, object)
    try:
        assert isinstance(obj(None, 10, 'test'), TqdmHBox)
    except (ImportError, NameError):
        pass

# Generated at 2022-06-22 05:25:07.706497
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Mainly to check that the tqdm_notebook constructor does not raise
    for _ in tqdm_notebook(range(3)):
        pass


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-22 05:25:19.133569
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    from time import sleep
    from itertools import chain
    from logging import root
    from traceback import format_exc
    from unittest import TestCase
    try:
        import nose
    except ImportError:
        try:
            import unittest2 as unittest  # Python2.6
        except ImportError:
            import unittest

    class TestTqdmNotebookClose(TestCase):
        def test_close(self):
            global bar
            bar = tqdm_notebook(xrange(10), leave=True)
            for i in bar:
                pass
            sleep(1)
            bar.reset()
            for i in bar:
                pass
            sleep(1)
            bar.reset(100)
            for i in bar:
                pass

# Generated at 2022-06-22 05:25:26.967407
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import trange
    from time import sleep

    # 0 iterations
    with trange(0) as t:
        for i in t:
            pass
    assert t.n == 0

    # 1 iteration
    with trange(1) as t:
        pass
    assert t.n == 1

    # 1 iteration
    with trange(1) as t:
        t.update()
    assert t.n == 1

    # 2 iterations
    with trange(2) as t:
        for i in t:
            sleep(0.01)
    assert t.n == 2

    # 2 iterations (manual)
    with trange(2) as t:
        for i in range(2):
            sleep(0.01)
            t.update()
    assert t.n == 2

   

# Generated at 2022-06-22 05:26:22.574065
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    test_case = tqdm_notebook.status_printer(
        None, total=10, desc='Test', ncols=100)
    assert test_case is not None
    assert test_case.children[0].value == 'Test'
    assert test_case.children[1] is not None
    assert test_case.children[2].value == ''
    assert test_case.layout.width == '100px'
    assert test_case.layout.display == 'inline-flex'
    assert test_case.layout.flex_flow == 'row wrap'

# Generated at 2022-06-22 05:26:31.009870
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    if IPY == 0:  # pragma: no cover
        return

    a = tqdm_notebook(range(10))
    assert str(a.container) == '[>                ]'

    a.update(1)
    assert str(a.container) == '[#>               ]'

    a.reset(11)
    assert str(a.container) == '[1/11>            ]'

    a.display()
    assert str(a.container) == '[1/11>            ]'

    a.close()
    assert str(a.container) == '[=============     ]'

    a.container.close()

# Generated at 2022-06-22 05:26:39.611806
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from pylab import randn
    from tqdm.notebook import tqdm
    from time import sleep

    a = randn(1000)  # array of random number

    # create a progress bar
    pbar = tqdm(total=len(a))

    # iterate over array and update progress bar
    for i in a:
        sleep(0.01)
        pbar.update(1)

    # reset pbar
    pbar.reset(10)

    # iterate over new array and update progress bar
    for i in range(10):
        sleep(0.01)
        pbar.update(1)

    # close progress bar
    pbar.close()

# Generated at 2022-06-22 05:26:51.095963
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from random import random, sample
    from IPython.display import clear_output
    from ipywidgets import IntProgress
    x = sample(range(10), 7)
    for i in tqdm_notebook(x, desc='1st loop', leave=False):
        # can also use progress bar in jupyter notebook
        pbar = IntProgress(max=len(x))
        pbar.value = i + 1
        display(pbar)
        bar = tqdm_notebook(x, desc='2nd loop')
        for j in bar:
            sleep(random() / 5.)
            bar.update()
            if random() < 0.3:  # update description (left side)
                bar.set_description('Processing {0}'.format(j + 1 + i))

# Generated at 2022-06-22 05:26:58.426633
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import io
    import sys

    fp = io.StringIO()
    _orig_stdout = sys.stdout
    sys.stdout = fp

    IPY = getattr(sys, 'ipcompleter', None) is not None

    tqdm_notebook.status_printer(file=fp, total=2, desc="test")
    if IPY:
        assert '\n'.join(["test", "  0%|",  # '|' gets replaced by <bar/>
                          "|         "  # empty progression bar
                          "[00:01<00:01,  1.00it/s]"]) \
            in fp.getvalue()

# Generated at 2022-06-22 05:27:01.486923
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from numbers import Number
    from time import sleep

    for n in tqdm_notebook(range(1, 17)):
        assert isinstance(n, Number), n
        sleep(0.01)

# Generated at 2022-06-22 05:27:08.280643
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test status printer when total is given"""
    pbar = tqdm_notebook.status_printer(file=sys.stdout, total=10)
    assert pbar.children[1].max == 10
    assert pbar.children[1].value == 0
    assert pbar.children[0].value == ""
    assert pbar.children[2].value == ""
    assert pbar.bar_style == ''
    assert pbar.layout.width == '100%'
    assert len(pbar.layout) == 1  # width='100%' is the only layout



# Generated at 2022-06-22 05:27:19.212976
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    # Note: only possible to test the static (without total) display
    # since the IPython notebook display is not compatible with CLI
    import sys
    import time

    from .utils import _term_move_up

    ipython = get_ipython()
    if ipython is None:
        raise Exception("Requires IPython/Jupyter")

    for ncols in [None, 100, "100%", "100px"]:
        for total in [None, 10, 100]:
            for leave in [True, False]:
                for desc in ["", "desc", "LONG DESCRIPTIVE TEXT"]:
                    # Initialize progress bar
                    pbar = tqdm_notebook(
                        total=total, leave=leave, desc=desc, ncols=ncols)

                    # Test display without msg

# Generated at 2022-06-22 05:27:29.364854
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from numpy import std, mean
    from numpy.random import randint, shuffle
    from numpy.random import seed as np_seed
    from random import random  # NOQA
    from random import seed as py_seed
    from math import ceil
    from copy import deepcopy
    import io
    try:
        from IPython.display import clear_output
    except ImportError:
        # fake clear_output
        def clear_output(*args):  # NOQA
            pass

    # get the terminal screen size (only correct on *nix)
    try:
        scrsize = int(open('/sys/class/tty/console/cols').read())
    except IOError:
        scrsize = 79

    # Initialise the test variables
    N_LOOPS = 100
    N

# Generated at 2022-06-22 05:27:32.511922
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test function for class tqdm_notebook (method close)."""
    with tqdm_notebook(total=10, leave=True, unit_scale=False) as t:
        for i in range(10):
            t.update()

