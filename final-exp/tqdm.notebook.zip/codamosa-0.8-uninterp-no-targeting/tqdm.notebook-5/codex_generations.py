

# Generated at 2022-06-22 05:20:19.697803
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    print("test_tqdm_notebook_reset starting...")
    total1 = 10
    total2 = 100
    with tqdm_notebook(total=total1) as t:
        assert t.total == total1
        t.reset(total=total2)
        assert t.total == total2
    assert t.total == total2
    print("test_tqdm_notebook_reset passed!")

test_tqdm_notebook_reset()


# Generated at 2022-06-22 05:20:32.057883
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from unittest import mock
    except ImportError:
        from unittest.mock import mock
    from IPython import display
    from tqdm import tqdm_notebook

    with mock.patch.object(display, "display",
                           side_effect=Exception("Display called!")):
        with tqdm_notebook(total=1,
                           leave=False,
                           dynamic_ncols=False,
                           unit_scale=True) as pbar:
            pbar.update(1)
            pbar.close()


# Generated at 2022-06-22 05:20:37.429099
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    """
    Test that tnrange contains all its elements (`__contains__`)
    and raises nothing.
    """
    elements = list(tnrange(100))
    for el in elements:
        assert el in elements
    assert elements == list(range(100))



# Generated at 2022-06-22 05:20:47.463252
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Note: this test cannot be run in IPython
    #       because we need to test clear_output on a non-displayed progress bar.
    import pytest
    with pytest.raises(Exception):
        clear_output()  # test clear_output before display
    t = tqdm_notebook(range(3))
    t.clear()
    t.close()
    assert t._previous_print_data == (None, None, '')
    with pytest.raises(Exception):
        clear_output()  # test clear_output after display
    clear_output(wait=True)  # test clear_output just after display

# Generated at 2022-06-22 05:20:54.619144
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=1)
    assert not t.disable
    # test normal behaviour
    t.close()
    t.total = 0
    t.close()
    t.total = 1
    t.n = 0
    t.close()
    # test early stop
    t.reset(total=10)
    t.update(5)
    t.close()
    # test early stop with leave=True
    t.leave = True
    t.reset(total=10)
    t.update(5)
    t.close()

# Generated at 2022-06-22 05:21:07.211770
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for the `display` method of the `tqdm_notebook` class
    """
    from re import findall
    from xml.sax.saxutils import unescape

    ncols = [None, 100, '100px', '100%']
    bar_styles = ['success', 'info', 'warning', 'danger']
    for ncol in ncols:
        for bar_style in bar_styles:
            t = tqdm_notebook(ncols=ncol, total=1, mininterval=0,
                              desc="test", bar_format='{desc}{percentage:3.0f}%')
            t.display(close=True, pos=0, total=1, bar_style=bar_style)
            # parse displayed output

# Generated at 2022-06-22 05:21:10.772416
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from unittest import TestCase
    from nose.tools import assert_raises

    class Test_tqdm_notebook_clear(TestCase):
        """
        Testing for clear().
        """

        def test_clear(self):
            tqdm_notebook.clear()

    try:
        tqdm_notebook.clear()
    except TypeError:
        return
    assert_raises(TypeError, Test_tqdm_notebook_clear("test_clear"))



# Generated at 2022-06-22 05:21:16.616297
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm.auto import tqdm
    # time.sleep is not an iterator
    try:
        with tqdm(total=10) as t:
            for _ in t:
                sleep(0.01)
    except TypeError:
        pass
    else:
        raise RuntimeError()


# Generated at 2022-06-22 05:21:19.563669
# Unit test for function tnrange
def test_tnrange():
    from .tests import test_tqdm

    test_tqdm.test_tnrange(tqdm=tqdm_notebook)



# Generated at 2022-06-22 05:21:27.343583
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._tqdm import format_size

    undefined = object()
    for n in range(1, 6):
        for bar_style in ['', 'info', 'warning', 'danger', 'success']:
            for (total, unit), size_str in dict(
                    zip(
                        zip(
                            [undefined, 50, 100, 1000],
                            [undefined, "B", "B", "KiB"]),
                        ["", "", "", "1.00"])).items():
                t = tqdm_notebook(total=total, unit=unit)

                # Display bar
                t.display(pos=n, bar_style=bar_style, close=False)

                # Display bar with new values

# Generated at 2022-06-22 05:21:43.602781
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.auto import trange
    l = [1, 2, 3]
    for i in trange(len(l)):
        l[1] = 5
    assert l == [1, 5, 3]



# Generated at 2022-06-22 05:21:47.847998
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        pbar.clear()
        pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:21:58.744434
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from unittest.mock import patch, PropertyMock
        from unittest import TestCase
        from unittest.case import skip
    except ImportError:
        from unittest2.mock import patch, PropertyMock
        from unittest2 import TestCase, skip

    from .utils import _range
    from .std import tqdm as std_tqdm

    class TestTqdmHBox(TestCase):

        def test_repr_1(self):
            """Testing TqdmHBox._repr_json_ method."""

            test_tqdm = tqdm_notebook(_range(10), unit='s', desc='ReprTest')
            test_tqdm.start()
            test_tqdm.update()
            test_tqdm.refresh()

           

# Generated at 2022-06-22 05:22:07.007106
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from tqdm._utils import save_json
        from tqdm import tqdm, trange
        from time import sleep
        from os import remove
        from gc import disable, enable
        from io import BytesIO
    except ImportError:
        return
    # Disable GC to keep results of memory profiling
    disable()

    # Save memory profiling
    try:
        import objgraph
        save_pkl = save_json
        def profile_memory():
            save_pkl("tqdm_notebook_close.pkl", objgraph.typestats())
    except ImportError:
        def profile_memory():
            pass

    # Prepare outputs
    sys.stdout = BytesIO()
    sys.stderr = BytesIO()

# Generated at 2022-06-22 05:22:09.964603
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import notebook
    import time
    num_iter = 10
    for i in notebook.tqdm(range(num_iter)):
        time.sleep(0.2)



# Generated at 2022-06-22 05:22:19.819045
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=10) as t:
        for i in range(5):
            t.update()
        t.n = 5
        t.update()


if __name__ == '__main__':  # pragma: no cover
    # Useful for interactive testing
    try:
        from IPython.core.interactiveshell import InteractiveShell
        from IPython.core.ultratb import AutoFormattedTB

        ipython = InteractiveShell.instance()
        ipython.display_formatter.ipython_formatter = AutoFormattedTB()
    except Exception:
        pass

    test_tqdm_notebook_update()


# Generated at 2022-06-22 05:22:30.542697
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from ipykernel import kernelspec
        from IPython.display import clear_output
    except ImportError:  # pragma: no cover
        # This is only tested if those packages are installed
        return

    try:
        # Clear output after repairing import
        clear_output()
        # Check current kernel type
        kernel_type = kernelspec.KernelSpecManager().get_kernel_spec().display_name
    except:  # NOQA
        # not in a kernel
        kernel_type = None

    if kernel_type not in (None, 'Python [conda env:tqdm]',
                           'Python 3 [conda env:tqdm_notebook]',
                           'Python [conda env:tqdm_notebook]'):
        # Don't test if not in tqdm notebook environment
        return

# Generated at 2022-06-22 05:22:39.767069
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import inspect
    from contextlib import contextmanager

    pbar = tqdm_notebook.status_printer(*std_tqdm.DEFAULT_ARGS)
    assert isinstance(pbar, HBox)
    assert pbar.layout.display == 'block'
    assert pbar.layout.width == "100%"
    assert pbar.layout.justify_content == 'space-between'

    pbar = tqdm_notebook.status_printer(*std_tqdm.DEFAULT_ARGS, ncols=30)
    assert pbar.layout.width == "30px"
    pbar = tqdm_notebook.status_printer(*std_tqdm.DEFAULT_ARGS, ncols="30px")
    assert pbar.layout.width == "30px"
    pbar

# Generated at 2022-06-22 05:22:41.793504
# Unit test for function tnrange
def test_tnrange():
    iterable = tnrange(10)
    assert iterable.__next__() == 0
    assert list(iterable) == list(range(1, 10))



# Generated at 2022-06-22 05:22:48.263523
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Test with default arguments
    tqdm_notebook().update()
    # Call with n=1
    tqdm_notebook().update(1)
    # Call with n=5
    tqdm_notebook().update(5)
    # Call with n=-1 (not allowed)
    try:
        tqdm_notebook().update(-1)
    except ValueError:
        pass
    # Call with n=0
    tqdm_notebook().update(0)



# Generated at 2022-06-22 05:23:02.809462
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    for i in range(5):
        tqdm_notebook.status_printer(i, i * 10, i * 10, i * 10)



# Generated at 2022-06-22 05:23:09.708922
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=1) as t:
        test = (hasattr(t, 'container') and
                hasattr(t, 'ncols') and
                hasattr(t, 'display') and
                hasattr(t.container, 'children') and
                hasattr(t.container.children[-2], 'bar_color') and
                hasattr(t, 'colour') and
                True)
        t.close()
    assert test

# Generated at 2022-06-22 05:23:20.322970
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test for simplest case
    a = tqdm_notebook()
    for i in a:
        pass
    for i in a:
        pass
    # Test for specified length
    for i in tqdm_notebook(range(10)):
        pass
    # Test for specified length and iterable
    for i in tqdm_notebook(range(10), ['a', 'b']):
        pass
    # Test for specified length and total
    for i in tqdm_notebook(range(10), total=100):
        pass
    # Test with manual iteration
    b = tqdm_notebook()
    b.__iter__()
    b.__iter__()
    b.__iter__()
    b.__iter__()
    for i in b:
        pass

# Generated at 2022-06-22 05:23:26.074088
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        iterable = tqdm_notebook(range(5))
    except ImportError:  # pragma: no cover
        return
    # Progress bar created
    iterable.reset()
    iterable.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:23:31.706411
# Unit test for function tnrange
def test_tnrange():
    try:
        from tqdm.autonotebook import tnrange
    except ImportError:
        return
    from tqdm._tqdm import trange

    with tnrange(4) as t:
        for ii in t:
            pass


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:23:43.230014
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Initialize
    status_printer = tqdm_notebook.status_printer
    file_printer = tqdm_notebook.status_printer(None)
    # Test types in returned values
    assert isinstance(status_printer(None), HBox)
    assert isinstance(file_printer, HBox)
    # Test types of attributes
    assert isinstance(status_printer(None).children, list)
    assert isinstance(file_printer.children, list)
    # Test length of at least 2 for children
    assert len(status_printer(None).children) >= 2
    assert len(file_printer.children) >= 2
    # Test whether they are all HTML objects
    assert all([isinstance(child, HTML)
                for child in status_printer(None).children])
   

# Generated at 2022-06-22 05:23:51.257200
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # # Checking with a complete bar
    hbox = TqdmHBox()
    hbox.pbar = std_tqdm(total=10)
    hbox.pbar.update(10)
    try:
        assert str(hbox) == '100%|██████████| 10/10 [00:00<?, ?it/s]'
        # # Checking with 'Pretty'
        assert repr(hbox) == '100%|██████████| 10/10 [00:00<?, ?it/s]'
    finally:
        hbox.pbar.close()



# Generated at 2022-06-22 05:23:53.612936
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=1) as t:
        assert t.total == 1



# Generated at 2022-06-22 05:24:02.165491
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    pbar = tqdm_notebook(total=1)
    assert pbar.container.layout.display != 'none'
    pbar.display(close=True)
    assert pbar.container.layout.display == 'none'
    clear_output(wait=True)

# Generated at 2022-06-22 05:24:06.964580
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox()) == "{'bar': '  0%|          | 0/0 [00:00<?, ?it/s]', 'desc': ''}"
    assert repr(TqdmHBox(pbar=None)) == "{'bar': '  0%|          | 0/0 [00:00<?, ?it/s]', 'desc': ''}"
    assert repr(TqdmHBox(pbar='')) == "{'bar': '  0%|          | 0/0 [00:00<?, ?it/s]', 'desc': ''}"
    pbar = tqdm(total=10)
    drepr = repr(TqdmHBox(pbar=pbar))

# Generated at 2022-06-22 05:24:30.389273
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class TestClass(TqdmHBox):
        def __init__(self):
            self.pbar = std_tqdm()
            self.pbar.format_dict = {
                "bar_format": "{bar} {r_bar}",
                "n": 2 / 3.,
                "total": 3,
            }
    # Test resulting json
    tc = TestClass()

# Generated at 2022-06-22 05:24:40.996901
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.utils.tests import test_widgets
    import unittest

    class DummyPBar:
        def format_dict(self):
            return {'l_bar': '', 'bar': '', 'info': 'Hello', 'r_bar': ''}

        def format_meter(self, *args, **kwargs):
            return '{l_bar}{bar}{info}{r_bar}'

    def repr_test(obj, style=None, pretty=False):
        if pretty:
            try:
                obj._repr_pretty_(pp, 0)
                return True
            except Exception as e:
                return str(e)
        else:
            try:
                return obj._repr_json_(style_name=style)
            except Exception as e:
                return str(e)


# Generated at 2022-06-22 05:24:43.745791
# Unit test for function tnrange
def test_tnrange():
    list(tnrange(5))
    list(tnrange(5, 15))
    list(tnrange(5, 15, 3))



# Generated at 2022-06-22 05:24:55.523293
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    """
    Sanity checks
    """
    # Currently only tests whether no errors are raised
    list(tnrange(3))
    list(tnrange(3, 5))
    list(tnrange(3, 5, 2))

    # Tests total
    pbar = tnrange(3, desc='testing total')
    assert pbar.total == 3
    for _ in pbar:
        pass

    pbar = tnrange(0, total=3, desc='testing total')
    assert pbar.total == 3
    for _ in pbar:
        pass

    # Test iterable
    for _ in tnrange(iter(range(3)), desc='testing iterable'):
        pass


if __name__ == '__main__':  # pragma: no cover
    test_tnrange()

# Generated at 2022-06-22 05:24:56.842457
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(range(3))
    t.clear()

# Generated at 2022-06-22 05:25:01.906803
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        for i in range(2):
            t.display_format = '{i}'
            assert not t.n
            t.clear()
            t.set_description('{i}')
            assert not t.n
            t.clear()
            assert not t.n



# Generated at 2022-06-22 05:25:11.444799
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=2) as t:
        t.display(bar_style='info')
        t.update(1)
        t.display('message', bar_style='success')
        t.close()
    # test if the display works without calling `t.update`
    t = tqdm_notebook(total=2)
    t.display('first', bar_style='info')
    t.update(1)
    t.display('second', bar_style='success')
    t.close()


if __name__ == '__main__':  # pragma: no cover
    # Testing
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:25:21.034647
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """
    import time

    # No total, auto-disable and manual mode
    bar = tqdm_notebook(total=None, disable=None, manual=True)
    for i in range(8):
        time.sleep(0.1)
        bar.update(i + 1)

    # Total, auto-disable and manual mode
    bar = tqdm_notebook(total=8, disable=None, manual=True)
    for i in range(8):
        time.sleep(0.1)
        bar.update(i + 1)

# Generated at 2022-06-22 05:25:33.020547
# Unit test for function tnrange
def test_tnrange():
    """
    Tests that `tnrange` creates an `HBox` with a `FloatProgress` child
    widget of the expected length.
    """
    expected_len = 20
    progress_bar = tnrange(expected_len)
    assert progress_bar.total == expected_len
    assert len(progress_bar) == expected_len

    # Check that the widget is of the correct type
    assert isinstance(progress_bar.container, TqdmHBox)
    assert isinstance(progress_bar.container.children[1], IProgress)

    # Check that the widget has the correct progress length
    progress_bar = tnrange(expected_len, desc='Testing')
    assert progress_bar.total == expected_len
    assert len(progress_bar) == expected_len
    progress_bar.close()



# Generated at 2022-06-22 05:25:38.308921
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        iterable = range(5)
        h = tqdm_notebook(iterable, leave=False)
        for i in h:
            pass
        assert not h.container.visible
        h = tqdm_notebook(iterable, leave=True)
        for i in h:
            pass
        assert h.container.visible
    except Exception as e:
        # tqdm_notebook is not installed
        assert e.__class__.__name__ == 'ImportError'

# Generated at 2022-06-22 05:26:12.459857
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_equal, assert_not_equal, raises
    from nose import with_setup

    tb = tqdm_notebook(range(10))

    for i, _ in enumerate(tb):
        assert_equal(tb.n, i + 1)
        # TODO: waiting for ipywidgets PR https://github.com/jupyter-widgets/ipywidgets/pull/1856
        #       to allow test of bar style
        # assert_equal(tb.colour, 'blue')
    assert_equal(tb.n, i + 1)

    @with_setup(tb.reset, tb.close)
    def test_with_error():
        for _ in tb:
            if tb.n >= 5:
                raise Exception
        # TODO:

# Generated at 2022-06-22 05:26:23.370546
# Unit test for function tnrange
def test_tnrange():
    from io import StringIO
    from time import sleep
    with StringIO() as f:
        for i in tnrange(4, file=f):
            sleep(0.5)
        assert '\r    100%|██████████| 4/4 [00:02<00:00,  1.25it/s]\n' in f.getvalue()
    with StringIO() as f:
        for i in tnrange(3, 2, 4, file=f):
            sleep(1)
        assert '\r     50%|█████     | 2/4 [00:02<00:02,  1.00s/it]\n' in f.getvalue()



# Generated at 2022-06-22 05:26:33.476372
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from io import StringIO

    class TqdmIO(StringIO):
        """StringIO with additional flush method"""
        def flush(self, *_, **__):
            pass

    try:
        # import IPython
        from IPython.utils.py3compat import cast_unicode_py2
        # IPython.utils.text.columnize
        from IPython.utils.text import num_columns
    except ImportError:
        # mock IPython
        from unittest.mock import MagicMock
        IPython = cast_unicode_py2 = num_columns = MagicMock()
        del MagicMock

    with TqdmIO() as fp:
        pbar = tqdm_notebook(total=10, file=fp, ncols=150)

# Generated at 2022-06-22 05:26:37.325845
# Unit test for function tnrange
def test_tnrange():
    import time
    try:
        list(tqdm(tnrange(10)))
        list(tqdm(tnrange(10), leave=False))
    except ImportError:
        return
    with tqdm(total=10) as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(0.01)



# Generated at 2022-06-22 05:26:43.586521
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Manual tqdm
    if hasattr(TqdmHBox, 'bar'):
        raise ImportError("Test requires TqdmHBox to have no attribute 'bar'")
    t = tqdm_notebook(total=42, leave=False)
    for i in range(10):
        t.update(i)
        assert TqdmHBox.bar.value == i
    t.reset()
    assert TqdmHBox.bar.max == 42
    assert TqdmHBox.bar.value == 0



# Generated at 2022-06-22 05:26:50.299355
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(3)):
        sleep(0.1)
        # change bar colour to green; then red
        if i == 2:
            tqdm_notebook.colour = "green"
        else:
            tqdm_notebook.colour = "red"


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:26:54.719035
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from tqdm import tqdm
    with tqdm(total=3) as pbar:
        pbar.set_description("description")
        pbar.set_postfix_str("postfix")
        pbar.n = 2
        pbar.update()
        time.sleep(0.1)
        pbar.close()

# Generated at 2022-06-22 05:27:05.692412
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=1)
    t.update()
    t.close()
    t = tqdm_notebook(total=1)
    t.update()
    t.reset(None)
    t.close()


if __name__ == "__main__":
    from doctest import testmod
    from .utils import _term_move_up
    testmod()

    print("\nClose the progress bar to finish the test.")
    with tqdm_notebook(total=3, desc='Testing tqdm_notebook') as t:
        for i in range(3):
            t.update()


# Generated at 2022-06-22 05:27:17.732902
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .std import tqdm
    from .gui import tqdm_gui
    from .utils import _open_file

    def test_factory(tqdm_cls):
        f = _open_file()
        progress_bar = tqdm_cls(
            iterable=_range(10), ncols=100, disable=False, file=f)
        try:
            for obj in progress_bar:
                continue
        finally:
            progress_bar.close()
        print("", file=f)
        return f.getvalue()

    # test tqdm_notebook.close()
    tqdm_nb_close = test_factory(tqdm_notebook)

    # test tqdm.close()
    tqdm_close = test_factory(tqdm)
   

# Generated at 2022-06-22 05:27:26.884283
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset() of class tqdm_notebook
    """
    from tqdm import tqdm_notebook as tqdm
    from tqdm.auto import trange
    from time import sleep
    with tqdm(total=100) as pbar:
        for i in trange(10, desc='1st loop'):
            sleep(0.1)
        pbar.reset(total=1000)
        assert pbar.total == 1000
        for i in trange(100, desc='2nd loop'):
            sleep(0.1)


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:28:22.550174
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase

    class Test(TestCase):
        def test_tqdm_notebook_status_printer(self):
            pbar = tqdm_notebook.status_printer()
            self.assertEqual(pbar.children[0].bar_style, '')
            self.assertEqual(pbar.children[0].value, 0)
            self.assertEqual(pbar.children[0].max, 1)
            self.assertEqual(pbar.children[0].layout.width, "20px")

    return Test().test_tqdm_notebook_status_printer()


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:28:26.468787
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    with pytest.raises(TypeError):
        tqdm_notebook().clear()

# Generated at 2022-06-22 05:28:38.636435
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import re
    import time
    import unittest

    class TqdmNotebookTest(unittest.TestCase):
        """
        Test the method `tqdm_notebook.reset`
        """
        def setUp(self):
            tn = tqdm_notebook(total=10, desc='my bar', leave=False)
            tn.reset(total=20)
            self.tn = tn

        def test_reset(self):
            tn = self.tn
            ltext, pbar, rtext = tn.container.children

            # Test that the bar attributes have been reset
            self.assertEqual(pbar.value, 0)
            self.assertEqual(pbar.max, 20)

            # Test that the length of the bar has been reset
            pbar.layout.width

# Generated at 2022-06-22 05:28:48.493473
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.display import display, clear_output
    a = TqdmHBox([HTML(), IProgress(), HTML()])
    assert repr(a) == "?/? [?/s]", repr(a)

    a.pbar = tqdm_notebook(total=100, ncols='20px')
    display(a)
    assert repr(a) == "0/100 [0/s]", repr(a)

    clear_output()
    assert repr(a) == "0/100 [0/s]", repr(a)

    a.pbar.update(10)
    assert repr(a) == "10/100 [0/s]", repr(a)

# Generated at 2022-06-22 05:28:55.708267
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .tests import borrowkwargs
    from .gui import tqdm_gui

    for t in (tqdm_gui, tqdm_notebook):
        with borrowkwargs(t) as t2:
            pbar = t2(range(0, 3))
            pbar.clear()
            assert pbar.n == 0
            assert pbar.last_print_n == 0

            pbar = t2(range(0, 3), leave=True)
            pbar.clear()
            assert pbar.n == 3
            assert pbar.last_print_n == 0

# Generated at 2022-06-22 05:29:06.065607
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    class Test1:
        def update(self, x):
            self.x = x
            return x

    pbar = tqdm_notebook(Test1(), total=4)
    assert pbar.update(1) == 1
    assert pbar.n == 1
    assert pbar.update(2) == 2
    assert pbar.n == 2
    assert pbar.update(3) == 3
    assert pbar.n == 3
    assert pbar.update(4) == 4
    assert pbar.n == 4
    assert pbar.update(5) == 5
    assert pbar.n == 5
    pbar.close()



# Generated at 2022-06-22 05:29:17.948437
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    from time import sleep
    # global variables
    i = 0
    m = 10000
    with tnrange(m, desc='test', ascii=True, ncols=80) as t:
        for _ in t:
            i += 1
            sleep(0.01)
    assert m == i
    # total=None
    m = 10000
    with tnrange(m, desc='test', ascii=True, ncols=80, total=None) as t:
        for _ in t:
            i += 1
            sleep(0.01)
    assert 1 == i
    # test for `disable=None` (inverse of `disable=False`)
    m = 10

# Generated at 2022-06-22 05:29:25.903464
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import unittest as ut
    class _Test(ut.TestCase):

        def test_1(self):
            with tqdm_notebook(total=9) as t:
                for i in range(10):
                    t.update()

        def test_2(self):
            with tqdm_notebook(total=3) as t:
                for i in range(4):
                    t.update()

        def test_3(self):
            with tqdm_notebook(total=3) as t:
                for i in range(4):
                    t.display(close=True)
                    t.update()

    ut.main()

# Generated at 2022-06-22 05:29:32.270051
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(total=10)
    for i in range(10):
        bar.update()
    assert bar.n == 10, 'Bar was not updated'
    bar.reset(total=None)
    assert bar.n == 0, 'Bar was not reset'
    bar.n = 10
    bar.reset(total=None)
    assert bar.n == 0, 'Bar was not reset'

# Generated at 2022-06-22 05:29:44.143476
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm._utils import _term_move_up
    t = tqdm_notebook(total=10)
    t.update()
    t.update()
    t.update(10)
    assert t.n == 21
    t.close()
    out, err = capsys.readouterr()
    out, err = re.sub(r'\s+', ' ', out), re.sub(r'\s+', ' ', err)
    assert out == '\r  0%|                                | 0/10 <bar/> '
    assert err == '\r  2%|#                               | 2/10 ' \
           + _term_move_up() + '\r100%|#########################| 10/10 '

