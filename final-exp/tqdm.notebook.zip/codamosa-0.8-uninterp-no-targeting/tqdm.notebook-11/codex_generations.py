

# Generated at 2022-06-22 05:20:17.877467
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    class dummy_tqdm(tqdm_notebook):
        def __init__(self, iterable=None, **kwargs):
            super(dummy_tqdm, self).__init__(iterable=iterable, **kwargs)
            self.trange = self  # make it singleton

    # Initialize a dummy progressbar
    pbar = dummy_tqdm(total=10)

    # Test if the update method is working properly
    assert (pbar.n == 0)
    pbar.update(2)
    assert (pbar.n == 2)
    pbar.update(3)
    assert (pbar.n == 5)

    # Test if the update method is working properly
    assert (pbar.n == 5)
    pbar.update(2)

# Generated at 2022-06-22 05:20:30.095610
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.contrib import tenumerate

    for _ in tenumerate(tqdm_notebook(iterable=[1, 2, 3], desc="test:",
                                      ascii=True)):
        pass
    hbox = tenumerate.container

    assert repr(hbox) == "[test:]  0%|          | 0/3 [00:00<?, ?it/s]"
    assert repr(hbox) == "[test:]  0%|          | 0/3 [00:00<?, ?it/s]"
    assert repr(hbox) == "[test:]  0%|          | 0/3 [00:00<?, ?it/s]"


# Generated at 2022-06-22 05:20:32.208119
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-22 05:20:36.369984
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_widget = tqdm(total=42)
    try:
        assert isinstance(tqdm_widget.container, TqdmHBox)
        # Just test that we can use __repr__ without crashing
        tqdm_widget.container.__repr__()
        tqdm_widget.container.__repr__(False)
        tqdm_widget.container.__repr__(True)
    finally:
        tqdm_widget.close()

# Generated at 2022-06-22 05:20:40.886444
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox()
    assert hasattr(hbox, '_repr_json_')
    assert hasattr(hbox, '__repr__')
    assert hasattr(hbox, '_repr_pretty_')



# Generated at 2022-06-22 05:20:52.453271
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """
    Unit test for tqdm_notebook.
    """
    from time import sleep

    # Check tqdm_notebook is registered
    tqdm_gui._instances.clear()
    ip = tqdm_notebook(total=10, desc="test", leave=False, miniters=0)
    assert tqdm_gui._instances == [ip]

    # Check tnrange and trange are registered
    tqdm_gui._instances.clear()
    ip = tnrange(10, desc="test", leave=False)
    assert tqdm_gui._instances == [ip]
    tqdm_gui._instances.clear()
    ip = trange(10, desc="test", leave=False)

# Generated at 2022-06-22 05:20:58.663320
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import ExitStack
    from io import StringIO
    from unittest import main, TestCase, skipUnless
    from subprocess import PIPE, run, DEVNULL

    def ipy():
        """Check whether IPython/Jupyter is installed."""
        try:
            proc = run(['jupyter', '--version'], stdout=DEVNULL, stderr=PIPE)
        except OSError:
            try:
                proc = run(['ipython', '--version'], stdout=DEVNULL, stderr=PIPE)
            except OSError:
                return False
        if proc.returncode != 0:
            return False
        version = proc.stderr.decode().split()[1]

# Generated at 2022-06-22 05:20:59.964973
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as bar:
        bar.update(5)
        bar.reset()

# Generated at 2022-06-22 05:21:12.662892
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """test set_description"""
    from tqdm import _tqdm

    with tests_disable_loop_exception_whitelist():
        for desc in ["", "test", "foo bar"]:
            bar = tqdm_notebook(desc=desc)
            bar.total = 10
            for i in range(5):
                bar.update()
                assert isinstance(bar, _tqdm), "tqdm_notebook must be an instance" \
                    " of _tqdm"
            bar.reset()
            assert bar.n == 0, "tqdm.reset() must reset 'n' to 0 but got {}".format(
                bar.n)

# Generated at 2022-06-22 05:21:17.620921
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as t:
        for i in range(5):
            t.update()
            assert t.n == i + 1
        assert t.n == 5

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:21:45.149333
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    if IPY == 0:  # pragma: no cover
        return
    with warnings.catch_warnings():
        warnings.filterwarnings(
            'ignore', message=".*IProgress is deprecated.*")
        pbar = IProgress(min=0, max=1)
        pbar.value = 1
        pbar.bar_style = 'info'
        container = TqdmHBox(children=[pbar])
        assert container.__repr__() == pbar.__repr__()
        container.pbar.bar_format = "{bar} {rate_fmt}"
        assert container.__repr__() == pbar.__repr__()

# Generated at 2022-06-22 05:21:54.816808
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Basic tests this method """
    d = tqdm_notebook.status_printer("a string")
    assert isinstance(d, TqdmHBox)
    assert isinstance(d.children[1], IProgress)
    assert d.children[1].max == 100  # total = None
    assert d.children[1].bar_style == ''
    d = tqdm_notebook.status_printer("a string", total=15, desc="desc")
    assert d.children[1].max == 15  # total = 15
    assert d.children[0].value == "desc"  # desc = "desc"
    if IPY >= 3:
        assert d._repr_json_(pretty=False) == d._repr_json_(pretty=True)



# Generated at 2022-06-22 05:21:59.414477
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=3) as pbar:
        pbar.update()
        pbar.update()
        pbar.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:22:04.235833
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from numpy.random import randint
    from time import sleep

    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            sleep(0.1)
            pbar.update(10)
            if randint(100) == 50:
                pbar.reset()


# Generated at 2022-06-22 05:22:13.808061
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    hb = TqdmHBox()
    try:
        # Test if the `pretty` argument has been added
        # to the `_repr_pretty_` method.
        # If so, the following line will succeed.
        hb._repr_pretty_(None, None)
    except TypeError:
        # So the `pretty` argument was NOT added,
        # this is not the version of `TqdmHBox` that we want.
        raise ImportError(
            "IPython version is too old, please update it."
            " See https://ipython.readthedocs.io/en/stable/install/kernel_install.html"
            " for installation instructions.")

# Generated at 2022-06-22 05:22:20.024325
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    with tqdm_notebook(total=10) as pbar:
        for i in range(6):
            time.sleep(0.1)
            pbar.update()
    # Test for #561
    try:
        for i in range(4):
            time.sleep(0.1)
            pbar.update()
    except AttributeError:
        pass
    else:
        raise AssertionError("We should not be able to update a closed bar")



# Generated at 2022-06-22 05:22:27.997561
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """Unit test for constructor of tqdm_notebook"""
    # Force tqdm import
    from ._tqdm import tqdm
    from ._tqdm import trange
    # Test progress bar
    with tqdm(total=1) as c:
        c.update()
    # Test non-total
    with tqdm(ascii=True) as c:
        pass
    # Test tnrange
    for _ in trange(100, ascii=True):
        pass

# Generated at 2022-06-22 05:22:36.300070
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    from .gui import tqdm as tqdm_gui

    with tqdm_notebook(total=100, leave=True) as pbar:
        for i in _range(100):
            time.sleep(.5)
            pbar.update(10)

    with tqdm_gui(total=100, leave=True) as pbar:
        for i in _range(100):
            time.sleep(.5)
            pbar.update(10)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-22 05:22:47.510674
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from shutil import get_terminal_size
    for _ in ['ipython', 'ipykernel', 'jupyter-client', 'jupyter-core', 'notebook']:
        try:
            from importlib import import_module
            if _ in ['ipython', 'ipykernel', 'jupyter-client', 'jupyter-core', 'notebook']:
                import_module(_)
            break
        except ImportError:
            pass
    import builtins
    builtins.__tqdm_ipython__ = True

# Generated at 2022-06-22 05:22:55.875056
# Unit test for function tnrange
def test_tnrange():
    from sys import stderr
    from time import sleep

    for i in tnrange(3, desc='1st loop', leave=True):
        # Print will not be displayed until the second loop
        # print tqdm_test_print
        sleep(0.5)
    for i in tnrange(1, desc='2nd loop'):
        sleep(0.5)
        stderr.write(str(tqdm_test_print))
        stderr.flush()
    tqdm_test_print = "done"
    stderr.write(str(tqdm_test_print))
    stderr.flush()



# Generated at 2022-06-22 05:23:31.229415
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import _test_closing_iterable
    _test_closing_iterable(tqdm_notebook(iter(range(100))))

# Generated at 2022-06-22 05:23:38.736326
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stderr
    from time import sleep
    from random import random

    with tqdm_notebook(total=10, file=stderr, ncols=80) as t:
        for i in range(10):
            sleep(0.1)
            t.set_description("task %s" % i)
            t.set_postfix(i=i, loss=i ** 2, dummy=random())


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:23:43.439700
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep
    from random import random

    for i in tqdm_notebook(range(5)):
        sleep(random() * 0.1)  # DO NOT REMOVE!
        clear_output(wait=True)

# Generated at 2022-06-22 05:23:46.414975
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    total = 4
    bar = tqdm_notebook(total=total)
    for i in range(total):
        bar.update()
    bar.close()


# Generated at 2022-06-22 05:23:55.905612
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Test the specialised __repr__() and _repr_pretty_() methods of
    class TqdmHBox.
    """
    hb = TqdmHBox()
    assert re.match(r'IPy\w+\.widgets\.HBox\[', hb.__repr__())
    assert re.match(r'IPy\w+\.widgets\.HBox\[', hb._repr_pretty_({}))
    hb.pbar = std_tqdm({})
    # Should not raise
    repr(hb)
    hb._repr_pretty_({})

# Generated at 2022-06-22 05:23:58.618793
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop', leave=False):
            for k in tnrange(100, desc='3nd loop', leave=False):
                sleep(0.01)
    sleep(0.1)

# Generated at 2022-06-22 05:24:04.303997
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    with tqdm_notebook(total=None) as t:
        for _ in tqdm_notebook(range(5), file=sys.stdout, ncols=None):
            t.update()
    with tqdm_notebook(total=None, ncols=20) as t:
        t.update()

# Generated at 2022-06-22 05:24:15.620872
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class pbar(object):
        format_dict = dict(
            ascii=False,
            fps=6.0,
            lap=6.0,
            loss=6.0,
            refresh_time=0.01,
            completed=6,
            total=10,
            percentage=100.0,
            elapsed=6.0,
            estimated=6.0,
            rate=6.0,
            bar_format='{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]'
                       )

    repr_pretty = '|█████[00:00<00:00]| 6/10 [00:00<00:00]\n'

# Generated at 2022-06-22 05:24:22.903737
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    from tqdm import tnrange
    z = tnrange(2)

    z.display(1, "foo", bar_style="info")
    time.sleep(3)
    z.display(0, "foobar", bar_style="warning")
    time.sleep(3)
    z.display(1, "foobaz", bar_style="danger")
    time.sleep(3)
    z.display(0, "fooquux", bar_style="success")
    time.sleep(3)

# Generated at 2022-06-22 05:24:25.897983
# Unit test for function tnrange
def test_tnrange():
    from pytest import raises
    from .utils import FormatReaction

    with raises(TypeError):
        for _ in tnrange(3):
            break

    for _ in tnrange(3):
        pass



# Generated at 2022-06-22 05:25:18.857430
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=10)
    for _ in t:
        assert not t.disable
        t.close()
        assert t.disable

# Generated at 2022-06-22 05:25:31.249401
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import shuffle, randrange
    from operator import mul

    # Create a fake notebook
    class a:
        @staticmethod
        def display(*args, **kwargs):
            pass

    # Fake display
    def disp(msg=None, pos=None,
             # additional signals
             close=False, bar_style=None, check_delay=True):
        return

    # Initialize tqdm_notebook
    n = 100
    fp = a()
    fp.display = disp
    t = tqdm_notebook(n, file=fp)
    t.disp = disp
    t.refresh()
    # Test that every iterations displays the progress bar
    for i in t:
        if i % 4:
            t._instant_dynamic_display()
            assert t.n == i
           

# Generated at 2022-06-22 05:25:40.456039
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # This test is only for Pyton 2 or 3
    # The __iter__ test is on test_notebook.py
    from six.moves import range
    try:
        from unittest.mock import Mock
    except ImportError:  # pragma: no cover
        from mock import Mock

    expected_total = 5
    expected_n = 1

    # workaround for unittest.mock.call signature
    def call_callable(func):
        return func()

    def test_not_implemented():
        bar = tqdm_notebook()
        bar.update(expected_n)

    def test_implemented():
        bar = tqdm_notebook()
        bar.n = 0
        bar.total = expected_total
        bar.update(expected_n)


# Generated at 2022-06-22 05:25:50.168750
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from pytest import raises
    from six.moves import StringIO

    _ = StringIO()

    bar = tqdm_notebook(total=None, file=_)  # test with fp=None
    bar.update()
    bar.reset(total=None)  # test with total=None

    bar = tqdm_notebook(total=None, file=_)  # test with fp=None
    bar.update()
    with raises(ValueError):
        bar.reset(total=-1)

    bar = tqdm_notebook(total=1, file=_)
    assert not bar.reset(total=-1)

# Generated at 2022-06-22 05:26:01.829383
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test is performed with the code below:
    # box = TqdmHBox()
    # box.pbar = tqdm_notebook(total=5, desc='test', bar_format='{bar} {n}/{total}', ncols=10)
    # box.pbar.update(3)
    # display(box)
    # box.pbar.update(5)
    #
    # If the test is running well in IPython, the following error should be
    # displayed: "Javascript error adding output!" with the following traceback
    # somewhere in the trace: "Maximum call stack size exceeded"
    # This can be ignored if the output looks fine.
    def test():
        from IPython.display import display
        from tqdm.notebook import tqdm_notebook

# Generated at 2022-06-22 05:26:07.019658
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from contextlib import redirect_stderr
    import io

    # redirect_stderr to a io.StringIO object
    f = io.StringIO()
    # redirect_stderr and check that nothing is printed
    with redirect_stderr(f):
        tnrange(1).clear()
    assert f.getvalue() == ''


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:26:18.121369
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():

    def test_msg(msg):
        hbox = TqdmHBox()
        hbox.pbar = {'total': 100, 'n': 15, 'desc': msg}
        # check that the representation of TqdmHBox is a str
        assert isinstance(repr(hbox), str)

    test_msg("     Hello world\n    ")
    test_msg("     Hello world\n\n")
    test_msg("     Hello world\n\n\n")
    test_msg("   <message with\n\nmultilines>   ")
    test_msg("")
    test_msg("   ")


try:
    test_TqdmHBox___repr__()
except:  # NOQA
    pass

# Generated at 2022-06-22 05:26:29.661275
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # import modules
    import warnings

    # test the method status_printer of class tqdm_notebook
    with warnings.catch_warnings(record=True):
        base_w = tqdm_notebook.status_printer('file')
        assert str(base_w).startswith('<')

    # test the method status_printer of class tqdm_notebook with total
    with warnings.catch_warnings(record=True):
        base_w_total = tqdm_notebook.status_printer('file',
                                                    total=1)
        assert str(base_w_total).startswith('<')

    # test the method status_printer of class tqdm_notebook with

# Generated at 2022-06-22 05:26:38.745656
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test tqdm_notebook method `close`."""
    with tqdm_notebook(total=10) as bar:
        bar.disp = lambda *_, **__: None
        bar.update(1)
        bar.update(8)
        bar.close()

    with tqdm_notebook(total=10) as bar:
        bar.disp = lambda *_, **__: None
        bar.update(1)
        bar.update(7)
        bar.update(2)
        bar.close()

    with tqdm_notebook(total=10) as bar:
        bar.disp = lambda *_, **__: None
        bar.update(1)
        bar.update(8)
        bar.close()
        bar.reset()
        bar.close()

   

# Generated at 2022-06-22 05:26:50.635928
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook:
    checks if the IPython progress bar is correctly updated.
    """
    from random import gauss
    # Setup and use a tqdm_notebook instance with one loop
    with tqdm_notebook(total=100) as t:
        for i in range(100):
            t.update(1)
    # Setup and use a tqdm_notebook instance without total
    with tqdm_notebook() as t:
        for i in range(100):
            t.update()
    # Setup and use a tqdm_notebook instance without total
    # with random updates
    with tqdm_notebook() as t:
        for i in range(100):
            t.update(gauss(1, 0.5))


# Exec