

# Generated at 2022-06-22 05:20:13.770906
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm as tqdm_gui

    # with total
    with tqdm_notebook(range(10), unit='B', unit_scale=True, mininterval=0.01,
                       desc='notebook', leave=True, bar_format='{desc}: {percentage:3.0f}%|{bar}|') as t:
        assert isinstance(t, tqdm_notebook)
        for _ in t:
            pass
        assert repr(t) == \
            "notebook: 100%|██████████████████████████████████████████████████| 10/10 [00:00<?, ?it/s]"
        t.pause()
        # Resume
        t.close()

    # no total (unknown total)

# Generated at 2022-06-22 05:20:17.955849
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=3) as pbar:
        pbar.update()
        pbar.clear()
        pbar.update()
        pbar.update()
        pbar.clear()
        pbar.update()

# Generated at 2022-06-22 05:20:30.214162
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from tqdm import tqdm
    # Initialize, print and close
    for i in tqdm(range(3), desc='1st loop', leave=True):
        for j in tqdm(range(2), desc='2nd loop', leave=True):
            for k in tqdm(range(5), desc='3nd loop', leave=True):
                sleep(0.01)
                pass
            pass
        pass
    # Reset
    for i in tqdm(range(3), desc='1st loop'):
        for j in tqdm(range(2), desc='2nd loop'):
            for k in tqdm(range(5), desc='3nd loop'):
                sleep(0.01)
                pass
            pass
        pass


# Unit test

# Generated at 2022-06-22 05:20:33.107155
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # clear is not implemented for tqdm_notebook, so this is just a stub test
    t = tnrange(10)
    assert isinstance(t, tnrange)
    t.clear()
    t.close()

# Generated at 2022-06-22 05:20:38.209480
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(range(2), total=2, leave=True)
    for _ in t:
        pass
    assert t.n == 2
    assert not t.displayed

    t.reset(total=4)
    assert t.n == 0
    # avoid invisible bar
    assert t.displayed
    for _ in t:
        pass
    assert t.n == 4
    assert t.displayed


if __name__ == "__main__":  # pragma: no cover
    from nose.plugins.skip import SkipTest
    raise SkipTest("Not a test module")

# Generated at 2022-06-22 05:20:45.379028
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    t = tqdm_notebook(range(10), desc='Spam')
    for i in t:
        sleep(0.1)
        if i == 5:
            t.display('')  # clear bar
            t.display('Bacon')
        else:
            t.display()  # update bar


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-22 05:20:49.224925
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    try:
        for _ in tqdm(range(4), desc='tqdm_notebook testing'):
            sleep(0.01)
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass



# Generated at 2022-06-22 05:20:58.001697
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        with tqdm(total=100, ncols='100%') as t:
            assert isinstance(t, tqdm_notebook)
            t.n = 10
            t.refresh()
            t.n = 40
            t.update()
            t.n = 90
            t.refresh()
            for i in range(10):
                t.update()
                t.postfix = [('test', i**2)]
                t.display(pos=i, total=10, bar_style='info')
            t.display(close=True)
    except ImportError:
        pass

# Generated at 2022-06-22 05:21:07.211354
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    try:
        from unittest import mock
    except ImportError:  # pragma: no cover
        from unittest.mock import mock
    with mock.patch('sys.stderr'):
        for i in tqdm_notebook([1, 2, 3]):
            clear_output(wait=True)
            assert i == tqdm_notebook().n

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-22 05:21:10.799719
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = tqdm_notebook(range(10), leave=False)
    bar.close()


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-22 05:21:27.689878
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test `tqdm_notebook.status_printer` function
    """
    widget = tqdm_notebook.status_printer(total=10)
    assert widget.children[0].value == ('10it [00:00, ?it/s]')
    widget = tqdm_notebook.status_printer(total=10, desc='desc')
    assert widget.children[0].value == ('desc')
    assert widget.children[1].value == 0
    widget = tqdm_notebook.status_printer(total=10, ncols=100)
    assert widget.children[0].value == ('100%|##########|10/10 [00:00<?, ?it/s]')

# Generated at 2022-06-22 05:21:30.270809
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=1) as pbar:
        pbar.update()

# Generated at 2022-06-22 05:21:34.901391
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # the first call to tqdm should generate the widget
    # the second call should clear the widget
    with tqdm_notebook(total=1, unit='i') as pbar:
        pbar.clear()
        pbar.update()
        pbar.clear()

# Generated at 2022-06-22 05:21:40.572952
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    with tqdm_notebook(total=1, leave=False) as tn:
        time.sleep(1)
        tn.close()
        # check that tn.container.close() was called during tn.close()
        # (which is not the case if we raise an error)
        assert not tn.container.visible
        return tn


# Generated at 2022-06-22 05:21:45.090860
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        import numpy as np
        np.warnings.filterwarnings('ignore', category=FutureWarning)
    except ImportError:
        pass

    from .tqdm import tees, tqdm

    class FakeTqdm:
        format_meter = lambda s, **k: k['desc'] + '\n' \
                       + ' '.join([k['n'], k['unit'], k['rate']])
        format_dict = {
            'desc': '',
            'n': '9/10',
            'rate': '',
            'unit': 'it',
            'bar_format': "",
            "l_bar": "[",
            "r_bar": "]",
        }


# Generated at 2022-06-22 05:21:53.251120
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from sys import stderr

    with tqdm_notebook(["a", "b", "c", "d"], file=stderr,
                       desc='Before') as t:
        for i in t:
            assert(t.n == 1)
            break
        for i in t:
            assert(t.n == 2)
            break
        for i in t:
            assert(t.n == 3)
            break
        for i in t:
            assert(t.n == 4)
            break
        t.close()



# Generated at 2022-06-22 05:21:57.721816
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm_notebook(xrange(10))
    assert isinstance(repr(t.container), str), repr(t.container)
    t.close()

# Generated at 2022-06-22 05:22:08.539545
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert repr(TqdmHBox()) == '  0%|          | 0/?'
    assert repr(TqdmHBox(children=[HBox(), IProgress(0, 1), HBox()])) == '  0%|          | 0/1 [00:00<?, ?it/s]'

# Generated at 2022-06-22 05:22:18.356399
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.testing import globalipapp
    from IPython.display import clear_output
    from time import sleep
    with globalipapp.ipapp.connection_info():
        for i in tqdm(range(10), desc='first loop'):
            sleep(0.01)
            clear_output(wait=True)
        tqdm_notebook.clear(tqdm_notebook)
        tqdm_notebook.write('test', file=sys.stdout)
        for i in tqdm(range(10), desc='second loop'):
            sleep(0.01)
            clear_output(wait=True)
        tqdm_notebook.display(close=True, check_delay=False)

# Generated at 2022-06-22 05:22:29.167829
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tqdm as tqdm_gui

    tn = tqdm_notebook(None, leave=False)
    tg = tqdm_gui(None, leave=False)
    tn.close()
    tg.close()
    assert tn.container and tg.container
    with tqdm_notebook(None, leave=False) as tn:
        with tqdm_gui(None, leave=False) as tg:
            pass
    assert not tn.container and not tg.container

    widgets = [
        "TEST1: ", tn,
        '  ',
        "TEST2: ", tg,
    ]

    # try:
    #     from IPython.version_info import major as ipython_major_version
    # except ImportError: 

# Generated at 2022-06-22 05:22:46.215316
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        for _ in trange(10):
            # tqdm.notebook.clear()
            pass
    except:
        pass

# Generated at 2022-06-22 05:22:51.995009
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import trange
    with trange(10, desc="testing tqdm_notebook clear") as t:
        for i in t:
            pass
        t.clear()
        # Check that it fails
        t.clear(True)


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:22:56.136618
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    t = tqdm_notebook(total=2)
    t.displayed = True
    for _ in range(3):
        t.update()



# Generated at 2022-06-22 05:23:03.987116
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Unit test for `TqdmHBox.__repr__`."""
    from tqdm.notebook import tqdm as t
    t = t(1)
    with t:
        t.update()
    repr_ = repr(t.container)
    assert ' HTML(value=' in repr_
    assert ' IntProgress(value=' in repr_
    assert ' HTML(value=' in repr_
    assert ' HBox(children=' in repr_


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:23:10.121878
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import unittest

    class Test(unittest.TestCase):
        def test(self):
            tb = tqdm_notebook.status_printer(total=10, desc="Test")
            display(tb)

    try:
        unittest.main()
    except SystemExit:
        return
    raise ValueError("unittest.main() exited without raising SystemExit")

# Generated at 2022-06-22 05:23:20.709801
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Assert basic instantiation
    pbar = tqdm_notebook(total=100)
    assert pbar.container.children[1].max == 100
    pbar.update(10)
    assert pbar.container.children[1].max == 100
    assert pbar.container.children[1].value == 10
    # Reset and assert that the max is reset and the bar is cleared
    pbar.reset()
    assert pbar.container.children[1].value == 0
    assert pbar.container.children[1].max == 0
    # Reset with a new total and assert it is applied
    pbar.reset(total=200)
    assert pbar.container.children[1].max == 200
    assert pbar.container.children[1].value == 0
    # Assert the bar can be used again
    pbar

# Generated at 2022-06-22 05:23:24.604333
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.notebook import tqdm
    pbar = tqdm(total=1)
    try:
        pbar.update()
    except:
        raise
    finally:
        pbar.close()



# Generated at 2022-06-22 05:23:34.820804
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    with tqdm_notebook(total=1337) as pbar:
        for i in tqdm_notebook(range(1337)):
            pbar.update(1)
            assert i == pbar.n
            assert i == pbar.last_print_n
            assert pbar.total == 1337
            assert (pbar.n / pbar.total) == float(pbar.n) / float(pbar.total)
            assert (type(pbar.n) == int)
            assert sys.stderr.isatty()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-22 05:23:41.762077
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    TqdmHBox(children=[]) == {}
    tqdm_notebook().container == {'bar_format': '{l_bar}<bar/>{r_bar}',
                                  'bar_template': '{desc}{percentage:3.0f}%|{bar}| [{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}]',
                                  'ascii': True}

# Generated at 2022-06-22 05:23:53.157934
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython import get_ipython
    from IPython.testing.globalipapp import get_ipython  # NOQA: F811

    global ip
    ip = get_ipython()  # NOQA: F821
    ip.run_cell("from tqdm import tqdm_notebook")
    if IPY >= 3:
        ip.run_cell("tqdm_notebook.status_printer(None)")
        if IPY < 4:
            ip.run_cell("tqdm_notebook.status_printer(None, 100)")
    else:  # IPython 2.x
        # TODO: test in 2.x
        pass


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:24:15.964043
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    def test_generator():
        """
        A test generator wrapped in tqdm_notebook.__iter__
        """
        yield 1
        yield 2
        assert False, "assertion error"
        yield 3

    def test_list():
        """
        A test list wrapped in tqdm_notebook.__iter__
        """
        return [1, 2]

    try:
        list(tqdm_notebook(test_generator()))
    except AssertionError as e:
        assert "assertion error" in str(e)
    else:
        assert False
    assert list(tqdm_notebook(test_list())) == [1, 2]



# Generated at 2022-06-22 05:24:26.044183
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    '''
    Unit test for method `__repr__` of class `TqdmHBox`
    '''
    from .std import tqdm as std_tqdm
    from .utils import _range

    def f1():
        for i in std_tqdm(_range(3)):
            pass

    def f2():
        for i in std_tqdm(None, total=3, unit="m", desc="d", bar_format="{l_bar}{bar}{r_bar}"):
            pass

    import sys
    import re
    import os

    sys.argv[1:] = ["-v", "-s", "--durations=10"]
    sys.argv.append(os.path.splitext(__file__)[0] + ".test_TqdmHBox___repr__")

# Generated at 2022-06-22 05:24:37.942700
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from sys import version_info
    if version_info.major == 2:
        from nose.core import SkipTest
        raise SkipTest
    from nose.tools import assert_raises

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # Setup mock
    tqdm_notebook.clear = lambda *_, **__: None
    mock_isatty = patch('tqdm._tqdm.tqdm_gui.isatty').start()
    mock_isatty.return_value = False  # Disable all printing
    mock_isinteractive = patch('tqdm._tqdm.tqdm_gui.isinteractive').start()
    mock_isinteractive.return_value = False  # Disable all printing

    # Check with current tqdm

# Generated at 2022-06-22 05:24:48.729000
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    """Unit test for `tnrange`"""
    from time import sleep, time
    from random import randrange
    from os import getpid

    if 'ipywidgets' not in sys.modules:
        return

    with tnrange(10) as t:
        for i in t:
            sleep(0.1)
    try:
        print(t)
    except NameError:
        pass

    with tnrange(3, desc='1st loop') as t1:
        for i in t1:
            sleep(0.1)
            with tqdm(desc='2nd loop', leave=False, total=i + 1) as t2:
                for j in t2:
                    sleep(0.1)

# Generated at 2022-06-22 05:25:00.169592
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # prepare the file
    with open("output.txt", "w") as fout:
        fout.write("TEST")

    # prepare the status printer
    from os import remove
    from time import sleep
    from random import randint
    try:
        # determine ipywidgets version
        ipywidgets.version_info
        import ipywidgets as widgets
    except AttributeError:
        import ipywidgets as widgets

    # test the base of the method
    pbar = tqdm_notebook.status_printer(fout)
    assert isinstance(pbar, widgets.HBox)
    assert isinstance(pbar.children[0], widgets.HTML)
    assert isinstance(pbar.children[1], widgets.FloatProgress)

# Generated at 2022-06-22 05:25:10.687195
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    reset_called = False

    def test_reset():
        global reset_called
        reset_called = True

    bar = tqdm_notebook(total=2)
    bar.display()
    assert type(bar.container) == TqdmHBox
    assert bar.container.pbar == bar
    test_b = str(bar)
    sleep(0.01)  # let the progressbar update
    assert test_b != str(bar)

    bar.reset()
    test_a = str(bar)
    sleep(0.01)  # let the progressbar update
    assert test_a != str(bar)

    bar.reset(total=3)
    assert bar.total == 3

    bar.n = 4
    bar.reset()
    assert bar.total == None

# Generated at 2022-06-22 05:25:20.029053
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # check default style
    status_printer = tqdm_notebook.status_printer(None)
    assert isinstance(status_printer, TqdmHBox)
    assert status_printer.layout.flex_flow == 'row wrap'
    assert status_printer.layout.display == 'inline-flex'
    assert status_printer.layout.width == '100%'
    ltext, pbar, rtext = status_printer.children
    assert isinstance(ltext, HTML)
    assert isinstance(pbar, IProgress)
    assert isinstance(rtext, HTML)
    assert pbar.max == 100
    assert pbar.min == 0
    assert pbar.step == 1
    assert pbar.value == 0
    assert pbar.bar_style == 'info'

    # check custom

# Generated at 2022-06-22 05:25:32.024927
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from io import StringIO
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    def wrapper(bar):
        with captured_output() as (out, err):
            bar.display()
            assert (out.getvalue() == '') and (err.getvalue() == '')
            # Test left and right msg
            bar.display

# Generated at 2022-06-22 05:25:41.010059
# Unit test for function tnrange
def test_tnrange():
    """Test both trange and tnrange"""
    from distutils.version import LooseVersion
    from time import time
    from sys import version_info

    tqdm_notebook.clear()  # reset tqdm_instance()
    total = 5
    for _ in tqdm_notebook(range(total)):
        assert len(tqdm_notebook.instances) == 1
        time()  # burn some time
    assert len(tqdm_notebook.instances) == 0
    assert tqdm_notebook.n == tqdm_notebook.total == 0

    # Initialise instances
    tqdm_notebook.clear()
    total = 5
    for _ in tqdm_notebook(range(total)):
        assert len(tqdm_notebook.instances) == 1

# Generated at 2022-06-22 05:25:45.437729
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(total=5, leave=False)
    t.clear()


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:26:38.535771
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.core.getipython import get_ipython
    ip = get_ipython()
    if not ip or ip.__name__ != '__main__':  # pragma: no cover
        return

    n = 10
    t = tqdm(1)
    t.sleep_time = 0
    t.total = n
    for _ in t:
        pass

    t.clear()
    t.write("")
    t.clear()
    t.write("", 0)
    t.clear()
    t.write("", n)
    t.clear()
    t.display()
    t.close()

    t = tqdm(range(n), file=sys.stdout)
    for _ in t:
        pass
    t.close()


# Generated at 2022-06-22 05:26:42.950806
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    t = tqdm_notebook(total=100)
    assert repr(t.container) == ('HBox' if IPY > 3 else '')
    assert len(t) == 100
    t.refresh()

# Generated at 2022-06-22 05:26:45.279322
# Unit test for function tnrange
def test_tnrange():
    for _ in tnrange(4, 6):
        pass
    for _ in tnrange(10 ** 6):
        pass



# Generated at 2022-06-22 05:26:56.372442
# Unit test for function tnrange
def test_tnrange():
    from .gui import tnrange as gtnrange
    from .std import tnrange as stnrange
    from .import tqdm

    def apply_test(test_name, args, kwargs):
        # Apply test
        test_tqdm = getattr(gtnrange, test_name)
        if test_name != 'test_format_interactive':
            # test_format_interactive fails if not using tqdm_gui,
            # which is perfectly normal
            test_tqdm(*args, **kwargs)

        # Test few defaults
        kwargs.setdefault('file', None)
        kwargs.setdefault('dynamic_ncols', True)
        kwargs.setdefault('mininterval', 0.1)

        # Test tnrange
        # Test tqdm_note

# Generated at 2022-06-22 05:27:03.275044
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    a = tqdm_notebook(["a", "b", "c", "d"])
    for i in a:
        sleep(0.1)
        pass
    a = tqdm_notebook(["a", "b", "c", "d"], desc="1st loop")
    for i in a:
        sleep(0.1)
        pass
    a = tqdm_notebook(["a", "b", "c", "d"], desc="2nd loop", leave=True)
    for i in a:
        sleep(0.1)
        pass
    a = tqdm_notebook(["a", "b", "c", "d"], desc="3rd loop", leave=False)
    for i in a:
        sleep(0.1)
        pass

# Generated at 2022-06-22 05:27:10.457184
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from IPython.core.display import clear_output
    try:
        t = tqdm_notebook(total=4)
        for i in range(4):
            sleep(0.2)
            clear_output(wait=True)
            t.update()
            t.display()
        t.close()  # finish
    except:  # NOQA
        t.close()
        raise
    print('Tests passed!')

# Generated at 2022-06-22 05:27:12.931329
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    l = [1, 2]
    l_ = list(tqdm_notebook(l))
    assert l == l_
    with tqdm_notebook(l, ascii=True) as t:
        l_ = list(t)
    assert l == l_

# Generated at 2022-06-22 05:27:14.802575
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook([], display=False)



# Generated at 2022-06-22 05:27:26.392181
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm as std_tqdm
    from .gui import tgrange as std_tgrange
    from .std import trange as std_trange
    from .std import tqdm as std_tqdm_std
    from .std import trange as std_trange_std

    with std_tqdm(leave=True, miniters=None, mininterval=0) as t:
        assert isinstance(t, std_tqdm)
        assert t.container is None

    with tqdm(leave=True, miniters=None, mininterval=0) as t:
        assert isinstance(t, tqdm_notebook)
        assert isinstance(t.container, TqdmHBox)


# Generated at 2022-06-22 05:27:33.145329
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from contextlib import redirect_stdout
    container = TqdmHBox(children=[HTML(), FloatProgress(min=0, max=10), HTML()])
    container.pbar = proxy(tqdm(total=10))
    with redirect_stdout(StringIO()) as stdout:
        print(container)
    assert '<' not in stdout.getvalue()  # no HTML


if __name__ == "__main__":
    test_TqdmHBox___repr__()
    print("Passed unit test !")

# Generated at 2022-06-22 05:28:39.206674
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test empty bar
    bar = TqdmHBox()
    assert (bar.__repr__(pretty=False) == "{'n': 0, 'total': None}")
    assert (bar.__repr__(pretty=True) == "{'total': None}")

    # Test bar with a total
    bar.pbar = std_tqdm(total=100)
    assert (bar.__repr__(pretty=False) == "{'n': 0, 'total': 100}")
    assert (bar.__repr__(pretty=True) == "{'total': 100}")


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:28:45.150935
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    n = tqdm_notebook([])
    n.update(0)
    n.update(1)
    n.update(1)
    n.update(1)
    n.update(1)
    n.update(1)
    n.update(1)
    n.update(1)
    n.update(1)

# Generated at 2022-06-22 05:28:48.985223
# Unit test for function tnrange
def test_tnrange():
    from .tests import TqdmTestCase

    with TqdmTestCase(miniters=0, leave=True) as t:
        for i in tnrange(4, desc='Test', mininterval=0.01):
            t.write("HI")

# Generated at 2022-06-22 05:28:59.201013
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from nose.tools import raises
    try:
        from unittest import mock
    except ImportError:
        import mock
    # def test_tqdm_notebook(*args, **kwargs):
    for args in [(), ('2',), ('a',), (_range(2),), (_range('a'),)]:
        kwargs = dict(desc=None)
        if len(args) < 2:
            # args = tuple(args) + (None,)*2
            kwargs['total'] = None
        else:
            kwargs['total'] = args[1]
        td = tqdm_notebook(*args, **kwargs)
        assert isinstance(td, tqdm_notebook)
        td.close()
        del td

        # Test with `leave=True` and :meth:`clear

# Generated at 2022-06-22 05:29:07.092101
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        import IPython  # noqa
    except ImportError:
        return None  # not in IPython
    else:
        # test that `reset` / `close` work properly
        try:
            with tqdm.notebook.tqdm(range(2), leave=True) as t:
                for i in t:
                    if i == 0:
                        t.reset()
            t.close()
        except AttributeError:
            return False
        else:
            return True

# Generated at 2022-06-22 05:29:18.959340
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from io import StringIO
    with StringIO() as f:
        _, pbar, _ = TqdmHBox(
            children=[HTML(), IProgress(min=0, max=1), HTML()]).children
        pbar._repr_json_(True)
        pbar.format_meter(**pbar.format_dict)
        pbar.value = 1
        print(pbar, file=f)
        pbar.bar_style = 'info'
        print(pbar, file=f)
        pbar.bar_style = 'warning'
        print(pbar, file=f)
        pbar.bar_style = 'danger'
        print(pbar, file=f)
        pbar.bar_style = 'success'
        print(pbar, file=f)

# Generated at 2022-06-22 05:29:21.053296
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # creation
    with tqdm_notebook() as t:
        t.clear()  # no-op



# Generated at 2022-06-22 05:29:30.093699
# Unit test for method close of class tqdm_notebook

# Generated at 2022-06-22 05:29:41.463435
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .tests import unittest
    import warnings
    import io
    from contextlib import redirect_stdout

    class TqdmNotebookCloseTest(unittest.TestCase):
        def test_close(self):
            with self.assertRaises(AssertionError):
                with tqdm_notebook(total=10) as t:
                    pass
                t.close()  # double close, must fail
            with self.assertRaises(AssertionError):
                with tqdm_notebook(total=10) as t:
                    t.close()  # close manually, must fail
            with self.assertRaises(AssertionError):
                with tqdm_notebook(total=10) as t:
                    raise ValueError()
                    t.close()  # not reached, must fail

# Generated at 2022-06-22 05:29:46.679395
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep  # NOQA
    from random import random  # NOQA

    for i in tqdm_notebook([], leave=False, mininterval=1e-3):
        sleep(1e-3 * (0.3 + random()))
        i.update()