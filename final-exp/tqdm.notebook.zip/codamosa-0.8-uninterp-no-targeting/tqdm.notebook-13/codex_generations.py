

# Generated at 2022-06-22 05:20:09.432534
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from sys import getrecursionlimit, setrecursionlimit
    max_rec = getrecursionlimit()
    setrecursionlimit(2 * max_rec)

# Generated at 2022-06-22 05:20:11.832356
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        t.clear()
        t.update()
test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:20:23.799028
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    d = {'bar_format': '{l_bar}|{bar}|{r_bar}{postfix}'}
    h = TqdmHBox()
    h.pbar = std_tqdm().format_dict
    assert h.__repr__() == ""
    h.pbar.update(1)
    h.pbar.update_to(2)
    assert h.__repr__() == "1/2 [===============>      ]"
    h.pbar = std_tqdm().format_dict
    h.pbar.update(1)
    h.pbar.update_to(2)
    assert h._repr_json_() == d
    assert h._repr_json_(pretty=False) == d
    assert h._repr_json_(pretty=True) == d

# Generated at 2022-06-22 05:20:30.962408
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import logging
    logging.basicConfig(level=logging.DEBUG)
    container = TqdmHBox(children=[HTML(), FloatProgress(), HTML()])
    container.pbar = tqdm_notebook(total=3)
    container.pbar.n = 1
    container.pbar.display(bar_style='success')
    logging.debug(container)
    assert container.__repr__() == container.__repr__(True)

del absolute_import, division

# Generated at 2022-06-22 05:20:36.769225
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    d = {'l_bar': 'A', 'r_bar': 'B', 'bar_format': '{l_bar}<bar/>{r_bar}'}
    assert repr(TqdmHBox(children=[], pbar=TqdmHBox(format_dict=d))) == d['bar_format'].format(**d)

# Generated at 2022-06-22 05:20:39.858655
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=10, leave=False) as t:
        t.update(1)
        t.close()


# Generated at 2022-06-22 05:20:51.608433
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    obj = TqdmHBox()
    assert repr(obj) == ""
    obj.pbar = tqdm_notebook(total=5)
    assert repr(obj) == "  0%|          | 0/5 [00:00<?, ?it/s]"
    obj.pbar.n = 1
    assert repr(obj) == " 20%|#        | 1/5 [00:00<00:00, ?it/s]"
    obj.pbar.total = 10
    assert repr(obj) == " 10%|#        | 1/10 [00:00<00:00, ?it/s]"
    obj.pbar.n = 3
    assert repr(obj) == " 30%|###      | 3/10 [00:00<00:00, ?it/s]"


# Generated at 2022-06-22 05:20:58.463113
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test pretty repr
    bar = tqdm(total=6, leave=True, ncols=20,
               desc='pretty', bar_format='{l_bar}{bar}{r_bar}')
    assert bar.container._repr_pretty_(None) == 'pretty:   0%|          | 0/6 [00:00<?, ?it/s]\n'

    # Test normal repr
    assert bar.container._repr_json_(None) == bar.container._repr_json_(True)
    bar.container._repr_json_(None) == bar.container._repr_json_(True)

    # Test non-pretty repr
    assert bar.container.__repr__() == 'pretty:   0%|          | 0/6 [00:00<?, ?it/s]\n'

# Generated at 2022-06-22 05:21:11.085680
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    test_tqdm_notebook_status_printer:
    """
    try:
        from IPython.display import clear_output
    except ImportError:
        pass
    from .tests_tqdm import pretest_posttest  # NOQA

    # Unit tests
    @pretest_posttest
    def unit_test():
        total = 7

        # Test default output
        pbar = tqdm_notebook.status_printer(total=total)
        for i in range(total):
            pbar.value = i
        pbar.bar_style = 'success'
        pbar.close()
        clear_output(wait=1)

        # Test custom layout
        pbar = tqdm_notebook.status_printer(total=total, ncols=100)
        p

# Generated at 2022-06-22 05:21:23.042864
# Unit test for method display of class tqdm_notebook

# Generated at 2022-06-22 05:21:47.847976
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import contextmanager
    from io import StringIO
    import sys
    import traceback

    @contextmanager
    def redirect_stderr():
        err = StringIO()
        sys.stderr.flush()
        oldstderr = sys.stderr
        oldstdout = sys.stdout
        try:
            sys.stderr = sys.stdout = err
            yield err
        finally:
            sys.stderr = oldstderr
            sys.stdout = oldstdout

    with redirect_stderr() as err:
        with tqdm_notebook(range(10), unit='B', unit_scale=True,
                           leave=True, position=0) as t:
            for i in t:
                t.set_description("desc %i" % i)
                t

# Generated at 2022-06-22 05:21:49.876039
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .tests import SimpleProgressbarTest

    SimpleProgressbarTest.test_reset(tqdm_notebook)

# Generated at 2022-06-22 05:21:56.297604
# Unit test for function tnrange
def test_tnrange():
    """
    Simple unit tests for tnrange
    """
    from time import sleep
    l = [1, 2, 3]
    for _ in tnrange(len(l), desc='1st loop'):
        pass
    for _ in tnrange(len(l), desc='2nd loop'):
        for _ in tnrange(len(l), desc='2nd nested loop'):
            for _ in tnrange(len(l), desc='2nd nested nested loop'):
                sleep(.01)
    with tnrange(10, desc='parallel') as prange:
        for _ in l:
            prange.update()



# Generated at 2022-06-22 05:22:05.950593
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test tqdm_notebook's close method"""
    import time
    try:
        # TODO: this test cannot raise an exception in manual mode
        #  (bar recreated in case of exception)
        for i in tqdm_notebook(range(3), desc='f', leave=False,
                               disable=False, dynamic_ncols=True):
            assert i == 0 or i == 1 or i == 2
            time.sleep(0.01)
            raise ValueError
    except ValueError:
        pass
    for i in tqdm_notebook(range(3), desc='g', leave=True,
                           disable=False, dynamic_ncols=True):
        assert i == 0 or i == 1 or i == 2
        time.sleep(0.01)
    # test total=None

# Generated at 2022-06-22 05:22:07.892749
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    return TqdmHBox(children=[HTML(), IProgress(min=0, max=1), HTML()])

# Generated at 2022-06-22 05:22:10.138254
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=None) as pbar:
        pbar.clear()

# Generated at 2022-06-22 05:22:19.943207
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Unit tests for TqdmHBox class."""
    from unittest import TestCase
    from tqdm.auto import tqdm
    from io import StringIO

    class TestTqdmHBox(TestCase):
        """
        These unit-tests check if the different constructors behave as
        expected.
        """
        def test_echo(self):
            """
            Test on the `__repr__` method returning the same thing as
            the echo method.
            """
            # Test on empty `TqdmHBox` object
            self.assertEqual(repr(TqdmHBox()), TqdmHBox().__repr__())

            # Test on `TqdmHBox` object with a progressbar
            str_buffer = StringIO()

# Generated at 2022-06-22 05:22:24.967926
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    if not IPY or IPY < 2:
        return
    s = repr(TqdmHBox())
    assert '\r' not in s
    assert '\n' not in s
    assert 'HBox' in s
    assert 'pbar' not in s
    assert 'placeholder' not in s



# Generated at 2022-06-22 05:22:36.718662
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    import time

    # Avoid ipython-specific issues
    if 'ipykernel' in sys.modules or 'IPython' in sys.modules:
        return
    t = tqdm_notebook(total=5)
    t.display('init')
    t.display(close=True)
    t.display()
    # Avoid testing too much
    t.disable = True
    t.display()
    t.disable = False
    t.display('')
    # IProgress was killed by the change to ipywidgets 6.0.0
    # try:
    #     t.display(bar_style='danger')
    # except Exception:
    #     pass
    t.close()
    t.display()
    t.clear()
    t.reset()
    t.display()

# Generated at 2022-06-22 05:22:42.328225
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from collections import deque
    with tqdm_notebook(total=10) as t:
        l = deque([1, 2, 3, 4, 5], maxlen=3)
        for i in l:
            t.update()
        t.reset(total=5)
        for i in l:
            t.update()

# Generated at 2022-06-22 05:22:59.306887
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    # Testing
    with tqdm(total=4) as pbar:
        for _ in range(4):
            pbar.update()
            assert next(pbar) == pbar.n



# Generated at 2022-06-22 05:23:10.494235
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    import time
    import random

    def f():
        time.sleep(0.1)
        raise RuntimeError('something bad happened')

    t = tqdm_notebook(range(3))
    t.close()  # should be safe to call repeatedly
    t.reset(3)
    t.display()  # display() will have no effect
    t.update()
    t.close()
    t.display()  # display() will have no effect
    t.close()

    t = tqdm_notebook(range(3))
    t.close()  # should be safe to call repeatedly
    t.reset(3)
    try:
        for _ in t:
            f()
    except RuntimeError:
        t.close()
    t.display()  # display() will have no

# Generated at 2022-06-22 05:23:18.387466
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output  # NOQA
    from time import sleep
    with tqdm_notebook(total=3) as t:
        for i in range(3):
            sleep(0.1)
            t.clear()
            t.update()


test_tqdm_notebook_clear.__test__ = False  # for pytest # NOQA

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_clear()  # pragma: no cover

# Generated at 2022-06-22 05:23:24.006653
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test method clear of class tqdm_notebook"""
    with tqdm_notebook(range(3), leave=True) as t:
        for i in range(3):
            t.clear()


if __name__ == '__main__':
    with tqdm(total=100) as t:
        for i in range(10):
            t.update()
            sleep(0.1)

# Generated at 2022-06-22 05:23:36.064291
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10) as t:
        for i in range(5):
            t.update()
    assert t.n == 5
    t.reset()
    assert t.n == 0
    assert t.container[-2].value == 0
    assert t.container[-2].max == 10
    assert t.container[-2].bar_style == ''

    # set total
    t.reset(total=20)
    assert t.n == 0
    assert t.container[-2].value == 0
    assert t.container[-2].max == 20
    assert t.container[-2].bar_style == ''

    # set total=None
    t.reset()
    assert t.n == 0
    assert t.container[-2].value == 0

# Generated at 2022-06-22 05:23:39.993063
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm_notebook([0, 1, 2], desc='test')
    for _ in t:
        pass
    assert isinstance(t.container, TqdmHBox)
    assert t.container.__repr__().startswith('test |')

# Generated at 2022-06-22 05:23:43.544388
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time

    progress_bar = trange(10, desc='testing notebook update')
    for i in range(10):
        progress_bar.update(1)
        time.sleep(0.5)


# Generated at 2022-06-22 05:23:46.865582
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook([1, 2, 3]):
        pass


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-22 05:23:48.390000
# Unit test for function tnrange
def test_tnrange():
    for n in tnrange(3):
        pass



# Generated at 2022-06-22 05:24:00.542499
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(3), desc='foo'):
        pass
    for i in tqdm_notebook(iterable=range(3), desc='foo'):
        pass
    for i in tqdm_notebook(range(3), unit='foo'):
        pass
    for i in tqdm_notebook(range(3), unit_scale=True):
        pass
    for i in tqdm_notebook(range(3), unit_scale=2):
        pass
    for i in tqdm_notebook(range(3), unit_divisor=2):
        pass
    for i in tqdm_notebook(range(3), total=10):
        pass
    for i in tqdm_notebook(range(3), miniters=5):
        pass

# Generated at 2022-06-22 05:24:16.794649
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(iterable=range(1000000), desc='Notebook:',
                           leave=False):
        pass


if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-22 05:24:27.902773
# Unit test for function tnrange
def test_tnrange():
    from time import sleep

    with tqdm(total=100) as pbar:
        for i in tnrange(100, desc='1st loop'):
            # test closing
            if i == 5:
                pbar.close()
            # test updating total
            if i == 15:
                pbar.total = 20
            # test dynamic_ncols
            if i == 25:
                pbar.dynamic_ncols = True
            # test ascii
            if i == 35:
                pbar.ascii = not pbar.ascii
            # test unit_scale
            if i == 45:
                pbar.unit_scale = 2
            # test unit
            if i == 55:
                pbar.unit = 'i'
            if i >= 65 and i < 75:
                continue
           

# Generated at 2022-06-22 05:24:38.975230
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    :func:`tqdm.notebook.tqdm_notebook.status_printer` unit test.
    """
    if IPY == 0:
        return
    fp = tqdm_notebook.status_printer(None)
    fp.update(1)
    assert isinstance(fp, TqdmHBox)
    assert isinstance(fp.pbar, IProgress)
    # test different width attributes
    assert fp.pbar.layout.width is None  # default style of ipywidgets
    fp = tqdm_notebook.status_printer(None, ncols=20)
    assert fp.pbar.layout.width == "20px"
    fp = tqdm_notebook.status_printer(None, ncols=100)
   

# Generated at 2022-06-22 05:24:44.227777
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .std import tqdm

    for leave in (True, False):  # test both with and without `leave=True`
        bar = tqdm(total=4, leave=leave)
        try:
            bar.update(1)
            bar.update(1)
        except Exception as e:
            raise e
        finally:
            bar.close()



# Generated at 2022-06-22 05:24:54.857068
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Make sure the TqdmHBox class is properly constructed"""
    from unittest import TestCase, main

    class TestTqdmHBox(TestCase):
        def test_constructor(self):
            """Test constructor"""

            def test_constructor_no_args():
                TqdmHBox()

            def test_constructor_widgets():
                with self.assertRaises(TypeError):
                    TqdmHBox(HTML())

            def test_constructor_pbar():
                TqdmHBox(pbar=IProgress())

            test_constructor_no_args()
            test_constructor_widgets()
            test_constructor_pbar()

    main()



# Generated at 2022-06-22 05:25:05.626979
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from ipywidgets import IntProgress
    from ipywidgets import IntSlider
    from ipywidgets import Label
    from IPython.display import display
    from IPython.display import clear_output
    from IPython import get_ipython

    # in jupyter notebook, use `get_ipython`
    # otherwise, test without
    ip = get_ipython()

    hb = TqdmHBox()
    assert(repr(hb) == "")

    # test existing html.output
    ip.run_cell("hb = TqdmHBox(hb.output, style='warning')")
    assert(repr(hb) == "")
    hb.pbar = IntProgress()

# Generated at 2022-06-22 05:25:09.604228
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.tests import tests
    tests.test_tqdm(tqdm_notebook)


if __name__ == '__main__':
    from tqdm.tests import _test_tqdm
    _test_tqdm(tqdm_notebook)

# Generated at 2022-06-22 05:25:19.418255
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from unittest import TestCase

    class TestTqdmNotebookReset(TestCase):
        TEST_NUM = 10

        def test_reset(self):
            # Setup
            test_tqdm = tqdm_notebook(total=self.TEST_NUM)

            # Test 1
            counter = 0
            while test_tqdm.n < self.TEST_NUM:
                test_tqdm.update()

                counter += 1

            self.assertEqual(test_tqdm.n, self.TEST_NUM)
            self.assertEqual(counter, self.TEST_NUM)

            # Test 2
            test_tqdm.reset()

            counter = test_tqdm.n

# Generated at 2022-06-22 05:25:31.508600
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm import format_dict
    from io import StringIO

    infostr = StringIO()
    pbar = tqdm_notebook.status_printer(infostr, 10, 'foo')
    assert format_dict(pbar, ncols=50) == format_dict(tqdm_notebook, ncols=50)
    pbar.close()
    # Test removing {bar}
    pbar = tqdm_notebook.status_printer(infostr, 10, 'foo', ncols=50)
    assert str(pbar) == format_dict(pbar, ncols=50)
    pbar.close()
    # Test {bar} removal with ncols

# Generated at 2022-06-22 05:25:40.639110
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Tests the method close of class tqdm_notebook.
    Prints some information if the test is running.
    """
    # Imports
    from time import sleep

    # Test progress bar
    tqdm_notebook(
        desc="Test progress bar",
        iterable=list(range(10)),
        leave=False
    ).close()
    tqdm_notebook(
        desc="Test progress bar",
        iterable=list(range(10)),
        leave=True
    ).close()

    # Test interrupted loop
    try:
        for _ in tqdm_notebook(desc="Test interrupted loop",
                               iterable=range(10), leave=False):
            raise KeyboardInterrupt
            sleep(0.1)
    except KeyboardInterrupt:
        print("Interrupted")

    # Test

# Generated at 2022-06-22 05:26:38.089117
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import randrange
    try:
        from ipykernel.iostream import OutStream  # NOQA: F401
    except ImportError:
        from IPython.zmq.iostream import OutStream  # NOQA: F401

    # For (non-)reference, here is the basic test of tqdm_notebook:

    with OutStream():
        x = list(tqdm_notebook(range(10), desc='1st loop'))
        assert x == list(range(10))

        x = list(tqdm_notebook(range(10), desc='Testing', leave=True))
        assert x == list(range(10))

        x = list(tqdm_notebook(range(100), desc='2nd loop'))

# Generated at 2022-06-22 05:26:41.823595
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    with tqdm.tnrange(100) as t:
        for i in range(100):
            time.sleep(0.1)
            t.update()
            # t.set_description('hello!')


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-22 05:26:53.155796
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """Test tqdm_notebook constructor"""
    import sys
    import time
    from .utils import FormatCustomText, FormatCustomTimer

    try:
        from unittest import mock  # python 3.3+
    except ImportError:
        import mock  # requires pip install mock

    with mock.patch('sys.stderr', sys.stdout):
        with mock.patch('time.sleep'):
            with mock.patch('time.time') as mock_time:
                mock_time.return_value = 0
                arg1 = ['1', '2', '3']

# Generated at 2022-06-22 05:27:03.560756
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import _range
    from .utils import _term_move_up
    with open('/dev/null', 'w') as devnull:
        with tqdm_notebook(total=2, bar_format='{l_bar}{bar}|',
                           file=devnull, leave=False, disable=False) as pbar:
            assert pbar.gui and not pbar.disable
            assert pbar.total == 2
            assert pbar.unit_scale
            assert '100%|' in pbar.format_dict['bar_format']
            pbar.write("ab")
            pbar.update(1)
            assert pbar.n == 1
            assert pbar.last_print_n == 1
            pbar.clear()
            assert pbar.n == 1 and pbar.last_print_n

# Generated at 2022-06-22 05:27:06.239431
# Unit test for function tnrange
def test_tnrange():
    with tnrange(100) as bar:
        for _ in bar:
            pass
    assert bar.n == 100

if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-22 05:27:16.708941
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Test"
    try:
        from IPython import get_ipython  # NOQA
    except ImportError:
        raise unittest.SkipTest("IPython not found, skipping test!")

    ipy = get_ipython()
    if not hasattr(ipy, 'kernel') or ipy.kernel is None:
        raise unittest.SkipTest("IPython kernel not found, skipping test!")

    with tqdm_notebook(total=2, desc="I'm in a Jupyter Notebook!", leave=True) as t:
        for i in range(2):  # 1, 2:
            sleep(0.1)
            t.update()

# Generated at 2022-06-22 05:27:27.436188
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import sys
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    t = tqdm_notebook(total=3)
    with patch.object(sys, 'stderr', sys.stdout):
        t.update()
    assert t.n == 1
    with patch.object(sys, 'stderr', sys.stdout):
        t.update(2)
    assert t.n == 3
    with patch.object(sys, 'stderr', sys.stdout):
        t.update(4)
    assert t.n == 3
    with patch.object(sys, 'stderr', sys.stdout):
        t.update(-4)
    assert t.n == 0

# Generated at 2022-06-22 05:27:29.824771
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox()) == "{total: 100%|█| Time: 0:00:00}0.00it/s"



# Generated at 2022-06-22 05:27:32.389496
# Unit test for function tnrange
def test_tnrange():
    """
    Test module function tnrange.
    """
    assert list(tnrange(10, desc='tnrange')) == list(tqdm(list(range(10)), desc='tnrange'))



# Generated at 2022-06-22 05:27:44.003308
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # self, iterable=None, desc=None, total=None, leave=False,
    # file=None, ncols=None, mininterval=0.1, maxinterval=10.0,
    # miniters=None, ascii=None, disable=False, unit='it', unit_scale=False,
    # dynamic_ncols=False, smoothing=0.3, bar_format=None, initial=0,
    # position=None, postfix=None, unit_divisor=1000, gui=False, **kwargs

    # check ncols (str/int)
    ncols = '100%'
    ncols_int = 100
    tn = tqdm_notebook(ncols=ncols)

# Generated at 2022-06-22 05:28:51.488881
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from contextlib import contextmanager
    import sys

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.stdout, sys.stderr
        try:
            sys.stdout, sys.stderr = new_out, new_err
            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    class FakeFile:
        def isatty(self):
            return True

    # check IPython display
    with captured_output() as (out, err):
        t = tqdm_notebook(total=10)
        assert t.displayed

    # check normal display

# Generated at 2022-06-22 05:28:58.751054
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    if IPY == 0:  # pragma: no cover
        raise unittest.SkipTest("IPy not found")

    import os, shutil, tempfile

    curdir = os.path.dirname(__file__)
    # tempdir = os.path.join(curdir, "tmp")  # 558
    tempdir = tempfile.mkdtemp()

    def dir_size(path):
        return sum(os.path.getsize(f) for f in os.listdir(path) if os.path.isfile(f))

    def write_big_file(tempdir, size):
        tempfile = os.path.join(tempdir, "bigfile.bin")
        with open(tempfile, "wb") as f:
            f.seek(size - 1)

# Generated at 2022-06-22 05:29:10.449339
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from sys import stderr
    from numpy.random import random
    for total in [3, 4, 5]:
        bar = tqdm_notebook(total=total)
        for i in bar:
            sleep(0.01)
            bar.set_description(str(random()))
        bar.reset(total=total)
        for i in bar:
            sleep(0.01)
            bar.set_description(str(random()))
        bar.close()
        assert not bar.displayed
    bar = tqdm_notebook(total=10, file=stderr)
    bar.reset()
    bar.close()

if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:29:21.504088
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    if IProgress is None:
        raise ImportError(
            "IProgress not found. Please update jupyter and ipywidgets.")
    # Test the progress bar container width
    t = tqdm_notebook(total=5, desc="test")
    _, pbar, _ = t.container.children
    assert pbar.layout.width == "20px"
    t.close()
    t = tqdm_notebook(total=5, position=10, desc="test")
    _, pbar, _ = t.container.children
    assert pbar.layout.width != "20px"
    t.reset()
    assert pbar.layout.width != "20px"
    t.close()
    t = tqdm_notebook(total=5, desc="test")
    _, pbar, _

# Generated at 2022-06-22 05:29:32.578227
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    class Test(tqdm_notebook):
        """
        Class to test ``tqdm_notebook.close``
        """
        def __init__(self, leave=None, disable=None, desc=''):
            self.leave = leave
            self.disable = disable
            self.desc = desc
            self.total = 2

        def update(self, n=1):
            pass


# Generated at 2022-06-22 05:29:44.882811
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm
    from random import random
    from time import sleep

    print('\n')
    # Test case 1
    for i in tqdm(range(1, 5), desc='1st loop'):
        for j in tqdm(range(1, 100), desc='2nd loop', leave=False):
            sleep(0.01)
        if (i % 2 == 0):
            print('Closing')
            tqdm.close()  # not recommended

    # Test case 2
    for i in tqdm(range(1, 5), desc='1st loop'):
        for j in tqdm(range(1, 100), desc='2nd loop', leave=False):
            sleep(0.01)
        if (i % 2 == 0):
            print('Closing')
            t