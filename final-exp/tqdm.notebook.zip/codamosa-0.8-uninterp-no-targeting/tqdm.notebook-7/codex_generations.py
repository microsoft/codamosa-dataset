

# Generated at 2022-06-22 05:20:14.935865
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        for i in tqdm_notebook(range(10)):
            pass
    except NameError:
        pass
    try:
        for i in tqdm_notebook(range(10), leave=True):
            pass
    except NameError:
        pass


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_clear()

# Generated at 2022-06-22 05:20:24.024674
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    :func:`test_tqdm_notebook`
      Unit test for constructor of class :class:`tqdm_notebook`
    """
    with tqdm_notebook(total=10, desc="Test") as t:
        assert t.container.children[0].value == "Test"
        assert t.container.children[2].value == "Test"


# Main unit test script
if __name__ == '__main__':
    from .__main__ import main  # NOQA
    main()

# Generated at 2022-06-22 05:20:27.682263
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    assert repr(TqdmHBox()._repr_json_()) == "{}"
    assert repr(TqdmHBox()._repr_json_(pretty=True)) == "{'ascii': True}"

# Generated at 2022-06-22 05:20:32.376666
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        assert pbar.total == 10

        # Clear the progress bar
        pbar.clear()

        # Check if total of the progress bar is updated
        assert pbar.total == 10



# Generated at 2022-06-22 05:20:38.842904
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests:
     - automatic/manual mode
     - with/without colour
     - with/without leave
    """
    _range = (1, 2) if IPY >= 4 else (1, 2, 1)
    # _range = (1, 3, 2)  # ignore 1.x
    for leave in (False, True):
        for manual in (False, True):
            for colour in (False, True):
                # loop is not implemented at the moment
                t = tqdm(range(*_range), leave=leave,
                         disable=manual, colour=colour)
                if not manual:
                    try:
                        for _ in t:
                            t.reset(total=5)
                    except:  # NOQA
                        pass

# Generated at 2022-06-22 05:20:49.196617
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from random import random
    N = 5
    for i in tqdm(range(N), total=N, leave=True):
        duration = random() * 0.5
        sleep(duration)

    # Test resetting
    t = tqdm(range(N), total=N, leave=True)
    sleep(0.2)
    t.reset()
    for i in t:
        duration = random() * 0.5
        sleep(duration)


if __name__ == '__main__':
    """
    Run `jupyter notebook examples/Notebook Example.ipynb`
    or `python examples/Notebook\ Example.ipynb`
    and the widget will be displayed.
    """
    # Unit test for method reset of class tqdm_notebook
    test_t

# Generated at 2022-06-22 05:20:55.926582
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test the reset method of the tqdm_notebook class
    total = 100
    t = tqdm_notebook(total=total)
    for i in range(0, total):
        t.update()
    assert t.n == total, "Initialization failed"
    t.reset()
    assert t.n == 0, "Reset failed"



# Generated at 2022-06-22 05:21:01.165440
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import unittest
    return unittest.main(
        argv=['-c', '--failfast'],
        defaultTest='test_tqdm_notebook_status_printer',
        module='test_tqdm_notebook',
    )

# Generated at 2022-06-22 05:21:11.086206
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test tqdm_notebook's status printer.
    """
    from IPython.display import HTML, display, clear_output
    import time
    pbar = tqdm_notebook.status_printer(None)
    display(pbar)
    for i in range(1, 11):
        pbar.value = i
        time.sleep(0.5)
        clear_output(wait=True)
    pbar.close()


# Leave the following line for the sole purpose of testing
if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-22 05:21:14.591546
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests_tqdm import coverage_test_tqdm_notebook___iter__
    coverage_test_tqdm_notebook___iter__()



# Generated at 2022-06-22 05:21:34.515057
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for _ in trange(4):
        # Note: I don't want to make any assumption on how
        #       the bar will be rendered, so any match is good.
        assert re.match(r"\|\d+/\d+\|", repr(tqdm_notebook()))
        tqdm_notebook().update(1)
    tqdm_notebook().close()

# Generated at 2022-06-22 05:21:40.196225
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .tests import _test_update
    with _test_update():
        n = tqdm_notebook(total=3)
        try:
            for i in n:
                n.update(i, 'n-->{}'.format(i))
        except Exception as e:
            raise e
        finally:
            n.close()


# Generated at 2022-06-22 05:21:48.894768
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._tqdm_notebook import tqdm_notebook as tqdm

    for unit_scale in [None, True, False, 1, 2]:
        for total in [None, 100, 200]:
            bar = tqdm(total=total, unit_scale=unit_scale)
            bar.check_ncols = lambda: True
            bar.display()


if __name__ == '__main__':
    r = tqdm_notebook(range(100))
    for i in r:
        pass

# Generated at 2022-06-22 05:21:58.670020
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tot_iters = 100
    with tqdm(total=tot_iters) as pbar:
        for _ in pbar:
            pass
    assert pbar.n == pbar.total == tot_iters
    with tqdm(total=tot_iters) as pbar:
        for _ in pbar:
            1 / 0  # Trigger exception
    assert pbar.n == tot_iters
    with tqdm(total=tot_iters) as pbar:
        for _ in pbar:
            pass
        try:
            pbar.close()
        except AttributeError:
            pass



# Generated at 2022-06-22 05:22:01.731579
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    with tqdm_notebook(total=10, leave=False) as bar:
        for i in range(10):
            bar.update(1)
            time.sleep(0.2)

# Generated at 2022-06-22 05:22:07.790288
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import trange

    remaining = 100
    for i in trange(100, leave=True, ncols=100, desc="test"):
        assert i == (100 - remaining)
        remaining -= 1
        if i > 75:
            raise ValueError("test")
    return True


if __name__ == "__main__":
    assert test_tqdm_notebook_update()

# Generated at 2022-06-22 05:22:13.290576
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    with tqdm_notebook(total=2) as t:
        assert isinstance(t, tqdm_notebook)
        t.update()
        t.display()
        t.write('hello world')
    assert isinstance(t, tqdm_notebook)
    assert not t.displayed



# Generated at 2022-06-22 05:22:20.114389
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import pytest  # type: ignore
    try:
        import tqdm
    except ImportError:
        raise pytest.skip("no tqdm library")
    with tqdm.tqdm_notebook(total=2, leave=True) as pbar:
        assert pbar.n == 0
        assert pbar.total == 2
        pbar.update(1)
        pbar.reset(total=4)
        assert pbar.n == 1
        assert pbar.total == 4

# Generated at 2022-06-22 05:22:23.709292
# Unit test for function tnrange
def test_tnrange():
    """
    Test function tnrange()
    """
    # Check if works properly
    """
    with tnrange(10) as n:
        [i**2 for i in n]
    """

# Generated at 2022-06-22 05:22:26.937533
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Unit test that method clear of class tqdm_notebook does not raise exception."""
    tnb = tqdm_notebook()
    return tnb.clear()

# Generated at 2022-06-22 05:23:00.191548
# Unit test for function tnrange
def test_tnrange():
    from .std import tnrange
    with tnrange(4) as t:
        for i in range(4):
            t.set_description(i)

# Generated at 2022-06-22 05:23:07.925426
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import display
    container = tqdm_notebook(
        total=5, leave=False, disable=False,
        desc='Testing constructor', ncols="100%")
    display((container,))
    for i in container:
        container.set_description("I'm in loop n#{}".format(i))
        container.update()


if __name__ == '__main__':  # pragma: no cover
    sys.stderr.write("\n*** Testing tqdm_notebook ***\n")
    test_tqdm_notebook()

# Generated at 2022-06-22 05:23:13.210034
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # test tqdm_notebook.disp() (method close)
    from tqdm import tqdm
    from time import sleep

    for _ in tqdm(range(4), ascii=True, ncols=30):
        sleep(0.01)



# Generated at 2022-06-22 05:23:15.763684
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    import os
    import numpy as np
    with tqdm_notebook(total=3, leave=True) as t:
        t.reset(total=5)
        t.set_description('Test')
        for j in range(5):
            t.update()
            time.sleep(0.1)


# Generated at 2022-06-22 05:23:26.650995
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IProgress is None:
        return  # noqa: B305  # test skipped
    from ipywidgets import FloatProgress
    from ipywidgets import HTML
    from ipywidgets import HBox
    tqdm_notebook._instances = TqdmHBox()
    c = tqdm_notebook.status_printer(None, total=None)
    assert isinstance(c, TqdmHBox)
    assert isinstance(c.children[0], HTML)
    assert isinstance(c.children[1], FloatProgress)
    assert isinstance(c.children[2], HTML)
    assert isinstance(c.children[1].max, float)
    c = tqdm_notebook.status_printer(None, total=1000)
    assert isinstance(c.children[0], HTML)

# Generated at 2022-06-22 05:23:32.117392
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange.
    """
    with tnrange(100) as t:
        for i in t:
            pass
    assert t.n == 100
    assert t.last_print_n == 0


if __name__ == '__main__':  # run tests
    test_tnrange()

# Generated at 2022-06-22 05:23:34.706413
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=1) as pbar:
        pbar.update(1)
    return



# Generated at 2022-06-22 05:23:46.210652
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook
    """

    # Import standard tqdm, since we only have test on this one
    from tqdm import tqdm as std_tqdm
    from time import sleep

    # Create standard tqdm instance and see if it is working
    t = std_tqdm(total=100)
    for i in _range(10):
        t.update()
        sleep(0.1)
    t.close()

    # Create a tqdm_notebook instance and check if it is working
    t = tqdm_notebook(total=100)
    for i in _range(10):
        t.update()
        sleep(0.1)
    t.close()

    # Create a tqdm_notebook instance and check if it is working

# Generated at 2022-06-22 05:23:55.868662
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange

    Thanks @bstriner for the initial version!
    https://github.com/tqdm/tqdm/pull/329
    """
    n = 10000
    new_tqdm = tnrange(n)
    for i in new_tqdm:
        new_tqdm.set_description("tnrange(%i)" % n)
    assert new_tqdm.n == n
    new_tqdm.close()


if __name__ == "__main__":  # pragma: no cover
    test_tnrange()

# Generated at 2022-06-22 05:24:02.741323
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from itertools import cycle
    from random import sample

    for bar_style in cycle(["success", "danger", "info"]):
        for _ in tqdm(sample(range(10), 5), bar_style="danger"):
            sleep(0.1)
        bar.reset()


# Run tests
if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-22 05:24:49.479475
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tnrange
    for _ in tnrange(int(1e6), desc='notebook iter'):
        pass


# Generated at 2022-06-22 05:24:53.763106
# Unit test for function tnrange
def test_tnrange():
    import time
    with tqdm.container(100) as t:
        for i in tnrange(100):
            time.sleep(0.01)
            t.display(i + 1)

# Generated at 2022-06-22 05:24:55.511016
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    pbar = tqdm_notebook(total=20)
    for i in range(20):
        sleep(0.1)
        pbar.update()
    pbar.clear()

# Generated at 2022-06-22 05:25:00.553626
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    t = tqdm_notebook(xrange(1, 10), desc="Test bar", leave=True)
    for j, i in enumerate(t):
        time.sleep(0.001)
        t.update(i)
    t.close()
    assert j == 8

# Generated at 2022-06-22 05:25:07.356053
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for desc in [None, "test"]:
        for total in [None, 10, 100]:
            with tqdm_notebook(desc=desc, total=total, disable=False) as t:
                for i in t:
                    t.update()
                    if i >= 10:
                        t.set_description("test2")
                        break
                t.set_description("test2")
            assert not hasattr(t, 'container')

# Generated at 2022-06-22 05:25:18.067896
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for class `tqdm_notebook`.
    """
    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()

    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            pbar.update()

    with tqdm_notebook(total=10, desc='desc') as pbar:
        for i in range(10):
            pbar.update()

    with tqdm_notebook(total=10, desc='desc') as pbar:
        for i in range(10):
            pbar.set_description('desc2')
            pbar.update()


# Generated at 2022-06-22 05:25:30.472729
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test tqdm_notebook constructor with and without IPython"""
    import time
    try:
        ipywidgets
        has_ipython = True
    except ImportError:
        has_ipython = False
    print(has_ipython)
    time.sleep(0.1)
    print('tqdm_notebook(disable=True):')
    with tqdm_notebook(disable=True) as a:
        for i in a:
            pass
    for j in a:
        pass
    # if has_ipython and not IPY:
    #     assert not a.displayed
    # else:
    #     assert a.displayed
    time.sleep(0.1)
    print('tqdm_notebook(disable=False):')

# Generated at 2022-06-22 05:25:36.358409
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=20) as pbar:
        pbar.update(10)
        assert pbar.n == 10
        assert pbar.pos == 10
        assert pbar.n == pbar.last_print_n
        assert pbar.n == pbar.last_print_t
        pbar.update(15)
        assert pbar.n == 15
        assert pbar.pos == 15


# Generated at 2022-06-22 05:25:42.518894
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from pandas.util.testing import makeCustomDataframe as mkdf
    from time import sleep

    df = mkdf(5, 2)
    for index, row in tqdm_notebook(df.iterrows(), total=len(df), desc="Iterating over row"):
        sleep(0.001)



# Generated at 2022-06-22 05:25:53.144760
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    This function requires being called via pytest --verbose,
    and will be displayed as an additional test.
    """
    pbar = tqdm_notebook(unit_scale=10)
    assert pbar.total is None
    # check that display() has no issues with total=None
    pbar.display()
    pbar.total = 10
    for i in pbar:
        for j in pbar:
            # check that display() has no issues with total=int
            pbar.display()
            pbar.add(1)
    pbar.total = "2MB"
    # check that display() has no issues with total=str
    pbar.display()
    pbar.close()

# Generated at 2022-06-22 05:28:19.585981
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox(children=[HTML(), HTML(), HTML()])) == ''

# Generated at 2022-06-22 05:28:20.478733
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    print(tqdm_notebook(total=100))

# Generated at 2022-06-22 05:28:26.939174
# Unit test for function tnrange
def test_tnrange():
    """
    Test `tnrange` function
    """
    from random import random
    list(tqdm(tqdm_notebook(range(10 ** 2)), leave=True))
    list(tqdm(tqdm_notebook(range(10 ** 6)), total=10 ** 5, leave=True))
    list(tqdm(tqdm_notebook(range(10 ** 6)), total=10 ** 5,
              leave=False, disable=False, leave=True))
    list(tqdm(tqdm_notebook(range(10 ** 6)), total=10 ** 5, leave=True))
    list(tqdm(tqdm_notebook(range(10 ** 6)), total=10 ** 5, leave=True))

# Generated at 2022-06-22 05:28:32.539875
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm_notebook(range(4)):
        sleep(.1)
        if i == 2:
            raise Exception("Test error")


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-22 05:28:38.739070
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test 1
    box = TqdmHBox()
    assert repr(box) == "<HBox: /%>"
    # Test 2
    box.pbar = TqdmHBox().pbar
    assert repr(box) == "<HBox: /%>"
    # Test 3
    box.pbar.n = 5
    box.pbar.total = 10
    assert repr(box) == "<HBox: 50%>"

# Generated at 2022-06-22 05:28:44.594004
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    range_iter = _range(100)
    for _ in tqdm_notebook(range_iter):
        sleep(.1)
    range_iter = _range(100)
    for i in range(3):
        sleep(.1)
        range_iter.update()


# Generated at 2022-06-22 05:28:55.367628
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class TqdmHBoxReprTest(TqdmHBox):
        def __init__(self, **kwargs):
            super(TqdmHBoxReprTest, self).__init__(**kwargs)
            self.pbar = TqdmHBoxReprTest.Pbar()

        class Pbar:
            format_dict = {
                "bar_format": "test_format",
            }

    TqdmHBoxReprTest(display=False)
    print(TqdmHBoxReprTest)
    assert False, "Test failed with: {}".format(TqdmHBoxReprTest)

if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-22 05:29:07.542841
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test if the method close of tqdm_notebook properly updates the
    progressbar in case of exceptions and works as intended.
    """
    from random import randint
    from time import sleep
    from traceback import print_exc
    for i in trange(10, desc='test loop', leave=False):
        # Sleep for a random time between 0 and 2 seconds
        sleep(randint(0, 2000) / 1000)
        if randint(0, 1):
            try:
                # test displaying an exception
                raise RuntimeError('this is a test exception')
            except Exception as e:
                print_exc()
                # test displaying a KeyboardInterrupt
                raise KeyboardInterrupt()
            finally:
                # close the progressbar in the current state
                trange.close()



# Generated at 2022-06-22 05:29:16.543613
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox(children=[HTML(), IProgress(min=0, max=100), HTML()])
    hbox.pbar = tqdm_notebook.status_printer()
    hbox.pbar.bar_format = " {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}] {bar}"
    for i in range(101):
        hbox.pbar.update(i)
        assert hbox.__repr__() == hbox.pbar.format_meter(), i

# Generated at 2022-06-22 05:29:24.561383
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        ipywidgets
    except ImportError:
        return None
    hb = TqdmHBox()
    ipywidgets.register('TqdmHBox', TqdmHBox)
    hb2 = ipywidgets.widget_manager.lookup('TqdmHBox')()
    assert hb.__class__ == hb2.__class__
    assert hb._repr_json_() == hb2._repr_json_()
    assert hb._repr_json_(True) == hb2._repr_json_(True)
    assert len(repr(hb)) == len(repr(hb2))