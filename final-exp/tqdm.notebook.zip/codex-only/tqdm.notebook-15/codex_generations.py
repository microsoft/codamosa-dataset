

# Generated at 2022-06-24 10:12:37.539932
# Unit test for function tnrange
def test_tnrange():
    # First, test that tnrange gives a consistent result as range/xrange
    # (after casting to list)
    for _ in tnrange(0, 100):
        pass
    assert (list(tnrange(0, 100)) ==
            list(range(0, 100)) ==
            list(xrange(0, 100)))  # NOQA: F821
    # Then test the overall tnrange and display mechanics
    # NB: this is not a perfect test as it can pass and still have a problem
    # (e.g. display could succeed but still have an incorrect display)
    # but this is better than no test...

    # Test with no delay
    with TqdmExperimentalWarning():
        t = tnrange(10, ncols=10)

# Generated at 2022-06-24 10:12:44.240403
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    if IPY == 0:
        raise unittest.SkipTest("IPython is not installed")

    kwargs = dict(min=0, max=10)
    if IPY >= 3:
        kwargs['value'] = 10
    else:
        kwargs['value'] = 0

    # Test with a total
    pbar = tqdm_notebook.status_printer(None, 10, '', ncols=80)
    pbar_ipython = IProgress(**kwargs)
    assert (pbar.__class__.__name__ == pbar_ipython.__class__.__name__)
    # test bar width
    pbar = tqdm_notebook.status_printer(None, 10, '', 80)

# Generated at 2022-06-24 10:12:49.924346
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    _tqdm = tqdm(total=2)
    _tqdm.reset(total=3)
    assert _tqdm.n == 0
    assert _tqdm.total == 3
    assert _tqdm.last_printed_n == 0
    assert _tqdm.last_print_n == 0

# Generated at 2022-06-24 10:12:56.855089
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase
    tc = TestCase('__init__')
    fmt = tqdm_notebook.status_printer(None, total=10, desc='foo')
    tc.assertEqual(fmt.children[0].value, 'foo: ')
    tc.assertEqual(fmt.children[2].value, '')

# Generated at 2022-06-24 10:13:02.743466
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for bar_style in (None, 'info', 'success'):
        for leave in (False, True):
            for total in (1, 10):
                for n in (0, 1, 5):
                    t = tqdm_notebook(total=total, leave=leave, desc=str([bar_style, leave, total, n]))
                    t.n = n
                    t.displayed = True
                    t.close()

# Generated at 2022-06-24 10:13:12.078476
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import cli_printer
    from .std import format_meter
    from .std import TMonitor
    from .utils import FormatCustomTextType

    # Test 1
    # -------
    tp = tqdm_notebook.status_printer(
        file=None, total=None, desc=None, ncols=None)
    assert (isinstance(tp, TqdmHBox)
            and isinstance(tp.children[0], HTML)
            and isinstance(tp.children[1], IProgress)
            and isinstance(tp.children[2], HTML))

# Generated at 2022-06-24 10:13:24.985128
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=2)
    t.update(1)
    # Test display of "success" style if no error
    t.close()
    # Test display of "danger" style if error
    t.n = 1
    t.total = 2
    t.close()
    assert not t.disable
    # Test not display of "danger" style if error & leave=True
    t = tqdm_notebook(total=2, leave=True)
    t.n = 1
    t.close()
    # Test not display of "success" style if error
    t = tqdm_notebook(total=2)
    t.n = 1
    t.total = 2
    t.close()


# Generated at 2022-06-24 10:13:33.011360
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    a = tqdm_notebook.status_printer(None)
    a = tqdm_notebook.status_printer(None, total=10)
    a = tqdm_notebook.status_printer(None, desc='desc')
    a = tqdm_notebook.status_printer(None, total=10, desc='desc')
    a = tqdm_notebook.status_printer(None, total=10, desc='desc', ncols=10)
    return a

# Generated at 2022-06-24 10:13:45.544049
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from six.moves import xrange
    from tqdm.auto import tqdm
    format = '{l_bar}{bar}{r_bar} |{n_fmt}/{total_fmt}[{elapsed}<{remaining}]'

    # First we test the progress bar with unknown length
    with tqdm(xrange(3), total=None, bar_format=format) as t:
        assert t.n == 0
        assert t.last_print_n == 0
        assert t.total == None
        assert t.last_print_n == 0
        assert t.ncols == 100

# Generated at 2022-06-24 10:13:59.547738
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:
        return

    def dummy_f(*_, **__):
        pass

    for unit in '', 'kilo', 'Mega', 'Giga', 'Tera':
        for total in 1, 1000, 1000000:
            # Test different unit scale
            kwargs = {'unit_scale': True, 'desc': unit,
                      'total': total, 'unit': unit}

            # Test different ncols
            for ncols in '', '50%', 100, None:
                kwargs['ncols'] = ncols
                tqdm_notebook.status_printer(dummy_f, **kwargs)

    # Test unknown total (text format only, no widget)
    kwargs = {'desc': 'no total', 'total': None, 'ncols': None}

# Generated at 2022-06-24 10:14:01.303619
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t = tqdm_notebook([1, 2, 3], desc='test', total=3)
    for _ in t:
        pass
    t.close()


# Generated at 2022-06-24 10:14:04.228666
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from random import random
    for _ in tqdm(list(range(50))):
        _ = random()
        for __ in tqdm(list(range(50))):
            __ = random()

if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:14:16.150531
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from datetime import timedelta, datetime as dt
    import uuid
    # Create a simple progress bar
    hb = TqdmHBox()
    hb.pbar = object()
    hb.pbar.format_dict = {'bar_format': '{bar}'}
    hb.pbar.smoothing = 0.5
    hb.pbar.elapsed_td = timedelta(seconds=1)
    hb.pbar.start_t = dt.now()
    hb.pbar.last_print_t = dt.now()
    hb.pbar.n = 1
    hb.pbar.total = None

# Generated at 2022-06-24 10:14:25.181612
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from .utils import format_interval
    import math
    import time

    pbar = tqdm(total=10)
    hbox = TqdmHBox([])
    hbox.pbar = pbar
    assert repr(hbox) == '| 0% | 0/10 [00:00<?, ?it/s]'
    assert repr(hbox) == str(hbox)
    pbar.update(5)
    hbox.color = 'red'
    assert repr(hbox, pretty=True) == pbar.format_meter(**hbox._repr_json_(True))
    pbar.n = 10
    time.sleep(1)
    pbar.n = 12
    time.sleep(1)
    pbar.close()

    pbar = tq

# Generated at 2022-06-24 10:14:30.548663
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import pytest
    from pytest import approx
    from tqdm.autonotebook import tqdm
    with tqdm(total=10, desc='test_update') as pbar:
        for i in range(3):
            pbar.update(2)
            assert pbar.n == approx((i + 1) * 2)

# Generated at 2022-06-24 10:14:41.982831
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit tests for the constructor of tqdm_notebook.
    """
    with tqdm_notebook(total=9,
                       desc='Notebook GUI',
                       unit='it',
                       mininterval=0.5,
                       miniters=1,
                       unit_scale=True,
                       dynamic_ncols=False,
                       leave=True,
                       disable=False,
                       bar_format='{n_fmt}/{total_fmt}{bar}{n_fmt}{r_bar}',
                       postfix=None,
                       colour="blue") as t:
        for i in t:
            pass

        assert not t.disable
        assert t.total == 9
        assert t.n == 9
        assert t.mininterval == 0.5
        assert t.miniters == 1


# Generated at 2022-06-24 10:14:51.017323
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    x = tqdm_notebook(range(100000000), desc='Clear Test', leave=True,
                      mininterval=0.0)
    for _ in x:
        if x.n == 1000:
            x.clear()
            assert x.n == 0
            x.update(500)
            assert x.n == 500
            x.clear()
            x.update(500)
            assert x.n == 500
            x.clear(nolock=True)  # Clear without lock
            assert x.n == 0

if __name__ == '__main__':  # pragma: no cover
    """
    Example notebook bar:
    """
    try:
        from tqdm.notebook import tqdm
    except ImportError:
        raise ImportError("tqdm.notebook requires ipywidgets")

# Generated at 2022-06-24 10:14:56.273929
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox._repr_json_() == {}
    hb = TqdmHBox()
    assert str(hb) == ''
    assert repr(hb) == ""
    assert hb._repr_json_() == {}
    assert hb._repr_json_(True) == {}
    assert hb._repr_pretty_('pp') == None
    hb.pbar = std_tqdm()
    hb.pbar.n = 5
    hb.pbar.total = 10
    assert str(hb) == '50%|#########5/10'

# Generated at 2022-06-24 10:15:08.790621
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import redirect_stderr
    from io import StringIO

    # io.StringIO is not used because it's not supported
    # on python 2.7 (module io )
    capturer = StringIO()
    with redirect_stderr(capturer):
        with tqdm(total=10) as pbar:
            for _ in range(5):
                pbar.update()
            pbar.close()

    captured = capturer.getvalue()
    assert pbar.n == 5
    assert not captured

    with redirect_stderr(capturer):
        with tqdm(total=10) as pbar:
            for _ in range(5):
                pbar.update()
            pbar.close()
    captured = capturer.getvalue()
    assert pbar.n == 5

# Generated at 2022-06-24 10:15:18.473358
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test to check if display and close are called
    """
    try:
        from unittest.mock import patch
    except ImportError:  # Python 2
        from mock import patch

    with patch.object(tqdm_notebook, 'display') as display_mock:
        t = tqdm_notebook(total=10)
        t.update(1)
        t.update(2)
        t.update(3)
        t.display(check_delay=False)
        t.display(close=True, check_delay=False)
        assert display_mock.call_count == 4
        # now make sure that if display() is called with pos=None
        # then it will not call display() (pos=None when there's no update)

# Generated at 2022-06-24 10:15:28.712873
# Unit test for function tnrange
def test_tnrange():
    from time import sleep  # pragma: no cover
    for i in tnrange(10, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop'):
            for _ in tnrange(100, desc='3nd loop'):
                sleep(0.01)
    for i in tnrange(10, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop'):
            for _ in tnrange(100, desc='3nd loop'):
                sleep(0.01)
            break

# Generated at 2022-06-24 10:15:36.880845
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for n_iter in (None, 10):
        for n_chars in (None, 10):
            for ncols in (None, "100px", 100):
                for total in (100, None):
                    for leave in (True, False):

                        tq = tqdm_notebook(total=total,
                                           ncols=ncols,
                                           leave=leave)
                        tq.reset(total=n_iter)
                        tq.update(1)
                        childs = tq.container.children

                        assert len(childs) == 3
                        ltext, pbar, rtext = childs

                        if ncols:
                            # ncols could be 100, "100px", "100%"
                            ncols = str(ncols)  # ipywidgets only accepts string

# Generated at 2022-06-24 10:15:43.237543
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from IPython.display import display
    from numpy.testing import assert_equal

    class Test(unittest.TestCase):
        def test_formatter(self):
            pbar = tqdm_notebook(total=10, ncols=100)
            box = pbar.container

            # check repr_html and _repr_pretty_
            assert_equal(box.__repr__(True), box.__repr__(False))

            # check update
            self.assertTrue(box.__repr__(False).startswith("  0%|          "))
            pbar.update(10)

# Generated at 2022-06-24 10:15:52.041529
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from sys import stderr
    from tqdm import tqdm_notebook
    import time
    for test_class in [tqdm_notebook]:
        with test_class(total=10, file=stderr, leave=True) as pbar:
            for i in range(10):
                time.sleep(1)
                pbar.update()
        with test_class(total=10, file=stderr, leave=False) as pbar:
            for i in range(10):
                time.sleep(1)
                pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:16:02.248330
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from unittest import TestCase

    class TqdmUpdate(TestCase):
        "Make sure `update()` respects `position`"

        class MockTqdmNotebook(tqdm_notebook):  # noqa
            "Saves `position` in `last_pos`"

            last_pos = 0

            def display(self, *args, **kwargs):
                self.last_pos = self.position
                super(TqdmUpdate.MockTqdmNotebook, self).display(*args, **kwargs)

        def test_pos(self):
            "Test `position` sync"
            t = self.MockTqdmNotebook(total=10, ncols=70)
            for i in t:
                t.update(5)

# Generated at 2022-06-24 10:16:05.185642
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        iterable = tqdm_notebook(range(2))
        next(iterable)
        iterable.clear()
        next(iterable)
    except Exception as e:
        return "Error"
    return "Success"

# Generated at 2022-06-24 10:16:15.529540
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # test that it prints "100%" when total = None
    tqdm_notebook.status_printer(sys.stdout).pbar.max
    tqdm_notebook.status_printer(sys.stdout, total=123).pbar.max
    tqdm_notebook.status_printer(sys.stdout, total=123, ncols=100).pbar.max
    tqdm_notebook.status_printer(sys.stdout, total=123, ncols="100px").pbar.max
    tqdm_notebook.status_printer(sys.stdout, total=123, ncols="100%").pbar.max


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:16:19.684693
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for the function ``tnrange``.
    Basic use case with no arguments.
    """
    for _ in tnrange():
        break


if __name__ == "__main__":  # pragma: no cover
    from doctest import testmod
    testmod()  # print "tests failed" if any

# Generated at 2022-06-24 10:16:23.813142
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=5) as t:
        for i in range(5):
            t.clear()
            t.update()


# Generated at 2022-06-24 10:16:27.758059
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm.utils import _term_move_up
    with tqdm(total=9) as bar:
        bar.update()
        bar.close()
        print(_term_move_up() + "Test")  # NOQA

# Generated at 2022-06-24 10:16:38.085154
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Test tqdm_notebook constructor by checking that the
    repr output is equivalent to the repr output of a tqdm object.
    """

# Generated at 2022-06-24 10:16:48.575354
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from inspect import getsourcefile
    from os.path import abspath
    from sys import modules
    from time import sleep

    # Download and import pyglet from
    # https://bitbucket.org/pyglet/pyglet/get/tip.zip and ensure that this
    # file is named pyglet/__init__.py and is located in the current working
    # directory
    from pyglet.window import Window as pygletWindow

    # Unit test function
    def test(x):
        raise x

    # Hide pyglet

# Generated at 2022-06-24 10:17:00.717541
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    pbar = tqdm_notebook(total=100)
    assert pbar.total == 100
    assert pbar.container.children[-2].bar_style != 'danger'
    pbar.close()
    assert pbar.container.children[-2].bar_style != 'danger'

    pbar = tqdm_notebook(total=100)
    assert pbar.total == 100
    assert pbar.container.children[-2].bar_style != 'danger'
    pbar.update(50)
    assert pbar.container.children[-2].bar_style != 'danger'
    pbar.close()
    assert pbar.container.children[-2].bar_style != 'danger'

    pbar = tqdm_notebook(total=100)
    assert pbar.total == 100
   

# Generated at 2022-06-24 10:17:08.842234
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert TqdmHBox().__repr__() == TqdmHBox().__repr__()
    assert TqdmHBox().__repr__(True) == TqdmHBox().__repr__(True)
    assert str(TqdmHBox().__repr__()) == str(TqdmHBox().__repr__())
    assert str(TqdmHBox().__repr__(True)) == str(TqdmHBox().__repr__(True))


# Unit tests for the rest

# Generated at 2022-06-24 10:17:18.949276
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    desc = "Loop:"
    bar = std_tqdm.format_dict['bar']
    bar = re.sub(r'\{desc\}', desc, bar)
    bar = re.sub(r'\{bar\}', '<bar/>', bar)
    bar_reg = re.sub(r'\{bar\}', '\t{bar}', bar)
    bar_reg = re.sub(r'\{.*?\}', '.*?', bar_reg)
    cls = TqdmHBox()
    cls.pbar = tqdm_notebook()
    cls.pbar.desc = desc
    assert re.match(bar_reg, cls.__repr__())
    assert re.match(bar_reg, cls.__repr__(pretty=True))


# Generated at 2022-06-24 10:17:25.892558
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    try:
        import numpy as np
    except ImportError:
        np = None
    for n in tqdm(range(10), total=10):
        sleep(0.01)
    for n in tqdm(range(50), total=100):
        sleep(0.01)
    if np is not None:
        x = tqdm(np.zeros(10))
        for i in range(10):
            sleep(0.01)
            x.update()
        x.reset(total=20)
        for i in range(20):
            sleep(0.01)
            x.update()

# Generated at 2022-06-24 10:17:30.827723
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    container = TqdmHBox(children=[HTML(), HTML()])
    try:
        container._repr_json_(pretty=False)
    except Exception:
        raise Exception("TqdmHBox: constructor failed")


if __name__ == "__main__":  # pragma: no cover
    test_TqdmHBox()

# Generated at 2022-06-24 10:17:38.297311
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from sys import stderr
    from time import sleep

    try:
        from IPython.display import clear_output
        from IPython import get_ipython
    except ImportError:
        raise
    
    # Check all bar positions
    for position in ['', 'left', 'right']:
        with tqdm_notebook(total=10, position=position) as bar:
            for i in range(10):
                sleep(0.1)
                bar.update()



# Generated at 2022-06-24 10:17:46.337485
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    a = tqdm(total=5)
    a.update(3)
    a.close()
    b = tqdm(total=5)
    b.update(5)
    b.close()
    c = tqdm(total=5)  # test for #507
    c.close()
    d = tqdm(total=5)  # test for #507
    d.update(3)
    d.close()



# Generated at 2022-06-24 10:17:52.235746
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Unit test to check TqdmHBox class constructor works correctly."""
    abar = std_tqdm()
    hbox = TqdmHBox(children=[HTML(), IProgress(), HTML()], pbar=abar)
    assert repr(hbox) == abar.format_meter()

if __name__ == "__main__":
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    test_TqdmHBox()

# Generated at 2022-06-24 10:17:56.437984
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from random import randint
    from sys import stderr
    from time import sleep

    # Create the class instance
    with tqdm_notebook(total=100, bar_format='{desc}: {bar}') as t:
        # Update status and write to stderr
        for i in range(100):
            sleep(0.01)
            t.set_description('Step %i' % randint(1, 100))
            t.update()


# Generated at 2022-06-24 10:17:59.729960
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        for i in tqdm_notebook(range(10)):
            if i == 5:
                raise Exception('A test exception')
    except:
        pass

# Generated at 2022-06-24 10:18:03.003485
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time

    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.clear()
            time.sleep(1)
            t.update()

# Generated at 2022-06-24 10:18:09.940556
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Test tqdm.notebook.tqdm_notebook()"
    with tqdm_notebook(total=5) as pbar:
        pbar.update(2)
        assert pbar.ncols is None
        pbar.ncols = "100%"
        assert pbar.ncols == "100%"
        assert pbar.total == 5
        assert pbar.n == 2
        pbar.update(2)
    assert pbar.total == 5
    assert pbar.n == 5
    assert not hasattr(pbar, 'container')



# Generated at 2022-06-24 10:18:19.354817
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import tqdm
    from .utils import _range
    from .tqdm import _term_move_up

    # Test tqdm_notebook
    with tqdm(total=5, desc='test_notebook') as t:
        assert t.total == 5
        t.update(2)
        t.reset(total=10)
        assert t.total == 10
        t.reset(total=0)
        assert t.total == 10
        t.reset(total=None)
        assert t.total == 10
        t.reset()
        assert t.total == 10
        assert t.n == 0
        t.update(3)
        assert "test_notebook: 3it" in t.__repr__()
        t.reset()
        assert t.total == 10
        assert t

# Generated at 2022-06-24 10:18:22.757257
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Test TqdmHBox representation
    """
    bar = TqdmHBox()
    bar.pbar = tqdm_notebook(total=10)
    bar.pbar.n = 5
    repr(bar)
    # silent

# Generated at 2022-06-24 10:18:30.369404
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .std import tqdm
    import sys
    try:  # Py2
        from StringIO import StringIO
    except ImportError:  # Py3
        from io import StringIO
    # Checking values of progress bar
    for total in [None, 100]:
        for leave in [False, True]:
            for ncols in [None, 50, "50px", "50%", "50.0px"]:
                if total is None:
                    fp = StringIO()
                    t = tqdm_notebook(ncols=ncols, leave=leave, file=fp)
                    assert t.ncols is None
                    assert t.container.pbar.layout.width == "20px"

# Generated at 2022-06-24 10:18:39.499922
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    ipywidgets.Text()
    with tqdm_notebook(total=1, desc='foo', leave=False) as pbar:
        assert pbar.container.children[1].value == 0
        pbar.update()
        assert pbar.container.children[1].value == 1
        pbar.clear()
        assert pbar.container.children[1].value == 0
        pbar.update()
        assert pbar.container.children[1].value == 1
        with pbar:
            assert pbar.container.children[1].value == 1
            pbar.clear()
            assert pbar.container.children[1].value == 0
            pbar.update()
            assert pbar.container.children[1].value == 1

# Generated at 2022-06-24 10:18:44.881879
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from collections import Iterable
    except ImportError:
        return  # SKIP
    # Test clear with simple iterator
    l = list(range(10))
    n = tqdm(l, disable=True)
    n.clear()
    # Test with tqdm() iterator
    n = tqdm(tqdm(l, disable=True), disable=True)
    n.clear()

# Generated at 2022-06-24 10:18:47.653949
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Unit test for method __repr__ of class TqdmHBox.
    """
    b = TqdmHBox()
    b._repr_json_()
    # b._repr_pretty_(None)


# Generated at 2022-06-24 10:18:54.871367
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

    with tqdm_notebook(total=10, unit='i') as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(1)

if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:19:05.623971
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import platform
    import unittest
    import warnings

    class TestClose(unittest.TestCase):
        def test(self):
            # Test that no error occurs when closing an ipywidgets bar
            with warnings.catch_warnings(record=True):
                import ipywidgets
                t = tqdm_notebook(total=10, desc='test')
            for i in range(10):
                t.update()
            t.close()
            self.assertLess(t.n, t.total)
            t.reset(total=10)
            self.assertEqual(t.n, 0)
            t.close()
            if platform.python_implementation() != 'PyPy':
                # pypy raises an error in IPython
                self.assertEqual(t.n, 0)


# Generated at 2022-06-24 10:19:13.115797
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class FakeTqdm(object):
        def __init__(self):
            self.format_dict = {'bar_format': '{percentage:3.0f}% |{bar}|'}
            self.format_meter = lambda **x: "test format meter"

    # Instantiate a TqdmHBox and test the result of the different cases
    bar = TqdmHBox(pbar=FakeTqdm())
    assert str(bar) == "test format meter"

    bar = TqdmHBox()
    assert str(bar) == "<ipywidgets.widgets.widget_box.HBox object at 0x(.+)>"

# Generated at 2022-06-24 10:19:17.828320
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update(1)
            t.reset()


if __name__ == "__main__":
    from doctest import testmod
    testmod(verbose=True)

# Generated at 2022-06-24 10:19:25.826919
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    try:
        from IPython.display import display  # , clear_output
        from IPython import get_ipython  # noqa: F401
        from traitlets import TraitError
    except ImportError:
        return
    import subprocess
    from .autonotebook import tqdm as atqdm
    from .std import tqdm as stqdm

    ip = get_ipython()
    if not ip or not ip.has_trait('kernel'):
        return

    def test():
        with atqdm(total=5) as t:
            for i in t:
                pass

    def test_gen():
        with atqdm(total=5, ncols=10) as t:
            for i in t:
                yield i


# Generated at 2022-06-24 10:19:31.477783
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    __test_tqdm_notebook___iter__(0)
    __test_tqdm_notebook___iter__(1)
    __test_tqdm_notebook___iter__(5)
    __test_tqdm_notebook___iter__(100)
    __test_tqdm_notebook___iter__(100000000)
    print(sys.version)



# Generated at 2022-06-24 10:19:35.423726
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    h = TqdmHBox()
    h.pbar = tqdm_notebook()
    assert h.__repr__() == '0it [00:00, ?it/s]'



# Generated at 2022-06-24 10:19:46.510136
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from numpy.testing import assert_equal
    t = tqdm_notebook(total=2, leave=False)
    for i in range(2):
        t.update(1)
        sleep(0.5)
    with open('tqdm_notebook_update.txt', 'rb') as f:
        assert isinstance(f.read(), bytes)


if __name__ == "__main__":  # pragma: no cover
    # simple test
    from time import sleep
    import numpy as np
    with tqdm(total=10) as t:
        for i in range(10):
            t.set_postfix(i=i, t=t.format_interval(t.last_print_t))
            sleep(0.3)


# Generated at 2022-06-24 10:19:54.290942
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    t = tqdm_notebook(total=2)
    t.reset(total=3)
    t.reset()
    # __repr__
    t.close()
    t = trange(0)  # no total
    assert t._repr_json_(pretty=True) == {}
    t.close()
    t = trange(0)
    with t:
        t.reset()
        # display
        t.disp()
        # colour
        t.colour = "#00ff00"
        t.close()
        # __iter__
        try:
            for _ in t:
                assert False
        except:  # NOQA
            assert t.container.children[-2].bar_style == 'danger'
            t.close()
        # update

# Generated at 2022-06-24 10:20:05.375320
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test repr
    repr_dict = {'total': 100, 'desc': 'desc', 'n': 0, 'ncols': 80,
                 'ascii': False, 'unit_scale': False, 'unit': 'it',
                 'postfix': None, 'bar_format': '{l_bar}{bar}{r_bar}'}
    # Test both pretty-print and not pretty-print alternatives
    for pretty in [None, False, True]:
        assert (TqdmHBox()._repr_json_(pretty) == {})
        assert (TqdmHBox(pbar=object())._repr_json_(pretty) == {})
        hbox = TqdmHBox(pbar=object())
        hbox.pbar.format_dict = repr_dict

# Generated at 2022-06-24 10:20:14.527184
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    # Mock a pbar
    class PBar:
        bar_format = "{bar}"
        format_dict = {'bar': '#'}

        def format_meter(self, **kwargs):
            kwargs.pop('ncols', None)
            return self.bar_format.format(**self.format_dict)

    # __repr__ = pretty = coloured
    foo = TqdmHBox()
    foo.pbar = PBar()
    assert repr(foo) == u'\u001b[0;34m#\u001b[0m'
    # _repr_json_ = not pretty = not coloured
    dic = foo._repr_json_(pretty=False)
    assert dic == {'bar': '#'}
    # __repr__ =

# Generated at 2022-06-24 10:20:23.943079
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    unit tests for method close of class tqdm_notebook
    """
    from tqdm.auto import tqdm
    from time import sleep

    # Check that total=None does not raise an exception
    with tqdm(total=None) as pbar:
        pbar.update()

    # Check if the progressbar is properly closed
    with tqdm(total=3) as pbar:
        pbar.update()
        sleep(1)
        pbar.update()
        sleep(1)
        pbar.update()
        sleep(1)
        pbar.update(1)

    # Check if the progressbar leaves or not
    with tqdm(total=3, leave=False) as pbar:
        pbar.update(3)

    # Check if the progressbar leaves or not before completion

# Generated at 2022-06-24 10:20:31.386637
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():

    import sys

    return  # cannot test easily atm, is mocking display() really needed?

    class MockWidget(TqdmHBox):
        def _repr_json_(self):
            return '<MockWidget>'

        def __repr__(self):
            return '<MockWidget>'

        def _repr_pretty_(self, _, **__):
            pass

    # Simple test
    with std_tqdm.externalipython():
        from IPython.html.widgets import FloatProgress
        from IPython.html.widgets import HTML
        from IPython.html.widgets import HBox

        IProgress, HTML, HBox = FloatProgress, HTML, HBox

        import io

        stdout = sys.stdout

# Generated at 2022-06-24 10:20:35.100701
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange.
    """
    with tnrange(3, desc='Test', leave=True) as t:
        for x in t:
            pass


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:20:43.891420
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import random

    for pretty in [None, False, True]:
        pbar = TqdmHBox()
        pbar.format_dict = {'n': random.randint(1, 1000)}
        assert re.match(r'(\x1b\[34m\x1b\[1m|)  0%|\x1b\[39m(\x1b\[22m\x1b\[0m|) : [\w ]+ 0/\w{1,4} [\?]\?/s',  # NOQA
                         pbar.__repr__(pretty))
        pbar.format_dict['n'] = 100

# Generated at 2022-06-24 10:20:53.669808
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from unittest import mock
    except ImportError:  # Python-2 backport
        import mock
    # Create a testclass
    class TestClass(tqdm_notebook):
        def __init__(self, *args, **kwargs):
            self._n = 0
            super(TestClass, self).__init__(*args, **kwargs)

        def display(self, *args, **kwargs):
            self._n += 1

    t = TestClass(total=10)
    with mock.patch('IPython.display.display') as mock_method:
        t.display()
    assert mock_method.call_count == 1
    t = TestClass(total=10)

# Generated at 2022-06-24 10:20:56.329476
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    assert repr(TqdmHBox()) == '{desc: 100%|██████████| 3/3 [00:00<?, ?it/s]}'

# Unit tests for class tqdm_notebook

# Generated at 2022-06-24 10:21:06.670943
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for i in tqdm(range(0, 10)):
        sleep(.1)
    for i in tqdm(range(0, 10), leave=True):
        sleep(.1)
    for i in tqdm(range(10, 0, -1)):
        sleep(.1)
        if i == 3:
            break
    for i in tqdm(range(0, 10)):
        sleep(.1)
    try:
        for i in tqdm(range(0, 10)):
            raise Exception()
    except:
        pass
    for i in tqdm(range(0, 10), leave=True):
        sleep(.1)
    for i in tqdm(range(0, 10)):
        sleep(.1)

# Generated at 2022-06-24 10:21:13.572106
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output
    from time import sleep

    try:
        pbar = tqdm_notebook(total=2)
        for i in range(3):
            sleep(.1)
            pbar.update()
        sleep(.1)
        clear_output()
    except KeyboardInterrupt:
        pass
    finally:
        pbar.close()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:21:24.063954
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from IPython.display import display  # noqa F401
    except ImportError:
        return
    import time
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # NOQA

    with patch('IPython.display.display') as ipp_display:
        tn = tqdm_notebook(total=1)
        tn.display(close=True)
        assert ipp_display.called
        assert tn.displayed

        tn.close()
        tn.display(close=True)
        ipp_display.assert_called_with(tn.container)

    with patch('IPython.display.display') as ipp_display:
        tn = tqdm_notebook(total=1)

# Generated at 2022-06-24 10:21:34.690738
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    To run: `python tests/test_tqdm`
    """

    # Mock the actual print function
    actual_print = print

    def print(*args, **kwargs):
        """
        Mock print function to check that the correct strings are passed
        """
        # Get string from argument list
        args = [str(arg) for arg in args]

        # Check for bar update
        if not args:
            return

        # Check for end of bar
        if args[0].endswith('\n'):
            return

        # Check for bar printing
        actual_print(*args, **kwargs)  # pragma: no cover

    # Replace actual print function by our mock
    from builtins import print
    print = print

    #

# Generated at 2022-06-24 10:21:35.831831
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tn = tqdm_notebook(total=100, file=None)
    tn.display()

# Generated at 2022-06-24 10:21:43.600202
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = IProgress(min=0, max=100)
    pbar.value = 73
    pbar.bar_style = 'info'
    ltext = HTML('Hello ')
    rtext = HTML('World!')
    container = TqdmHBox(children=[ltext, pbar, rtext])
    assert (str(container) ==
            'Hello World!|█████████████████████████████████████████████-| 73/100')

# Generated at 2022-06-24 10:21:54.717158
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from ipywidgets import IntProgress
    except ImportError:
        from IPython.html.widgets import IntProgress
    from ipywidgets import HBox

    class tqdm_notebook_test(tqdm_notebook):
        """
        Overrides `__init__` to force testing of private `_decr_instances`
        function.
        """
        def __init__(self, *args, **kwargs):
            super(tqdm_notebook_test, self).__init__(*args, **kwargs)
            self.__class__._decr_instances()


# Generated at 2022-06-24 10:22:02.328144
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        if i == 1:
            tnrange(100, desc='2nd loop').close()
            break

    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
            if j == 1:
                break

    with tnrange(50) as pbar:
        for i in range(50):
            sleep(0.01)
            pbar.set_description('Parsing %d%%' % (i + 1))

# Generated at 2022-06-24 10:22:05.811721
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    t = tqdm_notebook(range(5), desc='testing')
    t.clear()
    pytest.raises(AttributeError, lambda: t.format_dict)

# Generated at 2022-06-24 10:22:09.114771
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .tests import _test_tqdm_notebook
    return _test_tqdm_notebook(tqdm_notebook)


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:22:11.806874
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .tests import test_tqdm
    test_tqdm(tqdm, file=None)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:22:13.453361
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(10)):
        # do something
        pass


# Generated at 2022-06-24 10:22:20.498048
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    import re
    from contextlib import contextmanager
    from io import StringIO
    tqdm._instances.clear()

    def wcswidth(s):
        """
        Python 2/3 compatible unicode width function.
        """
        if sys.version_info[0] >= 3:
            from unicodedata import east_asian_width
            return sum([east_asian_width(c) in 'WF' and 2 or 1 for c in s])
        else:
            import unicodedata
            return sum([unicodedata.east_asian_width(c) in 'WF' and 2 or 1
                        for c in s])

    @contextmanager
    def captured_output():
        new_out, new_err = StringIO(), StringIO()
        old_out, old_err = sys.std

# Generated at 2022-06-24 10:22:25.318201
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(_range(10)):
        sleep(0.5)
    for i in tqdm_notebook(_range(10)):
        sleep(0.5)
        raise Exception('Uncaught Exception')
    for i in tqdm_notebook(_range(10)):
        sleep(0.5)


# Generated at 2022-06-24 10:22:32.893608
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    a = tqdm_notebook(range(5), mininterval=0)
    for i in a:
        a.clear()
        assert a.n == i
        assert a.last_print_n == i
    assert a.n == a.last_print_n == 4


if __name__ == '__main__':
    test_tqdm_notebook_clear()