

# Generated at 2022-06-24 10:12:39.036176
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stderr
    from time import sleep
    from datetime import timedelta


# Generated at 2022-06-24 10:12:46.805113
# Unit test for function tnrange
def test_tnrange():
    """
    test trange with counter
    """
    import time
    from numbers import Number

    total = 20
    r = range(total)
    t = tnrange(total)
    assert r == t

    t = tnrange(total)
    t.update(1)  # counter = 1
    assert t.n == 1
    for i in t:
        assert isinstance(i, Number)
        time.sleep(.1)

    t = tnrange(total)
    t.update(1)  # counter = 1
    assert t.n == 1
    for i in t:
        assert isinstance(i, Number)
        time.sleep(.1)

    with tnrange(total) as t:
        for i in t:
            assert isinstance(i, Number)
            time.sleep

# Generated at 2022-06-24 10:12:59.292168
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    from sys import version_info as v
    if v[0] < 3 and v[1] < 3:  # pragma: no cover
        raise SkipTest("Does not work on Python < 3.3")

    with tqdm_notebook(total=1, unit='B', unit_scale=False, leave=True) as t:
        assert t.total == 1
        t.update()



# Generated at 2022-06-24 10:13:01.632061
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(range(10), leave=True)
    for i in t:
        pass
    t.clear()  # won't raise error

# Generated at 2022-06-24 10:13:11.028460
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_raises
    try:
        raise Exception
    except Exception:
        exc_info = sys.exc_info()

    for n in tqdm(_range(10), desc='__iter__', leave=False):
        if n > 5:
            raise exc_info[0](exc_info[1]).with_traceback(exc_info[2])
        assert n in list(_range(10))

    for n in tnrange(10, desc='tnrange'):
        assert n in list(_range(10))

    for n in tnrange(10, desc='tnrange',
                     total=20):  # Test dynamic total
        assert n in list(_range(10))


# Generated at 2022-06-24 10:13:15.835019
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(5)):
        assert i in range(5)



# Generated at 2022-06-24 10:13:19.146245
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook.clear()
    t = tqdm_notebook(total=300, leave=True, unit_scale=0.1)
    for i in _range(10):
        t.update(30)


# Generated at 2022-06-24 10:13:23.923288
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hb = TqdmHBox()
    hb.pbar = std_tqdm()
    assert hb.__repr__().startswith('  0%|')
    assert hb.__repr__(True).startswith('  0%|')

# Generated at 2022-06-24 10:13:35.753085
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import _decode
    from .std import tqdm as std_tqdm
    from .std import TMonitor
    from time import sleep
    from os import devnull

    class _tqdm_notebook(tqdm_notebook):
        def display(self, **kwargs):
            return super(_tqdm_notebook, self).display(**kwargs)

    # We need to catch `display` output
    # NB: `devnull` cannot be called with a unicode filename (#491)

# Generated at 2022-06-24 10:13:43.743732
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY < 4:
        from nose import SkipTest
        raise SkipTest("IPython/Jupyter Notebook widget test not available")
    from IPython.display import clear_output
    # Initialize widgets
    clear_output()
    with tqdm_notebook(total=100, desc='main') as pbar:
        for i in range(10):
            pass
        pbar.reset()
        pbar.set_description('new desc')
        for i in range(10):
            pass


# Generated at 2022-06-24 10:13:53.780202
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # test no arguments
    assert repr(TqdmHBox()) == {}

    # test with a tqdm_notebok (note: does not really display)
    with tqdm_notebook(total=1) as t:
        assert repr(t.container) == t.format_meter()

    # test with a tqdm
    with tqdm(total=1) as t:
        assert repr(t.container) == t.format_meter()

    # test with a tqdm (non-initialised)
    t = tqdm(total=1)
    assert repr(t.container) == "{bar_format}<bar/>{n_fmt}/{total_fmt}"

# Generated at 2022-06-24 10:14:02.233542
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    a = TqdmHBox()
    assert repr(a) == 'HBox(layout=Layout(height=' + (
        '\'100px\'' if sys.version_info[0] >= 3 else '100') + '))'
    b = TqdmHBox(pbar='hi')
    assert repr(b) == 'HBox(layout=Layout(height=' + (
        '\'100px\'' if sys.version_info[0] >= 3 else '100') + '))'
    b = TqdmHBox(pbar='hi', layout={'other': 3})
    assert repr(b) == 'HBox(layout=Layout(height=' + (
        '\'100px\'' if sys.version_info[0] >= 3 else '100') + ', other=3))'
    b = TqdmHBox

# Generated at 2022-06-24 10:14:07.859421
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import sys
    import contextlib
    from io import StringIO
    sio = StringIO()

    @contextlib.contextmanager
    def captured():
        sys.stdout = sio
        yield sio
        sys.stdout = sys.__stdout__

    with captured():
        print(TqdmHBox())

    assert sio.getvalue() == ""
    sio.close()

    with captured():
        print(TqdmHBox(pbar=1))

    assert sio.getvalue().strip() == "0.00it/s"
    sio.close()


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:14:18.044055
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    h = TqdmHBox(children=[HTML(), IProgress(min=0, max=1), HTML()])
    h.pbar = proxy(tqdm_notebook())
    assert h.__repr__().startswith('[    ')
    assert h.__repr__(True).startswith('...')


if __name__ == "__main__":
    # Uncomment the following lines to display the widget
    # from IPython.display import display  # , clear_output
    # display(tqdm_notebook())
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:14:26.330755
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in [True, False]:
        for total, n in [((i, j) for i in range(5) for j in range(i + 1))]:
            # test successful bar
            t = tqdm_notebook(total=total, leave=leave)
            t.update(n)
            t.close()
            if total is None or total > n:
                # No total or not finished bar -> bar should still be displayed
                assert t.container.visible
            elif n == total:
                # Successful bar -> will be closed
                assert not t.container.visible
                assert t.container.bar_style == 'success'
            # test interrupted bar
            t = tqdm_notebook(total=total, leave=leave)
            t.update(n)

# Generated at 2022-06-24 10:14:39.509821
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    from time import sleep
    from numpy.random import random as rand
    from tqdm.utils import _supports_unicode
    from tqdm.auto import tqdm as auto_tqdm

    # Setup widget
    widget = tqdm_notebook(total=105)

    # Update widget with total=None at regular intervals
    for i in range(100):
        sleep(rand() / 5)
        widget.update(n=1)
    # Close widget
    widget.close()

    # Check that auto-interval mode is working
    def tqdm_auto_notebook(total, desc='test_tqdm_notebook_auto_interval'):
        return tqdm_notebook(total=total, desc=desc, dynamic_ncols=True)

    auto_interval_tqdm

# Generated at 2022-06-24 10:14:49.126061
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from pytest import approx

    # Prepare
    pbar = IProgress(min=0, max=1)
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    ltext = HTML()
    rtext = HTML()
    ltext.value = 'desc'
    rtext.value = 'msg'
    container = TqdmHBox(children=[ltext, pbar, rtext])
    pbar.value = 42 / 42
    # Test
    assert repr(container) == '[ desc|########################################|100% msg]'
    # Test with float
    pbar.value = 42 / 42.0
    assert repr(container) == '[ desc|########################################|100.0% msg]'
    # Test with float and precision

# Generated at 2022-06-24 10:14:55.696046
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    from IPython.display import HTML
    pbar1 = IProgress(min=0, max=3)

    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar1, rtext])

    ltext.value = "<b>foo</b>"
    rtext.value = "bar"
    pbar1.value = 1
    pbar1.bar_style = 'danger'

# Generated at 2022-06-24 10:15:07.771323
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Set IPython to version 3
    IPY = 3
    if IProgress is not None:
        t = tqdm_notebook(total=10)
        for i in range(10):
            t.update()
        t.close()
        assert t.container.visible == False
        # Set IPython to version 4
        IPY = 4
    if IProgress is not None:
        t = tqdm_notebook(total=10)
        for i in range(10):
            t.update()
        t.close()
        assert t.container.visible == False
    # Set IPython to version 2
    IPY = 2
    if IProgress is not None:
        t = tqdm_notebook(total=10)
        for i in range(10):
            t.update()
        t.close()

# Generated at 2022-06-24 10:15:17.658477
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=5, leave=True, miniters=5, mininterval=0) as t:
        for i in range(7):
            t.update()
        t.reset(total=7)
        for i in range(7):
            t.update()
        # t.clear()
        # t.display('')
        t.reset()
        t.reset(total=7)
        for i in range(7):
            t.update()
    # try:
    #    with tqdm_notebook(total=10, leave=False, miniters=0, mininterval=0) as t:
    #        for i in range(10):
    #            t.update()
    #            t.reset(total=10)
    #        for i in range(

# Generated at 2022-06-24 10:15:24.283520
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    class TestClass(tqdm_notebook):
        def __init__(self, n=10):
            super(tqdm_notebook, self).__init__(n)

    test_obj = TestClass()
    assert hasattr(test_obj, 'clear')
    test_obj.clear()



# Generated at 2022-06-24 10:15:34.561130
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import io
    import sys
    from collections import Iterable

    ret_tqdm = []
    ret_list = []
    ret_tqdm_notebook = []
    with closing(io.StringIO()) as our_file, redirect_stdout(our_file):

        # test
        for _ in tqdm(range(8), desc='testing'):
            ret_tqdm.append(_)

        # list
        for _ in list(range(8)):
            ret_list.append(_)

        # test notebook
        for _ in tqdm_notebook(range(8), desc='testing notebook'):
            ret_tqdm_notebook.append(_)

    assert ret_tqdm == ret_list
    assert ret_tqdm_notebook == ret_list

    # check the availability of

# Generated at 2022-06-24 10:15:40.203087
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as t
    for pos, msg in zip(t(range(4), desc='', unit='', leave=False,
                         disable=True), ['', '', '', ''] + [''] * 4):
        pass

test_tqdm_notebook_display()

# Generated at 2022-06-24 10:15:50.789646
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        for i in _range(10):
            pbar.update()

    assert pbar.n == 10
    assert pbar.total == 10
    assert pbar.container.children[1].value == 10

    # Clear the bar
    pbar.clear()

    assert pbar.n == 0
    assert pbar.total == 10
    assert pbar.container.children[1].value == 0

    # Update the bar
    pbar.update(6)

    assert pbar.n == 6
    assert pbar.total == 10
    assert pbar.container.children[1].value == 6

    # Other clear means
    pbar.update(3)
    pbar.reset(5)

    assert pbar.n == 0
    assert pbar

# Generated at 2022-06-24 10:16:01.822136
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    t = tqdm_notebook(total=2, leave=False, display=False)
    t.display()
    t.update(1)
    t.display()
    t.update()
    t.close()
    clear_output()
    t = tqdm_notebook(total=2, leave=False, display=False)
    t.update()
    t.display(msg="Hello World!", pos=1)
    t.update()
    t.close()
    clear_output()
    t = tqdm_notebook(total=2, leave=False, display=False)
    t.update()
    t.display(pos=1, msg="")
    clear_output()

# Generated at 2022-06-24 10:16:09.450895
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test if `display()` method of `tqdm_notebook` works as expected.

    Expected results:
        - `display()` doesn't throw an error
        - `display()` returns the expected result when bar_style is set
    """
    # Test no error is thrown
    a = tqdm_notebook(range(1000))
    for _ in a:
        a.display()

    # Check bar style is set to expected value
    for bar_style in ['success', 'danger']:
        tqdm_notebook.clear()

        a = tqdm_notebook(range(1000))
        for _ in a:
            a.display(bar_style=bar_style)

        b = tqdm_notebook.instances[-1]

# Generated at 2022-06-24 10:16:19.475719
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # In IPython
    hbox = TqdmHBox()
    assert hbox.__repr__(pretty=True) == "{desc: }{percentage:3.0f}%"
    hbox.pbar = std_tqdm.tqdm()
    assert "100%" in hbox.__repr__(pretty=True)
    # In regular python
    hbox = TqdmHBox()
    assert hbox.__repr__(pretty=True) == "HBox(children=(HTML(value=''), IProgress(value=0, max=1), HTML(value='')))"
    hbox.pbar = std_tqdm.tqdm()
    assert '100%' in hbox.__repr__(pretty=True)
    # In IPython (without pretty)

# Generated at 2022-06-24 10:16:23.826096
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    from tqdm.autonotebook import tqdm
    with tqdm(total=2) as bar:
        bar.update(1)
        time.sleep(0.1)
        bar.reset()
        time.sleep(0.1)
        bar.update(1)
        time.sleep(0.1)
        bar.reset()
        time.sleep(0.1)

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:16:35.156551
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = tqdm(total=10)
    d = pbar.format_dict
    d["ascii"] = False
    print('TqdmHBox._repr_json_ ', pbar.container._repr_json_(pretty=None))
    print('TqdmHBox._repr_json_pretty_ ', pbar.container._repr_json_(pretty=True))
    print('TqdmHBox.__repr__ ', pbar.container.__repr__())
    print('TqdmHBox.__repr__pretty_ ', pbar.container.__repr__(pretty=True))
    print('TqdmHBox._repr_pretty_ ', pbar.container._repr_pretty_(None, pretty=True))
    pbar.close()
    return pbar.container

# Generated at 2022-06-24 10:16:39.259405
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    with tqdm_notebook(total=1, file=sys.stdout) as t:
        t.display()
        t.display()
        t.display()
        t.display(close=True)

# Generated at 2022-06-24 10:16:49.321458
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    sys.stderr.write("\n")
    tqdm_notebook.display(None, None, bar_style=None)
    tqdm_notebook.display("", pos=None, close=False)
    tqdm_notebook.display("\r", pos=None, close=False, bar_style=None)
    tqdm_notebook.display("", pos=None, close=False, bar_style=None)
    # HBox error
    # tqdm_notebook.display()
    # tqdm_notebook.display(None)

    # reset
    sys.stderr.write("\n")
    test = tqdm_notebook.display(None, None, bar_style=None)
    test.close()
    # tqdm_notebook.display(None,

# Generated at 2022-06-24 10:16:57.168443
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # It is a mistery that the following test fails on the Travis-CI
    # It should be investigated further...
    if 'CI' in os.environ:
        return
    if IPY < 2:
        raise AssertionError("IPython is not imported.")

    for ncols in [None, 80, 100]:
        hbox = tqdm(total=1000, ncols=ncols, desc='Test Bar', miniters=100,
                    file=sys.stdout, leave=True, mininterval=0)
        for i in _range(5):
            hbox.update()
        hbox.close()
        assert not hbox.container.visible
        assert hbox.container.layout.visibility == 'hidden'

    for ncols in [None, 80, 100]:
        hbox = t

# Generated at 2022-06-24 10:17:05.714216
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.utils.capture import capture_output

    # Test with total
    with capture_output() as c:
        tqdm_notebook.status_printer(
            None, total=10, desc='test', ncols=50)
    assert ('test' in c.stdout) and ('0/10' in c.stdout)

    # Test without total
    with capture_output() as c:
        tqdm_notebook.status_printer(
            None, total=0, desc='test', ncols=50)
    assert ('test' in c.stdout) and ('0/0' in c.stdout)

# Generated at 2022-06-24 10:17:07.758818
# Unit test for function tnrange
def test_tnrange():
    from .tests import test_tnrange
    test_tnrange(tnrange)

# Generated at 2022-06-24 10:17:15.624725
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    with tqdm_notebook(total=3) as pbar, \
            redirect_stderr(StringIO()) as buf:  # suppress_stdout_stderr:
        pbar.display(0, total=3, desc='foooo', ncols=30)
        assert "<bar/>" in buf.getvalue()


# (c) 2014 - 2015, Michael Kessler and contributors
# License: BSD v3.0, https://github.com/Kronuz/pytest-ipynb/blob/master/LICENSE

# Generated at 2022-06-24 10:17:24.731953
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from pytest import raises
    import sys
    from .utils import FormatCustom
    from .gui import tqdm
    from .gui import tqdm_notebook
    from .utils import _range

    # test for custom bar format (issue #452)
    with tqdm(total=50, file=sys.stdout,
              bar_format=FormatCustom("BAR", "BEST")) as t:
        for _ in _range(10):
            assert t.format_dict["bar_format"] == "BAR"
            t.set_postfix(some=1)
        for _ in _range(10):
            assert t.format_dict["bar_format"] == "BEST"
            t.set_postfix(some=1)

    # test for exception with ipywidgets

# Generated at 2022-06-24 10:17:27.273076
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as t:
        t.update(50)
        t.clear()
        t.update(50)

# Generated at 2022-06-24 10:17:36.658988
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep, time
    # By default, no unit_scale
    for i in tqdm(range(3), position=0):
        pass  # hidding the output of the loop
    for i in tqdm(_range(3), position=0, total=4):
        pass  # hidding the output of the loop
    for i in tqdm(range(3), position=0, desc='Unit tests'):
        pass  # hidding the output of the loop
    for i in trange(3, position=0):
        pass  # hidding the output of the loop
    t = tqdm(range(5), miniters=2, mininterval=0.01, smoothing=100, position=0)
    t.update(2)
    t.n = 6
    t.refresh()
   

# Generated at 2022-06-24 10:17:48.125360
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    w = tqdm_notebook.status_printer(None, total=5)
    if IPY >= 4:
        assert w.layout.width == "100%"
    else:
        assert w.layout.width == "100%"
        assert '%' in w.children[1].layout.width

    w = tqdm_notebook.status_printer(None, total=5, ncols=200)
    if IPY >= 4:
        assert w.layout.width == "200px"
    else:
        assert w.layout.width == "200px"
        assert w.children[1].layout.width == "200px"

    w = tqdm_notebook.status_printer(None, total=5, ncols=100)
    assert w.layout.width == "100%"

    w

# Generated at 2022-06-24 10:17:51.765227
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from IPython.display import clear_output
    except ImportError:
        raise unittest.SkipTest("IPython not found")
    clear_output.counter = 0
    with tqdm_notebook(total=1) as t:
        t.clear()
    assert clear_output.counter == 1

# Generated at 2022-06-24 10:17:56.933238
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test tqdm_notebook status printer"""
    # Fake sys.stderr
    class FakeStdErr(object):
        """Fake std err"""
        def write(self, *_, **__):
            pass

    # Instantiate an instance of tqdm_notebook and get status_printer's result
    tq = tqdm_notebook(
        iterable=range(1),
        leave=True,
        file=FakeStdErr(),
        desc="test",
        ncols=100)
    tq.status_printer(None, total=1)



# Generated at 2022-06-24 10:18:02.819188
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('tqdm.notebook.tqdm_notebook.close') as mock_close:
        with tqdm_notebook(total=0) as pbar:
            pbar.clear()
        assert mock_close.call_count == 1

# Generated at 2022-06-24 10:18:11.569646
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.tests import tests, _range
    from io import StringIO

    class TqdmHBox_with_format_dict(TqdmHBox):
        def __init__(self, *args, **kwargs):
            super(TqdmHBox_with_format_dict, self).__init__(*args, **kwargs)

# Generated at 2022-06-24 10:18:16.225734
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # easy way to check: tqdm.notebook.__iter__() must output an infinite bar
    # NB: this will most likely raise an Exception due to `next` being
    #     called infinitely, but shouldn't break the generator.
    # NB: don't use len() as it will call next() and the loop will break
    for _ in tqdm(tqdm_notebook(list())):
        pass

# Generated at 2022-06-24 10:18:21.085146
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test status_printer
    """
    # import io and context manager
    if True:  # pragma: no cover
        import io as cStringIO
        from contextlib import contextmanager
        # Alternative: using __future__ io (Python 3.3+)
        # from io import StringIO as cStringIO
        # from contextlib import ExitStack as contextmanager
    else:  # pragma: no cover
        from cStringIO import StringIO as cStringIO
        from contextlib2 import ExitStack as contextmanager

    @contextmanager
    def stdoutIO(stdout=None):
        """
        Context manager which redirect `sys.stdout` and `print` to a file-like
        object.
        """
        old = sys.stdout
        if stdout is None:
            stdout = cStringIO()
       

# Generated at 2022-06-24 10:18:28.557184
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main as ut_main
    from tempfile import TemporaryFile
    from io import DEFAULT_BUFFER_SIZE
    try:
        from unittest.mock import patch
    except ImportError:  # noqa
        from mock import patch  # noqa
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO  # noqa

    class TestTqdmNotebook(TestCase):
        def setUp(self):
            self.file = TemporaryFile()  # sys.stdout.buffer
            self.pbar = tqdm_notebook(total=10, file=self.file, leave=True)

        def test_init(self):
            self.assertEqual(self.pbar.total, 10)

# Generated at 2022-06-24 10:18:33.285474
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest import mock
        assert mock  # silence pyflakes
    except ImportError:
        import mock

    with mock.patch('IPython.display.clear_output') as mock_method:
        with tqdm_notebook(total=2) as pbar:
            pbar.clear()
        assert mock_method.called

# Generated at 2022-06-24 10:18:37.263229
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for _ in tqdm_notebook(range(4)):
        pass
    for _ in tqdm_notebook(range(4)):
        tqdm_notebook.update()


if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:18:44.922721
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer._tqdm.total = 5
    pbar = tqdm_notebook.status_printer(tqdm_notebook.status_printer._tqdm)
    # This is the expected HTML for the ipywidgets layout.
    # Note that this layout may change in the future.
    status_printer_expected = '''\
<widgetsnbextension.widgetsnbextension.VBox object at 0x...>'''
    assert(str(pbar) == status_printer_expected)

# Generated at 2022-06-24 10:18:50.071736
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from ipywidgets import IntProgress
    except ImportError:
        return
    from tqdm import tqdm as std_tqdm

    # new style
    for cls in [tqdm_notebook, tqdm]:
        for leave in [True, False]:
            for desc in [None, '']:
                widget = cls(unit='B', total=3, leave=leave, disable=False,
                             desc=desc)
                assert isinstance(widget.displayed, bool)
                widget.update()
                assert isinstance(widget.displayed, bool)
                widget.update()
                widget.update()
                if leave:
                    assert widget.displayed is False
                else:
                    assert widget.displayed is True
            # TODO: add check inside close()
            # with captured_

# Generated at 2022-06-24 10:18:56.635556
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random

    t = tqdm_notebook(total=1, desc="testing IPython widget")
    try:
        for i in t:
            t.set_description("testing IPython widget: %i" % i)
            sleep(0.01 * random())
    except KeyboardInterrupt:
        t.close()
        raise
    t.close()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:19:03.170112
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    """Unit test for method reset of class tqdm_notebook"""
    from tqdm.auto import trange
    t = trange(10)
    for i in t:
        pass
    t.reset(total=20)
    for i in t:
        pass


if __name__ == "__main__":  # pragma: no cover
    from sys import argv
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:19:12.811032
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.notebook import tqdm_notebook
    import numpy as np
    import IPython

    # IPython has a bug where it does not recognise
    # numpy int for max, so a float is needed
    test_iterable = range(np.random.randint(999, 10 ** 5))
    # Range of random floats from 0 to 1
    float_range = np.random.random(len(test_iterable))
    if IPY == 0:
        print("N.B.: test_tqdm_notebook_status_printer() cannot be run "
              "outside IPython/Jupyter Notebook")
        return
    for i in tqdm_notebook(float_range):
        # Example of print
        print("\rResult: {}".format(i), end="")
        #

# Generated at 2022-06-24 10:19:19.644177
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from unittest import TestCase
    TestCase().assertIsInstance(TqdmHBox([]), HBox)
    TestCase().assertIsInstance(TqdmHBox(pbar=proxy(tqdm_notebook())), HBox)
    TestCase().assertIsInstance(TqdmHBox(pbar=proxy(tqdm_notebook())).pbar,
                                tqdm_notebook)


# Extra test for closing a tqdm_notebook

# Generated at 2022-06-24 10:19:21.356286
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for n in tqdm_notebook(range(5)):
        pass

# Generated at 2022-06-24 10:19:29.011049
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test tqdm_notebook.status_printer() method"""
    from tqdm.auto import tqdm
    try:
        with tqdm(total=2, leave=False) as pbar:
            children = pbar.container.children
            assert len(children) == 3
            html_l, p, html_r = children
            assert isinstance(p, IProgress)
            assert isinstance(html_l, HTML)
            assert isinstance(html_r, HTML)
    except (ImportError, ValueError, AttributeError):
        pass



# Generated at 2022-06-24 10:19:29.678686
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    pass

# Generated at 2022-06-24 10:19:39.187895
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """IPython/Jupyter progressbar widget for testing"""
    import ipywidgets

    check(int(ipywidgets.__version__[0]))
    pbar = IProgress(min=0, max=100)
    pbar.value = 80
    pbar.bar_style = 'info'
    html = HTML("<b>Current Progress:</b>")
    container = TqdmHBox(children=[html, pbar])
    container


if __name__ == '__main__':
    # Test in Notebook
    test_TqdmHBox()

# Generated at 2022-06-24 10:19:47.110413
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    # First, test if display by default works (the bar should appear)
    # with tqdm.notebook.tqdm(total=1) as t:
    #     t.display()
    #     time.sleep(2)  # wait for display

    # Then, test if display with msg='' erases the bar
    # with tqdm.notebook.tqdm(total=1) as t:
    #     t.display(msg='')
    #     time.sleep(2)  # wait for display
    pass


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:19:49.638498
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(5)):
        assert 0 <= i < 5
    for i in tqdm_notebook(range(10)):
        assert 0 <= i < 10


# Generated at 2022-06-24 10:19:56.550444
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .std import tqdm as std_tqdm
    from .std import tqdm_gui as std_tqdm_gui
    for cls in [tqdm_notebook, std_tqdm, std_tqdm_gui]:
        with cls(total=2) as pbar:
            n_updates = 0
            for i in pbar:
                n_updates += 1
            assert n_updates == 2
            assert pbar.n == 2
            assert pbar.displayed

        # test error-handling
        with cls(total=2) as pbar:
            n_updates = 0
            for i in pbar:
                n_updates += 1
                if i == 1:
                    raise ValueError
            assert n_updates == 2
            assert pbar.n

# Generated at 2022-06-24 10:20:00.368074
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        tn = tqdm_notebook(total=5)
        for _ in tn:
            if tn.n == 2:
                break
    except:  # NOQA
        pass
    tn.close()

# Generated at 2022-06-24 10:20:09.105422
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    # Test if total = None
    test_tqdm = tqdm_notebook(total=None)
    time.sleep(1)
    test_tqdm.close()
    # Test if total != None
    test_tqdm2 = tqdm_notebook(total=100)
    time.sleep(1)
    test_tqdm2.close()
    # Test if n < total
    test_tqdm3 = tqdm_notebook(total=100)
    time.sleep(1)
    test_tqdm3.update(1)
    test_tqdm3.close()
    # Test if n > total
    test_tqdm4 = tqdm_notebook(total=100)
    time.sleep(1)
    test_tqdm4

# Generated at 2022-06-24 10:20:18.141145
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Available without Jupyter Notebook
    if sys.version_info >= (3, 0):
        from unittest.mock import patch
    else:
        from mock import patch

    with patch.multiple('sys', stdout=None, displayhook=None,
                        stderr=None, get_ipython=None):
        from tqdm._tqdm import _instances
        pbar = tqdm_notebook(total=100)  # test constructor
        pbar.close()
        assert pbar in _instances

        # test constructor with disable
        for v in [True, False]:
            with patch("tqdm._tqdm.tqdm_gui.tqdm._tqdm_notebook.display",
                       side_effect=lambda _: 1 / 0):
                pbar = tqdm

# Generated at 2022-06-24 10:20:27.062687
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # bar style tests
    def run_assert(**kwargs):
        kwargs.setdefault('desc', 'desc')
        kwargs.setdefault('total', 100)
        kwargs.setdefault('ncols', 100)
        kwargs.setdefault('bar_format', '{l_bar}{bar}{r_bar}')
        kwargs.setdefault('n', 50)
        kwargs.setdefault('smoothing', 1.)
        kwargs.setdefault('dynamic_ncols', False)
        kwargs.setdefault('unit', 'it')
        kwargs.setdefault('unit_scale', False)
        kwargs.setdefault('gui', True)
        kwargs.setdefault('leave', False)
        kwargs.setdefault('disable', False)


# Generated at 2022-06-24 10:20:33.592909
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from IPython.display import HTML

    # Test with some parameters
    container = tqdm_notebook.status_printer(None, total=10, desc=desc)
    children = [
        isinstance(ch, HTML) and ch.value == desc for ch in container.children]
    assert all(children)

    # Test without total
    child = tqdm_notebook.status_printer(None)
    assert isinstance(child, IProgress)

    # Test with no IPython
    global IPY, IProgress
    IPY, IProgress = 0, None
    try:
        tqdm_notebook()
    except ImportError:
        pass
    else:  # pragma: no cover
        raise RuntimeError('Expected ImportError')

# Generated at 2022-06-24 10:20:40.302542
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    h = TqdmHBox()
    h.pbar = tqdm_notebook(total=100)
    h.pbar.n = 21
    assert h.__repr__() == '21%|########4 |'
    assert h.__repr__(pretty=None)['bar'] == '21%|########4 |'
    assert h.__repr__(pretty=True) == '21%|########4 |'
    assert h.__repr__(pretty=False) == '21%|########4 |'

# Generated at 2022-06-24 10:20:41.908107
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook(range(1000)):
        pass


# Generated at 2022-06-24 10:20:51.856417
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        container = tqdm_notebook.status_printer(_range(1))
        assert isinstance(container, TqdmHBox)
        assert isinstance(container.children[0], HTML)
        assert isinstance(container.children[1], IProgress)
        assert isinstance(container.children[2], HTML)
    except (NameError, ImportError):
        pass

    if IPY:
        with tqdm_notebook(total=1, unit='B', unit_scale=True,
                           miniters=1, mininterval=1, ascii=False) as t:
            assert t.leave is True
            assert t.gui is True
            assert str(t) == '0it [00:00, ?it/s]'

# Generated at 2022-06-24 10:20:55.867860
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tf = tqdm(["spam", "eggs", "foo bar"])
    for i in tf:
        pass
    tf.close()
    assert tf == str(tf)

TqdmHBox___repr__ = test_TqdmHBox___repr__



# Generated at 2022-06-24 10:21:04.581492
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm import trange
    from ipywidgets import HTML
    from IPython.display import display, clear_output

    for i in range(10):
        tr = trange(100, desc='Foobar', leave=True, ncols=100)
        for _ in tr:
            assert hasattr(tr, 'container')
            assert isinstance(tr.container, TqdmHBox)
            assert isinstance(tr.container.children[0], HTML)
            assert isinstance(tr.container.children[1], IProgress)
            assert isinstance(tr.container.children[2], HTML)
            clear_output(wait=True)



# Generated at 2022-06-24 10:21:15.225288
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    from IPython.display import clear_output

    # Setup
    n = 100
    total_width = 30
    desc = "my bar!"
    with tqdm_notebook(total=n, desc=desc, ncols=total_width, leave=False) as t:
        if not hasattr(t, 'displayed'):
            raise AssertionError
        assert t.disable is False
        assert t.total == n
        assert t.dynamic_ncols is False
        assert t.ncols == total_width
        assert str(t) == desc
        if t.ncols is None:
            assert t.container.layout.width == '20px'
        assert not hasattr(t, 'colour')


# Generated at 2022-06-24 10:21:18.055742
# Unit test for function tnrange
def test_tnrange():
    from .utils import format_interval
    from time import sleep
    with tnrange(4) as t:
        for i in t:
            sleep(.5)


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-24 10:21:29.936929
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from io import StringIO
    from tqdm.std import tqdm as std_tqdm
    with StringIO() as f:
        # Initialize tqdm
        t = std_tqdm(total=1000, file=f)

        # Test __repr__
        assert repr(TqdmHBox()) != repr(TqdmHBox())
        assert repr(TqdmHBox(pbar=t)) == repr(TqdmHBox(pbar=t))
        assert repr(TqdmHBox(pbar=t)) != repr(TqdmHBox())

        # Test _repr_pretty_
        pretty_out = StringIO()
        t._repr_pretty_(pretty_out, False)
        assert pretty_out.getvalue() == t.format_meter()

        # Test _re

# Generated at 2022-06-24 10:21:38.948581
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Expected output for function test_TqdmHBox___repr__
    exp_output = [
        u'  0%|          | 0/2 [00:00<?, ?it/s]',
        u'  0%|          | 0/3 [00:00<?, ?it/s]'
    ]

    # Create a TqdmHBox instance
    tqdm_hbox = TqdmHBox()

    # Set the pbar attribute
    pbar = tqdm(list(range(2)))
    tqdm_hbox.pbar = pbar

    # Test that function __repr__ works as expected
    assert str(tqdm_hbox) == exp_output[0]
    pbar.update(1)