

# Generated at 2022-06-24 10:12:28.614628
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        tqdm_notebook.clear()
    except AttributeError:
        pass

# Generated at 2022-06-24 10:12:38.629027
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep

    msg = "Testing .update() with .total=None"
    with tqdm_notebook(bar_format=' {desc}',
                       desc=msg, total=None) as t:
        assert msg == t.desc
        # test if None in total is well handled
        assert t.total is None
        t.update()
        assert t.n == 1
        t.update()
        assert t.n == 2

    msg = "Testing .update() with .total=30"
    with tqdm_notebook(bar_format=' {desc}',
                       desc=msg, total=30) as t:
        assert t.n == 0
        t.update(5)
        assert t.n == 5
        t.update(5)
        assert t

# Generated at 2022-06-24 10:12:40.300905
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests that `tqdm_notebook.clear()` won't crash.
    """
    tqdm_notebook().clear()

# Generated at 2022-06-24 10:12:48.541933
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook.status_printer(None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, None, None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, None, None, None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, 10, None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, 10, '', None), TqdmHBox)

# Generated at 2022-06-24 10:12:52.541568
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import trange
    for i in trange(4, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(50, desc='3nd loop', leave=True):
                assert (i, j, k) == (0, 0, 0)
                break


# Generated at 2022-06-24 10:13:03.734545
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Unit test for constructor of class TqdmHBox."""
    hbox = TqdmHBox()
    assert hbox.__repr__(pretty=True) == "[0%]|"
    hbox.pbar = std_tqdm(total=10)
    assert hbox.__repr__(pretty=True) == "[0%|#####   ]|[0/10]"
    hbox.pbar.update(1)
    assert hbox.__repr__(pretty=True) == "[10%|######  ]|[1/10]"
    hbox.pbar.update(1)
    assert hbox.__repr__(pretty=True) == "[20%|####### ]|[2/10]"
    hbox.pbar.update(1)
    assert hbox.__repr

# Generated at 2022-06-24 10:13:12.666391
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    ipywidgets.IntProgress(value=0, min=0, max=1, step=1)
    ipywidgets.IntProgress(description='description', value=0, min=0, max=1, step=1)
    ipywidgets.FloatProgress(value=0, min=0, max=10, step=1)
    ipywidgets.FloatProgress(description='description', value=0, min=0, max=10, step=1)

    with tqdm(_range(10)) as t:
        for i in t:
            pass
    assert not t.displayed

    with tqdm(_range(10), display=False) as t:
        for i in t:
            pass
    assert not t.displayed


# Generated at 2022-06-24 10:13:25.511271
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tnrange, tqdm

    for total in [None, 10, 20]:
        with tnrange(total=total, desc="test") as t:
            for i in t:
                pass
            t.reset(100)
            for i in t:
                pass
            t.reset()

    with tqdm(desc="test") as t:
        for _ in t:
            t.reset(100)
        t.reset()


if __name__ == "__main__":
    # Run all unit tests with `python -m tqdm.notebook tests`
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:13:37.657216
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import unittest

    class Mock():

        def __init__(self):
            self.progress = None
            self.style = None

    class MockContainer(object):

        def __init__(self):
            self.close_called = False
            self.visible = False

        def close(self):
            self.close_called = True
            self.visible = False

    class TestClose(unittest.TestCase):

        def test_close(self):
            mock = Mock()
            mock_container = MockContainer()
            progress = tqdm_notebook(total=10)
            progress.container = mock_container
            progress.container.children = [None, mock, None]
            progress.close()
            self.assertEqual(mock_container.close_called, True)

# Generated at 2022-06-24 10:13:50.436125
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    expected = '[  0%]|          |'
    pbar = tqdm(total=10)
    container = TqdmHBox(children=[HTML(), pbar.bar, HTML()])
    pbar.bar = container
    result = pbar.__repr__()
    pbar.close()
    assert result == expected
    # Use a dict to compare between the two, since some dictionaries
    # (like the pbar attribute 'format_dict') can have different orders
    # between python2 and python3
    print(dict(pbar.format_dict))

# Generated at 2022-06-24 10:13:58.472431
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    try:
        with tqdm_notebook(total=0) as pbar:
            pass
    except Exception:
        pass
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update(1)
            time.sleep(0.001)
        pbar.clear()
        pbar.close()
    sys.exit(0)


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:14:00.616534
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.testing import tools as ipytools
    ipytools.assert_equals(str(TqdmHBox()), '')
    ipytools.assert_equals(TqdmHBox()._repr_pretty_(None), None)

# Generated at 2022-06-24 10:14:05.122731
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for ncols in [None, "100%", 100, "100px", 100.0]:
        container = tqdm_notebook.status_printer(None, total=1, desc="Description",
                                                 ncols=ncols)
        ltext, pbar, rtext = container.children
        assert(pbar.max == 1)
        assert(ltext.value == "Description")
        assert(rtext.value == "0it [00:00, ?it/s]")

# Generated at 2022-06-24 10:14:16.235400
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm_gui
    for cls in (tqdm_notebook, tqdm_gui):
        with cls(total=None) as pbar:
            pbar.reset()
        with cls(total=None) as pbar:
            pbar.reset(total=1)
        with cls(total=None) as pbar:
            pbar.reset(total=1)
            pbar.reset()
        with cls(total=None) as pbar:
            pbar.reset(total=1)
            pbar.reset(total=2)
        with cls(total=1) as pbar:
            pbar.reset()
        with cls(total=1) as pbar:
            pbar.reset(total=1)

# Generated at 2022-06-24 10:14:20.091299
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import random
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            sleep(random())
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:14:25.450850
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    from tqdm import tnrange
    tt = tnrange(2, 3)
    time.sleep(0.1)
    tt.reset(5)
    time.sleep(0.1)
    tt.close()
    if (tt.n != 0 and
            tt.total == 5):
        raise ValueError


if __name__ == "__main__":
    # Avoid pytest skips
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:14:32.887760
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import BytesIO
    from unittest import TestCase

    class TqdmHBoxTester(TestCase):
        def test_repr_json(self):
            t = TqdmHBox()
            t.pbar = tqdm_notebook()
            self.assertEqual(t._repr_json_().keys(), ['desc', 'ncols'])

        def test_repr_pretty(self):
            t = TqdmHBox()
            t.pbar = tqdm_notebook()
            rp = BytesIO()
            t._repr_pretty_(rp, None)
            self.assertIn(b'avg', rp.getvalue())

        def test_repr(self):
            t = TqdmHBox()
            t.pbar = tq

# Generated at 2022-06-24 10:14:38.003278
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    try:
        iterable = iter(range(10))  # NOQA
    except NameError:
        iterable = iter(xrange(10))  # NOQA
    for i in iterable:
        pass
    for i in tqdm_notebook(iterable):
        pass



# Generated at 2022-06-24 10:14:42.184579
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    try:
        with tqdm_notebook(total=3, desc='foo') as pbar:
            for i in range(4):
                sleep(0.01)
                pbar.update(1)
    except:  # NOQA
        assert False, 'Caught an exception'
    else:
        assert False, 'Did not catch expected exception'
    return



# Generated at 2022-06-24 10:14:45.423779
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=None, disable=False)
    t.close()


if __name__ == "__main__":
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(unittest.makeSuite(test_tqdm_notebook_close))
    unittest.TextTestRunner(verbosity=2).run(suite)

# Generated at 2022-06-24 10:14:53.494279
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class FakeIPython(object):
        def __init__(self):
            self.widgets = FakeIPythonWidgets()
            self.display = FakeIPythonDisplay()

    class FakeIPythonWidgets(object):
        class FloatProgress():
            def __init__(self, min=0, max=1):
                self.bar_style = 'info'
                self.value = 1
                self.min = min
                self.max = max
                self.layout = FakeLayout()

        class HTML():
            def __init__(self):
                self.value = None

        class HBox():
            def __init__(self, children):
                self.children = children
                self.layout = FakeLayout()

        class Layout():
            def __init__(self):
                self.width = None

# Generated at 2022-06-24 10:15:00.398096
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.testing.globalipapp import get_ipython
    from IPython.display import clear_output
    ip = get_ipython()
    if ip is None:
        return
    ip.enable_gui('notebook')
    clear_output()

    pbar = tqdm_notebook.status_printer('test', 100, 'testing', 20)
    assert pbar.layout.width == "20px"
    assert pbar.value == 0
    # pbar.layout = "width: 50px"
    pbar.layout.width = "50px"
    assert pbar.layout.width == "50px"

    # Check display
    from IPython.display import display
    display(pbar)
    pbar.value = 10  # update value
    # reset
    pbar.max = 200
   

# Generated at 2022-06-24 10:15:06.546054
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    import time
    with tqdm(total=100) as pbar:
        for i in range(100):
            time.sleep(0.1)
            pbar.update(1)



# Generated at 2022-06-24 10:15:17.528139
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    import pytest
    # Test with simple numbers
    with tnrange(0, 4) as pbar:
        for _ in pbar:
            pass
    # Repeat without resetting the bar
    with tnrange(0, 4, leave=True) as pbar:
        for _ in pbar:
            pass
        assert pbar.total == 4
        assert pbar.n == pbar.total
    # Test if position argument works
    with tnrange(0, 4) as pbar:
        for _ in pbar:
            assert pbar.n == 0
            pbar.set_description("iteration %d" % (pbar.n + 1))
            pbar.update(1)
            assert pbar.n == 1
            pbar.update()
            assert pbar.n

# Generated at 2022-06-24 10:15:24.574534
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for `tnrange`
    """
    for i in tnrange(0, 3):
        pass
    for i in tnrange(3):
        pass
    for i in tnrange(4, 0, -1):
        pass
    for i in tnrange(0, 5, 0.5):
        pass

# Generated at 2022-06-24 10:15:28.507806
# Unit test for function tnrange
def test_tnrange():
    "Test function tnrange"
    from .utils import format_sizeof

    lst = list(tnrange(5, desc='size ' + format_sizeof(5)))
    assert lst == list(range(5))



# Generated at 2022-06-24 10:15:34.154652
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Checks that `tqdm_notebook` can be reset multiple times."""
    # Avoid printing tqdm messages in test
    tqdm_notebook.default_gui = tqdm_notebook.gui

    # Test for issue #617 and GH pr #665
    for n in [1, 0, -1, -2, None]:
        pbar = tqdm_notebook(total=5)
        for _ in pbar:
            pbar.total = n
            break

    # Test for issue #745 and GH pr #746
    for n in [1, 0, -1, -2, None]:
        pbar = tqdm_notebook()
        for _ in pbar:
            pbar.total = n
            break
    tqdm_notebook.reset(total=1)

    #

# Generated at 2022-06-24 10:15:35.576761
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .utils import format_sizeof
    from .std import FormatStrin

# Generated at 2022-06-24 10:15:47.544803
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    def rem_newlines(t):
        return t.replace('\n', '\\n') if t is not None else t

    # Create object
    pbar = tqdm_notebook(total=5)
    assert rem_newlines(repr(pbar.container)) == \
        'HBox(children=(HTML(value=u\'\'), FloatProgress(value=0, max=5), HTML(value=u\'\')), layout=Layout(align_self=u\'center\', display=u\'inline-flex\', flex_flow=u\'row wrap\', justify_content=u\'space-between\', width=u\'100%\'))'

# Generated at 2022-06-24 10:15:49.780791
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import trange
    for n in trange(3):
        for m in trange(3):
            pass
    pass

# Generated at 2022-06-24 10:15:55.175578
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test if clear method of tqdm_notebook class doesn't raise AttributeError.

    This bug was fixed in tqdm>=4.42.1.
    """
    import tqdm
    with tqdm.tqdm_notebook() as t:
        pass
        t.clear()

# Generated at 2022-06-24 10:15:58.485308
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # test if display works with empty tqdm_notebook instance
    pbar = tqdm_notebook()
    pbar.display()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:16:00.900872
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # unit testing requires having IPython notebook
    if IPY == 0:
        return
    from .tests import test_update
    test_update(tqdm_notebook)

# Generated at 2022-06-24 10:16:08.934307
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert str(tqdm_notebook.status_printer(None, 10, 'test')) == \
        'test |0%|                                               | 0/10 [00:00<?, ?it/s]  '
    assert str(tqdm_notebook.status_printer(None, total=None, desc='test')) == \
        'test |0%|                                               | 0it/s  '


if __name__ == '__main__':  # pragma: no cover
    from subprocess import PIPE, Popen

    # Need to create a separate base environment for `conda list`
    env = dict(os.environ)
    env.pop('__PYVENV_LAUNCHER__', None)

    # Check IPython/Jupyter notebook dependencies
    has_ipywid

# Generated at 2022-06-24 10:16:15.427782
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Tests if TqdmHBox._repr_pretty_() returns the same as
    TqdmHBox.__repr__().
    """
    def get_pretty_repr(obj, pretty=False):
        s = str(obj._repr_json_(pretty=pretty))
        return s[1:-1].replace('"', '')

    obj = TqdmHBox()
    assert obj.__repr__() == obj._repr_pretty_(None)

# Generated at 2022-06-24 10:16:18.582724
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        tqdm.write('Hello')
        tqdm.write('World')
        assert t.last_print_n == 0, t.last_print_n


# Generated at 2022-06-24 10:16:22.775324
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for iterable in [tnrange(4, desc='1st loop'), tnrange(4)]:
        for _ in iterable:  # test update
            iterable.update()
            iterable.update(2)
            iterable.update(2)
            iterable.update()
            iterable.update()



# Generated at 2022-06-24 10:16:24.649433
# Unit test for function tnrange
def test_tnrange():
    from .tests import test_tnrange as test
    test()


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-24 10:16:29.214587
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_equal
    from warnings import catch_warnings
    with catch_warnings(record=True):
        l = []
        for _ in tqdm_notebook(range(4)):
            l.append(_)
        assert_equal(l, [0, 1, 2, 3])

# Generated at 2022-06-24 10:16:34.662164
# Unit test for function tnrange
def test_tnrange():
    with tqdm(total=1) as pbar:
        for _ in tnrange(10**6, ncols=100, bar_format="{r_bar}"):
            pass
        assert pbar.n == 10**6


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:16:40.076899
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    try:
        from IPython.html import widgets
        from IPython.display import display, clear_output
    except ImportError:
        return

    try:  # doesn't work in IPython < 5
        clear_output(wait=True)
        bar = tqdm_notebook(total=10, leave=True)
        bar.close()
        clear_output(wait=True)
        bar = tqdm_notebook(total=10, leave=False)
        bar.close()
    except ValueError:
        pass

# Generated at 2022-06-24 10:16:50.453239
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from sys import version_info
    if version_info[0] < 3:
        from time import time as time_func
    else:
        from time import perf_counter as time_func

    from time import sleep
    # slow tqdm no longer flushes output!
    for i in tqdm(range(5), leave=False, desc='1st loop',
                  ascii=False, mininterval=0.5, miniters=1):
        sleep(0.2)
    assert '1st loop' in repr(tqdm)

    t = time_func()
    for i in tqdm(range(5), leave=False, desc='2nd loop',
                  ascii=False, mininterval=0.5, miniters=1):
        sleep(0.2)

# Generated at 2022-06-24 10:17:02.154425
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from re import findall
    from IPython.display import clear_output
    from time import sleep

    t = tqdm_notebook(total=200)
    for i in range(10):
        t.display()
        t.update(10)
        sleep(0.01)
    clear_output()
    for i in range(10):
        t.display(close=True)
        t.update(10)
        sleep(0.01)


# Generated at 2022-06-24 10:17:13.311982
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import StringIO
    import re
    import traceback
    import sys


# Generated at 2022-06-24 10:17:20.809437
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test without total
    d = tqdm_notebook.status_printer(None)
    assert d._repr_html_().split('\n')[1].startswith('<progress')

    # Test with total
    d = tqdm_notebook.status_printer(None, total=None)
    assert d._repr_pretty_().startswith('[')

    # Test with ncols
    d = tqdm_notebook.status_printer(None, total=None, ncols=100)
    assert d.layout.width == '100%'

# Generated at 2022-06-24 10:17:26.440150
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython import get_ipython

    ip = get_ipython()
    if ip is None:
        return

    # test html representation
    ltext = HTML()
    rtext = HTML()
    pbar = IProgress(min=0, max=10)
    container = TqdmHBox(children=[ltext, pbar, rtext])
    container.pbar = proxy(tqdm_notebook())
    container._repr_json_(True)

    # test pretty representation
    container._repr_pretty_(ip, None)

# Generated at 2022-06-24 10:17:33.290773
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    i = 0
    for _ in tnrange(9, desc='1st loop'):
        for _ in tnrange(5, desc='2nd loop', leave=False):
            for _ in tnrange(3, desc='3nd loop'):
                i += 1
                if i > 3:
                    break
                if i % 2 == 0:
                    continue
        if i > 15:
            break



# Generated at 2022-06-24 10:17:42.948497
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    test_tqdm_notebook_close
    """
    import time
    import sys
    try:
        from ipywidgets import FloatProgress as IProgress
    except ImportError:
        IProgress = None
    try:
        from IPython.display import display
    except ImportError:
        display = None
    if IProgress is None or display is None:
        print("IProgress or display not found. Skip the test")
        return
    pbar = tqdm_notebook(
        range(10), file=sys.stdout, leave=True, dynamic_ncols=True)
    for i in pbar:
        time.sleep(0.1)
    # Print initial bar state
    # pbar.close()
    pbar.container.close()
    print("Done")

# Generated at 2022-06-24 10:17:48.870783
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    with tqdm_notebook(total=3) as pbar:
        pbar.clear()
        pbar.update(1)
        time.sleep(0.5)
        pbar.clear()
        pbar.update(1)
        time.sleep(0.5)
        pbar.clear()
        pbar.update(1)

# Generated at 2022-06-24 10:17:53.374785
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm_notebook(total=5) as bar:
        for i in bar:
            sleep(0.1)
            bar.set_postfix(i=i)
    assert bar.__exit__() is None
    assert bar.n == 5
    assert bar.last_print_n == 5
    assert bar.total == 5



# Generated at 2022-06-24 10:18:04.898770
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    test_cases = [
        # 0-size bar
        (1, 0, False),
        (1, 0, True),
        # dynamic ncols
        (0, 0, False),
        (1, 0, False),
        (2, 0, False),
        (3, 0, False),
        (4, 0, False),
        (5, 0, False),
        # static ncols
        (0, 0, True),
        (1, 0, True),
        (2, 0, True),
        (3, 0, True),
        (4, 0, True),
        (5, 0, True),
    ]

    # check IPython imports
    if IProgress is None or HBox is None:
        return

    # run test cases

# Generated at 2022-06-24 10:18:07.306464
# Unit test for function tnrange
def test_tnrange():
    """Test function tnrange"""
    from .tests import _test_iterable
    _test_iterable(tnrange(4))
    _test_iterable(tnrange(4).__iter__())


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:18:18.047845
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    import io
    import sys
    import os

    if (sys.version_info[0] == 2 and sys.version_info[1] < 7):
        print('SKIP: python2.6 does not support context manager (inherited from object).')
        return

    try:
        from IPython.display import display  # , clear_output
    except ImportError:
        print('SKIP: ipywidgets is not installed.')
        return

    with io.open(os.devnull, 'w') as f:
        with tqdm(total=100, disable=False, file=f) as t:
            for i in _range(100):
                time.sleep(.01)
                t.update()


# Generated at 2022-06-24 10:18:20.822875
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10, leave=True) as pbar:
        assert pbar.total == 10
        assert pbar.n == 0



# Generated at 2022-06-24 10:18:28.296581
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test method __repr__ of class TqdmHBox.
    """
    try:
        from unittest import mock
    except ImportError:  # NOQA # pragma: no cover
        import mock
    from ipywidgets import HTML
    from ipywidgets import FloatProgress as IProgress
    from ipywidgets import HBox

    #No args
    HBox_test = TqdmHBox()
    assert repr(HBox_test)=='0.00it [00:00, ?it/s]'

    #Empty pbar
    HBox_test = TqdmHBox()
    HBox_test.pbar = None
    repr(HBox_test)=='0.00it [00:00, ?it/s]'

    #Pbar with args

# Generated at 2022-06-24 10:18:38.130943
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import random
    from .utils import FormatCustomTextTest
    for _ in tqdm_notebook(
            iterable=[_ for _ in FormatCustomTextTest]):
        pass
    for _ in tqdm_notebook(
            iterable=[_ for _ in FormatCustomTextTest],
            bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'):
        pass
    for _ in tqdm_notebook(
            iterable=[_ for _ in FormatCustomTextTest],
            bar_format='{l_bar}{bar}| {n:>5}'):
        pass

# Generated at 2022-06-24 10:18:42.274302
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    with tqdm_notebook(total=1) as pbar:
        sleep(1)
        pbar.reset(total=2)
        sleep(1)
        pbar.reset(total=3)
        sleep(1)
        pbar.reset(total=4)

# Generated at 2022-06-24 10:18:50.203951
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox()) == ""
    assert repr(TqdmHBox(pbar=1)) == "'{pbar:1}'"
    assert repr(TqdmHBox(pbar=1, ascii=True)) == "'{pbar:1}'"
    assert repr(TqdmHBox(pbar=1, ascii=False)) == "'{pbar:1}'"
    assert repr(TqdmHBox(pbar=1, ascii='html')) == "{'pbar': 1, 'ascii': False}"
    assert repr(TqdmHBox(pbar=1, ascii='json')) == "{'pbar': 1, 'ascii': True}"
    assert repr(TqdmHBox(pbar=1, ascii='trackref'))

# Generated at 2022-06-24 10:18:53.422753
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import IPython.html
    class DummyNotebook(object):
        def __init__(self):
            class DummyNotebookWidget(object):
                def clear_output(self, *args, **kwargs):
                    print("output cleared")
            self.widget = DummyNotebookWidget()
    IPython.html.widgets.NotebookWidget = DummyNotebook
    tqdm_notebook.clear()

# Generated at 2022-06-24 10:18:59.742664
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    try:
        from IPython.display import clear_output
    except ImportError:
        raise unittest.SkipTest("IPython not found")
    try:
        from unittest.mock import patch  # Py3
    except ImportError:
        from mock import patch  # NOQA
    with patch("IPython.display.clear_output") as m:
        t = tqdm_notebook(range(10))
        for i in t:
            if i == 5:
                t.close()
                assert m.called
                break
        else:
            raise RuntimeError("Cannot find the break!")



# Generated at 2022-06-24 10:19:09.550649
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # test default unit_scale of 1
    t = tqdm_notebook(total=100)
    # set the unit_scale of the instance to 100
    t.unit_scale = 100
    assert t.container.children[1].max == 100
    t.reset(total=200)
    assert t.container.children[1].max == 200
    t.update(100)
    assert t.container.children[1].max == 200 and t.container.children[1].value == 200
    # test unit_scale
    t.reset(total=400)
    assert t.container.children[1].max == 400
    t.update(200)
    assert t.container.children[1].max == 400 and t.container.children[1].value == 400
    t.reset(total=600)
    assert t.container

# Generated at 2022-06-24 10:19:16.648606
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    # Test to catch exception
    try:
        for _ in tqdm_notebook([]):
            raise Exception
    except Exception:
        pass
    # Test to no catch exception
    try:
        for _ in tqdm_notebook([], leave=True):
            raise Exception
    except Exception:
        exc_raised = True
    assert exc_raised
    # Test to catch KeyboardInterrupt
    try:
        for _ in tqdm_notebook(iter([])):
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass
    # Test to no catch KeyboardInterrupt
    try:
        for _ in tqdm_notebook(iter([]), leave=True):
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        exc_raised = True
    assert exc_raised

# Generated at 2022-06-24 10:19:19.602734
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    with tqdm_notebook(total=100, leave=False) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update(1)

# Generated at 2022-06-24 10:19:27.170802
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests that update() works with the clear() method of class tqdm_notebook.
    """
    descr = "tqdm: clear test"
    n = 10000
    w1 = tqdm_notebook(range(n), descr, ncols=0)
    for i in w1:
        if i > 5:
            w1.clear()
        w1.update()
    w1.close()


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    total = 100
    for i in tqdm(range(total)):
        sleep(0.01)
    for i in tqdm(range(total)):
        sleep(0.01)
    for i in trange(total):
        sleep(0.01)
   

# Generated at 2022-06-24 10:19:33.146932
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    t = tqdm_notebook(total=10, desc="Test")
    for i in range(10):
        sleep(0.01)
        t.update()
    assert t.n == 10
    t.reset()
    assert t.n == 0
    t.reset(total=20)
    assert t.total == 20



# Generated at 2022-06-24 10:19:44.267619
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # If a user prints a progress bar, we want to make sure that
    # the progress bar is displayed properly.
    # Note that this behaviour is also mimicked by the Jupyter notebook.

    class FakeTqdm(object):
        def format_dict(self):
            return dict(desc=None, total=10, n=5,
                        leave=True, unit="it",
                        ascii=True, unit_scale=True,
                        rate=100.0, rate_noinv=100.0,
                        avg=100.0, avg_noinv=100.0,
                        l_bar="[", r_bar="]", bar_format="{l_bar}{bar}{r_bar}",
                        postfix=[])

    hbox = TqdmHBox()
    hbox.pbar = FakeTqdm()

# Generated at 2022-06-24 10:19:48.002528
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import Markdown
    pbar = tqdm_notebook(total=1)
    try:
        pbar.display()
        pbar.display(close=True)
    except Exception:
        test = False
    else:
        test = True
    pbar.close()
    return test



# Generated at 2022-06-24 10:19:53.662001
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from collections import namedtuple
    # prepare input parameters
    args = namedtuple('Args', ['unit', 'unit_scale', 'unit_divisor',
                               'mininterval'])
    kwargs = {
        'unit': 'it',
        'unit_scale': True,
        'unit_divisor': 1000,
        'mininterval': 0.5,
    }
    args = args(**kwargs)

    # instantiate the class tqdm_notebook
    with tqdm_notebook(total=1, desc='update test', **kwargs) as t:
        # call method update of class tqdm_notebook
        t.update(9)
        # check that method update of class tqdm_notebook updated the progress
        # bar correctly
        assert t.n == 9


# Generated at 2022-06-24 10:20:05.082145
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from ipywidgets import HTML
    from ipywidgets import FloatLogSlider
    # init progress bar
    tn = tqdm_notebook(total=100, desc='Loading...', mininterval=0)
    _, pbar, _ = tn.container.children

    expected = [
        (0, ['Loading...', '', '  0%|'], ''),
        (1, ['Loading...', '', '  5%|'], ''),
        (20, ['Loading...', '', ' 21%|'], ''),
        (100, ['Loading...', '', '100%|'], 'success'),
    ]
    for n, children, style in expected:
        tn.update(n)
        children = [a.value for a in children]
        # check display
        ltext, c

# Generated at 2022-06-24 10:20:09.733202
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    total = 2
    from time import sleep
    from random import random
    duration = 0.1 + 3 * random()
    with tqdm_notebook(total=total, desc="test_tqdm_notebook___iter__") as pbar:
        for _ in pbar:
            sleep(duration / total)


# Generated at 2022-06-24 10:20:19.093793
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    pbar = IProgress(min=0, max=5)
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])

    assert container.pbar.format_dict['bar_format'] == "{l_bar}<bar/>{r_bar}"
    container.pbar.format_dict['bar_format'] = "{bar}"
    assert container.pbar.format_dict['bar_format'] == "{bar}"
    assert container.pbar.format_dict['ncols'] is None
    container.pbar.format_dict['ncols'] = 10
    assert container.pbar.format_dict['ncols'] == 10


if __name__ == "__main__":  # pragma: no cover
    test_TqdmH

# Generated at 2022-06-24 10:20:21.606885
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    repr_output = repr(TqdmHBox())
    assert repr_output.startswith("{'pbar':")
    assert repr_output.endswith("'gui': True}")


# Generated at 2022-06-24 10:20:29.840359
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    import sys

    pbar = tqdm_notebook(total=100)
    for i in range(100):
        time.sleep(0.01)
        pbar.update(1)  # +1
    pbar.close()
    pbar.clear()
    pbar = tqdm_notebook(total=100)
    for i in range(100):
        time.sleep(0.01)
        pbar.update(10)  # +10
    pbar.close()
    pbar.clear()
    pbar = tqdm_notebook(total=100)
    for i in range(100):
        time.sleep(0.01)
        pbar.update(5)  # +5
    pbar.close()
    pbar.clear()
    pbar = t

# Generated at 2022-06-24 10:20:38.046000
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook.
    Note: this method does not automatically test the leave attribute
    """

# Generated at 2022-06-24 10:20:41.029264
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests import test_tqdm_notebook___iter___impl
    test_tqdm_notebook___iter___impl(tqdm_notebook)


# Generated at 2022-06-24 10:20:47.671120
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Examples
    --------
    >>> from tqdm.notebook import tqdm_notebook
    >>> tqdm_notebook().update()
    >>> tqdm_notebook().update(1)
    >>> tqdm_notebook().update(2)
    """
    from tqdm.contrib import tenumerate
    for i in tqdm_notebook(tenumerate(3), desc='Test'):
        pass


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-24 10:20:57.215490
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test whether TqdmNotebook.__iter__ is working smoothly"""
    from .utils import _range
    from .std import tqdm
    # test basic cases
    l = list(tqdm_notebook(range(4)))
    assert l == [0, 1, 2, 3]
    # test zero case
    l = list(tqdm_notebook(range(0), 1))
    assert len(l) == 0
    # test disable
    l = list(tqdm_notebook(_range(4), disable=True))
    assert l == [0, 1, 2, 3]
    # test ignore
    l = list(tqdm_notebook(_range(4), disable=None))
    assert l == [0, 1, 2, 3]
    # test auto disable with file=None

# Generated at 2022-06-24 10:21:07.393406
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    progress_bar = tqdm_notebook(ascii=True, ncols=120)
    progress_bar.display(close=True)

    progress_bar = tqdm_notebook(ascii=True, ncols=120)
    assert progress_bar.displayed is False
    progress_bar.display()
    assert progress_bar.displayed

    clear_output()
    progress_bar = tqdm_notebook(ascii=True, ncols=120)
    assert progress_bar.displayed is False
    progress_bar.display(ncols=200)
    assert progress_bar.displayed
    assert progress_bar.container.layout.width == "200px"

    clear_output()
    progress_bar = tqdm_note

# Generated at 2022-06-24 10:21:17.641530
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Ensure that `xrange` with errors behaves correctly.
    """
    # Verify KeyboardInterrupt + close
    x = tqdm(xrange(5), desc='t', leave=True)
    for i in x:
        if i == 3:
            raise KeyboardInterrupt()
        x.set_description('t2')
    assert i == 2  # should not be incremented
    assert x.n == 3  # should not be incremented
    assert x.last_print_n == 2  # should not be incremented
    assert x.last_print_t != 0  # last t should be updated
    assert x.ncols == 100  # should not be modified
    x.close()
    # Verify error + close
    x = tqdm(xrange(5), desc='t', leave=True)

# Generated at 2022-06-24 10:21:29.623672
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    # Mute the stdout
    old_stdout = sys.stdout
    sys.stdout = io = StringIO()
    # Generate a status printer
    tqdm_notebook.status_printer(fp=None, total=10, desc="Downloading")
    # Recover the stdout
    sys.stdout = old_stdout
    # Validate the output
    if IPY not in (32, 3, 4):
        assert "Downloading" in io.getvalue()
        assert "10" in io.getvalue()
        assert "100%" in io.getvalue()
    else:
        assert "Downloading" not in io.getvalue()
        assert "10" not in io.getvalue()
        assert "100%" not in io.getvalue()

# Generated at 2022-06-24 10:21:36.693364
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    container = TqdmHBox()
    container.pbar = None
    assert repr(container) == "{}"

    container = TqdmHBox()
    container.pbar = tqdm_notebook(total=100)
    container.pbar.n = 42
    d = container.pbar.format_dict
    d['bar_format'] = d['bar_format'].replace("{bar}", "<bar/>")
    assert repr(container) == container.pbar.format_meter(**d)

if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:21:44.160004
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test"""
    from scratch.notebook import tqdm_notebook
    from IPython.display import HTML, display, clear_output
    display(HTML("<style>"
                 ".output_result {display: inline-flex;}"
                 ".output_result > * { flex: 1; margin: 0 5px;}"
                 ".output_result > .widget-label { flex: 2; }"
                 "#notebook-container.border-box-sizing { padding: 0; }"
                 "#notebook-container { font-size: 11px; }"
                 "</style>"))
    clear_output(wait=1)

# Generated at 2022-06-24 10:21:55.599461
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert TqdmHBox._repr_json_() == {}
    assert TqdmHBox(l_bar='hello')._repr_json_() == {'l_bar': 'hello'}
    assert TqdmHBox(l_bar='hello', bar_format='{l_bar}').__repr__() == 'hello'
    assert TqdmHBox(l_bar='hello', bar_format='{l_bar}').__repr__(True) == 'hello'
    assert TqdmHBox(l_bar='hello', bar_format='{l_bar}|').__repr__() == 'hello|'

# Generated at 2022-06-24 10:21:56.945901
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for _ in trange(1, 100, 5):
        pass

# Generated at 2022-06-24 10:22:04.621079
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .tests import tests
    if tests.test_module():
        from io import StringIO
        with StringIO() as buf:
            with tqdm(total=100, file=buf) as pbar:
                for _ in pbar:
                    break
            assert pbar.closed
        if tests.show():
            with tqdm(total=100) as pbar:
                for _ in pbar:
                    break
            pbar.close()
            assert pbar.closed

if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:22:14.178473
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Run unit test for tqdm_notebook.tqdm_notebook.status_printer
    """
    class TestObject:
        fp = None
        total = 10
        desc = "Desc"
        ncols = 50

    # Test default behavior
    obj = TestObject()
    container = tqdm_notebook.status_printer(obj)
    ltext, pbar, rtext = container.children
    assert ltext.value == "Desc"
    assert rtext.value == ""
    assert not container.layout.display
    assert pbar.value == 0
    assert pbar.min == 0
    assert pbar.max == 10
    assert pbar.step == 1
    assert pbar.layout.width == '50%'

    # Test no description
    obj = TestObject()
   

# Generated at 2022-06-24 10:22:21.666754
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Tests the `tqdm_notebook.display` method, which is a bit hacky and internal.
    """
    from IPython import get_ipython
    from IPython.core.display import clear_output
    from IPython.testing.globalipapp import get_ipython
    from IPython.testing.decorators import skipif_not_matplotlib, skipif_not_x11

    # This part will be skipped if no display is available
    @skipif_not_x11
    def test_display():
        try:
            from IPython.display import display, clear_output
        except ImportError:
            from IPython.core.display import display, clear_output
        from tqdm.notebook import tqdm, trange
        from time import sleep
        from numpy import arange


# Generated at 2022-06-24 10:22:32.892854
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from distutils.version import LooseVersion
    import ipywidgets

    if LooseVersion(ipywidgets.__version__) < LooseVersion('7.0'):
        raise unittest.SkipTest("Skip test for old ipywidgets version")

    from tqdm.notebook import tqdm
    from time import sleep;
    from collections import deque
    from numpy.testing import assert_equal
    import sys

    n = 100

    with tqdm(total=n, leave=True) as pbar:
        for i in range(n):
            # Check that bar are aligned and reset can update the total
            if i % 3 == 0:
                pbar.reset(total=n+1)
            sleep(1e-5)
            pbar.update()
