

# Generated at 2022-06-24 10:12:31.684283
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=3)
    t.disp("0")
    import time
    time.sleep(0.1)
    t.display("1", n=1)
    time.sleep(0.1)
    t.display("2", n=2)
    time.sleep(0.1)
    t.display("3", n=3)
    time.sleep(0.1)
    t.display("4", n=4)
    time.sleep(0.1)
    t.display("5", n=5, bar_style="success")
    time.sleep(0.1)
    t.display("6", n=6, bar_style="danger")
    time.sleep(0.1)
    t.display("7", n=7, bar_style="warning")

# Generated at 2022-06-24 10:12:33.589858
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    my_bar = tqdm_notebook(total=10)
    my_bar.clear()



# Generated at 2022-06-24 10:12:38.206532
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook.
    """
    with tqdm_notebook(total=1) as t:
        for item in t:
            assert t.n == 1

    with tqdm_notebook(total=1) as t:
        for item in t:
            raise Exception()



# Generated at 2022-06-24 10:12:46.435410
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .utils import format_dict, format_meter
    from .std import tqdm_gui

    test = tqdm_notebook(total=1)
    text1 = test.format_meter(**format_dict(test, **format_meter()))
    bar_style = 'danger'
    test.update(0)
    test.display(bar_style=bar_style)
    text2 = test.format_meter(**format_dict(test, **format_meter()))
    assert test.colour == bar_style
    test.reset()
    test.display()
    text3 = test.format_meter(**format_dict(test, **format_meter()))
    assert text1 == text3
    test = tqdm_gui(total=1)

# Generated at 2022-06-24 10:12:48.148889
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Cleanup output in Jupyter Notebook for tested methods.
    """
    from IPython.display import clear_output
    clear_output()

# Generated at 2022-06-24 10:12:50.470396
# Unit test for function tnrange
def test_tnrange():
    """
    Unit tests for function tnrange.
    """
    with tnrange(100) as t:
        for j in t:
            x = j

# Generated at 2022-06-24 10:13:02.642648
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for total in (None, 100):  # test with and without known total
        for leave in (False, True):  # test both display modes
            t = tqdm_notebook(total=total, leave=leave)
            for i in t:
                t.update()
                if total is not None and i + 1 >= total:  # loop is finished
                    break
            t.close()
            if total is None:
                try:
                    assert t.container.pbar.max == 1
                except:  # NOQA
                    # assert statement raised, reset did not work
                    raise Exception("tqdm reset did not work")

# Generated at 2022-06-24 10:13:11.969597
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time

    try:
        from ipywidgets import AppLayout, FloatText, Layout, Button
    except:
        return
    # Test with fixed total
    with tqdm(total=10) as fixed_bar:
        for i in fixed_bar:
            time.sleep(0.1)
            if i >= 1:
                fixed_bar.reset(1000)
    # Test unknown total
    with tqdm() as unknown_bar:
        for i in unknown_bar:
            time.sleep(0.1)
            if i >= 1:
                unknown_bar.reset(1000)
    # Test without total
    with tqdm(total=None) as no_total_bar:
        for i in no_total_bar:
            time.sleep(0.1)
            if i >= 1:
                no

# Generated at 2022-06-24 10:13:19.128878
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=4) as pbar:
        for i in pbar:
            if i > 2:
                raise RuntimeError
            pbar.update()


if __name__ == "__main__":
    # execute only if run as a script
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:13:23.485116
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.testing.globalipapp import get_ipython
    with get_ipython():
        for i in tqdm_notebook(range(1, 100)):
            assert i
            if i == 50:
                break


# Generated at 2022-06-24 10:13:25.566587
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for _ in tqdm_notebook(range(10), desc='desc', leave=True):
        pass



# Generated at 2022-06-24 10:13:31.312660
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    box = TqdmHBox(children=[HTML(), IProgress(min=0, max=10), HTML()])
    box.pbar = tqdm_notebook()
    assert repr(box) == '{desc}{bar} {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'

# Generated at 2022-06-24 10:13:40.110691
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test `method update of class tqdm_notebook`.
    """
    try:
        raise Exception()
    except:
        n_iter = 1
        tqdm_notebook_test = tqdm_notebook(
            desc='test', total=n_iter, leave=True)
        for _ in tqdm_notebook_test:
            tqdm_notebook_test.update()
        tqdm_notebook_test.close()
        assert tqdm_notebook_test.n == n_iter



# Generated at 2022-06-24 10:13:46.096115
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    # Note: we don't need to test for multi-process mode as it's not supported

    # Test for GUI mode
    with tqdm_notebook(total=5) as t:
        for i in t:
            assert t.n == i + 1
            if t.n == 2:
                # Test reset
                t.reset()
                assert t.n == 0
                continue
            if t.n >= 5:
                break
        assert t.n == 5



# Generated at 2022-06-24 10:13:55.898618
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method `status_printer` of class `tqdm_notebook`.
    """
    # Tests:
    #   - left column
    #   - right column
    #   - bar
    #   - bar size
    #   - bar style
    #   - bar color
    #   - bar value
    #   - bar min
    #   - bar max
    #   - bar orientation
    # With:
    #   - dynamic_ncols
    #   - different ncols values
    #   - desc and no desc
    all_tests_passed = True
    column_widths = [0, 50, 100, '50%', '100%', 'aaa']
    desc = "Description"

# Generated at 2022-06-24 10:14:00.612873
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests that resetting a shared bar in tqdm notebook sets the progress
    bar to the correct value.
    """
    from __future__ import print_function
    t = tnrange(30, leave=False)
    # progress is now at 10%
    t.reset(20)
    # progress should be at 10% but is at 0%
    for i in t:
        print(i)



# Generated at 2022-06-24 10:14:07.173181
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # -------------------------------------
    # NOTEBOOK progress bar
    # -------------------------------------
    # Hide progress bar after completion
    #  a) without error - tqdm_notebook(total=100, leave=False)
    #  b) with error - tqdm_notebook(total=100, leave=True)
    #  c) no total - tqdm_notebook(leave=True)
    #  d) no total, no error - tqdm_notebook()
    with tqdm_notebook(total=100, leave=False) as t:
        for i in range(10):
            t.update()
            sleep(0.01)
    assert t.container.visible

    with tqdm_notebook(total=100, leave=True) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:14:09.984511
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Tests the `__repr__` method of `TqdmHBox`
    using the `test_tnrange` function.
    """
    try:
        from unittest import mock  # python3
    except ImportError:
        import mock  # python2

    with mock.patch('IPython.display.display'):
        test_tnrange()



# Generated at 2022-06-24 10:14:14.816597
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if not IPY:  # pragma: no cover
        return  # ipywidgets unavailable

    if IPY <= 3:
        from IPython.html.widgets import FloatProgress as IProgress
    else:
        from ipywidgets import FloatProgress as IProgress
    from IPython.display import clear_output

    clear_output(wait=1)
    try:
        c = tqdm_notebook.status_printer(None)  # noqa: F841
        assert isinstance(c, HBox)
        assert isinstance(c.children[1], IProgress)
    finally:
        c.close()


test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:14:17.592059
# Unit test for function tnrange
def test_tnrange():
    """
    Tests for `trange` function using nose framework.
    """
    with tnrange(4) as t:
        for i in t:
            assert i == t.n - 1
            if i == 2:
                t.set_description("test")


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:14:26.035003
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import IPython
    if IPython.version_info < (4, 0, 0):
        raise ImportError(
            "IPython.version_info < (4, 0, 0). Please update ipywidgets."
            " See https://ipywidgets.readthedocs.io/en/stable/user_install.html")
    from ipywidgets import IntProgress
    if IntProgress is None:
        raise ImportError(
            "IntProgress not found. Please update ipywidgets."
            " See https://ipywidgets.readthedocs.io/en/stable/user_install.html")
    from IPython.display import display

# Generated at 2022-06-24 10:14:31.862596
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=100) as t:
        for i in range(100):
            sleep(0.1)
            t.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:14:39.321268
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import random as rd

    # random tqdm objects
    qs = [tqdm_notebook(total=rd()) for _ in range(10)]
    # update it a few times
    for i in range(10):
        for q in qs:
            q.update(rd())
    # perform a few updates and check for exceptions
    for q in qs:
        update_val = rd()
        q.update(update_val)
        assert q.n >= update_val

# Generated at 2022-06-24 10:14:42.786875
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm
    t = tqdm(range(10))
    for x in t:
        pass
    t.reset()
    t.close()

test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:14:50.165193
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Initialize
    t = tqdm_notebook(ncols=100)
    assert t.total is None
    try:

        # Auto display
        assert not t.displayed
        t.update_total(100)
        assert t.displayed
        assert t.total == 100

        # Close
        t.close()
        t.displayed = True
        t.close()
        assert not t.displayed

        # Errors
        t.reset()
        t.update_total(100)
        t.update(101)
        t.close()
    finally:
        t.close()



# Generated at 2022-06-24 10:14:55.544357
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # test tqdm_notebook __iter__ raises error
    # import tqdm.notebook as tn
    t = tqdm_notebook(iterable=[], total=3)
    try:
        for _ in t:
            # raise error
            raise ValueError
    except ValueError:
        assert t.n == 1
    else:
        assert False


if __name__ == "__main__":  # pragma: no cover
    from time import sleep
    from IPython.core.display import HTML
    from tqdm import tqdm as std_tqdm
    from main import __version__

    with tnrange(10) as t:
        for i in t:
            # Update bar content
            t.set_description('Test {}'.format(i))

# Generated at 2022-06-24 10:14:57.790127
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test with None as a total number of iterations
    # NB: This is actually the main reason of this unit test
    tqdm_notebook(None).__iter__()


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:14:59.169639
# Unit test for function tnrange
def test_tnrange():
    from .tests import comparison
    comparison(tnrange, "tnrange")

# Generated at 2022-06-24 10:15:09.097754
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .gui import tqdm as tqdm_gui

    with tqdm_notebook(total=1) as pbar:
        with tqdm_gui(total=2) as pbar2:
            pbar.update()
            pbar.update()
            pbar2.update()
            pbar2.update()
            pbar2.update()
            pbar.update()

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:15:11.442086
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    d = tqdm_notebook.status_printer(None)
    assert isinstance(d, TqdmHBox)



# Generated at 2022-06-24 10:15:17.027118
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from inspect import isfunction
    tn = tqdm_notebook(total=10, leave=True, desc='test', bar_format='{bar}')
    for _ in tn:
        pass
    assert isfunction(tn.disp)

    tn = tqdm_notebook(total=10, leave=True, desc='test', bar_format='{bar}')
    for _ in tn:
        break
    assert isfunction(tn.disp)


if __name__ == '__main__':
    import unittest
    unittest.main()

# Generated at 2022-06-24 10:15:24.852076
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=1) as pbar:
        update(n=1)

    with tqdm_notebook(total=1) as pbar:
        update(n=0)

    with tqdm_notebook(total=1) as pbar:
        update()

    with tqdm_notebook(total=0) as pbar:
        update(1)



# Generated at 2022-06-24 10:15:29.418596
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    f = tqdm_notebook(range(4))
    for i in f:
        pass
    assert f.displayed
    f.close()
    assert not f.displayed
    # test again (ensure no error)
    f.close()
    assert not f.displayed


# Generated at 2022-06-24 10:15:35.030649
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from unittest import mock
        from IPython.display import display, clear_output
        with mock.patch('IPython.display.display'):
            with mock.patch('IPython.display.clear_output'):
                display(TqdmHBox())
                clear_output()
                display(TqdmHBox())
                clear_output()
                display(TqdmHBox())
    except ImportError:
        pass

test_TqdmHBox()

# Generated at 2022-06-24 10:15:47.142758
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-24 10:15:55.356743
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test the close method (make sure it is called)"""

    from unittest import TestCase, skipIf

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    import sys
    import tqdm.auto as tqdm

    if tqdm._tqdm.gui.TQDM_GUI == 'notebook':
        class TestCloseMethod(TestCase):
            """Test the close method (make sure it is called)"""
            @patch.object(tqdm._tqdm.gui.tqdm_notebook.TqdmHBox, 'close')
            def test_close_method(self, close):
                """Test close method"""

# Generated at 2022-06-24 10:16:04.675536
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert repr(tqdm_notebook.status_printer(None, 1000, 'desc', 100)) == \
        ("{'bar_format': '{l_bar}<bar/>{r_bar}', 'desc': 'desc',\n"
         " 'n': 0, 'ncols': 100, 'total': 1000, 'unit': 'it', 'unit_scale': True,\n"
         " 'unit_divisor': 1000}")

# Generated at 2022-06-24 10:16:08.451775
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        pbar = TqdmHBox(children=())
    except Exception:
        raise
    else:
        assert pbar.__repr__() == "{n:.2f}%|•         |"
    finally:
        pbar.close()



# Generated at 2022-06-24 10:16:10.202631
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .tests import test_close

    test_close(tqdm_notebook)



# Generated at 2022-06-24 10:16:14.016554
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tnrange(100, desc='test'):
        1
        2
        3

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:16:23.725131
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    TqdmHBox._repr_json_ = lambda _, __: {"n": 3, "total": 4}
    assert repr(TqdmHBox()) == "3/4 [===>                   ]"
    assert TqdmHBox()._repr_pretty_(None) == "3/4 [===>                   ]"
    assert TqdmHBox()._repr_pretty_(None, pretty=True) == "3/4 [===>                   ]"
    TqdmHBox._repr_json_ = lambda _, pretty: {"n": 3, "total": 4, "ascii": not pretty}
    assert repr(TqdmHBox()) == "3/4 [===>                   ]"

# Generated at 2022-06-24 10:16:30.772279
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test for TqdmHBox __repr__"""
    h = TqdmHBox()
    h.pbar = tqdm()
    h.pbar.cur = 3
    h.pbar.total = 10
    h.pbar.bar_format = '{bar}'
    assert str(h) == '\r    [#####     ]   30%|#####           |\r3/10 [00:00<?, ?it/s]'
    h.pbar.close()


# Generated at 2022-06-24 10:16:34.616451
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import trange

    with trange(10, leave=False) as pbar:
        for i in pbar:
            sleep(0.01)

# Generated at 2022-06-24 10:16:41.951877
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        IProgress(max=10)  # Jupyter 4+ randomises the initial width
        IProgress(max=100)  # so we need more than one
    except NameError:  # pragma: no cover
        raise ImportError()  # skip tests if ipywidgets not installed
    except Exception:  # pragma: no cover
        raise RuntimeError("IPython widgets failed to create, try updating jupyter/ipywidgets")  # NOQA: E501
    from IPython.display import clear_output
    t = tqdm_notebook(total=10)
    for i in range(3):
        t.reset()
        assert t.n == 0
        t.update(7)
        assert t.n == 7
        clear_output(wait=False)
        t.reset()


# Generated at 2022-06-24 10:16:46.721540
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .basics import tqdm
    from .gui import TqdmHBox

    for pretty in [True, False]:
        t = tqdm(total=100)
        t.update(1)
        print(t.container.__repr__(pretty))
        t.container.close()

    TqdmHBox().__repr__(pretty)



# Generated at 2022-06-24 10:16:55.575108
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # setup test variables
    ncols = '100%'
    min_value = 0
    max_value = 18.4746
    value = 7.0882

    # initialize test class
    test_class = TqdmHBox()
    test_class.pbar = object()
    test_class.pbar.format_dict = {'ncols': ncols,
                                   'bar_format': None,
                                   'min_value': min_value,
                                   'max_value': max_value,
                                   'value': value,
                                   'ascii': True}

    # generate the class representation
    class_repr = test_class.__repr__(pretty=True)

    # generate the expected representation

# Generated at 2022-06-24 10:17:01.318907
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from IPython import get_ipython
    except ImportError:
        pass
    else:
        ip = get_ipython()
        ip.run_cell('from tqdm.notebook import trange, tqdm')
        ip.run_cell('for _ in trange(10): pass')
        ip.run_cell('for _ in tqdm(range(10)): pass')

# Generated at 2022-06-24 10:17:12.445997
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .tests import test_tqdm
    # run through class tqdm to generate tests
    # (not possible on class tqdm_notebook because of Jupyter)
    test_tqdm(tqdm)
    # test special behaviour of error bars
    # NB: cannot use "for i in tqdm_notebook" because broken
    #     in IPython async due to KeyboardInterrupt
    t = tqdm_notebook(total=10)
    for i in range(10):
        t.update()
    # clear warning bar
    t.close()
    t = tqdm_notebook(total=10)
    for i in range(10):
        t.update()
    t.reset()
    for i in range(10):
        t.update()
    t.close()
    t

# Generated at 2022-06-24 10:17:22.227420
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    from time import sleep
    from random import random
    from numpy.random import normal

    for a in tqdm_notebook(range(0, 30), desc="1st loop"):
        for b in tqdm_notebook(range(0, 100), desc="2nd loop"):
            for c in tqdm_notebook(range(0, 100), desc="3rd loop", leave=False):
                sleep(0.01 * normal(0.5, 0.1))  # randn(0.5, 0.1)

        if random() > 0.8:
            try:
                raise ValueError()
            except ValueError:
                # Clear last bar
                c.clear()
                # Print traceback
                raise


# Unit tests for method __iter__ and __enter__ of class

# Generated at 2022-06-24 10:17:30.233089
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import pytest

    class UnexpectedException(Exception):
        def __init__(self, msg):
            super(UnexpectedException, self).__init__(msg)

    with pytest.raises(UnexpectedException) as exception_info:
        with tqdm_notebook(range(100), unit="it") as pbar:
            for i in pbar:
                if i == 50:
                    raise UnexpectedException("Unexpected Exception!")
    assert "Unexpected Exception!" == str(exception_info.value)

# Generated at 2022-06-24 10:17:40.895088
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    from .utils import FormatStdin
    from .std import format_interval
    from .std import TIME_SENSITIVE  # NOQA

    # Init a tqdm_notebook instance
    t = tqdm_notebook(total=100, leave=False, unit='i',
                      unit_scale=True, unit_divisor=1024, dynamic_ncols=True)
    # Test first `display` call
    assert t.format_dict['total'] == t.total
    t.display()
    assert t.format_dict['total'] == t.total
    # Test second `display` call with a message
    t.display(msg="Hello world!")
    assert t.format_dict['total'] == t.total
    # Test closing the bar
    t.display(close=True)

# Generated at 2022-06-24 10:17:44.381697
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test tqdm_notebook update method"""
    def test(tq):
        tq.update(3)
        tq.update(2)
        tq.update()
        tq.update(1)
    test(tqdm_notebook(total=5))

# Generated at 2022-06-24 10:17:52.467721
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    t = tqdm_notebook(total=1)
    t.set_description(u"Descr\u00E9ption")
    t.set_postfix(OrderedDict([('a', 'b'), ('c', 'd')]))
    t.display(close=True)
    t.display(bar_style='info')
    t.display(bar_style='danger')
    t.display(bar_style='success')
    t.display(msg='test')
    t.display(close=True)

# Generated at 2022-06-24 10:17:56.233437
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # noinspection PyListCreation
    t = tqdm_notebook([])
    t.close()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:18:07.013560
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import version_info
    from time import sleep
    from os import getenv

    if version_info.major == 3:
        from time import perf_counter as time
    else:
        from time import time

    def test_tqdm_notebook_display(leave=False, total=None):
        t = tqdm_notebook(total=total, desc='Test', unit='iB', miniters=1,
                          mininterval=0, leave=leave)
        t.update(0)
        assert t.displayed
        assert str(t) == ''  # no output on tqdm_notebook

        # Update with no iteration
        t.update()
        for _ in range(3):
            sleep(0.01)
            t.update()

        t.update(2)

# Generated at 2022-06-24 10:18:12.471250
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm._utils import _term_move_up
    for _ in tqdm_notebook(range(3), leave=True):
        tqdm_notebook().reset()
        print('\nend of loop')
    print('end of test_tqdm_notebook_reset')



# Generated at 2022-06-24 10:18:16.036258
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in range(5):
        t = tqdm_notebook(total=4, leave=True)
        for j in range(4):
            sleep(0.1)
            t.update()
        t.reset()
    t.close()

# Generated at 2022-06-24 10:18:26.156627
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    try:
        from time import monotonic as time
    except ImportError:  # pragma: no cover
        from time import time

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.025)
            pbar.update()

    # total changed
    with tqdm_notebook(total=4, leave=True) as pbar:
        for i in range(4):
            sleep(0.025)
            pbar.update()

    # total changed
    with tqdm_notebook(total=0, leave=True, dynamic_ncols=True) as pbar:
        for i in range(4):
            sleep(0.025)
            pbar.update(2)


# Generated at 2022-06-24 10:18:36.166208
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for class `tqdm_notebook`.
    """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    from IPython.display import clear_output

    # Use the IPython notebook interface for tqdm
    with unittest.mock_module.patch('tqdm.gui.tqdm.tqdm_notebook', unittest.DEFAULT,
                                    tnrange=tnrange, tqdm=tqdm, trange=trange):
        from tqdm._tqdm_gui import tqdm_notebook as _tqdm
        from tqdm import tqdm as _tqdm_base

        # Test tqdm notebook default parameters

# Generated at 2022-06-24 10:18:39.599020
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = trange(10)
    for i in bar:
        bar.update()
        if i > 2:
            break
    bar.close()
    assert not bar.container.children[1].bar_style

# Generated at 2022-06-24 10:18:48.608227
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from itertools import count
    from time import sleep
    from .utils import FormatCustom, format_dict
    from .std import tqdm
    from .gui import tqdm_gui
    from .gui import tgrange

    with tqdm_gui(total=4, leave=True) as pbar:
        for i in pbar:
            pbar.display(desc='{0:5.2%}'.format(i / pbar.total))
            sleep(0.1)
            pbar.display(desc='{0:5.2%}'.format(i / pbar.total), bar_style='success')
            sleep(0.1)


# Generated at 2022-06-24 10:18:58.516972
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # pylint: disable=undefined-loop-variable
    from io import StringIO
    from time import sleep
    import os

    # create fake stdout for testing
    f = StringIO()
    # f = open('/dev/null', 'w')
    # hack warnings to use f instead of stdout
    _stderr = sys.stderr

    def fxn():
        sys.stderr = f

    # monkey patch _decr_instances of tqdm to avoid RuntimeError on exit
    tqdm._decr_instances = lambda: None

    # hack to get the ncols number
    ncols = int(os.environ.get('COLUMNS', 80)) - 1


# Generated at 2022-06-24 10:19:06.533217
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=2) as t:
        assert t.total == 2
        t.update()
        t.update()
        t.close()


if __name__ == '__main__':  # pragma: no cover
    try:
        test_tqdm_notebook()
        print('Success:')
    except Exception:
        raise
    else:
        # On python 2.6, 'print' is not a function
        __builtins__.__dict__['print'](
            'Run the module from IPython console or Jupyter notebook.',
            file=sys.stderr)

# Generated at 2022-06-24 10:19:10.495198
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():

    # Test with a exception
    with tqdm_notebook(range(10), leave=True) as t:
        for i in t:
            if i == 3:
                raise Exception()
            else:
                t.update()

    # Test with a keyboard interrupt
    with tqdm_notebook(range(10)) as t:
        try:
            for i in t:
                if i == 3:
                    raise KeyboardInterrupt()
                else:
                    t.update()
        except KeyboardInterrupt:
            pass

    # Test without a exception
    with tqdm_notebook(range(10)) as t:
        for i in t:
            t.update()

# Generated at 2022-06-24 10:19:20.764802
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test the two modes
    import traceback
    try:
        from nose.tools import istest  # @UnresolvedImport
        # Only raise assertion errors if they are related to this test
        if istest() and not traceback.extract_stack()[-2][2] == 'test_TqdmHBox___repr__':
            return
    except ImportError:
        pass
    try:
        hbox = TqdmHBox()
        hbox.children = [1, 2, 3]
        print(hbox)
    finally:
        # Avoid other tests being affected
        del TqdmHBox.__repr__
        del TqdmHBox._repr_pretty_

# Generated at 2022-06-24 10:19:27.906496
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from unittest import TestCase
    import json
    class TestTqdmHBox_repr(TestCase):
        """Test __repr__ of class TqdmHBox"""
        def test_repr(self):
            """Test __repr__"""
            from tqdm.notebook import tqdm_notebook
            from tqdm.std import TqdmTypeError

# Generated at 2022-06-24 10:19:40.295278
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        pbar.display()
        pbar.display()
        assert hasattr(pbar, 'container')
        assert pbar.container.visible
        assert pbar.container.children[0].value == pbar.desc
        assert pbar.container.children[1].value == pbar.n
        assert pbar.container.children[1].max == pbar.total * pbar.unit_scale
        assert pbar.container.children[2].value == ''
        pbar.n = pbar.last_print_n = 0
        pbar.clear()  # DEPRECATED
        pbar.close()
        assert not pbar.container.visible

    pbar = tqdm_notebook(total=3)
   

# Generated at 2022-06-24 10:19:48.584706
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    def display(*args, **kwargs):
        pass

    try:
        pbar = tqdm_notebook(total=0, leave=False)
        pbar.update(1)
        # gh-1248: was raising RecursionError
        for i in pbar:
            pbar.update()
            break
        # check that user can override display
        pbar = tqdm_notebook(total=0, leave=False, disable=False)
        pbar.disp = display
        pbar.update(1)
    except Exception:
        assert False, 'Failed trange notebook test'
    else:
        assert True, 'Success trange notebook test'

# Generated at 2022-06-24 10:19:55.856391
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import tqdm
    from .utils import _supports_unicode
    from .utils import format_interval
    from .utils import format_meter
    from .utils import format_sizeof
    import io
    import os
    import sys

    # Code stolen from tqdm.std
    if not _supports_unicode(sys.stdout):
        if sys.stdout.encoding:
            encoding = sys.stdout.encoding.lower()
        else:
            encoding = "utf-8"
        if encoding in {"utf-8", "utf8"}:
            pass
        elif encoding in {"cp65001", "utf-8-sig"}:
            sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8")
        else:
            raise

# Generated at 2022-06-24 10:20:04.000422
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    if IPY < 2:
        return

    container = TqdmHBox()
    assert repr(container) == ""
    assert container._repr_json_() == {}
    container = TqdmHBox(children=[2, 3])
    assert repr(container) == ""
    assert container._repr_json_() == {}

    container.pbar = object()
    assert repr(container) != ""
    assert container._repr_json_() != {}


if __name__ == '__main__':
    tqdm_notebook.test()  # pragma: no cover

# Generated at 2022-06-24 10:20:08.396848
# Unit test for function tnrange
def test_tnrange():
    "Test tnrange function"
    with closing(tnrange(9, desc='Test1')) as x:
        for i in x:
            pass
    with closing(tnrange(9, desc='Test2', leave=True)) as x:
        for i in x:
            pass

# Generated at 2022-06-24 10:20:11.756466
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(10)):
        pass

    for i in tqdm_notebook(range(10), desc='hi', total=100, bar_format='{desc}[{elapsed}]'):
        pass



# Generated at 2022-06-24 10:20:21.731049
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from random import random
    from time import sleep
    from unittest import TestCase, main
    from IPython.display import clear_output


# Generated at 2022-06-24 10:20:29.937860
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():

    import json
    import os
    import random

    from .tqdm import tqdm
    from .utils import _range

    os.environ['COLUMNS'] = '120'
    verbose = os.getenv('TEST_VERBOSE')

    # list of attributes to update in the loop, with their new values

# Generated at 2022-06-24 10:20:38.136095
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(range(3)) as t:
        msg = "Hello !"
        t.display(msg)
        assert t.container.children[-1].value == msg
        t.display(msg, bar_style='danger')
        assert t.container.children[-2].bar_style == 'danger'
        t.display(msg, bar_style='info')
        assert t.container.children[-2].bar_style == 'info'
        t.display(msg, bar_style='success')
        assert t.container.children[-2].bar_style == 'success'
        t.display(msg, bar_style='warning')
        assert t.container.children[-2].bar_style == 'warning'
        t.display(msg, bar_style='danger')
        assert t.container

# Generated at 2022-06-24 10:20:41.161778
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for _ in trange(1, leave=True):
        pass

if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:20:51.015634
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from distutils.version import LooseVersion
    ipywidgets_v = LooseVersion(ipywidgets.__version__)
    if ipywidgets_v >= '7.0.0':
        return  # there is no __repr__ in ipywidgets7
    x = TqdmHBox()
    assert x.__repr__() == ''
    assert x.__repr__(True) == ''
    x.pbar = mock.MagicMock()
    x.pbar.widget_dict.return_value = {'bar': {}, 'info': {}}
    assert x.__repr__() == '{bar:|{"bar": {}, "info": {}}|}'

# Generated at 2022-06-24 10:20:54.901383
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .utils import _test_env_notebook
    with _test_env_notebook():
        from tqdm.notebook import tqdm
        from tqdm import trange
        for i in trange(10):
            assert isinstance(tqdm(total=10), TqdmHBox)

# Generated at 2022-06-24 10:21:01.089514
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    hbox.pbar = tqdm_notebook()
    assert re.match(r'\r\s*\| *0 *\|', hbox.__repr__())  # py3
    assert re.match(r'\r\s*\| *0 *\|', hbox.__repr__(pretty=True))  # py3
    assert re.match(r'\r\s*\| *0 *\|', hbox.__repr__(pretty=False))  # py3
    assert re.match(r'\r\s*\| *0 *\|', str(hbox))  # py3


# Generated at 2022-06-24 10:21:11.570412
# Unit test for method status_printer of class tqdm_notebook

# Generated at 2022-06-24 10:21:19.313283
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    '''
    Case:
    The class tqdm_notebook has a method close() that is used to finish the
    progress bar.

    It is good practice to check if the bar finished correctly by calling the
    close() method even if the iterable passed to the object's constructor has
    been fully iterated.

    This test checks if the bar is finished correctly by using the `close()`
    method when the iterable passed to the `tqdm_notebook` object's constructor
    is completely iterated.
    '''
    for i in tqdm_notebook(range(5)):
        pass
    for i in tqdm_notebook([1, 2, 3, 4, 5]):
        pass



# Generated at 2022-06-24 10:21:23.190364
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)


if __name__ == "__main__":
    r = trange(100)
    for i in r:
        sleep(0.01)
        r.set_description("Processing %i" % i)

    # Unit test for method update of class tqdm_notebook
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(0.1)

# Generated at 2022-06-24 10:21:27.329446
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        bar = TqdmHBox()
        assert repr(bar) == bar._repr_json_()
        assert repr(bar) == bar._repr_pretty_()
        assert repr(bar)
        assert repr(bar)
    except Exception as e:
        print("ERROR: %s" % e)
        sys.exit(1)
    print("Success!")  # pragma: no cover

if __name__ == "__main__":  # pragma: no cover
    test_TqdmHBox()

# Generated at 2022-06-24 10:21:29.667275
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = tqdm_notebook(total=1)
    bar.total = 2
    bar.close()



# Generated at 2022-06-24 10:21:38.708626
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from IPython.display import HTML
    from IPython.display import display
    from IPython.display import clear_output
    from IPython.display import Markdown

    f = StringIO()
    pbar = tqdm_notebook(total=3, file=f)
    clear_output()
    assert repr(pbar) == str(pbar)
    pbar.update()
    clear_output()
    assert repr(pbar) == str(pbar)
    pbar.update()
    # By now, either `display(pbar.container)` has been called with
    # a "pretty" representation, so the next call to `repr` will return
    # a pretty representation
    # Or it has not been called, so we can call `display(pbar)` to
    # force a

# Generated at 2022-06-24 10:21:45.166280
# Unit test for function tnrange
def test_tnrange():
    from tqdm.auto import trange as ta
    from time import sleep
    from numpy import asarray

    with ta(3, desc="my_tnrange", leave=True) as t:
        for i in t:
            sleep(0.5)

    with ta(3, desc="my_tnrange", leave=True) as t:
        for i in t:
            pass
        t.set_postfix(asarray([1, 2, 3]))
        for i in t:
            pass

    tnrange3 = tnrange(3, desc="my_tnrange", leave=True)
    for i in tnrange3:
        pass
    tnrange3.close()


if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-24 10:21:49.316929
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import pytest  # use pytest to raise an error for "raises"
    with pytest.raises(NotImplementedError):
        with tqdm_notebook(total=3) as t:
            t.write("")



# Generated at 2022-06-24 10:21:59.187503
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Simple unit tests for tqdm_notebook
    """

# Generated at 2022-06-24 10:22:07.260700
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():  # pragma: no cover
    """
    Tests the clear method of `tqdm` with `gui=True`

    Note: requires IPython/Jupyter (for `HTML` and `HBox`)
    """
    from .tests import common

    for i in tqdm(common.irange(), total=7, desc='1st loop'):
        common.sleep(.1)
        t = tqdm(common.irange(), total=7, desc='2nd loop')
        for j in t:
            common.sleep(.1)
        t.close()
    print('success')

# Generated at 2022-06-24 10:22:16.005604
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    IPython/Jupyter Notebook progressbar decorator for iterators.
    Includes a default `range` iterator printing to `stderr`.
    """
    from copy import copy
    from time import sleep

    # import IPython/Jupyter base widget and display utilities
    from ipywidgets import HBox, FloatProgress
    from IPython.display import display

    for leave in [False, True]:
        for total in [None, 1000]:
            for total_err in [None, 1000]:
                for close_err in [False, True]:
                    for total_changed in [False, True]:
                        for close_changed in [False, True]:
                            pbar = tqdm_notebook(total=total,
                                                 leave=leave)
                            # update bar
                            pbar.display()  #

# Generated at 2022-06-24 10:22:18.884564
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        with tqdm_notebook(total=10) as progress_bar:
            progress_bar.clear()
    except Exception as error:
        assert False, 'clear() method has not been tested, validation failed ({})'.format(error)

# Generated at 2022-06-24 10:22:24.869769
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # INIT
    total = 11
    iterable = range(total)
    pbar = tqdm_notebook(iterable, disable=True)
    # CODE
    for _ in pbar:
        pass
    # ASSERTS