

# Generated at 2022-06-24 10:12:26.945503
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_hbox = TqdmHBox()
    tqdm_hbox.pbar = std_tqdm()
    assert str(tqdm_hbox) == tqdm_hbox.pbar.format_meter()

# Generated at 2022-06-24 10:12:34.011185
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test for case when total is not specified
    test_printer = tqdm_notebook.status_printer(sys.stdout)
    assert isinstance(test_printer, TqdmHBox), "Test status_printer, total is not specified"

    # Test for case when total is specified
    test_printer = tqdm_notebook.status_printer(sys.stdout, total=30)
    assert isinstance(test_printer, TqdmHBox), "Test status_printer, total is specified"

# Generated at 2022-06-24 10:12:35.843489
# Unit test for function tnrange
def test_tnrange():
    try:
        for _ in tnrange(17):
            pass
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-24 10:12:45.086658
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook.
    """
    try:
        from IPython import get_ipython as _get_ipython
    except ImportError:
        return
    ip = _get_ipython()
    if ip is None or ip.__class__.__name__ == 'TerminalInteractiveShell':
        return

    from random import random, randint
    from time import sleep

    ncols_values = [None, '100%', 100, '100px', True, False]
    for ncols in ncols_values:
        with tqdm(total=17, file=sys.stdout, ncols=ncols) as pbar:
            for _ in range(15):
                pbar.update()
                sleep(random())
            pbar.close()



# Generated at 2022-06-24 10:12:51.476703
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test to test tqdm status printer in notebook"""
    try:
        from IPython.display import clear_output
    except ImportError:
        pass  # Cannot test in non-ipython environment
    else:
        clear_output()  # Clear output for for interactive testing
        # Test for total
        progbar = tqdm_notebook.status_printer(total=10,
                                               ncols='100px')
        pbar = progbar.children[1]
        assert (pbar.max, pbar.value, pbar.step) == (10, 0, 1)
        # Test for No-total
        progbar = tqdm_notebook.status_printer()

# Generated at 2022-06-24 10:13:03.152847
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class TqdmMockup(object):
        pass
    t = TqdmMockup()
    t.fp = sys.stdout
    t.total = 100
    t.n = 0
    t.desc = "foo"
    t.ncols = 100
    t.dynamic_ncols = False
    t.unit_scale = 1
    t.unit = ""

# Generated at 2022-06-24 10:13:08.865165
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    l = [(i, None) for i in range(10)]
    if IPY < 4:
        l.insert(0, (0, l[0][1]))
    for n, widget in l:
        x = tqdm_notebook.status_printer(None, n, 'Description')
        assert isinstance(x, HBox)
        assert widget is None or x == widget


# Test for tqdm_notebook

# Generated at 2022-06-24 10:13:16.768030
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from collections import Iterable
    with tqdm_notebook(total=50, dynamic_ncols=True, desc='Test: ', leave=True,
                       unit='it', position=0) as pbar:
        for i in pbar:
            assert isinstance(i, int) and i == pbar.n, \
                "Wrong iteration (expected {0}, got {1})!".format(pbar.n, i)
            assert i <= 50, "too many iterations!"
            if i <= 20:
                pbar.set_postfix_str('Hello %i' % i, refresh=False)
            elif i <= 40:
                pbar.set_postfix({'B,': i, 'A': '/'.join(map(str, range(3)))},
                                 refresh=False)

# Generated at 2022-06-24 10:13:28.871343
# Unit test for function tnrange
def test_tnrange():
    from .tests import test
    from .autonotebook import trange

    """
    test for function tqdm_notebook()
    """
    for i in trange(1000000):
        pass

    with tnrange(10) as t:
        for i in t:
            pass

    with tqdm(total=9) as t:
        t.update()

    with tqdm(total=9) as t:
        t.update(2)

    list(tqdm(range(10)))

    test(tqdm, leave=True, ncols=100)
    test(tqdm, mininterval=0.01, miniters=1, ncols=100)
    test(tqdm, mininterval=10, miniters=1, ncols=100)
   

# Generated at 2022-06-24 10:13:41.364285
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # get a random list of objects
    L = [range, str, list, set, dict, hash]
    # call method _repr_json_
    d = TqdmHBox()._repr_json_()
    # check output
    assert isinstance(d, dict)
    assert "desc" in d
    assert "bar_format" in d
    assert "postfix" in d
    assert "rate" in d
    assert "ascii" in d
    assert isinstance(d["ascii"], bool)
    assert "total" in d
    # check if only specified types are present in output
    for k, v in d.items():
        assert k != "postfix" or any([isinstance(i, q) for i in v for q in L])
    # check pretty printing
    assert TqdmH

# Generated at 2022-06-24 10:13:49.010400
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for desc in [False, "desc"]:
        for leave in [False, True]:
            for total in [None, 2]:
                t = tqdm(desc=desc, total=total, leave=leave)
                t.clear()
                if total is None:
                    assert t.last_print_n == 0
                else:
                    assert t.last_print_n == t.n
                t.reset()



# Generated at 2022-06-24 10:14:00.118914
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from pprint import pprint

    # Use StringIO with pprint to check rendered output
    out = StringIO()
    pprint({'pbar': TqdmHBox()}, stream=out)
    s = out.getvalue()

    assert not s
    assert 'desc' in s
    assert 'bar' in s
    assert 'total' not in s
    assert 'ncols' not in s
    assert 'desc=' not in s
    assert 'bar=' not in s
    assert 'total=' not in s
    assert 'ncols=' not in s

    assert 'desc' in repr(TqdmHBox())
    assert 'bar' in repr(TqdmHBox())
    assert 'total' not in repr(TqdmHBox())
    assert 'ncols' not in repr

# Generated at 2022-06-24 10:14:02.781958
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .tests import Iterable
    from .gui import tqdm
    from time import sleep
    progressbar = tqdm(Iterable(5), leave=False)
    for _ in progressbar:
        sleep(0.5)
        progressbar.update()
    progressbar.close()

# Generated at 2022-06-24 10:14:16.109557
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from .std import time
    from .utils import close_on_error
    with close_on_error(lambda: tn.close()):
        tn = trange(3, desc='tn', leave=True, position=0)
        tn.display(msg="test")
        time.sleep(1)
        tn.display(close=True)
        tn.display(bar_style='success')
        tn = trange(3, position=2)
        try:
            tn.display(bar_style='danger')
        except:
            tn.display(bar_style='success')
        else:
            assert False, "no exception was raised"


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_

# Generated at 2022-06-24 10:14:25.147090
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # This might be part of a unit test suite in the future
    import os
    import sys
    import unittest
    import sys
    from tqdm._utils import _term_move_up

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # type: ignore

    try:
        from StringIO import StringIO  # Python 2
    except ImportError:
        from io import StringIO  # Python 3+

    class TestTqdmNotebookUpdate(unittest.TestCase):
        @patch.object(sys, 'stderr', StringIO())  # type: ignore
        def test_basic(self):
            with tqdm_notebook(total=10) as pbar:
                for i in range(10):
                    pbar.update(2)


# Generated at 2022-06-24 10:14:32.795826
# Unit test for function tnrange
def test_tnrange():
    from time import sleep

    with tnrange(4) as t:
        for i in range(4):
            sleep(.5)
            t.set_description('step {}'.format(i))
            t.update()

    with tnrange(2, 3) as t:
        for i in t:
            sleep(.5)
            t.set_description('step {}'.format(i))

    l = list(range(25))
    with tnrange(len(l)) as t:
        for i in l:
            l[i] = i ** 2
            sleep(.01)
            t.set_description('step {}'.format(i))
            t.update()

    with tnrange(10, desc='first loop') as t:
        for i in range(10):
            sleep(.1)

# Generated at 2022-06-24 10:14:43.401646
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython.testing.globalipapp import get_ipython
    except ImportError:
        from IPython.kernel.zmq.tests.test_kernelapp import get_ipython
    from IPython.core.display import clear_output
    ip = get_ipython()
    if ip is None:  # pragma: no cover
        tqdm_notebook.display("Can only test tqdm_notebook().update() in an IPython environment!")
        return  # pragma: no cover
    ip.Magics.autocall = 2
    ip.run_cell("from tqdm.notebook import tqdm as tqn")
    ip.run_cell("from tqdm.notebook import tqdm as tqn")

# Generated at 2022-06-24 10:14:52.159700
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.display import clear_output
    from tqdm.auto import tqdm as tqdm_auto
    # Set notebook width to narrow value in order to test text wrapping
    notebook_width_px = 100
    h = TqdmHBox()
    h.layout.width = str(notebook_width_px) + 'px'
    h.layout.flex_flow = 'row wrap'
    pbar = IProgress(min=0, max=100)
    ltext = HTML()
    rtext = HTML()
    # Test setter/getter
    assert pbar.bar_style == ''
    pbar.bar_style = 'info'
    assert pbar.bar_style == 'info'
    # Test child packaging
    h.children = [ltext, pbar, rtext]
    h.p

# Generated at 2022-06-24 10:14:57.486301
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from IPython.core.display import clear_output
    print("\nTesting tqdm_notebook reset method\n")
    for leave_bar in [False, True]:
        for error_during_loop in [False]:
            total, error_at = 10, 4
            pbar = tqdm_notebook(total=total, leave=leave_bar)
            for i in pbar:
                sleep(0.005)
                if i == error_at and error_during_loop:
                    raise RuntimeError("tqdm_notebook reset unit test")
                pbar.update()
            # test without calling close
            # (which would set bar_style to success)
            if not leave_bar:
                clear_output(wait=True)
                pbar.container.close()

# Generated at 2022-06-24 10:15:09.270038
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10) as pbar:
        for _ in range(10):
            pass
        pbar.reset(total=20)
        for _ in range(20):
            pass


if __name__ == "__main__":
    from time import sleep
    from tqdm import trange
    try:
        for i in trange(10, desc='1st loop'):
            for j in trange(5, desc='2nd loop', leave=False):
                for k in trange(100, desc='3nd loop', leave=False):
                    sleep(0.01)
    except Exception as e:
        print(e)

# Generated at 2022-06-24 10:15:17.518250
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox._repr_json_() == {}
    assert TqdmHBox(pbar=None)._repr_json_() == {}
    assert repr(TqdmHBox(pbar=None)) == "<Box>"
    assert repr(TqdmHBox(pbar=None)).startswith("<Box>")
    assert TqdmHBox(pbar=None).__repr__() == "<Box>"
    assert TqdmHBox(pbar=None).__repr__(True) == "<Box>"

    # _repr_json_
    pbar = std_tqdm(ascii=True)
    assert TqdmHBox(pbar=pbar)._repr_json_(pretty=None) == {'ascii': True}
    assert TqdmHBox

# Generated at 2022-06-24 10:15:30.585053
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from copy import copy
    import sys

    # Python 2-3 compatible
    if hasattr(sys, 'pypy_version_info'):
        # In PyPy sys.stdout.encoding is None
        # (https://foss.heptapod.net/pypy/pypy/-/issues/1940)
        return

    if sys.stdout.encoding is None:
        sys.stdout.encoding = 'UTF-8'

    tqdm_notebook.status_printer(None, total=None, desc=None, ncols=None)
    tqdm_notebook.status_printer(None, total=None, desc=None, ncols=100)

# Generated at 2022-06-24 10:15:41.097619
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from io import StringIO
    from sys import version_info
    from IPython.core.display import HTML, SVG
    from IPython.core.displaypub import publish_display_data
    NB_KERNEL_DISP_METHOD = "ipykernel.kernelbase.Kernel.do_display"

    class _KernelBase(object):
        """
        Mock kernel base class. Used to get a reference to the
        display method.
        """
        def do_display(_, data, metadata, transient):
            publish_display_data('', data=data, metadata=metadata,
                                 transient=transient)

    # class IPythonKernel(_KernelBase):
    #     def do_display(_, data, metadata, transient):
    #         publish_display_data('', data=data, metadata=metadata,
    #                              transient

# Generated at 2022-06-24 10:15:50.148530
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.auto import trange
    from unittest import TestCase

    class TestTqdmNotebook(TestCase):
        def test_reset(self):
            # three different modes to test:
            for leave in [True, False, None]:
                with trange(3, leave=leave) as t:
                    for i in t:
                        if i == 1:
                            t.reset(total=7)
                        t.update()
                    self.assertEqual(t.n, t.total)

    try:
        from unittest import main
        main(module='tqdm.tests.test_notebook', exit=False)
    except SystemExit:
        pass

# Generated at 2022-06-24 10:15:55.897136
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    from tqdm import trange
    try:
        for i in trange(10, desc="test trange"):
            sleep(random() / 5)
    except Exception:
        pass


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:16:05.117977
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from pytest import raises
    try:
        from IPython import get_ipython
    except ImportError:
        raise (ImportError(
            "IPython doesn't seem to be installed. "
            "Please install it to use `tqdm.notebook.clear()`."))

    ip = get_ipython()
    if ip is None:
        raise RuntimeError('Could not access IPython shell')

    ip.run_code('from tqdm import tqdm_notebook as tqdm')
    ip.run_code('from tqdm.notebook import tqdm_notebook as tqdm')
    ip.run_code('from tqdm.notebook import tqdm_notebook as tqdm; t = tqdm(1); t.close()')

# Generated at 2022-06-24 10:16:13.422422
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_raises
    from random import shuffle
    from time import sleep
    from .gui import tqdm_gui

    # Disable asyncio event loop
    tqdm_gui.list_of_running_instances = []

    tmp_list = list(range(5))

    shuffle(tmp_list)
    with tqdm_notebook(tmp_list) as t:
        for i in t:
            if i >= 2:
                raise AssertionError
            sleep(0.01)

    assert_raises(AssertionError, lambda: list(tqdm_notebook(tmp_list)))

# Generated at 2022-06-24 10:16:16.400856
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=100) as pbar:
        import time
        for i in range(10):
            pbar.update(10)
            time.sleep(0.01)



# Generated at 2022-06-24 10:16:26.393146
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test the method status_printer of class tqdm_notebook"""
    import sys

    if 'IPython' in sys.modules:
        # In IPython: Test the status_printer of tqdm_notebook
        msg = 'Testing tqdm_notebook.status_printer...\n'
        tqdm_notebook.status_printer(sys.stdout, desc=msg, ncols=100)
        msg = 'Testing tqdm_notebook.status_printer... done.'
        tqdm_notebook.status_printer(sys.stdout, desc=msg, ncols=100)

if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:16:29.653759
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as t:
        t.update(1)
        t.clear()
        assert t.n == 0
        t.update(2)
        assert t.n == 2
        t.close()

# Generated at 2022-06-24 10:16:39.585219
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from random import randint
    from time import sleep

    # Simple bar reset
    bar = tqdm_notebook(total=100)
    for _ in range(100):
        sleep(randint(1, 10) * 0.01)
        bar.update()
    bar.reset(total=300)
    for _ in range(300):
        sleep(randint(1, 10) * 0.01)
        bar.update()
    bar.close()

    # Reset an unknown total bar
    bar = tqdm_notebook(total=None)
    for _ in range(3):
        sleep(randint(1, 10) * 0.01)
        bar.update()
    bar.reset(total=20)

# Generated at 2022-06-24 10:16:48.108529
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import CloseableFile

    with CloseableFile() as fobj:
        t = tqdm_notebook(total=1, file=fobj)
        t.update()
        t.close()

    with CloseableFile() as fobj:
        t = tqdm_notebook(total=1, file=fobj)
        t.update(1)
        t.close()

    with CloseableFile() as fobj:
        t = tqdm_notebook(total=1, file=fobj)
        t.close()


if __name__ == '__main__':
    from .main import _test  # noqa
    _test()

# Generated at 2022-06-24 10:16:56.730763
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import unittest
    import copy

    class TestRepr(unittest.TestCase):

        def test_repr(self):
            iterable = [1, 3, 5]

            tqdm_bar = tqdm_notebook(iterable, desc="Testing")

            tqdm_bar.n = 1
            tqdm_bar.refresh()

            pbar = TqdmHBox()
            pbar.pbar = tqdm_bar

            # pretty mode
            result = pbar.__repr__(True)

# Generated at 2022-06-24 10:16:59.943196
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as pbar:
        for i in pbar:
            if i == 10:
                pbar.clear()
            sleep(0.01)


# Generated at 2022-06-24 10:17:05.515489
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook constructor
    """
    progress_bar = tqdm_notebook()
    assert progress_bar.total == 1

    progress_bar = tqdm_notebook(total=10)
    assert progress_bar.total == 10

    progress_bar = tqdm_notebook(total=None)
    assert progress_bar.total is None



# Generated at 2022-06-24 10:17:11.141384
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Note: not really a test, but a debug / demo
    pbar = tqdm_notebook(total=2)
    pbar.update(1)
    from IPython.display import HTML, display
    display(pbar.container)
    pbar.container.value = None
    print(repr(pbar.container))

# Generated at 2022-06-24 10:17:20.999920
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    from unittest import TestCase
    from collections import defaultdict
    from copy import deepcopy
    class T(TestCase):
        def test_default(self):
            h = TqdmHBox()
            h.pbar = pbar = defaultdict(lambda: 0)
            self.assertEqual(repr(h), "[{desc}{bar}]")
            self.assertEqual(h._repr_json_(), {})
            pbar['total'] = 100
            self.assertEqual(repr(h), "[{desc}: {percentage:3.0f}%]")
            pbar['total'] = None  # non-numeric
            self.assertEqual(repr(h), "[{desc}: {n:4.0f}]")

# Generated at 2022-06-24 10:17:28.320717
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    from .std import tqdm as std_tqdm

    def f(a=3, b=1, c='b'):
        for i in range(a * b * 2):
            if c == 'b':
                yield i
            elif c == 's':
                yield str(i)

    t = tqdm_notebook(f(c='s'))
    assert isinstance(t, std_tqdm)
    assert isinstance(t.n, int)
    assert isinstance(t.container, HBox)

    # NORMAL CASE
    # ------------
    # 1) __iter__ is instantiated with a generator and thus with `gui='text'`
    # 2) disp is False (since delay <= 0)
    # 3) update() is called in the loop -> disp is True


# Generated at 2022-06-24 10:17:37.316687
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test the update method of the `tqdm.notebook.tqdm` class."""
    t = tqdm_notebook(total=2)
    try:
        assert t.container.children[-2].value == 0  # rtext.value
        t.update()
        t.update()
        assert t.container.children[-2].value == 1  # rtext.value
    finally:
        t.close()


if __name__ == "__main__":
    from .main import _tqdm_test  # NOQA: F401
    _tqdm_test(tqdm, tqdm_notebook)

# Generated at 2022-06-24 10:17:46.118585
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=5) as t:
        for i in range(3):
            t.update()
        t.reset()
        for i in range(3):
            t.update()
    assert t.n == 3
    assert t.total == 5


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=[__file__, '--with-doctest',
                         '--nocapture', '--nologcapture'],
                    exit=False)

# Generated at 2022-06-24 10:17:56.278567
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.utils import format_dict
    from tqdm.gui import format_meter

    # default
    hbox = TqdmHBox(children=[HTML(), IProgress(), HTML()])
    hbox.pbar = tqdm_notebook(100)
    hbox._repr_json_()
    assert repr(hbox) == format_meter(**format_dict(100, None))

    # pretty w/o pbar
    hbox = TqdmHBox(children=[HTML(), IProgress(), HTML()])
    hbox._repr_pretty_(None)

    # pretty w/ pbar
    hbox = TqdmHBox(children=[HTML(), IProgress(), HTML()])
    hbox.pbar = tqdm_notebook(100)
    hbox._repr_pretty_(None)


# Generated at 2022-06-24 10:18:05.307543
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    test_cases = [
        (None, "", "", ""),
        ("abcd", "abcd", "", ""),
        ("", "", "", ""),
        ("", "", "abcd", "abcd"),
        ("", "", "", ""),
        ("abcd", "abcd", "abcd", ""),
        ("abcd", "abcd", "", "abcd"),
        ("abcd", "abcd", "abcd", "abcd"),
        ("abcd<bar/>efgh", "abcd", "efgh", ""),
        ("abcd<bar/>efgh", "abcd", "", "efgh"),
        ("abcd<bar/>efgh", "abcd", "efgh", "efgh"),
    ]


# Generated at 2022-06-24 10:18:08.439717
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Given
    with tqdm_notebook(total=10) as t:
        for i in t:
            t.clear()
            if i == 5:
                break
    # Then
    assert not t.displayed

# Generated at 2022-06-24 10:18:14.442684
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """

    # Imports
    import sys
    import warnings

    # Defining class to test
    class Cls(tqdm_notebook):
        def __init__(self):
            self.close_was_called = False
            self.x = 0
            self.total = 3
            self.n = 0
            self.container = None
            self.disable = False
            self.unit = "unit"
            self.dynamic_ncols = False

        def update(self, n=1):
            self.x = n

        def close(self):
            self.close_was_called = True

    # Creating object
    cls = Cls()

    # Testing exceptions

# Generated at 2022-06-24 10:18:19.174724
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Runs a basic test of :class:`tqdm_notebook`"""
    from .tests_tqdm import test_tqdm
    test_tqdm(tqdm_notebook)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:18:25.188056
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Sanity test for `tqdm.notebook.TqdmHBox`'s setters/getters
    """
    container = TqdmHBox()  # No pbar
    assert container._repr_json_() == {}
    assert repr(container) == ""
    container._repr_pretty_(None)
    container.pbar = "dummy"
    assert repr(container) != ""
    assert container.pbar == "dummy"



# Generated at 2022-06-24 10:18:35.196782
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = tqdm_notebook(total=10)
    pbar.update()
    pbar.container.description = 'description'
    pbar.container.bar_style = 'danger'
    assert pbar.container._repr_json_(pretty=False) == {
        'n': 1, 'total': 10, 'desc': 'description',
        'bar_format': '{l_bar}{bar}{r_bar}'}
    assert pbar.container.__repr__() == (
        'description|  0%|                             | 1/10 [00:00<?, ?it/s]')
    assert pbar.container.__repr__(pretty=True) == (
        'description|  0%|                             | 1/10 [00:00<?, ?it/s]')



# Generated at 2022-06-24 10:18:38.895878
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(1)
            pbar.update(1)



# Generated at 2022-06-24 10:18:46.822618
# Unit test for function tnrange
def test_tnrange():
    for _ in tnrange(10, desc="test #1", leave=True):
        pass
    for _ in tnrange(10, desc="test #2", leave=True,
                     disable=False, unit_scale=True,
                     unit='dots', dynamic_ncols=True):
        pass
    for _ in tnrange(10, desc="test #3", leave=True,
                     miniters=2, mininterval=0.1, maxinterval=1.1,
                     smoothing=0.9, bar_format='{l_bar}>{n_fmt}/{total_fmt}'):
        pass

# Generated at 2022-06-24 10:18:57.581385
# Unit test for constructor of class tqdm_notebook

# Generated at 2022-06-24 10:19:06.832435
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test tqdm_notebook reset"""
    from IPython import get_ipython
    ip = get_ipython()
    if ip is not None:
        try:
            ip.magic("gui widgets")
        except AttributeError:  # ipython < 6
            ip.magic("matplotlib widget")
    bar = tqdm_notebook(total=10)
    for _ in range(5):
        bar.update()
    bar.reset(total=15)
    for _ in range(15):
        bar.update()
    bar.close()


# TODO: make a test for method close of class tqdm_notebook


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:19:11.396628
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from ipywidgets import IntProgress
    from .std import tqdm as std_tqdm
    from .gui import tqdm_gui
    from .gui import tqdm as tqdm_gui_tqdm

    b = IntProgress()
    c = tqdm_notebook(total=None)
    c.container.children = (None, b, None)
    c.reset()
    assert b.max == 1 and b.value == 0 and b.bar_style == 'info'
    d = std_tqdm(total=10)
    d.reset()
    assert d.n == 0 and d.total == 10
    e = tqdm_gui(total=10)
    e.reset()
    assert e.n == 0 and e.total == 10
    e.reset(total=5)

# Generated at 2022-06-24 10:19:22.216228
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .utils import FormatBase
    from .auto import tqdm as auto_tqdm

    class tqdm_dummy(FormatBase):
        bar = '{desc}{bar}'

    tn = tqdm_notebook(1, 2, 3)

    # Test with total
    tn.container = tqdm_notebook.status_printer(tn.fp, total=100)
    assert tn.container.children[0].value == ''
    assert tn.container.children[1].bar_style == ''
    assert tn.container.children[1].max == 100
    assert tn.container.children[1].value == 0
    assert tn.container.children[1].min == 0
    assert tn.container.children[2].value == ''

    # No total

# Generated at 2022-06-24 10:19:26.066252
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Simple test for tqdm_notebook.close"""
    # tnrange requires ncols given
    t = tnrange(5, ncols=10, desc="my bar")
    for i in t:
        pass
    t.close()

# Generated at 2022-06-24 10:19:32.304240
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    bar = tqdm_notebook(desc='tqdm', total=9, leave=True)
    assert repr(bar) == bar.__repr__(pretty=True) == str(bar)
    assert repr(bar) == repr(bar.container)
    assert repr(bar.__repr__()) == repr(bar.__repr__(pretty=False))

test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:19:43.590551
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    with tqdm_notebook(total=1, desc="test") as pbar:
        assert pbar.displayed
        sleep(0.01)
        pbar.update(0)
        pbar.display("hello")  # also check that msg='', ''!=None
        assert pbar.container.children[1].bar_style == 'info'
        pbar.display("hello", bar_style='success')
        assert pbar.container.children[1].bar_style == 'success'
        pbar.display("hello", bar_style='danger')
        assert pbar.container.children[1].bar_style == 'danger'
        pbar.display("hello", bar_style='danger')
        assert pbar.container.children[1].bar_style == 'danger'

# Generated at 2022-06-24 10:19:51.768526
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .tests import setup_tests
    setup_tests()

    from .tests._test_tqdm import _test_status_printer
    import sys

    try:
        __IPYTHON__
        no_glue = True
    except NameError:
        no_glue = False
    _test_status_printer(tqdm_notebook, disable=no_glue, ncols=0, file=sys.stdout)
    _test_status_printer(tqdm_notebook, disable=no_glue, ncols=None, file=sys.stdout)
    _test_status_printer(tqdm_notebook, disable=no_glue, ncols=10, file=sys.stdout)

# Generated at 2022-06-24 10:20:03.423288
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import _range
    from .std import tqdm
    try:
        from IPython import get_ipython
    except ImportError:
        get_ipython = None

    # IPython magic
    if get_ipython:
        ip = get_ipython()
        ip.magic("gui qt5")

    for cls in [tqdm]:
        # force bar not to close
        bar = cls(total=1, leave=True)
        bar.update(1)
        bar.close()
        assert not bar.container.visible

        # force bar to close (1/2)
        bar = cls(total=2, leave=True)
        bar.update()
        bar.close()
        assert not bar.container.visible

        # force bar to close (2/2)

# Generated at 2022-06-24 10:20:09.761755
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(range(3)) as t:
        assert t.n == 0
        assert not t.container.visible

        t.update()
        assert t.n == 1
        assert t.container.visible

        t.close()
        assert t.n == 1
        assert not t.container.visible


# Test for method reset of class tqdm_notebook

# Generated at 2022-06-24 10:20:19.520856
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    t = tqdm_notebook(total=4)
    for _ in range(4):
        t.update()

    t.close()
    try:
        t.clear()
    except:
        pass
    try:
        t.display()
    except:
        pass

    t = tqdm_notebook(total=4, leave=True)
    for _ in range(4):
        t.update()
    clear_output(wait=True)
    t = tqdm_notebook(total=4, desc="Danger Batman!", leave=True)
    for _ in range(4):
        t.update()
    clear_output(wait=True)

# Generated at 2022-06-24 10:20:27.979026
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    import datetime
    from time import sleep
    from math import ceil as _ceil

    try:
        from IPython import get_ipython
    except ImportError:
        get_ipython = lambda: None  # NOQA

    class fake_IProgress(object):
        def __init__(self, *args, **kwargs):
            self.bar_style = ''
            self.value = 0

        def __iadd__(self, increase):
            return self

        def close(self):
            pass


# Generated at 2022-06-24 10:20:39.841939
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = tqdm_notebook(total=0, leave=True)
    bar.close()
    assert not bar.displayed

    with pytest.raises(RuntimeError):
        bar = tqdm_notebook(total=0)
        bar.close()

    bar = tqdm_notebook()
    bar.update()
    bar.close()
    assert not bar.displayed

    bar = tqdm_notebook()
    bar.update(0)
    bar.close()
    assert not bar.displayed

    bar = tqdm_notebook(total=0)
    bar.update(0)
    bar.close()
    assert not bar.displayed

    bar = tqdm_notebook(total=0)
    bar.update(1)
    bar.close()
    assert bar

# Generated at 2022-06-24 10:20:43.497890
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import tqdm
    for i in tqdm(range(10)):
        sleep(2)
    for i in tqdm(range(10)):
        i / (i - 9)
        sleep(0.1)

# Generated at 2022-06-24 10:20:44.964542
# Unit test for function tnrange
def test_tnrange():
    assert list(tnrange(3)) == [0, 1, 2]



# Generated at 2022-06-24 10:20:54.535906
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import re
    import time
    # Test case 1, run through once
    pbar = tqdm_notebook(total=5)
    for i in range(5):
        time.sleep(0.01)
        pbar.display(pbar.n)
    assert pbar.n == 5
    assert pbar.last_print_n == 5
    assert pbar.last_print_t is not None
    assert re.search(r'^\s*1/1\s*$', pbar.container.children[-1].value)
    assert pbar.container.children[-2].style.bar_color is not None
    pbar.close()
    # Test case 2, do an update (not clear output, and display
    # but no change to last_print_n)
    pbar = tqdm

# Generated at 2022-06-24 10:21:00.925335
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook.
    """
    from tqdm._tqdm_test_example import main as test
    try:
        from io import StringIO  # Py3
    except ImportError:
        from io import BytesIO as StringIO  # Python 2
    out = StringIO()
    test(tqdm_notebook, out)
    val = out.getvalue().strip()
    # Run tests to make sure everything works
    assert val.count('\n') == 10
    # Make sure we're using IPython widgets
    assert 'IPython.html.widgets' in val
    # Check that bar_format is ignored by ipywidgets
    assert 'ignorebar' not in val



# Generated at 2022-06-24 10:21:11.419307
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    if IPY == 0:
        raise unittest.SkipTest("Missing ipywidgets")
    if IPY >= 4:
        raise unittest.SkipTest("Testing disabled for notebook")

    n = 50
    pbar = tqdm_notebook(total=n)
    try:
        for i in range(n):
            pbar.update()
            if i == 2:
                raise Exception
    except Exception:
        pbar.close()
    if IPY < 4:
        assert pbar.container.children[-2].bar_style == 'danger'
    else:
        assert pbar.container.children[-2].style.bar_style == 'danger'
    # make sure we don't clear the bar for non-errors
    pbar.reset(total=n)

# Generated at 2022-06-24 10:21:18.422441
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class _TqdmHBox(TqdmHBox, list):
        bar_style = ''
        value = 0.0
        max = 1.0
        format_dict = {}
        children = []
        def format_meter(self, **_):
            return 'Test'
        def __init__(self, **kwargs):
            self.update(kwargs)
    assert repr(_TqdmHBox()) == 'Test'
    assert repr(_TqdmHBox(pretty=True)) == 'Test'


if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:21:24.852518
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm._tqdm_notebook import tqdm_notebook  # NOQA
    t = tqdm_notebook(total=10, bar_format='{l_bar}{bar}{r_bar}')
    for i in range(5, 10):
        sleep(0.1)
        t.update(i)
    t.close()



# Generated at 2022-06-24 10:21:27.650181
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import trange
    for _ in trange(5):
        pass
    for _ in trange(3):
        pass

# Generated at 2022-06-24 10:21:37.066133
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from unittest.mock import patch
    from unittest import TestCase
    # Prepare HTML encoding test
    try:  # Py3
        from html import unescape
    except ImportError:  # Py2
        # noinspection PyUnresolvedReferences
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    # Create TqdmHBox, Text(HTML) and FloatProgress widgets
    pbar = IProgress(min=0, max=2)
    ltext = HTML()
    rtext = HTML()
    # Create HBox
    hbox = TqdmHBox(children=[ltext, pbar, rtext])
    hbox.pbar = proxy(pbar)  # pbar is a weakref of the original widget
    # Update widget
    pbar.value = 1

# Generated at 2022-06-24 10:21:44.407566
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from inspect import isfunction

    def test_widget():
        # test main display
        t = tqdm_notebook(total=2,
                          bar_format="{l_bar}{bar}{r_bar}")
        for i in t:
            t.display()

        # test msg and pos
        t = tqdm_notebook(total=2,
                          bar_format="{l_bar}{bar}{r_bar}")
        for i in t:
            t.display(msg='{foo}'.format(foo=1),
                      pos=1)
            t.display(pos=0,
                      msg='{foo}'.format(foo=2))

        # test close

# Generated at 2022-06-24 10:21:56.000208
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test the `__repr__` method of the `tqdm.notebook.TqdmHBox` class"""
    progress_box_1 = TqdmHBox(
        children=[HTML(), IProgress(min=0, max=1), HTML()])
    assert '\n[0%|          | 0/1 [00:00<?, ?it/s]\n]\n' == \
        progress_box_1.__repr__()

    progress_box_2 = TqdmHBox(
        children=[HTML('this is a test'), FloatProgress(min=0, max=1), HTML()])
    assert '\n[   0%|          | 0/1 [00:00<?, ?it/s]this is a test\n]\n' == \
        progress_box_2.__repr

# Generated at 2022-06-24 10:21:59.397544
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm
    bar = tqdm_notebook(total=1000)
    bar.reset(total=100)
    assert bar.total == 100

# Generated at 2022-06-24 10:22:09.736314
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm.auto import tqdm
    with tqdm(total=2, desc='testing close()') as pbar:
        pbar.update(1)
        pbar.close()  # nothing happens, end style not changed

    with tqdm(total=2, desc='testing close()') as pbar:
        pbar.update(2)
        pbar.close()  # nothing happens, end style not changed

    with tqdm(total=2, desc='testing close()') as pbar:
        pbar.close()  # nothing happens, end style not changed

    with tqdm(total=2, leave=False, desc='testing close()') as pbar:
        pbar.update(2)
        pbar.close()  # close ipywidgets display


# Generated at 2022-06-24 10:22:15.603203
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from warnings import catch_warnings
    with catch_warnings(record=True) as warns:
        from tqdm.notebook import trange
    assert len(warns) == 1
    assert 'tqdm_notebook/__init__.py:23' in str(warns[0].file)
    # test __iter__
    l = [0] * 5
    for i, _ in enumerate(trange(5)):
        l[i] += 1
    assert l == [1] * 5

# Generated at 2022-06-24 10:22:22.968896
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from copy import copy
    from json import loads

    # Test _repr_json_()
    hbox = TqdmHBox()
    assert loads(hbox._repr_json_(pretty=None)) == {}
    hbox.pbar = tqdm_notebook(total=10)
    assert loads(hbox._repr_json_(pretty=None)) != {}
    assert loads(hbox._repr_json_(pretty=True)) != {}
    assert loads(hbox._repr_json_(pretty=False)) != {}
    assert loads(hbox._repr_json_(pretty=True)) != loads(hbox._repr_json_(pretty=False))
    assert hbox._repr_json_(pretty=True).endswith(',', 0, -2)