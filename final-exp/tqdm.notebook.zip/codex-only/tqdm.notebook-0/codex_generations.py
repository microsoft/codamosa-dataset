

# Generated at 2022-06-24 10:12:28.817437
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import display, clear_output
    bar = tqdm_notebook.status_printer("file", 0, "description")
    display(bar)
    clear_output(wait=1)
    display(bar)  # this should not raise an error


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:12:37.893973
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from .utils import format_sizeof
    from time import sleep
    for n in tqdm(range(int(1e7)), leave=True):
        sleep(1e-4)
    print(repr(tqdm(range(10), desc='<hoho>', leave=True, ncols=100)))
    print(format_sizeof(400))
    print(format_sizeof(1000))
    print(format_sizeof(1e6))
    print(format_sizeof(9.9e9))
    print(format_sizeof(1e12))
    print(format_sizeof(1.8e18))



# Generated at 2022-06-24 10:12:46.278768
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # test default ...
    # Note: for this test, we have to define a `test()` function
    # to avoid bugs with `finally: close()`
    def test():
        for i in tqdm_notebook(range(10)):
            pass
    # ... and no-total cases
    if hasattr(tqdm_notebook, 'sp'):  # pragma: py2 no cover
        tqdm_notebook.sp = None
    for nt in [True, False]:
        # give control to the user
        if not nt:
            tqdm_notebook.total = 10
            tqdm_notebook.disable = False
        else:
            tqdm_notebook.disable = True
            tqdm_notebook.total = None
        # test
        test()
        #

# Generated at 2022-06-24 10:12:52.211691
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from unittest import mock
        from IPython.display import display
    except ImportError:
        from unittest import mock
        from IPython.display import display

    pbar = IProgress(min=0, max=10)
    pbar.value = 1
    pbar.layout.width = "20px"
    ltext = HTML()
    rtext = HTML()
    ltext.value = 'test1'
    rtext.value = 'test2'
    pbar.bar_style = 'info'
    container = TqdmHBox(children=[ltext, pbar, rtext])
    container.pbar = proxy(pbar)
    display(container)

    # test __repr__()

# Generated at 2022-06-24 10:12:57.438673
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    n = 100
    with tqdm_notebook(total=n, leave=True) as progressbar:
        for i in range(n):
            progressbar.clear()
            progressbar.update(1)



# Generated at 2022-06-24 10:13:05.093270
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test for manual iteration
    for _, pbar in zip(tqdm_notebook(range(10)), range(10)):
        pbar.update()
    assert pbar.n == 10

    # Test nested loop
    for _ in tqdm_notebook(range(5)):
        for _, pbar in zip(tqdm_notebook(range(2)), range(2)):
            pbar.update()
        assert pbar.n == 2
    assert pbar.n == 10

    # Test nested leave=False
    for _ in tqdm_notebook(range(2)):
        for _, pbar in zip(tqdm_notebook(range(3), leave=False), range(3)):
            pbar.update()
        assert pbar.n == 3

# Generated at 2022-06-24 10:13:08.598590
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock
    container = TqdmHBox()
    container.pbar = MagicMock()
    container.pbar.format_dict = {}
    repr(container)

# Generated at 2022-06-24 10:13:16.595740
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython.display import clear_output
    from IPython.display import display
    from time import sleep

    for init_n in [None, 100]:
        for total in [None, 100]:
            for leave in [True, False]:
                t = tqdm_notebook(total=total, leave=leave, init=init_n)
                if init_n is not None:
                    assert t.n == init_n
                t.reset(total=None)
                # noinspection PyUnusedLocal
                def post_reset(l):
                    sleep(0.01)  # make clear_output non-noop
                    clear_output(wait=True)
                    assert t.n == 0
                    assert t.last_print_t == 0
                    assert t.smoothing == 1

# Generated at 2022-06-24 10:13:23.644262
# Unit test for function tnrange
def test_tnrange():
    """Unit test for tnrange"""
    # Python 3 (IPython 4+)
    for _ in tqdm(range(3)):
        pass

    # Python 2 (IPython 3+)
    try:
        range = xrange
    except NameError:
        pass
    else:
        for _ in tqdm(range(3)):
            pass

    return True

if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:13:28.134603
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for n in tqdm_notebook(range(100)):
        assert n == n
    for n in tqdm_notebook(range(100)):
        assert n == n
        break
    t = tqdm_notebook(range(2))
    for n in t:
        assert n == n
        t.update(5)
    for n in tqdm_notebook(range(100)):
        assert n == n
        if n > 5:
            raise Exception()
    for n in tqdm_notebook(range(100)):
        assert n == n
        if n > 5:
            break



# Generated at 2022-06-24 10:13:34.544659
# Unit test for function tnrange
def test_tnrange():
    """Unit test for tnrange"""
    for i in tnrange(7):
        pass
    for j in tnrange(3, 12):
        pass
    for i in tnrange(3, 32, 5):
        pass
    for j in tnrange(3, 32, 5, leave=True):
        pass

if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-24 10:13:39.700293
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        for i in tqdm_notebook(_range(10)):
            assert i == i
    except:  # NOQA
        raise



# Generated at 2022-06-24 10:13:42.907119
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=1, leave=True) as pbar:
        for i in pbar:
            assert i == 0
            pass


# Generated at 2022-06-24 10:13:54.148647
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output

    pbar = tqdm_notebook(total=100)
    assert pbar.container.layout.width is None
    for i in range(10):
        pbar.update()
        clear_output(wait=True)
    clear_output(wait=1)
    assert pbar.container.layout.width == "100%"
    pbar.close()

    pbar = tqdm_notebook(total=100, ncols=None)
    assert pbar.container.layout.width is None
    pbar.close()
    clear_output(wait=1)

    pbar = tqdm_notebook(total=100, ncols=300)
    assert pbar.container.layout.width == "300px"
    pbar.close()
    clear_output

# Generated at 2022-06-24 10:14:01.202504
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    n = 10
    t = 10
    s = 0.01
    tn = tqdm_notebook(total=t)
    while tn.n < t:
        tn.update(s)
        tn.refresh()
        time.sleep(s)

    # Reset progress bar should set it as on initial state
    tn.reset()

    tn.update()
    assert tn.n == 0

if __name__ == '__main__':
    from .scripts._tqdm import _test_instances
    _test_instances(tqdm_notebook)

# Generated at 2022-06-24 10:14:06.804526
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from numpy.random import randint, seed
    seed(1)
    # Test clear=True
    pbar = tqdm_notebook(total=100)
    for i in range(50):
        pbar.update(1)
        sleep(0.01)
        if pbar.n >= 20 and not pbar.container.children[1].bar_style:
            # display bar as danger after 20% to test
            pbar.container.children[1].bar_style = 'danger'
    pbar.close()


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:14:12.426593
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for constructor of class TqdmHBox.

    Test standard constructor, with and without optional attributes.
    """
    a = TqdmHBox()
    assert str(a) == (
        '<tqdm_notebook.TqdmHBox object at ' + str(id(a)) + '>')
    assert a._repr_json_() == {}

    b = TqdmHBox(children=[HTML(), IProgress(), HTML()])
    assert str(b) == (
        '<tqdm_notebook.TqdmHBox object at ' + str(id(b)) + '>')
    assert b._repr_json_() == {}

    c = TqdmHBox(children=[HTML(), IProgress(), HTML()], pbar=proxy(b.pbar))

# Generated at 2022-06-24 10:14:15.652933
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(None)


if __name__ == "__main__":
    test_tqdm_notebook_status_printer()
    import doctest
    doctest.testmod()

# Generated at 2022-06-24 10:14:24.250584
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from unittest.mock import patch, mock_open
    except ImportError:
        from mock import patch, mock_open
    open_mock = mock_open()
    with patch('builtins.open', open_mock, create=True):
        file = open('foo', 'w')
        pbar = tqdm_notebook(total=10, file=file)
        assert isinstance(pbar.container, TqdmHBox)
        open_mock.assert_called_with('foo', 'w')
        file.write(repr(pbar))
        file.write(str(pbar))
        pbar._repr_pretty_(None)
        file.write(pbar._repr_json_())

# Generated at 2022-06-24 10:14:27.853201
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests import tests
    from .std import tqdm

    for i in tqdm_notebook(tests._range(10)):
        if i == 5:
            return
    for i in tqdm_notebook(tests._range(10)):
        if i == 7:
            raise Exception("testing exception")

if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:14:40.251146
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import unittest
    import os

    class TestTqdmNotebookClass(unittest.TestCase):
        def setUp(self):
            self.t = tqdm_notebook(total=10, disable=False)
        def test_tqdm_notebook_setup(self):
            self.assertTrue(not self.t.disable)
            # test total
            self.assertEqual(10, self.t.total)
            # test leave
            self.assertTrue(self.t.leave)
            # test miniters
            self.assertEqual(0, self.t.miniters)
            # test mininterval
            self.assertEqual(0.1, self.t.mininterval)
            # test n
            self.assertEqual(0, self.t.n)


# Generated at 2022-06-24 10:14:49.633844
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox
    # pbar is None
    hbox = TqdmHBox()
    assert repr(hbox) == repr(list())
    # pbar is empty
    hbox = TqdmHBox(pbar=tqdm_notebook())
    assert repr(hbox) == repr(list())
    # pbar is full
    pbar = tqdm_notebook(total=10)
    for i in range(10):
        pbar.update()
    hbox = TqdmHBox(pbar=pbar)

# Generated at 2022-06-24 10:14:51.624401
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Testing 'tqdm_notebook' constructor"""
    import time
    fp = sys.stdout
    n = 100000
    for j in trange(n, desc="tqdm_notebook test", unit='i'):
        time.sleep(0.01)

# Generated at 2022-06-24 10:14:59.962377
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Test that close() raises no exception
    pbar = tqdm_notebook(total=1)
    pbar.reset()
    pbar.close()
    pbar.close()  # double close should be noop
    pbar.reset()
    pbar.update()
    pbar.set_description('foo')
    pbar.set_postfix(post='bar')
    with std_tqdm(total=100) as pbar2:
        pbar2.update(10)
        pbar.update()
    pbar.close()
    # Test that it catches exception
    pbar.reset(total=1)
    with pbar:
        raise Exception()
    pbar.close()
    # Test that it catches KeyboardInterrupt
    pbar.reset(total=1)
    pbar.update

# Generated at 2022-06-24 10:15:05.316355
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        # suppress deprecation warning
        from IPython.utils.tests.test_warnings import catch_warnings
        with catch_warnings(record=True):
            from IPython.html import widgets
        ipython_enabled = True
    except ImportError:
        ipython_enabled = False
    if not ipython_enabled:
        return
    import time
    pbar = tqdm_notebook(total=100, leave=False)
    for i in range(100):
        pbar.update(1)
    pbar.reset()  # without total argument, left == False shouldn't raise
    assert pbar.total is None
    pbar.reset(total=10)
    assert pbar.total == 10
    pbar.reset(total=50)
    assert pbar.total == 50
    assert p

# Generated at 2022-06-24 10:15:16.709333
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .utils import _term_move_up
    from .std import format_sizeof
    from .utils import UnicodeIO
    pbar = TqdmHBox()
    pbar.pbar = tqdm_notebook('', leave=False)
    pbar.pbar.gauge(6.66, 10.0, 7, 10, '', '', '', '', '', '')
    # only test the beginning by comparing with tqdm std bar
    std_out = pbar.pbar.__repr__()
    out = pbar.__repr__()
    pbar.pbar.close()
    assert (out.startswith(std_out)) and (
        out.endswith("\r%s" % _term_move_up()))

# Generated at 2022-06-24 10:15:19.730569
# Unit test for function tnrange
def test_tnrange():
    from .tests import test_tqdm

    # Check function tnrange
    l = list(tnrange(7, desc="desc", leave=True))
    assert l == test_tqdm.range7


if __name__ == "__main__":
    try:
        test_tnrange()
        print('Successfully passed!')
    except AssertionError:
        print('Failed to pass the unit test')

# Generated at 2022-06-24 10:15:32.680911
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """test display of class tqdm_notebook"""
    import time

    t = tqdm_notebook(total=1)
    t.refresh()
    assert t.displayed
    t.close()

    t = tqdm_notebook(total=1)
    t.display(close=True, check_delay=False)
    assert not t.displayed
    t.close()

    t = tqdm_notebook(total=1)
    t.display(check_delay=False)
    t.close()

    t = tqdm_notebook(total=1)
    t.display(check_delay=False)
    assert t.colour is None  # #872
    t.colour = 'red'
    assert t.colour == 'red'  # #872
    t.close

# Generated at 2022-06-24 10:15:43.820932
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test tqdm_notebook Class"""
    # Test minimal basic usage with ncols
    with tqdm_notebook(total=2, ncols=0) as t:
        assert isinstance(t, tqdm_notebook)
        assert hasattr(t, 'update')
        assert hasattr(t.container, 'children') and len(t.container.children) == 3
        t.update()
        t.update()
    # Test basic usage
    with tqdm_notebook(total=2) as t:
        assert isinstance(t, tqdm_notebook)
        assert hasattr(t, 'update')
        assert hasattr(t.container, 'children') and len(t.container.children) == 3
        t.update()
        t.update()
    # Test iterable


# Generated at 2022-06-24 10:15:52.157061
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from IPython.testing.globalipapp import get_ipython
    except ImportError:
        return (None, None)

    ip = get_ipython()
    ip.config["IPCompleter"]["greedy"] = True

    pbar = tqdm_notebook(total=10, desc="Test")
    repr_pbar = repr(pbar)
    repr_ip = repr(pbar.container)
    pbar.close()

    del ip
    return repr_ip, repr_pbar


if __name__ == '__main__':
    from .main import _test
    _test()

# Generated at 2022-06-24 10:15:56.548865
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    from time import sleep

    with tqdm_notebook(total=1) as pbar:
        for _ in tnrange(3):
            sleep(0.01)
            pbar.update()

# Generated at 2022-06-24 10:16:05.540176
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main

    class Test_tqdm_notebook_display(TestCase):
        def setUp(self):
            self.p = None
            self.container = None
            self.ltext = None
            self.rtext = None
            self.pbar = None
            self.initerrors = ''

        def create_pbar(self, **kwargs):
            try:
                self.p = tqdm_notebook(**kwargs)
                self.container = self.p.container
                self.ltext = self.container.children[0]
                self.pbar = self.container.children[1]
                self.rtext = self.container.children[2]
            except Exception as e:
                self.initerrors += str(e) + '\n'

       

# Generated at 2022-06-24 10:16:14.713455
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    # Testing with unknown total (auto-adapt to `value` changes)
    bar = tqdm_notebook(total=None, leave=True)
    assert bar.total is None
    for _ in range(10):
        bar.update(1)
        sleep(1)
    # Note that the value at the end might be lower than 10
    # Bar was auto-adjusted to the new range (0, 10)
    bar.reset()
    # Testing with known total
    bar.reset(total=15)
    assert bar.total == 15
    for _ in range(10):
        bar.update(1)
        sleep(1)
    assert bar.n == 10
    assert bar.total == 15

# Generated at 2022-06-24 10:16:18.626271
# Unit test for function tnrange
def test_tnrange():
    """Test function tnrange"""
    list(tqdm(tnrange(100)))
    # Test reset during iteration
    list(tqdm(tqdm(tnrange(100)).reset(total=10)))


# Run script if executed as standalone
if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:16:29.225574
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test of method `display` of class `tqdm_notebook`"""
    # On IPython (not Jupyter or IPython 2.x), tqdm_notebook will not
    # display an output, so just test if it's fully functional.
    # On Jupyter and IPython 2.x, we need to test if the output
    # is displayed as expected
    from .gui import _test_gui_display

    if hasattr(IPY, "kernel"):
        # IPython 4.x
        on_ipython = bool(IPY.kernel)
    else:
        try:
            from IPython import get_ipython as get_ipython_func
            on_ipython = bool(get_ipython_func())
        except ImportError:
            on_ipython = False

# Generated at 2022-06-24 10:16:34.851065
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import unittest
    import sys
    import re

    IPY = 0
    try:
        import ipywidgets
        IPY += 4
    except ImportError:
        IPY += 32
        try:
            import IPython.html.widgets as ipywidgets  # NOQA: F401
        except ImportError:
            pass


# Generated at 2022-06-24 10:16:40.081909
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import sys
    if sys.version_info >= (3, 4):  # pragma: no cover
        with tqdm_notebook(total=10) as pbar:
            pbar.update(8)
            pbar.close()
    with tqdm_notebook(total=10) as pbar:
        pbar.update(8)
        pbar.close()

# Tests (to be run from __main__ import tqdm_notebook; test_tqdm_notebook())

# Generated at 2022-06-24 10:16:46.792910
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # locals and globals are needed to run this function in a python subprocess
    # without raising NameError
    globals().update(locals())
    import os

    # Clear previous output (really necessary?)
    # clear_output(wait=1)
    # Set values
    min = 0
    max = 10
    value = 3
    bar_style = None
    # Initialize IPython progress bar
    pbar = IProgress(min=min, max=max, value=value)
    # Check IPython progress bar display
    assert pbar.min == min, "Min value is not set properly"
    assert pbar.max == max, "Max value is not set properly"
    assert pbar.value == value, "Value is not set properly"
    assert pbar.bar_style == bar_style, "Bar style is not set properly"

# Generated at 2022-06-24 10:16:55.825790
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import display
    from IPython.display import clear_output
    # show the bar
    close_after = False
    bar = tqdm_notebook(total=5, desc='Test', leave=close_after)
    for i in range(5):
        bar.update()
    bar.close()
    assert not bar.container.children[1].visible
    assert bar.container.children[1].style.bar_color == 'success'

    # hide the bar
    close_after = True
    bar = tqdm_notebook(total=5, desc='Test', leave=close_after)
    for i in range(5):
        bar.update()
    bar.close()
    assert not bar.container.children[1].visible
    assert bar.container.children[1].style.bar_color

# Generated at 2022-06-24 10:16:59.067144
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10) as t:
        t.display()
        t.reset()
        assert t.n == 0
        t.reset(total=100)
        assert t.total == 100

# Generated at 2022-06-24 10:17:10.435382
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """Test tqdm_notebook(...)"""
    from time import sleep

    class T(tqdm_notebook):
        """Modified tqdm_notebook for testing"""
        def __init__(self, *args, **kwargs):
            """Add attributes for testing"""
            super(T, self).__init__(*args, **kwargs)
            self.current_bar = None
            self.printer_calls = []

        def status_printer(self, file):
            self.current_bar = super(T, self).status_printer(file)
            return self.current_bar

        def format_dict(self, n):
            """Force bar to be 100% full"""
            d = super(T, self).format_dict(n)

# Generated at 2022-06-24 10:17:12.213589
# Unit test for function tnrange
def test_tnrange():
    with tnrange(4) as t:
        for i in t:
            assert i == t.n

# Generated at 2022-06-24 10:17:21.973013
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook.
    """
    # Check if total is preserved with "100%"
    assert isinstance(tqdm_notebook(total=100, ncols=100),
                      tqdm_notebook), "ncols=100% error: total != 100"
    # Check if total is preserved with "100px"
    assert isinstance(tqdm_notebook(total=100, ncols="100px"),
                      tqdm_notebook), "ncols=100px error: total != 100"
    # Check if total is preserved with "100"
    assert isinstance(tqdm_notebook(total=100, ncols=100),
                      tqdm_notebook), "ncols=100 error: total != 100"
    # Check if total is preserved with "

# Generated at 2022-06-24 10:17:33.509230
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup
    tqdm.clear()

    # Test reset and leave=True, leave=False
    for kwargs in [{"total": 5}, {"total": 5, "leave": True}, {"total": 5, "leave": False}]:
        pbar = tqdm_notebook(**kwargs)
        assert pbar.total == kwargs["total"]
        assert not pbar.displayed
        pbar.update(2)
        assert pbar.n == 2
        pbar.reset()
        assert pbar.n == 0
        assert pbar.total == kwargs["total"]
        pbar.update(3)
        assert pbar.n == 3
        pbar.close()
        assert pbar.n == 3
        assert pbar.total == kwargs["total"]
        assert not pbar

# Generated at 2022-06-24 10:17:38.670216
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    """
    Test the method update of class tqdm_notebook
    """
    class Test(tqdm_notebook):
        def __init__(self, **kwargs):
            super(Test, self).__init__(**kwargs)

    t = Test()
    t.update()
    t.update(1)

# Generated at 2022-06-24 10:17:44.968564
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    with tqdm_notebook(total=3, file=sys.stderr) as pbar:
        for i in range(3):
            pbar.update()
    # should automatically close at the end
    # just check that nothing got broken
    assert pbar.total == 3
    assert pbar.n == 3
    assert pbar.last_print_n == 3
    assert pbar.displayed


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-24 10:17:48.260646
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test HBox.__repr__()"""
    from tqdm import trange
    for i in trange(2):
        pass
    return


if __name__ == "__main__":
    import nose
    nose.runmodule()

# Generated at 2022-06-24 10:17:50.012260
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-24 10:18:01.405525
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .gui import tqdm_gui
    from .std import tqdm
    import io

    class TqdmFake(object):
        """Emulates the API of tqdm"""
        def __init__(self, total, desc, ncols):
            self.value = 0
            self.min = 0
            self.max = total
            self.bar_style = ''
            self.desc = desc
            self.ncols = ncols

        def update(self, fake):
            self.value = fake

        @property
        def gui(self):
            return self

    # Test text bar display with format string
    with io.StringIO() as f:
        t = TqdmFake(100, 'Fake', 50)

# Generated at 2022-06-24 10:18:03.238235
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for i in tqdm(range(100)):
        pass
    # test closing notebook tqdm

# Generated at 2022-06-24 10:18:07.555808
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """

    pbar = tqdm_notebook(total=10)
    # Update pbar in a loop
    for _ in range(10):
        pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:18:11.537652
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        display(None)
    except Exception:
        return
    try:
        pbar = IProgress()
        TqdmHBox(children=[None, pbar, None])
    except Exception:
        return
    from IPython.display import clear_output
    try:
        clear_output  # NOQA
    except NameError:
        return

# Generated at 2022-06-24 10:18:21.016951
# Unit test for function tnrange
def test_tnrange():
    """
    Test if tnrange is working correctly with different arguments
    """
    try:
        from IPython.display import clear_output
    except ImportError:
        return


# Generated at 2022-06-24 10:18:28.499627
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    from IPython.html.widgets import FloatProgress, Widget
    assert isinstance(tqdm_notebook.status_printer(None, total=123), Widget)
    assert isinstance(tqdm_notebook.status_printer(None, total=0), Widget)
    assert isinstance(tqdm_notebook.status_printer(None), FloatProgress)
    assert not isinstance(tqdm_notebook.status_printer(sys.stdout), Widget)
    assert isinstance(tqdm_notebook.status_printer(StringIO()), Widget)
    assert isinstance(tqdm_notebook.status_printer(sys.stderr), Widget)

# Generated at 2022-06-24 10:18:38.328210
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tnrange
    from time import sleep

    # test is not disabled
    assert tnrange(0).disable is False

    # test decorator
    @tqdm_notebook
    def mygen():
        for i in range(3):
            yield i

    # testing bar format
    with tnrange(3, desc='Foo', leave=True, bar_format='{l_bar}{bar}{r_bar}',
                 ncols=100) as t:
        for i in t:
            sleep(0.1)

    # testing total=None
    with tnrange(desc='Bar', leave=True, ncols=100) as t:
        for i in t:
            sleep(0.1)
            if i > 2:
                break
    assert t.n == 3

   

# Generated at 2022-06-24 10:18:43.122998
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    from tqdm import tnrange
    a = tnrange(1, total=10, ncols=50)
    for i in a:
        pass
    a.reset(total=None)
    for j in a:
        assert (j == 1)
        break


# Generated at 2022-06-24 10:18:49.650579
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from _tqdm import TqdmTypeError
    from types import GeneratorType
    tqdm_notebook.clear = lambda *a, **k: None
    p = tqdm_notebook(range(10))
    assert isinstance(p, GeneratorType)
    assert p.n == 0
    try:
        p.display(False)
    except Exception as e:
        print(type(e), e)
        raise
    try:
        p.display(False, 1, 2, 3)
    except Exception as e:
        print(type(e), e)
        raise
    try:
        p.display(False, 2, 3)
    except Exception as e:
        print(type(e), e)
        raise

# Generated at 2022-06-24 10:18:53.710425
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .tests import test_tqdm_notebook_close as test_tqdm_close

    return test_tqdm_close(tqdm_notebook)

# Generated at 2022-06-24 10:19:00.135857
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    # pylint: disable=redefined-outer-name
    for leave in [True, False]:
        for total in [False, True]:
            bar = tqdm_notebook(total=1 if total else None, leave=leave)
            bar.update(1)
            bar.reset(total=2 if total else None)
            for i in bar:  # pylint: disable=unused-variable
                bar.update()
                time.sleep(.1)
            bar.close()
    # pylint: enable=redefined-outer-name
    return True


if __name__ == '__main__':
    __main__ = test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:19:05.372358
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from inspect import signature
    from random import seed
    seed = seed(42)  # Fix randomness
    with tqdm_notebook(total=10, desc=str(seed)) as pbar:
        for i in range(10):
            pbar.display(pos=i, close=i == 9)


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:19:08.922694
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=1) as n:  # instantiate
        n.close()
    with tqdm_notebook(total=1, leave=True) as n:
        n.close()

# Generated at 2022-06-24 10:19:11.798407
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(10)

# Generated at 2022-06-24 10:19:14.393292
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for n in tqdm_notebook(range(5), desc='unittest_clear', miniters=0):
        tqdm_notebook.clear()
    tqdm_notebook.clear()

# Generated at 2022-06-24 10:19:24.361607
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class DummyFile(object):
        """Dummy file-like object that will write to a string buffer."""

        def __init__(self):
            self.buf = ''

        def write(self, s):
            self.buf = self.buf + s

    class DummyPBar(object):
        """Dummy progress bar class with a dummy `value` property."""

        def __init__(self, min=0, max=10):
            self.min = min
            self.max = max
            self.value = min

        def layout(self):
            return type('layout', (), {'width': '500px'})()

    # Test the default output in the base case
    pbar = tqdm_notebook.status_printer(DummyFile())
    assert isinstance(pbar, TqdmHBox)

# Generated at 2022-06-24 10:19:26.304316
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    for _ in tqdm_notebook(range(0, 5)):
        time.sleep(1)


# Test for closing of class tqdm_notebook's constructor

# Generated at 2022-06-24 10:19:38.588956
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import BytesIO
    from io import StringIO
    from sys import platform
    from contextlib import redirect_stdout


# Generated at 2022-06-24 10:19:42.740004
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from itertools import chain
    from time import sleep

    for i in chain(*[[j] * 3 for j in range(10)]):
        sleep(0.1)  # so that we can see the progress bar
        tqdm.write(str(i))
        if i == 9:
            tqdm.clear()

# Generated at 2022-06-24 10:19:49.295631
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .std import tqdm as std_tqdm
    for __ in tqdm_notebook(list(range(10)), leave=False):
        pass

    # Test exception catching with manual tqdm
    total = 10
    for __ in tqdm_notebook(list(range(total)), leave=True, disable=False):
        for __ in std_tqdm(list(range(total)), leave=False):
            raise Exception()

if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:20:00.369077
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test total message
    if IPY:
        kwargs = tqdm_notebook.status_printer(total=100)
        i = kwargs[1]
        assert i.min == 0
        assert i.max == 100
    else:
        assert tqdm_notebook.status_printer(total=None) is None

    # Test desc message
    if IPY:
        kwargs = tqdm_notebook.status_printer(desc='foo')
        assert isinstance(kwargs[0], HTML)
        assert kwargs[0].value == 'foo'
    else:
        assert tqdm_notebook.status_printer(desc='foo') is None

    # Test ncols message
    if IPY:
        kwargs = tqdm_notebook.status_

# Generated at 2022-06-24 10:20:06.477431
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=5, file=sys.stdout)
    try:
        assert t.display(msg="success|<bar/>") == None
        assert t.display(msg="success|<bar/>", bar_style="info") == None
        assert t.display(msg="success") == None
        assert t.display(msg="success", bar_style="info") == None
    finally:
        # should not throw, see #872
        t.close()

# Generated at 2022-06-24 10:20:15.894277
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test case for method `tqdm_notebook.status_printer()`.
    """
    from .utils import _supports_unicode

# Generated at 2022-06-24 10:20:19.930577
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook

    """
    t = tqdm_notebook(total=3, unit='s')
    t.display(check_delay=False)
    t.display(close=True, check_delay=False)

# Generated at 2022-06-24 10:20:22.002251
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    pbar = tqdm()
    pbar.total = 5
    pbar.n = 1
    pbar.refresh()
    repr(pbar.container)



# Generated at 2022-06-24 10:20:30.589942
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:
        return

    p = tqdm_notebook.status_printer(None, total=100, desc="test", ncols=100)
    assert p.children[0].description == "test"
    (p.pbar.layout.width,) = p.layout.width.split("px")  # get width from string

    # Check width
    assert p.layout.width == "100%"
    assert p.pbar.layout.width == "100"
    p.pbar.layout.width = "30%"
    assert p.pbar.layout.width == "30"
    assert p.layout.width == "30px"
    p.pbar.layout.width = 100
    assert p.pbar.layout.width == "100"
    assert p.layout.width == "100px"

# Generated at 2022-06-24 10:20:38.589864
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook.
    """
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    tqdm_notebook(total=10)
    t = tqdm_notebook(total=10)
    t.update()
    t.close()
    tqdm_notebook(total=10, display=False)
    tqdm_notebook(total=10, leave=True)

    class Tests(unittest.TestCase):
        def test_tnrange(self):
            with tnrange(10) as t:
                for i in t:
                    pass

        def test_tnrange_iterable(self):
            for _ in tnrange([0, 1, 2]):
                pass


# Generated at 2022-06-24 10:20:41.466968
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import IPython.core.interactiveshell as ipshell

    with ipshell.TerminalInteractiveShell.instance() as shell:
        shell.enable_pylab(False)
        with tqdm_notebook(total=100) as t:
            t.update(90)


if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:20:51.330290
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm as _tqdm_gui
    from .utils import _get_child_updates, format_dict

    # Test basic construction of tqdm_notebook
    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            pbar.update()

    # Test tqdm_notebook with non integer value
    with tqdm_notebook(total=3.0) as pbar:
        for _ in range(3):
            pbar.update()

    # Test `async` mode in tqdm_notebook
    with tqdm_notebook(total=5) as pbar:
        pbar.update(2)

    # Test positional arguments in tqdm_notebook

# Generated at 2022-06-24 10:20:59.982460
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Iterate over [0, 1, 2]
    for _ in tqdm_notebook(range(3)):  # + all keyword paramaters
        pass
    # Iterate over ["a", "b", "c"]
    for _ in tqdm_notebook(list("abc")):
        pass  # pragma: no cover


if __name__ == "__main__":  # pragma: no cover
    from doctest import testmod
    testmod()

    n = 100
    for i, x in enumerate(tqdm_notebook(range(n), ascii=True)):
        if i % 2:
            tqdm_notebook.write("A")
        elif i % 3:
            tqdm_notebook.write("B")
        else:
            tqdm_notebook

# Generated at 2022-06-24 10:21:10.038130
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.testing.globalipapp import get_ipython
    ip = get_ipython()
    if ip is None:
        raise RuntimeError("IPython console has not been started!")

    total = 20
    desc = "<description>"
    s = tqdm_notebook.status_printer(ip.stdout, total=total, desc=desc)
    assert isinstance(s, TqdmHBox)
    children = (HTML(desc), IProgress(min=0, max=total), HTML())
    assert s.children == children
    assert str(s) == ""


# Main function for method status_printer of class tqdm_notebook
if __name__ == "__main__":
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:21:15.097887
# Unit test for function tnrange
def test_tnrange():
    import time
    from .utils import FormatCustomTextTest
    with FormatCustomTextTest(None) as fct:
        for _ in tnrange(10, desc='tnrange', miniters=2, mininterval=0.1,
                         smoothing=0):
            fct.update(_)
            time.sleep(0.01)



# Generated at 2022-06-24 10:21:22.028631
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test for reset method of class tqdm_notebook
    """

    # Test 1: total = None
    pbar = tqdm_notebook(total=20, desc="Test 1")
    total = pbar.total
    pbar.reset()
    assert pbar.n == 0
    assert pbar.total == total
    assert pbar.dynamic_ncols
    assert pbar.ncols is None
    assert pbar.max_width == 20

    # Test 2: total = 100
    pbar = tqdm_notebook(total=20, desc="Test 2")
    pbar.reset(total=100)
    assert pbar.total == 100
    assert not pbar.dynamic_ncols
    assert pbar.ncols == 100
    assert pbar.max_width

# Generated at 2022-06-24 10:21:33.114106
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from IPython.utils.py3compat import PY3
    import io

    # Initialise mock tqdm_notebook object
    obj = tqdm_notebook(range(0, 6), desc='Testing display()')
    obj_obj = obj.__dict__
    obj_obj['displayed'] = True
    obj_obj['container'] = {'children': [{'value': 'Testing display()'},
                                         {'value': 0, 'max': 5, 'bar_style': ''},
                                         {'value': ': : 5it/s'}]}

    # Redirect stdout for testing
    old_stdout = sys.stdout
    sys.stdout = io.StringIO() if PY3 else io.BytesIO()

    # Test display(msg=None)


# Generated at 2022-06-24 10:21:35.863068
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests.gui import tqdm_notebook_test_sequence, test_ipy
    assert test_ipy()
    for _ in tqdm_notebook_test_sequence():
        pass

# Generated at 2022-06-24 10:21:41.471278
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Unit test for `TqdmHBox` constructor.

    Returns
    -------
    None
        If everything is ok.
    """
    from sys import stdout
    assert TqdmHBox(children=[HTML(), FloatProgress(), HTML()])
    assert TqdmHBox(
        children=[HTML(), FloatProgress(min=0, max=1), HTML()]).pbar
    assert TqdmHBox(
        children=[HTML(), FloatProgress(min=0, max=1), HTML()]).pbar.format_dict
    assert TqdmHBox(
        children=[HTML(), FloatProgress(min=0, max=1), HTML()]).pbar.format_meter(
            bar_format='')

# Generated at 2022-06-24 10:21:50.456668
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.utils.tests.testformatters import _get_empty_globals

    from tqdm.notebook import tqdm_notebook
    from tqdm import tqdm

    with tqdm(_range(100)) as t:
        container = tqdm_notebook.status_printer(t.fp, total=100, desc="description")
        (ltext, pbar, rtext) = container.children
        assert pbar.min == 0
        assert pbar.max == 100
        assert ltext.value == 'description'
        assert rtext.value == tqdm.format_meter(0, 100, 0, 0)



# Generated at 2022-06-24 10:22:00.052860
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Unit test for method reset of class tqdm_notebook"""
    from .utils import FormatCustomTextTest

    with FormatCustomTextTest() as fct:
        for leave in [True, False]:
            for total in [None, 10, 5]:
                desc = 'DESC=%s' % total
                t = tqdm_notebook(total=total, leave=leave, desc=desc)
                for _ in t:
                    pass
                fct.assertIn(desc, t.__repr__(pretty=True))
                fct.assertRegex(t.__repr__(pretty=True), r"total=\d+")
                t.reset(total=10)
                fct.assertIn(desc, t.__repr__(pretty=True))

# Generated at 2022-06-24 10:22:10.478654
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.auto import tqdm
    for _ in tqdm(range(8), desc='test', leave=True,
                  bar_format="{l_bar}|{bar}|{n_fmt}"):
        sleep(0.25)
        if _ == 3:
            tqdm.write()

# Generated at 2022-06-24 10:22:17.299528
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tqdm_notebook(total=10)
    assert pbar._total == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].value == 0
    pbar.update(5)
    assert pbar._total == 10
    assert pbar.container.children[-2].max == 10
    assert pbar.container.children[-2].value == 5
    pbar.reset(total=15)
    assert pbar._total == 15
    assert pbar.container.children[-2].max == 15
    assert pbar.container.children[-2].value == 0



# Generated at 2022-06-24 10:22:18.278605
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    list(tqdm_notebook([])).should.equal([])

# Generated at 2022-06-24 10:22:24.419194
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # clear traceback if any
    import sys, traceback
    # sys.last_tb = None
    # sys.last_type, sys.last_value, sys.last_traceback = None, None, None
    try:
        from tqdm.notebook import tqdm_notebook
        for i in tqdm_notebook(range(5), desc='testing', leave=True):
            if i > 2:
                raise Exception
    except Exception:
        pass
    try:
        assert traceback.format_exc().count('testing')
        print('PASS')
    except AssertionError:
        print('FAIL')
        print(traceback.format_exc())


# Command-line execution
if __name__ == "__main__":
    test_tqdm_notebook___iter__()