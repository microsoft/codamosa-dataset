

# Generated at 2022-06-24 10:12:29.170847
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from IPython.core.display import clear_output
    from io import StringIO
    from tqdm import tnrange

    pbar = tnrange(100)
    for i in pbar:
        with StringIO() as buf, redirect_stdout(buf):
            pbar.close()
            pbar.close()  # second call should not be a problem
            assert '\r' not in buf.getvalue()  # no carriage return
        clear_output()
    pbar.close()
    clear_output()

if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:12:40.652728
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from pandas import DataFrame
    import pandas as pd
    from numpy.random import rand

    # without total
    b = tqdm_notebook(rand(10, 10))
    for i in b:
        pass

    # with total, no error
    for i in tqdm_notebook(rand(10)):
        pass

    # with total, with error
    a = rand(10)
    try:
        for i in tqdm_notebook(a):
            a.resize(10000)
    except ValueError:
        pass

    # test reset/clear
    t = 0

# Generated at 2022-06-24 10:12:51.546388
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test method status_printer of class tqdm_notebook.
    """
    from tqdm._tqdm_notebook import tqdm_notebook as tqdm
    progress = tqdm.status_printer(None, 100, 'Testing... ', 30)
    assert progress.layout.width == '30px'
    progress = tqdm.status_printer(None, 100, 'Testing... ', '100px')
    assert progress.layout.width == '100px'
    progress = tqdm.status_printer(None, 100, 'Testing... ', '100%')
    assert progress.layout.width == '100%'

if __name__ == '__main__':  # pragma: no cover
    from .main import _test_argv
    _test_argv('notebook')

# Generated at 2022-06-24 10:12:57.114407
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from .gui import tqdm
    container = tqdm(total=10)
    assert isinstance(container, TqdmHBox)

if __name__ == "__main__":  # pragma: no cover
    test_TqdmHBox()

# Generated at 2022-06-24 10:13:00.996459
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Only for coverage report.
    for method in (tqdm_notebook, tqdm, trange):
        with method(total=1) as pbar:
            pbar.clear()
            pbar.close()

# Generated at 2022-06-24 10:13:08.366336
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    from time import sleep

    for i in tqdm_notebook(range(2), "A"):
        for j in tqdm_notebook(range(5), "B", leave=False):
            sleep(0.01)
            tqdm_notebook.update()
        if i == 1:
            # if finish with error, the progressbar is not safely closed
            raise ValueError()
    # this line should not be printed at the end, but only the error
    print("END OF THE LOOP")


if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:13:15.513281
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import time
    import pickle
    try:
        from ipywidgets import AppLayout, FloatProgress, Layout, \
            HBox, VBox, Button, Label
    except ImportError:
        AppLayout = FloatProgress = Layout = HBox = VBox = Button = Label = None
    try:  # python 2
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None
    try:  # python 3
        from tqdm.autonotebook import tnrange
    except ImportError:
        tnrange = tqdm_notebook

    bar = tqdm_notebook(total=150)
    bar.n = 50
    bar.close()

   

# Generated at 2022-06-24 10:13:27.518777
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for method __iter__ of class tqdm_notebook"""
    import time
    import random

    with tqdm_notebook(total=10) as t:
        for i in range(10):
            time.sleep(0.5)
            t.update()
            assert i+1 == t.n
            assert 10 == t.total

    with tqdm_notebook(total=10, leave=True) as t:
        for i in range(10):
            time.sleep(0.5)
            t.update()
            assert i+1 == t.n
            assert 10 == t.total

    with tqdm_notebook(total=10) as t:
        for i in range(10):
            time.sleep(0.5)
            t.update()

# Generated at 2022-06-24 10:13:40.058698
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    box = TqdmHBox()
    box.pbar = object()
    assert repr(box) == '\r|      | 0.00? /s'  # with ASCII art

    # --- Pretty printing test ---
    box._repr_json_ = lambda _: {
        "n": 0,
        "total": 200,
        "desc": "desc",
        "unit": "units",
        "unit_scale": True,
        "bar_format": "{l_bar}<bar/>{r_bar}",
    }

    # Verify pretty printing with Python 2

# Generated at 2022-06-24 10:13:44.712434
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for function close of class tqdm_notebook
    """
    t = tqdm_notebook(total=10)
    for i in t:
        if i == 6:
            raise Exception
    t.close()
    # Should pass without errors

# Generated at 2022-06-24 10:13:50.763831
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    html = TqdmHBox(HBox(), IProgress(), HTML()).__repr__()
    assert not re.search('<bar/>', html)

# Generated at 2022-06-24 10:13:55.153977
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from io import StringIO
    from time import sleep
    buf = StringIO()
    for _ in tqdm(range(3), file=buf):
        sleep(0.1)
    print(buf.getvalue())
    assert("\n" not in buf.getvalue())

if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:14:02.853711
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from sys import version_info
    ipython_version = version_info < (3,)
    if ipython_version:
        from IPython.utils.traitlets import Dict
        from IPython.utils.py3compat import str_to_bytes
    else:
        from traitlets import Dict
        def str_to_bytes(s):
            if isinstance(s, bytes):
                return s
            return s.encode()
    pbar = TqdmHBox()
    pbar.pbar = Dict()

# Generated at 2022-06-24 10:14:16.119032
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test method `display` of the class `tqdm_notebook`."""
    try:
        ipywidgets
    except ImportError:
        return  # no need to test in this case
    # Create a new TqdmHBox
    c = tqdm_notebook.status_printer(file=None)

    # Test TqdmHBox repr
    repr(c)

    # Test TqdmHBox pretty repr
    c._repr_pretty_(None, None)

    # Test TqdmHBox close
    c.close()

    # Test update of TqdmHBox
    c.update(1)



# Generated at 2022-06-24 10:14:19.602949
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(5), desc='2nd loop'):
            break
    assert True



# Generated at 2022-06-24 10:14:26.598006
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test the behaviour of the method __iter__ of tqdm_notebook
    """
    # if global display is slow, we need to wait longer, or even
    # fail due to slow `display` (default delay=0.001s)
    # we make sure to not call `display` at all, so we test the
    # iteration
    t = tqdm_notebook(range(10), leave=True, delay=10)
    # make sure we test the __iter__ function
    res = []
    for i in t:
        res.append(i)
    assert res == list(range(10))
    # make sure tqdm_notebook didn't call display
    assert t.displayed is False

# Generated at 2022-06-24 10:14:35.509967
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from time import sleep
    from random import random

    # Note: A proper test would cover the total=N case of reset
    #       but it would require a big refactoring for testing
    #       the accumulated work in the true backend
    #       (probably exposing a _n attribute and testing it
    #        instead of just resetting)

    # Test simple reset
    t = trange(1)
    t.reset()
    t.reset()

    # Test reset with same total
    t = trange(3)
    t.reset(3)
    t.reset(3)

    # Test reset with different total
    t = trange(3)
    t.reset(4)
    with t.container.output_to(0, False):
        t.reset()
        t.reset()

   

# Generated at 2022-06-24 10:14:39.190335
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # generate a list of a lot of strings of the same length
    list_of_strings = ['gumby'] * 100
    # create a tqdm instance
    t = tqdm_notebook(list_of_strings)
    # call the method update
    t.update(50)
    # check if the value of the progressbar is 50
    assert(t.n == 50)

# Generated at 2022-06-24 10:14:48.824735
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """ Test method clear of class tqdm_notebook """
    # Test clear method of TqdmHBox class
    obj_tqdm_notebook = tqdm(total=2)
    for i in range(2):
        obj_tqdm_notebook.update()
        obj_tqdm_notebook.clear()
    obj_tqdm_notebook.close()
    del obj_tqdm_notebook


if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    for i in trange(4):
        for j in trange(100):
            sleep(0.01)
            if j == 50:
                tqdm.clear()  # reset progress bar so we can test close()
        tqdm.write("Hello world!")
    t

# Generated at 2022-06-24 10:14:54.637867
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    for i in tqdm_notebook(range(10),
                           desc="Testing IPython integration"):
        sleep(0.1)

# Generated at 2022-06-24 10:14:59.725077
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm as gtqdm
    try:
        from pip._vendor import pkg_resources  # https://github.com/pypa/pip/issues/1882#issuecomment-135127737
        pkg_resources.get_distribution('ipywidgets')
    except (ImportError, pkg_resources.DistributionNotFound):
        return None, None  # ipywidgets is not installed

    with gtqdm(leave=False, disable=True) as progress:
        assert progress == 0
        progress.update(1)
        assert progress == 1

# Generated at 2022-06-24 10:15:05.006892
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit tests for `tqdm.notebook.tqdm.display` method.
    """
    # Works with print()
    try:
        from contextlib import redirect_stdout
    except ImportError:  # Python 2
        if sys.version_info[0] < 3:
            import StringIO
            StringIO = StringIO.StringIO
            class redirect_stdout(object):
                """Redirect stdout to a stream or a file object."""
                def __init__(self, target):
                    self.target = target
                    self.old_stdout = sys.stdout
                def __enter__(self):
                    sys.stdout = self.target
                def __exit__(self, exc_type, exc_value, traceback):
                    sys.stdout = self.old_stdout


# Generated at 2022-06-24 10:15:15.036162
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO

    # Test simple text progress bar
    sio = StringIO()
    tqdm_notebook(["a", "b"], file=sio)
    sio.seek(0)
    assert "<progress style=\" width: 100%\" value=\"2\" max=\"2\"></progress>" in sio.read()

    # Test _repr_pretty_
    sio = StringIO()
    tqdm_notebook(["a", "b"], file=sio, ncols=200)
    sio.seek(0)
    pbar = sio.read()
    assert "|████████████████████| 100%|</progress></span>" in sio.read()

    # Test ncols=100%
    sio = StringIO()

# Generated at 2022-06-24 10:15:20.234583
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from contextlib import contextmanager
    from warnings import catch_warnings
    from tqdm.std import TqdmDeprecationWarning

    @contextmanager
    def catch_warnings_silence():
        with catch_warnings(record=True) as w:
            yield w
        warnings = [x for x in w
                    if issubclass(x.category, TqdmDeprecationWarning)]
        assert len(warnings) == 2, '\n{}'.format(warnings)

    with catch_warnings_silence():
        from tqdm.notebook import tqdm_notebook
        a = tqdm_notebook(total=10, desc='a', leave=False)
        # Test reset on a closed bar
        a.close()
        a.reset(total=20)
        assert a.n

# Generated at 2022-06-24 10:15:33.088006
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.autonotebook import tqdm
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()
            assert t.n == i + 1

# Mocking and checking
# from tqdm.utils import _term_move_up as clear_up
# from tqdm.utils import format_interval as format_interval_orig
# from tqdm.utils import format_meter as format_meter_orig
# from tqdm.utils import format_num as format_num_orig
# from tqdm.utils import format_sizeof as format_sizeof_orig
# from tqdm.utils import len_range as len_range_orig
# def format_interval(t):
#     return format_interval_orig(t, prefix='',

# Generated at 2022-06-24 10:15:34.741489
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    return tqdm_notebook.status_printer(None, 500, 'desc', None)

# Generated at 2022-06-24 10:15:42.358721
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        from unittest import mock
    except ImportError:
        import mock

    IProgress.reset = mock.MagicMock()
    TqdmHBox.pbar = mock.MagicMock()
    TqdmHBox.pbar.reset = mock.MagicMock()

    tqdm_notebook.reset()
    IProgress.reset.assert_called_once_with()
    TqdmHBox.pbar.reset.assert_called_once()

# Generated at 2022-06-24 10:15:43.277330
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for _ in tqdm_notebook(range(3), total=3):
        pass
    # All should pass without exception

# Generated at 2022-06-24 10:15:53.232874
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    for i in tqdm_notebook(range(10), desc='test'):
        time.sleep(0.1)
    for i in tqdm_notebook(range(10), desc='test', leave=True):
        time.sleep(0.1)
    for i in tqdm_notebook(range(10), desc='test', leave=True, disable=True):
        time.sleep(0.1)
    for i in tqdm_notebook(range(10), desc='test', leave=True, disable=False):
        time.sleep(0.1)
    pbar = tqdm_notebook(range(10))
    for i in pbar:
        pbar.set_description("test")
        time.sleep(0.1)

# Generated at 2022-06-24 10:16:02.986232
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from test_tqdm_notebook import dummy_tqdm_notebook as tqdm
    pbar = tqdm(range(10))
    pbar.n = 1
    pbar.total = 10
    pbar.last_print_n = 0
    pbar.last_print_t = None
    pbar.set_postfix({})
    pbar.set_description("Dummy")
    pbar.container.pbar = tqdm
    pbar.container.pbar.format_dict = pbar.format_dict
    pbar.container.pbar.format_meter = pbar.format_meter

# Generated at 2022-06-24 10:16:08.358177
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm_notebook
    tn = tqdm_notebook(total=4, leave=True)
    for _ in tn:
        tn.reset(total=10)
        break
    with tn:
        pass
    # tn.reset()  # uncomment to show the bar
    # NB: finally display the bar only once
    tn.close()

# Generated at 2022-06-24 10:16:12.751528
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    n = 100
    for i in tqdm_notebook(range(n)):
        if i == n//2:
            # Reset at middle of iteration
            i = tqdm_notebook.reset(n)
        else:
            i = tqdm_notebook.update(1)

# Generated at 2022-06-24 10:16:21.982949
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from sys import version_info
    from io import StringIO
    from contextlib import closing

    # Test raising and handling
    if version_info[0] >= 3:
        from builtins import range
    else:
        from __builtin__ import xrange as range  # NOQA

    with closing(StringIO()) as our_file:
        with tqdm_notebook(total=5, file=our_file) as pbar:
            pbar.update()
            e = None
            try:
                for i in range(5):
                    raise RuntimeError()
            except RuntimeError as e:
                pass

            try:
                pbar.update()
            except RuntimeError as e:
                pass

    assert e

    # Test disable

# Generated at 2022-06-24 10:16:29.756269
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from json import loads
    from sys import version_info
    from types import GeneratorType
    t = tqdm(total=4)
    assert isinstance(t, tqdm_notebook)
    assert t.container is not None
    if IPY == 3:
        # Test `_repr_json_` (pretty=False)
        d = loads(t.container._repr_json_())
        assert d == t.format_dict
        # Test `_repr_pretty_` (pretty=True)
        pretty = getattr(t.container, '_repr_pretty_', None)
        if pretty:
            pretty(None)

    # Test `_repr_` magic
    if version_info >= (3, 0):
        assert repr(t.container) == t.format_meter()

# Generated at 2022-06-24 10:16:36.607525
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Create a progress bar
    progress_bar = tqdm_notebook(total=10, desc="Test")
    # Create a container with this progress bar
    container = TqdmHBox(children=[
        HTML(),
        progress_bar.container.children[-2],
        HTML()
    ])
    container.pbar = proxy(progress_bar)
    # Check the pretty printing of the container
    assert repr(container) == progress_bar.format_meter()

# Generated at 2022-06-24 10:16:40.806241
# Unit test for function tnrange
def test_tnrange():
    "Test function tnrange"
    from time import sleep
    tot = 10
    with tnrange(tot) as t:
        for i in t:  # tnrange auto-initializes loop
            sleep(0.01)



# Generated at 2022-06-24 10:16:51.114174
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm_notebook(total=4, desc="Here we go!") as pbar:
        for i in range(4):
            sleep(0.5)
            pbar.update()

    # test with no total
    with tqdm_notebook(desc="Here we go!") as pbar:
        for i in range(4):
            sleep(0.5)
            pbar.update()

    # worker: test with no total
    with tqdm_notebook(desc="Here we go!", leave=False) as pbar:
        for i in range(4):
            sleep(0.5)
            pbar.update()

    # worker: close goes to end of loop

# Generated at 2022-06-24 10:17:02.894352
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    # check that close() works with auto-colonization
    try:
        from IPython.utils import io
    except ImportError:
        from IPython.core import io
    with io.capture_output() as captured:
        with tqdm(total=3) as pbar:
            display(pbar)
            pbar.update()
            pbar.close()  # should close display

    with patch("tqdm._tqdm_notebook.display") as mocked_display:
        with tqdm(total=3) as pbar:
            mocked_display.assert_not_called()
            display(pbar)
            mocked_display.assert_called()
            pbar.update()
            p

# Generated at 2022-06-24 10:17:10.045868
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest import mock
    except ImportError:  # python <= 2.6
        import mock

    with mock.patch('IPython.display.clear_output') as m:
        tqdm_notebook(desc='foo').clear()
    assert not m.called

    with mock.patch('IPython.display.clear_output') as m:
        tqdm_notebook(desc='foo').clear(nolock=True)
    assert m.called

# Generated at 2022-06-24 10:17:14.202518
# Unit test for function tnrange
def test_tnrange():
    """ Test tnrange """
    for _ in tnrange(10):
        pass
    # Test nested loop
    for _ in tnrange(3):
        for _ in tnrange(5):
            pass

if __name__ == '__main__':
    # Unit test
    test_tnrange()

# Generated at 2022-06-24 10:17:17.597779
# Unit test for function tnrange
def test_tnrange():
    import time

    with tnrange(10) as t:
        for i in t:
            t.set_description('%i of %i' % (i, 10))
            time.sleep(0.1)
    assert i == 9

# Generated at 2022-06-24 10:17:22.263080
# Unit test for function tnrange
def test_tnrange():
    """
    Test for function tnrange
    """
    list(tnrange(3, desc='test'))
    list(tnrange(3, desc='test', leave=True))
    list(tnrange(3, desc='test', leave=False))
    list(tnrange(3, desc='test', disable=False))
    list(tnrange(3, desc='test', disable=True))

# Generated at 2022-06-24 10:17:33.925297
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from sys import stderr
    from time import sleep
    import numpy as np
    from IPython.core.display import clear_output
    from IPython.core.magic import register_line_magic
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",
                                message="This display object.+support.+")
        from IPython.display import display
        from IPython.display import HTML
        from tqdm import trange
        from tqdm.notebook import HTML
        from tqdm.notebook import FloatProgress as IProgress
        from tqdm.notebook import HBox
    from tqdm.notebook import tqdm_notebook

    @register_line_magic
    def tnb(line):
        """IPython Magic:"""
        # use of `tq

# Generated at 2022-06-24 10:17:43.354677
# Unit test for method update of class tqdm_notebook

# Generated at 2022-06-24 10:17:51.748411
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test method __iter__ of class tqdm_notebook."""
    from .tests_tqdm import _TestTqdmNested, _TestTqdmNestedChild
    from .gui import tqdm
    from .std import tqdm as tqdm_std

    class _TestTqdmNotebookNested(_TestTqdmNested):
        """Test for nested tqdm on Jupyter notebook."""
        tqdm = tqdm_notebook

    class _TestTqdmNotebookNestedChild(_TestTqdmNestedChild):
        """Test for nested tqdm on Jupyter notebook."""
        tqdm = tqdm_notebook

    tqdm_notebook.close()
    _TestTqdmNested.__test__ = False
    _TestTq

# Generated at 2022-06-24 10:17:55.192536
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    from tqdm import tnrange

    for i in tnrange(10, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            for k in tnrange(100, desc='3nd loop'):
                pass



# Generated at 2022-06-24 10:18:06.013378
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        # call method clear of class tqdm_notebook
        pbar = tqdm_notebook(total=1, desc="test_tqdm_notebook_clear")
        pbar.clear()
        # need to use pbar.close() to force close the bar
        pbar.close()
    except:  # noqa
        raise

if __name__ == "__main__":
    # execute only if run as a script
    from time import sleep
    from .tests.gui import test_tqdm_notebook

    # test method clear of class tqdm_notebook
    test_tqdm_notebook_clear()
    # test update
    for i in tqdm_notebook(range(10), desc="1st loop"):
        sleep(0.01)

# Generated at 2022-06-24 10:18:08.551050
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=4) as pbar:
        for i in range(4):
            pbar.set_description("Processing %i" % (i + 1))
            sleep(0.5)
            pbar.update(1)

# Generated at 2022-06-24 10:18:14.540659
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .tests import tests
    from .gui import tqdm_gui
    import __main__

    # Initialize
    __main__.tqdm_gui = tqdm_gui
    total = 10
    tn = tqdm_notebook(total=total)

    pbar = tn.container.children[-2]  # avoid <bar/> in "<l_bar><bar/><r_bar>"
    l_bar = float(pbar.value)
    r_bar = float(pbar.max - l_bar)

    # Check initial bar state
    assert pbar.bar_style == 'info'
    assert (l_bar, r_bar) == (0., 10.)
    tests.kwargs(tn)

    # Check 2nd bar state
    val = 2.

# Generated at 2022-06-24 10:18:23.262436
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test method __iter__ of class tqdm_notebook.
    """
    # Instantiate tqdm_notebook
    with tqdm_notebook(total=2) as tqdm_notebook_object:
        assert isinstance(tqdm_notebook_object, tqdm_notebook)
        assert isinstance(tqdm_notebook_object.container, TqdmHBox)

        # Generic __iter__ (this tests `range()` internally)
        for _ in tqdm_notebook_object:
            assert tqdm_notebook_object.n == 1

        # Dynamic bar
        tqdm_notebook_object.reset()
        with tqdm_notebook(total=None) as t:
            assert t.total is None
            t.update()

        # Exception

# Generated at 2022-06-24 10:18:30.671561
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as t:
        assert not t.disable
        assert not t.displayed
        t.update(5)
        # test no loop
        t.update(5)
        t.clear()
        assert t.n == 5
        assert t.last_print_n == 5
        t.update(5)
        assert t.n == 10
        assert t.last_print_n == 10
        # test loop
        t.update(5)
        assert t.n == 15
        assert t.last_print_n == 15
        t.clear()
        assert t.n == 15
        assert t.last_print_n == 5
        t.close()


if __name__ == '__main__':
    from ._utils import _test_arg_and_kwargs

# Generated at 2022-06-24 10:18:40.408297
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.core.getipython import get_ipython
    ipython = get_ipython()
    if ipython is None:
        return
    ipython.magic('gui qt5')
    import time
    from .tqdm_gui import tqdm as tqdm_gui
    try:
        for _ in tqdm_notebook(range(5), desc='1st loop', leave=False):
            for _ in tqdm_notebook(range(5), desc='2nd loop', leave=False):
                for _ in tqdm_gui(range(5), desc='3rd loop', leave=False):
                    time.sleep(.01)
    except KeyboardInterrupt:
        pass
    assert tqdm_notebook.gui == tqdm_gui.gui

# Generated at 2022-06-24 10:18:49.155523
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:
        return
    try:
        tn = tqdm_notebook.status_printer(None, total=100, desc='test')
    except TypeError:
        tn = tqdm_notebook.status_printer(total=100, desc='test')
    _, pbar, _ = tn.children
    assert pbar.max == 100
    assert pbar.value != 100
    assert pbar.bar_style == ''
    assert pbar.bar_style != 'info'
    assert tn.layout.width == '100%'
    # HBox length = 1+flex+1
    assert len(tn.children) == 3
    tn.close()
    # Try with total=None

# Generated at 2022-06-24 10:18:58.980567
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import IPython

    # check if IPython is running
    if IPython.get_ipython() is None:
        # IPython not running, simulate a IPython frontend
        class IPython:
            class display:
                def display(x):
                    # handle class TqdmHBox
                    if isinstance(x, TqdmHBox):
                        return x.__repr__()
                    # handle all other cases
                    else:
                        return x
    else:
        # IPython is running, use standard display
        IPython.display.display = IPython.display.display

    # test case 1
    class TestTqdmHBox(TqdmHBox):
        def __init__(self):
            self.pbar = None
    hb = TestTqdmHBox()
    assert hb.__repr__

# Generated at 2022-06-24 10:19:08.838652
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    # display widget container
    tn = tqdm_notebook(total=20, mininterval=0.1, leave=True)
    tn.reset(total=5)
    for i in tn:
        pass
    assert tn.total == 5
    assert tn.bar_format == '{l_bar}<bar/>{n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'
    ltext, pbar, rtext = tn.container.children
    assert pbar.value == tn.n
    assert ltext.value == tn.desc
    assert tn.colour == '#31a354'
    assert tn.displayed == True
    tn.reset(total=0)

# Generated at 2022-06-24 10:19:12.374670
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10) as bar:
        bar.reset(total=3)
        assert bar.total == 3
        bar.reset(total=100)
        assert bar.total == 100
        bar.reset(total=None)
        assert bar.total is None

# Generated at 2022-06-24 10:19:18.057279
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as pbar:
        assert pbar.clear() is None
        pbar.update()
        pbar.clear()  # does not raise an error when tqdm is in progress
        pbar.update()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:19:21.538006
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    from time import sleep
    with tqdm_notebook(total=9) as pbar:
        for i in range(10):
            assert pbar.update() is None
            sleep(0.1)



# Generated at 2022-06-24 10:19:23.664731
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=10) as bar:
        for i in bar:
            pass


# Generated at 2022-06-24 10:19:33.660401
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import StringIO
    from .std import sys, tqdm
    for tb in ['ascii', 'utf', 'unicode']:
        original_stdout = sys.stdout
        sys.stdout = StringIO()
        t = tqdm(total=1, ncols=0, file=sys.stdout)
        t.close()
        assert hasattr(t, 'n')
        assert t.n == 1
        assert hasattr(t, 'container')
        assert hasattr(t, 'container')
        assert not t.container.visible
        assert '\r' not in sys.stdout.getvalue()
        sys.stdout = original_stdout

# Generated at 2022-06-24 10:19:36.246467
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm(total=1, desc='Testing clear()') as progress:
        progress.clear()
        progress.update()



# Generated at 2022-06-24 10:19:46.980007
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase

    class TqdmTest(TestCase):
        def test_display(self):
            # tests return values on errors
            self.assertRaises(TypeError, tqdm(total=-1), "Hello")
            self.assertRaises(TypeError, tqdm(total="Hello"), "Hello")
            self.assertRaises(TypeError, tqdm(total=1, miniters=-1), "Hello")
            self.assertRaises(TypeError, tqdm(total=1, miniters="Hello"), "Hello")
            self.assertRaises(TypeError, tqdm(total=1, ascii="Hello"), "Hello")
            self.assertRaises(ValueError, tqdm(total=1, mininterval="Hello"), "Hello")
            self.assertRaises

# Generated at 2022-06-24 10:19:48.716920
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    out = tqdm_notebook(desc="test", total=1)
    assert out.format_dict["desc"] == "test"

# Generated at 2022-06-24 10:19:51.188499
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import tqdm

    for _ in tqdm(range(10), desc='test_tqdm_notebook_update', leave=True):
        pass



# Generated at 2022-06-24 10:19:57.375596
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time

# Generated at 2022-06-24 10:20:07.456435
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Run `python -m tqdm.notebook --test`"""
    from inspect import isclass
    from sys import argv
    # Default bar
    t = tqdm_notebook()
    t.close()

    # No bar
    t = tqdm_notebook(disable=True)
    t.close()

    # Progress bar
    with tqdm_notebook(total=10, desc='Loading...') as t:
        for i in range(10):
            t.update()

    # No output
    with tqdm_notebook(total=10, desc='Loading...', disable=True) as t:
        for i in range(10):
            t.update()

    # Manual bar
    t = tqdm_notebook(total=10, desc='Loading...')

# Generated at 2022-06-24 10:20:16.729739
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tnrange.
    """
    # standard usage
    list(tqdm(range(10), desc="test_tqdm"))

    # disable
    list(tqdm(range(10), desc="test_tqdm", disable=True))

    # dynamically disable
    list(tqdm(range(10), desc="test_tqdm", disable=lambda: True))
    list(tqdm(range(10), desc="test_tqdm", disable=lambda: False))
    state, i = [False, 0]

    def disabler():
        nonlocal state, i
        # disable for the first three iterations
        state = i <= 2
        i += 1
        return state


# Generated at 2022-06-24 10:20:25.870298
# Unit test for function tnrange
def test_tnrange():
    from random import shuffle, seed
    from .utils import FormatCustomTextTest, DiscreteMeterTest

    for N in [1, 20, 50]:
        test = tnrange(N, leave=True)
        for i in test:
            pass
        FormatCustomTextTest(test)  # test custom formatting
        DiscreteMeterTest(test)  # test meter border cases

        test = tnrange(N, leave=True)
        shuffle(test)
        test.n = None
        test.close()
        FormatCustomTextTest(test)  # test custom formatting
        DiscreteMeterTest(test)  # test meter border cases

        with test:
            shuffle(test)
            test.n = None
        FormatCustomTextTest(test)  # test custom formatting
        DiscreteMeterTest(test)  # test meter border

# Generated at 2022-06-24 10:20:33.982158
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from IPython.display import clear_output
        from IPython import get_ipython
    except ImportError:
        return  # tqdm_notebook not available

    ipy = get_ipython()
    if ipy is None:
        return  # Not running in IPython

    from datetime import timedelta
    from time import sleep

    t = tqdm_notebook(
        total=2, desc='Foo', miniters=1, dynamic_ncols=True, smoothing=0)

# Generated at 2022-06-24 10:20:37.118170
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test that checks that tnrange() ends properly.
    """
    for n in tnrange(2, 3):
        assert n in (2, 3)



# Generated at 2022-06-24 10:20:45.151090
# Unit test for function tnrange
def test_tnrange():
    "Tests function tnrange"
    with tnrange(4, leave=True) as t:
        for i in t:
            pass
    # Test total
    with tnrange(4) as t:
        for i in t:
            pass
    with tnrange(0, 4) as t:
        for i in t:
            t.set_description('{i}/{total}'.format(i=i, total=t.total))
            t.update()
        t.set_description('{i}/{total}'.format(i=4, total=4))
    assert t.total == 4
    # Test N/total

# Generated at 2022-06-24 10:20:49.222391
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test to ensure `tqdm.notebook.tqdm` can be closed externally."""
    tq = tqdm_notebook(total=100, leave=False)
    tq.update(10)
    # close() is called by the garbage collector
    del tq



# Generated at 2022-06-24 10:20:57.724804
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    def check_pbar_repr(widget, expected):
        if IPY == 32:
            return repr(widget) == repr(expected)
        else:
            return repr(widget).startswith(expected)

    with std_tqdm(total=10) as pbar:
        pbar.n = 5
        assert check_pbar_repr(TqdmHBox(pbar=proxy(pbar)), '   10%|')
        assert TqdmHBox(pbar=proxy(pbar)).__repr__(True) == '   10%|'
    assert TqdmHBox(pbar=None).__repr__(True) == '{desc}'

test_TqdmHBox()

# Generated at 2022-06-24 10:21:07.926470
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tgrange
    from .utils import format_sizeof
    from .utils import format_interval
    from .std import tqdm as std_tqdm
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = None

    if IProgress is None:
        return None

    with std_tqdm(total=10, desc='std') as t:
        with std_tqdm(total=10, desc='nb') as t2:
            for i in tgrange(2):
                t.update(1)
                t2.update(1)
                if clear_output:
                    clear_output()
    with tnrange(total=10, desc='nb') as t2:
        for i in tgrange(2):
            t2

# Generated at 2022-06-24 10:21:13.757406
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=9, leave=True) as pbar:
        assert len(pbar) == 9
        pbar.reset(total=10)
        assert len(pbar) == 10
        pbar.update(1)
        assert len(pbar) == 10
        assert pbar.n == 1
        assert pbar.total == 10

# Generated at 2022-06-24 10:21:24.325982
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal
    from copy import copy
    import gc

    # test bar initialization
    no_total = tqdm_notebook()
    assert_equal(no_total.container.pbar.max, 1)
    assert_equal(no_total.container.pbar.value, 0)
    assert_equal(no_total.container.children[0].value, '')
    assert_equal(no_total.container.children[2].value, '')

    # test automagic display
    pbar = tqdm_notebook(range(2))
    assert_equal(pbar.container.style.description_width, 'initial')
    assert_equal(pbar.container.children[0].value, '')
    assert_equal(pbar.container.children[2].value, '')


# Generated at 2022-06-24 10:21:34.872464
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .gui import tqdm_gui
    from .std import tqdm
    from .utils import _supports_unicode
    from .utils import _environ_cols_wrapper

    for cls, is_gui in ((tqdm, False), (tqdm_notebook, True), (tqdm_gui, True)):
        total = 0.0

        # Test with int
        stdout = sys.stdout

# Generated at 2022-06-24 10:21:41.531870
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    with tqdm_notebook(total=1) as t:
        assert t.displayed
        sleep(0.05)
    assert not t.displayed

    with tqdm_notebook(total=1) as t:
        assert t.displayed
        sleep(0.05)
        t.display(close=True)
    assert not t.displayed

    with tqdm_notebook(total=1) as t:
        sleep(0.05)
        t.display(close=True)
    assert not t.displayed

    with tqdm_notebook(total=1) as t:
        t.display(close=True)
    assert not t.displayed  # display() hide the bar


# Generated at 2022-06-24 10:21:43.826695
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for leave in (False, True):
        ht = tqdm_notebook(["a", "b", "c"], leave=leave)
        ht.clear()

# Generated at 2022-06-24 10:21:50.065607
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    Clear tqdm_notebook bar and hide it
    """
    with tqdm_notebook(total=10) as t:
        for _ in range(5):
            t.clear()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_clear()  # unit test

# Generated at 2022-06-24 10:21:54.500335
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=1) as t:
        t.update(1)
        t.close()
    with tqdm_notebook(total=1) as t:
        t.update(0.5)
        t.close()
        t.close()



# Generated at 2022-06-24 10:21:58.243758
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    total = 5
    try:
        for _ in tqdm_notebook(range(total), desc='1st loop'):
            sleep(.1)
    except KeyboardInterrupt:
        # works when never displayed
        pass



# Generated at 2022-06-24 10:22:08.336727
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tqdm_gui
    from time import sleep

    # Test 1: CLI
    for _ in tqdm_gui(range(3), desc='1st loop'):
        for _ in tqdm_gui(range(4), desc='2nd loop', leave=True):
            for _ in tqdm_gui(range(5), desc='3nd loop', leave=True):
                sleep(0.01)
    # Test 2: Colours
    for _ in tqdm_gui(range(3), desc='1st loop', bar_format='{l_bar} {bar}',
                      bar_format_dict={'l_bar': '{desc}:',
                                       'r_bar': ' {percentage:3.0f}%|'}):
        tqdm_gui.colour = "blue"

# Generated at 2022-06-24 10:22:16.965086
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    from random import random, randint

    with tqdm_notebook(total=100, desc='A Loop', leave=False) as t:
        for i in range(100):
            # Update bar with simulated info
            t.n = i
            t.last_print_n = i - 1
            t._desc = 'A Loop'
            t.update_to(i + 1)
            t.display()
            if randint(0, 10) == 0:
                # random clears
                t.display(clear=True)
            if randint(0, 10) == 0:
                # random close
                clear_output(wait=True)
                break


# Generated at 2022-06-24 10:22:24.207984
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Setup default output
    # Initialize parent class + avoid printing by using gui=True
    tn = tqdm_notebook(gui=True)

    # pbar = tn.status_printer(sys.stderr)
    assert hasattr(tn, 'container')
    assert hasattr(tn.container, 'children')
    assert hasattr(tn.container.children[1], 'bar_style')
    assert hasattr(tn.container.children[1], 'style')
    assert hasattr(tn.container.children[1].style, 'bar_color')


if __name__ == '__main__':
    from .tests import test_tqdm

    test_tqdm_notebook_status_printer()
    test_tqdm(tqdm, tqdm_notebook, trange)