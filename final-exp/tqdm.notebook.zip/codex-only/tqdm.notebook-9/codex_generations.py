

# Generated at 2022-06-24 10:12:32.945533
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    assert hbox.__repr__() == ''
    hbox.pbar = 0
    assert hbox.__repr__() == ''
    hbox.pbar = 1
    assert hbox.__repr__() == ''
    hbox.pbar = tqdm_notebook(total=10)
    assert hbox.__repr__() == '[                                        ]   0%|          | 0/10 [00:00<?, ?it/s]'
    assert hbox._repr_pretty_() == None
    hbox.pbar.n = 5
    assert hbox.__repr__() == '[######################               ]  50%|######### | 5/10 [00:00<?, ?it/s]'
    hbox.pbar.n = 10
   

# Generated at 2022-06-24 10:12:41.277826
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import mock
    import IPython.display
    t = tqdm_notebook(total=100)
    assert hasattr(t, 'displayed')
    assert hasattr(t, 'display')
    assert t.displayed
    with mock.patch.object(IPython.display, 'display') as m:
        assert t.displayed
        t.reset()
        assert not t.displayed
        assert t.n == 0
        m.assert_not_called()
        t.reset(total=5, display=True)
        assert t.displayed
        m.assert_called_once_with(t.container)
        assert t.total == 5
        t.reset(total=10, display=False)
        assert not t.displayed
        m.assert_called_once_with(t.container)
       

# Generated at 2022-06-24 10:12:44.959546
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        with tqdm(total=1) as bar:
            bar.update()
        assert True, "IPython/Jupyter Notebook widget update method works"
    except:  # NOQA
        assert False, "IPython/Jupyter Notebook widget update method failed"

# Generated at 2022-06-24 10:12:56.779976
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class StatusPrinterClass(tqdm_notebook):
        # override the tqdm class method
        @staticmethod
        def status_printer(_, total=None, desc=None, ncols=None):
            return super(StatusPrinterClass,
                         StatusPrinterClass).status_printer(
                             _, total, desc, ncols)
    spc = StatusPrinterClass()

    # Raise error
    try:
        spc.status_printer(None, None, None, None)
        assert False
    except ImportError:
        assert True

    # Test default
    # display(spc.status_printer(None, None, None, None))
    ipy = IPY

# Generated at 2022-06-24 10:13:00.285342
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    return tqdm_notebook(['a']).display()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:13:09.939174
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Skip test if IPython / Jupyter is not installed
    if IPY == 0:
        raise SkipTest("IPython / Jupyter is not installed")

    from IPython.core.getipython import get_ipython
    from unittest import TestCase
    from time import sleep

    # test
    with TestCase():
        # manual tqdm
        with tqdm_notebook(total=10) as pbar:
            for i in range(10):
                assert pbar.n == i
                sleep(0.1)
                pbar.update()

        # iterable tqdm
        with tqdm_notebook(range(10)) as pbar:
            for i in pbar:
                assert pbar.n == i
                sleep(0.1)

        # iterable tqdm


# Generated at 2022-06-24 10:13:17.361133
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from ipywidgets import IntSlider

    class MyTqdmClass(tqdm_notebook):
        def __init__(self):
            super(MyTqdmClass, self).__init__()
            self.displayed = False
        def display(self, *_, **__):
            self.displayed = True

    class ConvertedSlider(MyTqdmClass):
        def __init__(self, min, max, value):
            self.min = min
            self.max = max
            self.value = value
            super(ConvertedSlider, self).__init__()
            self.bar_format = "Slider: {n}{bar}{r_bar}"

        def update(self, *_, **__):
            self.value += 1

    # test display in the right

# Generated at 2022-06-24 10:13:28.121836
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    if not IPY:
        raise unittest.SkipTest("IPython not found. Skipping tests.")
    from IPython.display import HTML, display
    h = TqdmHBox()
    h.pbar = tqdm_notebook(total=4)
    assert repr(h) == ''  # no status printed
    # update bar 3 times
    for _ in range(3):
        h.pbar.update()
    assert '   3/4' in repr(h)
    assert 'elapsed' in repr(h)
    # check no exception
    display(h)
    assert h._repr_pretty_ is not None


if __name__ == '__main__':
    unittest.main()

# Generated at 2022-06-24 10:13:40.486847
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from random import Random
    from random import shuffle
    from random import choices

    import sys

    class FakeStdout(object):
        writelines = sys.stdout.writelines

        def isatty(self):
            return getattr(self, '_isatty', False)

    TEST_COUNT = 100
    SEED = 224624
    rng = Random(SEED)
    bar_options = (3, 10, rng.randint(30, 120))

    def _test_TqdmHBox___repr__(bar_options):
        # Arrange
        ncols = bar_options
        pbar = IProgress(min=0, max=100)
        pbar.layout.width = f"{ncols}px"
        ltext = HTML()
        rtext = HTML()
       

# Generated at 2022-06-24 10:13:52.348721
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Run examples in docstrings and verify against doctests.
    """
    from copy import copy
    from pprint import pprint
    from doctest import testmod

    if IPY >= 4:  # pragma: no cover
        from ipywidgets import Textarea

        textarea = Textarea()
    else:
        from IPython.html.widgets import Textarea

        textarea = Textarea()

    with open(__file__, 'rb') as fread:
        txt = fread.read().decode('utf-8')
    textarea.value = txt  # txt = textarea.value # to check

    fmt_dict = copy(tqdm_notebook.format_dict)

# Generated at 2022-06-24 10:13:55.485356
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm_notebook
    from time import sleep

    for i in tqdm_notebook(list(range(3))):
        sleep(.1)


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:14:01.939302
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test for tqdm_notebook close with wrong total"""
    from tqdm.std import tqdm
    from tqdm.notebook import tqdm_notebook
    import logging

    def test_logrep(name, obj, skip=()):
        """Return logger.debug report of object attributes"""
        # skip: (tuples of) strings
        if type(skip) is str:
            skip = [skip]
        return (name + " has " +
                str(len(obj.__dict__) - len(skip)) + " attributes: " +
                ', '.join(obj.__dict__.keys() - skip))

    # create some test bars
    tn = tqdm_notebook(total=42)
    txt = tqdm(total=42)

    # check for class differences

# Generated at 2022-06-24 10:14:03.795089
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        t.update(1)
        t.clear()
        t.update(1)



# Generated at 2022-06-24 10:14:16.151251
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import _supports_unicode, format_sizeof
    from .std import tqdm as tqdm_std

    # Test tqdm_notebook
    # Test with unicode (py2)
    with tqdm_notebook(desc="notebook", total=10, ascii=_supports_unicode()) as t:
        assert t.n == 0
        for i, char in enumerate(t):
            assert t.n == i + 1
            assert t.last_print_n == i + 1
            assert t.last_print_t == t.format_interval(i + 1)
            assert t.last_print_t_noformat == t.format_interval(i + 1, False)
            assert t.format_dict['n'] == i + 1
            assert t.format

# Generated at 2022-06-24 10:14:20.708610
# Unit test for function tnrange
def test_tnrange():
    """
    Simple smoke test
    """
    # check that no exception is thrown
    for _ in tnrange(100):
        pass
    # is the progressbar range correct ?
    pbar = tnrange(5, 5)
    assert next(pbar) == 5
    assert next(pbar) is StopIteration


# Generated at 2022-06-24 10:14:31.370020
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from tqdm.utils import _term_move_up
    # import sys
    # sys.stderr = open('/dev/null', 'w')
    out = tqdm_notebook.status_printer(file=None)
    close, bar_style, check_delay = 'test', 'test', 'test'  # dummy values
    out.display(msg='test', bar_style=bar_style, check_delay=check_delay)
    # No return: just check it doesn't crash
    assert True


# At the bottom to avoid circular dependencies
# (`from tqdm import tqdm` recurses)
from .autonotebook import tqdm as tqdm_autonotebook  # NOQA: F811
tqdm_gui = tqdm_note

# Generated at 2022-06-24 10:14:37.951333
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit tests for tqdm_notebook.reset().
    """
    from tqdm.auto import trange
    from time import sleep
    for total in [10, None]:
        for leave in [True, False]:
            for i in trange(total, leave=leave):
                sleep(0.01)
            trange(total, leave=leave).reset(total=total)

# Generated at 2022-06-24 10:14:40.476626
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in [True, False]:
        bar = tqdm_notebook()
        bar.displayed = True  # Hack to avoid clearing output immediately
        assert bar.leave == leave
        bar.close()



# Generated at 2022-06-24 10:14:49.757975
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from os import devnull
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('sys.stderr', devnull):  # avoid `[I send SIGPIPE when trying to print...]`
        with patch('IPython.display.display'):
            with tqdm_notebook(total=10) as t:
                for i in range(11):
                    t.update()
                    if i == 5:
                        # test exception
                        raise RuntimeError("test")
                t.close()
            tqdm_notebook(total=5).close()
        with tqdm_notebook(total=5, leave=True) as t:
            t.close()

# Generated at 2022-06-24 10:14:55.123334
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from IPython.display import clear_output
    total = 6
    with tqdm_notebook(total=total) as t:
        for i in range(total):
            t.update()
            time.sleep(0.01)
            clear_output(wait=True)
    for i in tqdm_notebook(range(total)):
        time.sleep(0.01)
        clear_output(wait=True)
        # raise exception
        if i == 3:
            raise ValueError("test_tqdm_notebook_update")
    #raise ValueError("test_tqdm_notebook_update")
    # never reach this point if exception is raised above

# Generated at 2022-06-24 10:14:57.286583
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tnrange(2, **{'unit': 'foo'})
    t.reset(total=10)
    t.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:15:09.315400
# Unit test for function tnrange
def test_tnrange():
    """Unittest for function `tnrange`"""
    from IPython.display import clear_output
    from time import sleep
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        clear_output()
    clear_output()
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
            clear_output()
    clear_output()


if __name__ == '__main__':  # pragma: no cover
    test_tnrange()

# Generated at 2022-06-24 10:15:18.918359
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tgrange
    from .utils import format_sizeof
    from random import randint
    import time
    try:
        from IPython.core.display import clear_output
        clear_output(wait=True)
    except ImportError:
        pass
    for _ in tgrange(15, desc='clearing'):
        t = tqdm_notebook(
            format='{n_fmt}/{total_fmt} [{elapsed}<{remaining}, '
            '{rate_fmt}{postfix}]'
        )
        for _ in t:
            data = bytearray(randint(0, 255) for _ in range(randint(10, 10000)))

# Generated at 2022-06-24 10:15:31.651415
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import trange
    from unittest import TestCase
    if IPY == 0:
        raise TestCase.skipTest("IPython is not found")

    class TestTqdmNotebookDisplay(TestCase):
        def setUp(self):
            self.t = trange(1, 2)
            self.pbar = self.t.container.children[-2]
            self.ltext = self.t.container.children[0]
            self.rtext = self.t.container.children[-1]
            self.pbar.bar_style = ''
            self.display_msg = ""
            self.t.disp = self.display

        def display(self, msg=None, pos=None, **_):
            if msg is not None:
                self.display_msg = msg



# Generated at 2022-06-24 10:15:43.231578
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test the display method of class tqdm_notebook
    """
    from unittest import TestCase
    from tempfile import NamedTemporaryFile

    class TestTqdmNotebookDisplay(TestCase):
        def test_display(self):
            """
            Test the display method for the class tqdm_notebook
            """
            # Init progress bar
            progress = tqdm_notebook(total=9, desc='test', leave=False)

            # Test display for info style bar
            progress.display(msg="test_info", bar_style='info')
            self.assertEqual(
                progress.container.children[-2].bar_style, 'info')

            # Test display for success style bar
            progress.display(msg="test_success", bar_style='success')

# Generated at 2022-06-24 10:15:51.357831
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from pytest import raises
    from copy import copy
    tqdm.update(0)
    with raises(AttributeError):
        repr(tqdm.container)
    with raises(AttributeError):
        TqdmHBox()._repr_json_(True)
    # need to deepcopy to avoid sharing references
    d = copy(tqdm._instances[0].format_dict)
    d["bar_format"] = "{postfix}"
    tqdm._instances[0].format_dict = d
    assert repr(tqdm.container) == "{postfix}"
    tqdm.container.close()

# Generated at 2022-06-24 10:16:02.196870
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """
    from .gui import tqdm
    from .utils import format_sizeof
    from .std import format_interval
    from .std import format_meter
    from .utils import bytes

    from time import sleep

    # Initialization
    t = tqdm(total=None)  # no bar
    t = tqdm(total=None, desc="Display here")  # no bar, but with desc

    # Update with value
    t.update()
    assert t.n == 1
    t.update(9)
    assert t.n == 10
    t.update(10)
    assert t.n == 20
    t.update(1)
    assert t.n == 21

    # Update with iterable

# Generated at 2022-06-24 10:16:05.344743
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=1) as pbar:
        pbar.start()
        pbar.n = 0  # this should not change pbar.max
        pbar.update(1)

# Generated at 2022-06-24 10:16:15.656046
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython import display
    from IPython.display import HTML
    # Clear previous output (really necessary?)
    # clear_output(wait=1)
    # check close display
    pbar = tqdm_notebook()
    pbar.display(close=True, check_delay=False)
    if hasattr(pbar.container, 'close'):
        pbar.container.close()
    if hasattr(pbar.container, 'visible'):
        pbar.container.visible = False
    pbar.display(close=False, check_delay=False)
    if hasattr(pbar.container, 'close'):
        pbar.container.close()
    if hasattr(pbar.container, 'visible'):
        pbar.container.visible = False
    # check display
    pbar = tqdm

# Generated at 2022-06-24 10:16:21.117663
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """
    t = tqdm_notebook(total=10)
    t.update(10)
    msg = '\r{0}'.format(t.format_dict)
    assert msg == '\r{0}/10'.format(t.format_dict)
    t.close()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:16:29.630291
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from unittest.mock import patch, Mock
    from io import StringIO
    with patch('sys.stderr', new_callable=StringIO) as mock_stderr:
        tqdm_notebook(0, ncols=10, file=mock_stderr).close()
        tqdm_notebook(0, ncols=10, file=mock_stderr, leave=True).close()

        with patch('tqdm.notebook.display', Mock()):
            t = tqdm_notebook(2)
            t.close()
            assert not t.displayed
            t = tqdm_notebook(2, leave=True)
            t.close()
            assert not t.displayed

            t = tqdm_notebook(0)
            t.close()

# Generated at 2022-06-24 10:16:39.552924
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # status_printer should return a IProgress instance with
    # a children attribute containing a ltext, a bar and a rtext instances
    status = tqdm_notebook.status_printer(
        file=None, total=100, desc="My desc", ncols=50)
    assert isinstance(status, HBox)
    assert hasattr(status, 'children')
    assert len(status.children) == 3
    assert isinstance(status.children[0], HTML)
    assert isinstance(status.children[1], IProgress)
    assert isinstance(status.children[2], HTML)
    # status_printer should return a IProgress instance with
    # a children attribute containing a bar instance
    # if total is falsy

# Generated at 2022-06-24 10:16:42.324343
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    with tnrange(10) as t:
        for i in t:
            sleep(.1)



# Generated at 2022-06-24 10:16:52.942302
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # here we manually create tqdm_notebook, since this is the one we want to test
    t = tqdm_notebook(
        iterable=range(100),
        desc='test', leave=False, file=sys.stdout, disable=False,
        miniters=1, mininterval=0.1, maxinterval=1.0,
        min_iters_delay=0, dynamic_ncols=False)

    # the display method of tqdm_notebook is called inside TqdmBase,
    # but in this case we want to test only the tqdm_notebook's update
    # method and not base's, so we overwrite display with a fake one.
    def fake_display(_): pass
    t._instant_display = t.display
    t.display = fake_display

    #

# Generated at 2022-06-24 10:17:02.389020
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    from tqdm import tqdm_notebook
    from IPython.core.getipython import get_ipython

    ip = get_ipython()
    if ip is None or ip.__class__.__name__ not in ['ZMQInteractiveShell',
                                                  'TerminalInteractiveShell']:
        return
    try:
        ip.magic("config InlineBackend.figure_formats = ['svg']")
        with tqdm_notebook(total=100) as pbar:
            for i in range(10):
                pbar.update(10)
                time.sleep(.1)
    except Exception:
        return
    return True

# Generated at 2022-06-24 10:17:13.535479
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

    # Create tqdm_notebook object
    a = tqdm_notebook(desc="Test", total=1000, leave=False)
    a.displayed = False

    # print empty bar before starting the iteration
    a.display()
    assert a.displayed
    a.close()

    # print start bar
    a = tqdm_notebook(desc="Test", total=1000, leave=False)
    a.displayed = False
    a.display(check_delay=False)
    assert a.displayed
    a.close()

    # change bar style
    a = tqdm_notebook(desc="Test", total=1000, leave=False)
    a.displayed = False
    a.display(bar_style='warning', check_delay=False)
    assert a.container

# Generated at 2022-06-24 10:17:22.706261
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import display
    from IPython.display import clear_output
    try:  # Py2
        from cStringIO import StringIO as BytesIO
    except ImportError:  # Py3
        from io import BytesIO as BytesIO
    # Test setup
    io = BytesIO()
    io.name = '<stdout>'
    io.isatty = lambda: False
    io.fileno = lambda: -1
    io.flush = lambda: None
    io.close = lambda: None
    io.encoding = 'UTF-8'
    io.mode = 'w'
    n, ncols = 2, 100
    # Test 1
    with tqdm_notebook(n, file=io, ncols=ncols) as t:
        t.update()
   

# Generated at 2022-06-24 10:17:30.151344
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():  # pragma: no cover
    from io import StringIO

    try:
        from nose.tools import assert_equal
        # setup
        out = StringIO()
        # test
        with tqdm(total=10, file=out, ascii=True) as t:
            t.clear()
            t.update()
        assert_equal(out.getvalue(), '')
        # teardown
    except ImportError:
        pass

# Generated at 2022-06-24 10:17:36.848289
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=2) as pbar:
        assert pbar.n == 0
        pbar.update(1)
        assert pbar.n == 1
        yield pbar
        pbar.update()
        assert pbar.n == 2
    assert pbar.n == 2
    with tqdm_notebook(total=2) as pbar:
        raise KeyboardInterrupt()


# Generated at 2022-06-24 10:17:47.350250
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=3, leave=True) as pbar:
        pbar.update()
        pbar.update()
        pbar.reset()
        assert pbar.n == 0
        assert pbar.total == 3

    with tqdm_notebook(total=3, leave=True) as pbar:
        pbar.update()
        pbar.update()
        pbar.reset(total=5)  # reset to new length
        pbar.update()
        assert pbar.n == 1
        assert pbar.total == 5


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:17:51.091574
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test case 1: test exception
    try:
        for _ in tqdm_notebook(range(10)):
            raise(ValueError())
    except ValueError:
        pass

    # Test case 2: test without exception
    for _ in tqdm_notebook(range(10)):
        pass

# Generated at 2022-06-24 10:18:02.631599
# Unit test for method __iter__ of class tqdm_notebook

# Generated at 2022-06-24 10:18:05.274828
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm
    from time import sleep

    with tqdm(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:18:13.654138
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Unit test for method __repr__ of class TqdmHBox.

    Output contains:
    - the description (optional)
    - the bar: with or without ASCI art
    - the info string (optional).
    """
    if IPY == 0:
        return
    def _test(desc, bar_format, info, ascii, ans):
        d = dict(desc=desc, bar_format=bar_format, info=info, ascii=ascii)
        hb = TqdmHBox(pbar=std_tqdm(format_dict=d))

        # test that the method returns the expected string
        ret = str(hb)
        assert ret == ans, "method __repr__ returned %r instead of %r." % (ret, ans)

        # test that the method can

# Generated at 2022-06-24 10:18:22.453902
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    t = tqdm([1, 2], ncols=50, leave=False)
    for i in t:
        t.reset(total=100) # An exception should not be raised
        sleep(0.1)


if __name__ == "__main__":
    from time import sleep
    # TEST 1
    t = tqdm([1, 2], ncols=50, leave=False)
    for i in t:
        sleep(0.1)
    t.close()

    # TEST 2
    t = tqdm(total=10, ncols=50, leave=False)
    for i in range(10):
        t.update()
        sleep(0.1)
    t.close()

    # TEST 3

# Generated at 2022-06-24 10:18:24.223757
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = tqdm_notebook(total=1)
    bar.close()

# Generated at 2022-06-24 10:18:34.205673
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    if IPY < 4:
        raise unittest.SkipTest("Only IPython 4+ supported")

    import unittest
    import IPython

    # Set to true if you want to render the output of this test
    render_output = False

    # helper function (copied from tqdm/tests/test_tqdm.py)
    def _strip_progressbar(txt):
        """
        Strip a progress bar from the provided text.
        """
        txt = re.sub(r"\[[#\-.\| ]*\] *\n?$", "", txt)  # remove bar
        txt = re.sub(r"\r?\n?$", "", txt)  # remove trailing whites

# Generated at 2022-06-24 10:18:38.643537
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for the constructor of class tqdm_notebook.
    """
    from .tests import test_utils
    t = tqdm_notebook(total=100, desc="Unittest")
    for i in t:
        t.set_description("Unittest {}".format(i))
    test_utils.check_bar(t, 100)

# Generated at 2022-06-24 10:18:48.214757
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Setup tqdm_notebook
    pbar = tqdm_notebook(total=10)

    # Test clear before bar display
    pbar.clear()

    # Test clear after bar display
    pbar.update_to(5)
    pbar.clear()
    pbar.update_to(10)
    pbar.close()

    # Test clear in manual mode
    pbar = tqdm_notebook(total=10)
    pbar.clear()  # nop
    pbar.update(5)
    pbar.clear()
    pbar.close()

    # Test clear on a shared bar
    pbar1 = tqdm_notebook(total=10, desc='First')
    pbar2 = tqdm_notebook(total=10, desc='Second')

# Generated at 2022-06-24 10:18:58.191434
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    expected_output = """
0it [00:00, ?it/s]
1it [00:00, 1.14it/s]
2it [00:00, 1.14it/s]
3it [00:00, 1.14it/s]
4it [00:00, 1.14it/s]
> error KeyboardInterrupt :
"""
    import sys
    from tqdm._tqdm import _term_move_up
    from io import StringIO
    with StringIO() as f:
        old_stderr = sys.stderr
        sys.stderr = f

# Generated at 2022-06-24 10:19:08.089744
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from copy import deepcopy
    from textwrap import dedent
    from time import sleep

    for desc in [False, 'desc', 'desc1desc2']:
        for leave in [False, True]:
            for disable in [False, True]:
                for ncols in [None, "100%", "100px", 100]:
                    if ncols is not None:
                        msg = dedent("""
                            tnrange(..., desc={desc!r},
                                    leave={leave!r},
                                    disable={disable!r},
                                    ncols={ncols!r})""")
                    else:
                        msg = dedent("""
                            tnrange(..., desc={desc!r},
                                    leave={leave!r},
                                    disable={disable!r})""")

# Generated at 2022-06-24 10:19:18.149814
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # silence pytest
    import os
    os.environ['PYTEST_CURRENT_TEST'] = '/tmp'
    # prepare display
    try:
        from IPython.display import display
    except ImportError:
        pass
    try:
        from IPython.display import clear_output
    except ImportError:
        pass

    # prepare IPython progress bar
    if IProgress is None:  # #187 #451 #558 #872
        raise ImportError(
            "IProgress not found. Please update jupyter and ipywidgets.")
    pbar = IProgress(min=0, max=100)
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])

    # test repr_json
    d = pbar

# Generated at 2022-06-24 10:19:24.195710
# Unit test for function tnrange
def test_tnrange():
    try:
        from tqdm._tqdm import _version
    except ImportError:
        _version = 0
    try:
        if IPY <= 2:
            t = tnrange(10, desc='testing tnrange')
            next(t)
            t.set_description('testing tnrange')
            t.n = 2
            t.refresh()
        else:
            with tnrange(10, desc='testing tnrange') as t:
                next(t)
                t.set_description('testing tnrange')
                t.n = 2
                t.refresh()
    except KeyboardInterrupt:
        print('Keyboard interrupt (expected)!')
    except Exception as e:
        print('Unexpected error: ', e)
    else:
        print('no exception, ok!')


# Generated at 2022-06-24 10:19:35.904973
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    string = "test_tqdm_notebook_update"
    # update a closed progressbar
    with tqdm(range(2), desc=string, leave=False) as t:
        assert t.dynamic_ncols, "tqdm_notebook enable dynamic_ncols by default"
        assert t.disable == False, "tqdm_notebook should not disable by default"

        for i in t:
            if i == 1:
                t.update(3)  # tqdm should not try to update closed bars

    # update a not displayed progressbar
    with tqdm(range(2), desc=string, leave=False, miniters=1) as t:
        t.displayed = False  # simulate not displayed bar

# Generated at 2022-06-24 10:19:46.711779
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from ipywidgets import IntProgress
    except ImportError:
        from IPython.html.widgets import IntProgress
    from ipywidgets import HBox
    from ipywidgets import HTML

    # test for the first constructor
    tt = tqdm_notebook(total=10, desc='constructor1', ncols=100)
    assert isinstance(tt.container.children[0], HTML)
    assert isinstance(tt.container.children[1], IntProgress)
    assert isinstance(tt.container.children[2], HTML)
    assert tt.container.layout.width == '100px'
    assert tt.container.layout.display == 'inline-flex'
    assert tt.container.layout.flex_flow == 'row wrap'
    # test for the second constructor
    tt

# Generated at 2022-06-24 10:19:53.692914
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    >>> test_tqdm_notebook_clear()
    """
    from .utils import _term_move_up
    with tqdm_notebook(total=9, desc="Closing tqdm") as bar:
        assert bar.displayed
        bar.display()
        assert bar.displayed
        bar.clear()
        assert bar.displayed
        bar.n = 3
        bar.display()
        assert bar.displayed
        bar.n = 6
        bar.display()
        assert bar.displayed
        bar.n = 9
        bar.display()
        assert bar.displayed
        bar.close()
        assert not bar.displayed



# Generated at 2022-06-24 10:19:55.170839
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook(_range(100), desc='An iter', leave=True):
        pass



# Generated at 2022-06-24 10:20:05.831015
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test for `tqdm.notebook.tqdm.display`.
    """
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    # Test display()
    from tqdm.auto import tqdm
    from tqdm import trange

    # string_io = StringIO()
    # tqdm(range(3)).write(file=string_io)
    # print("--->", string_io.getvalue())

    pbar = tqdm(total=10)
    pbar.display(bar_style='success', close=True, check_delay=False)
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.visible == False

    pbar.reset(total=10)
   

# Generated at 2022-06-24 10:20:15.325131
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm

    with tqdm(total=2) as pbar:
        for i in range(4):
            pbar.set_description("foo bar%d" % i)
            if i < 2:
                pbar.update()
            else:
                pbar.display()
    assert pbar.n == 2
    assert "foo bar2" in repr(pbar) and "foo bar3" not in repr(pbar)
    # Check default bar style
    assert ';color:' not in repr(pbar)
    # Check set bar style
    pbar.display(bar_style='success')
    assert re.search(r'color: [\w#]+', repr(pbar))
    pbar.display(bar_style='warning')

# Generated at 2022-06-24 10:20:24.946931
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # normal case
    try:
        hbox = TqdmHBox()
        hbox.pbar = TqdmHBox()
        hbox.pbar.format_dict = {'bar_format': '{l_bar}{bar}{r_bar}',
                                 'bar_format_dict': {'l_bar': '',
                                                     'bar': '<bar/>',
                                                     'r_bar': ''}}
        assert hbox.__repr__() == ''
        assert hbox.__repr__(pretty=True) == ''
        test_passed = True
    except Exception as e:
        print(e)
        test_passed = False

    # exception case

# Generated at 2022-06-24 10:20:33.303635
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .utils import FormatStdin
    from .utils import format_sizeof
    import threading
    import time
    # no crash
    with tqdm_notebook(total=1, desc="BUG 75: clear") as pbar:
        pbar.clear()
    # no crash
    with tqdm_notebook(desc="BUG 81: clear") as pbar:
        pbar.clear()
    # no crash
    with tqdm_notebook(total=1) as pbar:
        pbar.clear()

    # #BUG 77: reset
    pbar = tqdm_notebook(total=1, desc="BUG 77: reset")
    pbar.clear()
    pbar.reset()
    assert pbar.total == 1
    assert 'BUG 77' not in str(pbar)
    pbar

# Generated at 2022-06-24 10:20:41.018382
# Unit test for function tnrange
def test_tnrange():
    for i in tnrange(3):
        pass

    for i in tnrange(3, desc='xxx'):
        pass

    for i in tnrange(3, desc='xxx', leave=True):
        pass

    for i in tnrange(3, desc='xxx', total=5):
        pass

    for i in tnrange(3, desc='xxx', leave=True, total=5):
        pass

    for i in tnrange(3, desc='xxx', total=3):
        pass

    for i in tnrange(3, desc='xxx', leave=True, total=3):
        pass



# Generated at 2022-06-24 10:20:43.900943
# Unit test for function tnrange
def test_tnrange():
    iterator = tnrange(10)
    assert hasattr(iterator, "__iter__")
    try:
        for i in iterator:
            assert i >= 0
    except KeyboardInterrupt:
        pass



# Generated at 2022-06-24 10:20:46.077785
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    return re.sub(r'0x[0-9a-f]+', '0xFFFFFFFF', repr(TqdmHBox(pbar=None)))

# Generated at 2022-06-24 10:20:50.283273
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time, sys
    with tqdm_notebook(total=10, unit_scale=1) as pbar:
        for i in range(10):
            time.sleep(0.01)
            pbar.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:20:53.447995
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.notebook import tqdm_notebook
    t = tqdm_notebook()
    t.update(1)
    t.update(2)
    t.update(3)



# Generated at 2022-06-24 10:20:56.610464
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert repr(TqdmHBox()) == '100%|██████████| 1/1 [00:00<00:00, 100.00it/s]'


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:20:58.174769
# Unit test for function tnrange
def test_tnrange():
    for _ in tnrange(4):
        pass



# Generated at 2022-06-24 10:21:04.909167
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    with tqdm_notebook(total=10) as bar:
        for i in range(5):
            sleep(0.1)
            bar.update()
        bar.reset()
        assert bar.n == 0
        for i in range(5, 10):
            sleep(0.1)
            bar.update()

if __name__ == "__main__":
    # Test tqdm_notebook reset
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:21:07.837681
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    >>> test_TqdmHBox()
    <_tqdm.tqdm_notebook.TqdmHBox object at 0x...>
    """
    return TqdmHBox()

# Generated at 2022-06-24 10:21:18.021696
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=1, bar_format="{l_bar}{bar}{r_bar}", ncols=None) as t:
        assert t.ncols is None
        t.update()
    with tqdm_notebook(total=1, bar_format="{l_bar}{bar}{r_bar}", ncols=100) as t:
        assert t.ncols == '100%'
        t.update()
    with tqdm_notebook(total=1, bar_format="{l_bar}{bar}{r_bar}", ncols="100%") as t:
        assert t.ncols == '100%'
        t.update()

# Generated at 2022-06-24 10:21:23.865844
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=9, unit='B', unit_scale=True) as pbar:
        for i in _range(3):
            pbar.update(1)


# Testing with `nosetests --with-coverage --cover-package=tqdm`
if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:21:31.934149
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=2) as pbar:
        pass

    with tqdm_notebook(total=2) as pbar:
        pbar.update(1)

    with tqdm_notebook(total=2) as pbar:
        pbar.update(2)

    with tqdm_notebook(total=2) as pbar:
        pbar.update(1)
        pbar.update(1)


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:21:40.783369
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from contextlib import redirect_stdout
    from io import StringIO
    from minitest import TestCase

    class TestTqdmHBox(TestCase):
        def setUp(self):
            self.default_d = dict(
                n=None,
                desc='',
                total=None,
                leave=False,
                mininterval=0.1,
                miniters=None,
                ascii=False,
                disable=False,
                unit='it',
                unit_scale=False,
                dynamic_ncols=False)
            self.default_d['n'] = self.default_d['total'] = 1
            self.default_d['unit_scale'] = True
            self.default_d['ascii'] = True


# Generated at 2022-06-24 10:21:51.446046
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pbar = tqdm_notebook('')
    pbar.clear()

    pbar = tqdm_notebook('')
    pbar.close()


if __name__ == "__main__":  # pragma: no cover
    # > python -m tqdm.notebook
    print('Testing tqdm_notebook (this might take a while)...')
    import time
    n = 250
    for i in tqdm_notebook(range(n)):
        time.sleep(0.01)
        if i == n // 3:
            pbar.reset(total=n*2)
            pbar.set_description('halfway there!')
            # pbar.clear()
            # pbar.close()
    pbar.clear()
    pbar.close()

# Generated at 2022-06-24 10:21:59.187692
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    """
    Test function of class tqdm_notebook.status_printer.
    """
    # Test default settings
    tqdm_notebook.status_printer(None, total=None, desc=None)
    # Test total settings
    tqdm_notebook.status_printer(None, total=10, desc=None)
    # Test description settings
    tqdm_notebook.status_printer(None, total=None, desc="Test")
    # Test total settings
    tqdm_notebook.status_printer(None, total=10, desc="Test")

# Generated at 2022-06-24 10:22:06.066260
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import _term_move_up
    from .pandas import tqdm_pandas

    for nrows in [0, 1, 4, 10]:
        with tqdm_pandas(total=nrows, leave=True) as pbar:  # manually close
            for _ in pbar:
                _term_move_up()
                pbar.write("")


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:22:16.359321
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal, assert_true
    from time import sleep

    try:
        import ipywidgets
    except ImportError:
        return

    with tqdm_notebook(total=100, ncols=100) as t:
        for i in range(100):
            t.update()
            sleep(10**-6)
    assert_true(isinstance(t.container.children[-2], ipywidgets.IntProgress))

    with tqdm_notebook(total=100, leave=True, ncols=100) as t:
        for i in range(100):
            t.update()
            sleep(10**-6)
    assert_true(isinstance(t.container.children[-2], ipywidgets.IntProgress))


# Generated at 2022-06-24 10:22:19.205525
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        _ = tqdm_notebook(iterable=[1, 2], desc='testing clear')
        _.clear()
    except Exception:
        raise Exception('tqdm_notebook.clear failed')


# Generated at 2022-06-24 10:22:25.838981
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch('tqdm.notebook.tqdm.tqdm_instance.TqdmHBox.format_meter',
               return_value="hello world") as fm:
        with patch('tqdm.notebook.tqdm.tqdm_instance.TqdmHBox.format_dict',
                   return_value={"format_dict": "hello world"}) as fd:
            # ugly, but we don't have a mock for a class
            box = TqdmHBox()
            box.pbar = None
            assert repr(box) == ""
            box.pbar = object()
            assert repr(box) == "hello world"
            assert repr(box) == repr(box) 