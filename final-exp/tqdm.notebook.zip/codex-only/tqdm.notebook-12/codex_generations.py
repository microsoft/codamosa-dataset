

# Generated at 2022-06-24 10:12:41.488046
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # prepare test
    pbar = IProgress()
    pbar.value = 1
    pbar.style.bar_color = 'red'
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])

    # test without arguments
    # this method calls format_dict
    # therefore, prepare format_dict with simple values
    # container.pbar.format_dict = {'l_bar': ' foo|',
    #                               'r_bar': '  4/5',
    #                               'n': 4,
    #                               'total': 5,
    #                               'bar_format': '{l_bar}<bar/>{

# Generated at 2022-06-24 10:12:49.201720
# Unit test for function tnrange
def test_tnrange():
    """
    Unit tests for tnrange.
    """
    # loop over tnrange
    objs = []
    for i in tnrange(1, 10):
        objs.append(i)
    assert objs == list(range(1, 10))

    # test that tnrange is an iterator
    it = tnrange(1, 10)
    assert next(it) == 1
    objs = []
    for i in it:
        objs.append(i)
    assert objs == list(range(2, 10))

    # test that tqdm_notebook is an iterator
    it = iter(tqdm_notebook(1, 10))
    assert next(it) == 1
    objs = []
    for i in it:
        objs.append(i)
    assert objs

# Generated at 2022-06-24 10:13:01.176075
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tgrange
    from sys import platform
    if hasattr(tgrange, '_instances'):
        tgrange._instances.clear()


# Generated at 2022-06-24 10:13:09.688275
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from unittest import TestCase
    class TestUpdate(TestCase):
        def test_update(self):
            with tqdm_notebook(total=10) as t:
                for i in range(3):
                    sleep(0.05)
                    t.display(None, i)
    TestUpdate('test_update').test_update()

if __name__ == '__main__':
    from time import sleep
    with tqdm(total=100, unit='B', unit_scale=True) as pbar:
        for i in range(100):
            pbar.display(None, i)
            sleep(0.05)
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:13:10.946871
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    No tests: interferes with print()
    """
    pass

# Generated at 2022-06-24 10:13:19.611063
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    return tqdm_notebook.status_printer(sys.stderr, total=10,
                                        desc="Testing if tqdm widgets are "
                                             "displayed correctly.")

if __name__ == '__main__':
    # Run the unit test when this file is run as a script
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:13:25.300491
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Check if tqdm_notebook.update() raises exception when calling `close()`
    """
    bar = trange(1)
    bar.close()
    try:
        bar.update()
    except AttributeError:
        pass
    else:
        raise AssertionError("`update()` after `close()` should raise")

# Generated at 2022-06-24 10:13:37.476883
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import sys
    import subprocess

    # Success test
    bar = tqdm(total=10)
    for i in range(10):
        bar.update(1)
    assert bar.n == 10
    bar.close()
    assert bar.n == 10
    out, err = subprocess.Popen(["ipython", "--colors=NoColor"],
                                stdin=subprocess.PIPE,
                                stdout=subprocess.PIPE,
                                stderr=subprocess.PIPE).communicate()
    assert out == b''
    assert err == b''

    # Error test
    bar = tqdm(total=10, leave=True)
    for i in range(10):
        bar.update(1)
    assert bar.n == 10
    bar.close()
   

# Generated at 2022-06-24 10:13:42.316439
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import sys
    p = tqdm(total=10000)
    p.update(1000)
    p.refresh()
    sys.stderr.write('\n')
    # this should not fail
    repr(TqdmHBox())
    p.close()

# Generated at 2022-06-24 10:13:49.736265
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from IPython.core.display import clear_output
    from time import sleep
    t = tqdm_notebook(range(10))
    sleep(0.01)
    clear_output()
    sleep(0.01)
    t.close()
    sleep(0.01)
    clear_output()
    sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:13:55.112900
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from io import StringIO
    with StringIO() as buf:
        with tqdm_notebook(total=100, file=buf) as t:
            assert t.total == 100
            t.display()
            t.display('')  # should do nothing
            t.display(close=True)

# Generated at 2022-06-24 10:13:59.855528
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import trange
    from time import sleep

    pbar = trange(10, desc='1st loop')
    for i in pbar:
        sleep(0.1)
        if i == 5:
            pbar.reset(total=9)
            pbar.set_description("Changing loop length")
    for i in pbar:
        sleep(0.1)

# Generated at 2022-06-24 10:14:06.551076
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import json
    from IPython.core.display import HTML

    class FakePbar(object):

        def __init__(self, vals):
            self.tpv, self.npv, self.nsv = vals

        @property
        def format_dict(self):
            return dict(
                total_postfix_vals=self.tpv,
                numeric_postfix_vals=self.npv,
                numeric_suffix_vals=self.nsv,
            )

        def format_meter(self, **kwargs):
            return str(kwargs)

    pbar = FakePbar([{'p': '1.5', 's': 'Pixels'},
                     {'n': '2.3'},
                     {'n': '4.6', 's': 'it/s'}])
   

# Generated at 2022-06-24 10:14:09.412225
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=1) as pbar:
        pbar.update(1)



# Generated at 2022-06-24 10:14:19.326017
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test for the method update of the class tqdm_notebook
    """
    from random import randint
    from time import sleep

    def test_range(test_range, test_iterable):
        """
        Randomized tests
        """
        result_tqdm = []
        result_range = []

        # Generate random arguments
        args = []
        for i in range(randint(0, 10)):
            args.append(randint(1, 10))

        # Generate random kwargs
        kwargs = {}
        for i in range(randint(0, 10)):
            kwargs["key{}".format(i)] = "value{}".format(i)

        # Generate 'normal' tqdm with given arguments

# Generated at 2022-06-24 10:14:30.457516
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from json import loads

    # With pretty=None
    bar = PBar(100)
    bar.update(4)
    disp = TqdmHBox(children=[HTML(), bar, HTML()])
    disp._repr_json_() == bar.format_dict

    # With pretty=True
    disp._repr_pretty_ = lambda _: None
    disp._repr_json_(pretty=True)['ascii']  # NOQA: WPS421

    # With pretty=False
    disp._repr_json_(pretty=False) == bar.format_dict
    disp._repr_json_(pretty=False)['ascii'] is True

    # str
    str(disp) == bar.format_meter(**bar.format_dict)

    # JSON dump

# Generated at 2022-06-24 10:14:41.895236
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    with tqdm_notebook(total=5) as t:
        for i in range(5):
            time.sleep(0.5)
            t.display(str(i))


if __name__ == '__main__':
    import sys
    import time

    if '-test' in sys.argv:
        test_tqdm_notebook_display()
        sys.exit()

    if '-upd' in sys.argv:
        t = tqdm(total=5, desc='Test')
        for i in range(5):
            time.sleep(0.5)
            t.update(1)
        t.close()
        sys.exit()

    t = tqdm(total=5, desc='Test')

# Generated at 2022-06-24 10:14:50.939728
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # We cannot test class tqdm_notebook with the try-except clause
    # as the test would be skipped if the except clause is reached
    from .utils import _screen_shape

    try:
        from IPython.display import display, clear_output
    except ImportError:
        pass
    else:
        err = '\nERROR: close method of class tqdm_notebook cannot be tested'
        with std_tqdm(total=3) as first_bar:
            display(first_bar)
            clear_output(wait=True)
            with std_tqdm(total=3) as second_bar:
                display(second_bar)
                clear_output(wait=True)
                with std_tqdm(total=3) as third_bar:
                    if third_bar.displayed:
                        err

# Generated at 2022-06-24 10:14:53.754570
# Unit test for function tnrange
def test_tnrange():
    "Test for tnrange"
    from time import sleep
    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
    for i in tnrange(2, desc='Cooling down'):
        sleep(0.5)
        print(i)

# Generated at 2022-06-24 10:14:59.099604
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from numpy.random import randint
    for i in tqdm_notebook(range(5), '1st loop'):
        for j in tqdm_notebook(range(100 + i), '2nd loop'):
            for k in tqdm_notebook(range(100 * (i + j)), desc='3rd loop', leave=False):
                sleep(0.01)
                # if a random number is even, raise a ValueError
                if randint(2) % 2 == 0:
                    raise ValueError('k = {}'.format(k))

# Generated at 2022-06-24 10:15:12.574278
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert repr(TqdmHBox()) == ""

# Generated at 2022-06-24 10:15:20.845219
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from ipywidgets import widgets, HTML
        from IPython.display import display
    except ImportError:
        try:
            import ipywidgets
            from ipywidgets import widgets, HTML
            from IPython.display import display
        except ImportError:
            return  # failed to import widgets module

    t = tqdm(range(10), desc='hello', ncols=10)
    d = t.format_dict
    d["ascii"] = True
    t._repr_json_(pretty=False)
    # parent class
    assert issubclass(HBox, widgets.ContainerWidget)

    # check input
    ltext = HTML()
    rtext = HTML()
    pbar = widgets.FloatProgress(min=0, max=10)