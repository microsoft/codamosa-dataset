

# Generated at 2022-06-24 10:12:32.991486
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    """
    Unit test for method __iter__ of class tqdm_notebook.

    """
    from tqdm import tqdm

    def test_func():
        try:
            for obj in tqdm_notebook(range(10)):
                if obj == 5:
                    raise Exception('Error')
        except Exception as e:
            if 'Error' not in str(e):
                raise

    test_func()



# Generated at 2022-06-24 10:12:43.410245
# Unit test for function tnrange
def test_tnrange():
    """Test tnrange"""
    try:
        import numpy as np
    except ImportError:
        np = None

    t = tnrange(6)
    assert len(t) == 6  # __len__
    assert list(t) == list(range(6))  # __iter__
    # reset via constructor (bar auto-closes)
    t = tnrange(6)
    for _ in t:
        break
    t0 = time()
    for i in range(4):
        t.reset(4)
        for _ in t:
            sleep(0.01)
    assert time() - t0 > 0.2  # reset works

    # Test simple case
    t = tnrange(5, desc='Testing', leave=True)
    assert t.n == 0

# Generated at 2022-06-24 10:12:47.587271
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        # dummy pbar for test
        pbar = IProgress(min=0, max=1)
        TqdmHBox(children=[HTML(), pbar, HTML()])._repr_json_(pretty=True)
        TqdmHBox(children=[HTML(), pbar, HTML()])._repr_json_(pretty=False)
        return True
    except Exception as e:
        return e

# Generated at 2022-06-24 10:12:52.430908
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Tests the update method of class tqdm_notebook
    """
    # Initialize a tqdm_notebook bar
    bar = tqdm_notebook(total=10, desc="Test",
                        unit="B", unit_scale=True)
    size = 0
    for i in range(10):
        size += i
        # Update progress
        bar.update()
    # Close progress bar
    bar.close()

# Generated at 2022-06-24 10:13:03.683884
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with trange(10) as t:
        assert t._gui is True
        for _ in t:
            pass
    with trange(10) as t:
        assert t._gui is True
        for i in t:
            if i == 5:
                break
    with trange(10) as t:
        assert t._gui is True
        for i in t:
            t.set_postfix(i=i)
            if i == 5:
                break
    with trange(10) as t:
        assert t._gui is True
        for i in t:
            t.set_postfix(foo="bar")
            if i == 5:
                break
    with trange(10) as t:
        assert t._gui is True

# Generated at 2022-06-24 10:13:12.386185
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test for tqdm.notebook.tqdm.update() method.
    """
    with tqdm_notebook(total=10) as pbar:
        assert not pbar.disable
        assert pbar.clear() is None
        assert pbar.close() is None
        assert pbar.display(check_delay=False) is None
        assert pbar.update() is None
        pbar.reset(total=100)
        pbar.update(n=1)
        with pbar:
            for i in _range(10):
                assert pbar.update() is None
                pbar.reset(total=100)
                pbar.update(n=1)
                for i in _range(10):
                    assert pbar.update() is None

# Generated at 2022-06-24 10:13:15.051205
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    t = tqdm_notebook(total=3, file=sys.stdout)
    t.display_adjust(postfix={'foo': 'bar'}, refresh=True)
    t.display(check_delay=False)
    t.display(bar_style='success')
    try:
        raise Exception
    except:
        t.display(bar_style='danger')
    else:
        raise Exception('Should have failed.')

# Generated at 2022-06-24 10:13:24.428297
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from datetime import datetime
    from IPython.display import clear_output, display
    with std_tqdm(total=5) as pbar:
        for i in range(5):
            pbar.set_description("desc %d" % i)
            sleep(1)
            clear_output(wait=True)
        pbar.write("fin {0}".format(datetime.now()))
        pbar.refresh()
        sleep(1)
        clear_output(wait=True)


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:13:29.857258
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Make sure that repr of TqdmHBox is well formed
    """
    from tqdm import tqdm
    from platform import python_implementation

    is_pypy = python_implementation() == 'PyPy'

    # First, test without parameter 'pretty=True' on Python 2.7 and Python3.x
    tqdm_obj = tqdm(range(10))
    repr_TqdmHBox_1 = repr(tqdm_obj.container)
    # This should fail if __repr__ is not well formed
    eval(repr_TqdmHBox_1)

    # Test on PyPy

# Generated at 2022-06-24 10:13:31.754187
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # test in notebooks/TQDM_NOTEBOOK_TEST.ipynb
    pass

# Generated at 2022-06-24 10:13:40.432669
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test method update of class tqdm_notebook
    """
    # Suppress output
    sys.stderr.close()
    sys.stderr = open('/dev/null', 'w')

    # Initialize a progress bar
    pbar = tqdm_notebook(total=100)

    # Update progress bar
    pbar.update(10)
    assert pbar.n == 10, "pbar.update(10) sets pbar.n to 10"

    # Close progress bar
    pbar.close()



# Generated at 2022-06-24 10:13:52.306650
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from nose.tools import eq_
    from nose.plugins.skip import SkipTest

    try:
        from ipywidgets import HBox, FloatProgress
        from ipywidgets import VBox
    except ImportError:
        raise SkipTest

    # Initialize a progress bar
    bar = tqdm_notebook(total=10)
    bar.moveto(4)
    assert bar.container.children[1].value == 4
    assert bar.container.style.visibility == ''

    # Test bar style
    bar.close()
    assert bar.container.children[1].bar_style == 'success'

    # Test hide
    bar.close(leave=False)
    assert bar.container.style.visibility == 'hidden'
    assert bar.container.children[1].value == 0

    # Test error handling
    bar

# Generated at 2022-06-24 10:13:59.409579
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test to check the correct behaviour of method reset of class tqdm_notebook
    """
    t = tqdm_notebook(total=2, leave=True, dynamic_ncols=False)
    t.reset()
    t.update(1)
    assert t.n == 1, "n should be 1"
    t.reset(total=4)
    t.update(2)
    assert t.total == 4, "total should be 4"
    t.update(3)
    assert t.n == 3, "n should be 3"
    assert t.total == 4, "total should be 4"
    t.reset(total=5)
    t.update(2)
    assert t.n == 2, "n should be 2"

# Generated at 2022-06-24 10:14:06.089574
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    bar = TqdmHBox()
    assert bar._repr_json_() == {}
    assert bar._repr_pretty_(None) is None
    assert bar.__repr__() == '{desc: , total: 0, n: 0, elapsed: 0, ' +\
        'bar_format: {l_bar}{bar}{r_bar}, pos: 0, unit_scale: 1, ' +\
        'unit: , ascii: False}'
    assert bar.__repr__(pretty=True) == '{desc: , total: 0, n: 0, elapsed: 0, ' +\
        'bar_format: {l_bar}\u2588{bar}\u2588{r_bar}, pos: 0, unit_scale: 1, ' +\
        'unit: , ascii: False}'

# Generated at 2022-06-24 10:14:16.640665
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from random import random, randint

    for _ in tqdm_notebook(range(2)):
        # Progress bar is not set to manual mode since we call close()
        # in the except block below
        # tqdm is in a try block to ensure that close() is called
        try:
            # create a new progress bar
            i = 0
            with tqdm_notebook(total=5) as pbar:
                while i < 5:
                    i += 1
                    pbar.update(1)
                    if random() > 0.5:
                        raise Exception()
        except:
            # re-use progress bar if failed
            i -= 1
            # signal error
            pbar.disp(bar_style='danger')
            pbar.reset(total=None)

# Generated at 2022-06-24 10:14:24.311347
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    hbox.pbar = std_tqdm()
    hbox.pbar.format_dict = {'bar_format': '{l_bar}<bar/>{r_bar}', 'ascii': True}
    hbox.pbar.n = 0
    hbox.pbar.total = 100
    test_case = hbox.__repr__(pretty=True)
    assert test_case == '[>                                                            ]'
    assert hbox.__repr__(pretty=False) == '[>                                                            ]'
    assert hbox.__repr__() == '[>                                                            ]'

# Generated at 2022-06-24 10:14:32.376903
# Unit test for method close of class tqdm_notebook

# Generated at 2022-06-24 10:14:37.747291
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    import warnings

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message="Widget Javascript ")
        with tqdm_notebook(total=1, position=1) as pbar:
            time.sleep(0.2)
            pbar.reset(total=2)
            time.sleep(0.2)

# Generated at 2022-06-24 10:14:47.476003
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Test basic `tnrange` and default `tqdm` settings"
    # Test `tnrange` default settings
    tn = tnrange(100)
    assert tn._instant_refresh == tqdm_notebook._instant_refresh
    assert tn.container.pbar.max == 100
    assert tn.total == 0  # not `100`
    assert tn.ascii == tqdm_notebook.ascii
    assert tn.unit == tqdm_notebook.unit
    assert tn.unit_scale == tqdm_notebook.unit_scale
    assert tn.unit_divisor == tqdm_notebook.unit_divisor
    assert tn.mininterval == tqdm_notebook.mininterval
    assert tn.maxinter

# Generated at 2022-06-24 10:14:59.185258
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """Test __repr__, _repr_json_, and _repr_pretty_ of TqdmHBox"""

    def check_TqdmHBox(pretty):
        hbox = TqdmHBox()
        assert hbox.__repr__(pretty) == hbox._repr_json_()
        assert hbox.__repr__(pretty) == hbox.__repr__(not pretty)

        hbox.pbar = std_tqdm(total=10)
        assert hbox.__repr__(pretty) == hbox._repr_json_()
        assert hbox.__repr__(pretty) == hbox.__repr__(not pretty)

        hbox.pbar.update(5)
        assert hbox.__repr__(pretty) == hbox._repr_

# Generated at 2022-06-24 10:15:07.957911
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=2, leave=False) as pbar:
        pbar.reset(total=10)
        assert pbar.total == 10
        assert pbar.n == 0
        assert pbar.container.children[-2].max == 10
        pbar.update()
        pbar.update()
        assert pbar.container.children[-2].value == 2

# Generated at 2022-06-24 10:15:17.790314
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    p = TqdmHBox()
    assert repr(p) == '<HBox(children=(<HTML()>, <FloatProgress(value=0.0, layout=Layout(height=\'10px\', width=\'100%\', flex_flow=\'column\', display=\'flex\'), description=\'\', min=0.0, max=100.0, bar_style=\'\', orientation=\'horizontal\'), <HTML()>))>'  # noqa: E501
    p.pbar = TqdmHBox()

# Generated at 2022-06-24 10:15:20.215130
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox()
    hbox.pbar = True
    hbox.__dict__  # <<<< avoid pyflakes warning
    assert hbox.__repr__() == TqdmHBox().__repr__()



# Generated at 2022-06-24 10:15:29.139601
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tqdm_notebook
    import sys
    import time
    for i in tqdm_notebook(range(10), file=sys.stdout):
        time.sleep(0.1)
    for i in tqdm_notebook(range(10), file=sys.stdout, leave=True):
        time.sleep(0.1)

if __name__ == "__main__":
    test_tqdm_notebook_update()
    input("Press enter to quit.")

# Generated at 2022-06-24 10:15:35.284322
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    hbox.children = [None, None, None]
    assert hbox._repr_json_() == {}
    assert hbox._repr_pretty_({}) == None
    hbox.children[1] = IProgress()
    assert hbox._repr_json_() != {}
    assert hbox._repr_pretty_({}) == None
    del hbox.children[1]

if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:15:47.393678
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test method `tqdm_notebook.__iter__()`
    """
    from time import sleep

    # Quiet test mode
    class _fake_stdout(object):
        def write(self, *args, **kwargs):
            pass

        def flush(self, *args, **kwargs):
            pass
    sys.stdout = _fake_stdout()

    # Display test mode
    # class _fake_stdout(object):
    #     def __init__(self):
    #         self.buffer = ""
    #         self.n = 1
    #         self.times = []
    #         self.interrupt = False

    #     def write(self, x):
    #         if '\r' not in x:
    #             self.buffer += x
    #         self.times.

# Generated at 2022-06-24 10:15:55.472891
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from functools import partial
    import _ipywidgets as ipywidgets
    # Test that it is possible to get the widget representation
    # (as a dict) even if _ipywidgets is an older version that does not have
    # _widget_repr_pretty_ by calling __repr__
    TqdmHBox._widget_repr_pretty_ = getattr(
        ipywidgets.Widget, '_widget_repr_pretty_', None)

# Generated at 2022-06-24 10:16:03.538102
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    pbar = tqdm_notebook(total=1)
    for _ in pbar:
        pass
    assert repr(pbar.container) == '100%|██████████| 1/1 [00:00<?, ?it/s]'
    assert pbar.container._repr_pretty_({}, None, True) == '100%|██████████| 1/1 [00:00<?, ?it/s]'


if IPY:
    tqdm.write = tqdm_notebook.write

if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:16:07.697873
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    w = TqdmHBox()
    assert repr(w) == '{desc: \x1b[A\x1b[A'
    w.pbar = std_tqdm().__iter__()
    assert repr(w) == ' \x1b[A\x1b[A'

# Generated at 2022-06-24 10:16:15.747723
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # test_tqdm_notebook_reset
    from tqdm import tqdm  # tqdm_gui
    from time import sleep

    print("test_tqdm_notebook_reset")
    for i in tqdm(range(20)):
        sleep(0.1)
    tqdm.reset(total=100)
    for i in tqdm(range(100)):
        sleep(0.1)
    tqdm.reset(total=None)
    for i in tqdm(range(20)):
        sleep(0.1)



# Generated at 2022-06-24 10:16:25.855531
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep

    # just check that display() works as output is not easily testable
    bar = tqdm_notebook()
    for i in bar:
        sleep(0.01)
        bar.display()
        if i >= 5:
            bar.close()
            break

    # test error signal
    bar = tqdm_notebook()
    for i in bar:
        sleep(0.01)
        bar.display()
        if i >= 5:
            bar.display(bar_style='danger')
            break

    # test close signal (with big delay to avoid race conditions)
    bar = tqdm_notebook(total=10, leave=True, delay=1)
    for i in bar:
        sleep(0.01)
        bar.display()

# Generated at 2022-06-24 10:16:36.606695
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from unittest import TestCase

    class FakeStream(object):
        def __init__(self):
            self.text = ''

        def write(self, text):
            self.text += text

        def flush(self):
            pass

    class TestTqdmNotebook(TestCase):
        def test_close_no_leave(self):
            stream = FakeStream()

            with tqdm_notebook(total=1, file=stream, leave=False) as t:
                t.update(value=1)
                t.close()
            self.assertEqual(stream.text, '')

        def test_close_leave(self):
            stream = FakeStream()
            with tqdm_notebook(total=1, file=stream, leave=True) as t:
                t.update(value=1)

# Generated at 2022-06-24 10:16:47.346315
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import re
    from .utils import _format_interval
    from .std import TqdmTypeError

    class obj(object):

        def _repr_json_(self, pretty=None):
            return {}

    if IPY:
        fp = tqdm_notebook.status_printer(obj(), None)
        assert isinstance(fp, obj.__class__)
        assert len(fp.children) == 3
        assert isinstance(fp.children[0], HTML)
        assert isinstance(fp.children[1], IProgress)
        assert isinstance(fp.children[2], HTML)

        assert fp.children[0].value == ''
        assert fp.children[1].value == 0
        assert fp.children[2].value == ''

        fp = tqdm_notebook.status_

# Generated at 2022-06-24 10:16:49.011553
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import trange

    for _ in trange(2, 2):
        pass


# Generated at 2022-06-24 10:17:01.162287
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from tqdm.notebook import tqdm_notebook
    import sys
    import io
    import os

    # Test the status printer function for notebook
    # There are race conditions and width limiting by ipywidgets
    # which are difficult to test without a real notebook
    # For now, just test if the widget is created correctly
    # and if the gui output is identical to the text output
    io_fh = io.StringIO()
    io_fh.isatty = lambda: True
    # Hack-ish way to avoid the danger bar_style being overridden by
    # success because the bar gets closed after the error...
    err = FakeErr()


# Generated at 2022-06-24 10:17:03.512961
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    def f():
        for i in tqdm_notebook(xrange(10)):
            yield i
    list(f())



# Generated at 2022-06-24 10:17:12.898861
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep

    try:
        pbar = tqdm_notebook(total=10)
        for i in range(5):
            pbar.update()
            sleep(0.1)
        for i in range(5):
            pbar.update(i)
            sleep(0.1)
        clear_output()
    except KeyboardInterrupt:
        pbar.close()
        print("tqdm_notebook: update method failed")
        raise
    pbar.close()


test_function = test_tqdm_notebook_update

if __name__ == '__main__':
    test_function()

# Generated at 2022-06-24 10:17:22.639129
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import sys
    from io import StringIO
    from mock import MagicMock
    sys.modules['ipywidgets'] = MagicMock()
    out = StringIO()
    bar = tqdm_notebook(iterable=["a", "b", "c"], file=out)
    assert repr(bar) == 'a |###       | 3/3 [00:00<?, ?it/s]\n'
    bar.n = 1
    assert repr(bar) == 'a |##        | 2/3 [00:00<?, ?it/s]\n'
    bar.update(1)
    assert repr(bar) == 'a |###       | 3/3 [00:00<?, ?it/s]\n'
    bar.close()
    del sys.modules['ipywidgets']

# Generated at 2022-06-24 10:17:34.402310
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import sys
    import tempfile

    with tempfile.NamedTemporaryFile(mode='w') as file:
        kwargs = dict(
            desc='Test clear() method',
            file=file,
            total=10,
        )

        # Initialize tqdm
        t = tqdm(*args, **kwargs)
        # Clear tqdm
        t.clear()

        # Check that clear() method doesn't print anything on the file
        file.seek(0)
        assert not file.read()


# Simple test showing that tqdm_notebook is using ipywidgets
# The following test is commented out because we cannot check the
# result of the test before running it...
# def test_tqdm_notebook_is_ipywidgets():
#     import sys

#     with tempfile.

# Generated at 2022-06-24 10:17:38.409259
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test method of class tqdm_notebook"""
    with tqdm_notebook(total=0, ncols=10) as pbar:
        assert len(str(pbar)) == 10
        for i in range(4):  # range is needed for python3 compatibility
            pbar.update(1)
        assert str(pbar) == "1/4 [>-------------------]  25%"


test_tqdm_notebook()

# Generated at 2022-06-24 10:17:50.014500
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    try:
        class Pbar(object):
            def __init__(self):
                self.value = 10
                self.max = 20

            def __repr__(self):
                raise NotImplementedError

        class TqdmHBox_(TqdmHBox):
            def __init__(self):
                self.pbar = Pbar()
        # TqdmHBox_ is a TqdmHBox which doesn't have children
        # (see tqdm_notebook.__init__)
        assert repr(TqdmHBox_()) == '   10%|#         | 2/20 [00:00<?, ?it/s]'
    except:
        raise
    else:
        print("class TqdmHBox passed the test in tqdm_notebook.py")

# Generated at 2022-06-24 10:17:53.280412
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""
    wdgt = tqdm_notebook.status_printer(None, desc=None)
    display(wdgt)
    wdgt.close()


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:17:57.491425
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep

    with tqdm_notebook(total=10, leave=True, unit_scale=False) as t:
        for i in range(10):
            sleep(i/10)
            t.update()


# Generated at 2022-06-24 10:18:07.987367
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Unit tests tqdm_notebook.update, including a few corner cases"""
    msg = "This test will detect some buggy behaviors, but not all.\n"
    msg += "For more, see https://github.com/tqdm/tqdm/issues"
    print(msg)
    test_total = 4
    for total in [test_total, None]:
        with tqdm_notebook(total=total) as t:
            for _ in _range(test_total):
                pass
            t.update(1)

    for GUI in [False, True]:
        for total in [test_total, None]:
            with tqdm_notebook(total=total, leave=False, gui=GUI) as t:
                for _ in _range(test_total):
                    pass
                t.update(1)

# Generated at 2022-06-24 10:18:18.373858
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    "Unit test for method reset of class tqdm_notebook"
    t = tqdm(total=1001)  # 1001 to force the detection of total
    t.reset()
    assert t.n == 0
    t = tqdm(total=1001)
    t.reset(total=1002)
    assert t.total == 1002
    try:
        import numpy as np
        t = tqdm(total=np.nan)  # force no total
    except:  # NOQA
        pass
    t.reset()
    assert t.n == 0
    t.reset(total=1002)
    assert t.total == 1002
    t._decr_instances()  # delete t
    assert t.container is None


# Generated at 2022-06-24 10:18:22.342788
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm(total=5)
    try:
        for _ in t:
            pass
    except:  # NOQA
        pass
    t.close()
    t.__repr__()
    t.__repr__(pretty=True)


# Generated at 2022-06-24 10:18:32.095301
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from .gui import tqdm as tqdm_gui
    everything_allright = True
    try:
        import ipywidgets  # NOQA
        ipywidgets_imported = True
    except ImportError:
        ipywidgets_imported = False

    if not ipywidgets_imported:
        return  # cannot even instantiate the bar
    # DEFAULT
    with tqdm_notebook(range(3)) as t:
        for i in t:
            pass
    # KWARGS
    close = False
    with tqdm_notebook(range(3), leave=False, disable=True, dynamic_ncols=True) as t:
        for i in t:
            if i == 1:
                close = True
                break
    assert close


# Generated at 2022-06-24 10:18:41.703844
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    from io import StringIO
    from contextlib import contextmanager

    @contextmanager
    def nostderr():
        import sys
        new_stderr = StringIO()  # redirect stderr from IPython display
        old_stderr = sys.stderr
        sys.stderr = new_stderr
        try:
            yield
        finally:
            sys.stderr = old_stderr

    # different display
    f = tqdm_notebook(range(3), file=sys.stdout,
                      bar_format='{desc}: {bar}|{n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
    time.sleep(0.1)
    f.display(bar_style='info')

# Generated at 2022-06-24 10:18:49.947119
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Initializing TqdmHBox with ipywidgets.HBox
    bar = tqdm_notebook.status_printer(None, total=100, desc='Loading', ncols=100)

    # Over-specified ncols (e.g. "100%")
    assert bar.layout.width == "100%"
    assert bar.layout.display == 'inline-flex'
    assert bar.layout.flex_flow == 'row wrap'

    # Assert ipywidgets.HBox layout
    assert bar._dom_classes == ('HBox', 'widget-hbox', 'vbox')
    assert bar._model_module == '@jupyter-widgets/controls'
    assert bar._model_module_version == '1.3.3'

# Generated at 2022-06-24 10:18:51.385376
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tqdm_notebook([])
    pbar.reset(total=100)
    assert pbar.max == 100

# Generated at 2022-06-24 10:18:58.213647
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import sys
    import time
    f = sys.stderr
    try:
        with tqdm_notebook(total=10, file=sys.stdout) as t:
            for i in range(10):
                time.sleep(0.1)
                t.update()
            t.reset(total=7)
            for i in range(7):
                time.sleep(0.1)
                t.update()
    finally:
        sys.stderr = f
        t.close()

# Generated at 2022-06-24 10:19:01.909192
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test method display of class tqdm_notebook()
    """
    tn = tqdm_notebook(total=1)
    # Check that display() does not raise
    tn.display()
    # Check that display(close=True) does not raise
    tn.display(close=True)
    # Check that display(close=True) does not raise
    tn.display(bar_style='success')
    # Check that display(close=True) does not raise
    tn.display(bar_style='danger')
    tn.close()

# Generated at 2022-06-24 10:19:07.556782
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # case 1: total=None, unit_scale=False
    with tqdm_notebook(total=None) as pbar:
        pbar.update()
        pbar.close()
    # case 2: total=None, unit_scale=None
    with tqdm_notebook(total=None) as pbar:
        pbar.update()
        pbar.close()
    # case 3: total=None, unit_scale=True
    with tqdm_notebook(total=None) as pbar:
        pbar.update()
        pbar.close()
    # case 4: total=0, unit_scale=False
    with tqdm_notebook(total=0) as pbar:
        pbar.close()
    # case 5: total=0, unit_scale=None

# Generated at 2022-06-24 10:19:15.462726
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test case for display method of class tqdm_notebook."""
    from .utils import _range
    from .std import FormatCustomTextType  # type: ignore

    def _test_display(total=None, desc='Default', display_kw=None, **display_kwargs):
        """test tqdm_notebook.display with given arguments"""
        display_kw = display_kw or display_kwargs
        for bar_style in (None, 'default', 'success', 'info', 'warning', 'danger'):
            for leave in (True, False):
                if isinstance(display_kw, dict):
                    t = tqdm_notebook(desc=desc, total=total, leave=leave,
                                      bar_style=bar_style, **display_kw)
                else:
                    t = tqdm_notebook

# Generated at 2022-06-24 10:19:24.752825
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm._tqdm import status_printer
    from tqdm.notebook import tqdm_notebook

    # Parse arguments

# Generated at 2022-06-24 10:19:36.349406
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-24 10:19:41.407122
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests tqdm_notebook.clear() to avoid `AttributeError: 'NoneType' object has no attribute 'children'` error
    """
    with tqdm_notebook(total=7) as _:
        for _ in range(3):
            _.clear()


# Generated at 2022-06-24 10:19:50.791695
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from sys import stderr
    for _ in tqdm_notebook(
            iterable=range(10),
            unit='foo',
            total=9,
            position=0,
            leave=False,
            file=stderr
    ):
        pass

    for _ in tqdm_notebook(
            iterable=range(10),
            unit='foo',
            total=10,
            position=0,
            leave=False,
            file=stderr
    ):
        pass

    for _ in tqdm_notebook(
            iterable=range(10),
            unit='foo',
            total=10,
            position=0,
            leave=False,
            file=stderr
    ):
        raise Exception('test')


test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:20:02.678638
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    import collections
    import os
    import re
    from .utils import StringIO

    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    try:
        from ipywidgets import FloatProgress
    except ImportError:
        from IPython.html.widgets import FloatProgress

    # Use class tqdm_notebook to print the progress bar
    with patch.object(sys, 'stderr', new_callable=StringIO):
        # Test iteration with total
        with tqdm_notebook(total=9) as pbar:
            assert isinstance(pbar, tqdm_notebook)
            assert isinstance(pbar.container, TqdmHBox)
            assert isinstance(pbar.container.children[-2], FloatProgress)


# Generated at 2022-06-24 10:20:13.005364
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from io import StringIO  # Python3
    from unittest import TestCase, main
    import time

    class TestTqdmNotebookClear(TestCase):
        """
        Tests for `tqdm.notebook.tqdm`.
        """

        class _TqdmIO(StringIO):
            """
            StringIO that records whether getvalue() has been called.
            """
            def __init__(self, *args, **kwargs):
                super(TestTqdmNotebookClear._TqdmIO, self).__init__(*args, **kwargs)
                self.getvalue_called = False

            def getvalue(self):
                self.getvalue_called = True
                return super(TestTqdmNotebookClear._TqdmIO, self).getvalue()


# Generated at 2022-06-24 10:20:14.994106
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    t = tqdm_notebook(total=10)
    for i in range(10):
        t.update()



# Generated at 2022-06-24 10:20:19.316862
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox(children=[]).__str__() == 'HBox()'
    assert TqdmHBox(children=[1, 2]).__str__() == 'HBox(children=(%r, %r))' % (
        1, 2)
    assert '<HTML' in str(TqdmHBox(children=[HTML(), HTML()]))

# Generated at 2022-06-24 10:20:23.298750
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    n = 100
    with tqdm_notebook(total=n) as pbar:
        for i in range(n):
            pbar.update()
    assert pbar.n == n
    assert pbar.displayed



# Generated at 2022-06-24 10:20:26.235310
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            assert t.n == i, t.n
            t.clear()
            assert t.n == i, t.n


# Generated at 2022-06-24 10:20:34.273577
# Unit test for method __repr__ of class TqdmHBox

# Generated at 2022-06-24 10:20:39.855012
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for total in [None, 1, 100]:
        with tqdm_notebook(total=total, desc="Test progress bar") as pbar:
            assert pbar.total == total
            pbar.update()

    """
    Unit test for constructor of class tqdm_notebook.
    Use the following command:
    >>> ipython -m tqdm._tqdm_notebook -- --debug
    """
    if __name__ == '__main__' and '--debug' in sys.argv:
        # conda install -c conda-forge safitty
        from IPython.display import clear_output
        from safitty import color_print, logger


# Generated at 2022-06-24 10:20:41.653975
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hb = TqdmHBox()
    hb.pbar = 1
    assert repr(hb) == "1"

# Generated at 2022-06-24 10:20:51.555726
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import mock
    from tqdm.notebook import tqdm_notebook as tn
    with mock.patch.object(tn, 'display') as mock_disp:
        tn.display(msg='simple msg')
        mock_disp.assert_called_once_with(msg='simple msg',
                                          pos=None, close=None,
                                          bar_style=None, check_delay=None)

        mock_disp.reset_mock()
        tn.display(msg='')
        mock_disp.assert_called_once_with(msg='', pos=None, close=None,
                                          bar_style=None, check_delay=None)

        tn.display(check_delay=False)
        tn.display(bar_style='danger')
       

# Generated at 2022-06-24 10:20:54.258345
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # HBox with no children
    container = TqdmHBox()
    assert container.__repr__() == "{'bar_format': '{l_bar}<bar/>{r_bar}'}"



# Generated at 2022-06-24 10:21:02.068925
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    box = TqdmHBox()
    box.pbar = tqdm_notebook(total=10, ascii=True)
    expected = 'Total: 10'.ljust(33) + '|' + '0/10 [?25l' + ' '*15 + '?' + '\n' + \
               ' '*33 + '|' + '?'*17 + '?25h'
    assert repr(box) == expected


if __name__ == '__main__':
    with tqdm(total=5) as t:
        for i in range(5):
            print(i)
            t.update()

# Generated at 2022-06-24 10:21:12.855579
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Unit test for method display of class tqdm_notebook"""
    import time

    # Can't test without IPython
    if IProgress is None:
        print("IProgress not found. Skipping test_tqdm_notebook_display.")
        return

    # Make sure there is no leftover garbage from previous runs
    from IPython import get_ipython
    ip = get_ipython()
    ip.magic("%gui none")
    ip.magic("%matplotlib inline")
    ip.magic("%matplotlib widget")
    ip.magic("%matplotlib notebook")
    ip.magic("%matplotlib inline")
    ip.magic("%matplotlib widget")
    ip.magic("%matplotlib notebook")

    # Test display method
    print("\nTesting display method...")
    bar = tq

# Generated at 2022-06-24 10:21:23.391067
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    if IPY == 0:
        return
    from IPython.display import HTML, display
    from IPython import get_ipython
    pbar = TqdmHBox()
    pbar.pbar = tqdm(total=10)
    display(pbar)
    try:
        pbar.pbar.update(5)
        pbar.pbar.update(5)
    except:
        pass
    html = HTML(str(pbar))
    display(html)
    # Test with pretty printing
    ip = get_ipython()
    ip.run_cell_magic('html', '', str(pbar))
    ip.run_cell_magic('html', '', '<pre>' + str(pbar) + '</pre>')
    # Test repr
    assert str

# Generated at 2022-06-24 10:21:34.282699
# Unit test for function tnrange
def test_tnrange():
    for total_delta, unit, ncols in [  # (total, ncols)
            (-1, 1, None),
            (-10, 2, None),
            (10, 1, None),
            (10, 2, None),
            (10, 2, 250),
            (10, 2, "250px"),
            (10, 2, "250%"),
            ]:
        total = total_delta + len(_range(10)) if total_delta >= 0 else None
        for leave in [False, True]:
            bar = tnrange(
                10, ncols=ncols, unit=unit, leave=leave, total=total)
            for obj in bar:
                pass
            if leave:
                assert bar.displayed, "tnrange failed to display leave=True"

# Generated at 2022-06-24 10:21:37.305399
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tf = tqdm_notebook(range(10))
    tf.update(1)

if __name__ == '__main__':
    test_tqdm_notebook_update()

 
# In[ ]:

# Generated at 2022-06-24 10:21:44.561885
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from unittest import TestCase

    class t(TestCase):
        def setUp(self):
            self._old_stderr = sys.stderr
            sys.stderr = sys.stdout

        def tearDown(self):
            sys.stderr = self._old_stderr

    with t():

        with tqdm_notebook(total=6, file=sys.stdout, desc="0%") as t:
            sleep(0.1)
            t.update(1)
            sleep(0.1)
            t.update(2)
            sleep(0.1)

        # Test close()
        with tqdm_notebook(total=3, file=sys.stdout, desc="0%") as t:
            pass  # noqa

        #

# Generated at 2022-06-24 10:21:56.177017
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests if the `tqdm_notebook.status_printer` method
    returns an IPython/Jupyter progress bar widget.
    """
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        if IPY == 4:
            # tqdm_notebook.status_printer(file)
            assert isinstance(tqdm_notebook.status_printer(None), ipywidgets.Widget)
        else:
            # tqdm_notebook.status_printer(file, total=None)
            assert isinstance(tqdm_notebook.status_printer(None, None), HBox)
        # tqdm_notebook.status_printer(file, total=10)

# Generated at 2022-06-24 10:21:59.407016
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    x = tqdm_notebook(total=3)
    x.update(1)
    x.update(1)
    x.close()

# Generated at 2022-06-24 10:22:09.736387
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from nose.tools import assert_equal
    from tqdm.notebook import tqdm
    from tqdm.auto import trange

    bar = tqdm(total=10)
    # assert_equal(repr(bar.container), bar.format_meter(ascii=True))
    assert_equal(repr(bar.container),
                 "[{l_bar}{bar}{r_bar}] {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]")
    bar.close()

    bar = trange(10)
    # assert_equal(repr(bar.container), bar.format_meter(ascii=True))

# Generated at 2022-06-24 10:22:18.073072
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test tqdm_notebook reset method"""
    import gc
    try:
        from IPython.display import clear_output
        clear_output
    except ImportError:
        pass  # skip test

    pbar = tqdm_notebook(total=10)
    for i in range(5):
        pbar.update(1)
    pbar.reset()
    for i in range(5):
        pbar.update(1)

    gc.collect()
    res = re.match(r'\[ *5/10 *\]', pbar.container.children[-1].value)
    assert res is not None, 'reset did not work'


if __name__ == '__main__':
    # Test
    n = 1000000

# Generated at 2022-06-24 10:22:22.721715
# Unit test for function tnrange
def test_tnrange():
    from .utils import _supports_unicode
    for x in tnrange(4, leave=True):
        pass
    l = [0, 1, 2, 3, 4, 5]
    for i, x in tqdm_notebook(enumerate(l), total=len(l)):
        assert i == x
    for i, x in enumerate(tqdm_notebook(l)):
        assert i == x

    # Test post-production closing
    pbar = tnrange(2)
    pbar.update()
    pbar.close()

# Generated at 2022-06-24 10:22:33.375112
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox()._repr_json_() == {}
    pbar = IProgress(min=0, max=1)
    container = TqdmHBox(children=[pbar, pbar])
    container.pbar = proxy(pbar)
    assert TqdmHBox()._repr_json_(pretty=True) == {
        'bar_format': '{l_bar}<bar/>{r_bar}',
        'ascii': True,
        'postfix': [{'n': 1, 'total': 1}],
        'max': 1,
        'total': 1,
        'min': 0,
        'n': 1,
        'desc': ''}
    assert repr(container)
    assert container._repr_pretty_(None)