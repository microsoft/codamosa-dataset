

# Generated at 2022-06-24 10:12:37.146957
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    h = TqdmHBox()
    h.pbar = tqdm_notebook(total=100)
    assert str(h) == h.__repr__(pretty=False)
    assert str(h) == h.__repr__(pretty=True)
    h.pbar.close()
    h.pbar = None
    assert h.__repr__() == h.__repr__(pretty=False)
    assert h.__repr__() == h.__repr__(pretty=True)
    # Try to display h
    from tqdm._utils import _term_move_up
    # A non-standard output display for h is expected,
    # because the default value of display_id is None
    display(h)
    # Move cursor to the first line for next output
    sys.stder

# Generated at 2022-06-24 10:12:45.698640
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Tests the method update of class tqdm_notebook.
    """
    if IPY < 0:
        return
    from tqdm import trange
    import time
    import multiprocessing as mp
    # Basic test
    with trange(10, leave=True) as t:
        for i in t:
            t.update()
            if i == 5:
                t.set_description('Foo')
                t.set_postfix(counter='bar')
            time.sleep(0.1)
    # Test with a description
    with trange(10, desc='Iterating...', leave=True) as t:
        for i in t:
            t.update()
            time.sleep(0.1)
    # Test resetting the bar

# Generated at 2022-06-24 10:12:50.994993
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import randint
    t = tqdm_notebook(total=100)
    for i in range(100):
        t.set_description('Loop %d' % i)
        sleep(0.01 + randint(0, 9)/100)
        t.update(1)
    t.close()


# Generated at 2022-06-24 10:13:00.699834
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as bar:
        bar.clear()
        assert bar.n == 0


if __name__ == '__main__':
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            import time
            time.sleep(0.5)
    test_tqdm_notebook_clear()

    test_tqdm_notebook_clear()
    print('All test passed!')

# Generated at 2022-06-24 10:13:10.301865
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    # Test display of bar on stdout
    try:
        from IPython.utils.io import CapturedIO
    except ImportError:  # IPython < 1.0
        from IPython.utils.capture import capture_output as CapturedIO
    with CapturedIO() as c:
        tqdm_notebook(range(3))
    assert re.search(r'\n\s*\r?\s*0%|50%|100%\s*\r?\n', c.stdout), c.stdout

    # Test display of bar in notebook
    from IPython.display import clear_output
    import IPython

# Generated at 2022-06-24 10:13:17.762269
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    container = tqdm_notebook.status_printer(None, 10)
    display(container)


if __name__ == "__main__":
    # Run the tests
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:13:23.379773
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    a = tqdm_notebook(["a", "ab", "abc", "abcd"], file=None)
    b = ["a", "ab", "abc", "abcd"]
    for i, j in zip(a, b):
        assert i == j
    assert a.n == 4 and a.total == 4
    return



# Generated at 2022-06-24 10:13:28.335156
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    x = tqdm_notebook.status_printer(None, 10, 'desc', 20)
    assert type(x) is TqdmHBox
    y = tqdm_notebook.status_printer(None, 10, 'desc', 100)
    assert type(y) is TqdmHBox

# Generated at 2022-06-24 10:13:33.509535
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import __version__ as version
    with tqdm_notebook(total=10) as pbar:
        for i in _range(11):
            pbar.set_description("v%s" % version)
            sleep(.1)
            pbar.update()

# Generated at 2022-06-24 10:13:39.168075
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as t:
        for i in range(10):
            t.clear()


# Generated at 2022-06-24 10:13:46.972776
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Check defaults
    assert tqdm_notebook.status_printer(None) == tqdm_notebook.status_printer(
        None, None, None, None)
    assert tqdm_notebook.status_printer(None) != tqdm_notebook.status_printer(
        None, None, None, "100px")
    # Check return value
    assert isinstance(tqdm_notebook.status_printer(None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, None, None, "100px"),
                      TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, None, None, None),
                      TqdmHBox)

# Generated at 2022-06-24 10:13:55.061613
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    print("Testing tqdm_notebook.__iter__ ...")
    from time import sleep

    with tqdm_notebook(total=3) as pbar:
        for i in pbar:
            sleep(0.01)
            assert i == pbar.n  # comparing ints is well defined

if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:14:02.807907
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .tqdm import trange
    import io
    progress_bar = trange(10)
    progress_bar_repr = repr(progress_bar)
    TqdmHBox_obj = TqdmHBox()
    TqdmHBox_obj.pbar = progress_bar
    # setting the io.StringIO value to call _repr_pretty_ method because it
    # accesses the output stream to write the progress bar
    open_old = open
    open = lambda *args, **kwargs: io.StringIO()
    TqdmHBox_obj._repr_pretty_(None)
    open = open_old
    TqdmHBox_obj_repr = repr(TqdmHBox_obj)
    # make sure that two representations are the same
    assert progress_bar_repr == Tq

# Generated at 2022-06-24 10:14:13.529134
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm(_range(10)) as t:
        for i in t:
            pass
    assert t.n == 10
    try:
        # the output will be in red (error)
        with tqdm(_range(10)) as t:
            raise Exception
    except:
        assert True
    # without error, output will be in green (success)
    with tqdm(_range(10)) as t:
        pass
    assert t.n == 10


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:14:17.543232
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    result = []
    with tqdm_notebook(total=3) as t:
        try:
            result.append(t.update(2))
            raise Exception
        except Exception:
            result.append(t.close())
            result.append(t.n)
            result.append(t.container.children[-2].bar_style)

    assert result == [None, None, 2, 'danger']



# Generated at 2022-06-24 10:14:22.830281
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import unittest
    from contextlib import redirect_stdout
    class TestTqdmHBox(unittest.TestCase):
        def setUp(self):
            self.hbox = TqdmHBox()

        def test___repr__(self):
            # Set the values of the widgets
            self.hbox.children = [HTML(), IProgress(), HTML()]
            self.hbox.pbar = tqdm_notebook()
            with redirect_stdout(open(os.devnull, "w")):
                self.hbox.pbar.display()
            # Call the method to be tested
            actual_result = self.hbox.__repr__()
            # Compare the result with what was expected

# Generated at 2022-06-24 10:14:27.409235
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from tqdm import trange
    for _ in trange(1000):
        pass
    t = trange(10)
    for _ in t:
        t.set_description("desc")
    for _ in t:
        t.set_postfix("postfix")

# Generated at 2022-06-24 10:14:40.251177
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox()
    del hbox
    hbox = TqdmHBox()
    hbox.pbar = 'test'

# Generated at 2022-06-24 10:14:46.539373
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from numpy.random import randint
    from numpy.random import choice
    import sys

    def _print(msg):
        print(msg, file=sys.stderr)

    # Default Total
    with tqdm(total=10) as t:
        _print("Test 1:")
        _print("\t")
        _print("\tInitial")
        _print("\t")
        sleep(1)
        _print("\t")
        _print("\tDone")
        _print("\t")
        _print("Test 2:")
        # Change Total
        t.reset(11)
        _print("\t")
        _print("\tInitial")
        _print("\t")
        sleep(1)
        _print("\t")
        _print

# Generated at 2022-06-24 10:14:54.202069
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from copy import deepcopy
    from json import dumps
    from ipywidgets import Layout

    pbar = IProgress(value=1, max=1, bar_style='info')
    container = TqdmHBox(children=[HTML(), pbar, HTML()])

    # Test pretty repr
    assert container.__repr__(pretty=True) == '<info> |#| 100%'  # no progress
    pbar.value = 0  # progress
    pbar.max = 5
    assert container.__repr__(pretty=True) == '\r|  0%|                                             |  0/5'

    # Test json repr
    pbar_json = pbar._repr_json_()
    container_json = deepcopy(container._repr_json_())

# Generated at 2022-06-24 10:14:57.330815
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
            time.sleep(0.1)

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-24 10:15:07.537128
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=3, leave=False) as t:
        t.update()
        assert t.container.pbar.bar_style != 'danger'
        t.update()
        assert t.container.pbar.bar_style != 'danger'
        assert t.container.pbar.bar_style != 'success'
        t.update()


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=['-s', '--with-doctest'], exit=False)

# Generated at 2022-06-24 10:15:17.659181
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm.auto import tqdm
    from tqdm._tqdm_test_examples import range_; from tqdm import _range
    from tqdm import trange
    from tqdm import tqdm_notebook
    from tqdm._utils import _term_move_up

    class dummy_file(object):
        """Dummy file-like output"""
        nl = False

        def __init__(self):
            self.n = 0
            """Number of times `write` was called"""

        def write(self, x):
            """Dummy write function"""
            if not self.nl:
                self.n += 1

        def flush(self):
            """Dummy flush function"""

    # disable tqdm bar

# Generated at 2022-06-24 10:15:23.816381
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    for x in tnrange(2):
        for y in tnrange(3):
            sleep(0.05)
    for x in tnrange(2):
        for y in tnrange(3):
            sleep(0.05)



# Generated at 2022-06-24 10:15:28.573277
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox()).startswith("tqdm")
    assert repr(TqdmHBox()).endswith("tqdm")
    pbar = tqdm_notebook(total=100)
    assert repr(TqdmHBox(pbar)) == repr(pbar)

# Generated at 2022-06-24 10:15:30.450177
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm(range(2)):
        sleep(0.1)

# Generated at 2022-06-24 10:15:38.007125
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import os
    import time
    from .tests_tqdm import pretest_posttest_monkeypatch, posttest, print_on_err
    # from .tests_tqdm import closing_to_file_redirection_monkeypatch
    # with closing_to_file_redirection_monkeypatch():
    with pretest_posttest_monkeypatch(print_on_err):
        pbar = tqdm_notebook(total=100)
        for i in range(10):  # warmup
            pbar.update(10)
        for i in range(0, 10, 2):
            assert pbar.n == i*10
            pbar.update(5)
            assert pbar.n == i*10+5
            time.sleep(0.1)



# Generated at 2022-06-24 10:15:48.750113
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """ Unit test for method __repr__ of class TqdmHBox """
    from IPython.display import display  # , clear_output

    for i in trange(10, desc="Making test", ncols=100):
        time.sleep(0.1)
    for i in trange(10, desc="Making test", ncols=100, leave=True):
        time.sleep(0.1)
    for i in trange(10, desc="Making test", ncols=100, leave=False):  # NOQA: F841
        time.sleep(0.1)
    for i in trange(10, desc="Making test", ncols=100, ascii=True):
        time.sleep(0.1)

# Generated at 2022-06-24 10:15:59.745302
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    class TestProgressBar(IProgress):
        def __init__(self, desc, max, ncols=None, bar_style=''):
            super(TestProgressBar, self).__init__(min=0, max=max)
            self.desc = desc
            self.bar_style = bar_style
            if max:
                self.value = max
            if ncols:
                self.layout.width = str(ncols) + 'px'

        def format_dict(self, pretty=None):
            d = dict(desc=self.desc, bar_style=self.bar_style,
                     ncols=self.layout.width, total=self.max)
            if pretty is not None:
                d["ascii"] = not pretty
            return d


# Generated at 2022-06-24 10:16:07.837033
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm
    try:
        from tqdm import notebook
    except ImportError:
        return
    with tqdm(total=10, desc="Test clear") as t:
        for i in range(10):
            t.set_description("Test clear %d" % i)
            t.update(1)
    with tqdm(total=10, desc="Test clear", dynamic_ncols=True) as t:
        for i in range(10):
            t.set_description("Test clear %d" % i)
            t.update(1)

# Generated at 2022-06-24 10:16:16.981726
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .utils import format_sizeof
    from .tests import _test_reset
    for unit in [None, '', 'B', 's', 'min', 'h', 'd', 'w', 'y', 'kb', 'MB']:
        for leave in [False, True]:
            for dynamic_ncols in [False, True]:
                for attr in ['n', 'n_fmt', 'rate', 'inv_rate', 'avg_rate',
                             'elapsed', 'eta', 'bar_format']:
                    _test_tqdm_notebook_reset(attr, unit,
                                              dynamic_ncols=dynamic_ncols,
                                              leave=leave)



# Generated at 2022-06-24 10:16:23.229359
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    :func:`tqdm.notebook.tqdm_notebook` class method
    `status_printer` unit test
    """
    from IPython.html.widgets import FloatProgress, HBox
    from IPython.display import HTML

    progress = tqdm_notebook.status_printer(None, 1337, "Getting Things Done!",
                                            ncols=100)
    assert isinstance(progress, HBox)
    left, pbar, right = progress.children
    assert isinstance(left, HTML)
    assert isinstance(pbar, FloatProgress)
    assert isinstance(right, HTML)

    assert pbar.min == 0
    assert pbar.max == 1337
    assert left.value == "Getting Things Done!"
    assert right.value == ""

# Generated at 2022-06-24 10:16:28.504710
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    for _ in range(3):
        try:
            for i in tqdm_notebook(range(3), desc='1st loop'):
                for j in trange(3, desc='2nd loop', leave=False):
                    for k in trange(3, desc='3rd loop', leave=False):
                        time.sleep(0.01)
                time.sleep(0.05)
            time.sleep(0.1)
        except KeyboardInterrupt:
            pass
    print('Done.')

# Generated at 2022-06-24 10:16:30.444846
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    obj = TqdmHBox()
    assert type(obj.__repr__()) == str

# Generated at 2022-06-24 10:16:35.347323
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    """
    pbar = tqdm_notebook(total=1, miniters=1)
    pbar.display(msg="Testing with display")
    pbar.display(close=True)


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:16:46.638190
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Unit test for method `update` of class `tqdm_notebook`"""
    from itertools import repeat
    from time import sleep
    from IPython.display import clear_output

    # Test manually with `disable=False`
    pbar = tqdm_notebook(disable=False)
    test_iter = repeat(None, 21)
    for _ in test_iter:
        sleep(0.1)
        pbar.update()
    pbar.close()
    clear_output()

    # Test manually with `disable=True`
    pbar = tqdm_notebook(disable=True)
    test_iter = repeat(None, 21)
    for _ in test_iter:
        sleep(0.1)
        pbar.update()
    pbar.close()
    clear_output()

   

# Generated at 2022-06-24 10:16:53.174982
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    class TqdmNotInNew(tqdm_notebook):
        def __new__(cls, *args, **kwargs):
            return std_tqdm(*args, **kwargs)

    with TqdmNotInNew(total=100) as t:
        for i in range(100):
            t.update()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:16:58.524611
# Unit test for function tnrange
def test_tnrange():
    from IPython import get_ipython
    from IPython.core.display import clear_output
    from time import sleep

    for i in tnrange(4, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        clear_output()



# Generated at 2022-06-24 10:17:09.899723
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Unit test for method TqdmHBox.__repr__

    Test the __repr__ method  of the class TqdmHBox

    Returns:
        -2: successful execution
        -1: unexpected error
    """

    # initialize tqdm
    t = tqdm(total=1)

    # test basic output
    try:
        res = repr(TqdmHBox(children=t.container.children))
    except Exception as e:
        print("Test TqdmHBox.__repr__ FAILED, unexpected error: " + str(e))
        return -1

    # expected res

# Generated at 2022-06-24 10:17:12.078980
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests import test_tqdm_notebook___iter__
    test_tqdm_notebook___iter__()


# Generated at 2022-06-24 10:17:15.574505
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    for _ in tqdm_notebook(range(2)):
        try:
            # raise any exception
            raise Exception()
        except:
            pass
    # raise KeyboardInterrupt
    raise KeyboardInterrupt()

# Generated at 2022-06-24 10:17:24.693750
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import unittest
    import io
    import json

    class TqdmTest(unittest.TestCase):
        def test_TqdmHBox(self):
            fp = io.BytesIO()

            try:  # Py2
                unicode = unicode  # NOQA
            except NameError:
                pass

            pbar = tqdm_notebook(total=2, file=fp)
            pbar.update()
            pbar.set_description('foo')
            pbar.set_postfix(OrderedDict(a=1, b=2))
            pbar.close()
            try:
                container = json.loads(fp.getvalue().decode('utf-8'))
            except AttributeError:
                container = json.loads(fp.getvalue())
            self.assertE

# Generated at 2022-06-24 10:17:33.721365
# Unit test for function tnrange
def test_tnrange():
    vals = list(tnrange(10))
    assert vals == list(_range(10)), vals
    vals = list(tnrange(1, 11))
    assert vals == list(_range(1, 11)), vals
    vals = list(tnrange(1, 11, 2))
    assert vals == list(_range(1, 11, 2)), vals
    vals = list(tnrange(10, 0, -1))
    assert vals == list(_range(10, 0, -1)), vals
    vals = list(tnrange(0))
    assert vals == list(_range(0)), vals



# Generated at 2022-06-24 10:17:42.621422
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Unit test for method status_printer of class tqdm_notebook """
    # No total provided
    status = tqdm_notebook.status_printer(sys.stdout)
    assert isinstance(status, TqdmHBox)
    # Total of 0
    status = tqdm_notebook.status_printer(sys.stdout, 0)
    assert isinstance(status, TqdmHBox)
    # Total provided
    status = tqdm_notebook.status_printer(sys.stdout, 1)
    assert isinstance(status, TqdmHBox)
    # Description provided
    status = tqdm_notebook.status_printer(sys.stdout, 1, 'test')
    assert isinstance(status, TqdmHBox)
    assert status.pbar.description

# Generated at 2022-06-24 10:17:48.394498
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = std_tqdm(1)
    t.update()
    t.close()
    assert t
    T = t.container
    assert T
    assert T.__repr__() == T.__repr__(False)
    assert T.__repr__(True) == T.__repr__(True)

# Generated at 2022-06-24 10:17:53.050689
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    l = list(tqdm_notebook(range(10)))
    assert l == list(range(10)), l

    l = list(tqdm_notebook(range(10)))
    assert l == list(range(10)), l

    l = list(tqdm_notebook(range(10)))
    assert l == list(range(10)), l



# Generated at 2022-06-24 10:18:01.197048
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test __iter__ attribute of class tqdm_notebook.
    """
    import time
    # Test if tqdm_notebook is closeable
    for _ in tqdm_notebook(range(3), desc='1st loop'):
        for _ in tqdm_notebook(range(3), desc='2nd loop', leave=True):
            for _ in tqdm_notebook(range(3), desc='3nd loop'):
                time.sleep(0.01)



# Generated at 2022-06-24 10:18:04.891109
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .utils import FormatStopError
    with tqdm_notebook(total=2) as pbar:
        pbar.update()
        raise FormatStopError  # #741
    assert not pbar.container.children[-2].style.bar_color

# Generated at 2022-06-24 10:18:11.471855
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from unittest import TestCase

    class test__tqdm_notebook___iter__(TestCase):
        def test_basic(self):
            for _ in tqdm_notebook(range(10)):
                pass
            for i in tqdm_notebook(range(10)):
                if i == 5:
                    raise RuntimeError
            with self.assertRaises(RuntimeError):
                for i in tqdm_notebook(range(10)):
                    if i == 5:
                        raise RuntimeError
    test__tqdm_notebook___iter__().test_basic()

# Generated at 2022-06-24 10:18:18.851424
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test tqdm_notebook.update()
    """
    from time import sleep
    from warnings import warn

    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message=r'Widget Javascript not detected.  It may not be installed or enabled properly.')
        try:
            delay = float(input('test_tqdm_notebook_update'
                                ' (skip=2, clear=1) delay: '))
        except (KeyboardInterrupt, EOFError):
            return None
    try:
        total = int(input('total: '))
    except (KeyboardInterrupt, EOFError):
        return None

# Generated at 2022-06-24 10:18:27.079257
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from os import cpu_count
    from time import sleep

    with tqdm_notebook(total=100) as pbar:
        for i in range(1, 100 + 1):
            pbar.update()
            sleep(0.1)

    assert not pbar.container.visible

    with tqdm_notebook(total=cpu_count()) as pbar:
        for i in range(cpu_count()):
            pbar.update()
        try:
            pbar.update(1)
            assert False
        except ValueError:
            assert True


if __name__ == '__main__':
    # Run unitest only when called by `python3 -m tqdm.notebook`
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:18:33.649947
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook(total=1)
    tqdm_notebook(total=1, leave=True)
    tqdm_notebook(total=1, dynamic_ncols=True)
    tqdm_notebook(total=1, dynamic_ncols=True, leave=True)
    tqdm_notebook(total=1, leave=True, dynamic_ncols=True)
    tqdm_notebook(total=1, dynamic_ncols=True, leave=True)

# Generated at 2022-06-24 10:18:42.744265
# Unit test for function tnrange
def test_tnrange():
    from IPython.core.debugger import Tracer  # NOQA
    # Tracer()()
    total = 12345
    for _ in tnrange(total, leave=True):
        pass
    for _ in tnrange(total):
        pass
    for _ in tnrange(total):
        raise RuntimeError()
    for _ in tnrange(total, desc="my desc"):
        pass
    for _ in tnrange(total, desc="my desc", colour='red'):
        pass
    for _ in tnrange(total, desc="my desc", colour='orange'):
        pass
    for _ in tnrange(total, desc="my desc", colour='green'):
        pass

# Generated at 2022-06-24 10:18:45.270638
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    output = StringIO()
    actual = tqdm_notebook.status_printer(file=output)
    assert isinstance(actual, TqdmHBox)
    assert repr(actual) == repr(actual._repr_json_())


if __name__ == "__main__":
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:18:46.744100
# Unit test for function tnrange
def test_tnrange():
    from .utils import assert_equal
    for i in tnrange(9, unit='a'):
        if i == 5:
            pass
    assert_equal(i, 8)



# Generated at 2022-06-24 10:18:56.055914
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # test for issue #748
    for n in tqdm(range(10)):  # pylint: disable=unused-variable
        pass

    # should not raise
    tqdm_notebook.close(tqdm.tpbar)
    # should not raise
    tqdm_notebook.close(tqdm.tpbar)
    # should close tpbar
    tqdm_notebook.close(tqdm.tpbar, leave=False)
    assert not tqdm.tpbar.container.visible
    # should not raise
    tqdm_notebook.close(tqdm.tpbar)



# Generated at 2022-06-24 10:19:01.672407
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Creating a mock IPython.display.display object
    try:
        display
    except NameError:
        class display(object):
            def __init__(self, *_):
                pass
    display_ = display(None)

    # Testing function status_printer of class tqdm_notebook
    tqdm_notebook.status_printer(display_)



# Generated at 2022-06-24 10:19:06.481834
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test `tqdm.notebook.clear()` method"""
    from .utils import NoOp, _range
    from .std import tqdm as std_tqdm
    tn = tqdm_notebook(total=1, file=NoOp)
    tn.clear()
    tn.update(0)
    tn.reset()
    std_tqdm(total=3).clear()
    n = tn.n
    tn.n = n
    tn.ncols = tn.ncols


if __name__ == "__main__":  # pragma: no cover
    _ = test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:19:11.246597
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            # t.total = 30  # doesn't work
            t.update()
    # assert t.total == 30  # doesn't work
    # assert t.ncols == 100


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:19:22.123683
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main
    from time import sleep
    from io import StringIO
    from tqdm import __version__ as tqdm_version  # NOQA

    class Test_tqdm_notebook_display(TestCase):

        def setUp(self):
            sys.stderr = StringIO()
            self.test_string = 'This is a test'

        def tearDown(self):
            sys.stderr = sys.__stderr__

        def test_display(self):
            # Use default output
            bar = tqdm_notebook(total=10, postfix={'test': 1},
                                display_postfix_text='test')
            bar.display()
            lines = sys.stderr.getvalue().split('\r')

# Generated at 2022-06-24 10:19:33.720945
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test the tqdm_notebook constructor"""
    # Empty
    assert tqdm_notebook.__init__(
        tqdm_notebook(), file=sys.stdout) is None

    # Test docstrings
    assert tqdm_notebook.__doc__  # test exists
    assert tqdm_notebook.__init__.__doc__  # test exists
    assert tqdm_notebook.status_printer.__doc__  # test exists

    # Test default arguments

# Generated at 2022-06-24 10:19:41.494905
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tnrange.
    """
    from itertools import chain
    # DEV: Will create a tqdm_notebook widget. Add the line
    # `from tqdm.notebook import tnrange; list(tnrange(10))`
    # in a Jupyter Notebook cell and execute it.
    list(chain.from_iterable(
        tnrange(i + 1, ncols=100) for i in tnrange(10)))



# Generated at 2022-06-24 10:19:45.810732
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    with tqdm_notebook(total=100, smoothing=1) as t:
        for i in range(4):
            t.clear()
            t.update(25)

# Generated at 2022-06-24 10:19:52.950816
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Create a class object with the attributes of a TqdmHBox
    class Dummy(object):
        def __init__(self):
            self.value = 1
            self.min = 0
            self.max = 2
            self.bar_style = "info"
            self.layout = Dummy()
            self.layout.width = None
    pbar = Dummy()
    # Create an object with attributes of a TqdmHBox
    hbox = TqdmHBox()
    hbox.pbar = pbar
    # Check the value of __repr__()
    assert hbox.__repr__() == "<info>| 1/2 [\n    1  <--->\n]</info>"

# Generated at 2022-06-24 10:20:04.647517
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # without `total`
    with tqdm_notebook(disable=True) as T:
        for i in T:
            sleep(0.01)

    # with `total`
    with tqdm_notebook(total=None, disable=True) as T:
        for i in T:
            sleep(0.01)
    # without total, but with leave=True as default
    with tqdm_notebook(disable=True) as T:
        for i in T:
            sleep(0.01)
        # raise an error if total is not provided and leave=True,
        # since the progress bar will never be hidden
        # if total is not provided and leave=False, the progress bar
        # will be hidden, the error will never be raised
        # since we're already in a finally block:
        # raise Runtime

# Generated at 2022-06-24 10:20:11.342370
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        import ipywidgets
    except ImportError:
        try:
            import IPython.html.widgets
        except ImportError:
            assert True
            return
    from .trange import trange
    from .utils import format_dict
    from .version import __version__
    from .utils import _term_move_up

    format_dict['bar_format'] = '{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining},{rate_fmt}]'
    format_dict['smoothing'] = 0

    with tqdm(total=10, leave=False, disable=False) as pbar:
        # no error
        pbar.close()
        assert pbar.bar_format == '.\n'

# Generated at 2022-06-24 10:20:21.230807
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    """
    Unit test for class tqdm_notebook
    """
    from tqdm.auto import tqdm as tqdm_auto

    # close() should not fail if not displayed
    t = tqdm_notebook(total=10)
    t.close()

    # repeat tqdm_notebook() with manual mode
    for i in tqdm_notebook(total=10, leave=True):
        # repeat tqdm_notebook() with manual mode
        for j in tqdm_notebook(total=10, leave=True):
            pass

        # repeat tqdm_auto() with manual mode
        for j in tqdm_auto(total=10, leave=True):
            pass
    t.close()

    # test reset in manual mode
    # test n

# Generated at 2022-06-24 10:20:29.931199
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # suppress deprecation warning for HTML widget
    # with warnings.catch_warnings():
    #     warnings.filterwarnings(
    #         'ignore', message=".*The `IPython.html` package has been deprecated.*")
    #     from IPython.html.widgets import HTML, FloatProgressWidget

    # if IPY > 4:  # Py3
    #     from ipywidgets import FloatProgress, HBox
    #     from IPython.display import display
    # else:
    #     from IPython.html.widgets import FloatProgressWidget as FloatProgress
    #     from IPython.html.widgets import ContainerWidget as HBox
    #     from IPython.display import display  # NOQA

    if None in (IProgress, HBox):  # #187 #451 #872
        return

    # __re

# Generated at 2022-06-24 10:20:40.176516
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock
    from unittest import TestCase
    from .std import TProgressBar
    from .std import PbarDeprecatedWarning

    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")

        class TqdmHBoxTest(TestCase):
            def test_repr(self):
                inst = TqdmHBox(Mock(TProgressBar))
                # As string
                s = inst.__repr__()
                self.assertTrue(s)
                # As pretty
                inst._repr_pretty_(Mock(), True)
                # As json
                d = inst._repr_json_()

# Generated at 2022-06-24 10:20:49.963996
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    python -m tqdm.notebook test_TqdmHBox___repr__
    """
    from .utils import _term_move_up
    import time

    for ncols in ['100%', 100, None]:
        for style in ['info', 'success', 'danger', None]:
            with tqdm(total=10, ncols=ncols, ascii=True, desc='this is test') as t:
                if style is not None:
                    t.bar_style = style
                print((TqdmHBox(children=t.container.children)))
                print((TqdmHBox(children=t.container.children)))
                print(repr(TqdmHBox(children=t.container.children)))

# Generated at 2022-06-24 10:20:53.842854
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=100, leave=False) as pbar:
        # Case 1: loop of 100 iterations
        for i in _range(100):
            pbar.update()

        # Case 2: loop of 10 iterations
        for i in _range(10):
            pbar.update(10)

# Generated at 2022-06-24 10:20:57.562630
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .utils import _supports_unicode
    from .std import tqdm as std_tqdm
    t = tqdm_notebook(_range(3), desc="Notebook")
    assert hasattr(t, 'clear')
    assert hasattr(t, 'container')
    t.clear()
    t.clear()

# Generated at 2022-06-24 10:21:07.749943
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Tests the display method of class tqdm_notebook.
    """
    from unittest import TestCase
    from io import StringIO
    import json
    class TqdmNotebookTest(TestCase):
        tn = tqdm_notebook(total=10)
        # test display
        def test_display_error(self):
            self.tn.container.children[0].value = 'test'
            self.tn.container.children[1].value = 0
            self.tn.container.children[1].bar_style = 'success'
            self.tn.container.children[2].value = ''
            self.tn.disp(msg='test', bar_style='danger')
            self.assertEqual(
                self.tn.container.children[0].value, 'test')

# Generated at 2022-06-24 10:21:17.946234
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Check single
    t = tqdm_notebook(["a", "b", "c", "d"], desc="test1")
    output = []
    for char in t:
        output.append(char)
        sleep(0.01)
    assert output == ["a", "b", "c", "d"]
    # Check nested
    t = tqdm_notebook(["a", "b", "c", "d"], desc="test1")
    output = []
    for char in t:
        output.append(char)
        t2 = tqdm_notebook(["1", "2", "3", "4"])
        for char2 in t2:
            output.append(char2)
            sleep(0.01)

# Generated at 2022-06-24 10:21:29.486720
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for method status_printer of class tqdm_notebook.

    See Also
    --------
    https://github.com/ipython/ipywidgets/issues/1133
    """
    # Initialize
    iterable = range(10)
    desc_list = [None, ""]
    with_bar = [True, False]
    for desc in desc_list:
        for with_bar in with_bar:
            # Call
            tqdm_notebook_class = tqdm_notebook(iterable, desc=desc)
            tqdm_notebook_class.bar_format = "{bar}" if with_bar else ""
            # Check Widget display
            display(tqdm_notebook_class.container)


# Generated at 2022-06-24 10:21:35.862465
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tnrange
    from time import sleep
    from sys import version_info

    a = tnrange(5)
    sleep(0.5)
    a.reset()
    for _ in a:
        sleep(0.5)
        if version_info.major >= 3:
            break

if __name__ == '__main__':
    import unittest
    import sys
    sys.argv.append('--verbose')
    unittest.main(module='tests', exit=False)

# Generated at 2022-06-24 10:21:36.961685
# Unit test for function tnrange
def test_tnrange():
    it = tnrange(8)
    for _ in it:
        pass

# Generated at 2022-06-24 10:21:41.145371
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    with tqdm_notebook(total=3) as pbar:
        for i in [1, 2, 3]:
            pbar.update(1)
            time.sleep(0.1)
    tqdm_notebook.clear_instance(pbar)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:21:51.773630
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .gui import tqdm_gui
    # Init
    tqdm2 = tqdm_notebook(leave=True)

    # Update
    vals = tqdm2.update()
    assert vals == (1, 1, 0)

    vals = tqdm2.update(2)
    assert vals == (1, 1, 0)

    # Close
    tqdm2.close()

    # Re-Init
    tqdm2 = tqdm_notebook(total=8, leave=True)

    # Update
    vals = tqdm2.update()
    assert vals == (1, 8, 0)

    vals = tqdm2.update(2)
    assert vals == (3, 8, 0)

    vals = tqdm2.update(3)

# Generated at 2022-06-24 10:21:55.478734
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(10)
    for i in range(5):
        t.update()
    t.reset()
    for i in range(10):
        t.update()
    t.close()

# Generated at 2022-06-24 10:22:01.961006
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        t1 = tqdm_notebook([1, 2, 3], leave=True)
        t2 = tqdm_notebook([1, 2, 3], leave=True)
        for i in t1:
            if i == 2:
                t1.clear(nolock=False)
                with t1.container.output_lock:
                    t1.container.clear_output()
                t2.clear(nolock=False)
                with t2.container.output_lock:
                    t2.container.clear_output()
    except Exception as e:
        assert False, "tqdm_notebook.clear() raised {} on exit".format(type(e).__name__)

# Generated at 2022-06-24 10:22:12.051049
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import TextIOWrapper
    from re import search as res
    from sys import stdout, stderr
    from time import sleep
    from tqdm.notebook import tqdm_notebook
    method = tqdm_notebook.status_printer

    assert method is not None

    # Test default output
    hbox = method(stdout)
    with TextIOWrapper(stdout) as s:
        print(hbox, file=s)
    assert res(r"(?m)^$", s.getvalue())

    # Test output with total and desc
    desc = "test"
    total = 23
    hbox = method(stdout, total, desc)
    with TextIOWrapper(stdout) as s:
        print(hbox, file=s)

# Generated at 2022-06-24 10:22:19.149689
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from unittest import TestCase, TestLoader

    class TqdmNotebookUpdate(TestCase):
        def check_update_signature(self, tqdm_obj):
            tqdm_obj.update(1)
            tqdm_obj.update(1, 1000)

        def test_tqdm_notebook_update(self):
            self.check_update_signature(tqdm_notebook(total=10))

    suite = TestLoader().loadTestsFromTestCase(TqdmNotebookUpdate)
    raise SystemExit(not TestLoader().run(suite).wasSuccessful())


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:22:25.796993
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .utils import _range
    from .std import format_interval, format_sizeof

    width = 40
    for i in trange(40, file=sys.stdout, desc='clearing', leave=True,
                    bar_format='{desc}: ' + ' ' * width + '{percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]'):
        file = sys.stdout
        fp = getattr(file, 'buffer', file)

        # Print header
        tn = tqdm_notebook(initial=0, total=5, unit='B',
                           desc='test', unit_scale=True, leave=True)
        tn.display()
        clear_

# Generated at 2022-06-24 10:22:36.196201
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from unittest import mock
    except ImportError:
        from unittest import mock
    from .gui import tgrange

    _range_ = range if sys.version_info[0] >= 3 else xrange
    tqdm_ = tqdm_notebook if sys.version_info[0] >= 3 else tqdm_notebook
    tgr = tgrange
