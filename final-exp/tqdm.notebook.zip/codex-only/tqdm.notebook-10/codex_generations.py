

# Generated at 2022-06-24 10:12:37.847779
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from distutils.version import LooseVersion
    from ipywidgets import __version__ as ipywidgets_version
    from tqdm.auto import tqdm

    if LooseVersion(ipywidgets_version) < LooseVersion('7.1'):
        print("WARNING: Skipping unit test for method reset of class "
              "tqdm_notebook: ipywidgets < 7.1")
        return

    def reset(bar, *args, **kwargs):
        try:
            bar.reset(*args, **kwargs)
        finally:
            bar.close()
        assert bar.total is None

    # Manual bar with leave=True
    bar1 = tqdm(total=10, leave=True)
    for _ in bar1:
        pass
    reset(bar1)
    assert bar1

# Generated at 2022-06-24 10:12:40.655525
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert TqdmHBox().__repr__() == TqdmHBox().__repr__(pretty=True)
    assert TqdmHBox().__repr__(pretty=False) == TqdmHBox().__repr__(pretty=0)

# Generated at 2022-06-24 10:12:48.691794
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    goal: to ensure no regression and ensure IProgress widget get correctly
    configured.
    """
    import sys
    from .utils import FormatCustomTextType, UnicodeIO, _environ_cols_wrapper
    from .utils import IS_PY26

    # Mock fake modules
    # prevent mock_open for preventing it to be removed by 2to3
    open_ = None
    try:
        from unittest.mock import patch, mock_open, call
    except ImportError:
        from mock import patch, mock_open, call
    else:
        open_ = open

    # Patch

# Generated at 2022-06-24 10:13:00.549953
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    """
    Test for method close of class tqdm_notebook:
        - verify that close do not raise exception
        - verify that it does not create side effects
    """
    from .autonotebook import tqdm
    from .std import tqdm as _tqdm
    t = tqdm([1, 2], 0)
    t.close()
    assert not t.disable, "tqdm_notebook should not be disabled after close"
    t = tqdm([1, 2], 0)  # recreate
    t.update()
    t.close()
    assert t.disable, "tqdm_notebook should be disabled after close"
    t = tqdm([1, 2], 0)  # recreate
    t.close()

# Generated at 2022-06-24 10:13:10.174206
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        import ipywidgets  # NOQA
    except ImportError:
        ipywidgets = None

    if ipywidgets is None:
        return

    # no disable
    with tqdm_notebook(desc="foo") as t:
        pass
    with tqdm_notebook(total=1, desc="foo") as t:
        t.display(close=True)
    try:
        with tqdm_notebook(disable=True, desc="foo") as t:
            pass
        assert False  # shouldn't get here
    except TqdmDeprecationWarning:
        pass
    # disable should still be deprecated but not raise TqdmDeprecationWarning
    with tqdm_notebook(disable=True, desc="foo") as t:
        pass

    # with disable
   

# Generated at 2022-06-24 10:13:20.618097
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=10) as t:
        # first print
        t.display(0)
        t.display(2)
        # test msg
        t.display(msg='msg')
        assert t.container.children[2].value == 'msg'
        # test pos
        t.display(pos=3)
        assert t.container.children[1].value == 3
        # test close
        t.display(close=True)
        assert not t.container.children[1].visible
        # test bar_style
        t.display(bar_style='danger')
        assert t.container.children[1].bar_style == 'danger'
        # test check_delay
        t.display(check_delay=True)
        assert t.displayed
        # test kwargs

# Generated at 2022-06-24 10:13:32.825966
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from copy import copy

    # test repr
    ch = tqdm_notebook(total=10, leave=True)
    hb = ch.container
    assert hb == hb.__repr__()  # repr is not empty (i.e. repr works)
    assert isinstance(hb.__repr__(), str)
    assert isinstance(hb._repr_json_(), dict)
    assert hb._repr_json_().keys() >= {'n', 'total', 'desc'}

    # test _repr_pretty_

# Generated at 2022-06-24 10:13:45.148216
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Test: __repr__
    # Test: _repr_pretty_
    t = TqdmHBox()
    t.pbar = tqdm_notebook(total=100)
    assert repr(t) == (
        '{desc}:   0%|          | 0/100 [00:00<?, ?it/s]{postfix}'
        .format(desc='', postfix=''))
    assert t._repr_pretty_() is None
    assert t._repr_json_() == {'total': 100, 'bar_format': '{l_bar}<bar/>{r_bar}',
                               'desc': '', 'postfix': []}

# Generated at 2022-06-24 10:13:59.548455
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import format_dict
    from .std import format_interval

    test_close = [True, False]
    for close in test_close:
        for _ in tqdm(range(5), desc="tqdm_notebook___iter__"):
            pass
        if close:
            break

    # Test total=None
    t = tqdm_notebook(ncols=None)
    t.last_print_n = None
    t.start_t = None
    t.last_print_t = None
    t.dynamic_ncols = True

    # Don't close automatically with `with` so we can test display()

# Generated at 2022-06-24 10:14:03.988797
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test -x option in tqdm."""
    from numpy.random import randn

    # Create a random array
    array = randn(40, 40)
    # Create a random target array with the same number of elements
    target = randn(array.size)

    for bar_style in ['info', 'success', 'danger']:
        with tqdm_notebook(total=1, bar_format="{bar_style}") as pbar:
            pbar.set_description(bar_style, refresh=False)
            pbar.display(bar_style=bar_style, check_delay=False)
            pbar.update(1)

# Generated at 2022-06-24 10:14:08.266697
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # type: () -> None
    from time import sleep
    for i in tqdm_notebook(range(5)):
        sleep(.5)

# Generated at 2022-06-24 10:14:18.542477
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    class dummy_tqdm(object):
        def __init__(self, bar_format=''):
            self.bar_format = bar_format

        def format_dict(self, *args, **kwargs):
            return {
                "n":        1,
                "total":    2,
                "avg":      3,
                "desc":     "bar_desc",
                "rate":     "{:.2f}",
                "rate_fmt": "4.20",
            }

        def format_meter(self, *args, **kwargs):
            return "format_meter"

    hbox = TqdmHBox(children=[])
    assert repr(hbox) == ''
    with pytest.raises(AttributeError):
        hbox.pbar.format_meter()

    hbox.p

# Generated at 2022-06-24 10:14:29.083232
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Clear progressbar first, then display an error style, then close.
    """
    from IPython.display import clear_output
    for cls in (tqdm_notebook, tqdm):
        pbar = cls(total=2, bar_format='{l_bar}{bar}|')
        clear_output()
        pbar.display(bar_style='danger')
        pbar.close()


if __name__ == "__main__":  # pragma: no cover
    if not IPY:
        raise RuntimeError(
            "No Jupyter/IPython environment detected, tqdm widgets cannot run.")
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:14:35.355625
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    for pretty in [None, False, True]:
        with suppress_std(level=1):
            hb = TqdmHBox()
            assert hb._repr_json_(pretty) == {}
            hb.pbar = tqdm(ascii=True, dynamic_ncols=True)
            print(hb)
            hb.pbar.close()

# Generated at 2022-06-24 10:14:36.950679
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    pass  # TODO: implement your test here



# Generated at 2022-06-24 10:14:43.660163
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    from unittest import TestCase
    from IPython.display import display

    class Test__repr__(TestCase):
        def test_simple(self):
            old_stdout = sys.stdout
            sys.stdout = StringIO()
            try:
                pbar = HBox(children=[IProgress(min=0, max=123), HTML(), HTML()])
                display(pbar)
                self.assertRegex(sys.stdout.getvalue(), r'^\r?\n?100%\|[#\|\+]{11}\|\s*\d{1,3}/123\s*$')
            finally:
                sys.stdout = old_stdout

# Generated at 2022-06-24 10:14:46.197100
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from IPython.core.display import HTML, display

    display(HTML(_repr_json_(TqdmHBox())))
    display(TqdmHBox())

# Generated at 2022-06-24 10:14:53.976847
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import FormatCustom
    from .cli import tqdm, TMonitor, TMonitorThread
    import time
    import re
    try:
        from thread import start_new_thread
    except ImportError:
        from _thread import start_new_thread
    try:
        from queue import Empty, Full
    except ImportError:
        from Queue import Empty, Full

    def _printer(gui=False):
        """
        Create a dummy tqdm instance (and dummy output device)
        """
        class _DummyOut(object):
            def write(self, _):
                pass

            def flush(self):
                pass
        out = _DummyOut()  # type: ignore

# Generated at 2022-06-24 10:14:58.226869
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_gui
    from tqdm._tqdm_gui import _range
    tqdm_gui.tqdm_gui(_range(3), desc='foobar', ncols=123)


if __name__ == "__main__":
    import unittest
    from tqdm._tqdm_gui_tests import TqdmGuiTest
    unittest.main(argv=[__file__, ])

# Generated at 2022-06-24 10:15:09.226929
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from .gui import trange, tgrange

    with trange(4) as t:
        assert isinstance(t, tqdm_notebook)
        for _ in t:
            pass

    with tgrange(4) as t:
        assert isinstance(t, tqdm_notebook)
        for _ in t:
            pass


# Test module
if __name__ == "__main__":  # pragma: no cover
    import pytest
    pytest.main([str(__file__.replace("\\", "/"))])

# Generated at 2022-06-24 10:15:11.952311
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time

    itr = tqdm_notebook(range(3))
    for _ in itr:
        itr.clear()
        time.sleep(0.2)

# Generated at 2022-06-24 10:15:20.044483
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    import time
    import types
    # hide `close` method in order not to display an output
    tqdm_notebook.close = types.MethodType(lambda s: None, tqdm_notebook)
    tpb = tqdm_notebook(total=5)
    # first display
    tpb.display()
    # clear bar if msg=''
    tpb.display(msg='')
    # change bar style
    tpb.display(bar_style='info')
    tpb.display(bar_style='success')
    tpb.display(bar_style='warning')
    tpb.display(bar_style='danger')
    # close the bar
    tpb.display(close=True)

# Generated at 2022-06-24 10:15:32.929875
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=DeprecationWarning)
        try:
            from IPython.display import clear_output
        except ImportError:
            return  # No display: no test

        try:  # notebook
            is_notebook = bool(get_ipython())
        except NameError:  # No IPython: no test
            return
        else:
            if not is_notebook:
                return  # No Jupyter: no test

        pbar = tqdm_notebook(total=4)
        for i in range(4):
            pbar.update()
        pbar.close()
        clear_output()
        pbar = tqdm_notebook(total=4)

# Generated at 2022-06-24 10:15:44.214682
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML as HTML_, display as display_
    HTML = HTML_
    display = display_
    import json
    from datetime import date

    # Class to test
    from .notebook import status_printer as test_status_printer

    # Test 1
    test_description = "test 1"
    test_total = 10
    # Args
    args = [sys.stderr, test_total, test_description]
    # Kwargs
    kwargs = {}
    # Call function
    ret = test_status_printer(*args, **kwargs)
    # Check type
    assert isinstance(ret, TqdmHBox)
    # Check children
    assert len(ret.children) == 3
    # Check first child
    assert isinstance(ret.children[0], HTML)


# Generated at 2022-06-24 10:15:50.511635
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from tqdm import tqdm_notebook
    for i in tqdm_notebook(range(100)):
        i
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            pbar.update(1)


if __name__ == '__main__':  # pragma: no cover
    # test_tqdm_notebook()
    pass

# Generated at 2022-06-24 10:15:55.616834
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test clear method of class tqdm_notebook"""
    with tqdm_notebook(total=10, disable=False) as pbar:
        for i in range(5):
            pbar.clear()
            pbar.update(1)



# Generated at 2022-06-24 10:15:58.564544
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm_notebook(total=100, desc='Testing __repr__')
    t.container.pbar._repr_json_()
    t.container.pbar._repr_pretty_()

# Generated at 2022-06-24 10:16:08.684549
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from unittest.mock import Mock
        assert Mock  # silence pyflakes
    except ImportError:
        from mock import Mock

    class fake_stdout:
        write = Mock()  # for python 2: mock.Mock(side_effect=lambda x: None)
        def flush(self):
            self.write.reset_mock()

    io = fake_stdout()
    if hasattr(sys, 'stdout'):
        orig_stdout = sys.stdout
    sys.stdout = io

# Generated at 2022-06-24 10:16:15.565866
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        iterable = range(5)
        total = len(iterable)
        desc = "Iteration test"
        ncols = None
        t = tqdm_notebook(iterable, total=total, desc=desc, ncols=ncols, leave=False)
        _sum = 0
        for i in t:
            _sum += i
        assert _sum == sum(iterable)
        assert t.n == total
    finally:
        t.close()



# Generated at 2022-06-24 10:16:25.392208
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm import _tqdm_notebook
    from tqdm import _tqdm
    from tqdm import __version__

    # Test ipywidgets
    __version__
    _tqdm_notebook()
    _tqdm_notebook(ncols=100)
    _tqdm_notebook(ncols="100px")
    _tqdm_notebook(ncols="100%")
    _tqdm_notebook(ncols=None)

    # Test direct call
    tqdm_notebook()
    tqdm_notebook(ncols=100)
    tqdm_notebook(ncols="100px")
    tqdm_notebook(ncols="100%")

# Generated at 2022-06-24 10:16:31.785227
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stderr
    from time import sleep

    with tqdm_notebook(total=1, file=stderr) as pbar:
        pbar.display()
        pbar.display("Current")  # test msg
        pbar.display("Current", bar_style='info')
        pbar.display("Done", bar_style='success')

    with tqdm_notebook(total=1, file=stderr) as pbar:
        pbar.display(close=True)

    with tqdm_notebook(total=1, file=stderr) as pbar:
        pbar.update(0)
        pbar.display()
        pbar.update()
        sleep(.01)
        pbar.display("Current")
        pbar.update()

# Generated at 2022-06-24 10:16:40.445490
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import json

    def _check(box, repr_json, repr_pretty=None, repr_str=None, repr_repr=None):
        assert json.loads(json.dumps(box._repr_json_())) == repr_json
        assert box._repr_pretty_({}).text == repr_pretty or repr_pretty is None
        assert box.__repr__() == repr_str or repr_str is None
        assert box.__repr__(True) == repr_repr or repr_repr is None

    pbar = tqdm_notebook(total=20)
    pbar.n = 10
    pbar.desc = "Test progress bar"
    pbar.refresh()
    box = TqdmHBox(children=[HTML(), pbar._gui_impl.pbar, HTML()])


# Generated at 2022-06-24 10:16:47.635568
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import random
    tries = 0
    for i in tqdm_notebook(range(100), desc="1st loop"):
        for j in tqdm_notebook(range(5), desc="2nd loop", leave=False):
            for k in tqdm_notebook(range(50), desc="3rd loop", leave=True):
                tries += 1
                val = random()
                if val > 0.5:
                    break
            if val > 0.75:
                break
        if val > 0.95:
            break
    assert tries == 13

# Generated at 2022-06-24 10:16:50.747453
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    with pytest.raises((TypeError, NameError)):
        tqdm_notebook().clear()

# Generated at 2022-06-24 10:16:58.723303
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test that if an exception is raised in a loop, the progress bar is still closed
    with tqdm_notebook(iterable=["a", "b", "c"], total=None) as t:
        for i, j in enumerate(t):
            if j == "b":
                raise ValueError
        try:
            del i
        except NameError:
            pass

if __name__ == "__main__":
    from nose.tools import assert_equal
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:17:10.093864
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .utils import _range
    from .std import tqdm
    from .std import TMonitor
    try:
        tnrange = tqdm_notebook
    except:
        return
    tn = tnrange(10, monitor=TMonitor())
    tn.displayed = True
    tn.ncols = "75%"
    tn.total = 100
    tn.leave = False
    tn.ascii = True
    # with bar
    assert 'class' in tn._repr_html_().lower()
    assert 'class' not in tn.format_meter().lower()
    # no bar
    tn.ncols = None
    assert 'class' not in tn._repr_html_().lower()
    assert 'class' in tn.format_meter().lower

# Generated at 2022-06-24 10:17:19.928829
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Runs method display with different parameters.
    """
    tqdm.clear(wait=True)  # Clear output for testing
    for i in _range(4):
        tqdm.write("%s test" % ('=' * (1 + i)))
    for pos in ['right', 'none', 'center']:
        for i in _range(4):
            tqdm.write("%s test %s" % ('=' * (1 + i), pos))
    # Test clearing
    for i in trange(3, desc="Testing clearing", leave=True):
        for j in _range(4):
            tqdm.write("%s test %d" % ('=' * (1 + j), i))
        tqdm.clear()


# Generated at 2022-06-24 10:17:22.455027
# Unit test for function tnrange
def test_tnrange():
    from .gui import tnrange, trange
    import time
    for _ in tnrange(2):
        for _ in tnrange(4):
            for _ in trange(6):
                time.sleep(.05)

# Generated at 2022-06-24 10:17:28.793029
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=3) as t:
        for _ in _range(3):
            t.update()


if __name__ == '__main__':
    # test_tqdm_notebook()
    from time import sleep
    with tqdm_notebook(total=50) as t:
        for k in _range(50):
            sleep(.1)
            t.update()

# Generated at 2022-06-24 10:17:33.691986
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=10) as t:
        for i in range(20):
            t.update()
            if i >= 20:
                break
    assert t.n == 10
    assert t.container.pbar.bar_style == 'danger'
    t.close()

# Generated at 2022-06-24 10:17:37.643436
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    "Unit test for method __repr__ of class TqdmHBox"
    t = tqdm_notebook(0)
    assert str(t) == str(t.container)
    t.close()
    assert str(t) == str(t.container)


# Generated at 2022-06-24 10:17:49.469838
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import io
    try:
        import unittest.mock as mock
    except ImportError:
        import mock
    import sys
    import tqdm.notebook

    # Redirect output to stdout
    sys.stdout = io.StringIO()
    with mock.patch('IPython.display.clear_output'):
        for manual in tqdm.autonotebook.MANUAL_CLOSE, []:
            for total in [None, 100]:
                for leave in [False, True]:
                    with tqdm.notebook.tqdm(total=total, leave=leave,
                                            manual=manual) as pbar:
                        pbar.update(31)
                        msg = pbar.format_dict
                        assert msg['bar']
                        assert pbar.ncols == '100%'
                        pbar

# Generated at 2022-06-24 10:17:55.497056
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # tqdm.notebook.tqdm(..., leave=True)  # leave mode
    with tqdm_notebook(total=4, leave=True) as t:
    #               ^----- display(t.container); use `with` statement
        for i in _range(4):
            t.update(1)
        t.display()  # update bar manually
    # tqdm.notebook.tqdm(..., leave=False)  # standard mode
    with tqdm_notebook(total=4) as t:  # leave mode
        for i in _range(4):
            t.update(1)
            t.display()  # update bar manually

# Generated at 2022-06-24 10:18:06.337974
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from nose.tools import raises

    # Testing function status_printer
    test_status_printer = tqdm_notebook.status_printer

    # Test for integer input
    assert test_status_printer(None, total=10) is not None
    assert test_status_printer(None, total=10).max == 10
    assert isinstance(test_status_printer(None, total=10).value, int)

    # Test for float input
    assert test_status_printer(None, total=10.0) is not None
    assert test_status_printer(None, total=10.0).max == 10.0
    assert isinstance(test_status_printer(None, total=10.0).value, float)

    # Test for negative integer input
    with raises(ValueError):
        test

# Generated at 2022-06-24 10:18:12.696472
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    if IPY <= 0:
        return False

    fp = sys.stderr
    total = 7
    desc = 'testing'
    ncols = 100
    pbar = IProgress(min=0, max=total)
    ltext = HTML()
    rtext = HTML()
    if desc:
        ltext.value = desc
    container = TqdmHBox(children=[ltext, pbar, rtext])
    # Prepare layout
    if ncols is not None:  # use default style of ipywidgets
        # ncols could be 100, "100px", "100%"
        ncols = str(ncols)  # ipywidgets only accepts string

# Generated at 2022-06-24 10:18:24.179078
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(unit='unit') as t:
        assert isinstance(t, tqdm_notebook)  # class
        assert t.disable == False  # gui mode

    with tqdm_notebook(disable=True) as t:
        assert t.disable == True  # terminal mode

    with tqdm_notebook(unit='unit', disable=False) as t:
        assert t.disable == False  # gui mode

    with tqdm_notebook(unit='unit', disable=True) as t:
        assert t.disable == True  # terminal mode

    with tqdm_notebook(
            desc='foo', unit='unit', disable=False, colour='r', ncols=200) as t:
        assert t.disable == False  # gui mode


# Generated at 2022-06-24 10:18:26.291545
# Unit test for function tnrange
def test_tnrange():
    assert sum(tnrange(5)) == 10
    assert sum(tqdm(range(5))) == 10
    assert sum(trange(5)) == 10

# Generated at 2022-06-24 10:18:36.299986
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook.

    Tests:
    + t_close (closed)
    + t_close (not closed)
    + t_bar_style (success)
    + t_bar_style (info)
    + t_bar_style (warning)
    + t_bar_style (danger)
    + t_bar_style (reset)
    + t_bar_style (retain danger)
    + t_clear
    """
    from .utils import _supports_unicode, _decode
    import time

    if not hasattr(tqdm_notebook, 'container'):
        print("tqdm_notebook.container does not exist, skipping test.")
        return


# Generated at 2022-06-24 10:18:45.051717
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test for tqdm_notebook status_printer method"""
    from .utils import _term_move_up

    # pylint: disable=protected-access
    # get some arguments
    total = 60
    desc = 'testing'
    ncols = '100%'
    # initialize test
    with std_tqdm(total=total, desc=desc, ncols=ncols) as pbar:
        pbar.status_printer(pbar.fp, total, desc, ncols)
        pbar.update()
        display(pbar.container)
        stdout = sys.stdout
        # prepare the bar to display on screen
        stdout.write(pbar._format_meter())
        stdout.flush()
        # the bar is displayed, now we have to erase it
        stdout

# Generated at 2022-06-24 10:18:50.211720
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        tqdm_notebook
    except NameError:
        return
    with tqdm_notebook(total=3) as bar:
        assert bar.displayed
        assert bar.container.children[1].bar_style == ''
        # Test resetting the bar
        bar.reset()
        assert not bar.displayed
        assert bar.container.children[1].bar_style == ''
        # Test updating the bar
        bar.update()
        assert bar.displayed
        assert bar.container.children[1].bar_style == ''
        # Test closing the bar
        bar.close()
        assert not bar.displayed
        assert bar.container.children[1].bar_style == 'success'
        # Test closing the bar in case of error
        bar.reset()
        bar.display()

# Generated at 2022-06-24 10:18:52.558182
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test of TqdmHBox.__repr__"""
    rep = TqdmHBox.__repr__(TqdmHBox())
    assert 'HBox' in rep
    assert 'FloatProgress' in rep
    assert 'HTML' in rep



# Generated at 2022-06-24 10:18:54.896233
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # with default parameters
    assert str(tqdm_notebook()) == ": : : 0it [00:00, ?it/s]"

if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:19:06.078258
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal, assert_raises, assert_regexp_matches

    class DummyTqdmNotebook(tqdm_notebook):
        def __init__(self, *args, **kwargs):
            super(DummyTqdmNotebook, self).__init__(*args, **kwargs)
            # the following line is to bypass the __init__ of tqdm_notebook
            self._instances = []

    # Test initialisation
    t = DummyTqdmNotebook(ncols="10%", desc="Description")
    assert_regexp_matches(str(t.container.layout), "width:10%")
    assert_equal(t.container.children[0].value, "Description")
    t.disp()

# Generated at 2022-06-24 10:19:14.675918
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(ascii=True, desc='1st loop') as t:
        for i in t:
            if i == 5:
                break
    assert t.n == 6
    assert not hasattr(t, 'unit_scale')

    with tqdm_notebook(5, ascii=True, desc='2nd loop') as t:
        for i in t:  # length=5, so print_freq=1
            if i == 2:
                t.set_description("foo")
            elif i == 3:
                t.set_postfix(ordered_dict=dict(a=1, b=2), refresh=False)
            elif i == 4:
                t.set_postfix(ordered_dict=dict(a=1, b=2), refresh=True)

   

# Generated at 2022-06-24 10:19:24.526184
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import ipywidgets
    from IPython.display import clear_output
    from IPython.core.display import display
    from time import sleep
    import sys

    bar = tqdm_notebook(total=None, unit='B', unit_scale=True, leave=False)

    assert isinstance(bar.container, ipywidgets.widgets.widget_container.HBox)
    assert isinstance(bar.container.children[1], ipywidgets.widgets.widget_float.FloatProgress)
    assert isinstance(bar.container.children[1], ipywidgets.widgets.widget_float.FloatProgress)
    assert bar.container.children[1].value == 0

    bar.update(200)
    assert bar.container.children[1].value == 200


# Generated at 2022-06-24 10:19:26.869619
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(unit='', total=5) as bar:
        bar.clear()
        bar.write("ABC")

# Generated at 2022-06-24 10:19:38.149589
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython import get_ipython
        has_ipython = True
    except ImportError:
        has_ipython = False
    if has_ipython:
        ip = get_ipython()
        ip.extension_manager.load_extension("autoreload")
        ip.extension_manager.load_extension("autosavetime")
    t = tqdm(total=1)
    t.update()
    t.close()
    # test error handling
    t = tqdm(total=1)
    t.update(2)
    t.close()
    # test keyboard interrupt
    t = tqdm(total=1)
    t.update(1)
    t.close()

# Generated at 2022-06-24 10:19:47.977061
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.utils import _term_move_up

    with tqdm(total=10, desc="Displaying") as pbar:
        pbar.clear()
        assert pbar.n == 0
        for i in range(10):
            sleep(0.1)
            pbar.update()

    with tqdm(total=10) as pbar:
        pbar.clear(nolock=False)
        assert pbar.n == 0
        with pbar.container.output:
            # Assert order
            assert pbar.n == 0
            assert pbar.container.children[-2].value == ''
            pbar.clear(nolock=True)
            assert pbar.n == 0
            assert pbar.container.children[-2].value == _term_move

# Generated at 2022-06-24 10:19:50.750038
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    tp = tqdm_notebook(total=10)
    for i in tp:
        sleep(0.1)
        if i == 3:
            tp.reset(total=100)
    tp.close()

# Generated at 2022-06-24 10:19:52.759756
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook() as t:
        t.clear()



# Generated at 2022-06-24 10:19:57.074163
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            pbar.clear(True)
            time.sleep(0.5)
    pass

# Generated at 2022-06-24 10:20:02.918976
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert tqdm_notebook.status_printer(sys.stderr) is not None
    assert tqdm_notebook.status_printer(sys.stderr, total=1) is not None
    assert tqdm_notebook.status_printer(
        sys.stderr, total=2, desc="TESTING") is not None

# Generated at 2022-06-24 10:20:13.075960
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # create test instance
    from tqdm.utils import _term_move_up
    # create a test tqdm instance
    t = tqdm_notebook(total=10, file=None)
    bar = t.status_printer(None)
    # test results
    for pretty in [True, False]:
        # use tqdm update method to print progress
        for i in tqdm(_range(10)):
            t.update()
        # get printed progressbar
        output = bar.__repr__(pretty)
        # check if we go back to line 0
        assert t.last_print_n == 0
        # check if printed output is not None
        assert output is not None
        # check if printed output is a string
        assert isinstance(output, str)
        # check if bar is printed
       

# Generated at 2022-06-24 10:20:22.484955
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test method status_printer of class tqdm_notebook.
    """
    from tqdm._utils import _term_move_up
    from tqdm._version import __version__
    from unittest import TestCase
    import sys

    class TqdmNotebookStatusPrinterTest(TestCase):
        # pylint: disable=too-many-locals
        """ Test method status_printer of class tqdm_notebook."""

        def setUp(self):
            """ Setup for test_tqdm_notebook_status_printer test case."""
            self.get_ipython = get_ipython
            self.fp = sys.stderr
            self.ncols = 10
            self.update = tqdm._tqdm.tqdm_gui.update
            self

# Generated at 2022-06-24 10:20:30.536253
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class `tqdm_notebook`.
    """
    from .tests import BaseTestClass

    class Test(BaseTestClass):
        def test_tqdm_notebook_class(self):
            with tqdm_notebook(total=10, desc='test') as t:
                for i in range(10):
                    t.update()
            t.close()
            self.assertEqual(t.total, 10)
            # check broken iterator
            t = tqdm_notebook(total=10, desc='test')
            for i in range(10):
                t.update()
            with self.assertRaises(Exception):
                for i in range(10):
                    t.update()
            t.close()
            if self.remove_chars:
                self.assertE

# Generated at 2022-06-24 10:20:38.068469
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Create a tqdm bar instance
    pbar = tqdm_notebook(unit="test", total=5)

    # Increment the bar
    for i in range(4):
        pbar.update()

    # Force the display of the bar
    # (only one bar is displayed at a time)
    display(pbar.container)

    # Close the bar
    pbar.close()

    # Check if the progress bar widget has been closed
    pbar_closed = pbar.container.layout.visibility == 'hidden'
    assert pbar_closed is True


# Generated at 2022-06-24 10:20:43.322257
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """ Unit test for class tqdm_notebook method clear """
    from nose.tools import assert_equal
    import time
    from .gui import tnrange

    try:
        with tnrange(10) as t:
            time.sleep(1)
    except:  # NOQA
        assert_equal(t.n, 10)



# Generated at 2022-06-24 10:20:50.191497
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython import get_ipython
    try:  # Tested on Jupyter Notebook
        ip = get_ipython()
        if not ip:
            raise ImportError("Ipython not found")
    except ImportError:
        raise RuntimeError("Only tested on jupyter notebook")
    a = tqdm_notebook(total=3)
    a.update()
    a.update()
    a.update()
    a.update()
    a.close()
    assert a.n == 3



# Generated at 2022-06-24 10:20:54.053833
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from unittest import TestCase
    from .gui import tqdm
    from .std import tqdm as tqdm_cli
    class TqdmClearTests(TestCase):
        def test_clear_tqdm_notebook_bar(self):
            tqdm.clear('test')

# Generated at 2022-06-24 10:21:03.635879
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    import os
    import sys
    import atexit  # will be called at exit of the script
    import time  # to wait for the progress bar to finish showing

    # clear current progress bars if any
    try:
        if IPY >= 3:
            from IPython import get_ipython
            get_ipython().history_manager.reset()
        else:
            # IPython 2.x
            from IPython.frontend.terminal import ipapp
            ipapp.terminal_app.clear_history()
    except NameError:
        pass

    bar_widths = [30, "250px", "50%"]

# Generated at 2022-06-24 10:21:10.608219
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    for _ in tqdm_notebook([1, 2, 3, 4], desc='1st loop'):
        for _ in tqdm_notebook([1, 2, 3, 4], desc='2nd loop', leave=False):
            for _ in tqdm_notebook([1, 2, 3, 4], desc='3nd loop',
                                   leave=False, ncols='100%'):
                sleep(0.01)
        sleep(0.01)

# Generated at 2022-06-24 10:21:12.926959
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test that tqdm_notebook has the method clear.
    """
    test = tqdm_notebook(range(100))
    test.clear()

# Generated at 2022-06-24 10:21:15.733040
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    class A(object):
        pass
    obj = A()
    obj.__iter__ = lambda x: iter(xrange(10))
    for i in tqdm_notebook(obj):
        assert i in range(10)



# Generated at 2022-06-24 10:21:23.863964
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import pytest
    from multiprocessing import Pool, TimeoutError
    try:
        p = Pool()
        # to be pickable and not hang on Windows
        f = lambda x: sum(tqdm_notebook(_range(x), leave=True))
        p.apply_async(f, [100])
        with pytest.raises(TimeoutError):
            p.apply_async(f, [100]).get(timeout=0.01)
        p.close()
    except ImportError:
        pass

# Generated at 2022-06-24 10:21:34.502893
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        from unittest.mock import Mock
    except ImportError:
        from mock import Mock

    display = Mock()
    t = tqdm_notebook(total=5, miniters=1, mininterval=0, display=display)
    del t  # noqa: F841
    assert display.call_count == 1, 'init should call display'

    display = Mock()
    t = tqdm_notebook(total=5, miniters=1, mininterval=0, display=display)
    t.update(0)
    t.close()
    assert display.call_count == 2, 'update + close should call display'

    display = Mock()
    t = tqdm_notebook(total=5, miniters=1, mininterval=0, display=display)

# Generated at 2022-06-24 10:21:40.506309
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    for i in tqdm_notebook(range(10)):
        pass


if __name__ == '__main__':  # pragma: no cover
    from time import sleep

    with tqdm_notebook(total=100, leave=True) as t:
        for i in range(3):
            for j in tqdm_notebook(range(20), total=20,
                                   desc='{0}th inner loop'.format(i)):
                sleep(0.01)
                t.update()

# Generated at 2022-06-24 10:21:51.278263
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        from IPython.core.display import clear_output
    except:  # NOQA: F821
        from IPython.display import clear_output

    t = tqdm_notebook(total=5)
    for i in range(5):
        t.update()

    t.reset(total=3)
    for i in range(3):
        t.update()

    try:
        clear_output(wait=1)
    except NameError:
        pass

    t.reset(total=8)
    for i in range(7):
        t.update()

    try:
        clear_output(wait=1)
    except NameError:
        pass

    t.reset(total=8)
    for i in range(7):
        t.update()
    t.reset()

   

# Generated at 2022-06-24 10:22:00.653060
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    # Avoid printing tnrange()
    def close(self):
        pass

    with tqdm_notebook(total=1, desc='tnrange') as t:
        t.update()
        t.close = close
        import IPython
        if IPY == 4:
            if IPython.__version__ < '4.2.2':
                # https://github.com/jupyter/notebook/pull/1038
                sys.stderr.write('\rWarning: tqdm requires Jupyter >= 4.2.2\n')

# Generated at 2022-06-24 10:22:05.967400
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    for __ in tnrange(4, desc='1st loop', leave=True):
        for __ in tnrange(int(2e2), desc='2nd loop', leave=True, unit='it'):  # NOQA
            pass
        assert 1 == 1, 'fail'

# Generated at 2022-06-24 10:22:15.016305
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Reset without total (total set to None)
    for i in _range(10):
        t = tqdm_notebook(total=i+1, mininterval=0, miniters=1, leave=True)
        for _ in t:
            pass
        if not t.n == t.total:  # Exception in manual mode
            raise Exception("Not equal: n: {} - total: {}".format(t.n, t.total))
        t.reset()

    # Reset with total
    for i in _range(10):
        t = tqdm_notebook(total=i+1, mininterval=0, miniters=1, leave=True)
        for _ in t:
            pass

# Generated at 2022-06-24 10:22:21.628107
# Unit test for function tnrange
def test_tnrange():
    from .utils import FormatCustomizeTest
    assert list(tqdm_notebook([])) == []
    for i, j in enumerate(tnrange(4, 7)):
        assert j == i + 4
        tqdm.write(str(j))
    assert i == 2


if __name__ == '__main__':
    try:
        assert sys.version_info[0] == 2
    except AssertionError:
        # unit test only works on IPY-2.7
        sys.exit(0)

    import doctest
    print("doctest: %s" % doctest.testmod())
    print("unit test: %s" % test_tnrange())

# Generated at 2022-06-24 10:22:32.893890
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook constructor.
    """
    if IPY == 0:
        return
    try:
        import time  # import time after IPython as it may need it
    except ImportError:
        return
    from .gui.utils import _term_move_up
    from .utils import _term_width
    t = tqdm_notebook(total=100, leave=False, position=0)
    for i in t:
        if i > 10:
            t.close()
            break
        time.sleep(0.01)
        t.update()
    assert not t.container.children[-2].is_hidden()  # #872