

# Generated at 2022-06-24 10:12:26.945782
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep

    with tqdm_notebook(total=5, leave=False) as t:
        for i in range(5):
            sleep(0.4)
            t.update()
    assert t.disable

# Generated at 2022-06-24 10:12:37.225204
# Unit test for function tnrange
def test_tnrange():  # pragma: no cover
    from time import sleep
    with tnrange(3) as t:
        for i in t:
            sleep(0.01)
        assert len(t) == 3
        t.clear()
        for i in t:
            assert len(t) == 3
            sleep(0.01)
        t.reset()
        for i in t:
            assert len(t) == 3
            sleep(0.01)
        assert len(t) == 3
    with tnrange(3) as t:
        [sleep(0.01) for i in t]
    with tnrange(3) as t:
        list(tqdm(i for i in range(3)))
    with tnrange(3) as t:
        list(tqdm(i for i in range(3)))

# Generated at 2022-06-24 10:12:39.586003
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from nose.tools import assert_equal
    hbox = tqdm_notebook(total=10)
    assert_equal(repr(hbox), hbox._repr_json_(pretty=True))



# Generated at 2022-06-24 10:12:50.013099
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from os import remove, getcwd, chdir
    from os.path import join
    import sys

    # Get an unique directory, then move to it
    if sys.version_info[0] >= 3:
        from tempfile import TemporaryDirectory
        with TemporaryDirectory() as tmpdir:
            chdir(tmpdir)
    else:
        import tempfile
        tmpdir = tempfile.mkdtemp()
        chdir(tmpdir)

    file1 = join('.ipynb_checkpoints', 'test.txt')
    with open(file1, 'w') as f:
        print('test1', file=f)

    file2 = join('test.txt')
    with open(file2, 'w') as f:
        print('test2', file=f)

    # Try to load the checkpoint file

# Generated at 2022-06-24 10:12:59.091620
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    if sys.version_info[0] == 2:
        from StringIO import StringIO
    else:
        from io import StringIO
    pbar = tqdm_notebook.status_printer(StringIO(), total=1)
    assert isinstance(pbar.children[0], HTML)
    assert isinstance(pbar.children[1], IProgress)
    assert isinstance(pbar.children[2], HTML)

# Generated at 2022-06-24 10:13:06.168068
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook(
        [1, 2, 3],
        desc='Test',
        leave=True,
        file=None,
    ):
        pass
    for _ in tqdm_notebook(
        [1, 2, 3],
        desc='Test',
        leave=True,
        file=None,
    ):
        raise StopIteration()
    for _ in tqdm_notebook(
        [1, 2, 3],
        desc='Test',
        leave=True,
        file=None,
    ):
        raise ValueError()

# Generated at 2022-06-24 10:13:09.818690
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    iterable = tqdm(_range(10))
    # iterate once
    for _ in iterable:
        pass

    iterable.reset()
    # iterate again
    for _ in iterable:
        pass

# Generated at 2022-06-24 10:13:17.312733
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from .std import format_sizeof

    bar = TqdmHBox()
    bar.pbar = tqdm_notebook(total=127, smoothing=0)
    bar.pbar.update(64)
    assert bar.pbar.format_dict['smoothing'] == 0
    assert format_sizeof(bar.pbar.format_dict['max']) == "127"
    assert format_sizeof(bar.pbar.format_dict['n']) == "64"
    assert format_sizeof(bar.pbar.format_dict['smoothing']) == "0"
    assert format_sizeof(bar.pbar.format_dict['rate']) == "0"
    assert bar.pbar.format_dict['bar_format'] == "{l_bar}{bar}{r_bar}"
   

# Generated at 2022-06-24 10:13:24.186759
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # use trange for testing class TqdmHBox
    import tqdm.notebook as notebook
    notebook.tqdm_notebook = notebook.tqdm_notebook
    with notebook.tqdm_notebook(total=2) as pbar:
        # should be str
        repr(pbar.container)
        # should be the same result
        pbar.container.__repr__()



# Generated at 2022-06-24 10:13:35.970098
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.auto import tqdm

    with tqdm(total=10, miniters=0, postfix={'foo': 1}) as pbar:
        assert hasattr(pbar, 'container')
        assert pbar.n < pbar.total

        pbar.reset(total=20)
        assert pbar.n == 0
        assert pbar.total == 20

        pbar.reset(total=100)
        assert pbar.n == 0
        assert pbar.total == 100

        pbar.reset(total=5)
        assert pbar.n == 0
        assert pbar.total == 5

        pbar.reset(total=30)
        assert pbar.n == 0
        assert pbar.total == 30

        pbar.reset(total=30)

# Generated at 2022-06-24 10:13:40.101276
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=4) as bar:
        for i in _range(4):
            if i > 1:
                bar.reset(total=2)
            bar.update()

# Generated at 2022-06-24 10:13:47.952451
# Unit test for function tnrange
def test_tnrange():
    from IPython import get_ipython
    _, _, start_ns = get_ipython().history_manager.get_tail(1)[0]

    list(tnrange(3))
    try:
        _, _, end_ns = get_ipython().history_manager.get_tail(1)[0]
        assert start_ns != end_ns
    except:
        pass


test_tnrange()

# Generated at 2022-06-24 10:13:55.738876
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase, main
    class Test_tqdm_notebook_display(TestCase):
        def test_display(self):
            tn = tqdm_notebook(total=100)
            tn.display()
            # test msg='' (should not clear the bar)
            tn.display(msg='')
            # test bar_style
            tn.display(bar_style='danger', msg='I got danger style')
            # test close
            tn.display(close=True)
            tn.close()
    main(exit=False)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:14:02.240449
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Unit test for method status_printer of class tqdm_notebook"""
    d = {
        'bar_format': '{bar}|{n_fmt}/{total_fmt}',
        'desc': 'Testing status_printer',
        'desc_postfix': 'postfix',
        'desc_pre': 'pre',
        'n': 17,
        'total': 100
    }
    res = tqdm_notebook.status_printer(None, total=100)
    assert isinstance(res, TqdmHBox)
    assert len(res.children) == 3

    res.pbar.format_dict = d

    # method repr_json_()
    assert res._repr_json_() == d
    assert res._repr_json_(pretty=True) == d

   

# Generated at 2022-06-24 10:14:07.693681
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    import re

    def _test(total, **kwargs):
        max_ = total  # define this variable to make sure that total variable is not changed
        hbox = tqdm_notebook.status_printer(total=total, **kwargs)
        assert hbox.layout.width == kwargs.get("ncols", "100%"), "Layout width should be ncols"
        assert len(hbox.children) == 3, "HBox should contain 3 elements"
        assert re.findall("/\|?\d+\.?\d*%\|?<", hbox.children[1].description) == [], \
            "Desc should not be displayed with 'bar_style = info'"

# Generated at 2022-06-24 10:14:17.982046
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test for tqdm_notebook__iter__()
    import random
    n = random.randint(1, 100)
    with tqdm_notebook(total=n) as pbar:
        for i in pbar:
            pass


if __name__ == "__main__":
    # Test for tqdm_notebook()
    from .utils import _write, _read, _term_move_up
    with tqdm_notebook(total=4) as pbar:
        for i in range(4):
            pbar.update()
    with tqdm_notebook(total=4, desc='desc') as pbar:
        for i in range(4):
            pbar.update()

# Generated at 2022-06-24 10:14:26.301891
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # No total
    print('Testing no total')
    for ncols in [None, "100", 100, "100px", "100%"]:
        container = tqdm_notebook.status_printer(None,
                                                 total=None,
                                                 desc='test',
                                                 ncols=ncols)
        print(container)
    print('Testing total')
    for ncols in [None, "100", 100, "100px", "100%"]:
        container = tqdm_notebook.status_printer(None,
                                                 total=100,
                                                 desc='test',
                                                 ncols=ncols)
        print(container)
        container.close()



# Generated at 2022-06-24 10:14:39.457409
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # IPython >= 5.0
    try:
        from IPython import get_ipython
        ipython = get_ipython()
        ipython.enable_matplotlib(gui='inline')
    except ImportError:
        pass

    # IPython >= 4.0
    try:
        from IPython import get_ipython
        ipython = get_ipython()
        try:
            ipython.get_ipython()
        except AttributeError:
            raise ImportError()
        else:
            try:
                # ipython.enable_matplotlib('inline')
                get_ipython().enable_matplotlib('inline')
            except AttributeError:
                pass
    except (ImportError, AttributeError):
        pass


# Generated at 2022-06-24 10:14:46.286463
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    import random
    msg = "Starting ... "
    with tqdm_notebook(desc=msg) as t:
        t.display(check_delay=False)
        t.update(20)
        time.sleep(0.5)
        t.update(40)
        time.sleep(0.1)
        if random.randint(0, 100) != 50:
            # if not getting unlucky, raise an error to highlight
            # the bar's foreground and background
            raise Exception
    print(msg)

# Generated at 2022-06-24 10:14:54.030516
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tqdm_gui
    from .std import tqdm
    from .utils import format_sizeof
    from time import sleep

    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = False  # NOQA

    # Check if IPython is installed
    if IPY is False:
        return

    # Test tqdm_notebook class
    with tqdm_notebook(total=100, desc='test') as pbar:
        pbar.update()
        pbar.set_postfix({'post': 'fix'})
        sleep(0.1)
        # Check auto-closing of the bar
        pbar.close()

# Generated at 2022-06-24 10:14:56.199909
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm(total=10)
    assert isinstance(t, TqdmHBox)
    assert repr(t).startswith('\r|0/10 [')
    t.update(1)
    assert repr(t).startswith('\r|1/10 [')
    t.close()

# Generated at 2022-06-24 10:14:59.534342
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    with tqdm_notebook(total=5) as t:
        for i in range(5):
            t.update()
            time.sleep(0.5)
            if i % 2 == 0:
                t.reset()
                time.sleep(0.5)
    assert t.total == 5

# Generated at 2022-06-24 10:15:03.367159
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    container = TqdmHBox()

# Generated at 2022-06-24 10:15:14.097173
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.utils.capture import capture_output
    import io

    with capture_output() as captured:
        with tqdm_notebook(total=2, leave=True) as pbar:
            pbar.update()
            pbar.update()
    assert captured.stdout.getvalue() == """|#                                                                                            | 0/2 [00:00<?, ?it/s]"""

    with capture_output() as captured:
        with tqdm_notebook(total=2) as pbar:
            pbar.update()
            pbar.update()
    assert captured.stdout.getvalue() == """|#                                                                                            | 0/2 [00:00<?, ?it/s]"""

    fobj = io.StringIO()

# Generated at 2022-06-24 10:15:18.036561
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = tqdm_notebook(total=100)
    # formatting
    assert isinstance(pbar, TqdmHBox)
    assert isinstance(pbar.container, TqdmHBox)
    assert repr(pbar) == repr(pbar.container)
    # repr
    assert repr(pbar) == pbar.format_meter()
    # pretty
    assert pbar.__repr__(True) == pbar.format_meter(ascii=True)

# Generated at 2022-06-24 10:15:23.874057
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm(total=1) as t:
        t.close()  # no error should be raised


# Clean up namespace.
del absolute_import, division, print_function, unicode_literals
del re, sys

# Generated at 2022-06-24 10:15:34.342660
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test exception handling
    try:
        with tqdm_notebook(total=3) as pbar:
            pbar.update()
            pbar.update()
            pbar.update()
            # should not raise/exceed max value
            pbar.update(total=1)
        assert False, "should raise"
    except Exception:
        pass
    try:
        with tqdm_notebook(total=3) as pbar:
            pbar.update()
            1 / 0
    except Exception:
        pass  # can raise

    # Test normal use
    with tqdm_notebook(total=3) as pbar:
        assert pbar.container.children[0].value == '  0%|'
        pbar.update()

# Generated at 2022-06-24 10:15:41.919327
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Test pretty repr
    class Bar(TqdmHBox):
        def _repr_json_(self, pretty=True):
            return {'bar': 'baz', 'ascii': 'foo'}
    for pretty in [False, True]:
        x = Bar()
        assert repr(x) == '\nfoo\n'
        assert x._repr_json_(pretty) == {'bar': 'baz', 'ascii': not pretty}

# Generated at 2022-06-24 10:15:52.198086
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.testing.globalipapp import get_ipython
    ip = get_ipython()
    if ip is None:  # pragma: no cover
        return

    # Testing global ipapp objects
    with ip.cell_magic('capture', 'output'):

        # Init and start print (test gui=True)
        tqdm_notebook(total=2, file=sys.stdout)

        # Testing bar formatting
        tqdm_notebook(file=sys.stdout)
        tqdm_notebook(file=sys.stderr, desc='foo', bar_format='{bar:.>20}')
        tqdm_notebook(file=sys.stderr, desc='foo', bar_format='{postfix}')

# Generated at 2022-06-24 10:15:58.223571
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import _test_gui_test, _term_move_up
    for _ in tqdm(range(1)):
        for i in trange(10, file=_test_gui_test.file, desc="foo", leave=True):
            reset_text = "foo:   0%|          | 0/10 [00:00<?, ?it/s]\n"
            assert _test_gui_test.file.getvalue() == reset_text
            assert i == 0
        assert (
            _test_gui_test.file.getvalue()
            == reset_text + _term_move_up() + _term_move_up())
        assert i == 9
        assert _test_gui_test.file.getvalue() == reset_text + _term_move_up()

# Generated at 2022-06-24 10:16:06.669697
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import randint
    for ncols in [None, 100, '100px', '100%']:
        t = trange(10, desc='Test', ncols=ncols)
        for i in t:
            t.set_description('step %i' % i)
            t.set_postfix(loss=randint(0, 10), acc=randint(0, 10))
            if i == 5:
                t.update()
                t.set_description('step %i' % i)
                t.set_postfix(loss=randint(0, 10), acc=randint(0, 10))
                t.update()
            t.update()
    t.close()


if __name__ == '__main__':
    import doctest

# Generated at 2022-06-24 10:16:13.964143
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(
        total=2, desc="test_tqdm_notebook_clear", file=sys.stdout) as pbar:
        pbar.clear()


if __name__ == "__main__":  # pragma: no cover
    for i in tqdm(range(10)):
        pass
    for i in trange(10):
        pass
    for i in tqdm_notebook(range(10), unit="i", desc="tqdm_notebook"):
        pass

# Generated at 2022-06-24 10:16:23.673932
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .utils import FormatCustomText, _term_move_up

    with FormatCustomText(desc='{bar} {n_fmt}/{total_fmt}', unit='Meow'):
        for i in tqdm_notebook(range(10), total=None):
            print(i)
            if i == 5:
                tqdm_notebook.reset()  # equivalent to tqdm.reset()
            if i == 8:
                tqdm_notebook.reset(total=9)
    print()  # newline

    with FormatCustomText(desc='{bar}1{bar}2', unit='Meow'):
        for i in tqdm_notebook(range(10), total=None):
            print(i)
            if i == 5:
                tqdm_notebook.reset()

# Generated at 2022-06-24 10:16:35.021145
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """make sure that the `status_printer` of class `tqdm_notebook`
    returns a box"""
    import ipywidgets
    assert isinstance(tqdm_notebook.status_printer('file'), ipywidgets.HBox)

    # check default file argument 'stderr'
    assert isinstance(tqdm_notebook.status_printer(None), ipywidgets.HBox)

    # check invalid file argument
    assert isinstance(tqdm_notebook.status_printer(file=123), ipywidgets.HBox)

    # check default file argument 'stderr' and total argument
    assert isinstance(tqdm_notebook.status_printer(None, 10), ipywidgets.HBox)

    # check invalid total argument

# Generated at 2022-06-24 10:16:39.710352
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test whether method close of class tqdm_notebook properly closes the progress bar.
    The `close()` method should not raise any exception.
    """
    from itertools import repeat
    for total in [None, -1, 1, 4]:
        for leave in [False, True]:
            bar = tqdm_notebook(repeat(None, total), total=total, leave=leave)
            bar.close()
            bar.close()

# Generated at 2022-06-24 10:16:49.707961
# Unit test for function tnrange
def test_tnrange():
    """
    Test function for tnrange.
    """
    # initialise
    t = tnrange(10, unit='tests')
    assert isinstance(t, tqdm_notebook)
    assert len(t) == 10
    # update
    for i in t:
        assert i == t.n - 1
        assert i >= 0
        if i == 3:
            t.set_description("three")
        if i == 4:
            t.set_postfix(str(i + 1))
        if i == 5:
            t.refresh()
        if i == 7:
            t.set_description("seven")
            t.n = 3
            t.refresh()
        if i == 8:
            t.reset()
            t.n = i
            t.refresh()

# Generated at 2022-06-24 10:16:53.273569
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear(): pass

if __name__ == '__main__':
    # Use `print(tqdm)` to avoid output in doctests
    print((tqdm))
    # tqdm.clear()
    # tqdm.display()
    # tqdm.update()
    # tqdm.close()
    # tqdm.reset()

# Generated at 2022-06-24 10:17:04.427231
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests tqdm_notebook method clear, since it is a dummy method
    that does nothing and might be forgotten in the future.
    """
    return True


if __name__ == '__main__':  # pragma: no cover
    if IPY == 0:
        raise RuntimeError("Requires IPython/Jupyter")

    # Test tqdm_notebook method clear
    test_tqdm_notebook_clear()

    # Test tqdm_notebook
    with tqdm_notebook(total=4, desc="test") as pbar:
        for i in range(4):
            pbar.update()
    pbar = tqdm_notebook(total=4, desc="test")
    for i in range(4):
        pbar.update()
    pbar.close()


# Generated at 2022-06-24 10:17:09.133494
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Check that the default empty bar is hidden on error
    t = tqdm_notebook(iterable=[1])
    try:
        for i in t:
            raise Exception("iterator error")
    except:
        pass
    assert t.container.visible is False

# Generated at 2022-06-24 10:17:13.578709
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=10) as t:
        for i in t:
            assert i == t.n
            assert isinstance(t, tqdm_notebook)
            assert isinstance(t.container, TqdmHBox)
            tqdm.sleep(0.01)



# Generated at 2022-06-24 10:17:22.735236
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from pytest import raises
    from tqdm.auto import trange

    with raises(TypeError):
        for _ in trange(10, 0, -1):
            pass

    with raises(TypeError):
        for _ in trange(10, -10, -1):
            pass

    with raises(ValueError):
        with trange(10) as t:
            t.reset(total=-1)

    with tqdm_notebook(total=10) as t:
        assert t.total == 10
        t.reset(total=5)
        assert t.total == 5

        t.reset()
        assert t.total == 5

        t.reset(total=20)
        assert t.total == 20
        for i in t:
            t.update()



# Generated at 2022-06-24 10:17:34.441724
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from json import loads
    from os import environ
    import IPython
    JUPYTER_NOTEBOOK = IPython.get_ipython() is not None
    if JUPYTER_NOTEBOOK:  # Needs to be run in an IPython/Jupyter Notebook
        # Check that pretty-print representation is correct
        hb = TqdmHBox()
        assert hb._repr_json_() == {}
        hb.pbar = object()
        d = hb._repr_json_()
        assert 'ascii' in d
        assert d['total'] is None
        d = hb._repr_json_(pretty=True)
        assert d['total'] is None
        assert d['ascii']

# Generated at 2022-06-24 10:17:43.892771
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    for _ in tqdm_notebook(range(10), unit='us', leave=False, desc='fdsa'):
        for __ in tqdm_notebook(range(10), unit='us', leave=False, desc='fdsa'):
            sleep(3e-6)
    with tqdm_notebook(range(10), unit='us', leave=False, desc='fdsa') as t:
        for _ in t:
            for __ in tqdm_notebook(range(10), unit='us', leave=False, desc='fdsa'):
                sleep(3e-6)

# Generated at 2022-06-24 10:17:52.073490
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.html.widgets import IntProgress

    tn = tqdm_notebook(total=10, file=sys.stdin)
    assert tn.container.children[-2].__class__ == IntProgress

    tn.update(5)
    assert tn.container.children[-2].value == 5

    tn.update()
    assert tn.container.children[-2].value == 6

    tn.update(-1)
    assert tn.container.children[-2].value == 5

    tn.update(-1)
    assert tn.container.children[-2].value == 4

    tn.update(-2)
    assert tn.container.children[-2].value == 2

    tn.update(-2)

# Generated at 2022-06-24 10:17:55.031157
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tnrange
    with tnrange(4, desc='foo') as t:
        for i in t:
            assert isinstance(i, int)

test_tqdm_notebook___iter__.test_name = "test_tqdm_notebook___iter__"


# Generated at 2022-06-24 10:18:02.587225
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from sys import stdout
    with tqdm_notebook(total=10) as t:
        for i in range(11):
            t.set_description("Testing for " + str(i))
            stdout.flush()
            sleep(0.01)

    t = tqdm_notebook(total=1000)
    for i in range(10):
        t.set_postfix(loss=i ** 3)
        sleep(0.01)
        t.update()
    t.close()

# Generated at 2022-06-24 10:18:06.923572
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for total in [None, 10]:
        for leave in [True, False]:
            t = tqdm(total=total, leave=leave)
            for _ in t:
                t.n += 1
            t.close()


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:18:12.948199
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for leave in [True, False]:
        for total in [None, 10, 5]:
            for ncols in [None, 100, "100px"]:
                for nobar in [True, False]:
                    t = tqdm_notebook(total=total, leave=leave, ncols=ncols)
                    t.update(n=nobar and t.total or 5)  # emulate an error
                    t.reset(total=nobar and total or None)  # reset
                    t.close()


if __name__ != '__main__':  # pragma: no cover
    __version__ = '4.52.0'
else:
    from .main import _test  # pragma: no cover
    _test()  # pragma: no cover

# Generated at 2022-06-24 10:18:16.234184
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update()
            pbar.clear()
            clear_output()

# Generated at 2022-06-24 10:18:25.367421
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    >>> test_tqdm_notebook()
    """
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None

    # Check tqdm_notebook has the same parameters as tqdm and can be used in
    # a with statement
    with tqdm_notebook(total=100, unit='B', unit_scale=True, desc='desc') as bar:
        assert bar.total == 100
        assert bar.unit == 'B'
        assert bar.unit_scale == True
        assert bar.desc == 'desc'


# Generated at 2022-06-24 10:18:31.208455
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=3) as t:
        t.update(1)
        t.reset(total=5)
        assert t.total == 5
        assert t.n == 1
        t.update(3)
        t.reset(total=2)
        assert t.total == 2
        assert t.n == 0
        t.update(2)
        t.reset(total=9)
        assert t.total == 9
        assert t.n == 2

# Generated at 2022-06-24 10:18:37.001129
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    # display_protocol=True
    # with tqdm_notebook(range(5), desc='test', display_protocol=True) as t:
    with tqdm_notebook(range(5), desc='test') as t:
        for x in t:
            time.sleep(0.1)


if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:18:40.969322
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(total=2)
    t.update(1)
    t.clear()
    t.close()
    assert t.n == 2, 't.n = {}, but t.n should be 2'.format(t.n)

# Generated at 2022-06-24 10:18:43.898689
# Unit test for function tnrange
def test_tnrange():
    """
    Simple test for function `tnrange`
    """
    x = list(tnrange(3, desc="numbers"))
    assert x == [0, 1, 2]


# Unit tests for class tqdm_notebook

# Generated at 2022-06-24 10:18:50.274021
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=2, leave=False, desc='default')
    t.display(msg='message')

    t.clear()
    t.display(close=True)
    try:
        t.display()
    except ValueError:
        pass
    else:
        raise AssertionError('should not close twice')

    t = tqdm_notebook(total=2, leave=False, desc='styles')
    t.display(msg='message', bar_style='info')

    t.display(msg='ok', bar_style='success')
    t.display(msg='ok', bar_style='')
    t.display(msg='ok', bar_style='success')
    t.display(msg='error', bar_style='danger')

# Generated at 2022-06-24 10:18:55.822383
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock

    import sys
    from os import devnull

    with mock.patch('sys.stderr', devnull):
        from tqdm import tqdm, trange
        from .std import tqdm as std_tqdm

        for cls in [std_tqdm, tqdm, trange]:
            with cls(total=1, file=sys.stderr, gui=True) as t:
                t.update()
                t.clear()

# Generated at 2022-06-24 10:19:06.729303
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Hard to do without breaking the docstring
    IPY = True
    if IPY:
        # TypeError: __init__() missing 1 required positional argument: 'file'
        with tqdm_notebook() as t:
            # AssertionError: bar_style is "info" instead of "success"
            t.close()
            # AssertionError: bar_style is not "danger"
            t.disp("Error!", bar_style='danger')
            # AssertionError: bar_style is not "warning"
            t.disp("Warning!", bar_style='warning')
            # AssertionError: bar_style is not "success"
            t.disp("Success!", bar_style='success')
            t.disp("Error!", bar_style='danger')
        # AssertionError: bar_style

# Generated at 2022-06-24 10:19:14.353765
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from contextlib import contextmanager
    @contextmanager
    def stdout_redirected(where):
        sys.stdout = where
        try:
            yield where
        finally:
            sys.stdout = sys.__stdout__
    with stdout_redirected(sys.stderr):
        hbox = TqdmHBox()
        assert repr(hbox) == ""
        hbox.pbar = tqdm_notebook(total=10)
        assert repr(hbox) == " |#                                                                          | 0/10 [00:00<?, ?it/s]"

if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:19:24.335466
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    import sys
    from io import StringIO

    # Decorator
    @tqdm_notebook
    def range_of(i):
        for _ in range(i):
            yield _

    out = StringIO()
    old_stdout = sys.stdout
    sys.stdout = out
    pbar = range_of(10)
    # Progress bar is displayed only upon first `write` call
    # (explicit or implicit)
    assert out.getvalue() == ''
    assert 10 == next(pbar)
    assert out.getvalue() != ''
    assert 20 == pbar.update()
    sys.stdout = old_stdout
    assert pbar.displayed

    # Constructor

# Generated at 2022-06-24 10:19:26.908700
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import raises

    with tqdm_notebook(total=None, desc='An iterable') as t:
        for i in t:
            if i >= 5:
                raise ValueError('hello')


# Generated at 2022-06-24 10:19:38.805926
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        # Notebook
        from tqdm.notebook import tqdm as t
        from tqdm.notebook import tnrange as r
        # error: from tqdm.notebook import tnrange
        assert t == tqdm_notebook
        assert r == tnrange
        tqdm_notebook(range(3)).__iter__()
        raise Exception
    except (ImportError, TypeError):
        # Console
        from tqdm import tqdm as t
        from tqdm import trange as r
        # Error: from tqdm.notebook import tqdm
        assert t == tqdm_notebook
        assert r == tnrange
        tqdm_notebook(range(3)).__iter__()

# Generated at 2022-06-24 10:19:48.353431
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tqdm_notebook
    import sys
    import re

    try:
        with tqdm_notebook(total=2000, file=sys.stdout) as pbar:
            for i in pbar:
                a = 2
                pbar.update()
    except:
        pass

    # NB: after exception, the bar should not be printed to stdout
    assert re.search(r"\|\s*\d*\s*\/\s*\d*\s*\|", sys.stdout.getvalue()) is None
    # but to stderr (note: red colour)
    assert re.search(r"\|\s*\d*\s*\/\s*\d*\s*\|", sys.stderr.getvalue()) is not None

# Generated at 2022-06-24 10:19:53.269593
# Unit test for function tnrange
def test_tnrange():
    """
    Check `tnrange(3)` and iteration.
    """
    _len = 0
    for _ in tnrange(3):
        _len += 1
    assert _len == 3

    for _ in tnrange(4):
        pass

    for _ in tnrange(0):
        pass

    for _ in tnrange(3):
        break
    assert _len == 3

# Generated at 2022-06-24 10:20:00.461839
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Recreates issue #557
    progress = tqdm_notebook(total=100)
    progress.reset(total=100)
    progress.reset(total=None)
    assert str(progress.container).find('100%') == -1
    progress.reset(total=10)
    assert str(progress.container).find('100%') == -1
    assert str(progress.container).find('10%') > -1



# Generated at 2022-06-24 10:20:09.164060
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    """
    Test the constructor of class `TqdmHBox`.
    """
    import json
    import io
    import contextlib

    class DummyBar(tqdm_notebook):
        """
        Dummy `tqdm_notebook` bar class to mimic the real one.
        """

        def __init__(self, *a, **k):
            # In the real class, `total` is a property
            self.total = k.pop('total', None)
            super(DummyBar, self).__init__(*a, **k)

        def _repr_json_(self, pretty=None):
            return {'total': self.total}

        def format_meter(self, pretty=None):
            return '{total}'

    # Test the representation is correct

# Generated at 2022-06-24 10:20:19.440995
# Unit test for function tnrange
def test_tnrange():
    """
    Tests tnrange and tnrange_notebook
    """
    from ._tqdm import _range as xrange
    try:
        from time import monotonic
        time = monotonic
    except ImportError:
        from time import time
        time = time

    # Test without args
    with tnrange(None) as t:
        for i in t:
            if i >= 5:
                break

    # Test with args
    with tnrange(10, 1, 3) as t:
        for i in t:
            assert i in [1, 2, 3]

    # Test with keywords
    with tnrange(1, 3, step=1, desc='Tnrange Test') as t:
        assert t.desc == 'Tnrange Test'
        assert t.unit == 'it'
       

# Generated at 2022-06-24 10:20:21.846587
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import closing
    total = 4
    clear = True
    with closing(tqdm_notebook(total=total, leave=True)) as pbar:
        for i in range(total):
            pbar.update(1)
            clear = False
        pbar.close()
        assert clear, 'pbar.close() failed to close'



# Generated at 2022-06-24 10:20:29.771927
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import json

    pbar = tqdm_notebook(__name__)
    hbox = pbar.container
    repr_json = hbox._repr_json_(pretty=True)
    assert repr_json["desc"] == __name__
    repr_json['desc'] = ''  # avoid line breaking

    pinfo = pbar._repr_raw_()
    json_pinfo = json.loads(pinfo)
    assert repr_json == json_pinfo
    assert repr(hbox) == "<TqdmHBox>: {0}".format(pinfo)
    assert hbox._repr_pretty_(None) is None
    # TODO: test _repr_pretty_

test_TqdmHBox()  # pragma: no cover

# Generated at 2022-06-24 10:20:33.286191
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as pbar:
        assert pbar.desc != None
        pbar.reset(total=5, desc=None)
        assert pbar.desc == None

# Generated at 2022-06-24 10:20:42.450823
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import os
    import sys
    import tempfile
    from io import open  # py2 compat

    def do_test(msg):
        # normal bar
        t = tqdm_notebook()
        t.display(msg=msg)
        # clear old msg
        t.display(msg='')
        # error bar
        t.display(msg=msg, bar_style='danger')
        # clear old msg
        t.display(msg='')
        # success bar
        t.display(msg=msg, bar_style='success')
        # close bar
        t.display(close=True)

    # py3 compat

# Generated at 2022-06-24 10:20:52.432196
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook.
    """
    from pyprind.prog_bar import BarNone
    from .std import tqdm as std_tqdm

    # Test warnings
    with std_tqdm(file=None) as t:
        assert isinstance(t, tqdm_notebook)
    with std_tqdm(file=sys.stderr) as t:
        assert isinstance(t, tqdm_notebook)
    # Test disabled
    try:
        with std_tqdm(disable=True) as t:
            assert isinstance(t, BarNone)
    except:  # noqa
        pass
    with std_tqdm(disable=False) as t:
        assert isinstance(t, tqdm_notebook)


# Generated at 2022-06-24 10:20:56.786169
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import trange
    for i in trange(4, desc="1st loop"):
        for j in trange(3, desc="2nd loop", leave=False):
            pass
        for j in trange(3, desc="3rd loop"):
            pass
    for i in trange(4, desc="4th loop"):
        for j in trange(3, desc="5th loop", leave=True):
            pass
        for j in trange(3, desc="6th loop"):
            pass



# Generated at 2022-06-24 10:20:58.796697
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tnrange
    a = tnrange(3)
    # Test clear
    a.clear()

# Generated at 2022-06-24 10:21:00.689226
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .main import _test_cls
    _test_cls(tqdm_notebook)

# Generated at 2022-06-24 10:21:09.932105
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Ensure that the progress bar is properly updated when using tqdm_notebook.
    """
    # Cases
    bar_max = 100
    bar_val = 0
    bar_val_2 = None

    # Run
    t = tqdm_notebook(total=bar_max)
    for i in t:
        # Check current bar val
        _, pbar, _ = t.container.children
        assert pbar.value == bar_val
        # Do some arbitrary stuff
        bar_val_2 = i % 3
        # Update bar
        t.update(bar_val_2)
        bar_val += bar_val_2

    # Close
    t.close()

# Generated at 2022-06-24 10:21:19.033076
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from .std import tnrange, tqdm

    # unit test for tnrange

# Generated at 2022-06-24 10:21:24.899021
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    for n in trange(3, desc='1st loop'):
        for _ in trange(100, desc='2nd loop'):
            sleep(0.01)
        trange.reset(total=1000, desc='2nd loop')


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:21:34.103073
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    for ncols in [None, '100%', 100, '80px']:
        try:
            with tqdm_notebook(total=10, leave=True, ncols=ncols, disable=False) as t:
                for i in range(10):
                    t.update()
            clear_output(wait=True)
        except ImportError:
            pass


# Print a test
if __name__ == "__main__":
    from tqdm import _tqdm_notebook
    tqdm_notebook = _tqdm_notebook.tqdm_notebook
    test_tqdm_notebook()

# Generated at 2022-06-24 10:21:37.149382
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import TMonitor
    import time

    with TMonitor(unit='test', miniters=1) as t:
        t.display()
        time.sleep(1.5)
        t.reset()
        time.sleep(1.5)

# Generated at 2022-06-24 10:21:44.243982
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import TqdmHBox

    text = "pbar"
    hbox = TqdmHBox(children=[text])
    assert str(hbox) == text

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

## IPython and Jupyter Notebook Integration
## Module tqdm.notebook
## Class tqdm_notebook
##     Experimental IPython/Jupyter Notebook widget using tqdm!
##     TqdmHBox
##         ipywidgets.HBox with a pretty representation
##     display
##     colour
##     __init__
##     __iter__
##     update
##     close
##     clear
##     reset
##     status_printer

# Generated at 2022-06-24 10:21:55.690754
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.autonotebook import tqdm
    from time import sleep
    for _ in tqdm(range(3)):
        sleep(.1)

    try:
        for _ in tqdm(range(3)):
            sleep(.1)
            raise Exception()
    except KeyboardInterrupt:
        raise Exception()
    except Exception:
        pass

    for _ in tqdm(range(3), leave=True):
        sleep(.1)

    try:
        for _ in tqdm(range(3), leave=True):
            sleep(.1)
            raise Exception()
    except KeyboardInterrupt:
        raise Exception()
    except Exception:
        pass


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:22:06.957425
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for `tnrange`
    """
    from time import sleep
    with tnrange(2) as t:
        for i in t:
            sleep(0.01)
            t.set_description('tnrange test')


if __name__ == '__main__':
    test_tnrange()
    list(tqdm([]))
    list(tqdm([], leave=True))
    try:
        for _ in tqdm([]):
            raise Exception()
    except Exception:
        pass

    with tqdm(total=100, postfix="TEST", leave=True) as t:
        t.update(42)
        t.update(0)
        t.update(50)
        t.update(0)
        t.update(10)

# Generated at 2022-06-24 10:22:12.598727
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    >>> test_TqdmHBox___repr__()
    [#####                                                                 ]
    """
    pbar = IProgress(min=0, max=100)
    pbar.value = 50
    pbar.bar_style = 'info'
    pbar.layout.width = '20px'
    container = TqdmHBox(children=[HTML(), pbar, HTML('Description')])
    print(repr(container))



# Generated at 2022-06-24 10:22:19.827596
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    pbar = tqdm_notebook(total=2)
    pbar.container.children[1].style.bar_color = 'black'

# Generated at 2022-06-24 10:22:25.069586
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import unittest
    test = unittest.TestCase()

    for i in tqdm_notebook(range(1, 100), desc="process 1", leave=True):
        pbar = tqdm_notebook(range(1, 100), desc="process 2", leave=True)
        for j in pbar:
            pbar.clear()
            test.assertEqual(pbar.n, 0)
            test.assertEqual(pbar.last_print_n, 0)


if __name__ == "__main__":
    test_tqdm_notebook_clear()