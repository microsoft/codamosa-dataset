

# Generated at 2022-06-24 10:12:37.164192
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # tqdm_notebook.clear() raises TqdmTypeError
    with tqdm_notebook(total=2) as pbar:
        pbar.clear()


if __name__ == '__main__':
    # Test for tqdm_notebook clear()
    test_tqdm_notebook_clear()

    # Unit test for tqdm_notebook HBox
    from ipywidgets import Layout
    from IPython.display import display
    from .utils import _term_move_up
    from .utils import _range

    with tqdm_notebook(total=9, desc='test', leave=False) as pbar:
        assert pbar.ncols is None
        display(pbar.container)  # used for testing this test
        pbar.update(1)
        assert pbar

# Generated at 2022-06-24 10:12:38.665640
# Unit test for function tnrange
def test_tnrange():
    from .tests import test_tnrange
    test_tnrange(tnrange)


# Generated at 2022-06-24 10:12:44.958934
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm(total=2, disable=True) as pbar:
        assert list(pbar) == [None, None]
    with tqdm(total=2, disable=False) as pbar:
        assert list(pbar) == [None, None]
    with tqdm(total=2, disable=True) as pbar:
        for x in pbar:
            assert x == None
    with tqdm(total=2, disable=False) as pbar:
        for x in pbar:
            assert x == None


# Generated at 2022-06-24 10:12:49.193476
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    x = tqdm_notebook(iterable=1, ascii=False, ncols=None,
                      leave=True,
                      unit="m")
    x.update(1)

# Generated at 2022-06-24 10:13:01.169496
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from io import StringIO
    import json
    import textwrap
    from .std import tqdm

    # No bar
    out = StringIO()
    with tqdm(file=out) as t:
        t.container = TqdmHBox()
    assert json.loads(out.getvalue()) == {}

    # Test: html representation
    out = StringIO()
    with tqdm(file=out) as t:
        t.container = TqdmHBox()
        t.display()
    assert out.getvalue() == textwrap.dedent("""\
    |0/0 [#, ncols=100%]
    |""")

    # Test: simple bar
    out = StringIO()
    with tqdm(total=1, file=out) as t:
        t.container = Tq

# Generated at 2022-06-24 10:13:04.008538
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # pylint: disable=protected-access
    t = tqdm_notebook(total=100)
    t.update()
    t._instant_clear_display()
    # pylint: enable=protected-access

# Generated at 2022-06-24 10:13:11.263891
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    # Make sure that `reset` hasn't been automatically called
    pbar = tqdm_notebook(total=5)
    assert pbar.total == 5
    assert pbar.n == 0
    for _ in pbar:
        pbar.update(1)
        assert pbar.n == 1
        pbar.reset()
        assert pbar.n == 0
        assert pbar.total == 5
        assert pbar.container.children[-2].value == 0
        break
    pbar.close()

# Generated at 2022-06-24 10:13:16.966665
# Unit test for function tnrange
def test_tnrange():
    """
    Test `tqdm.notebook.tnrange()`.
    """
    # Initialise the progress bar
    with tnrange(5, desc='1st loop') as t:
        # Iterate over the values
        for i in t:
            # Update the progress bar
            t.set_description('1st loop (iteration %i)' % i)
            t.refresh()
            sleep(0.5)


if __name__ == '__main__':
    from time import sleep
    try:
        test_tnrange()
    except KeyboardInterrupt:
        print("Tests interrupted")

# Generated at 2022-06-24 10:13:25.300040
# Unit test for function tnrange
def test_tnrange():
    from .tests import pretest_posttest  # NOQA
    with pretest_posttest() as (_, __):
        for _ in tnrange(10, desc='1st loop', leave=True, unit_scale=True):
            for _ in tnrange(5, desc='2nd loop', leave=True):
                for _ in tnrange(100, desc='3nd loop', leave=True,
                                 unit_scale=True):
                    continue

if __name__ == '__main__':
    test_tnrange()

# Generated at 2022-06-24 10:13:30.598591
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test the method update of the class tqdm_notebook.
    """
    t = tqdm_notebook(total=10)
    for i in t:
        t.update(3)
        if i >= 7:
            t.close()
    assert t.n == 10



# Generated at 2022-06-24 10:13:42.749183
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import os
    # Set up test
    t = tqdm_notebook(total=1)
    assert t.displayed
    assert t.leave
    assert len(t.container.children) == 3
    assert t.container.layout.display == 'inline-flex'
    assert t.container.layout.flex_flow == 'row wrap'
    assert t.container.layout.width == "100%"
    assert t.container.children[0].layout.width == "100%"
    assert t.container.children[1].layout.flex == '2'
    assert t.container.children[2].layout.width == "100%"

    # Test with leave=False (no info bar)
    t.leave = False
    t.close()
    assert not t.displayed
    assert not t.container.visible

    # Test with

# Generated at 2022-06-24 10:13:54.027829
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from os import devnull
    try:
        from io import StringIO
    except ImportError:
        from io import BytesIO as StringIO
    from random import random
    from time import sleep
    with open(devnull, 'w') as fout:
        for _ in tqdm_notebook(range(3), file=fout, leave=True):
            for _ in tqdm_notebook(range(1, 50), file=fout, leave=True, miniters=1, mininterval=0, ascii=True):
                sleep(random() / 5.)
        for i in tqdm_notebook(range(100), file=fout, miniters=100, mininterval=0, ascii=True, leave=True):
            sleep(random() / 5.)

# Generated at 2022-06-24 10:14:02.389308
# Unit test for function tnrange
def test_tnrange():
    from time import sleep
    from numpy import arange
    from numpy import array_equal as equal

    expected = list(range(10))  # xrange does not support slicing
    assert equal(tuple(tnrange(10)), expected)
    assert equal(tuple(tnrange(1, 10, 2)), expected[1::2])
    expected = list(arange(0, 1, 0.1))
    assert equal(tuple(tnrange(0, 1, 0.1)), expected)
    assert equal(tuple(tnrange(0.0, 1.0, 0.1)), expected)
    assert equal(tuple(tnrange(0.1, 1.0, 0.1)), expected)
    expected = list(arange(0, 0.1, 0.01))

# Generated at 2022-06-24 10:14:05.525214
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    from contextlib import closing

    with closing(StringIO()) as fp:
        tqdm_notebook.status_printer(fp, 1, 'desc', 10)
        assert fp.getvalue() == 'desc  0%|          | 0/1 [00:00<?, ?it/s]\n'

# Generated at 2022-06-24 10:14:16.276232
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    with tqdm_notebook(total=1, disable=False, unit="i", desc="test", miniters=0,
                       mininterval=0, maxinterval=0, ascii=" ") as t:
        assert t.default_miniters == 0 and t.miniters == 0
        t.update(1)
        assert t.dynamic_ncols, t.dynamic_ncols
        assert t.format_dict['bar_format'] == '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
        assert t.format_dict['info'] == 'test'
        assert t.format_dict['unit'] == 'i'
        assert not t.disable
        assert t.gui

# Generated at 2022-06-24 10:14:20.835151
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():  # pragma: no cover
    from time import sleep
    from tqdm import trange

    with trange(3, desc='test', leave=True) as t:
        for i in t:
            pass
    # nothing should happen


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:14:31.400132
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._tqdm import __version__

    t = tqdm_notebook(total=1, desc=__version__, leave=False)
    t.display(msg='tqdm made easy!')
    t.display(msg='')
    t.display(bar_style='danger')
    t.display(close=True)

    # test with no total
    t = tqdm_notebook(desc=__version__, leave=False)
    t.display(bar_style='info')
    t.display(msg='tqdm made easy!')
    t.display(msg='')
    t.display(bar_style='danger')
    t.display(close=True)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_

# Generated at 2022-06-24 10:14:42.745264
# Unit test for function tnrange
def test_tnrange():
    """Test for tnrange"""
    # These imports are not at the top to avoid polluting the
    # namespace when the tqdm_notebook is imported normally
    import warnings
    from threading import Thread
    from time import sleep

    # Run tests
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore",
                                message=".*Widget JavaScript not detected.*")
        # Test 1
        # https://github.com/tqdm/tqdm/issues/721
        with tqdm_notebook(total=100) as pbar:
            for i in range(50):
                pbar.update(1)
                sleep(0.05)

        # Test 2
        # https://github.com/tqdm/tqdm/issues/721

# Generated at 2022-06-24 10:14:44.666194
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=3, unit="", unit_scale=False) as pbar:
        pbar.update(1)
        pbar.reset()
        pbar.update(1)

# Generated at 2022-06-24 10:14:52.985803
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test method `status_printer` of class `tqdm_notebook`"""
    from .utils import _supports_unicode
    from .utils import _environ_cols_wrapper
    from .utils import _term_move_up

    # "tempfile"s for testing
    import tempfile
    tmp_out_1 = tempfile.TemporaryFile(mode='w+')
    tmp_out_2 = tempfile.TemporaryFile(mode='w+')
    tmp_err = tempfile.TemporaryFile(mode='w+')

# Generated at 2022-06-24 10:14:57.210283
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=5, desc='tqdm_notebook_update') as tq:
        assert tq.n == 0
        assert tq.total == 5
        tq.update()
        assert tq.n == 1
        assert tq.total == 5
        # Check if bar is updated with the right progress
        assert tq.container.children[1].value == 1
        tq.update(3)
        assert tq.n == 4
        assert tq.total == 5
        # Check if bar is updated with the right progress
        assert tq.container.children[1].value == 4


# Generated at 2022-06-24 10:14:59.952038
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

# Generated at 2022-06-24 10:15:05.294680
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from io import StringIO
    except ImportError:
        from StringIO import StringIO

    # Test html
    written = StringIO()
    hb = TqdmHBox(pbar=std_tqdm(total=6, file=written))
    hb._repr_pretty_(DummyPrettyPrinter())
    assert written.getvalue() == '\n100%|███████| 6/6 [00:00<00:00, ?it/s]\n'

    # Test html pretty
    written = StringIO()
    hb = TqdmHBox(pbar=std_tqdm(total=6, file=written))
    hb._repr_pretty_(DummyPrettyPrinter(), True)

# Generated at 2022-06-24 10:15:06.894034
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(range(2)) as tq:
        for i in tq:
            assert i == 0 or i == 1


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:15:17.567506
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    def equal(d1, d2):
        return (set(d1.keys()) == set(d2.keys())
                and all(map(lambda x, y: x == y, d1.values(), d2.values())))

    assert equal({"n": 0, "total": 0, "leave": False, "desc": "", "ncols": None},
                 TqdmHBox()._repr_json_())
    assert equal({"n": 0, "total": 0, "leave": False, "desc": "", "ncols": 100},
                 TqdmHBox()._repr_json_(100))

# Generated at 2022-06-24 10:15:30.628042
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from re import match
    from sys import stdout
    from textwrap import dedent

    from tqdm.notebook import TqdmHBox

    # Expected output: dedent(r'''\
    # |{desc}{bar}| {percentage:3.0f}% {remaining} {postfix}
    # ''')  # NOQA
    a = TqdmHBox()
    a.pbar = std_tqdm(total=10, file=StringIO())
    a.pbar.n = 5
    a.pbar.format_dict = a.pbar.format_meter(ascii=False)
    a.pbar.format_dict["desc"] += " " * 3
    a.pbar.format_dict["bar"] = a.pbar

# Generated at 2022-06-24 10:15:38.360673
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Clear should not raise any error when called on a closed tqdm
    # and should not print anything
    with tqdm_notebook(total=2) as pbar:
        try:
            import sys
            import os
            sys.stdout.write("\n")  # to test reset of stdout
            pbar.clear()

            old_stdout = sys.stdout
            pbar.clear()
            assert old_stdout == sys.stdout  # no change

            # Try to catch it if `pbar.clear()` prints
            sys.stdout = open(os.devnull, 'w')
            pbar.clear()
        finally:
            sys.stdout = sys.__stdout__


if __name__ == "__main__":
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:15:40.693775
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm(2, 3, 4) as t:
        for obj in t:
            sleep(0.5)

# Generated at 2022-06-24 10:15:51.194984
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from IPython.core.display import display
    from .utils import _decode_unicode
    # NOTE: this is a rather fragile test, it may fail when the
    # ipywidgets (or jupyter) module changes its API.
    # it is used to test the _repr_pretty_ and _repr_json_ methods
    # to make sure that they return the correct string.
    pbar = TqdmHBox()
    pbar.pbar = tqdm_notebook()
    pbar.pbar.format_dict['n'] = 100
    pbar.pbar.format_dict['total'] = 1000
    pbar.pbar.format_dict['desc'] = 'Desc'

# Generated at 2022-06-24 10:16:02.074369
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    def raise_exc(ex):
        """
        Function raises an exception.

        Parameters
        ----------
        ex : Exception
            The exception to raise.
        """
        raise ex

    # Tries to test if exception is propagated
    try:
        for _ in tqdm_notebook(range(1), desc='test_tqdm_notebook___iter__', leave=True):  # noqa
            raise_exc(Exception())
    except Exception:
        pass

    # Tries to test if KeyboardInterrupt is propagated
    try:
        for _ in tqdm_notebook(range(2), desc='test_tqdm_notebook___iter__', leave=True):  # noqa
            raise_exc(KeyboardInterrupt())
    except KeyboardInterrupt:
        pass



# Generated at 2022-06-24 10:16:04.500370
# Unit test for function tnrange
def test_tnrange():
    r = list(tnrange(5, 0, -1))
    assert r == list(range(5, 0, -1))



# Generated at 2022-06-24 10:16:14.955115
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook

    returns True if successful, False if unsuccessful
    """

    pbar = tqdm_notebook()
    pbar.close()
    try:
        assert(pbar.container.children[-2].bar_style == 'success')
    except AssertionError:
        return False

    pbar.close()
    try:
        assert(pbar.container.children[-2].bar_style == 'success')
    except AssertionError:
        return False

    pbar = tqdm_notebook(leave=False)
    pbar.close()
    try:
        assert(pbar.container.children[-2].bar_style == '')
    except AssertionError:
        return False

    pbar = tqdm_note

# Generated at 2022-06-24 10:16:24.730422
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    with patch.object(tqdm_notebook, 'update_to') as update_to:
        # update_to must be called with the new position
        with patch.object(tqdm_notebook, 'move_to') as move_to:
            # move_to must be called with the old position
            with patch.object(tqdm_notebook, 'display') as display:
                p = tqdm_notebook()
                p.update(2)
                display.assert_called_with(check_delay=False)
                update_to.assert_called_with(2)
                move_to.assert_called_with(0)

            # move_to must NOT be called when n < n_old

# Generated at 2022-06-24 10:16:27.069245
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    for _ in tqdm_notebook(range(10)):
        time.sleep(0.1)

# Generated at 2022-06-24 10:16:37.458026
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # python 2
    assert re.match(r'\r{0,1}100%|\|',
                    tqdm_notebook.status_printer(None, 100).layout.description)
    assert re.match(r'\r{0,1}100%|\|',
                    tqdm_notebook.status_printer(None, 100,
                                                 ncols=100).layout.description)
    assert re.match(r'\r{0,1}100%|\|',
                    tqdm_notebook.status_printer(None, 100,
                                                 ncols='100%').layout.description)

# Generated at 2022-06-24 10:16:42.788604
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # try to catch https://github.com/noamraph/tqdm/issues/479
    import random
    import time

    random.seed(0)
    with tqdm_notebook(total=20) as pbar:
        for _ in pbar:
            time.sleep(random.random())

# Generated at 2022-06-24 10:16:51.703944
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    >>> test_TqdmHBox()
    {'bar_format': '{l_bar}<bar/>{r_bar}',
     'desc': 'Hello World!',
     'postfix': {},
     'rate': 0.0,
     'unit': ''}
    """
    import pytest
    tqdm_notebook._repr_pretty_ = pytest.helpers.capture_stream('stdout')
    t = TqdmHBox()
    t.pbar = tqdm_notebook(total=2, desc='Hello World!')
    t.pbar.update(1)
    print(t)  # __repr__ -> _repr_pretty_

# Generated at 2022-06-24 10:16:56.743775
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as pbar:
        for _ in range(5):
            pbar.update()
        # Reset to 0
        pbar.reset()

        # Should work now
        assert pbar.total == 10
        assert pbar.n == 0

# Generated at 2022-06-24 10:17:02.176026
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test simple case
    hbox = TqdmHBox()
    hbox.pbar = std_tqdm.static_format_dict(**{'bar_format': 'hello world %r'})
    assert hbox.__repr__() == hbox.__repr__(pretty=False) == 'hello world %r'
    s = hbox._repr_json_(pretty=False)
    assert s['bar_format'] == 'hello world %r'

    # Test JSON
    hbox.pbar = std_tqdm.static_format_dict(
        **{'bar_format': 'hello world %r', 'ascii': False})
    s = hbox._repr_json_(pretty=False)
    assert s['bar_format'] == 'hello world %r'
    s = hbox._

# Generated at 2022-06-24 10:17:13.311240
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm

    try:
        from IPython.display import clear_output  # NOQA
    except ImportError:  # pragma: no cover
        return

    with tqdm(total=100, desc="Desc: ") as pbar:
        assert pbar.colour == ''
        pbar.colour = 'red'
        assert pbar.colour == 'red'

        assert pbar.bar_format == "{l_bar}<bar/>{r_bar}"
        pbar.bar_format = "{bar}"
        assert pbar.bar_format == "{bar}"

        pbar.display(desc="Test: ")
        assert pbar.colour == 'red'
        pbar.colour = ''


# Generated at 2022-06-24 10:17:16.008580
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook([1, 2, 3]):
        pass
    return

if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:17:18.808600
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .tests import test_tqdm_notebook
    test_tqdm_notebook.test_tqdm_notebook_status_printer(tqdm_notebook)


# Generated at 2022-06-24 10:17:27.096551
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Test leave
    with tqdm_notebook(unit='step', leave=True,
                       total=2) as t:
        t.update(2)
        assert t.displayed
        t.close()
        assert t.displayed is False

    # Test leave=False
    with tqdm_notebook(unit='step', leave=False,
                       total=2) as t:
        t.update(2)
        assert t.displayed
        t.close()
        assert t.displayed is False

    # Test leave=None and error
    with tqdm_notebook(unit='step', leave=None,
                       total=2) as t:
        t.update(2)
        assert t.displayed
        t.close()
        assert t.displayed is False

    # Test leave=True and

# Generated at 2022-06-24 10:17:36.547454
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from ipywidgets.widgets import DOMWidget
    from ipywidgets import Layout
    try:
        from unittest.mock import patch, Mock
    except ImportError:
        from mock import patch, Mock
    import sys

    if sys.version_info < (3,):
        import __builtin__ as builtin
        from StringIO import StringIO
    else:
        import builtin
        from io import StringIO

    def _reset_repr(*args, **kwargs):
        # Keep builtin repr()
        builtin.repr = builtin.repr
        # Avoid mocking repr() of DOMWidget
        DOMWidget.__repr__._original_function.revert()
        # Unset all keys in kwargs
        for k in kwargs:
            mock_obj.__repr__.reset_

# Generated at 2022-06-24 10:17:38.715094
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            pbar.update()

# Generated at 2022-06-24 10:17:45.941577
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # test no error
    from tqdm import tqdm_notebook as tqdm
    for i in tqdm(range(10)):
        pass
    # test foo error
    try:
        for i in tqdm(range(10)):
            raise RuntimeError("foo")
    except Exception as e:  # NOQA
        assert str(e) == "foo"
    # test KeyboardInterrupt
    try:
        for i in tqdm(range(10)):
            raise KeyboardInterrupt("foo")
    except Exception as e:  # NOQA
        assert isinstance(e, KeyboardInterrupt)


# Generated at 2022-06-24 10:17:56.097587
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function `tnrange`.
    """
    # import time
    import nose.tools
    from random import randint
    from nose.tools import assert_raises
    from .utils import format_sizeof
    from .utils import formatted_size  # NOQA
    from .utils import format_interval  # NOQA
    from .utils import format_timespan  # NOQA

    # Testing the default value of dynamic_ncols
    assert tnrange(5, dynamic_ncols=None).dynamic_ncols == True

    # Testing initialisation
    assert tnrange(5).total == 5
    assert tnrange(0).total == 0
    assert tnrange(1).total == 1
    assert tnrange(-5).total == 0
    nose.tools.assert_ra

# Generated at 2022-06-24 10:18:06.880776
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    kwargs = dict(i=0, ncols=None, bar_format=None, leave=None)
    c = tqdm_notebook.status_printer(None, **kwargs)
    assert isinstance(c, HBox)
    assert len(c.children) == 3
    assert isinstance(c.children[0], HTML)
    assert isinstance(c.children[1], IProgress)
    assert isinstance(c.children[2], HTML)
    assert c.layout.display == 'flex'
    assert c.layout.flex_flow == 'row wrap'

    kwargs = dict(i=0, ncols=100, bar_format=None, leave=None)
    c = tqdm_notebook.status_printer(None, **kwargs)

# Generated at 2022-06-24 10:18:14.775686
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm.tests.widget.tests_ipy import get_master_desc, get_total, \
        get_desc, get_bar, get_postfix_str, get_ncols, get_bar_style

    with tqdm_notebook(total=10, desc="foo") as pbar:
        sleep(0.2)
        assert get_total(pbar.container) == 10
        assert get_desc(pbar.container) == "foo"
        assert get_bar(pbar.container) == 1

        pbar.display("10/10")
        assert get_postfix_str(pbar.container) == "10/10"
        pbar.clear("10")
        assert get_postfix_str(pbar.container) == "10"

# Generated at 2022-06-24 10:18:25.005029
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Unit test for TqdmHBox.__repr__,
    the method called to display the progress bar in IPython / Jupyter.
    """
    # import ipywidgets.widgets as ipywidgets
    v = TqdmHBox(
        children=[ipywidgets.HTML(),
                  ipywidgets.FloatProgress(
                      min=0.0, max=100.0, step=1,
                      value=50,
                      bar_style='info',
                      layout=ipywidgets.Layout(width="100px")),
                  ipywidgets.HTML()])
    v.pbar = proxy(tqdm_notebook(total=100, desc='hello'))
    # DEPRECATED: replaced with an 'info' style bar
    # assert v.__repr__() ==

# Generated at 2022-06-24 10:18:32.143531
# Unit test for function tnrange
def test_tnrange():
    import time
    from .utils import format_sizeof
    assert format_sizeof(range(1000)) == format_sizeof(tnrange(1000))
    for i in tnrange(100, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop', leave=False):
            for k in tnrange(100, desc='3nd loop', leave=False):
                time.sleep(0.01)
            time.sleep(0.01)
        time.sleep(0.01)

    time.sleep(1)



# Generated at 2022-06-24 10:18:41.791459
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test reset method of class tqdm_notebook
    """
    # Test default (no reset)
    sample_size = 100
    with tqdm_notebook(total=sample_size) as pbar:
        for i in range(sample_size):
            pbar.update()

    # Test reset with None (no change)
    sample_size = 100
    with tqdm_notebook(total=sample_size) as pbar:
        for i in range(sample_size):
            pbar.update()
            pbar.reset(None)

    # Test reset with integer
    sample_size = 100
    new_total = 50
    with tqdm_notebook(total=sample_size) as pbar:
        for i in range(sample_size):
            pbar.update()

# Generated at 2022-06-24 10:18:49.997672
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from pytest import raises
    # Test without total
    pbar = tqdm_notebook.status_printer(sys.stdout, desc="Test")
    assert pbar.pbar.max == 1
    assert pbar.pbar.bar_style == 'info'
    # Test with total
    pbar = tqdm_notebook.status_printer(sys.stdout, total=100, desc="Test")
    assert pbar.pbar.max == 100
    # Test ncols
    pbar = tqdm_notebook.status_printer(sys.stdout, total=100, desc="Test", ncols=200)
    assert pbar.layout.width == '200px'
    # Test too small ncols

# Generated at 2022-06-24 10:18:52.802638
# Unit test for function tnrange
def test_tnrange():
    """
    Tests function tnrange
    """
    list(tnrange(3))
    assert tuple(tnrange(3)) == (0, 1, 2)
    assert tuple(tnrange(1, 3)) == (1, 2)
    assert tuple(tnrange(1, 5, 2)) == (1, 3)



# Generated at 2022-06-24 10:19:02.542931
# Unit test for function tnrange
def test_tnrange():
    """
    Function tnrange Unit Test (Test Coverage 100%)
    """
    import IPython
    from IPython import get_ipython
    ip = get_ipython()
    if ip is None or ip.__class__.__name__ != 'ZMQInteractiveShell':
        raise unittest.SkipTest()

    ipython_previous_out = ip.display_pub.out
    try:
        # Mock output channel
        ip.display_pub.out = ip.display_pub.out_impl
        list(tqdm(tnrange(1)))
        list(tqdm(tnrange(1, 2)))
        list(tqdm(tnrange(1, 2, 3)))
        list(tqdm(tnrange(1, 2, step=0.1)))
    finally:
        ip.display_pub

# Generated at 2022-06-24 10:19:10.403215
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from IPython.testing.globalipapp import get_ipython
    from IPython.testing.tools import get_display_pub_thread

    keyboard_input = get_ipython().pt_app.shell.keyboard_input
    display_pub = get_display_pub_thread().pub
    t = tqdm_notebook(total=1, leave=False, unit='B', unit_scale=True,
                      bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]')
    display_pub.clear_output()
    keyboard_input("t.close()")

# Generated at 2022-06-24 10:19:21.928460
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Mimic notebook display
    from io import BytesIO
    fp = sys.stdout = BytesIO()
    display = lambda *_: None
    setattr(tqdm_notebook, 'display', display)  # fake method
    container = tqdm_notebook.status_printer(fp)
    setattr(tqdm_notebook, 'container', container)  # fake attribute
    # Test update
    clear_output = lambda *_: None
    setattr(tqdm_notebook, 'clear_output', clear_output)  # fake method
    tn = tnrange(10, desc='test')
    tn.update()
    tn.close()

    # TODO: test display()
    # TODO: unittest update() on a manual tqdm

# Generated at 2022-06-24 10:19:26.463955
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """ Unit test for constructor of class TqdmHBox
    """
    a = TqdmHBox()
    b = TqdmHBox(children=[1, 2, 3])

    assert len(a.children) == 0
    assert len(b.children) == 3



# Generated at 2022-06-24 10:19:38.752961
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import sys
    import contextlib

    @contextlib.contextmanager
    def captured_output():
        new_out, new_err = sys.stdout, sys.stderr
        try:
            out_err = (new_out.fileno(), new_err.fileno())
            old_out, old_err = sys.stdout, sys.stderr
            sys.stdout, sys.stderr = new_out, new_err

            yield sys.stdout, sys.stderr
        finally:
            sys.stdout, sys.stderr = old_out, old_err

    with captured_output() as (out, err):
        for i in tqdm_notebook(range(10), desc='1st loop', leave=True):
            assert i == i

# Generated at 2022-06-24 10:19:46.774896
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for i in tnrange(4, desc='1st loop'):
        for j in tqdm(range(3), desc='2nd loop', leave=False,
                      bar_format='{percentage:3.0f}% {remaining}'):
            for k in trange(2, desc='3nd loop'):
                pass
    try:
        trange(4, desc='test')
    except ImportError:
        pass  # ipywidgets not installed
    else:
        raise RuntimeError("should have failed because ipywidgets not installed")


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:19:53.038817
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Test 1: no existing pbar
    test = TqdmHBox(children=None)
    assert not test.__repr__()
    assert not test._repr_json_()
    assert not test._repr_pretty_(object())

    # Test 2: existant pbar
    test = TqdmHBox(children=None)
    test.pbar = 1
    assert not test.__repr__()
    assert not test._repr_json_()
    assert not test._repr_pretty_(object())

    # Test 3: existant pbar with existing format_dict
    test = TqdmHBox(children=None)
    test.pbar = 1
    test.pbar.format_dict = {1: 2, 3: 4}
    assert not test.__repr__()
    assert test

# Generated at 2022-06-24 10:20:00.224550
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    box = TqdmHBox(children=["a", "b", "c"])  # does not fail
    assert re.search(r'a.*b.*c', box.__repr__())
    box = TqdmHBox(children=["a", "b", "c"])  # does not fail
    assert re.search(r'a.*b.*c', box._repr_pretty_(""))  # Does not fail

# Generated at 2022-06-24 10:20:05.707826
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10, disable=False) as t:
        # first bar
        assert t.last_print_t is None
        t.update()
        assert t.last_print_t is not None
        # second bar
        t.clear()
        assert t.last_print_t is None
        t.update()
        assert t.last_print_t is not None

# Generated at 2022-06-24 10:20:12.292314
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test to generate a progress bar widget in IPython/Jupyter Notebook.
    """
    from ipywidgets import FloatProgress as IProgress

    if IProgress is None:  # #187 #451 #558 #872
        return

    pbar = tqdm_notebook(total=10)
    for i in range(10):
        time.sleep(0.1)
        pbar.update()
    pbar.close()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:20:22.195376
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    """
    x = tqdm_notebook.status_printer(None, 100, "test")
    assert isinstance(x, TqdmHBox)
    assert isinstance(x.children[0], HTML)
    assert isinstance(x.children[1], IProgress)
    assert isinstance(x.children[2], HTML)
    assert x.layout.align_items == 'stretch'
    assert x.layout.border == ''
    assert x.layout.display == 'flex'
    assert x.layout.flex_flow == 'row'
    assert x.layout.justify_content == 'space-between'
    assert x.children[0].margin == ''
    assert x.children[0].padding == ''

# Generated at 2022-06-24 10:20:30.316599
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for function tnrange
    """
    # Test on non-integer input
    try:
        next(tnrange(1, 1.5))
    except TypeError:
        pass
    else:
        raise AssertionError('tnrange() fail on non-integer input')
    # Test on non-number input
    try:
        next(tnrange(1, None))
    except TypeError:
        pass
    else:
        raise AssertionError('tnrange() fail on non-number input')
    # Test iterator
    assert(sum(tnrange(5)) == 10)
    # Test leave
    for leave in [False, True]:
        for unit in [1, None]:
            pbar = tnrange(10, leave=leave, unit=unit)
            list(pbar)

# Generated at 2022-06-24 10:20:40.400003
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from random import random
        from time import sleep
        try:
            from IPython.display import clear_output
        except ImportError:
            clear_output = lambda: None

        values = []
        with tqdm_notebook(total=10) as pbar:
            for i in pbar:
                values.append(i)
                sleep(random() / 2)
                pbar.set_description("Processing event %i" % i)
                if i >= 8:
                    pbar.close()
                    raise KeyboardInterrupt
                clear_output(wait=True)

        assert values == list(range(1, 9))
    except Exception as e:
        import sys
        import traceback
        exc_type, exc_value, exc_traceback = sys.exc_info()

# Generated at 2022-06-24 10:20:50.240733
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    global IPY
    msg = 'test'
    pbar = IProgress(min=0, max=1)
    ltext = HTML()
    rtext = HTML()
    rtext.value = msg
    container = TqdmHBox(children=[ltext, pbar, rtext])
    assert repr(container) == msg
    if IPY > 3:
        assert container._repr_pretty_([], False, False) == msg
        repr_json = container._repr_json_()
        if repr_json:  # pragma: no cover
            assert repr_json['bar_format'] == '{desc}{percentage:3.0f}%|{bar}|{n_fmt}/{total_fmt}{postfix}'
            assert repr_json['bar_format'] == msg

# Generated at 2022-06-24 10:20:54.418664
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for i in tqdm_notebook(range(10)):
        pass
    t = tqdm_notebook(range(10))
    for i in t:
        t.reset(total=5)
    t.reset(total=5)
    for i in t:
        t.reset()
    t.reset()

# Generated at 2022-06-24 10:20:58.839207
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # test instantiation of class, no iterations
    # with optional specified total set, to trigger total=unknown bar
    bar1 = tqdm_notebook(total=7)
    del bar1
    bar2 = tqdm_notebook()
    del bar2

    # test when widgets are not available
    old_val = IProgress
    try:
        del IProgress
        bar3 = tqdm_notebook()
        del bar3
    finally:
        IProgress = old_val



# Generated at 2022-06-24 10:21:03.196948
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from .gui import tgrange
    if not IPY:
        raise ImportError
    with tqdm(total=10) as t:
        assert t.gui is True
        assert t.fd is sys.stdout
        assert t.disable is False
        for i in tgrange(5):
            t.update()

# Testing for python 2/3 compatibility
if __name__ == "__main__":
    test_tqdm_notebook()
    from .std import _tqdm_test
    _tqdm_test().test_notebook(tqdm_notebook)

# Generated at 2022-06-24 10:21:07.660838
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test `clear` method of tqdm_notebook."""
    # Test clear method of tqdm_notebook
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.clear()
            pbar.update(1)


test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:21:17.873029
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test for attribute error when tqdm_notebook object is initialised with disable=True
    with tqdm_notebook(total=10, disable=True) as tn:
        assert isinstance(tn.disable, bool)

    # Test for attribute error when tqdm_notebook object is initialised without disable
    with tqdm_notebook(total=10) as tn:
        assert tn.disable is False
        assert tn.displayed is False

    # Test for attribute error and exception when tqdm_notebook object is initialised and in iteration loop
    with tqdm_notebook(total=10) as tn:
        for i in range(7):
            assert tn.displayed is False
            tn.update(1)
            assert tn.displayed is False

# Generated at 2022-06-24 10:21:29.758504
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time

    # IPython/Jupyter Notebook progress bar widget with in-place updates
    try:
        from tqdm.notebook import tqdm
    except ImportError:  # pragma: no cover
        return  # skipped

    with tqdm(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
    time.sleep(1)

    # Redirected output to `file` (default: `sys.stderr`)
    with open('tqdm_notebook_test.txt', 'w') as fileobj:
        for i in tqdm(range(10), file=fileobj):
            time.sleep(0.1)

# Generated at 2022-06-24 10:21:32.576822
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = TqdmHBox()
    assert type(pbar.__repr__()) == str
    assert type(pbar.__repr__(pretty=True)) == str


# Generated at 2022-06-24 10:21:41.289728
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep

    for leave in [True, False]:
        for n in [0, 1]:  # unit-test with iterable
            for total in [None, 1]:  # iterable or manual
                for unit_scale in [True, False, 1]:  # dynamic or not
                    for disable in [True, False]:  # disabled or not
                        sys.stderr.write('\n')

                        with tqdm_notebook(total=total,
                                           unit_scale=unit_scale,
                                           disable=disable,
                                           leave=leave,
                                           ) as t:
                            for _ in range(n):
                                sleep(0.1)
                                t.update()


# Generated at 2022-06-24 10:21:43.099560
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as progressbar:
        progressbar.clear()

# Generated at 2022-06-24 10:21:48.901432
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook.close(tqdm_notebook.displayed)
    tqdm_notebook.clear(tqdm_notebook.container)
    tqdm_notebook.reset(total=tqdm_notebook.total)
    tqdm_notebook.colour = tqdm_notebook.container.children[-2].style.bar_color

# Generated at 2022-06-24 10:21:53.558549
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # for test coverage
    """
    Test method update of class tqdm_notebook.
    """
    from random import random

    delay = 10  # s
    with tqdm_notebook(total=100, leave=True, unit='B',
                       unit_scale=True, unit_divisor=1024,
                       desc='Downloading',
                       bar_format='{l_bar}{bar}{r_bar}',
                       miniters=1, mininterval=0.5,
                       timeout=5) as t:
        for _ in t:
            t.n += int(random() * 100)
            t.update(n=t.n)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_update()

# Generated at 2022-06-24 10:22:01.735161
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test tqdm_notebook.update()"""
    out = io.StringIO()
    t = tqdm_notebook(total=0, file=out, leave=True)
    for _ in range(4):
        # force printing of each iteration
        t.disable = False
        t.update()
    t.close()
    output = re.sub(r'\s+', '', out.getvalue())

# Generated at 2022-06-24 10:22:11.931110
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook."""
    pbar = tqdm_notebook.status_printer(None, total=10, desc="hello", ncols=40)
    assert isinstance(pbar, TqdmHBox)
    assert "hello" in str(pbar)
    assert '<progress style' in str(pbar)
    assert 'width: "40px"' in str(pbar)
    # check if the progress bar is displayed
    if IPY >= 3:
        assert 'display: "inline-flex"' in str(pbar)
    # test with a None total
    pbar = tqdm_notebook.status_printer(None, total=None)
    assert isinstance(pbar, TqdmHBox)
    assert 'min="0"'

# Generated at 2022-06-24 10:22:20.006884
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import sys
    import pytest

    # Test tqdm.notebook.close()
    if sys.version_info[0] == 2:
        pytest.skip("Can't test tqdm.notebook.close() on Python2")
    try:
        from IPython import get_ipython
    except ImportError:
        pytest.skip("Can't test tqdm.notebook.close() outside a notebook")
    ip = get_ipython()
    if not hasattr(ip, 'kernel') or not ip.kernel:
        pytest.skip("Can't test tqdm.notebook.close() outside a notebook")
    from IPython.display import display, clear_output


# Generated at 2022-06-24 10:22:26.252510
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit tests to check method close of class tqdm_notebook.
    """
    # html = tqdm_notebook(total=10)
    # assert(html._repr_html_() ==
    #        '<div style="width: 100%; background-color: #f6f8fa;">'
    #        '<div style="width: 0%; background-color: #007acc;">&nbsp;</div>'
    #        '</div>')

    a = tqdm_notebook(total=10)
    a.close()
    assert(a.container.visible is False)

    a = tqdm_notebook(total=10)
    a.update(1)
    a.close(
        bar_style="success",
        check_delay=False)  # to avoid

# Generated at 2022-06-24 10:22:32.589356
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    for total in [None, 4]:
        for ncols in [None, 100, "100px", "100%"]:
            for desc in ["", "Desc"]:
                tqdm_notebook.status_printer(
                    total=total, desc=desc, ncols=ncols)


if __name__ == '__main__':
    test_tqdm_notebook_status_printer()