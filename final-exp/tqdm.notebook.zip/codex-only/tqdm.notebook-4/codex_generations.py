

# Generated at 2022-06-24 10:12:34.528211
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from IPython.utils.io import capture_output
        from IPython import get_ipython
        from IPython.display import clear_output
    except ImportError:
        return  # dry-run only
    ipy = get_ipython()
    if ipy is None:
        return  # dry-run only

    with capture_output() as io:
        t = tqdm_notebook(total=10)
        t.display(check_delay=False)
        t.update(5)
        t.update(5)
        t.display(close=True, bar_style='success', check_delay=False)
    assert ">5" in io.stdout, str(io)
    with capture_output() as io:
        t = tqdm_notebook(total=10)
        t

# Generated at 2022-06-24 10:12:44.847814
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    t = tqdm(total=100, leave=False)
    for i in t:
        time.sleep(0.05)
        if i == 50:
            t.clear()
            t.reset()
            # Don't show the time elapsed
            t.bar_format = '{l_bar}<bar>{n_fmt}/{total_fmt}'
    assert t.smoothing == 1



# Generated at 2022-06-24 10:12:50.200298
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from unittest import TestCase, main

    class _tqdm_notebook(TestCase):
        def test_tqdm_notebook(self):
            with tqdm(desc='total', total=1) as pbar:
                pbar.display()  # test display()

    main()



# Generated at 2022-06-24 10:13:02.711176
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for expected exception on `tqdm_notebook.status_printer`
    """
    from .std import tqdm_gui
    from .utils import _range

    if IPY == 0 or IProgress is None:
        return

    if IPY >= 4:  # ipywidgets v7
        with tqdm_gui(unit='B/s',
                      bar_format='{l_bar}{bar}{r_bar}',
                      unit_scale=True, unit_divisor=1024) as t:
            assert t.status_printer == tqdm_gui.status_printer2
            for i in _range(10):
                t.update(1)

# Generated at 2022-06-24 10:13:06.572519
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # prepare fake iterable
    iterable = iter('a' for _ in range(5))
    # instantiate a tqdm_notebook with fake iterable
    for item in tqdm_notebook(iterable):
        assert item == 'a'

# Generated at 2022-06-24 10:13:15.815804
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""
    from inspect import signature

    hbox = tqdm_notebook.status_printer(total=100, desc='Unit test')
    assert isinstance(hbox, HBox)
    params = signature(hbox.close).parameters
    assert 'wait' in params
    ltext, pbar, rtext = hbox.children
    assert ltext.value == 'Unit test'
    assert pbar.min == 0
    assert pbar.max == 100
    assert rtext.value == ''
    assert hbox.pbar.unit_scale == 1

    try:
        IProgress = None
        hbox = tqdm_notebook.status_printer(None)
    except ImportError:
        pass


# if __name__ == '

# Generated at 2022-06-24 10:13:20.505501
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Testing tqdm_notebook()"""
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
    pbar.clear()


# Main method for running the unit test

# Generated at 2022-06-24 10:13:23.185302
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test method clear of class tqdm_notebook
    """
    assert tqdm_notebook().clear == tqdm_notebook().clear

# Generated at 2022-06-24 10:13:35.077768
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test widget output
    x = tqdm_notebook(total=10)
    assert x.container.layout.display == 'flex'
    assert x.container.layout.flex_flow == 'column'
    assert x.container.children[-2].layout.flex == '2'
    x.close()

    class _tqdm_notebook(_tqdm_notebook):
        def __init__(self, *args, **kwargs):
            # Initialize parent class + avoid printing by using gui=True
            kwargs['gui'] = True
            super(_tqdm_notebook, self).__init__(*args, **kwargs)

    # Test widget output with no_bar
    x = _tqdm_notebook(total=10)
    assert x.container.layout.display == 'inline-flex'

# Generated at 2022-06-24 10:13:41.329623
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    mybar = tqdm_notebook(total=10)
    for i in mybar:
        time.sleep(0.01)
        if mybar.n >= 3:
            mybar.reset(5)
            break


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:13:49.143159
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from IPython.display import clear_output as clr
    except ImportError:
        clr = lambda: None
    try:
        from IPython.display import display as disp
    except ImportError:
        disp = lambda x: None
    clr()
    bar = tqdm_notebook(total=3)
    if not hasattr(bar.container, 'close'):
        bar.container.close = lambda: None
    msg = ''

    # Test display '\r'
    msg += '\r'
    bar.disp(msg)
    assert not bar.container.visible
    msg = ''

    # Test display '\rmsg'
    msg += '\rmsg'
    bar.disp(msg)
    assert not bar.container.visible
    msg = ''

    # Test display '

# Generated at 2022-06-24 10:14:00.229181
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from unittest import TestCase, main


    n = 10


    class Mock(object):
        def __init__(self, n):
            self.n = n
            self.i = 0

        def __iter__(self):
            return self

        def __next__(self):
            if self.i < self.n:
                self.i += 1
                return self.i - 1
            else:
                raise StopIteration


    class TestTqdmNotebook___iter__(TestCase):
        def test_normal(self):
            pbar = tqdm_notebook(Mock(n), leave=False)
            self.assertEqual(next(pbar), 0)
            self.assertEqual(next(pbar), 1)
            self.assertEqual(pbar.n, 2)

# Generated at 2022-06-24 10:14:06.861344
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = IProgress(min=0, max=5)
    pbar.bar_style = 'success'
    pbar.value = 4
    hbox = TqdmHBox(children=[HTML("<foo>"), pbar, HTML("<bar>")])
    hbox.pbar = proxy(pbar)
    print(hbox)
    pbar.bar_style = 'info'
    pbar.value = 1
    # test without progress bar
    hbox.pbar = None
    print(hbox)
    # test with unicode and bar
    pbar = IProgress(min=0, max=5)
    pbar.bar_style = 'success'
    pbar.value = 4

# Generated at 2022-06-24 10:14:10.538504
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test for method __repr__ of class TqdmHBox.
    """
    pbar = tqdm_notebook()
    # Test with a status bar
    pbar.container.pbar = proxy(pbar)
    pbar.update(1)
    # Test only with status infos
    pbar.container.pbar = None
    print(pbar.container.__repr__())


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:14:15.912011
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_equal
    from nose.tools import assert_true
    from nose.tools import assert_not_equal
    from nose.tools import assert_raises
    from nose.tools import assert_in
    from tqdm import tqdm_notebook

    # test if the iter function works properly
    l = range(1000)
    l_iter = tqdm_notebook(l)
    for (a, b) in zip(l, l_iter):
        assert_equal(a, b)

    # test iter with error
    def test_exception():
        l = range(1000)
        l_iter = tqdm_notebook(l)
        for i, _ in enumerate(l_iter):
            if i == 500:
                raise Exception
            else:
                pass

    assert_

# Generated at 2022-06-24 10:14:24.043243
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit tests for method tqdm_notebook.close.
    """
    progress_bar = tqdm_notebook(total=11)
    progress_bar.update(5)
    progress_bar.close()
    progress_bar.reset()
    progress_bar.update(9)
    progress_bar.close()
    progress_bar.reset()
    progress_bar.update(10)
    progress_bar.close()
    progress_bar.reset()
    progress_bar.update(11)
    progress_bar.close()
    progress_bar.reset()
    progress_bar.update(12)
    progress_bar.close()
    progress_bar.reset()



# Generated at 2022-06-24 10:14:25.050332
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep

    for _ in tqdm_notebook([1, 2, 3]):
        sleep(0)



# Generated at 2022-06-24 10:14:32.519984
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox(children=[HTML("left"), IProgress(min=0, max=100),
                                   HTML("right")])) == "<tqdm.notebook.TqdmHBox object: {p_bar_desc}%|█▏{bar}| {postfix}>"
    assert repr(TqdmHBox(children=[HTML("left"), IProgress(min=0, max=100),
                                   HTML("right")], pbar=HTML("test"))) == "test"

# Generated at 2022-06-24 10:14:43.358123
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from IPython.display import display  # , clear_output
    except ImportError:
        raise Exception("TqdmHBox inherits from IPython.html.widgets.HBox"
                        " and requires IPython >= 2.0")

    t = tqdm_notebook(1)
    # Test repr of hidden bar
    t.container.visible = False
    assert repr(t.container) == ''
    # Test repr of visible non-empty bar
    t.container.visible = True
    assert (repr(t.container) ==
            '\r  0%|      | 0/1 [00:00<?, ?it/s]')
    # Clean up
    t.close()


if __name__ == '__main__':
    test_TqdmHBox()

# Generated at 2022-06-24 10:14:52.126827
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    ncols = 100
    npbars = 9

    def test_status_printer(desc=''):
        cont = tqdm_notebook.status_printer(None, desc=desc, ncols=ncols)
        if len(cont.children) > 1:  # no progress bar from manual tqdm
            cont.children[-2].max += 1  # for test on bar_style change
        return cont

    # Test for ncols
    for i in [ncols, '100%', '100px']:
        try:
            test_status_printer(desc='ncols=%s, ' % repr(i))
        except Exception:
            raise
        else:
            print('.', end='')
    print('')

    # Test for description

# Generated at 2022-06-24 10:15:00.008760
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # tests:
    # - can set bar style to danger
    # - can clear a message
    # - can display twice same msg with same name
    # - handles unicode
    m = u"hello"
    w = tqdm_notebook(range(10))
    w.display(m)
    assert m == w.get_lock().children[-2].value
    w.display()
    assert '' == w.get_lock().children[-2].value
    w.container.style.bar_color = 'red'
    w.display()
    assert '' == w.get_lock().children[-2].value
    assert 'red' == w.get_lock().children[-2].style.bar_color
    w.display()
    assert '' in w.get_lock().children[-2].value
    w

# Generated at 2022-06-24 10:15:05.362312
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for constructor of class tqdm_notebook
    """

# Generated at 2022-06-24 10:15:16.758952
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from time import sleep
    with tqdm_notebook(total=4) as pbar:
        for i in range(4):
            pbar.update(1)
            sleep(0.01)
    assert pbar.n == 4
    assert not pbar.container.visible
    with tqdm_notebook(total=4, leave=True) as pbar:
        for i in range(4):
            pbar.update(1)
            sleep(0.01)
    assert pbar.n == 4
    assert pbar.container.visible
    with tqdm_notebook(total=None, miniters=1, mininterval=0.01, leave=True) as pbar:
        for i in range(4):
            pbar.update(1)

# Generated at 2022-06-24 10:15:29.889391
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from collections import namedtuple
    from .tqdm import FormatCustom

    fake_gui = namedtuple('FakeGUI',
                          ['container', 'children', 'bar_style', 'style'])

    format_custom = FormatCustom('{desc}: {percentage:3.0f}%|{bar}|')

    pbar = tqdm_notebook.status_printer(None, total=100, desc='Downloading',
                                        ncols='100px')

    ltext, pbar, rtext = pbar.children

    assert ltext.value == 'Downloading: '
    assert rtext.value == '0%|'
    assert pbar.value == 0
    assert pbar.max == 100
    assert pbar.bar_style == ''
    assert pbar.layout.width == '100px'



# Generated at 2022-06-24 10:15:33.938674
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tnrange
    from sys import stdout
    from time import sleep

    for _ in tnrange(2, desc='1st loop', leave=True):
        for i in tnrange(10, desc='2nd loop'):
            stdout.write('\r  i = %2d' % i)
            stdout.flush()
            sleep(.1)
        stdout.write('\r')
        stdout.flush()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:15:45.368690
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    "test to tqdm.notebook.tqdm_notebook.display"
    # Note: no display here (done inside the "with")
    with tqdm_notebook(total=3, file=None) as pbar:
        assert pbar.displayed
        _, pbar_, _ = pbar.container.children
        pbar_.max = 2
        pbar_.value = 2
        assert pbar.displayed
        pbar.display(bar_style='success', check_delay=False)
        assert pbar.container.visible is False
        pbar.display(bar_style='danger', check_delay=False)
        assert pbar.container.visible is True
        pbar.reset(total=None)  # no progress, display info style
        assert pbar.displayed

# Generated at 2022-06-24 10:15:54.532506
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    box = TqdmHBox()
    box.pbar = tqdm_notebook()
    print(box)
    print(box)
    # string is different, but acceptable
    assert str(box) in ['  0%|\\r | : : |  0/0 [00:00<?, ?it/s]',
                        '  0%|\\r | : : |  0/0 [00:00<?, ?it/s]',
                        '  0%|\\r | : : |  0/0 [00:00<?, ?it/s]']

# Generated at 2022-06-24 10:15:56.172196
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    The bar should be closed when the update raises an exception.
    """
    # Todo: create conditions and assert statements
    # raise NotImplementedError()
    pass

# Generated at 2022-06-24 10:15:59.430180
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=2, desc='tqdm_notebook') as pbar:
        for i in range(2):
            assert pbar.n == i
            pbar.update()



# Generated at 2022-06-24 10:16:09.736647
# Unit test for function tnrange
def test_tnrange():
    from .gui import tnrange
    from time import sleep
    from copy import deepcopy

    l = list(range(10))
    for i in tnrange(len(l), desc='1st loop'):
        sleep(0.1)
        for j in tnrange(len(l), desc='2nd loop', leave=False):
            sleep(0.1)
            for k in tnrange(len(l), desc='3nd loop'):
                sleep(0.1)
    # no `leave` option
    for _ in tnrange(len(l), desc='1st loop'):
        sleep(0.1)
        for _ in tnrange(len(l), desc='2nd loop'):
            sleep(0.1)
        # no option

# Generated at 2022-06-24 10:16:14.763721
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    for i in trange(5, desc='1st loop'):
        for j in trange(100, desc='2nd loop'):
            sleep(0.01)
        trange.reset()
        for j in trange(50, desc='3nd loop'):
            sleep(0.01)



# Generated at 2022-06-24 10:16:16.008346
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    x = tqdm_notebook(total=10)
    for i in range(10):
        assert hasattr(x, "update")
        x.update()

# Generated at 2022-06-24 10:16:18.754284
# Unit test for function tnrange
def test_tnrange():
    """ Unit tests for `tqdm.notebook.tnrange` """
    for _ in tnrange(3):
        pass

if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:16:29.262114
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as pbar:
        assert pbar.n == 0  # initial state
        pbar.update(3)
        assert pbar.n == 3  # advanced
        pbar.update(2)
        assert pbar.n == 5  # advanced
        pbar.update(-4)
        assert pbar.n == 1  # rolled back
        # Test update() with non-numeric arg (should have no effect)
        pbar.update('hi')
        assert pbar.n == 1  # unchanged
        # Test update() with numeric arg (should have no effect)
        pbar.update('4')
        assert pbar.n == 5  # advanced
        # Test update() with numeric arg (should have no effect)
        pbar.update('2')

# Generated at 2022-06-24 10:16:39.303772
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import sys
    import os
    import tempfile
    from tqdm.tests import common
    from tqdm import tqdm

    counter = 0

    def my_generator():
        global counter
        for i in range(4):
            counter += 1
            yield i

    for attr in common.default_entries:
        for gui in [True, False]:
            # NB: compat with local `tqdm.gui._tqdm` copy
            gui_tqdm = getattr(tqdm.gui, '_tqdm' if gui else '_tqdm_notebook')
            ps = [len(str(i)) for i in range(1, 5)]
            pbars = []

# Generated at 2022-06-24 10:16:49.361762
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tnrange.
    """
    # Create a null writer to suppress output
    null_writer = open(os.devnull, 'w')

    # Simple test
    with closing(StringIO()) as our_file:
        for i in tnrange(3, file=our_file):
            # test update
            tqdm.write('hi', file=our_file)

# Generated at 2022-06-24 10:16:56.186384
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from nose.tools import assert_equal
    from tqdm.tests import test_tqdm_notebook_1
    with test_tqdm_notebook_1():
        t = tqdm_notebook(range(1))
        assert_equal(repr(t), "\r|0/1 [ >                                                                                                       ]")



# Generated at 2022-06-24 10:16:58.622856
# Unit test for function tnrange
def test_tnrange():
    """
    Test tnrange
    """
    list(tnrange(10))
    list(tnrange(10, unit='0'))
    list(tqdm_notebook(_range(10), unit='0'))



# Generated at 2022-06-24 10:17:04.283195
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython.display import clear_output

    for i in tqdm_notebook(range(3), postfix={"foo": "bar"}):
        assert i == 0
        clear_output()
        break
    for i in tqdm_notebook(range(2), postfix={"foo": "bar"}):
        assert i == 0
        clear_output()
        break


# Generated at 2022-06-24 10:17:13.666413
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    with tqdm_notebook(total=10) as t:
        assert t.total == 10
        for i in t:
            assert i == t.n
            # Update progress bar state
            t.set_description("Processing %i" % i)
    # Simulate an error and check bar style
    try:
        for i in trange(10):
            assert i == t.n
            raise ZeroDivisionError
    except ZeroDivisionError:
        pass
    except:  # NOQA
        print("Unexpected error:", sys.exc_info()[0])
    assert t.container.children[-2].bar_style == 'danger'

# Generated at 2022-06-24 10:17:16.536061
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)

# Generated at 2022-06-24 10:17:21.884715
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Functional test of the constructor of class tqdm_notebook."
    # with tqdm_notebook(total=3, desc="Loading...", leave=False) as pbar:
    with tqdm_notebook(total=3, desc="Loading...") as pbar:
        for i in range(4):
            pbar.update()
        for i in range(4):
            pbar.update()



# Generated at 2022-06-24 10:17:26.883413
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    """
    Testing `TqdmHBox` constructor.
    """
    try:
        ipywidgets
    except:
        return
    hbox = TqdmHBox()
    assert hbox
    assert repr(hbox)
    assert hbox.__repr__(pretty=True)

# Generated at 2022-06-24 10:17:29.527532
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    max_iter = 10
    for i in tqdm_notebook(range(max_iter), unit='B', total=max_iter):
        sleep(0.01)

# Generated at 2022-06-24 10:17:39.961616
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import FormatCustomized

    # We have to create a pbar in parent class
    pbar = FormatCustomized(format_dict={"bar_format": "{bar}{postfix}"})
    # Create a HBox
    hbox = TqdmHBox(children=[], pbar=pbar)
    # Test if result is not empty
    assert isinstance(hbox.__repr__(), str)
    # Test if result is not empty
    assert isinstance(hbox._repr_json_(pretty=True), dict)
    # Test if result is not empty
    assert isinstance(hbox._repr_pretty_(), None)

if __name__ == '__main__':
    test_TqdmHBox___repr__()
    print("Completed tests!")

# Generated at 2022-06-24 10:17:50.714269
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    # Create object
    class T(TqdmHBox):
        pass

    T().pbar = tqdm_notebook()

if __name__ == '__main__':  # pragma: no cover
    # Test the widget bar
    if IPY:
        # (hacky) fix the places where `file` is overridden to avoid stderr
        # output of tqdm (which is not captured by the tests)
        tqdm_notebook.status_printer = tqdm_notebook.status_printer._deco
        tqdm_notebook.__init__ = tqdm_notebook.__init__._deco

        from .main import tqdm, __version__
        from time import sleep

        __doc__ = "tqdm IPython/Jupyter notebook widget"
        print

# Generated at 2022-06-24 10:17:58.451342
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from sys import stderr
    TqdmType = tqdm_notebook
    TqdmType.status_printer(fp=stderr, total=10, ncols='100%')
    TqdmType.status_printer(fp=stderr, total=10)
    TqdmType.status_printer(fp=stderr, total=101, ncols=100)
    TqdmType.status_printer(fp=stderr, total=101, ncols=101)



# Generated at 2022-06-24 10:18:08.601828
# Unit test for function tnrange
def test_tnrange():
    "Test tnrange function."
    # No widget
    with std_tqdm(unit_scale=True, leave=False, disable=True) as pbar:
        for i in trange(5, disable=True):
            pbar.update()

    # IPython 3,4 tqdm widget
    try:
        from IPython.html import widgets
        assert hasattr(widgets, 'IntProgress')
        from IPython.html.widgets import IntProgress
    except ImportError:
        raise unittest.SkipTest()

    for i in trange(3):
        for j in trange(3):
            for _ in trange(10):
                pass

    # IPython 2 tqdm widget

# Generated at 2022-06-24 10:18:19.138125
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Test method `__repr__` of class `TqdmHBox`
    """
    x = TqdmHBox()
    if hasattr(x, '_repr_json_'):
        assert x._repr_json_() == {}

    x.pbar = None
    assert x.__repr__() == ''

    tqdm_nb_bar = tqdm_notebook(total=1001)
    x.pbar = tqdm_nb_bar.container.pbar
    assert x.__repr__() == "[0/1,000]\r[>                                                               ] 0% ETA:  --:--:--"

    tqdm_nb_bar.total = 1
    tqdm_nb_bar.refresh()
    assert x.__repr__()

# Generated at 2022-06-24 10:18:28.828637
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # ipywidgets are not supported in command line Python
    if IProgress is None:
        return

    # Manually check the constructor
    tqdm_notebook(total=100, desc="Test", ascii=True)
    tqdm_notebook(total=100, desc="Test", ascii=False)
    with tqdm_notebook(total=100, desc="Test", ascii=True) as t:
        t.update(1)
    with tqdm_notebook(total=100, desc="Test", ascii=False) as t:
        t.update(1)

    # Test exception in context manager

# Generated at 2022-06-24 10:18:37.307486
# Unit test for function tnrange
def test_tnrange():
    for i in tnrange(4, leave=True):
        assert i == i
    for i in tnrange(4, display=False):
        assert i == i
    for i in tnrange(4, desc='tnrange', leave=False):
        assert i == i
    for i in tnrange(4, desc='tnrange', leave=True):
        assert i == i
    for i in tnrange(4, desc='tnrange', leave=True):
        assert i == i
    for i in tnrange(5, desc='tnrange', leave=True):
        assert i == i

if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:18:44.615295
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # dummy file
    fp = open("test_status_printer.txt", 'w')

    # Test info bar (no total)
    tqdm_notebook.status_printer(fp, None, desc="Test info bar")

    # Test error bar (total=None)
    tqdm_notebook.status_printer(fp, None, desc="Test error bar")

    # Test normal bar (total=100)
    tqdm_notebook.status_printer(fp, 100, desc="Test normal bar")

# Generated at 2022-06-24 10:18:47.729380
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(list(range(10))):  # NOQA
        pass
    for i in tqdm_notebook(list(range(10))):  # NOQA
        if i > 5:
            pass



# Generated at 2022-06-24 10:18:54.251491
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test display of various bar styles"""
    bar = tqdm_notebook(total=3)
    bar.display(bar_style='info')
    bar.display(bar_style='warning')
    bar.display(bar_style='danger')
    bar.display(bar_style='success')
    bar.display(close=True)


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:18:59.191831
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # with tqdm_notebook() as trange:
    #     for _ in trange:
    #         trange.display()
    with tqdm_notebook() as trange:
        trange.display()
        trange.display("msg")
        trange.display("", bar_style='info')
        trange.display("msg", bar_style='success')
        trange.display("msg", bar_style='danger')
        trange.display("", close=True)

# Generated at 2022-06-24 10:19:02.858116
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit tests for tqdm_notebook.status_printer method.
    """
    tqdm_notebook.status_printer(None)  # no error
    assert repr(tqdm_notebook.status_printer(None))



# Generated at 2022-06-24 10:19:06.838132
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Catch deprecation warnings"""
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter('always')
        t = tqdm_notebook(total=1)
        t.close()

        assert len(w) == 1
        assert issubclass(w[-1].category, DeprecationWarning)
        assert "tqdm.notebook.tqdm.close()" in str(w[-1].message)
        assert "tqdm.notebook.tqdm.close()" in str(w[-1].message)

# Generated at 2022-06-24 10:19:10.303077
# Unit test for function tnrange
def test_tnrange():
    """Test tnrange"""
    from .tests import pretest_posttest
    vals = []
    result = pretest_posttest(lambda: list(tnrange(3)), vals.append)
    if result is not None:
        raise result



# Generated at 2022-06-24 10:19:17.050417
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    def _try(d):
        p = TqdmHBox(pbar=d)
        return p.__repr__(False), p.__repr__(True)

    # empty
    assert _try({}) == ('\n', '\n')

    # plain
    assert _try({
        'bar_format': '{bar}',
        'total_width': 19,
        'filled_width': 4,
        'left_bar': 'foo',
        'right_bar': 'bar',
    }) == ('foo[#########      ]bar', 'foo[#      ]bar')

    # HTML

# Generated at 2022-06-24 10:19:20.959076
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for `tqdm.notebook.tqdm.clear`.
    """
    # NB: fp=None is important to avoid log output
    for _ in tqdm_notebook(range(10), fp=None, disable=True):
        pass



# Generated at 2022-06-24 10:19:23.622150
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import trange
    t = trange(0, 1, desc='bar')
    t.display()
    t.update(1)
    sleep(1)
    t.close()



# Generated at 2022-06-24 10:19:25.855597
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert repr(TqdmHBox(foo=1)) == TqdmHBox(foo=1).__repr__()

# Generated at 2022-06-24 10:19:33.064555
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import mock
    import platform
    # if not IPY:
    #     sys.stderr.write("\nMissing IPython Notebook dependencies.\n"
    #                      "Ignoring tqdm_notebook unit test."
    #                      "Try: pip install ipython "
    #                      "(for Python 2) or `pip install ipython notebook`"
    #                      "(for Python 3)\n\n")
    #     return

    if not IPY:
        pytest.skip("missing IPython", allow_module_level=True)

    from IPython.display import clear_output  # NOQA
    from IPython.display import display  # NOQA

    # Test for IPython notebook 2.x

# Generated at 2022-06-24 10:19:44.185146
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    import os
    import subprocess
    import locale
    locale.setlocale(locale.LC_ALL, '')

    this_dir = os.path.dirname(os.path.realpath(__file__))
    fname = 'test_tqdm_notebook_status_printer.ipynb'
    fpath = os.path.join(this_dir, fname)
    if sys.platform == 'win32':
        # pythonw can not change the directory to run ipynb notebooks
        old_cwd = os.getcwd()
        os.chdir(this_dir)
    subprocess.check_call(['jupyter', 'nbconvert', '--to', 'notebook',
                           '--execute', fpath])

# Generated at 2022-06-24 10:19:49.181607
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=9) as bar:
        assert bar.n == 0
        for obj in bar:
            assert bar.n == obj
            if obj == 5:
                raise KeyboardInterrupt
        assert 0, "Should have raised KeyboardInterrupt"
    # Check that the bar is hidden after the exception
    assert bar.container.visible == False
    assert len(bar.container.children) == 0

# Test of method close of class tqdm_notebook

# Generated at 2022-06-24 10:19:52.579437
# Unit test for function tnrange
def test_tnrange():
    """Test tnrange function"""
    for _ in tnrange(4):
        pass
    for _ in tnrange(100):
        pass
    for _ in tnrange(1, 100):
        pass
    for _ in tnrange(0, 2, 5):
        pass

test_tnrange()

# Generated at 2022-06-24 10:20:04.217494
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hb = TqdmHBox([HTML(), IProgress(), HTML()])
    hb.pbar = tqdm_notebook(total=5)
    hb.pbar.n = 2
    print(hb)
    assert hb._repr_json_() == {
            'n': 2,
            'total': 5,
            'format_meter': ' 2/5',
            'bar_format': '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]',
            'ascii': True,
            'smoothing': 0.3,
            'desc': None,
        }


if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-24 10:20:09.550206
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # method clear of class tqdm_notebook is a noop,
    # just test that it does not raises exception
    with tqdm_notebook(total=1, unit='B', unit_scale=True,
                       miniters=1, desc='Downloading ...') as t:
        t.clear()
        # test default keyword arguments
        t.clear(nolock=False)


if __name__ == '__main__':
    import doctest
    doctest.testmod(optionflags=doctest.NORMALIZE_WHITESPACE)

# Generated at 2022-06-24 10:20:17.546581
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm
    t = tqdm(range(3), leave=True)
    for _ in t:
        # do nothing
        pass
    assert t.last_print_n == 3
    assert t.last_print_n_width == 1
    assert t.n == 3
    r = t.reset()
    assert t.last_print_n == 0
    assert t.last_print_n_width == 1
    assert t.n == 0
    assert r is t


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:20:23.322016
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as pbar:
        for i in _range(10):
            pbar.update()
        assert pbar.n == 10
        pbar.update(1)
        assert pbar.n == 11
        pbar.update(5)
        assert pbar.n == 16
        pbar.update(-1)
        assert pbar.n == 15
        pbar.update(-5)
        assert pbar.n == 10



# Generated at 2022-06-24 10:20:28.731002
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import trange
    from IPython.display import clear_output

    t = trange(3, desc='Updating')
    for i in t:  # will update desc and bar display below
        t.set_description('Done {}'.format(i))  # update desc
        t.set_postfix(i=i)  # update bar display
        sleep(0.25)
        clear_output()  # clear current bar display



# Generated at 2022-06-24 10:20:39.967630
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from tqdm import tqdm
    from time import sleep
    from sys import platform
    try:
        from tqdm.notebook.tests.utils import capture
    except ImportError:
        capture = lambda: None

    with capture() as cap, tqdm(total=100, disable=False) as t:
        sleep(0.01)
        t.display('{l_bar}|{bar}|{n_fmt}/{total_fmt}  ',
                  check_delay=False)
        # Expected behaviour:
        #   MacOS line-buffer: length = <w2> + <fmt> = 44
        #   Linux line-buffer: length = <w2> + 2 + <fmt> = 45
        #   Windows line-buffer: length = <w2>

# Generated at 2022-06-24 10:20:46.882919
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    TqdmHBox.pbar = tqdm.tqdm
    tqdm.tqdm.format_dict = dict(bar_format="{l_bar}<{bar}>{r_bar}")
    repr(TqdmHBox())
    tqdm.tqdm.format_dict = dict(bar_format="{l_bar}<{bar}>{r_bar}", ascii=True)
    repr(TqdmHBox())


# Test
if __name__ == '__main__':
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import sys


# Generated at 2022-06-24 10:20:48.394974
# Unit test for function tnrange
def test_tnrange():
    for _ in tnrange(4):
        pass



# Generated at 2022-06-24 10:20:57.656187
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    class TestTqdmNotebook(tqdm_notebook):
        def display(self, **_):
            return super(tqdm_notebook, self).display(**_)

    T = TestTqdmNotebook()
    assert T.displayed is None

    T = TestTqdmNotebook(3, unit_scale=1)
    assert repr(T) == '3it [00:00, ?it/s]'
    assert T.displayed is None
    assert T.display() is None
    assert T.displayed

    T = TestTqdmNotebook(5, unit='yo', unit_scale=1)
    assert repr(T) == '5yo [00:00, ?yo/s]'
    assert T.displayed is None
    assert T.display() is None
    assert T.displayed

# Generated at 2022-06-24 10:21:02.529842
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Check that the close method does not break"""
    for total in [None, 100]:
        for leave in [True, False]:
            pbar = tqdm_notebook(total=total, leave=leave)
            if total:
                for i in range(total - 10):
                    pbar.update(1)
            pbar.close()

# Generated at 2022-06-24 10:21:11.072759
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=2, leave=True) as pbar0:
        pbar0.set_description('description0')
        with tqdm_notebook(total=2, leave=False) as pbar1:
            pbar1.set_description('description1')
            with tqdm_notebook(total=2, leave=False) as pbar2:
                pbar2.set_description('description2')
                for __ in (pbar0, pbar1, pbar2):
                    pbar2.update()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-24 10:21:21.543179
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import unittest
    import sys
    import os
    import re
    import shutil

    class FakeStderr(object):
        def __init__(self):
            self.value = ''

        def write(self, x):
            self.value += x

    class TqdmNotebook_Tests(unittest.TestCase):

        def setUp(self):
            self.output_dir = "test_tqdm_notebook"
            if not os.path.exists(self.output_dir):
                os.makedirs(self.output_dir)
            self.cur_file = os.path.join(self.output_dir, "current_output.txt")
            self.ref_file = os.path.join(self.output_dir, "ref_output.txt")


# Generated at 2022-06-24 10:21:32.668032
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import StringIO
    try:
        from unittest.mock import patch
    except ImportError:  # Py2
        from mock import patch

    with patch('sys.stderr', new=StringIO()):

        t = tqdm_notebook(total=2, leave=False)
        t.close()
        assert not t.disable
        assert t.leave

        t = tqdm_notebook(total=2, leave=True)
        t.close()
        assert not t.disable
        assert t.leave

        t = tqdm_notebook(total=2, leave=False)
        t.n = 1
        t.close()
        assert not t.disable
        assert t.leave

        # test in manual mode

# Generated at 2022-06-24 10:21:38.111691
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # we want to keep params, but reset the iteration status
    # without having to know the params again
    t = tqdm_notebook(total=100, file=sys.stdout, unit='B')
    t.update(50)
    t.reset()
    t.update(50)
    t.close()
    # the bar should have been displayed twice, full each time
    # the second time, the bar should have been erased and re-displayed



# Generated at 2022-06-24 10:21:42.557462
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=5) as t:
        t.reset()
        assert t.total == 5
        assert t.n == 0
        assert t.container.children[-2].max == 5
        t.update()
        t.update()
        t.update()
        t.reset(10)
        assert t.total == 10
        assert t.n == 0
        assert t.container.children[-2].max == 10

# Generated at 2022-06-24 10:21:53.445721
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Unit test for method update of class tqdm_notebook"""
    import time
    bar = tqdm_notebook(total = 10)
    def test():
        for i in range(10):
            # Add small delay so that validator can make the updates without
            # exploding the browser.
            time.sleep(0.1)
            bar.update()
    try:
        test()
    except:
        print("!!! Transient method update() failed")


# Generated at 2022-06-24 10:22:01.660117
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .tests.test_tqdm import _range
    from unittest import mock

    tq = tqdm_notebook(_range(10), unit='B')

    # Test 1: check that tq.close() works when n == total
    with mock.patch('IPython.display.clear_output') as mock_clear_output:
        tq.close()
        assert mock_clear_output.call_count == 1

    # Test 2: check that tq.close() works when n < total
    with mock.patch('IPython.display.clear_output') as mock_clear_output:
        with mock.patch('IPython.display.display') as mock_display:
            tq.reset(total=20)
            tq.close()
            assert mock_clear_output.call_count == 0


# Unit

# Generated at 2022-06-24 10:22:11.849184
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from ipywidgets import FloatProgress
    from IPython.display import display

    # test if reset(total=None) works
    for n in range(1, 3):
        # create a tqdm_notebook
        with tqdm(total=n) as t:
            # display and update tqdm_notebook
            display(t.container)
            t.update(n)
        # reset tqdm_notebook
        t.reset(total=None)
        # display and update tqdm_notebook
        display(t.container)
        t.update(n)
        # close tqdm_notebook
        t.close()

    # test if reset(total=value) works

# Generated at 2022-06-24 10:22:14.856367
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    hbox = TqdmHBox(children=['string', 'string', 'string'])
    assert '<HBox' in repr(hbox)
    assert 'string' in str(hbox)
    assert 'string' in hbox._repr_pretty_(None)

# Generated at 2022-06-24 10:22:22.310244
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from pprint import pprint

    def _TqdmHBox_repr(pbar):
        if not isinstance(pbar, TqdmHBox):
            return '{}'.format(repr(pbar))
        if hasattr(pbar, 'format_dict'):
            d = pbar.format_dict
            # remove {bar}
            d['bar_format'] = (d['bar_format'] or "{l_bar}<bar/>{r_bar}").replace(
                "{bar}", "<bar/>")
            return pbar.format_meter(**d)
        else:
            return repr(pbar)

    # default repr
    pbar = tqdm_notebook(total=0)

# Generated at 2022-06-24 10:22:29.385775
# Unit test for function tnrange
def test_tnrange():
    """
    Unit testing for `tqdm.notebook.tnrange`
    """
    from time import sleep
    total = 5
    with tnrange(total) as t:
        for i in t:
            sleep(0.5)

    assert t.n == total


if __name__ == "__main__":
    r = tnrange(4)
    for i in r:
        r.set_description("current loop is {}".format(i))