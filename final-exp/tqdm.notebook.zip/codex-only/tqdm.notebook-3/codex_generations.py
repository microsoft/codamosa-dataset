

# Generated at 2022-06-24 10:12:34.897702
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    # if tqdm.notebook is unavailable, exit.
    if IPY == 0:
        return
    # test the status_printer method of tqdm.notebook in non-notebook environment
    # this may throw an exception, if so, exit.
    # if the execution passes, it means the method is OK.
    tqdm_notebook_test = tqdm_notebook(total=1)
    tqdm_notebook_test.status_printer(None, 1, '')

# Generated at 2022-06-24 10:12:44.720992
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test tqdm_notebook.status_printer()
    if IPY in (0,):  # pragma: no cover
        raise Exception("""IPython/Jupyter is required to test """
                        """tqdm_notebook.status_printer().""")
    # prepare ipython display
    from IPython.display import clear_output
    clear_output(wait=True)
    # prepare tqdm_notebook
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook.status_printer(None, total=4, desc='Hello world!', ncols=None)
    tqdm_notebook.status_printer(None, total=4, desc='Hello world!', ncols=60)

# Generated at 2022-06-24 10:12:56.745625
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        import pytest  # noqa
    except ImportError:
        raise RuntimeError(
            "tqdm.notebook tests require the 'pytest' library.")
    import logging

    class LoggingCapture(logging.Filter):
        """
        Logging filter to capture, for test purposes only.
        """

        def filter(self, record):
            self.messages = getattr(self, 'messages', [])
            self.messages.append(record.getMessage())

    with LoggingCapture() as l:
        try:
            from tqdm.notebook import tqdm_notebook
        except ImportError:
            pytest.skip("no IPython/Jupyter")

        with tqdm_notebook(total=10) as pbar:
            assert l.messages == ['']

# Generated at 2022-06-24 10:13:04.876054
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook
    """
    with tqdm_notebook(total=None) as pbar:
        pbar.display(bar_style='warning')
        pbar.close()
        assert pbar.container.children[-2].bar_style == 'warning'
    assert not pbar.container.children[-2].visible

    with tqdm_notebook(total=None) as pbar:
        assert not pbar.container.children[-2].visible
    assert not pbar.container.children[-2].visible

    for total in [None, 0, 1, 2]:
        with tqdm_notebook(total=total) as pbar:
            pbar.display(bar_style='danger')
            pbar.close()

# Generated at 2022-06-24 10:13:08.813520
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test on the IPython representation of the progress bar widget.
    """
    from .tests.test_notebook import test_TqdmHBox___repr__ as func
    print("TqdmHBox.__repr__: ", end='')
    func(TqdmHBox, tqdm_notebook)

# Generated at 2022-06-24 10:13:11.894700
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        list(tqdm_notebook(xrange(1)))
    except NameError:
        pass  # xrange only available on Python2
    list(tqdm_notebook(_range(1)))  # Test range on Python3

# Generated at 2022-06-24 10:13:20.320782
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from random import random

    pbar = tqdm_notebook(total=50, desc='dots')
    for i in range(50):
        pbar.update(1)
        sleep(random())
    pbar.close()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-24 10:13:32.619286
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from warnings import catch_warnings
    from tempfile import mkstemp
    from os import remove
    from io import open
    for widget_type in (tqdm_notebook, tqdm):
        t = widget_type(total=100, disable=False,
                        leave=True, position=0, colour='yellow')
        assert t.displayed
        t.display(desc="Test 1", bar_style='info')
        t.display(desc="Test 2", bar_style='warning')
        t.display(desc="Test 3", bar_style='danger')
        t.display(desc="Test 4", bar_style='success')
        t.display(desc="Test 5", bar_style='')
        t.close()
        assert t.displayed


# Generated at 2022-06-24 10:13:44.878430
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=3, desc="testing constructor") as pbar:
        assert pbar.gui
        assert pbar.container is not None
        assert pbar.container.children[-2].max == 3
        assert pbar.container.children[-2].value <= 1
        assert escape('testing constructor') in pbar.container.children[0].value
        assert pbar.container.children[-1].value == ''
        pbar.update()
        assert pbar.container.children[-2].value <= 2
        pbar.close()
        # Check for duplicated HBox or redundant progress bar
        assert len(pbar.container.children) == 3
        assert pbar.container.children[0]._dom_classes == ('widget-label',)

# Generated at 2022-06-24 10:13:59.547684
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tqdm as tqdm_gui
    t = tqdm_notebook(ascii=True, desc='   ', leave=False)
    # won't fail if clear() is not implemented
    t.update(1)
    t.close()
    # check tqdm_notebook close() is called in tqdm_gui clear()
    t = tqdm_gui(ascii=True, desc='   ', leave=False)
    t.clear()
    # check tqdm_notebook clear() is not called in tqdm_gui clear()
    t = tqdm_notebook(ascii=True, desc='   ', leave=False)
    t.clear()
    # check clear() updates bar on the fly

# Generated at 2022-06-24 10:14:04.582549
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in (True, False):
        for total in (None, 10):
            for n in (1, total, total + 1):
                # Manual mode
                t = tqdm_notebook(total=total, leave=leave)
                t.update(n)
                t.close()
                # Automatic mode
                try:
                    with tqdm_notebook(total=total, leave=leave) as t:
                        #  _ = [t.update() for _ in range(n)]
                        _ = [t.update(1) for _ in tqdm(_range(n))]
                except BaseException:
                    pass


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-24 10:14:09.791060
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm_notebook(range(4), leave=True):
        sleep(.1)
        if i == 1:
            tqdm_notebook.reset()
    print("done")

# Generated at 2022-06-24 10:14:19.648397
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # do not use 'from tqdm import trange' here
    from tqdm.notebook import trange
    for _ in trange(2):  # do NOT use a for loop to avoid displaying twice
        with trange(10) as t:
            for i in t:
                t.set_description("Processing %i" % i)
                t.set_postfix(loss=i)
                t.display(check_delay=False)  # display immediately
                t.display(pos=i)  # update position in display
                assert t.colour == t.container.children[-2].style.bar_color
                t.colour = 'red'
                t.display(msg='', check_delay=False)  # clear previous output
                t.display(bar_style='info', check_delay=False)

# Generated at 2022-06-24 10:14:28.090301
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test method status_printer of class tqdm_notebook.
    """
    mytqdm = tqdm_notebook()
    mytqdm.status_printer(None, 2, "test", 50)
    mytqdm.status_printer(None, None, "test2", 50)


if __name__ == '__main__':
    # Unit test
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-24 10:14:40.298003
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Prepare IPython progress bar
    if IProgress is None:  # #187 #451 #558 #872
        raise ImportError("IProgress not found. Please update jupyter and ipywidgets. "
                          "See https://ipywidgets.readthedocs.io/en/stable/user_install.html")
    pbar = IProgress(min=0, max=100)
    pbar.value = 1
    pbar.bar_style = 'info'
    pbar.layout.width = "20px"
    ltext = HTML()
    rtext = HTML()
    pbar.layout.display = 'none'  # do not display the progress bar
    container = TqdmHBox(children=[ltext, pbar, rtext])

    # Test prettify

# Generated at 2022-06-24 10:14:44.091856
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10, desc='Test', unit='it') as t:
        assert (t.total == 10 and t.unit == 'it' and
                t.desc == 'Test' and t.displayed)
        for i in range(10):
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-24 10:14:52.608915
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():  # pragma: no cover
    from nose.tools import assert_equal
    from tqdm import tqdm
    # ipywidgets version >=5.2.2, should be tested in conda and non-conda env:
    # eg. ipywidgets 7.1.1, jupyter 1.0.0
    try:
        from unittest.mock import patch, Mock
        from IPython import get_ipython
        from IPython.display import HTML as HTML2
        from IPython.core.getipython import get_ipython
    except ImportError:
        from mock import patch, Mock
        get_ipython = Mock(return_value=None)

# Generated at 2022-06-24 10:14:56.781084
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from nose import SkipTest

    try:
        # Make sure method update works even
        # when previous display has been cleared
        pbar = tqdm_notebook(total=7)
        # Clear previous display
        try:
            pbar.container.close()
        except AttributeError:
            pbar.container.visible = False
        # Try updating
        for _ in range(7):
            pbar.update()
    except Exception as e:
        raise SkipTest('Could not create a tqdm_notebook widget.'
                       '\nError: {e}'.format(e=e))



# Generated at 2022-06-24 10:14:57.278347
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pass

# Generated at 2022-06-24 10:15:07.302095
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    pbar = tqdm_notebook(total=7)
    try:
        for i in range(7):
            sleep(0.1)
            pbar.update()  # update progress bar manually
    finally:
        pbar.close()
    pbar.reset(total=3)
    assert pbar.total == 3
    try:
        for i in range(3):
            sleep(0.1)
            pbar.update()  # update progress bar manually
    finally:
        pbar.close()

# Generated at 2022-06-24 10:15:17.613218
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from unittest import TestCase
    from .tests_tqdm import pretest_posttest

    # Create a mock for tqdm_notebook class
    class tqdm_notebook:
        def __init__(self, *args, **kwargs):
            return

    # Execute the tested function
    @pretest_posttest(tqdm_notebook)
    def test():
        from .tqdm_notebook import tqdm_notebook
        from .tests_tqdm import pretest_posttest_decor

        # Check if the clear method of the class tqdm_notebook has no error
        @pretest_posttest_decor(tqdm_notebook)
        def test_method():
            # Create a random tqdm_notebook object
            tqdm_object = tq

# Generated at 2022-06-24 10:15:23.755541
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    try:
        from IPython.display import Image
        Image
    except ImportError:
        return
    a = TqdmHBox()
    a.pbar = TqdmHBox()
    repr(a)
    repr(a._repr_json_())

# Generated at 2022-06-24 10:15:32.887833
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(total=3)
    assert bar.n == 0
    assert bar.total == 3
    assert bar.displayed
    try:
        bar.update()
    except Exception:  # TODO: narrow exception handling
        bar.disp(bar_style='danger')
        raise
    bar.reset(total=5)
    assert bar.n == 0
    assert bar.total == 5
    try:
        bar.update()
    except Exception:  # TODO: narrow exception handling
        bar.disp(bar_style='danger')
        raise
    bar.close()
    assert bar.displayed

# Generated at 2022-06-24 10:15:41.045873
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tnrange
    from IPython.testing.globalipapp import get_ipython
    ip = get_ipython()
    # there is no IPython in Travis, Cirrus or AppVeyor
    if ip is None:
        return
    ip.magic("matplotlib inline")
    for i in tnrange(5, desc='1st loop'):
        for j in tnrange(5, desc='2nd loop'):
            ip.magic("timeit")
    assert i == 4
    assert j == 4

# Generated at 2022-06-24 10:15:43.618541
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import tqdm
    it = tqdm.tqdm_notebook(range(10))
    [i for i in it]
    return it


# Generated at 2022-06-24 10:15:46.760763
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep

    for i in tqdm_notebook(iterable=_range(3), desc='TEST'):
        sleep(1)



# Generated at 2022-06-24 10:15:55.115928
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    kwargs = {'desc': 'test', 'total': 1000}  # no ncols

    # make an IPython Notebook progress bar widget
    note_progress_bar1 = tqdm_notebook.status_printer(None, 100, 'x')
    assert isinstance(note_progress_bar1, TqdmHBox)
    assert kwargs['desc'] in str(note_progress_bar1)
    assert '100' in str(note_progress_bar1)
    assert 'x' in str(note_progress_bar1)

    # with kwarg 'ncols'
    note_progress_bar2 = tqdm_notebook.status_printer(None, 100, 'y', 20)
    assert isinstance(note_progress_bar2, TqdmHBox)
    assert kw

# Generated at 2022-06-24 10:16:02.687450
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method `status_printer` of class `tqdm_notebook`.
    """
    print("\nVerify method `status_printer` of class `tqdm_notebook`:")
    from .tests import tqdm_tests
    tqdm_tests.test_tqdm_status_printer_gui = lambda: tqdm_tests.test_status_printer(
        tqdm_notebook)
    tqdm_tests.test_tqdm_status_printer_gui()


# Cleanup namespace
del absolute_import, division, print_function, unicode_literals

# Generated at 2022-06-24 10:16:05.572765
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # if IProgress is None, this function will raise ImportError
    assert(str(type(tqdm_notebook.status_printer(_, total=10))) ==
           "<class 'tqdm.notebook.TqdmHBox'>")

# Generated at 2022-06-24 10:16:15.886169
# Unit test for function tnrange
def test_tnrange():
    for _ in tnrange(3):
        pass
    for _ in tnrange(12):
        pass
    for _ in tnrange(0, 3):
        pass
    for _ in tnrange(1, 12):
        pass
    for _ in tnrange(1, 12, 2):
        pass
    for _ in tnrange(2, 13, 2):
        pass
    for _ in tnrange(1, 13, 2):
        pass
    for _ in tnrange(3, 0, -1):
        pass
    for _ in tnrange(12, 0, -1):
        pass
    for _ in tnrange(12, 1, -1):
        pass
    for _ in tnrange(13, 1, -2):
        pass

# Generated at 2022-06-24 10:16:26.240562
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from time import sleep

    _no_tqdm = lambda x: x

    try:  # IPython 4.x + Python 2.x
        from ipywidgets import IntProgress
    except ImportError:
        try:  # IPython 3.x + Python 2.x
            from IPython.html.widgets import IntProgress
        except ImportError:
            try:  # IPython 2.x
                from IPython.html.widgets import IntProgressWidget as IntProgress
            except ImportError:
                IntProgress = _no_tqdm
        else:  # IPython 3.x
            from IPython.display import display
    else:  # IPython 4.x
        from ipywidgets import HBox, HTML
        from IPython.display import display


# Generated at 2022-06-24 10:16:36.816718
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    if IPY <= 0:  # pragma: no cover
        return
    from io import BytesIO
    from optparse import make_option
    from sys import stderr, stdout
    if not hasattr(stderr, 'isatty'):
        stderr.isatty = lambda: False
    if not hasattr(stdout, 'isatty'):
        stdout.isatty = lambda: False
    isatty = stderr.isatty() or stdout.isatty()
    bar = tqdm_notebook(total=300, leave=False, desc="Test TqdmHBox", ascii=not isatty)
    bar.display(close=True)
    bar.update(10)

# Generated at 2022-06-24 10:16:38.258781
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    assert TqdmHBox._repr_json_(TqdmHBox()) == {}

# Generated at 2022-06-24 10:16:48.652422
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Tests the method update of class tqdm_notebook.

    It is a quick test because the focus is on the update method, not the
    initialization.
    """

# Generated at 2022-06-24 10:17:00.766278
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Create a tqdm_notebook object for testing
    # Note: actual progress bar is not ready at that point
    #       so bar_format cannot be tested
    total = 10
    t = tqdm_notebook(total=total)
    # Check that the class TqdmHBox has a method _repr_pretty_
    assert hasattr(t.container, "_repr_pretty_"), \
        "class TqdmHBox has no method _repr_pretty_"
    assert hasattr(t.container, "_repr_json_"), \
        "class TqdmHBox has no method _repr_json_"
    # Check that the method _repr_pretty_ returns a string
    # that contains the bar with the propert width
    width = total * ' '
    pretty_repr_string = t

# Generated at 2022-06-24 10:17:07.025920
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # prepare
    tqdm_notebook.status_printer(file=None)
    tqdm_notebook.status_printer(file=None, total=None, desc=None, ncols=100)
    tqdm_notebook.status_printer(file=None, total=None, desc=None, ncols="100%")
    tqdm_notebook.status_printer(file=None, total=None, desc=None, ncols="100px")
    tqdm_notebook.status_printer(file=None, total=None, desc=None, ncols="100")
    tqdm_notebook.status_printer(file=None, total=None, desc=None, ncols=None)

# Generated at 2022-06-24 10:17:17.643377
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=2) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        pbar.update(1)
    with tqdm_notebook(total=2, file=None) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        pbar.update(1)
    # no exception
    with tqdm_notebook(total=2, file=None, disable=None) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        pbar.update(1)
    with tqdm_notebook(total=2, disable=True) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        assert str(pbar) == ""
        pbar.update

# Generated at 2022-06-24 10:17:26.279679
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from io import StringIO
    from IPython.display import clear_output

    with StringIO() as f:
        b = tqdm_notebook(["1", "2"], file=f, leave=True)
        clear_output()
        assert b.displayed  # displayed correctly after instantiation
        b.reset()
        assert not b.displayed  # hidden on reset b/c leave=True
        b.reset(total=4)
        assert not b.displayed  # not displayed on reset(total=...) either

        b = tqdm(["1", "2"], file=f, leave=False)
        clear_output()
        assert b.displayed  # displayed correctly after instantiation
        b.reset()
        assert b.displayed  # not hidden on reset b/c leave=False

# Generated at 2022-06-24 10:17:35.929539
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit tests for method `display` of class `tqdm_notebook`.

    Returns
    -------
    None.
    """
    t = tqdm_notebook(total=10)
    assert t.displayed is False
    t.display()
    assert t.displayed is True
    t.display()
    assert t.displayed is True
    t.display(close=True)
    assert t.displayed is False
    t.close()
    assert t.displayed is False
    t.display(close=True)
    assert t.displayed is False
    t = tqdm_notebook(total=10, leave=True)
    t.display(close=True)
    assert t.displayed is True
    t.close()  # deleting the progress bar

    # Test progress bar is correctly

# Generated at 2022-06-24 10:17:43.354245
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(None)
    tqdm_notebook.status_printer(None, 1)
    tqdm_notebook.status_printer(None, 1, "desc")
    tqdm_notebook.status_printer(None, total=1)
    tqdm_notebook.status_printer(None, 1, "desc", 10)
    tqdm_notebook.status_printer(None, 1, "desc", 100)
    tqdm_notebook.status_printer(None, 1, "desc", 100)


# Simple test for class tqdm_notebook

# Generated at 2022-06-24 10:17:47.563844
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from ipywidgets import FloatProgress
    from IPython.display import display, clear_output

    with tqdm(total=10) as pbar:
        assert isinstance(pbar, tqdm_notebook)
        assert pbar.container is pbar.widget.children[0].children[-2]
        assert isinstance(pbar.widget, HBox)
        assert pbar.widget.children[0].layout.height == 'auto'
        assert pbar.widget.children[-1].layout.height == 'auto'
        assert isinstance(pbar.container, FloatProgress)

        for i in range(10):
            sleep(0.01)
            pbar.update()

    clear_output()

# Generated at 2022-06-24 10:17:52.513242
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # define some dummy data
    data = list(range(100))
    with TqdmExperimentalWarning():
        for _ in tqdm(data, desc="clear_test"):
            pass
    with TqdmExperimentalWarning():
        # check if clear method of the class tqdm_notebook works
        for _ in tqdm(data, desc="clear_test"):
            pass
            tqdm.clear(wait=True)

# Generated at 2022-06-24 10:18:04.116809
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    """
    Unit test for method `update` of class `tqdm_notebook`.
    """
    import sys
    from tqdm import tqdm_gui
    try:
        from unittest.mock import patch
        get_ipython = lambda: sys
    except ImportError:
        try:
            from mock import patch  # python-mock on Fedora
            get_ipython = lambda: sys.modules['IPython']
        except ImportError:
            raise unittest.SkipTest("requires ipython/mock")


# Generated at 2022-06-24 10:18:11.398426
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    msg = 'test'
    with tqdm_notebook(total=3, desc=msg) as t:
        t.update(1)
        assert re.search(re.escape(msg) + r'[\s\S]*1/3', t.container.__repr__())
        t.update(1)
        assert re.search(re.escape(msg) + r'[\s\S]*2/3', t.container.__repr__())
        t.update(1)
        assert re.search(re.escape(msg) + r'[\s\S]*3/3', t.container.__repr__())



# Generated at 2022-06-24 10:18:18.804603
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import IPython
    if IPython.get_ipython() is None:  # pragma: no cover
        raise RuntimeError("tqdm_notebook.test_tqdm_notebook_display()"
                           " called outside of ipython environment")

    # Create a progress bar
    pbar = tqdm_notebook(total=1, desc="Test", ncols=100)

    # Check initial display
    assert pbar.container.layout.width == "100px"
    assert pbar.container.layout.flex == "2"
    assert isinstance(pbar.container, TqdmHBox)

    # Check display(msg=None)
    pbar.display()
    assert pbar.container.children[0].value == "Test"

    # Check display(msg="")

# Generated at 2022-06-24 10:18:28.691953
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # For coverage, IPython 4.x / 3.x / 2.x / 0.x
    global IPY

    # Test IPython 4.x
    IPY = 4
    method = tqdm_notebook.status_printer
    assert method is not None
    test_tqdm_notebook_status_printer.tried = True

    # Test IPython 3.x
    IPY = 3
    method = tqdm_notebook.status_printer
    assert method is not None

    # Test IPython 2.x
    IPY = 2
    method = tqdm_notebook.status_printer
    assert method is not None

    # Test IPython 0.x
    IPY = 0
    method = tqdm_notebook.status_printer
    assert method is not None

    # Test

# Generated at 2022-06-24 10:18:37.842762
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test the widget's iterability
    # Test for Jupyter Notebook
    if IPY == 4:
        widgets = ipywidgets
    else:
        from IPython.html import widgets  # NOQA: F401

    from time import sleep
    import random
    iterable = range(100)
    for _ in tqdm_notebook(iterable, desc='1st loop'):
        assert len(widgets.widget_manager.statuses) == 1
        sleep(0.01 * random.random())
    for _ in tqdm_notebook(iterable, desc='2nd loop'):
        assert len(widgets.widget_manager.statuses) == 1
        sleep(0.01 * random.random())

# Generated at 2022-06-24 10:18:43.685277
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    # Enable `leave=True` so bars are not removed
    with tqdm(leave=True, total=3) as t:
        for x in range(10):
            t.set_description('Processing ' + str(x))
            sleep(0.1)
            t.update()


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-24 10:18:49.713741
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    t = tqdm_notebook(total=3)
    assert t.total == 3
    for i in t:
        sleep(.01)

    assert t.n == 3
    assert t.container.children[-2].bar_style == 'success'
    assert t.container.children[-2].max == 3
    t.reset()
    assert t.n == 0
    assert t.container.children[-2].bar_style == ''
    assert t.container.children[-2].max == 3

if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-24 10:18:55.261918
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from .std import sys
    from .std import time

    pbar = tqdm_notebook(total=10)
    assert pbar.container.children[-2].bar_style == ''
    assert pbar.container.children[-2].max == 10
    pbar.update(9)
    pbar.close()
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    pbar.reset(total=10)
    assert pbar.container.children[-2].bar_style == ''
    pbar.close()  # do nothing if leave=True
    assert pbar.container.children[-2].bar_style == 'success'
    assert pbar.container.children[-2].value == 10
    pbar

# Generated at 2022-06-24 10:18:58.212407
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert not TqdmHBox().__repr__(pretty=True)
    assert not TqdmHBox().__repr__(pretty=False)

# Generated at 2022-06-24 10:19:04.468437
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tests_tqdm._utils import hbar_repr

    d = TqdmHBox(children=[HTML(), FloatProgress(), HTML()])
    d.pbar = proxy(object())

    d.pbar.format_dict = {'n': 10, 'ncols': 0, 'total': 10, 'elapsed': 0,
                          'desc': '', 'unit': '', 'bar_format': '{bar}',
                          'rate': 0, 'rate_noinv': 0, 'rate_noinv_scale': 0,
                          'rate_scale': 0, 'l_bar': '', 'bar': '', 'r_bar': ''}
    assert d.__repr__() == hbar_repr(10)[0]


# Generated at 2022-06-24 10:19:07.386086
# Unit test for function tnrange
def test_tnrange():
    with tnrange(4) as t:
        for i in t:
            assert i < 4


if __name__ == "__main__":
    test_tnrange()

# Generated at 2022-06-24 10:19:12.008959
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from .gui import tqdm
    for i in tqdm(range(10), desc='0th loop'):
        for j in tqdm(range(5), desc='1st loop'):
            for k in tqdm(range(100), desc='2nd loop'):
                sleep(0.01)
    tqdm.clear()

# Generated at 2022-06-24 10:19:22.613992
# Unit test for function tnrange
def test_tnrange():
    """Unit test for class tnrange"""
    from time import sleep
    try:
        import numpy as np
        np.seterr(all="ignore")
        assert list(tnrange(np.array([1, 2, 3]))) == [1, 2, 3]
    except ImportError:
        pass

    # Test iterable argument
    assert list(tnrange(10)) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]

    # Test leave
    trange(1, 7).close()
    with tnrange(7) as bar:
        for i in bar:
            assert not bar.n == bar.last_print_n
            if i == 6:
                bar.update()

    # Test __iter__ method
    bar = tnrange(7)
    assert next

# Generated at 2022-06-24 10:19:30.536463
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for total in [None, 8]:
        for leave in [True, False]:
            for initial in [None, 10]:
                for unit_scale in [None, 1, 1e6]:
                    with tqdm_notebook(
                            total=total, leave=leave, unit_scale=unit_scale,
                            position=initial) as t:
                        a = [1] * (t.total or 10)
                        for i in a:
                            t.update()
                        t.reset(total=len(a))
                        for i in a:
                            t.update()

# Generated at 2022-06-24 10:19:42.603388
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for `tqdm.notebook.tqdm_notebook`.

    Make sure the bar displays correctly and cleanly exits at the end.
    """
    import sys
    try:
        from StringIO import StringIO as SIO
    except ImportError:
        from io import StringIO as SIO
    try:
        from tqdm.notebook import tqdm_notebook as tqdm
    except ImportError:
        from tqdm.notebook import tqdm_notebook

# Generated at 2022-06-24 10:19:51.579057
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    from unittest import TestCase


# Generated at 2022-06-24 10:20:03.197495
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test tqdm_notebook.status_printer"""
    # Test horizontal bar and width
    output = tqdm_notebook.status_printer(None, 9, '', ncols=100)
    from IPython.display import display
    display(output)
    assert output.layout.height == "30px"
    assert output.layout.width == "100%"
    assert output.layout.display == "inline-flex"
    assert output.layout.flex_flow == "row wrap"

    # Test horizontal and vertical bar
    output = tqdm_notebook.status_printer(None, 9, '', ncols=500)
    display(output)
    assert output.layout.height == "30px"
    assert output.layout.width == "500px"

# Generated at 2022-06-24 10:20:07.386158
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    t = tqdm_notebook()
    for i in range(10):
        time.sleep(0.1)
        t.update()
    time.sleep(0.1)
    t.close()


# Generated at 2022-06-24 10:20:16.429454
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.std import __version__ as tqdm_version
    container = TqdmHBox()
    container.pbar = tqdm_notebook(total=100, desc='progress', leave=True,
                                   ncols='100%', initial=0, mininterval=0,
                                   display_format='{bar} {percentage:3.0f}%')
    # Test pretty display if possible

# Generated at 2022-06-24 10:20:25.793496
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # disable tests if no IPython/Jupyter
    if IProgress is None:
        return
    pbar = IProgress(min=0, max=1000)
    pbar.value = 500
    pbar.bar_style = 'success'
    pbar.layout.width = "800px"
    ltext = HTML()
    rtext = HTML()
    ltext.value = "desc"
    ltext.layout.width = "100px"
    rtext.layout.width = "100px"
    container = TqdmHBox(children=[ltext, pbar, rtext])
    container.pbar = proxy(pbar)
    container.layout.width = "800px"
    container.layout.display = 'inline-flex'
    container.layout.flex_flow = 'row wrap'
    assert container

# Generated at 2022-06-24 10:20:33.948311
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    from threading import Thread
    from time import sleep
    # test if bar closes when reaching total in manual mode
    for t in [None, 2, 0]:
        for l in [True, False]:
            with tqdm_notebook(total=t, leave=l, gui=True) as pbar:
                assert pbar.container.parent is None, "already displayed"
                assert not pbar.container.visible, "visible"
                assert not pbar.container.closed, "closed"
                display(pbar.container)
                assert pbar.container.parent is not None, "not displayed"
                assert pbar.container.visible, "not visible"
                assert not pbar.container.closed, "closed"
                pbar.update(1)
                pbar.update()

# Generated at 2022-06-24 10:20:42.873789
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import io
    import os
    import tempfile
    import shutil
    from IPython.utils import io

    class MyBar(tqdm_notebook):

        @property
        def bar_format(self):
            return '{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]{postfix}'

        def __init__(self, *args, **kwargs):
            kwargs['gui'] = True
            super(MyBar, self).__init__(*args, **kwargs)

    # Create temporary directory for images
    temp_dir = tempfile.mkdtemp()

    # Capture output
    with io.capture_output() as captured:
        bar = MyBar()
        bar.refresh()
        bar.container._repr

# Generated at 2022-06-24 10:20:52.836379
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit tests for method tqdm_notebook.update().
    """
    # Start with an empty bar
    with tqdm_notebook(total=0) as bar:
        # Init state:
        init_n = 0
        init_total = 0
        init_bar = "\n".join([
            "{desc}:   0%|                                                 | 0/0 [00:00<?, ?it/s]",
            "0it [00:00, ?it/s]"
        ])
        assert not bar.displayed
        assert bar.n == init_n
        assert bar.total == init_total
        assert bar.__repr__(True) == init_bar

        # Check update(n=0)
        bar.update(n=0)
        assert bar.n == init_n

# Generated at 2022-06-24 10:20:58.087301
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # python 2 range to check that 1st argument is treated as total
    for i in tnrange(10, 0, desc='1st loop', leave=True, disable=False):
        for j in tnrange(5, desc='2nd loop'):
            for k in tnrange(100, desc='3nd loop'):
                pass
            break
        break

if __name__ == '__main__':
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-24 10:21:02.529781
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit tests for `tqdm.notebook.tqdm.clear`.
    """
    with tqdm(total=3) as t:
        for i in t:
            t.clear()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-24 10:21:13.247606
# Unit test for constructor of class TqdmHBox
def test_TqdmHBox():
    import platform
    if platform.python_implementation() == 'PyPy':
        return
    class DummyTqdm(tqdm):
        @property
        def format_dict(self):
            return {'bar_format': '{bar}',
                    'l_bar': '[',
                    'r_bar': ']',
                    'bar': '0',
                    'n': 0,
                    'total': None,
                    'elapsed': '0:00:00',
                    'ascii': True,
                    'desc': 'test'}
    hb = TqdmHBox(children=[tqdm.HTML(), tqdm.FloatProgress(), tqdm.HTML()])
    hb.pbar = DummyTqdm()

# Generated at 2022-06-24 10:21:24.015870
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Test to avoid regression on `tqdm_notebook` constructor.
    """
    with tqdm_notebook(total=2) as pbar:
        for _ in range(3):
            pbar.update()
            assert not pbar.displayed
            if pbar.n == 1:
                assert pbar.container.children[1].bar_style == 'info'
                pbar.container.children[1].bar_style = ''
            else:
                assert pbar.container.children[1].bar_style == ''
            if pbar.n == 2:
                assert pbar.container.children[1].bar_style == 'success'
            pbar.container.children[0].value = 'foo'
            pbar.container.children[2].value = 'bar'

# Generated at 2022-06-24 10:21:25.316431
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    return tqdm_notebook(total=10)

# Generated at 2022-06-24 10:21:35.515492
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import HTML, display_html
    from time import sleep
    from IPython import get_ipython
    ipython = get_ipython()
    if ipython is not None:
        ipython.magic('matplotlib inline')
    if IPY == 32:  # IPython 3.x
        display_html(HTML("""<b><font color=#1E90FF>Only working in IPython
                             Notebook 4.x/5.x</font></b>"""))
        return
    if IPY == 4:  # IPython 4.x
        display_html(HTML("""<b><font color=#1E90FF>Only working in IPython
                             Notebook 5.x</font></b>"""))
        return

# Generated at 2022-06-24 10:21:41.754530
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.auto import tqdm as tqdm_auto  # NOQA: N802

# Generated at 2022-06-24 10:21:48.901089
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for __ in range(5):
        with tqdm_notebook(total=1, unit='B', unit_scale=True, miniters=1,
                           desc='test_notebook_clear') as t:
            assert t.n < t.total  # sanity check
            time.sleep(0.01)
            t.clear()
            # t.update(1)  # XXX: not possible
            t.close()
            assert t.n == t.total  # sanity check



# Generated at 2022-06-24 10:21:58.812488
# Unit test for function tnrange
def test_tnrange():
    """
    Unit test for tqdm_notebook.tnrange
    """
    tqdm_notebook.clear()
    t = tnrange(2)
    next(t)
    next(t)
    t.close()
    t.clear()
    t.close()
    t = tnrange(1)
    next(t)
    t.close()
    t = tnrange(1, 2)
    try:
        next(t)
        next(t)
        t.close()
        t.close()
    except:
        raise
    t = tnrange(1, 2)
    try:
        next(t)
        t.close()
        raise
    except StopIteration:
        pass
    t.close()



# Generated at 2022-06-24 10:22:09.026189
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.core.display import clear_output
    try:  # python 2
        from StringIO import StringIO as StreamIO
    except ImportError:  # python 3
        from io import StringIO as StreamIO
    # Define a function to catch the output
    with StreamIO() as our_file:
        # Call methods
        with tqdm(total=10, file=our_file) as t:
            clear_output()

            class T:
                value = ''

            # Check that `clear_output` was called.
            # As it is called in a different thread,
            # there is a race condition, so we check that it was called at least once
            t.container.children[0].values = [T()]
            t.update()
            assert T.value == '\n'
            t.update()
           

# Generated at 2022-06-24 10:22:17.268812
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tnrange, trange  # from tqdm.notebook import tnrange, trange
    from IPython.display import display, HTML

    # From issue #335:
    def style_check():
        assert HTML("<style>progress {width: 10%;}</style>").data == "<style>progress {width: 10%;}</style>"
        assert HTML("<style>progress {width: 10%;}</style>")._repr_html_() == "<style>progress {width: 10%;}</style>"
    style_check()

    # First test: rare case of zero iterations
    for n in trange(0, 0):
        assert n == 0

    # Second test: basic bar/counter display
    for i in trange(2):
        _ = i

    # Third test: with status text


# Generated at 2022-06-24 10:22:19.017580
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm(total=100) as t:
        for i in range(10):
            sleep(.1)
            t.update(10)


# Generated at 2022-06-24 10:22:23.316997
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=1, desc="test")
    t.display(close=True, check_delay=False)
    t.close()
    t = tqdm_notebook(total=1, desc="test")
    t.display(bar_style='success', check_delay=False)
    t.close()
    t = tqdm_notebook(total=1, desc="test")
    t.display(bar_style='danger', check_delay=False)
    t.close()
    print("Test passed")

# Generated at 2022-06-24 10:22:28.903797
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    from time import sleep
    l = list(range(10))
    t = tqdm_notebook(l)
    for i in l:
        t.update()
        sleep(0.01)
        if i == 4:
            clear_output(wait=True)
    t.close()