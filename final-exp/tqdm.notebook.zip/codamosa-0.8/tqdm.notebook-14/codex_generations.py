

# Generated at 2022-06-12 15:13:20.907897
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test that no error is raised.
    """
    for leave in (True, False):
        t = tqdm_notebook(total=1, leave=leave)
        try:
            t.close()  # this should not raise
        except Exception:
            raise AssertionError("error raised when leaving was " + str(leave))

# Generated at 2022-06-12 15:13:28.449989
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm import notebook
    from ipywidgets import FloatProgress
    try:
        from IPython.display import clear_output
    except ImportError:
        return
    for leave in [True, False]:
        for total in [3, None]:
            for n in [2, 3, None]:
                progress = notebook.tqdm_notebook(
                    total=total, leave=leave, unit_scale=False)
                progress.close()
                assert not progress.container.visible
                progress.reset()
                progress.close()  # should not crash
                assert not progress.container.visible



# Generated at 2022-06-12 15:13:36.408161
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=1) as pbar:
        pbar.reset()
        assert pbar.dynamic_ncols
        assert pbar.total is None
        assert pbar.n == 0
        assert pbar.container.children[-2].layout.width is None

    with tqdm_notebook(total=1, ncols='100%') as pbar:
        pbar.reset()
        assert not pbar.dynamic_ncols
        assert pbar.total is None
        assert pbar.n == 0
        assert pbar.container.children[-2].layout.width is None

    with tqdm_notebook(total=1, ncols=100) as pbar:
        pbar.reset()
        assert not pbar.dynamic_ncols
       

# Generated at 2022-06-12 15:13:47.349287
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from collections import defaultdict
    from tqdm._tqdm import _range
    from tqdm.std import tqdm as std_tqdm
    with tqdm_notebook(total=10) as t:
        for i in _range(5):
            t.update()
        for i in t:
            t.set_description("testing tqdm")
            t.set_postfix(default=1, testing=i)

    try:
        from IPython.display import clear_output
        with tqdm_notebook(total=10) as t:
            for i in _range(5):
                t.update()
                clear_output(wait=True)
            for i in _range(5):
                t.update()
    except ImportError:
        pass


# Generated at 2022-06-12 15:13:53.941400
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Regression test for tqdm_notebook.close() method.
    """
    import os
    # Case 1: no error
    with tqdm_notebook(total=10) as t:
        for i in t:
            t.update(1)
    # Case 2: error
    try:
        with tqdm_notebook(total=10) as t:
            for i in t:
                t.update(1)
                raise RuntimeError()
    except RuntimeError:
        pass
    # Case 3: KeyboardInterrupt
    with tqdm_notebook(total=10) as t:
        for i in t:
            t.update(1)
            os.kill(os.getpid(), 2)

# Generated at 2022-06-12 15:14:02.833600
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .utils import _range
    from .std import tqdm as std_tqdm

    for leave in (False, True):
        with tqdm(_range(3), leave=leave) as pbar:
            for i in pbar:
                assert(i == pbar.n)
                if i == 1:
                    pbar.reset(3)
        assert(pbar.n == 3)

    pbar = std_tqdm(_range(3), leave=False)
    for i in pbar:
        assert(i == pbar.n)
        if i == 1:
            pbar.reset(3)
    assert(pbar.n == 3)

    pbar = std_tqdm(_range(3), leave=True)

# Generated at 2022-06-12 15:14:07.260895
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    from IPython.display import clear_output
    with tqdm_notebook(total=9, leave=False) as pbar:
        for i in range(10):
            time.sleep(0.2)
            pbar.update(1)
            clear_output(wait=True)
    with tqdm_notebook(total=9, leave=True) as pbar:
        for i in range(10):
            time.sleep(0.2)
            pbar.update(1)
            clear_output(wait=True)

# Generated at 2022-06-12 15:14:10.964717
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=2) as pbar:
        try:
            for i in _range(2):
                pbar.update()
        except:
            pbar.disp(bar_style='danger', close=True)
            raise


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-12 15:14:21.962450
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm_gui  # NOQA

    for cls in (tqdm_notebook, tqdm_gui):
        t = cls(total=100, desc='testing')
        for i in t:
            if t.n < 20:
                t.display()
            elif t.n < 40:
                t.display(bar_style='success')
            elif t.n < 60:
                t.display(bar_style='warning')
            elif t.n < 80:
                t.display(bar_style='danger')
            elif t.n < 100:
                t.display(bar_style='info')
            if i == 5:
                t.display(desc='hello')
            if i == 15:
                t.display(desc='world')

# Generated at 2022-06-12 15:14:24.521507
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .tests import _test_update
    t = tqdm_notebook(total=100)
    for i in _test_update(t):
        pass


# Generated at 2022-06-12 15:14:46.677967
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    def test(n):
        for i in tqdm(range(n), desc="test", leave=True):
            pass

    test(5)
    test(5)


if __name__ == '__main__':
    # Unit tests
    test_tqdm_notebook_update()
    # Using tqdm
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()

# Generated at 2022-06-12 15:14:51.286909
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Simply run the tqdm_notebook() constructor
    to validate it. Avoids testing the integration
    with widgets.
    """
    # Test basic
    with tqdm_notebook(total=10) as t:
        assert t._inst_force_gui

    # Test leave
    with tqdm_notebook(total=10, leave=True) as t:
        assert t._inst_leave
        assert not t.container.visible


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-12 15:14:58.711285
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase

    class Test(TestCase):
        def test_display(self):
            """Run tqdm_notebook display method with some typical parameters."""

            pbar = tqdm_notebook(total=100)
            for _ in range(10):
                pbar.display(msg='', ncols=pbar.ncols,
                             close=True, bar_style='danger')
            # cannot .close() directly because of the IPython container
            pbar.container.close()

    return Test('test_display').test_display()

# Run test when file is not imported (e.g. when run from command-line)
if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:15:06.560575
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test with leave=False
    with tqdm(total=10, leave=False) as pbar:
        assert pbar.desc == ''
        pbar.set_description('foo')
        assert pbar.desc == 'foo'
        pbar.reset()
        assert pbar.desc == ''
        assert pbar.n == 0

    # Test with leave=True
    with tqdm(total=10, leave=True) as pbar:
        assert pbar.desc == ''
        pbar.set_description('foo')
        assert pbar.desc == 'foo'
        pbar.reset()
        assert pbar.desc == 'foo'
        assert pbar.n == 0

# Generated at 2022-06-12 15:15:13.491356
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    # tqdm.notebook.tqdm can be reset to 0 and is reusable
    g = tqdm_notebook(total=100)
    for _ in range(50):
        g.update()
        time.sleep(0.1)
    g.reset(10)
    for _ in range(10):
        g.update()
        time.sleep(0.1)
    g.reset(20)
    for _ in range(20):
        g.update()
        time.sleep(0.1)


# Generated at 2022-06-12 15:15:24.021382
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from tqdm import tqdm_notebook, tnrange
    from tqdm._utils import _term_move_up

    # Show bar and move cursor to next line
    t = tqdm_notebook(total=2)
    t.display()
    print()
    sleep(0.5)
    # t.close()  # Uncomment this to check correct behaviour

    # Show bar and move cursor to previous line
    t = tqdm_notebook(total=2)
    t.display(pos=None)
    print()
    sleep(0.5)
    t.close()

    # Show bar without moving cursor
    t = tqdm_notebook(total=2)
    t.display(pos=_term_move_up())
    sleep

# Generated at 2022-06-12 15:15:30.645216
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Initialized object.
    pbar1 = tqdm_notebook(total=10)
    pbar1.update(5)
    msg_clear1 = "Test closed"
    # Clear should do nothing when it is not in position to be closed.
    pbar1.clear(msg=msg_clear1)
    msg_clear2 = "Test not closed"
    # Clear should close pbar when it is in position to be closed.
    pbar2 = tqdm_notebook(total=10)
    pbar2.update(10)
    pbar2.clear(msg=msg_clear2)
    # Check if nothing has changed.
    assert pbar1._repr_json_().get('desc', None) is None
    assert pbar2._repr_json_().get('desc', None) is None

# Generated at 2022-06-12 15:15:39.443875
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar1 = tqdm_notebook(leave=True, disable=False, ncols=80)
    for _ in pbar1:
        continue
    assert pbar1.__repr__()
    assert pbar1.__repr__(pretty=True)

    pbar2 = tqdm_notebook(leave=True, disable=False, ncols=80)
    for _ in pbar2:
        continue
    assert 'p0123456789' in pbar2.__repr__()
    assert 'p0123456789' in pbar2.__repr__(pretty=True)


if __name__ == '__main__':
    test_TqdmHBox___repr__()

# Generated at 2022-06-12 15:15:44.075611
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.
    Test the drawing of the progress bar.
    """
    ipython_version = IPY
    if ipython_version == 2:
        raise unittest.SkipTest("Skipping test_tqdm_notebook_status_printer: "
                                "IPython 2.x has a different API")

    # test if the widget exists (see issue #872)
    if IProgress is None:  # pragma: no cover
        return

    # create some tqdm_notebook objects
    tqdm_notebook_obj_without_total = tqdm_notebook(gui=True)
    tqdm_notebook_obj_without_total.n = 10

# Generated at 2022-06-12 15:15:53.457559
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.core.display import clear_output
    from IPython.core.display import HTML
    from IPython.core.display import display

    ipy = 0
    try:
        import ipywidgets
        ipy = 4
    except ImportError:
        ipy = 32
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings(
                'ignore', message=".*The `IPython.html` package has been deprecated.*")
            try:
                import IPython.html.widgets as ipywidgets
            except ImportError:
                pass


# Generated at 2022-06-12 15:16:07.145987
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from tqdm import tqdm
    progress_bar = tqdm(total=100)
    for x in progress_bar:
        progress_bar.set_description("Processing %s" % x)
        sleep(0.01)
        

# Generated at 2022-06-12 15:16:12.517097
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from io import StringIO
    from sys import version_info
    from unittest import TestCase, main
    from .utils import FormatCustomString, _version2
    from .std import isPyPy, encoding
    from contextlib import contextmanager


# Generated at 2022-06-12 15:16:18.134746
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    try:
        from ipykernel import iostream
    except ImportError:
        from ipykernel.iostream import OutStream
    try:
        from ipywidgets import FloatSlider as IProgress
    except ImportError:
        from IPython.html.widgets import FloatProgressWidget as IProgress
    import pandas as pd
    error_raised = False
    output = None
    with iostream.OutStream():
        progress = tqdm_notebook(total=9, file=sys.stdout)
        for x in progress:
            sleep(0.1)
            if x % 3 == 0:
                output = progress.container
                raise Exception("error")
            progress.update()
    if not type(output) == IProgress:
        raise Exception("error")
    output = []

# Generated at 2022-06-12 15:16:24.394764
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    """
    Unit tests for tqdm_notebook's status_printer
    """
    # Initialize progress bar display
    total = 128
    desc = "Generating..."
    ncols = 200
    container = tqdm_notebook.status_printer(sys.stderr, total=total,
                                             desc=desc, ncols=ncols)

    # Initial display
    ltext, pbar, rtext = container.children
    # ltext: description left text
    assert ltext.value == desc
    # pbar: progress bar
    assert pbar.min == 0
    assert pbar.max == total
    assert pbar.step == 1
    assert pbar.value == 0
    # rtext: description right text
    assert rtext.value == ""

   

# Generated at 2022-06-12 15:16:34.106050
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test '\r' behaviour
    with tqdm_notebook(total=10, unit='B', unit_scale=True) as t:
        for i in range(5):
            t.update()
        # Test disable=True (i.e. in a context manager)
        with tqdm(total=5, unit='B', unit_scale=True, disable=True) as t:
            for i in range(5):
                t.update()

    # Test with `file` (deprecated)
    with tqdm_notebook(total=10, unit='B', unit_scale=True,
                       file=sys.stdout) as t:
        for i in range(5):
            t.update()
        # Test disable=True (i.e. in a context manager)

# Generated at 2022-06-12 15:16:38.895158
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    pbar = IProgress(min=0, max=100)
    container = TqdmHBox(children=[HTML(), pbar, HTML()])
    # cannot use self-testing assert in this function
    assert(container.__repr__() == '[100%|##########|]')
    assert(container.__repr__(pretty=True) == '[100%|##########|]')


# Generated at 2022-06-12 15:16:45.625817
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from nose.tools import assert_equal
    from tempfile import mkstemp
    import os

    # Test total = 0 (info style)
    fd, fname = mkstemp(text=True)
    with os.fdopen(fd, 'w') as fobj:
        fobj.write(repr(tqdm_notebook.status_printer(fp=fname, total=0)))
    l = len(repr(tqdm_notebook.status_printer(fp=fname, total=0)))
    assert_equal(l, 162, '{}: {}'.format(l, repr(tqdm_notebook.status_printer(
        fp=fname, total=0))))
    os.remove(fname)

    # Test total = 1 (info style)
    fd, fname

# Generated at 2022-06-12 15:16:50.437702
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from time import sleep
    from IPython.display import clear_output

    for i in tqdm_notebook(range(3)):
        for j in tqdm_notebook(range(4)):
            sleep(0.1)
            clear_output(wait=True) # simulates a clear cell
    clear_output(wait=True)

# Generated at 2022-06-12 15:17:00.886659
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tqdm as tqdm_gui

    for i in tqdm_notebook(xrange(3)):
        assert i == 0 or i == 1 or i == 2, 'failed 1'
        if i == 1:
            raise Exception('error at iteration 1')
    assert i == 2, 'failed 2'

    # unit test for issue #1049
    with tqdm_gui(_range(10), leave=True) as t:
        for i in tqdm_notebook(xrange(3), t) | tqdm_notebook(xrange(3)):
            if i == 0:
                t.close()
                break

    # unit test for issue #811
    # try:
    #     _ = list(tqdm_notebook(xrange(100), total=100))
   

# Generated at 2022-06-12 15:17:03.696304
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep

    for i in tqdm_notebook(range(4)):
        for j in tqdm_notebook(range(3)):
            for k in tqdm_notebook(range(2)):
                sleep(0.01)

# Generated at 2022-06-12 15:17:22.920730
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """ Unit test for method update of class tqdm_notebook """
    total = 10
    from time import sleep
    with tqdm_notebook(total=total) as pbar:
        for i in range(total):
            sleep(0.001)  # avoid tqdm progress rate overflow
            pbar.update(1)

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:17:29.967787
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test for the `tqdm_notebook.display()` method."""
    t = tqdm_notebook(total=None, leave=False)  # leave bar on exit
    t.reset(total=None)
    t.display()
    assert t.displayed
    t.clear()
    t.display(bar_style='info')
    t.display(bar_style='danger')
    t.display(msg='infos')
    t.display(msg='infos', bar_style='info')
    t.close()


if __name__ == '__main__':
    from .tests import main
    main()

# Generated at 2022-06-12 15:17:38.277160
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    class FakeTqdm:
        def __init__(self):
            self.n = 0
            self.total = 2
            self.container = None

    f = FakeTqdm()

    # No display
    tqdm_notebook.display(f)
    assert f.container is None

    # With display
    # NOTE: `display` is protected by `if not self.disable`
    # so we have to override self.disable temporarily
    old_disable = f.disable
    f.disable = False
    tqdm_notebook.display(f, display=True)
    assert f.container is not None
    assert f.container.pbar is f
    f.disable = old_disable

# Generated at 2022-06-12 15:17:43.425529
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep

    # Initialize tqdm
    t = tqdm_notebook(total=10)
    for i in t:
        sleep(.1)
        if i == 3:
            raise Exception('testing')  # need to unpack exception in the loop
    # Check that the bar is red
    # This check is not necessary, but helps to make sure that
    # the tqdm display function is called before the exception is raised.
    # (in the tqdm source, display() is called right after update() or close())
    assert t.colour == 'red', "Progress bar is not red"



# Generated at 2022-06-12 15:17:54.266450
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        import unittest2 as unittest
    except ImportError:
        import unittest
    import random
    import sys
    from .utils import format_sizeof

    random.seed(0)
    suite = unittest.TestSuite()

    # ---

    class Test_tqdm_notebook___iter__(unittest.TestCase):
        def test_smoke(self):
            if IProgress is None:  # #187
                return

            for n in (1, 5, 10):
                for total in (None, 10):
                    it = tqdm_notebook(xrange(n), total=total)
                    for _ in it:
                        pass
                    it.close()


# Generated at 2022-06-12 15:17:57.966693
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        return tqdm_notebook(total=10, ncols=72).total == 10
    except ImportError:
        return True


# Do not use "from tqdm import *", it will import all std_tqdm functions...
__all__ += std_tqdm.__all__

# Generated at 2022-06-12 15:18:00.612803
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    for i in tqdm(range(2), desc='test_tqdm_notebook_reset'):
        sleep(.5)
        if i == 0:
            tqdm.reset()  # Expect reset to 0



# Generated at 2022-06-12 15:18:06.370113
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from os import getcwd
    from os.path import join as pjoin
    from shutil import rmtree
    from tempfile import mkdtemp
    from time import sleep

    from tqdm.std import tqdm

    # Create test directory
    TEMP_DIR = pjoin(mkdtemp(), 'tqdm_tests')

    # Test how tqdm_notebook handles non-ASCII chars
    print('Testing `tqdm_notebook` with non-ASCII chars')
    t = tqdm_notebook("Проверка")
    for i in t:
        t.set_description("Проверка: {0}".format(i))
        sleep(.01)
    print('OK!')

    # Test how tqdm handles redirecting the output

# Generated at 2022-06-12 15:18:16.481030
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    miniters = 12
    mininterval = 0
    delta = 0.05
    maxinterval = 1
    left = '0.0/10.0'
    right = '0.00s'
    bar = ' 0%|                                                                |'
    total = 10
    try:
        from IPython import get_ipython
    except ImportError:
        return
    ip = get_ipython()
    t = tqdm_notebook(total=total, miniters=miniters,
                      mininterval=mininterval,
                      maxinterval=maxinterval,
                      leave=False, unit='', unit_scale=True)
    for _ in range(total):
        t.update()
        ip.kernel.do_one_iteration()

# Generated at 2022-06-12 15:18:25.023039
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    tqdm is not monkey patched
    """
    from unittest.mock import patch

    def capture_stdout(fn):
        def wrapped_fn(*args, **kwargs):
            with patch('sys.stdout', new=StringIO()) as mock_stdout:
                fn(*args, **kwargs)
            return mock_stdout.getvalue()

        return wrapped_fn

    import io
    from io import StringIO
    from sys import version_info

    # Range test
    for total in (100, 0, None):
        hbox = tqdm_notebook.status_printer(
            sys.stdout, total=total, ncols=80)
        assert isinstance(hbox, HBox)
        assert len(hbox.children) == 3

# Generated at 2022-06-12 15:18:56.471485
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from sys import version_info
    from numpy import random
    from tqdm import tqdm as std_tqdm

    t = list(tqdm_notebook(["", "", ""]))
    assert t[0].displayed
    t[0].display()  # test multiple calls to display
    assert not t[1].displayed
    assert not t[2].displayed
    t[2].display()
    assert t[2].displayed
    assert not t[1].displayed

    t[1].update()  # test update() before first call to display()
    assert t[1].displayed
    # test close() with no display
    t.append(tqdm_notebook([""]))
    assert not t[3].displayed
   

# Generated at 2022-06-12 15:19:05.143438
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        IPython
    except NameError:
        return
    try:
        IPython.get_ipython
        has_ipython = True
    except AttributeError:
        has_ipython = False
    if has_ipython:
        ip = IPython.get_ipython()
        if ip is None:
            has_ipython = False
    if not (has_ipython and IPY):
        return

    from IPython.display import clear_output

    t = tqdm_notebook()
    # Test initial output
    assert '\r' not in t.__repr__()
    # Test printing
    t.display(True)
    clear_output(wait=True)
    t.display()
    clear_output(wait=True)
    # Test bar style

# Generated at 2022-06-12 15:19:12.641500
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import io
    import sys
    str_io = io.StringIO()
    old = sys.stdout
    sys.stdout = str_io
    try:
        tqdm.tqdm_notebook.status_printer(fp=None, total=None)
        res = str_io.getvalue()
    finally:
        sys.stdout = old

    assert res == '<progress>\n    <bar value="0"/>\n    <info style="width: 0%"></info>\n</progress>\n'

# Generated at 2022-06-12 15:19:15.878981
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # prepare test
    iterable = iter(range(10))
    t = tqdm(iterable)
    # check that everything works
    for i in t:
        assert i == next(iterable)
        if i < 3:
            t.update()


# Generated at 2022-06-12 15:19:23.132051
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import io
    from .utils import _supports_unicode
    f = io.StringIO() if _supports_unicode else io.BytesIO()
    total = 5000
    pbar = tqdm_notebook.status_printer(f, total, "test", 100)
    assert isinstance(pbar, TqdmHBox), "TqdmHBox not found"
    assert pbar.pbar.max == total, "Total not set"
    assert pbar.pbar.description == "test", "Description not set"
    assert pbar.pbar.layout.width == "100px", "Width not set"
    # Test if the widget displays correctly (by setting it to a specific value)
    pbar.pbar.value = total // 2
    assert pbar.pbar.value == total // 2

# Generated at 2022-06-12 15:19:24.013226
# Unit test for method status_printer of class tqdm_notebook

# Generated at 2022-06-12 15:19:31.285878
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import clear_output
    from time import sleep
    try:
        from nose.tools import nottest
    except ImportError:
        def nottest(f): return f
    @nottest
    def test():

        # Check default arguments
        t = tqdm_notebook()
        assert len(t.container.children) == 3
        assert t.ncols == 88
        assert not t.reset_ncols
        assert t.leave
        assert t.desc == ''

        # Check arguments
        t = tqdm_notebook(desc='testing', ncols=100, reset_ncols=True, leave=False)
        assert len(t.container.children) == 3
        assert t.ncols == 100
        assert t.reset_ncols
        assert not t.leave


# Generated at 2022-06-12 15:19:39.778736
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Prepare dummy IPython progress bar
    class IProgress:
        def __init__(self, min, max):
            self.min = min
            self.max = max

        @property
        def value(self):
            return getattr(self, '_value', 0)

        @value.setter
        def value(self, value):
            self._value = value

        @property
        def bar_style(self):
            return getattr(self, '_bar_style', 0)

        @bar_style.setter
        def bar_style(self, bar_style):
            self._bar_style = bar_style

        class layout:
            @classmethod
            def display(cls, display):
                pass

            @classmethod
            def width(cls, width):
                pass


# Generated at 2022-06-12 15:19:42.541185
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    t = tqdm_notebook(total=12)
    try:
        for i in range(12):
            t.update(i)
    except:
        pass
    finally:
        t.close()



# Generated at 2022-06-12 15:19:50.705485
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import os
    try:  # For Python 3
        from io import StringIO
    except ImportError:  # For Python 2
        from io import BytesIO as StringIO
    from contextlib import closing
    from .utils import _supports_unicode
    file_kwarg = StringIO() if _supports_unicode else StringIO()
    with closing(tqdm_notebook(total=None, file=file_kwarg)) as pbar:
        assert pbar.ncols is None
        # display first bar
        pbar.display(check_delay=False)
        assert pbar.container.children[-2].bar_style == 'info'

        try:
            ncols = os.get_terminal_size().columns
        except (AttributeError, OSError):
            ncols = 100
