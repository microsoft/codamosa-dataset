

# Generated at 2022-06-12 15:13:53.280332
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = tqdm_notebook.status_printer(None)
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == '0'
    assert pbar.children[2].value == ''
    pbar.value = 1
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == '1'
    assert pbar.children[2].value == ''
    pbar.max = 1
    pbar.value = 1
    assert pbar.children[0].value == ''
    assert pbar.children[1].value == '1'
    assert pbar.children[2].value == ''
    pbar.bar_style = 'info'
    assert pbar.children[0].value == ''

# Generated at 2022-06-12 15:14:02.092783
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests the IPython/Jupyter progress bar widget output.
    """
    from .utils import _term_move_up
    objects = [{'name': 'foo', 'desc': ''},
               {'name': 'bar', 'desc': '0123456789'},
               {'name': 'baz', 'desc': None}]
    for o in objects:
        o['desc'] = o['desc'].ljust(10)
    for obj in objects:
        for key in 'name', 'desc', 'ncols':
            for total in (None, 0, 100, 1000):
                for ncols in (None, 0, 20, 100):
                    value = getattr(obj, key)

# Generated at 2022-06-12 15:14:05.361326
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t = tqdm_notebook(iterable=["a", "b", "c"])
    for i, item in enumerate(t):
        assert t.n == i + 1
        assert t.n == t.last_print_n + 1
        assert item == t.last_print_n


# Generated at 2022-06-12 15:14:11.502980
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import trange

    # See: https://github.com/tqdm/tqdm/issues/470
    # 1 iteration over range(3):
    t = trange(3, desc="1", ascii=True, file=sys.stdout)
    for i in t:
        sleep(1)
    assert t.n == 1

    # 2 iterations over range(3):
    t = trange(3, desc="2", ascii=True, file=sys.stdout)
    for i in t:
        t.update(2)
        sleep(1)
    assert t.n == 2

    # 3 iterations over range(3):
    t = trange(3, desc="3", ascii=True, file=sys.stdout)

# Generated at 2022-06-12 15:14:22.043900
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    t = tqdm_notebook(total=10, desc='ttt', leave=True)
    t.close()
    with pytest.raises(AttributeError):
        t.clear()
    t.reset(total=10)
    with pytest.raises(AttributeError):
        t.clear()
    t.close()
    with pytest.raises(AttributeError):
        t.clear()
    t.reset(total=10)
    t.update(5)
    with pytest.raises(AttributeError):
        t.clear()
    t.close()
    with pytest.raises(AttributeError):
        t.clear()
    t.reset(total=10)
    t.update(10)
    with pytest.raises(AttributeError):
        t.clear

# Generated at 2022-06-12 15:14:30.523933
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Tests the method display of the class tqdm_notebook.
    """
    from jupyter_client.manager import start_new_kernel
    from jupyter_client.blocking.client import BlockingKernelClient
    from .gui import tqdm_notebook
    from .utils import _term_move_up
    import IPython
    from IPython.display import clear_output

    _ = IPython.get_ipython()
    # Skip test if already in IPython
    if _ is not None:
        return
    # Skip test if no display
    try:
        display(_)
    except NameError:
        return
    # Skip test if IProgress not found
    if IProgress is None:
        return

    km, kc = start_new_kernel()


# Generated at 2022-06-12 15:14:38.742639
# Unit test for method update of class tqdm_notebook

# Generated at 2022-06-12 15:14:47.768494
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """
    # Clearing the bar works (this should be first to test)
    with tqdm_notebook(total=1) as bar:
        bar.update()
        bar.update(0)
        bar.update(1)

    # Check if setting the total after the widget has been created works
    with tqdm_notebook(total=1) as bar:
        bar.update()
        bar.update(0)
        bar.update(1)
    with tqdm_notebook(total=10) as bar:
        bar.update()
        bar.update(0)
        bar.update(1)

    # Check if setting the total after the widget has been created works

# Generated at 2022-06-12 15:14:50.326964
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    x = tqdm_notebook(["a", "b", "c", "d"])
    assert x.reset()._repr_pretty_() == '  0%|          | 0/4 [00:00<?, ?it/s]\n\n'



# Generated at 2022-06-12 15:14:55.698995
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(4)):
        sleep(.1)  # use an actual loop in order to be more precise
        pass
    sleep(10)  # enough time for the progress bar to automatically close
    for i in tqdm_notebook(range(4), leave=True):
        sleep(.1)  # use an actual loop in order to be more precise
        pass


# Generated at 2022-06-12 15:15:13.544309
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.utils import _term_move_up
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(10), desc="foo", file=sys.stdout):
        sleep(0.1)
    # Clear is no longer applicable as the bar is closed.
    # left in place to check that it doesn't crash.
    tqdm.clear()

# Generated at 2022-06-12 15:15:20.817955
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test standard display
    pbar = tqdm_notebook(total=100)
    pbar.display()

    # Test with info display
    pbar.reset(total=None)
    pbar.display()

    # Test error style display
    pbar.reset()
    pbar.display('', close=False, bar_style='danger')

    # Test success style display
    pbar.reset()
    pbar.display('', close=False, bar_style='success')

    # Test close()
    pbar.close()



# Generated at 2022-06-12 15:15:29.149889
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import gauss

    try:
        from ipywidgets.widgets import Layout
    except ImportError:
        Layout = object

    class _Test_IterNoTotal(object):
        __slots__ = ['pbar']

        def __init__(self, *_, **__):
            self.pbar = tqdm_notebook(**__)

        def __iter__(self):
            return self

        def __next__(self):
            x = gauss(mu=0, sigma=1)
            self.pbar.update()
            if abs(x) <= 1:
                raise StopIteration
            return x

        next = __next__


# Generated at 2022-06-12 15:15:39.263322
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Unit test for method close of class tqdm_notebook
    # Set delay of tqdm to 0
    original_tqdm_delay = tqdm_notebook.delay


# Generated at 2022-06-12 15:15:40.761749
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    _, pbar, _ = tqdm_notebook.status_printer(None, 10)
    assert pbar.min == 0
    assert pbar.max == 10



# Generated at 2022-06-12 15:15:49.718310
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    import unittest
    from .utils import FormatCustom

    class TestNotebookReset(unittest.TestCase):

        def test_reset(self):
            pbar = tqdm_notebook(total=100, leave=False)
            pbar.reset(total=50)
            # compare ncols and bar_size with a FormatCustom
            # so that colours and progress.<unit> are ignored
            string2 = str(FormatCustom(
                '{l_bar}<bar/>{r_bar}', pbar.ncols, pbar.bar_len))
            pbar.n = 0
            pbar.refresh()
            string1 = str(FormatCustom(
                '{l_bar}<bar/>{r_bar}', pbar.ncols, pbar.bar_len))

# Generated at 2022-06-12 15:15:58.276509
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    with patch('IPython.display.display') as ip:
        with tqdm_notebook(total=None, leave=True) as t:
            for i in range(5):
                t.update(1)
            assert ip.call_count == 1, IPY
        assert ip.call_count == 1, IPY
    with patch('IPython.display.display') as ip:
        with tqdm_notebook(total=None, leave=True) as t:
            for i in range(5):
                t.update()
            assert ip.call_count == 5, IPY
        assert ip.call_count == 5, IPY

# Generated at 2022-06-12 15:15:59.680208
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    return tqdm_notebook(total=40000, leave=False).update(40000)

# Generated at 2022-06-12 15:16:04.340324
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Initialize
    total = 100
    desc = "Test Progress Bar"
    ncols = "80%"
    pbar = tqdm_notebook.status_printer(
        None, total, desc, ncols=ncols)

    # Tests
    if IPY == 4:
        left_class_name = "progress-bar-description"
        middle_class_name = "progress-bar"
        right_class_name = "progress-bar-message"
    elif IPY == 3:
        left_class_name = "FLOATPROGRESS_DESCRIPTION"
        middle_class_name = "FLOATPROGRESS"
        right_class_name = "FLOATPROGRESS_MESSAGE"

# Generated at 2022-06-12 15:16:07.997111
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    for msg in (None, '', 'Hello world!'):
        for close in (True, False):
            pbar = tqdm_notebook(total=100)
            pbar.display(msg, close=close)
            pbar.close()
            if msg is None and not close:
                assert pbar.container.children[1].bar_style == 'info'
            else:
                assert pbar.container.children[1].bar_style == ''
            if close:
                assert pbar.container.children[1].value == 1

# Generated at 2022-06-12 15:16:24.454327
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Testing tqdm_notebook constructor and display() method"""
    # Method display() is called on each iteration, so we can test it
    # using the iterator.
    import time
    if IPY == 0:
        try:
            import tkinter
            tkinter.Tk().destroy()
        except ImportError:
            sys.exit(1)

    return_value = 10
    with tqdm_notebook(total=return_value, leave=False) as t:
        for i in t:
            time.sleep(0.01)
    assert i == return_value

# Generated at 2022-06-12 15:16:34.191318
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .gui import tnrange
    from .std import trange
    a = tnrange(2)
    b = trange(2)
    assert next(a) == next(b)
    assert next(a) == next(b)
    try:
        next(a)
    except StopIteration:
        try:
            next(b)
        except StopIteration:
            pass
        else:
            raise
    else:
        raise
    try:
        a.update(5)
    except ValueError:
        b.update(5)
    else:
        raise
    a.reset()
    b.reset()
    assert next(a) == next(b)
    assert next(a) == next(b)

# Generated at 2022-06-12 15:16:42.635747
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test function for `tqdm.notebook.tqdm_notebook.status_printer`
    """
    from .utils import _decompose
    from .std import tqdm

    def tqdm_instance(total, desc=None, ncols=None, bar_format=None):
        kwargs = dict(total=total, desc=desc)
        if ncols:
            kwargs['ncols'] = ncols
        if bar_format:
            kwargs['bar_format'] = bar_format
        return tqdm(**kwargs)

    # Here, use the status_printer function to generate a description
    # to ensure that all the outputs are exactly the same
    # as what `tqdm.format_meter` prints.

# Generated at 2022-06-12 15:16:52.323001
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test `tqdm_notebook.display`.

    (!) This test is run by the `tqdm.tests` package.

    :return: ``None``
    """
    from .gui import tqdm as gtqdm
    # Initialise a tqdm
    with gtqdm(total=100, leave=False) as pbar:
        # Test without bar style
        for i in range(100):
            # Test without msg
            pbar.display(i, check_delay=False)
            # Test with msg
            pbar.display(i, msg='test_msg', check_delay=False)
        # Test with bar style
        pbar.display(bar_style='success')
        pbar.display(bar_style='danger')

# Generated at 2022-06-12 15:17:01.202616
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # simple update
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update(1)
    assert t.n == t.total
    # instant finish
    with tqdm_notebook(total=10) as t:
        t.update(10)
    assert t.n == t.total
    # instant finish of readonly bar
    with tqdm_notebook(total=None) as t:
        t.update(10)
    assert t.n == 1
    # negative update
    with pytest.raises(ValueError):
        with tqdm_notebook(total=10) as t:
            t.update(-1)

# Generated at 2022-06-12 15:17:07.726296
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    bar = tqdm_notebook([1, 2, 3])
    bar.container.pbar = bar
    assert str(bar.container) == (
        "|██████▏                         | 3/4 [00:00<?, ?it/s]")
    assert type(bar.container._repr_pretty_(None)) is None

# Generated at 2022-06-12 15:17:16.086313
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Tests that tqdm_notebook.__iter__()
    - correctly displays the widget
    - cannot be closed outside of the loop
    - can be closed inside of the loop
    - calls widget.close()
    - calls widget.display(bar_style='danger') if excepted inside the loop
    """
    from IPython import get_ipython
    from IPython.core.display import clear_output
    from contextlib import contextmanager

    # mock the Notebook to raise an exception on output
    # open but empty mock ipython
    @contextmanager
    def mock_ipy_fail_output(self):
        try:
            # mock write
            yield
        finally:
            # restore write
            pass

    raise_on_output = False

# Generated at 2022-06-12 15:17:20.273229
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tnrange
    from tqdm import tqdm as tn
    # custom sleep function for testing purposes
    def _sleep(t):
        from time import sleep
        sleep(t / 10**6)
    for _ in tnrange(1, 10, unit_scale=True):
        with tn(total=10) as t:
            for i in t:
                _sleep(10000)
                t.set_description("{0:d}".format(i))
                t.update()



# Generated at 2022-06-12 15:17:29.829551
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from ._tqdm_test_examples import _range_of_floats, _range_of_strings, _range_of_iterables
    from .std import TqdmTypeError, TqdmKeyError

    # Callback for main test
    def check_err_msg(bar, msg):
        try:
            bar.display(msg)
            assert False
        except (TqdmTypeError, TypeError):
            pass
        except (TqdmKeyError, KeyError):
            pass

    # Test init (no args)
    bar = tqdm_notebook()
    bar.display()

    # Test the decorator creation, init and display
    bar = tqdm_notebook(_range(5))
    bar.display()

    # Test display, pos, total

# Generated at 2022-06-12 15:17:38.983157
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from time import sleep
    t = tqdm_notebook(total=100, file=sys.stdout)
    for i in range(100):
        t.display(i + 1)
        sleep(0.01)
    t.display(100, close=True)
    print()


# For debugging
if __name__ == '__main__':  # pragma: no cover
    from time import sleep
    test_tqdm_notebook_update()

    with tqdm(total=100, file=sys.stdout) as t:
        for i in range(100):
            t.display(i + 1)
            sleep(0.01)
    print()
    t.clear()


# Generated at 2022-06-12 15:17:56.738471
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=1, leave=False) as t:
        t.display("hello world")


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:18:03.616047
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    import warnings
    import ipywidgets
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', message='.*IPython.kernel.*')
        from IPython.kernel import InProcessKernelManager
    from io import StringIO

    # Test against a non-notebook environment
    sys.modules['ipykernel'] = None
    try:
        tqdm.tqdm_notebook(range(1))
    except ImportError:
        pass
    else:
        raise Exception('ImportError not raised')
    sys.modules['ipykernel'] = None  # reinit

    # test default color
    pbar = tqdm.tqdm_notebook(range(1))
    assert pbar.colour is None

    # test colour change
    pbar = tqdm.tq

# Generated at 2022-06-12 15:18:06.352677
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for i in tqdm_notebook([1, 2, 3], bar_format='{desc}: {n_fmt}', desc='foo'):
        assert str(tqdm_notebook.clear(i)) == ""

# Generated at 2022-06-12 15:18:16.445485
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test basic functionnality
    hb = TqdmHBox()
    hb.pbar = TqdmHBox()
    hb.display()
    assert hb.children == [HTML(), IProgress(), HTML()]

    # Test display text in bar
    tb = tqdm_notebook(desc="foo", file=sys.stderr)
    tb.display(msg="bar")
    assert hb.children[0].value == "foo"
    assert hb.children[2].value == "bar"

    # Test changing style & progress
    tb.display(msg="baz", bar_style="danger", pos=2)
    assert hb.children[0].value == "foo"
    assert hb.children[2].value == "baz"

# Generated at 2022-06-12 15:18:19.882771
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        for i in tqdm_notebook([1, 2, 3, 4]):
            pass
    except RuntimeError:
        pass  # update raises an error when closed
    else:
        raise RuntimeError("'update' method of class tqdm_notebook did not raise exception for closed bar")

# Generated at 2022-06-12 15:18:27.793312
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.core.display import HTML as _HTML
    from IPython.display import clear_output as _clear_output

    class DisplayTester(object):
        def __init__(self):
            self._value = None

        def __call__(self, value, pos=None):
            self._value = value

        @property
        def value(self):
            return self._value

    with_html = DisplayTester()
    with_clear_output = DisplayTester()
    with_bar_style = DisplayTester()
    with_check_delay = DisplayTester()

    def fake_display(arg):
        with_html(arg)

    def fake_clear_output(arg):
        with_clear_output(arg)


# Generated at 2022-06-12 15:18:31.501018
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(4), desc='Testing that the widget is not double printed'):  # noqa
        assert i == i


# Generated at 2022-06-12 15:18:33.960558
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook([1, 2, 3]):
        assert i == 1
        break
    assert i == 1


# Generated at 2022-06-12 15:18:42.197835
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from contextlib import closing
    from tqdm import tnrange, TqdmTypeError
    with closing(tnrange(10)) as t:
        assert not t.disable
        for i in t:
            sleep(0.1)
        assert t.n == 10
        assert t.dynamic_ncols  # use default style of ipywidgets

    # test + test __contains__
    for _ in tnrange(10):
        assert 'total' in t
        assert not 'nonexistent' in t

    # test __getitem__
    assert t['total'] == 10

    # test __setitem__
    t['total'] = 20
    assert t['total'] == 20

    # test __delitem__
    del t['total']
    assert t['total'] is None



# Generated at 2022-06-12 15:18:46.915144
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test cases
    inputs = [
        (None, None, None, None),
        (None, None, 'Desc', None),
        (10, None, None, None),
        (10, '1.2', None, None),
        (10, '1.2', 'Desc', None),
        (10, '1.2', 'Desc', 100),
        (10, '1.2', 'Desc', 100.5)]
    for total, n, desc, ncols in inputs:
        tqdm_notebook.status_printer(None, total, desc, ncols)



# Generated at 2022-06-12 15:19:09.521185
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from pytest import raises
    with tqdm_notebook(total=5) as t:
        assert t.desc == ''
        assert t.n == 0
        assert t.total == 5
        assert t.container.children[1].max == 5
        # This will raise if reset is not called correctly
        if t.n < t.total:
            t.reset(total=10)
        t.reset(total=10)
        # Check that the width of the progress bar is reset if unknown total
        assert t.ncols is None
        assert t.container.children[1].layout.width is None
        t.update(2)
        assert t.n == 2
        assert t.total == 10
        assert t.container.children[1].max == 10
        # Check that the width of the progress bar is reset if known

# Generated at 2022-06-12 15:19:13.649534
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    import time
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()
            time.sleep(0.01)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-12 15:19:20.372878
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import sys
    import tempfile
    from io import StringIO
    with tempfile.TemporaryFile('w+') as f:
        old_stdout = sys.stdout
        try:
            sys.stdout = f
            for _ in tqdm_notebook(range(3)):
                pass
            f.seek(0)
            s = f.read()
        finally:
            sys.stdout = old_stdout
    assert '\r' not in s  # no repeated line
    assert '\n' not in s  # no newline


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:19:26.387580
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for leave in [True, False]:
        for total in [2, 10]:
            for ncols in ['100%', None]:
                t = tqdm_notebook(range(total), leave=leave, ncols=ncols)
                t.update(1)
                t.reset()
                t.update(1)
                t.close()

                # Test reset without total
                t = tqdm_notebook(range(total), leave=leave, ncols=ncols)
                t.update(1)
                t.reset()
                t.update(1)
                t.close()
                t.reset()

                # Test reset with total
                t = tqdm_notebook(range(total), leave=leave, ncols=ncols)
                t.update(1)
               

# Generated at 2022-06-12 15:19:28.669118
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests the clear() method of the tqdm_notebook class. To be run in notebooks.
    """
    bar = tqdm_notebook(total=100, leave=True)
    bar.clear()  # should not raise an error

# Generated at 2022-06-12 15:19:33.914897
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import sys
    try:  # pragma: no cover
        if sys.stderr.isatty():
            sys.stderr.close()
        sys.stderr = open(sys.stderr.fileno(), 'w', encoding='utf-8', closefd=False)
    except (AttributeError, OSError):  # pragma: no cover
        pass
    # Test reset
    pbar = tqdm_notebook(total=10)
    for _ in pbar:
        pass
    assert pbar.n == 10
    pbar.reset(total=20)
    assert pbar.total == 20 and pbar.n == 0



# Generated at 2022-06-12 15:19:37.924211
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    x = tqdm_notebook(total=10)
    x.update(1)
    x.update(1)
    x.close()
    # check that it can be used in a loop (see #457)
    for i in tqdm_notebook(range(3)):
        x.update()
    x.close()


# Generated at 2022-06-12 15:19:46.609793
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    file = sys.stdout

    # Case 1: no total, info style text only
    expected_res1 = (
        'Total size: [                               ] 0/?'
        ' - Rate: N/A - ETA: ??:??:??\r')
    res1 = tqdm_notebook.status_printer(file).value
    assert res1 == expected_res1

    # Case 2: total but unknown total, info style text only
    N = None
    expected_res2 = (
        'Total size: [                               ] 0/?'
        ' - Rate: N/A - ETA: ??:??:??\r')
    res2 = tqdm_notebook.status_printer(file, total=N, desc='Total size:').value
    assert res2 == expected_res2

    # Case 3

# Generated at 2022-06-12 15:19:53.894834
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset() of class tqdm_notebook.
    Verifies that reset can happen before, at and after the first
    iterable element and that the progressbar max value is updated
    accordingly.
    """
    import time
    from contextlib import contextmanager
    from unittest import TestCase

    class tqdm_test(tqdm_notebook):
        def __init__(self, *a, **k):
            k.setdefault('leave', True)
            super(tqdm_test, self).__init__(*a, **k)

        @contextmanager
        def _joblib_wrapper(self, *args, **kwargs):
            yield

    # Test preconditions
    time_sleep_real = time.sleep
    tqdm_notebook.time_sleep = time_sleep

# Generated at 2022-06-12 15:19:59.719387
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.utils import _term_move_up
    with tqdm_notebook(total=2) as pbar:
        pbar.display()
        pbar.update(1)
        pbar.display()
        pbar.display()
        pbar.display()
        pbar.update(1)
        pbar.display()

    with tqdm_notebook(total=3) as pbar:
        pbar.display()
        pbar.update(1)
        pbar.display(close=True)

    if IPY > 0:  # pragma: no cover
        with tqdm_notebook(total=3) as pbar:
            pbar.display()
            pbar.update(1)
            pbar.display(bar_style='success')

# Generated at 2022-06-12 15:20:31.056937
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    from .std import tnrange, trange, tqdm_gui
    if not IProgress:
        return
    # no total
    with tnrange(10) as tr:
        for _ in tr:
            pass
        tr.reset()
        for _ in tr:
            pass
    with tqdm_gui(10) as tr:
        for _ in tr:
            pass
        tr.reset()
        for _ in tr:
            pass
    # with total
    with tnrange(5, 10) as tr:
        for _ in tr:
            pass
        tr.reset(total=10)
        for _ in tr:
            pass
    # no total, with leave

# Generated at 2022-06-12 15:20:36.788534
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook.
    """
    try:
        from IPython.display import clear_output
    except ImportError:
        from IPython.html.widgets import ContainerWidget as HBox
    else:
        from ipywidgets import HBox
    with tqdm_notebook() as t:
        assert isinstance(t.container, HBox)
        assert t.total is None
        assert t.n == 0
        t.total = 100
        t.update(1)
        assert t.n == 1
        assert t.container.children[-2].style.bar_color is None
        t.reset()
        assert t.n == 0
        assert t.container.children[-2].style.bar_color is None

# Generated at 2022-06-12 15:20:41.968719
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    assert hasattr(tqdm_notebook, 'clear')
    # clear() raises NotImplementedError
    tn = tqdm_notebook(total=1)
    assert repr(tn) != ''
    tn.clear()
    assert repr(tn) != ''
    # clear() of standard tqdm can be used
    tn = tqdm_notebook(total=1)
    std_tqdm.clear(tn)
    assert repr(tn) == ''


# Class-based unit test

# Generated at 2022-06-12 15:20:51.363294
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = tqdm_notebook.status_printer(file=None, total=100)
    assert pbar.children[0].value == ""
    assert pbar.children[2].value == ""
    assert pbar.children[1].value == 0
    assert pbar.children[1].min == 0
    assert pbar.children[1].max == 100
    assert pbar.children[1].bar_style == ""

    pbar = tqdm_notebook.status_printer(file=None, total=None)
    assert pbar.children[0].value == ""
    assert pbar.children[2].value == ""
    assert pbar.children[1].value == 1
    assert pbar.children[1].min == 0
    assert pbar.children[1].max == 1
    assert pbar

# Generated at 2022-06-12 15:20:54.475060
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test tqdm_notebook.update"""
    from tqdm.autonotebook import tqdm
    with tqdm(total=3) as t:
        t.update()
        t.update()
        t.update()
    assert t.n == 3



# Generated at 2022-06-12 15:21:03.787694
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal
    for t in [None, 17, 43]:
        h = tqdm_notebook(total=t, leave=True)
        assert_equal(h.container.layout.width, "20px")
        assert_equal(h.container.layout.display, "")
        h.close()
    for t, v, width in [[None, None, "20px"],
                        [None, 10, "20px"],
                        [10, None, "20px"],
                        [10, 5, "100%"]]:
        h = tqdm_notebook(total=t, leave=True, ncols="100%")
        assert_equal(h.container.layout.width, width)
        assert_equal(h.container.layout.display, "inline-flex")

# Generated at 2022-06-12 15:21:11.124201
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from unittest import mock
    except ImportError:
        from mock import mock

    with mock.patch('IPython.display.clear_output') as mock_method:
        tqdm_notebook(['aa', 'bb']).display(close=True)
        mock_method.assert_called_once_with(wait=1)

    with mock.patch('IPython.display.display') as mock_method:
        tqdm_notebook(['aa', 'bb'], display=False)
        mock_method.assert_not_called()
        tqdm_notebook(['aa', 'bb']).update()
        mock_method.assert_called_once()
        tqdm_notebook(['aa'], leave=True).update()
        mock_method.assert_called_once()
        t

# Generated at 2022-06-12 15:21:17.970025
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython.display import clear_output
    except ImportError:
        return
    with tqdm(total=None, leave=True) as pbar:
        for i in _range(20):
            pbar.update()
            pbar.set_description("test")
            assert pbar.n == (pbar.n + 1) - 1
            assert pbar.n == i + 1
            clear_output(wait=True)
    assert pbar.n == 20



# Generated at 2022-06-12 15:21:20.452840
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    class SubTqdmNotebook(tqdm_notebook):
        def clear(self):
            pass
    SubTqdmNotebook().update(1)

# Generated at 2022-06-12 15:21:29.915452
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .std import tqdm
    from tqdm._instances import _instances
    from tqdm._tqdm import format_dict
    from tqdm.utils import sizeof_fmt

    # Test format_meter
    tqdm.format_meter(format_dict(dict(desc='Foo'), 'desc', 'Foo'))
    tqdm.format_meter(format_dict(dict(bar_format='{desc}'), 'bar_format', '{desc}'))
    tqdm.format_meter(format_dict(dict(bar_format='{desc} {bar} {n_fmt}/s'), 'bar_format', '{desc} {bar} {n_fmt}/s'))

# Generated at 2022-06-12 15:22:26.442718
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    if IPY == 0:
        raise RuntimeError("No ipywidgets found in test")
    # prepare env
    t = tnrange(10)
    # simulate init values
    t.total = 10
    t.ncols = 100
    assert(t.total == 10)
    # fake iteration
    for i in _range(10):
        assert(t.n == i)
        assert(t.total == 10)
        assert(t.ncols == 100)
        sleep(0.01)
        t.update(1)
    # end fake iteration
    assert(t.n == 10)
    assert(t.total == 10)
    assert(t.ncols == 100)
    t.total = None
    assert(t.total == None)
    t.ncol

# Generated at 2022-06-12 15:22:28.555475
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(range(10), display=False)
    assert (len(t.container.children) == 3)
    assert (t.displayed is False)
    t.display()
    assert (t.displayed is True)

# Generated at 2022-06-12 15:22:33.814975
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    b = tqdm_notebook(total=1)
    b.reset()
    b.reset(total=2)
    b.reset(total=0)
    b.reset(total=1)
    b.reset(total=None)
    b.reset(total=1)
    assert b.total == 1
    # In manual mode, n reset is useless
    b.n = 10
    b.reset()
    assert b.n == 10
    # In auto mode, it is useful
    b.n = 10
    b.total = None
    b.reset()
    assert b.n == 0



# Generated at 2022-06-12 15:22:35.657882
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .tests import test_tqdm_notebook
    test_tqdm_notebook()

if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:22:40.172627
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(None, total=None, desc=None, ncols=None)
    tqdm_notebook.status_printer(None, total=1, desc='hello', ncols=None)
    tqdm_notebook.status_printer(None, total=1, desc='hello', ncols='105px')
    tqdm_notebook.status_printer(None, total=1, desc='hello', ncols=105)
    tqdm_notebook.status_printer(None, total=1, desc='hello', ncols='100%')

# Generated at 2022-06-12 15:22:48.715601
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from ast import literal_eval
    hbox = tqdm_notebook.status_printer(fp=None, total=120, desc='Downloading',
                                        ncols='100%')
    assert (str(hbox.children[0]) == "<class 'IPython.html.widgets.widget_string.HTML'>"
            and str(hbox.children[1]) == "<class 'IPython.html.widgets.widget_float.FloatProgress'>"
            and str(hbox.children[2]) == "<class 'IPython.html.widgets.widget_string.HTML'>")
    hbox_style = literal_eval(str(hbox.style))
    assert hbox_style['width'] == '100%'


# Generated at 2022-06-12 15:22:55.048356
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialise the class tqdm_notebook
    tqdm_actual = tqdm_notebook(ncols=100)
    # initialise the class tqdm
    tqdm_expected = std_tqdm(ncols=100)
    # Check if the two methods are equal using the update method to decrease
    # the number of trials
    for i in range(0,10):
        tqdm_notebook.update(tqdm_actual, 1)
        std_tqdm.update(tqdm_expected, 1)
        assert tqdm_expected.n==tqdm_actual.n
        assert tqdm_expected.last_print_n==tqdm_actual.last_print_n

# Generated at 2022-06-12 15:23:02.850838
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=0) as t:
        pass
    t.reset()
    with tqdm_notebook(total=0) as t:
        pass
    t.reset(total=42)
    with tqdm_notebook(total=0) as t:
        pass
    t.reset(leave=False)
    with tqdm_notebook(total=0, leave=False) as t:
        pass
    t.reset()


if __name__ == '__main__':
    try:
        test_tqdm_notebook_reset()
    except:
        pass

# Generated at 2022-06-12 15:23:12.212585
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    result = tqdm_notebook.status_printer(None, total=10, desc="desc",
                                          ncols=100)
    assert isinstance(result, TqdmHBox)
    assert isinstance(result.children[0], HTML)
    assert isinstance(result.children[1], IProgress)
    assert isinstance(result.children[2], HTML)
    assert str(result.children[0].value) == "desc"
    assert str(result.children[1].layout.max) == "10"
    assert str(result.children[1].layout.value) == "0"
    assert str(result.layout.width) == "100%"
    assert result.children[1].layout.flex == "2"
    assert str(result.children[1].layout.width) == "100%"
   

# Generated at 2022-06-12 15:23:17.130536
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests tqdm_notebook.reset() method.
    """
    cnt = 0
    for i in tqdm_notebook(range(12345), total=1000, dynamic_ncols=True, leave=False):
        cnt += 1
        if not cnt % 47:
            tqdm_notebook.reset(total=12345)
            continue
        if not cnt % 23:
            tqdm_notebook.reset(total=None)
            continue