

# Generated at 2022-06-12 15:13:38.460322
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Unit test for method __repr__ of class TqdmHBox"""
    from pytest import raises
    from .utils import StringIO

    # tqdm_notebook.__version__ is not available in setup.py
    from .tqdm import __version__
    from .std import tqdm

    # standard test for trange
    with tqdm.temporary_file() as f:
        with raises(Exception):
            with tqdm.tqdm(file=f, bar_format='{l_bar}{bar}{r_bar}') as t:
                l = [float('nan')] * 3
                assert t.miniters == 1
                assert repr(t) == t.format_meter(**t.format_dict)
                t.display(False)
                assert t.miniters == 1


# Generated at 2022-06-12 15:13:42.875831
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .gui import tqdm_notebook
    from .gui import _tqdm_notebook_status_printer as status_printer

    # Check no crash
    x = status_printer(None, 100)


# Hide the test from the docstring
del test_tqdm_notebook_status_printer

# Generated at 2022-06-12 15:13:52.056646
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .utils import _suppress_stdout

    # Tested with no total (info style bar)

# Generated at 2022-06-12 15:13:58.769070
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import pytest
    from time import sleep
    from .std import tqdm

    with pytest.raises(ImportError):
        tqdm_notebook(range(5))

    with tqdm(range(5), leave=True) as t:
        for _ in t:
            sleep(0.1)
        assert t.container.__repr__()
        assert t.container.__repr__(pretty=True)
        t.container.visible = False
        assert t.container.__repr__() == {}
        assert t.container.__repr__(pretty=True) == '{}'

# Generated at 2022-06-12 15:14:03.395816
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook.
    """
    iterable = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j']
    for obj in tqdm(iterable):
        assert obj in iterable
        iterable.remove(obj)
        if not iterable:
            break


# Generated at 2022-06-12 15:14:11.062617
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    total = 100
    transient_tqdm = tqdm_notebook(range(total))
    for i in transient_tqdm:
        transient_tqdm.set_description("Transient tqdm [%d/%d]" % (i + 1, total))
        time.sleep(0.1)
        if i % 10 == 0:
            transient_tqdm
    transient_tqdm.clear()
    transient_tqdm.close()

    new_ncols = 100
    parent = tqdm_notebook(range(total), total=total, desc='Parent')
    for i in parent:
        parent.set_description("Parent [%d/%d]" % (i + 1, total))

# Generated at 2022-06-12 15:14:19.813426
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time

    class DumbTqdmNotebook:
        def __init__(self):
            class Output:
                def close(self):
                    pass

            self.clear = self.display = lambda *_, **__: None
            self.disable = False
            self.container = Output()
            self.container.pbar = proxy(self)
        def __iter__(self):
            yield 1
            raise KeyboardInterrupt

    try:
        tq = DumbTqdmNotebook()
        for _ in tq:
            time.sleep(0.1)
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-12 15:14:28.215492
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import _tqdm_notebook
    from tqdm._tqdm import TMonitor, set_lock
    set_lock(True)
    # tqdm._instances.clear()
    # tqdm._instances.append(tqdm_notebook(total=100,
    #     leave=True, desc="", mininterval=0))
    # tqdm._instances[-1].update()
    # tqdm._instances.clear()

    # DEPRECATED: warn if total is None
    _tqdm_notebook(total=None, leave=True, desc="")

    # No total
    prev_mon = TMonitor().prev

# Generated at 2022-06-12 15:14:34.922027
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Tests for `tqdm.notebook.tqdm_notebook.__iter__`"""
    # NOTE: class TqdmHBox(HBox) {_.layout.width="50px"}
    # causes weird jupyter notebook tests failures
    # (see #1345: no error during runtime, but weird warning)
    # So we use the original HBox class instead.
    range_ = tqdm_notebook(range(10), leave=False)
    try:
        assert type(iter(range_)) == type(range_)
    finally:
        range_.close()



# Generated at 2022-06-12 15:14:37.851936
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook
    try:
        from IPython.display import clear_output, display  # NOQA
        tqdm_notebook().display()
        tqdm_notebook().display(close=True)
    except:
        pass

# Generated at 2022-06-12 15:15:09.360363
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """ Test the method reset() of class tqdm_notebook """
    from random import randint
    test_bar = tqdm_notebook(total=randint(10, 20))

    # Change the total of test_bar
    test_bar.reset(total=randint(10, 20))
    assert test_bar.total == test_bar.n

    # Change to unknown time
    test_bar.reset(total=None)
    assert test_bar.total is None
    assert test_bar.n == 0

# Generated at 2022-06-12 15:15:13.406172
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tnrange
    from time import sleep
    from IPython import get_ipython

    ip = get_ipython()
    ip.magic("time")

    for i in tnrange(10, desc="looping"):
        sleep(0.2)

# Generated at 2022-06-12 15:15:16.628326
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert all(x == y for (x, y) in zip(
        tqdm_notebook(iterable=range(10), display=False),
        range(10)))



# Generated at 2022-06-12 15:15:26.175811
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase, main
    from io import StringIO
    from inspect import DontReadFromInput, isclass

    class TqdmHBox(HBox):
        def _repr_json_(self):
            pbar = getattr(self, 'pbar', None)
            if pbar is None:
                return {}
            return pbar.format_dict

    class T(TestCase):
        def test(self):
            if IPY < 2:
                self.fail("Test skipped: IPython v2+ is required")
        if IPY < 2:
            test = T.fail

        def setUp(self):
            self.stdout = sys.stdout
            sys.stdout = StringIO()
            self.stderr = sys.stderr
            sys.stderr = StringIO()



# Generated at 2022-06-12 15:15:37.168127
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import unittest
    from tqdm._utils import _term_move_up
    from tqdm import _tqdm_notebook

    class Test(unittest.TestCase):
        def test(self):
            self.bar = _tqdm_notebook.tqdm_notebook(ncols=200)
            self.bar.update(10)
            self.bar.clear()
            self.assertEqual(_term_move_up(), "")
    test = unittest.main(module=__name__, exit=False)
    if test.result.wasSuccessful():
        # Cleanup
        tqdm_notebook.clear()


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:15:40.103571
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=10) as pbar:
        for i in pbar:
            if i == 5:
                raise Exception('Test raise')
            elif i > 5:
                break
            else:
                assert i < 5



# Generated at 2022-06-12 15:15:45.049957
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from traitlets import link as link_trait
    from time import sleep as time_sleep
    from tqdm.auto import tqdm as tqdm_auto
    from .std import tqdm as tqdm_std

    for tqdm_cls in (tqdm_auto, tqdm_notebook, tqdm_std):
        t = tqdm_cls(total=100, desc='TQDM DISPLAY')
        pbar = t.container.children[1]

        def update_pbar_value(change):
            t.update()

        link_trait(pbar, 'value', update_pbar_value)
        pbar.max = 100

        for i in t:
            time_sleep(0.01)  # Simulate work



# Generated at 2022-06-12 15:15:53.664573
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from .std import tqdm as std_tqdm

    def test_bar_style(bar_style, desc=None):
        with tqdm_notebook(total=1, desc=desc) as pbar:
            sleep(2)
            pbar.disp(bar_style=bar_style)
            sleep(1)
            pbar.disp(close=True)
    test_bar_style('success')
    test_bar_style('info')
    test_bar_style('warning')
    test_bar_style('danger')
    test_bar_style('danger', desc='fatal error')
    try:
        with std_tqdm(total=1, desc='failing desc') as pbar:
            sleep(5)
            raise Exception
    except:
        pass

# Generated at 2022-06-12 15:15:55.788785
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tnrange(0, 10)
    for i in t:
        t.desc = str(i)
        t.display()


# Generated at 2022-06-12 15:15:58.993718
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import nose.tools as nt
    for t in [tqdm_notebook, tnrange, tqdm, trange]:
        with nt.assert_raises(NotImplementedError):
            t(total=10, file=sys.stderr).clear()

# Generated at 2022-06-12 15:16:32.968254
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.auto import tqdm

    class TqdmHandler(object):
        n = 0

        def update(self, n):
            self.n = n
            return n

        def close(self):
            pass

    for total in [None, 0, 4]:
        for n in [4, 4.5, 6]:
            for leave in [True, False]:
                th = TqdmHandler()
                t = tqdm_notebook(th, total=total, leave=leave)
                # check that total is modified
                assert t.cont

# Generated at 2022-06-12 15:16:36.685946
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    "Test that `class tqdm_notebook` produces a widget"
    with tqdm_notebook(total=3, leave=True) as t:
        t.update()
        t.update()
        t.update()
    from IPython.display import clear_output
    clear_output()



# Generated at 2022-06-12 15:16:43.764631
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    html = HTML
    try:  # just in case
        import IPython.display as IPy_display
    except ImportError:
        return None
    box = TqdmHBox()
    box.add_class("test")
    box.add_traits(trait_name_list=["pbar"])
    IPy_display.display(box)
    box.pbar = getattr(html, "pbar")
    assert box.__repr__() == html.pbar
    html.pbar = None
    assert box.__repr__() == {}
    html.pbar = "this is not a ProgressBar"
    assert box.__repr__() == {}



# Generated at 2022-06-12 15:16:54.230831
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import tqdm
    from .utils import TqdmDeprecationWarning

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", TqdmDeprecationWarning)
        try:
            import ipywidgets
            ipywidgets.FloatProgress(min=0, max=1)
        except ImportError:
            import IPython.html.widgets as ipywidgets
        ipywidgets.HTML("")
    pbar = tqdm_notebook.status_printer(file=None, total=100,
                                        desc="tqdm_notebook unit test", ncols=100)
    assert isinstance(pbar, ipywidgets.HBox)
    assert len(pbar.children) == 3

# Generated at 2022-06-12 15:16:59.866526
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=1000, desc="Test Notebook") as t:
        assert t.n == 0
        t.update()
        assert t.n == 1
        t.update(10)
        assert t.n == 11
        for _ in t:
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:17:02.034676
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test update of tqdm_notebook.
    """
    import time
    for i in trange(10):
        time.sleep(.1)


# Generated at 2022-06-12 15:17:08.297564
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Simply test the constructor of the class `tqdm_notebook()`.
    """

    # Init
    if IProgress is None:  # #187 #451 #558 #872
        raise ImportError(
            "IProgress not found. Please update jupyter and ipywidgets."
            " See https://ipywidgets.readthedocs.io/en/stable/user_install.html")
    if IPY < 3:
        raise ImportError(
            "IPython 3+ required for Jupyter Notebook support. Please upgrade.")

    # Init progress bar
    bar1 = TqdmHBox(children=[HTML(), IProgress(), HTML()])
    display(bar1)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:17:09.803538
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=5) as bar:
        bar.update(1)
        bar.update(1)
        bar.reset()
        bar.update(2)

# Generated at 2022-06-12 15:17:16.939947
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from contextlib import contextmanager
    from inspect import getgeneratorstate
    from unittest import TestCase

    class TqdmNotebookUpdateTestCase(TestCase):
        # Test that tqdm_notebook method `update` raise on close
        def test_update(self):
            generator_state = ''
            with tqdm_notebook(iterable=[1, 2, 3]) as t:
                with self.assertRaises(RuntimeError):
                    for _ in t:
                        generator_state = getgeneratorstate(t)
                        if generator_state == 'SUSPENDED':
                            t.update()

    return TqdmNotebookUpdateTestCase

test_tqdm_notebook_update.__test__ = False  # to avoid nose to fail on this test

# Generated at 2022-06-12 15:17:23.589301
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    try:
        from IPython.display import clear_output
    except ImportError:
        return
    try:
        with tqdm_notebook(total=10, leave=False) as pbar:
            assert "10it [00:00, ?" in repr(pbar)
            for i in range(10):
                pbar.display()
                clear_output(wait=1)
                sleep(0.1)
            pbar.display(close=True)
    except Exception:
        pass  # #187
    finally:
        clear_output()

# Generated at 2022-06-12 15:18:48.168816
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():  # pragma: no cover
    from time import sleep

    progress_bar = tqdm_notebook(total=3)
    progress_bar.write('Hello World!')
    sleep(1)
    progress_bar.clear()
    sleep(1)
    progress_bar.n = 2
    progress_bar.refresh()
    sleep(1)

    with tqdm_notebook(total=3) as progress_bar:
        progress_bar.write('Hello World!')
        sleep(1)
        progress_bar.clear()
        sleep(1)
        progress_bar.n = 2
        progress_bar.refresh()
        sleep(1)


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-12 15:18:54.620612
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=3, disable=False) as pbar:
        for i in range(4):
            pbar.update()
    assert (str(pbar) ==
            '100%|█████████████████████████████████████████████████| 3/3 [00:00<?, ?it/s]')
    assert (pbar.container.children[-1].value ==
            '100%|█████████████████████████████████████████████████| 3/3 [00:00<?, ?it/s]')
    assert pbar.container.children[-2].bar_style == 'success'



# Generated at 2022-06-12 15:18:57.705897
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=4) as pbar:
        for i in range(4):
            sleep(0.5)
            pbar.update()
    assert pbar._repr_pretty_(None) == pbar.__repr__(True)


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-12 15:18:59.961755
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = trange(1, ascii=True, file=sys.stderr)
    assert isinstance(t, tqdm_notebook)
    t.clear()

# Generated at 2022-06-12 15:19:09.964941
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    ipy = 0
    try:  # IPython 4.x
        from ipywidgets import HBox, FloatProgress as IProgress
        ipy = 4
    except ImportError:  # IPython 3.x / 2.x
        try:
            from IPython.html.widgets import HTML, HBox, FloatProgressWidget as IProgress
            ipy = 3
        except ImportError:
            ipy = 0
            IProgress = None
            HBox = object

    if ipy == 0:
        # (test_)tqdm_notebook_reset can be detected by --doctest-modules
        # and will fail in "make test", but this is fine since it doesn't apply
        # without IPython anyway
        return

    old_stdout = sys.stdout

# Generated at 2022-06-12 15:19:13.059502
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    t = tqdm_notebook(total=1)
    t.clear()
    with pytest.raises(AttributeError):
        t.container.children[0].value = ''
    t.close()

# Generated at 2022-06-12 15:19:14.970540
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(range(10)) as t:
        for i in t:
            assert i == t.n - 1



# Generated at 2022-06-12 15:19:22.272333
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """ Unit test for method reset of class tqdm_notebook """
    from collections import namedtuple
    from random import randint
    from time import sleep
    iterable = [namedtuple('TqdmTestReset', ('a', 'b', 'c'))(randint(0, 100),
                                                             randint(0, 100),
                                                             randint(0, 100))
                for _ in trange(10)]
    for i in iterable:
        sleep(0.01)
    bar = trange(10)
    for i in iterable:
        sleep(0.01)
        # Workaround for issue #13 of the Notebook widget,
        # where the progressbar is stuck
        bar.reset(total=10)
    bar.close()

# Generated at 2022-06-12 15:19:25.222697
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests the method "clear" of the class "tqdm_notebook".
    """
    for _ in tqdm_notebook(range(3), ncols=100):
        pass
    tqdm_notebook.clear(wait=True)

# Generated at 2022-06-12 15:19:31.136318
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as t:
        # Check that the progress bar is dislayed
        assert t.container.children[1].bar_style == ''
        # Check that we can't access the progress bar in the old container
        assert (not hasattr(t.container, 'children')) or len(t.container.children[1]) == 3
        # Check that the progress bar is not displayed when nb of iterations not known
        t.reset(total=None)
        assert len(t.container.children[1]) == 3
        # Check that the progress bar is displayed when nb of iterations known
        t.reset(total=10)
        assert t.container.children[1].bar_style == ''


# Generated at 2022-06-12 15:22:02.996717
# Unit test for method status_printer of class tqdm_notebook

# Generated at 2022-06-12 15:22:11.184039
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test method __repr__ of class TqdmHBox."""
    from pytest import raises
    assert isinstance(TqdmHBox().__repr__(), str)
    assert isinstance(TqdmHBox().__repr__(True), str)
    assert isinstance(TqdmHBox().__str__(), str)
    assert isinstance(TqdmHBox()._repr_json_(), dict)
    assert isinstance(TqdmHBox()._repr_json_(pretty=True), dict)
    with raises(TypeError):
        isinstance(TqdmHBox()._repr_json_(pretty='a'), dict)
    with raises(TypeError):
        isinstance(TqdmHBox()._repr_json_(pretty=0), dict)

# Generated at 2022-06-12 15:22:16.976217
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from numpy.random import random
    from IPython.core.display import clear_output
    pbar = tqdm_notebook(total=10, desc='foo')
    for i in range(10):
        pbar.update(1)
        sleep(random() / 10)
    pbar.close()
    clear_output()
    pbar.reset()
    pbar.display(desc='bar')
    for i in range(10):
        pbar.update(1)
        sleep(random() / 10)

if __name__ == '__main__':
    # test_tqdm_notebook_reset()
    import doctest
    doctest.testmod()
    print("Doctests ok")

# Generated at 2022-06-12 15:22:26.443437
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tgrange
    from .std import trange as ttrange
    from .std import tqdm as ttqdm
    def test_tqdm_notebook_iter(tqdm_cls):
        for i in tqdm_cls(list(range(3))):
            for j in tqdm_cls(list(range(3))):
                for k in tqdm_cls(list(range(3))):
                    1 / 0
        with tqdm_cls(list(range(3))) as t:
            for i in t:
                for j in tqdm_cls(list(range(3))):
                    for k in tqdm_cls(list(range(3))):
                        1 / 0

# Generated at 2022-06-12 15:22:28.526872
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.notebook import trange
    for i in trange(3):
        sleep(.3)


# Generated at 2022-06-12 15:22:30.931898
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    for _ in tqdm_notebook(range(10)):
        time.sleep(0.01)

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:22:39.288695
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep

    # Without error
    with tqdm_notebook(total=10) as pbar:
        for _ in pbar:
            sleep(0.01)

    # With KeyboardInterrupt
    try:
        with tqdm_notebook(total=10) as pbar:
            for _ in pbar:
                sleep(0.01)
                raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass

    # With error
    try:
        with tqdm_notebook(total=10) as pbar:
            for _ in pbar:
                sleep(0.01)
                raise Exception
    except Exception:
        pass

    # With 'error' bar

# Generated at 2022-06-12 15:22:43.021396
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    total = 100
    with tqdm_notebook(total=total) as t:
        for i in range(total):
            t.display(i, "Go Steelers")
            time.sleep(0.02)

# Generated at 2022-06-12 15:22:46.702120
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stdout  # NOQA
    # Create a valid tqdm instance and display it
    tqdm_notebook(range(3), file=stdout).display()
    # assert False, "not working"


if __name__ == "__main__":
    import pytest
    pytest.main([__file__])

# Generated at 2022-06-12 15:22:50.938279
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    progress = tqdm_notebook(total=1)
    progress.display()
    progress.close()


try:
    get_ipython
    if 'In' in get_ipython().__class__.__name__:
        # In rep mode
        pass
    else:
        __doc__ += """
Example notebook:
    https://github.com/tqdm/tqdm/blob/master/examples/tqdm_notebook_example.ipynb
"""
except NameError:
    pass