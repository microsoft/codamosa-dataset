

# Generated at 2022-06-12 15:13:40.328979
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # test for function __repr__
    # note that this is called for display, so it should be very short!
    # note that __format__/__str__ is used to print the repr,
    # we can override __repr__ but not __format__/__str__
    # easy to test, just print!
    # this test is enough as the default repr is automatically
    # used in __format__/__str__

    # create progressbar with default arguments
    pbar = tqdm_notebook()

    # check that the repr does not exceed the limit
    # this test is not nice because it can break
    # for reasons that are not bugs
    assert (len(repr(pbar.container)) <= 80)

    # update progressbar
    for _ in pbar:
        pass

    # check that the repr is less than 80

# Generated at 2022-06-12 15:13:50.740561
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from random import randrange
    from IPython.display import clear_output
    from .gui import tqdm as std_tqdm_gui
    for i in tqdm_notebook(range(2)):
        for j in std_tqdm_gui(
                range(10), desc="update" if i == 0 else "update_leave",
                leave=(i == 1)):
            sleep(0.05)
            # Force IPython Notebook refresh
            clear_output()
        assert j == 9
    clear_output()
    with tqdm_notebook(range(10)) as t:
        for i in t:
            sleep(0.05)
        t.reset(total=20)
        assert t.total == 20
        for i in t:
            sleep(0.05)

# Generated at 2022-06-12 15:13:59.694380
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        global HTML, IProgress, HBox
        from IPython.display import clear_output  # NOQA
        from IPython.html.widgets import HTML
        from IPython.html.widgets import FloatProgressWidget as IProgress
        from IPython.html.widgets import ContainerWidget as HBox
    except ImportError:
        return
    from io import StringIO
    # Redirecting stdout for AssertionError
    saved_stdout = sys.stdout
    sys.stdout = buf = StringIO()

    # Create a progress bar
    with tqdm(total = 10) as pbar:
        # Clear the progress bar
        pbar.clear()
        # Passes the test
        assert(pbar.n == 0)
        # Return the saved stdout
    sys.stdout = saved_stdout

# Generated at 2022-06-12 15:14:02.298282
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    import time
    with tqdm_notebook(total=3) as pbar:
        for i in pbar:
            time.sleep(0.25)



# Generated at 2022-06-12 15:14:08.313205
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = None
    if clear_output is None:
        return  # test only in notebook

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update()

    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            pbar.update()
            sleep(0.1)
        pbar.display(close=True)

    clear_output()
    print('Test `_tqdm_notebook.update`: pass')

# Generated at 2022-06-12 15:14:11.849770
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import tqdm_notebook as tqn
    try:
        iterator = tqn(iterable=range(3), desc="Test case", leave=True)
        for _ in iterator:
            sleep(.8)
            iterator.update()
    except NotImplementedError:
        pass

# Generated at 2022-06-12 15:14:22.203110
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # only IPython/Jupyter >= 3.0
    if IPY == 0:
        return
    # get the test function
    func = tqdm_notebook.status_printer
    # prepare HBox and its children
    hbox = func('test')
    ltext, pbar, rtext = hbox.children
    # format_dict
    d = pbar.format_dict
    # test the bar style
    assert pbar.style.bar_color == d['bar_color']
    assert pbar.layout.width == d['width']
    assert pbar.layout.visibility == d['visibility']
    # test the alignement
    assert ltext.layout.align_self == 'flex-end'
    assert rtext.layout.align_self == 'flex-start'
    # test the bar format

# Generated at 2022-06-12 15:14:23.928640
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    tn = tqdm_notebook(desc="test", unit="B")
    for i in tn:
        sleep(0.01)
        tn.update()
    tn.close()

# Generated at 2022-06-12 15:14:32.006630
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for ncols in ['z', None, 100, '100px', '100%']:  # invalid, unchanged, valid
        t = tqdm_notebook(total=2, desc='init', ncols=ncols, leave=True)
        t.reset(total=3)
        assert t.total == 3, "t.total = %r" % t.total
        assert t.ncols == ncols, "t.ncols = %r" % t.ncols
        t.reset(total=4)
        assert t.total == 4, "t.total = %r" % t.total
        assert t.ncols == ncols, "t.ncols = %r" % t.ncols
        t.reset(total=None)

# Generated at 2022-06-12 15:14:35.745856
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from sys import stdout
    from time import sleep

    # Create a progress bar that will iterate through a range of values
    with tqdm_notebook(total=2, file=stdout) as pbar:
        for _ in range(2):
            pbar.update()
            sleep(0.5)



# Generated at 2022-06-12 15:15:10.701432
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .gui import tqdm_gui

    # Test with total 100
    total = 100
    pbar = tqdm_notebook.status_printer(
        total=total, desc="Testing the progress bar", ncols="100%")
    pbar.value = 0
    for i in tqdm_gui(range(total)):  # pragma: no cover
        pbar.value += 1

    # Test without total
    pbar = tqdm_notebook.status_printer(desc="Testing the progress bar")
    pbar.value = 1
    pbar.value += 1

    # Test with total 0
    total = 0
    pbar = tqdm_notebook.status_printer(
        total=total, desc="Testing the progress bar", ncols="100%")
    pbar.value

# Generated at 2022-06-12 15:15:19.097022
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython import get_ipython
    return get_ipython() and get_ipython().__class__.__name__ == 'ZMQInteractiveShell'


if __name__ == '__main__':
    from time import sleep
    for i in tqdm(range(10), desc='1st loop'):
        for j in tqdm(range(5), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop'):
                sleep(0.01)
    # This can be used to check the Jupyter notebook is running
    print("Done")

# Generated at 2022-06-12 15:15:24.702102
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Tests for `tqdm_notebook`"""
    try:
        import ipywidgets
    except ImportError:
        try:
            import IPython.html.widgets
        except ImportError:
            return  # NOQA
    l = range(1000)
    l = tqdm_notebook(l)
    for i in l:
        pass
    l.close()

# Generated at 2022-06-12 15:15:26.626678
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test of method __iter__ of class tqdm_notebook"""
    assert([i for i in tqdm_notebook([0])] == [0])


# Generated at 2022-06-12 15:15:32.471786
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Main test for tqdm_notebook.reset() method."""
    from time import sleep

    # Should test that the bar_style is resetted
    for total in [None, 3, 10]:
        for leave in [True, False]:
            print("\nTesting tqdm_notebook.reset(total=%s, leave=%s)" %
                  (total, leave))
            bar = tqdm_notebook(total=total, leave=leave, unit="B", unit_scale=True)
            bar.update()
            bar.set_description(msg='started')
            assert bar.leave == leave
            assert bar.total == total
            sleep(0.1)
            bar.reset(total=total)
            assert bar.leave == leave
            assert bar.total == total
            # cleanup
            bar.close()

# Generated at 2022-06-12 15:15:41.107958
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML as HTML_DISPLAY
    from .std import tqdm_gui, tnrange
    from .std import get_instances
    for t in get_instances():
        # Test HTML output
        pbar = tqdm_notebook.status_printer(
            total=101, desc='Displaying test', ncols=100)
        assert str(pbar).startswith('Displaying test')
        assert isinstance(pbar, TqdmHBox)
        assert isinstance(pbar.children[0], HTML_DISPLAY)
        assert isinstance(pbar.children[1], IProgress)
        assert isinstance(pbar.children[2], HTML_DISPLAY)
        assert pbar.pbar == pbar.children[1]
        pbar.pbar.value = 101

# Generated at 2022-06-12 15:15:50.455967
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm._tqdm import status_printer  # noqa
    from tests_tqdm import pretest_posttest, String_IO
    from random import uniform
    from math import ceil
    from time import sleep

    # Typical output run
    if not pretest_posttest():
        raise ValueError('Test failed')

    # Empty tqdm
    with pretest_posttest():
        with tqdm(total=0) as t:
            pass

    # Randomized test
    f = String_IO()
    with tqdm(total=10, file=f) as t:
        for i in range(10):
            sleep(uniform(0.01, 0.1))
            t.update()
    assert f.getvalue()

    # Test total=None
    f = String_IO()


# Generated at 2022-06-12 15:15:58.313254
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook()
    try:
        t.pbar.visible = True
    except AttributeError:
        t.pbar.displayed = True
    t.display()
    assert t.pbar.visible


if __name__ == "__main__":
    # Unit test for method display of class TqdmHBox
    def test_TqdmHBox_display():
        h = TqdmHBox(children=[HTML(), FloatProgress(), HTML()])
        h.pbar = tqdm_notebook()
        h.pbar.n = 1
        h.pbar.total = 100
        h.pbar.display()

    test_TqdmHBox_display()
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:16:03.347815
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    import sys
    msg = "testing"
    progress = 1
    total = 5
    old_stdout = sys.stdout
    try:
        sys.stdout = StringIO()
        from .notebook import tqdm
        container = tqdm.status_printer(file, total=total)
        assert len(container.children) == 3
        assert isinstance(container.children[1], IProgress)
        assert isinstance(container, HBox)
    finally:
        sys.stdout = old_stdout

# Generated at 2022-06-12 15:16:07.530585
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # bug in tqdm_notebook.reset()
    # should be fixed in the following commit
    # https://github.com/tqdm/tqdm/commit/054c8b1668b27cf71c235fdd464b7c8fbd0eeb56
    from tqdm import tqdm_notebook
    t = tqdm_notebook(total=10)
    for i in range(5):
        t.update()
    t.reset(total=None)
    for i in range(4):
        t.update()

if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:16:27.673548
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit tests to test method status_printer of class tqdm_notebook"""

    # Test with arguments
    desc = "Test"
    tot_val = 20
    ncols = 100
    container = tqdm_notebook.status_printer(_range(tot_val), desc=desc, ncols=ncols)
    ltext, pbar, rtext = container.children
    assert (pbar.max == tot_val)
    assert (container.layout.width == '100%')
    assert (container.layout.display == 'inline-flex')
    assert (container.layout.flex_flow == 'row wrap')
    assert (pbar.layout.flex == '2')
    assert (ltext.value == desc)
    assert (rtext.value == '')

    # Test without arguments
    container

# Generated at 2022-06-12 15:16:37.367908
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import clear_output
    from random import randint

    def random_clear_output(tqdm):
        """
        Add clear_output for random iterations in test to ensure
        that the output is not overridden
        """
        if randint(0, 5) == 3:
            clear_output(wait=True)

    # 100%
    pbar = tqdm_notebook.status_printer(sys.stdout, total=100, desc='Loading...')
    random_clear_output(pbar)

    # 100%
    pbar = tqdm_notebook.status_printer(sys.stdout, total=100, desc='Loading...', ncols=10)
    random_clear_output(pbar)

    # Test 0% total
    pbar = tqdm_notebook

# Generated at 2022-06-12 15:16:44.993724
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm import trange
    from .utils import format_size
    from .std import tqdm as std_tqdm
    defer_batch = (
        '100%|██████████| 50/50 [00:01<00:00, 40.91it/s]'
        + '\n' + 'itertools.chain(r, r) :  50%|█████     | 25/50 [00:00<00:00, 242.56it/s]')
    for total, expected in [(None, True), (False, True), (True, True), (100, True)]:
        pbar = trange(2, file=sys.stdout, total=total)

# Generated at 2022-06-12 15:16:55.393060
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for `tqdm_notebook.update()` method.
    """
    from .std import tqdm

    # NB: this test is a bit pointless since it tests parent class's method
    # but is here to ensure tqdm has a consistent behavior across
    # notebooks, text and GUI environments.

    total, desc, leave = 200, 'test', True
    pbar = tqdm(total=total, desc=desc, leave=leave)

    # update with n < total
    new_n, new_total = 30, 30  # new_total > n
    pbar.update(n=new_n, total=new_total)
    assert pbar.n == new_n
    assert pbar.total == new_total

    # update with n > total
    new_n, new_total = 80

# Generated at 2022-06-12 15:17:03.362285
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=1)
    t.display(msg='msg')
    t.display(msg='msg', bar_style='warning')
    t.display(msg='msg', bar_style='danger')
    t.display(msg='msg', bar_style='success')
    t.display(msg='msg', bar_style='info')
    t.display(msg='msg', bar_style='danger')
    t.display(close=True)
    t.display(msg='msg', bar_style='warning')


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:17:08.563866
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        if IPY < 3:
            raise ImportError  # skip tests if not IPython Notebook
        import time
        # wait a bit if user is still browsing the noteook
        time.sleep(5)
        total = 100
        with tqdm_notebook(total=total) as t:
            for i in range(total):
                time.sleep(0.1)
                t.update(1)
            for i in range(total):
                time.sleep(0.1)
                t.update(1)
    except:
        # display error message if failed
        from IPython.display import HTML, display

# Generated at 2022-06-12 15:17:16.213059
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    `tqdm_notebook.status_printer` is a method that returns a
    `ipywidgets` widget, containing a description and a `FloatProgress`
    widget (`IProgress`).
    Its object must have the method `update` that takes a sole argument,
    a number between 0 and `max` (included), which is used to update
    the current value for that bar.
    This method is called by `tqdm_notebook.ipython_widget_wrapper` to
    generate the IPython widget for use in the tqdm notebook module.
    """
    if IPY:  # pragma: no cover
        from io import StringIO
        from tqdm.notebook import tqdm_notebook
        out = StringIO()

# Generated at 2022-06-12 15:17:19.097075
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import unittest

    class TestTqdmMethods(unittest.TestCase):
        def test_status_printer(self):
            tqdm_notebook.status_printer(None)

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-12 15:17:28.824752
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import os

    # Testing the case of pretty=False and pretty=None
    container = TqdmHBox()
    container.pbar = std_tqdm('')
    assert isinstance(container.__repr__(), str)
    assert isinstance(container.__repr__(False), str)

    # Testing the case of pretty=True
    current_os = os.name
    os.name = 'posix'
    container.pbar.format_dict['ascii'] = False
    assert container.__repr__(True) == '\r  0%|                                                           | 0/1 [00:00<?, ?it/s]'
    container.pbar.format_dict['ascii'] = True

# Generated at 2022-06-12 15:17:33.063294
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        # Does not work correctly due to how ipywidgets is imported
        from ipywidgets.widgets import FloatSlider
    except ImportError:
        return

    with tqdm_notebook(total=10) as pbar:
        for i in range(15):
            pbar.update(1)
            pbar.reset(total=100)

# Generated at 2022-06-12 15:17:57.962867
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    from threading import Thread

    try:
        from tkinter import TclError  # python 3
    except ImportError:
        from Tkinter import TclError  # python 2

    with tqdm(total=10) as pb:
        def reset_test():
            time.sleep(0.1)
            try:
                pb.reset()
            except TclError:
                pass
            pass

        t = Thread(target=reset_test)
        t.start()
        for i in range(10):
            pb.update()
            time.sleep(0.05)
        t.join()

# Generated at 2022-06-12 15:18:05.682704
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random

    def sleep_rand():
        sleep(random())

    # Note: manual tqdm doesn't cope well with KeyboardInterrupt
    #       but that's normal, it's an *incomplete* bar
    #       (same thing in text mode)

    # start = 1
    with tqdm_notebook(total=32) as pbar:
        for _ in pbar:  # total=None
            sleep_rand()

    # start = 2
    for _ in tqdm_notebook(total=40, desc="1st loop"):  # total=None
        sleep_rand()

    # start = 3

# Generated at 2022-06-12 15:18:09.291597
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    buff = StringIO()
    tqdm_notebook.status_printer(buff, 10, 'title')
    assert buff.getvalue() == 'title:<bar/>\n'


# test_tqdm_notebook_status_printer()

# Generated at 2022-06-12 15:18:18.729674
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test tqdm_notebook display method.
    """
    import sys
    import shutil
    from random import randrange
    from subprocess import Popen, PIPE, STDOUT
    from io import StringIO
    from collections import defaultdict
    from os.path import getctime
    from time import sleep
    from types import GeneratorType

    def init_tqdm(*args, **kwargs):
        """
        Initialise a tqdm_notebook instance with the given arguments
        and return it.
        """
        fp = kwargs.pop('file', sys.stderr)
        if fp is sys.stderr:
            fp = sys.stdout
        kwargs['gui'] = True
        # convert disable = None to False

# Generated at 2022-06-12 15:18:22.339232
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    with tqdm_notebook(total=2) as pbar:
        for i, x in enumerate(range(2)):
            time.sleep(0.25)
            pbar.update()
            yield x
# test_tqdm_notebook___iter__()



# Generated at 2022-06-12 15:18:26.598095
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """tests the __iter__ method of the tqdm_notebook class"""
    from .tqdm import trange
    for i in trange(3, desc='1st loop', disable=False):
        for j in trange(100, desc='2nd loop'):
            for k in trange(100, desc='2nd loop', leave=True):
                pass
            assert j == k
        assert i == j == k

# Generated at 2022-06-12 15:18:29.279453
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from random import randint
    from time import sleep
    t = tqdm_notebook(total=300, desc="test")
    for i in range(900):
        t.update(3)
        sleep(randint(1, 5) / 100.0)
    t.close()



# Generated at 2022-06-12 15:18:33.515783
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    test_bar = tqdm_notebook(total=10)
    assert test_bar.total == 10
    test_bar.reset(total=100)
    assert test_bar.total == 100

    test_bar.reset()
    assert test_bar.total == None

# Generated at 2022-06-12 15:18:41.870886
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from numpy import random  # nosec
    from tqdm import tqdm_notebook

    # First test: display on 3 seconds delay
    t = tqdm_notebook(total=100, desc='tqdm notebook', leave=False,
                      bar_format='{l_bar}{bar:40}{r_bar}{bar:-10b}',
                      display=True, unit='it', unit_scale=True)
    for i in random.rand(100):  # nosec
        t.update()
        sleep(0.03)
    t.close()

    # Second test: this will try to close the bar

# Generated at 2022-06-12 15:18:43.018824
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    iterable = range(100)
    output = list(tqdm(iterable))
    assert output == iterable


# Generated at 2022-06-12 15:18:58.335298
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from IPython.display import HTML, display, clear_output

    with tqdm_notebook(total=10, unit='B', unit_scale=True, desc='test') as t:
        for i in range(10):
            clear_output(wait=True)
            display(HTML("<h1>Hello World</h1>"))
            t.update()
            sleep(0.01)
        t.close()


if __name__ == "__main__":
    test_tqdm_notebook()  # pragma: no cover

# Generated at 2022-06-12 15:19:00.841661
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test for tqdm.notebook.tqdm_notebook.reset()."""
    from time import sleep

    tq = tqdm_notebook(total=10)
    for i in tq:
        sleep(0.1)
    tq.reset(total=5)
    for i in tq:
        sleep(0.1)

# Generated at 2022-06-12 15:19:10.949237
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Runs `tqdm_notebook.__init__` and prints the result [for test purposes]"""
    from .std import tqdm_gui
    i = tqdm_notebook(["hi", "there", "friend"], ncols=100,
                      desc="This is a test tqdm!", file=sys.stdout)
    for obj in i:
        assert type(obj) == str
        i.display(pos=i.n,
                  msg="Processing %s" % obj,
                  bar_style=tqdm_gui.default_gui.widgets[i.pos]["bar_style"])
    i.clear()
    i.close()
    print(i)


# Test the module
if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:19:19.354208
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .tests import pretest_posttest  # NOQA (for Py2)
    with pretest_posttest():
        pbar = tqdm_notebook(total=0)

# Generated at 2022-06-12 15:19:25.627791
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import re
    from IPython.html.widgets import HTML
    from IPython.html.widgets import FloatProgress as IProgress

    pbar = IProgress(max=100)

    # No total? Show info style bar with no progress tqdm status
    pbar.bar_style = 'info'
    try:
        pbar.layout.width = "20px"
    except AttributeError:
        pass
    rtext = HTML()
    t = tqdm_notebook(total=None)
    t.container = tqdmHBox([HTML(), pbar, rtext])
    t.colour = None
    t.displayed = False
    t.display("Unit test")
    assert pbar.bar_style == 'info'
    assert pbar.value == 1
    assert not rtext.value

    # Show

# Generated at 2022-06-12 15:19:30.617354
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from numpy.testing import assert_equal
    with tqdm_notebook(total=10) as pbar:
        for _ in range(5):
            sleep(0.1)
            pbar.update()
        # reset bar
        pbar.reset(total=5)
        for _ in range(5):
            sleep(0.1)
            pbar.update()
    # check total n
    assert_equal(pbar.n, 10)
    # check bar style
    assert_equal(pbar.container.children[-2].bar_style, 'success')

# Generated at 2022-06-12 15:19:32.996159
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update()
    assert t.n == 10


# Script mode
if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-12 15:19:41.075463
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from collections import namedtuple
    from nose.tools import (
        assert_equal, assert_false, assert_true)
    from numpy.testing import assert_array_equal, assert_array_almost_equal

    # DEPRECATED: replaced with an 'info' style bar
    # # Case 0: no total
    # assert_false(hasattr(tqdm_notebook.status_printer(None), 'value'))
    # assert_false(hasattr(tqdm_notebook.status_printer(None), 'max'))
    # assert_false(hasattr(tqdm_notebook.status_printer(None), 'bar_style'))
    # assert_false(hasattr(tqdm_notebook.status_printer(None), 'layout'))

    # Case 1: with total
   

# Generated at 2022-06-12 15:19:48.547796
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import math
    import random
    import time

    def test_reset(t):
        """Helper function to test the reset method"""
        progress_bar = tqdm_notebook(total=t)
        for i in range(t):
            progress_bar.update()
            time.sleep(0.1)
        progress_bar.close()

        progress_bar.reset()

        for i in range(t):
            progress_bar.update()
            time.sleep(0.1)
        progress_bar.close()

    # Test the reset method
    test_reset(3)
    test_reset(5)
    test_reset(10)
    test_reset(100)
    test_reset(100000)

# Generated at 2022-06-12 15:19:55.673190
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from sys import stdout

    with tqdm_notebook(total=10, leave=True, unit='B', unit_scale=1, unit_divisor=1,
                  bar_format='{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]{postfix}',
                  ascii=False, ncols=None, mininterval=0.1, maxinterval=10, miniters=1,
                  desc=None, dynamic_ncols=True, position=0, postfix=None, unit_scale=False,
                  gui=True, file=stdout, ncols=None, disable=False) as t:
        assert t.total == 10
        t.reset(total=100)
        assert t.total == 100


# Generated at 2022-06-12 15:20:16.806826
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Check that tqdm_notebook.__iter__() works correctly
    from .gui import tqdm as tqdm_gui
    from .gui import tgrange as tgrange_gui
    from .gui import trange as tgrange_gui
    from .gui import tnrange as tnrange_gui

    for cls in [tqdm_notebook,
                tnrange, tqdm,
                tqdm_gui, tgrange_gui, tgrange_gui, tnrange_gui]:
        obj = cls(range(1, 4))
        assert isinstance(obj, tqdm_notebook)
        assert iter(obj) is obj
        obj.close()



# Generated at 2022-06-12 15:20:20.585836
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for leave in [False, True]:
        with tqdm(total=2, leave=leave) as t:  # total=None
            t.update()
            t.reset()
            t.reset(total=1)
            t.update()
            sleep(0.01)



# Generated at 2022-06-12 15:20:22.595373
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    h = TqdmHBox(children=[None, None, None])
    h.__repr__()  # should not raise
    assert h._repr_pretty_(object()) == h._repr_json_() == {}

# Generated at 2022-06-12 15:20:24.300087
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as progress:
        for _ in range(10):
            progress.update(1)
        assert (progress.n == 10), "progress.n != 10"

# Generated at 2022-06-12 15:20:30.333610
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method tqdm_notebook.status_printer

    Tests the method `tqdm_notebook.status_printer` by default.
    """
    def check_ipython_4(tqdm_notebook):
        """
        Check the `tqdm_notebook` class for IPython version 4.
        """
        # Check the case when the total is None
        widget = tqdm_notebook.status_printer(None, desc='Checking')
        assert widget.children[0].value == 'Checking'
        assert widget.children[1].bar_style == 'info'
        assert widget.children[1].layout.width == '20px'
        assert widget.children[2].value == ''

        # Check the case when the total is not None
        widget = tqdm_note

# Generated at 2022-06-12 15:20:33.262371
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test function for tqdm_notebook's `status_printer`
    """
    if IPY == 0:
        return
    tqdm_notebook.status_printer(file=None)

if __name__ == '__main__':
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-12 15:20:37.329092
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            sleep(.5)
            pbar.display()

    pbar = tqdm_notebook(total=4, leave=False)
    for _ in range(4):
        sleep(.5)
        pbar.update()
        pbar.display()
    pbar.display(bar_style='success')



# Generated at 2022-06-12 15:20:45.477700
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    from .utils import _range

# Generated at 2022-06-12 15:20:53.104523
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook.

    Tested values:
        - max_value = None,
        - max_value = 100,
        - max_value = 0,
    """
    # max_value = None
    pbar = tqdm_notebook.status_printer(sys.stdout)
    assert(isinstance(pbar, HBox))
    # max_value = 100
    pbar = tqdm_notebook.status_printer(sys.stdout, 100)
    assert(isinstance(pbar, HBox))
    # max_value = 0
    pbar = tqdm_notebook.status_printer(sys.stdout, 0)
    assert(isinstance(pbar, HBox))
    # print(pbar)

# Generated at 2022-06-12 15:21:01.621412
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm as gtqdm
    if not bool(gtqdm):  # no X-windows
        return

    from .tests import pretest_posttest_test

    def test(desc=None, total=None, leave=None, **kwargs):
        """
        Unit test for tqdm_notebook.reset(total=new_total)

        Parameters
        ----------
        desc : str or None
            Description to use
        total : int or None
            Total to use
        leave : bool or None
            Leave argument to use
        **kwargs :
            Additional kwargs to pass to tnrange
        """
        if desc is None:
            desc = "test " + str(desc)
        if total is None:
            total = int(abs(hash(desc)) % 15) + 1
       

# Generated at 2022-06-12 15:21:32.287861
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    kwargs = {}
    file = kwargs.get('file', sys.stderr)
    if file is sys.stderr or file is None:
        kwargs['file'] = sys.stdout  # avoid the red block in IPython

    kwargs['gui'] = True
    kwargs['disable'] = bool(kwargs.get('disable', False))
    total = kwargs.get('total', 10)
    unit_scale = 1 if kwargs.get('unit_scale', True) else kwargs['unit_scale'] or 1
    desc = kwargs.get('desc', "Test")
    ncols = kwargs.get('ncols', None)
    pbar = tqdm_notebook.status_printer(file, total, desc, ncols)

# Generated at 2022-06-12 15:21:42.281277
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    In the beginning:
        [I] msg1  bar1  msg2
    Then:
        [I] msg3  bar2  msg4
    Then:
        [I] msg5  bar3
    Finaly:
        []
    """
    # In the beginning:
    # [I] msg1  bar1  msg2
    # msg1 appears
    # msg2 appears
    # bar1 appears
    t = tqdm_notebook(display=False)
    t.display("msg1", bar_style="info")
    t.display("msg2", bar_style="info")
    t.display()
    t.close()
    # [I] msg3  bar2  msg4
    # msg4 appears
    # msg3 appears
    # bar2 appears
    t = tqdm_

# Generated at 2022-06-12 15:21:47.137065
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    container = TqdmHBox()
    container.pbar = std_tqdm()
    assert container.__repr__() != container.__repr__(pretty=True)
    assert container.__repr__(pretty=True) == container.__repr__(pretty=False)
    assert container.__repr__() == container.__repr__(pretty=False)


# Generated at 2022-06-12 15:21:52.230464
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import doctest
    doctest.testmod()

    # check that nonetype ncols does not break the progressbar
    tqdm_notebook(desc="test", ncols=None)
    # test that it works even without IPython/Jupyter
    tqdm_notebook.IProgress = None
    tqdm_notebook.HBox = None
    tqdm_notebook.HTML = None
    tqdm_notebook(desc="test", ncols=None)


# unit test + coverage
if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:22:02.666389
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Add a new test that uses the update method
    # (for testing coverage on the update method in ipython)
    import unittest
    from unittest.mock import patch

    class TqdmNotebookUpdateTest(unittest.TestCase):
        """Class for testing the tqdm_notebook method update."""
        @patch('IPython.display.display')
        def test_update(self, mock_display):
            """Test update."""
            self.tn = tqdm_notebook(range(5), leave=False)
            self.assertEqual(self.tn.n, 0)
            # Test all paths of the update method
            self.tn.update(1)
            self.assertEqual(self.tn.n, 1)

# Generated at 2022-06-12 15:22:07.726726
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Tests class tqdm_notebook._iter__"""
    # test if iteration works and the correct amount increments
    for i in tqdm_notebook(range(2)):
        pass

    # test if iteration works and the correct amount increments
    for i in tqdm_notebook(range(3), total=3):
        pass

    # test if iteration works and the correct amount increments
    for i in tqdm_notebook(xrange(2)):
        pass



# Generated at 2022-06-12 15:22:15.608331
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test method `update` of class `tqdm_notebook`.
    """
    from time import sleep
    from tqdm.utils import _term_move_up

    t = tqdm_notebook(
        total=4,
        file=sys.stdout,
        mininterval=0.2,
        leave=False
    )
    try:
        t.update(0)
        sleep(0.5)
        t.update(1)
        sleep(0.5)
        t.update(2)
        # precondition: no output, only update
        t.update(3)
        sleep(0.5)
        t.update(4)
        sleep(0.5)
        # postcondition: no output, only update
    except Exception as e:
        t.close()

# Generated at 2022-06-12 15:22:25.549333
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test the method status_printer of class tqdm_notebook.
    """
    import unittest
    from io import StringIO

    class TqdmNotebookTest(unittest.TestCase):
        """
        Test class for the method status_printer of class tqdm_notebook.
        """

        def test_status_printer(self):
            """
            Test the method status_printer of class tqdm_notebook.
            """
            # Redirect the output to a fake stream
            output_file = StringIO()

            # Initialize the tqdm_notebook object
            tqdm_notebook._instances = {}  # reset tqdm_notebook instances
            tqdm_notebook_obj = tqdm_notebook(file=output_file)

            # Give

# Generated at 2022-06-12 15:22:32.659136
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import io
    import os

    # Create a proxy
    # NOTE: if tqdm is not imported at this point, then jupyter will fail
    # with a "NameError: name 'get_ipython' is not defined"
    ip = get_ipython()
    if ip is None:
        raise RuntimeError("Notebook progressbar: not in an IPython notebook!")
    ip.history_manager.store_inputs = lambda *a: None
    ip.run_cell = lambda *a: None

    # Make a mock object to capture stdout
    class FileLike(io.BytesIO):
        def write(self, x):
            # print("write(): got %r" % x)
            io.BytesIO.write(self, x)


# Generated at 2022-06-12 15:22:40.479088
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Display a random progress bar"""
    import random
    import time
    random.seed(0)
    from .tqdm import tqdm_notebook

    pbar = tqdm_notebook.status_printer(file=None)
    len = random.randint(10, 20)
    pbar.value = random.randint(0, len)
    pbar.max = len
    pbar.bar_style = random.choice(['info', 'warning', 'danger', 'success'])