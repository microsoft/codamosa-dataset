

# Generated at 2022-06-12 15:13:39.631153
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert TqdmHBox.__repr__(dict()) == "{'pbar': None}"
    assert TqdmHBox.__repr__(dict(pbar=None)) == "{'pbar': None}"

# Generated at 2022-06-12 15:13:50.099602
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY < 3:
        raise Exception("IPython version not supported for this test")
    from IPython.display import HTML, clear_output
    from IPython.html.widgets import FloatProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML as _HTML

    for ncols in [None, 90, "50%", "50px"]:
        for total in [None, 10]:
            desc = "a"*10  # ten chars
            msg = "<b>{l_bar}</b><bar/>{r_bar}".format(l_bar=desc, r_bar="b")
            c = tqdm_notebook.status_printer(sys.stderr, total=total,
                                             desc=desc, ncols=ncols)


# Generated at 2022-06-12 15:13:56.572195
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from ipywidgets import HTML
    from IPython.display import display
    from IPython import get_ipython
    ip = get_ipython()
    for ip in [None, ip]:
        for leave in [True, False]:
            for disable in [True, False]:
                display(HTML("<hr/>"))
                t = tqdm_notebook(range(3), leave=leave, disable=disable,
                                  desc="Update test (leave={})".format(leave),
                                  file=ip)
                for i in range(5):
                    t.update()
                t.close()



# Generated at 2022-06-12 15:14:01.381157
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    for _ in tqdm_notebook(range(4), desc='1st loop', leave=True):
        for _ in tqdm_notebook(range(5), desc='2nd loop'):
            sleep(.1)
        if _ == 2:
            break


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-12 15:14:09.317515
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for the method status_printer of class tqdm_notebook
    """
    import io

    from .utils import format_sizeof

    # Prepare the text

# Generated at 2022-06-12 15:14:14.147101
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for total in [None, 0, 10, 60.4]:
        for leave in [True, False]:
            t = tqdm_notebook(total=total, leave=leave)
            t.reset(total=20)
            t.update(1)
            if total is None:
                assert t.total == 0
            else:
                assert t.total == total
            t.close()


if __name__ == "__main__":
    from .tests import test_tqdm  # NOQA
    test_tqdm(tqdm_notebook)

# Generated at 2022-06-12 15:14:18.581039
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # import tqdm.notebook
    with tqdm(total=2, gui=True) as t:
        assert t.n == 0
        t.update()
        assert t.n == 1
        t.update(1)
        assert t.n == 2



# Generated at 2022-06-12 15:14:22.406322
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            pbar.update()
    assert pbar.displayed
    try:
        pbar.close()
        assert False, "Expected error"
    except AttributeError:
        pass



# Generated at 2022-06-12 15:14:30.871184
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from tqdm import _utils
    from tqdm._utils import _term_move_up

    for t in [tqdm_notebook, tnrange, tqdm]:
        try:
            with t(3, bar_format="{l_bar}{bar}|") as pbar:
                pbar.write("Foo\n")
                pbar.reset(4)
                pbar.set_postfix_str("Bar")
                pbar.set_postfix_str("Baz", "Quux")
                pbar.set_postfix(a=1, b=2)
                pbar.set_postfix(dict(a=1, b=2))
                pbar.update(3)
        finally:
            _utils.term_move_down = _term_move

# Generated at 2022-06-12 15:14:39.656970
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class TestPbar(IProgress):
        def __init__(self, *args, **kwargs):
            super(TestPbar, self).__init__(*args, **kwargs)
            self.msg = None

        @staticmethod
        def _ipython_display_(self):
            self.msg = ''

    def test(msg):
        if getattr(TestPbar, 'msg', None) != msg:
            raise AssertionError("Wrong msg:\n" + str(msg) + "\n"
                                 "Expected:\n" + str(TestPbar.msg))

    t = tqdm_notebook
    t.status_printer(None, total=1)  # defaults
    test("<bar>")
    t.status_printer(None, total=0)  # disable if no total


# Generated at 2022-06-12 15:14:55.800863
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase
    from io import StringIO
    from unittest.mock import patch
    from .utils import FormatStrin

# Generated at 2022-06-12 15:14:58.678913
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    # Initialize the tqdm_notebook
    pbar = tqdm_notebook(total=100)
    for i in range(10):
        # Update the process status
        pbar.update(10)
        time.sleep(0.1)
    pbar.close()

# Generated at 2022-06-12 15:15:00.185269
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook(range(100), leave=True):
        pass


# Generated at 2022-06-12 15:15:08.824236
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output

    # Test display
    n = tqdm_notebook(total=5)
    assert n.displayed is False
    n.update()
    assert n.displayed is True
    clear_output()

    # Test with delay > 0
    n = tqdm_notebook(total=5, desc="test", delay=1)
    assert n.displayed is False
    n.update()
    assert n.displayed is False
    n.display()
    assert n.displayed is True
    clear_output()

    # Test with delay = 0
    n = tqdm_notebook(total=5, desc="test", delay=0)
    assert n.displayed is False
    n.update()
    assert n.displayed is True
    clear_output()




# Generated at 2022-06-12 15:15:13.618113
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time

    # Test reset method
    bar = tqdm_notebook(range(4), disable=False)
    for i in bar:
        time.sleep(0.2)
        if i == 1:
            bar.reset(2)

if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:15:24.138634
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    _interactive_shell = tqdm_notebook.gui().name
    assert tqdm_notebook == tqdm and tnrange == trange, \
        "tqdm_notebook aliases are not working"
    assert hasattr(tqdm_notebook, "display"), \
        "tqdm_notebook object has no display method"
    assert tqdm_notebook(total=2).gui().name == _interactive_shell, \
        "interactive shell was not detected properly"
    assert tqdm_notebook(total=1, disable=None).gui().name == _interactive_shell, \
        "interactive shell was not detected properly"

# Generated at 2022-06-12 15:15:35.901616
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import version
    from time import sleep
    t = tqdm_notebook()
    t.display()
    t.display(bar_style='danger')
    t.display(bar_style='success')
    t.display(close=True)
    t.display(bar_style='danger', close=True)
    t.display(bar_style='success', close=True)
    t.display(close=True)
    if version >= "3":
        from io import StringIO as uio
    else:
        from StringIO import StringIO as uio
    if hasattr(uio, 'getvalue'):
        uio = uio.getvalue
    assert not t.displayed
    t.display(bar_style='danger')

# Generated at 2022-06-12 15:15:42.954569
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for method close of class tqdm_notebook
    """
    from io import StringIO
    import contextlib

    # fake stdout to check string printed by tqdm
    fake_stdout = StringIO()

    @contextlib.contextmanager
    def fake_stdout_cm(fake_stdout):
        """
        Context manager to temporarily hook a fake stdout object
        """
        import sys
        real_stdout = sys.stdout
        sys.stdout = fake_stdout
        yield
        sys.stdout = real_stdout

    def check_close_string(total, leave, expected_end, expected_elapsed):
        """
        Check that the end string of a tqdm bar contains only the end
        information (and in particular no progress bar)
        """
        fake_stdout

# Generated at 2022-06-12 15:15:52.378063
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Tests that method `tqdm_notebook.__iter__` raises and hides the bar on
    KeyboardInterrupt, and displays it in case of stop iteration.
    """
    from tqdm import TqdmKeyboardInterrupt, TqdmDeprecationWarning
    from time import sleep
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    # Monkey patch IProgress to intercept bar value and style
    class IProgressMock(object):
        """Mock of pbar.style"""
        def __init__(self):
            self.value = 0
            self.bar_style = ''
            self.layout = MagicMock()
            self.layout.flex = '2'


# Generated at 2022-06-12 15:15:58.695692
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm._tqdm_notebook_test_class import TestTqdmNbNoclear
    with TestTqdmNbNoclear(total=1, bar_format='{l_bar}{bar}{r_bar}') as t:
        t.update()
        t.update()
    try:
        with TestTqdmNbNoclear(total=1, bar_format='{l_bar}{bar}{r_bar}') as t:
            t.update()
            t.clear()
            t.update()
        assert False
    except AssertionError:
        pass

# Generated at 2022-06-12 15:16:17.493055
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.utils import _supports_unicode
    from tqdm import tqdm  # use the std module for testing!
    import re
    import sys

    # Check if ipywidgets is installed
    try:
        import ipywidgets
    except ImportError:
        print("ipywidgets is not installed.", file=sys.stderr)
        return None

    # Unicode character
    if _supports_unicode():
        unichr = chr
    else:
        unichr = lambda c: c

    # If range is not used, the total will be unknown
    container = tqdm_notebook.status_printer(file=None)
    assert 'aria-valuemax' not in container._repr_json_(pretty=False)
    assert 'aria-valuemax'

# Generated at 2022-06-12 15:16:19.501880
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_equal

    # Test simple iteration
    with tqdm_notebook(total=10) as t:
        for i in t:
            assert_equal(t.n, i + 1)



# Generated at 2022-06-12 15:16:23.668561
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    it = tqdm_notebook(range(3), desc='An example')
    for _ in it:
        sleep(0.01)

    it = tqdm_notebook(range(3), desc='Another example', disable=True)
    for _ in it:
        sleep(0.01)

    with tqdm_notebook(range(3), desc='An example', disable=True) as it:
        for _ in it:
            sleep(0.01)


# Generated at 2022-06-12 15:16:33.346623
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import time
    import unittest
    import io
    class TestClear(unittest.TestCase):
        """ Test clear method of class tqdm_notebook """
        @staticmethod
        def _f():
            """ Generator to use with tqdm_notebook """
            yield 'Hello'
            yield 'World'
        def test_clear(self):
            """ Test clear method of class tqdm_notebook """
            # Save the print output
            sys.stdout = f = io.StringIO()
            # Define a progress bar to clear
            bar = tqdm_notebook(self._f(), file=sys.stdout)
            # Print the progress bar one time
            for _ in bar:
                pass
            # Clear the progress bar
            bar.clear()
            # Test the result

# Generated at 2022-06-12 15:16:41.958661
# Unit test for method display of class tqdm_notebook

# Generated at 2022-06-12 15:16:51.710366
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test function for tqdm_notebook status_printer"""
    from ipywidgets import IntProgress
    from IPython.display import HTML

    # check the function tqdm_notebook status_printer
    total = 5
    file = tqdm_notebook.status_printer(None, total)
    assert isinstance(file, TqdmHBox)
    assert isinstance(file.pbar, IntProgress)
    assert isinstance(file.children[3], HTML)

    # check the function tqdm_notebook status_printer when no total
    # DEPRECATED: replaced with an 'info' style bar
    # file = tqdm_notebook.status_printer(None)
    # assert isinstance(file, TqdmHBox)
    # assert isinstance(file.pbar,

# Generated at 2022-06-12 15:16:55.227302
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2) as t:
        t.write("abc")
        t.clear()
        t.write("def")
        t.clear()
        t.write("ghi")
        t.clear()
        t.update()



# Generated at 2022-06-12 15:16:59.866247
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert return_tqdm_notebook_status_printer() == {
        'pos': 0, 'total': 100, 'bar_format': '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    }



# Generated at 2022-06-12 15:17:04.450343
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    """
    Test if tqdm_notebook.display works.

    Yields
    ------
    out  : tuple
        Output messages:
        - `type`: output message type (1: info, 2: success, 3: error)
        - `content`: output message content ('' for types 1 and 2)
    """
    # method display of class tqdm_notebook
    from IPython.display import HTML, clear_output
    from IPython.core.display import display
    from tqdm import tqdm_notebook as tn
    from tqdm._tqdm_notebook import tqdm as _tqdm
    from tqdm import trange
    from time import sleep


# Generated at 2022-06-12 15:17:05.945870
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=100, leave=True) as pbar:
        for i in range(100):
            pbar.update(2)

# Generated at 2022-06-12 15:18:00.299600
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import os
    import sys

    t = tqdm_notebook(range(10), file=sys.stdout)
    t.reset()
    t.reset(total=5)
    t.reset(total=5)

    # test clear and display=False
    t = tqdm_notebook(range(10), file=sys.stdout, display=False)
    t.reset()
    t.reset(total=5)
    t.reset(total=5)

    # test widget
    t = tqdm_notebook(range(10), file=sys.stdout)
    t.reset()
    t.reset(total=5)
    t.reset(total=5)

    # test close and leave
    t = tqdm_notebook(range(10), file=sys.stdout)


# Generated at 2022-06-12 15:18:06.179755
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from contextlib import contextmanager
    from io import StringIO
    with suppress_stdout_stderr():
        @contextmanager
        def capture_output(stdout):
            orig_out, orig_err = sys.stdout, sys.stderr
            sys.stdout, sys.stderr = stdout, stdout
            try:
                yield
            finally:
                sys.stdout, sys.stderr = orig_out, orig_err


# Generated at 2022-06-12 15:18:16.301035
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    args = (1, 'Testing...')
    kwargs = {'ncols': '100px', 'smoothing': 0.1}
    c = tqdm_notebook.status_printer(*args, **kwargs)
    assert c.layout.width == '100px'
    assert c.layout.display == 'inline-flex'
    assert c.layout.flex_flow == 'row wrap'
    assert 'Testing...' in c.children[0].value
    assert isinstance(c.children[-2], IProgress)
    assert c.children[-2].max == 1
    assert c.children[-2].value == 0
    assert isinstance(c.children[-1], HTML)
    assert c.children[-1].value == '0it [00:00, ?it/s]'
    c

# Generated at 2022-06-12 15:18:24.256045
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import tqdm
    main_bar = tqdm_notebook(total=10)
    main_bar.reset()
    assert main_bar.total == 0


if __name__ == '__main__':
    import sys
    test_tqdm_notebook_reset()
    print("Testing tqdm_notebook(10)", file=sys.stderr)
    with tqdm(total=10) as t:
        for i in range(10):
            t.update(1)
    print("Testing tqdm_notebook(10^4)", file=sys.stderr)
    with tqdm(total=10000) as t:
        for i in range(10000):
            t.update(1)

# Generated at 2022-06-12 15:18:34.042549
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        import ipywidgets
    except ImportError:
        ipywidgets = None
    if ipywidgets:
        from IPython.display import display, clear_output
        fp = tqdm_notebook(total=10)
        fp.reset(total=12)
        display(fp)

        fp.reset(total=14)
        display(fp)
        clear_output()
        fp.reset(total=16)
        display(fp)

        fp.reset(total=18)
    else:
        raise unittest.SkipTest("ipywidgets not installed")


if __name__ == '__main__':
    import unittest
    here = sys.argv.count('--here') != 0  # used by CI, do not remove

# Generated at 2022-06-12 15:18:42.263514
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from math import sqrt
    import time
    style = 'info'  # style = 'warning'

    # '100% (1 of 1)'
    with tqdm_notebook(total=1, desc='foo', mininterval=0) as t:
        t.update()
        time.sleep(1)
        t.container.close()
        t.displayed = False

        # '100% (1 of 1)'
        t.reset(total=1)
        t.update()

        # '0%|          | 0/1'
        t.reset(total=1)
        assert t.n == 0
        t.update()
        t.displayed = False

        # '0%|          | 0/1'
        t.reset(total=1)
        assert t.n == 0

# Generated at 2022-06-12 15:18:43.956863
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:
        raise ImportError('IPython not found')
    else:
        assert tqdm_notebook.status_printer(0, 100, 'hello bar')

# Generated at 2022-06-12 15:18:54.986434
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from unittest import mock
    except ImportError:  # pragma: no cover
        from mock import mock

    try:
        from contextlib import nullcontext
    except ImportError:  # pragma: no cover
        from contextlib import ExitStack


        class nullcontext(ExitStack):
            def __init__(self, *args, **kwargs):
                super(nullcontext, self).__init__()
                self.__enter__()

            def __exit__(self, *args, **kwargs):
                self.__exit__(*args, **kwargs)

    class FakePBar(object):
        def __init__(self):
            self.value = 0
            self.bar_style = ""


# Generated at 2022-06-12 15:19:03.867306
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep

    # Testing update in while loop with an error
    try:
        with tqdm_notebook(['.', '..', '...']) as bar:
            for i in bar:
                bar.update(i)
                sleep(.1)
                raise Exception
    except:  # NOQA
        bar.disp(bar_style='danger')
        assert bar.colour == 'red'

    # Testing update in while loop in manual mode
    try:
        with tqdm_notebook(['.', '..', '...']) as bar:
            for i in bar:
                sleep(.1)
                bar.update(i)
                raise Exception
    except:  # NOQA
        assert bar.colour == 'red'

    # Testing update in for loop

# Generated at 2022-06-12 15:19:14.010664
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import format_sizeof
    from .utils import sizeof_fmt
    from .utils import time_units
    from .utils import sec_to_str
    from .utils import str_to_sec
    from .gui import tqdm_gui
    from .gui import tgrange
    from .gui import tqdm_pandas
    from .gui import tqdm_pandas
    from .gui import tqdm_pandas
    from multiprocessing import Pool
    from subprocess import Popen
    from os import cpu_count
    from os import name
    from sys import executable
    from contextlib import closing
    from functools import partial

    # Test .pos
    t = tqdm_notebook(0, desc="test")
    assert (t.pos == 0)

# Generated at 2022-06-12 15:19:46.863022
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """ Real life examples of usage. """
    # Standard
    for i in tqdm_notebook(range(8)):
        pass

    # Reset
    pbar = tqdm_notebook(total=8)
    for i in range(5):
        pbar.update()
    pbar.reset(total=5)
    for i in range(5):
        pbar.update()

    # No reset (but no display of 100%)
    pbar = tqdm_notebook(total=8, leave=True)
    for i in range(9):
        pbar.update()

    # Dynamic ncols
    for i in tqdm_notebook(range(8), dynamic_ncols=True):
        pass

    # No output

# Generated at 2022-06-12 15:19:54.115950
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test tqdm_notebook.display()"""
    from io import StringIO
    # Test exception display
    try:
        raise Exception("Simulated error message")
    except Exception:
        exc_str = StringIO()
        tqdm_notebook.format_exc(exc_str)
        exc_msg = exc_str.getvalue()
        # Test IPython/Jupyter Notebook progress bar widget
        t = tqdm_notebook(desc='Simulated progress bar')
        t.display(msg=exc_msg, bar_style='danger')
        assert t.container.children[-2].bar_style == 'danger'
        t.close()
        # Test tqdm plain text display

# Generated at 2022-06-12 15:20:03.246979
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # DEPRECATED
    assert tqdm_notebook.status_printer(None) is None

    # Test default bar
    from re import sub
    from sys import stdout
    from IPython import get_ipython

    # This test is also relevant for the default ncols
    ipython = get_ipython()
    ipython.magic("config InlineBackend.figure_format = 'retina'")
    container = tqdm_notebook.status_printer(stdout)

# Generated at 2022-06-12 15:20:12.508084
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # #451
    class PW(TqdmHBox):
        format_dict = {'n': 1, 'total': 10, 'bar_format': '{bar}|{n}/{total}'}

    hb = PW()
    assert hb.__repr__(pretty=True) == hb.__repr__(pretty=False)
    assert '{bar}|{n}/{total}' in hb.__repr__(pretty=True)
    assert '<bar/>|1/10' in hb.__repr__(pretty=False)
    hb.close()
    assert '<bar/>|1/10' in hb.__repr__(pretty=True)
    hb.bar_style = 'danger'

# Generated at 2022-06-12 15:20:20.328703
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    try:
        from IPython.display import clear_output
    except ImportError:
        def clear_output(wait=None):
            local_display.clear_output(wait=wait)
    try:
        from IPython.display import display
    except ImportError:
        from IPython.display import display as ipy_display
        def display(*args, **kwargs):
            ipy_display(*args, **kwargs)
    try:
        ipywidgets
    except ImportError:
        ipywidgets = None
    try:
        from tqdm.gui import tkgui
        tkgui_installed = True
    except ImportError:
        tkgui_installed = False
    try:
        from IPython.display import HTML
    except ImportError:
        HTML = None

# Generated at 2022-06-12 15:20:22.566951
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    progressbar = tqdm_notebook(total=30)
    for i in range(10):
        progressbar.update()

    progressbar.close()


if __name__ == "__main__":
    test_tqdm_notebook()

# Generated at 2022-06-12 15:20:27.296057
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from functools import partial

    status_printer = tqdm_notebook.status_printer
    html = HTML()
    text = partial(HTML, value="")
    ip = IProgress(min=0, max=10)
    assert status_printer(None) == ip
    assert status_printer(None, desc="foobar") == TqdmHBox(children=[text(desc="foobar"), ip, text()])
    assert status_printer(None, total=None) == ip
    assert status_printer(None, desc="foobar", total=None) == TqdmHBox(children=[text(desc="foobar"), ip, text()])

# Generated at 2022-06-12 15:20:33.642311
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.utils.capture import capture_output
    from IPython.display import clear_output

    # Hack to create a new IProgress bar in IPython
    def new_pbar(total=None):
        """Returns a new HTML IPython.html.widgets.FloatProgress instance"""
        if IProgress is None:  # #187 #451 #558 #872
            raise ImportError(
                "IProgress not found. Please update jupyter and ipywidgets."
                " See https://ipywidgets.readthedocs.io/en/stable"
                "/user_install.html")
        if total:
            return IProgress(min=0, max=total)

# Generated at 2022-06-12 15:20:37.505708
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    class FakeIter:
        def __init__(self):
            self.counter = 0

        def __next__(self):
            if self.counter == 5:
                raise StopIteration
            self.counter += 1
            return self.counter

        next = __next__  # Python2.7 compatibility

    pbar = tqdm_notebook(FakeIter(), unit='', leave=True)
    pbar.clear()
    assert pbar.container.visible is False



# Generated at 2022-06-12 15:20:39.931110
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=1) as t:
        t.reset(total=2)
        t.update()
        t.reset()


# Generated at 2022-06-12 15:21:10.873555
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    import time
    # Initial check: IPython
    if IProgress is None:
        raise RuntimeError("Skip test (IPython not installed)")

    # Initial check: tqdm
    ip = tqdm(total=10)
    ip.display(False)  # to avoid the display of the initial empty bar
    time.sleep(0.01)
    ip.display(close=True)
    time.sleep(0.01)

    # Test display
    m, s = divmod(int(time.time()), 60)
    h, m = divmod(m, 60)
    time_str = "%02d:%02d:%02d" % (h, m, s)
    with open(sys.argv[0], 'rb') as f:
        f.seek(0, 2)


# Generated at 2022-06-12 15:21:19.346003
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = None

    # setup
    d = tqdm_notebook(total=1000, leave=False)
    n = total = 100
    # test
    d.__iter__()
    for i in d:
        assert i >= 0 and i < n
        if i >= n:
            break
        n += 10
        d.total = total + i
        if clear_output is not None:
            clear_output(wait=True)
        d.update(10)
    # teardown
    d.close()



# Generated at 2022-06-12 15:21:21.600519
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t = tqdm_notebook()
    t.container.__repr__(True)
    t.container.__repr__(False)


# Generated at 2022-06-12 15:21:23.245454
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=2, leave=True, position=0) as t:
        t.clear()
        t.clear(nolock=True)
        assert t.n == 0

# Generated at 2022-06-12 15:21:25.467139
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        tqdm_notebook.display()
    except:
        assert False, "test_tqdm_notebook_display failed"

# Generated at 2022-06-12 15:21:33.865592
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    try:
        from IPython.display import clear_output
    except ImportError:
        clear_output = lambda: None
    try:
        from ipywidgets import FloatSlider, IntSlider
    except ImportError:
        FloatSlider = IntSlider = None
    try:
        from IPython.display import HTML
    except ImportError:
        HTML = None

    import tempfile, webbrowser
    from os import path

# Generated at 2022-06-12 15:21:43.891076
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Fake handles
    class _fake_stdout(object):
        def __init__(self):
            self.n = 0
        def write(self, _):
            self.n += 1

    def test(self, msg=None, pos=None,
             # additional signals
             close=False, bar_style=None, check_delay=True,
             expected_n=None, expected_msg=None,
             **kwargs):
        self.fp = _fake_stdout()
        if msg:
            result = getattr(super(tqdm_notebook, self), "display")(
                msg=msg, pos=pos,
                close=close, bar_style=bar_style, check_delay=check_delay,
                **kwargs)

# Generated at 2022-06-12 15:21:51.642687
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.notebook import tqdm
    from tqdm import trange
    from time import sleep, time
    from random import shuffle
    from numpy.random import rand
    from six.moves import range as xrange

    list_tests = [
        [1, 2, 3],
        [i for i in range(1, 101)],
        list(range(101, 0, -1)),
        list(range(5, 2000, 3)),
    ]

# Generated at 2022-06-12 15:22:02.153659
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test for tqdm_notebook (manual/main thread):
    Method reset of class tqdm_notebook
    """
    from .gui import tqdm as gtqdm
    from .gui import tqdm_gui
    from .std import tqdm as stdtqdm
    from .std import tqdm_std

    # Reset test
    out = gtqdm(total=10)
    for i in out:
        if i == 2:
            out.reset()
        if i == 5:
            break
    assert (out.n == 0)
    assert (out.n == 0)
    assert (out.n == 0)

    # Reset test with total argument
    out = gtqdm(total=10)

# Generated at 2022-06-12 15:22:07.590034
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from .gui import tqdm as tqdm_gui
    from .utils import format_interval
    from .std import format_meter
    import time

    def _test_print_loss(pbar):
        for _ in pbar:
            time.sleep(0.01)
        pbar.write(format_meter(1, 1, 0, 0))

    with tqdm_notebook(total=5, bar_format="{l_bar} {bar} {r_bar} ") as pbar:
        _test_print_loss(pbar)
        time.sleep(0.1)
        with pbar.set_description("test"):
            pbar.close()


# Generated at 2022-06-12 15:22:33.373982
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tnrange(0, 5) as t:
        for i in t:
            assert (i == t.n-1)
            t.update()


# Generated at 2022-06-12 15:22:34.792462
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Use:
        self = tqdm_notebook(total=2)
        self.display(msg='')
    """
    pass

# Generated at 2022-06-12 15:22:40.424917
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    try:
        from IPython.kernel.zmq.pylab.backend_inline import InlineBackend # type: ignore
        from matplotlib.pyplot import plot, show, close  # type: ignore
    except ImportError:
        raise ImportError("Matplotlib/IPython not installed")
    # Test the `status_printer` method of the `tqdm_notebook` class
    from tqdm.notebook import tqdm_notebook, status_printer
    pbar = status_printer(file=None)
    # Test the type of the output
    assert isinstance(pbar, HBox)
    # Test the length (3 children)
    pbar = status_printer(file=None, total=10, miniters=1)

# Generated at 2022-06-12 15:22:46.158739
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tqdm(range(50), desc="Notebook TQDM"):
        sleep(0.01)
        if i == 10:
            tqdm.reset(total=80, leave=True)
        if i == 20:
            tqdm.reset(total=100)
    sleep(0.01)


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:22:52.770042
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from unittest import TestCase

    class TestTqdmNb(TestCase):
        """Test tqdm_notebook.status_printer"""
        def test_nb_status_printer(self):
            """smoke test status_printer"""
            # Empty bar
            obj = tqdm_notebook.status_printer(None, 0)
            try:
                display(obj)
            except NameError:
                pass
            # No total
            obj = tqdm_notebook.status_printer(None)
            try:
                display(obj)
            except NameError:
                pass
            # Total
            obj = tqdm_notebook.status_printer(None, 23)
            try:
                display(obj)
            except NameError:
                pass


# Generated at 2022-06-12 15:22:54.595545
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    pbar = tqdm_notebook(total=10)
    for i in range(10):
        time.sleep(0.5)
        pbar.update(1)
    pbar.close()

# Generated at 2022-06-12 15:23:04.231882
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # just tests that no exception is thrown
    try:
        import ipykernel  # NOQA
    except ImportError:
        raise unittest.SkipTest("IPython/Jupyter not found")
    pbar = tqdm_notebook(total=1)
    pbar.display('')
    pbar.display('')
    pbar.display('')
    pbar.display(close=True)
    pbar.display(close=True)
    pbar.display(close=True)
    pbar.display('')
    pbar.display('')
    pbar.display('')
    pbar.display(close=True)
    pbar.display(close=True)
    pbar.display(close=True)
    pbar.close()

# Generated at 2022-06-12 15:23:11.389826
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    bar = tqdm_notebook(iterable=[1, 2, 3, 4, 5, 6, 7, 8, 9, 0], leave=True)
    sleep(0.2)
    bar.update(2)
    sleep(0.2)
    bar.update(2)
    sleep(0.2)
    bar.close()
    # Clear after test
    sleep(0.2)
    try:
        bar.container.clear_output(wait=True)
    except AttributeError:
        bar.container.close()


# Generated at 2022-06-12 15:23:18.934226
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    from .gui.tqdm_gui import main  # test-module requires tqdm_gui
    from .gui import tgrange

    for module in '', '.gui':
        for cls in 'tqdm', 'trange':
            with main(postfix=module + '.' + cls, disable=True):
                i = 0
                # try behaviour with total #219
                for _ in eval(module + '.' + cls)(range(10)):
                    pass
                # try behaviour without total #219
                for _ in eval(module + '.' + cls)():
                    i += 1
                    if i > 10:
                        break

    # Test the HTML escaping of special characters
    msg = "&*&^%&*&<>&*"

# Generated at 2022-06-12 15:23:29.629057
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import numpy as np
    for v in np.linspace(0, 1, 11):
        hbox = TqdmHBox(children=[None, None, None])
        hbox.pbar = std_tqdm()
        hbox.pbar.total = 100
        hbox.pbar.n = int(v*100)
        hbox.pbar.dynamic_ncols = True
        hbox.pbar.dynamic_miniters = True
        hbox.pbar.dynamic_postfix = True
        hbox.pbar.unit_scale = True
        hbox.pbar.unit = 'B'
        print(repr(hbox))
        print(hbox.__repr__(pretty=True))
    print("Test suite finished")