

# Generated at 2022-06-12 15:13:26.874146
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook
    """
    try:
        from IPython.html.widgets import HTML, FloatProgress
        from IPython.html.widgets import HBox as ContainerWidget
    except ImportError:
        return None  # pass for IPython < 4
    try:
        from IPython.display import display
    except ImportError:
        return None  # pass for IPython < 3
    from IPython.utils.capture import capture_output

    errors = []

    # --- Testing method display ---
    with capture_output() as captured:
        # test method display
        # with a msg and a progress bar
        mytqdm = tqdm_notebook(
            range(0, 10), desc="test display", ascii=True, disable=False)
        mytq

# Generated at 2022-06-12 15:13:34.776495
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    from sys import stderr
    from json import dumps

    l = []

    class tqdm_notebook_test(tqdm_notebook):
        def display(self, **_):
            l.append(_)

        def __init__(self, *args, **kwargs):
            self.fp = stderr
            super(tqdm_notebook_test, self).__init__(*args, **kwargs)
            self.gui = kwargs.get("gui", True)

    def t(total=1000, desc="", ncols=None):
        one = tqdm_notebook_test(total=total, desc=desc, ncols=ncols)
        one.update(total)

# Generated at 2022-06-12 15:13:41.450677
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    # exception and keyboard interrupt
    try:
        for i in tqdm_notebook(range(5)):
            raise Exception
    except Exception:
        pass
    time.sleep(1)

    try:
        for i in tqdm_notebook(range(5)):
            raise KeyboardInterrupt
    except KeyboardInterrupt:
        pass
    time.sleep(1)

    # exception in note
    try:
        for i in tqdm_notebook(range(5), desc='testing', unit='i'):
            raise Exception
    except Exception as e:
        pass
    time.sleep(1)

    # exception in note

# Generated at 2022-06-12 15:13:51.608825
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Test method close of class tqdm_notebook
    """
    # define a manual tqdm with total = 10
    t = tqdm_notebook(total=10)
    # test bar_style with no error (total=None)
    t.close()
    t.reset()
    t.bar_style = None
    # test bar_style with no error (total=10)
    t.close()
    t.reset()
    t.bar_style = None
    # test bar_style with error (total=None)
    t.close()
    t.reset()
    t.bar_style = 'error'
    # test bar_style with error (total=10)
    t.close()
    t.reset()
    t.bar_style = 'error'

# Generated at 2022-06-12 15:14:00.638112
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import tqdm

    with tqdm(total=9, leave=False, file=sys.stdout) as pbar:
        for j in range(5):
            pbar.update(2)
            for i in range(100):
                pass
    for _ in trange(4):
        for i in range(100):
            pass
    for _ in trange(4, leave=True):
        for i in range(100):
            pass
    for _ in tqdm(range(10), leave=True, file=sys.stdout):
        for i in range(100):
            pass
    for _ in tqdm(range(5), leave=False, file=sys.stdout):
        for i in range(100):
            pass

# Generated at 2022-06-12 15:14:02.215499
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    c = tqdm_notebook(total=1)
    c.update()
    c.close()

# Generated at 2022-06-12 15:14:10.027847
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import warnings
    import time
    from numpy import arange
    from tqdm.utils import _term_move_up

    with warnings.catch_warnings():
        warnings.simplefilter("ignore", category=RuntimeWarning)

        pbar = tqdm_notebook(arange(10))
        for i in pbar:
            with pbar.out:
                print(_term_move_up() + 'test')
                time.sleep(.1)

        # Test unit_scale
        pbar = tqdm_notebook(arange(10), unit_scale=0.1)
        for i in pbar:
            with pbar.out:
                print(_term_move_up() + 'test')
                time.sleep(.1)

        # Test dynamic_ncols
        out = lambda **_: None

# Generated at 2022-06-12 15:14:20.665531
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # unit tests are run in a separate process
    # (see unittest docs) and have no access to global variables.
    # Thus they have to be imported inside the function which uses them

    # Test with error in the loop
    t = tqdm_notebook(iterable=range(3), desc='Testing error', leave=False)
    for i in range(3):
        if i == 2:
            raise ValueError("An error happened")
        t.update()
    try:
        t.close()
    except ValueError:
        pass
    else:
        raise ValueError("Didn't catch the error")

    # Test with error occuring after closing tqdm
    t = tqdm_notebook(iterable=range(3), desc='Testing no error when closed',
                      leave=False)

# Generated at 2022-06-12 15:14:29.217526
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests method status_printer of class tqdm_notebook
    """
    from IPython.display import clear_output
    try:  # Py2
        from StringIO import StringIO
    except ImportError:  # Py3
        from io import StringIO
    try:  # Python 3
        from unittest import mock  # Python 3.3+
    except ImportError:
        from mock import MagicMock as mock  # Python 2


# Generated at 2022-06-12 15:14:33.755389
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(fp=None)
    tqdm_notebook.status_printer(fp=None, total=None)
    tqdm_notebook.status_printer(fp=None, total=None, desc='desc')
    tqdm_notebook.status_printer(fp=None, total=None, desc='desc', ncols=None)


# Generated at 2022-06-12 15:14:50.565049
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=10, desc='test_display', ncols=50) as pbar:
        assert pbar.container.children[0].value == 'test_display'
        pbar.display()
        assert pbar.container.children[0].value == 'test_display'
        pbar.display('')
        assert pbar.container.children[0].value == 'test_display'
        pbar.display('test')
        assert pbar.container.children[2].value == 'test'


# Generated at 2022-06-12 15:14:53.703259
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm, trange
    for i in trange(4):
        tqdm.clear(nolock=False)
    for i in trange(4):
        tqdm.clear(nolock=True)

# Generated at 2022-06-12 15:14:56.783480
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test
    items = [1, 2, 3]
    with tqdm_notebook(items) as t:
        for item in t:
            assert item in items
            items.remove(item)
        assert not items, "Not all items were iterated"



# Generated at 2022-06-12 15:14:59.054482
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    progress_bar = tqdm_notebook(total=1, leave=False)
    progress_bar.update()
    progress_bar.close()

if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-12 15:15:04.979528
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for tqdm_notebook.
    """
    from IPython import get_ipython

    ip = get_ipython()
    if not ip:
        raise ImportError("Test requires IPython.")

    class TestTqdmNotebook(tqdm_notebook):
        """
        Test tqdm_notebook class constructor and update.
        """
        def __init__(self, total, interval, leave=None, disable=False):
            # Keep parent from messing with formatting
            super(TestTqdmNotebook, self).__init__(
                total=total, mininterval=0, maxinterval=interval,
                leave=leave, disable=disable)

        def update(self, *_, **__):
            super(TestTqdmNotebook, self).update()


# Generated at 2022-06-12 15:15:11.617576
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test to check if method update is compatible
    with those of std_tqdm and tqdm"""
    try:
        from tqdm.autonotebook import tqdm as autonotebook_tqdm
    except ImportError:
        return
    for tqdm_cls in (tqdm_notebook, std_tqdm, autonotebook_tqdm):
        for n in (1, -1, 'a', 1.0):
            with tqdm_cls(total=10) as bar:
                bar.update(n)
                assert bar.n == n
                bar.update()  # n=1
                assert bar.n == n + 1

if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:15:17.279063
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from pytest import raises
    hold_stdout = sys.stdout
    sys.stdout = sys.__stdout__
    bar_cls = tqdm(total=None)
    bar = bar_cls.__enter__()
    bar.__exit__(None, None, None)
    assert raises(ValueError, bar.clear)
    sys.stdout = hold_stdout



# Generated at 2022-06-12 15:15:26.696361
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test method __iter__ of class tqdm_notebook.
    """
    from ._tqdm_test import pretest_posttest_testsuite, range
    import sys
    TRange = tqdm_notebook(range(5))
    for _ in TRange:
        pass
    for _ in TRange:
        pass  # test repeated use
    # Test exception raising
    from tqdm import TqdmTypeError
    try:
        for _ in TRange:
            raise ValueError()
    except ValueError:
        pass
    else:
        raise AssertionError()
    TRange.close()
    # Test method `tnrange`
    TRange = tnrange(5)
    for _ in TRange:
        pass
    for _ in TRange:
        pass
    # Test

# Generated at 2022-06-12 15:15:37.712987
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Avoid the red block in IPython
    assert not tqdm_notebook.status_printer(sys.stderr).children[0].value
    assert not tqdm_notebook.status_printer(
        sys.stderr).children[-1].value

    # Check bar width
    assert tqdm_notebook.status_printer(
        sys.stderr, "100%").layout.width.endswith("%")
    assert tqdm_notebook.status_printer(
        sys.stderr, "100px").layout.width.endswith("px")
    assert tqdm_notebook.status_printer(
        sys.stderr, "100").layout.width.endswith("px")

# Generated at 2022-06-12 15:15:42.623447
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook.
    """
    try:
        from ipywidgets import Widget
    except (ImportError, RuntimeError):
        return  # no ipywidgets / running in the Github ipynb viewer

    # Check parent class: tqdm
    with tqdm_notebook(range(3)) as t:
        assert t.update() == 1
        assert isinstance(t.container, Widget)
        assert t.update() == 2
        assert t.update() == 3
        assert t.update() == 4

# Generated at 2022-06-12 15:15:57.836714
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # create a TqdmHBox object to test
    h = TqdmHBox()
    # check that the HBox representation is as expected
    print(h)
    assert str(h) == '<HBox>'

# Generated at 2022-06-12 15:16:04.451057
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # init
    status_printer = tqdm_notebook.status_printer
    out = status_printer(None)
    ltext, pbar, rtext = out.children
    # No dynamic width:
    assert(out.layout.width == "100%")
    # With dynamic width:
    out = status_printer(None, ncols="100")
    assert(out.layout.width == "100px")
    # Test desc & total
    out = status_printer(None, total=10, desc="test desc")
    ltext, pbar, rtext = out.children
    assert(ltext.value == "test desc")
    assert(pbar.max == 10)

# Test display method in case of error

# Generated at 2022-06-12 15:16:09.755972
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=6, disable=False) as bar:
        for i in _range(5):
            assert bar.n < bar.total
            bar.update(1)
            # raise exception if total isn't set
            if i == 3:
                bar.total = None
                try:
                    assert bar.total is None
                except:
                    break
                bar.ncols = None
                bar.display(info='starting<br>long<br>info<br>reset')
                bar.reset()

    bar.close()
    # Test reset
    from time import sleep
    with tqdm_notebook(total=10, leave=True, mininterval=0,
                       disable=False) as bar:
        for i in _range(10):
            bar.update()

# Generated at 2022-06-12 15:16:15.214162
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test for method 'status_printer' of class 'tqdm_notebook'"""
    from tqdm.notebook import tqdm_notebook as tqdm
    if IProgress is None:
        return
    pbar = tqdm.status_printer(sys.stdout, total=0)
    assert (len(pbar.children) == 3)
    assert (pbar.layout.width == '100%')
    pbar = tqdm.status_printer(sys.stdout, total=0, ncols=100)
    assert (len(pbar.children) == 3)
    assert (pbar.layout.width == '100px')
    pbar = tqdm.status_printer(sys.stdout, total=0, ncols=100.00)

# Generated at 2022-06-12 15:16:21.098329
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test the method status_printer of class tqdm_notebook"""
    # Test without total
    # DEPRECATED: replaced with an 'info' style bar
    # assert isinstance(tqdm_notebook.status_printer(None), str)

    # Test with total = 1 (no bar)
    assert isinstance(tqdm_notebook.status_printer(None, 1),
                      TqdmHBox)

    # Test with total = 2 (bar)
    assert isinstance(tqdm_notebook.status_printer(None, 2),
                      TqdmHBox)
    # Test with total = 3 (bar) and desc
    assert isinstance(tqdm_notebook.status_printer(None, 3, 'desc'),
                      TqdmHBox)

# Generated at 2022-06-12 15:16:27.104835
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # only test if IPyhton/Jupyter is installed
    if IPY:
        # test init
        t = tqdm_notebook(total=1, desc='test', disable=False)
        t = tqdm_notebook(total=1, desc='test', disable=True)
        t = tqdm_notebook(total=1, desc='test')
        # test display
        t.display()
        t.display(bar_style='success')
        t.display(bar_style='danger')
        t.display(close=True)
        t.display(msg="test")
        t.display(msg="test", bar_style='warning')
        # test close and __iter__
        t = tqdm_notebook(total=2, desc='test', disable=False)

# Generated at 2022-06-12 15:16:37.094676
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import sys
    from io import StringIO
    # redirect stdout to StringIO instance
    orig_stdout, sys.stdout = sys.stdout, StringIO()

    # from tqdm.notebook import tqdm
    # from time import sleep
    # for _ in tqdm(range(10)):
    #     sleep(0.1)

    # Restore stdout
    sys.stdout = orig_stdout
    pbar = eval(sys.stdout.getvalue().strip())

    # Assert that we can get the default pretty representation
    pbar.__repr__(pretty=True)
    # Assert that we can get the JSON pretty representation
    pbar._repr_json_(pretty=True)
    # Assert that we can get the JSON non-pretty representation

# Generated at 2022-06-12 15:16:43.606349
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from tkinter import Tk
        from tkinter.messagebox import showinfo
    except ImportError:
        from Tkinter import Tk
        from tkMessageBox import showinfo
    from time import sleep

    root = Tk()

    def test():
        for i in tqdm_notebook(range(10)):
            sleep(0.1)
    root.after(100, test)
    root.after(2000, lambda: showinfo('Tk', 'ok'))
    root.mainloop()


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:16:54.108395
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test method `status_printer` of class `tqdm_notebook`.
    """
    # simple
    assert str(tqdm_notebook.status_printer(None, None)) == '\n'
    assert str(tqdm_notebook.status_printer(None, 10))  == '10it [00:00, ?it/s]\n'
    assert str(tqdm_notebook.status_printer('foo', None)) == 'foo:   0%|          | 0/?? [00:00?s]'

    # more
    assert str(tqdm_notebook.status_printer(None, 10, "test")) == 'test:  10it [00:00, ?it/s]\n'

# Generated at 2022-06-12 15:16:57.445537
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=3) as pbar:
        for i in pbar:
            pass

test_tqdm_notebook___iter__()


# Generated at 2022-06-12 15:17:12.063879
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .tests import _test_reset
    _test_reset(tqdm_notebook)

# Generated at 2022-06-12 15:17:17.879608
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from os import getpid
    progress = tqdm_notebook(total=100)
    for k in range(100):
        progress.set_postfix(OrderedDict(pid=getpid(), k=k))
        progress.update(1)
        if k % 5 == 4:  # print every 5th iteration
            progress.ncols = (progress.n + k + 1) % 100  # change bar width
            progress.refresh()
            sleep(0.01)


# Unit test
if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:17:27.517810
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests the `tqdm_notebook` method `status_printer` using all possible
    configurations.
    """
    desc = "description of the progress bar"
    ncols = "100%"
    total = 250

    # Test with total bar
    widget = tqdm_notebook.status_printer(sys.stdout, total, desc, ncols)

    # Test with info bar
    widget = tqdm_notebook.status_printer(sys.stdout, total=None, desc=None)
    widget = tqdm_notebook.status_printer(sys.stdout, total=None, desc=desc)
    widget = tqdm_notebook.status_printer(sys.stdout, total=None, desc=None, ncols=ncols)
    widget = t

# Generated at 2022-06-12 15:17:32.424057
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test tqdm_notebook()
    with tqdm_notebook(total=5) as t:
        for i in t:  # should be already closed
            raise ValueError
    # Test tnrange()
    with tnrange(5) as t:
        for i in t:  # should be already closed
            raise ValueError


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:17:40.886430
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm

    if IPY not in [2, 3, 4]:
        raise SkipTest

    try:
        from IPython.display import clear_output
    except ImportError:
        raise SkipTest

    with tqdm(total=2) as bar:
        # bar.update()
        # assert str(bar.container) == '[|-+-+-|-]'

        # update with msg
        bar.display('coloured...', bar_style='success')
        assert bar.colour == '#00ff00'

        # update with msg
        bar.display('danger...', bar_style='danger')
        assert bar.colour == '#ff0000'

        # Hides bar on update
        bar.display(bar_style='danger', close=True)
        assert bar.container.visible is False

        # raise exception

# Generated at 2022-06-12 15:17:50.978539
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=100)
    for i in t:
        t.display()
        if i == 2:
            t.display(msg='{}/{}'.format(t.n, t.total))
        if i == 10:
            t.display('Hello world!')
        if i == 20:
            t.display(desc='Informative message')
        if i == 30:
            t.display(pos=300)
        if i == 70:
            t.display(bar_style='danger')
        if i == 80:
            t.display(bar_style='success')
        if i == 90:
            t.display(close=True)


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:17:56.846920
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from IPython.display import display
    from IPython.core.display import HTML
    from .std import tqdm

    with tqdm(1) as pbar:
        display(pbar.container)  # to be sure to be in Jupyter
        pbar.set_description("First desc")
        f = pbar.container._repr_pretty_
        assert isinstance(f(None), str)
        f = pbar.container._repr_json_
        assert isinstance(f(None), HTML)



# Generated at 2022-06-12 15:18:03.708091
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tq = tqdm_notebook(total=None)
    tq.container = tqdm_notebook.status_printer(tq.fp, tq.total, tq.desc, 100)
    ltext, pbar, rtext = tq.container.children

    assert 'width' not in pbar.layout.keys()
    assert tq.ncols is None

    tq = tqdm_notebook(total=None, ncols=300)
    tq.container = tqdm_notebook.status_printer(tq.fp, tq.total, tq.desc, tq.ncols)
    ltext, pbar, rtext = tq.container.children

    assert 'width' not in pbar.layout.keys()

# Generated at 2022-06-12 15:18:08.913502
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        with tqdm_notebook(total=1) as pbar:
            pbar.total = 2
            raise ValueError()
    except ValueError:
        pass
    finally:
        try:
            assert pbar.n == 0
            assert pbar.total == 2
            assert pbar.container.children[1].max == 2
        finally:
            pbar.close()



# Generated at 2022-06-12 15:18:18.336410
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    check_total = 42
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    try:
        # only import ipywidgets if it's actually needed
        from ipywidgets import FloatProgress as IProgress
    except ImportError:  # pragma: no cover
        IProgress = None

    methods = ('update', 'display', 'close', 'reset')
    with MagicMock() as mock_ipy:
        mock_ipy_list = []
        for method in methods:
            method_mock = getattr(mock_ipy, method)
            method_mock.side_effect = lambda *a, **k: None
            mock_ipy_list.append(method_mock)
        mock_ipy

# Generated at 2022-06-12 15:18:58.646952
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Check if the `close` signal works
    # Don't display the widget, to avoid interfering with other tests
    t = tqdm_notebook([], gui=False)
    t.disp(close=True)
    assert not t.displayed

    # Check if the `msg` signal works
    # Don't display the widget, to avoid interfering with other tests
    t = tqdm_notebook([], gui=False)
    t.disp('hello')
    assert t.displayed
    assert t.container.children[-1].value == 'hello'

    # Check if the `danger` style works
    # Don't display the widget, to avoid interfering with other tests
    t = tqdm_notebook([], gui=False)
    t.disp(bar_style='danger')

# Generated at 2022-06-12 15:19:01.355657
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            time.sleep(0.1)
            t.update()



# Generated at 2022-06-12 15:19:10.710212
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .std import TestCase

    class tqdm_test(tqdm_notebook):
        def __init__(self):
            super(tqdm_test, self).__init__(disable=True)

    tt = tqdm_test()
    container = tt.status_printer(file=None)
    assert isinstance(container, TqdmHBox)
    ltext, pbar, rtext = container.children
    assert isinstance(ltext, HTML)
    assert isinstance(rtext, HTML)
    assert isinstance(pbar, IProgress)


if __name__ == "__main__":
    from .std import _test_argv
    _test_argv(__doc__)

# Generated at 2022-06-12 15:19:13.357290
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import random
    from time import sleep

    for _ in tqdm_notebook(range(3)):
        assert random() < .5
        sleep(0.01)



# Generated at 2022-06-12 15:19:21.297001
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=2) as bar:
        assert bar.desc is None
        assert bar.total == 2
        assert bar.ncols is None

        bar.reset(total=4, desc='new desc')
        assert bar.desc == 'new desc'
        assert bar.total == 4
        assert bar.ncols is None  # unchanged

        bar.reset(total=None, ncols=100)
        assert bar.desc == 'new desc'
        assert bar.total is None
        assert bar.ncols == 100

        bar.reset(desc='final desc')
        assert bar.desc == 'final desc'
        assert bar.total is None
        assert bar.ncols == 100

        bar.reset()
        assert bar.desc == 'final desc'
        assert bar.total is None

# Generated at 2022-06-12 15:19:24.858094
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test for method `__iter__` of class `tqdm_notebook`
    """
    from .tests import TestBasic

    from .std import tqdm as std_tqdm

    TestBasic.test_tqdm___iter__(tqdm_notebook)
    with std_tqdm() as t:
        t.write("OK")



# Generated at 2022-06-12 15:19:31.235569
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    import sys
    t = tqdm_notebook(total=10)
    for i in range(3):
        for j in t:
            time.sleep(.1)
        t.reset(total=4)  # t.total = 4
        for j in t:
            time.sleep(.1)
        t.reset()  # t.total = 10
        for j in t:
            time.sleep(.1)
    # Try tqdm without total
    for i in tqdm_notebook(range(1), leave=True):
        time.sleep(0.5)
    from tqdm.autonotebook import tnrange
    t = tnrange(10)
    for i in range(3):
        for j in t:
            time.sleep(.1)


# Generated at 2022-06-12 15:19:33.109705
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update()


# Generated at 2022-06-12 15:19:37.501047
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=3) as pbar:
        assert sys.stdout.isatty()
        assert not sys.stderr.isatty()
        pbar.n = 1
        pbar.display()
        pbar.n = 2
        pbar.display()
        pbar.n = 3
        pbar.display()

if __name__ == "__main__":
    with tqdm_notebook(total=3) as pbar:
        pbar.n = 1
        pbar.display()
        pbar.n = 2
        pbar.display()
        pbar.n = 3
        pbar.display()

# Generated at 2022-06-12 15:19:46.202849
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    import numpy as np
    from inspect import signature
    from .gui import tqdm as _tqdm
    def bar(total_iteration, reset_after_iteration):
        # Test that reset after manual iteration works
        with _tqdm(total=total_iteration) as pbar:
            for i in range(total_iteration):
                if i == reset_after_iteration:
                    pbar.reset(total=0)
                pbar.update()
            pbar.reset()
            pbar.reset(total=3, desc='new bar', leave=True)
            pbar.update(1)
            sleep(0.01)

    sig = signature(bar)
    # exhaustive testing!