

# Generated at 2022-06-12 15:13:44.409347
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # mock some ipython methods
    class display:
        @staticmethod
        def __init__(*args, **kwargs):
            pass

        @staticmethod
        def __call__(*args, **kwargs):
            pass

    class widgets:
        @staticmethod
        def IntProgress():
            class IntProgress:
                @staticmethod
                def __init__(*args, **kwargs):
                    pass

                @staticmethod
                def __setattr__(*args, **kwargs):
                    pass

                @staticmethod
                def layout(*args, **kwargs):
                    pass

                @staticmethod
                def style(*args, **kwargs):
                    pass

            return IntProgress()


# Generated at 2022-06-12 15:13:49.323602
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from random import random

    for _ in tqdm_notebook(range(5)):
        _ = random()  # noqa: F841
        for _ in tqdm_notebook(range(5)):
            _ = random()  # noqa: F841
            tqdm_notebook().display(close=True)


# Generated at 2022-06-12 15:13:57.442180
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    import time
    total = 5
    with tqdm(total=total, leave=True) as pbar:
        for n in range(total):
            time.sleep(0.01)
            pbar.update(n)
    # reset with new total
    new_total = 10
    with tqdm(total=new_total, leave=True) as pbar:
        for new_n in range(new_total):
            time.sleep(0.01)
            pbar.update(new_n)
    # reset keeping old total
    with tqdm(leave=True) as pbar:
        for new_n in range(total):
            time.sleep(0.01)
            pbar.update(new_n)

# Generated at 2022-06-12 15:14:05.778596
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from unittest import TestCase
    from tqdm._utils import _term_move_up
    from tqdm.autonotebook import tqdm

    for i in trange(100, desc="Test"):
        pass

    # check html display
    from IPython.core.display import HTML
    from IPython.core.display import display

    display(HTML("<h1>HTML display</h1>"))
    display(HTML("<table><tr><td><b>Hello!</b></td></tr></table>"))

    # check html escape
    display(HTML("<h1>HTML escape</h1>"))
    display(HTML("<table><tr><td><b>Test &</b></td></tr></table>"))

    # check <bar/>

# Generated at 2022-06-12 15:14:11.850009
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm.auto import tqdm as tqdm_auto
    from tqdm import tqdm as tqdm_normal

    def move_up(n=1):
        print('\x1b[{}A'.format(n), end='')

    for cls in (tqdm_normal, tqdm_auto, tqdm_notebook):
        if cls is None:
            continue

        try:  # catch ^C in manual mode
            # test no err
            with cls(total=1) as pbar:
                pass
            assert pbar.disable is False
            move_up()
            print('ok')
            # test err
            with cls(total=1) as pbar:
                raise Exception
        except:  # NOQA
            pass

# Generated at 2022-06-12 15:14:22.242465
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from nose.tools import assert_equal, assert_is_not_none
    from nose.tools import assert_is_instance

    # Test 1
    ncols = 100
    desc = "Test1"
    total = 100
    hb = tqdm_notebook.status_printer(None, total, desc, ncols)
    assert_is_not_none(hb)
    assert_is_instance(hb, TqdmHBox)
    assert_equal(len(hb.children), 3)
    assert_is_instance(hb.children[0], HTML)
    assert_is_instance(hb.children[1], IProgress)
    assert_is_instance(hb.children[2], HTML)
    assert_equal(hb.children[0].value, desc)
    assert_

# Generated at 2022-06-12 15:14:30.716992
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from ipywidgets import HTML

    if IPY <= 0 or IPY == 2:
        return  # Jupyter unavailable or not tested for IPY=2

    # Test display
    tqdm_notebook.display(None, None, close=True, bar_style=None)
    tqdm_notebook.display(None, None, close=False, bar_style='info')
    tqdm_notebook.display(None, None, close=False, bar_style='warning')
    tqdm_notebook.display(None, None, close=False, bar_style='success')
    tqdm_notebook.display(None, None, close=False, bar_style='danger')


# Generated at 2022-06-12 15:14:39.349295
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test that tqdm_notebook.status_printer behaves as expected.
    """
    # Import TqdmTypeError to avoid circular dependency
    from .std import TqdmTypeError
    import types

    tqdm_notebook.status_printer(None, total=20, desc='desc', ncols=100)
    assert tqdm_notebook.status_printer(None, total=20, desc='desc')
    # Make sure that tqdm_notebook.status_printer does not throw an
    # exception with different parameters
    assert tqdm_notebook.status_printer(None, total=2, desc='desc')
    assert tqdm_notebook.status_printer(None, total=20, desc='desc')
    assert tqdm_notebook.status_printer

# Generated at 2022-06-12 15:14:43.394241
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test for the method `tqdm_notebook.__iter__`
    """
    from ._utils_test import _test_tqdm_iter

    _test_tqdm_iter(_tqdm=tqdm_notebook)



# Generated at 2022-06-12 15:14:49.188844
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as t:
        t.display("test", bar_style="success", check_delay=False)
        t.clear()
        assert t.container.children[1].bar_style == ""
        t.display("test", bar_style="success", check_delay=False)


if __name__ == '__main__':
    from ._tqdm import _test_short_repr, _test_iter_len
    _test_short_repr(tqdm_notebook)
    _test_iter_len(tqdm_notebook)
    test_tqdm_notebook_clear()

# Generated at 2022-06-12 15:15:09.241526
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test of method status_printer of class tqdm_notebook
    """
    # import external modules
    import sys
    # import standard modules
    from json import loads, dumps
    # get instance of class tqdm_notebook
    tqdm_notebook_instance = tqdm_notebook(total=1000, disable=False)
    # get default output of method status_printer
    status_printer_default_output = tqdm_notebook_instance.status_printer(file=sys.stdout, total=1000)
    # get pretty-print output of method status_printer
    status_printer_pretty_output = tqdm_notebook_instance.status_printer(file=sys.stdout, total=1000)
    # compare the default pretty-print output of method status_printer

# Generated at 2022-06-12 15:15:13.696056
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tqdm_notebook(total=10)
    for i in pbar:
        pbar.reset()
    pbar.reset(50)
    for i in pbar:
        pbar.reset()
    pbar.reset(100)
    for i in pbar:
        pbar.reset()

# Generated at 2022-06-12 15:15:20.276578
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import nose.tools as nt
    # test tqdm_notebook.reset()
    t = tqdm_notebook(total=5)
    t.update(5)
    try:
        t.reset(total=10)
        t.update(5)
        t.close()
        # this should raise an exception if an error occurred
        # during the reset method
        assert t._instantaneous_rate == 50  # check rate
    except:
        raise nose.SkipTest


# Generated at 2022-06-12 15:15:24.139036
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    bar = tqdm_notebook.status_printer(None, 42, "title")
    assert bar.children[0].value == "title"
    assert bar.children[1].max == 42
    assert bar.children[2].value == ""

# Generated at 2022-06-12 15:15:34.474004
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from IPython.display import display, clear_output

    display(tqdm_notebook(["a", "b", "c", "d"]))
    sleep(1)
    display(tqdm_notebook("xyz"))
    sleep(1)
    try:
        for t in tqdm_notebook([]):
            sleep(0.5)
    except KeyboardInterrupt:
        pass
    t = tqdm_notebook("xyz")
    sleep(1)
    t.close()
    sleep(1)
    clear_output()

if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:15:42.339656
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .gui import tqdm as tqdm_gui
    from .utils import _range

    for cls in [tqdm_notebook, tqdm_gui]:
        for display in [False, True]:
            for desc in [None, '', 'desc', '<desc>']:
                for ncols in [None, '10', '100px', '100%']:

                    # Initialize
                    t = cls(total=5, desc=desc, ncols=ncols,
                            leave=False, disable=display)
                    t.displayed = False
                    # Click and check message
                    for i in _range(5):
                        msg = t._format_meter(desc=desc, ncols=ncols)

# Generated at 2022-06-12 15:15:44.291526
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=2) as t:
        t.update()
        t.close()
    pass

# Generated at 2022-06-12 15:15:53.583337
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest.case import TestCase
    from unittest import mock

    class TestTqdmNotebook(TestCase):
        def setUp(self):
            self.t = tqdm_notebook(total=10)

        def tearDown(self):
            self.t.close()
        # @patch('IPython.display.display')
        # def test_first_display(self, mock_display):
        #     self.t.display(check_delay=True)
        #     self.assertTrue(mock_display.called)
        # @patch('IPython.display.display')
        # def test_first_display_not_called(self, mock_display):
        #     self.t.display(check_delay=False)
        #     self.assertFalse(mock_display.called)


# Generated at 2022-06-12 15:15:57.071355
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=None, leave=True, ncols=3000) as t:
        for i in range(1, 5):
            t.reset(total=i + 1)
            for j in range(i):
                t.update()
    assert t.n == i



# Generated at 2022-06-12 15:16:04.390794
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for leave in [None, True, False]:
        for manual in [None, True, False]:
            for unit_scale in [None, True, False, 2]:
                for total in [None, 50, 100]:
                    for init in [4, 25]:
                        for finish in [4, 26]:
                            for desc in [None, "bar"]:
                                for disable in [None, True, False]:
                                    for unit in [None, 'blocks']:
                                        kwargs = {'leave': leave,
                                                  'manual': manual,
                                                  'unit_scale': unit_scale,
                                                  'total': total,
                                                  'unit': unit,
                                                  'disable': disable}

# Generated at 2022-06-12 15:16:36.850811
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Do not use test_tqdm_notebook_status_printer as a name,
    # it will hide the tqdm method with the same name
    # NB: test with IPython notebook must be done outside of the unittest

    # Test without total
    # t = tqdm_notebook()
    # Test with total
    t = tqdm_notebook(total=10, ncols=0)
    assert t.container is not None
    assert t.container.children
    assert isinstance(t.container.children[0], HTML)
    assert isinstance(t.container.children[1], IProgress)
    assert isinstance(t.container.children[2], HTML)

    assert t.container.children[1].value == 0
    assert t.container.children[1].min == 0
    assert t

# Generated at 2022-06-12 15:16:38.895280
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(range(3), leave=True) as t:
        raise StopIteration
        t.update()

# Generated at 2022-06-12 15:16:45.813103
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        import unittest as ut
    except ImportError:
        import unittest2 as ut
    import subprocess as sp
    import tempfile as tf
    import os
    from contextlib import contextmanager
    from .utils import _range

    @contextmanager
    def python_in_temp_source_file(source):
        t = tf.NamedTemporaryFile(suffix='.py', delete=False)
        t.write(source.encode('utf-8'))
        t.close()
        try:
            yield t.name
        finally:
            os.remove(t.name)

    class TestTqdmHBox(ut.TestCase):
        def test_pretty_pprint(self):
            """Test TqdmHBox.__repr__()"""

# Generated at 2022-06-12 15:16:56.861959
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test tqdm_notebook method reset."""
    with tqdm_notebook(total=100) as bar:
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)
        bar.reset(total=100)

# Generated at 2022-06-12 15:16:59.358552
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for _ in tqdm_notebook(range(100), total=100):
        pass
    for _ in tqdm_notebook(range(100), total=100):
        pass

# Generated at 2022-06-12 15:17:00.686471
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    tqdm_notebook().display()

# Generated at 2022-06-12 15:17:07.368045
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase
    from time import sleep

    class TqdmNotebookDisplayTest(TestCase):

        def test_display_stdout(self):
            out = sys.stdout
            try:
                from cStringIO import StringIO
            except ImportError:
                from io import StringIO
            with tqdm_notebook(total=10, file=StringIO()) as t:
                t.display(0, pos=0, total=10)
                t.display(1, pos=1, total=10, bar_style='success')
                output = t.display(close=True, bar_style='danger')
                self.assertEqual(output, None)
                # test the use of fp=out
                t.display(0, pos=0, total=10, fp=out)
                t

# Generated at 2022-06-12 15:17:09.941122
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # function from test_tqdm
    from .gui import test_tqdm_clear
    return test_tqdm_clear(tqdm)


if __name__ == '__main__':
    import nose
    nose.runmodule(argv=['-s', '--with-doctest'], exit=False)

# Generated at 2022-06-12 15:17:17.310081
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import tqdm
    for leave in (None, False, True):
        for dynamic_ncols in (None, False, True):
            ncols = 100 if dynamic_ncols else None
            with tqdm_notebook(total=10, leave=leave, dynamic_ncols=dynamic_ncols, ncols=ncols) as t:
                assert t.n == 0
                assert t.last_print_n == 0
                assert t.last_print_t == 0
                assert t.leave == bool(leave)
                assert t.container == t.container
                assert t.container.children[1].style.bar_color == ''
                for i in t:
                    assert t.n == i + 1

# Generated at 2022-06-12 15:17:25.062569
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import naturalsize
    import math

    # Initialize tqdm
    with tqdm_notebook(_range(10)) as bar:
        # Loop over the bar
        for i in bar:
            # Check format
            assert math.isnan(float(bar.format_dict['rate'])), \
                "rate must be NaN in unknown iteration"
            assert naturalsize(i) in bar.format_dict['bar'], \
                "iteration not found"
            # Check style
            if i % 2 == 0:
                bar.bar_style = 'danger'
            else:
                bar.bar_style = 'success'

# Generated at 2022-06-12 15:18:23.369959
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

    with open('/dev/null', 'w') as fd:
        for j in range(1, 5):
            for i in tqdm(range(20), file=fd):
                # Compute stuff
                sleep(j / 200)
            for i in tqdm(range(20), file=fd):
                # Compute other stuff
                sleep(j / 200)
                if i == 10:
                    raise KeyboardInterrupt
            for i in tqdm(range(10), file=fd,
                          leave=False,
                          position=1 + (j % 2),
                          bar_format="{desc}: {percentage:3.0f}%|{bar}|"):
                # Compute yet other stuff
                sleep(j / 200)


# Generated at 2022-06-12 15:18:26.684349
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            sleep(0.1)
            pbar.update(10)


if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:18:32.653082
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit tests for method `tqdm_notebook.display`.
    """
    from io import StringIO
    from contextlib import contextmanager

    from .utils import _term_move_up
    from .utils import format_sizeof
    from .utils import format_interval
    from .utils import format_speeddata
    from .main import Bar

    @contextmanager
    def stdout_state(sio):
        """Helper context manager to redirect stdout"""
        with sio, std_tqdm.stdout(sio):
            yield

    # Test parametrization and config

# Generated at 2022-06-12 15:18:41.305214
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Initialize and update bar
    b = tqdm_notebook()

# Generated at 2022-06-12 15:18:45.860729
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10, disable=False) as pbar:
        pbar.update()
    assert pbar.n == 1
    with tqdm_notebook(total=10, disable=False) as pbar:
        pbar.update(2)
    assert pbar.n == 2
    with tqdm_notebook(total=10, disable=False) as pbar:
        pbar.update(2)
        assert pbar.n == 2
        pbar.update(4)
    assert pbar.n == 5



# Generated at 2022-06-12 15:18:47.560394
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from IPython.display import clear_output

    with tqdm_notebook(total=None) as t:
        for i in _range(1000):
            t.update()
        clear_output()

# Generated at 2022-06-12 15:18:55.844520
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox(children=[HTML("ltext"), IProgress(), HTML("rtext")])
    hbox.pbar = hbox.children[1]
    hbox.pbar.value = 2
    hbox.pbar.bar_style = "info"
    hbox.pbar.layout.width = "20px"
    assert hbox.__repr__(pretty=True) == "ltext<bar/>rtext"
    assert hbox.__repr__(pretty=False) == "ltext|<bar/>|rtext"
    hbox.pbar.bar_style = "success"
    assert hbox.__repr__(pretty=True) == "ltext{bar}rtext"

# Generated at 2022-06-12 15:19:00.273773
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=3)
    assert t.displayed

    t.update(2)
    t.display()

    t.display(bar_style='danger')

    t.close()

if __name__ == '__main__':  # pragma: no cover
    from pytest import main
    main(['-xrs', __file__.replace('.pyc', '.py')])

# Generated at 2022-06-12 15:19:10.038290
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import _tqdm_notebook
    # first run to create the container
    with _tqdm_notebook(total=1) as t:
        # second run with total changed and doing some iteration
        with t.reset(total=2) as t:
            assert t.total == 2
            t.update()
            assert t.n == 1
        # third run, n should be reset to 0
        with t.reset():
            assert t.total == 2
            assert t.n == 0
    # fourth run, total should be reset to unknown
    with t.reset() as t:
        assert t.total is None
        assert t.n == 0
        t.total = 2
        assert t.total == 2
        t.update()
        assert t.n == 1

# Generated at 2022-06-12 15:19:18.656742
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.std import TqdmTypeError, TqdmKeyError

    t = tqdm_notebook()

    # Test case: empty bar
    t.display(msg='')
    # Test case: empty bar with closing signal
    t.display(msg='', close=True)
    # Test case: bar with message
    t.display(msg='test')
    # Test case: bar with progress
    t.display(msg='test', pos=1)
    # Test case: bar with progress and changing style
    t.display(msg='test', pos=2, bar_style='info')

    # Test case: error bar
    try:
        raise TqdmTypeError
    except TqdmTypeError:
        t.display(bar_style='danger')

    # Test case: error and closing bar
   

# Generated at 2022-06-12 15:21:00.699193
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests `tqdm_notebook.status_printer`
    """
    # pylint: disable=protected-access
    widg = tqdm_notebook.status_printer(sys.stdout)

    assert len(widg.children) == 3
    # Remove children
    widg.children = []
    assert len(widg.children) == 0

    widg = tqdm_notebook.status_printer(sys.stdout, total=100, desc="Test")
    assert len(widg.children) == 3
    # Remove children
    widg.children = []
    assert len(widg.children) == 0
    # pylint: enable=protected-access

test_tqdm_notebook_status_printer()


# Generated at 2022-06-12 15:21:07.747840
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook().close()
    tqdm_notebook(1).close()
    tqdm_notebook(total=1).close()
    t = tqdm_notebook(bar_format="{l_bar}{bar}{r_bar}")
    t.close()
    t = tqdm_notebook(bar_format="{l_bar}{bar}{r_bar}", leave=True)
    t.close()
    with tqdm_notebook(1, leave=True) as t:
        pass
    with tqdm_notebook(1, leave=True) as t:
        raise ValueError()

# Generated at 2022-06-12 15:21:10.308202
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.auto import trange
    from contextlib import ExitStack as does_not_raise
    for i in trange(4):
        with does_not_raise():
            sleep(0.5)
        trange.update(1)

# Generated at 2022-06-12 15:21:16.337107
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    import difflib
    output = []
    with open(__file__, 'r') as f:
        lines = f.readlines()
        if 'Py3' in sys.version:
            lines.append('except ImportError:\n')

    def myprint(*args):
        output.append(' '.join(args) + '\n')

    def myflush(*args):
        pass

    def myclose(*args):
        pass

    with tqdm(total=20, file=DummyTqdmFile(on_close=myclose, on_flush=myflush),
              disable=True) as t:
        t.status_printer(myprint)  # should print out 20 dots
        t.status_printer(myprint, total=5)  # should print out 5 dots
        t.status_pr

# Generated at 2022-06-12 15:21:20.152294
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Returns
    -------
    container : TqdmHBox to check for total=None
        Used for testing.
    """
    container = tqdm_notebook.status_printer(None, None, None)
    return container

del std_tqdm

# Generated at 2022-06-12 15:21:29.611142
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from os import devnull
    from sys import stderr
    from time import sleep
    with open(devnull, 'w') as f:
        t = tqdm_notebook(total=10, file=f, leave=True)
        for i in t:
            pass
        assert t.container.pbar.bar_style == 'success'
    with open(devnull, 'w') as f:
        t = tqdm_notebook(total=10, file=f, leave=True, position=1)
        for i in t:
            pass
        assert t.container.pbar.bar_style == 'success'
    with open(devnull, 'w') as f:
        t = tqdm_notebook(total=10, file=f, leave=True, dynamic_ncols=True)
       

# Generated at 2022-06-12 15:21:34.426536
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for _t in tqdm(range(2)):
        t = tqdm(range(4), leave=False)
        for _ in t:
            if t.n == 2:
                t.reset()

    t = tqdm(range(4), leave=False)
    for _ in t:
        if t.n == 2:
            t.reset()
            t.close()


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:21:45.263523
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Setup dummy environment
    # import IPython.html.widgets
    # ipywidgets = IPython.html.widgets  # NOQA
    # import IPython.display
    # display = IPython.display.display  # NOQA

    # Create dummy tqdm instance
    t = tqdm_notebook(total=3, postfix="test")

    # Assert progress bar is disabled
    assert not t.disable

    # Assert bar is not printed yet
    assert not t.displayed
    assert t.n == 0

    # Increase progress
    t.update()

    # Assert bar is printed
    assert t.displayed
    assert t.n == 1

    # Once again
    t.update()
    assert t.n == 2

    # Close
    t.close()

    # Assert

# Generated at 2022-06-12 15:21:52.178241
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from sys import executable, argv
    from os import getcwd, chdir
    from os.path import dirname, realpath, join as joinpath, sep as sepchr
    from subprocess import Popen, PIPE, STDOUT
    from time import sleep
    try:
        chdir(dirname(realpath(__file__)))
        with open(joinpath(getcwd(), "test_tqdm_notebook.py"), "r") as f:
            testpy = f.read()
    finally:
        chdir(getcwd())

    # Unit test 1: Test tqdm_notebook() with empty iterable (total=None)

# Generated at 2022-06-12 15:22:02.677181
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # reset on progress bar with total
    t = tqdm_notebook(total=100)
    assert t.total == 100
    assert t.miniters == 1
    t.n = 50
    t.reset(total=50)
    assert t.total == 50
    assert t.miniters == 1
    t.reset(total=25)
    assert t.total == 25
    assert t.miniters == 1
    t.reset(total=0)
    assert t.total == 0
    assert t.miniters == 1
    t.reset(total=None)
    assert t.total is None
    assert t.miniters == 1
    t.close()

    # reset on progress bar without total
    t = tqdm_notebook(total=None)
    assert t.total is None
