

# Generated at 2022-06-12 15:13:50.841716
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test for method `tqdm.notebook.tqdm_notebook.clear`"""
    from unittest import TestCase
    from unittest.mock import patch
    from tqdm.notebook import tqdm_notebook

    container = None

    class Tqdm_notebookTestCase(TestCase):
        """Test cases for `tqdm.notebook.tqdm_notebook` method clear"""

        def test_tqdm_notebook_clear(self):
            """
            Test that method clear() of tqdm_notebook block bar
            """
            global container
            pbar = tqdm_notebook(range(10))
            container = pbar.container

# Generated at 2022-06-12 15:13:59.819103
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    from pprint import pprint
    from json import loads
    # test all possible attributes value

# Generated at 2022-06-12 15:14:01.421100
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm(total=10) as bar:
        bar.clear()
    assert bar.n == 0



# Generated at 2022-06-12 15:14:04.182808
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import trange

    with trange(10) as t:
        for i in t:
            t.set_description("ADVANCING {}".format(i))
            t.update(3)



# Generated at 2022-06-12 15:14:05.653946
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        for _ in range(10):
            pbar.clear()



# Generated at 2022-06-12 15:14:13.092199
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    n = 10
    from time import sleep
    from contextlib import contextmanager
    from tqdm.auto import trange

    # testing exception
    if IPY < 2:
        return

    @contextmanager
    def no_stderr():
        old = sys.stderr
        sys.stderr = open('/dev/null', 'w')
        yield
        sys.stderr = old

    with no_stderr():
        for _ in trange(n, desc='testing exception', bar_format='{l_bar}'):
            sleep(0.1)
            raise Exception()

    # testing KeyboardInterrupt

# Generated at 2022-06-12 15:14:21.061499
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    try:
        for i in tqdm_notebook(range(3), desc="TEST"):
            assert i == 0 or i == 1 or i == 2
            time.sleep(0.1)
    except:  # NOQA
        raise

    try:
        for i in tqdm_notebook(range(3), desc="TEST", leave=True):
            assert i == 0 or i == 1 or i == 2
            time.sleep(0.1)
    except:  # NOQA
        raise



# Generated at 2022-06-12 15:14:23.419568
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    for i in trange(4):
        clear_output(wait=True)
        assert i in range(4)


# Generated at 2022-06-12 15:14:25.759160
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # DEPRECATED -- replaced with a 'info' style bar
    # # Case 1: no total
    # assert tqdm_notebook.status_printer(None) is not None

    # Case 2: total
    assert tqdm_notebook.status_printer(None, total=10) is not None



# Generated at 2022-06-12 15:14:26.767496
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Start the notebook.py
    print("\nNotebook.py:\n")
    notebook_py()



# Generated at 2022-06-12 15:14:46.753009
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    import re
    from IPython.display import display
    total = 100
    k = int(total ** 0.25)
    if k < 1:
        k = 1
    for i in tqdm_notebook(range(total), total=total, ncols=50):
        s = tqdm_notebook.status_printer(sys.stderr, i, total=total,
                                         ncols=50)
        # check progress bar width
        _, pbar = s.children
        assert pbar.max == total
        assert re.match(r"\d+%", pbar.description.strip())



# Generated at 2022-06-12 15:14:49.928775
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
    assert pbar.n == pbar.total
    clear_output()


# Generated at 2022-06-12 15:14:54.452031
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            pbar.update(1)
            pass
        pbar.clear()
        for i in range(100, 200):
            pbar.update(1)
            pass
        pbar.n = 300

# Generated at 2022-06-12 15:14:57.165908
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        iterable = [1, 2, 3]
        with tqdm_notebook(iterable) as t:
            t.clear()
    except Exception:
        raise AssertionError("Test tqdm_notebook clear failed")



# Generated at 2022-06-12 15:15:03.434729
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook.status_printer(None), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, ncols=100), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, 10), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, total=10), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, desc='Test'), TqdmHBox)
    assert isinstance(tqdm_notebook.status_printer(None, 0), TqdmHBox)

# Generated at 2022-06-12 15:15:10.676387
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for n in [1, 2]:
        pbar = tqdm_notebook(total=4, leave=True)
        for i in range(4):
            pbar.update()
            if i == 2:
                pbar.reset(total=8)
            assert pbar.n == i + n
        assert pbar.n == 4


if __name__ == "__main__":
    """
    Usage:
    python tqdm_notebook.py
    or
    python -m tqdm.notebook
    """
    import time

    test_tqdm_notebook_reset()

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            time.sleep(0.2)
            pbar.update(1)

# Generated at 2022-06-12 15:15:21.272352
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import display, clear_output
    from IPython import get_ipython

    ip = get_ipython()
    if ip is not None:
        ip.kernel.do_one_iteration = lambda: None

    # test display_here argument
    t = tqdm_notebook(total=10, desc='display_here')
    t.display()
    clear_output()
    t.display()
    clear_output()
    t.display()
    clear_output()
    t.close()

    # test progress bar style changes
    t = tqdm_notebook(total=10, desc='bar_style')
    t.display()
    t.display(bar_style='success')
    t.display(bar_style='danger')
    t.display(bar_style='info')
   

# Generated at 2022-06-12 15:15:29.430723
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """

# Generated at 2022-06-12 15:15:39.444262
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    from random import random

    total = 10

    # Test total set in reset()
    with tqdm_notebook(total=total) as orig_bar:
        for _ in orig_bar:
            n = int(random()*total + 1)
            orig_bar.reset(total=n)
            for _ in orig_bar:
                pass

    # Test total not set in reset()
    with tqdm_notebook(total=total) as orig_bar:
        for _ in orig_bar:
            orig_bar.reset()
            for _ in orig_bar:
                pass

    # Test total not set in reset(), but set in constructor
    with tqdm_notebook() as orig_bar:
        for _ in orig_bar:
            orig_bar.reset()

# Generated at 2022-06-12 15:15:43.730374
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    main_bar = tqdm_notebook(total=10, desc='Main bar')
    sub_bar = tqdm_notebook(total=20, desc='Sub bar')
    for i in main_bar:
        sub_bar.reset()
        for j in sub_bar:
            time.sleep(0.01)
        time.sleep(0.1)
    main_bar.close()
    sub_bar.close()


if __name__ == '__main__':
    try:
        test_tqdm_notebook_reset()
    finally:
        time.sleep(1)  # leave time for closing bar

# Generated at 2022-06-12 15:16:09.815036
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for _ in tqdm_notebook(range(1), leave=True):
        pass


# Generated at 2022-06-12 15:16:12.514944
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests the method reset of class tqdm_notebook.
    """
    n = 1000
    progressbar = tqdm(total=1000)
    for _ in range(n):
        progressbar.update()
    progressbar.reset()
    if progressbar.n != 0:
        raise Exception('tqdm_notebook.reset() failed')

# Generated at 2022-06-12 15:16:13.802501
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from .gui import tnrange
    from .tests import tests
    t = tnrange(100)
    assert tests._test(t, "clear")

# Generated at 2022-06-12 15:16:19.474990
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import modules
    from time import sleep

    # Mock display
    _display_calls = []

    def mock_display(*args):
        _display_calls.append(args)

    # Mock clear_output
    _clear_output_calls = 0

    def mock_clear_output(*args):
        nonlocal _clear_output_calls
        _clear_output_calls += 1

    modules['IPython.display'] = type(
        "MockIPythonDisplay",
        (object,),
        {'display': mock_display}
    )

    # Mock clear_output
    modules['IPython.display'].clear_output = mock_clear_output

    # Test
    test = tqdm_notebook(desc="Hello", total=4)
    sleep(0.01)  # for tq

# Generated at 2022-06-12 15:16:25.099997
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=9, desc='A', leave=True) as pbar:
        assert repr(pbar) == (
            '  0%|                                                          '
            '| 0/9 [00:00<?, ?it/s]\nA:   0it [00:00, ?it/s]')
        for _ in _range(9):
            pbar.update()
        assert repr(pbar) == (
            '100%|█████████████████████████████████████████████████████| 9/9 '
            '[00:00<00:00, ?it/s]\nA:   9it [00:00, ?it/s]')



# Generated at 2022-06-12 15:16:30.709023
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Unit test for method clear of class tqdm_notebook
    """
    t = tqdm_notebook(total=2)
    t.set_description('Test')
    t.set_postfix(dict(A='X', B='Y'))
    assert t._repr_pretty_(None) is None
    assert t._repr_pretty_(None) is None
    t.update(1)
    t.clear()

# Generated at 2022-06-12 15:16:39.890291
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test the reset method of tqdm_notebook class.

    Usage:
    Import this script (tqdm.notebook) and run:
    >> test_tqdm_notebook_reset()
    """
    from nose.tools import assert_equal

    t = tqdm_notebook(total=10, unit_scale=True)

    t.reset(total=100)
    assert_equal(t.total, 100)
    assert_equal(t.n, 0)
    t.update()
    assert_equal(t.total, 100)
    assert_equal(t.n, 1)

    t.reset(total=10)
    assert_equal(t.total, 10)
    assert_equal(t.n, 0)
    t.update()

# Generated at 2022-06-12 15:16:42.208131
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm(total=5) as pbar:
        for _ in pbar:
            pass
    assert pbar.n == 5
    assert pbar.last_print_n == 5

# Generated at 2022-06-12 15:16:47.745675
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from nose.plugins.skip import SkipTest
    from IPython.display import clear_output
    raise SkipTest("This test doesn't actually test anything but was an "
                   "attempt to fix ipywidgets #873. "
                   "It is succeeded by a similar test by another maintainer "
                   "in `tests/test_notebook_tqdm_bar.py` which also unfortunately "
                   "does not actually test anything.")
    try:
        # noinspection PyUnresolvedReferences
        from ipywidgets import FloatProgress
    except ImportError:
        raise SkipTest("ipywidgets not found")

    pbar = tqdm_notebook(total=2)
    first_displayed_value = pbar.container.children[1]()[0].value

# Generated at 2022-06-12 15:16:58.818205
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from unittest.mock import MagicMock
    except ImportError:
        from mock import MagicMock

    tqdm_notebook.status_printer = MagicMock()
    tqdm_notebook.status_printer().children = ['desc', MagicMock(), 'unit']

    tnrange(10)._instances = []
    for i in tnrange(10):
        assert i == i
    assert tnrange(10)._instances == []

    tnrange(10)._instances = []
    for i in tnrange(10):
        if i == 5:
            raise ValueError
    assert tnrange(10)._instances == []

    tnrange(10)._instances = []

# Generated at 2022-06-12 15:17:31.110871
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook."""
    from datetime import datetime
    from time import sleep
    from .std import time, time_ns
    # In python2.7
    nanos = time_ns if hasattr(time, 'time_ns') else lambda: int(1e9 * time())
    # Unit test for method status_printer of class tqdm_notebook
    try:
        # Check for IPython
        import IPython
        dummy_input, sb, display = IPython.get_ipython().raw_input, IPython.get_ipython().getoutput, IPython.display.display
    except (NameError, AttributeError):
        dummy_input, sb, display = input, lambda x: x, print


# Generated at 2022-06-12 15:17:36.010266
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from IPython.display import clear_output  # NOQA
    except ImportError:
        return None

    t = tqdm_notebook(total=10)
    for _ in t:
        t.update()

    # test reset
    try:
        t.reset(total=3)
    except Exception as e:
        raise e

    return t

# Generated at 2022-06-12 15:17:39.265367
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook

    Checks that no exception is raised in __iter__.
    """
    try:
        for _ in tqdm(range(0)):
            pass
    except:
        assert False, "Exception raised in __iter__"

# Generated at 2022-06-12 15:17:45.115579
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """ Unit test for method update of class tqdm_notebook """
    from .utils import format_sizeof

    # Only way to test is to have an error
    try:
        with tqdm_notebook(total=2) as pbar:
            pbar.update()
            raise Exception
    except Exception:
        pass

    # Test bar style
    with tqdm_notebook(total=2) as pbar:
        pbar.n = 1
        pbar.bar_style = 'info'
        pbar.display()
        pbar.bar_style = 'warning'
        pbar.display()
        pbar.bar_style = 'danger'
        pbar.display()
        pbar.bar_style = 'success'
        pbar.display()

    # Test bar format

# Generated at 2022-06-12 15:17:50.589270
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test reset without any change
    with tqdm_notebook(total=100) as t:
        assert t.container.children[1].max == 100
        t.reset()
        assert t.container.children[1].max == 100

    # Test reset with a new total
    with tqdm_notebook(total=100) as t:
        assert t.container.children[1].max == 100
        t.reset(total=50)
        assert t.container.children[1].max == 50

    # Test reset with an unknown total width
    with tqdm_notebook() as t:
        assert t.container.children[1].max == 1
        assert t.container.layout.width == '20px'  # default width for unknown total
        t.reset()
        assert t.container.children[1].max

# Generated at 2022-06-12 15:17:58.830585
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from time import sleep
    from tqdm.utils import get_ipython

    ip = get_ipython()
    if not ip:  # pragma: no cover
        print("Cannot test tqdm_notebook inside non-Ipython env.")
        return

    tqdm_notebook.clear()

    with tqdm_notebook(total=40) as t:
        for i in range(40):
            t.set_description("Desc: %d" % i)
            t.set_postfix(OrderedDict(loss=0.1 * i + 0.05,
                                      acc="%.2f" % (0.1 * i + 0.05)))
            sleep(0.1)
            t.update()

    tqdm_notebook.clear()

# Generated at 2022-06-12 15:18:05.106054
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    This method tests the `tqdm_notebook.status_printer` method
    It does so by instantiating a `tqdm_notebook.tqdm_notebook.TqdmHBox()`
    and a `TqdmHBox()` without description and tries to match the output.
    It also tries to set the progressbar to one, which changes the whole output
    and checks whether that is correct as well.
    This method assumes that the tqdm progressbar is correct. So an error here
    could be a bug in the `tqdm_notebook.tqdm_notebook.TqdmHBox()` or the
    `tqdm_notebook.tqdm_notebook.status_printer` methods.
    """
    from unittest import TestCase
    import re


# Generated at 2022-06-12 15:18:07.171281
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test if iterating on `tqdm_notebook(range(0))` doesn't raise any error
    for _ in tqdm(range(0)):
        pass

# Generated at 2022-06-12 15:18:17.310371
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm
    from time import sleep
    from sys import version as sys_version
    from subprocess import Popen, PIPE, call
    if call(['python', '-c', 'import ipywidgets']) == 0:
        skip = False
    elif sys_version.startswith("3"):
        skip = True
    elif call(['pip', 'show', 'ipywidgets']) == 0:
        skip = False
    else:
        skip = True
    if skip:
        return


# Generated at 2022-06-12 15:18:25.808425
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .version import __version__
    from .autonotebook import tqdm as std_tqdm
    from .tqdm import trange, tqdm
    from .utils import ensure_tqdm
    from .std import TqdmKeyError, TqdmTypeError, TqdmDeprecationWarning, TqdmExperimentalWarning

    with ensure_tqdm(tqdm_notebook) as t:
        assert isinstance(t, tqdm_notebook)
        assert t.gui

        with pytest.raises(TqdmKeyError):
            list(t.update(n=1, total=-1))

        with pytest.raises(TqdmTypeError):
            list(t.update(n=1, miniters='2'))


# Generated at 2022-06-12 15:19:16.717325
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    t = tqdm_notebook(3)
    t.update()
    t.update(2)
    t.close()
    # Test dark mode
    from os import getenv
    if getenv('TRAVIS_PYTHON_VERSION') or getenv('GITHUB_ACTIONS'):
        return
    t = tqdm_notebook(3, colour='dark')
    t.update()
    t.update(2)
    t.close()



# Generated at 2022-06-12 15:19:21.879409
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from numpy.random import random
    with tqdm_notebook(total=10) as t:
        for i in range(11):
            sleep(0.1)
            t.set_description("test %i" % (i))
            t.update()
    assert t.n == 11
    with tqdm_notebook(random((20, 20)), desc="test2") as t:
        for _ in t:
            sleep(0.01)
    assert t.n == 400

# Generated at 2022-06-12 15:19:24.347764
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from IPython import get_ipython
    get_ipython().system("jupyter nbconvert --to python --stdout tqdm_notebook.ipynb")
test_tqdm_notebook()

# Generated at 2022-06-12 15:19:26.757141
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test tqdm_notebook constructor"""
    with tqdm_notebook(total=10) as t:
        for i in t:
            assert t.n == i + 1, "values t.n and i are not equal"

# Generated at 2022-06-12 15:19:33.248522
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from tqdm import __version__
    from sys import version
    from os import name
    from traceback import format_exc

    def _decode_unicode(string):
        """Decode unicode string for Python2/3 compatibility"""
        if hasattr(string, 'decode'):  # unicode string
            return string.decode('utf-8')
        return string

    # test_dict = {
    #     "l_bar": '',
    #     "r_bar":
    #     '  9%|████████▏                                                           | 20/218 [00:00<00:02, 166.81it/s]',
    #     "n": 20,
    #     "total": 218,
    #     "bar_format": '{l_bar}{bar}{r_

# Generated at 2022-06-12 15:19:36.681511
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    try:
        from ipywidgets import FloatProgress
    except ImportError:
        return  # skip if no ipywidgets

    try:
        import ipywidgets as widgets
    except ImportError:
        widgets = None

    if widgets:
        import time

        iterable = range(100)

        progress = tqdm_notebook(iterable, miniters=1, leave=False)

        for i in progress:
            # Do some work
            pass



# Generated at 2022-06-12 15:19:42.153464
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # test tqdm_notebook update method with disable=True
    with tqdm_notebook(total=1, disable=True) as T:
        assert not T.displayed
        T.update()
        assert not T.displayed

    with tqdm_notebook(total=1, disable=False) as T:
        assert not T.displayed
        T.update()
        assert T.displayed
        assert T.n == 1
        T.container.remove()



# Generated at 2022-06-12 15:19:50.263424
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Need to run "jupyter notebook" to start the notebook server first
    # Then you can run the unittest in Jupyter Notebook or Jupyter QtConsole.
    from IPython import get_ipython
    from ipykernel.comm import Comm
    from time import sleep

    comm = Comm(target_name='tqdm_test')

    def tqdm_test(comm):
        for msg in tqdm(['msg%d' % x for x in range(5)], desc='Test', ncols=50):
            comm.send(msg)
            sleep(0.01)

    if get_ipython() is not None:
        comm.on_msg(lambda _: None)

# Generated at 2022-06-12 15:19:53.570570
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm.tnrange(2) as bar:
        bar.reset(total=10)
        bar.update(2)

    # this is a bug on the code
    # because the bar does not reset at all
    assert bar.total == 2
    assert bar.n == 2
    assert bar.leave == False



# Generated at 2022-06-12 15:19:59.485167
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from copy import copy

    for desc in ['', 'desc', "Lorem ipsum dolor sit amet"]:
        kwargs = dict(desc=desc, ncols=100)

        try:
            # Test standalone bar
            pbar = tqdm_notebook.status_printer(None, **kwargs)
            str(pbar)
        except (ImportError, TypeError):
            pass

        # Test tqdm_notebook bar display
        pbar = tqdm_notebook(10, **kwargs)
        pbar.display(check_delay=False)

        if IPY == 3:  # Won't pass in 4+
            # Test HBox representation
            hbox = copy(pbar.container)
            str(hbox)

            # Test display + representation

# Generated at 2022-06-12 15:21:36.306853
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm._utils import _term_move_up
    from io import StringIO
    import pdb
    
    fake_out = StringIO()
    for i in tqdm_notebook(range(3),
                           file=fake_out,
                           leave=True, desc='PYTHON'):
        pdb.set_trace()
        
    print(fake_out.getvalue())
    assert(_term_move_up(fake_out) != True)

if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:21:43.382533
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import os
    try:  # py3
        from unittest.mock import patch
    except ImportError:  # py2
        from mock import patch

    with patch.object(sys, 'stderr', open(os.devnull, 'w')):
        with tqdm_notebook(total=1) as pbar:
            pbar.display(close=True)
            pbar.display(bar_style='success')
            pbar.display(bar_style='danger')


# A simple test to check if the notebook progress bar is working correctly

# Generated at 2022-06-12 15:21:49.690917
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():  # pragma: no cover
    # The following test is meant for IPython notebooks
    # as it requires a sympy package to pass
    try:
        from sympy import prime, primerange
    except ImportError:
        # No such module 'sympy'
        return
    t = tqdm_notebook(prime(i) for i in primerange(10**3, 10**4))
    for i in t:
        assert i in primerange(10**3, 10**4)
    t.close()
    assert t.n == len(list(primerange(10**3, 10**4)))



# Generated at 2022-06-12 15:21:56.152930
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit tests for method status_printer of class tqdm_notebook."""
    import sys
    import time
    from tqdm.auto import tqdm

    pbar = tqdm_notebook.status_printer(sys.stdout, 23, '-->', 100)

    for i in tqdm(range(23)):
        time.sleep(0.01)
        pbar.value = i
    pbar.close()


# Generated at 2022-06-12 15:22:04.796677
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from pytest import raises
    from numpy.random import randint

    for l in [10, 1000, 1000000]:
        with tqdm_notebook(total=l) as pbar:
            for _ in range(l):
                pbar.update()
                assert pbar.total == l, 'total wrong in tqdm_notebook __iter__'
        assert pbar.total == l, 'total wrong in tqdm_notebook __iter__'

        with tqdm_notebook(range(l)) as pbar:
            for j in pbar:
                assert pbar.total == l, 'total wrong in tqdm_notebook __iter__'


# Generated at 2022-06-12 15:22:13.538880
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    # Create a progress bar with max = 10
    progress_bar = tqdm_notebook(total=10)
    # Update the progress bar with 5
    progress_bar.update(n=5)
    # Check that the progress bar is actually updated
    assert progress_bar.n == 5
    # Reset the progress bar
    progress_bar.reset()
    # Check that the progress bar is now back to 0
    assert progress_bar.n == 0
    # Check that the max remains the same
    assert progress_bar.total == 10
    # Update the progress bar once again
    progress_bar.update(n=5)
    # Reset the progess bar with a new max
    progress_bar.reset(20)
    # Check that the max has been updated
    assert progress_bar.total == 20
    # Check that the progress bar is

# Generated at 2022-06-12 15:22:16.593323
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    s = tqdm_notebook.status_printer(None)
    assert len(s.children) == 3
    assert isinstance(s.children[0], HTML)
    assert isinstance(s.children[1], IProgress)
    assert isinstance(s.children[2], HTML)
    assert isinstance(s, TqdmHBox)

# Generated at 2022-06-12 15:22:26.409728
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=2) as t:
        t.update()
        assert t.displayed
        assert t.ncols is None
        tqdm_notebook(total=2, ncols=100).close()

# for testing purposes
if __name__ == '__main__':
    # python tqdm/notebook.py [-l <line>]
    from .utils import _decode_html_entities
    from .std import tqdm, TqdmTypeError

    # tests

# Generated at 2022-06-12 15:22:31.183004
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    try:
        from tqdm import tqdm_notebook
        from IPython.display import clear_output
    except ImportError:
        return
    for _ in tqdm_notebook(range(2)):
        for _ in tqdm_notebook(range(5), desc='1st loop', leave=True):
            for _ in tqdm_notebook(range(100), desc='2nd loop'):
                pass
            clear_output()
        clear_output()

# Generated at 2022-06-12 15:22:37.173390
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=100, leave=False)
    t.close()
    assert t.container.pbar.bar_style == 'success'
    t = tqdm_notebook(total=100, leave=True)
    t.close()
    assert t.container.pbar.bar_style == 'success'
    t = tqdm_notebook(total=100, leave=False, disable=True)
    t.close()
    assert t.container.pbar.bar_style == 'success'
    t = tqdm_notebook(total=100, leave=False, disable=False)
    t.close()
    assert t.container.pbar.bar_style == 'success'
    t = tqdm_notebook(total=100, leave=False, disable=False)
