

# Generated at 2022-06-12 15:13:27.671456
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    with tqdm(total=10) as t:
        for i in range(5):
            time.sleep(1)
            t.update()
        t.reset(total=5)
        for i in range(5):
            time.sleep(1)
            t.update()

# Generated at 2022-06-12 15:13:35.525778
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Test the method status_printer of class tqdm_notebook """
    # initialise
    bar = tqdm_notebook.status_printer(None, 100)
    assert len(bar.children) == 3, bar.children

    # test total
    assert bar.children[1].max == 100, bar.children[1].max

    # check initial value
    assert bar.children[1].value == 0, bar.children[1].value

    # test ltext
    ltext, pbar, rtext = bar.children
    ltext.value = "test"
    assert ltext.value == "test", ltext.value
    assert ltext.value != "", ltext.value

    # test rtext
    rtext.value = "test"
    assert rtext.value == "test", rtext.value

# Generated at 2022-06-12 15:13:41.169684
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test to check the behaviour of tqdm_notebook.__iter__"""
    import time
    a = tqdm_notebook(range(10))
    time.sleep(0.01)
    b = [i for i in a]
    assert b == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert a.n == 10
    assert a.container.children[0].value == '0it [00:00, ?it/s]'

# Generated at 2022-06-12 15:13:51.398011
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        import pandas
        import numpy
    except ImportError:
        raise unittest.SkipTest("Pandas and/or numpy not found")
    else:
        if pandas.__version__ < '0.18.0' or numpy.__version__ < '1.10.0':
            raise unittest.SkipTest(
                "Pandas and/or numpy version is too old")

    from .utils import FormatTelegramBot

    try:
        input = raw_input
    except NameError:
        pass

    class _TestTqdmNotebookIter(unittest.TestCase):
        def test_TqdmTypeError(self):
            with self.assertRaises(TypeError):
                for obj in tqdm_notebook([]):
                    pass


# Generated at 2022-06-12 15:13:55.818225
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for i in tqdm(range(100), leave=False):
        # do some process
        pass


if __name__ == '__main__':
    from tqdm._utils import _test_env  # NOQA
    _test_env.run_tests(verbose=0, ignore_files_whitelist={"tqdm_gui.py"})

# Generated at 2022-06-12 15:14:04.486886
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():

    # Fake sys.stderr
    if "fake_stderr" not in globals():
        global fake_stderr
        fake_stderr = open('_tqdm_test_stderr.txt', 'w', encoding='utf-8')

    # Fake sys.stdout
    if "fake_stdout" not in globals():
        global fake_stdout
        fake_stdout = open('_tqdm_test_stdout.txt', 'w', encoding='utf-8')

    # Tests
    # Test #1
    kwargs = {}
    container = tqdm_notebook.status_printer(fake_stdout, total=10, desc='TEST 1', **kwargs)
    assert len(container.children) == 3
    assert type(container.children[0]) is HTML


# Generated at 2022-06-12 15:14:09.962812
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import random
    from time import sleep
    from sys import stderr

    # Python 2.x backwards compatibility
    try:
        # Python 2.x
        range = xrange
    except NameError:
        # Python 3.x
        pass

    try:
        for _ in tqdm_notebook(range(10), file=stderr, desc='0123456789', leave=True):
            sleep(random())
        with tqdm_notebook(range(10), file=stderr, desc='0123456789', leave=True) as t:
            sleep(random())
            raise ValueError
    except ValueError:
        pass

# Generated at 2022-06-12 15:14:20.582728
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """The display method is critical: it's the one with the most bugs"""
    from ipywidgets import IntProgress
    t = std_tqdm(total=1, leave=False, dynamic_ncols=True)
    c = t._instantiate_widget(
        IntProgress,
        t.status_printer,
        fp=t.fp,
        total=t.total,
        desc=t.desc,
        ncols=t.ncols)
    t.container = TqdmHBox(children=c.children)
    t.pbar = c.children[1]
    t.displayed = False
    t.delay = 0


# Generated at 2022-06-12 15:14:27.685859
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Error in manual tqdm
    try:
        for i in tqdm_notebook(range(10), leave=True):
            if i == 5:
                raise Exception()
    except:
        pass
    else:
        assert False, "Error not detected"
    # Error in automatic tqdm
    try:
        for i in tqdm_notebook(range(10), leave=True, total=None):
            if i == 5:
                raise Exception()
    except:
        pass
    else:
        assert False, "Error not detected"


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:14:36.271824
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Make sure tqdm_notebook works properly"""
    # Tests
    if IPY == 0:
        raise ImportError("IPython not found")
    for total in [10, None]:
        for desc in ["", "test"]:
            for ncols in [None, 100, "100px", "100%"]:
                # Initialize IPython progress bar
                file = sys.stdout
                pbar = tqdm_notebook.status_printer(file, total, desc, ncols)
                # Tests
                assert (pbar.children[0].value == desc)
                try:
                    max_ = int(pbar.children[1].max)
                except TypeError:  # handle unknown total (None)
                    max_ = None
                assert (max_ == total)

# Generated at 2022-06-12 15:14:55.246112
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    try:
        from unittest.mock import patch  # >= 3.3
    except ImportError:
        from mock import patch  # python-mock

    # import IPython.display
    # clear_output = IPython.display.clear_output
    # display = IPython.display.display
    with patch('IPython.display.clear_output') as clear_output, \
            patch('IPython.display.display') as display:
        # Patch IPython.display.display
        t = tqdm_notebook(total=3, desc="test", display=False)
        assert t.displayed is False
        t.update()
        t.update()
        t.update()
        assert t.displayed is True
        t.close()
        # Patch IPython.

# Generated at 2022-06-12 15:14:59.431328
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1, leave=False) as pbar:
        assert pbar.set_description('test') is None
        assert pbar.set_postfix() is None
        if hasattr(pbar, '_instant_clear'):
            assert pbar._instant_clear().set_description('test2') is None
        else:
            assert pbar.clear().set_description('test2') is None
        assert pbar.close() is None

# Generated at 2022-06-12 15:15:02.197923
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Some objects are not iterable (e.g. an integer)
    try:
        tqdm_notebook(42)
    except TypeError:
        pass



# Generated at 2022-06-12 15:15:09.845057
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for tqdm_notebook.__iter__()"""
    with tqdm_notebook(total=2) as pbar:
        # should raise ValueError if not iterable
        try:
            iter(pbar)
        except ValueError:
            pass
        else:
            raise Exception('Failed to raise ValueError')

        # should work fine on iterable
        pbar.reset(total=3)
        assert iter(pbar) is pbar
        pbar.update()
        assert pbar.last_print_t == pbar.start_t
        try:
            for _ in pbar:
                pbar.update()
        finally:
            # next call to `pbar.update` should raise a ValueError
            try:
                pbar.update()
            except ValueError:
                pass


# Generated at 2022-06-12 15:15:19.938810
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    test = tqdm_notebook(iterable=_range(5), leave=False, total=5)
    assert len(test) == 0
    assert test.n == 0
    assert test.container.children[-2].value == 0

    test.update()
    assert test.n == 1
    assert test.container.children[-2].value == 1

    test.update(1)
    assert test.n == 2
    assert test.container.children[-2].value == 2

    test.update(3)
    assert test.n == 5
    assert test.container.children[-2].value == 5

    test.update(7)
    assert test.n == 12
    assert test.container.children[-2].value == 12



# Generated at 2022-06-12 15:15:28.515081
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .std import tqdm

    # Instantiate tqdm_notebook
    with tqdm(total=1, leave=False, disable=False) as t:
        # Clear the bar
        t.display('')
        assert t.container.children[-1].value == ''
        # Print a bar
        msg = "test"
        t.display(msg)
        assert t.container.children[-1].value == msg
        # Clear the bar again
        t.display('')
        assert t.container.children[-1].value == ''
        # Update it with a new bar
        msg = "test2"
        t.display(msg)
        assert t.container.children[-1].value == msg
        # Signal to close the bar
        t.display(close=True)
        assert hasattr

# Generated at 2022-06-12 15:15:34.602090
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.tests import CommonTest, pretest_posttest, closing_save_schemes
    with closing_save_schemes(tqdm_notebook):
        CommonTest().test_update(tqdm_notebook)
    with closing_save_schemes(tqdm_notebook):
        CommonTest().test_update(tqdm_notebook, False)


# Generated at 2022-06-12 15:15:38.179205
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear(): pass


if __name__ == "__main__":
    from ._tqdm import _test, __version__

    print("Testing tqdm_notebook %s" % __version__, file=sys.stderr)
    _test(tqdm)
    _test(tnrange)

# Generated at 2022-06-12 15:15:40.949864
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import trange
    for n in trange(4, desc="test_tqdm_notebook_update", leave=False):
        print(n)


if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:15:44.249677
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        import ipywidgets
    except ImportError:
        return None
    total = 14
    i = tqdm_notebook(total=total)
    i.reset()
    for j in i:
        if j == total/2:
            i.close()
            break

# Generated at 2022-06-12 15:16:22.583074
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    def try_tqdm_notebook_update():
        import time
        pbar = tqdm_notebook(total=10)
        for i in range(10):
            pbar.update(1)
            time.sleep(0.1)
    try_tqdm_notebook_update()

if __name__ == '__main__':
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:16:28.591598
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(range(5))
    t.clear()
    del t
    t = tqdm_notebook(range(5))
    t.close()
    t.clear()
    del t
    t = tqdm_notebook(range(5))
    t.reset()
    t.clear()
    del t
    t = tqdm_notebook(range(5))
    t.reset()
    t.close()
    t.clear()
    del t
    t = tqdm_notebook(range(5))
    t.clear()
    t.close()
    del t
    t = tqdm_notebook(range(5))
    t.clear()
    t.reset()
    del t

# Generated at 2022-06-12 15:16:37.094541
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test the update method of tqdm_notebook"""
    t = tqdm_notebook(total=2)
    t.update()
    t.update()
    try:
        t.update(n=1)
    except Exception as e:
        if issubclass(e.__class__, IndexError):
            pass
        else:
            raise e
    try:
        t.update(total=3)
    except Exception as e:
        if issubclass(e.__class__, IndexError):
            pass
        else:
            raise e
    t.close()


if __name__ == '__main__':
    from pytest import main
    main([__file__])

# Generated at 2022-06-12 15:16:44.798369
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm_notebook
    from tqdm._utils import _term_move_up

    t = tqdm_notebook(range(100), leave=False, desc="test_tqdm")
    for _ in t:
        pass
    assert not t.displayed
    # Test empty bar
    t.reset()
    assert t.displayed
    assert t.container.children[-2].bar_style == ''
    assert t.n == 0
    assert t.ncols is None

    # Test bar with new total
    t.total = 10
    t.reset()
    assert t.container.children[-2].bar_style == ''
    assert t.n == 0
    assert t.ncols is None

    # Test bar without new total (but known)
    t.total

# Generated at 2022-06-12 15:16:48.586492
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    sum_ = 0
    for i in tqdm_notebook(range(1000)):
        sum_ += i
        time.sleep(0.0001)
    assert sum_ == 499500


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:16:51.936630
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tnrange
    for _ in tnrange(2):
        print('tqdm_notebook display test')



# Generated at 2022-06-12 15:17:01.761096
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = tqdm_notebook.status_printer(None, desc='Testing IPython / Jupyter notebook progress bar widget', ncols=100)
    pbar.children[1].value = 100
    assert(repr(pbar) == "\nTesting IPython / Jupyter notebook progress bar widget: 100%|███████████████████████████████████████████████████| 100/100 [00:00<00:00, ?it/s]")
    pbar.children[1].value = 50
    assert(repr(pbar) == "\nTesting IPython / Jupyter notebook progress bar widget: 50%|████████████████████████████████████████████| 50/100 [00:00<00:00, ?it/s]")
    return pbar

# test

# Generated at 2022-06-12 15:17:04.908277
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t = tqdm_notebook(range(4))
    for i in t:
        assert i == t.n - 1
        if i == 2:
            break
    t = tqdm_notebook(range(4))
    for i in t:
        assert i == t.n - 1
    assert i == t.last_print_n - 1


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:17:11.340347
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
    # test reset
    with tqdm_notebook(total=10) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)
            if i == 5:
                pbar.reset()
                pbar.reset(total=7)
                for j in range(7):
                    pbar.update(1)
    # test reset + leave
    with tqdm_notebook(total=10, leave=True) as pbar:
        for i in range(10):
            sleep(.1)
            pbar.update(1)

# Generated at 2022-06-12 15:17:15.283381
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook() as pbar:
        import time
        for i in range(20):
            time.sleep(0.1)
            pbar.update(1)
        pbar.reset(10)
        for i in range(10):
            time.sleep(0.1)
            pbar.update(1)
            assert pbar.n == i+1


# Generated at 2022-06-12 15:18:17.744080
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Testing `tqdm.notebook.tqdm` __iter__ method"""
    from tqdm import trange
    import sys

    # Test standard behaviour
    out = trange(5)
    assert next(out) == 0
    assert next(out) == 1
    for i in out:
        assert i == 2
    for i in out:
        assert i == 3

    # Test with exception
    try:
        for _ in trange(1):
            raise Exception
    except Exception:
        pass
    assert out.n == 0

    # Test with KeyboardInterrupt

# Generated at 2022-06-12 15:18:25.381802
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Create a mock object and set the "parent" attribute
    class FakeParent(object):
        def __init__(self):
            self.parent = None
    parent = FakeParent()

    # Call the method
    tqdm_notebook.status_printer(parent, disable=True)
    assert isinstance(parent.parent, HBox)
    rtext = parent.parent.children[-1]
    assert rtext.value == '[disable]'

    # Call the method
    tqdm_notebook.status_printer(parent, disable=False)
    assert isinstance(parent.parent, HBox)
    ltext = parent.parent.children[0]
    assert ltext.value == ''


# Generated at 2022-06-12 15:18:28.754494
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test for compatibility with tqdm.gui
    """
    try:
        from tqdm.gui import tqdm as tqdm_gui
        test_tqdm_notebook_status_printer.get_status_printer = tqdm_gui.status_printer
        test_tqdm_notebook_status_printer.get_status_printer()
    except Exception:
        pass

# Generated at 2022-06-12 15:18:34.483152
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:  # pragma: no cover
        raise ImportError("Please install IPython/Jupyter to test tqdm_notebook.")
    disp = tqdm_notebook.status_printer(None, total=2, desc="", ncols=100)
    # Only test if it displays correctly
    display(disp)
    assert True

# Generated at 2022-06-12 15:18:41.194040
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    class ReturnException:
        pass

    # Test 1/2 (no error)
    try:
        with tqdm_notebook(total=2, leave=True) as pbar:
            for i in range(2):
                pbar.update()
    except ReturnException:
        assert False
    else:
        assert True

    # Test 2/2 (with error)
    try:
        with tqdm_notebook(total=2, leave=True) as pbar:
            for i in range(1):
                pbar.update()
            raise ReturnException
    except ReturnException:
        assert True
    else:
        assert False

# Generated at 2022-06-12 15:18:43.545870
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.core.display import display
    tqdm_notebook().display()
    tqdm_notebook().display(bar_style='success')
    tqdm_notebook().display(bar_style='danger')

# Generated at 2022-06-12 15:18:54.986070
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep

    # Jupyter notebook detected
    # we no longer need to check for Jupyter
    # since the module will fail to load without
    assert sys.modules.get("IPython") is not None

    # Load widget if available (not in Python 2)
    # only for python 2.x
    try:
        from traitlets import Dict, Float, Int, Unicode
        getattr(ipywidgets, 'widget_float.Progress')
    except ImportError:
        return

    # Test whether tqdm and tqdm_widget can be called without error
    try:
        widgets = tqdm_notebook(total=None)
        widgets.container.close()
    except (ImportError, RuntimeError):  # no IPython or tqdm < 4.7
        return

    # Test whether t

# Generated at 2022-06-12 15:18:56.921105
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    for i in tqdm_notebook(range(5), leave=True):
        time.sleep(0.5)

# Generated at 2022-06-12 15:19:05.690855
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from io import StringIO
    buf = StringIO()
    # Test if calling reset without calling display because of delay=0
    # raises an exception
    try:
        with tqdm(total=0, file=buf) as t:
            t.reset()
            t.display()
    except Exception:
        raise Exception("Calling reset() without calling display() first "
                        "with delay=0 raises an exception and should not.")
    buf.close()
    # Test if calling reset with a new total works
    with tqdm(total=1, file=buf) as t:
        t.update(1)
        t.reset(total=10)
        t.update(1)
    buf.close()
    # Test if calling reset with a new unknown total works

# Generated at 2022-06-12 15:19:08.877366
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=5) as t:
        for i in range(5):
            t.update(1)


# Generated at 2022-06-12 15:21:59.562398
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert list(tqdm_notebook(range(5))) == list(range(5))



# Generated at 2022-06-12 15:22:05.428408
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    with tqdm_notebook(total=4, leave=False) as t:
        for i in range(4):
            time.sleep(0.1)
            t.update(1)
    assert t.n == 4  # assert tqdm_notebook.update(tqdm_notebook())
    assert t.n == 4  # assert tqdm_notebook.update(tqdm_notebook())
    assert t.n == 4  # assert tqdm_notebook.update(tqdm_notebook())
    assert t.n == 4  # assert tqdm_notebook.update(tqdm_notebook())



# Generated at 2022-06-12 15:22:14.056539
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython import get_ipython
    # ipykernel >= 4.10
    try:
        from ipykernel import iostream
    except ImportError:
        from ipykernel import iostreams as iostream

    from time import sleep
    from unittest import TestCase

    class Test(TestCase):
        def setUp(self):
            self.ip = get_ipython()
            self.ip.kernel.do_one_iteration = lambda: None

        def test(self):
            pbar = tqdm_notebook(range(10))
            self.assertEqual(pbar.__repr__(pretty=True),
                             '  0%|                               | 0/10 '
                             '[00:00<?, ?it/s]')
            pbar.close()

# Generated at 2022-06-12 15:22:23.952936
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

    pbar = tqdm_notebook(total=2)
    assert not pbar.container.visible

    pbar.display()
    assert pbar.container.visible

    pbar.display(close=True)
    assert not pbar.container.visible

    pbar.display()
    pbar.display(bar_style='success')
    sleep(.01)
    assert pbar.container.children[-2].bar_style == 'success'
    pbar.display(bar_style='danger')
    sleep(.01)
    assert pbar.container.children[-2].bar_style == 'danger'

    pbar.display()
    pbar.colour = '#FFFFFF'
    assert pbar.container.children[-2].style.bar_color == '#FFFFFF'


# Generated at 2022-06-12 15:22:31.246018
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm as tqdm_gui
    w = tqdm_notebook(total=10)
    assert w.total is not None
    assert not isinstance(w, tqdm_gui)
    assert w.bar_format == '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    assert not hasattr(w, 'n')
    assert not hasattr(w, 'last_print_n')
    w.reset(total=9999)  # Total should be updated to 9999
    assert w.total is not None
    assert not hasattr(w, 'n')
    assert not hasattr(w, 'last_print_n')
    w.reset()  # Total should be reset to None
    assert w.total

# Generated at 2022-06-12 15:22:39.289292
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # First test: reset a bar with unknown total (ncols=None)
    with tqdm_notebook(total=None, ncols=None) as t:
        t.write("Line 1")
        t.reset(total=10)
        t.update(1)
        t.reset(total=10)
        t.write("Line 2")
        t.update(2)
    # Second test: reset a known total bar with width=100% (ncols=None)
    with tqdm_notebook(total=10, ncols=None) as t:
        t.write("Line 1")
        t.reset(total=10)
        t.update(1)
        t.reset(total=10)
        t.write("Line 2")
        t.update(2)
    # Third

# Generated at 2022-06-12 15:22:47.999996
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    with tqdm(range(20), desc='1st loop') as t:
        [sleep(0.1) for _ in t]
    with tqdm(range(20), desc='2nd loop') as t:
        for i in t:
            sleep(0.1)
            if i > 5:
                raise Exception('BOOM!')
            # continue
    with tqdm(total=20, desc='3rd https://github.com/tqdm/tqdm#ipython-jupyter-integration') as t:
        for i in range(20):
            sleep(0.1)
            t.update()
    with tqdm(range(20), desc='4th loop', leave=True) as t:
        [sleep(0.1) for _ in t]


# Generated at 2022-06-12 15:22:54.347395
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    test the output of a tqdm_notebook
    """
    try:
        if IPY == 0:  # pragma: no cover
            raise ImportError  # Avoid testing if IPython is not supported
        # Python2
        from StringIO import StringIO
    except ImportError:  # pragma: no cover
        # Python3
        from io import StringIO

    file = StringIO()
    total = 10
    desc = "test"
    kwargs = dict()
    tqdm_nb = tqdm_notebook(file=file, total=total, desc=desc)
    bar = tqdm_nb.status_printer(tqdm_nb.fp, total, desc,
                                 kwargs.get('ncols', None))

    # check the format of the file
    expected_

# Generated at 2022-06-12 15:22:59.712663
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.utils import _term_move_up
    from .tests_tqdm import _range

    class err(Exception):
        pass

    with std_tqdm(total=None) as bar:
        bar.disp = lambda *_: None
        try:
            for _ in bar:
                raise err
        except err:
            pass
        assert not hasattr(bar, 'clear')

    with std_tqdm(total=None) as bar:
        bar.disp = lambda *_: None
        bar.update(10)
        try:
            bar.update(10)
            raise err
        except err:
            pass
        assert not hasattr(bar, 'clear')

    with std_tqdm(total=None) as bar:
        bar.disp = lambda *_: None

# Generated at 2022-06-12 15:23:09.091768
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from nose.tools import assert_equal
    from .gui import tqdm as _tqdm

    # Check catch KeyboardInterrupt
    with tqdm_notebook(total=3) as bar:
        bar.update()
        raise KeyboardInterrupt

    # Check close on error in an iterator