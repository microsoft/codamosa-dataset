

# Generated at 2022-06-12 15:13:39.499061
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test that `TqdmHBox._repr_html_()` and `TqdmHBox._repr_pretty_()`
    produce the same output.
    """
    import random
    import unittest
    from io import StringIO
    from copy import copy
    from html.parser import HTMLParser
    from threading import Thread
    from queue import Queue, Empty
    from collections import namedtuple

    class_args = ("a", 1, 10)
    class_kwargs = {"mininterval": 0}
    progbar = tqdm_notebook(*class_args, **class_kwargs)

    def run_unit_test(q, html, pretty):
        progress = []
        for n in range(6):
            # Randomly update progress value
            n = random.random()

# Generated at 2022-06-12 15:13:49.990546
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm import _term_move_up
    from html import unescape
    if IPY == 2:
        # ipywidgets 6.0.0+ on IPython 2.x needs to be compiled
        # separately, and in this case, it is not always compiled
        return
    with std_tqdm.external_write_mode():
        # Use a standard output, which can be tested
        with std_tqdm(disable=True, file=sys.stdout) as t:
            # Try to delete previous line
            t.fp.write(_term_move_up() + '\r')
            # Prepare for tqdm_notebook widget
            c = tqdm_notebook.status_printer(
                t.fp, 10000, 'Test of tqdm_notebook widget')
            # Check that the content

# Generated at 2022-06-12 15:13:53.549788
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm.tests import TqdmDeprecationWarning

    with TqdmDeprecationWarning():
        t = tqdm(total=10)
        assert str(t) == t.format_dict['bar_format'] % t.format_dict
        t.close()



# Generated at 2022-06-12 15:14:02.386430
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stderr
    from time import sleep
    from tqdm.utils import format_sizeof

    # Create tqdm instance
    t = tqdm_notebook(
        bar_format='{l_bar}{bar}{r_bar}',
        total=10,
        leave=False,
        file=stderr,
        mininterval=0.1,
        miniters=10)

    # Set verbose display function
    def disp(*args, **kwargs):
        t.display(*args, **kwargs)
        sleep(0.1)

    # Display initial bar
    disp()

    # Update bar
    t.update(0)
    disp()
    t.update(1)
    disp()
    t.update(2)
    disp()

    # Refresh bar
    t

# Generated at 2022-06-12 15:14:04.100758
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as t:
        for i in t:
            if t.n == 5:
                t.reset()
            t.update()


# Generated at 2022-06-12 15:14:10.350130
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm import tqdm
    from tqdm.notebook import tqdm as tqdm_notebook

    for T in [tqdm_notebook, tqdm]:
        for leave in [False, True]:
            with T(leave=leave) as t:
                assert repr(t) == T.__repr__(t)
                assert repr(t) == T.__str__(t)
                assert repr(t) == t.__str__()
                assert repr(t) == t.__repr__()

if __name__ == "__main__":
    test_TqdmHBox___repr__()

# Generated at 2022-06-12 15:14:20.157125
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    for i in tqdm_notebook(range(10)):
        sleep(.1)
        # update value, change bar style
        if i == 4:
            tqdm_notebook.update(tqdm_notebook.container.pbar, i+1, bar_style='warning')
            # update description
            tqdm_notebook.container.pbar.set_description("foo")
        # reset
        if i == 7:
            tqdm_notebook.reset()
        # close
        if i == 9:
            tqdm_notebook.close()
            # check idem-potency
            tqdm_notebook.close()

# Generated at 2022-06-12 15:14:25.657259
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from IPython.display import clear_output
    except ImportError:
        return
    with tqdm_notebook(total=10) as pbar:
        for _ in range(10):
            pbar.clear()
            pbar.update()
    # this will raise an exception if clear_output was called
    try:
        clear_output()
    except:
        raise Exception("tqdm_notebook.clear() shouldn't call clear_output")


# Generated at 2022-06-12 15:14:28.817352
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # import module under test
    from tqdm.notebook import tqdm

    # prepare the test suite
    def nested_loops_generator():
        """
        A generator that produces multiple nested loops
        """
        for j in tqdm(range(1000), desc="first loop"):
            for i in tqdm(range(1000), desc="second loop"):
                yield i

    # execute the test suite
    for obj in nested_loops_generator():
        pass

# Generated at 2022-06-12 15:14:37.192924
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    container = TqdmHBox(children=[1, 2, 3])
    assert repr(container) == "1 2 3"
    container.pbar = container
    assert repr(container) == "{'pos': 0, 'total': None, 'elapsed': None, 'desc': '1 2'}"
    container.pbar.format_dict['ascii'] = False
    assert repr(container) == "{'pos': 0, 'total': None, 'elapsed': None, 'desc': '1 2'}"
    container.pbar.format_dict['ascii'] = None
    container.pbar.format_dict['desc'] = ''
    assert repr(container) == "{'pos': 0, 'total': None, 'elapsed': None, 'desc': ''}"

# Generated at 2022-06-12 15:15:04.054740
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    '''
    Unit test for method status_printer of class tqdm_notebook.
    '''
    test_instance = tqdm_notebook()
    container = test_instance.status_printer(sys.stdout, total = 10, desc = 'Testing container')
    assert (type(container)) == TqdmHBox, 'status_printer of class tqdm_notebook is not returning an instance of TqdmHBox class.'
    ltext, pbar, rtext = container.children
    assert (type(ltext)) == HTML and (type(rtext)) == HTML, 'status_printer of class tqdm_notebook is not returning all children of the TqdmHBox instance.'

# Generated at 2022-06-12 15:15:11.101258
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    try:
        import IPython
    except ImportError:
        try:
            import ipywidgets
        except ImportError:
            try:
                import IPython.html.widgets as ipywidgets  # NOQA: F401
            except ImportError:
                pass
    from tqdm import notebook

    tqdm_nb = getattr(tqdm, 'tqdm_notebook', tqdm.tqdm_notebook)

    if tqdm_nb is None:  # pragma: no cover
        print("tqdm.notebook not found")
        return
    print("Testing tqdm_notebook.status_printer ...")
    assert tqdm_nb._instances
    t = tqdm_nb._instances[0]
    assert t.displayed
    h = t

# Generated at 2022-06-12 15:15:19.141016
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    test_inst = tqdm_notebook(total=100)
    sleep(0.01)
    test_inst.update(10)
    test_inst.update(20)
    sleep(0.01)
    test_inst.close()
    assert test_inst.total == 100, 'Total is not set correctly'
    assert test_inst.n != 100, 'Manual update does not work'
    assert test_inst.n == 30, 'Manual update does not work'
    assert test_inst.pbar.value == 30, 'Manual update does not work'



# Generated at 2022-06-12 15:15:24.789342
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    for i in tqdm(range(50)):
        time.sleep(0.05)
        if i == 10:
            tqdm.colour = 'red'
        if i == 20:
            tqdm.colour = 'blue'
        if i == 30:
            tqdm.colour = 'green'
        if i == 40:
            tqdm.colour = 'orange'

# Generated at 2022-06-12 15:15:36.735427
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm import tnrange
    from IPython.testing.globalipapp import get_ipython  # noqa (tests)
    ip = get_ipython()

    # Test correct bar width
    bar_width = tnrange(1, 100, 1, ncols=20).container.layout.width
    assert bar_width == '20px'

    # Test progress bar style changed
    pbar = tnrange(1, 3, 1).container.children[1]
    pbar.bar_style = 'danger'
    assert pbar.bar_style == 'danger'

    # Test progress bar style changed to success
    pbar = tnrange(1, 3, 1).container.children[1]
    pbar.bar_style = 'success'
    assert pbar.bar_style == 'success'

    #

# Generated at 2022-06-12 15:15:38.219034
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm(_range(10)) as t:
        for i in t:
            pass



# Generated at 2022-06-12 15:15:44.270587
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from inspect import signature
    from time import sleep

    # Setup miniters=1 and mininterval=0
    # to make sure the bar updates on every iteration
    with tqdm(range(2), miniters=1, mininterval=0) as t:
        # Check if the 'desc' kwarg is accepted
        assert 'desc' in signature(t.update).parameters

        # Check if initial display is correct
        t.display(1, False)
        assert len(t.container.children[-2].children) == 1

        # Check if bar updates correctly
        t.display(1, False)
        assert len(t.container.children[-2].children) == 2

        # Test bar_format
        t.bar_format = '{l_bar}{bar}{r_bar}'
        t.display

# Generated at 2022-06-12 15:15:50.798769
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        update = tqdm_notebook(
            [1, 2, 3, 4], desc='Test method update',
            display=False).update
    except ImportError as e:
        print('Skipping test_tqdm_notebook_update:', e)
    else:
        for i in update(0):
            update(1, bar_style='info')
            update(2, bar_style='success')
            update()
            update(1, bar_style='danger')
            break

# Generated at 2022-06-12 15:15:54.179131
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as pbar:
        assert pbar.total == 10
        pbar.reset(total=10)
        assert pbar.total == 10
        pbar.reset(total=100)
        assert pbar.total == 100

test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:15:55.366057
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(file=None)


# Generated at 2022-06-12 15:16:13.933189
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for iterable in [
            tqdm_notebook(iterable=range(1000000))]:
        for _ in iterable:
            iterable.reset(total=2000000)
            iterable.reset(total=None)
            iterable.reset()

    with tqdm_notebook(iterable=range(1000000), total=2000000) as iterable:
        for _ in iterable:
            iterable.reset(total=2000000)
            iterable.reset(total=None)
            iterable.reset()

    with tqdm_notebook(iterable=range(1000000), total=None) as iterable:
        for _ in iterable:
            iterable.reset(total=2000000)
            iterable.reset(total=None)
            iterable.reset()



# Generated at 2022-06-12 15:16:19.644285
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._tqdm_notebook import tqdm_notebook as pbar
    try:
        import ipywidgets as widgets
        from IPython.display import display, clear_output
    except ImportError:
        raise ImportError("test_tqdm_notebook_display requires ipywidgets")

    # Test error display
    t = pbar(range(0), bar_format="{l_bar}")
    t.display(bar_style="danger")
    t.display(bar_style="danger", check_delay=False)
    t.close()

    # Test percentage display
    t = pbar(range(0), bar_format="{percentage:3.0f}%")
    t.display(check_delay=False)
    t.close()

    # Test bar width
    # n

# Generated at 2022-06-12 15:16:25.885777
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import nose
    import tempfile
    with tempfile.TemporaryFile() as f:
        pbar = tqdm_notebook(file=f)
        pbar.display()
        assert pbar.displayed

        # will not work in "test_tqdm_notebook_display" but works in a notebook
        # assert pbar.container.children[0].value == '0it [00:00, ?it/s]\n<bar/>'

        # tqdm_notebook._repr_json_(pbar.container)
        # '{"bar_format": "{l_bar}<bar/>{r_bar}", "total": null, "n": 0, "desc": null, "position": null, "dynamic_ncols": true, "unit": "it", "unit_scale": true, "leave":

# Generated at 2022-06-12 15:16:35.713872
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from ipywidgets import IntProgress, FloatProgress
    from tqdm import tqdm
    from tqdm import tqdm_notebook

    for P in (IntProgress, FloatProgress):
        with tqdm(total=10, bar_format='{bar}') as pbar, \
                tqdm_notebook(total=10, bar_format='{bar}') as pbar_notebook:
            assert repr(P()) == "{b}<bar/>{r}".format(
                b=pbar.__enter__().__repr__(pretty=True),
                r=pbar.__enter__().__repr__(pretty=False))

# Generated at 2022-06-12 15:16:43.820975
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from random import random

    items = list(range(10))
    total = len(items)
    pbar = tqdm_notebook(items)
    for item in pbar:
        sleep(random())
        assert pbar.n < pbar.total  # this must be the case, or we have a bug

    # Test reset with unknown total
    pbar.reset()
    assert pbar.n == 0
    assert pbar.total is None
    pbar.reset(total=total)
    assert pbar.n == 0
    assert pbar.total == total
    pbar.reset(total=total + 1)
    assert pbar.total == (total + 1)
    assert pbar.n == 0

    # Test `close` method with an error
    pbar.close()
   

# Generated at 2022-06-12 15:16:53.639146
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test of tqdm_notebook.status_printer
    """
    import io
    try:
        from StringIO import StringIO  # Python 2.x
    except ImportError:
        from io import StringIO  # Python 3.x

    output = StringIO() if not PY3 else io.StringIO()
    fp = tqdm_notebook.status_printer(output)
    assert fp is not None
    if not PY3:
        assert type(fp).__name__ == 'TqdmHBox'
    else:
        assert str(type(fp)) == "<class 'tqdm._tqdm_notebook.TqdmHBox'>"
    assert str(fp) == ''



# Generated at 2022-06-12 15:17:03.027349
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from time import time, sleep
    from .gui import _gui_isnotebook, _gui_has_notebook
    from .auto import tqdm

    if not _gui_has_notebook:
        return
    elif not _gui_isnotebook:
        try:
            get_ipython()
        except NameError:
            return

    t = tqdm_notebook.status_printer(fp=None, total=None, desc='Desc', ncols='10px')
    assert t.layout.width == '10px'
    t = tqdm_notebook.status_printer(fp=None, total=None, desc='Desc', ncols=35)
    assert t.layout.width is None

# Generated at 2022-06-12 15:17:07.889512
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    def custom_print(self, *args, **kwargs):
        self._inst_cust_print_called = True
        super(tqdm_notebook, self)._inst_cust_print(*args, **kwargs)

    tqdm_notebook._inst_cust_print = tqdm_notebook._inst_cust_print_call
    tqdm_notebook._inst_cust_print_call = custom_print
    tqdm_notebook.clear = lambda x: True
    tqdm_notebook.close = lambda x: True

    for _ in tqdm_notebook(range(4)):
        pass
    assert tqdm_notebook._inst_cust_print_called

# Generated at 2022-06-12 15:17:16.087974
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Main function"""
    import time

    t = tqdm_notebook(total=10, mininterval=0)
    for i in range(10):
        time.sleep(0.1)
        t.update()

    with tqdm_notebook(total=10, mininterval=0.1) as t:
        for i in range(10):
            t.set_description("Processing %i" % i)
            time.sleep(0.1)
            t.update()

    with tqdm_notebook(total=10, mininterval=0.1) as t:
        for i in range(10):
            t.set_description("Processing %i" % i)
            time.sleep(0.1)
            t.update()
        t.close()


# Generated at 2022-06-12 15:17:24.821461
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import pytest
    IPY = 0
    try:  # IPython 4.x
        import ipywidgets
        IPY = 4
    except ImportError:  # IPython 3.x / 2.x
        IPY = 32
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings(
                'ignore', message=".*The `IPython.html` package has been deprecated.*")
            try:
                import IPython.html.widgets as ipywidgets  # NOQA: F401
            except ImportError:
                pass
