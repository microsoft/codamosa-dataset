

# Generated at 2022-06-12 15:13:26.942083
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
            pbar.set_description("%i" % (i))
        # Test closing the bar with different bar_style
        pbar.close()
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
            pbar.set_description("%i" % (i))
        # Test closing the bar with different bar_style
        pbar.close(bar_style='danger')

# Generated at 2022-06-12 15:13:30.106176
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for _ in tqdm_notebook(range(3)):
        # NB: KeyboardInterrupt should NOT be raised in try/except
        for _ in tqdm_notebook(range(3), leave=True):
            pass
test_tqdm_notebook_update()



# Generated at 2022-06-12 15:13:34.142453
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for unit_scale in (True, False, 2):
        t = tqdm_notebook(total=1, unit_scale=unit_scale)
        t.update()
        t.update()
        # Close in case the update was quick
        t.close()
        t.clear()
        t.update(1)
        t.close()



# Generated at 2022-06-12 15:13:38.542972
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Test tqdm_notebook.close()"""

    t = tqdm_notebook(total=100)
    t.update(99)
    t.close()
    assert(not hasattr(t, 'container'))

    t = tqdm_notebook(total=100)
    t.update()
    t.close()
    assert(not hasattr(t, 'container'))



# Generated at 2022-06-12 15:13:49.332800
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    # test that adding new bars works if the widget has been closed/removed
    with tqdm(total=100, leave=True) as pbar:
        for i in range(10):
            pbar.update(10)
        pbar.reset(total=150)
        for i in range(15):
            pbar.update(10)

    # test that it works with reusing the bar
    with tqdm(total=100, leave=True) as pbar:
        for i in range(10):
            pbar.update(10)
        pbar.reset(total=150)
        for i in range(15):
            pbar.update(10)

    # test that it works in manual mode

# Generated at 2022-06-12 15:13:55.810330
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Test if tqdm_notebook can update smoothly
    bar = tqdm_notebook(total=10)
    bar.update(2)
    assert bar.n == 2
    bar.update(5)
    assert bar.n == 7
    bar.update(10)
    assert bar.n == 10
    bar.close()
    # Test if tqdm_notebook can update smoothly with unit='steps'
    bar = tqdm_notebook(unit='steps', total=10)
    bar.update(2)
    assert bar.n == 2
    bar.update(5)
    assert bar.n == 7
    bar.update(10)
    assert bar.n == 10
    bar.close()
    # Test if tqdm_notebook can update smoothly with unit='it'
    bar = tq

# Generated at 2022-06-12 15:14:04.486557
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from os import remove
    from os.path import isfile
    from sys import executable
    from tempfile import mkstemp
    from subprocess import Popen

    # Note: the test is run afterwards (see the end of the file)
    # because ipywidgets uses "ipykernel" which can only be imported
    # within the kernel.

    def test_disp():
        # Note: units are not tested as it is not part of the display method
        tqdm_notebook.set_lock(force=False)  # release lock on global `extras`

# Generated at 2022-06-12 15:14:14.284650
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    container = TqdmHBox(children=[])
    # Test 1: no attributes has been set
    assert container.__repr__() == 'TqdmHBox(children=[])'

    # Test 2: pbar has been set
    container.pbar = 1
    assert container.__repr__(pretty=True) == 'HBox(children=[])'
    assert container.__repr__() == 'HBox(children=[])'

    # Test 3: pbar has been set and is of type tqdm
    container.pbar = tqdm_notebook(0)
    assert container.__repr__(pretty=True) == \
        "[{desc}{n_fmt}/{total_fmt}]  {bar} {postfix}"

# Generated at 2022-06-12 15:14:19.856609
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    import os
    import IPython
    IPython.embed()
    time.sleep(1)
    with tqdm_notebook(total=2) as pbar:
        time.sleep(1)
        pbar.update(1)
        pbar.reset(total=3)
        time.sleep(1)
        pbar.update(2)

# Generated at 2022-06-12 15:14:20.468611
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pass

# Generated at 2022-06-12 15:14:41.609618
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with _range(10) as t:
        t.reset(None)
        if t.total != 10:
            raise Exception("t.reset(None) did not raise exception")
        t.reset()
        if t.total != 10:
            raise Exception("t.reset() did not raise exception")
        t.reset(100)
        if t.total != 100:
            raise Exception("t.reset(100) did not raise exception")
        if t.ncols is not None:
            raise Exception("t.ncols was changed")



# Generated at 2022-06-12 15:14:49.253072
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    if IProgress is None:  # pragma: no cover
        return
    from sys import stderr
    from random import randint
    from copy import copy
    from re import match

    # Test with custom file
    f = 'file'
    status = tqdm_notebook.status_printer(f, total=3, desc="[test]")
    assert isinstance(status, TqdmHBox)
    assert status.children[1].value == 0
    assert status.children[2].value == ''
    status.update(n=2)
    assert status.children[1].value == 2
    assert status.children[2].value == "0%|"
    status.close()

    # Test with custom file

# Generated at 2022-06-12 15:14:55.093470
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for _ in tqdm_notebook(_range(1), total=1):
        pass
    assert tqdm_notebook(_range(2)).n == 2


if __name__ == '__main__':
    try:
        input = raw_input
    except NameError:
        pass
    try:
        from inspect import signature

        if signature(IProgress.__init__).parameters:  # has parameters
            ipywidgets_version = tuple(
                map(int, ipywidgets.__version__.split(".")))
            if ipywidgets_version < (7, 5):
                raise ImportError()
    except ImportError:
        print("Please update jupyter and ipywidgets.")

# Generated at 2022-06-12 15:15:01.710079
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 0:  # pragma: no cover
        raise unittest.SkipTest("IPython is not installed.")
    from unittest import TestCase
    from contextlib import ExitStack
    from unittest.mock import patch

    class TestStatusPrinter(TestCase):
        """Test tqdm_notebook.status_printer method."""

        @patch('sys.stdout', new=sys.__stdout__)  # get it back to normal
        def setUp(self):
            self.stack = ExitStack()
            self.addCleanup(self.stack.close)

        def test_status_printer(self):
            """Test if tqdm_notebook.status_printer works as expected."""

            # Test with total

# Generated at 2022-06-12 15:15:09.622845
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    ipywidgets.IntSlider(description="test")  # ensure widget can be displayed
    try:
        ipywidgets.Output()  # ensure widget can be displayed
    except NameError:
        return  # no output widget on IPY<3
    # Unit test for function display method
    with tqdm_notebook(total=1) as t:
        t.display()

    # Unit test for function display method with `msg`
    with tqdm_notebook(total=1) as t:
        t.display(msg="foo")

    # Unit test for function display method with `bar_style`
    with tqdm_notebook(total=1) as t:
        t.display(bar_style='warning')

    # Unit test for function display method with `close`

# Generated at 2022-06-12 15:15:15.407569
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm(total=10, unit='B', desc='Test method clear of class tqdm_notebook', leave=True, disable=False) as pbar:
        for i in range(10):
            pbar.update()
        assert pbar.n == 10
        pbar.clear()
        assert pbar.n == 0
tqdm.clear = test_tqdm_notebook_clear

# Generated at 2022-06-12 15:15:25.362601
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test of `tqdm_notebook.method_update()`
    """
    try:
        from ipywidgets import FloatProgress, HBox
        from IPython.display import display  # NOQA
    except ImportError:
        return None  # skip the test
    test = tqdm_notebook(total=10)
    assert test.container.pbar.max == 10
    test.update(1)
    assert test.container.pbar.value == 1
    test.update(2)
    assert test.container.pbar.value == 3
    test.update()
    assert test.container.pbar.value == 4
    test.update(5)
    assert test.container.pbar.value == 9
    test.update()
    assert test.container.pbar.value == 10


# Generated at 2022-06-12 15:15:33.964794
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Test case 1: iterable
    for _ in tqdm_notebook(range(10)):
        pass

    # Test case 2: iterable with total
    for _ in tqdm_notebook(range(10), total=10):
        pass

    # Test case 3: iterator with total
    for _ in tqdm_notebook(iter(range(10)), total=10):
        pass

    # Test case 4: iterator
    for _ in tqdm_notebook(iter(range(10))):
        pass

# Generated at 2022-06-12 15:15:42.021681
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    with tqdm_notebook(total=10) as pbar:
        assert pbar.displayed
        pbar.display(0, pos=5)
        clear_output(wait=1)
        assert pbar.displayed
        pbar.display(pos=10)
    assert not pbar.displayed


# Unit test
if __name__ == '__main__':
    from .tests import TestTqdmNotebook
    with TestTqdmNotebook(leave=False, desc='test_tqdm_notebook') as t:
        for i in t:
            pass

    with TestTqdmNotebook(leave=True, desc='test_tnrange') as t:
        for i in tnrange(10):
            pass


# Generated at 2022-06-12 15:15:51.462225
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .tests import TestReset
    from .utils import format_sizeof
    from .gui import tqdm
    import sys
    import os

    def trial(cls=tqdm, leave=True, unit_div=None, desc=None, **kwargs):
        total = 10000
        t = cls(total=total, unit_divisor=unit_div, leave=leave,
                desc=desc, **kwargs)
        if desc is not None:
            t.ncols = 50
        with TestReset(t) as b:
            for i in b:
                pass
        if not leave:
            return b.sp(total=total)


# Generated at 2022-06-12 15:16:22.678161
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    t = tqdm_notebook(total=1)
    t.display()  # display once
    t.display()  # make sure it doesn't display again
    assert str(t) == "0/1"
    t.display(msg="Hello World!")
    assert str(t) == "Hello World!"
    t.display(close=True)
    assert str(t) == "Hello World!"
    clear_output()



# Generated at 2022-06-12 15:16:28.686650
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch  # python 2
    with patch('sys.stderr', new=sys.stdout):
        with patch('IPython.display.display') as mock_display:
            with patch('IPython.display.clear_output') as mock_clear_output:
                import warnings
                with warnings.catch_warnings():
                    warnings.filterwarnings(
                        "ignore", message="Widget Javascript not detected.")
                    # Build the widget
                    widget = tqdm_notebook(total=5)
                    mock_display.assert_called_with(widget.container)
                    # Simulate a user interaction (click)
                    widget.container.children[-2].value = 2
                    widget.update(2)

# Generated at 2022-06-12 15:16:31.854777
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Given
    with tqdm_notebook(total=2, leave=False) as t:
        # When
        t.clear()
        # Then
        t.update()  # exception if `print` was called.

# Generated at 2022-06-12 15:16:39.540036
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for unit_scale in True, False, None, 10 ** 10:
        for leave in True, False:
            for disable in True, False:
                bar = tqdm_notebook(range(10), unit_scale=unit_scale, leave=leave,
                                    disable=disable)
                bar.reset()
                total = bar.total

                for total_reset in None, 0, 1, 10:
                    bar.reset(total_reset)
                    assert bar.total == total_reset or unit_scale is True
            # try:
            #     bar.reset(17)
            #     assert bar.total != 17 or unit_scale is True
            # except:
            #     pass

# Generated at 2022-06-12 15:16:46.185554
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tnrange
    from time import sleep

    if True:  # pragma: no cover
        # reset the bar
        bar = tnrange(10, desc='testing', position=0, leave=True)
        for x in bar:
            sleep(0.1)
        assert bar.n == 10
        bar.reset()
        assert bar.n == 0
        for x in bar:
            sleep(0.2)
        assert bar.n == 5
        bar.reset()
        for x in bar:
            sleep(0.4)
        assert bar.n == 3
        bar.reset(total=10)
        for x in bar:
            sleep(0.4)
        assert bar.n == 3
        bar.reset(total=None)  # no progress
        assert bar.n == 3


# Generated at 2022-06-12 15:16:57.236805
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Unit test for class tqdm_notebook.
    """
    from os import getpid
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch
    import warnings

    with warnings.catch_warnings():
        warnings.filterwarnings("ignore", message=r"The 'warn' method is deprecated, use 'warning' instead")

        t = tqdm_notebook(total=100)
        for i in t:
            if i == 1:
                t.close()
            if i == 2:
                t.close()
            if i == 3:
                t.close()

        t = tqdm_notebook(total=100)

# Generated at 2022-06-12 15:17:05.212918
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from io import StringIO
    from sys import stdout
    from unittest import TestCase
    from contextlib import contextmanager

    @contextmanager
    def capture(command, *args, **kwargs):
        out, sys.stdout = sys.stdout, StringIO()
        command(*args, **kwargs)
        sys.stdout.seek(0)
        yield sys.stdout.read()
        sys.stdout = out

    class ProgressBarTest(TestCase):

        @classmethod
        def setUpClass(cls):
            # to test it without a Notebook
            class _Widget(HBox):
                def _repr_json_(self, pretty=None):
                    return {}
            global HBox
            HBox = _Widget


# Generated at 2022-06-12 15:17:07.071315
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tqdm_notebook(total=10)
    for _ in pbar:
        pass
    pbar.reset(total=1000)
    for _ in pbar:
        pass

# Generated at 2022-06-12 15:17:16.053331
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    if IPY == 'off':
        pytest.skip("Skip tqdm_notebook unit tests")

    import IPython
    from IPython.display import clear_output
    from IPython.html.widgets import FloatProgress as IProgress
    from IPython.html.widgets import HBox
    from IPython.html.widgets import HTML
    from IPython.utils.io import capture_output

    try:
        from urllib.parse import quote
    except ImportError:
        from urllib import quote

    # Make sure clear_output is patched
    clear_output()
    # Clean up all IPython progress bars
    delattr(IPython, 'widget_tqdm')
    # Avoid displaying any periodic output

# Generated at 2022-06-12 15:17:21.254653
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    t = tqdm_notebook(total=5)
    for _ in t:
        time.sleep(0.01)
    t.reset()
    assert t.total is None and t.n == 0
    t.reset(10)
    assert t.total == 10 and t.n == 0

    with tqdm_notebook(total=5, leave=False) as t:
        for _ in t:
            time.sleep(0.01)
        t.reset(10)
    # old bar had leave=False, so there should be 2 bars (old + new)
    assert t.total == 10 and t.n == 0


test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:18:21.273915
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert tqdm_notebook([1], disable=True).__iter__() == [1]
    assert list(tqdm_notebook([1], disable=False)) == [1]
    assert list(tqdm_notebook({"a": "1"}, disable=False)) == ["a"]
    assert list(tqdm_notebook({"a": "1"}, disable=False)) == ["a"]

    def foo():
        for i in tqdm_notebook(range(5), disable=False):
            if i == 2:
                raise ValueError("test")
            yield i

    with pytest.raises(ValueError, match="test"):
        list(foo())
    assert list(foo()) == [0, 1, 3, 4]
    assert list(foo()) == [0, 1, 3, 4]



# Generated at 2022-06-12 15:18:26.507972
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=100) as pbar:
        for i in range(20):
            pbar.update(5)
    assert pbar.n == 100
    assert pbar.total == 100
    assert pbar.container.pbar.value == pbar.n
    assert pbar.container.pbar.max == pbar.total
    assert pbar.container.pbar.bar_style == 'success'

# # Unit test for method reset of class tqdm_notebook

# Generated at 2022-06-12 15:18:30.969746
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Check that it doesn't raise an exception
    with tqdm_notebook(total=10, desc='foobar') as pbar:
        pbar.clear()


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-12 15:18:33.838005
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    with tqdm_notebook(total=5) as _:
        pass


if __name__ == '__main__':
    test_tqdm_notebook_close()

# Generated at 2022-06-12 15:18:35.713410
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(total=0, leave=False)
    t.reset(total=0)
    t.reset(total=0)

# Generated at 2022-06-12 15:18:39.053415
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for total in [tqdm_notebook.DEFAULT_TOTAL, 100, None]:
        with tqdm_notebook(total=total) as pbar:
            for i in [1, 2, 3]:
                pbar.update()



# Generated at 2022-06-12 15:18:42.486715
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from tqdm.auto import tqdm

    with tqdm(total=10, leave=False) as pbar:
        for _ in range(10):
            pbar.update(1)
            pbar.write("test")
    assert pbar.n == pbar.total



# Generated at 2022-06-12 15:18:44.932405
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Testing tqdm_notebook"""
    with tqdm_notebook(total=100) as bar1:
        for _ in range(10):
            bar1.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:18:50.648457
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    res = tqdm_notebook.status_printer(sys.stdout, total=10, desc='desc', ncols=50)
    assert type(res) is TqdmHBox
    assert len(res.children) == 3
    assert res.children[0].value == 'desc'
    assert res.children[0].layout.width == 'auto'
    assert res.children[1].layout.width == '50px'
    assert res.children[1].max == 10
    assert res.children[1].value == 0
    assert res.children[2].value == ''
    assert res.children[2].layout.width == 'auto'
    assert res.layout.width == '50px'
    assert res.layout.display == 'inline-flex'
    assert res.layout.flex_flow == 'row wrap'

# Generated at 2022-06-12 15:18:54.350129
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=5) as t:
        assert t.total == 5
        assert t.gui is True
        assert isinstance(t.format_dict, dict)
        assert isinstance(t.format_meter(**t.format_dict), str)
        for _ in range(5):
            t.update()



# Generated at 2022-06-12 15:22:58.541239
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:  # for Python 2
        from HTMLParser import HTMLParser
        unescape = HTMLParser().unescape
    except (AttributeError, ImportError):  # for Python 3
        from html import unescape

    test = TqdmHBox()
    test.pbar = std_tqdm.format_dict_class(
        n=3, total=10, bar_format="{l_bar}{bar}{r_bar}")
    repr_str = repr(test)
    repr_str_pretty = repr(test)
    repr_str_json = test._repr_json_()
    repr_str_json_pretty = test._repr_json_(pretty=True)

# Generated at 2022-06-12 15:23:00.685323
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .gui import tqdm
    for i in tqdm(range(9)):
        assert i in range(9)



# Generated at 2022-06-12 15:23:09.646244
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test reset with leave=False and leave=True
    with tqdm_notebook(total=10, leave=False) as t:
        for i in range(0, 10):
            t.update()
            if i == 5:
                t.reset(leave=False)
    # Test bar style is success after reset with leave=False
    with tqdm_notebook(total=10, leave=False) as t:
        for i in range(0, 10):
            t.update()
            if i == 5:
                t.reset(leave=False)
    # Test bar style is success after reset with leave=True
    with tqdm_notebook(total=10, leave=True) as t:
        for i in range(0, 10):
            t.update()