

# Generated at 2022-06-12 15:13:38.429177
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test for method __iter__ of class tqdm_notebook"""
    # length of the string to generate
    for i in tqdm_notebook(range(1, 5), desc='1st loop'):
        for j in tqdm_notebook(range(1, 5), desc='inner loop'):
            for k in tqdm_notebook(range(1, 5), desc='3rd loop'):
                # total value
                total = 100.0
                # construct similar string
                for _ in tqdm_notebook(range(int(total)),
                                       desc='dynamic range',
                                       unit='B',
                                       unit_scale=True,
                                       leave=True):
                    pass


if __name__ == "__main__":  # pragma: no cover
    test_tqdm_note

# Generated at 2022-06-12 15:13:49.205423
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    def test(pos=None, msg=None, colour=None, display=True):
        # msg='' clears the bar  # NOT ANYMORE
        with tqdm_notebook(total=1, leave=False, disable=False,
                           position=pos, bar_format="{desc}: |{bar}|") as t:
            t.desc = msg or ""
            t.colour = colour
            t.display(msg=msg, colour=colour, display=display)
            sleep(0.1)

    # run the tests
    for s in ["", "hello", "hello world", "foo" * 100, "<bar/>", "<bar/>|"]:
        test(pos=None, msg=s)

# Generated at 2022-06-12 15:13:57.621129
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.utils import _term_move_up
    import time
    # time.sleep(1)
    pbar = tqdm_notebook.status_printer(sys.stderr, 0, "")
    print()
    for i in trange(9, desc='1st loop', leave=True, ncols=20,
                    dynamic_ncols=False):
        print()
        with trange(10, desc='2nd loop', leave=True, ncols=20,
                    dynamic_ncols=False) as pbar:
            for i, j in zip(range(10), trange(10, leave=False, ncols=20,
                                              dynamic_ncols=False)):
                time.sleep(0.01)

# Generated at 2022-06-12 15:14:06.020453
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.notebook import tqdm as tqdm_n
    from tqdm.auto import tqdm

    # Should remain silent
    with tqdm_n(total=None) as nb:
        list(map(nb.update, range(10)))
    with tqdm(total=None) as nb:
        list(map(nb.update, range(10)))

    # Should raise a TqdmTypeError
    with tqdm_n(total=10) as nb:
        list(map(nb.update, range(10)))
        try:
            list(map(nb.update, range(10)))
        except TypeError:
            pass
        else:
            raise AssertionError()

# Generated at 2022-06-12 15:14:10.804056
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        from unittest import mock
    except ImportError:
        import mock

    # mock clear_output and display to test tqdm_notebook.clear
    with mock.patch('IPython.display.clear_output') as clear_output:
        with mock.patch('IPython.display.display') as display:

            # run clear on tqdm_notebook
            with tqdm_notebook(total=100) as pbar:
                pbar.clear()

            # clear_output and display should not be called
            assert not clear_output.called
            assert not display.called

# Generated at 2022-06-12 15:14:21.916028
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    class ExceptionMock(Exception):
        pass

    class MyTqdm(tqdm_notebook):
        """
        Mock class of tqdm_notebook
        """
        def __init__(self, *args, **kwargs):
            super(MyTqdm, self).__init__(*args, **kwargs)
            self.iter_called = 0
            self.update_called = 0
            self.display_called = 0
            self.close_called = 0
            self.raise_next_update = False

        def __iter__(self):
            self.iter_called += 1
            for obj in super(MyTqdm, self).__iter__():
                yield obj

        def update(self, n=1):
            self.update_called += 1

# Generated at 2022-06-12 15:14:30.401384
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test tqdm_notebook.status_printer

    """
    try:
        import unittest.mock as mock
    except ImportError:
        import mock

    with mock.patch('IPython.display.display') as _display:
        with mock.patch('IPython.display.clear_output') as _clear_output:
            try:
                from tqdm.notebook import tqdm_notebook, tqdm as tqdm_std
            except ImportError:
                return 0
            tqdm_notebook.status_printer(None)
            tqdm_notebook.status_printer(None, 100)
            tqdm_notebook.status_printer(None, 100, 'desc')

# Generated at 2022-06-12 15:14:38.487493
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.auto import tqdm
    for GUI in [tqdm_notebook, tqdm]:  # tqdm, tqdm_notebook
        try:
            from unittest.mock import patch
            from unittest.mock import MagicMock
        except:  # pragma: no cover
            from mock import patch
            from mock import MagicMock
        with patch('IPython.display.display') as mock_display, \
                patch('IPython.display.clear_output') as mock_clear_output:

            mock_display.return_value = MagicMock()
            mock_clear_output.return_value = MagicMock()

            progress_bar = GUI(total=10)

            progress_bar.display()

            assert mock_display.called is True
            assert mock_clear_output

# Generated at 2022-06-12 15:14:42.613697
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from nose.tools import assert_equal
    from ipywidgets import jsdlink
    with tqdm_notebook(total=5) as t:
        for i in range(5):
            t.update()



# Generated at 2022-06-12 15:14:48.611584
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tqdm_gui, tqdm_notebook
    from time import sleep
    for cls in [tqdm_notebook, tqdm_gui]:
        with cls(total=10, desc='A', file=None, disable=False) as pbar:
            # Test update and refresh
            for _ in range(5):
                sleep(1e-2)
                pbar.update(1)
            # Test write
            msg = "test"
            pbar.write(msg)
            assert msg in pbar.container.children[-1].value
            # Test close
            pbar.close()

# Generated at 2022-06-12 15:15:09.210157
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    status_printer = tqdm_notebook.status_printer

    # Empty config should return immediately
    # assert status_printer(None, None) is None
    assert status_printer(None, None, None, 10) is None
    assert status_printer(None, None, None, ncols=10) is None

    # Testing with a positive total
    hbox = status_printer(None, 1, None, ncols=10)
    assert isinstance(hbox, HBox)
    assert len(hbox.children) == 3
    assert hbox.children[0].__class__ == HTML

    # Testing with a negative total
    hbox = status_printer(None, -1, None, ncols=10)
    assert isinstance(hbox, HBox)

# Generated at 2022-06-12 15:15:19.530013
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from ipywidgets import FloatProgress as IProgress
    except ImportError:  # IPython 2.x
        from IPython.html.widgets import FloatProgressWidget as IProgress
    from IPython.display import DisplayHandle
    from time import sleep

    # Create a tqdm object
    t = tqdm_notebook(total=5)

    # Assert a warning is raised if the IPython display (from `from tqdm import tqdm`)
    # is not the one from tqdm_notebook (from `from tqdm.notebook import tqdm`)

# Generated at 2022-06-12 15:15:28.252803
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    from io import StringIO
    from IPython.core.ultratb import AutoFormattedTB

    # dummy file-like to replace sys.stderr
    class DummyFile(StringIO):
        def write(self, s):
            pass

    def test_filter_tb(tb):  # pragma: no cover
        # In IPython 5+, the ipywidgets module creates a global display hook
        # that adds HTML formatting to the traceback (spans and inline images).
        # Here we remove the formatting, so that the traceback can be
        # compared to the expected traceback
        tb_lines = tb.splitlines()

# Generated at 2022-06-12 15:15:32.339769
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    from random import random
    with tqdm_notebook(total=4) as t:
        for i in range(4):
            sleep(random())
            t.update()



# Generated at 2022-06-12 15:15:41.046038
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(total=None)
    t.write('message')
    assert t.total is None
    assert t.n < t.total
    t.reset()
    assert t.total is None
    assert t.n == 0

    t = tqdm_notebook(total=10)
    t.write('message')
    assert t.total == 10
    assert t.n < t.total
    t.reset()
    assert t.total == 10
    assert t.n == 0

    t = tqdm_notebook(total=None)
    t.write('message')
    assert t.total is None
    assert t.n < t.total
    t.reset(total=10)
    assert t.total == 10
    assert t.n == 0



# Generated at 2022-06-12 15:15:46.521782
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Test method status_printer of class tqdm_notebook """
    from IPython.display import HTML

    container = tqdm_notebook.status_printer(None, total=None, desc=None)
    assert isinstance(container, HBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)

# Generated at 2022-06-12 15:15:55.077542
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # test_module_imported is called in main of test_tqdm.
    # It will set `tqdm` as `tqdm.std.tqdm` instead of `tqdm.tqdm_notebook_imported.tqdm_notebook`
    # thus we need to import the standard tqdm here.
    from .std import tqdm
    from .std import trange
    from .utils import format_sizeof

    # test clear by iterable
    for n in trange(5, desc='1st loop'):
        for i in range(1000):
            pass
    for n in trange(5, desc='2nd loop'):
        for i in range(1000):
            pass

    # test clear by manual update

# Generated at 2022-06-12 15:15:58.812720
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Tests the tqdm_notebook constructor.
    """
    try:
        with tqdm_notebook(total=100) as t:
            assert t.n == 0
            t.update()  # increment t.n
            assert t.n == 1
    except NameError:
        # tqdm_notebook not installed
        pass

# Generated at 2022-06-12 15:16:05.617344
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IProgress is None:
        return
    filler = '*' * 10
    dummy = tqdm_notebook(total=5, file=sys.stdout, desc=filler)
    container = dummy.status_printer(file=sys.stdout)
    pbar = container.children[1]
    ltext = container.children[0]
    rtext = container.children[2]
    # initial state
    assert ltext.value == filler
    assert rtext.value == ''
    rtext.value = 'text'
    assert rtext.value == 'text'
    # update
    dummy.display(msg='text')
    assert ltext.value == filler
    assert rtext.value == 'text'
    dummy.display(close=True)
    assert ltext.value == filler
    assert rtext

# Generated at 2022-06-12 15:16:11.004519
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    try:
        from IPython.display import clear_output
    except ImportError:
        def clear_output(*_, **__):
            pass  # NOQA: E701

    with tqdm_notebook(total=10, desc='1st loop') as pbar:
        for i in range(10):
            pbar.display()
            time.sleep(0.01)
            pbar.set_description("1st loop (done %i/10)" % (i + 1))
            pbar.set_postfix(ordered_dict(x=(5 - i) ** 2, y=''))

    with tqdm_notebook(total=10, desc='2nd loop') as pbar:
        # Set bar colour to green at the start
        pbar.colour = 'green'
       

# Generated at 2022-06-12 15:16:43.850716
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # with closing(tqdm_notebook(total=0)) as t:
    with tqdm_notebook(total=0) as t:
        pass
    # with closing(tqdm_notebook(total=0, position=1)) as t:
    with tqdm_notebook(total=0, position=1) as t:
        pass
    # with closing(tqdm_notebook(total=1)) as t:
    with tqdm_notebook(total=1) as t:
        pass
    try:
        # t = tqdm_notebook(total=0, leave=False, miniters=1)
        t = tqdm_notebook(total=0, leave=False, miniters=1)
        with t:
            pass
    finally:
        t.close

# Generated at 2022-06-12 15:16:49.511172
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    import time
    import numpy as np
    from datetime import timedelta

    progress = tqdm_notebook.status_printer(None)
    for i in range(10):
        progress.value = i
        time.sleep(0.01)
    progress.value = 10
    progress.close()



# Generated at 2022-06-12 15:16:54.811483
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test method `__iter__` of class `tqdm_notebook`.
    Makes sure the class `tqdm_notebook` is able to iterate.
    """
    import sys

    # Test iterating with `tqdm_notebook`
    for _ in tqdm_notebook(range(10), file=sys.stdout):
        pass



# Generated at 2022-06-12 15:17:03.951299
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import monotonic
    from tqdm.auto import tqdm

    time_to_wait = 0.2

    # Does not return anything
    tqdm(total=1, unit='s')

    start = monotonic()
    # Test that update() is not blocking
    with tqdm(total=time_to_wait, unit='s') as pbar:
        while monotonic() - start < time_to_wait:
            pbar.update(0.1)

    # Newline tests
    with tqdm(total=1, unit='s', file=sys.stdout) as pbar:
        pbar.update(1)
    print("")

# Generated at 2022-06-12 15:17:08.735101
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """ Unit tests for the reset method of the tqdm_notebook class """
    # Check that reset works, only when a total was given
    with tqdm_notebook(total=100, leave=True) as t:
        t.update(20)
        t.reset(total=None)
        t.update(10)
        t.reset()
        t.update(10)
        t.reset(total=50)
        t.update(5)
        t.reset(total=10)
        t.update(5)
        t.reset(total=None)
        t.update(5)



# Generated at 2022-06-12 15:17:11.180167
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=5) as pbar:
        for i in range(5):
            pbar.display(pos=i)
            time.sleep(0.1)


# Generated at 2022-06-12 15:17:15.748461
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from tqdm.auto import tqdm
    for progressbar_cls in [tqdm, tqdm_notebook]:
        try:
            with progressbar_cls(total=0) as pbar:
                # test that pbar.close() doesn't throw an exception
                pbar.close()
        finally:
            tqdm.close()  # clean up to prevent RuntimeError


del absolute_import, division, print_function
del escape, re, sys, warnings

# Generated at 2022-06-12 15:17:16.614227
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tnrange(0)

# Generated at 2022-06-12 15:17:18.183370
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(10), desc="test__iter__"):
        assert i in range(10)



# Generated at 2022-06-12 15:17:19.482466
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(10)):
        assert True



# Generated at 2022-06-12 15:17:48.558238
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=4) as t:
        t.update(1)
        t.update(1)
        t.update(1)
        t.update(1)
    assert t.n == 4

test_tqdm_notebook_update()

# Generated at 2022-06-12 15:17:52.446885
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_instance = tqdm_notebook()
    tqdm_notebook_instance.total = None
    tqdm_notebook_instance.reset(total = 1000);
    assert tqdm_notebook_instance.total == 1000

# Generated at 2022-06-12 15:18:00.394569
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import StringIO
    from random import random
    try:
        from IPython import get_ipython
        ip = get_ipython()
        if not ip:
            raise ImportError('Not in an IPython Notebook')
    except ImportError:
        raise ImportError(
            "Notebook testing requires IPython Notebook to be installed")

    # Test the usual case: no error
    ip.run_cell("bar = tqdm_notebook(range(10))")
    ip.run_cell("for i in bar:")
    ip.run_cell("    bar.update()")
    ip.run_cell("bar.close()")

    # Test the usual case: error occurs
    ip.run_cell("bar = tqdm_notebook(range(10))")

# Generated at 2022-06-12 15:18:06.218965
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import clear_output
    for total in [None, 20]:
        for bar_style in [None, 'info']:
            for ncols in [None, 100, "100px", "100%"]:
                file = sys.stdout  # avoid the red block in IPython
                pbar = tqdm_notebook.status_printer(
                    file, total, desc='bar_style %r' % bar_style, ncols=ncols)
                if total:
                    assert pbar.max == total
                else:
                    assert pbar.bar_style == bar_style
                if ncols is not None:
                    # ncols could be 100, "100px", "100%"
                    ncols = str(ncols)  # ipywidgets only accepts string

# Generated at 2022-06-12 15:18:16.338074
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""

# Generated at 2022-06-12 15:18:24.919684
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        from IPython.display import clear_output
    except ImportError:
        return None
    import time

    for progress in (tqdm, tqdm_notebook,):
        with progress(total=1) as p:
            p.display()
            clear_output(wait=True)
            p.reset()
            p.reset(total=1)
            p.reset(total=100)
            p.reset()

        with progress(total=1) as p:
            p.display()
            p.reset()
            p.display()
            p.reset(total=1)

        with progress(total=1) as p:
            p.display()
            p.update(1)
            p.reset()
            p.display()
            p.reset(total=1)


# self-

# Generated at 2022-06-12 15:18:31.283573
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.utils import _term_move_up
    from unittest import TestCase

    class TestDisplay(TestCase):
        def test_display(self):
            pbar = tqdm_notebook(total=1)
            d = pbar.format_dict
            d['bar'] = "<bar/>"  # replace {bar} since not defined with IPyW
            pbar.display(pbar.format_meter(**d))
            self.assertTrue("<bar/>" in pbar.container.children[0].value)
            self.assertEqual(pbar.container.children[1].value, 0)
            self.assertTrue("/ 1" in pbar.container.children[2].value)

            d = pbar.format_dict
            d['bar'] = "<bar/>"  # replace {

# Generated at 2022-06-12 15:18:40.309250
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from random import random
    pbar = tqdm(total=100, ncols=100, bar_format='{l_bar:20.5}  |  {n_fmt}/{total_fmt}')
    pbar.display(pos=0, bar_style='success')
    sleep(1)
    try:
        pbar.display(pos=0, bar_style='danger', msg='error')
        assert False, "Code should have failed!"
    except:
        sleep(1)
    pbar.display(pos=0, bar_style='info', msg='')
    sleep(1)
    pbar.display(pos=0, msg='')

    for i in pbar:
        i /= 100 * random()
        pbar.display(pos=i)

# Generated at 2022-06-12 15:18:42.359207
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    with tqdm(total=10) as pbar:
        for i in pbar:
            time.sleep(0.1)



# Generated at 2022-06-12 15:18:46.673871
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Test case for method update of class tqdm_notebook."""
    with std_tqdm(0) as t:
        assert not t.disable
        assert t.n == 0
        assert t.last_print_n == 0
        assert not t.displayed

        t.n = 42
        t.__dict__.update(n=43)
        t.update()
        assert t.n == 44
        assert t.last_print_n == 44


# Test for method reset of class tqdm_notebook

# Generated at 2022-06-12 15:19:18.666505
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method display of class tqdm_notebook
    """
    tqdm_notebook.display()
    pbar = tqdm_notebook(total=10)
    try:
        for _ in pbar:
            pbar.display(msg='{0}/{1}'.format(pbar.n, pbar.total),
                         bar_style='info')
            pbar.display(msg='test {0}'.format(pbar.format_dict))
            pbar.display(msg=pbar.format_dict)
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-12 15:19:20.808852
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Absolute minimal test to make sure at least nothing raises.
    """
    msg = tqdm_notebook.status_printer(None)
    msg.update(1)


# Generated at 2022-06-12 15:19:24.144232
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test method reset"""
    from time import sleep
    t = tqdm_notebook(total=100, leave=True)
    for i in range(20):  # will be interrupted
        sleep(0.01)
        t.update()
    t.reset()  # reset
    for i in range(20):  # will finish successfully
        sleep(0.01)
        t.update()

# Generated at 2022-06-12 15:19:31.427378
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .tests import TqdmTestCase, pretest_posttest
    from .gui import tqdm

    class TqdmNotebookResetTest(TqdmTestCase):

        @pretest_posttest
        def test_notebook_reset(self):
            """Tests reset with tqdm_notebook"""
            with tqdm(total=4) as t:
                for i in range(3):
                    t.update()
                self.assertTrue(t.n < t.total)
                t.reset(total=2)
                self.assertTrue(t.n == 0)

    return TqdmNotebookResetTest().test_notebook_reset()


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:19:34.767425
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(list(range(10)))
    t.display(0, 0)
    t.display(1, 1)
    t.display(3, 3)
    t.container.children[-2].bar_style = 'success'

# Generated at 2022-06-12 15:19:39.298127
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Check that `update()` works as expected"""
    t = tqdm_notebook(list(range(3)))
    assert len(t) == 3
    t.update(2)
    assert t.n == 2
    t.update(2)  # should fail without throwing an exception


if __name__ == "__main__":
    from doctest import testmod
    testmod()

# Generated at 2022-06-12 15:19:41.470143
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=9, desc='test') as pbar:
        pbar.reset(total=6)
        for i in range(6):
            pbar.update()

# Generated at 2022-06-12 15:19:49.695633
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Tests that the status printer of the tqdm_notebook instance
    returns a widget displaying the correct information
    """
    from IPython.display import display

    # Setup tqdm_notebook instance
    t = tqdm_notebook(total=100, desc="Tqdm")
    # Get widget
    t.displayed = True
    widget = t.status_printer(None, 100, "Tqdm")
    display(widget)

    # Test initial value
    assert widget.children[1].value == 0

    # Test update
    t.update(10)
    assert widget.children[1].value == 10

    # Test update after closing
    t.close()
    t.update(10)
    assert widget.children[1].value == 10

    # Test reset
    t.reset()
   

# Generated at 2022-06-12 15:19:56.562267
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Test method status_printer of class tqdm_notebook"""
    from IPython.display import clear_output

    tqdm_notebook.status_printer('', 999)
    tqdm_notebook.status_printer('', 999, 'Foo')
    tqdm_notebook.status_printer('', 999, 'Foo', ncols=100)

    tqdm_notebook.status_printer('', 999, 'Foo', ncols='10%')
    tqdm_notebook.status_printer('', 999, 'Foo', ncols='10px')
    tqdm_notebook.status_printer('', 999, 'Foo', ncols='0%')

# Generated at 2022-06-12 15:20:04.291329
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from IPython import get_ipython
    from tqdm.auto import tqdm as tqdm_auto

    ip = get_ipython()

    # Test if update() is broken when disable=True
    for t in [tqdm, tqdm_notebook, tqdm_auto]:
        pbar = t(10, disable=True)
        for _ in range(10):
            pbar.update()
        pbar.close()

    # Test if update() and reset() are idempotent
    pbars = [tqdm(10), tqdm_notebook(10), tqdm_auto(10)]
    for pbar in pbars:
        pbar.update()
        pbar.reset(1)
        pbar.update()