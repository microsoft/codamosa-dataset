

# Generated at 2022-06-12 15:13:21.821833
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=9, leave=True, disable=False) as t:
        for i in range(5):
            t.display(msg=str(i))
        t.display(msg='', bar_style='success')
        t.display(close=True)

if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:13:28.782090
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """Tests that tqdm_notebook close() does not hide bar
    when error occurs in manual mode (n < total)"""
    with tqdm_notebook(total=10) as t:
        assert t.container.visible
        t.update(1)
        t.close()
        assert not t.container.visible

    with tqdm_notebook(total=2) as t:
        assert t.container.visible
        t.update(1)
        try:
            raise Exception
        except:  # NOQA
            t.close()
            assert t.container.visible

# Generated at 2022-06-12 15:13:33.488234
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from unittest import TestCase, main
    import sys

    class Tests(TestCase):
        def test_instantiation(self):
            r = tqdm_notebook(range(10), file=sys.stdout)
            r.close()

    main(argv=[''], verbosity=2, exit=False)


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook()

# Generated at 2022-06-12 15:13:36.240596
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=10, leave=True, miniters=2, maxinterval=0.1)
    for i in range(10):
        t.update()
    t.close()

# Generated at 2022-06-12 15:13:47.260800
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import HTML, clear_output
    from IPython.core import display
    import time
    import sys

    # Clear previous output (really necessary?)
    clear_output()

    container = TqdmHBox()
    ltext = HTML()
    rtext = HTML()
    container.children = (ltext, IProgress(), rtext)
    container.layout.width = "50px"
    display(container)

    for i in range(5):
        rtext.value = str(i)
        time.sleep(0.2)

        # Clear previous output
        clear_output()
        display(container)

    rtext.value = "Done"

# Generated at 2022-06-12 15:13:51.185327
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .utils import free_position
    from IPython.display import clear_output

    with free_position(position=4):
        pbar = tqdm_notebook(total=4)
        pbar.update()  # 0%
        for _ in range(4):
            pbar.update()
        pbar.close()
        clear_output()



# Generated at 2022-06-12 15:14:00.182958
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import ipykernel

    # Short test
    t = tqdm_notebook(total=10)
    display(t.container)
    t.update()
    t.close()
    return

    # Full test (manual)
    t = tqdm_notebook(total=10)
    t.display(check_delay=False)

# Generated at 2022-06-12 15:14:08.209912
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.utils.capture import capture_output
    import io
    import re

    with capture_output() as captured:
        with tqdm_notebook(total=100) as pbar:
            for i in range(50):
                # Print description
                pbar.set_description('DEsc')
                pbar.set_description_str('Besc')
                # Print postfix
                pbar.set_postfix(OrderedDict([
                    ('loss', '%.3f' % (i / 2.)),
                    ('acc', '%d' % (i * 10)),
                    ('acc2', '%.f' % (i * 10)),
                    ('a%c', '%.f' % (i * 10)),
                ]))

# Generated at 2022-06-12 15:14:14.874025
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Testing tqdm_notebook(range(5))
    bar = tqdm_notebook(range(5))
    for i, obj in enumerate(bar):
        time.sleep(0.2)
        assert i == obj

    # Testing tqdm_notebook(range(5)) with catch/raise
    bar = tqdm_notebook(range(5))
    for i in bar:
        time.sleep(0.2)
        if i >= 3:
            raise Exception()

    # Testing tqdm_notebook(itertools.count())
    bar = tqdm_notebook(itertools.count())
    for i, obj in enumerate(bar):
        time.sleep(0.2)
        assert i == obj
        if i >= 5:
            break

    # Testing tqdm

# Generated at 2022-06-12 15:14:24.168897
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Check with total
    pbar = tqdm_notebook.status_printer(None, 10, 'testing')
    _, pbar, _ = pbar.children
    assert pbar.min == 0
    assert pbar.max == 10
    # Check without total
    pbar = tqdm_notebook.status_printer(None, total=0, desc='testing')
    _, pbar, _ = pbar.children
    assert pbar.bar_style == 'info'


# Run self-test if executed directly
if __name__ == '__main__':
    test_tqdm_notebook_status_printer()
    print('Self Test: passed all tests')

# Generated at 2022-06-12 15:14:37.448036
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    t = tqdm_notebook(total=1)
    t.close()


# Generated at 2022-06-12 15:14:46.818791
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import randint
    from time import sleep
    from pytest import approx
    # tqdm_notebook will change to tqdm in the future
    # some tests are already placed to the end of this README file
    from tqdm.notebook import tqdm_notebook

    # test manual update
    t = tqdm_notebook(total=100, leave=True)
    for i in range(5):
        t.update()
        sleep(0.01)
    t.close()
    assert t.n == 5

    # test manual update with random interval
    t = tqdm_notebook(total=100, leave=True)
    for i in range(5):
        t.update(randint(1, 5))
        sleep(0.01)
    t.close()
    assert t

# Generated at 2022-06-12 15:14:53.145906
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from collections import namedtuple
    from operator import attrgetter
    from copy import copy

    tqdm_notebook.display.clear()

    # Test display of tqdm(0)
    expected = (
        namedtuple('expected', 'value bar_style')(
            attrgetter('value'),
            attrgetter('bar_style'))
    )

# Generated at 2022-06-12 15:14:58.153961
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        import IPython.display
        IPython.display.clear_output = lambda: None
    except ImportError:
        pass
    try:
        import ipywidgets
        ipywidgets.HBox().clear_output = lambda: None
        ipywidgets.FloatProgress().clear_output = lambda: None
    except ImportError:
        pass
    t = tqdm_notebook(total=5)
    for i in t:
        pass
    t.clear()
    t.close()

# Generated at 2022-06-12 15:15:05.941666
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for leave in [True, False]:
        for total, n in [
                (None, None),
                (None, 4),
                (4, 4)]:

            with tqdm_notebook(total=total, leave=leave) as pbar:
                if n is not None:
                    for _ in range(n):
                        pbar.update()


# Use the tqdm_notebook class as the tqdm default class
# (use tqdm_gui(tqdm_class=tqdm_notebook) to achieve the same effect)
tqdm.tqdm = tqdm_notebook
tqdm.tnrange = tnrange
tqdm.trange = trange

# Generated at 2022-06-12 15:15:08.316653
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    l = [i for i in range(100)]
    for _ in tqdm_notebook(l):
        if _ == 10:
            raise Exception("Error")
        if _ == 20:
            break

# Generated at 2022-06-12 15:15:17.098699
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Tests method __iter__ of class tqdm_notebook.
    """
    # check if __iter__ works with HBox and iterable
    _h = tqdm_notebook(_range(5))
    for __ in _h:
        pass
    assert isinstance(_h.container, HBox)
    _h.close()

    # check if __iter__ works with HBox and iterable
    try:
        _h = tqdm_notebook(_range(5))
        raise Exception("Exception raising test")
    except:  # NOQA
        pass
    assert isinstance(_h.container, HBox)
    _h.close()



# Generated at 2022-06-12 15:15:23.894645
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    for i in tnrange(6, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            sleep(0.01)
        tnrange.reset()
        assert j == 99  # tnrange hasn't really been reset.
        tnrange.refresh()


if __name__ == '__main__':
    try:
        test_tqdm_notebook_reset()
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-12 15:15:27.388603
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from doctest import run_docstring_examples as dtest
    dtest(tqdm_notebook.status_printer, globals(), name="tqdm_notebook")


# Generated at 2022-06-12 15:15:33.745501
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in tqdm_notebook(range(10)):
        if i == 3:
            tqdm_notebook.update(1)
        if i == 5:
            tqdm_notebook.update()
        if i == 7:
            tqdm_notebook.update(1e2)
        if i == 8:
            tqdm_notebook.update(-1)


# Generated at 2022-06-12 15:15:53.391615
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """test if method close of class tqdm_notebook works fine"""
    # test if close can be called without calling other methods before
    tqdm_notebook(total=0).close()
    # test if close can be called after updating to total
    tqdm_notebook(total=1).update(1).close()
    # test if close can be called after updating less than total
    tqdm_notebook(total=2).update(1).close()
    # test if close can be called after resetting the total
    assert tqdm_notebook(total=1).reset(total=1).update(1).close()
    # test if close can be called without calling reset
    assert tqdm_notebook(total=1).update(1).close()

# Generated at 2022-06-12 15:15:58.737484
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Test case for method __iter__ of class tqdm_notebook.
    """
    iterable = tqdm_notebook([1, 2, 3, 4], desc='test')
    assert iter(iterable) is iterable
    try:
        for _ in iterable:
            pass
    except: # noqa
        iterable.disp(bar_style='danger')
        raise
    finally:
        if iterable.desc:
            iterable.disp(close=True)

# Generated at 2022-06-12 15:16:05.589823
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import format_sizeof
    from .utils import format_interval
    import time

    for i, _ in tqdm_notebook(enumerate(range(4)), total=4,
                              desc="test", leave=None,
                              bar_format="{l_bar}{bar}{r_bar}"):
        time.sleep(.5)
    with tqdm_notebook(total=10, desc='test') as t:
        for i in range(10):
            t.set_postfix(memory=format_sizeof(123456789),
                          refresh=format_interval(i),
                          foo=format_interval(10 - i))
            t.update()
            time.sleep(.1)

# Generated at 2022-06-12 15:16:11.004541
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm._utils import _term_move_up
    from time import sleep

    ipy = get_ipython()  # noqa
    if ipy is None:
        return

    def print_newline():
        print("")

    if sys.stderr.isatty():
        print_newline()
        sys.stderr.write(_term_move_up())
        sys.stderr.flush()
    else:
        pass

    pbar = tqdm_notebook(range(5))
    for i in iter(pbar):
        sleep(0.5)
        if i >= 1:
            pbar.postfix = {'c': 'c', 'b': 'b', 'a': 'a'}

# Generated at 2022-06-12 15:16:16.506505
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    b = TqdmHBox()
    assert b.__repr__() == '|       | 0/0 <...>'
    b.pbar = TqdmHBox()
    b.pbar.n = 5
    b.pbar.total = 10
    assert b.__repr__() == '|##     | 5/10 <...>'
    assert b.__repr__(True) == '|##     | 5/10 <...>'
    b.pbar.n = 10
    assert b.__repr__() == '|##########| 10/10 <...>'
    assert b.__repr__(True) == '|##########| 10/10 <...>'
    b.pbar.n = 5
    b.pbar.total = None
    assert b.__repr__

# Generated at 2022-06-12 15:16:18.965815
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    '''
    If there is no error raised when running this function,
    it means the clear function of class tqdm_notebook does not work.
    '''
    with tqdm_notebook(total=1) as pbar:
        pbar.clear()
        pbar.update()


# Generated at 2022-06-12 15:16:21.586132
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep
    for i in tqdm_notebook(range(1, 20)):
        sleep(0.1)
        if not i % 5:
            raise ValueError("Raising a ValueError for testing exception"
                             " management in iterable tqdm")



# Generated at 2022-06-12 15:16:27.492007
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """This is a test for function TqdmHBox.__repr__()."""
    import pdb
    my_format_dict = {
        "bar_format": "{l_bar}...{bar}...{r_bar}",
        "l_bar": '[',
        "bar": '=',
        "r_bar": ']',
        "n": 5,
        "total": 25,
        "rate": '0.25s',
        "unit": 'it',
        "postfix": {'a': 12, 'b': 34}}
    my_TqdmHBox = TqdmHBox()
    my_TqdmHBox.pbar = std_tqdm(**my_format_dict)
    my_TqdmHBox._repr_json_()
    my_Tq

# Generated at 2022-06-12 15:16:37.329973
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():  # pragma: no cover
    from .tqdm import __version__
    from .utils import format_sizeof, format_interval
    from .std import tqdm
    try:
        import IPython
    except ImportError:
        return
    bar = tqdm.tqdm_notebook(total=10, unit='MiB', unit_scale=True)
    bar.n = 9
    bar.refresh()
    d = bar.format_dict  # get formatted data
    assert d['unit'] == 'MiB'
    assert d['rate'].endswith('B/s')
    assert int(float(d['rate'][:-3])) == d['n'] // d['elapsed']
    assert int(float(d['rate'][:-4])) == d['n'] // d['elapsed']

# Generated at 2022-06-12 15:16:39.096137
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    t = tqdm_notebook(total=100)
    t.update(50)



# Generated at 2022-06-12 15:17:01.891504
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    print('Testing tqdm_notebook.status_printer()')
    total = 1234
    desc = 'hello'
    ncols = 30
    hbox = tqdm_notebook.status_printer(tqdm_notebook.fp,
                                        total=total,
                                        desc=desc,
                                        ncols=ncols)
    assert len(hbox.children) == 3
    assert isinstance(hbox, TqdmHBox)
    assert isinstance(hbox.children[1], IProgress)
    assert isinstance(hbox.children[0], HTML)
    assert isinstance(hbox.children[2], HTML)
    assert hbox.children[1].max == total


# Generated at 2022-06-12 15:17:07.057499
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.html.widgets import Text
    from IPython.html.widgets import IntSlider
    from IPython.html.widgets import DOMWidget
    from IPython.html.widgets import ContainerWidget
    from IPython.html.widgets import HBox
    from IPython.html.widgets import VBox
    # Test with total
    tqdm_notebook.status_printer(None, total=1000)
    # Test without total (should return an info styled progress bar)
    tqdm_notebook.status_printer(None)
    tqdm_notebook.status_printer(None, total=None)
    # Test with specified ncols
    tqdm_notebook.status_printer(None, total=1000, ncols=100)
    tqdm_notebook.status

# Generated at 2022-06-12 15:17:16.018150
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm import _tqdm_notebook
    from datetime import timedelta
    from time import sleep

    with _tqdm_notebook(total=2, unit_scale=True, unit='iB', leave=True) as pbar:
        sleep(0.01)
        pbar.update(1)
        sleep(0.02)
        pbar.update(2)

    with _tqdm_notebook(total=2, unit_scale=True, unit='iB', leave=True,
                        mininterval=0.1) as pbar:
        sleep(0.1)
        pbar.update(1)
        sleep(0.2)
        pbar.update(2)


# Generated at 2022-06-12 15:17:23.367243
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import sys
    import time
    import copy

    t = tqdm_notebook(total=100, desc='foo',
                      unit='b', unit_scale=True, unit_divisor=1000, ascii=True)
    assert(t.format_dict['rate'] == '0.00')
    for i in t:
        pass
    t.reset(total=100, desc='bar',
            unit='b', unit_scale=True, unit_divisor=1000, ascii=True)
    for i in t:
        pass
    t.close()


if __name__ == "__main__":
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:17:32.130039
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import sys
    from tqdm.notebook import tqdm
    if sys.version_info.major == 3:  # Python 3
        from tqdm.contrib.test_tqdm_notebook_update import TestUpdateWrapper
        TestUpdateWrapper.run_test(tqdm)
    elif sys.version_info.major == 2:  # Python 2
        from tqdm.contrib_stress_tests import TestUpdateWrapper
        TestUpdateWrapper.run_test(tqdm)


if __name__ == '__main__':
    from json import dumps as jdumps
    from time import sleep

# Generated at 2022-06-12 15:17:40.721570
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(range(3), total=3)
    for i in bar:
        if i == 2:
            bar.reset(total=1)
            assert bar.total == 1

if __name__ == "__main__":
    # Unit tests
    from pytest import approx
    test_tqdm_notebook_reset()

    import time

    # Test bar display
    for i in trange(3, desc='1st loop'):
        for j in trange(5, desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop'):
                time.sleep(0.01)
        time.sleep(0.1)

    # Test initial and total reset
    total = 2*10

# Generated at 2022-06-12 15:17:44.311392
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.contrib.test import skip_if_no_IPython

    skip_if_no_IPython()

    from IPython.display import display

    t = tqdm(list(range(10)), ncols=20)
    t.update()
    display(t.container)
    t.display()
    t.update()
    t.update()
    t.close()



# Generated at 2022-06-12 15:17:49.736381
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from time import sleep

    def iterrange(n):
        for i in range(n):
            sleep(0.01)
            yield i

    orig_instances = tqdm_notebook.instances
    tqdm_notebook.clear_instances()
    try:
        with tqdm_notebook(iterrange(10)) as t:
            try:
                for i in t:
                    pass
            except:  # noqa
                pass
        with tqdm_notebook(iterrange(10)) as t:
            try:
                for i in t:
                    pass
            except:  # noqa
                pass
    finally:
        tqdm_notebook.instances = orig_instances
        tqdm_notebook.clear_instances()



# Generated at 2022-06-12 15:17:54.640642
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    class DummyException(Exception):
        pass
    # zmq.error.ZMQError is hard to raise
    try:
        import zmq
    except ImportError:
        zmq = DummyException

    for i, e in enumerate([Exception, KeyboardInterrupt, SystemExit, zmq.error.ZMQError]):
        t = tqdm_notebook(total=10)
        assert t._total == 10  # can't set t.total, only as a parameter
        with t:
            if i == 0:
                # Testing exception in tqdm update method
                try:
                    t.update()
                    t.update(10)  # always true (no exception currently)
                except Exception:
                    pass

# Generated at 2022-06-12 15:17:59.207590
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from IPython import get_ipython
        get_ipython()
        hbox = tqdm_notebook()
        hbox.close()
        hbox = tqdm_notebook(total=10, leave=False)
        hbox.close()
        from IPython.display import clear_output
        clear_output(wait=True)
    except ImportError:
        pass



# Generated at 2022-06-12 15:18:21.619332
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # test update display in ipython notebook
    a = tqdm_notebook(["a", "b", "c", "d"])
    for i in "abcd":
        a.update()
    a.close()

# Generated at 2022-06-12 15:18:26.299680
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from IPython.display import clear_output
        from IPython.html.widgets import Button
    except ImportError:
        raise unittest.SkipTest

    def _test(desc=""):
        with tqdm(total=4, desc=desc) as bar:
            for i in bar:
                pass
        clear_output()

    _test()
    _test("{desc}: {n}")



# Generated at 2022-06-12 15:18:36.533642
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Tests for `tqdm.notebook.tqdm(...).clear()`.
    """
    from os import getpid
    from random import random
    from time import sleep

    # tqdm.notebook bugs
    with tqdm_notebook(total=10,
                       desc="testing clear method") as pbar:
        for _ in range(10):
            pbar.clear()
            sleep(0.5)  # let's watch
    pbar.clear()  # if this call fails, it will raise an exception
    bar2 = tqdm_notebook(desc="testing clear method")
    bar2.clear()  # if this call fails, it will raise an exception


# Generated at 2022-06-12 15:18:41.896458
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output  # NOQA

    from time import sleep
    from tqdm import trange
    for _ in trange(4, desc='1st loop'):
        for _ in trange(5, desc='2nd loop', leave=True):
            sleep(.2)
            clear_output(wait=True)
            sleep(.2)
        sleep(.2)


if __name__ == "__main__":
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:18:47.808603
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    from tqdm.utils import _term_move_up
    from .gui import tqdm_gui
    try:
        from ipywidgets import FloatProgress
        from IPython.display import display
    except ImportError:
        return

    with tqdm_gui(10, desc='Description', unit='units') as bar:
        assert isinstance(bar, tqdm_notebook)
        assert isinstance(bar.container.children[-2], FloatProgress)
        assert isinstance(bar.container.children[-1], HBox)
        assert bar.container.children[-2].description == 'Description'
        assert bar.container.layout.width == '100%'
        for i in bar:
            sleep(0.1)
            bar.update()

# Generated at 2022-06-12 15:18:51.218963
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=3) as pbar:
        i = 0
        while True:
            if i < 3:
                i += 1
                pbar.update()
            else:
                break



# Generated at 2022-06-12 15:18:53.149665
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        t1 = tqdm_notebook([0, 100])
        t1.clear()
        return True
    except Exception:
        return False

# Generated at 2022-06-12 15:18:59.396044
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep

    # Initialise tqdm
    pbar = tqdm_notebook(total=10)

    # Check default display
    assert pbar.container.children[-2].bar_style == 'info'
    pbar.display()
    assert pbar.container.children[-2].bar_style == 'info'

    # Check basic display
    pbar.display("Test 1")
    assert pbar.container.children[-2].bar_style == 'info'

    # Check warning display
    pbar.display("Test 2", bar_style="warning")
    assert pbar.container.children[-2].bar_style == 'warning'

    # Check success display
    pbar.display("Test 3", bar_style="success")

# Generated at 2022-06-12 15:19:09.397576
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from nose.tools import assert_equal
    import json
    t = tqdm_notebook(total=10, mininterval=0, miniters=0,
                      desc='Unit test', leave=True,
                      bar_format='{desc}: {n_fmt}/{total_fmt}')
    for i in _range(5):
        t.update()
    t.reset(total=100)
    t.display(pos=1, bar_style='danger',
              msg='`tqdm.reset(total=100)` Unit test')

# Generated at 2022-06-12 15:19:18.015402
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep
    from sys import stderr
    from io import StringIO

    with StringIO() as f:
        t = tqdm_notebook(["a", "b", "c"], file=f)
        t.write("hi\n")
        sleep(1)
        t.display(bar_style='success', ncols=99)
        t.write("bye\n")
        sleep(1)
        t.display(file=stderr)
        t.write("foo\n")
        sleep(1)
        t.display(bar_style='warning', ncols="100%")
        t.write("bar\n")
        sleep(1)
        t.display(bar_style='danger')
        t.write("danger\n")
        sleep(1)
        t.close

# Generated at 2022-06-12 15:19:41.572923
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from datetime import timedelta
    import time
    tqdm.clear()
    tqdm.close()
    # ncols
    tqdm_notebook(total=100, ncols=100).display()
    tqdm_notebook(total=100, ncols='100px').displa

# Generated at 2022-06-12 15:19:49.726578
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Testing tqdm_notebook constructor"""
    try:
        import ipywidgets
    except ImportError:
        return
    # Test if layout.width is available
    if ipywidgets.widgets.FloatProgress.layout.width is None:
        return
    # Test if bar_style is available
    try:
        ipywidgets.widgets.FloatProgress().bar_style
        ipywidgets.widgets.FloatProgress(bar_style='success').bar_style
    except AttributeError:
        return
    t = tqdm_notebook(total=1)
    t.close()
    # Test _repr_json_
    assert t._repr_json_()
    # Test _repr_pretty_
    t._repr_pretty_(None)
    # Test __repr__
   

# Generated at 2022-06-12 15:19:50.861175
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=10) as t:
        for i in range(11):
            t.update()

# Generated at 2022-06-12 15:19:57.429754
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    try:
        # avoid displaying the bar
        tqdm_notebook(ncols=100)
    except ImportError:
        return
    try:
        from IPython.html.widgets import ContainerWidget
    except ImportError:
        ContainerWidget = object
    class MockContainerWidget(ContainerWidget):
        def __init__(self, *_, **__):
            super(MockContainerWidget, self).__init__(*_, **__)
            self.pbar = None
            self.closed = False

        def _repr_json_(self, pretty=None):
            return self.pbar.format_dict

        def __repr__(self, pretty=False):
            return self.pbar.format_meter(**self._repr_json_(pretty))


# Generated at 2022-06-12 15:20:04.350173
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from IPython.display import clear_output
    except ImportError:
        return  # skip this test if ipywidgets not available

    t = tqdm_notebook(range(10))
    for i in t:
        time.sleep(.01)
        if i % 3 == 0:
            t.display(msg='i=%d' % i, pos=i)
            clear_output(wait=True)  # clear screen display
        elif i == 4:
            t.display(bar_style='info')
        elif i == 5:
            t.display(bar_style='danger')
        elif i == 8:
            t.display(close=True)

# Generated at 2022-06-12 15:20:15.188996
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    """Test for tqdm_notebook()"""
    from .gui import tqdm as tqdm_gui
    with tqdm_notebook(total=10) as t:
        assert t.disable == 0
        assert t.unit_scale == 1
        assert repr(t) == repr(tqdm_gui(0, total=10))
    try:
        with tqdm_notebook(total=None, leave=False) as t:
            assert t.unit_scale is True
            assert t.disable == 1
        raise AssertionError("tqdm_notebook must fail with no total")
    except TypeError:
        pass
    with tqdm_notebook(total=0, leave=False) as t:
        assert t.disable == 0
        pass

# Generated at 2022-06-12 15:20:21.388570
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Tests the display method of tqdm_notebook
    """
    from .std import sys
    from io import StringIO
    from .auto import trange
    from .utils import _range

    # Mocks
    class Mock_FloatProgress:
        """
        Mock for ipywidgets.FloatProgress
        """
        def __init__(self):
            self.value = 0
            self.bar_style = ''

    class Mock_HBox:
        """
        Mock for ipywidgets.HBox
        """
        def __init__(self):
            self.children = []

    class Mock_HTML:
        """
        Mock for ipywidgets.HTML
        """
        def __init__(self):
            self.value = ''


# Generated at 2022-06-12 15:20:27.001986
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        from unittest.mock import Mock
    except ImportError:  # pragma: no cover
        from mock import Mock
    HBox = Mock()
    pbar = Mock()
    pbar.format_dict = {}

    obj = TqdmHBox(children=[HBox, HBox, HBox])
    obj.pbar = pbar
    assert repr(obj) == pbar.format_meter()

    obj.pbar.format_dict["bar"] = "This is an error"
    assert repr(obj) == pbar.format_meter()

    obj.pbar.format_dict["bar"] = "This is an error"
    assert repr(obj) == pbar.format_meter(ascii=True)

test_TqdmHBox___repr__()

# Generated at 2022-06-12 15:20:28.074656
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in trange(10):
        pass



# Generated at 2022-06-12 15:20:29.985661
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for method __iter__ of class tqdm_notebook"""
    lst = range(10)
    for _ in tqdm_notebook(lst):
        pass
