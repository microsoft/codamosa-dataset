

# Generated at 2022-06-12 15:13:44.565939
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Setup
    from contextlib import contextmanager

    @contextmanager
    def capture_print():
        from io import StringIO
        import sys
        captured = StringIO()
        sys.stdout = captured  # noqa: F841
        yield captured
        sys.stdout = sys.__stdout__  # noqa: F841

    # Test reset
    with capture_print() as captured:
        pbar = tqdm_notebook(range(10), leave=False)
        for i in pbar:  # same as call to tqdm_notebook(...).__iter__()
            pass
    assert "100%" not in captured.getvalue()

    # Test leave as true
    with capture_print() as captured:
        pbar = tqdm_notebook(range(10), leave=True)
       

# Generated at 2022-06-12 15:13:51.608259
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    Make sure that exception is not raised when bar is closed.

    Method close of class tqdm_notebook is called when bar is in manual mode
    and loop reaches the end (i.e. n == total) or there is a keyboard interrupt.
    """
    for leave in (False, True):
        try:
            for i in tqdm_notebook(iterable=range(10), leave=leave,
                                   desc="Foo"):
                pass
        except:  # noqa
            raise AssertionError("Method close of class tqdm_notebook"
                                 " raised an exception although it should not.")

# Generated at 2022-06-12 15:14:00.752353
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    try:
        from IPython.display import display
    except ImportError:
        return
    container = tqdm_notebook.status_printer(file=None,
                                             total=100,
                                             desc='description')
    assert container.children[0].value == 'description'
    assert container.children[1].max == 100
    assert container.children[1].value == 0  # Initial value
    assert container.children[2].value == ''
    #
    container = tqdm_notebook.status_printer(file=None,
                                             total=0,
                                             desc='description2')
    assert container.children[0].value == 'description2'
    assert container.children[1].max == 1
    assert container.children[1].value == 1

# Generated at 2022-06-12 15:14:08.758843
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from copy import copy
    try:
        from IPython.display import clear_output
    except ImportError:
        raise SkipTest


# Generated at 2022-06-12 15:14:10.698859
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from .tests import test_tqdm_notebook
    test_tqdm_notebook.test_TqdmHBox___repr__()



# Generated at 2022-06-12 15:14:21.735315
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    status_printer = tqdm_notebook.status_printer
    # Test without total
    try:
        pbar = status_printer(None)
        assert False, "Expected pbar without total to raise error"
    except ImportError:
        pass
    assert pbar is None
    # Test total
    pbar = status_printer(None, 10)
    assert isinstance(pbar, HBox)
    assert pbar.children == [HTML(), IProgress(min=0, max=10), HTML()]
    # Test total and desc
    pbar = status_printer(None, 10, desc="Desc")
    assert isinstance(pbar, HBox)
    assert pbar.children == [HTML(value="Desc"), IProgress(min=0, max=10), HTML()]
    # Test total,

# Generated at 2022-06-12 15:14:23.378024
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook.status_printer(None), TqdmHBox)

# Generated at 2022-06-12 15:14:28.454769
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import tqdm as std_tqdm
    from copy import copy

    t = std_tqdm(total=100)
    t.update()
    t.reset()

    t = tqdm_notebook(total=100)
    t.update()
    t.reset()

    # test total
    t = tqdm_notebook(total=100)
    t.n = 10
    t.reset(total=10)
    assert t.n == 10
    assert t.total == 10

    t = tqdm_notebook(total=100)
    t.total = 10
    t.reset(total=10)
    assert t.n == 0
    assert t.total == 10

    # test initial zero
    t = tqdm_notebook(total=100)

# Generated at 2022-06-12 15:14:32.530618
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from time import sleep
    with tqdm_notebook(total=1) as pbar:
        assert pbar.displayed
        sleep(0.2)
        # close will be checked when the context manager exit
    # assert not pbar.displayed


if __name__ == '__main__':

    test_tqdm_notebook_close()

# Generated at 2022-06-12 15:14:35.098714
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Setup progressbar
    progressbar = tqdm(["a", "b", "c", "d"])
    # Go through progressbar
    for char in progressbar:
        pass


# Generated at 2022-06-12 15:15:03.620566
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from .gui import tgrange, Tgrange
    from .pandas import tqdm_pandas, tqdm_gui

    # Test with a tqdm instance
    tqdm_notebook.status_printer(std_tqdm(total=10))

    # Test with a Tgrange instance
    try:
        tqdm_notebook.status_printer(Tgrange(total=10))
    except Exception as e:
        print("Tgrange test failed:", str(e))

    # Test with a tgrange generator
    try:
        tqdm_notebook.status_printer(tgrange(10))
    except Exception as e:
        print("tgrange test failed:", str(e))

    # Test with a tqdm_pandas instance
    tq

# Generated at 2022-06-12 15:15:07.340755
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook(iterable=range(5), leave=False)
    # Clear previous output (really necessary?)
    # clear_output(wait=1)
    tqdm_notebook(iterable=range(5), leave=True)
    # Clear previous output (really necessary?)
    # clear_output(wait=1)

# Generated at 2022-06-12 15:15:12.570717
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for method __iter__ of class tqdm_notebook"""
    import six

    with tqdm_notebook(leave=False, total=10) as t:
        for i in t:
            if i > 2:
                raise AssertionError("error")
            time.sleep(0.1)


if __name__ == "__main__":
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:15:23.018806
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """Test for method display of class tqdm.notebook"""
    from .tests import TqdmDeprecationWarning, closing
    from .std import tqdm_gui
    from io import StringIO

    with closing(StringIO()) as fp, closing(tqdm_gui(ncols=100, file=fp)) as t:
        assert t.container.layout.width == "100px"
        assert '<bar/>' in fp.getvalue()

        t.disp()  # NOOP
        assert '<bar/>' in fp.getvalue()

        t.disp('test')
        assert 'test<bar/>' in fp.getvalue()

        t.disp('left<bar/>right')
        assert 'left<bar/>right' in fp.getvalue()

    # Check for deprec

# Generated at 2022-06-12 15:15:28.628270
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    mp = tqdm_notebook(total=5)
    for _ in mp:
        pass
    mp.reset()
    assert mp.n == 0
    mx = tqdm_notebook(total=5)
    mx.reset(total=10)
    assert mx.n == 0
    assert mx.total == 10

if __name__ == '__main__':  # Run unit tests
    test_tqdm_notebook_reset()

# Generated at 2022-06-12 15:15:32.065355
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    t = tqdm(range(5))
    assert isinstance(t, tqdm_notebook)
    assert t.gui is True
    t.close()

# Generated at 2022-06-12 15:15:33.829084
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for _ in tqdm_notebook([1, 2, 3]):
        pass


# Generated at 2022-06-12 15:15:41.937945
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        from itertools import repeat
        from time import sleep

        # WITH TOTAL:
        t = tqdm_notebook(repeat(0), total=10, leave=True)
        for i in t:
            sleep(0.1)  # sleep a little after each iteration
            if i == 5:
                t.reset(total=5)
        assert t.n == 5 and t.total == 5

        # WITHOUT TOTAL: Note that manual `n` is always the same
        t = tqdm_notebook(repeat(0), total=None, leave=True)
        for i in t:
            sleep(0.1)
            if i == 5:
                t.reset(total=None)
        assert t.n == 5 and t.total is None
    except KeyboardInterrupt:
        pass

# Generated at 2022-06-12 15:15:51.387514
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # NOQA

    # Check if IProgress is importable
    if IProgress is None:
        return

    from IPython.display import clear_output
    from time import time

    # Test 1
    pbar_minimal = tqdm(total=1)
    pbar_minimal.update(1)
    pbar_minimal.close()

    # Test 2
    pbar = tqdm(total=20)
    for i in range(20):
        sleep(0.1)
        pbar.update(1)
    pbar.close()

    # Test 3
    pbar = tqdm(total=20)
    for i in range(20):
        sleep(0.1)
        pbar.update(1)
        if i == 10:
            clear_output(wait=True)
   

# Generated at 2022-06-12 15:15:54.138413
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.auto import tqdm
    for _ in tqdm(range(3)):
        print("Hello")


if __name__ == '__main__':
    test_tqdm_notebook_clear()

# Generated at 2022-06-12 15:16:18.377578
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in trange(10):
        pass


if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:16:20.205242
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    try:
        tqdm.tqdm_notebook.status_printer(file=None, total=100, desc="Loading")
    except Exception:
        raise Exception("Cannot initialize the progress bar")

# Generated at 2022-06-12 15:16:26.363499
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():  # pragma: no cover
    from time import sleep
    from tqdm.auto import trange, tqdm
    with tqdm(total=5) as t:
        for i in range(5):
            sleep(0.25)
            t.update()
    sleep(0.25)
    with trange(5) as t:
        for i in range(5):
            sleep(0.25)
            t.update()
    try:
        with tqdm(total=5, file=None):
            pass
    except Exception as e:
        assert "IProgress" in e.args[0]
    try:
        with tqdm(total=5, file=sys.stderr) as t:
            pass
    except TypeError:
        pass
    else:
        raise TypeError

# Generated at 2022-06-12 15:16:36.207836
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import time
    import unittest

    def _status_printer_method(container):
        pbar = IProgress(min=0, max=1)
        ltext = HTML()
        rtext = HTML()
        return HBox(children=[ltext, pbar, rtext])

    class TestTqdmNotebook(unittest.TestCase):
        def test_status_printer_method(self):
            from tqdm import tqdm_notebook as tn
            test_tn = tn.status_printer(file=None, total=None, desc=None)
            self.assertEqual(str(type(test_tn)), "<class 'ipywidgets.widgets.widget_box.HBox'>", 'instance of HBox')


# Generated at 2022-06-12 15:16:42.850827
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .utils import _test_cls
    _test_cls(tqdm_notebook, leave=True,
              manual_iter={'desc': 'foobar', 'total': 10},
              manual_close={'bar_style': 'success', 'check_delay': False},
              ncols=None)
    # delayed display
    _test_cls(tqdm_notebook, leave=True,
              manual_iter={'desc': 'foobar', 'total': 10, 'delay': 2},
              manual_close={'bar_style': 'success', 'check_delay': False},
              ncols=None)

# Generated at 2022-06-12 15:16:45.661706
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm(total=10) as t:
        t.total = 5
        assert t.n == 5
        assert t.total == 5
        t.reset()
        assert t.n == 0
        assert t.total == 5

# Generated at 2022-06-12 15:16:56.820002
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import trange
    from inspect import currentframe, getouterframes

    filename = __file__
    # Get calling file name
    for frame in getouterframes(currentframe()):
        if frame[1] != filename:
            calling_filename = frame[1]
            break
    try:
        with open(calling_filename) as f:
            calling_file_size = len(f.read())
    except (OSError, IOError):
        calling_file_size = None


# Generated at 2022-06-12 15:17:04.942565
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Unit test for method `display()` of class `tqdm_notebook`
    """
    from unittest import TestCase, main
    from tqdm.utils import _supports_unicode, _environ_cols_wrapper

    class TqdmNotebookTest(TestCase):
        "alias"

        def setUp(self):
            self.t = tqdm_notebook(total=30, desc="Testing display...",
                                   ncols=15, leave=True)

        def test_display(self):
            """
            Test for `display()`
            """
            for _ in range(30):
                self.t.update()

            self.t.disp(msg="Custom test 1", pos=None,
                        bar_style='warning')  # use default pos
            self.t

# Generated at 2022-06-12 15:17:11.371850
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit test for class `tqdm.tqdm_notebook`.
    """
    # Update description
    with tqdm_notebook(total=1, desc="Description") as bar:
        bar.desc = "New Description"

    # Change bar style
    with tqdm_notebook(total=1) as bar:
        bar.bar_style = "warning"

    # Disable progressbar
    with tqdm_notebook(disable=True, total=100) as bar:
        for _ in range(100):
            bar.update()

    # Customize container width
    with tqdm_notebook(total=1, ncols=200) as bar:
        assert bar.container.layout.width == '200px'


# Generated at 2022-06-12 15:17:18.750897
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import unittest
    class Test_tqdm_notebook_reset(unittest.TestCase):

        def test_reset(self):
            with tqdm(total=2) as pbar:
                pbar.update()
                pbar.reset(total=10)
                pbar.update()
                pbar.reset()
                pbar.update()
                self.assertEqual(pbar.n, 1)
                self.assertEqual(pbar.total, None)
                self.assertEqual(pbar.n / (pbar.total or 1) * 100, 100)

    unittest.main(argv=['test_tqdm_notebook_reset'],
                  exit=False, verbosity=2, defaultTest='Test_tqdm_notebook_reset')

# Generated at 2022-06-12 15:17:48.722285
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tqdm_notebook as tqdm
    # some long computation...
    try:
        for i in tqdm(range(9999), ascii=True):
            pass
    except:
        raise
        # pass
    finally:
        tqdm.close()



# Generated at 2022-06-12 15:17:57.741070
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # test for: tqdm_notebook().status_printer(None, None, None, None)

    from .std import tqdm_gui # avoid cyclic import
    tqdm_gui.status_printer(None, None, None, None)
    tqdm_gui.status_printer(None, None, u'', None)
    tqdm_gui.status_printer(None, None, u'a', None)

    # test for: tqdm_notebook().status_printer(None, 0, None, None)
    tqdm_gui.status_printer(None, 0, None, None)
    tqdm_gui.status_printer(None, 0, u'', None)
    tqdm_gui.status_printer(None, 0, u'a ', None)

# Generated at 2022-06-12 15:18:03.894945
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from io import StringIO
    for i in trange(1, 5, desc='TEST DESC'):
        pass
    with open('/dev/stdout', 'w') as f:
        for i in trange(1, 5, desc='TEST DESC', file=f):
            pass
    try:
        ipywidgets.Widget.close_all()
    except (AttributeError, NameError):
        pass
    with StringIO() as f:
        for i in trange(1, 5, desc='TEST DESC', file=f):
            pass


if __name__ == '__main__':
    import pytest
    pytest.main([__file__])
    # test_tqdm_notebook()

# Generated at 2022-06-12 15:18:06.950089
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test method __iter__."""
    t = tqdm_notebook(10)
    # t.update(1) is called in __iter__
    assert isinstance(t.__iter__(), type(t))



# Generated at 2022-06-12 15:18:17.046071
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Setup the display
    from tqdm.contrib import tenumerate
    # Run the tests
    for i, el in tenumerate(range(10)):
        # Split description and bar
        _, tq = tqdm(total=10, desc='hello')
        tq.container.children[0].value = 'hello'
        tq.container.children[2].value = 'world'
        # Try to set the bar style
        tq.container.children[1].bar_style = 'warning'
        tq.update()
    # A random test
    _, tq = tqdm(desc='hello world')
    tq.container.children[0].value = 'hello'
    tq.container.children[2].value = 'world'
    tq.container.children[1].bar_

# Generated at 2022-06-12 15:18:25.556313
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import os
    import sys
    import time

    try:
        import IPython  # NOQA
    except ImportError:
        print("\n\nNo IPython found. Skipping notebook tests.\n")
        return

    if sys.stderr is not sys.__stderr__:  # pragma: no cover
        return  # apparently in a test suite

    # Setup tqdm and IPython progress bar
    tpbar = tqdm_notebook(range(0, 50), ncols=0, leave=False)
    ipbar = IProgress(min=0, max=50)
    ipbar.bar_style = 'success'
    ipbar.value = 0

    # Tests

# Generated at 2022-06-12 15:18:31.827179
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    from time import sleep

    from IPython.display import clear_output

    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            sleep(0.1)
            pbar.display(close=True, check_delay=False)
            pbar.update()
        pbar.display(close=True, check_delay=False)

    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            sleep(0.1)
            clear_output()
            pbar.update()
        clear_output()

    with tqdm_notebook(total=4) as pbar:
        for _ in range(4):
            sleep(0.1)
            pbar.clear()
            pbar

# Generated at 2022-06-12 15:18:40.521141
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():  # pragma: no cover
    from tqdm.auto import trange

    for test_prog_bar in [tqdm_notebook.status_printer, trange.status_printer]:
        bar = test_prog_bar(file=None)
        assert isinstance(bar, TqdmHBox)

        left, pbar, right = bar.children
        assert isinstance(left, HTML)
        assert isinstance(pbar, IProgress)
        assert isinstance(right, HTML)

        # Test that total=0 doesn't give a zero division error
        with std_tqdm(disable=True) as bar:
            test_prog_bar(bar, total=0)

        # Test that total=None produces an info bar
        pbar = test_prog_bar(file=None, total=None)

# Generated at 2022-06-12 15:18:46.198997
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    n = 100

    with tqdm(total=n, desc='test', ncols=300) as pbar:
        for i in range(n):
            pbar.set_postfix(foo=i, bar=i)
            pbar.display(check_delay=False)

    # test with a/synchronicity
    with tqdm(total=n, desc='test', ncols=300) as pbar:
        for i in range(n):
            pbar.set_postfix(foo=i, bar=i)
            pbar.display()  # will wait the minimum delay before displaying


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:18:52.186566
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        from ipykernel.zmqshell import ZMQInteractiveShell
    except ImportError:
        from IPython.kernel.zmq.zmqshell import ZMQInteractiveShell
    from IPython.core.displaypub import publish_display_data
    import json

    class MockKernel:
        def get_shell(self):
            return ZMQInteractiveShell()

    # Assert on the test routine print
    class TestPrint(list):

        def __enter__(self):
            self._original_print = tqdm._tqdm_gui.tqdm_notebook.print_function
            tqdm._tqdm_gui.tqdm_notebook.print_function = self.append
            return self

        def __exit__(self, *args):
            tqdm._tqdm

# Generated at 2022-06-12 15:20:44.234866
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stdout
    from time import sleep
    from re import search

    display(stdout)
    t = tqdm_notebook(total=100, leave=False)
    for _ in range(100):
        sleep(0.01)
        t.update()

    assert not search(r'{bar}', t._repr_pretty_(None)), \
        "Observed '{bar}' in bar (should be hidden)"

# Generated at 2022-06-12 15:20:52.316463
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from sys import stdout
    from tqdm.utils import _term_move_up
    from time import sleep
    from random import randint
    from collections import defaultdict

    t = tqdm_notebook(total=10, file=stdout)
    string_to_display = "Testing tqdm_notebook"
    # testing msg, pos and bar_style
    t.display(string_to_display, pos=7)
    sleep(randint(100, 200) / 1000)
    t.display(bar_style="success")
    sleep(randint(100, 200) / 1000)
    # test close
    t.display(close=True)
    # resets stdout cursor
    print(_term_move_up() + _term_move_up())
    # testing colors and delay0 display

# Generated at 2022-06-12 15:20:59.123417
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    progress_bar = tqdm_notebook.status_printer(sys.stdout,
                                                total=1,
                                                desc='hello',
                                                ncols=100)
    # The following test is not intended to test ipywidgets
    # It only tests the correctness of the returned values
    assert isinstance(progress_bar, TqdmHBox)
    assert len(progress_bar.children) == 3
    assert isinstance(progress_bar.children[0], HTML)
    assert isinstance(progress_bar.children[1], IProgress)
    assert isinstance(progress_bar.children[2], HTML)

# Generated at 2022-06-12 15:21:03.142407
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    with tqdm_notebook(total=5) as t:
        for i in t:
            t.desc = "desc {}".format(i + 1)
            time.sleep(0.3)
            if i >= 2:
                raise Exception("Test exception")


# Generated at 2022-06-12 15:21:10.590907
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # setup
    tqdm_notebook.reset_instance()
    tqdm_notebook._instances.clear()
    tqdm_notebook._instance_dicts.clear()
    tqdm_notebook._decorated_streams.clear()

    test_repr = TqdmHBox().__repr__
    test_repr_json = TqdmHBox()._repr_json_

    # empty
    assert test_repr() == '\n'
    assert test_repr(pretty=True) == '\n'
    assert test_repr_json() == {}
    assert test_repr_json(pretty=True) == {}

    # simple
    TqdmHBox().pbar = std_tqdm(total=2)

# Generated at 2022-06-12 15:21:13.701285
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # success case
    pbar = tqdm_notebook(total=10)
    for _ in range(10):
        pbar.update()
    pbar.reset()
    for _ in range(10):
        pbar.update()

    # error case
    pbar.reset()
    for _ in range(5):
        pbar.update()
    raise KeyboardInterrupt

# Generated at 2022-06-12 15:21:23.215489
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML, display
    from tqdm.notebook import tqdm_notebook

    def test(*args, **kwargs):
        # Get IPython progress bar
        iter_test = tqdm_notebook(*args, **kwargs)
        assert isinstance(iter_test.container, HBox)
        pbar = iter_test.container.children[-2]
        assert isinstance(pbar, IProgress)
        # Prepare HTML layout
        container = HBox(children=[
            iter_test.container,
            HTML(value="<div>&nbsp;{}</div>".format(
                "&nbsp;".join(map(str, args))))])
        container.layout.border = "1px solid black"
        container.layout.padding = "5px"

# Generated at 2022-06-12 15:21:28.284591
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import pytest
    from IPython.display import clear_output, display
    # tests the following function
    # tnrange = tqdm_notebook(range(100), leave=True)
    # tnrange.display(msg='Test', pos=10)
    # tnrange.display(msg='Test', pos=20)
    # tnrange.display(close=True)

    # test exception handling
    tnrange = tqdm_notebook(range(100), leave=True)
    with pytest.raises(Exception):
        tnrange.display(msg='Test', pos=10)
        tnrange.display(msg='Test', pos=20)
        tnrange.display(bar_style='danger')

    tnrange = tqdm_notebook(range(100), leave=True)


# Generated at 2022-06-12 15:21:31.222507
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=100, unit='B', unit_scale=True, miniters=1,
                       mininterval=0.1) as t:
        for i in range(10):
            t.update()
        t.close()



# Generated at 2022-06-12 15:21:34.610277
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import time
    for t in [None, 100]:
        for i in tqdm_notebook(range(10), total=t, leave=True):
            time.sleep(0.01)
        tqdm_notebook().reset()


if __name__ == '__main__':
    test_tqdm_notebook_reset()