

# Generated at 2022-06-12 15:13:38.609840
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import pytest
    with pytest.raises(AttributeError):
        tqdm_notebook().clear()

# Generated at 2022-06-12 15:13:49.324975
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import types
    from io import StringIO
    from contextlib import redirect_stdout

    class DummyTqdmNotebook(tqdm_notebook):
        # Wrapper to avoid the `progressbar` widget to appear
        def display(self, *_, **__):
            self.displayed = True
            if self.delay <= 0:
                return
            self.delay_step = min(self.delay_step * 2, self.max_interval)

        def __init__(self, *args, **kwargs):
            super(DummyTqdmNotebook, self).__init__(*args, **kwargs)
            # `status_printer` is static method, so we add it as a class method
            self.status_printer = types.MethodType(self.status_printer, self)


# Generated at 2022-06-12 15:13:50.389141
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test with default parameters
    widgets = tqdm_notebook.sta

# Generated at 2022-06-12 15:13:59.132371
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Tests `tqdm.notebook.tqdm`.
    """
    try:
        from IPython.display import display  # NOQA
    except ImportError:
        return

    pbar = tqdm_notebook(total=2)
    pbar.reset(3)
    pbar.update()
    assert pbar.n == 1
    assert pbar.total == 3
    assert pbar.leave == False
    pbar.reset(leave=True)
    assert pbar.leave == True
    pbar.reset()
    assert pbar.leave == False
    assert pbar.total is None
    pbar._instant_apply = False  # skip instant mode for this test
    assert pbar.container.children[1].layout.width is None
    pbar.reset(4)

# Generated at 2022-06-12 15:14:05.744009
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # pragma: no cover
    """Test method close of class tqdm_notebook"""
    from nose.tools import raises
    from time import sleep

    def test_exit_code(hb):
        try:
            raise KeyboardInterrupt
        except Exception:
            hb.close()
            exit(2)

    def test_close(hb):
        hb.close()
        exit(0)

    hb = tqdm_notebook(range(2))
    for i in hb:
        sleep(.1)
    try:
        test_close(hb)
    except Exception:
        test_exit_code(hb)

# Generated at 2022-06-12 15:14:13.120116
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:  # ipywidgets
        # Note: ipywidgets 7.x has broken module import
        # import ipywidgets as testmod
        # load_submodules('ipywidgets')
        import ipywidgets
        if ipywidgets.__version__.split('.')[:2] >= ['7', '0']:
            raise ImportError()
    except ImportError:
        from nose.plugins.skip import SkipTest  # noqa
        raise SkipTest("ipywidgets not installed")

    import tempfile
    try:
        from unittest.mock import patch, MagicMock  # Python 3
    except ImportError:  # Python 2
        from mock import patch, MagicMock  # NOQA

    with tempfile.NamedTemporaryFile() as tmp:
        pbar = tqdm

# Generated at 2022-06-12 15:14:18.535967
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Check if clear() of tqdm_notebook is not doing anything
    n = 100
    t = tnrange(n)
    for i in t:
        t.clear()
    t.close()

if __name__ == "__main__":
    # test
    for _ in tqdm_notebook(range(50)): pass

# Generated at 2022-06-12 15:14:25.514976
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    success = False
    try:
        for i in tqdm_notebook(range(3), desc="test_tqdm_notebook___iter__"):
            assert i == next(tqdm_notebook(range(3), desc="test_tqdm_notebook___iter__"))
            # raise an exception
            if i == 1:
                raise Exception
        # should not be reached, there is an exception
        raise Exception
    except:
        success = True
    assert success, "Exception not raised"

if __name__ == '__main__':
    test_tqdm_notebook___iter__()

# Generated at 2022-06-12 15:14:33.562580
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from unittest.mock import patch
    except ImportError:
        from mock import patch

    tn = tqdm_notebook(total=5, leave=True)

    with patch('IPython.display.display') as mock_display:
        tn.display()

    assert not mock_display.called

    with patch('IPython.display.display') as mock_display:
        tn.display(bar_style='success')

    assert mock_display.called

    with patch('IPython.display.display') as mock_display:
        tn.close()

    assert mock_display.called

    with patch('IPython.display.display') as mock_display:
        tn.display(msg='')

    assert not mock_display.called

# Generated at 2022-06-12 15:14:37.386988
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Unit-test tqdm_notebook.
    """
    import time

    try:
        from ipywidgets import IntProgress
    except ImportError:
        return None

    with tqdm_notebook(total=5) as pbar:
        for _ in range(5):
            pbar.update()
            time.sleep(0.5)
    return pbar

# Generated at 2022-06-12 15:14:58.252845
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:  # pragma: no cover
        import unittest
    except ImportError:  # pragma: no cover
        try:  # Py3
            import unittest2 as unittest
        except ImportError:  # Py2
            raise ImportError("Please install unittest2 to run the Python 2 "\
                              "tests: pip install unittest2")

    class TestTqdmNotebook(unittest.TestCase):
        def setUp(self):
            self.t = tqdm_notebook(0)

        def test_clear(self):
            self.t.clear()
            self.t.close()

    unittest.main(argv=['first-arg-is-ignored'], exit=False)

# Generated at 2022-06-12 15:15:04.758284
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    bar = tqdm_notebook(total=5, desc='#1', leave=False)
    bar.display(desc="test", close=True)
    clear_output(wait=1)
    try:
        bar.display(bar_style='danger')
        # test that bar is closed properly
        bar.display()
    except AttributeError:
        pass
    finally:
        clear_output(wait=1)


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:15:05.941563
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import random

    tqdm_notebook().update(random() * 100)

# Generated at 2022-06-12 15:15:07.984017
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm(total=3) as t:
        t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:15:17.709698
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep

    for _ in range(3):  # test repeated usage
        with tqdm_notebook(total=4) as pbar:
            for _ in range(4):
                sleep(.5)
                pbar.update()
            # since open leave=True and reset total=None, should display
            pbar.reset()
        for _ in range(4):
            sleep(.5)
        # since open leave=False and reset total=None, should display too
        pbar.reset()
        for _ in range(4):
            sleep(.5)
        # since open leave=False and reset total=5, should not print bar
        pbar.reset(total=5)
        for _ in range(5):
            sleep(.5)

# Generated at 2022-06-12 15:15:25.610606
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # mock stdout
    from cStringIO import StringIO
    import sys
    old_stdout = sys.stdout
    sys.stdout = StringIO()

    # test
    tn = tqdm_notebook(total=100)
    assert (repr(tn.container.__repr__(True)) == repr(old_stdout.getvalue()) and
            tn.container.children[0].value == "100%|██████████| 100/100 [00:00<00:00, " +
            "?it/s]")
    old_stdout.close()
    sys.stdout = old_stdout

# Generated at 2022-06-12 15:15:33.524863
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time

    n = 1000
    # n = int(1e9)  # uncomment to test notebook's performance
    with tqdm(total=n, unit='B', unit_scale=True,
              leave=True, dynamic_ncols=True) as t:
        for i in range(n):
            time.sleep(0.0001)
            t.update()


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:15:37.246697
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test1: Test display on a local new Jupyter Notebook
    ctr = tqdm_notebook.status_printer(total=10)
    for i in _range(10):
        ctr.value = i
    ctr.close()

# Generated at 2022-06-12 15:15:40.697021
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """Unit test for method update of class tqdm_notebook"""
    from time import sleep
    d = tqdm_notebook(unit="i", total=3)
    try:
        for i in d:
            sleep(0.5)
    except KeyboardInterrupt:
        pass
    tqdm_notebook.close()

# Generated at 2022-06-12 15:15:49.648330
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    from io import BytesIO
    with BytesIO() as file:
        file.encoding = 'UTF-8'  # avoid encoding errors
        with tqdm_notebook(total=None, file=file, dynamic_ncols=True) as pbar:
            pbar.file = file  # force bar display
            try:
                for i in trange(3, desc='1st loop', leave=False):
                    pbar.set_description_str('1st loop, iter %i' % i)
                    sleep(0.01)
            except Exception:
                pbar.disp(bar_style='danger')
                raise
            pbar.reset(total=20)

# Generated at 2022-06-12 15:16:19.192638
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():  # pragma: no cover
    import time
    from tqdm.auto import tqdm, trange
    with tqdm(total=100) as t:
        for i in trange(10):
            time.sleep(0.1)
            t.update(10)
        for i in trange(10):
            time.sleep(0.1)
            t.update(10)
        t.reset(total=50)
        for i in trange(10):
            time.sleep(0.1)
            t.update(10)

# Generated at 2022-06-12 15:16:22.925054
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for i in trange(3):
        print(i)
        tqdm_notebook.clear(i)  # noqa E221
        tqdm_notebook.close(i)  # noqa E221
        if False:  # pragma: no cover
            tqdm_notebook.close(i)  # noqa E221
            tqdm_notebook.close(i)  # noqa E221



# Generated at 2022-06-12 15:16:33.263917
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from io import StringIO
    from sys import version_info as __version_info__
    from textwrap import dedent
    from unittest import TestCase

    class TqdmHBoxRe(TestCase):
        def test_repr(self):
            # set up objects to be used in the test
            tqdm_hbox_obj = TqdmHBox()
            tqdm_hbox_obj.pbar = std_tqdm()
            tqdm_hbox_obj.pbar.format_dict = {
                "bar_format": "{l_bar}<bar/>{r_bar}",
                "n": 1000,
                "desc": "desc_str",
                "total": 1000,
                "ncols": 100,
                "ascii": False}
            # redirect stdout for assertion

# Generated at 2022-06-12 15:16:38.423431
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    if IPY <= 0:
        return  # pragma: no cover

    try:
        x, y = tnrange(None), tnrange(None)
        x.reset(total=None)
        x.reset()
        x.reset(total=None)
        x.reset(total=None)
    except:  # NOQA
        raise
    finally:
        x.close()
        y.close()

# Generated at 2022-06-12 15:16:45.568427
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""
    # Not working on CI but can be tested manually
    # # Test with no total
    # from IPython.display import clear_output
    # from time import sleep
    # h = tqdm_notebook.status_printer(None)
    # h.value = 0
    # for i in range(3):
    #     h.value += 1
    #     clear_output(wait=True)
    #     display(h)
    #     sleep(0.25)
    # clear_output(wait=True)

    # Test with total
    from IPython.display import clear_output
    from time import sleep
    h = tqdm_notebook.status_printer(None, total=3)

# Generated at 2022-06-12 15:16:47.704596
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    l = ['a', 'b', 'c']
    tqdm_notebook(l, unit='units')


# Generated at 2022-06-12 15:16:58.769191
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test method display of class tqdm_notebook
    # (also tests the update and close methods)
    from time import sleep
    from re import findall
    from tqdm.auto import trange
    from .gui import tgrange

    for i in trange(3, desc='1st loop'):
        for j in tgrange(3, desc='2nd loop', leave=True):
            for k in trange(3, desc='3rd loop'):
                sleep(.1)
        sleep(.1)

# Generated at 2022-06-12 15:17:05.213994
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import tqdm
    from time import sleep
    for i in tqdm(range(4), desc='1st loop', leave=False):
        for j in tqdm(range(3), desc='2nd loop', leave=False, total=3):
            try:
                sleep(0.01)  # long computation
            except KeyboardInterrupt:
                pass
            tqdm.write("current: {}".format(j))
    # tqdm.write("current: {}".format(i))  # should not be shown
    # tqdm.clear()  # should not be shown
    print("should be not part of the progress bar")



# Generated at 2022-06-12 15:17:09.326874
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from contextlib import contextmanager

    @contextmanager
    def fake_stdout():
        stdout = sys.stdout
        sys.stdout = ""
        yield
        assert not sys.stdout
        sys.stdout = stdout

    if hasattr(sys.stdout, "fileno"):
        del sys.stdout.fileno

    with fake_stdout():
        with tqdm_notebook(total=2):
            pass  # ensure that `close()` can be called twice without segfault
        with tqdm(total=2) as pbar:
            pbar.set_description("HELLO WORLD")
            pbar.update(1)



# Generated at 2022-06-12 15:17:12.918204
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(0) as pbar:  # pragma: no cover
        assert pbar.gui == True
        assert pbar.disable == False
        assert pbar.displayed == True
        assert pbar.n == 0
        assert pbar.total == 0


# Generated at 2022-06-12 15:18:12.428747
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=0) as pbar:
        # loop 10 times, showing the progress bar
        for _ in range(10):
            pbar.update(1)
    assert pbar.n == 10


# Generated at 2022-06-12 15:18:21.313247
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal

    from .utils import _screen_shape

    # Resize terminal window
    _screen_shape(22, 100)

    # Initialize a tqdm_notebook instance
    t = tqdm_notebook(total=10, leave=False)
    msg = 'test'
    t.display(msg)
    assert_equal(t.container.children[-1].value, msg)

    # Test close bar
    t.display(close=True)
    assert_equal(t.container.children[-1].value, msg)

    # Test bar_style attribute
    t.display(bar_style='danger')
    assert_equal(t.container.children[-2].bar_style, 'danger')

    t.display(bar_style='success')

# Generated at 2022-06-12 15:18:24.153886
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import timeit
    from tqdm.auto import trange
    for x in trange(10):
        timeit.sleep()
        if x == 0:
            raise Exception()


# Generated at 2022-06-12 15:18:27.008436
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """ Unit test for method status_printer of class tqdm_notebook """
    try:
        tqdm_notebook.status_printer(_range(5))
    except:  # noqa
        assert False, "Status printer unit test failed!"
    else:
        assert True, "Status printer unit test successful!"

# Generated at 2022-06-12 15:18:35.590421
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from tqdm import __version__
    for total in [None, 1, 2, 3]:
        for leave in [True, False]:
            for dynamic_ncols in [True, False]:
                t = tqdm_notebook(total=total, leave=leave, dynamic_ncols=dynamic_ncols)
                sleep(.1)
                t.reset(total=None)
                sleep(.1)
                t.reset(total=None)
                sleep(.1)
                t.reset(total=2)
                for _ in t:
                    sleep(.1)

# Generated at 2022-06-12 15:18:43.452947
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test .reset() method of class tqdm_notebook"""
    from .gui import tqdm as _tqdm

    # Note: total=2 is arbitrary and only used to simplify the test
    with _tqdm(total=2, leave=True) as bar:
        assert bar.n == 0
        # update to n=1 (50%)
        bar.update(1)
        # Fix total to 3, without resetting current n=1
        bar.reset(total=3)
        assert bar.n == 1 and bar.total == 3
        # update to n=3 (100%), this should be a success
        bar.update(2)
        assert bar.bar_style == 'success'
        # Reset to n=0 (0%), with total=5 and leave=True
        bar.reset(total=5)
       

# Generated at 2022-06-12 15:18:54.951969
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep

    # basic test update
    with tqdm_notebook(total=1) as pbar:
        assert pbar.total == 1
        pbar.update(1)
        assert pbar.n == 1
        pbar.update(0)
        assert pbar.n == 1
    assert pbar.n == 1

    # test update and close
    with tqdm_notebook(total=1) as pbar:
        assert pbar.total == 1
        pbar.update(1)
    assert pbar.n == 1

    # test update and close with error
    try:
        with tqdm_notebook(total=2) as pbar:
            assert pbar.total == 2
            pbar.update(1)
            raise Exception
    except:
        assert pbar.n

# Generated at 2022-06-12 15:18:56.883494
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from .tests.gui import test_iter_notebook
    test_iter_notebook(tqdm_notebook)


# Generated at 2022-06-12 15:19:00.537693
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    sum_ = 0
    with tqdm_notebook(total=4) as pbar:
        for i in range(4):
            time.sleep(0.3)
            sum_ += i
            pbar.update(i)
        pbar.update()
    assert sum_ == 6

# Generated at 2022-06-12 15:19:10.751272
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():  # pragma: no cover
    import time
    # Test update()
    with tqdm_notebook(total=9, unit="i", unit_scale=True) as pbar:
        assert pbar.dynamic_ncols
        assert not pbar.leave
        assert pbar.displayed
        assert 10**3 <= pbar.total <= 10**4
        for i in _range(3):
            pbar.update()
        for i in _range(6):
            pbar.update(2)
            time.sleep(0.01)

        # Reset
        pbar.reset()
        assert not pbar.displayed
        assert pbar.n == 0

        for i in _range(3):
            pbar.update()
        for i in _range(6):
            pbar.update(2)


# Generated at 2022-06-12 15:21:29.377663
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # test tqdm_notebook with __iter__ method
    with tqdm_notebook(total=2) as pbar:
        for i in range(2):
            pbar.update()

    assert (pbar.last_print_n == 2)



# Generated at 2022-06-12 15:21:37.887082
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """test_tqdm_notebook_status_printer"""
    import ipywidgets  # NOQA

    tqdm_notebook.status_printer(None, total=2, desc='test')
    tqdm_notebook.status_printer(None, total=2, desc='test', ascii=True)
    tqdm_notebook.status_printer(None, total=2, desc='test', ncols=100)
    tqdm_notebook.status_printer(None, total=2, desc='test', ncols="100%")
    tqdm_notebook.status_printer(None, total=2, desc='test', ncols="auto")

    # Test case: no total

# Generated at 2022-06-12 15:21:41.478386
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import tqdm as t

    with t.tqdm_notebook(total=10) as pbar:
        for i in range(10):
            pbar.update()



# Generated at 2022-06-12 15:21:49.661522
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    from unittest import TestCase, main
    import sys

    class Test_tqdm_notebook___iter__(TestCase):

        # Tests that tqdm_notebook works as intended
        def test_tqdm_notebook_basics(self):
            with tqdm_notebook(total=4) as pbar:
                for _ in range(4):
                    pbar.update()
            self.assertTrue((pbar.n, pbar.total) == (4, 4))

        # Tests that tqdm_notebook works as intended

# Generated at 2022-06-12 15:21:52.217166
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as t:
        t.clear()

        try:
            t.close()
        except:  # NOQA
            pass

# Generated at 2022-06-12 15:22:00.627828
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import display
    import time
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)
    time.sleep(3)  # simulate long calculation
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)
            time.sleep(0.1)


if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-12 15:22:05.308103
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Test `tqdm.notebook.tqdm.reset()` with `total>0`"""
    from .tests import _test_reset, _range, _has_name

    try:
        import ipywidgets  # NOQA: F401
        _test_reset(tqdm, tqdm_notebook, _range, _has_name)
    except ImportError:
        pass


# Class `tnrange` is almost the same as `tqdm_notebook` so
# the unit test is defined only once

# Generated at 2022-06-12 15:22:13.950126
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialize test parameters
    xrange_iter = _range(100)
    test_kwargs = dict(
        total=100,
        unit='B',
        unit_scale=True,
        desc='Test tqdm_notebook.update',
        leave=False)

    # Initialize and update tqdm_notebook instance
    t = tqdm_notebook(xrange_iter, **test_kwargs)
    for i in xrange_iter:
        t.update()
        # Test for format_dict method access
        try:
            t.format_dict
        except AttributeError:
            raise AssertionError()

    # Test for format_meter method access
    try:
        t.format_meter
    except AttributeError:
        raise AssertionError()

    # Test for left side `

# Generated at 2022-06-12 15:22:23.784839
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.auto import tqdm
    with tqdm(total=0) as pbar:
        assert pbar.update()
        assert pbar.update() == 2
        assert pbar.update(99) == 101
        assert pbar.update(0) == 101
        try:
            pbar.update(-1)
        except ValueError:
            pass
        else:
            raise # pragma: no cover
        pbar.clear()
        assert pbar.update() == 1
        assert pbar.update(9) == 10
        assert pbar.update(-1) == 9
        assert pbar.update(-5) == 4
        pbar.close()
        assert pbar.update() == 5
        pbar.reset()
        assert pbar.update(1) == 1
        assert pbar.update

# Generated at 2022-06-12 15:22:29.717296
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit tests for the `tqdm_notebook.__iter__` method.
    """
    import time

    for i in tqdm_notebook(range(5), desc="1st loop", leave=True):
        for j in tqdm_notebook(range(5), desc="2nd loop", leave=True, unit='it'):
            for k in tqdm_notebook(range(5), desc="3rd loop", leave=True, unit='it'):
                time.sleep(0.01)
            time.sleep(0.01)
        time.sleep(0.01)

