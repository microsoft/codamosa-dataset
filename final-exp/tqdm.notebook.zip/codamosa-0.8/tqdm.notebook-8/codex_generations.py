

# Generated at 2022-06-12 15:13:47.953078
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10, leave=False, ncols=100) as t:
        t.update(5)
        # t.reset() should reset the bar to 0
        t.reset()
        assert t.n == 0
        assert t.last_print_n == 0
        t.update(2)
        t.reset(total=50)
        assert t.n == 0
        assert t.total == 50

# Generated at 2022-06-12 15:13:54.903344
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():  # pragma: no cover
    from .std import tqdm as std_tqdm

    # Initialize tqdm
    t = tqdm_notebook(total=100)

    # default display: no msg, no bar_style
    t.display()

    # display with msg
    t.display("msg")

    # display with msg and reset bar_style
    t.display("msg2", bar_style='info')

    # display with msg and reset bar_style
    t.display("msg3", bar_style='success')

    # display with msg and bar_style
    t.display("msg4", bar_style='danger')

    # display with msg and bar_style and close
    t.display("msg5", bar_style='danger', close=True)

    # display with msg and no bar_style
    t

# Generated at 2022-06-12 15:14:02.260656
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython.display import Markdown, display
    from io import StringIO

    for i in tqdm_notebook(range(1, 6), desc='1st loop'):
        for j in tqdm_notebook(range(1, 6), desc='2nd loop', leave=False):
            for k in tqdm_notebook(range(1, 5), desc='3rd loop', leave=False):
                pass

    # Disable tqdm_notebook
    with StringIO() as f:
        with tqdm_notebook(range(2), desc='test', file=f, leave=False) as t:
            t.disable = True
            for i in t:
                pass
        assert not f.getvalue().strip()

    display(Markdown("# Test has completed successfully!"))



# Generated at 2022-06-12 15:14:05.182008
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for _ in trange(2, desc='test', leave=True):
        pass
    # Ensure that clear() is not implemented as it is not meaningful in Jupyter notebook
    try:
        tqdm_notebook().clear()
    except NotImplementedError:
        pass
    else:
        assert False



# Generated at 2022-06-12 15:14:08.198334
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as bar:
        bar.n = 1
        bar.refresh()
        bar.clear()
        assert bar.format_dict['n'] == 1
        assert bar.format_dict['bar_format'] == "{desc}{n_fmt}/{total_fmt} [{bar}]"

# Generated at 2022-06-12 15:14:14.849193
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from datetime import timedelta
    from tqdm.auto import tqdm

    for ncols in [None, 100, "100%", "100px"]:
        ip = tqdm_notebook.status_printer(
            file=None, total=100, desc=None, ncols=ncols)
        assert isinstance(ip, TqdmHBox)
        assert len(ip.children) == 3
        ltext, pbar, rtext = ip.children
        assert ltext is not None
        assert isinstance(pbar, IProgress)
        assert rtext is not None
        assert not pbar.disabled
        assert pbar.bar_style == ''
        assert pbar.value == 0
        assert pbar.min == 0
        assert pbar.max == 100

# Generated at 2022-06-12 15:14:25.017115
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from sys import version_info

    if version_info < (3, 3):  # pragma: no cover
        return  # py < 3.3 not usable by tqdm_notebook

    # create a progress bar
    pbar = tqdm_notebook(total=1)

    # update to n=1
    pbar.update()

    # Set display to False to not show the progress bar
    # and instead test it.
    pbar.display(display=False)

    # get the progress bar widgets
    ltext, pbar, rtext = pbar.container.children

    # when n=1
    assert pbar.value == 1
    assert rtext.value == ""

    # set display to False again to not show the progress bar.
    pbar.display(display=False)

    # when finished, change the

# Generated at 2022-06-12 15:14:33.332609
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from unittest.mock import patch

    with patch('IPython.display.display') as disp_mock:
        c = tqdm_notebook(range(10))
        assert len(list(c)) == 10
    disp_mock.assert_called_once_with(c.container)
    assert not c.container.visible
    assert c.container.children[-2].bar_style == 'success'

    # test try/except (RuntimeError)
    with patch('IPython.display.display') as disp_mock:
        c = tqdm_notebook(range(10))

# Generated at 2022-06-12 15:14:42.756983
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    class dummy_tqdm_notebook(object):

        @staticmethod
        def format_dict():
            return {u'bar_format': u'{percentage:3.0f}%'}

        @staticmethod
        def status_printer(file, total, desc, ncols):
            if IProgress is None:
                return file

            pbar = IProgress(min=0, max=10)
            ltext = HTML()
            rtext = HTML()
            container = TqdmHBox(children=[ltext, pbar, rtext])
            if ncols is not None:
                ncols = str(ncols)
                try:
                    if int(ncols) > 0:
                        ncols += 'px'
                except ValueError:
                    pass
                pbar.layout.flex

# Generated at 2022-06-12 15:14:48.409935
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from ..tests.samples import Sample
    with Sample(width=40, max_width=40) as s:
        d = tqdm_notebook(total=1000)
        d.display(pos=0, total=1000, bar_style='info')
        d.display(pos=100, total=1000, bar_style='success', check_delay=False)
        d.display(pos=1000,
                  total=1000,
                  bar_style='danger',
                  check_delay=False)
        d.close()
        assert s.ind == s.len
        assert d.displayed

# Generated at 2022-06-12 15:15:05.342191
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook()
    t.close()
    assert t.displayed is False
    t.display()
    assert t.displayed is True
    t.close()
    assert t.displayed is False
    t.close()
    assert t.displayed is False

# Generated at 2022-06-12 15:15:11.813658
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Test that the method status_printer return an instance of an HBox widget.
    """
    # Test with a total
    hbox = tqdm_notebook.status_printer(None, total=10)
    assert isinstance(hbox, HBox)
    assert len(hbox.children) == 3
    assert isinstance(hbox.children[0], HTML)
    assert isinstance(hbox.children[1], IProgress)
    assert isinstance(hbox.children[2], HTML)
    # Test without a total
    hbox = tqdm_notebook.status_printer(None, total=None)
    assert isinstance(hbox, HBox)
    assert len(hbox.children) == 3
    assert isinstance(hbox.children[0], HTML)

# Generated at 2022-06-12 15:15:20.951993
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
     WARNING: as this function is part of the main file, it should not be
     executed if the main file is imported.
     So if this test is to be executed, the first test in main should be
     disabled.
    :return:
    """
    from tqdm import tqdm_notebook as tqdm

    for i in tqdm(range(2)):
        for j in tqdm(range(2)):
            tqdm.reset(total=4)
            for k in tqdm(range(4)):
                pass
    tqdm.close()


if __name__ == '__main__':
    test_tqdm_notebook_reset()
    # import doctest
    # doctest.testmod()

# Generated at 2022-06-12 15:15:29.208211
# Unit test for method display of class tqdm_notebook

# Generated at 2022-06-12 15:15:38.716248
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import random
    import time
    total_iterations = 20
    pbar = tqdm_notebook(total=total_iterations)
    for i in pbar:
        time.sleep(0.1)
        if pbar.last_print_n != i + 1 or pbar.n != i + 1:
            raise AssertionError("Bad iterations number (n={}, last_print_n={}".format(
                pbar.n, pbar.last_print_n))
        if i == total_iterations // 2:
            if random.choice([True, False]):
                raise Exception("Exception in iter")
        pbar.set_description("Iteration {}".format(i))
    pbar.close()


# Generated at 2022-06-12 15:15:40.472839
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for __ in tqdm_notebook([""]):
        pass


if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:15:49.422863
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import time
    try:
        from unittest import mock
    except ImportError:
        import mock  # NOQA Py2
    with mock.patch('sys.stderr', new=mock.Mock()):
        # Test msg
        with tqdm(total=2, desc='testing') as t:
            t.display(msg='5%')
            assert t.container.children[0].value == 'testing'
            assert t.container.children[1].value == ''
            assert t.container.children[2].value == '5%'
            # Test no msg
            t.display()
            assert t.container.children[0].value == 'testing'
            assert t.container.children[1].value == ''
            assert t.container.children[2].value == '0/2'
            # Test

# Generated at 2022-06-12 15:15:57.949660
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from time import sleep as time_sleep
    from .gui import tqdm_gui
    from .utils import _term_move_up

    # Capturing stdout and stderr to check if the progress bars are properly
    # updated (since this is the only automatic way to really test the
    # progress bars)
    import os
    import sys
    import tempfile
    with tempfile.TemporaryFile() as temp:
        sys_stdout_fd = sys.stdout.fileno()
        saved_stdout = os.dup(sys_stdout_fd)
        os.dup2(temp.fileno(), sys_stdout_fd)
        with tempfile.TemporaryFile() as temp2:
            sys_stderr_fd = sys.stderr.fileno()
            saved_stderr = os.du

# Generated at 2022-06-12 15:16:02.861188
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import warnings
    warnings.warn("A warning", DeprecationWarning)
    final_result = "Empty"
    with tqdm_notebook(total=1, desc="Before") as t1:
        assert t1.format_dict["desc"] == "Before"
        t1.clear()
        t1.set_postfix_str("After")
        assert t1.format_dict["desc"] == "After"
        final_result = repr(t1.container.children[1])
    return final_result

# Generated at 2022-06-12 15:16:08.568720
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from unittest import TestCase
    from six import PY3

    class MyTest(TestCase):
        def test_tqdm_notebook_display(self):
            try:
                import tqdm  # NOQA
            except:
                raise self.skipTest('Requires `tqdm`')

            try:
                import ipywidgets  # NOQA
            except:
                raise self.skipTest('Requires `ipywidgets`')

            bar = tqdm.tqdm_notebook(total=1, desc='foo')
            if PY3:
                self.assertEqual(bar.container.children[0].value, 'foo')
            else:
                self.assertEqual(bar.container.children[0].value, u'foo')

# Generated at 2022-06-12 15:16:49.783402
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from IPython.display import clear_output
    with tqdm_notebook(total=3) as test:
        assert len(list(test)) == 3
        test.close()
        clear_output()
        # Should safely iterate even with error during iteration
        with tqdm_notebook(total=3) as test:
            assert len(list(test)) == 3
            raise RuntimeError()
        clear_output()
        # Exception should also be re-raised
        with pytest.raises(RuntimeError):
            with tqdm_notebook(total=3) as test:
                assert len(list(test)) == 3
                raise RuntimeError()

# Generated at 2022-06-12 15:16:57.865289
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO
    from contextlib import redirect_stdout
    from time import sleep
    from tqdm.notebook import trange

    # pipeline = StringIO()
    # with redirect_stdout(pipeline):
    for _ in trange(10, desc='desc', leave=True, bar_format='{l_bar}{bar}'):
        sleep(0.01)
        # print(pipeline.getvalue())

if __name__ == '__main__':  # pragma: no cover
    test_tqdm_notebook_display()

# Generated at 2022-06-12 15:17:03.394277
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test normal use
    for i in tqdm_notebook(range(3)):
        assert i == i

    # Test exception propagation (IPython).
    # Note: doesn't work (finishes without raising error)
    #       on Python command line, only in IPython
    # try:
    #     for i in tqdm_notebook(range(3)):
    #         assert i == i
    #         raise Exception()
    # except:
    #     pass



# Generated at 2022-06-12 15:17:07.866176
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from itertools import repeat
    for rng in repeat(range(6), 2):
        with tqdm_notebook(rng) as t:
            for _ in t:
                continue
        assert t.n == t.total
    try:
        with tqdm_notebook(range(6)) as t:
            for _ in t:
                raise ValueError()
    except ValueError:
        pass
    else:
        assert False, "tqdm_notebook(...).__iter__ did not raise ValueError()"
    assert t.n < t.total, "tqdm_notebook(...).__iter__ did not raise ValueError()"



# Generated at 2022-06-12 15:17:15.004904
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from datetime import timedelta
    from time import sleep
    from tqdm.auto import trange, tqdm_notebook
    from tqdm import main
    import os

    # Test no IPython
    if 'TERM' in os.environ:
        # Hack because IPython on auto mode still detects as available in
        # ipython on rapidshare (not even able to pip install!)
        del os.environ['TERM']
    assert main.main(['--help']) == 0
    os.environ['TERM'] = 'xterm'  # restore term

    # Test no IPython
    ip = 'IPython'
    if ip not in sys.modules:
        # Hack because IPython on auto mode still detects as available in
        # ipython on rapidshare (not even able to pip install!)
        sys.modules

# Generated at 2022-06-12 15:17:19.742692
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO

    os_prev = std_tqdm.fileio
    std_tqdm.fileio = StringIO()

    try:
        pbar = tqdm_notebook(total=6)
        for _ in range(3):
            pbar.display(msg='Test display')
        pbar.display(msg='Test closing', close=True)

        assert std_tqdm.fileio.getvalue().strip('\r\n') == r'Test display Test closing'
    finally:
        std_tqdm.fileio = os_prev

# Generated at 2022-06-12 15:17:29.441764
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():  # NOQA: D103
    for d in (0, 0.1, 1):
        for i in tnrange(1000, desc='test_1', leave=False,
                         bar_format=r'{desc}: {n}/{total}',
                         display_interval=d):
            pass
        for i in tnrange(1000, desc='test_2', leave=True,
                         bar_format=r'{desc}: {n}/{total}',
                         display_interval=d):
            pass
        for i in tnrange(1000, desc='test_3', leave=True, mininterval=0,
                         bar_format=r'{desc}: {n:.1f}/{total}',
                         display_interval=d):
            pass

# Generated at 2022-06-12 15:17:33.063079
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    # %pdb
    with tqdm_notebook(total=3) as pbar:
        time.sleep(1)
        pbar.update()
        raise Exception()
        time.sleep(1)
        pbar.update()
        time.sleep(1)
        pbar.update()

# Generated at 2022-06-12 15:17:37.238409
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    pbar = tqdm_notebook(range(10))
    for i in pbar:
        pbar.disp(pbar.format_dict['bar'])
        assert (pbar.container.children[0].value == pbar.format_dict['bar'])
    pbar.close()


# Generated at 2022-06-12 15:17:43.795573
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from nose.tools import assert_equal

    # Initialize a progress bar
    bar = tqdm_notebook(total=10)

    # Check that the progress bar is displayed and has the good properties
    assert_equal(bar.container.children[-2].max, 10)
    assert_equal(bar.container.children[-2].value, 0)

    # Update the progress bar and check the value
    bar.update(0)
    assert_equal(bar.container.children[-2].value, 0)

    # Update and check the value
    bar.update(2)
    assert_equal(bar.container.children[-2].value, 2)

    # Reset the progress bar
    bar.reset(total=5)

    # Check that the progress bar is displayed and has the good properties

# Generated at 2022-06-12 15:18:18.765856
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in range(1, 5):
        t = tqdm_notebook(total=5, disable=False, position=i)
        for j in range(5):
            t.update(1)


if __name__ == '__main__':  # pragma: no cover
    import time, os
    test_tqdm_notebook_update()

    try:  # prevent Jupyter going crazy with too much outputs
        for _ in tqdm(range(5), desc='1st loop', leave=False):
            for _ in tqdm(range(3), desc='2nd loop', leave=True, ncols=50):
                time.sleep(0.01)
    except KeyboardInterrupt:
        # avoid two ^C showing up in Jupyter notebook
        pass

    from .main import main

# Generated at 2022-06-12 15:18:26.925107
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import io
    import json

    cell_width = 80
    cell_width_json = 120

    def _format_json(d):
        buf = io.StringIO()
        json.dump(d, buf, indent=2, sort_keys=True)
        return buf.getvalue()

    # Check default bar with 100% completed (total=1)
    d = tqdm_notebook.status_printer(total=1).pbar.format_dict
    assert d['bar'] == d['postfix'] == d['postfix_str'] == ''
    assert d['ascii'] or d['bar'] == '100%'
    assert d['ascii'] or len(d['bar']) <= cell_width
    assert not d['ascii'] or d['bar'] == '|###| 100%'

   

# Generated at 2022-06-12 15:18:37.725405
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from ._tqdm_test_sample import sample_iterable
    with tqdm_notebook(total=None, disable=True) as t:
        assert t == list(tqdm_notebook(sample_iterable(), total=None, disable=True))

    with tqdm_notebook(total=None, disable=False) as t:
        assert t == list(tqdm_notebook(sample_iterable(), total=None, disable=False))

    with tqdm_notebook(total=100, disable=False) as t:
        assert t == list(tqdm_notebook(sample_iterable(), total=100, disable=False))


# Generated at 2022-06-12 15:18:44.750663
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from time import sleep
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.update(1)
            sleep(0.1)
    with tqdm_notebook(total=10,
                       desc='Test 1',
                       leave=True,
                       unit_scale=True,
                       unit='its') as t:
        for i in range(10):
            t.update(1)
            sleep(0.1)
    with tqdm_notebook(total=9,
                       desc='Test 2',
                       leave=False,
                       unit_scale=True,
                       unit='its') as t:
        for i in range(9):
            t.update(1)
            sleep(0.1)

# Generated at 2022-06-12 15:18:49.756967
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Check that `tqdm.notebook.tqdm_notebook.status_printer` works
    """
    # Cannot test this when tqdm_notebook is not loaded.
    if not IPY:
        return

    # Import here to avoid dependence in setup.py
    from .gui import tqdm
    from .std import tqdm as std_tqdm

    nrows, ncols = 2, 2
    orig_rows = std_tqdm.get_ipython_widget().layout.height
    orig_cols = std_tqdm.get_ipython_widget().layout.width

# Generated at 2022-06-12 15:18:56.880058
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    with tqdm_notebook(total=3) as pbar:
        for i in _range(3):
            sleep(0.5)
            pbar.update(1)
        pbar.reset(4)
        for i in _range(4):
            sleep(0.5)
            pbar.update(1)
        pbar.reset()
        for i in _range(4):
            sleep(0.5)
            pbar.update(1)
        pbar.reset(3)
        for i in _range(3):
            sleep(0.5)
            pbar.update(1)
test_tqdm_notebook_reset()


# Unit test (tqdm/tqdm#872 and tqdm/tqdm#924)

# Generated at 2022-06-12 15:19:05.646166
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test the tqdm_notebook constructor"""
    try:
        from IPython.core.getipython import get_ipython
    except ImportError:
        from IPython import get_ipython  # NOQA: ignore=F811
    from .utils import FormatCustomTextTest, TestCase, pretest_check_version
    pretest_check_version()

    with FormatCustomTextTest(
            "{desc}: {n:4d}/{total:4d}",
            desc='test', total=5, leave=False) as t:
        with TestCase(t) as tc:
            tc.assertEqual(str(t), "test:    0/   5")
            tc.assertEqual(t.n, 0)
            tc.assertEqual(t.total, 5)
            t.update()


# Generated at 2022-06-12 15:19:13.393527
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from time import sleep
    # Initialize
    t = tqdm_notebook(total=2)
    assert not t.displayed

    # Update once
    t.update(1)
    assert t.displayed

    # Try to close the bar
    t.close()
    assert t.displayed
    sleep(0.15)  # wait for the display to refresh

    # Close the bar
    t.close()
    assert t.displayed
    sleep(0.15)  # wait for the display to refresh

    assert not t.displayed



# Generated at 2022-06-12 15:19:21.331038
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """
    Test perfect behaviour of the method clear.
    """
    from .tests.utils import free_port
    from .tqdm import TqdmTypeError
    from threading import Thread
    from tornado import ioloop, web, httpserver

    io_loop = ioloop.IOLoop.current()

    def start_web():
        class MainHandler(web.RequestHandler):
            def get(self):
                self.write("Hello, world")

        app = web.Application([
            (r"/", MainHandler),
        ])

        server = httpserver.HTTPServer(app)
        server.listen(free_port())
        io_loop.start()

    Thread(target=start_web).start()

# Generated at 2022-06-12 15:19:28.301007
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    pbar = tnrange(10)
    pbar.reset(total=20)
    assert pbar.total == 20
    assert pbar.n == 0
    assert pbar.last_print_n == 0
    assert pbar.container.children[-2].max == 20
    assert pbar.container.children[-2].value == 0
    pbar.reset()
    assert pbar.total is None
    assert pbar.n == 0
    assert pbar.last_print_n == 0
    assert pbar.container.children[-2].max == 1
    assert pbar.container.children[-2].value == 1
    pbar.reset(total=15)
    assert pbar.container.children[-2].max == 15
    assert pbar.container.children[-2].value == 1
   

# Generated at 2022-06-12 15:20:23.973304
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from io import StringIO
    close = '<div style="display: none;">\n' \
            '  <div style="float: left; width: 15px; font-weight: bold;">\n' \
            '    18%\n' \
            '  </div>\n' \
            '  <div style="background-color: #4CAF50; width: 100%; height: 100%; float: left;">' \
            '</div>\n' \
            '</div>\n' \
            '</div>\n'

# Generated at 2022-06-12 15:20:27.771422
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """ Tests the method __iter__ of class tqdm_notebook """

    num_iterations = 100

    # tqdm.notebook.tqdm.__iter__
    pbar = tqdm(iterable = range(num_iterations),
                disable = False)

    # iterate through the for loop
    for i in range(num_iterations):
        assert pbar.n == i
        next(pbar)

    # close the progress bar
    pbar.close()



# Generated at 2022-06-12 15:20:31.976898
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    class Test(tqdm_notebook):
        def update(self, *args, **kwargs):
            # avoid displaying it in notebook
            return self.last_print_n

    try:
        tn = Test(total=10, disable=True)
        for _ in tn:
            pass
        assert tn.n == 10
        tn.reset()
        tn.update(1)
        assert tn.n == 1
    except Exception:
        raise
    finally:
        tn.close()

# Generated at 2022-06-12 15:20:34.600924
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Test method __iter__ of class tqdm_notebook."""
    import time
    # prepare test parameters
    n = 10
    delay = 0.2  # to avoid flickering
    # start test
    for _i in tqdm_notebook(range(n), file=sys.stdout, leave=False):
        time.sleep(delay)

# Generated at 2022-06-12 15:20:38.641814
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    import numpy as np
    for i in trange(100):
        time.sleep(0.01)
        # test signals:
        # msg='', bar_style='', miniters=0, e.g. info bar
        # msg='', bar_style='success', miniters=1, e.g. success bar
        trange.display(msg='' * (i % 2), bar_style='' * (i % 2),
                       miniters=i % 2, ncols=100)


if __name__ == "__main__":
    test_tqdm_notebook_update()

# Generated at 2022-06-12 15:20:46.529083
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    from .std import TqdmTypeError
    from .utils import _term_move_up

    from .std import TqdmExperimentalWarning
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore', category=TqdmExperimentalWarning)
        for i in tqdm_notebook(range(3)):
            time.sleep(0.01)
    for i in tqdm_notebook(range(10), leave=True):
        time.sleep(0.01)
    with open('/dev/null', 'w') as nul:
        pbar = tqdm_notebook(range(3), file=nul)
    assert pbar.file is nul

# Generated at 2022-06-12 15:20:51.446737
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(ncols=100) as t:
        t.update(45)
        assert t.n == 45
        assert t.pbar.value == 45
        assert t.container.layout.width == "100px"
        t.displayed = True
        t.update(83)
        assert t.container.layout.width == "100px"
        assert t.pbar.value == 83

# Generated at 2022-06-12 15:20:59.881728
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for tqdm_notebook.status_printer method.
    """
    # Note: if this test fails, it does not necessarily mean the function does
    # not work as expected, but may be a side effect of an update of ipywidgets.
    # Please refer to https://github.com/tqdm/tqdm/pull/860 and
    # https://github.com/tqdm/tqdm/pull/872 for more info

    # Check if ipywidgets is installed
    if IProgress is None:
        return

    # Call function
    hbox = tqdm_notebook.status_printer(None, total=10, desc="Test")

    # Check HBox
    assert isinstance(hbox, TqdmHBox)
    assert len(hbox.children) == 3

# Generated at 2022-06-12 15:21:03.351205
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    assert tqdm_notebook(range(50)).update() == 1
    assert tqdm_notebook(range(50)).update(1) == 1
    assert tqdm_notebook(range(50)).update(10) == 10

# Generated at 2022-06-12 15:21:06.336377
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    import time
    with tqdm_notebook(total=3) as pbar:
        for i in range(3):
            time.sleep(0.1)
            pbar.update()
    assert not pbar.container.visible
