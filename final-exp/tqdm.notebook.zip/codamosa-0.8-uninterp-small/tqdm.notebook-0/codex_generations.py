

# Generated at 2022-06-26 09:46:44.294190
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook()
    assert(tqdm_notebook_0.__iter__() == tqdm_notebook_1.__iter__())


# Generated at 2022-06-26 09:46:47.569271
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.status_printer(_, total=None, desc=None, ncols=None)


# Generated at 2022-06-26 09:46:56.358523
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # it would be nice to test display() method more thoroughly
    # but this method is tightly coupled with ipywidgets and
    # we do not want them imported unnecessarily in setup.py
    from tqdm import tqdm_notebook
    pbar = tqdm_notebook()
    pbar.start()
    for _ in pbar:
        pass
    pbar.close()



# Generated at 2022-06-26 09:47:04.447688
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    """
    check that closing of the bar works
    """
    t0 = tqdm_notebook(total=100)
    for k in range(100):
        t0.update(1)
    t0.close()
    if t0.displayed and t0.n == t0.total:
        pass
    else:
        raise ValueError("Closing of the bar doesn't work")


# Generated at 2022-06-26 09:47:07.512526
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:47:11.581558
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:47:21.533401
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    x = tqdm_notebook
    import ipywidgets as ipyw
    ipywidgets.HBox = ipyw.HBox
    ipywidgets.FloatProgress = ipyw.FloatProgress
    ipywidgets.HTML = ipyw.HTML
    fp = sys.stdout
    total = 10
    desc = "test"
    ncols = 100
    widget = x.status_printer(fp,total,desc,ncols)
    assert type(widget) == ipyw.HBox
    assert widget.layout.width == "100%"


# Generated at 2022-06-26 09:47:25.143711
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.close()


# Generated at 2022-06-26 09:47:28.439233
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:47:32.894603
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    # assert isinstance(tqdm_notebook_0.__iter__(), __generator_modified);


# Generated at 2022-06-26 09:48:28.534904
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.avg_time = 0.0
    tqdm_notebook_0.container.pbar = None
    tqdm_notebook_0.dynamic_ncols = False
    tqdm_notebook_0.format_dict = {'bar_format': '{desc}{percentage:3.0f}%|{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_noinv_fmt}]'}
    tqdm_notebook_0.format_interval = 0.05000000074505806
    tqdm_notebook_0.l_bar_template = '{l_bar}'
    tqdm_note

# Generated at 2022-06-26 09:48:36.280330
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from IPython.display import clear_output
    except ImportError:
        pass
    tqdm_notebook_0 = tqdm_notebook("test", bar_format="{desc}:{bar}", disable=True)
    if tqdm_notebook_0.disable:
        tqdm_notebook_0.disp("msg", pos="pos", close=True, bar_style="bar_style", check_delay=True)
    else:
        tqdm_notebook_0.disp("msg", pos="pos", close=True, bar_style="bar_style", check_delay=True)


# Generated at 2022-06-26 09:48:45.670066
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from nose.tools import assert_equal
    # Tests
    with test_case_0.tqdm_notebook_0 as t:
        for i in t:
            assert_equal(t.n, i)
            if t.n >= 5:
                t.clear()
                t.display()
                break
            t.update()


# Generated at 2022-06-26 09:48:48.795908
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Make sure that it closes without error
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.close()
    pass


# Generated at 2022-06-26 09:48:58.723300
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.notebook import tqdm_notebook
    import sys
    total = 10
    with tqdm_notebook(total=total) as pbar:
        for i in range(total):
            pbar.update()

    total = 100
    with tqdm_notebook(total=total) as pbar:
        for i in range(100):
            pbar.reset(total=total)
            pbar.update()

# Generated at 2022-06-26 09:49:08.692685
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook(desc="clear_test")
    tqdm_notebook_1.update()
    tqdm_notebook_1.clear()
    tqdm_notebook_1.clear("test_case")
    tqdm_notebook_1.clear("test_case", 'test_case')


# Generated at 2022-06-26 09:49:12.230121
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Prepare IPython progress bar
    test_printer = tqdm_notebook()
    test_printer.status_printer(None, 10, '')


# Generated at 2022-06-26 09:49:18.285301
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .gui import tqdm as tqdm_gui
    from .std import tqdm as tqdm_std

    if tqdm_gui == tqdm_notebook:
        test_case_0()



# Generated at 2022-06-26 09:49:27.001089
# Unit test for method display of class tqdm_notebook

# Generated at 2022-06-26 09:49:32.102350
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_0 = tqdm_notebook()
    assert isinstance(tqdm_notebook_0.close(), None) == True


# Generated at 2022-06-26 09:50:10.503561
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IProgress is None:
        return
    pbar = tqdm_notebook.status_printer(None)
    # pbar.test_1()
    assert pbar.layout.width == '100%'
    assert pbar.layout.display == 'inline-flex'
    assert pbar.layout.flex_flow == 'row wrap'
    assert pbar.children[0].class_ == ['widget-html']
    assert pbar.children[1].class_ == ['widget-float-progress']
    assert pbar.children[2].class_ == ['widget-html']
    assert pbar.children[1].layout.flex == '2'


# Generated at 2022-06-26 09:50:12.244722
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(range(10))
    tqdm_notebook_1_update = tqdm_notebook_1.update(1)
    #tqdm_notebook_0.update(1)


# Generated at 2022-06-26 09:50:14.681525
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    total = None
    tqdm_notebook_0.reset(total)


# Generated at 2022-06-26 09:50:23.276338
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Test case with total set and n < total
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_1.n = 2  # test value for n
    tqdm_notebook_1.total = 10  # test value for total
    tqdm_notebook_1.container_children = [u'test value for ltext', u'test value for pbar', u'test value for rtext']  # test value for children
    tqdm_notebook_1.container = u'test value for container'  # test value for container
    tqdm_notebook_1.container.pbar = u'test value for pbar'  # test value for pbar
    tqdm_notebook_1.displayed = False  # test value for displayed
   

# Generated at 2022-06-26 09:50:29.672924
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tnb = tqdm_notebook(total=100, ncols=100)
    tnb.display(close=True)
    tnb.display(msg="Testing")
    tnb.display(bar_style='success')
    tnb.close()
    tnb.display(bar_style='success')
    tnb.display()



# Generated at 2022-06-26 09:50:34.716393
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    wdgs = tqdm_notebook.status_printer()
    ltext, pbar, rtext = wdgs.children
    assert type(ltext) == HTML
    assert type(rtext) == HTML
    assert type(pbar) == IProgress


# Generated at 2022-06-26 09:50:43.822754
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # test with default total
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.total is None

    # test with custom total
    tqdm_notebook_2 = tqdm_notebook(total=10)
    tqdm_notebook_2.reset(total=10)
    assert tqdm_notebook_2.n == 0
    assert tqdm_notebook_2.total == 10


# Generated at 2022-06-26 09:50:51.898494
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    tqdm_notebook_1.update(int(sys.argv[1]))
    tqdm_notebook_1.update(n=int(sys.argv[2]))
    tqdm_notebook_1.update(1)
    tqdm_notebook_1.update(2)
    tqdm_notebook_1.update(n=3)
    tqdm_notebook_1.update(n=4)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_update()

# Generated at 2022-06-26 09:50:57.726883
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        tqdm_notebook_1 = tqdm_notebook()
        tqdm_notebook_1.reset(total=None)
    except BaseException as e:
        raise e


# Generated at 2022-06-26 09:51:00.576132
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display("message", 1, close=True, bar_style=None, check_delay=True)


# Generated at 2022-06-26 09:51:35.690869
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import clear_output
    tqdm_notebook_disp_0 = tqdm_notebook()

    # 1. call display() with no input and check the output
    tqdm_notebook_disp_0.display()

    # 2. call display() with msg='' and check the output
    msg_0 = ''
    tqdm_notebook_disp_0.display(msg=msg_0)

    # 3. call display() with msg='hello' and check the output
    msg_1 = 'hello'
    tqdm_notebook_disp_0.display(msg=msg_1)

    # 4. call display() with msg='hello' and pos=1 and check the output
    pos_0 = 1

# Generated at 2022-06-26 09:51:43.070540
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    #test tqdm_notebook with total parameter included
    test_with_total = tqdm_notebook.status_printer(0,total=10, ncols=100)
    assert isinstance(test_with_total, TqdmHBox)

    #test tqdm_notebook without total parameter included
    test_without_total = tqdm_notebook.status_printer(0)
    assert isinstance(test_without_total, TqdmHBox)

# Generated at 2022-06-26 09:51:56.263972
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test all four cases
    tqdm_notebook_1 = tqdm_notebook(file=None, disable=False)
    tqdm_notebook_2 = tqdm_notebook(file=None, disable=False)
    tqdm_notebook_3 = tqdm_notebook(file=None, disable=False)
    tqdm_notebook_4 = tqdm_notebook(file=None, disable=False)
    tqdm_notebook_1.total = 2
    tqdm_notebook_1.ncols = 100
    tqdm_notebook_1.unit = 'it'
    tqdm_notebook_2.total = 2
    tqdm_notebook_2.ncols = 100

# Generated at 2022-06-26 09:52:00.726018
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:52:09.431925
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from IPython.display import HTML, clear_output
    from unittest.mock import MagicMock

    def display(self, msg=None, pos=None,
                # additional signals
                close=False, bar_style=None, check_delay=True):
        if close:
            self.closed = True

    HTML_value = HTML()
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.container = MagicMock()

    # Assign test values
    tqdm_notebook_0.container.children = [HTML_value, None, None]
    tqdm_notebook_0.display = display
    tqdm_notebook_0.disable = False
    tqdm_notebook_0.total = 0
    tqdm_notebook

# Generated at 2022-06-26 09:52:16.519394
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Init a new tqdm_notebook object
    tqdm_notebook_0 = tqdm_notebook()
    result = tqdm_notebook_0.__iter__()
    assert result is None


# Generated at 2022-06-26 09:52:30.239229
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook(total=2)

    tqdm_notebook_0.n = 1
    tqdm_notebook_0.format_dict['bar_format'] = '{bar}'
    tqdm_notebook_0.format_dict['bar_format'] = '{bar}'
    tqdm_notebook_0.container.__repr__('{bar}')
    assert tqdm_notebook_0.container._repr_json_(True) == {'bar': '█', 'bar_format': '{bar}'}
    tqdm_notebook_0.container.__repr__()
    assert tqdm_notebook_0.container._repr_json_(True) == tqdm_notebook_0.container.__

# Generated at 2022-06-26 09:52:31.688570
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()

# Generated at 2022-06-26 09:52:33.453358
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    this_tqdm = tqdm_notebook()
    this_tqdm.update(123)


# Generated at 2022-06-26 09:52:40.710015
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=10, desc='unit test') as t:
        t.reset()
        assert t.container.children[-2] is not None and t.container.children[-2].bar_style == ''

if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-26 09:53:54.723092
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    pbar = tqdm_notebook()
    pbar.display()


# Generated at 2022-06-26 09:54:00.621716
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm.notebook import tqdm_notebook
    from tqdm import trange
    from time import sleep

    # Initialize tqdm_notebook
    for i in tqdm_notebook(range(10), desc='1st loop'):
        for j in tqdm_notebook(range(5), desc='2nd loop', leave=False):
            for k in trange(100, desc='3nd loop', leave=False):
                sleep(0.01)



# Generated at 2022-06-26 09:54:06.977330
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import _get_tqdm_tqdm_tqdm_tqdm  # NOQA

    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.display()
    except:
        pass

    # Test display method of class tqdm_notebook
    _get_tqdm_tqdm_tqdm_tqdm(
        lambda: tqdm_notebook(display=True),
        None,
        None,
        [None],
        [None],
        [None],
        [None],
        'test_tqdm',
        )._test(None)


# Generated at 2022-06-26 09:54:17.538311
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test when total is not None
    pbar = tqdm_notebook.status_printer(None,10)
    assert(pbar.children[0].value == '')
    assert(pbar.children[1].min == 0)
    assert(pbar.children[1].max == 10)
    assert(pbar.children[1].value == 0)
    assert(pbar.children[2].value == '')

    # Test when total is None
    pbar = tqdm_notebook.status_printer(None,desc="Example")
    assert(pbar.children[0].value == 'Example')
    assert(pbar.children[1].min == 0)
    assert(pbar.children[1].max == 1)
    assert(pbar.children[1].value == 1)

# Generated at 2022-06-26 09:54:23.236849
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update(None)
    tqdm_notebook_1.update(1)


# Generated at 2022-06-26 09:54:28.473241
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test with arguments (both positional and keyword)
    # expected_result = None
    # actual_result = tqdm_notebook_0.display()
    # assert expected_result == actual_result

    # Test without arguments
    # expected_result = None
    # actual_result = tqdm_notebook_0.display()
    # assert expected_result == actual_result

    pass



# Generated at 2022-06-26 09:54:40.251454
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    iterable = range(2)

    tqdm_notebook_0 = tqdm_notebook(iterable, desc='test1')
    tqdm_notebook_0.update()
    # tqdm_notebook.update(n=1)

    tqdm_notebook_0 = tqdm_notebook(iterable)
    tqdm_notebook_0.update()

    # tqdm_notebook_0.update(desc='test2')
    tqdm_notebook_0.update(n=collections.abc.Callable)


# Generated at 2022-06-26 09:54:43.911105
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert tqdm_notebook.status_printer(fp=None, total=None, desc=None, ncols=None)


# Generated at 2022-06-26 09:54:50.670913
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Check that the bar is correct and that widget is a HBox object
    """
    tqdm_notebook_1 = tqdm_notebook()
    value = tqdm_notebook_1.status_printer(None, total=10, desc="test")
    assert value.__class__.__name__ == 'HBox'
    ltext, pbar, rtext = value.children
    assert len(ltext.value) == len("test")
    assert pbar.bar_style == ''
    assert rtext.value == ''


# Generated at 2022-06-26 09:54:54.407545
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    np.random.rand(10)
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()
    

# Generated at 2022-06-26 09:56:03.894963
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=10, leave=True, disable=False, gui=True) as t:
        for i in range(10):
            t.update()
    print('End')


# Generated at 2022-06-26 09:56:09.562657
# Unit test for method __iter__ of class tqdm_notebook

# Generated at 2022-06-26 09:56:15.658195
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # tqdm_notebook_case_0 = tqdm_notebook(xrange(100))
    # assert test_case_0(tqdm_notebook_case_0) == "tqdm_notebook"
    pass

# Generated at 2022-06-26 09:56:20.947670
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from random import shuffle
    from time import sleep
    from tqdm import trange

    # Create a manually controlled tqdm instance
    with trange(10) as t:
        for i in t:
            sleep(0.01)
            if i == 6:
                break

    # Reset it
    t.reset(5)
    assert t.total == 5

    # Update and reset it again
    t.update()
    t.reset()
    assert t.total is None

    # Repeat, but with tqdm class
    with tqdm(total=10) as t:
        for i in range(10):
            sleep(0.01)
            if i == 6:
                break

    t.reset(5)
    assert t.total == 5

    t.update()
    t.reset()