

# Generated at 2022-06-26 09:46:49.766761
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:46:54.848893
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    test_int = 10
    total = tqdm_notebook_0.reset(total = test_int)
    assert test_int == total

# Generated at 2022-06-26 09:46:56.358711
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t.reset(total=None)


# Generated at 2022-06-26 09:46:57.944848
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    status_printer_input = tqdm_notebook.status_printer()



# Generated at 2022-06-26 09:47:01.457644
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    obj = tqdm_notebook()
    obj.status_printer(None, 50, "Desc", None)


# Generated at 2022-06-26 09:47:07.686737
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        pbar = tqdm_notebook(total=100, desc='Title', leave=True)
        pbar.display(msg='', pos=10, close=False, bar_style=None, check_delay=True)
    except:
        return False
    return True


# Generated at 2022-06-26 09:47:21.755105
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test for constructor
    #    class tqdm_notebook(std_tqdm):
    # No progress bar will show up without test_case_0()

    tqdm_notebook_0 = tqdm_notebook(total=10)
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_1.total = 20
    if tqdm_notebook_1.total == 20:
        # Test for method clear
        tqdm_notebook_1.clear()

    # Test for method close
    tqdm_notebook_0.close()

    # Test for method display
    tqdm_notebook_0.display()

    # Test for method reset
    tqdm_notebook_0.reset()
    tqdm_

# Generated at 2022-06-26 09:47:24.727077
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for _ in tqdm_notebook(range(4)):
        pass

if __name__ == "__main__":
    test_tqdm_notebook()
    test_case_0()

# Generated at 2022-06-26 09:47:31.872413
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test case 1
    # test display method with arguments msg, pos, close, bar_style and check_delay
    tqdm_notebook_1 = tqdm_notebook(total = 25)
    # test display method with no arguments
    tqdm_notebook_1.display()
    # test display method with arguments msg, pos, close and bar_style
    tqdm_notebook_1.display(msg = "Unit test case", pos = 12, close = False, bar_style = "info")


# Generated at 2022-06-26 09:47:37.900568
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_h_box_0 = tqdm_notebook.status_printer(10, total=10, desc='None', ncols=10)
    assert isinstance(tqdm_h_box_0, TqdmHBox)


# Generated at 2022-06-26 09:47:53.477649
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()


# Generated at 2022-06-26 09:48:01.467511
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    file = sys.stdout
    total = 10
    desc = "test"
    ncols = 100
    tqdm_notebook_1.status_printer(file, total, desc, ncols)
    return


# Generated at 2022-06-26 09:48:04.067775
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert __repr__()

# Generated at 2022-06-26 09:48:11.071445
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from random import random
    from time import sleep
    list1 = [random() for x in tqdm_notebook(range(10))]
    assert len(list1) == 10

    for x in tqdm_notebook(range(10)):
        sleep(0.01)


# Generated at 2022-06-26 09:48:12.339531
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()

# Generated at 2022-06-26 09:48:19.369982
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test with a msg
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.unit_scale = True
    tqdm_notebook_1.n = 15
    tqdm_notebook_1.total = 100
    tqdm_notebook_1.dynamic_ncols = True
    tqdm_notebook_1.unit = 'it'
    tqdm_notebook_1.unit_scale = 1
    tqdm_notebook_1.unit_divisor = 10
    tqdm_notebook_1.miniters = 1
    tqdm_notebook_1.mininterval = 0
    tqdm_notebook_1.maxinterval = 10
    tqdm_notebook_1.ascii

# Generated at 2022-06-26 09:48:32.008894
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # pylint: disable=no-member
    assert(tqdm_notebook.status_printer(None) is not None)
    assert(tqdm_notebook.status_printer(None, total=10) is not None)
    assert(tqdm_notebook.status_printer(None, total=10, desc='Description') is not None)
    assert(tqdm_notebook.status_printer(None, total=10, desc='Description', ncols=20) is not None)
    assert(tqdm_notebook.status_printer(None, total=None, desc='Description', ncols=20) is not None)
    assert(tqdm_notebook.status_printer(None, total=None) is not None)

# Generated at 2022-06-26 09:48:41.462483
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Instantiate dummy object of class to test
    tqdm_notebook_3 = tqdm_notebook()

    # Unit test for calling method reset() of object tqdm_notebook_3
    result_tqdm_notebook_3 = tqdm_notebook_3.reset()
    assert isinstance(result_tqdm_notebook_3, tqdm_notebook)

# Generated at 2022-06-26 09:48:46.235802
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:48:49.468714
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook([1, 2, 3, 4, 5],desc="Testing tqdm")
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:49:16.445787
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    print("Test of update()")
    for i in tqdm_notebook_0.update(20):
        print(i)


# Generated at 2022-06-26 09:49:19.859958
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test extending the base tqdm class with the tqdm_notebook class
    test_case_0()

# Generated at 2022-06-26 09:49:23.025971
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    x = tqdm_notebook()
    x.reset()
    x.reset(total=1)



# Generated at 2022-06-26 09:49:24.492737
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    test_case_0()


# Generated at 2022-06-26 09:49:26.725578
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    expected_result = [1, 2, 3]
    actual_result = list(tqdm_notebook([1, 2, 3]))
    assert actual_result == expected_result



# Generated at 2022-06-26 09:49:37.881997
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.n = 0
    tqdm_notebook_0.ncols = None
    tqdm_notebook_0.disable = False
    tqdm_notebook_0.total = None
    tqdm_notebook_0.unit_scale = 1
    tqdm_notebook_0.miniters = None
    tqdm_notebook_0.desc = None
    tqdm_notebook_0.dynamic_ncols = False
    tqdm_notebook_0.leave = False
    tqdm_notebook_0.last_print_n = 0
    tqdm_notebook_0.unit = 'it'

# Generated at 2022-06-26 09:49:41.667481
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:49:48.018831
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm import tqdm
    from tqdm import tqdm_notebook

    progress_bar_1 = tqdm(
        desc='bar 1', position=1, total=100, leave=False)
    progress_bar_2 = tqdm(
        desc='bar 2', position=2, total=100, leave=False)

    for _ in range(50):
        progress_bar_1.update(1)
        progress_bar_2.update(2)

    progress_bar_1.clear()
    progress_bar_2.clear()

    for _ in range(50):
        progress_bar_1.update(1)
        progress_bar_2.update(2)



# Generated at 2022-06-26 09:49:54.310089
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    total = 100
    tqdm_notebook_0.reset(total)
    assert tqdm_notebook_0.total == total


# Generated at 2022-06-26 09:49:56.586209
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display('msg' , None , False , None, None)



# Generated at 2022-06-26 09:50:27.784873
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    times = 10
    tqdm_notebook_1 = tqdm_notebook()
    for i in range(times):
        tqdm_notebook_1.update(1)
    assert tqdm_notebook_1.n == times


# Generated at 2022-06-26 09:50:32.611475
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook_object = tqdm_notebook()
    tqdm_notebook_object.reset(total = 1)



# Generated at 2022-06-26 09:50:40.379450
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Tests the display method of the class tqdm_notebook.
    """
    # Tested with tqdm_notebook(total=1)
    bar = tqdm_notebook(total=1)
    # Test 1 iteration
    bar.display(msg='Testing...')
    assert bar.container.children[-2].value == 'Testing...'
    # Test multiple iterations
    bar.display(msg='Another Test')
    assert bar.container.children[-2].value == 'Another Test'
    # Test end of iterations
    bar.display(msg='DONE')
    assert bar.container.children[-2].value == 'DONE'
    assert bar.container.children[-2].bar_style == 'success'

# Generated at 2022-06-26 09:50:45.003022
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook(disable=False)
    tqdm_notebook_1.display(close=True, check_delay=True)


# Generated at 2022-06-26 09:50:49.296725
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.total = 100
    tqdm_notebook_0.update()
    assert tqdm_notebook_0.n == 1


# Generated at 2022-06-26 09:50:55.998021
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(total = 100, unit = "m")
    for i in range(100):
        tqdm_notebook_1.update(1)


# Generated at 2022-06-26 09:50:58.718464
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert type(tqdm_notebook.status_printer(tqdm_notebook())) == TqdmHBox

# Generated at 2022-06-26 09:51:11.534594
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test 1.1
    # tqdm_notebook_1
    tqdm_notebook_1 = tqdm_notebook()
    # tqdm_notebook_1_iterator
    tqdm_notebook_1_iterator = tqdm_notebook_1.__iter__()

# Generated at 2022-06-26 09:51:20.511104
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset(total=10)
    assert tqdm_notebook_1.container.children[1].max == 10
    tqdm_notebook_1.reset()
    assert tqdm_notebook_1.container.children[1].min == 0
    tqdm_notebook_1.close()


# Generated at 2022-06-26 09:51:23.675328
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    pbar = tqdm_notebook()
    pbar.display()



# Generated at 2022-06-26 09:52:22.521960
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook(
        total=10, file=sys.stderr, ascii=False, disable=False, leave=False,
        miniters=None, mininterval=0.1, maxinterval=10.0, maxiters=None, ncols=100,
        initial=0, position=None, unit='it', unit_scale=False, gui=True,
        dynamic_ncols=False, ascii_ignore=None, desc='Testing',
        nrows=None, postfix=None, unit_divisor=1000, write_bytes=False,
        gui_args=None, gui_fmt=None, **kwargs)
    tqdm_notebook_1.display()


# Generated at 2022-06-26 09:52:29.395619
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = tqdm_notebook.status_printer(total=100, desc='testing')
    try:
        assert pbar.max == 100
        # reset max value
        pbar.max = 200
        assert pbar.max == 200
        # close progress bar widget
        pbar.close()
    except:
        pbar.close()
        raise


# Generated at 2022-06-26 09:52:32.581383
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_1 = tqdm_notebook()
    try:
        tqdm_notebook_1.close()
    except KeyboardInterrupt:
        pass
    except ValueError:
        pass
    except TypeError:
        pass
    except Exception:
        pass


# Generated at 2022-06-26 09:52:38.062713
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(desc='testing tqdm_notebook', total=10)
    for i in range(6):
        tqdm_notebook_1.update(i)


# Generated at 2022-06-26 09:52:41.627937
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    with pytest.raises(ImportError, message="Please update jupyter and ipywidgets."):
        tqdm_notebook.status_printer()


# Generated at 2022-06-26 09:52:50.249103
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(disable=0, unit="b", unit_scale=0.0, unit_divisor=1.0, dynamic_ncols=False)
    for obj in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:53:00.843054
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_1 = tqdm_notebook(0, 50)
    #check the progress bar
    assert (tqdm_notebook_1.container.value == 0)
    assert (tqdm_notebook_1.container.min == 0)
    assert (tqdm_notebook_1.container.max == 50)
    assert (tqdm_notebook_1.container.description == '')
    assert (tqdm_notebook_1.container.bar_style == '')

    tqdm_notebook_2 = tqdm_notebook(0, 50, desc = 'Test')
    #check the progress bar
    assert (tqdm_notebook_2.container.value == 0)
    assert (tqdm_notebook_2.container.min == 0)
   

# Generated at 2022-06-26 09:53:09.114425
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook(
        bar_format='')
    tqdm_notebook_0.n = 0
    tqdm_notebook_0.last_print_n = 0
    tqdm_notebook_0.dynamic_ncols = True
    tqdm_notebook_0.file = sys.stdout
    tqdm_notebook_0.miniters = 1
    tqdm_notebook_0.dynamic_miniters = True
    tqdm_notebook_0.mininterval = 0.5
    tqdm_notebook_0.maxinterval = 10.0
    tqdm_notebook_0.smoothing = 0.3
    tqdm_notebook_0.avg_time = 3

# Generated at 2022-06-26 09:53:13.097638
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()


# Generated at 2022-06-26 09:53:21.141564
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .std import tqdm as std_tqdm
    tqdm_notebook_1 = tqdm_notebook(total = 1)
    tqdm_notebook_1.display(msg = 'msg', pos = 1, close = False, bar_style = None, check_delay = True)
    tqdm_notebook_1.display(msg = 'msg', pos = 1, close = True, bar_style = None, check_delay = True)
    tqdm_notebook_2 = tqdm_notebook(gui = True)
    tqdm_notebook_2.display(msg = 'msg', pos = 1, close = False, bar_style = 'bar_style', check_delay = True)

# Generated at 2022-06-26 09:55:04.968705
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    for i in tqdm_notebook_1:
        pass


# Generated at 2022-06-26 09:55:11.030070
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        from .tests import test_tqdm_notebook
        test_tqdm_notebook()
    except Exception as e:
        print(e)
        assert False


# Generated at 2022-06-26 09:55:19.813755
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.container = TqdmHBox()
    tqdm_notebook_0.container.pbar = std_tqdm()
    tqdm_notebook_0.container.pbar.format_dict = {}
    tqdm_notebook_0.container.__repr__()

# Generated at 2022-06-26 09:55:25.279671
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_2 = tqdm_notebook(range(5), desc="test", total=5)
    tqdm_notebook_2.reset()


# Generated at 2022-06-26 09:55:28.649588
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display("haha")


# Generated at 2022-06-26 09:55:32.395543
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    for tqdm_notebook_0_i in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:55:40.870422
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():

    obj = tqdm_notebook()

    try:
        for obj in obj:
            # return super(tqdm...) will not catch exception
            ...
    except:  # NOQA
        pass
    # NB: don't `finally: close()`
    # since this could be a shared bar which the user will `reset()`



# Generated at 2022-06-26 09:55:41.939403
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook()



# Generated at 2022-06-26 09:55:48.848414
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    msg = "a"
    pos = 1
    close = False
    bar_style = "info"
    check_delay = True
    print('Test: Display')
    display = tqdm_notebook(msg, pos, close, bar_style, check_delay)


# Test tqdm_notebook()

# Generated at 2022-06-26 09:55:57.678760
# Unit test for method display of class tqdm_notebook