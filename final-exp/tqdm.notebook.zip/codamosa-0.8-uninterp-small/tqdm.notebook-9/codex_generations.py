

# Generated at 2022-06-26 09:46:43.920554
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    args = {}
    args['file'] = sys.stderr

    args['total'] = 3
    tqdm_notebook_1 = tqdm_notebook(**args)
    tqdm_notebook_1.container = tqdm_notebook.status_printer(tqdm_notebook_1.fp,
                                                             tqdm_notebook_1.total, tqdm_notebook_1.desc,
                                                             tqdm_notebook_1.ncols)
    tqdm_notebook_1.container.pbar = proxy(tqdm_notebook_1)
    tqdm_notebook_1.update()

    # default msg

# Generated at 2022-06-26 09:46:46.697222
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:46:50.824638
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # tqdm_notebook_1 = tqdm_notebook()
    # AssertionError: No implementation provided for '__iter__'
    pass


# Generated at 2022-06-26 09:46:55.840587
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()
    assert tqdm_notebook_1.disable == True



# Generated at 2022-06-26 09:46:59.075015
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    test_tqdm = tqdm_notebook()
    assert type(tqdm_notebook.status_printer(test_tqdm, total = 100, desc = 'Test', ncols = 100)) == TqdmHBox


# Generated at 2022-06-26 09:47:09.774681
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    if not IProgress:
        raise ImportError
    container = tqdm_notebook.status_printer(None, 2, "", None)
    container.pbar.max = 10
    assert container._repr_pretty_() == "\x1b[C\x1b[K| 88% |"
    container.pbar.clear()
    assert container._repr_pretty_() == "\x1b[C\x1b[K| 88% |"
    container.pbar.close()


if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_clear()

# Generated at 2022-06-26 09:47:13.971897
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook.status_printer(total=None, desc=None, ncols=None)


# Generated at 2022-06-26 09:47:16.461418
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
	clear = tqdm_notebook.clear
	pass


# Generated at 2022-06-26 09:47:19.598908
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_test_display = tqdm_notebook()
    tqdm_notebook_test_display.display()


# Generated at 2022-06-26 09:47:24.530298
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Create tqdm_notebook object
    tqdm_notebook_1 = tqdm_notebook()
    # Call display method
    tqdm_notebook_1.display()


# Generated at 2022-06-26 09:47:39.685727
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_reset_0 = tqdm_notebook()
    tqdm_notebook_reset_0.reset(total=None)


# Generated at 2022-06-26 09:47:50.975837
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Method to test the reset method of the class tqdm_notebook
    """
    # Create a new instance of class tqdm_notebook and set the total to 10
    tqdm_notebook_instance = tqdm_notebook()
    tqdm_notebook_instance.total = 10
    # Assert if the instance is not equal to the total
    assert tqdm_notebook_instance.total == 10
    # Reset the instance of class tqdm_notebook
    tqdm_notebook_instance.reset()
    # Assert if the instance has been reset to 0
    assert tqdm_notebook_instance.total == 0

# Generated at 2022-06-26 09:47:56.164481
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    reset_test = tqdm_notebook(total=100)
    reset_test.reset(total=200)
    reset_test.reset()


# Generated at 2022-06-26 09:48:02.421954
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Create a new object tqdm_notebook_0
    tqdm_notebook_0 = tqdm_notebook()
    # Call TqdmHBox.__repr__()
    TqdmHBox.__repr__(tqdm_notebook_0)


# Generated at 2022-06-26 09:48:07.957560
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from tqdm.notebook import tqdm_notebook
    import six
    import sys
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.file = sys.stdout
    tqdm_notebook_1.total = 10
    tqdm_notebook_1.desc = ''
    tqdm_notebook_1.ncols = None
    tqdm_notebook_1.status_printer(6,10,'',None)
    assert not eval('tqdm_notebook_1')
    assert isinstance(tqdm_notebook_1,tqdm_notebook)



# Generated at 2022-06-26 09:48:18.069387
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # bar with no total
    bar = tqdm_notebook_0 = tqdm_notebook()
    bar.reset()

    # bar with total
    bar = tqdm_notebook_0 = tqdm_notebook(total=100)
    bar.reset(total=50)

    # bar with no total and text
    bar = tqdm_notebook_0 = tqdm_notebook(desc="text")
    bar.reset(total=50)

    # bar with unknown total and text
    bar = tqdm_notebook_0 = tqdm_notebook(total=None, desc="text")
    bar.reset(total=50)

    # bar with no total and width

# Generated at 2022-06-26 09:48:24.230419
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook___iter__0 = tqdm_notebook_0.__iter__()
    assert isinstance(tqdm_notebook___iter__0, object)



# Generated at 2022-06-26 09:48:26.357503
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:48:37.782883
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    a = tqdm_notebook()
    a.disable = True
    a.leave = True
    a.total = 100
    a.dynamic_ncols = True
    a.displayed = True
    a.desc = None
    a.n = 1
    a.check_delay = True
    a.display()
    a.display(msg = "a")
    a.display(msg = "a", pos = 1)
    a.display(pos = 1)
    a.display(close = True)
    a.display(bar_style = "a")
    a.display(check_delay = False)


# Generated at 2022-06-26 09:48:51.193115
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test with simple arguments
    tqdm_notebook_display_0 = tqdm_notebook()
    tqdm_notebook_display_0.display()
    tqdm_notebook_display_0.display("aaaa")
    tqdm_notebook_display_0.display("bbbb", "cccc")
    tqdm_notebook_display_0.display(pos="dddd")
    tqdm_notebook_display_0.display(close="eeee")
    tqdm_notebook_display_0.display(bar_style="ffff")
    tqdm_notebook_display_0.display(check_delay="gggg")
    # Test with dependent arguments

# Generated at 2022-06-26 09:49:17.696468
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    return tqdm_notebook.status_printer()



# Generated at 2022-06-26 09:49:22.409906
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    first_bar = tqdm_notebook(range(0, 100))
    second_bar = tqdm_notebook(range(0, 100))
    second_bar.reset(total=100)
    second_bar.close()

# Generated at 2022-06-26 09:49:36.346666
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_3 = tqdm_notebook()
    tqdm_notebook_4 = tqdm_notebook()
    tqdm_notebook_5 = tqdm_notebook()
    tqdm_notebook_6 = tqdm_notebook()
    tqdm_notebook_7 = tqdm_notebook()
    tqdm_notebook_8 = tqdm_notebook()
    tqdm_notebook_9 = tqdm_notebook()
    tqdm_notebook_10 = tqdm_notebook()
   

# Generated at 2022-06-26 09:49:38.013004
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    try:
        with tqdm_notebook(range(10)) as t:
            for i in t:
                t.clear()
                raise Exception()
    except Exception:
        pass

# Generated at 2022-06-26 09:49:46.340262
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    from IPython.display import HTML
    import ipywidgets
    ncols = 100
    file = None
    total = 1
    desc = None
    pbar = ipywidgets.FloatProgress(min=0, max=total)
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])
    pbar.layout.flex = '2'
    container.layout.width = ncols
    container.layout.display = 'inline-flex'
    container.layout.flex_flow = 'row wrap'
    assert container != None

# Generated at 2022-06-26 09:49:51.404039
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=10) as pbar:
        pbar.clear(True)



# Generated at 2022-06-26 09:49:54.739504
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update(500)


# Generated at 2022-06-26 09:50:03.834653
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook._repr_pretty_ = lambda x,y: print(x.__repr__(True))
    tqdm_notebook_0 = tqdm_notebook()
    
    #test display case 1
    tqdm_notebook_0.display()

    #test display case 2
    tqdm_notebook_0.display(msg = "Stuff", pos = 3)

    #test display case 3
    tqdm_notebook_0.display(msg = "", close = False, bar_style = 'success', check_delay = True)

    #test display case 4
    tqdm_notebook_0.display(msg = "", close = True, bar_style = 'danger', check_delay = False)


# Generated at 2022-06-26 09:50:11.329185
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from time import sleep
    from random import randint
    from .utils import format_interval
    from .utils import format_meter
    from .std import tqdm
    
    tqdm_notebook_0 = tqdm(total=4)
    for i in range(4):
        sleep(randint(1, 3))
        tqdm_notebook_0.update(1)
    tqdm_notebook_0.close()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:50:21.721941
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from IPython.display import HTML
    from ipywidgets import FloatProgress as IProgress
    from ipywidgets import HBox as TqdmHBox
    import ipywidgets
    from .std import tqdm as std_tqdm
    from .std import tqdm
    import sys
    import re
    from weakref import proxy
    from .utils import _range
    import warnings
    with warnings.catch_warnings():
        warnings.filterwarnings(
            'ignore', message=".*The `IPython.html` package has been deprecated.*")
        try:
            import IPython.html.widgets as ipywidgets  # NOQA: F401
        except ImportError:
            pass


# Generated at 2022-06-26 09:50:50.950600
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """
    Construct a tqdm_notebook object.
    Call method __repr__ of TqdmHBox class with argument pretty = False.
    Verify if the returned value of __repr__ is a string.
    """
    tqdm_notebook_0 = tqdm_notebook()
    TqdmHBox_0 = TqdmHBox()
    ret_value = TqdmHBox_0.__repr__(False)
    assert isinstance(ret_value, str)



# Generated at 2022-06-26 09:50:58.943493
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    msg = 'test'
    tqdm_notebook_1.display(msg)
    output_1 = tqdm_notebook_1.container.children[-1].value
    assert output_1 == msg, 'Fails to display message'


# Generated at 2022-06-26 09:51:09.828375
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    n = 1000
    tqdm_notebook_1 = tqdm_notebook(range(n))
    # Test end bar
    for i in tqdm_notebook_1:
        pass
    # Test interupt bar
    tqdm_notebook_2 = tqdm_notebook(range(n))
    for i in tqdm_notebook_2:
        if i == int(n / 2):
            raise Exception('test_tqdm_notebook_display: '
                            'Exception was raised in iterate')



# Generated at 2022-06-26 09:51:14.303741
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook.status_printer(None, None, None, None), HBox)


# Generated at 2022-06-26 09:51:21.460808
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_test = tqdm_notebook()
    # tqdm_notebook.total=1, tqdm_notebook.n=0
    tqdm_notebook_test.reset()
    assert tqdm_notebook_test.total == 0, 'total not reset'
    assert tqdm_notebook_test.n == 0, 'n not reset'


# Generated at 2022-06-26 09:51:33.332167
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    iterable = range(10)
    tqdm_notebook_1 = tqdm_notebook(iterable)
    tqdm_notebook_1.display()
    assert tqdm_notebook_1.displayed
    assert tqdm_notebook_1.container.visible
    tqdm_notebook_1.display()
    assert tqdm_notebook_1.displayed
    assert tqdm_notebook_1.container.visible
    tqdm_notebook_1.display(close=True)
    assert tqdm_notebook_1.displayed
    assert not tqdm_notebook_1.container.visible


# Generated at 2022-06-26 09:51:36.976154
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    iter_obj = tqdm_notebook([-1, -2, -3])
    assert (len(iter_obj) == 3) == True


# Generated at 2022-06-26 09:51:41.055587
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=100) as t:
        for i in range(100):
            time.sleep(0.01)
            t.update()


# Generated at 2022-06-26 09:51:44.376059
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Display all class attributes (methods + properties, etc)
    attrs = [x for x in dir(tqdm_notebook) if not x.startswith('__')]
    assert "reset" in attrs, "The method `reset` of class tqdm_notebook was not found."


# Generated at 2022-06-26 09:51:52.374322
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        test_case_0()
    except NameError:
        # It fails if tqdm is not installed
        pass
    except TypeError:
        assert False, 'tqdm_notebook.disp() with no parameters'


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-26 09:52:18.988407
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Testing IPython 2
    if IPY < 3:
        raise ImportError("IPython >= 3 is required")
    # Calling display with default arguments
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()

# Generated at 2022-06-26 09:52:31.777654
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    # display the widget, default value for msg,pos,close,bar_style,check_delay is None,None,False,'success',True
    # test initial display
    tqdm_notebook_1.display()
    # test displaying with all arguments
    tqdm_notebook_1.display(msg='test msg', bar_style='info', check_delay=False)
    # test displaying with 'close' True
    tqdm_notebook_1.display(close=True)
    # test displaying with 'bar_style' 'danger'
    tqdm_notebook_1.display(bar_style='danger')
    # test displaying with 'bar_style' 'danger'

# Generated at 2022-06-26 09:52:33.046730
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from nose.plugins.skip import SkipTest
    raise SkipTest



# Generated at 2022-06-26 09:52:37.859208
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_status_printer_obj = tqdm_notebook()
    tqdm_notebook_status_printer_obj.status_printer()


# Generated at 2022-06-26 09:52:48.172473
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()

    tqdm_notebook_1._instances = []
    tqdm_notebook_1.fp = 1
    tqdm_notebook_1.guessit = True
    tqdm_notebook_1.gui = True
    tqdm_notebook_1.mininterval = 0.1
    tqdm_notebook_1.maxinterval = 10
    tqdm_notebook_1.dynamic_mininterval = True
    tqdm_notebook_1.miniters = 0
    tqdm_notebook_1.last_print_n = 0
    tqdm_notebook_1.last_print_t = 1
    tqdm_notebook_1.last_print_t_no

# Generated at 2022-06-26 09:52:54.794484
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    msg_0 = "string format \"{r_bar}\""
    pos_0 = None
    close_0 = False
    bar_style_0 = None
    check_delay_0 = True
    tqdm_notebook_0.display(msg_0, pos_0, close_0, bar_style_0, check_delay_0)



# Generated at 2022-06-26 09:52:58.757232
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:53:06.926335
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup
    total = 5
    # Exercise
    tqdm_notebook_0 = tqdm_notebook(total=total)
    # Verify preconditions
    assert tqdm_notebook_0.unit_scale == 0
    def total_assert(tqdm_notebook):
        assert tqdm_notebook.total == total
    # Run method to be tested
    tqdm_notebook_0.reset(total=total)
    # Verify
    total_assert(tqdm_notebook_0)

# Generated at 2022-06-26 09:53:19.368881
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Create an instance of tqdm_notebook
    # unit_scale is set to 1
    # total is set to 10
    tqdm_notebook_0 = tqdm_notebook(unit_scale = 1, total = 10)
    # Check if the attribute leave of instance tqdm_notebook_0 is set to False
    assert tqdm_notebook_0.leave == False
    # Check if the attribute dynamic_ncols of instance tqdm_notebook_0 is set to False
    assert tqdm_notebook_0.dynamic_ncols == False
    # Check if the attribute format_dict of instance tqdm_notebook_0 is empty
    assert tqdm_notebook_0.format_dict == {}
    # Check if the attribute unit_scale of instance tqdm_notebook_

# Generated at 2022-06-26 09:53:25.170167
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from ._utils import _create_unit_test
    test = _create_unit_test(tqdm_notebook.display, 1, 2)
    test(msg="")
    test(close=True)
    test(bar_style="")
    test(msg="", bar_style="success", close=False, check_delay=False)



# Generated at 2022-06-26 09:54:19.612963
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:54:27.411383
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # test_case_1
    tqdm_notebook_1 = tqdm_notebook(total=100)

    # test_case_2
    tqdm_notebook_2 = tqdm_notebook(total=100, file=sys.stderr)

    # test_case_3
    tqdm_notebook_3 = tqdm_notebook(total=100, ncols=1000)



# Generated at 2022-06-26 09:54:31.728003
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    assert tqdm_notebook_1.update() == True


# Generated at 2022-06-26 09:54:41.080365
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    #tqdm_notebook_0 = tqdm_notebook()
    for i in tqdm(range(10)):
        pass
    for i in tqdm(range(10),desc='test'):
        pass
    for i in tqdm(range(10),desc='test',leave=True):
        pass
    for i in tqdm(range(10),ncols=100):
        pass
    for i in tqdm(range(10),desc='test',leave=True,ncols=100):
        pass
    for i in tqdm(range(10),desc='test',leave=True,ncols=100,total=10):
        pass

# Generated at 2022-06-26 09:54:43.012115
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    n = tqdm_notebook()
    assert n.unit is None


# Generated at 2022-06-26 09:54:47.575739
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()  # construction of class tqdm_notebook
    tqdm_notebook_1.disp()  # call display method of class tqdm_notebook



# Generated at 2022-06-26 09:54:53.073751
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Create a counter instance
    tqdm_notebook_0 = tqdm_notebook()
    # Call method reset of tqdm_notebook_0
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:55:04.156957
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import io
    import sys
    import contextlib

    # Redirect the standard output to a custom buffer
    # This allows us to check the output (stdout) of the method display
    # of the class tqdm_notebook
    custom_file = io.StringIO()
    @contextlib.contextmanager
    def custom_stdout(file):
        old_stdout = sys.stdout
        sys.stdout = file
        try:
            yield file
        finally:
            sys.stdout = old_stdout

    # INIT TESTS
    iterable = [0.08, 0.16, 0.2, 0.32, 0.2, 0.22, 0.14, 0.18, 0.11, 0.17]
    total = len(iterable)

    # Setup default output
    file = sys

# Generated at 2022-06-26 09:55:08.163082
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Inputs
    tqdm_notebook_0 = tqdm_notebook()
    # Check all outputs
    tqdm_notebook_0.update()
    # Unit test for method update of class tqdm_notebook

# Generated at 2022-06-26 09:55:14.731057
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # ncols = None, total = 50
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.status_printer(total=50)
   