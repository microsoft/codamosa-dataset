

# Generated at 2022-06-26 09:47:06.857197
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    for tqdm_notebook_0_0 in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:47:12.559432
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(int(5), file=sys.stderr)
    for tqdm_notebook_0_iter in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:47:24.457074
# Unit test for method status_printer of class tqdm_notebook

# Generated at 2022-06-26 09:47:33.136117
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
     # Setup
     tqdm_h_box_0 = TqdmHBox()
     # Returned value
     tqdm_h_box_0_repr_0 = tqdm_h_box_0.__repr__()
     # Returned value
     tqdm_h_box_0_repr_1 = tqdm_h_box_0.__repr__(True)
     # Returned value
     tqdm_h_box_0_repr_2 = tqdm_h_box_0.__repr__(False)
     # Returned value
     test_repr_pretty_0 = tqdm_h_box_0.__repr__(True)


# Generated at 2022-06-26 09:47:36.780581
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:47:37.687701
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pass

# Generated at 2022-06-26 09:47:40.967449
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    _, ltext, rtext = tqdm_notebook.status_printer('1', 1, '')
    assert(isinstance(ltext, IPY))
    assert(isinstance(rtext, IPY))


# Generated at 2022-06-26 09:47:44.230235
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm(['a', 'b', 'c', 'd']):
            assert 1 == 1
    assert 1 == 1


# Generated at 2022-06-26 09:47:50.264902
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
  # Create tqdm_notebook instance
  tqdm_notebook_0 = TqdmHBox()
  # Create iterator
  iterator_0 = iter(tqdm_notebook_0)
  # Call __iter__
  tqdm_notebook_0.__iter__()
  # Assert the value of the iterator
  assert iterator_0 is not None


# Generated at 2022-06-26 09:47:55.861556
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Create a tqdm_notebook object with total steps=10
    obj = tqdm_notebook(total=10)
    # Update the progress bar by 1 step
    obj.update()


# Generated at 2022-06-26 09:48:14.399060
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # test whether global member is initialized correctly
    assert IPY > 0, "IPython/Jupyter Notebook is required"
    assert IProgress is not None, "ipywidgets is required"

    # test tqdm_notebook constructor
    test_case_0()

# Generated at 2022-06-26 09:48:17.442087
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    try:
        for i in tqdm_notebook_1:
            pass
    except:
        assert False
    assert True


# Generated at 2022-06-26 09:48:23.167629
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.reset()
    except Exception as ex:
        print(str(ex))
        return False
    return True


# Generated at 2022-06-26 09:48:28.631260
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    TqdmHBox_0 = tqdm_notebook_0.container
    # Pretty Representations are not implemented for TqdmHBox.
    # Calling the method __repr__(False) of class TqdmHBox returns a pretty
    # representation.
    assert TqdmHBox_0.__repr__(False) == ""


# Generated at 2022-06-26 09:48:34.295286
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    it = tnrange(100)
    from time import sleep
    for i in it:
        sleep(0.01)
        it.set_description("desc: {}".format(i))
        it.set_postfix(finished=i+1, bar_format="{l_bar}{bar}|")

if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-26 09:48:37.789719
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # instantiate target object
    tqdm_notebook_0 = tqdm_notebook()
    # call function
    result = tqdm_notebook_0.reset()    # check result
    assert result is None

# Generated at 2022-06-26 09:48:50.723842
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_3 = tqdm_notebook()
    # Test for case - 1
    tqdm_notebook_1.status_printer(sys.stdout, 100, "Test_case_1")
    # Test for case - 2
    tqdm_notebook_2.status_printer(sys.stdout, 100, "Test_case_2", 100)
    # Test for case - 3
    tqdm_notebook_3.__init__()
    tqdm_notebook_3 = tqdm_notebook(disable=True)


# Generated at 2022-06-26 09:49:01.378238
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test for basic functionality of tqdm notebook display
    def test_basic_tqdm_display():
        a = tqdm_notebook(["a", "b", "c", "d"])
        for i in a:
            a.set_description("Processing %s" % i)
        return a

    a = test_basic_tqdm_display()
    # Test for tqdm display with total
    def test_tqdm_display_with_total():
        a = tqdm_notebook(["a", "b", "c", "d"], total=4)
        for i in a:
            a.set_description("Processing %s" % i)
        return a

    b = test_tqdm_display_with_total()
    # Test for tqdm display with early close


# Generated at 2022-06-26 09:49:15.477314
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Unit test for method status_printer of class tqdm_notebook"""
    tqdm_notebook_0 = tqdm_notebook()

    # Test 1:
    _, res = tqdm_notebook_0.status_printer()
    assert(res == None)

    # Test 2:
    _, res = tqdm_notebook_0.status_printer(0)
    assert(res == None)

    # Test 3:
    _, res = tqdm_notebook_0.status_printer(1)
    assert(res == None)

    # Test 4:
    _, res = tqdm_notebook_0.status_printer(1, 1)
    assert(res == None)



# Generated at 2022-06-26 09:49:19.561420
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()



# Generated at 2022-06-26 09:49:55.740172
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test case 0
    tqdm_notebook_0 = tqdm_notebook()
    msg = None
    pos = None
    close = False
    bar_style = None
    check_delay = True
    tqdm_notebook_0.display(msg, pos, close, bar_style, check_delay)



# Generated at 2022-06-26 09:50:00.627721
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm(total=10) as t:
        for i in range(10):
            t.update(2)


# Generated at 2022-06-26 09:50:03.106226
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # DEV: `trange` is nicer but not a proper unit test
    for _ in trange(10):
        pass



# Generated at 2022-06-26 09:50:14.129755
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()
    tqdm_notebook_0.display(close=True)
    tqdm_notebook_0.display(bar_style='success')
    tqdm_notebook_0.display(bar_style='danger')
    tqdm_notebook_0.display(check_delay=False)
    tqdm_notebook_0.display(msg='message', pos=None, close=False, 
                            bar_style=None, check_delay=True)
    tqdm_notebook_0.container.children[-2].style.bar_color = '#434343'


# Generated at 2022-06-26 09:50:17.268184
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:50:28.515604
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.status_printer(sys.stdout, total = 100, desc = 'A test for status_printer', ncols = 100)
    
test_case_0()
test_tqdm_notebook_status_printer()

from tqdm.notebook import trange
from time import sleep

for i in trange(3, desc='1st loop'):
    for j in trange(100, desc='2nd loop'):
        sleep(0.01)

# Generated at 2022-06-26 09:50:32.218648
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    for i in tqdm_notebook(range(4)):
        pass

if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:50:40.599574
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    # AssertionError [ERR_ASSERTION] : tqdm_notebook (6, '<=', 0)
    # AssertionError [ERR_ASSERTION] : fp (True,)
    # AssertionError [ERR_ASSERTION] : fp (1, '<=', 1)
    # AssertionError [ERR_ASSERTION] : fp (True,)
    # AssertionError [ERR_ASSERTION] : fp (1, '<=', 1)
    # AssertionError [ERR_ASSERTION] : fp (True,)
    # AssertionError [ERR_ASSERTION] : fp (1, '<=', 1)
    # AssertionError

# Generated at 2022-06-26 09:50:44.643164
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    total = 100
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.status_printer(total)


# Generated at 2022-06-26 09:50:52.511798
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for unit_test_object in [tqdm_notebook(), tnrange(), trange()]:
        for counter in [0, 1, 5]:
            for disable in [True, False]:
                unit_test_object.disable = disable
                unit_test_object.update(counter)
                assert unit_test_object.n == counter
                if unit_test_object.total is not None:
                    assert unit_test_object.n == counter
                if isinstance(unit_test_object, tqdm_notebook):
                    assert not unit_test_object.displayed
                    unit_test_object.container.visible = False
                    unit_test_object.display(check_delay=False)
                    assert unit_test_object.displayed
                    unit_test_object.displayed = False
                unit_test_object.n

# Generated at 2022-06-26 09:52:13.108288
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from random import random
    from time import sleep
    # use random length
    m_length = random()*100
    # random length input
    test_input = round(m_length*3)
    iteration = [i for i in trange(test_input)] # create a tqdm_notebook object
    for i in iteration:
        sleep(m_length/30)
        iteration.set_description_str(str(i))
    iteration.set_description_str(str(int(m_length)))
    iteration.reset(total=int(m_length))
    for i in iteration:
        sleep(m_length/30)
    assert len(iteration) == m_length


# Generated at 2022-06-26 09:52:14.938108
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook(["a","b","c"])
    # Calling clear once
    t.clear()
    # Calling clear twice, as some other functions are just called once
    t.clear()


# Generated at 2022-06-26 09:52:18.239426
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Case 0
    tqdm_notebook_0 = tqdm_notebook()

    # Case 1
    tqdm_notebook_1 = tqdm_notebook()


# Generated at 2022-06-26 09:52:31.360999
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():

    # Declare some local variables
    unit_scale_0 = None
    total_0 = None
    total_1 = None
    unit_scale_1 = None
    unit_scale_2 = None
    total_2 = None
    unit_scale_3 = None

    # Call the constructor of class tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook(unit_scale = unit_scale_0, total = total_0)
    tqdm_notebook_1 = tqdm_notebook(unit_scale = unit_scale_1, total = total_1)
    tqdm_notebook_2 = tqdm_notebook(unit_scale = unit_scale_2, total = total_2)
    tqdm_notebook_3 = tqdm_notebook()



# Generated at 2022-06-26 09:52:43.677633
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.notebook import tqdm_notebook

    tqdm_notebook_0 = tqdm_notebook(total=100)
    assert tqdm_notebook_0.displayed == False

    tqdm_notebook_0 = tqdm_notebook(total=100)
    assert tqdm_notebook_0.displayed == False

    tqdm_notebook_0 = tqdm_notebook(total=100)
    assert tqdm_notebook_0.displayed == False

    tqdm_notebook_0 = tqdm_notebook(total=100)
    assert tqdm_notebook_0.displayed == False

    tqdm_notebook_0 = tqdm_notebook(total=100)
    assert tqdm_notebook_

# Generated at 2022-06-26 09:52:58.046709
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Parameters
    ncols = 20
    delay = 2
    unit_scale = True
    unit_divisor = 1000
    unit = 'bytes'
    total = 1000
    leave = False
    file = None
    n = 0
    position = 0
    bar_format = '{l_bar}{bar}{r_bar}'
    initial = 0
    desc = 'Test Case: Reset'
    dynamic_ncols = False
    miniters = None
    mininterval = 0
    maxinterval = 0.1
    disable = False
    smoothing = 0.3
    ascii = False
    unit_scale = None
    unit_divisor = 1000
    mininterval = 0
    maxinterval = 0.1
    check_interval = 100
    gui = False

    # Initialize

# Generated at 2022-06-26 09:53:07.765326
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Test for display method
    """
    tqdm_notebook.disable = True
    if IPY >= 32:
        tqdm_notebook.close = lambda *args, **kwargs: None

    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()

    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.tqdm.disable = False
    tqdm_notebook_2.display()

    tqdm_notebook.disable = None
    if IPY >= 32:
        tqdm_notebook.close = lambda *args, **kwargs: None



# Generated at 2022-06-26 09:53:12.790946
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()
    tqdm_notebook_0.update(1)


# Generated at 2022-06-26 09:53:19.782552
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # instantiate a tqdm.notebook.tqdm_notebook object
    tqdm_notebook_0 = tqdm_notebook()
    # invoke display method on object tqdm_notebook_0
    tqdm_notebook_0.display()

if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_display()
    print("All test cases passed!")

# tqdm_notebook()
# trange(10**6)
# range(10**6)

# Generated at 2022-06-26 09:53:26.191440
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Initialization
    tqdm_notebook_1 = tqdm_notebook()
    msg = ''
    pos = None
    close = False
    bar_style = None
    check_delay = True

    # Test method display of class tqdm_notebook
    tqdm_notebook_1.display(msg, pos, close, bar_style, check_delay)


# Generated at 2022-06-26 09:55:36.582220
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Default instantiation
    tqdm_notebook_1 = tqdm_notebook()
    # end __iter__


# Generated at 2022-06-26 09:55:40.182820
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()
    pass



# Generated at 2022-06-26 09:55:42.368388
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_clear = tqdm_notebook()
    tqdm_notebook_clear.clear()


# Generated at 2022-06-26 09:55:55.610099
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from nose import tools as nose_tools
    tqdm_notebook_obj = tqdm_notebook()
    try:
        tqdm_notebook_obj.total = 5
        tqdm_notebook_obj.n = 2
        tqdm_notebook_obj.reset(10)
        nose_tools.assert_equal(tqdm_notebook_obj.total, 10)
        nose_tools.assert_equal(tqdm_notebook_obj.n, 2)

        tqdm_notebook_obj.reset()
        nose_tools.assert_equal(tqdm_notebook_obj.total, 0)
        nose_tools.assert_equal(tqdm_notebook_obj.n, 0)

    except Exception as e:
        assert False, e


# Generated at 2022-06-26 09:55:59.003493
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    progress_bar = tqdm_notebook()
    progress_bar.display()



# Generated at 2022-06-26 09:56:00.799444
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    a = 5


# Generated at 2022-06-26 09:56:08.676851
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test the constructor of class tqdm_notebook"""
    from nose.tools import assert_raises, assert_equal, assert_true, assert_false
    from inspect import ismethod
    try:
        from IPython.display import clear_output  # NOQA: F401
    except ImportError:
        clear_output = lambda *_, **__: None

    # tqdm_notebook_0 = tqdm_notebook()
    assert_raises(ImportError, test_case_0)

    # test ncols is correct or not
    tqdm_notebook_1 = tqdm_notebook(ncols="50px")
    assert_true(tqdm_notebook_1.ncols == '50px')

# Generated at 2022-06-26 09:56:12.310745
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # For the display function of tqdm_notebook to work properly,
    # it requires IProgress and its subclasses.
    assert IProgress is not None

# Generated at 2022-06-26 09:56:16.351834
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update(1)
