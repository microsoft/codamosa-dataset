

# Generated at 2022-06-26 09:46:40.845824
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Default args
    var_0 = TqdmHBox()


# Generated at 2022-06-26 09:46:42.616362
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    iterator = test_case_0()
    for element in iterator:
        if iterator.n >= iterator.total:
            break

# Generated at 2022-06-26 09:46:45.513508
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Init
    var_1 = tqdm_notebook()
    # Execute
    var_1.clear()


# Generated at 2022-06-26 09:46:47.752513
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    test_case_0()


# Generated at 2022-06-26 09:46:59.990704
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    var_1 = tnrange()
    var_2 = tnrange()
    var_1.reset(total=1)
    var_3 = tnrange(0)
    var_2.reset(total=0)
    var_4 = tnrange(2)
    var_5 = tnrange()
    var_3.reset(total=0)
    var_6 = tnrange()
    var_5.reset(total=1)
    var_5.reset(total=2)
    var_7 = tnrange(1)
    var_8 = tnrange(1)
    var_7.reset(total=0)
    var_9 = tnrange(1)
    var_7.reset(total=1)
    var_10 = tnrange()

# Generated at 2022-06-26 09:47:04.855521
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # From line 150 of tqdm/notebook.py
    try:
        from IPython.display import HBox
    except ImportError:
        return None
    assert True


# Generated at 2022-06-26 09:47:07.375861
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    var = tqdm_notebook(t, total=t.N, leave=False)
    

# Generated at 2022-06-26 09:47:21.570835
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython.display import clear_output
    from tqdm.notebook import tqdm as tqdm_notebook
    import sys

    for i in tqdm_notebook(range(10)):
        pass

    for i in tqdm_notebook(range(10), leave=True):
        pass

    # clearing the previous output is important
    clear_output()

    for i in tqdm_notebook(range(10)):
        pass

    for i in tqdm_notebook(range(10), leave=True):
        pass

    # clearing the previous output is important
    clear_output()

    for i in tqdm_notebook(range(10), desc='1st loop'):
        pass

    assert not hasattr(tqdm_notebook, "wrong_attribute")


# Generated at 2022-06-26 09:47:29.922332
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Variables initialization
    var_0 = list()
    var_1 = [1, 2, 3, 4]

    # Call the method passing correct arguments
    var_2 = tqdm_notebook(var_1)

    # Call the method for coverage purpose
    var_3 = tqdm_notebook()

    # Test the result
    assert all(var_4 == var_5 for var_4, var_5 in zip(var_0, var_2))


# Generated at 2022-06-26 09:47:33.996747
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import tnrange

    with tnrange(10) as var_0:
        for var_1 in var_0:
            pass


# Generated at 2022-06-26 09:47:50.293656
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.container_init()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:47:53.768922
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:47:58.661834
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook___iter__0 = iter(tqdm_notebook_0)


# Generated at 2022-06-26 09:48:04.828969
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_obj = tqdm_notebook()
    if hasattr(tqdm_notebook_obj, 'display'):
        # Call method display of object tqdm_notebook_obj
        tqdm_notebook_obj.display()
        # Call method display of object tqdm_notebook_obj with arbitrary number of parameters
        # tqdm_notebook_obj.display(5,5)


# Generated at 2022-06-26 09:48:17.005515
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from .utils import format_dict
    from .utils import format_interval
    from .utils import format_meter
    from .std import tqdm as std_tqdm
    from .utils import _tqdm_widget_defaults  # NOQA

    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()
    tqdm_notebook_1.display(msg='')
    tqdm_notebook_1.display(pos=0)
    tqdm_notebook_1.display(close=True)
    tqdm_notebook_1.display(bar_style='info')

    # Note: this test is originally from tqdm.std.
    d = format_dict(**_tqdm_widget_defaults)


# Generated at 2022-06-26 09:48:23.952699
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    from io import StringIO
    io = StringIO()
    tqdm_notebook_1 = tqdm_notebook(desc='desc', file=io)
    tqdm_notebook_1.close()
    text = io.getvalue()
    assert "<progressbar/>" in text


# Generated at 2022-06-26 09:48:33.975490
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import unittest
    class TestCase(unittest.TestCase):
        def test_tqdm_notebook_display(self):
            import sys
            from .std import tqdm_notebook # import tqdm.notebook.tqdm_notebook
            import ipywidgets
            try:
                from IPython.html.widgets import HTML
                from IPython.html.widgets import FloatProgress as IProgress
                from IPython.html.widgets import HBox
            except ImportError:
                HTML = None
                IProgress = None
                HBox = None
            @staticmethod
            def status_printer(obj, total=None, desc=None, ncols=None):
                pbar = IProgress(min=0, max=total)
                ltext = HTML()
                rtext = HTML()

# Generated at 2022-06-26 09:48:39.846363
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook()
    t.reset(total=10)
    assert t.total == 10
    assert t.ncols is None
    t.reset(total=10, ncols=20)
    assert t.total == 10
    assert t.ncols == 20
    t.reset(total=None, ncols=None)
    assert t.total is None
    assert t.ncols is None


# Generated at 2022-06-26 09:48:49.296573
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    unit_test_tqdm_notebook = tqdm_notebook()
    # Tests the function when passed all default arguments
    unit_test_tqdm_notebook.status_printer(file=sys.stdout)
    # Tests the function when passed non-default arguments
    unit_test_tqdm_notebook.status_printer(file=sys.stdout, total=10, desc="test", ncols=10)


# Generated at 2022-06-26 09:48:56.623404
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook(total=1, colour="orange")
    tqdm_notebook_0.clear()
    _, pbar, _ = tqdm_notebook_0.container.children
    assert pbar.bar_style == "success"


# Generated at 2022-06-26 09:49:24.042797
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    '''
    Unit test class tqdm_notebook method update
    '''
    tqdm_notebook_1 = tqdm_notebook(ncols=200)
    tqdm_notebook_1.update(n=20)



# Generated at 2022-06-26 09:49:31.606221
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.update()
    except Exception as e:
        print("Error in method update of class tqdm_notebook: "+str(e))


# Generated at 2022-06-26 09:49:35.644997
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    """Test the method clear of the tqdm_notebook class"""
    try:
        tqdm_notebook_0 = tqdm_notebook()
        # tqdm_notebook_0.clear
    except:  # NOQA
        raise AssertionError("The method clear is not well defined.")

# Generated at 2022-06-26 09:49:36.727409
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    test_obj = tqdm_notebook()
    test_obj.clear()

# Generated at 2022-06-26 09:49:41.798850
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=1) as t:
        t.update()  # display bar
        t.clear()
        t.update()  # clear bar
        assert not t.displayed


# Generated at 2022-06-26 09:49:44.134617
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:49:47.685472
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    with tqdm_notebook(total=100) as t:
        for i in t:
            t.clear(i)


# Generated at 2022-06-26 09:49:53.943524
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update(n=100)
    tqdm_notebook_1.update(n=-100)


# Generated at 2022-06-26 09:50:07.310565
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # test value for ltext, rtext
    ltext_value = "ltext"
    rtext_value = "rtext"
    hbox_instance = HBox()
    hbox_instance.children = [HTML(ltext_value), IProgress(min=0, max=1), HTML(rtext_value)]
    tqdm_notebook_instance = tqdm_notebook()
    tqdm_notebook_instance.container = hbox_instance
    tqdm_notebook_instance.display(msg='')

    assert hbox_instance.children[0].value == ltext_value
    assert hbox_instance.children[1].value == 1
    assert hbox_instance.children[2].value == rtext_value



# Generated at 2022-06-26 09:50:20.235276
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.n = 0
    IProgress_1 = IProgress(min=0, max=None)
    IProgress_1.value = 0
    IProgress_1.bar_style = 'info'
    ltext_1 = HTML()
    rtext_1 = HTML()
    ltext_1.value = ""
    rtext_1.value = ""
    container_1 = TqdmHBox(children=[ltext_1, IProgress_1, rtext_1])
    tqdm_notebook_1.container = container_1
    tqdm_notebook_1.container.pbar = proxy(tqdm_notebook_1)
    ltext_1.value = ""

# Generated at 2022-06-26 09:50:37.281808
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook(total=None)
    tqdm_notebook_1.reset(total=20)



# Generated at 2022-06-26 09:50:42.010344
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        with tqdm(total=100, desc="Computing") as t:
            for i in range(10):
                t.update()
            t.close()
    except Exception as e:
        print(e)

# Generated at 2022-06-26 09:50:48.588594
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()

if __name__=="__main__":
    try:
        test_case_0()
        test_tqdm_notebook_reset()
    except:
        print("Error in unit tests")

# Generated at 2022-06-26 09:51:01.548508
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook(5)
    tqdm_notebook_1.update()
    assert tqdm_notebook_1.n == 1
    tqdm_notebook_1.reset(total=None)
    assert tqdm_notebook_1.n == 0
    tqdm_notebook_1.reset()
    assert tqdm_notebook_1.n == 0
    tqdm_notebook_1.reset(total=10)
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.total == 10
    tqdm_notebook_1.reset(total=0)
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.total

# Generated at 2022-06-26 09:51:09.228619
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # 1st test: without error
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.disp()

    # 2nd test: with error
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.disp(bar_style='danger')


# Generated at 2022-06-26 09:51:16.328083
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    t = tqdm_notebook()
    t.display()
    t.display("50%")
    t.display("100%")
    t.display("50%", bar_style="info")
    t.display("100%", bar_style="danger")



# Generated at 2022-06-26 09:51:22.646521
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    total = 10
    tqdm_notebook_0 = tqdm_notebook(total=total, desc="tqdm_notebook_0", file=sys.stdout)
    i = 0
    for _ in tqdm_notebook_0:
        assert tqdm_notebook_0.n == i
        i = i + 1
    assert tqdm_notebook_0.n == 10


# Generated at 2022-06-26 09:51:34.982744
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # initialize instance of this test class
    # create attribute: IProgress, with value none for testing
    tqdm_notebook.IProgress = None
    tqdm_notebook_1 = tqdm_notebook()

    # set attribute 'file' of tqdm_notebook_1 to be sys.stderr
    tqdm_notebook_1.file = sys.stderr

    # test value of tqdm_notebook_1.file is sys.stderr
    assert tqdm_notebook_1.file == sys.stderr

    # test status_printer method of tqdm_notebook_1 when total is none
    assert type(tqdm_notebook_1.status_printer(tqdm_notebook_1.file)) == TqdmHBox

    # test status

# Generated at 2022-06-26 09:51:37.876808
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()

if __name__ == '__main__':
    test_tqdm_notebook()

# Generated at 2022-06-26 09:51:42.881797
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert isinstance(tqdm_notebook().status_printer(sys.stdout), HBox)



# Generated at 2022-06-26 09:52:29.125462
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert tqdm_notebook.status_printer == tqdm_notebook().status_printer


# Generated at 2022-06-26 09:52:36.450357
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Case 0
    tqdm_notebook_0 = tqdm_notebook()
    TqdmHBox_0 = TqdmHBox()
    assert TqdmHBox_0.__repr__() != None


# Generated at 2022-06-26 09:52:39.611770
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    t = tqdm_notebook()
    t.update(1)


# Generated at 2022-06-26 09:52:44.303868
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        tqdm_notebook_1 = tqdm_notebook()
        for obj in tqdm_notebook_1.__iter__():
            # return super(tqdm...) will not catch exception
            yield obj
    except: # NOQA
        tqdm_notebook_1.disp(bar_style='danger')
        raise
    # NB: don't `finally: close()`
    # since this could be a shared bar which the user will `reset()`


# Generated at 2022-06-26 09:52:50.871071
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.__iter__()
    assert isinstance(tqdm_notebook_1, tqdm_notebook)


# Generated at 2022-06-26 09:52:53.442207
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    assert tqdm_notebook.status_printer(file = sys.stdout, total = 2) is not None


# Generated at 2022-06-26 09:53:07.367797
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Initialization
    tqdm_test = tqdm_notebook.__new__(tqdm_notebook)
    tqdm_test.n = 0
    tqdm_test.total = tqdm_test.dynamic_total = [{'n': 0}]
    tqdm_test.miniters = 1
    tqdm_test.dynamic_miniters = [{'miniters': 1}]
    tqdm_test.last_print_t = time()
    tqdm_test.ncols = 100
    tqdm_test.desc = None
    tqdm_test.desc_initialized = False
    tqdm_test.unit = 'it'
    tqdm_test.unit_scale = False

# Generated at 2022-06-26 09:53:11.593023
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    assert(tqdm_notebook_0.__iter__())


# Generated at 2022-06-26 09:53:14.179547
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    assert tqdm_notebook().reset(total=0) != None


# Generated at 2022-06-26 09:53:20.028001
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Unit test for method reset tqdm_notebook
    tqdm_notebook_1 = tqdm_notebook(total=2)
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:54:21.889242
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """ return true if class tqdm_notebook is loaded """
    tqdm_notebook_0 = tqdm_notebook()
    return True


# Generated at 2022-06-26 09:54:26.191428
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear(n=1)


# Generated at 2022-06-26 09:54:39.355012
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    ipy = IPY
    if ipy is 0:  # pragma: no cover
        try:
            import ipywidgets
            ipy = 4
        except ImportError:
            try:
                import IPython
                ipy = 32
            except ImportError:
                ipy = 0
    if ipy is 0:  # pragma: no cover
        raise ImportError(
            "IProgress not found. Please update jupyter and ipywidgets.")

    if ipy is 32:  # pragma: no cover
        from IPython.html.widgets import HTML
        from IPython.html.widgets import FloatProgress as IProgress
        from IPython.html.widgets import HBox
        IPY = 3
    else:
        from ipywidgets import HTML
        from ipywidgets import FloatProgress as I

# Generated at 2022-06-26 09:54:50.758390
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from io import StringIO
    from sys import stdout
    from IPython.core.interactiveshell import InteractiveShell
    from IPython.utils.io import capture_output

    stdout = capture_output(stdout)
    InteractiveShell.ast_node_interactivity = 'last_expr'

    with stdout:
        for i in trange(1, 4, 0.3333333333333333):
            pass

    with stdout:
        for j in trange(1, 4, 0.3333333333333333):
            pass

    # clear_output(wait=1)
    stdout.truncate(0)
    stdout.seek(0)

    bar = tqdm_notebook(total=10)
    for i in range(10):
        bar.update()
        sleep(0.1)


# Generated at 2022-06-26 09:54:56.457375
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm.notebook import tqdm_notebook

    method = tqdm_notebook._instances[0].disp
    method(msg="", pos=None, close=False, bar_style=None, check_delay=True)



# Generated at 2022-06-26 09:54:59.234842
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    # Test result 1:
    tqdm_notebook_0.reset()
    # Test result 2:
    tqdm_notebook_0.reset(total=10)



# Generated at 2022-06-26 09:55:03.740668
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()


# Generated at 2022-06-26 09:55:09.109277
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import pytest
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update(n = 1)

    try:
        tqdm_notebook_0.update(n = 1)
    except TypeError:
        pytest.raises(TypeError, tqdm_notebook_0.update, n = 1)



# Generated at 2022-06-26 09:55:12.252447
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()


# Generated at 2022-06-26 09:55:22.811410
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    import random
    import time
    import unittest

    class IProgressMock():
        def __init__(self, total):
            self.total = total

        def __call__(self, total):
            return self

    def display(obj, msg=None, pos=None,
                # additional signals
                close=False, bar_style=None, check_delay=True):
        return obj
        # Clear previous output (really necessary?)
        # clear_output(wait=1)

        if not msg and not close:
            d = self.format_dict
            # remove {bar}
            d['bar_format'] = (d['bar_format'] or "{l_bar}<bar/>{r_bar}").replace("{bar}", "<bar/>")