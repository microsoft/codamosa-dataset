

# Generated at 2022-06-26 09:46:47.148434
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    print('\nTesting method update...')
    test_tqdm_notebook = tqdm_notebook(total=5)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.update(1)
    test_tqdm_notebook.close()


# Generated at 2022-06-26 09:46:56.521875
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    try:
        tqdm_notebook_1 = tqdm_notebook()
    except:
        tqdm_notebook_1 = None
    
    if tqdm_notebook_1 is None:
        tqdm_notebook_0.__iter__()
    else:
        tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:47:09.894230
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():

    # Test for constructor of tqdm_notebook
    t_notebook = tqdm_notebook(total=10, desc="tqdm_notebook")
    assert isinstance(t_notebook, tqdm_notebook)
    assert t_notebook.total == 10
    assert t_notebook.desc == "tqdm_notebook"
    assert isinstance(t_notebook.container, TqdmHBox)

    # Test for display function
    t_notebook.disp(1)
    assert t_notebook.container.children[0].value == ""
    assert t_notebook.container.children[1].value == 1
    assert t_notebook.container.children[2].value == ""
    assert t_notebook.container.children[1].bar_style == ""
    t_note

# Generated at 2022-06-26 09:47:13.398751
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()


# Generated at 2022-06-26 09:47:24.665369
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm import tqdm_notebook
    from tqdm import trange
    from time import sleep
    # Unit test for constructor of tqdm_notebook
    test_case_tqdm_notebook_0 = tqdm_notebook(range(100))
    test_case_tqdm_notebook_1 = tqdm_notebook(range(100),desc="Test_Desc")
    test_case_tqdm_notebook_2 = tqdm_notebook(range(100),desc="Test_Desc",ncols=100,
                                              disable=False)
    # Unit test for close function of tqdm_notebook
    test_case_tqdm_notebook_3 = trange(10)

# Generated at 2022-06-26 09:47:26.723858
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    total = 1000
    desc = '-'

    # Default test case
    tqdm_notebook.status_printer(None, total, desc)
    # Customized test case
    tqdm_notebook.status_printer(None, total, desc, ncols = 200)


# Generated at 2022-06-26 09:47:39.766007
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook(disable=False, mininterval=0.1, smoothing=1-1.0/1, gui=True)
    msg = 'test_msg_test_msg_test_msg'
    tqdm_notebook_0.container.children[0].value = 'test_msg_test_msg_test_msg'
    # Disable the below del command in case the TqdmHBox object has not been initialized
    # del tqdm_notebook_0.container
    # ncols = None
    # value = 1
    # pbar = ipywidgets.FloatProgress(min=0, max=1)
    # container = TqdmHBox(children=[ltext, pbar, rtext])

    # tqdm_notebook_0.container

# Generated at 2022-06-26 09:47:42.001103
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_0 = tqdm_notebook()
    try:
        tqdm_notebook_0.close()
    except AttributeError:
        pass


# Generated at 2022-06-26 09:47:52.263795
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    print("Running test case: test_tqdm_notebook___iter__")
    def test_func():
        pass

    tqdm_notebook_0 = tqdm_notebook(desc='Test Desc', disable=True)
    tqdm_notebook_1 = tqdm_notebook(desc='Test Desc', total=10, disable=True)
    tqdm_notebook_2 = tqdm_notebook(5, desc='Test Desc', total=10, disable=True)
    tqdm_notebook_3 = tqdm_notebook(5, desc='Test Desc', total=10, disable=True)
    tqdm_notebook_3.reset()
    tqdm_notebook_3.update()
    tqdm_notebook_3.close()


# Generated at 2022-06-26 09:47:57.769959
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # If repr() does not call repr_pretty, the pretty print feature does not work.
    # TODO: Ideally unit test would make a valid output from repr_pretty, and test its output.
    test_case_0()

# Generated at 2022-06-26 09:48:17.942661
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tnb_0 = tqdm_notebook(max=10)
    tnb_0.display()
    assert True



# Generated at 2022-06-26 09:48:21.136824
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    cd = tqdm_notebook(range(5))
    for i in cd:
        pass


# Generated at 2022-06-26 09:48:26.589444
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from random import randint
    tqdm_notebook_0 = tqdm_notebook(tqdm_notebook_0)
    for i in tqdm_notebook_0:
        assert(isinstance(i, int))
        assert(i <= 99)
        assert(i >= 0)


# Generated at 2022-06-26 09:48:31.981609
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()


if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_update()

# Generated at 2022-06-26 09:48:36.076851
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.close()


# Generated at 2022-06-26 09:48:42.403961
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm._tqdm_notebook import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook(iterable=[1, 2, 3])
    for i in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:48:50.148897
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t_r_a_n_g_e_0 = tnrange(5)
    list_0 = []
    for t_r_a_n_g_e_1 in t_r_a_n_g_e_0:
        list_0.append(t_r_a_n_g_e_1)
    assert list_0 == [0, 1, 2, 3, 4]


# Generated at 2022-06-26 09:48:54.307298
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook()


# Generated at 2022-06-26 09:49:03.595375
# Unit test for method close of class tqdm_notebook

# Generated at 2022-06-26 09:49:07.928756
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook(total=None, disable=None,
                                    leave=True, file=None, ncols=None, mininterval=1.0,
                                    maxinterval=10.0, miniters=None, ascii=None, desc='',
                                    unit='it', unit_scale=None, dynamic_ncols=False,
                                    smoothing=0.3, bar_format='{l_bar}{bar}{r_bar}',
                                    initial=0, position=None, postfix=None, unit_divisor=1000,
                                    gui=True, colour='blue')


# Generated at 2022-06-26 09:50:17.034855
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tc_list_0 = tqdm(list(range(5)), total=5)
    try:
        for tc_list_1 in tc_list_0:
            pass
    except:
        print("Unexpected error:", sys.exc_info()[0])
        raise


test_case_0()
test_tqdm_notebook___iter__()

# Generated at 2022-06-26 09:50:24.553124
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Arrange
    iter_0 = TqdmHBox();
    iter_1 = iter(iter_0);
    # Act
    iterator = tqdm_notebook(iter_1);
    # Assert
    assert isinstance(iterator.format_dict, dict);
    assert not iterator.last_print_n;


# Generated at 2022-06-26 09:50:28.044896
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_status_printer_0 = tqdm_notebook.status_printer(_, total=None, desc=None, ncols=None)


# Generated at 2022-06-26 09:50:30.481922
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_obj = tqdm_notebook()
    tqdm_notebook_obj.status_printer(1)


# Generated at 2022-06-26 09:50:33.261052
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_status_printer_0 = tqdm_notebook_0.status_printer(None, None, None, None)


# Generated at 2022-06-26 09:50:34.614223
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tnb_0 = tqdm_notebook()
    tnb_0.display("hello", 1, False, None, True)


# Generated at 2022-06-26 09:50:41.013460
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for i in range(0, 4):
        try:
            current = i
            tqdm_notebook_reset_ref = tqdm_notebook(iterable=range(0, 4), desc='A very basic demo', leave=False).reset(total=i)
        except Exception as e:
            raise Exception("Failed with exception: " + str(e))


if __name__ == "__main__":
    # Running unit tests
    import sys
    import unittest
    case_0_suite = unittest.TestSuite()
    case_0_suite.addTest(TestCase("test_case_0"))
    runner = unittest.TextTestRunner()
    runner.run(case_0_suite)

# Generated at 2022-06-26 09:50:51.423626
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Testing TqdmHBox initialization
    # Testing IProgress Widget when total!=None
    ipython_progress_bar_1 = tqdm_notebook.status_printer(
        sys.stdout, total=0, desc="Description", ncols="100%")
    ipython_progress_bar_2 = tqdm_notebook.status_printer(
        sys.stdout, total=0, desc="Description", ncols=100)
    ipython_progress_bar_3 = tqdm_notebook.status_printer(
        sys.stdout, total=80, desc="Description", ncols="200px")

# Generated at 2022-06-26 09:50:55.774157
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    _ = tqdm_notebook(range(10))
    _.update(1)
    _.update()


# Generated at 2022-06-26 09:50:58.905822
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tmp_tqdm_obj = tqdm_notebook()
    tmp_tqdm_obj.clear()


# Generated at 2022-06-26 09:51:32.000195
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Set total
    total = 10
    # Init class tqdm_notebook
    tqdm_0 = tqdm_notebook(total=total)
    # Update 5x
    for _ in range(5):
        # Update by 1
        tqdm_0.update()
    # Check n
    assert tqdm_0.n == 5

# Running unit tests
if __name__ == '__main__':
    test_case_0()
    test_tqdm_notebook_update()

# Generated at 2022-06-26 09:51:43.738669
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Constructor with no arguments
    tqdm_notebook_0 = tqdm_notebook()
    # Test instance data of tqdm_notebook_0 with ipython_vars
    assert hasattr(tqdm_notebook_0, 'ncols')
    assert hasattr(tqdm_notebook_0, 'container')
    assert hasattr(tqdm_notebook_0, 'displayed')
    assert hasattr(tqdm_notebook_0, 'disp')
    assert hasattr(tqdm_notebook_0, '_instances')
    assert hasattr(tqdm_notebook_0, 'colour')
    assert hasattr(tqdm_notebook_0, '_miniters')

# Generated at 2022-06-26 09:51:52.290029
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(total=5, position=1)
    bar.reset(total=10)
    bar.update(5)
    assert(bar.n == 5)
    assert(bar.total == 10)
    assert(bar.n == 5)
    bar.reset()
    assert(bar.n == 0)


# Generated at 2022-06-26 09:51:55.248772
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()
    tqdm_notebook_display(tqdm_notebook_0)


# Generated at 2022-06-26 09:51:58.741015
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    """Test method TqdmHBox.__repr__ for correct output"""
    tqdm_h_box_1 = TqdmHBox()
    string_1 = tqdm_h_box_1.__repr__()
    assert string_1 == '\r    0%|          | 0/0 [00:00<?, ?it/s]'


# Generated at 2022-06-26 09:52:08.709069
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    from ipywidgets import HTML
    from ipywidgets import FloatProgress as IProgress
    from ipywidgets import HBox
    try:
        from IPython.display import display
    except ImportError:
        pass
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.file = sys.stdout
    tqdm_notebook_0.desc = 'test_desc'
    tqdm_notebook_0.total = 10
    tqdm_notebook_0.disable = False
    tqdm_notebook_0.unit = None
    tqdm_notebook_0.unit_scale = True

    tqdm_notebook_0.display()



# Generated at 2022-06-26 09:52:19.967171
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    return_value1 = tqdm_notebook.status_printer(
        _=None, total=None, desc=None, ncols=None)
    return_value2 = tqdm_notebook.status_printer(
        _=None, total=3, desc=None, ncols=None)
    return_value3 = tqdm_notebook.status_printer(
        _=None, total=3, desc='test', ncols=None)
    return_value4 = tqdm_notebook.status_printer(
        _=None, total=3, desc='test', ncols=50)


# Generated at 2022-06-26 09:52:29.285187
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Create a tqdm instance with unit_scale=True and total=100 
    # and call the update method with n=2
    # Note: the value should be updated with unit_scale=True by 2*100/100 = 2
    tqdm_notebook_0 = tqdm_notebook(unit_scale=True, total=100)
    tqdm_notebook_0.update(n = 2)
    tqdm_notebook_0.close()


# Generated at 2022-06-26 09:52:30.806941
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    # no assertion



# Generated at 2022-06-26 09:52:36.523426
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # method tqdm_notebook.update of class tqdm_notebook has no arguments
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:53:09.410246
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # normal behaviour
    tqdm_notebook_0 = tqdm_notebook(total=None)
    tqdm_notebook_0.display(None, None, False, None, False)
    # abnormal behaviour
    # case 1, was not displayed so no close attribute
    try:
        tqdm_notebook_1 = tqdm_notebook()
        tqdm_notebook_1.display(close=True)
    except AttributeError:
        pass
    # case 2, was displayed but bar_style is still danger and no close attribute
    try:
        tqdm_notebook_2 = tqdm_notebook()
        tqdm_notebook_2.display(close=True, bar_style='danger')
    except AttributeError:
        pass


# Generated at 2022-06-26 09:53:20.268219
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    args_0 = [
        [
            0,
        ]
    ]

# Generated at 2022-06-26 09:53:30.143438
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    assert True
    # 1. init tqdm
    tqdm_0 = tqdm_notebook(total=10)
    tqdm_0.__init__(
        desc='description', total=10, leave=False, position=0, 
        unit='unit', miniters=1, mininterval=0, ascii=False, 
        disable=False, ncols=100, 
        bar_format='{l_bar}{bar}{r_bar}', initial=0, maxinterval=10.0, 
        smooth=1.0, postfix=None, dynamic_ncols=False, 
        unit_scale=True, gui=True, colour='colour', 
        nrows=None, file=sys.stdout)
    # 2. init tqdm_h_box
   

# Generated at 2022-06-26 09:53:30.975924
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    pass



# Generated at 2022-06-26 09:53:32.055776
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook()
    bar.reset(total=100)


# Generated at 2022-06-26 09:53:41.438946
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup tqdm_notebook
    total = 100

    # Unittest
    with tqdm_notebook(total=total) as t:
        assert (t.reset != None), "Reset function doesn't exist"
        # Assert before reset
        assert t.n == 0, "Invalid number of iterations (before reset)!"\
                         "Expected: 0; Observed: {0}".format(t.n)
        assert t.total == 100, "Invalid total (before reset)!"\
                               "Expected: 100; Observed: {0}".format(t.total)

        # Reset tqdm_notebook
        t.reset(total=total)

        # Assert after reset

# Generated at 2022-06-26 09:53:46.187401
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .utils import _range
    
    for i in tqdm(_range(10)):
        pass
    for i in tqdm(_range(10), bar_format = '{bar} {l_bar} {bar}'):
        pass


# Generated at 2022-06-26 09:53:59.737902
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test for tqdm_notebook.reset
    """
    unit_test = tqdm_notebook(total=5)
    unit_test.reset(5)
    assert unit_test.n == 0
    assert unit_test.dynamic_ncols == False
    assert unit_test.total == 5
    assert unit_test.dynamic_miniters is True
    assert unit_test.smoothing is None
    assert unit_test.bar_format is None
    assert unit_test.miniters == 0
    assert unit_test.ascii is False
    assert unit_test.desc is None
    assert unit_test.unit is None
    assert unit_test.postfix is None
    assert unit_test.unit_scale is False
    assert unit_test.gui is True
    assert unit

# Generated at 2022-06-26 09:54:01.375347
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    pass


# Generated at 2022-06-26 09:54:05.334717
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Setup
    s_0 = tqdm_notebook(total=1)
    # AssertionError: AssertionError("IProgress not found. Please update jupyter and ipywidgets. See https://ipywidgets.readthedocs.io/en/stable/user_install.html")
    s_0.close()


# Generated at 2022-06-26 09:54:40.106662
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # input arguments for the stub
    fp = sys.stderr
    leave = False
    # expected output for the stub
    expected_output = range(10)
    # copy so as not to affect any other tests
    kwargs = tqdm_notebook_0.kwargs.copy()
    kwargs['gui'] = True
    kwargs['fp'] = fp
    kwargs['leave'] = leave
    # instantiate the object to be tested
    tqdm_notebook_1 = tqdm_notebook(**kwargs)
    # call the method
    actual_output = tqdm_notebook_1.__iter__()
    # compare the output to the expected
    assert actual_output == expected_output


# Generated at 2022-06-26 09:54:50.949125
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook(total=0)
    tqdm_notebook_1 = tqdm_notebook(total=1)
    tqdm_notebook_2 = tqdm_notebook(total=2)
    tqdm_notebook_3 = tqdm_notebook(total=3)
    tqdm_notebook_4 = tqdm_notebook(total=4)
    tqdm_notebook_5 = tqdm_notebook(total=5)
    tqdm_notebook_6 = tqdm_notebook(total=6)
    tqdm_notebook_7 = tqdm_notebook(total=7)
    tqdm_notebook_8 = tqdm_notebook(total=8)
   

# Generated at 2022-06-26 09:54:56.057323
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Local variables
    iter_return = None
    tqdm_notebook_0 = tqdm_notebook()
    iter_return = iter(tqdm_notebook_0)
    return iter_return


# Generated at 2022-06-26 09:54:59.773391
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()

    # setup the parameters, then test
    tqdm_notebook_1.disp('test')
    tqdm_notebook_1.display(msg = 'test2')
    tqdm_notebook_1.display(msg = 'test3', close = True)
    

# Generated at 2022-06-26 09:55:08.100081
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(range(0, 1000), desc = 'Preparing')
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0 = tqdm_notebook(range(0, 10), desc = 'Preparing')
    for i in tqdm_notebook_0:
      pass


# Generated at 2022-06-26 09:55:12.466474
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Test result without a pbar
    test_container = TqdmHBox()
    assert test_container.__repr__(pretty=True) == "{'n': 0, 'total': None, 'bar_format': None, 'unit': ''}"


# Generated at 2022-06-26 09:55:21.012341
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook(iterable=[1, 2, 3, 4, 5, 6, 7, 8, 9, 10])
    for tqdm_notebook_0_val_0 in tqdm_notebook_0:
        # check if type of val_0 matches expected type
        assert isinstance(tqdm_notebook_0_val_0, int)


# Generated at 2022-06-26 09:55:24.684276
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    for i in tqdm_notebook(range(3)):
        pass


# Generated at 2022-06-26 09:55:27.525805
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert tqdm_notebook().__iter__().__class__ == tqdm_notebook


# Generated at 2022-06-26 09:55:31.905249
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
	tqdm_notebook_1 = tqdm_notebook()
	tqdm_notebook_1.update()
	tqdm_notebook_1.update(n=1)
