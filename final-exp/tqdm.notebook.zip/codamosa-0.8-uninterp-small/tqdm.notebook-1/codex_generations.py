

# Generated at 2022-06-26 09:46:41.314493
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(_, total=None, desc=None, ncols=None)


# Generated at 2022-06-26 09:46:46.621068
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # test case 1
    # set total is None
    total_1 = None
    desc_1 = "Downloading"
    ncols_1 = "100px"
    widget = tqdm_notebook.status_printer(_, total_1, desc_1, ncols_1)

    # Unit test for method __init__ of class tqdm_notebook

# Generated at 2022-06-26 09:46:48.137796
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Put your code here
    pass



# Generated at 2022-06-26 09:46:56.358688
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=1, desc='Desc 0', ncols=80) as t:

        # Test case 1: n = 1
        t.update(n=1)

        # Test case 2: n = 0
        t.update(n=0)

        # Test case 3: n = -1
        t.update(n=-1)

# Generated at 2022-06-26 09:47:03.149695
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # create object tqdm_notebook
    obj = tqdm_notebook(10)
    # check that initial value of n is 0
    assert obj.n == 0
    # call update method with parameter n = 2
    obj.update(2)
    # check that n is 2
    assert obj.n == 2
    pass

# Generated at 2022-06-26 09:47:05.415527
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    x = tqdm_notebook.status_printer(None)


# Generated at 2022-06-26 09:47:13.269019
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    msg = 'msg'

    # Case 0: disable
    #tqdm_notebook_0 = tqdm_notebook(disable=True)
    #tqdm_notebook_0.display(msg)

    # Case 1: msg = None
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display(pos=1)

    # Case 2: close = True
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.display(msg,pos=2,close=True)

    # Case 3: bar_style = None
    tqdm_notebook_3 = tqdm_notebook()

# Generated at 2022-06-26 09:47:17.855755
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Arrange
    tqdm_notebook_0 = tqdm_notebook()
    # Act
    # Assert
    test_case_0()



# Generated at 2022-06-26 09:47:26.076613
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook(range(2))
    for i in tqdm_notebook_0:
        tqdm_notebook_0.update()
    tqdm_notebook_1 = tqdm_notebook(range(2), disable=True)
    for i in tqdm_notebook_1:
        tqdm_notebook_1.update()
    tqdm_notebook_2 = tqdm_notebook(range(2), leave=False)
    for i in tqdm_notebook_2:
        tqdm_notebook_2.update()
    tqdm_notebook_3 = tqdm_notebook(range(2), leave=True)
    for i in tqdm_notebook_3:
        tqdm

# Generated at 2022-06-26 09:47:27.685793
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
	tqdm_notebook_0 = tqdm_notebook()
	tqdm_notebook_0.update()


# Generated at 2022-06-26 09:47:51.915404
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():

    # testing the total argument
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_2 = tqdm_notebook(total=20)

    # testing the position argument
    tqdm_notebook_3 = tqdm_notebook(position=0)
    tqdm_notebook_4 = tqdm_notebook(position=1)

    # testing the disable argument
    tqdm_notebook_5 = tqdm_notebook(disable=False)
    tqdm_notebook_6 = tqdm_notebook(disable=True)

    # testing the unit argument
    tqdm_notebook_7 = tqdm_notebook(unit='B')

# Generated at 2022-06-26 09:48:00.129357
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test method 'update' of class 'tqdm_notebook'
    """
    # raise AssertionError if test fails
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    assert(tqdm_notebook_1.n==1)


# Generated at 2022-06-26 09:48:03.936362
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_status_printer_1 = tqdm_notebook_1.status_printer(file=sys.stderr, total=10)


# Generated at 2022-06-26 09:48:07.635625
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook(total=10) as t:
        for i in range(10):
            t.display()



# Generated at 2022-06-26 09:48:13.954318
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    output = tqdm_notebook_0.status_printer(sys.stderr, total=100)
    if not (output.__class__.__name__ == 'TqdmHBox'):
        raise Exception("Testcase failed for 'status_printer'")


# Generated at 2022-06-26 09:48:24.367581
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    # Creating an object of class tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    # Creating an object of class tqdm_notebook
    tqdm_notebook_1 = tqdm_notebook()

    # Creating a list 'i_list' of integers from 1 to 100
    i_list = list(range(1, 100))

    # Creating a list 'i_list_1' of integer from 1 to 100
    i_list_1 = list(range(1, 100))

    # Initializing 'n' to 1
    n = 1

    # Initializing 'n_1' to 1
    n_1 = 1

    # Adding i to the progress bar
    for i in i_list:
        # Using the update method to update the progress bar
        tqdm_

# Generated at 2022-06-26 09:48:26.435719
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(range(100)) as t:
        for i in t:
            pass


# Generated at 2022-06-26 09:48:32.846465
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test if total is reset
    """
    test_total = 10
    tqdm_notebook_1 = tqdm_notebook(total = test_total)
    assert tqdm_notebook_1.total == test_total
    new_total = 20
    tqdm_notebook_1.reset(new_total)
    assert tqdm_notebook_1.total == new_total



# Generated at 2022-06-26 09:48:39.241062
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1.display(msg="", pos=0, close=False, bar_style=None, check_delay=True)
    tqdm_notebook_0.display(msg="", pos=0, close=False, bar_style=None, check_delay=True)


# Generated at 2022-06-26 09:48:41.572845
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook.clear()


# Generated at 2022-06-26 09:49:11.449100
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        test_case_0()
    except:
        print("Exception in user code:")
        print('-' * 60)
        traceback.print_exc(file=sys.stdout)
        print('-' * 60)
        raise

# Generated at 2022-06-26 09:49:14.865594
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()


# Generated at 2022-06-26 09:49:20.153021
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset(total=10)
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:49:23.570580
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.__init__()
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:49:31.054196
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_ = tqdm_notebook()
    tqdm_notebook_.update(n=1)

    tqdm_notebook_.update(n=0)

    tqdm_notebook_.update(n=-0)


# Generated at 2022-06-26 09:49:36.518047
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    def tqdm_notebook_iter(self):
        for obj in super(tqdm_notebook, self).__iter__():
            # return super(tqdm...) will not catch exception
            yield obj
    # Initialize mock object
    tqdm_notebook_1 = tqdm_notebook()
    # Invoke method with no parameters
    tqdm_notebook_iter(tqdm_notebook_1)


# Generated at 2022-06-26 09:49:42.128131
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.status_printer(file=sys.stdout, total=10, desc="tqdm", ncols=80)


# Generated at 2022-06-26 09:49:47.312075
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Prepare test
    tqdm_notebook_1 = tqdm_notebook(total=1)
    tqdm_notebook_1.n = 1
    # Execute tested method
    tqdm_notebook_1.reset()
    # Check
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.last_print_n == 0
    assert tqdm_notebook_1.last_print_t is None
    assert tqdm_notebook_1.start_t is None


# Generated at 2022-06-26 09:49:59.199242
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import warnings
    warnings.filterwarnings("ignore", category=DeprecationWarning)

    # Use HTML widget as output file
    file_1 = HTML()

    # Check 1 : Total is specified
    l_result = tqdm_notebook.status_printer(
        file_1, total=100, desc=None, ncols=None)

    # Check the type of returned value and the output file
    assert isinstance(l_result, TqdmHBox) and \
        isinstance(l_result.children[0], HTML) and \
        isinstance(l_result.children[1], IProgress) and \
        isinstance(l_result.children[2], HTML)

    # Check 2 : Total is not specified

# Generated at 2022-06-26 09:50:02.496784
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in tqdm_notebook(range(100)):
        pass


# Generated at 2022-06-26 09:50:30.322988
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    from tqdm.notebook import tqdm_notebook, TqdmHBox
    tqdm_notebook_0 = tqdm_notebook()
    tmp_0 = TqdmHBox()
    tmp_1 = tmp_0.__repr__()
    # TODO: Add assertions for return values and side effects


# Generated at 2022-06-26 09:50:31.689505
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    test_case_0()


# Generated at 2022-06-26 09:50:37.455557
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_1 = tqdm_notebook()
    assert repr(tqdm_notebook_1.container) == '<tqdm_notebook._tqdm_notebook.TqdmHBox at 0x7f8e4425c2d0>'
    # No assert, just checking for no failure


# Generated at 2022-06-26 09:50:46.617923
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialization
    tqdm_notebook_1 = tqdm_notebook()

    # Check type of returned object
    # assert type(tqdm_notebook_1) is class 'tqdm.tqdm_notebook._tqdm_notebook.tqdm_notebook'
    # Exception message check
    # assert tqdm_notebook_1.update(n=1) == __


# Generated at 2022-06-26 09:50:50.600406
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()

    # tqdm_notebook_1.status_printer.__doc__
    # with out arguments
    tqdm_notebook_1.status_printer()
    # with arguments
    tqdm_notebook_1.status_printer(tqdm_notebook_1, None, None, None)


# Generated at 2022-06-26 09:51:02.080547
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test that display handles None msg
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(msg=None)
    # Test that display handles empty msg
    tqdm_notebook_0.display(msg='')
    # Test that display handles non empty msg
    tqdm_notebook_0.display(msg='unit test')
    # Test that display handles  None bar_style
    tqdm_notebook_0.display(bar_style=None)
    # Test that display handles empty bar_style
    tqdm_notebook_0.display(bar_style='')
    # Test that display handles non empty bar_style
    tqdm_notebook_0.display(bar_style='info')
    # Test that display handles bool close


# Generated at 2022-06-26 09:51:12.673872
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test with default args first
    tqdm_notebook_0 = tqdm_notebook()
    list_0 = [i for i in tqdm_notebook_0]
    assert list_0 == []

    tqdm_notebook_0 = tqdm_notebook(0)
    list_0 = [i for i in tqdm_notebook_0]
    assert list_0 == []

    tqdm_notebook_0 = tqdm_notebook(0, 1)
    list_0 = [i for i in tqdm_notebook_0]
    assert list_0 == []

    tqdm_notebook_0 = tqdm_notebook(5)
    list_0 = [i for i in tqdm_notebook_0]

# Generated at 2022-06-26 09:51:23.847980
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():

    # Testing GUI mode
    temp = tqdm_notebook()
    container = temp.status_printer(None, total = 10, desc = "Testing", ncols = "100px")
    assert container.layout.width == "100px"
    assert container.layout.display == "inline-flex"
    assert container.layout.flex_flow == "row"

    container = temp.status_printer(None, total = 10, desc = "Testing", ncols = "100%")
    assert container.layout.width == "100%"
    assert container.layout.display == "inline-flex"
    assert container.layout.flex_flow == "row"

    container = temp.status_printer(None, total = 10, desc = "Testing", ncols = 20)
    assert container.layout.width == "20px"


# Generated at 2022-06-26 09:51:29.676633
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    assert tqdm_notebook_0.__iter__() == super(tqdm_notebook,tqdm_notebook_0).__iter__()


# Generated at 2022-06-26 09:51:40.304222
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Initialization
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.miniters = 10
    tqdm_notebook_0.mininterval = 0.1
    tqdm_notebook_0.maxinterval = 10
    tqdm_notebook_0.miniters = 10
    tqdm_notebook_0.mininterval = 0.1
    tqdm_notebook_0.maxinterval = 10
    tqdm_notebook_0.miniters = 10
    tqdm_notebook_0.mininterval = 0.1
    tqdm_notebook_0.maxinterval = 10
    tqdm_notebook_0.miniters = 10

# Generated at 2022-06-26 09:52:27.514650
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.close()


# Generated at 2022-06-26 09:52:35.021793
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY >= 4:
        tqdm_notebook.status_printer(
            _ = None, total = 10, desc = "test_case", ncols = 100
        )


# Generated at 2022-06-26 09:52:37.731580
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    for obj in [tqdm_notebook()]:
        assert (obj.clear() is None)


# Generated at 2022-06-26 09:52:41.969869
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    with tqdm_notebook(total=2, file=sys.stdout, desc='test') as t:
        for i in tqdm_notebook_0:
            pass
        assert t.n == 1


# Generated at 2022-06-26 09:52:47.405821
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.close()


# Generated at 2022-06-26 09:52:59.495622
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from tqdm.notebook import tqdm_notebook
    from tqdm import tqdm
    import time

    list_range = [i for i in range(10)]

    # Generate bars
    tqdm_notebook_1 = tqdm(list_range)
    tqdm_notebook_2 = tqdm(list_range, desc='#1')
    tqdm_notebook_3 = tqdm(list_range, desc='#2', leave=True)

    tqdm_1 = tqdm(list_range)
    tqdm_2 = tqdm(list_range, desc='#1')
    tqdm_3 = tqdm(list_range, desc='#2', leave=True)


# Generated at 2022-06-26 09:53:01.086290
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    # Create an instance of TqdmHBox
    tqdmHBox_0 = TqdmHBox()


# Generated at 2022-06-26 09:53:06.787748
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook(desc="test_tqdm_notebook.clear()")
    tqdm_notebook_0 = tqdm_notebook(desc="test_tqdm_notebook.clear()")
    with tqdm_notebook_1 as obj:
        for i in tqdm_notebook_0:
            obj.clear()


# Generated at 2022-06-26 09:53:17.959845
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import time
    from tqdm.autonotebook import tqdm
    for i in tqdm(range(20), desc='1st loop'):
        for j in tqdm(range(50), desc='2nd loop', leave=False):
            for k in tqdm(range(100), desc='3nd loop', leave=False,
                          bar_format="{l_bar}{bar}|{n_fmt}/{total_fmt}[{elapsed}<{remaining}]"):
                time.sleep(0.01)
            time.sleep(0.01)


# Generated at 2022-06-26 09:53:22.596783
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()

