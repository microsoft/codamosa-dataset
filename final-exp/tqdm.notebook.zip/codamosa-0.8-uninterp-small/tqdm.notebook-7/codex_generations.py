

# Generated at 2022-06-26 09:46:50.071549
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # Without arguments
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()



# Generated at 2022-06-26 09:46:58.360512
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    status_printer_arg_types = [int, NoneType]
    for arg_count, arg_type in enumerate(status_printer_arg_types):
        if arg_count == 0:
            arg = 1
        elif arg_count == 1:
            arg = None
        with raises(TypeError):
            tqdm_notebook_1.status_printer(arg)


# Generated at 2022-06-26 09:47:10.923981
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test 'normal' success case
    tqdm_notebook_1 = tqdm_notebook()
    list_1 = [i for i in tqdm_notebook_1]
    assert list_1 == [], 'unexpected result: {}'.format(list_1)

    # Test 'error' case
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.total = 0
    tqdm_notebook_2.n = 5
    try:
        for i in tqdm_notebook_2:
            pass
    except:
        pass
    tqdm_notebook_2.total = 2
    tqdm_notebook_2.n = 3

# Generated at 2022-06-26 09:47:18.910099
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        print("Testing display method of tqdm_notebook")
        # initialize class
        tqdm_notebook_1 = tqdm_notebook()
        # call display
        tqdm_notebook_1.display()
    except Exception as e:
        print("Test failed: {}".format(e))
        raise e


# Generated at 2022-06-26 09:47:31.617013
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .tests import tests

    # initialize tqdm_notebook instance
    tqdm_notebook_ins = tqdm_notebook()

    # set tqdm_notebook_ins.total
    total = 4
    tqdm_notebook_ins.total = total

    # check if tqdm_notebook_ins.total is equal to total
    tests.test_function(total, tqdm_notebook_ins.total)

    # set tqdm_notebook_ins.n
    n = 3
    tqdm_notebook_ins.n = n

    # check if tqdm_notebook_ins.n is equal to n
    tests.test_function(n, tqdm_notebook_ins.n)

    # call reset method
    total_new = 7
    tqdm

# Generated at 2022-06-26 09:47:42.828595
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import os
    import sys
    import types
    import unittest
    # Set environment variable to use dummy display
    os.environ["TEST_TQDM_DISPLAY"] = "dummy"
    # Reload tqdm to apply changes
    reload(sys.modules["tqdm._tqdm_notebook"])
    from tqdm._tqdm_notebook import tqdm_notebook
    # Initialize tqdm instance
    tqdm_notebook_0 = tqdm_notebook()

    @types.MethodType
    def test_display(self):
        self.display()

    tqdm_notebook_0.display = types.MethodType(test_display, tqdm_notebook_0)

    from unittest import TestCase

# Generated at 2022-06-26 09:47:52.548495
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    print('\nEntering test_TqdmHBox___repr__...\n')
    # code from tqdm/_tqdm_notebook.py
    class TqdmHBox(HBox):
        """`ipywidgets.HBox` with a pretty representation"""
        def _repr_json_(self, pretty=None):
            pbar = getattr(self, 'pbar', None)
            if pbar is None:
                return {}
            d = pbar.format_dict
            if pretty is not None:
                d["ascii"] = not pretty
            return d

        def __repr__(self, pretty=False):
            pbar = getattr(self, 'pbar', None)
            if pbar is None:
                return super(TqdmHBox, self).__repr__

# Generated at 2022-06-26 09:48:02.343139
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from nose.tools import assert_equal
    from nose.tools import assert_raises
    from nose.tools import assert_true
    from nose.tools import assert_false

    tqdm_notebook_0 = tqdm_notebook()
    assert_equal(tqdm_notebook_0.displayed, False)


if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook()

# Generated at 2022-06-26 09:48:07.136830
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with tqdm_notebook() as ip:
        for i in range(10):
            ip.display()


# test that the special attribute `.colour` can be set

# Generated at 2022-06-26 09:48:11.268076
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(0, 100)
    tqdm_notebook_1.update(100)


# Generated at 2022-06-26 09:49:04.931659
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.update()


# Generated at 2022-06-26 09:49:10.914069
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # create test object
    tqdm_notebook_1 = tqdm_notebook()
    # check if a reset call works
    assert tqdm_notebook_1.reset() == None



# Generated at 2022-06-26 09:49:13.430838
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        tqdm_notebook_0 = tqdm_notebook(0,1)
        assert isinstance(tqdm_notebook_0,tqdm_notebook)
    except ImportError:
        pass
            

# Generated at 2022-06-26 09:49:19.013462
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(bar_format="{l_bar}")
    tqdm_notebook_1.update(1)


# Generated at 2022-06-26 09:49:23.480663
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import tqdm
    t = tqdm.tqdm_notebook(range(10))
    for i in range(10):
        t.update(1)
        

# Generated at 2022-06-26 09:49:36.850772
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    Setup
    -----
    A tqdm_notebook object and all necessary inputs to call display method.
    E.g. container, pbar, ltext, rtext, self.n, msg and bar_style

    Expected out
    ------------
    >>> tn1.display(msg='test_msg')
    >>> pbar.value == self.n
    >>> ltext.value == ''
    >>> rtext.value == 'test_msg'

    >>> tn1.display(msg="",close=True)
    >>> container.visible = False
    """
    tqdm_notebook_1 = tqdm_notebook()

    ltext = HTML()
    rtext = HTML()
    pbar = IProgress(min=0, max=1)
    tqdm_notebook_1.container = T

# Generated at 2022-06-26 09:49:47.237706
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():

    # Basic test
    tqdm_notebook_status_printer_0 = tqdm_notebook.status_printer("stderr", 10)
    tqdm_notebook_status_printer_1 = tqdm_notebook.status_printer(file=sys.stderr, total=10)

    # Test with optional arguments
    tqdm_notebook_status_printer_2 = tqdm_notebook.status_printer("stderr", 10, "Experimental IPython/Jupyter Notebook widget using tqdm!\n", 20)

# Generated at 2022-06-26 09:49:58.909732
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    _, pbar, _ = tqdm_notebook().status_printer(None, 100).children
    assert(pbar.min == 0)
    assert(pbar.max == 100)

# References:
# IPython/Jupyter Notebook widget API reference:
# http://ipywidgets.readthedocs.io/en/latest/examples/Widget%20List.html
# https://github.com/ipython/ipywidgets/blob/master/ipywidgets/widgets/widget.py

# tqdm API reference:
# http://tqdm.readthedocs.io/en/latest/
# https://github.com/noamraph/tqdm/blob/master/tqdm/tqdm.py

# Generated at 2022-06-26 09:50:11.512414
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    a = tnrange(10)
    # verify that reset does not create a new widget
    b = a.reset()
    assert id(a) == id(b)
    # verify that reset resets the progress bar
    assert b.n == 0
    assert b.last_print_n == 0
    # verify that reset resets the color of the progress bar
    assert b.colour is None
    # verify that reset resets the maximum of the progress bar
    assert b.total == 10
    # verify that reset resets the total to None if no total was given before
    b = tnrange()
    b = b.reset()
    assert b.total is None
    # verify that reset resets the total to a given argument
    b = b.reset(total=100)
    assert b.total == 100
    assert b.ncol

# Generated at 2022-06-26 09:50:21.505621
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test with all possible arguments
    from tqdm import tqdm

    bar_styles = list(tqdm.bar_styles.keys())
    bar_lengths = [1, 5, 10, 20, 30, 40, 50, 100, 200, 300, 400, 500, 1000]
    bar_lengths.extend([3, 4, 6, 7, 8, 9, 17, 23, 37])  # prime numbers
    bar_descriptions = ["", " ", " ", " ", " ", " ", " ", " ", " ", " ", "", ""]
    bar_descriptions.extend([" ", " ", " ", " ", " ", " ", " ", " ", " "])

# Generated at 2022-06-26 09:51:10.442052
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    # ipywidgets.widget_bool.WidgetBool is __iter__
    assert isinstance(tqdm_notebook_0.__iter__(), ipywidgets.widget_bool.WidgetBool)


# Generated at 2022-06-26 09:51:22.217740
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test Scenario 1:
    # tqdm_notebook_0 = tqdm_notebook()
    # tqdm_notebook_0.status_printer()
    # return tqdm_notebook_0
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook_0.status_printer()
    return tqdm_notebook_1
    # Test Scenario 2:
    # tqdm_notebook_0 = tqdm_notebook()
    # tqdm_notebook_0.status_printer(file)



# Generated at 2022-06-26 09:51:34.767780
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm_notebook
    from datetime import datetime
    from time import sleep
    # test 1
    total = 100
    with tqdm_notebook(total = total) as pbar:
        for i in range(total):
            pbar.update(1)
    sleep(1)

    assert pbar.total == total
    assert pbar.n == total

    # test 2
    total = 100
    pbar = tqdm_notebook(total = total)
    for i in range(total):
        pbar.update(1)
    sleep(1)

    assert pbar.total == total
    assert pbar.n == total
    # reset the bar
    pbar.reset()
    assert pbar.total == total
    assert pbar.n == 0

    # test

# Generated at 2022-06-26 09:51:42.186664
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initializes instance of tqdm_notebook
    tqdm_notebook_instance = tqdm_notebook()

    # Tests class initialization
    assert(tqdm_notebook_instance.gui == True)
    assert(tqdm_notebook_instance.disable == False)

    # Tests update method
    assert(tqdm_notebook_instance.update() == True)



# Generated at 2022-06-26 09:51:45.917152
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    for obj in tqdm_notebook_0.__iter__():
        pass


# Generated at 2022-06-26 09:51:49.323484
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    container = TqdmHBox()
    r = container.__repr__()
    assert(r == '')


# Generated at 2022-06-26 09:51:53.333380
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        for i in tqdm_notebook(range(1)):
            pass
    except Exception:
        assert False
    assert True


# Generated at 2022-06-26 09:51:55.328319
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook(total=3)
    tqdm_notebook_1.reset()

# Generated at 2022-06-26 09:51:58.124693
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    assert isinstance(TqdmHBox.__repr__, Callable)
    assert isinstance(TqdmHBox.__repr__(), str)
    assert True


# Generated at 2022-06-26 09:52:05.844096
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from unittest import mock
    from pytest import raises
    with mock.patch.object(tqdm_notebook, '__iter__'):
        tqdm_notebook_0 = tqdm_notebook()
        raises(NotImplementedError, tqdm_notebook_0.__iter__)


# Generated at 2022-06-26 09:53:04.950432
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    progress = tqdm_notebook.status_printer(None, 42, {"total":42})
    value, max_value = 42, 42
    assert progress.max == max_value
    assert progress.value == value
    progress.value = max_value
    progress.bar_style = "sucess"
    assert progress.value == max_value


# Generated at 2022-06-26 09:53:12.703408
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    try:
        tqdm_notebook_0.clear()
    except NotImplementedError:
        pass
    else:
        raise Exception('ExpectedNotImplementedError')
        pass


# Generated at 2022-06-26 09:53:14.756476
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    assert False, "Test not implemented"


# Generated at 2022-06-26 09:53:18.089864
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Unit test for constructor of class tqdm_notebook
    test_case_0()

if __name__ == '__main__':
    test_tqdm_notebook()
    tqdm_notebook().close()

# Generated at 2022-06-26 09:53:31.511710
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    assert not tqdm_notebook(total=10).reset().n, "error in tqdm_notebook reset"

##############################################################################
# CONSOLE VERSION (also used in the Jupyter Notebook version)
##############################################################################

if __name__ == "__main__":
    # Test button
    def test():
        """Main function"""
        from tqdm import trange, tqdm
        from time import sleep, time
        from sys import stderr

        # Pre-test cleanup
        try:
            from IPython import get_ipython
            get_ipython().magic('clear')
        except ImportError:
            pass


# Generated at 2022-06-26 09:53:38.932336
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    tqdm_notebook_1.update(1)
    try:
        tqdm_notebook_1.update(1)
        raise ValueError
    except Exception as e:
        # ensure the exception is of the right type
        assert(isinstance(e, ValueError))
    tqdm_notebook_1.close()


# Generated at 2022-06-26 09:53:41.545119
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook()
    t.clear()

# Generated at 2022-06-26 09:53:44.797240
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:53:48.495260
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    import time
    import numpy as np
    tqdm_notebook_1 = tqdm_notebook(
        total=0, ncols=80, desc="Epoch 1", leave=True,
        unit='it', unit_scale=True)
    for i in range(10000):
        tqdm_notebook_1.update(1)
    # assert tqdm_notebook_1.n==10000


# Generated at 2022-06-26 09:53:51.569914
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()
