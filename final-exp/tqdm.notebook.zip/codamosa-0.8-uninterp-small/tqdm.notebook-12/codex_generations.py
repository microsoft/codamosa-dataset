

# Generated at 2022-06-26 09:46:42.579831
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.tnrange(5,5)
    tqdm_notebook_0.update(1)

# Generated at 2022-06-26 09:46:44.290774
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    assert tqdm_notebook.clear() != 0

# Generated at 2022-06-26 09:46:47.029232
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:46:49.204415
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook()


# Generated at 2022-06-26 09:47:00.476519
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()

if __name__ == '__main__' and __package__ is None:
    import os
    import sys
    path = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    sys.path.insert(0, path)
    ipy = int(os.environ.get('IPYTHON_VERSION','0'))
    if ipy == 0:
        import tqdm
        tqdm.test()
else:  # pragma: no cover
    from ._tqdm_test import _test as test
    from ._tqdm_test import _main as main

# Generated at 2022-06-26 09:47:11.706728
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    import sys
    total = 100
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook(file=sys.stderr)
    tqdm_notebook_2 = tqdm_notebook(total=total)
    tqdm_notebook_3 = tqdm_notebook(file=sys.stderr, total=total)
    tqdm_notebook_4 = tqdm_notebook(disable=False)
    tqdm_notebook_5 = tqdm_notebook(file=sys.stderr, disable=False)
    tqdm_notebook_6 = tqdm_notebook(total=total, disable=False)
    tqdm_notebook_7 = tqdm_notebook

# Generated at 2022-06-26 09:47:17.769862
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_close_0 = tqdm_notebook()
    tqdm_notebook_close_0 = tqdm_notebook()
    tqdm_notebook_close_0.close()


# Generated at 2022-06-26 09:47:21.755308
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():

    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.container = TqdmHBox()
    tqdm_notebook_0.container.children = [HTML(), IProgress(0, 0), HTML()]

    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:47:29.725539
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    This function is used to test the reset method of tqdm_notebook
    """
    tqdm_notebook_0 = tqdm_notebook('description', 10)
    tqdm_notebook_0.reset(100)
    tqdm_notebook_0.reset(10)
    tqdm_notebook_0.reset()
    tqdm_notebook_0.reset()



# Generated at 2022-06-26 09:47:34.949039
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    n = 10
    pbar = tqdm_notebook(range(n), leave=True)
    for i in range(n):
        pbar.update()
        time.sleep(random.random())


# Generated at 2022-06-26 09:48:01.594828
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t_n = tqdm_notebook(total=10)
    t_n.display(msg='', bar_style='', check_delay=True)
    t_n.reset()
    assert t_n.n == 0


# Generated at 2022-06-26 09:48:13.442379
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook(disable=True)
    assert tqdm_notebook_0.disable == True
    tqdm_notebook_0.reset()
    assert tqdm_notebook_0.n == 0
    tqdm_notebook_0.reset(total=10)
    assert tqdm_notebook_0.total == 10
    assert tqdm_notebook_0.n == 0


if __name__ == '__main__':
    test_tqdm_notebook_reset()

# Generated at 2022-06-26 09:48:24.160433
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # tqdm_notebook is a special case because it redefines __iter__
    # instantiate a tqdm_notebook object
    tqdm_notebook_0 = tqdm_notebook(iterable=[])
    # try to iterate over some_custom_object
    try:
        for elem in iter(tqdm_notebook_0):
            pass
    except:
        pass



# Generated at 2022-06-26 09:48:25.977853
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tn = tqdm_notebook()
    tn.display()


# Generated at 2022-06-26 09:48:29.821185
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    n = 1
    tqdm_notebook_0 = tqdm_notebook()
    return tqdm_notebook_0.update(n)


# Generated at 2022-06-26 09:48:35.191204
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook(disable=False)
    total = 1
    tqdm_notebook_0.reset(1)



# Generated at 2022-06-26 09:48:38.036253
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # initialize update
    tqdm_notebook_0 = tqdm_notebook(3, unit='1 loop')
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:48:50.567415
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    print("\n# Unit test for method __repr__ of class TqdmHBox")
    print("\n## Case 0: no pbar")
    tqdm_h_box_0 = TqdmHBox()
    print("Returned: {}".format(tqdm_h_box_0.__repr__()))
    print("Expected: {}".format(""))
    print("\n## Case 1: pretty")
    tqdm_h_box_1 = TqdmHBox()
    print("Returned: {}".format(tqdm_h_box_1.__repr__(True)))
    print("Expected: {}".format(""))


# Generated at 2022-06-26 09:48:54.228437
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_n_0 = tqdm_notebook(range(10))


# Generated at 2022-06-26 09:49:03.591022
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    test_case_0()


if __name__ == "__main__":
    # execute only if run as a script
    import matplotlib.ticker

    def test_case_1():
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.__init__()
        tqdm_notebook_0.update(1)
        tqdm_notebook_0.update()
        tqdm_notebook_0.reset(1)
        tqdm_notebook_0.reset()
        tqdm_notebook_0.set_description('0')
        tqdm_notebook_0.set_description(0)

    def test_case_2():
        tqdm_notebook_0 = tqdm_notebook()
       

# Generated at 2022-06-26 09:49:46.309872
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    # Attach the module to the test case
    tc = globals()['test_case_0']
    # Check the class name of the method close
    assert tc.tqdm_h_box_0.__class__.__name__ == 'TqdmHBox'
    # Assert the existance of class attribute 'pbar' as a proxy
    assert hasattr(tc.tqdm_h_box_0, 'pbar')
    assert type(tc.tqdm_h_box_0.pbar) == 'weakproxy'
    # Check the repr method of the class TqdmHBox
    assert tc.tqdm_h_box_0.__repr__() == '<tqdm._tqdm_notebook._TqdmHBox object at 0x7f753759a908>'


# Generated at 2022-06-26 09:49:51.929711
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    #Init a tqdm_notebook object
    _widget_0 = tqdm_notebook()
    for t in _widget_0:
        pass


# Generated at 2022-06-26 09:49:54.092082
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tqdm_notebook()
    t.clear()


# Generated at 2022-06-26 09:49:58.140833
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Unit test for method reset of class tqdm_notebook
    """
    try:
        tqdm_notebook_bar = tqdm_notebook(total=200)
        tqdm_notebook_bar.reset(total=100)
    except Exception as e:
        print("Error Occured is ", str(e))
        raise e


# Generated at 2022-06-26 09:50:02.425804
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tn_0 = tqdm_notebook(disable=False)
    tn_0.close()


# Generated at 2022-06-26 09:50:13.072546
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    try:
        from IPython.display import display, clear_output  # NOQA: F401
    except ImportError:
        display = clear_output = None
        print('\nSKIPPING test_tqdm_notebook_reset '
              '(could not import display/clear_output)')
        return

    # Setup
    display(tqdm(total=20), file=sys.stdout)
    tqdm.reset()

    # Run
    with tqdm(total=20) as pbar:
        for i in range(20):
            pbar.update()
    # Check
    assert pbar.n == 20
    assert pbar.container.visible

    # Run
    with tqdm(total=20) as pbar:
        for i in range(10):
            pbar.update()


# Generated at 2022-06-26 09:50:18.393244
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    global test_tqdm_notebook
    test_tqdm_notebook = tqdm_notebook()
    test_tqdm_notebook.display()

if __name__ == "__main__":
    # test_tqdm_notebook_display()
    test_case_0()

# Generated at 2022-06-26 09:50:21.584585
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_obj = tqdm_notebook()
    tqdm_notebook_obj.close()


# Generated at 2022-06-26 09:50:32.774423
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for _ in tqdm_notebook(range(10)):
        pass
    assert not tqdm_notebook(range(10)).reset().displayed
    assert not tqdm_notebook(range(10)).reset(total=float("inf")).displayed
    # Test optional 'disable' keyword argument to constructor
    assert not tqdm_notebook(range(10), disable=True).reset().displayed
    assert not tqdm_notebook(range(10), disable=True).reset(total=float("inf")).displayed
    # Test optional 'disable' keyword argument to update()
    tn = tqdm_notebook(range(10), disable=True)
    tn.update()
    tn.reset()
    assert not tn.displayed
    tn.reset(total=float("inf"))


# Generated at 2022-06-26 09:50:36.004864
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(total=5, leave=True)
    for i in range(5):
        bar.update(1)
        sleep(0.5)
    bar.reset()
    for i in range(5):
        bar.update(1)
        sleep(0.5)


# Generated at 2022-06-26 09:51:06.239921
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:51:08.938978
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_n_0 = tqdm_notebook.status_printer(None)


# Generated at 2022-06-26 09:51:14.160900
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=100) as pbar:
        for i in range(100):
            pbar.update(1)


# Generated at 2022-06-26 09:51:24.356364
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        from ipywidgets import HTML, FloatProgress
        from ipywidgets import HBox as ContainerWidget
    except ImportError:
        from IPython.html.widgets import HTML
        from IPython.html.widgets import ContainerWidget
        from IPython.html.widgets import FloatProgressWidget as FloatProgress

    tqdm_nb = tqdm_notebook(disable = False)
    tqdm_nb.container = TqdmHBox()
    tqdm_nb.container.pbar = proxy(tqdm_nb)
    tqdm_nb.container.children = (HTML(), FloatProgress(), HTML()) # ltext, pbar, rtext
    tqdm_nb.container.children[1].bar_style = ''    # pbar.bar_style
    tqdm_nb.container.children

# Generated at 2022-06-26 09:51:35.631672
# Unit test for method __iter__ of class tqdm_notebook

# Generated at 2022-06-26 09:51:39.303464
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    test_tqdm_notebook = tqdm_notebook()
    test_tqdm_notebook.display()


# Generated at 2022-06-26 09:51:41.903454
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    bar = tqdm_notebook(total=1000)
    bar.reset()
    assert bar.total == 0


# Generated at 2022-06-26 09:51:55.451996
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialize variable
    total = 10
    # Create tqdm object
    tqdm_notebook_1 = tqdm_notebook(total=total)
    fp = sys.stdout
    # Add 2 to value
    tqdm_notebook_1.update(2)
    # Compare the value with 2
    assert 2 == tqdm_notebook_1.n, 'Value of tqdm_notebook_1 is incorrect'
    assert 0 == tqdm_notebook_1._last_print_n, 'Value of tqdm_notebook_1._last_print_n is incorrect'
    # Add 5 to value
    tqdm_notebook_1.update(5)
    # Compare the value with 7

# Generated at 2022-06-26 09:51:57.644283
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with warnings.catch_warnings():
        warnings.filterwarnings('ignore')
        for _ in tqdm_notebook(range(1), total=1):
            pass



# Generated at 2022-06-26 09:52:02.232618
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.status_printer(file = sys.stdout)


# Generated at 2022-06-26 09:52:54.984305
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    print("\nTest method status_printer of class tqdm_notebook\n")
    tqdm_notebook_container = tqdm_notebook.status_printer(sys.stdout, total=50, desc='testing', ncols=50)

    if (tqdm_notebook_container.children[0].value == 'testing' and 
        len(tqdm_notebook_container.children) == 3 and 
        tqdm_notebook_container.layout.width == '50px'):
        print("Successfully tested method status_printer of class tqdm_notebook")
    else:
        print("Method status_printer of class tqdm_notebook has failed.")


# Generated at 2022-06-26 09:53:06.311161
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():

    tqdm_notebook_0 = tqdm_notebook(pandas.read_csv(io.StringIO(u'0,0\n1,1')))
    # Wait for a second
    time.sleep(1)
    # Display bar
    tqdm_notebook_0.display()
    # Wait for a second
    time.sleep(1)
    # Close bar
    tqdm_notebook_0.close()

if __name__ == '__main__':
    import cProfile
    cProfile.run('test_tqdm_notebook()')

# Generated at 2022-06-26 09:53:10.530177
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    object = tqdm_notebook('test_tqdm_notebook_reset')
    object.reset(total=10)
    assert object.total == 10


# Generated at 2022-06-26 09:53:15.186752
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm(total = int(3))
    for i in tqdm_notebook_0:
        pass


# Generated at 2022-06-26 09:53:21.587302
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    n_iter = None
    total = 10000
    unit = 'it'
    desc = None
    leave = False
    file = sys.stderr
    ncols = None
    mininterval = 0.1
    maxinterval = 10.0
    miniters = None
    ascii = None
    disable = False
    unit_scale = False
    dynamic_ncols = False
    smoothing = 0.3
    bar_format = '{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}]'
    initial = 0
    pos = None
    postfix = None
    unit_divisor = 1000
    gui = True
    Write = not disable and file is not sys.stderr
    inplace = True

# Generated at 2022-06-26 09:53:24.512826
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    a = tqdm_notebook(range(10))
    a.__iter__()
    a.close()


# Generated at 2022-06-26 09:53:28.703788
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_h_box_0 = TqdmHBox()
    tqdm_h_box_0.pbar = None
    sub_str = '<HBox'
    str_res = tqdm_h_box_0.__repr__()
    assert sub_str in str_res


# Generated at 2022-06-26 09:53:34.246202
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Input
    _ = None
    total = 10
    desc = ""
    ncols = "100%"
    file_kwarg = sys.stderr
    gui = True
    disable = False
    # colour = None
    display_here = True
    n = 10
    msg = None
    close = False
    bar_style = None
    check_delay = True
    pretty = False
    pbar = IProgress(min=0, max=total)
    ltext = HTML()
    rtext = HTML()
    container = TqdmHBox(children=[ltext, pbar, rtext])

# Generated at 2022-06-26 09:53:39.917160
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    gui_kwargs_0 = {}
    gui_kwargs_0['gui'] = True
    gui_kwargs_0['disable'] = False
    tqdm_notebook_0 = tqdm_notebook('10', '10 s', **gui_kwargs_0)
    total_1 = 17
    tqdm_notebook_0.reset(total=total_1)
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:53:49.154145
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Test case 1
    tqdm_notebook_1 = tqdm_notebook(disable=True, ncols=None)
    tqdm_notebook_1.update(n=1)
    n = 0
    while n < 3:
        try:
            tqdm_notebook_1.update(1)
            n += 1
        except:
            print('failed for reason:')
            raise
    tqdm_notebook_1.update(n=2)

    # Test case 2
    tqdm_notebook_2 = tqdm_notebook(disable=False, ncols=None)
    tqdm_notebook_2.update(n=1)
    n = 0

# Generated at 2022-06-26 09:54:51.954843
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    try:
        tqdm_notebook_0.update()
    except:
        pass
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.total = 1
    tqdm_notebook_1.n = 0
    try:
        tqdm_notebook_1.update()
    except:
        pass
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.total = 1
    tqdm_notebook_2.n = 1
    try:
        tqdm_notebook_2.update()
    except:
        pass

# Generated at 2022-06-26 09:54:59.611689
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup initial progress bar
    t = tqdm_notebook(total=10)
    for i in range(10):
        t.update()
    # Check if the progress bar is closed after reset
    t.reset()
    assert (t.n == 0)
    assert (t.last_print_n == t.n == 0)
    # Check if the progress bar is still closed after reset with total argument
    t.reset(total=5)
    assert (t.n == 0)
    assert (t.last_print_n == t.n == 0)



# Generated at 2022-06-26 09:55:04.647290
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(iterable=[1, 2, 3])
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:55:08.837820
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        from_iter_0 = iter(tqdm_notebook(list(range(10))))
        for_1 = True
        for for_2 in from_iter_0:
            for_1 = for_2
    except:
        for_1 = False
    return for_1


# Generated at 2022-06-26 09:55:17.438818
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """Unit test for method reset of class tqdm_notebook"""
    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.reset(total = 10)
    except Exception as e:
        # Check that exception is not raised
        print(e)
        assert False



# Generated at 2022-06-26 09:55:21.333745
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in tqdm_notebook(range(10)):
        pass


    # Additionnal tests

    # Raises an error because of missing total
    with tqdm_notebook(total=None, desc='foo') as t:
        pass
    t.close()



# Generated at 2022-06-26 09:55:34.124472
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_np_0 = tqdm_notebook("Test")
    ltext_0=HTML()
    pbar_0=IProgress(min=0, max=1000)
    rtext_0=HTML()
    container_0=TqdmHBox(children=[ltext_0,pbar_0,rtext_0])
    tqdm_np_0.container = container_0
    tqdm_np_0.displayed = True
    tqdm_np_0.ncols = 3
    tqdm_np_0.display(msg="Hello",pos=500,close=False,bar_style="success",check_delay=True)
    tqdm_np_1 = tqdm_notebook("Test")
    ltext_1=HTML()
    pbar_1=I

# Generated at 2022-06-26 09:55:42.001580
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialize tqdm_notebook object
    tqdm_notebook_obj_1 = tqdm_notebook(5,desc='Some description', position=0)

    # Call method tqdm_notebook.update of tqdm_notebook object
    # with argument n=2
    tqdm_notebook_obj_1.update(2)


# Generated at 2022-06-26 09:55:46.613607
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    a = tqdm_notebook(range(100))
    for i in range(100):
        a.update(1)
    a.close()


# Generated at 2022-06-26 09:55:53.354958
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Returns `self` iterator to avoid `TypeError: 'tqdm_notebook' object is not
        iterable` when accidentally writing `for x in t`.
    """
    assert (isinstance(iter(tqdm_notebook()), tqdm_notebook))
