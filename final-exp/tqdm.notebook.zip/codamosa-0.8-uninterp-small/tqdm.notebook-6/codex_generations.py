

# Generated at 2022-06-26 09:46:37.648054
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test case with positional arguments
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display(msg='', pos=None,
        # additional signals
        close=False, bar_style=None, check_delay=True)


# Generated at 2022-06-26 09:46:41.875247
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    unit_test_tqdm_notebook_status_printer = tqdm_notebook.status_printer()


# Generated at 2022-06-26 09:46:49.809421
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    num_0 = {}
    num_1 = {}
    num_1['total'] = 12
    total_0 = num_1['total']
    pos_0 = {}
    pos_1 = {}
    pos_0['n'] = 3
    n_0 = pos_0['n']
    close_0 = {}
    close_0['close'] = True
    close_1 = close_0['close']
    bar_style_0 = {}
    bar_style_0['bar_style'] = None
    bar_style_1 = bar_style_0['bar_style']
    check_delay_0 = {}
    check_delay_0['check_delay'] = False
    check_delay_1 = check_delay_0['check_delay']

    tqdm_notebook_1 = tqdm_notebook

# Generated at 2022-06-26 09:46:50.529071
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    assert True

# Unit test of method display of class tqdm_notebook

# Generated at 2022-06-26 09:46:56.978759
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    dict_0 = {}
    tqdm_notebook_0 = tqdm_notebook(**dict_0)
    TqdmHBox_0 = TqdmHBox(**dict_0)
    TqdmHBox_0._repr_json_()


# Generated at 2022-06-26 09:47:10.166895
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from io import StringIO
    import sys
    import ipywidgets
    from IPython.display import display
    class fake_file:
        def write(self, s):
            print(s)
        def flush(self):
            0
    sys.stderr = StringIO()
    sys.stdout = StringIO()
    tqdm_notebook_1 = tqdm_notebook(**{})
    tqdm_notebook_1.gui = True
    tqdm_notebook_1.disable = False
    assert isinstance(tqdm_notebook_1.status_printer(fake_file(), 0, "", None), ipywidgets.widgets.widget.Widget)

# Generated at 2022-06-26 09:47:17.256784
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    print("testing tqdm_notebook update")

    range_1 = range(1000)
    tqdm_notebook_1 = tqdm_notebook(range_1)
    for i in range_1:
        tqdm_notebook_1.update()



# Generated at 2022-06-26 09:47:20.972427
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    dict_0 = {}
    tqdm_notebook_0 = tqdm_notebook(**dict_0)
    dict_1 = {}
    dict_1['disable'] = True
    tqdm_notebook_0.update(**dict_1)


# Generated at 2022-06-26 09:47:32.427594
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # NOTES:
    # - This test case only calls the display function but does not check the
    #   results from the function
    # - This test case includes multiple test cases
    #
    # NOTES:
    # - The default value of "msg" is None (e.g., msg=None)
    # - The default value of "pos" is None (e.g., pos=None)
    #
    # Calling the display function with missing parameter
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(1.5, 2.5)
    tqdm_notebook_0.display(msg=1.5, ncols=2.5)

# Generated at 2022-06-26 09:47:39.403903
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    dict_0 = {}
    tqdm_notebook_0 = tqdm_notebook(**dict_0)
    try:
        for i in range(3):
            tqdm_notebook_0.update()
    except:
        tqdm_notebook_0._instances.clear()
        raise

    return


# Generated at 2022-06-26 09:47:57.484419
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm import tqdm
    with tqdm(total=10) as t:
        for i in range(10):
            t.update()


# Generated at 2022-06-26 09:48:04.012893
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test case with tqdm_notebook

    # Initalize class
    tqdm_notebook_0 = tqdm_notebook()

    # Call method reset with argument total
    tqdm_notebook_0.reset(total=0)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_reset()

# Generated at 2022-06-26 09:48:09.982081
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Check that the update method works
    tqdm_n_0 = tqdm_notebook(total=100, disable=False, leave=False)
    var_1 = tqdm_n_0.update(n=1)


# Generated at 2022-06-26 09:48:12.732727
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    var_1 = tqdm_notebook(total=3)
    for var_2 in var_1:
        pass


# Generated at 2022-06-26 09:48:16.733029
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    var_1 = tqdm_notebook(1)


# Generated at 2022-06-26 09:48:20.750528
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:48:23.373789
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    var_1 = tqdm_notebook()
    var_1.clear()


# Generated at 2022-06-26 09:48:25.894407
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    var_15 = tqdm_notebook(total=100)
    var_16 = var_15.reset()


# Generated at 2022-06-26 09:48:28.102784
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    for i in range(1, 10):
        print(i)



# Generated at 2022-06-26 09:48:32.398872
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    with tqdm_notebook(total=100) as pbar:  # pylint: disable=unused-variable
        for i in range(50):
            pbar.update(2)


# Generated at 2022-06-26 09:48:48.521211
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    args = [('',)]
    tqdm_notebook_0.clear(*args)

# Generated at 2022-06-26 09:48:59.721084
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test basic usage
    tqdm_notebook_1 = tqdm_notebook(desc="Test tqdm_notebook")
    tqdm_notebook_1.display()

    # Test msg parameter
    tqdm_notebook_2 = tqdm_notebook(desc="Test msg parameter")
    tqdm_notebook_2.display(msg="This is a test message")

    # Test bar_style parameter
    tqdm_notebook_3 = tqdm_notebook(desc="Test bar_style parameter")
    tqdm_notebook_3.display(bar_style='success')



# Generated at 2022-06-26 09:49:03.124244
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    bar = tqdm_notebook_0(total=1)
    bar.close()
    assert bar.disable



# Generated at 2022-06-26 09:49:12.691784
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test no total
    try:
        status_printer = tqdm_notebook.status_printer(None)
    except ImportError:
        pass
    # Test with total
    tqdm_notebook.status_printer(None, 100, 'Test')

if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_status_printer()

# Generated at 2022-06-26 09:49:25.328395
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """Test the constructor."""
    tqdm_notebook_0 = tqdm_notebook()
    assert tqdm_notebook_0.disable
    # Test with no args
    tqdm_notebook_1 = tqdm_notebook(disable=False)
    assert not tqdm_notebook_1.disable
    assert tqdm_notebook_1.dynamic_ncols
    assert tqdm_notebook_1.unit_scale is True
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.total is None
    assert tqdm_notebook_1.last_print_n == 0
    assert tqdm_notebook_1.unit == 'it'
    assert tqdm_notebook_1.unit_scale is True

# Generated at 2022-06-26 09:49:27.625383
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    try:
        with tqdm_notebook(total=10, miniters=0, mininterval=0, file=sys.stdout) as t:
            pass
    except (ImportError):
        print("tqdm_notebook requires ipywidgets, please install it")


# Generated at 2022-06-26 09:49:32.028410
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:49:34.935133
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    def iter_func():
        yield 0
    # call the method
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:49:40.805141
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    result_0 = tqdm_notebook_0.status_printer(total=100)
    assert isinstance(result_0, TqdmHBox)



# Generated at 2022-06-26 09:49:47.158854
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # create an instance of tqdm_notebook
    inst_tqdm_notebook = tqdm_notebook()
    result = inst_tqdm_notebook.status_printer(file=sys.stdout)
    # Note: because the progress bar is inside a HBox, in a notebook
    # the representation of the bar is displayed as a dictionary.
    # If the test is run manually, the representation is displayed
    # as an actual progress bar.
    # In both cases, the HBox is returned and the test is successful.
    assert isinstance(result, TqdmHBox)



# Generated at 2022-06-26 09:50:03.395527
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    TqdmHBox_0 = TqdmHBox()
    assert TqdmHBox_0.__repr__() == "<__main__.TqdmHBox object at 0x102109cf8>"



# Generated at 2022-06-26 09:50:08.945138
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Init with n=4
    tqdm_notebook_1 = tqdm_notebook(4)
    assert tqdm_notebook_1.n == 4

    # Reset with total=5
    tqdm_notebook_1.reset(5)
    assert tqdm_notebook_1.n == 0
    assert tqdm_notebook_1.total == 5

# Generated at 2022-06-26 09:50:13.539547
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    import time
    print('tqdm_notebook_close_0')
    bar = tqdm_notebook(range(16), 'Testing close', ncols=70)
    time.sleep(0.1)
    bar.close()

test_tqdm_notebook_close()

# Generated at 2022-06-26 09:50:16.916233
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:50:20.111489
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_1 = tqdm_notebook(total=10, desc='test_tqdm_notebook_close')
    tqdm_notebook_1.close()


if __name__ == "__main__":
    test_tqdm_notebook_close()

# Generated at 2022-06-26 09:50:31.627740
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    import sys
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.clear()
    assert tqdm_notebook_2._instances is None, tqdm_notebook_2._instances
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.clear(nolock=True)
    assert tqdm_notebook_2._instances is None, tqdm_notebook_2._instances
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.clear(nolock=True, lock_args=(10,))
    assert tqdm_notebook_2._instances is None, tqdm_notebook_2._instances

# Generated at 2022-06-26 09:50:34.035876
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    pbar = tqdm_notebook()
    pbar.close()
    assert pbar.total != None
    assert pbar.ncols != None
    assert pbar.__getstate__() != None


# Generated at 2022-06-26 09:50:45.515750
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initialize tqdm instance
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.container = TqdmHBox()
    tqdm_notebook_0.ncols = '100%'
    tqdm_notebook_0.container.children = [tqdm_notebook_0.container.ltext, tqdm_notebook_0.container.pbar, tqdm_notebook_0.container.rtext]
    tqdm_notebook_0.container.ltext = HTML()
    tqdm_notebook_0.container.rtext = HTML()
    tqdm_notebook_0.container.pbar = IProgress()
    tqdm_notebook_0.container.pbar.min = 0
    t

# Generated at 2022-06-26 09:50:49.161800
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    bar = tqdm_notebook(total=4)
    for i in range(4):
        bar.update()
    bar.display('Hello world')



# Generated at 2022-06-26 09:51:01.773918
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm import tnrange

    t = tnrange(10)
    t.display()
    t.display(close=True)
    t.display(pos=9)
    t.close()
    t = tnrange(10)
    t.display()
    t.display(bar_style='success')
    t.close()
    t = tnrange(10)
    t.display()
    t.display(bar_style='danger')
    t.close()
    t = tnrange(10)
    t.display()
    t.display(close=False, bar_style='success')
    t.display(bar_style='danger', check_delay=False)  # noqa
    t.display(close=False, bar_style='danger')  # noqa

# Generated at 2022-06-26 09:51:36.095430
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # created the object
    tqdm_notebook_2 = tqdm_notebook()
    # checks if bar_style is an attribute
    tqdm_notebook_2.bar_style = "info"
    # checks if bar_style is an attribute
    tqdm_notebook_2.bar_style = "success"
    # checks if bar_style is an attribute
    tqdm_notebook_2.bar_style = "danger"
    # checks if n is an attribute
    tqdm_notebook_2.n = 1
    # checks if format_dict is an attribute

# Generated at 2022-06-26 09:51:40.453915
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.contrib.tests._utils import _test_reset
    reset_tqdm_notebook = _test_reset(tqdm_notebook())



# Generated at 2022-06-26 09:51:44.352680
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    assert hasattr(tqdm_notebook_0, '__iter__')
    assert hasattr(tqdm_notebook_0, '__next__')



# Generated at 2022-06-26 09:51:51.523412
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    if IPY == 0:
        raise unittest.SkipTest("No IPython/Jupyter found")
    tn = tqdm(total=100, desc='test')
    assert len(tn.container.children) == 3
    tn.close()
    del tn


# Generated at 2022-06-26 09:51:59.320312
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # test_case_0
    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_0.display(msg='test msg')
    except Exception as error:
        raise error

    # test_case_1
    try:
        tqdm_notebook_1 = tqdm_notebook()
        tqdm_notebook_1.display(msg='', pos=10)
    except Exception as error:
        raise error

    # test_case_2
    try:
        tqdm_notebook_2 = tqdm_notebook()
        tqdm_notebook_2.display(msg='test msg', close=False, bar_style=None, check_delay=True)
    except Exception as error:
        raise error

    # test_

# Generated at 2022-06-26 09:52:09.216866
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Testcase 1:
    tqdm_notebook_1 = tqdm_notebook()
    assert tqdm_notebook_1.display() == None

    # Testcase 2:
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.close = lambda: "/c/t_q_dm"
    tqdm_notebook_2.display() # Cannot be caught
    tqdm_notebook_2.display(bar_style="test_case")
    tqdm_notebook_2.display(close=True, bar_style="test_case")
    tqdm_notebook_2.display(close=True)

    # Testcase 3:
    tqdm_notebook_3 = tqdm_notebook()
    tqdm

# Generated at 2022-06-26 09:52:15.149943
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()
    assert True


# Generated at 2022-06-26 09:52:18.611261
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset(3) # Test with valid argument
    tqdm_notebook_0.reset(None) # Test with optional argument



# Generated at 2022-06-26 09:52:28.147496
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.n = 5
    tqdm_notebook_0.total = 10
    tqdm_notebook_0.desc = "test_tqdm_notebook_display"
    tqdm_notebook_0.display(msg = None, pos = None, close = False, bar_style = None, check_delay = True)


# Generated at 2022-06-26 09:52:42.499839
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()
    tqdm_notebook_1.display(close=True)
    tqdm_notebook_1.display(msg="test")
    tqdm_notebook_1.display(msg='', close=True)
    tqdm_notebook_1.display(msg=1)
    tqdm_notebook_1.display(pos=0)
    tqdm_notebook_1.display(bar_style='test')
    tqdm_notebook_1.display(check_delay=False)


# Generated at 2022-06-26 09:54:07.188510
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from nose.tools import raises
    from tqdm import TqdmTypeError, TqdmKeyError
    for float_type in [float, lambda: .5]:
        for total_magnitude in [1, 1e15]:
            for unit_scale_magnitude in [1, 1e15]:
                yield test_case_0,
                with raises(TqdmTypeError):
                    tqdm_notebook(None)
                with raises(TqdmTypeError):
                    tqdm_notebook([])
                with raises(TqdmTypeError):
                    tqdm_notebook(tqdm_notebook_0)
                with raises(TqdmTypeError):
                    tqdm_notebook(['a', 'b', 'c'], desc='d')

# Generated at 2022-06-26 09:54:12.134258
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset(20)
    assert tqdm_notebook_1.total == 20


# Generated at 2022-06-26 09:54:18.910075
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0.total = 1
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0.total = 2
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0.total = 3
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0.total = 4
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0.total = 5
    for i in tqdm_notebook_0:
        pass
    tqdm_notebook_0

# Generated at 2022-06-26 09:54:29.609401
# Unit test for constructor of class tqdm_notebook

# Generated at 2022-06-26 09:54:40.498330
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(close=None)
    tqdm_notebook_0.display(msg=None)
    tqdm_notebook_0.display()
    tqdm_notebook_0.display(close=None)
    tqdm_notebook_0.display(msg=None, close=None)
    tqdm_notebook_0.display(msg=None, pos=None, close=None)
    tqdm_notebook_0.display(msg=None)
    tqdm_notebook_0.display(close=None)
    tqdm_notebook_0.display(msg=None, pos=None, close=None, bar_style=None, check_delay=True)


# Generated at 2022-06-26 09:54:48.734737
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # test for normal case for method display (tqdm_notebook)
    test_msg = 'test message'
    test_pos = 5
    test_close = True
    test_bar_style = 'info'
    test_check_delay = False
    test_case = tqdm_notebook()
    test_case.display(test_msg, test_pos, test_close, test_bar_style, test_check_delay)


# Generated at 2022-06-26 09:54:58.454654
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test for init of tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    assert tqdm_notebook_0.disable == False
    assert tqdm_notebook_0.gui == True
    assert tqdm_notebook_0.total == None
    assert tqdm_notebook_0.unit == 'it'
    assert tqdm_notebook_0.unit_scale == False
    assert tqdm_notebook_0.leave == True
    assert tqdm_notebook_0.desc == None
    assert tqdm_notebook_0.mininterval == 0.1
    assert tqdm_notebook_0.miniters == None
    assert tqdm_notebook_0.dynamic_ncols == False
    assert t

# Generated at 2022-06-26 09:55:08.638674
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(close=True)
    TqdmHBox_0 = TqdmHBox()
    TqdmHBox_0.pbar = tqdm_notebook_0
    TqdmHBox___repr___0 = TqdmHBox_0.__repr__()
    TqdmHBox___repr___1 = TqdmHBox_0.__repr__(True)


# Generated at 2022-06-26 09:55:13.660413
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """
    Unit test for method __iter__ of class tqdm_notebook
    """
    tqdm_notebook_1 = tqdm_notebook()


# Generated at 2022-06-26 09:55:22.462797
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook(gui=True)
    fp_0 = sys.stdout  # avoid the red block in IPython
    total_0 = None # replace with IPython progress bar display (with correct total)
    desc_0 = None # replace with IPython progress bar display (with correct total)
    ncols_0 = None # replace with IPython progress bar display (with correct total)
    status_printer_0 = tqdm_notebook(gui=True).status_printer(fp_0, total_0, desc_0, ncols_0)
    return status_printer_0
