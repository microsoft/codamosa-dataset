

# Generated at 2022-06-26 09:46:32.666218
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Assert that update works ok
    for i in trange(10):
        pass


# Generated at 2022-06-26 09:46:41.760136
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    try:
        tqdm_notebook_0 = tqdm_notebook()
        tqdm_notebook_1 = tqdm_notebook()
        tqdm_notebook_1.__iter__()
        tqdm_notebook_0.__iter__()
    except Exception:
        print('Exception caught in file tqdm_notebook.py for function test_tqdm_notebook___iter__')
        raise


# Generated at 2022-06-26 09:46:45.046289
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    ncols = 100
    total = 10
    desc = 'desc'
    tqdm_notebook_0 = tqdm_notebook.status_printer(None, total, desc, ncols)


# Generated at 2022-06-26 09:46:49.677260
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    #tqdm_notebook_0 = tqdm_notebook()
    assert 1 == 1
    print('All tests passed successfully')


# Generated at 2022-06-26 09:46:56.519946
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Initialize tqdm_notebook instance
    test_tqdm_notebook = tqdm_notebook(iterable=range(10))
    # Iterate using the method __iter__
    assert list(test_tqdm_notebook.__iter__()) == list(range(10))


# Generated at 2022-06-26 09:47:00.351381
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook(3, 0.5)
    tqdm_notebook_0.reset(2)


# Generated at 2022-06-26 09:47:01.918649
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    test_case_0()


# Generated at 2022-06-26 09:47:12.253320
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Test basic constructor of class tqdm_notebook

    Test passes if:
        Calling constructor with valid arguments does not raise any errors
        Calling constructor with invalid arguments does raise TypeError
    """
    tqdm_notebook_0 = tqdm_notebook(10)
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_2 = tqdm_notebook(10, disable=True)
    tqdm_notebook_3 = tqdm_notebook(total=10)
    tqdm_notebook_4 = tqdm_notebook(10, leave=True)
    tqdm_notebook_5 = tqdm_notebook(10, disable=True, leave=True)
    tqdm_notebook_6 = tqdm_note

# Generated at 2022-06-26 09:47:16.304197
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.close()


# Generated at 2022-06-26 09:47:17.720910
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()


# Generated at 2022-06-26 09:47:36.341476
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.status_printer('file', 'total', 'desc', 'ncols')


# Generated at 2022-06-26 09:47:37.827153
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    pass


# Generated at 2022-06-26 09:47:40.149716
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for n in tqdm_notebook(range(10)):
        assert True
        break
    assert True


# Generated at 2022-06-26 09:47:43.195693
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=100) as t:
        for i in range(100):
            t.update()
            assert t.n == i + 1
    t.reset(total=200)
    assert t.n == 0
    for i in range(200):
        t.update()
        assert t.n == i + 1

# Generated at 2022-06-26 09:47:47.431401
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from nose.tools import assert_equal
    tqdm_notebook_1 = tqdm_notebook()
    assert tqdm_notebook_1.display() is None


# Generated at 2022-06-26 09:47:52.379638
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    t0 = tqdm_notebook(total = 10)
    t0.container.children[0].value = "desc"
    t0.container.children[2].value = "desc"
    T0 = TqdmHBox(children=[HTML(),IProgress(min=0, max=10),HTML()])
    T0.pbar = t0
    try:
        repr(T0)
    except NotImplementedError:
        assert True
    else:
        assert False


# Generated at 2022-06-26 09:48:05.382199
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    """
    input:
        - msg = "test"
        - pos = 123
        - close = True
        - bar_style = "danger"
        - check_delay = True
    output:
        - pbar.value = 123
        - ltext.value = "test"
        - rtext.value = ""
        - pbar.bar_style = "danger"
        - self.container.close()
    """
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.container = TqdmHBox()
    ltext = HTML()
    pbar = IProgress()
    rtext = HTML()
    tqdm_notebook_1.container.children = [ltext, pbar, rtext]

# Generated at 2022-06-26 09:48:06.819853
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:48:12.860697
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_1 = tqdm_notebook(total=10)
    try:
        tqdm_notebook_1.update(3)
        tqdm_notebook_1.close()
    except Exception as e:
        print("got exception")
        print(e)


# Generated at 2022-06-26 09:48:28.093284
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    #Setup test
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.total = 1
    tqdm_notebook_1.pos = 1
    tqdm_notebook_1.bar_format = '{desc}  {percentage:3.0f}%|{bar}|  {n_fmt}/{total_fmt}'
    tqdm_notebook_1.unit = 'it'
    tqdm_notebook_1.unit_scale = True
    tqdm_notebook_1.leave = False
    tqdm_notebook_1.disable = False
    tqdm_notebook_1.n = 1

    # Perform test
    tqdm_notebook_1.display()

    #Test result
   

# Generated at 2022-06-26 09:48:59.009148
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()
    return



# Generated at 2022-06-26 09:49:11.648033
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    total = 10
    # assert tqdm_notebook_0.total == None,
    # "The value of the attribute total of class tqdm_notebook is not None"
    tqdm_notebook_0.reset(total=total)
    assert tqdm_notebook_0.total == total, "The value of the attribute total of class tqdm_notebook does not match the expected value"

# Generated at 2022-06-26 09:49:14.340887
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    global tqdm_notebook_0
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:49:24.195778
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    for tqdm_notebook_0 in [tqdm_notebook(),tqdm_notebook(range(50))]:
        tqdm_notebook_1 = tqdm_notebook_0
        # Check tqdm_notebook_1 is an instance of tqdm_notebook
        assert(isinstance(tqdm_notebook_1, tqdm_notebook))
        tqdm_notebook_0.close()
        # Check tqdm_notebook_1 is an instance of tqdm_notebook
        assert(isinstance(tqdm_notebook_1, tqdm_notebook))


# Generated at 2022-06-26 09:49:37.180890
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    return
    import re
    from .utils import _range
    from .std import default_colours

    with tqdm(_range(100), desc='', unit='it', smoothing=0,
              bar_format='{l_bar}{bar:10}{r_bar}{bar:-10b}', leave=False) as t:
        for _ in t:
            d = t.format_dict
            pb = re.split(r'\|?<bar/>\|?', d['bar'], 1)
            if pb[1]:
                d['bar'] = pb[0] + colour(pb[1], default_colours['bar'])
            else:
                d['bar'] = ''
            pb = re.split(r'\|?{bar}|?', d['bar_format'], 1)

# Generated at 2022-06-26 09:49:44.966084
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.notebook import tqdm
    import time

    for i in tqdm(range(5)):
        time.sleep(0.2)
    # reset
    tqdm.reset()
    # restart
    for i in tqdm(range(5)):
        time.sleep(0.2)
    # assert that the bar is closed properly
    assert (tqdm.pbar.style.bar_color != 'danger')


# Generated at 2022-06-26 09:49:54.092121
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook(total = 10)
    for i in range(10):
        tqdm_notebook_1.update()
    tqdm_notebook_1.reset(total = 20)
    for i in range(20):
        tqdm_notebook_1.update(i)



# Generated at 2022-06-26 09:50:07.951434
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Unit test for method update of class tqdm_notebook
    """
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    # test for typical use case
    tqdm_notebook_2 = tqdm_notebook(total=10)
    tqdm_notebook_2.update(2)
    # test for exception: as_completed iterator
    try:
        tqdm_notebook_3 = tqdm_notebook()
        tqdm_notebook_3.update(0)
    except Exception as e:
        print(e)

# Generated at 2022-06-26 09:50:18.101773
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(msg=None, pos=None, close=False, bar_style=None, check_delay=True)
    # Default values
    msg = None
    pos = None
    close = False
    bar_style = None
    check_delay = True
    tqdm_notebook_0.display(msg=msg, pos=pos, close=close, bar_style=bar_style, check_delay=check_delay)


# Generated at 2022-06-26 09:50:25.874001
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.total = 10
    tqdm_notebook_1.update()
    assert tqdm_notebook_1.n == 1
    tqdm_notebook_1.update(4)
    assert tqdm_notebook_1.n == 5


# Generated at 2022-06-26 09:52:05.750543
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    with tqdm_notebook(total=100) as pbar:
        for i in range(10):
            pbar.update(10)


# Generated at 2022-06-26 09:52:11.761695
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=5) as pbar:
        for i in range(5):
            pbar.update(1)
    # check if the progressbar's reset method works
    with tqdm_notebook(total=5) as pbar:
        for i in range(5):
            pbar.update(1)
    assert(pbar.n == 5)
    pbar.reset(total=0)
    assert(pbar.n == 0)
    with pytest.raises(ValueError):
        pbar.reset(total=-1)


# Generated at 2022-06-26 09:52:18.772224
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.disable = False
    with std_tqdm() as t:
        for i in tqdm_notebook_0:
            t.update(1)
            if t.n >= 2:
                raise Exception("")


# Generated at 2022-06-26 09:52:31.646354
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    list_0 = list()
    list_0.append(None)
    assert isinstance(tqdm_notebook_0.__iter__(), list_0)
    tqdm_notebook_0 = tqdm_notebook()
    list_1 = list()
    list_1.append(None)
    assert isinstance(tqdm_notebook_0.__iter__(), list_1)
    tqdm_notebook_0 = tqdm_notebook()
    list_2 = list()
    list_2.append(None)
    assert isinstance(tqdm_notebook_0.__iter__(), list_2)
    tqdm_notebook_0 = tqdm_notebook()
    list_3

# Generated at 2022-06-26 09:52:35.896332
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .std import tqdm as std_tqdm
    # Initialize a progress bar
    progress_bar = std_tqdm(total=2)
    assert progress_bar.n != 0
    assert progress_bar.n <= 2
    # Test the method update
    progress_bar.update(1)
    assert progress_bar.n >= 1
    assert progress_bar.n <= 2
    progress_bar.update(1)
    assert progress_bar.n == 2


# Generated at 2022-06-26 09:52:39.849427
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()
    return


# Generated at 2022-06-26 09:52:44.495253
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try: 
        a = tqdm_notebook()
        assert True
    except:
        assert False


# Generated at 2022-06-26 09:52:49.171450
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=5)
    t.pandas(total=5)


# Generated at 2022-06-26 09:53:00.375489
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from IPython.display import HTML
    from ipywidgets import FloatProgress
    from ipywidgets import HBox
    from ipywidgets import HTML
    from tqdm import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook(total=2, desc="This is a Test", leave=False)
    # get the object
    ltext, pbar, rtext = tqdm_notebook_0.container.children
    # set the msg
    msg = "Test"
    # call the display
    tqdm_notebook_0.display(msg=msg)
    # check the msg in the bar
    assert(tqdm_notebook_0.container.children[2].value == msg)
    # check the format of the text

# Generated at 2022-06-26 09:53:03.674434
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook.status_printer(
        None,
        None,
        None,
        None,
    )
    return



# Generated at 2022-06-26 09:55:51.980208
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_ = tqdm_notebook()
    tqdm_notebook_.reset(total = None)

# Generated at 2022-06-26 09:55:57.983381
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Test method reset of class tqdm_notebook
    """
    # create a tqdm_notebook object
    test_tqdm_notebook_reset_obj = tqdm_notebook()

    # check if the total of the tqdm_notebook object is 0
    if test_tqdm_notebook_reset_obj.total != 0:
        return -1

    # reset the tqdm_notebook object
    test_tqdm_notebook_reset_obj.reset()

    # check if the total of the tqdm_notebook object is 0
    if test_tqdm_notebook_reset_obj.total != 0:
        return -1

    return 0


# Generated at 2022-06-26 09:56:08.113505
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(desc = 'test', file = sys.stdout, miniters = 1, mininterval = 0.1)
    T = _range(10)
    for _ in tqdm_notebook_0:
        try:
            T.__iter__()
        except StopIteration as e:
            pass
        except:
            assert False

# Generated at 2022-06-26 09:56:11.573691
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=100) as tbar:
        tbar.reset()
