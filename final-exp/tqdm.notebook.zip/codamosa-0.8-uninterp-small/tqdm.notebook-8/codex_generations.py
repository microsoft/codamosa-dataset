

# Generated at 2022-06-26 09:46:45.102457
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """Tests tqdm_notebook.status_printer"""
    # Call the method
    var_0 = tqdm_notebook.status_printer()


# Generated at 2022-06-26 09:46:54.427140
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from .std import tqdm as std_tqdm
    # instantiate class
    self = std_tqdm()
    # call method
    self.reset()
    # get expected outcome
    expected = None
    # check if expected outcome and outcome match
    assert expected == self, 'Expected: %s, but got: %s'%(expected, self)


# Generated at 2022-06-26 09:46:56.519893
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if __name__ == "__main__":
        test_case_0()

# Generated at 2022-06-26 09:46:57.842186
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    pass


# Generated at 2022-06-26 09:46:59.867084
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    print('Function: update')
    test_case_0()

# Generated at 2022-06-26 09:47:05.416997
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.notebook import tqdm_notebook
    var_0 = tqdm_notebook([1, 2, 3], desc="test")
    for elem in var_0:
        pass


# Generated at 2022-06-26 09:47:07.329508
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    var_0 = tnrange()
    var_0.reset()


# Generated at 2022-06-26 09:47:16.300121
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    from tqdm.notebook import tqdm_notebook as tqdm
    with tqdm(total=10) as pbar:
        for n in range(10):
            pbar.update(1)
            pbar.clear()
            assert pbar.n == n + 1
            pbar.clear()
    assert pbar.n == 10

# Generated at 2022-06-26 09:47:19.170111
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    obj = tnrange(10, desc='tqdm_notebook_reset')
    assert obj.reset(total=1) != None


# Generated at 2022-06-26 09:47:20.758292
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pass


# Generated at 2022-06-26 09:47:40.522287
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test private method display of class tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display(msg=None, pos=None, close=False, bar_style=None, check_delay=True)

# Generated at 2022-06-26 09:47:42.122269
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:47:52.307756
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.unit_scale = False
    tqdm_notebook_1.disable = False
    tqdm_notebook_1.total = 42
    tqdm_notebook_1.unit = 'it'
    tqdm_notebook_1.unit_scale = True
    tqdm_notebook_1.desc = ''
    tqdm_notebook_1.total_var = None
    tqdm_notebook_1.gui = False
    tqdm_notebook_1.miniters = None
    tqdm_notebook_1.mininterval = 0.1
    tqdm_notebook_1

# Generated at 2022-06-26 09:47:58.511182
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    """
    Test case for constructor of class tqdm_notebook
    """
    def create():
        # non-existing import
        return tqdm_notebook()

    with pytest.raises(ImportError):
        create()

# Generated at 2022-06-26 09:48:00.613165
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()


# Generated at 2022-06-26 09:48:01.348460
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    test_case_0()


# Generated at 2022-06-26 09:48:07.919382
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_1.update(1)
    assert tqdm_notebook_1.n == 1


# Generated at 2022-06-26 09:48:09.312220
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    obj = tqdm_notebook()
    try:
        for obj in obj.__iter__():
            pass
    except Exception as e:
        print(e)


# Generated at 2022-06-26 09:48:14.325498
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    test_tqdm_notebook_close_1 = tqdm_notebook()
    test_tqdm_notebook_close_1.total = 2
    test_tqdm_notebook_close_1.n = 1
    test_tqdm_notebook_close_1.close()


# Generated at 2022-06-26 09:48:23.317975
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from tqdm._tqdm_gui import tqdm_notebook
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_2 = tqdm_notebook()
    msg_1 = "Done"
    bar_style_1 = "info"
    # Test Case: Case1
    tqdm_notebook_1.display(msg=msg_1, bar_style=bar_style_1)
    # Test Case: Case2
    tqdm_notebook_2.display(msg=msg_1, close=True)

if __name__ == "__main__":
    test_case_0()
    test_tqdm_notebook_display()

# Generated at 2022-06-26 09:48:51.741797
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    progress = tqdm_notebook(total=4, leave=False)
    progress.clear()


# Generated at 2022-06-26 09:48:56.531493
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t = tqdm_notebook(range(10))
    for i in t:
        for x in tqdm_notebook(range(10)):
            pass


# Generated at 2022-06-26 09:48:59.444872
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:49:10.787552
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook(total=42, leave=True)
    tqdm_notebook_1.update(n=1)
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.update()


# Generated at 2022-06-26 09:49:23.754081
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    import sys
    import random

    # Create a TqdmHBox object
    tqdm_notebook_0 = tqdm_notebook(total=100)
    if not tqdm_notebook_0.disable:
        tqdm_notebook_0.displayed = True
        tqdm_notebook_0.container = tqdm_notebook.status_printer(
            sys.stdout, total=100, desc='description')
        tqdm_notebook_0.container.pbar = tqdm_notebook_0
        tqdm_notebook_0.container.children[0].value = 'description'
        tqdm_notebook_0.container.children[1].value = random.randint(1, 100)

# Generated at 2022-06-26 09:49:31.211489
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.notebook import tqdm_notebook
    x = tqdm_notebook(range(10))
    x.reset(total=10, leave=False)
    x.close()
    assert x.n == 0
    assert x.total == 10


# Generated at 2022-06-26 09:49:33.552359
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    for obj in tqdm_notebook_0:
        continue

# Generated at 2022-06-26 09:49:37.977773
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    for i in range(1, 11):
        tqdm_notebook_0.update(1)

# Generated at 2022-06-26 09:49:47.580709
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    try:
        import ipywidgets
        IPY = 4
    except ImportError:  # IPython 3.x / 2.x
        IPY = 32
        import warnings
        with warnings.catch_warnings():
            warnings.filterwarnings(
                'ignore', message=".*The `IPython.html` package has been deprecated.*")
            try:
                import IPython.html.widgets as ipywidgets  # NOQA: F401
            except ImportError:
                pass

# Generated at 2022-06-26 09:49:52.006287
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.__iter__()


# Generated at 2022-06-26 09:50:55.262857
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:50:59.834028
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    hbox = TqdmHBox()
    hbox.bar = 'some_bar'
    result = hbox.__repr__()
    # check if the result is not empty
    assert result != '', 'empty result of __repr__'


# Generated at 2022-06-26 09:51:03.308612
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_reset_0 = tqdm_notebook().reset(total=1)


# Generated at 2022-06-26 09:51:07.164189
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    test_tqdm = tqdm_notebook()

    test_tqdm.reset(total=20)

    assert test_tqdm.total == 20


# Generated at 2022-06-26 09:51:11.091158
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook._instances.clear()
    tqdm_notebook_1 = tqdm_notebook()
    assert isinstance(tqdm_notebook_1.status_printer(
        file=sys.stdout), TqdmHBox)



# Generated at 2022-06-26 09:51:12.894761
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()

# Generated at 2022-06-26 09:51:16.328087
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:51:25.122844
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(0, 100, desc= "test 1")
    tqdm_notebook_2 = tqdm_notebook(0, 100, desc= "test 2")
    tqdm_notebook_3 = tqdm_notebook(0, 100, desc= "test 3")
    tqdm_notebook_4 = tqdm_notebook(0, 100, desc= "test 4")
    tqdm_notebook_5 = tqdm_notebook(0, 100, desc= "test 5")
    tqdm_notebook_6 = tqdm_notebook(0, 100, desc= "test 6")
    tqdm_notebook_7 = tqdm_notebook(0, 100, desc= "test 7")
    tq

# Generated at 2022-06-26 09:51:32.523028
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.n = 2
    curr_format = tqdm_notebook_1.format_dict
    tqdm_notebook_1.update(1)
    assert (tqdm_notebook_1.n == 3)


# Generated at 2022-06-26 09:51:43.859391
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test case 1
    # Setup and reset
    tqdm_notebook_0 = tqdm_notebook(desc="test_tqdm_notebook_reset_1", leave=False)
    tqdm_notebook_0.reset()
    # Assertions
    assert tqdm_notebook_0.curr_len == 0
    assert tqdm_notebook_0.desc == "test_tqdm_notebook_reset_1"
    assert tqdm_notebook_0.format_dict["bar_format"] == "{l_bar}{bar}| {n_fmt}/{total_fmt} [{elapsed}<{remaining}, {rate_fmt}{postfix}]"
    assert tqdm_notebook_0.format_dict["rate_noinv"] is False


# Generated at 2022-06-26 09:52:54.894122
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Bar with total=4
    bar = tqdm_notebook(total=4)
    for _ in range(4):
        bar.update()

    # Test reset with total=8
    bar.reset(total=8)
    for _ in range(8):
        bar.update()

    # Test reset without total: it should not change the total of the bar
    bar.reset()
    for _ in range(2):
        bar.update()
    bar.close()

    # Test reset on non-deterministic iterable
    # The total will be set to None
    bar = tqdm_notebook()
    for _ in range(2):
        bar.update()

    # Test reset with total=None: it should not change the total of the bar
    bar.reset(total=None)

# Generated at 2022-06-26 09:53:03.311565
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_3 = tqdm_notebook()



# Generated at 2022-06-26 09:53:06.438397
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    # call __repr__ method of class TqdmHBox
    assert tqdm_notebook_0.container.__repr__() == ''


# Generated at 2022-06-26 09:53:09.658914
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    assert tqdm_notebook_1.reset() is None


# Generated at 2022-06-26 09:53:12.387834
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()


# Generated at 2022-06-26 09:53:17.417206
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    for i in tqdm_notebook_1.__iter__():
        tqdm_notebook_1.update()


# Generated at 2022-06-26 09:53:22.010165
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Instantiate tqdm_notebook
    tqdm_notebook_1 = tqdm_notebook()
    # Test the iterable
    for i in tqdm_notebook_1:
        pass


# Generated at 2022-06-26 09:53:30.859337
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    if IPY == 2:
        pass
    elif IPY in [3, 4]:
        from IPython.testing.globalipapp import get_ipython
        ip = get_ipython()
        bar = tqdm_notebook.status_printer(
            None, desc="test", ncols=None).children[1]
        assert bar.type == 'FloatProgress'
        assert bar.max == 1
        assert bar.layout.width == '20px'  # default width

        # Test that the progress bar is output to the notebook cell
        ip.run_cell("test_case_0()")
        # The following assertation raises an exception
        # if the bar is not displayed
        bar.visible = True

        # Test that the progress bar's title can be updated
        bar.bar_style = 'info'
        bar

# Generated at 2022-06-26 09:53:33.113938
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from tqdm.notebook import tqdm_notebook
    tqdm_notebook_0 = tqdm_notebook()
    total = 100
    tqdm_notebook_0.reset(total=total)
    assert tqdm_notebook_0.total == total, "Error with reset"

# Generated at 2022-06-26 09:53:40.179419
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_status_printer_0 = tqdm_notebook.status_printer(None)
    tqdm_notebook_status_printer_1 = tqdm_notebook.status_printer(None,
                                    total=None,
                                    desc=None,
                                    ncols=None)
    if '__main__' == __name__:
        test_case_0()
        test_tqdm_notebook_status_printer()

# Generated at 2022-06-26 09:55:54.997011
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # init
    tqdm_notebook_0 = tqdm_notebook()
    # Reset to 0 iterations for repeated use.
    try:
        tqdm_notebook_0.reset()
    except Exception as error:
        print("An exception occurred in reset(): ", type(error), error.args)


# Generated at 2022-06-26 09:56:05.506679
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Test case: No. 0
    # _, container = tqdm_notebook()._instances['status']._instances[''].status_printer(None, None, None, None)
    _, container = tqdm_notebook_0.status_printer(None, None, None, None)
    assert isinstance(container, HBox)
    assert isinstance(container.children[0], HTML)
    assert isinstance(container.children[1], IProgress)
    assert isinstance(container.children[2], HTML)



# Generated at 2022-06-26 09:56:11.779485
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.display("")
