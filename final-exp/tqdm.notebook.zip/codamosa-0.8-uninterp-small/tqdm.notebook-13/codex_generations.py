

# Generated at 2022-06-26 09:46:32.407113
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    t = tqdm_notebook(0)
    t.reset(10)
    assert t.total == 10


# Generated at 2022-06-26 09:46:40.033037
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    h_box = TqdmHBox()
    h_box_1 = TqdmHBox()
    h_box_1.pbar = proxy(h_box_1)
    assert h_box_1.__repr__() == '100%|██████████| 10/10 [00:00<00:00, 1000.10it/s]'


# Generated at 2022-06-26 09:46:44.504526
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # This unit test will pass if you have IPython/Jupyter installed
    status_printer_0_0 = tqdm_notebook.status_printer(file=None, total=None,
                                                      desc=None, ncols=None)


# Generated at 2022-06-26 09:46:49.833272
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    n_iter = 10
    tqdm_notebook_obj = tqdm_notebook(total=n_iter)
    for i in range(n_iter//2):
        tqdm_notebook_obj.update(n=1)

    old_total = tqdm_notebook_obj.total
    assert old_total == n_iter
    new_total = n_iter + 10
    tqdm_notebook_obj.reset(total=new_total)

    assert new_total == tqdm_notebook_obj.total
    

# Generated at 2022-06-26 09:46:56.135509
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    try:
        tqdm_notebook_0 = tqdm_notebook.__init__()
        tqdm_notebook_0.close()
    except:
        print("Error occured while calling tqdm_notebook.close()")


# Generated at 2022-06-26 09:47:02.410344
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from collections import defaultdict
    from tqdm import __version__ as tqdm_version
    import pickle
    from .tests_tqdm import pretest_posttest_run, is_ascii_art

    # Dummy tqdm object

# Generated at 2022-06-26 09:47:04.042705
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    pass


# Generated at 2022-06-26 09:47:08.651010
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_h_box_0 = TqdmHBox()
    # Call method __repr__ of tqdm_h_box_0
    tqdm_h_box_0___repr__ = tqdm_h_box_0.__repr__()


# Generated at 2022-06-26 09:47:21.116135
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from IPython.display import display, clear_output
    tqdm_notebook_0 = tqdm_notebook(4, ncols=100)
    for i in tqdm_notebook_0:
        tqdm_notebook_0.status_printer(tqdm_notebook_0.fp, None, None, tqdm_notebook_0.ncols)
        clear_output(wait=1)
        display(tqdm_notebook_0.container)
        tqdm_notebook_0.n = (tqdm_notebook_0.n) + (1)
    tqdm_notebook_0.close()



# Generated at 2022-06-26 09:47:29.121101
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    print('Testing method update of class tqdm_notebook')
    # Testing for tqdm_notebook update
    tqdm_notebook_update_0 = tqdm_notebook()

    # Testing for tqdm_notebook update
    tqdm_notebook_update_1 = tqdm_notebook()
    tqdm_notebook_update_1.update()


# Generated at 2022-06-26 09:47:51.653117
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.display()


# Test tqdm_notebook.display with close=True

# Generated at 2022-06-26 09:48:01.467809
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Test if update of a tqdm_notebook instance is correctly handled.

    The test is performed by creating a tqdm_notebook instance,
    calling update and checking whether the tqdm_notebook instance
    behaves correctly.
    """
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:48:05.731884
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # obj is TqdmHBox
    # obj.pbar is tqdm_notebook
    # obj.pbar.disp
    from IPython.display import display
    from time import sleep

    with tqdm_notebook(total=2) as obj:
        sleep(1)
        obj.pbar.update(1)
        display("Hello")
        sleep(1)
        obj.pbar.update(1)



# Generated at 2022-06-26 09:48:14.430673
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    Function that runs an update test over an instance of tqdm_notebook,
    verifying that the attributes 'n' and 'total' are equal to the expected values
    """
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update(n=5)
    assert tqdm_notebook_1.n == 5, "n has not been properly updated"
    assert tqdm_notebook_1.total == None, "total has not been properly updated"


# Generated at 2022-06-26 09:48:15.602488
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook(disable=False)
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:48:22.008443
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=21) as t:
        for i in _range(2):
            t.update(10)
            t.reset(total=30)
            for i in _range(10):
                t.update()



# Generated at 2022-06-26 09:48:27.903848
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook(total=4)
    for i in range(4):
        tqdm_notebook_1.update(1)
    tqdm_notebook_1.reset(total=3)
    for j in range(3):
        tqdm_notebook_1.update(1)


# Generated at 2022-06-26 09:48:31.091779
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:48:35.804352
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test for public function '__iter__' of class 'tqdm_notebook'
    iter = tqdm_notebook().__iter__()


# Generated at 2022-06-26 09:48:41.227368
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test with a float value for the total
    tqdm_notebook_1 = tqdm_notebook(total=20)
    tqdm_notebook_1.reset(15.6)
    # Test with an integer value for the total
    tqdm_notebook_2 = tqdm_notebook(total=20)
    tqdm_notebook_2.reset(15)
    # Test without giving a value for the total
    tqdm_notebook_3 = tqdm_notebook(total=20)
    tqdm_notebook_3.reset()



# Generated at 2022-06-26 09:49:11.367106
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook(desc='tqdm_notebook_test_1')
    tqdm_notebook_1.update()
    assert tqdm_notebook_1.n == 1

# Generated at 2022-06-26 09:49:14.789167
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # initialise object
    x = tqdm_notebook(total=10)
    # test case 1
    x.display()



# Generated at 2022-06-26 09:49:18.857550
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_test = tqdm_notebook()
    tqdm_notebook_test.reset()


# Generated at 2022-06-26 09:49:23.232454
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_1 = tqdm_notebook()
    assert isinstance(tqdm_notebook_1, tqdm_notebook)


# Generated at 2022-06-26 09:49:29.048817
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    expected_value = 1
    test_obj = tqdm_notebook()
    test_obj.n = 0
    actual_value = test_obj.update()
    assert actual_value == expected_value


# Generated at 2022-06-26 09:49:35.755305
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    with warnings.catch_warnings():
        warnings.filterwarnings("ignore")
        tqdm_notebook_0 = tqdm_notebook()
        display_successfull = False
        try:
            tqdm_notebook_0.display(msg = "test")
            display_successfull = True
        except:
            display_successfull = False
    assert display_successfull == True


# Generated at 2022-06-26 09:49:37.550085
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    assert tqdm_notebook_1.__iter__()
    

# Generated at 2022-06-26 09:49:42.382652
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Setup
    tqdm_notebook_0 = tqdm_notebook()

    # Assert
    assert tqdm_notebook_0.reset() == tqdm_notebook_0



# Generated at 2022-06-26 09:49:45.484373
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    for total_ in [1, 10, None]:
        for ncols_ in [None, "100", "100%", 100]:
            yield check_tqdm_notebook_reset, total_, ncols_



# Generated at 2022-06-26 09:49:56.010714
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.display()
    tqdm_notebook_1.display("")
    tqdm_notebook_1.display("", 0)
    tqdm_notebook_1.display("", 0, True)
    tqdm_notebook_1.display("", 0, True, "")
    tqdm_notebook_1.display("", 0, True, "", True)


# Generated at 2022-06-26 09:50:48.030135
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    #Initialize tqdm_notebook object
    tqdm_notebook_0 = tqdm_notebook()
    #Assert test case
    assert tqdm_notebook_0.display() == None


# Generated at 2022-06-26 09:50:56.367326
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    t = tqdm_notebook(total=1)
    assert t.last_print_n == 0
    assert t.last_print_t is None
    t.display(n=1, pos=1, bar_style='success', close=True)
    assert t.last_print_n == 1
    assert t.last_print_t is None

# Generated at 2022-06-26 09:50:59.770004
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    assert isinstance(tqdm_notebook_1.__iter__(), type(tuple()))


# Generated at 2022-06-26 09:51:11.996437
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_1.status_printer("", progress=True, ncols=None)
    tqdm_notebook_2 = tqdm_notebook(total=10)
    tqdm_notebook_2.status_printer("", progress=True, ncols=1)
    tqdm_notebook_3 = tqdm_notebook(total=10)
    tqdm_notebook_3.status_printer("", progress=True, ncols=-1)
    tqdm_notebook_4 = tqdm_notebook(total=10)
    tqdm_notebook_4.status_printer("", progress=True, ncols=100)


# Generated at 2022-06-26 09:51:23.673094
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Tests for display of tqdm_notebook
    tqdm_notebook_1 = tqdm_notebook()
    # Test for display
    # Test with bar_style = danger and close = False
    tqdm_notebook_1.display(bar_style = 'danger', close = False)
    # Test with bar_style = success and close = True
    tqdm_notebook_1.display(bar_style = 'success', close = True)
    # Test with bar_style = info and close = True
    tqdm_notebook_1.display(bar_style = 'info', close = True)
    tqdm_notebook_1.display("XYZ")
    tqdm_notebook_1.display("XYZ", bar_style = 'danger')
    tqdm_notebook_1

# Generated at 2022-06-26 09:51:35.296709
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # check for
    # 1. if the original value of self.total is the same as the one after reset, then it
    # has been reset to the new total
    # 2. if the original and current value (before and after reset)of
    # self.container.children[1].max is the same, then it has been reset to the new
    # total
    a = tqdm_notebook()
    old_total = a.total
    old_max = a.container.children[1].max

    a.reset(10)
    assert old_total != a.total, "Reset function not functioning"
    assert old_max == a.container.children[1].max, "Reset function not functioning"

    # check for exception if total field is not integer

# Generated at 2022-06-26 09:51:44.736580
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    import tqdm
    from tqdm import tqdm_notebook
    # Test if resetting an already closed bar could lead to an unexpected
    # reopening of the bar on update.
    # See issue #753.
    total = 100
    tqdm_notebook_0 = tqdm.tqdm_notebook(total=total)
    for i in range(total):
        tqdm_notebook_0.update()
    tqdm_notebook_0.close()
    # Making sure the bar is closed
    tqdm_notebook_1 = tqdm.tqdm_notebook(total=total)
    tqdm_notebook_0.reset(total=total)
    for i in range(total):
        tqdm_notebook_0.update()
    tqdm_

# Generated at 2022-06-26 09:51:48.309554
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:51:58.505770
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tq = tqdm_notebook()
    try:
        tq.status_printer(None)
        raise Exception("status_printer should throw an error if IProgress doesn't exist")
    except ImportError:
        pass
    except Exception as e:
        raise Exception("status_printer should throw an ImportError error "
                        "if IProgress doesn't exist") from e
    # Test if total is None
    tq.status_printer(None, total=None)

    # Test if total is not None
    tq.status_printer(None, total=10)
    # Test if total is not None and desc is given
    tq.status_printer(None, total=10, desc='desc')
    # Test if total is None and desc is given

# Generated at 2022-06-26 09:52:05.750914
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    pass
    # from IPython import get_ipython
    # get_ipython().run_line_magic('run', 'tqdm/notebook.py')
    # tqdm_notebook_0 = tqdm_notebook()
    # tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:54:05.643217
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import numpy as np
    # With total
    tqdm_notebook_1 = tqdm_notebook(total=10)
    assert tqdm_notebook_1.container.children[1].max == 10

    # Without total
    tqdm_notebook_2 = tqdm_notebook()
    assert tqdm_notebook_2.container.children[1].max == 1


# Generated at 2022-06-26 09:54:12.553254
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    # Ensure function returns a <class 'tqdm._tqdm_notebook.tqdm_notebook'>
    assert isinstance(tqdm_notebook_0.reset(total=1), tqdm_notebook)


# Generated at 2022-06-26 09:54:15.833936
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    # Assert that __iter__() raises a TypeError when called with 0 arguments
    with pytest.raises(TypeError):
        tqdm_notebook_1.__iter__()


# Generated at 2022-06-26 09:54:25.479150
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Arrange
    tqdm_notebook_0 = tqdm_notebook(total=10, disable=False)

    # Act
    for obj in tqdm_notebook_0.__iter__():
        tqdm_notebook_0.update()
    # Assert
    assert tqdm_notebook_0.n == 10


# Generated at 2022-06-26 09:54:31.282666
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from io import StringIO
    import sys
    import unittest
    import warnings

    @tqdm_notebook
    def thunk():
        return range(100)

    class ExceptionTest(unittest.TestCase):
        pass
    function_return_value = thunk()
    ExceptionTest.assertEqual(
        function_return_value, range(100),
        'The returned value did not match the expected value')
    my_stdout = StringIO()
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        my_stdout.flush()
        sys.stdout = my_stdout
        print(function_return_value)
        sys.stdout = sys.__stdout__

# Generated at 2022-06-26 09:54:40.563015
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test if total is None
    tqdm_notebook_1 = tqdm_notebook(total=10)
    assert tqdm_notebook_1.total == 10, "Total should be 10."
    tqdm_notebook_1.reset()
    assert tqdm_notebook_1.total == None, "Total should be None."

    # Test if total is not None
    tqdm_notebook_2 = tqdm_notebook()
    assert tqdm_notebook_2.total == None, "Total should be None."
    tqdm_notebook_2.reset(total=20)
    assert tqdm_notebook_2.total == 20, "Total should be 20."



# Generated at 2022-06-26 09:54:51.129369
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    Unit test for method status_printer of class tqdm_notebook
    """
    tqdm_notebook_0 = tqdm_notebook()

    status_printer_arg_types = [
        [
            [int, float],
            [int, None]
        ],
        [
            [int, float],
            [int, None],
            [str, None]
        ]
    ]

    status_printer_arg_values = [
        [
            [5, 5.5],
            [None, None]
        ],
        [
            [5, 5.5],
            [None, None],
            [None, None]
        ]
    ]


# Generated at 2022-06-26 09:54:54.974955
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(*[1, 2, 3])
    r = tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:54:58.339814
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    t = tqdm_notebook(range(10))
    for i in t.__iter__():
        pass


# Generated at 2022-06-26 09:55:07.041225
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    """
    Used to test the method `reset` of class `tqdm_notebook`
    """
    tqdm_notebook_test_reset = tqdm_notebook(total=10)
    tqdm_notebook_test_reset.reset(total=15)
    assert tqdm_notebook_test_reset.total==15
