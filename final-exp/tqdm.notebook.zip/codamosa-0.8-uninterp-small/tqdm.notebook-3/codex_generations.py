

# Generated at 2022-06-26 09:46:42.266536
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Method __iter__ of class tqdm_notebook instance
    tqdm_notebook_0 = tqdm_notebook(range(1, 10))
    # User code
    tqdm_notebook_0.__iter__()


# Generated at 2022-06-26 09:46:44.594837
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:46:47.360411
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook(disable=False)
    tqdm_notebook_0.reset()


# Generated at 2022-06-26 09:46:55.001218
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tb = tqdm_notebook(['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z'], desc='Testing---')
    for i in tb:
        pass


# Generated at 2022-06-26 09:47:02.126670
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    """
    test class tqdm_notebook
    """
    from .tqdm.std import TqdmTypeError
    from .tqdm._utils import _term_move_up
    from .tqdm._utils import _unicode
    from .tqdm.std import FormatCustomTextType
    from .tqdm.std import FormatDefaultTextType
    from .tqdm.std import FormatCustomTextExt
    from ._version import __version__
    total2 = 10
    total3 = 11
    total4 = 5
    total5 = 9
    desc1 = 'desc1'
    desc2 = 'desc2'
    desc3 = 'desc3'
    desc4 = 'desc4'
    desc5 = 'desc5'
    desc6 = 'desc6'
    desc7 = 'desc7'
   

# Generated at 2022-06-26 09:47:06.520576
# Unit test for method close of class tqdm_notebook
def test_tqdm_notebook_close():
    tqdm_notebook_0 = tqdm_notebook("test_tqdm_notebook_close")
    tqdm_notebook_0.close()


# Generated at 2022-06-26 09:47:08.566300
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:47:13.740544
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    total = 1
    desc = ""
    ncols = None
    test_return = tqdm_notebook.status_printer(None, total, desc, ncols)



# Generated at 2022-06-26 09:47:18.594543
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_h_box_1 = tqdm_notebook_0.status_printer(None)


# Generated at 2022-06-26 09:47:31.487856
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.disable = False
    tqdm_notebook_0.total = 10
    tqdm_notebook_0.n = 10
    tqdm_notebook_0.container.children[-2].style.bar_color = None
    tqdm_notebook_0.ncols = None
    tqdm_notebook.display(tqdm_notebook_0, None)
    tqdm_notebook.display(tqdm_notebook_0, None, close=True)
    tqdm_notebook.display(tqdm_notebook_0, 'Test message')

# Generated at 2022-06-26 09:48:05.135928
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    size = 100
    status = {'total': size, 'interval': 1, 'ncols': 100, 'desc': 'Test of display method'}
    tqdm_notebook_display = TqdmHBox()
    for i in range(size):
        status['n'] = i
        tqdm_notebook_display.display(pos=status)
        import time
        time.sleep(0.1)
    tqdm_notebook_display.display(close=True)
    tqdm_notebook_display.display()


if __name__ == '__main__':
    test_tqdm_notebook_display()

# Generated at 2022-06-26 09:48:16.778669
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    import sys
    import re
    import os
    import cgi
    import html
    tqdm_notebook_0 = tqdm_notebook()
    # test for the message when there is no close
    tqdm_notebook_0.display(msg=None, pos=None, close=False, bar_style=None, check_delay=True)

    #test for the message when there is a close
    tqdm_notebook_0.display(msg=None, pos=None, close=True, bar_style=None, check_delay=True)

    # test for the colour
    tqdm_notebook_0.colour = '#dfe0d0'

    # test for the colour setter
    tqdm_notebook_0.colour



# Generated at 2022-06-26 09:48:19.255361
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook()


# Generated at 2022-06-26 09:48:31.963952
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test 1
    test_tqdm_notebook_obj = tqdm_notebook()

    # Test 2

# Generated at 2022-06-26 09:48:37.742297
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tn_0 = tqdm_notebook(range(10), ascii=True)
    tn_0.__iter__()

    tn_1 = tqdm_notebook(range(10), ascii=False)
    tn_1.__iter__()


# Generated at 2022-06-26 09:48:48.607771
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():

    # create a dummy, reset and test that the bar style is empty
    dummy = tqdm_notebook(total=2, leave=True)
    dummy.reset(total=2)
    assert dummy.container.children[-2].bar_style == ''

    # create a dummy, reset and test that the bar style is no longer empty
    dummy = tqdm_notebook(total=2, leave=True)
    dummy.reset(total=1)
    assert dummy.container.children[-2].bar_style != ''

# Generated at 2022-06-26 09:48:52.339481
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:48:56.961289
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.status_printer(file = sys.stdout)


# Generated at 2022-06-26 09:49:00.038412
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    pbar = tqdm_notebook(total=100)

    for i in range(100):
        pbar.update(1)
    pbar.close()


# Generated at 2022-06-26 09:49:12.995583
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    test_case_0()


if __name__ == '__main__':
    file_name = 'tqdm_notebook.py'
    with open(file_name, 'w') as file:
        file.write(str(tqdm_notebook))

    import unittest
    suite = unittest.TestLoader().discover(
        start_dir='./', pattern='*_test.py', top_level_dir='./')
    unittest.TextTestRunner(verbosity=1).run(suite)

    import os
    os.remove(file_name)

# Generated at 2022-06-26 09:49:28.353883
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook()


# Generated at 2022-06-26 09:49:32.708816
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tq = tqdm_notebook(total=7)
    for i in tq:
        pass


# Generated at 2022-06-26 09:49:36.691893
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    print("\nCheck that tqdm_notebook.display does not raise an exception")

    msg = "message"
    bar_style = "success"
    check_delay = True

    tqdm_notebook_0 = tqdm_notebook()

    tqdm_notebook_0.display(msg, None, False, bar_style, check_delay)


# Generated at 2022-06-26 09:49:40.052546
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    a = tqdm_notebook(total=0)
    a.reset()


# Generated at 2022-06-26 09:49:43.549040
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_h_box_0 = TqdmHBox()
    assert tqdm_h_box_0.__repr__() == '{}'


# Generated at 2022-06-26 09:49:56.698969
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_obj = tqdm_notebook(iterable=None, total=None, desc=None,
                             position=None, leave=False, miniters=None,
                             maxinterval=None, mininterval=None, maxiters=None,
                             ascii=False, disable=False, unit='it',
                             unit_scale=False, dynamic_ncols=False,
                             smoothing=0.3, bar_format=None, initial=0,
                             position_names=('bar', 'n', 'avg', 'elapsed'),
                             gui=True, colour=None, display=True, file=None)
    assert test_obj.disable is False


# Generated at 2022-06-26 09:50:10.509942
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_h_box_0 = TqdmHBox()
    tqdm_h_box_1 = TqdmHBox()
    # check that the pretty print is working
    assert( isinstance(tqdm_h_box_0.__repr__(True), str))
    assert(tqdm_h_box_0.__repr__(True) != tqdm_h_box_1.__repr__(True))
    # check that the non pretty print is working
    assert( isinstance(tqdm_h_box_0.__repr__(), str))
    assert(tqdm_h_box_0.__repr__() != tqdm_h_box_1.__repr__())


# Generated at 2022-06-26 09:50:12.177561
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for i in tqdm_notebook(range(50)):
        pass

test_tqdm_notebook_update()

# Generated at 2022-06-26 09:50:14.562786
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear(1, 2)


# Generated at 2022-06-26 09:50:17.771701
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():

    def test_case_tqdm_notebook_clear_0():
        tqdm_notebook_0 = tqdm_notebook(disable=True)


# Generated at 2022-06-26 09:50:31.081905
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()

# Generated at 2022-06-26 09:50:39.467033
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    from ._tqdm import tqdm as tqdm_object
    from .std import TqdmWarning, TqdmDeprecationWarning

    # Test for class tqdm_notebook
    tqdm_notebook(total=0)

    with tqdm_object(total=0, desc="Test 1: (1/3)") as t:
        assert isinstance(t, tqdm_notebook)
        t.update(1)

    t = tqdm_notebook(total=2, desc="Test 1: (2/3)")
    assert isinstance(t, tqdm_notebook)
    t.update()

    with tqdm_object(total=0, desc="Test 1: (3/3)") as t:
        assert isinstance(t, tqdm_notebook)


# Generated at 2022-06-26 09:50:41.007865
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    assert True


# Generated at 2022-06-26 09:50:47.397949
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    from tqdm import tnrange
    import time

    for i in tnrange(3, desc='1st loop'):
        for j in tnrange(100, desc='2nd loop'):
            time.sleep(0.01)



# Generated at 2022-06-26 09:50:49.221614
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Tested by test_case_0
    assert True


# Generated at 2022-06-26 09:50:55.262584
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pbar = TqdmHBox(children=[HTML(), IProgress(min=0, max=1), HTML()])
    print(pbar)
    pbar.close()



# Generated at 2022-06-26 09:50:56.565816
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    test_obj = tqdm_notebook()
    test_obj.status_printer(_,total = None, desc = None, ncols = None)


# Generated at 2022-06-26 09:51:01.299122
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_1 = tqdm_notebook()
    # test with tqdm_notebook_1.status_printer:
    # parameter total is of type int
    total = 15
    # parameter desc is of type basestring
    desc = ""
    tqdm_notebook_1.status_printer(total=total, desc=desc)


# Generated at 2022-06-26 09:51:11.060279
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook_0 = tqdm_notebook()
    test_file = sys.stderr
    test_total = 10
    test_desc = "TEST"
    test_ncols = None
    test_pbar = tqdm_notebook_0.status_printer(test_file, test_total, test_desc, test_ncols)
    assert test_pbar.min == 0
    assert test_pbar.max == 10
    assert test_pbar.step == 1
    assert test_pbar.max == test_total



# Generated at 2022-06-26 09:51:12.818591
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    test_case_0()



# Generated at 2022-06-26 09:51:42.566966
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_container_0 = tqdm_notebook_1.container
    tqdm_notebook_container_0.pbar = tqdm_notebook_1
    tqdm_notebook_container_0.__repr__(False)


# Generated at 2022-06-26 09:51:45.839940
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        tqdm_notebook(1)
    except:
        return False
    return True


# Generated at 2022-06-26 09:51:57.447896
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    import sys
    import re
    import inspect
    from inspect import getsource

    # Get source code of method status_printer of class tqdm_notebook
    src_str = inspect.getsource(tqdm_notebook.status_printer)

    # Remove leading and trailing whitespace, capture in src_str_stripped
    src_str_stripped = re.sub('^\s+|\n|\r|\s+$', '', src_str)

    # List of keywords in method status_printer of class tqdm_notebook

# Generated at 2022-06-26 09:51:59.509462
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Initializing the class
    tqdm_notebook_0 = tqdm_notebook(3, desc='Test', leave=True)
    # Running method __iter__
    # Failing because of missing assertTrue


# Generated at 2022-06-26 09:52:00.726329
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()


# Generated at 2022-06-26 09:52:03.798967
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # Initializing object
    tqdm_notebook_1 = tqdm_notebook(total=10)
    tqdm_notebook_2 = tqdm_notebook(total=10)
    # Testing default values
    tqdm_notebook_1.update()
    assert tqdm_notebook_1.n == 1
    tqdm_notebook_2.update(n=1)
    assert tqdm_notebook_2.n == 2
    assert tqdm_notebook_1 == tqdm_notebook_2


# Generated at 2022-06-26 09:52:04.961231
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():

    test_obj = tqdm_notebook()
    test_obj.status_printer()



# Generated at 2022-06-26 09:52:06.502846
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()


# Generated at 2022-06-26 09:52:10.372195
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_1 = tqdm_notebook()
    # test the status bar is display successfully
    assert tqdm_notebook_1.total == tqdm_notebook_1.container.children[-2].max



# Generated at 2022-06-26 09:52:17.190715
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset(total=None);
    assert tqdm_notebook_0.n == 0

    

# Generated at 2022-06-26 09:53:08.260794
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    # Test if exception is thrown for correct input
    try:
        tqdm_notebook_0.clear()
    except Exception as e:
        raise AssertionError("Unexpected exception thrown: {0}".format(str(e))) from e
    # Test if exception is thrown for incorrect input
    with pytest.raises(TypeError):
        tqdm_notebook_0.clear("blabla")


# Generated at 2022-06-26 09:53:19.837610
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Test 1: Test when leave = True and bar_style = None
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset(leave = True, bar_style = None)
    # Test 2: Test when leave = False and bar_style = None
    tqdm_notebook_2 = tqdm_notebook()
    tqdm_notebook_2.reset(leave = False, bar_style = None)
    # Test 3: Test when leave = None and bar_style = 'success'
    tqdm_notebook_3 = tqdm_notebook()
    tqdm_notebook_3.reset(leave = None, bar_style = 'success')
    # Test 4: Test when leave = None and bar_style = None
    tqdm_

# Generated at 2022-06-26 09:53:28.470685
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():

    msg1 = "test_tqdm_notebook_clear"
    test_tqdm_notebook = tqdm_notebook(total=3, desc=msg1)

    assert test_tqdm_notebook.desc == msg1
    assert test_tqdm_notebook.total == 3

    for i in test_tqdm_notebook:
        if i == 1:
            test_tqdm_notebook.clear()

    assert test_tqdm_notebook.desc == None
    assert test_tqdm_notebook.total == None



# Generated at 2022-06-26 09:53:31.763810
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    from tqdm import trange
    from time import sleep
    for i in trange(10):
        sleep(0.01)
        raise Exception()
        yield i


# Generated at 2022-06-26 09:53:39.224984
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test 1
    # Iterate over `10` elements by default (`trange`)
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.__iter__()

    # Test 2
    # Iterate over `10` elements by default (`trange`) with `desc`
    tqdm_notebook_1 = tqdm_notebook(desc="test")
    tqdm_notebook_1.__iter__()



# Generated at 2022-06-26 09:53:43.045217
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:53:45.577904
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_obj = tqdm_notebook()
    tqdm_notebook_obj.clear()

# Generated at 2022-06-26 09:53:47.272957
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    list1 = tqdm_notebook(range(5), desc='1st loop')
    assert list1 == [0, 1, 2, 3, 4]



# Generated at 2022-06-26 09:53:50.655248
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()

# Generated at 2022-06-26 09:53:53.547590
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    input1 = tqdm_notebook()
    input1.clear()
    input1.clear(nolock=True)


# Generated at 2022-06-26 09:55:30.697048
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_1 = tqdm_notebook()
    generator = tqdm_notebook_1.__iter__()
    assert [next(generator) for n in range(2)] == [0, 1]


# Generated at 2022-06-26 09:55:35.305889
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Test with no args
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.__iter__()
    # Test with args
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.__iter__(True, 1, 'hello')
    # Test with named args
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.__iter__(arg1=True, arg2=1, arg3='hello')


# Generated at 2022-06-26 09:55:44.829014
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update(n=2)


## Unit test for method reset of class tqdm_notebook
#def test_tqdm_notebook_reset():
#    tqdm_notebook_0 = tqdm_notebook()
#    tqdm_notebook_0.reset(total=None)
#
#
## Unit test for method __iter__ of class tqdm_notebook
#def test_tqdm_notebook___iter__():
#    tqdm_notebook_0 = tqdm_notebook()
#    for _ in (tqdm_notebook_0.__iter__()):
#        pass
#
#
## Unit test for method display of class tqdm_note

# Generated at 2022-06-26 09:55:48.637284
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:55:57.557503
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():

    import types
    # In case the function update of class tqdm_notebook is not refreshed
    if not(type(tqdm_notebook.update) is types.MethodType):
        test_tqdm_notebook_update()

    tqdm_notebook_test_value_1 = tqdm_notebook()
    tqdm_notebook_test_value_2 = tqdm_notebook()
    tqdm_notebook_test_value_3 = tqdm_notebook()
    tqdm_notebook_test_value_4 = tqdm_notebook()

    tqdm_notebook_test_value_3.update(1)
    tqdm_notebook_test_value_4.update(1)

    tqdm_notebook_test_value_1.update

# Generated at 2022-06-26 09:56:07.961243
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # change ncols and n to test total=None
    # create tqdm_notebook object
    tqdm_notebook_obj = tqdm_notebook(total=100)
    # call reset method
    tqdm_notebook_obj.reset()
    # check if n is reset
    assert tqdm_notebook_obj.n == 0
    # check if leave is reset
    assert tqdm_notebook_obj.leave == False
    # check total is reset
    assert tqdm_notebook_obj.total == 100

    # create another tqdm_notebook object
    tqdm_notebook_obj = tqdm_notebook()
    # set n and leave
    tqdm_notebook_obj.n = 10
    tqdm_notebook_obj.leave = True


# Generated at 2022-06-26 09:56:11.438330
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    test_case_0.tqdm_notebook_0.display()


# Generated at 2022-06-26 09:56:18.196044
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Check that display does not crash with message and position
    tn = tqdm_notebook()
    tn.disp('msg', pos=1)
    # Check that display does not crash without message
    tn.disp(pos=1)
    # Check that display does not crash without position
    tn.disp('msg')
    # Check that display does not crash without message nor position
    tn.disp()