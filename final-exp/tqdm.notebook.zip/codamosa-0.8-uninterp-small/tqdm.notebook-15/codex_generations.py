

# Generated at 2022-06-26 09:46:41.874827
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook.display(msg=None, pos=None, close=False, bar_style=None, check_delay=True)

# Generated at 2022-06-26 09:46:43.568932
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():

    # Test with arguments
    var_0 = tnrange(10)


# Generated at 2022-06-26 09:46:46.392131
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    obj_0 = tqdm_notebook()
    obj_0.update()    # Unit testing for method update of class tqdm_notebook


# Generated at 2022-06-26 09:46:48.517869
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    t = tnrange()
    t.clear()
    t.close()

# Generated at 2022-06-26 09:46:59.075168
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Check that HTML objects are returned if total is not None
    var_1 = tqdm_notebook.status_printer(None, total=None)
    if not isinstance(var_1, HBox):
        print ("Test #1 (status_printer) failed : the function returned ", var_1, " instead of ", HBox, ".")
    var_2 = tqdm_notebook.status_printer(None, total=1)
    if not isinstance(var_2, HBox):
        print ("Test #2 (status_printer) failed : the function returned ", var_2, " instead of ", HBox, ".")



# Generated at 2022-06-26 09:47:11.209721
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    var_0 = range(100)
    var_1 = tqdm_notebook(var_0)
    var_2 = var_1.reset()
    assert var_1.miniters == 1, 'test_tqdm_notebook_reset failed'
    assert var_1.desc == '', 'test_tqdm_notebook_reset failed'
    assert var_1.dynamic_ncols == True, 'test_tqdm_notebook_reset failed'
    assert var_1.smoothing == 0, 'test_tqdm_notebook_reset failed'
    assert var_1.unit_scale == False, 'test_tqdm_notebook_reset failed'
    assert var_1.maxinterval == 0, 'test_tqdm_notebook_reset failed'
    assert var

# Generated at 2022-06-26 09:47:18.746763
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    description_0 = "test_case_0"
    with tqdm_notebook(total=100, desc=description_0) as variable_0:
        variable_0.reset(total=1000)

if __name__ == '__main__':
    test_case_0()
    test_tqdm_notebook_reset()

# Generated at 2022-06-26 09:47:26.669343
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    from datetime import datetime
    from time import sleep
    from tqdm import tnrange

    progress_bar = tnrange(5)
    for _ in progress_bar:  # You can also use tqdm_gui(...)
        sleep(0.5)
        progress_bar.set_description(str(datetime.now()))
    progress_bar.close()



# Generated at 2022-06-26 09:47:29.117457
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    with open("test_tqdm_notebox_status_printer.test.txt", "w") as f:
        var_1 = tqdm_notebook.status_printer(f)


# Generated at 2022-06-26 09:47:39.279240
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Display tqdm_notebook
    var_1 = tqdm_notebook()
    # Display tqdm_notebook, in custom position
    var_2 = tqdm_notebook()
    # Display tqdm_notebook, with message
    var_3 = tqdm_notebook()
    # Display tqdm_notebook, close bar
    var_4 = tqdm_notebook(range(10))
    var_4.display(close=True)


# Generated at 2022-06-26 09:48:05.504370
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Initialize tqdm_notebook object
    var_0 = tqdm_notebook((1,))
    # Call method status_printer
    var_1 = var_0.status_printer(var_0, 1, "Example", 100)
    # Assert the results
    assert(var_1.children[1].max == 1)
    assert(var_1.children[1].bar_style == '')
    assert(var_1.children[0].value == "Example")
    assert(var_1.children[2].value == '')
    assert(var_1.layout.display == "inline-flex")
    assert(var_1.layout.width == "100%")
    assert(var_1.style.description_width == "initial")


# Generated at 2022-06-26 09:48:10.262617
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    from IPython.display import clear_output
    from time import sleep
    # Test that resetting works
    with tqdm_notebook(total=9, leave=True) as pbar:
        for i in range(1, 10):
            sleep(0.01)
            pbar.update(1)
            if i == 5:
                pbar.reset()
                assert pbar.n == 0
                assert pbar.last_print_n == 0
                assert pbar.last_print_t is None
                assert pbar.last_print_refresh_t is None
                assert pbar.last_print_n_visible == ' ' * len(str(pbar.total))



# Generated at 2022-06-26 09:48:14.215443
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    var_0 = tnrange(10)
    var_0.clear()
    assert var_0.n == 0 and var_0.total == 10
    var_0.clear()
    assert var_0.n == 0 and var_0.total == 10

# Generated at 2022-06-26 09:48:22.777355
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Testing if method status_printer of class tqdm_notebook works correctly.
    # tqdm_notebook.status_printer(file=1, total=None, desc=None, ncols=None)
    # var_0 is the return
    var_0 = tqdm_notebook.status_printer(file=1, total=None, desc=None, ncols=None)
    assert isinstance(var_0, TqdmHBox)
    assert var_0.__repr__(pretty=True) == '|                                                        |   0/1 [00:00<?, ?it/s]\n'


# Generated at 2022-06-26 09:48:28.726694
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    def test_0(total, desc, ncols, file_, value):
        assert tqdm_notebook.status_printer(file=file_, total=total, desc=desc, ncols=ncols)
    
    # test 0
    total = None
    desc = None
    ncols = None
    file_ = sys.stderr
    value = None
    test_0(total, desc, ncols, file_, value)


# Generated at 2022-06-26 09:48:32.698942
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    # Instantiate a tqdm_notebook object
    var_0 = tqdm_notebook()

    # Try resetting the bar
    var_0.reset()


# Generated at 2022-06-26 09:48:35.042034
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    pass


# Generated at 2022-06-26 09:48:39.051294
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Create instance of tqdm_notebook
    inst = tqdm_notebook()
    inst.display()
    inst.display(msg=None, bar_style=None, check_delay=True)
    inst.display(msg='', pos=None, close=False, bar_style=None, check_delay=True)


# Generated at 2022-06-26 09:48:45.321868
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    assert (tqdm_notebook.display(self, msg=None, pos=None,
                # additional signals
                close=False, bar_style=None, check_delay=True)==0)


# Generated at 2022-06-26 09:48:46.478370
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    var_1 = tqdm_notebook()
    var_1.clear()


# Generated at 2022-06-26 09:49:14.017665
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # Test if the class is recognized by IPython.display
    try:
        from IPython.display import _display_mimetype_map
        assert 'application/json' in _display_mimetype_map
    except ImportError:
        pass  # don't enforce on external systems

    # Experimental test to check if display can be called correctly,
    # and also advances the bar correctly

# Generated at 2022-06-26 09:49:18.857558
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    # test clear
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.clear()


# Generated at 2022-06-26 09:49:25.151774
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    try:
        from unittest.mock import Mock, patch
    except ImportError:
        from mock import Mock, patch

    with patch.object(tqdm_notebook, 'status_printer') as mock_status_printer:
        mock_return_value = Mock()
        mock_status_printer.return_value = mock_return_value
        tqdm_notebook().status_printer()
        mock_status_printer.assert_called_once()


# Generated at 2022-06-26 09:49:34.710351
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    """
    This unit test checks the update method of class tqdm_notebook.
    The test passes if the update method of the tqdm_notebook
    class returns a tqdm_notebook instance.
    """
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.update()
    assert isinstance(tqdm_notebook_1, tqdm_notebook)


# Generated at 2022-06-26 09:49:46.546823
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    # Testing with total = 20, desc = "Desc of tqdm_notebook_1"
    tqdm_notebook_1 = tqdm_notebook.status_printer(total=20, desc="Desc of tqdm_notebook_1")
    assert tqdm_notebook_1.max == 20
    assert tqdm_notebook_1.description == "Desc of tqdm_notebook_1"

    # Testing with total = 24, desc = "Desc of tqdm_notebook_2"
    tqdm_notebook_2 = tqdm_notebook.status_printer(total=24, desc="Desc of tqdm_notebook_2")
    assert tqdm_notebook_2.max == 24

# Generated at 2022-06-26 09:49:51.030080
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    for _ in tqdm(range(100), desc="Testing update method"):
        pass


# Generated at 2022-06-26 09:49:54.381313
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.clear()


# Generated at 2022-06-26 09:49:57.511036
# Unit test for method clear of class tqdm_notebook
def test_tqdm_notebook_clear():
    tqdm_notebook_0 = tqdm_notebook(100000)
    assert tqdm_notebook_0.total == 100000
    tqdm_notebook_0.clear()
    assert tqdm_notebook_0.total == 100000


# Generated at 2022-06-26 09:50:05.137015
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    # Test the most basic function of tqdm_notebook
    with tqdm_notebook(total=1) as t:
        for i in range(1):
            # Currently, it does not really prints.
            pass

# Tests for the method update of class tqdm_notebook

# Generated at 2022-06-26 09:50:19.147824
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_0 = tqdm_notebook()

    tqdm_notebook_0.contaner = "test_string"
    tqdm_notebook_0.n = 1000
    tqdm_notebook_0.ncols = 30
    tqdm_notebook_0.disp("test_string", pos=1000)
    tqdm_notebook_0.disp(close=True, bar_style="test_string", check_delay=True)

    tqdm_notebook_0.ncols = 200
    tqdm_notebook_0.disp("test_string", pos=1000)
    tqdm_notebook_0.disp(close=True, bar_style="test_string", check_delay=True)

    tqdm_notebook

# Generated at 2022-06-26 09:50:49.050920
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm.notebook import tqdm_notebook

    total = 10
    tqdm_iter = tqdm_notebook(desc='Updating tqdm_notebook', total=total)

    for _ in range(total):
        tqdm_iter.update()
    assert tqdm_iter.n == total



# Generated at 2022-06-26 09:51:00.384495
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    tqdm_notebook_0 = tqdm_notebook(1, desc="test")
    for i in tqdm_notebook_0:
        pass

    if isinstance(tqdm_notebook_0.format_dict, dict) == False:
        raise AssertionError("Class tqdm_notebook__iter__(1) assertion error (1)")

    if tqdm_notebook_0.format_dict["desc"] != "test":
        raise AssertionError("Class tqdm_notebook__iter__(1) assertion error (2)")


# Generated at 2022-06-26 09:51:06.952490
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.update()
    tqdm_notebook_0.update(10)
    tqdm_notebook_0.update(10, 30)


# Generated at 2022-06-26 09:51:11.287854
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():

    # create an instance of class TqdmHBox
    tqdm_notebook_1 = tqdm_notebook()

    # call method __repr__ of TqdmHBox on this instance
    r = tqdm_notebook_1.__repr__(pretty=False)

    return r


# Generated at 2022-06-26 09:51:15.474995
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    try:
        tqdm_notebook_0 = tqdm_notebook()
    except:
        assert False
    else:
        assert True


# Generated at 2022-06-26 09:51:21.746190
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    # If a simple call to update works
    try:
        tqdm_notebook_1 = tqdm_notebook()
        tqdm_notebook_1.update(1)
    except Exception:
        # AssertionError if update did not work
        raise AssertionError("tqdm_notebook.update() fails.")


# Generated at 2022-06-26 09:51:32.602446
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from tqdm import tqdm
    from tqdm import tqdm_notebook
    total = 100
    test_tqdm = tqdm(total=total)
    test_tqdm_notebook = tqdm_notebook(total=total)
    for _ in test_tqdm:
        pass
    for _ in test_tqdm_notebook:
        pass
    assert test_tqdm.n == test_tqdm_notebook.n


if __name__ == "__main__":
    test_case_0()

# Generated at 2022-06-26 09:51:35.955334
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    tqdm_notebook_display = tqdm_notebook()
    assert (tqdm_notebook_display.disable == None)


# Generated at 2022-06-26 09:51:42.749521
# Unit test for method update of class tqdm_notebook
def test_tqdm_notebook_update():
    from .pandas import tqdm_pandas

    head = None
    dummy = list(range(100))
    dummy_df = tqdm_pandas(dummy)
    with tqdm_notebook(dummy_df.groupby('test'), leave=True) as t:
        for i in t:
            head = dummy_df.head(5)
            t.update()



# Generated at 2022-06-26 09:51:56.115586
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Setup
    from random import randint
    from .utils import _range

    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.n = 0
    tqdm_notebook_0.total = randint(0, 9223372036854775807)
    tqdm_notebook_0.container = None

    # Testing
    def test_iter(tqdm_notebook_0):
        assert isinstance(tqdm_notebook_0, tqdm_notebook)
        if IPY:
            assert isinstance(tqdm_notebook_0.container, TqdmHBox)
        else:
            assert 'TqdmHBox' not in str(tqdm_notebook_0.container)
        assert tqdm_

# Generated at 2022-06-26 09:53:58.274797
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    with tqdm_notebook(total=100, file=sys.stdout) as pbar:
        for i in range(100):
            pbar.update()
            if i == 50:
                pbar.reset(total=50)


# Generated at 2022-06-26 09:54:07.210019
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():

    # Test when msg is not None and pos is not None and close is not False and bar_style is not None and check_delay is not True
    tqdm_notebook_0 = tqdm_notebook()
    msg = "msg"
    pos = 20
    tqdm_notebook_0.display(msg, pos)

    # Test when msg is None and pos is not None and close is not False and bar_style is not None and check_delay is not True
    msg = None
    tqdm_notebook_0.display(msg, pos)

    # Test when msg is None and pos is None and close is not False and bar_style is not None and check_delay is not True
    pos = None
    tqdm_notebook_0.display(msg, pos)

    # Test when msg is None and pos is None and

# Generated at 2022-06-26 09:54:17.633908
# Unit test for method display of class tqdm_notebook
def test_tqdm_notebook_display():
    # test case 1
    # c = tqdm_notebook_1.container
    # set tqdm_notebook_1.container to something that can be displayed
    tqdm_notebook_1 = tqdm_notebook()
    tqdm_notebook_1.container = tqdm_notebook_1.status_printer(file=sys.stderr)
    # set tqdm_notebook_1.displayed to an initial value
    tqdm_notebook_1.displayed = False
    # call tqdm_notebook_1.disp()
    tqdm_notebook_1.disp(msg="this is a test")
    # c = tqdm_notebook_1.container
    # assert c.children[0].value == "this is a test"
   

# Generated at 2022-06-26 09:54:25.257176
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    """Unit test for method __iter__ of class tqdm_notebook"""
    tqdm_notebook_0 = tqdm_notebook()
    assert [i for i in tqdm_notebook_0.__iter__()] == []


# Generated at 2022-06-26 09:54:28.038929
# Unit test for method __repr__ of class TqdmHBox
def test_TqdmHBox___repr__():
    tqdm_notebook_0 = tqdm_notebook()
    print(tqdm_notebook_0.container)


if __name__ == '__main__':
    test_case_0()
    test_TqdmHBox___repr__()

# Generated at 2022-06-26 09:54:40.224749
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()
    tqdm_notebook_0.reset()

    # Test fields
    assert tqdm_notebook_0.disable == False
    assert tqdm_notebook_0.pbar_factor == 10
    assert tqdm_notebook_0.gui == True
    assert tqdm_notebook_0.interval == 0.5
    assert tqdm_notebook_0.monitor_interval == 100
    assert tqdm_notebook_0.maxinterval == 10
    assert tqdm_notebook_0.mininterval == 0.1
    assert tqdm_notebook_0.miniters == 1
    assert tqdm_notebook_0.n == 0

# Generated at 2022-06-26 09:54:44.447609
# Unit test for method __iter__ of class tqdm_notebook
def test_tqdm_notebook___iter__():
    # Init object
    t = tqdm_notebook()

    # Result
    s = t.__iter__()
    for x in s:
        assert x


# Generated at 2022-06-26 09:54:47.760438
# Unit test for constructor of class tqdm_notebook
def test_tqdm_notebook():
    tqdm_notebook_0 = tqdm_notebook()


if __name__ == '__main__':
    test_case_0()
    test_tqdm_notebook()

# Generated at 2022-06-26 09:54:55.403027
# Unit test for method reset of class tqdm_notebook
def test_tqdm_notebook_reset():
    tqdm_notebook_0 = tqdm_notebook()

    # Test for __init__
    tqdm_notebook_1 = tqdm_notebook(total=9)

    # Test for setter
    tqdm_notebook_1.total = 9

    # Test for reset
    tqdm_notebook_1.reset()


# Generated at 2022-06-26 09:54:59.372257
# Unit test for method status_printer of class tqdm_notebook
def test_tqdm_notebook_status_printer():
    tqdm_notebook(total=10, desc='test', ncols='100px').display()
    tqdm_notebook(total=10, desc='test', ncols='100%').display()
    tqdm_notebook(total=10, desc='test', ncols=100).display()
