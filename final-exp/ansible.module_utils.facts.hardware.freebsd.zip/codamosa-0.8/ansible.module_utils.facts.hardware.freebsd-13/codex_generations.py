

# Generated at 2022-06-11 02:32:58.587109
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert isinstance(FreeBSDHardwareCollector(), HardwareCollector)


# Generated at 2022-06-11 02:33:08.652284
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    harwd = FreeBSDHardware(module)
    facts = harwd.populate()

    assert facts['uptime_seconds'] >= 0
    assert facts['devices']
    assert facts['processor_count'] >= 0
    assert facts['processor_cores'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['memfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['mounts']


from ansible.module_utils.basic import AnsibleModule
if __name__ == '__main__':
    main()

# Generated at 2022-06-11 02:33:19.808846
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import sys

    if sys.version_info[0] == 2:
        # Python2 does not support bytes literal
        bs = lambda s: s.decode('latin1')
    else:
        bs = lambda s: s.encode('latin1')

    def mktime(secs):
        # Function will be monkey-patched in fixtures to mock time.time()
        return secs

    class Test_module:
        """Simple test class to act as "module" object in order to test
        FreeBSDHardware() class."""
        def __init__(self, platform='FreeBSD', encoding='UTF-8'):
            self.platform = platform
            # Needed by self.run_command, in order to properly decode bytes
            # results
            self.encoding = encoding


# Generated at 2022-06-11 02:33:24.981753
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardware
    # Instantiate the FreeBSDHardware class to get a handle to the get_dmi_facts() method
    hw = FreeBSDHardware(None)
    # Run the method get_dmi_facts() to get Platform, Bios facts and Form Factor
    test_dmi_facts = hw.get_dmi_facts()
    assert test_dmi_facts['form_factor'] == 'Tower'

# Generated at 2022-06-11 02:33:38.898272
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True)

# Generated at 2022-06-11 02:33:49.448920
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockModule(object):
        def __init__(self, cmd, rc, out, err):
            self.cmd = cmd
            self.rc = rc
            self.out = out
            self.err = err
            self.run_command_calls = 0

        def get_bin_path(self, arg):
            if arg == 'sysctl':
                return '/sbin/sysctl'
            elif arg == 'swapinfo':
                return '/sbin/swapinfo'
            else:
                raise Exception

        def run_command(self, cmd, encoding=None, check_rc=True):
            self.run_command_calls += 1
            if self.cmd == cmd:
                return self.rc, self.out, self.err

    memory_facts = {}

# Generated at 2022-06-11 02:33:59.816105
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.collector import get_collector
    from ansible.module_utils._text import to_bytes

    collected_facts = {'ansible_collect_subset': ['all'],
                       'ansible_facts': {},
                       'ansible_local': {'collectors': []},
                       'ansible_system_capabilities': {'capabilities': {'system': [], 'privileged': {}}}}
    ansible_facts = dict()
    ansible_facts['ansible_os_family'] = 'FreeBSD'
    collector = get_collector('hardware', collected_facts, ansible_facts)
    collector_facts = collector.collect()

    assert collector_facts['processor_count'] == '1'
    assert collector_facts['processor_cores'] == '4'




# Generated at 2022-06-11 02:34:11.579000
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import unittest

    class fake_module:
        def __init__(self):
            self.run_command = lambda x, encoding=None: (0, struct.pack('=L', 1511930291), '')

        def get_bin_path(self, x):
            if x == 'sysctl':
                return 'sysctl'
            else:
                raise RuntimeError('Unexpected call.')

    # It's 2017-11-23T14:44:51Z in UTC.
    expected_results = {
        'uptime_seconds': 1511930291,
    }

    # Check with a good sysctl output.
    facts = FreeBSDHardware(fake_module())
    results = facts.get_uptime_facts()

    assert results == expected_results



# Generated at 2022-06-11 02:34:23.515784
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    hardware = FreeBSDHardware(basic.AnsibleModule(argument_spec={}))
    hardware.module.run_command = lambda x, **kwargs: (0, 'FreeBSD 12.0-RELEASE-p7 GENERIC amd64', '')
    dmesg_boot = to_bytes(u'CPU: AMD Ryzen 7 1800X Eight-Core Processor (3392.04-MHz K8-class CPU)\nLogical CPUs per core: 1\n')
    with open(FreeBSDHardware.DMESG_BOOT, 'wb') as f:
        f.write(dmesg_boot)

    result = hardware.get_cpu_

# Generated at 2022-06-11 02:34:26.260514
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.populate(False)
    assert hardware.facts['memory_mb']['memtotal_mb'] > 0

# Generated at 2022-06-11 02:34:48.182974
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test case for `FreeBSDHardware.get_cpu_facts()` method.

    :return: None
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Test data to verify the get_cpu_facts method of the FreeBSDHardware class
    input_data = {'processor': [
        'Intel(R) Core(TM) i7-6820HQ CPU @ 2.70GHz',
        'Intel(R) Core(TM) i7-6820HQ CPU @ 2.70GHz'],
        'processor_cores': '2',
        'processor_count': '2',
        'uptime_seconds': 118105.526}
    
    # Call the method passing a mock module and assert the output against the expected data
    freebsd_hardware = FreeBSDHardware(None)


# Generated at 2022-06-11 02:35:01.300670
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self, bin_dir):
            self.bin_dir = bin_dir

        def get_bin_path(self, path):
            return os.path.join(self.bin_dir, path)

        @staticmethod
        def run_command(cmd, encoding=None):
            kern_boottime = int(time.time()) - 123456789
            out = struct.pack('@L', kern_boottime)
            return (0, out, '')

    class MockFactCollector(object):
        def __init__(self):
            self.facts = {}

    # Test that the kern.boottime returns the expected uptime_seconds
    mock_module = MockModule('.')
    mock_facts = MockFactCollector()
    freebsd_hw_

# Generated at 2022-06-11 02:35:11.806032
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    import ansible.module_utils.facts.hardware.freebsd as hardware
    hardware.os = hardware
    hardware.json = hardware
    hardware.os.open = hardware
    hardware.os.path.exists = hardware

    fdi = hardware.FreeBSDHardware()

    # Create test fixture
    fdi.module.get_bin_path = lambda x: None
    fdi.module.run_command = lambda x: ('', 'ada0p3', '')
    fdi.module.run_command.rc = 0
    fdi.module.run_command.out = 'ada0p3\nada0p2\nda0\n'
    fdi.module.run_command.err = ''
    fdi.module.os_path_exists = lambda x: True

    # Call method to test

# Generated at 2022-06-11 02:35:25.704906
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:35:35.767538
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hw = FreeBSDHardware()

    hw._module = MockBSDModule()
    hw._module.run_command.return_value = (0, '2', None)


# Generated at 2022-06-11 02:35:40.531491
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware.module = MockModule()
    hardware.module.run_command = run_command_mock()
    hardware.get_memory_facts()
    for fact in hardware.facts.values():
        assert(fact != 'NA')


# Generated at 2022-06-11 02:35:50.152412
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    sysctl = module.get_bin_path('sysctl')
    rc, out, err = module.run_command("%s vm.stats.vm.v_page_size" % sysctl, check_rc=False)
    pagesize = out.strip()
    rc, out, err = module.run_command("%s vm.stats.vm.v_page_count" % sysctl, check_rc=False)
    pagecount = out.strip()
    rc, out, err = module.run_command("%s vm.stats.vm.v_free_count" % sysctl, check_rc=False)
    freecount = out.strip()
    swapinfo = module.get_bin_path('swapinfo')
    rc,

# Generated at 2022-06-11 02:36:02.198987
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    ''' test the method populate of class FreeBSDHardware

    FreeBSDHardware.populate(self)
    '''
    mod = AnsibleModule(argument_spec=dict())
    mod.get_bin_path = MagicMock(return_value=True)
    mod.run_command = MagicMock(return_value=(0, '', ''))

    fhw = FreeBSDHardware(mod)
    fhw.populate()

    # Assertion: the values of the dict returned by populate() should
    # be identical to the mock values
    assert 'memfree_mb' in fhw.facts
    assert 'memtotal_mb' in fhw.facts
    assert 'swapfree_mb' in fhw.facts
    assert 'swaptotal_mb' in fhw.facts
    assert 'processor' in fhw.facts

# Generated at 2022-06-11 02:36:13.301661
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """ Test FreeBSDHardware get_dmi_facts function with a valid dmidecode executable path.

    The test execute the function get_dmi_facts with a call to a valid dmidecode path
    and check the output is a dict with keys expected.
    """
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # The test call the function get_dmi_facts with a valid dmidecode path
    # and check the output is a dict with keys expected.
    fact_obj = FreeBSDHardware(module)
    dmi_facts = fact_obj.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'product_version' in dmi_facts.keys()


# Generated at 2022-06-11 02:36:18.064843
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    freebsdhw = FreeBSDHardware(module)
    freebsdhw.populate()

    assert freebsdhw.facts.get('uptime_seconds')
    assert freebsdhw.facts['devices']

# Generated at 2022-06-11 02:36:36.264612
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    x = FreeBSDHardwareCollector()
    assert x.platform == 'FreeBSD'
    assert x.fact_class == FreeBSDHardware

# Generated at 2022-06-11 02:36:47.570842
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset = dict(default=['!all'], type='list')
        ),
        supports_check_mode=True
    )

    if not HAS_FREEBSD_HARDWARE:
        module.fail_json(msg="FreeBSD's platform module is required")

    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    for k in ('processor', 'processor_cores', 'processor_count'):
        module.exit_json(ansible_facts={k: cpu_facts[k]})



# Generated at 2022-06-11 02:36:57.411102
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = {}


# Generated at 2022-06-11 02:37:05.590754
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec=dict(
            filter=dict(default=None, required=False),
        ),
        supports_check_mode=True
    )

    if not HAS_DMI_DECODE:
        module.fail_json(msg=missing_required_lib('dmidecode'), exception=DMIDECODE_IMP_ERR)
    if not HAS_DMIDECODE:
        module.fail_json(msg=missing_required_lib('dmidecode'), exception=DMIDECODE_IMP_ERR)

    hardware_object = FreeBSDHardware(module)
    result = hardware_object.get_dmi_facts()

    module.exit_json(ansible_facts=result)


# Generated at 2022-06-11 02:37:09.800359
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils import basic
    # creating a mock for FreeBSDHardware object
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    freebsd_hardware_mock = FreeBSDHardware(module)
    expected_result = {'memtotal_mb': 124264, 'memfree_mb': 103858,
                       'swaptotal_mb': 1000, 'swapfree_mb': 1000}
    actual_result = freebsd_hardware_mock.get_memory_facts()
    assert (expected_result == actual_result)

# Generated at 2022-06-11 02:37:20.025512
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule({}, {}, False)
    module.get_bin_path = lambda x: x
    fhw = FreeBSDHardware(module)


# Generated at 2022-06-11 02:37:22.648486
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc is not None


# Generated at 2022-06-11 02:37:35.012549
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    cmd = 'dmidecode -s'
    expected_cmd = (('dmidecode', '-s'),)

    m = FreeBSDHardware(module)
    m.module.run_command = fake_run_command

    # Missing dmidecode binary
    m.module.get_bin_path = lambda _x: None


# Generated at 2022-06-11 02:37:45.497760
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class module:
        def get_bin_path(self, executable, required=False, opt_dirs=[]):
            if executable == 'dmidecode':
                return 'dmidecode'
            if executable == 'sysctl':
                return 'sysctl'
            return None

        def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace', text=None):
            return (0, '', '')

    test_object = FreeBSDHardware(module)
    result = test_object.get_dmi_facts()
   

# Generated at 2022-06-11 02:37:57.415112
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import ansible.module_utils.facts.processor.freebsd
    import ansible.module_utils.facts.system.freebsd
    import ansible.module_utils.facts.bios.freebsd

    dmi_facts = ansible.module_utils.facts.bios.freebsd.DMIFacts()
    proc_facts = ansible.module_utils.facts.processor.freebsd.ProcessorFacts()
    sys_facts = ansible.module_utils.facts.system.freebsd.SystemFacts()

    fhw = FreeBSDHardware(dmi_facts, proc_facts, sys_facts)
    result = fhw.populate()
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    test_FreeBSDHardware_populate()

# Generated at 2022-06-11 02:38:24.232122
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule({})
    harware_instance = FreeBSDHardware(module)
    ret = harware_instance.populate()
    assert isinstance(ret, dict)
    assert 'mounts' in ret.keys()
    assert 'memtotal_mb' in ret.keys()
    assert 'devices' in ret.keys()
    assert 'uptime_seconds' in ret.keys()
    assert 'processor' in ret.keys()
    assert 'processor_cores' in ret.keys()
    assert 'processor_count' in ret.keys()



# Generated at 2022-06-11 02:38:26.219012
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    hardware.populate()


# Generated at 2022-06-11 02:38:34.956003
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FreeBSDFakeModule():
        @staticmethod
        def run_command(*args, **kwargs):
            class FreeBSDFakeCommandOutput():
                def __init__(self, out, rc=0):
                    self.rc = rc
                    self.err = None
                    self.out = out
                def communicate(self):
                    return self.out, self.err
            return FreeBSDFakeCommandOutput(out, rc)
        @staticmethod
        def get_bin_path(name):
            return name

    out = b'kern.boottime\n{ sec = 1534785966, usec = 135826 } Fri Aug 24 21:19:26 2018'
    fact = FreeBSDHardware().get_uptime_facts()
    assert 'uptime_seconds' not in fact


# Generated at 2022-06-11 02:38:43.802072
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware = FreeBSDHardware(module)
    # Test normal call
    hardware_collector.collect()
    hardware.populate()
    # Test empty return case
    hardware.get_cpu_facts = lambda: {}
    hardware.get_memory_facts = lambda: {}
    hardware.get_uptime_facts = lambda: {}
    hardware.get_dmi_facts = lambda: {}
    hardware.get_device_facts = lambda: {}
    hardware.get_mount_facts = lambda: {}
    hardware.populate()

# Generated at 2022-06-11 02:38:51.329674
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.populate()

    assert hardware.facts['processor']
    assert hardware.facts['processor_cores'] >= 1
    assert hardware.facts['processor_count'] >= 1
    assert hardware.facts['memtotal_mb'] >= 0
    assert hardware.facts['memfree_mb'] >= 0
    assert hardware.facts['swaptotal_mb'] >= 0
    assert hardware.facts['swapfree_mb'] >= 0
    assert hardware.facts['devices']
    assert hardware.facts['uptime_seconds'] >= 0
    assert hardware.facts['devices']
    assert hardware.facts['form_factor']

# Generated at 2022-06-11 02:38:57.898553
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']
    assert facts['devices']
    assert facts['uptime_seconds']
    assert facts['memfree_mb']
    assert facts['memtotal_mb']
    assert facts['swapfree_mb']
    assert facts['swaptotal_mb']



# Generated at 2022-06-11 02:39:05.450182
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = type("module", (object,), {"get_bin_path": lambda self, arg: arg})
    hardware = FreeBSDHardware(module=module)

# Generated at 2022-06-11 02:39:16.815817
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    Hardware = FreeBSDHardware()

    test_cpu_facts = Hardware.get_cpu_facts()
    test_memory_facts = Hardware.get_memory_facts()
    test_uptime_facts = Hardware.get_uptime_facts()
    test_dmi_facts = Hardware.get_dmi_facts()
    # test_device_facts = Hardware.get_device_facts()
    test_mount_facts = Hardware.get_mount_facts()

    test_facts = {}
    test_facts.update(test_cpu_facts)
    test_facts.update(test_memory_facts)
    test_facts.update(test_uptime_facts)
    test_facts.update(test_dmi_facts)
    # test_facts.update(test_device_facts)

# Generated at 2022-06-11 02:39:20.199554
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector = FreeBSDHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert isinstance(collector._fact_class(), Hardware)
    assert collector._platform == 'FreeBSD'


# Generated at 2022-06-11 02:39:29.167119
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, "4", ""))

    hw = FreeBSDHardware(module=module)
    facts = hw.get_cpu_facts()

    module.run_command.assert_called_once_with("sysctl -n hw.ncpu", check_rc=False)
    module.run_command.reset_mock()

    assert type(facts) is dict
    assert 'processor_count' in facts
    assert facts['processor_count'] == '4'


# Generated at 2022-06-11 02:39:53.366230
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())

    hardware_facts = FreeBSDHardwareCollector(module).collect()[0]
    print(json.dumps(hardware_facts))

    assert 'memtotal_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'uptime_seconds' in hardware_facts

# Generated at 2022-06-11 02:40:02.149916
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import pytest

    sysdir = '/fake_dir'
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')

    # Case when /dev isn't a directory
    hw = FreeBSDHardware()
    with pytest.raises(OSError):
        hw.get_device_facts()

    # Case when dirlist is empty
    with pytest.raises(Exception) as excinfo:
        with pytest.raises(OSError):
            hw.get_device_facts()

# Generated at 2022-06-11 02:40:05.752267
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = {}
    fh = FreeBSDHardwareCollector(facts, None)
    assert fh.platform == 'FreeBSD'
    assert fh.fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:40:12.209011
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    before = datetime.datetime.now()
    result = FreeBSDHardware().get_uptime_facts()
    after = datetime.datetime.now()

    assert 'uptime_seconds' in result
    uptime_seconds = int(result['uptime_seconds'])
    assert 0 <= uptime_seconds <= int((after - before).total_seconds())



# Generated at 2022-06-11 02:40:14.390227
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hwc = FreeBSDHardwareCollector()
    assert isinstance(hwc, HardwareCollector)

# Generated at 2022-06-11 02:40:20.462077
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    sample_sysctl_output = (
        b'{ kern.boottime = { sec = 1573394384, usec = 587362 } }\n'
    )
    m = FreeBSDHardware(module=None, timeout=5)
    # pylint: disable=protected-access
    m._raw_uptime_output = sample_sysctl_output
    # pylint: enable=protected-access

    assert(m.get_uptime_facts() == {
        'uptime_seconds': 1573394384,
    })

# Generated at 2022-06-11 02:40:27.419576
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    import os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fhw = FreeBSDHardware()
    print(fhw.get_dmi_facts())
    assert('bios_vendor' in fhw.get_dmi_facts())
    assert('system_vendor' in fhw.get_dmi_facts())


# Generated at 2022-06-11 02:40:38.269275
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # monkey patching module api
    FreeBSDSubject = FreeBSDHardware(None)

    # dmidecode should be in path for this test to work
    dmi_bin = FreeBSDSubject.module.get_bin_path('dmidecode')
    if dmi_bin:
        rc, out, err = FreeBSDSubject.module.run_command(dmi_bin + " -s bios-vendor")
        assert rc == 0, "dmidecode not found in path (%s)" % (dmi_bin)
    else:
        assert False, "dmidecode not found in path (%s)" % (dmi_bin)

    # FreeBSD requires specific facts and they are populated here
    FreeBSDSubject.populate()

    # assert that some facts have been properly populated on FreeBSDHardware class
    assert FreeBSDSub

# Generated at 2022-06-11 02:40:46.979474
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    class MyModule(object):
        def __init__(self):
            self.params = Bunch()
            self.params.bin_path = "/bin"
            self.run_command_environ_update = None

        def get_bin_path(self, name, opt_dirs=[]):
            return "/bin/%s" % name


# Generated at 2022-06-11 02:40:55.736637
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class mockModule:
        def __init__(self):
            self.run_command_statistics = []

        def get_bin_path(self, name, required=False, opt_dirs=[]):
            return '.'

        @staticmethod
        def run_command(command, check_rc=True, data=None, binary_data=False,
                        path_tokens=False, environ_update=None, encoding=None):
            return (0, 'hw.ncpu: 4', '')

    m = mockModule()
    facts = FreeBSDHardware(m)

    assert facts.get_cpu_facts() == {
        'processor': [],
        'processor_count': '4',
        'processor_cores': 'NA'
    }


# Generated at 2022-06-11 02:41:23.841830
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    # Check object
    assert isinstance(FreeBSDHardwareCollector, type)

    # Create test object
    fhc = FreeBSDHardwareCollector()

    # Check object
    assert isinstance(fhc, HardwareCollector)
    assert isinstance(fhc, FreeBSDHardwareCollector)

    # Check attributes
    assert hasattr(fhc, '_fact_class')
    assert hasattr(fhc, '_platform')

    # Check values
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'



# Generated at 2022-06-11 02:41:26.678101
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():  # pylint: disable=invalid-name
    hardware_collector = FreeBSDHardwareCollector()  # pylint: disable=unused-variable
    assert hardware_collector is not None

# Generated at 2022-06-11 02:41:31.194873
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    f = FreeBSDHardware(module)
    result = f.get_cpu_facts()
    assert isinstance(result['processor'], list)
    assert isinstance(result['processor_cores'], int)
    assert isinstance(result['processor_count'], int)


# Generated at 2022-06-11 02:41:35.219193
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Arrange
    module = MockModule()
    cmd = MockCommand(['sysctl', '-b', 'kern.boottime'])
    module.run_command = cmd.run_command

    def get_bin_path(name):
        if name == 'sysctl':
            return '/usr/sbin/sysctl'
        return None
    module.get_bin_path = get_bin_path

    current_time = time.time()
    fake_boot_time = current_time - 36000
    cmd.return_value = (0, struct.pack('@L', int(fake_boot_time)), '')

    # Act
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()

    # Assert
    assert 'uptime_seconds' in uptime_facts


# Generated at 2022-06-11 02:41:38.748841
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    freebsd_hardware = FreeBSDHardware(module)
    freebsd_hardware.populate()
    facts = freebsd_hardware.get_facts()
    assert facts
    assert isinstance(facts, dict)


# Generated at 2022-06-11 02:41:48.416914
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockedModule:
        def __init__(self):
            self.params = {"gather_subset": "!all", "filter": "ansible_memory_mb"}

        def get_bin_path(self, command):
            return command

        def run_command(self, command, check_rc=True, encoding=None):
            if command == "sysctl  -n hw.ncpu":
                return (0, "4", "")

            if command == "sysctl  vm.stats":
                output = """
vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 172264
vm.stats.vm.v_free_count: 30389
"""
                return (0, output, "")


# Generated at 2022-06-11 02:41:58.551441
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:42:05.499557
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleStub(object):
        pass

    module = ModuleStub()
    module.run_command = lambda cmd, encoding=None: (0, struct.pack('@L', int(time.time())), None)
    module.get_bin_path = lambda bin: bin

    facts = FreeBSDHardware(module)
    uptime_facts = facts.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0


# Generated at 2022-06-11 02:42:14.745937
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    result = hardware.populate()
    assert result['devices']['da0'] == ['da0s1a', 'da0s1b', 'da0s2']
    assert result['devices']['da1'] == ['da1s1a', 'da1s1b', 'da1s2']
    assert result['devices']['da2'] == ['da2s1a', 'da2s1b', 'da2s2']
    assert result['devices']['ada0'] == ['ada0s1a', 'ada0s1b', 'ada0s1d', 'ada0s1e', 'ada0s2']

# Generated at 2022-06-11 02:42:24.874849
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """ test class FreeBSDHardware - get_device_facts method"""
    class ModuleMock(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, encoding=None):
            return 0, '', ''

        def get_bin_path(self, path, required=False):
            return path

    class AnsibleModuleMock(object):
        def __init__(self, params):
            self.params = params

        def run_command(self, cmd, encoding=None):
            return 0, '', ''

        def get_bin_path(self, path, required=False):
            return path

    params = {
        'freebsd_sysdir': '/dev'
    }
    module = AnsibleModuleMock(params)