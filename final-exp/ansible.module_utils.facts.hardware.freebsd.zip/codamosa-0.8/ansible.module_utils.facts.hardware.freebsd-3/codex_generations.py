

# Generated at 2022-06-11 02:33:08.652573
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware_obj = FreeBSDHardware(module)
    hardware_facts = hardware_obj.populate()

    assert isinstance(hardware_facts, dict)
    assert isinstance(hardware_facts['processor'], list)
    assert isinstance(hardware_facts['processor_cores'], str)
    assert isinstance(hardware_facts['processor_count'], str)
    assert isinstance(hardware_facts['memtotal_mb'], int)
    assert isinstance(hardware_facts['memfree_mb'], int)
    assert isinstance(hardware_facts['swaptotal_mb'], int)
    assert isinstance(hardware_facts['swapfree_mb'], int)

# Generated at 2022-06-11 02:33:19.808951
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    ''' Unit test for method get_memory_facts of class FreeBSDHardware '''
    module = AnsibleModule(argument_spec={})
    sysctl = module.get_bin_path('sysctl')

    rc, out, err = module.run_command("%s vm.stats" % sysctl, check_rc=False)
    for line in out.splitlines():
        data = line.split()
        if 'vm.stats.vm.v_page_size' in line:
            pagesize = int(data[1])
        if 'vm.stats.vm.v_page_count' in line:
            pagecount = int(data[1])
        if 'vm.stats.vm.v_free_count' in line:
            freecount = int(data[1])

    dut = FreeBSDHardware()

    res_memtotal

# Generated at 2022-06-11 02:33:24.972844
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    fact_value = hardware.get_memory_facts()

    assert isinstance(fact_value, dict), "mod_hardware fact is not of type dict"
    assert 'memtotal_mb' in fact_value, "memtotal_mb fact not present"
    assert 'memfree_mb' in fact_value, "memfree_mb fact not present"


# Generated at 2022-06-11 02:33:26.737959
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    m = FreeBSDHardwareCollector()
    assert m.platform == 'FreeBSD'

# Generated at 2022-06-11 02:33:40.588282
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware._module.run_command = Mock(return_value=(0, "vm.stats.vm.v_page_size: 4096 bytes\nvm.stats.vm.v_page_count: 7782384\nvm.stats.vm.v_wire_count: 8646\nvm.stats.vm.v_active_count: 523199\nvm.stats.vm.v_cache_count: 207400\nvm.stats.vm.v_inactive_count: 2307704\nvm.stats.vm.v_free_count: 2659850\nvm.stats.vm.v_zone_count: 4"))
    assert hardware.get_memory_facts() == {'memtotal_mb': 30287, 'memfree_mb': 2600}


# Generated at 2022-06-11 02:33:50.764988
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    now = int(time.time())

    # No data, no facts
    assert FreeBSDHardware({}).get_uptime_facts() == {}

    # Data with the wrong size, no facts
    r = {'kern.boottime': b'0123456789'}
    assert FreeBSDHardware(r).get_uptime_facts() == {}

    # Data with the right size, but with a bogus value
    r = {'kern.boottime': b'01234567'}
    assert FreeBSDHardware(r).get_uptime_facts() == {}

    # Data with the right size and a correct value
    r = {'kern.boottime': struct.pack('@L', now)}
    facts = FreeBSDHardware(r).get_uptime_facts()
    assert facts['uptime_seconds'] == now

    # Data

# Generated at 2022-06-11 02:34:00.762779
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils._text import to_text
    data = FreeBSDHardware().populate()
    assert 'memfree_mb' in data
    assert 'memtotal_mb' in data
    assert 'swapfree_mb' in data
    assert 'swaptotal_mb' in data
    assert 'uptime_seconds' in data
    assert 'processor' in data
    assert 'processor_cores' in data
    assert 'processor_count' in data
    assert 'devices' in data
    assert to_text(json.dumps({'memfree_mb': data['memfree_mb']})) in to_text(data)
    assert to_text(json.dumps({'memtotal_mb': data['memtotal_mb']})) in to_text(data)

# Generated at 2022-06-11 02:34:05.667973
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector.fact_class == FreeBSDHardware
    assert hardware_collector.fact_class().platform == 'FreeBSD'

# Generated at 2022-06-11 02:34:12.900493
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = type('AnsibleModule', (object,), {
        'get_bin_path': lambda cls: lambda path: path,
        'run_command': lambda path, _: (0, '1599693585.945036', ''),
    })

    hardware_facts = FreeBSDHardware(module)
    uptime_facts = hardware_facts.get_uptime_facts()

    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] == int(time.time()) - 1599693585

# Generated at 2022-06-11 02:34:19.741553
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz', 'Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz']
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-11 02:34:41.689976
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-11 02:34:45.733773
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Test method populate of class FreeBSDHardware'''
    # Create an instance of class FreeBSDHardware
    hardware = FreeBSDHardware()

    # Invoke method populate of class FreeBSDHardware
    hardware_facts = hardware.populate()

    # Test if hardware_facts is empty
    if hardware_facts:
        return hardware_facts

    return False


# Generated at 2022-06-11 02:34:58.240497
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )

    output = ""

    # dmidecode returns bytes, not utf.
    output += '{\n'
    output += '\t"version":\n'
    output += '\t{\n'
    output += '\t\t"string_keyversion" = 0x0,\n'
    output += '\t\t"major_version" = 0x2,\n'
    output += '\t\t"minor_version" = 0x7\n'
    output += '\t},\n'
    output += '\t"current_time": 1580560817,\n'

# Generated at 2022-06-11 02:35:07.638590
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    module.get_bin_path = MagicMock(return_value='/sbin/sysctl')
    module.run_command = MagicMock(return_value=(0, '...', ''))
    module.params = {}

    facts = {}
    facts['ansible_virtualization_role'] = 'guest'
    facts['ansible_virtualization_type'] = 'test_ansible_virtualization_type'

    fsh = FreeBSDHardware(module)
    fsh.populate(facts)

    for attr in ['memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'uptime_seconds']:
        assert hasattr(fsh, attr)


# Generated at 2022-06-11 02:35:15.376418
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def run_command(self, cmd, check_rc=False, encoding=None):
            return 0, '', ''

        def get_bin_path(self, name):
            return '/bin/dmidecode'

    class TestFreeBSDHardware(FreeBSDHardware):
        module = TestModule()

    hardware = TestFreeBSDHardware()
    hardware.get_dmi_facts()

# Generated at 2022-06-11 02:35:28.455415
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Initialize hardware module
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json

    # Initialize FreeBSDHardware class
    hardware = FreeBSDHardware(module)

    # Populate facts
    facts = hardware.populate()

    # Assert that the facts are valid
    assert facts['devices']
    assert facts['memfree_mb'] >= 0
    assert facts['memtotal_mb'] >= 0
    assert facts['processor']
    assert facts['processor_cores'] >= 0
    assert facts['processor_count'] >= 0
    assert facts['swapfree_mb'] >= 0
    assert facts['swaptotal_mb'] >= 0
    assert facts['uptime_seconds'] >= 0
    assert facts['devices']
    assert facts['mounts']

# Generated at 2022-06-11 02:35:39.736139
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Instantiate FreeBSDHardware object
    fhw = FreeBSDHardware()

    # Set value for parameter sysctl
    sysctl = '/sbin/sysctl'

    # Set value for parameter dmesg_boot
    dmesg_boot = ''

    # Call method get_cpu_facts of class FreeBSDHardware
    cpu_facts = fhw.get_cpu_facts()

    # Assert result
    assert cpu_facts == {'processor_cores': '2', 'processor': ['Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz (2394.53-MHz K8-class CPU)', 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz (2394.53-MHz K8-class CPU)']}



# Generated at 2022-06-11 02:35:45.798489
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create a FreeBSDHardware object with the method populate mocked
    freebsd_hardware_obj = FreeBSDHardware()

    # Create a mock_module object to be able to call the method run_command
    mock_module_obj = MagicMock()

    # Create a mock_module object and assign it as the module class attribute of FreeBSDHardware
    freebsd_hardware_obj.module = mock_module_obj

    # Call the method populate
    freebsd_hardware_obj.populate()

    # Assert that the method run_command was called with these arguments
    mock_module_obj.run_command.assert_any_call('sysctl -n hw.ncpu')

# Generated at 2022-06-11 02:35:47.218359
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware({})
    hardware.get_dmi_facts()

# Generated at 2022-06-11 02:35:59.202179
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class HardwareModule(object):
        ''' Class that substitutes AnsibleModule'''
        def __init__(self):
            self.params = None
            self.args = None
            self.fail_json = None
            self.exit_json = None
            self._debug = True
            self.debug = None
            self.check_mode = None
            self.run_command = None
        def get_bin_path(self, name):
            if name == 'dmidecode':
                return 'dmidecode_exec'

    class ModuleExit(Exception):
        ''' Class that substitutes AnsibleModule.exit_json'''
        def __init__(self, *args, **kwargs):
            pass

    class RunCommand(object):
        ''' Class that substitutes AnsibleModule.run_command'''

# Generated at 2022-06-11 02:36:24.565576
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FauxAnsibleModule({})
    # default behavior
    hardware = FreeBSDHardware(module)
    hardware_out = hardware.get_cpu_facts()
    assert hardware_out == {'processor': [], 'processor_count': None, 'processor_cores': None}, 'Default values are wrong'
    # vm.stats behavior
    hardware = FreeBSDHardware(module, {'path': 'fake_path', 'dmesg': None})
    hardware.module.run_command = MagicMock(return_value=(0, 'hw.ncpu: 2', ''))
    hardware.module.get_bin_path = MagicMock(return_value='fake_path')
    hardware_out = hardware.get_cpu_facts()

# Generated at 2022-06-11 02:36:32.493949
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hw = FreeBSDHardware()
    hw._module = AnsibleModuleMock(run_command=get_memory_facts_run_command_mock)
    memory_facts = hw.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 200
    assert memory_facts['memfree_mb'] == 8
    assert memory_facts['swaptotal_mb'] == 20
    assert memory_facts['swapfree_mb'] == 12



# Generated at 2022-06-11 02:36:36.046613
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Ensure that the constructor of class FreeBSDHardwareCollector works
    """

    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'


# Generated at 2022-06-11 02:36:39.007296
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:36:47.569675
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    result = hardware.get_cpu_facts()
    expected = {'processor': ['Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz', 'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz'],
                'processor_cores': '2',
                'processor_count': '2'}
    assert result == expected



# Generated at 2022-06-11 02:36:51.854767
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule({})
    freebsd_hw = FreeBSDHardware(module)

    uptime_facts = freebsd_hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-11 02:36:55.368501
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-11 02:37:04.221656
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    hardware_obj = FreeBSDHardware(module)
    result = hardware_obj.populate()

    assert result.get('memtotal_mb')
    assert result.get('memfree_mb')
    assert result.get('swaptotal_mb')
    assert result.get('swapfree_mb')
    assert result.get('processor')
    assert result.get('processor_cores')
    assert result.get('processor_count')
    assert result.get('devices')
    assert result.get('uptime_seconds')

# Generated at 2022-06-11 02:37:12.478872
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create an instance of FreeBSDHardware
    FH = FreeBSDHardware(dict())
    # Time in seconds since the epoch
    time_seconds_since_epoch = int(time.time())
    # Time in seconds since the epoch and microseconds
    time_seconds_since_epoch_microseconds = [time_seconds_since_epoch, 0]
    # Test raw output of sysctl -b kern.boottime (bytes)
    sysctl_out = struct.pack('@LL', *time_seconds_since_epoch_microseconds)
    # Expected result of method get_uptime_facts
    expected_result = {"uptime_seconds" : time_seconds_since_epoch}
    # Call method get_uptime_facts of class FreeBSDHardware
    result = FH.get_uptime_facts(sysctl_out)


# Generated at 2022-06-11 02:37:17.469392
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bsd_mock = FreeBSDHardware(dict(module=dict(run_command=lambda x, **kwargs: [[0, '', '']])))
    assert bsd_mock.get_cpu_facts() == {'processor': ['Genuine Intel(R) CPU 0000 @ 2.00GHz'], 'processor_count': '1', 'processor_cores': '1'}



# Generated at 2022-06-11 02:37:52.942892
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    result = {
        "processor": ["Intel(R) Core(TM) i3-4010U CPU @ 1.70GHz"],
        "processor_cores": "2",
        "processor_count": "2"
    }
    module = MockModule()
    freebsd_hardware = FreeBSDHardware(module=module)
    assert freebsd_hardware.get_cpu_facts() == result


# Generated at 2022-06-11 02:38:02.140659
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    d = FreeBSDHardware()
    cpu_facts = d.get_cpu_facts()
    assert isinstance(cpu_facts, dict)
    assert 'processor' in cpu_facts
    assert isinstance(cpu_facts['processor'], list)
    assert 'processor_cores' in cpu_facts
    assert isinstance(cpu_facts['processor_cores'], str)
    assert 'processor_count' in cpu_facts
    assert isinstance(cpu_facts['processor_count'], str)



# Generated at 2022-06-11 02:38:07.771560
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware_obj = FreeBSDHardware()
    hardware_obj.module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    dmi_facts = hardware_obj.get_dmi_facts()
    assert dmi_facts
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-11 02:38:19.225289
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fh = FreeBSDHardware()
    dmi_facts = fh.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_vendor' in dmi_facts

# Generated at 2022-06-11 02:38:30.295782
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a new instance of FreeBSDHardware
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)

    # Use a value representing the number of seconds elapsed since the epoch
    # as fake kern.boottime value
    kern_boottime = int(time.time())

    # Use a fake sysctl command that always returns that value when the
    # '-b' option is specified
    def sysctl_mock(command, **kwargs):
        command_args = command[2:]
        if command_args == ['-b', 'kern.boottime']:
            return (0, struct.pack('@L', kern_boottime))

        return (1, '', 'fake error')

    # Patch module.run_command
    module.run_command = sysctl_mock

    # Run the tested method


# Generated at 2022-06-11 02:38:42.631780
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)
    m = 'hw.ncpu'
    hardware.module.run_command = Mock(return_value=(0, '4', None))

# Generated at 2022-06-11 02:38:51.987377
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # The test is done in terms of seconds because
    # the get_uptime_facts method returns seconds.
    # We need to call time.time() before and after
    # the time.sleep() because the time.sleep() may
    # make the before and after values the same.
    freebsdhw = FreeBSDHardware()

    # Simple case
    before = time.time()
    time.sleep(1)
    after = time.time()

    # Wrap the get_uptime_facts method in mock because it uses
    # sysctl with will be unavailable in test environment.
    with mock.patch.object(freebsdhw, 'get_uptime_facts'):
        uptime_seconds = freebsdhw.get_uptime_facts()
    assert(uptime_seconds == int(after - before))

    # More complicated case


# Generated at 2022-06-11 02:39:02.024206
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFailException
    import re
    import traceback


# Generated at 2022-06-11 02:39:10.483437
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts_instance = FreeBSDHardware()
    result = hardware_facts_instance.populate()
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result
    assert 'devices' in result
    assert 'uptime_seconds' in result

# Generated at 2022-06-11 02:39:19.123675
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_device_facts = {}
    test_device_facts['processor'] = ['04:01.0 CPU: QEMU Virtual CPU version 2.0', '05:01.0 CPU: QEMU Virtual CPU version 2.0']
    test_device_facts['processor_cores'] = '1'
    test_device_facts['processor_count'] = '6'
    test_device_facts['memory'] = {'nocache': {'free': 46824, 'used': 157077504, 'total': 157125328},
                                   'real': {'free': 373688, 'used': 100941824, 'total': 104310512},
                                   'swap': {'free': 1509968, 'used': 0, 'total': 1509968}}

# Generated at 2022-06-11 02:40:21.076199
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_res = {}
    mem_res['memtotal_mb'] = 15351
    mem_res['memfree_mb'] = 10243
    mem_res['swaptotal_mb'] = 8191
    mem_res['swapfree_mb'] = 8076

    res = FreeBSDHardware({}).get_memory_facts()
    assert res['memtotal_mb'] == mem_res['memtotal_mb']
    assert res['memfree_mb'] == mem_res['memfree_mb']
    assert res['swaptotal_mb'] == mem_res['swaptotal_mb']
    assert res['swapfree_mb'] == mem_res['swapfree_mb']



# Generated at 2022-06-11 02:40:31.542973
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def run_command(cmd, check_rc=True, encoding=None):
        return (0, pack_boottime(), '')

    def pack_boottime():
        return struct.pack('@L', int(time.time() - 1578658125))

    class TestFreeBSDHardware():
        module = None
        def get_bin_path(self, binary):
            return binary

    hardware = FreeBSDHardware()
    hardware.run_command = run_command
    uptime_facts = hardware.get_uptime_facts()
    if not uptime_facts:
        raise Exception("failed to gather uptime facts")
    if 'uptime_seconds' not in uptime_facts:
        raise Exception("uptime fact 'uptime_seconds' is missing")
    if uptime_facts['uptime_seconds'] < 0:
        raise Exception

# Generated at 2022-06-11 02:40:35.852007
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec = dict(data=dict()))
    module.params['data']['memfree_mb'] = 16384
    hardware = FreeBSDHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memfree_mb'] == 16384



# Generated at 2022-06-11 02:40:45.524373
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, arg):
            if 'dmidecode' in arg:
                return '/usr/sbin/dmidecode'
            return None

        def run_command(self, cmd, encoding=None):
            return (self.rc, self.out, self.err)


# Generated at 2022-06-11 02:40:46.755125
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hc = FreeBSDHardwareCollector()
    assert(isinstance(hc, HardwareCollector))

# Generated at 2022-06-11 02:40:55.911832
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create mock object to simulate the module
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(side_effect=lambda x: x)
    fhw = FreeBSDHardware(module)
    # Get the response from the method
    ret = fhw.populate()
    # Verify content of the response
    assert 'devices' in ret
    assert 'memtotal_mb' in ret
    assert 'memfree_mb' in ret
    assert 'swaptotal_mb' in ret
    assert 'swapfree_mb' in ret
    assert 'processor' in ret
    assert 'processor_cores' in ret
    assert 'processor_count' in ret
    assert 'uptime_seconds' in ret

# Generated at 2022-06-11 02:41:04.864445
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleStub():
        def __init__(self):
            self.params = {}

        def get_bin_path(self, name):
            return os.environ.get(name)

        def run_command(self, args):
            return 1, "", "No dmidecode executable found"

    fhw = FreeBSDHardware(ModuleStub())
    dmi_facts = fhw.get_dmi_facts()
    assert dmi_facts['chassis_asset_tag'] == 'NA'
    assert dmi_facts['chassis_serial'] == 'NA'
    assert dmi_facts['chassis_vendor'] == 'NA'
    assert dmi_facts['chassis_version'] == 'NA'
    assert dmi_facts['form_factor'] == 'NA'

# Generated at 2022-06-11 02:41:14.907687
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from units.modules.utils import set_module_args
    from ansible.module_utils.facts import ansible_facts

    # Create test instance of FreeBSDHardware class
    test = FreeBSDHardware({})
    test.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    sysctl_path = os.path.join(os.sep, 'bin', 'sysctl')
    swapinfo_path = os.path.join(os.sep, 'bin', 'swapinfo')
    sysctl_call_string = "'' 'vm.stats' '' '' {0}".format(sysctl_path)
    swapinfo_call_string = "'' '-k' '' '' {0}".format(swapinfo_path)
    test.module.run_command = MagicM

# Generated at 2022-06-11 02:41:24.038492
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts import fact_collector
    from ansible.module_utils.facts.collector import Collector
    from ansible.module_utils.facts.hardware import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    class TestModule(object):
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            pass

        def run_command(self, *args, **kwargs):
            if args[0] == 'swapinfo -k':
                return (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', '')

# Generated at 2022-06-11 02:41:34.491412
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hw = FreeBSDHardware()
    hw.populate()

    assert hw.facts['uptime_seconds'] > 0
    assert hw.facts['memtotal_mb'] > 0

    mount_el = {'mount': '/',
                'device': '/dev/ada0p2',
                'fstype': 'ufs',
                'options': 'rw',
                'blocks': '51892288',
                'used': '26392584',
                'available': '23449680',
                'capacity': '51%',
                'filesystem': '/'}
    assert hw.facts['mounts'][0] == mount_el

    assert hw.facts['devices'] is not None
    assert 'ada0' in hw.facts['devices']
