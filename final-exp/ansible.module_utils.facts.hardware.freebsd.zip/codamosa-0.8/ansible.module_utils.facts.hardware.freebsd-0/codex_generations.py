

# Generated at 2022-06-11 02:33:08.308736
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Set up a mock module
    class MockModule(object):
        def __init__(self, module_name, platform, param_dict=None, bin_paths=None):
            self._name = module_name
            self._platform = platform
            self._params = param_dict
            self._bin_paths = bin_paths

        def get_bin_path(self, arg, required=False, opt_dirs=[]):
            return '/sbin'


# Generated at 2022-06-11 02:33:19.487925
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """Unit test for method get_uptime_facts of class FreeBSDHardware"""
    class FreeBSDFakeModule(object):
        def __init__(self):
            self.run_command_called = False
            self.run_command_rc = 0
            self.run_command_out = b'\x00\x00\x00\x00\x00\x00\x00\x01\x00\x00\x00\x01\x00\x00\x00\x01'
            self.run_command_err = ''
            self.run_command_encoding = None

        def get_bin_path(self, path, required=True):
            return path

        def run_command(self, cmd, encoding=None):
            self.run_command_called = True
            self.run_command_enc

# Generated at 2022-06-11 02:33:22.489929
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    my_module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(my_module)
    result = hardware.populate()
    # printing result only for unit testing purpose
    print(result)



# Generated at 2022-06-11 02:33:32.364850
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:33:39.576875
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    freebsd = FreeBSDHardware()
    freebsd.module = AnsibleModuleMock()
    freebsd.module.run_command = run_command_mock
    freebsd.module.get_bin_path = get_bin_path_mock
    freebsd.module._socket_path = _socket_path_mock
    assert freebsd._platform == 'FreeBSD'
    freebsd.populate()


# Generated at 2022-06-11 02:33:49.995544
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def _time():
        return 100000

    def _subprocess_check_output(cmd, encoding=None):
        return b'\x00\x00\x00\x00\x00\x00\x00\x00'

    def _subprocess_check(cmd, encoding=None):
        return 0, 'success'

    module_tmp = __import__('ansible.module_utils.facts.hardware.freebsd', globals(), locals(), ['AnsibleModule'], 0)
    module_tmp.AnsibleModule = None
    module = module_tmp.AnsibleModuleMock(exit_json=_subprocess_check)
    module.run_command = _subprocess_check_output
    module.get_bin_path = lambda cmd: cmd

    time.time = _time

    h = Free

# Generated at 2022-06-11 02:34:00.442247
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class ModuleMock:
        def __init__(self):
            self.run_command_counter = 0

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd, check_rc=True):
            self.run_command_counter += 1
            if self.run_command_counter == 1:
                return 0, 'hw.ncpu: 4', None
            elif self.run_command_counter == 2:
                return 0, 'CPU: Intel(R) Core(TM) i7-4600U CPU @ 2.10GHz', None
            elif self.run_command_counter == 3:
                return 0, 'Logical CPUs per core: 2', None

    hardware = FreeBSDHardware(ModuleMock())
    cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-11 02:34:12.291917
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    module.params = {}

    # Populate FreeBSDHardware() object
    hw = FreeBSDHardware(module)
    facts = hw.populate()

    assert isinstance(facts['devices']['da1'], list)
    assert isinstance(facts['devices']['da1'][0], str)
    assert isinstance(facts['mounts'], list)
    assert isinstance(facts['mounts'][0], dict)

    for key in ['memtotal_mb', 'memfree_mb', 'swaptotal_mb', 'swapfree_mb',
                'processor_cores', 'processor_count', 'uptime_seconds']:
        assert isinstance(facts[key], int)


# Generated at 2022-06-11 02:34:16.694958
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    hardware.module = Mock()
    hardware.module.run_command.return_value = ["", "8", ""]

    hardware._get_cpu_facts()
    assert hardware.module.run_command.called_once_with("sysctl -n hw.ncpu")



# Generated at 2022-06-11 02:34:29.218089
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mock_module = MockModule({'sysctl': '/sbin/sysctl'})

# Generated at 2022-06-11 02:34:43.746435
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec={})
    hardware = FreeBSDHardware(module=module)
    result = hardware.get_dmi_facts()
    assert result.get('form_factor') == 'NA'

# Generated at 2022-06-11 02:34:55.530068
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.utils import ModuleFailException

    class MockModule(object):
        def __init__(self, timeval):
            self.timeval = timeval

        def get_bin_path(self, path):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, encoding=None):
            if cmd == ['/usr/bin/sysctl', '-b', 'kern.boottime']:
                return 0, "0x{:08x}".format(self.timeval), ''
            else:
                raise RuntimeError("Not implemented")

    module = MockModule(1490700551)
    hardware = FreeBSDHardware(module=module)

    uptime_facts = hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 16

# Generated at 2022-06-11 02:34:56.781026
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    c = FreeBSDHardwareCollector()

# Generated at 2022-06-11 02:35:00.092624
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fact = FreeBSDHardware()
    device_facts = {'devices': {'ada0': [], 'da0': []}}
    assert fact.get_device_facts() == device_facts

# Generated at 2022-06-11 02:35:08.440995
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class FreeBSDHardware"""
    # Create a mock module, so we don't have to invent a file or print to stdout
    mock_module = type('AnsibleModule', (object,), {
        'get_bin_path': classmethod(lambda cls, arg: '/sbin/sysctl')
    })

    # Create a mock module, so we don't have to invent a file or print to stdout

# Generated at 2022-06-11 02:35:22.764156
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test case with parameter 'sysctl' is missing
    module = MockModule()
    module.get_bin_path.return_value = None

    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] is None
    assert memory_facts['memfree_mb'] is None
    assert memory_facts['swaptotal_mb'] is None
    assert memory_facts['swapfree_mb'] is None

    # Test case with sysctl command executed successfully
    module.get_bin_path.return_value = 'sysctl'

# Generated at 2022-06-11 02:35:33.871767
# Unit test for method get_uptime_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:35:39.984170
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hw = FreeBSDHardware()
    import time
    # The only way of testing FreeBSDHardware.get_uptime_facts() is to
    # monkey-patch the time module.
    def mock_time():
        return 1000000000
    time.time = mock_time
    assert hw.get_uptime_facts() == {'uptime_seconds': 1000000}

# Generated at 2022-06-11 02:35:46.825135
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    host_facts = dict()

    host_facts['ansible_system'] = 'FreeBSD'
    host_facts['ansible_processor_count'] = 2
    host_facts['ansible_memtotal_mb'] = 2048
    host_facts['ansible_swaptotal_mb'] = 512
    host_facts['ansible_devices'] = {
        'ada1': [
            'ada1p1',
            'ada1p2',
        ],
    }
    host_facts['ansible_mounts'] = [
        '/dev/ada1p2 on / (ufs, local)',
        '/dev/ada1p1 on /boot (ufs, local)',
    ]

    freebsd_host_facts = FreeBSDHardware(None).populate()


# Generated at 2022-06-11 02:35:58.958253
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Create a instance of class FreeBSDHardware
    test_instance = FreeBSDHardware()
    # For testing, set the value of _module of test_instance to a MagicMock instance
    test_instance._module = MagicMock()
    # The test result
    test_result = {'processor': [], 'processor_cores': '2', 'processor_count': '4'}

    # Get the value of sysctl from the instance of class AnsibleModule
    sysctl = test_instance._module.get_bin_path.return_value

    # The mock data

# Generated at 2022-06-11 02:36:19.099298
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())

    if hasattr(module, 'set_module_args'):
        # pylint: disable=no-member,no-name-in-module
        module.set_module_args("")
    else:
        module.params = {}
    result = FreeBSDHardware.get_cpu_facts(module)
    assert len(result) == 3
    assert len(result['processor']) > 1
    assert 'processor_cores' in result
    assert 'processor_count' in result


# Generated at 2022-06-11 02:36:24.007382
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware = FreeBSDHardware(module=module)
    uptime = hardware.get_uptime_facts()
    current_time_secs = int(time.time())
    assert uptime['uptime_seconds'] <= current_time_secs

# Generated at 2022-06-11 02:36:35.066593
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test function get_cpu_facts for class FreeBSDHardware
    """
    freebsd_hardware_obj = FreeBSDHardware()
    freebsd_hardware_obj.module = MockModule()
    freebsd_hardware_obj.module.run_command = Mock(return_value=(0, '2', ''))
    cpu_facts_actual = freebsd_hardware_obj.get_cpu_facts()
    cpu_facts_expected = {'processor': ['Intel(R) Core(TM) i3-6100U CPU @ 2.30GHz'],
                          'processor_cores': '2',
                          'processor_count': '2'}
    assert cpu_facts_actual == cpu_facts_expected


# Generated at 2022-06-11 02:36:45.395412
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    result = FreeBSDHardware(module).populate()
    root_device = re.sub(r'(s\d+.*)', '', result['devices'].keys()[0])
    assert result['devices'][root_device][0] == root_device + 'a'  # e.g. sdaa
    assert result['devices'][root_device][0] in result['mounts'][0]['device']  # e.g. /dev/sdaa


# Generated at 2022-06-11 02:36:56.109011
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = DummyAnsibleModule()
    freebsd_hw = FreeBSDHardware(module)

    # test with empty dmesg.boot
    freebsd_hw._module.run_command = mock_run_command([0, 'vm.stats.vm.v_page_size: 4096', 'vm.stats.vm.v_page_count: 2425600', 'vm.stats.vm.v_free_count: 979354'])
    freebsd_hw.swapinfo = mock_swapinfo([0,'Device          1M-blocks     Used    Avail Capacity', '/dev/ada0p3        314368        0   314368     0%'])
    setattr(freebsd_hw, 'read_file', mock_read_file(content=''))
    facts = freebsd_hw.populate()


# Generated at 2022-06-11 02:36:59.689749
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Set up test objects
    module = AnsibleModule(argument_spec={})
    hardware_info = FreeBSDHardware(module)

    # Run method to test
    dmi_facts = hardware_info.get_dmi_facts()

    # Assert results
    for key in dmi_facts.keys():
        assert isinstance(dmi_facts[key], str)

# Generated at 2022-06-11 02:37:09.482118
# Unit test for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:37:19.753300
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    import warnings
    import os
    import sys

    class FakeModule(object):

        def __init__(self):
            self.params = {}

        def get_bin_path(self, exe):
            return exe

        def run_command(self, cmd, check_rc=True, encoding=None):
            if cmd == [exe, '-b', 'kern.boottime']:
                # kern.boottime returns seconds and microseconds as two 64-bits
                # fields, but we are only interested in the first field.
                struct_format = '@L'
                struct_size = struct.calcsize(struct_format)
                current_time = int(time.time())
                return (0, struct.pack(struct_format, current_time), None)

# Generated at 2022-06-11 02:37:33.033924
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    Unit test for FreeBSDHardware.get_uptime_facts()
    '''
    # pylint: disable=W0212
    class Module(object):
        @staticmethod
        def run_command(cmd, encoding='utf-8'):
            ''' mock Module.run_command '''
            return 0, \
                b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', \
                ''
        @staticmethod
        def get_bin_path(exe):
            ''' mock Module.get_bin_path '''
            return sysctl

    facts = FreeBSDHardware(Module())
    uptime_facts = facts.get_uptime_facts()
   

# Generated at 2022-06-11 02:37:43.848022
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # create a fake module with module.run_command as a mock
    module = type('', (object,), { 'run_command': run_command_mock })

    # create a FreeBSDHardware instance
    obj = FreeBSDHardware()
    obj.module = module

    # test valid dmidecode output

# Generated at 2022-06-11 02:38:28.708666
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # On FreeBSD, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    _sysctl_cmd = 'sysctl'
    _cmd = [_sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    _rc, out, _err = 0, b't\x00\x00\x00\x00\x00\x01\\\x10\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    _struct_

# Generated at 2022-06-11 02:38:32.700004
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = FreeBSDHardware()
    assert facts.collect() == {
        'devices': {},
        'processor': [],
        'processor_cores': '0',
        'processor_count': '0',
        'uptime_seconds': 0
    }

# Generated at 2022-06-11 02:38:44.067473
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_module = module_params['FreeBSD']
    test_result = {'uptime_seconds': 1456300}
    test_FreeBSDHardware = FreeBSDHardware(test_module)
    assert test_result == test_FreeBSDHardware.get_uptime_facts()


# Generated at 2022-06-11 02:38:50.286292
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    result = hardware.populate()
    assert('memtotal_mb' in result)
    assert('memfree_mb' in result)
    assert('swapfree_mb' in result)
    assert('swaptotal_mb' in result)
    assert('processor' in result)
    assert('processor_cores' in result)
    assert('processor_count' in result)
    assert('devices' in result)
    assert('uptime_seconds' in result)

# Generated at 2022-06-11 02:39:01.013491
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module_mock = MockModule()
    hardware_mock = FreeBSDHardware(module_mock)

    # Test for FreeBSD 10.3, no swap devices

# Generated at 2022-06-11 02:39:13.013801
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
        Test get_dmi_facts()
    """

    # Example output of dmidecode

# Generated at 2022-06-11 02:39:20.143587
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True,
    )
    bsd_hardware = FreeBSDHardware()
    bsd_hardware.module = module
    uptime_facts = bsd_hardware.get_uptime_facts()

    if not isinstance(uptime_facts, dict) or 'uptime_seconds' not in uptime_facts:
        module.fail_json(msg="Expected a dict containing uptime_seconds")

    if uptime_facts['uptime_seconds'] < 0:
        module.fail_json(msg="uptime_seconds is a negative value, this should not happen")

    uptime_facts = bsd_hardware.get_uptime_facts()

    return uptime_facts



# Generated at 2022-06-11 02:39:30.839728
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hardware = FreeBSDHardware(module)

    hardware.populate()

    # All should work on FreeBSD
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['devices']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['mounts']
    assert hardware.facts['devices']

# Generated at 2022-06-11 02:39:38.949497
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = None
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert 'hardware' in hardware_facts
    assert 'devices' in hardware_facts['hardware']
    assert 'uptime_seconds' in hardware_facts['hardware']
    assert 'memtotal_mb' in hardware_facts['hardware']
    assert 'mounts' in hardware_facts['hardware']
    assert 'processor' in hardware_facts['hardware']
    assert 'system_vendor' in hardware_facts['hardware']

# Generated at 2022-06-11 02:39:44.431373
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake module to load the facts.
    module = AnsibleModule(argument_spec={})
    module.run_command = Mock(return_value=(0, b'\xee\x80\xdeO\x00\x00\x00\x00\x00', None))

    # Initialize the fact class and run the code.
    hardware = FreeBSDHardware(module)
    facts = hardware.get_uptime_facts()

    # Assert that the facts were collected correctly.
    assert facts == {'uptime_seconds': int(time.time() - 421792288)}

# Generated at 2022-06-11 02:41:20.919798
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts import timeout

    # Patching time.time
    time_time_original = time.time
    time.time = lambda: 1234567.89

# Generated at 2022-06-11 02:41:31.195275
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:41:37.667771
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import sys, os
    sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), '../../..'))
    from ansible.module_utils.facts.system.freebsd import fact_subclass

    hardware = fact_subclass.FreeBSDHardware()
    uptime_facts = hardware.get_uptime_facts()
    uptime_seconds = uptime_facts.get('uptime_seconds')
    assert uptime_seconds is not None

# Generated at 2022-06-11 02:41:42.265876
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    gather_subset = [
        '!all',
        '!min',
        'processor',
    ]
    test_FreeBSDHardware = FreeBSDHardware({}, gather_subset)
    result = test_FreeBSDHardware.populate()
    assert result['processor'][0] == 'Intel(R) Core(TM) i7-2600 CPU @ 3.40GHz'



# Generated at 2022-06-11 02:41:51.315116
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    hardware.module = MockModule()
    hardware.module.run_command.return_value = 0, dmesg_boot, ''
    hardware.module.get_bin_path.return_value = 'sysctl'
    hardware.module.run_command.return_value = 0, '4', ''
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '4'
    assert len(cpu_facts['processor']) == 4
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i7-3612QM CPU @ 2.10GHz'
    assert cpu_facts['processor'][1] == 'Intel(R) Core(TM) i7-3612QM CPU @ 2.10GHz'
    assert cpu_

# Generated at 2022-06-11 02:41:55.097187
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    unittest.TestCase.assertEqual(FreeBSDHardware().get_memory_facts,
                                  {'swaptotal_mb': 3071, 'swapfree_mb': 3071, 'memtotal_mb': 7869, 'memfree_mb': 7555})


# Generated at 2022-06-11 02:42:06.705961
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, executable):
            # Just hardcode the sysctl command, which is used in this test
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)

            if cmd[0] == '/sbin/sysctl':
                # Return a fake result
                return 0, b'kern.boottime = { sec = 15000, usec = 0 }\n', ''
            else:
                # Let the test know that an unexpected call was made, so it
                # can detect errors
                return -1, '', ''

    module = MockModule()

# Generated at 2022-06-11 02:42:13.616850
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Run test for this platform
    if os.path.exists('/proc/meminfo'):
        h = FreeBSDHardware()
        h.populate()
        assert h.facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4', 'ada0s5']
        assert h.facts['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4', 'ada1s5']
    else:
        assert True

# Generated at 2022-06-11 02:42:24.627357
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from time import time
    module = type('AnsibleModuleMock', (object,), {'get_bin_path': lambda self, x: x})
    module.run_command = lambda self, x: (0, struct.pack('@L', int(time() - 12345)), '')
    f = FreeBSDHardware()
    f.module = module
    assert f.get_uptime_facts() == {'uptime_seconds': 12345}  # test a simple case

    module.run_command = lambda self, x: (0, '', '')
    assert f.get_uptime_facts() == {}  # test the case where no data was returned

    module.run_command = lambda self, x: (0, 'foo', '')
    assert f.get_uptime_facts() == {}  # test the case where an

# Generated at 2022-06-11 02:42:35.557260
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Construct a "module" which is a fake AnsibleModule with the necessary
    # parameters to run get_uptime_facts of class FreeBSDHardware
    class FakeAnsibleModule:
        def run_command(self, cmd, encoding=None):
            # We don't really need to fake the "module" since
            # get_uptime_facts actually only call get_bin_path, i.e. a
            # dummy "module" is enough to run get_uptime_facts
            return (0, '\xde\xad\xbe\xef', '')
        def get_bin_path(self, cmd, required=False):
            return '/usr/bin/sysctl'
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)
    hardware.get_uptime_facts()
    assert hardware.uptime