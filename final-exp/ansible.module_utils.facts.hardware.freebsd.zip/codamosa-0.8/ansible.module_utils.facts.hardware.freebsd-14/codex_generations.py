

# Generated at 2022-06-11 02:33:05.392022
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Unit test for method populate of class FreeBSDHardware.'''

    # Test with empty input
    fh = FreeBSDHardware({})
    assert fh.populate() == {'devices': {},
                             'processor': [],
                             'uptime_seconds': -1,
                             'system_vendor': 'NA',
                           }

    # Test for normal case
    fh = FreeBSDHardware({'module_setup': True})
    assert fh.populate() is not None


# Generated at 2022-06-11 02:33:16.296397
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = DummyModule()
    freebsd_hardware = FreeBSDHardware(module, 'dummy')
    dmidecode_bin = freebsd_hardware.module.get_bin_path('dmidecode')
    freebsd_hardware.module.params['gather_subset'] = [
        '!all', '!min', 'dmi',
    ]
    # No dmidecode tool => dmi commands will return NA
    assert len(freebsd_hardware.get_dmi_facts()) != 0 and \
        'NA' in freebsd_hardware.get_dmi_facts().values()
    # No dmidecode tool => no DMI_DICT['bios_date'] fact
    assert 'bios_date' not in freebsd_hardware.get_dmi_facts

# Generated at 2022-06-11 02:33:20.346980
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    fact = FreeBSDHardwareCollector(module)
    ansible_facts = fact.populate()
    for key in ansible_facts.keys():
        assert key in FreeBSDHardware.__dict__



# Generated at 2022-06-11 02:33:27.530724
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import unittest
    import ansible.module_utils.facts.system.freebsd.hardware as fbhdw
    import ansible.module_utils.facts.system.freebsd.hardware as fbhdw2
    import ansible.module_utils.facts.system.freebsd.hardware as fbhdw3
    from ansible.module_utils.facts.system.freebsd.hardware import FreeBSDHardware
    from ansible.module_utils.facts.system.freebsd.hardware import FreeBSDHardware
    from ansible.module_utils.facts.system.freebsd.hardware import FreeBSDHardware
    class AnsibleExitJson(Exception):
        """Exception class to be raised by module.exit_json and caught
        by the test case"""
        pass


# Generated at 2022-06-11 02:33:40.936238
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake raw value.
    #
    # kern.boottime is a struct containing two 64-bits fields.
    # The first field is the seconds since epoch, and the second
    # field is the number of microseconds since the epoch.
    #
    # https://github.com/freebsd/freebsd/blob/master/sys/sys/time.h#L86
    #
    # We only care about the first field (the number of seconds
    # since the epoch).

    # 1234 seconds
    expected_result = {
        'uptime_seconds': 1234
    }
    fake_out = b'\x00\x00\x00\x00\x00\x04\xd2\x04\x00\x00\x00\x00'

# Generated at 2022-06-11 02:33:42.779012
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Need more specific unit tests
    facts = {}
    hardware = FreeBSDHardware(facts)

    hardware.populate()

    assert hardware.populate() is not None

# Generated at 2022-06-11 02:33:49.967539
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Tests the get_dmi_facts function of the FreeBSDHardware class """
    (rc, out, err) = os.popen3('dmidecode -s system-product-name')
    dmi_facts_expected = ''.join([line for line in out.readlines() if not line.startswith('#')])
    fhw = FreeBSDHardware()
    dmi_facts_actual = fhw.get_dmi_facts()
    assert dmi_facts_actual['product_name'] == dmi_facts_expected.rstrip()

# Generated at 2022-06-11 02:34:00.398897
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    set_module_args = dict(gather_subset='!all,!any')
    module = basic.AnsibleModule(argument_spec=dict())
    module.params['gather_subset'] = ['!any']
    module.params['timeout'] = 1
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.uptime_seconds > 0
    fh = open(FreeBSDHardware.DMESG_BOOT, 'wb')

# Generated at 2022-06-11 02:34:06.208774
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    facts = FreeBSDHardware()
    try:
        assert facts.get_dmi_facts() is not None
    except NameError:
        assert True
    except Exception:
        assert False


if __name__ == '__main__':
    print(json.dumps(FreeBSDHardware().populate()))

# Generated at 2022-06-11 02:34:14.913791
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)
    data = hardware_obj.get_dmi_facts()
    assert data.get('bios_date') != 'NA'
    assert data.get('bios_version') != 'NA'
    assert data.get('bios_vendor') != 'NA'
    assert data.get('system_vendor') != 'NA'
    assert data.get('product_name') != 'NA'
    assert data.get('product_serial') != 'NA'
    assert data.get('product_version') != 'NA'
    assert data.get('product_uuid') != 'NA'
    assert data.get('chassis_serial') != 'NA'
    assert data.get('chassis_vendor') != 'NA'
   

# Generated at 2022-06-11 02:34:31.272794
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Test FreeBSDHardware.populate() method."""

    module = AnsibleModule(argument_spec=dict())

    hardware = FreeBSDHardware()
    hardware.module = module
    hardware.populate()

    module.exit_json(changed=False, ansible_facts=dict(ansible_device_facts=hardware.facts))



# Generated at 2022-06-11 02:34:43.350979
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeAnsibleModule:
        def __init__(self):
            self.bin_path = {}
            self.bin_path['sysctl'] = '/sbin/sysctl'
        def run_command(self, command, encoding=None):
            # Output of sysctl -b kern.boottimestamp
            # The value is a timestamp in seconds since 1970 (UNIX epoch).
            # Use it to compute the current uptime.
            boottime_struct = 1599852059
            return (0, boottime_struct, '')

    facts = FreeBSDHardware(FakeAnsibleModule())
    uptime = facts.get_uptime_facts()

    # Get the current timestamps as a reference value.
    curr_time = int(time.time())

# Generated at 2022-06-11 02:34:48.891698
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # pylint: disable=protected-access
    hardware = FreeBSDHardware()
    hardware._module = AnsibleModuleMock()
    hardware._module.run_command.return_value = (0, 'hw.ncpu: 2\n', 'some error')

    # test get cpu facts
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-11 02:34:50.729734
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert isinstance(hw, HardwareCollector)

# Generated at 2022-06-11 02:34:55.353950
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhwc = FreeBSDHardwareCollector()
    assert isinstance(fhwc, HardwareCollector)
    assert isinstance(fhwc, FreeBSDHardwareCollector)
    assert fhwc.platform == 'FreeBSD'



# Generated at 2022-06-11 02:35:05.431781
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleStub(object):

        def __init__(self):
            self.bin_path = "/usr/bin/sysctl"

        def get_bin_path(self, path):
            return "/usr/bin/sysctl"

        def run_command(self, cmd, encoding=None):
            return 0, "time.kern.boottime: { sec = 1468873970, usec = 495565 }", ""

    module = ModuleStub()

    fbsd_hardware = FreeBSDHardware(module)
    uptime_facts = fbsd_hardware.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == int(time.time() - 1468873970)



# Generated at 2022-06-11 02:35:13.752173
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    args = dict(
        _ansible_verbosity=4,
        _ansible_no_log=True,
    )
    fh = FreeBSDHardware(module=MockModule(**args))
    dmi_facts = fh.populate()
    assert isinstance(dmi_facts['dmi'], dict)
    assert isinstance(dmi_facts['dmi']['bios_version'], basestring)


# Generated at 2022-06-11 02:35:17.944336
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_facts_collector = FreeBSDHardwareCollector()
    assert hardware_facts_collector.platform == 'FreeBSD'
    assert hardware_facts_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:35:23.370607
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Create an object of FreeBSDHardwareCollector
    """
    my_obj = FreeBSDHardwareCollector()
    assert isinstance(my_obj, FreeBSDHardwareCollector)
    assert isinstance(my_obj._fact_class, FreeBSDHardware)
    assert my_obj._platform == 'FreeBSD'

# Generated at 2022-06-11 02:35:34.297969
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_facts = dict(DFD=dict())

# Generated at 2022-06-11 02:36:08.762450
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    set_module_args(dict(gather_subset='hardware', filter='*'))
    fsystem = FreeBSDHardware(module)
    fsystem.populate()
    assert 'uptime_seconds' in fsystem.facts
    assert 'devices' in fsystem.facts
    assert 'mounts' in fsystem.facts
    assert 'memfree_mb' in fsystem.facts
    assert 'memtotal_mb' in fsystem.facts
    assert 'swapfree_mb' in fsystem.facts
    assert 'swaptotal_mb' in fsystem.facts
    assert 'processor' in fsystem.facts
    assert 'processor_cores' in fsystem.facts
    assert 'processor_count' in fsystem.facts
    assert 'dmi' in fsystem.facts

# Generated at 2022-06-11 02:36:19.281965
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """ test method get_cpu_facts of class FreeBSDHardware """
    # mock module
    module = FakeModule()
    module.run_command = MagicMock(return_value=(0, '16', ''))

    # mock object and call method
    freebsdhardware = FreeBSDHardware(module)

# Generated at 2022-06-11 02:36:24.789210
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = MockModule()

    class TestUptime(object):

        @timeout()
        def get_uptime_facts(self):
            return {'uptime_seconds': int(time.time())}

    f = TestUptime()
    f.module = module
    uptime = f.get_uptime_facts()
    assert uptime['uptime_seconds'] > 0



# Generated at 2022-06-11 02:36:36.500921
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    cpu_facts = {}

    # TODO: Add dummy dmesg content
    dmesg_boot = '\n'.join([
        'CPU: AMD EPYC Processor (3204.00-MHz K8-class CPU)',
        'Origin = "AuthenticAMD"  Id = 0x81808f23  Fam = 0x17  Mod = 0x0',
        'Stepping = 15',
        'CPU: AMD EPYC Processor (3204.00-MHz K8-class CPU)',
        'Origin = "AuthenticAMD"  Id = 0x81808f23  Fam = 0x17  Mod = 0x0',
        'Stepping = 15'
    ])

    hardware = FreeBSDHardware()

    cpu_facts['processor'] = []

# Generated at 2022-06-11 02:36:45.481259
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # pylint: disable=protected-access
    kern_boottime = 1513684516
    out = struct.pack('@L', kern_boottime)
    fake_module = object()
    fake_module.run_command = lambda *args, **kwargs: (0, out, None)
    uptime_facts = FreeBSDHardware(fake_module).get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - kern_boottime)

# Generated at 2022-06-11 02:36:56.142718
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeModule:
        def __init__(self):
            self.exit_args = None
            self.exit_kwargs = None
            self.run_args = None
            self.run_kwargs = None
            self.params = None
            self.fail_json_args = None
            self.fail_json_kwargs = None

        def run_command(self, *args, **kwargs):
            self.run_args = args
            self.run_kwargs = kwargs
            return ('0', '0\n', '')

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs

        def fail_json(self, *args, **kwargs):
            self.fail_json_args = args
            self

# Generated at 2022-06-11 02:37:03.963936
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Setup a mock module
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Create and instance of FreeBSDHardware and run populate()
    hw = FreeBSDHardware(module=module)
    facts = hw.populate()

    # Assert that all created facts are present
    assert 'devices' in facts
    assert 'uptime_seconds' in facts
    assert 'mounts' in facts

    # Assert that the module ran without error
    assert module.exit_json.called


# Generated at 2022-06-11 02:37:06.520434
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    result = FreeBSDHardwareCollector()
    assert result is not None
    assert result.platform == 'FreeBSD'
    assert result.fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:37:13.104251
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_FreeBSDHardware = FreeBSDHardware()
    test_FreeBSDHardware.module = object
    setattr(test_FreeBSDHardware.module, 'get_bin_path', lambda x: '/bin/sysctl')
    test_FreeBSDHardware.module.run_command = lambda x: ['1', 'hw.ncpu: 6', '']
    assert test_FreeBSDHardware.get_cpu_facts()['processor_count'] == '6'



# Generated at 2022-06-11 02:37:17.642424
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem = FreeBSDHardware.get_memory_facts()
    assert type(mem['memtotal_mb']) is int
    assert type(mem['memfree_mb']) is int
    assert type(mem['swaptotal_mb']) is int
    assert type(mem['swapfree_mb']) is int



# Generated at 2022-06-11 02:38:13.121840
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FreeModule:
        def get_bin_path(self, name, required=True, opt_dirs=None):
            return '/usr/bin/sysctl'

        def run_command(self, cmd, encoding=None, check_rc=True, binary_data=False):
            return (0, struct.pack('@L', 1524926550), '')

    class FreeArgs:
        def __init__(self):
            self.timeout = 10

    mock_module = FreeModule()
    mock_args = FreeArgs()

    f = FreeBSDHardware(mock_module, mock_args)
    uptime_facts = f.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - 1524926550)

# Generated at 2022-06-11 02:38:19.851288
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware_obj = FreeBSDHardware(module)
    memory_facts = hardware_obj.get_memory_facts()
    # Test get_memory_facts()
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['memtotal_mb'] >= memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0



# Generated at 2022-06-11 02:38:25.192626
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class FakeModule(object):
        def get_bin_path(self, name):
            dmiPath = "/usr/local/sbin/dmidecode"
            if name == 'dmidecode':
                return dmiPath
            return None

        def run_command(self, args):
            if args[0] == dmiPath:
                return (0, "foo", None)
            return (0, None, None)

    module = FakeModule()
    hw = FreeBSDHardware(module)
    hw.populate()

# Generated at 2022-06-11 02:38:34.495842
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import types
    import sys
    import tempfile
    import subprocess
    # We cannot import module_utils.basic to get the time class
    class time(object):
        class time(object):
            @staticmethod
            def time():
                return 2.5

    # Mock sys.modules
    sys.modules['time'] = time
    sys.modules['os'] = types.ModuleType('os')
    sys.modules['os.path'] = types.ModuleType('os.path')

    # Mock os.path.isfile
    def isfile(path):
        return True
    sys.modules['os.path'].isfile = isfile

    # Mock the open function to return the content of a file
    def open_mock(path, mode):
        if path == '/var/run/dmesg.boot':
            return

# Generated at 2022-06-11 02:38:44.858554
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class AnsibleModuleMock(object):
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, name, opt_dirs=[]):
            return self.bin_path[name]

        def run_command(self, *cmd_args, **kwargs):
            # Format of cmd_args for run_command() is (args, check_rc=True)
            # mock dmidecode does not support -s option, so check for this and return error
            if "-s" in cmd_args[0]:
                # dmidecode not supported
                return (1, "", "dmidecode not supported")

# Generated at 2022-06-11 02:38:53.215501
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_cases = []
    test_cases.append(b'\x00\x00\x00\x00\x00\x00\x00\x00')
    test_cases.append(b'\x00\x00\x00\x00\x00\x00\x00\x01')
    test_cases.append(b'\xff\xff\xff\xff\xff\xff\xff\xff')

    for test_case in test_cases:
        result = FreeBSDHardware.get_uptime_facts.__wrapped__(test_case, None)
        assert 'uptime_seconds' in result
        assert abs(int(time.time()) - result['uptime_seconds']) < 1


if __name__ == '__main__':
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-11 02:38:57.524621
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils._text import to_bytes
    hardware_collector = FreeBSDHardwareCollector()
    hardware_obj = hardware_collector.collect()
    assert isinstance(hardware_obj, FreeBSDHardware)
    assert hardware_obj.platform == FreeBSDHardware._platform
    assert hardware_obj.module.params == {}

# Generated at 2022-06-11 02:39:02.239221
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.platform == 'FreeBSD'
    assert hardware.system == 'FreeBSD'
    assert str(hardware.uptime_seconds).isdigit()
    assert hardware.fstype

# Generated at 2022-06-11 02:39:12.471158
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    hardware = FreeBSDHardware(module)

    out = hardware.get_cpu_facts()

    assert isinstance(out, dict), "get_cpu_facts() did not return a hash"
    assert 'processor' in out, "get_cpu_facts() did not return a hash with the key processor"
    assert 'processor_cores' in out, "get_cpu_facts() did not return a hash with the key processor_cores"
    assert 'processor_count' in out, "get_cpu_facts() did not return a hash with the key processor_count"



# Generated at 2022-06-11 02:39:17.886965
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    hardware = FreeBSDHardware(module)

    facts = hardware.populate()

    # check whether some of the facts are available
    if facts:
        assert 'processor' in facts
        assert 'processor_count' in facts
        assert 'processor_cores' in facts
    else:
        assert False, "'get_cpu_facts' failed to get facts"


# Generated at 2022-06-11 02:40:53.784815
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dmi_data = {}
    dmi_data['BIOS Information'] = "Handle 0x0000, DMI type 0, 24 bytes\n"

# Generated at 2022-06-11 02:41:02.845984
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # We don't have access to module fail_json in this test file.
    def fail_json(*args, **kwargs):
        pass
    module = type('', (object,), {'fail_json': fail_json})


# Generated at 2022-06-11 02:41:08.032683
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    cpu_facts = hardware.get_cpu_facts()
    # Assert that the correct number of processors is found
    assert len(cpu_facts['processor']) == int(cpu_facts['processor_count'])
    # Assert that the processor name contains 'CPU'
    assert cpu_facts['processor'][0].startswith('CPU')



# Generated at 2022-06-11 02:41:18.937249
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    FACTS = {}
    FACTS['devices'] = {}
    FACTS['devices']['ada0'] = ['ada0s1a', 'ada0s1b', 'ada0s1e', 'ada0s1d', 'ada0s1f']
    FACTS['devices']['ada1'] = ['ada1s1a', 'ada1s1b', 'ada1s1e', 'ada1s1d', 'ada1s1f']
    FACTS['devices']['ada2'] = ['ada2s1a', 'ada2s1b', 'ada2s1e', 'ada2s1d', 'ada2s1f']

# Generated at 2022-06-11 02:41:23.123399
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = 'test'
    m = FreeBSDHardware(module=module)
    facts = m.populate()
    facts_keys = facts.keys()
    # Only testing for a few keys, as to not be brittle in the face of changes
    assert 'devices' in facts_keys
    assert 'uptime_seconds' in facts_keys

# Generated at 2022-06-11 02:41:26.058536
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)
    out = hardware.get_memory_facts()
    assert out['memtotal_mb'] > 0
    assert out['memfree_mb'] >= 0

# Generated at 2022-06-11 02:41:33.152791
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Create a instance of class FreeBSDHardwareCollector
    my_obj = FreeBSDHardwareCollector()
    my_obj.collect()
    # Asserting the name of platform that class FreeBSDHardwareCollector is for
    assert my_obj.platform == 'FreeBSD'
    # Asserting the name of fact_class that class FreeBSDHardwareCollector is for
    assert my_obj.fact_class == FreeBSDHardware
    # Asserting the platform of class FreeBSDHardware that class FreeBSDHardwareCollector is for
    assert my_obj.fact_class._platform == 'FreeBSD'

# Generated at 2022-06-11 02:41:42.571518
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-11 02:41:51.484055
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # init vars
    FACT_DATA = { 'devices':{}, 'processor_cores':'2', 'processor_count':'2', 'processor':['Intel(R) Core(TM)2 Quad CPU     Q8400  @ 2.66GHz', 'Intel(R) Core(TM)2 Quad CPU     Q8400  @ 2.66GHz'], 'memfree_mb':'339', 'memtotal_mb':'2048', 'swapfree_mb':'40966', 'swaptotal_mb':'40966', 'uptime_seconds':'2820' }

# Generated at 2022-06-11 02:42:02.856171
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockModule()
    hardware = FreeBSDHardware(module)

    cpu_facts = hardware.get_cpu_facts()
    memory_facts = hardware.get_memory_facts()
    uptime_facts = hardware.get_uptime_facts()
    dmi_facts = hardware.get_dmi_facts()
    device_facts = hardware.get_device_facts()

    fsmap = hardware.get_mount_facts()

    hardware.populate()

    assert hardware.populated

    for key in cpu_facts:
        assert cpu_facts[key] == hardware.ansible_facts[key]

    for key in memory_facts:
        assert memory_facts[key] == hardware.ansible_facts[key]

    for key in uptime_facts:
        assert uptime_facts[key] == hardware.ansible_