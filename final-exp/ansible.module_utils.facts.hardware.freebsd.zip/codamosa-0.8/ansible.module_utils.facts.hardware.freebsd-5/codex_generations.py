

# Generated at 2022-06-11 02:33:08.823392
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:33:19.897408
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create a class for testing
    class AnsibleModule:
        def get_bin_path(self, arg):
            return '/sbin/sysctl'


# Generated at 2022-06-11 02:33:27.278731
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware as cls
    import pytest
    fact = cls()

    mock_exists = lambda x: x == '/var/run/dmesg.boot'
    mock_get_file_content = lambda x: ' '

    mock_run_command_rc0 = lambda x, encoding=None: (0, "249\n", '')
    mock_run_command_rc1 = lambda x, encoding=None: (1, "", '')

    def mock_get_bin_path(name):
        if name == 'sysctl':
            return 'sysctl'
        if name == 'dmidecode':
            return 'dmidecode'

    fact.get_bin_path = mock_get_bin_path
    fact.module.run_command

# Generated at 2022-06-11 02:33:40.414910
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.timeout import get_timeout
    from ansible.module_utils.facts.utils import FactsFiles

    module = DummyModule()
    facts_files = FactsFiles(module=module)

    h = FreeBSDHardware(module=module, facts_files=facts_files)
    uptime = h.get_uptime_facts()
    # We need to test that the uptime is not too far in the past.
    # Hence, we use a margin of at least half of the timeout setting.
    min_uptime_secs = time.time() - get_timeout() // 2

    assert isinstance(uptime, dict)
    assert 'uptime_seconds' in uptime
    assert uptime['uptime_seconds'] > min_uptime_secs



# Generated at 2022-06-11 02:33:45.077558
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    har = FreeBSDHardware(module=module)

    cpu_facts = har.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-11 02:33:52.915750
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    m = None
    global_args = {}
    global_args['gather_subset'] = ['all']
    global_args['gather_timeout'] = 10
    global_args['filter'] = '*'
    # Create instance of FreeBSDHardware
    freebsd_hw_fact_instance = FreeBSDHardware(m, global_args)

    # Populate freebsd_hw_fact_instance
    collected_facts = freebsd_hw_fact_instance.populate()

    if 'ansible_facts' in collected_facts:
        # ansible_facts must be a dict
        assert isinstance(collected_facts['ansible_facts'], dict)
        # Test bios_date
        bios_date = collected_facts['ansible_facts']['bios_date']
        assert bios_date != 'NA'
       

# Generated at 2022-06-11 02:33:58.859496
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    module = mock.MagicMock()
    module.get_bin_path.return_value = None
    freebsd_hardware = FreeBSDHardware(module)
    cpu_facts = freebsd_hardware.get_cpu_facts()
    assert cpu_facts == {}
    # Can't test on FreeBSD because you can't create a process


# Generated at 2022-06-11 02:34:10.899615
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    f1 = open('/home/ansible/ansible_repo/test/unit/module_utils/facts/hardware/freebsd/vm_stats', 'r')
    out = f1.read()
    f1.close()
    f2 = open('/home/ansible/ansible_repo/test/unit/module_utils/facts/hardware/freebsd/swapinfo', 'r')
    out2 = f2.read()
    f2.close()

    class temp:
        def __init__(self):
            self.run_command_count = 0

        def run_command(self, args, check_rc=False, encoding=None):
            if self.run_command_count == 0:
                self.run_command_count += 1
                return (0, out, '')


# Generated at 2022-06-11 02:34:15.951913
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    assert hardware.get_cpu_facts() == {'processor': [
        'Intel(R) Core(TM) i7-4558U CPU @ 2.80GHz (2800.06-MHz K8-class CPU)'], 'processor_cores': '2', 'processor_count': '4'}


# Generated at 2022-06-11 02:34:28.488638
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' Test get_dmi_facts of FreeBSDHardware class by mocking data'''
    from mock import patch, MagicMock
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes

    # Test fixture

# Generated at 2022-06-11 02:34:52.785580
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fb = FreeBSDHardware()

    dmi_facts = fb.get_dmi_facts()
    assert dmi_facts is not None
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'chassis_asset_tag' in dmi_facts
    assert 'chassis_serial' in dmi_facts
    assert 'chassis_vendor' in dmi_facts

# Generated at 2022-06-11 02:35:04.377369
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """Unit test for method `get_device_facts` of class `FreeBSDHardware`

    :return:
        None
    """
    import unittest
    import sys
    import shutil

    if sys.version_info < (2, 7):
        import unittest2 as unittest

    from tempfile import mkdtemp
    from ansible.module_utils.facts.facts.hardware.freebsd import FreeBSDHardware

    # Create a test directory
    tempdir = mkdtemp()


# Generated at 2022-06-11 02:35:18.251116
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts.get('system_vendor') != 'NA'
    assert dmi_facts.get('product_name') != 'NA'
    assert dmi_facts.get('product_serial') != 'NA'
    assert dmi_facts.get('product_version') != 'NA'
    assert dmi_facts.get('form_factor') != 'NA'
    assert dmi_facts.get('bios_vendor') != 'NA'
    assert dmi_facts.get('bios_version') != 'NA'
    assert dmi_facts.get('bios_date') != 'NA'

# Generated at 2022-06-11 02:35:30.611560
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    sys_arch = 'x86_64'
    bios_date = '06/14/2016'
    bios_vendor = 'American Megatrends Inc.'
    bios_version = '3.11'
    board_asset_tag = 'Not Specified'
    board_name = 'Z87-PRO'
    board_serial = 'MS2B0E1661574'
    board_vendor = 'ASUSTeK COMPUTER INC.'
    board_version = 'Rev 1.xx'
    chassis_asset_tag = 'Asset-1234567890'
    chassis_serial = 'SER234567890'
    chassis_vendor = 'Chassis Manufacture'
    chassis_version = 'Chassis Version'
    form_factor = 'Desktop'
    product_name = 'P8Z87-PRO'


# Generated at 2022-06-11 02:35:37.238998
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_input = {
        'module': {
            'get_bin_path': lambda x: '/usr/bin/sysctl',
            'run_command': lambda x, check_rc=True: ('', u'4\n', '')
        }
    }
    test_hardware = FreeBSDHardware(test_input)
    test_output = test_hardware.get_cpu_facts()
    assert test_output['processor_count'] == '4'

# Generated at 2022-06-11 02:35:40.362793
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MagicMock()

    m = FreeBSDHardware(module)

    m.get_memory_facts()



# Generated at 2022-06-11 02:35:46.221155
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    dh = FreeBSDHardware()
    cpu_facts = dh.get_cpu_facts()

    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '2'


# Generated at 2022-06-11 02:35:50.452533
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/sysctl'
    module.run_command.return_value = (0, BIN_SYSCTL_BIN_VALUES, '')

    test_obj = FreeBSDHardware(module=module)

    expected_uptime_seconds = 1549473868
    assert expected_uptime_seconds == test_obj._uptime_seconds


# Generated at 2022-06-11 02:35:56.975738
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    freebsd = FreeBSDHardware()
    freebsd.module = module
    module.get_bin_path = lambda x: "/usr/sbin/dmidecode"
    dmi_facts = freebsd.get_dmi_facts()
    assert dmi_facts['product_uuid'] == "NA"
    assert dmi_facts['system_vendor'] == "NA"



# Generated at 2022-06-11 02:36:04.291128
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # The FreeBSD boot time is retrieved by sysctl(8).
    # In order to not depend on the actual system, we force the boot time.
    class ModuleMock(object):
        def __init__(self):
            self.run_command_expect = {
                '/sbin/sysctl -b kern.boottime': (0, b'123 456\n'),
                '/bin/ls *': (0, ''),
            }
            self.run_command_actual = {}

        def get_bin_path(self, arg, *args, **kwargs):
            return arg

        def run_command(self, arg, *args, **kwargs):
            self.run_command_actual[arg] = True

# Generated at 2022-06-11 02:36:37.587771
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock(platform='FreeBSD')

    HardwareCollector._collectors['FreeBSD'] = FreeBSDHardwareCollector

    facts = FreeBSDHardware(module).populate()

    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-11 02:36:42.502513
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    mod = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(mod)
    facts = fhw.populate()
    assert type(facts) == dict
    assert 'processor' in facts
    assert type(facts['processor']) == list


# Generated at 2022-06-11 02:36:54.708657
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-11 02:37:05.109475
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fixture = dict()
    facts = dict()
    for key in ['product_uuid', 'product_name', 'product_vendor', 'product_version', 'product_serial',
                'system_vendor', 'board_asset_tag', 'board_vendor', 'board_version', 'board_serial',
                'board_name', 'chassis_asset_tag', 'chassis_vendor', 'chassis_version', 'chassis_serial',
                'form_factor', 'bios_vendor', 'bios_version', 'bios_date']:
        fixture[key] = 'NA'

    module = DummyModule()
    freebsd_hardware = FreeBSDHardware(module)
    for key in fixture.keys():
        facts[key] = fixture[key]

# Generated at 2022-06-11 02:37:06.051811
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware = FreeBSDHardwareCollector()
    assert isinstance(hardware, FreeBSDHardwareCollector)

# Generated at 2022-06-11 02:37:16.944073
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:37:23.465570
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    facts = FreeBSDHardware()
    fact = facts.get_memory_facts()

    assert fact['swaptotal_mb'] > 0
    assert fact['swapfree_mb'] > 0
    assert fact['memtotal_mb'] > 0
    assert fact['memfree_mb'] > 0


# Generated at 2022-06-11 02:37:27.367780
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Test constructor of class FreeBSDHardwareCollector
    """
    facts = FreeBSDHardwareCollector()
    assert isinstance(facts, HardwareCollector)



# Generated at 2022-06-11 02:37:32.778646
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Testing the get_cpu_facts method of class FreeBSDHardware
    """
    test_obj = FreeBSDHardware(None)
    cpu_facts = test_obj.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-11 02:37:38.196650
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())

    # test with binary dmidecode available
    os.environ['PATH'] = '/usr/sbin:/sbin:/usr/bin:/bin'
    fhw = FreeBSDHardware()

    # testing code for the case where we can't use dmidecode
    os.environ['PATH'] = ''
    fhw = FreeBSDHardware()

# Generated at 2022-06-11 02:38:42.248426
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_args = []
            self.run_command_rcs = []
            self.run_command_exceptions = []
            self.run_command_out = []
            self.run_command_all_rc = []

        def get_bin_path(self, path, required=False):
            return None

        def run_command(self, args, check_rc=True, data=None, binary_data=False, buffer=None, executable=None,
                        cwd=None, path_prefix=None, use_unsafe_shell=False, propagate_ctlc=False, run_in_check_mode=False,
                        environ_update=None, encoding=None, errors='surrogate_or_strict'):
            self

# Generated at 2022-06-11 02:38:43.588916
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector.collect() == FreeBSDHardware().populate()

# Generated at 2022-06-11 02:38:45.632318
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhwc = FreeBSDHardwareCollector()
    assert fhwc.get_platform() == 'FreeBSD'

# Generated at 2022-06-11 02:38:50.768289
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    hardware.module.run_command = lambda x: ("", "hw.ncpu: 2\r\n", "")
    hardware.module.get_bin_path = lambda x: ("")
    result = hardware.get_cpu_facts()
    assert result == {'processor': [],
                      'processor_cores': 'NA',
                      'processor_count': '2'}


# Generated at 2022-06-11 02:39:01.487447
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake class to use with monkey patch.
    class FakeModule(object):
        def get_bin_path(self, name):
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            # Return an older uptime but still less than 2**48.
            return (0, struct.pack('@L', 2**40), '')

    # Use the fake module to create a FreeBSDHardware instance.
    module = FakeModule()
    facts = FreeBSDHardware(module).get_uptime_facts()

    # Test the output of the method.
    assert 'uptime_seconds' in facts
    assert facts['uptime_seconds'] >= 2**40
    assert facts['uptime_seconds'] < 2**48
    assert isinstance(facts['uptime_seconds'], int)

# Generated at 2022-06-11 02:39:04.664893
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware({})

    # Check 1: uptime_seconds should be an integer strictly positive
    uptime_seconds = m.get_uptime_facts()['uptime_seconds']
    assert uptime_seconds > 0 and isinstance(uptime_seconds, int)

# Generated at 2022-06-11 02:39:16.493557
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Read file /var/run/dmesg.boot to a list
    with open('/var/run/dmesg.boot') as f:
        output = f.readlines()
    assert output[0] == 'Copyright (c) 1992-2016 The FreeBSD Project.\n'

    # Call constructor of class FreeBSDHardwareCollector
    ah = FreeBSDHardwareCollector()
    assert ah.platform == 'FreeBSD'

    # Call function get_cpu_facts()
    ah.module.params = {'timeout': 1}
    ah.get_cpu_facts()
    ah.module.params = {'timeout': None}
    ah.get_cpu_facts()
    ah.module.params = {'timeout': 0}
    ah.get_cpu_facts()
    ah.module.params = {'timeout': 30}
    ah

# Generated at 2022-06-11 02:39:28.586492
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Create a class instance named 'freebsd_hardware'
    freebsd_hardware = FreeBSDHardware(dict())

    # Set the sysctl executable module path
    freebsd_hardware.module.get_bin_path = lambda x: '/usr/bin/sysctl'

    # Set the sysctl command output

# Generated at 2022-06-11 02:39:37.503670
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fake_module = type('', (), dict(exit_json=lambda self, **kwargs: True,
                                    fail_json=lambda self, **kwargs: True,
                                    run_command=lambda self, **kwargs: True,
                                    get_bin_path=lambda self, **kwargs: True,
                                    check_mode=False,
                                    changed=False))
    memory_facts = FreeBSDHardware(fake_module).get_memory_facts()
    assert 'memfree_mb' in memory_facts
    assert 'memtotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts


# Generated at 2022-06-11 02:39:44.055781
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    facts = {'module_setup': True}
    m = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Mock module
    m.get_bin_path = MagicMock(return_value='/bin/true')
    m.run_command = MagicMock(return_value=(0, '', ''))
    # Instantiate Hardware
    fhw = FreeBSDHardware(m)
    # Run method
    uptime_facts = fhw.get_uptime_facts()
    # Test output
    assert uptime_facts['uptime_seconds'] >= 0


# Generated at 2022-06-11 02:41:35.613961
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Note: we use the 'freebsd' platform here because the get_cpu_facts()
    # method doesn't depend on any platform-specific facts.
    fhw_module = FreeBSDHardware({'ANSIBLE_MODULE_ARGS': {}})
    assert fhw_module.get_cpu_facts() == get_cpu_facts_expected()



# Generated at 2022-06-11 02:41:44.659112
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = Command()

    # Construct the class under test
    hardware = FreeBSDHardware(module)

    # Test a successful command
    module.run_command = MagicMock(return_value=(0, b'a\x00\x00\x00', None))
    rc, out, err = module.run_command = MagicMock(return_value=(0, b'\x12\x34\x56\x78\x9a\xbc\xde\xf0', None))
    assert hardware.get_uptime_facts() == {'uptime_seconds': 134120792}

    # Test a command that fails
    module.run_command = MagicMock(return_value=(1, None, 'Some error'))
    assert hardware.get_uptime_facts() == {}

# Generated at 2022-06-11 02:41:50.401106
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    h = Hardware()
    h._module = DummyModule()
    h.module.run_command = run_command_mock
    result = h.get_memory_facts()
    assert result == {'memtotal_mb': 1048576, 'memfree_mb': 838860, 'swaptotal_mb': 1048576, 'swapfree_mb': 1048576}
    assert h.module.run_command.call_count == 2


# Generated at 2022-06-11 02:42:01.732162
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    Test to see if method get_uptime_facts of class FreeBSDHardware
    works as intended.
    '''

    class FakeModule(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

    class FakeProcess(object):
        def __init__(self):
            self.returncode = 0
            self.stdout = b'kern.boottime: { sec = 1581125554, usec = 875922 } Sat Feb  1 15:59:14 2020\n'


# Generated at 2022-06-11 02:42:12.077182
# Unit test for method get_device_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:42:23.374170
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)

    dmi_facts = hardware_obj.get_dmi_facts()
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'chassis_asset_tag' in dmi_facts
    assert 'chassis_serial' in dmi_facts
    assert 'chassis_vendor' in dmi_facts

# Generated at 2022-06-11 02:42:26.637367
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Unit test for constructor of class FreeBSDHardwareCollector
    """
    obj = FreeBSDHardwareCollector()
    assert obj._fact_class == FreeBSDHardware
    assert obj._platform == 'FreeBSD'
    assert not hasattr(obj, 'module')

# Generated at 2022-06-11 02:42:37.079169
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for populate method of FreeBSDHardware class
    '''
    module = AnsibleModule(
        argument_spec=dict(
            gather_subset=dict(type='list', default=['!all'])
        ),
        supports_check_mode=True
    )

    warn_msg = [
        'dmesg command is not available',
        'swapinfo command is not available',
        'sysctl is not available',
    ]

# Generated at 2022-06-11 02:42:38.670460
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhw = FreeBSDHardwareCollector()
    assert fhw is not None
    assert fhw._platform == 'FreeBSD'


# Generated at 2022-06-11 02:42:47.479916
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    with open(FreeBSDHardware.DMESG_BOOT, 'rb') as dmesg_boot:
        contents = dmesg_boot.read()
    fbsdhw = FreeBSDHardware()
    ufacts = fbsdhw.get_uptime_facts()
    logtime_str = re.search(r'^Bootup\s+:\s+(.*)$', contents, re.MULTILINE).group(1)
    upsec = int(time.time() - int(time.mktime(time.strptime(logtime_str, '%b %d, %Y %I:%M:%S %p %Z'))))