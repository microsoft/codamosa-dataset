

# Generated at 2022-06-11 02:33:00.877868
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    freebsd_hardware_collector = FreeBSDHardwareCollector()
    assert type(freebsd_hardware_collector).__name__ == 'FreeBSDHardwareCollector'


# Generated at 2022-06-11 02:33:06.042106
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """Test class FreeBSDHardwareCollector"""

    # Test FreeBSDHardwareCollector class constructor
    hw = FreeBSDHardwareCollector()
    # is subclass
    assert isinstance(hw, HardwareCollector)
    # platform
    assert hw.platform == 'FreeBSD'
    # fact_class
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-11 02:33:12.590797
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class MockModule:
        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, check_rc=True):
            return 0, "", ""

    m = MockModule()
    h = FreeBSDHardware(m)
    cpu_facts = h.get_cpu_facts()
    assert cpu_facts == {
        'processor': [],
        'processor_count': '',
        'processor_cores': ''
    }


# Generated at 2022-06-11 02:33:22.739518
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Given:
    #   A mocked module
    #   An instance of FreeBSDHardware class
    #   A mocked file containing 1 CPU
    #   A mocked file containing 2 cores
    _module = type('', (), {'get_bin_path': lambda _, path, *args, **kwargs: None, 'run_command': lambda _, *args, **kwargs: (0, 'dummy', '')})()
    _instance = FreeBSDHardware(_module, timeout=5)
    _mocked_dmesg_boot = "/* CPU: dummy\n /* Logical CPUs per cores: 2\n"
    _original_get_file_content = FreeBSDHardware.get_file_content

    # When:
    #   We try to get CPU facts from mocked dmesg file

# Generated at 2022-06-11 02:33:32.542948
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Unit tests for FreeBSDHardware class
    """
    cpu_facts = {
        'processor': ['Intel(R) Core(TM) i5-2540M CPU @ 2.60GHz (2600.09-MHz K8-class CPU)'],
        'processor_cores': '1',
        'processor_count': '2'
    }

# Generated at 2022-06-11 02:33:35.518848
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'

# Generated at 2022-06-11 02:33:46.865801
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''Unit test for method get_cpu_facts of class FreeBSDHardware'''
    # Note : this test code assume the platform is FreeBSD
    if os.uname()[0] != 'FreeBSD':
        print("Skip this test code")
        return

    # The following data is copied from the output of dmesg.
    # (dmesg | grep 'CPU:' | sed -e 's/^[^:]*: //g' | grep -v '^CPU')

# Generated at 2022-06-11 02:33:48.629757
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware({'module': None})
    hardware.get_uptime_facts()

# Generated at 2022-06-11 02:33:53.340750
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    from ansible.module_utils.facts import stubs
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    hardware = FreeBSDHardware(stubs.StubModule())
    device_facts = hardware.get_device_facts()

    assert device_facts == {}

# Generated at 2022-06-11 02:34:02.359192
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    frebsdhwobj = FreeBSDHardware()
    sysctl_cmd = frebsdhwobj.module.get_bin_path('sysctl')
    sysctl_cmd = sysctl_cmd + " -b kern.boottime"
    import subprocess
    rc = 0
    out = "kern.boottime = { sec = 1536862416, usec = 0 }"
    err = None
    if err is None:
        err = ""
    frebsdhwobj.module.run_command = lambda x, encoding=None: (rc, out, err)
    uptime_facts = frebsdhwobj.get_uptime_facts()
    assert(uptime_facts['uptime_seconds'] == int(time.time() - 1536862416))

# Generated at 2022-06-11 02:34:23.116549
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts



# Generated at 2022-06-11 02:34:36.269478
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import sys
    import os
    import re
    import subprocess

    # Get class FreeBSDHardware
    _current = os.path.dirname(os.path.abspath(__file__))
    _parent = os.path.dirname(_current)
    sys.path.append(_parent)
    mod = __import__('freebsd')
    FreeBSDHardware = getattr(mod, 'FreeBSDHardware')

    # Get sysctl(8) binary
    sysctl = FreeBSDHardware.module.get_bin_path('sysctl')

    # Get swapinfo(8) binary
    swapinfo = FreeBSDHardware.module.get_bin_path('swapinfo')

    # Get memory
    memory_facts = FreeBSDHardware.get_memory_facts()

    # Calculate expected total memory
    rc, out, err = subprocess.getstatusoutput

# Generated at 2022-06-11 02:34:47.306881
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = AnsibleModule(argument_spec={})

    def set_bin_path(bin_path):
        return bin_path


# Generated at 2022-06-11 02:35:00.465664
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = MockModule()
    freebsd_hardware = FreeBSDHardware(module=module)
    # Test with a valid dmesg output

# Generated at 2022-06-11 02:35:06.181052
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create a fake module.
    module = AnsibleModule(argument_spec=dict())
    # Set 'ansible_facts' as global variable
    setattr(module, 'ansible_facts', dict())
    # We can't use the __init__ method of the class FreeBSDHardware
    # because it uses 'ansible' which is not a module
    facts = FreeBSDHardware()
    # We need this variable in the facts module
    setattr(facts, 'module', module)
    # Update the ansible_facts variable
    facts.populate()
    module.exit_json(**module.ansible_facts)



# Generated at 2022-06-11 02:35:13.159602
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mock_module = type('', (), {'run_command': lambda x: (0, '', ''), 'get_bin_path': lambda x: '/bin/sysctl'})()
    result = FreeBSDHardware(mock_module).get_memory_facts()
    assert result['memtotal_mb']
    assert 'swaptotal_mb' in result


# Generated at 2022-06-11 02:35:26.784553
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Unit test for method get_memory_facts of class FreeBSDHardware
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.utils import ansible_runners
    from ansible.module_utils.facts.timeout import timeout

    if not os.path.exists('/sbin/swapinfo'):
        return

    fbsd_hw_obj = FreeBSDHardware(ansible_runners)

    out_memfacts = fbsd_hw_obj.get_memory_facts()
    cmd = "/sbin/swapinfo -k"
    rc, out, err = fbsd_hw_obj.module.run_command(cmd)
    memtotal = (out.splitlines())[-1].split()[1]

# Generated at 2022-06-11 02:35:28.700917
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    result = hardware.get_device_facts()
    assert result == {}

# Generated at 2022-06-11 02:35:40.025011
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeModule(object):
        def __init__(self):

            def run_command(*args, **kwargs):
                fake_stdout = (
                    b'kern.boottime: { sec = 1548389763, usec = 709605 }\n'
                )
                return 0, fake_stdout, None
            self.run_command = run_command

            def get_bin_path(*args, **kwargs):
                return '/sbin/sysctl'
            self.get_bin_path = get_bin_path

            self.debug = lambda *args, **kwargs: None

    module = FakeModule()
    up = FreeBSDHardware().get_uptime_facts()
    assert up['uptime_seconds'] == int(time.time() - 1548389763)

# Generated at 2022-06-11 02:35:46.846989
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """ FreeBSDHardware_get_uptime_facts: test for method get_uptime_facts()
    of class FreeBSDHardware.
    """
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.basic import AnsibleModule

    module = AnsibleModule(argument_spec={}, supports_check_mode=False, check_invalid_arguments=False)

    class MockFreeBSDHardware(FreeBSDHardware):
        """ Mock class for FreeBSDHardware."""
        def populate(self, collected_facts=None):
            """ Mock method for populate."""
            # pylint: disable=missing-docstring
            pass


# Generated at 2022-06-11 02:36:02.941265
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware('ansible', 'FreeBSD')
    hardware.module = MockModule()

    hardware.get_dmi_facts()



# Generated at 2022-06-11 02:36:09.191350
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # Mock dmidecode executable
    test_module.get_bin_path = lambda x: '/usr/sbin/dmidecode'

    # Mock system dmi output

# Generated at 2022-06-11 02:36:19.805041
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class Module:
        def __init__(self, binary_path):
            self.binary_path = binary_path

        def get_bin_path(self, binary_path):
            return binary_path

        def run_command(self, cmd, check_rc=True):
            if cmd == 'dmidecode -s system-manufacturer':
                return 0, 'Manufacturer', ''
            elif cmd == 'dmidecode -s system-version':
                return 0, 'Version', ''
            elif cmd == 'dmidecode -s system-product-name':
                return 0, 'Product name', ''
            elif cmd == 'dmidecode -s system-serial-number':
                return 0, 'Serial number', ''
            elif cmd == 'dmidecode -s system-uuid':
                return 0, 'UUID',

# Generated at 2022-06-11 02:36:27.907621
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts import Collector
    from ansible.module_utils.facts.system.freebsd import FreeBSDHardware
    from ansible.module_utils.six import PY2

    fhw = FreeBSDHardware({})

    # Test for standard output
    if PY2:
        setattr(fhw.module, 'run_command', lambda cmd: (0, "Pagesize: 4096\nRealmem: 33554432\nFreemem: 4194304\n", ""))
    else:
        setattr(fhw.module, 'run_command', lambda cmd: (0, b"Pagesize: 4096\nRealmem: 33554432\nFreemem: 4194304\n", b""))
    fhw.module.get_bin_path = lambda x: "sysctl"
    ret = f

# Generated at 2022-06-11 02:36:35.891125
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    # Test with unset data
    hardware_unset = FreeBSDHardware(dict())
    hardware_unset.module = MockModule()
    uptime_facts = hardware_unset.get_uptime_facts()
    assert len(uptime_facts) == 0

    # Test with broken data
    hardware_broken = FreeBSDHardware(dict())
    hardware_broken.module = MockModule(raw_output=[1, "broken", ""])
    uptime_facts = hardware_broken.get_uptime_facts()
    assert len(uptime_facts) == 0

    # Test with empty string data
    hardware_empty = FreeBSDHardware(dict())
    hardware_empty.module = MockModule(raw_output=[0, "", ""])
    uptime_facts = hardware_empty.get_uptime_facts()

# Generated at 2022-06-11 02:36:49.549447
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import gather_subset

    mock_module = basic.AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list')
    })

    # We cannot call the populate method with an empty module.
    # so we need to mock some attributes and methods
    mock_module.run_command = lambda x: (0, '', '')
    mock_module.get_bin_path = lambda x: x
    mock_module.params = {'gather_subset': ['all']}

    # Mock the facts with empty data.

# Generated at 2022-06-11 02:36:59.561216
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self._check_mode = False
            self._diff = False
            self._tmpdir = None
            os.environ['PATH'] = '/usr/bin'

        def get_bin_path(self, arg):
            return arg

    module = MockModule()

    def mock_run_command(*args, **kwargs):
        return 0, str(get_uptime()), ''

    module.run_command = mock_run_command

    facts_collector = FreeBSDHardwareCollector(module=module)
    uptime_facts = facts_collector.get_sys_uptime()
    assert uptime_facts['uptime_seconds'] == get_uptime()

# Generated at 2022-06-11 02:37:05.618501
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import _known_facts
    from ansible.module_utils.facts.facts import Facts
    module = FakeModule()
    dut = _known_facts['FreeBSDHardware']()
    dut.gather(module)
    facts = Facts(module).populate()
    assert 'uptime_seconds' in facts
    assert 'uptime_hours' in facts
    assert 'uptime_days' in facts
    assert 'uptime_days_long' in facts


# Generated at 2022-06-11 02:37:10.677209
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.run_command_results = []
            self.run_command_appends = []
            self.run_command_rc = 0

        def get_bin_path(self, _):
            return '/sbin/dmidecode'

        def run_command(self, args):
            if len(self.run_command_appends) > 0:
                self.run_command_results.append(self.run_command_appends.pop(0))
            return self.run_command_results.pop(0)

    # Setup dmidecode output
    bios_date = '01/01/2016'
    bios_vendor = 'Test Firmware'
    bios_version = '1.0'
    board_

# Generated at 2022-06-11 02:37:14.391031
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    facts = dict()
    facts['ansible_os_family'] = 'FreeBSD'
    facts['ansible_architecture'] = 'amd64'
    assert FreeBSDHardware(dict(), facts).get_memory_facts() == {'memfree_mb': 63, 'memtotal_mb': 511, 'swapfree_mb': 0, 'swaptotal_mb': 0}


# Generated at 2022-06-11 02:37:34.361718
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeModule():
        def get_bin_path(path):
            return '/bin/sysctl'
        def run_command(cmd, encoding=None):
            return 0, 'kern.boottime = { sec = 1515790743, usec = 404275 }\n', ''
    f = FreeBSDHardware(FakeModule())
    uptime = f.get_uptime_facts()
    assert uptime['uptime_seconds'] == 172908

# Generated at 2022-06-11 02:37:36.349202
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Just make sure it doesn't throw an exception.
    data = FreeBSDHardware.get_dmi_facts(None)
    assert isinstance(data, dict)

# Generated at 2022-06-11 02:37:40.437273
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    testHardware = FreeBSDHardware()
    testHardware.module.run_command = lambda x: (1, '', '')
    testHardware.get_cpu_facts()
    assert testHardware.collector.fetch_file.called



# Generated at 2022-06-11 02:37:48.711286
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Arrange
    # get_dmi_facts() in FreeBSDHardware calls dmidecode
    # Dmidecode must be available in order to test get_dmi_facts()
    # which is the reason why fake_module is used in this test
    test_facts_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test_facts_module.run_command = mock.Mock(return_value=(0, 'sample output', ''))
    fake_module = mock.MagicMock()
    fake_module.run_command = test_facts_module.run_command
    fake_module.get_bin_path = mock.Mock(return_value='/usr/local/bin/dmidecode')
    test_facts_module.params = {}

# Generated at 2022-06-11 02:37:58.615543
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:38:11.389384
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test empty and invalid swapinfo output
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/sbin/swapinfo')
    module.run_command = Mock(return_value=(0, '', ''))
    module.params = {}

    h = FreeBSDHardware(module)
    memory_facts = h.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert memory_facts['memtotal_mb'] is not None
    assert memory_facts['memfree_mb'] is not None
    assert 'swaptotal_mb' not in memory_facts
    assert 'swapfree_mb' not in memory_facts

    # Test valid swapinfo output
    module.run_command

# Generated at 2022-06-11 02:38:22.322391
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Test that FreeBSDHardware.get_memory_facts() works correctly
    """
    import sys
    import os
    import tempfile
    import shutil

    test_dir = tempfile.mkdtemp()
    sys.path.append(test_dir)

    with open('ansible_module_facts.py', 'w') as f:
        f.write('''
#!/usr/bin/python

try:
    from ansible.module_utils.facts.hardware import FreeBSDHardware
    h = FreeBSDHardware()
    memory_facts = h.get_memory_facts()
    print('memtotal_mb=%s' % memory_facts['memtotal_mb'])
    print('memfree_mb=%s' % memory_facts['memfree_mb'])
except ImportError:
    pass
''')



# Generated at 2022-06-11 02:38:32.122670
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """Test the FreeBSDHardware class get_uptime_facts method."""

    import time
    import random

    class MockFactsModule(object):
        def run_command(self, cmd, check_rc=True, encoding=None):
            """Stub of FactsModule.run_command."""
            return (0, '/dev/random\n', None)

        def get_bin_path(self, path):
            """Stub of FactsModule.get_bin_path."""
            if path == 'sysctl':
                return '/usr/bin/sysctl'
            return ''

    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self):
            self.module = MockFactsModule()

    # Emulate a system booting 10 seconds ago.
    freebsdhw = MockFreeBSDHardware()
    freebsdh

# Generated at 2022-06-11 02:38:42.723679
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    obj = FreeBSDHardware()
    obj.module.run_command = lambda x, **kwargs: (0, 'hw.ncpu: 4', '')
    cpu_facts = obj.get_cpu_facts()
    assert cpu_facts == {
        'processor': [
            'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz (2793.99-MHz K8-class CPU)',
            'Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz (2793.99-MHz K8-class CPU)'
        ],
        'processor_cores': '2',
        'processor_count': '4'
    }


# Generated at 2022-06-11 02:38:47.801660
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Check if the method get_dmi_facts returns a dictionary with keys
    presented in DMI_DICT
    '''
    fh = FreeBSDHardware()
    dmi_facts = fh.get_dmi_facts()
    assert set(dmi_facts.keys()) == set(FreeBSDHardware.DMI_DICT.keys())

# Generated at 2022-06-11 02:39:20.290150
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.params['gather_subset'] = []
    module.params['gather_timeout'] = 1
    hw = FreeBSDHardware(module)
    facts = hw.populate()
    # module.exit_json(changed=False, ansible_facts=facts)
    # print(facts)

    dmi_facts = hw.get_dmi_facts()
    # module.exit_json(changed=False, ansible_facts=dmi_facts)

    for k, v in dmi_facts.items():
        if v == 'NA':
            assert(facts[k] is not None)
        else:
            assert(facts[k] == v)



# Generated at 2022-06-11 02:39:26.192864
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    # Test with empty paramaters
    x = FreeBSDHardwareCollector()
    assert x._fact_class == FreeBSDHardware
    assert x._platform == 'FreeBSD'

    # Test with parameters
    x = FreeBSDHardwareCollector(fact_class=FreeBSDHardware, platform='FreeBSD')
    assert x._fact_class == FreeBSDHardware
    assert x._platform == 'FreeBSD'

# Generated at 2022-06-11 02:39:34.123380
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''
    Test get_cpu_facts method of class FreeBSDHardware
    '''

    # prepare mocks for module, os, and sysctl
    module_mock = Mock()
    module_mock.get_bin_path.return_value = '/sbin/sysctl'
    module_mock.run_command.return_value = (0, "hw.ncpu: 4\n", "")

    # create class
    hardware_mock = FreeBSDHardware(module_mock)

    # get cpu fact
    cpu_facts = hardware_mock.get_cpu_facts()

    # assert if we got the right cpu fact
    assert cpu_facts.get('processor_count') == "4"

# Generated at 2022-06-11 02:39:43.419213
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import hardware as hardware_m
    import os
    import time

    class MockModule():
        def get_bin_path(self, command):
            if command == 'sysctl':
                return '/sbin/sysctl'

        def run_command(self, *args, **kwargs):
            if args[0] == ['/sbin/sysctl', '-b', 'kern.boottime']:
                now = time.time()
                return (0, struct.pack('@L', now - 30.2), None)

    fh = FreeBSDHardware(MockModule())

    uptime_facts = fh.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 30


# Generated at 2022-06-11 02:39:48.660865
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = object()
    module.get_bin_path = lambda name: ''
    module.run_command = lambda cmd, encoding=None: (0, '923642592.77', '')
    facts = FreeBSDHardwareCollector(module).collect()['ansible_facts']
    assert isinstance(facts['ansible_uptime_seconds'], int)


# Generated at 2022-06-11 02:39:53.935865
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    import sys
    from ansible.module_utils.facts.collector import get_collector_instance

    # Instantiate FreeBSDHardwareCollector
    fact_collector = get_collector_instance(sys.modules[__name__])
    assert fact_collector is not None
    assert fact_collector._fact_class == FreeBSDHardware
    assert fact_collector._platform == "FreeBSD"

# Generated at 2022-06-11 02:40:02.555718
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils._text import to_bytes


# Generated at 2022-06-11 02:40:04.414705
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = FreeBSDHardware()
    assert len(m.get_cpu_facts()['processor']) > 0


# Generated at 2022-06-11 02:40:06.826394
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector = FreeBSDHardwareCollector()
    assert hw_collector.platform == 'FreeBSD'

# Generated at 2022-06-11 02:40:11.017767
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._platform == 'FreeBSD'
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware
    assert fhc.fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:40:53.240030
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module_mock = MockModule()
    module_mock.get_bin_path.return_value = "/bin/sysctl"
    hardware = FreeBSDHardware(module_mock)


# Generated at 2022-06-11 02:40:55.782940
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()

    module.exit_json(ansible_facts={'hardware': memory_facts})



# Generated at 2022-06-11 02:41:04.704720
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    facts = {'module': dict()}
    facts['module']['run_command'] = lambda *args, **kwargs: ('', '', '')
    facts['module']['get_bin_path'] = lambda name: None
    module = dict()
    module['exit_json'] = lambda *args, **kwargs: exit(0)
    module['fail_json'] = lambda *args, **kwargs: exit(1)

    sysdir = '/dev'

# Generated at 2022-06-11 02:41:12.035023
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    hardware = FreeBSDHardware({}, {})

    cpu_facts = hardware.get_cpu_facts()

    assert type(cpu_facts) == dict
    assert 'processor' in cpu_facts
    assert len(cpu_facts['processor']) > 0
    assert 'CPU:' in cpu_facts['processor'][0]
    assert 'processor_cores' in cpu_facts
    assert int(cpu_facts['processor_cores']) > 0
    assert 'processor_count' in cpu_facts
    assert int(cpu_facts['processor_count']) == len(cpu_facts['processor'])



# Generated at 2022-06-11 02:41:22.356915
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModuleMock()
    # Check that we load sysctl module
    module.run_command = lambda a, **kw: (1, 'sysctl command is not installed', '')
    f = FreeBSDHardware(module=module)
    facts = f.get_memory_facts()
    assert facts['memfree_mb'] == 0
    assert facts['memtotal_mb'] == 0
    assert facts['swapfree_mb'] == 0
    assert facts['swaptotal_mb'] == 0

    # Fake sysctl output
    module.run_command = lambda a, **kw: (0, 'vm.stats.vm.v_page_count: 1234\nvm.stats.vm.v_page_size: 5678\nvm.stats.vm.v_free_count: 5678', '')
    f = FreeBSDHardware

# Generated at 2022-06-11 02:41:32.419957
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    freebsd = FreeBSDHardware(module)
    dmesg_boot = [
        "CPU: ",
        "Logical CPUs per core: 1",
    ]
    module.run_command = MagicMock(return_value=(0, None, None))
    freebsd.DMESG_BOOT = os.path.join(os.path.dirname(__file__), 'test.dmesg_boot')

    file_output = []
    for line in dmesg_boot:
        file_output.append(line+"\n")
    f = open(freebsd.DMESG_BOOT, "wt")
    f.writelines(file_output)
    f.close()

    cpu_facts = freebsd.get_cpu_facts()

# Generated at 2022-06-11 02:41:35.027068
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'


# Generated at 2022-06-11 02:41:44.419889
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class KModule:
        def get_bin_path(self, program):
            return program

        def run_command(self, program, check_rc=True):
            if program == "sysctl vm.stats":
                return 0, "vm.stats.vm.v_page_size: 2048\n"\
                       "vm.stats.vm.v_page_count: 4102358\n"\
                       "vm.stats.vm.v_free_count: 1159778\n", None
            elif program == "swapinfo -k":
                return 0, "Device    512-blocks     Used    Avail Capacity\n"\
                       "/dev/ada0p3        314368        0   314368     0%\n", None
            else:
                return 2, "Error", "Force error"


# Generated at 2022-06-11 02:41:52.456384
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.six import iteritems
    from ansible.module_utils.facts import _get_file_content, _get_mount_size

    facts = FreeBSDHardware().populate()
    # test no error, unset values are 'NA'
    for key in ('bios_date', 'bios_vendor', 'bios_version', 'board_asset_tag',
                'board_name', 'board_serial', 'board_vendor', 'board_version',
                'chassis_asset_tag', 'chassis_serial', 'chassis_vendor',
                'chassis_version', 'form_factor', 'product_name',
                'product_serial', 'product_uuid', 'product_version',
                'system_vendor'):
        assert key in facts
        assert facts[key]

# Generated at 2022-06-11 02:42:03.903454
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # We cannot test get_uptime_facts() directly because it relies on the
    # time.time() function which we can't easily mock in Python 2.7.

    # We do the next best thing: check that it uses the struct module
    # correctly.

    # Create a mocked struct object that returns a fixed boot time when
    # unpack() is called.
    class MockedStruct:
        def unpack(self, _):
            return (time.time() - 1, )

    # Patch struct.unpack() to return the mocked struct object.
    struct_orig = struct.unpack
    struct.unpack = lambda _: MockedStruct()
