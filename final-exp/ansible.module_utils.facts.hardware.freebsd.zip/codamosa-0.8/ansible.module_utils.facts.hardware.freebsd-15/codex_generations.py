

# Generated at 2022-06-11 02:33:06.188474
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class ModuleMock(object):
        def __init__(self):
            self.sysctl = '/sbin/sysctl'
            self.bin_path_result = '/sbin/sysctl'
            self.run_command_result = (0, '4', '')

        def get_bin_path(self, arg, opt_dirs=[]):
            return self.bin_path_result

        def run_command(self, arg, check_rc=False, encoding=None):
            return self.run_command_result

    class HardwareMock(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    class MockOpen(object):
        def __init__(self, file_content=''):
            self.file_content = file_content


# Generated at 2022-06-11 02:33:17.280107
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # patch AnsibleModule and Popen
    import sys
    import ansible.module_utils.facts.hardware.system_profiler

    module = ansible.module_utils.facts.hardware.system_profiler
    module.Popen = mock.MagicMock()

    x = {'rc': 0, 'stdout': module.SYSTEM_PROFILER_OUTPUT, 'stderr': ''}
    module.Popen.return_value.communicate.return_value = (x['stdout'], x['stderr'])
    module.Popen.return_value.returncode = x['rc']

    # patch os.path.isfile
    module.os = mock.MagicMock()
    module.os.path = mock.MagicMock()
    module.os.path.isfile.return_

# Generated at 2022-06-11 02:33:20.858344
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    freebsd_hw = FreeBSDHardware(module=module)
    memory_facts = freebsd_hw.get_memory_facts()
    assert memory_facts.get('swaptotal_mb')
    assert memory_facts.get('swapfree_mb')
    assert memory_facts.get('memtotal_mb')
    assert memory_facts.get('memfree_mb')



# Generated at 2022-06-11 02:33:27.819523
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    This tests the method get_uptime_facts of class FreeBSDHardware.

    This method returns a dictionary whose key is uptime_seconds and
    whose value is the number of seconds since the last boot of
    the system.

    In this unit test, we check if the value is an integer and if it
    is not too big. This test is designed to be executed on
    a system on which the process started at least 10 seconds ago.
    """
    expected_uptime_seconds = int(time.time()) - os.stat(__file__).st_ctime
    assert expected_uptime_seconds > 10
    hardware_facts = FreeBSDHardware()
    uptime_fact = hardware_facts.get_uptime_facts()
    uptime_seconds = uptime_fact["uptime_seconds"]
    assert uptime_seconds > 0

# Generated at 2022-06-11 02:33:33.840278
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''Unit test for method get_dmi_facts of class FreeBSDHardware'''
    frbs_hw = FreeBSDHardware()
    dmi_facts_dict = frbs_hw.get_dmi_facts()
    assert 'system_vendor' in dmi_facts_dict


# Generated at 2022-06-11 02:33:40.960160
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:33:51.014317
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """ Check parsing of raw kern.boottime output
    """
    module = FakeModule()
    hwinfo = FreeBSDHardware(module)

    time_to_boot = time.time() - 1577668354
    kern_boottime_str = struct.pack('@L', int(time_to_boot))

    os.environ['RAW_KERN_BOOTIME'] = kern_boottime_str

    rc = os.system('unset PATH; /usr/bin/python3 -m ansible_collections.ansible.os_migrate.plugins.modules.hardware.freebsd')
    assert rc == 0

    assert os.environ['FACTS']['uptime_seconds'] == int(time_to_boot)

# Fake module for test_FreeBSDHardware_get_uptime_facts

# Generated at 2022-06-11 02:33:52.831599
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Test without arguments
    test_object = FreeBSDHardwareCollector()
    assert test_object is not None


# Generated at 2022-06-11 02:33:56.913144
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils import basic
    m = basic.AnsibleModule(
        argument_spec={},
    )

    hardware = FreeBSDHardware(m)

    dmi_facts = hardware.get_dmi_facts()

    print(dmi_facts)

# Generated at 2022-06-11 02:34:04.476758
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:34:18.768905
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    l = ['freebsd']
    hardware_collector = FreeBSDHardwareCollector
    hardware_collector.collect(l)
    assert l == ['freebsd', 'freebsd']

# Generated at 2022-06-11 02:34:31.925026
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    FreeBSDHardware.module = module
    freebsd_hw = FreeBSDHardware()

    class TestFacts(object):
        def __init__(self):
            self.os_version = '10.1'

    test_facts = TestFacts()

    # Test with no /var/run/dmesg.boot file
    module.run_command.return_value = [0, '', '']
    module.get_file_content.return_value = ''
    facts_dict = freebsd_hw.populate(test_facts)

# Generated at 2022-06-11 02:34:40.359366
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    m = FreeBSDHardware()
    output = m.get_device_facts()
    assert 'devices' in output
    # TODO: assert len(output['devices']) > 2
    assert output
    assert output['devices']['ada0'][0] == 'ada0s1'
    assert output['devices']['ada0'][1] == 'ada0s2'
    assert output['devices']['ada1'][0] == 'ada1s1'
    assert output['devices']['ada1'][1] == 'ada1s2'

# Generated at 2022-06-11 02:34:49.967965
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    myfacts = dict()
    mymodule = dict()
    mymodule['run_command'] = dict()
    mymodule['run_command']['rc'] = 0
    mymodule['run_command']['out'] = "hw.ncpu: 24"
    mymodule['run_command']['err'] = ""
    mymodule['get_bin_path'] = dict()
    mymodule['get_bin_path']['rc'] = 0
    mymodule['get_bin_path']['out'] = "/usr/sbin/sysctl"
    mymodule['get_bin_path']['err'] = ""
    mymodule['file_exists'] = dict()
    mymodule['file_exists']['rc'] = 0
    mymodule['file_exists']['out'] = ""
    mymodule

# Generated at 2022-06-11 02:35:01.126159
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware()
    hardware.module = MockModule()

    hardware.module.run_command.return_value = (0, 'vm.stats.vm.v_page_size=4096\nvm.stats.vm.v_page_count=331791\nvm.stats.vm.v_free_count=124628\n', '')
    # Real values of memtotal_mb and memfree_mb are 13824 and 4945 on a FreeBSD 11.0 i386 test VM
    assert hardware.get_memory_facts() == {'memtotal_mb': 13708, 'memfree_mb': 4928}


# Generated at 2022-06-11 02:35:05.939297
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Test FreeBSDHardware.populate()."""
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)

    # Test the endpoint with a mocked module
    hardware.module = module
    facts = hardware.populate()

    # Test if the populate return a populated facts dict
    assert len(facts) > 2


# Unit tests for method get_mount_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:35:09.005486
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f = FreeBSDHardwareCollector()
    assert f.get_facts()['ansible_facts']['ansible_system'] == 'FreeBSD'

# Generated at 2022-06-11 02:35:23.190250
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Mock data
    # dmi_bin
    mocked_bin_path = '/usr/sbin/dmidecode'
    # dmidecode -s bios-release-date
    mocked_bios_date = (0, '2015-10-22', '')
    # dmidecode -s bios-vendor
    mocked_bios_vendor = (0, 'American Megatrends Inc.\n', '')
    # dmidecode -s bios-version
    mocked_bios_version = (0, 'V3.11\n', '')
    # dmidecode -s baseboard-asset-tag
    mocked_board_asset_tag = (0, 'Base Board Asset Tag\n', '')
    # dmidecode -s baseboard-product-name
    mocked_board_name

# Generated at 2022-06-11 02:35:25.883714
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    h = FreeBSDHardware({'module_setup': True})
    h.populate_facts()
    assert 'devices' in h.facts

# Generated at 2022-06-11 02:35:29.796798
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    my_obj = FreeBSDHardware()
    res = my_obj.populate()

    assert res['processor']
    assert res['processor_cores']
    assert res['processor_count']
    assert res['devices']
    assert res['uptime_seconds']

# Generated at 2022-06-11 02:35:58.609081
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = DummyAnsibleModule()
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz',
                                      'Intel(R) Core(TM)2 Duo CPU     T7700  @ 2.40GHz']
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-11 02:36:06.350767
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    '''Testing FreeBSDHardware.get_cpu_facts()'''
    hardware = FreeBSDHardware()

    cpu_facts = {'processor': ['Geode(TM) Integrated Processor by Advanced Micro Devices, Inc.']}
    cpu_facts['processor_count'] = '1'

    current_cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts == current_cpu_facts


# Generated at 2022-06-11 02:36:11.821390
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """ Returns the number of processors, the cores and model name"""
    from ansible.module_utils.facts.facts.hardware.freebsd import FreeBSDHardware
    test_object = FreeBSDHardware({'module': None})
    output = {
        "processor": ["Intel(R) Core(TM) i3-4130 CPU @ 3.40GHz"],
        "processor_cores": "2",
        "processor_count": 1
    }
    assert test_object.get_cpu_facts() == output, "should return the number of processors, the cores and model name"


# Generated at 2022-06-11 02:36:23.262267
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class FreeBSDHardware."""

# Generated at 2022-06-11 02:36:26.318546
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_obj = FreeBSDHardware({})
    test_obj.module = MockModule()

    assert test_obj.get_memory_facts() == {'swaptotal_mb': 2048, 'memtotal_mb': 7680, 'swapfree_mb': 2048, 'memfree_mb': 6144}



# Generated at 2022-06-11 02:36:33.819481
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fake_module = FakeAnsibleModule()
    fake_module.mock_command(command="/sbin/swapinfo -k", rc=255, out='', err='command not found')
    freebsd_hw = FreeBSDHardware(fake_module)

    assert freebsd_hw.get_memory_facts() == {'swaptotal_mb': None, 'swapfree_mb': None, 'memtotal_mb': None, 'memfree_mb': None}



# Generated at 2022-06-11 02:36:35.821612
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw


# Generated at 2022-06-11 02:36:49.490834
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)
    hardware.populate()

    # TODO: write unit tests to assert the output
    # facts = hardware.get_facts()
    # keys = [ 'devices', 'uptime_seconds', 'memfree_mb', 'memtotal_mb',
    #          'processor', 'swapfree_mb', 'swaptotal_mb', 'processor_cores',
    #          'processor_count' ]
    # for key in keys:
    #     assert key in facts
    # assert re.search(r'^\d+$', facts['memfree_mb'])
    # assert re.search(r'^\d+$', facts['memtotal_mb'])
    # assert re.search(r'^\d+$', facts['

# Generated at 2022-06-11 02:36:56.192612
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    # Test values are taken from the following command:
    # kern.boottime.tv_sec = 1572849333
    # kern.boottime.tv_usec = 429531
    boottime = 1572849333.429531
    now = time.time()
    # We need to remove the fractional part to produce the expected result.
    expected = now - int(boottime)
    assert FreeBSDHardware.get_uptime_facts()['uptime_seconds'] == expected

# Generated at 2022-06-11 02:37:05.096855
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create a fake timestamp.
    fake_timestamp = time.time()

    # Create a fake boottime using the fake timestamp.
    # The actual value of kern_boottime below is irrelevant because our code will
    # convert it to a proper timestamp.
    kern_boottime = int(fake_timestamp)

    # Create a fake string with the binary representation of kern_boottime.
    # Note: we expect the little-endian format.
    kern_boottime_hex = struct.pack('@L', kern_boottime)

    # Create a fake sysctl command that will return kern_boottime_hex.
    fake_sysctl_cmd = 'fake_sysctl_cmd'

    # Create a fake dmi_facts.

# Generated at 2022-06-11 02:37:57.816388
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for method populate of class FreeBSDHardware
    '''
    class MockModule(object):
        def __init__(self):
            self.run_command = run_command
            self.get_bin_path = get_bin_path

    class MockHardware(FreeBSDHardware):
        pass

    def run_command(self, args, check_rc=True, encoding=None, errors='strict'):
        '''
        Return a tuple containing three values: (rc, out, err)
        '''
        rc = 0
        out = ''
        err = ''
        command = args.split()[0]

# Generated at 2022-06-11 02:38:10.666419
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MockModule():
        def __init__(self):
            self.run_command_results = [
                (0, 'hw.ncpu: 1\n', ''),
                (0, 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 4437952\nvm.stats.vm.v_free_count: 4254148\n', ''),
                (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%', '')
            ]
            self.run_command_index = 0

        def run_command(self, command, check_rc=False, encoding=None):
            result = self.run_command_results[self.run_command_index]
            self

# Generated at 2022-06-11 02:38:12.776854
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-11 02:38:22.593384
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MagicMock()
    module.get_bin_path.return_value = '/sbin/sysctl'
    module.run_command.return_value = (0, '', '')
    mem_free = 200 * 10**6
    mem_total = 400 * 10**6
    swap_free = 100 * 10**6
    swap_total = 200 * 10**6
    out_str = "vm.stats.vm.v_page_size: %d\nvm.stats.vm.v_page_count: %d\nvm.stats.vm.v_free_count: %d\n" % (10**6, mem_total, mem_free)

    def get_mount_size_mock(mount_point):
        return {'size_total': swap_total, 'size_available': swap_free}

# Generated at 2022-06-11 02:38:24.010838
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    m = FreeBSDHardwareCollector()
    assert m.collect() == {}

# Generated at 2022-06-11 02:38:33.780395
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class TestModule(object):
        def __init__(self, rc, out, err, bin_path):
            self.rc = rc
            self.out = out
            self.err = err
            self.bin_path = bin_path

        def get_bin_path(self, *args, **kwargs):
            return self.bin_path

        def run_command(self, *args, **kwargs):
            return self.rc, self.out, self.err

    # Create a FreeBSDHardware object, and call populate() to test it
    _hw = FreeBSDHardware(TestModule(0, '', '', '/bin/true'))
    _facts = _hw.populate()

    assert _facts['processor_count'] == '1'

# Generated at 2022-06-11 02:38:44.620589
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts import collector
    from ansible.module_utils.facts.collector import TestModule
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content

    # Create a TestModule with a timeout of 1 second and a run_command that returns fake output.
    testmodule = TestModule({'command_timeout': 1, 'run_command_environ_update': {'LANG': 'C'}})


# Generated at 2022-06-11 02:38:53.130001
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import unittest



# Generated at 2022-06-11 02:39:02.835783
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-11 02:39:14.644601
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class Module:
        def __init__(self):
            self.run_command = self.fake_run_command
            self.result = 0, '', ''
            self.run_command_args = []

        def get_bin_path(self, binary):
            return binary

        def fake_run_command(self, cmd, check_rc=False):
            self.run_command_args.append(cmd)
            return self.result

    class Connection:

        def __init__(self, module):
            self.module = module

        def run(self, cmd, check_rc=False):
            return self.module.fake_run_command(cmd, check_rc)

    module = Module()
    connection = Connection(module)

    # use first line of dmesg.boot for CPU facts
    module.result = 0

# Generated at 2022-06-11 02:40:58.473000
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestMockModule:
        def get_bin_path(self, path):
            return "/bin/" + path

        def run_command(self, cmd, check_rc=True):
            return 0, "hw.ncpu: 2\n", ""

    class TestMockModule2:
        def get_bin_path(self, path):
            return "/bin/" + path

        def run_command(self, cmd, check_rc=True):
            test_cmd = "/bin/sysctl -n hw.ncpu"
            if cmd == test_cmd:
                return 0, "2\n", ""

    class TestMockModule3:
        def get_bin_path(self, path):
            return "/bin/" + path

        def run_command(self, cmd, check_rc=True):
            test_cmd

# Generated at 2022-06-11 02:41:07.914521
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    class MockModule:
        def __init__(self, bin_path):
            self.bin_path = bin_path

        def get_bin_path(self, binary):
            return self.bin_path

        def run_command(self, cmd, check_rc=True):
            out = """hw.ncpu: 4
vm.stats.vm.v_page_count: 3362763
vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_free_count: 1823488"""
            return (0, out, '')

    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    m = MockModule(bin_path='/bin')
    f = MockFreeBSDHardware(m)
    memory_facts = f.get

# Generated at 2022-06-11 02:41:10.197482
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert isinstance(fhc, HardwareCollector)
    assert isinstance(fhc._fact_class, FreeBSDHardware)

# Generated at 2022-06-11 02:41:21.083844
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import copy
    import ansible.module_utils.facts.hardware.freebsd as fhw
    import time

    class MockModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err
        def run_command(self, cmd, encoding=None, check_rc=True):
            return self.rc, self.out, self.err

    # This is a copy of the output from a FreeBSD machine
    # converted to bytes.
    #
    # A look at the source code (currently commit
    # a3f4e8f64c0bd723b107089f6e8feb98b19087a0, but if
    # it changes, it will be a different commit, but the
    # data format

# Generated at 2022-06-11 02:41:27.034762
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware(None)
    data = open('tests/data/uptime.txt').read()
    output = '\n'.join(data.split('\n')[2:4])
    m.module.run_command = lambda x, encoding=None: (0, output, '')
    seconds = int(time.time() - 1533541410)
    assert m.get_uptime_facts() == {'uptime_seconds': seconds}

# Generated at 2022-06-11 02:41:36.295032
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """
    Unit test for method populate of class FreeBSDHardware
    """
    def get_bin_path(name):
        """
        dummy function for FreeBSDHardware._module.get_bin_path().
        """
        return name
    def run_command(cmd, check_rc=False, encoding=None):
        """
        dummy function for FreeBSDHardware._module.run_command().
        """
        return (0, cmd, None)
    class Module():
        """
        dummy class for FreeBSDHardware._module.
        """
        def __init__(self):
            self.get_bin_path = get_bin_path
            self.run_command = run_command
    obj = FreeBSDHardware()
    obj._module = Module()
    obj.populate()

# Generated at 2022-06-11 02:41:40.877230
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware(None)

    facts = hardware.populate()

    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-11 02:41:48.713825
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # build a mock module
    module = AnsibleModule(argument_spec={})

    # build a mock hardware
    hardware = FreeBSDHardware()
    hardware.module = module
    # build a mock result
    hardware_collector = FreeBSDHardwareCollector()
    hardware_collector.collect()
    result = hardware_collector.read_facts()

    # test
    result = hardware.get_memory_facts()
    assert result['swaptotal_mb'] == 0
    assert result['swapfree_mb'] == 0
    assert result['memtotal_mb'] != 0
    assert result['memfree_mb'] != 0



# Generated at 2022-06-11 02:41:49.168551
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-11 02:41:52.684417
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    try:
        f_ins = FreeBSDHardwareCollector()
    except Exception:
        assert False, 'Fail to instantiate FreeBSDHardwareCollector.Unittest fail!'
    assert True, 'Instantiating FreeBSDHardwareCollector.Unittest pass!'
