

# Generated at 2022-06-17 00:01:35.106470
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:01:47.699120
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockTime(object):
        def __init__(self):
            self.time = 0

        def time(self):
            self.time += 1
            return self.time

    # Create a mock class
    class MockStruct(object):
        def __init__(self):
            self.struct_size = 8

        def calcsize(self, struct_format):
            return self.struct_size

        def unpack(self, struct_format, out):
            return (1, )

    # Create a mock class

# Generated at 2022-06-17 00:01:58.133646
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Create a dictionary with the expected results

# Generated at 2022-06-17 00:02:09.459293
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Test get_cpu_facts method
    cpu_facts = freebsd_hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'

# Generated at 2022-06-17 00:02:16.259452
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['system_vendor'] != 'NA'
    assert hardware_facts['product_name'] != 'NA'
    assert hardware_facts['product_serial'] != 'NA'
    assert hardware_facts['product_uuid'] != 'NA'
    assert hardware_facts

# Generated at 2022-06-17 00:02:29.105026
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'
    assert dmi_facts['product_name'] == 'NA'
    assert dmi_facts['product_version'] == 'NA'
    assert dmi_facts['product_serial'] == 'NA'
    assert dmi_facts['product_uuid'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_asset_tag']

# Generated at 2022-06-17 00:02:31.900632
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz', 'Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']


# Generated at 2022-06-17 00:02:40.055782
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:52.072127
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test with a valid kern.boottime value
    kern_boottime = struct.pack('@L', int(time.time() - 3600))
    module.run_command = MagicMock(return_value=(0, kern_boottime, ''))
    assert hardware.get_uptime_facts() == {'uptime_seconds': 3600}

    # Test with an invalid kern.boottime value
    module.run_command = MagicMock(return_value=(0, '', ''))
    assert hardware.get_uptime_facts() == {}

    # Test with an error when running the command
    module.run_command = MagicMock(return_value=(1, '', ''))
    assert hardware.get_uptime

# Generated at 2022-06-17 00:02:56.319742
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:03:18.457888
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    devices = hardware.get_device_facts()
    assert 'devices' in devices
    assert isinstance(devices['devices'], dict)
    assert 'ada0' in devices['devices']
    assert isinstance(devices['devices']['ada0'], list)
    assert 'ada0s1' in devices['devices']['ada0']
    assert 'ada0s2' in devices['devices']['ada0']
    assert 'ada0s3' in devices['devices']['ada0']
    assert 'ada0s4' in devices['devices']['ada0']
    assert 'ada0s5' in devices['devices']['ada0']
    assert 'ada0s6' in devices['devices']['ada0']


# Generated at 2022-06-17 00:03:29.951301
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware()

    # Create a dictionary of expected dmi facts

# Generated at 2022-06-17 00:03:40.628727
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Check that the method get_uptime_facts returns a dictionary
    assert isinstance(freebsd_hardware.get_uptime_facts(), dict)

    # Check that the method get_uptime_facts raises a TimeoutError
    # when the timeout is reached
    freebsd_hardware.timeout = 0.001
    assert isinstance(freebsd_hardware.get_uptime_facts(), TimeoutError)

# Generated at 2022-06-17 00:03:45.627828
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0



# Generated at 2022-06-17 00:03:47.476661
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:03:51.162577
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:03:57.849105
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']


# Generated at 2022-06-17 00:04:10.046669
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_calls = []

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return (0, '', '')

        def get_bin_path(self, name):
            self.get_bin_path_calls.append(name)
            return '/usr/bin/%s' % name

    module = Module()
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:04:17.476779
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz', 'Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz']


# Generated at 2022-06-17 00:04:23.342583
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:04:44.198846
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': run_command})

    # Create a mock class for the FreeBSDHardware class
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock time module
    time_module = type('time', (object,), {'time': lambda: 1500000000})

    # Create a FreeBSDHardware object
    hardware = MockFreeBSDHardware(module)

    # Patch the time module
    hardware.__class__.time = time_module.time

    # Call the get_uptime_facts method
    uptime_facts = hardware.get_uptime_facts()

    # Assert that the uptime_facts dictionary is correct

# Generated at 2022-06-17 00:04:49.046339
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']


# Generated at 2022-06-17 00:04:52.258504
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:05:02.615452
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import time

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Get the current time
    now = time.time()

    # Get the uptime facts
    uptime_facts = freebsd_hardware.get_uptime_facts()

    # Check the uptime_seconds fact
    assert uptime_facts['uptime_seconds'] >= 0

    # Check the uptime_seconds fact
    assert uptime_facts['uptime_seconds'] <= now

# Generated at 2022-06-17 00:05:12.982231
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'chassis_vendor' in dmi_facts
    assert 'chassis_version' in d

# Generated at 2022-06-17 00:05:17.830106
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:26.189420
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    devices = hardware.get_device_facts()
    assert devices['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4']
    assert devices['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4']
    assert devices['devices']['ada2'] == ['ada2s1', 'ada2s2', 'ada2s3', 'ada2s4']
    assert devices['devices']['ada3'] == ['ada3s1', 'ada3s2', 'ada3s3', 'ada3s4']

# Generated at 2022-06-17 00:05:33.306937
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:05:46.084060
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'chassis_asset_tag' in dmi_facts
    assert 'chassis_serial' in dmi_facts
    assert 'chassis_vendor' in dmi_facts

# Generated at 2022-06-17 00:05:54.477820
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '8'


# Generated at 2022-06-17 00:06:29.396162
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    import os
    import tempfile
    import shutil
    import json
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils._text import to_bytes

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary dmidecode
    dmidecode = os.path.join(tmpdir, 'dmidecode')

# Generated at 2022-06-17 00:06:40.472429
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test with sysctl output
    sysctl_output = '''
vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 524288
vm.stats.vm.v_free_count: 524288
'''
    module.run_command = MagicMock(return_value=(0, sysctl_output, ''))
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 512
    assert memory_facts['memfree_mb'] == 512

    # Test with swapinfo output

# Generated at 2022-06-17 00:06:42.406557
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:06:49.053268
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:06:54.885426
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/bin/%s' % name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if cmd == ['/bin/sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', int(time.time() - 3600)), ''
            else:
                raise Exception('Unexpected command: %s' % cmd)

    module = MockModule()
    hardware = FreeBSDHardware(module)
    facts = hardware.get_uptime_facts()

    assert facts['uptime_seconds'] == 3600

# Generated at 2022-06-17 00:07:00.106258
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:07:05.100433
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.get_memory_facts()
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-17 00:07:13.367365
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:24.434508
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test data
    dmi_bin = '/usr/sbin/dmidecode'

# Generated at 2022-06-17 00:07:35.474716
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:08:09.082694
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import mock
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create a mock module
    module = mock.MagicMock()
    module.run_command.return_value = (0, '', '')
    module.get_bin_path.return_value = '/usr/bin/sysctl'

    # Create a FreeBSDHardware object
    hardware = FreeBSDHardware(module)

    # Create a mock time
    time = mock.MagicMock()
    time.time.return_value = 1512085200

    # Create a mock struct
    struct = mock.MagicMock()
    struct.calcsize.return_value = 8
    struct.unpack.return_value = (1512085200, )

    # Create a mock os
    os = mock.MagicMock()
   

# Generated at 2022-06-17 00:08:20.202514
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_

# Generated at 2022-06-17 00:08:30.105727
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, b'kern.boottime: { sec = 1535982542, usec = 558000 }\n', ''),
        'get_bin_path': lambda self, cmd: cmd,
    })()

    # Create a mock class
    class_ = type('AnsibleModule_class', (object,), {
        'module': module,
    })

    # Create a mock instance of the class
    instance = class_()

    # Call the method
    result = FreeBSDHardware.get_uptime_facts(instance)

    # Assert the result

# Generated at 2022-06-17 00:08:39.355476
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'

# Generated at 2022-06-17 00:08:50.382415
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts
    assert 'mounts' in facts
    assert 'bios_date' in facts
    assert 'bios_vendor' in facts
    assert 'bios_version' in facts
    assert 'board_asset_tag' in facts
    assert 'board_name' in facts

# Generated at 2022-06-17 00:08:53.981756
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts


# Generated at 2022-06-17 00:08:58.226153
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:09:01.685086
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'

# Generated at 2022-06-17 00:09:08.362482
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '4'


# Generated at 2022-06-17 00:09:19.042195
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:09:52.376170
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:10:04.106277
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:10:12.996081
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:10:24.871636
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == '1'
    assert hardware_facts['processor'] == ['Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz']
    assert hardware_facts['processor_cores'] == '2'
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 7861
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3']

# Generated at 2022-06-17 00:10:31.999376
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:10:40.497633
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleStub(object):
        def __init__(self):
            self.params = {}
            self.params['gather_subset'] = ['all']

        def get_bin_path(self, arg, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            return 0, 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 46988\nvm.stats.vm.v_free_count: 46988\n', ''

    class FactsStub(object):
        def __init__(self):
            self.facts = {}

    module = ModuleStub()
    facts = FactsStub()
    hardware = FreeBSDHardware(module)


# Generated at 2022-06-17 00:10:44.248476
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:10:48.697415
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:10:52.753107
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-17 00:10:57.472475
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
