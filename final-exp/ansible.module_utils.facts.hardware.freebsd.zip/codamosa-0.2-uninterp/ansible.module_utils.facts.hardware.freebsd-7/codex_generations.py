

# Generated at 2022-06-17 00:01:45.264522
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Create a fake dmesg.boot file

# Generated at 2022-06-17 00:01:50.119819
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '8'


# Generated at 2022-06-17 00:01:56.327868
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:01.242205
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:08.531195
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:02:13.846524
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:26.928663
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test case 1: dmidecode is not available
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module)
    dmi_facts = fhw.get_dmi_facts()

# Generated at 2022-06-17 00:02:38.234596
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']
    assert hardware_facts['board_asset_tag']

# Generated at 2022-06-17 00:02:50.883066
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a FreeBSDHardware instance
    freebsd_hardware = FreeBSDHardware()

    # Get the uptime facts
    uptime_facts = freebsd_hardware.get_uptime_facts()

    # Check that the uptime_seconds fact is present
    assert 'uptime_seconds' in uptime_facts

    # Check that the uptime_seconds fact is an integer
    assert isinstance(uptime_facts['uptime_seconds'], int)

    # Check that the uptime_seconds fact is greater than 0
    assert uptime_facts['uptime_seconds'] > 0

    # Check that the uptime_seconds fact is less than 1 year
    assert uptime_facts

# Generated at 2022-06-17 00:03:01.447933
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    devices = hardware.get_device_facts()['devices']
    assert devices
    assert 'ada0' in devices
    assert 'da0' in devices
    assert 'cd0' in devices
    assert 'ada0' in devices['ada0']
    assert 'ada0s1' in devices['ada0']
    assert 'ada0s2' in devices['ada0']
    assert 'ada0s3' in devices['ada0']
    assert 'ada0s4' in devices['ada0']
    assert 'ada0s5' in devices['ada0']
    assert 'ada0s6' in devices['ada0']
    assert 'ada0s7' in devices['ada0']

# Generated at 2022-06-17 00:03:16.317918
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'


# Generated at 2022-06-17 00:03:21.016778
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:03:32.076028
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert len(hardware_facts['processor']) > 0
    assert len(hardware_facts['devices']) > 0
    assert len(hardware_facts['mounts']) > 0
    assert hardware_facts['system_vendor'] != 'NA'
    assert hardware_facts

# Generated at 2022-06-17 00:03:39.948557
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '4'


# Generated at 2022-06-17 00:03:44.102862
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:03:51.354875
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:03:58.513994
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']



# Generated at 2022-06-17 00:04:10.445084
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_

# Generated at 2022-06-17 00:04:22.476183
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self.run_command_kwargs = []
            self.run_command_results = []

        def get_bin_path(self, name):
            return name

        def run_command(self, args, **kwargs):
            self.run_command_calls += 1
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)
            return self.run_command_results.pop(0)

    class MockTime(object):
        def __init__(self):
            self.time_calls = 0
            self.time_

# Generated at 2022-06-17 00:04:25.408656
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:04:48.252248
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-6200U CPU @ 2.30GHz']


# Generated at 2022-06-17 00:04:52.357448
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:04.196960
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Create a dmidecode file

# Generated at 2022-06-17 00:05:16.609693
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.params = {}
    test_module.get_bin_path = lambda x: '/usr/sbin/dmidecode'

# Generated at 2022-06-17 00:05:18.319426
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._fact_class == FreeBSDHardware
    assert hardware_collector._platform == 'FreeBSD'

# Generated at 2022-06-17 00:05:23.411295
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:28.307953
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleStub(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, arg):
            return '/usr/sbin/dmidecode'

        def run_command(self, arg, encoding=None):
            return (self.rc, self.out, self.err)

    class AnsibleModuleStub(object):
        def __init__(self, module):
            self.module = module

    class HardwareStub(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Test with dmidecode executable available

# Generated at 2022-06-17 00:05:33.490588
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:36.198701
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:05:45.342890
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake module
    module = type('', (), {})()
    module.run_command = lambda cmd, encoding=None: (0, '', '')
    module.get_bin_path = lambda cmd: cmd

    # Create a fake class
    class FakeClass:
        def __init__(self):
            self.module = module
    # Create an instance of FreeBSDHardware
    hardware = FreeBSDHardware(FakeClass())

    # Get the uptime facts
    uptime_facts = hardware.get_uptime_facts()

    # Check if uptime_seconds is an integer
    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-17 00:06:23.891205
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:06:34.342315
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'
    assert dmi_facts['product_name'] == 'NA'
    assert dmi_facts['product_version'] == 'NA'
    assert dmi_facts['product_serial'] == 'NA'
    assert dmi_facts['product_uuid'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_asset_tag']

# Generated at 2022-06-17 00:06:39.421977
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-17 00:06:50.406251
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4']
    assert hardware.facts['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4']
    assert hardware.facts['devices']['ada2'] == ['ada2s1', 'ada2s2', 'ada2s3', 'ada2s4']
    assert hardware.facts['devices']['ada3'] == ['ada3s1', 'ada3s2', 'ada3s3', 'ada3s4']

# Generated at 2022-06-17 00:06:54.765861
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:06:57.767346
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._fact_class == FreeBSDHardware
    assert fhc._platform == 'FreeBSD'

# Generated at 2022-06-17 00:07:00.229405
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:07:09.168399
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_args = []
            self.run_command_kwargs = []

        def get_bin_path(self, executable):
            return executable

        def run_command(self, args, encoding=None, check_rc=True):
            self.run_command_calls += 1
            self.run_command_args.append(args)
            self.run_command_kwargs.append(locals())
            return 0, '', ''

    class MockTime(object):
        def __init__(self):
            self.time_calls = 0
            self.time_args = []
            self.time_kwargs = []


# Generated at 2022-06-17 00:07:20.984510
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_

# Generated at 2022-06-17 00:07:29.700277
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Create a FreeBSDHardware object
    hardware = FreeBSDHardware()

    # Create a mock module
    module = MockModule()

    # Set the module attribute of the FreeBSDHardware object
    hardware.module = module

    # Create a mock sysctl command
    sysctl = MockCommand()

    # Set the module attribute of the FreeBSDHardware object
    hardware.module.get_bin_path = Mock(return_value=sysctl)

    # Create a mock dmesg command
    dmesg = MockCommand()

    # Set the module attribute of the FreeBSDHardware object
    hardware.module.get_bin_path = Mock(return_value=dmesg)

    # Create a mock dmesg.boot file
    dmesg_boot = MockFile()

    # Set the module attribute of the FreeBSDHardware object
    hardware.DMESG_BOOT = dmesg

# Generated at 2022-06-17 00:08:20.202462
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test with a valid kern.boottime value
    kern_boottime = b'\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    module.run_command = MagicMock(return_value=(0, kern_boottime, ''))
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time())

    # Test with an invalid kern.boottime value

# Generated at 2022-06-17 00:08:27.061581
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:08:31.070401
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz', 'Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz']
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:08:38.602412
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Check that the method returns a dictionary
    assert isinstance(hardware.get_uptime_facts(), dict)

    # Check that the method returns a dictionary with the key 'uptime_seconds'
    assert 'uptime_seconds' in hardware.get_uptime_facts()

    # Check that the method returns a dictionary with the key 'uptime_seconds'
    # and that the value is an integer
    assert isinstance(hardware.get_uptime_facts()['uptime_seconds'], int)



# Generated at 2022-06-17 00:08:43.132374
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:08:45.595575
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:08:54.414248
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['uptime_seconds']


# Generated at 2022-06-17 00:09:00.942239
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['uptime_seconds']


# Generated at 2022-06-17 00:09:10.905536
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['mounts']
    assert hardware_facts['processor_count']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']
    assert hardware_facts['board_asset_tag']

# Generated at 2022-06-17 00:09:17.935928
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:10:51.183113
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz']


# Generated at 2022-06-17 00:10:54.641450
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-17 00:10:59.060914
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:11:04.319121
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']


# Generated at 2022-06-17 00:11:08.757240
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-17 00:11:17.517228
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert len(hardware_facts['processor']) == hardware_facts['processor_count']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
