

# Generated at 2022-06-17 00:01:33.359476
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-5300U CPU @ 2.30GHz']
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:01:41.415457
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test with dmidecode
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/sbin/dmidecode')

# Generated at 2022-06-17 00:01:47.656700
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0


# Generated at 2022-06-17 00:01:58.088992
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    import unittest

    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, required=False):
            return '/bin/' + name

        def run_command(self, cmd, encoding=None, check_rc=True):
            return self.rc, self.out, self.err

    class TestFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    class TestFreeBSDHardwareCollector(FreeBSDHardwareCollector):
        def __init__(self):
            self.module = None
            self.facts = None


# Generated at 2022-06-17 00:02:09.402493
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'
    assert dmi_facts['board_name'] != 'NA'
    assert dmi_facts['board_version'] != 'NA'
    assert dmi_facts['board_serial'] != 'NA'
    assert dmi_facts['board_asset_tag']

# Generated at 2022-06-17 00:02:17.349715
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert len(hardware_facts['processor']) > 0
    assert len(hardware_facts['devices']) > 0
    assert len(hardware_facts['mounts']) > 0
    assert hardware_facts['bios_date'] != 'NA'
    assert hardware_facts

# Generated at 2022-06-17 00:02:30.928508
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Test get_uptime_facts()
    uptime_facts = freebsd_hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

    # Test get_uptime_facts() with timeout
    freebsd_hardware.timeout = 1
    try:
        uptime_facts = freebsd_hardware.get_uptime_facts()
    except TimeoutError:
        pass

# Generated at 2022-06-17 00:02:36.194763
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:02:43.186295
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0

# Generated at 2022-06-17 00:02:48.969883
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import time

    # Create a FreeBSDHardware instance
    freebsd_hardware = FreeBSDHardware()

    # Get the uptime_seconds fact
    uptime_seconds = freebsd_hardware.get_uptime_facts()['uptime_seconds']

    # Check if the uptime_seconds fact is correct
    assert uptime_seconds == int(time.time())

# Generated at 2022-06-17 00:03:09.744858
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['mounts']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']
    assert hardware_facts['board_asset_tag']

# Generated at 2022-06-17 00:03:18.200622
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['devices'] != {}
    assert hardware_facts['mounts'] != []


# Generated at 2022-06-17 00:03:25.698997
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-6200U CPU @ 2.30GHz']


# Generated at 2022-06-17 00:03:33.443813
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']

# Generated at 2022-06-17 00:03:43.668032
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['processor_count'] == '1'
    assert hardware_facts['processor_cores'] == '1'
    assert hardware_facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']
    assert hardware_facts['memtotal_mb'] == 8192
    assert hardware_facts['memfree_mb'] == 8192
    assert hardware_facts['swaptotal_mb'] == 0
    assert hardware_facts['swapfree_mb'] == 0
    assert hardware_facts['uptime_seconds'] == 0
    assert hardware_facts['devices'] == {}
    assert hardware_facts['mounts'] == []

# Generated at 2022-06-17 00:03:51.568273
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, '', ''))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/dmidecode')
    hardware = FreeBSDHardware(module)
    hardware.get_dmi_facts()
    module.run_command.assert_called_with('/usr/sbin/dmidecode -s system-manufacturer')


# Generated at 2022-06-17 00:03:58.210192
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:04:10.281768
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils._text import to_bytes
    import os
    import tempfile
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary file
    fd, path = tempfile.mkstemp(dir=tmpdir)

    # Create the test class
    test_class = FreeBSDHardware()

    # Create a test file
    with os.fdopen(fd, 'wb') as f:
        f.write(to_bytes('vm.stats.vm.v_page_size: 4096\n'))
        f

# Generated at 2022-06-17 00:04:19.040797
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'
    assert dmi_facts['product_name'] == 'NA'
    assert dmi_facts['product_version'] == 'NA'
    assert dmi_facts['product_serial'] == 'NA'
    assert dmi_facts['product_uuid'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'

# Generated at 2022-06-17 00:04:23.318315
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:04:53.132461
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz', 'Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz']


# Generated at 2022-06-17 00:05:04.466292
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleMock(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if cmd == ['/bin/sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', int(time.time()) - 3600), ''
            else:
                return 1, '', ''

    module = ModuleMock()
    hardware = FreeBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 3600}

# Generated at 2022-06-17 00:05:16.800352
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor'][0]
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']

# Generated at 2022-06-17 00:05:22.371633
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4', 'ada0s5', 'ada0s6', 'ada0s7', 'ada0s8', 'ada0s9', 'ada0s10']
    assert hardware.facts['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4', 'ada1s5', 'ada1s6', 'ada1s7', 'ada1s8', 'ada1s9', 'ada1s10']

# Generated at 2022-06-17 00:05:26.203476
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:05:33.102723
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:05:40.690189
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz']


# Generated at 2022-06-17 00:05:47.917867
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:05:57.081263
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Test FreeBSDHardware.get_dmi_facts method
    '''
    # Create a FreeBSDHardware object
    freebsd_hw = FreeBSDHardware()

    # Create a dmidecode output

# Generated at 2022-06-17 00:06:00.520706
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:15.361526
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:21.772652
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz']


# Generated at 2022-06-17 00:07:28.535331
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['mounts']



# Generated at 2022-06-17 00:07:36.670372
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:07:43.223865
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['devices']
    assert hardware.facts['mounts']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']

# Generated at 2022-06-17 00:07:53.569157
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'

# Generated at 2022-06-17 00:08:02.047530
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {'run_command': run_command})

    # Create a mock class
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Create a FreeBSDHardware object
    hardware = MockFreeBSDHardware(module)

    # Test the method get_uptime_facts
    assert hardware.get_uptime_facts() == {'uptime_seconds': 0}



# Generated at 2022-06-17 00:08:10.215690
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 00:08:17.419111
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz']


# Generated at 2022-06-17 00:08:26.189672
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts
