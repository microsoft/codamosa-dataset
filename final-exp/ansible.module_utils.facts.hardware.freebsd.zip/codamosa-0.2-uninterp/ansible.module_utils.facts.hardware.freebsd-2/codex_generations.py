

# Generated at 2022-06-17 00:01:39.056157
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['board_asset_tag'] != 'NA'

# Generated at 2022-06-17 00:01:49.501249
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor'][0] != ''
    assert hardware_facts['devices'] != {}
    assert hardware_facts['mounts'] != []


# Generated at 2022-06-17 00:01:55.604056
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:02:03.081833
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content

    # Test with dmidecode
    dmi_facts = {}
    dmi_facts['bios_date'] = '01/01/2000'
    dmi_facts['bios_vendor'] = 'Vendor'
    dmi_facts['bios_version'] = '1.0'
    dmi_facts['board_asset_tag'] = 'AssetTag'
    dmi_facts['board_name'] = 'BoardName'
    dmi_facts['board_serial'] = 'BoardSerial'
    dmi_facts['board_vendor'] = 'BoardVendor'


# Generated at 2022-06-17 00:02:11.955526
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    devices = hardware.get_device_facts()
    assert 'devices' in devices
    assert isinstance(devices['devices'], dict)
    assert len(devices['devices']) > 0
    for device in devices['devices']:
        assert isinstance(devices['devices'][device], list)
        assert len(devices['devices'][device]) > 0
        for slice in devices['devices'][device]:
            assert isinstance(slice, str)
            assert len(slice) > 0


# Generated at 2022-06-17 00:02:24.905622
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['board_asset_tag'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['chassis_asset_tag'] == 'NA'
    assert dmi_

# Generated at 2022-06-17 00:02:33.184954
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:45.019302
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = lambda x: x

        def get_bin_path(self, executable):
            return '/usr/sbin/dmidecode'

        def run_command(self, cmd, encoding=None):
            if cmd == '/usr/sbin/dmidecode -s bios-release-date':
                return (0, '01/01/2000\n', '')
            elif cmd == '/usr/sbin/dmidecode -s bios-vendor':
                return (0, 'Vendor\n', '')
            elif cmd == '/usr/sbin/dmidecode -s bios-version':
                return (0, 'Version\n', '')

# Generated at 2022-06-17 00:02:48.464465
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'


# Generated at 2022-06-17 00:02:51.664254
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc._platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:03:11.014890
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor_count' in cpu_facts
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts


# Generated at 2022-06-17 00:03:17.626409
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz', 'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz']


# Generated at 2022-06-17 00:03:25.071151
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3']
    assert hardware.facts['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3']
    assert hardware.facts['devices']['ada2'] == ['ada2s1', 'ada2s2', 'ada2s3']
    assert hardware.facts['devices']['ada3'] == ['ada3s1', 'ada3s2', 'ada3s3']
    assert hardware.facts['devices']['ada4'] == ['ada4s1', 'ada4s2', 'ada4s3']
    assert hardware.facts

# Generated at 2022-06-17 00:03:30.181101
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '4'


# Generated at 2022-06-17 00:03:37.065838
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:03:42.768237
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake module
    module = type('', (), {'run_command': lambda self, cmd, encoding=None: (0, struct.pack('@L', int(time.time() - 100)), '')})
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-17 00:03:51.228512
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-17 00:04:01.501207
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, struct.pack('@L', int(time.time() - 100)), ''),
        'get_bin_path': lambda self, cmd: cmd,
    })()

    # Create an instance of FreeBSDHardware
    hardware = FreeBSDHardware(module)

    # Call the method get_uptime_facts
    uptime_facts = hardware.get_uptime_facts()

    # Assert that the uptime is 100 seconds
    assert uptime_facts['uptime_seconds'] == 100

# Generated at 2022-06-17 00:04:11.820963
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:04:17.785819
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_facts = FreeBSDHardware(module).populate()
    assert hardware_facts['devices']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['uptime_seconds']


# Generated at 2022-06-17 00:04:52.451866
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:04.259558
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:05:16.635559
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']

# Generated at 2022-06-17 00:05:28.829169
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    import time

    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware()

    # Get the current time
    now = time.time()

    # Get the uptime_seconds fact
    uptime_facts = fhw.get_uptime_facts()

    # Check that the uptime_seconds fact is correct
    assert uptime_facts['uptime_seconds'] == int(now - uptime_facts['uptime_seconds'])

    # Check that the timeout is working
    fhw.set_timeout(1)
    try:
        fhw.get_uptime_facts()
    except TimeoutError:
        pass
    else:
        assert False

# Generated at 2022-06-17 00:05:31.988232
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-17 00:05:34.125534
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:05:46.172582
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_

# Generated at 2022-06-17 00:05:57.826039
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.get_device_facts()

# Generated at 2022-06-17 00:06:09.635211
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['board_asset_tag'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['chassis_asset_tag'] == 'NA'
    assert dmi_

# Generated at 2022-06-17 00:06:22.196267
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-17 00:07:17.468016
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:27.131147
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()[0]
    assert hardware.populate()['uptime_seconds'] > 0
    assert hardware.populate()['memtotal_mb'] > 0
    assert hardware.populate()['memfree_mb'] > 0
    assert hardware.populate()['swaptotal_mb'] > 0
    assert hardware.populate()['swapfree_mb'] > 0
    assert hardware.populate()['processor_count'] > 0
    assert hardware.populate()['processor_cores'] > 0
    assert hardware.populate()['devices'] != {}
    assert hardware.populate()['mounts'] != []

# Generated at 2022-06-17 00:07:32.852408
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] is not None
    assert memory_facts['memfree_mb'] is not None
    assert memory_facts['swaptotal_mb'] is not None
    assert memory_facts['swapfree_mb'] is not None

# Generated at 2022-06-17 00:07:36.336629
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:07:46.840123
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    fhw = FreeBSDHardware()

    # Create a dictionary with dmidecode output

# Generated at 2022-06-17 00:07:51.915801
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:55.743841
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:08:02.687634
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:08:09.253106
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector._fact_class == FreeBSDHardware
    assert hardware_collector._platform == 'FreeBSD'

# Generated at 2022-06-17 00:08:20.232603
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert facts['devices']
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']
    assert facts['uptime_seconds']
    assert facts['bios_date']
    assert facts['bios_vendor']
    assert facts['bios_version']
    assert facts['board_asset_tag']
    assert facts['board_name']
    assert facts['board_serial']
    assert facts['board_vendor']
    assert facts['board_version']
    assert facts

# Generated at 2022-06-17 00:10:17.154445
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-17 00:10:28.216208
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:10:36.006239
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'

# Generated at 2022-06-17 00:10:46.431218
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['bios_date'] != 'NA'
    assert hardware_facts['bios_vendor'] != 'NA'
    assert hardware_facts['bios_version'] != 'NA'

# Generated at 2022-06-17 00:10:49.870105
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:10:52.956222
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:10:55.626438
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:11:07.001451
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_

# Generated at 2022-06-17 00:11:10.035671
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
