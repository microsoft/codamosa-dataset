

# Generated at 2022-06-17 00:01:33.861024
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '8'


# Generated at 2022-06-17 00:01:39.819692
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:01:43.970123
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:01:51.885449
# Unit test for method get_uptime_facts of class FreeBSDHardware

# Generated at 2022-06-17 00:02:01.642656
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class TestModule(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None

        def get_bin_path(self, name):
            return '/usr/sbin/dmidecode'

        def run_command(self, cmd, check_rc=True, encoding=None):
            return 0, '', ''

    class TestFacts(object):
        def __init__(self):
            self.facts = {}

    test_module = TestModule()
    test_facts = TestFacts()
    test_hardware = FreeBSDHardware(test_module)
    test_hardware.populate(test_facts)

# Generated at 2022-06-17 00:02:13.765824
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.facts.collector import BaseFileCacheCollector
    from ansible.module_utils.facts.collector import BaseFileCacheModuleCollector
    from ansible.module_utils.facts.collector import BaseFilePersistentCollector
    from ansible.module_utils.facts.collector import BaseFilePersistentModuleCollector

# Generated at 2022-06-17 00:02:26.802806
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_

# Generated at 2022-06-17 00:02:33.793771
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz']


# Generated at 2022-06-17 00:02:40.142116
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:02:47.145957
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0



# Generated at 2022-06-17 00:03:08.547748
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import time

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Get the current time
    current_time = time.time()

    # Get the uptime_seconds fact
    uptime_seconds = freebsd_hardware.get_uptime_facts()['uptime_seconds']

    # Assert that the uptime_seconds fact is less than the current time
    assert uptime_seconds < current_time

# Generated at 2022-06-17 00:03:18.500400
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'uptime_seconds' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'mounts' in facts
    assert 'bios_date' in facts
    assert 'bios_vendor' in facts
    assert 'bios_version' in facts
    assert 'board_asset_tag' in facts
    assert 'board_name' in facts

# Generated at 2022-06-17 00:03:30.028656
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] == 'NA'
    assert dmi_facts['product_name'] == 'NA'
    assert dmi_facts['product_version'] == 'NA'
    assert dmi_facts['product_serial'] == 'NA'
    assert dmi_facts['product_uuid'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_asset_tag']

# Generated at 2022-06-17 00:03:42.365712
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Test the get_uptime_facts method
    uptime_facts = freebsd_hardware.get_uptime_facts()

    # Check if the uptime_facts is a dict
    assert isinstance(uptime_facts, dict)

    # Check if the uptime_facts contains the key 'uptime_seconds'
    assert 'uptime_seconds' in uptime_facts

    # Check if the value of 'uptime_seconds' is an integer
    assert isinstance(uptime_facts['uptime_seconds'], int)

    # Check if the value of 'uptime_seconds'

# Generated at 2022-06-17 00:03:50.658910
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts


# Generated at 2022-06-17 00:04:00.136751
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz', 'Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz']
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-17 00:04:06.390224
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:04:18.596882
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:04:26.150762
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz', 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']


# Generated at 2022-06-17 00:04:35.031218
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:05:15.747479
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-17 00:05:21.782149
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_facts
    assert 'board_serial' in dmi_

# Generated at 2022-06-17 00:05:27.457837
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:05:36.195966
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if cmd == ['sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', int(time.time() - 42)), ''
            else:
                return 1, '', ''

    class TestFreeBSDHardware(unittest.TestCase):
        def setUp(self):
            self.module = MockModule()
            self.hardware = FreeBSDHardware(module=self.module)


# Generated at 2022-06-17 00:05:47.160307
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['board_asset_tag'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'
    assert dmi_facts['board_serial'] == 'NA'
    assert dmi_facts['board_vendor'] == 'NA'
    assert dmi_facts['board_version'] == 'NA'
    assert dmi_facts['chassis_asset_tag'] == 'NA'
    assert dmi_

# Generated at 2022-06-17 00:05:58.957758
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

# Generated at 2022-06-17 00:06:03.305445
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:06:11.088060
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:06:21.075474
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleMock(object):
        def get_bin_path(self, name, required=False):
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None):
            return 0, 'kern.boottime: { sec = 1577983124, usec = 877000 } Fri Jan  3 17:25:24 2020', ''

    class HardwareMock(FreeBSDHardware):
        def __init__(self):
            self.module = ModuleMock()

    hardware = HardwareMock()
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 1577983124

# Generated at 2022-06-17 00:06:27.967899
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4258U CPU @ 2.40GHz']


# Generated at 2022-06-17 00:07:52.639779
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:08:03.867708
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert len(hardware_facts['processor']) > 0
    assert len(hardware_facts['devices']) > 0
    assert len(hardware_facts['mounts']) > 0
    assert hardware_facts['bios_date'] != 'NA'
    assert hardware_facts

# Generated at 2022-06-17 00:08:06.333569
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:08:12.854012
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz']
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-17 00:08:19.356815
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz', 'Intel(R) Core(TM) i5-3320M CPU @ 2.60GHz']


# Generated at 2022-06-17 00:08:26.875522
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import timeout
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size
    from ansible.module_utils.facts.utils import get_file_lines
    from ansible.module_utils.facts.utils import get_file_content
    from ansible.module_utils.facts.utils import get_mount_size

# Generated at 2022-06-17 00:08:31.377233
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Constructor of FreeBSDHardwareCollector class.
    """
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:08:41.375504
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['processor_count'] == '1'
    assert hardware.facts['processor'] == ['Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz']
    assert hardware.facts['processor_cores'] == '4'
    assert hardware.facts['memtotal_mb'] == 8192
    assert hardware.facts['memfree_mb'] == 7981
    assert hardware.facts['swaptotal_mb'] == 0
    assert hardware.facts['swapfree_mb'] == 0
    assert hardware.facts['devices']['ada0'][0] == 'ada0s1a'

# Generated at 2022-06-17 00:08:51.555781
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['bios_date']
    assert hardware_facts['bios_vendor']
    assert hardware_facts['bios_version']
    assert hardware_facts['board_asset_tag']
    assert hardware_facts['board_name']
   

# Generated at 2022-06-17 00:09:01.249821
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memfree_mb'] > 0
    assert hardware_facts['swaptotal_mb'] > 0
    assert hardware_facts['swapfree_mb'] > 0
    assert hardware_facts['processor_count'] > 0
    assert hardware_facts['processor_cores'] > 0
    assert len(hardware_facts['processor']) > 0
    assert len(hardware_facts['devices']) > 0
    assert len(hardware_facts['mounts']) > 0
