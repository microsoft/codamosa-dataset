

# Generated at 2022-06-17 00:01:38.931056
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    fh = FreeBSDHardware()
    dmi_facts = fh.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'

# Generated at 2022-06-17 00:01:50.180728
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:02:00.474292
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a FreeBSDHardware object
    freebsd_hardware = FreeBSDHardware()

    # Call the method get_uptime_facts
    uptime_facts = freebsd_hardware.get_uptime_facts()

    # Check that the method returns a dictionary
    assert isinstance(uptime_facts, dict)

    # Check that the dictionary contains the key 'uptime_seconds'
    assert 'uptime_seconds' in uptime_facts

    # Check that the value of 'uptime_seconds' is an integer
    assert isinstance(uptime_facts['uptime_seconds'], int)

    # Check that the value of 'uptime_seconds' is positive
    assert upt

# Generated at 2022-06-17 00:02:05.228507
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:02:15.768944
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Create a mock module
    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []
            self.run_command_rcs = []
            self.run_command_outs = []
            self.run_command_errs = []

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            return self.run_command_rcs.pop(0), self.run_command_outs.pop(0), self.run_command_errs.pop(0)

    #

# Generated at 2022-06-17 00:02:28.438851
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, b'kern.boottime: { sec = 1528681575, usec = 568000 }\n', ''),
        'get_bin_path': lambda self, cmd: cmd,
    })()

    # Create a mock class
    class_ = type('AnsibleModule_class', (object,), {
        'module': module,
    })

    # Instantiate the class
    hardware = class_()

    # Call the method
    uptime_facts = hardware.get_uptime_facts()

    # Assert the result
    assert uptime_facts == {'uptime_seconds': 1528681575}

# Generated at 2022-06-17 00:02:34.271972
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-5257U CPU @ 2.70GHz']


# Generated at 2022-06-17 00:02:39.730361
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:02:52.069009
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['system_vendor'] != 'NA'
    assert dmi_facts['product_name'] != 'NA'
    assert dmi_facts['product_version'] != 'NA'
    assert dmi_facts['product_serial'] != 'NA'
    assert dmi_facts['product_uuid'] != 'NA'
    assert dmi_facts['bios_vendor'] != 'NA'
    assert dmi_facts['bios_version'] != 'NA'
    assert dmi_facts['bios_date'] != 'NA'
    assert dmi_facts['board_vendor'] != 'NA'

# Generated at 2022-06-17 00:03:01.089742
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = type('AnsibleModule', (object,), {
        'run_command': lambda self, cmd, encoding=None: (0, struct.pack('@L', int(time.time())), ''),
        'get_bin_path': lambda self, cmd: cmd,
    })()

    # Create a FreeBSDHardware object
    hardware = FreeBSDHardware(module)

    # Call the get_uptime_facts method
    uptime_facts = hardware.get_uptime_facts()

    # Check that the uptime_seconds fact is present
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-17 00:03:23.392977
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock class
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Create a mock class
    class MockTime(object):
        def __init__(self):
            self.time = 0

        def time(self):
            self.time += 1
            return self.time

    # Create a mock class
    class MockStruct(object):
        def __init__(self):
            self.struct = 0

        def calcsize(self, format):
            return 8

        def unpack(self, format, data):
            return (self.struct, )

    # Create a mock class

# Generated at 2022-06-17 00:03:32.546306
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import datetime
    import time
    import unittest

    class MockModule(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name):
            return '/bin/' + name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if cmd == ['/bin/sysctl', '-b', 'kern.boottime']:
                return (0, '\x00\x00\x00\x00\x00\x00\x00\x00', '')
            else:
                raise Exception('Unexpected command: %s' % cmd)

    class MockTime(object):
        def __init__(self):
            self.time_calls = []

# Generated at 2022-06-17 00:03:37.464007
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    Test FreeBSDHardwareCollector constructor
    """
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:03:43.451315
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:03:51.104764
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    class ModuleMock(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, name):
            return name

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append(cmd)
            if cmd == ['/sbin/sysctl', '-b', 'kern.boottime']:
                return 0, b'\x00\x00\x00\x00\x00\x00\x00\x00', ''
            else:
                return 1, '', ''


# Generated at 2022-06-17 00:04:02.706355
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']
    assert hardware.facts['memtotal_mb']
    assert hardware.facts['memfree_mb']
    assert hardware.facts['swaptotal_mb']
    assert hardware.facts['swapfree_mb']
    assert hardware.facts['processor']
    assert hardware.facts['processor_cores']
    assert hardware.facts['processor_count']
    assert hardware.facts['uptime_seconds']
    assert hardware.facts['bios_date']
    assert hardware.facts['bios_vendor']
    assert hardware.facts['bios_version']
    assert hardware.facts['board_asset_tag']
    assert hardware.facts['board_name']
    assert hardware.facts

# Generated at 2022-06-17 00:04:05.253389
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:04:12.633278
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_

# Generated at 2022-06-17 00:04:23.663598
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ada0'] == ['ada0s1a', 'ada0s1b', 'ada0s1d', 'ada0s1e', 'ada0s1f', 'ada0s1g', 'ada0s1h']
    assert hardware.facts['devices']['ada1'] == ['ada1s1']
    assert hardware.facts['devices']['ada2'] == ['ada2s1']
    assert hardware.facts['devices']['ada3'] == ['ada3s1']
    assert hardware.facts['devices']['ada4'] == ['ada4s1']
    assert hardware.facts['devices']['ada5'] == ['ada5s1']
   

# Generated at 2022-06-17 00:04:30.707946
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']


# Generated at 2022-06-17 00:05:00.272655
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:05:08.440566
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['devices']
    assert hardware_facts['mounts']


# Generated at 2022-06-17 00:05:17.617557
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts

# Generated at 2022-06-17 00:05:29.894177
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class TestModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, name, opt_dirs=[]):
            return '/usr/bin/' + name

        def run_command(self, cmd, check_rc=True, encoding=None):
            return self.rc, self.out, self.err

    class TestFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # Test case 1: sysctl command returns error
    module1 = TestModule(1, '', '')
    freebsd_hardware1 = TestFreeBSDHardware(module1)
    memory_facts1 = freebsd_hardware1.get

# Generated at 2022-06-17 00:05:33.886299
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:05:40.405255
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0


# Generated at 2022-06-17 00:05:42.880739
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:05:51.955591
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert facts['devices']
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']
    assert facts['memfree_mb']
    assert facts['memtotal_mb']
    assert facts['swapfree_mb']
    assert facts['swaptotal_mb']
    assert facts['uptime_seconds']
    assert facts['devices']
    assert facts['mounts']
    assert facts['bios_date']
    assert facts['bios_vendor']
    assert facts['bios_version']
    assert facts['board_asset_tag']
    assert facts['board_name']
    assert facts['board_serial']

# Generated at 2022-06-17 00:05:54.022982
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:06:02.013810
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'board_vendor' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_version' in dmi_

# Generated at 2022-06-17 00:06:41.784729
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError
    from ansible.module_utils.facts.utils import get_file_content
    import os
    import tempfile
    import shutil
    import json
    import pytest

    # Create a temporary directory
    tmpdir = tempfile.mkdtemp()

    # Create a temporary dmidecode file
    dmidecode_file = os.path.join(tmpdir, 'dmidecode')

# Generated at 2022-06-17 00:06:46.992803
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:06:53.567989
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    dmi_facts = hardware.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'product_serial' in dmi_facts
    assert 'product_uuid' in dmi_facts
    assert 'product_version' in dmi_facts
    assert 'bios_date' in dmi_facts
    assert 'bios_vendor' in dmi_facts
    assert 'bios_version' in dmi_facts
    assert 'board_asset_tag' in dmi_facts
    assert 'board_name' in dmi_facts
    assert 'board_serial' in dmi_facts

# Generated at 2022-06-17 00:07:00.936796
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0



# Generated at 2022-06-17 00:07:11.741274
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test with a valid kern.boottime value
    kern_boottime = b'\x00\x00\x00\x00\x00\x00\x00\x00'
    with patch('ansible.module_utils.facts.hardware.freebsd.open', mock_open(read_data=kern_boottime), create=True):
        uptime_facts = hardware.get_uptime_facts()
        assert uptime_facts['uptime_seconds'] == 0

    # Test with an invalid kern.boottime value
    kern_boottime = b'\x00\x00\x00\x00\x00\x00\x00'

# Generated at 2022-06-17 00:07:17.384962
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert 'processor_cores' in cpu_facts
    assert 'processor_count' in cpu_facts


# Generated at 2022-06-17 00:07:24.583475
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0


# Generated at 2022-06-17 00:07:29.460137
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:07:35.836441
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert uptime_facts['uptime_seconds'] > 0

# Generated at 2022-06-17 00:07:45.748526
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert facts['devices']
    assert facts['devices']['ada0']
    assert facts['devices']['ada0'][0] == 'ada0s1'
    assert facts['devices']['ada0'][1] == 'ada0s2'
    assert facts['devices']['ada0'][2] == 'ada0s3'
    assert facts['devices']['ada0'][3] == 'ada0s4'
    assert facts['devices']['ada0'][4] == 'ada0s5'
    assert facts['devices']['ada0'][5] == 'ada0s6'

# Generated at 2022-06-17 00:09:10.588328
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware

# Generated at 2022-06-17 00:09:19.931429
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']
    assert hardware_facts['mounts']
    assert hardware_facts['processor']
    assert hardware_facts['processor_cores']
    assert hardware_facts['processor_count']
    assert hardware_facts['memfree_mb']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swapfree_mb']
    assert hardware_facts['swaptotal_mb']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['dmi']


# Generated at 2022-06-17 00:09:21.606173
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:09:29.173896
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4770 CPU @ 3.40GHz']
    assert cpu_facts['processor_cores'] == '4'
    assert cpu_facts['processor_count'] == '8'


# Generated at 2022-06-17 00:09:38.752812
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    facts = hardware.populate()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts


# Generated at 2022-06-17 00:09:44.520236
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '2'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz', 'Intel(R) Core(TM) i5-3210M CPU @ 2.50GHz']


# Generated at 2022-06-17 00:09:49.864019
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0



# Generated at 2022-06-17 00:09:55.126200
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    assert hw.platform == 'FreeBSD'
    assert hw.fact_class == FreeBSDHardware


# Generated at 2022-06-17 00:10:01.322544
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware.populate()
    assert hardware.facts['devices']['ada0'] == ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4']
    assert hardware.facts['devices']['ada1'] == ['ada1s1', 'ada1s2', 'ada1s3', 'ada1s4']
    assert hardware.facts['devices']['ada2'] == ['ada2s1', 'ada2s2', 'ada2s3', 'ada2s4']
    assert hardware.facts['devices']['ada3'] == ['ada3s1', 'ada3s2', 'ada3s3', 'ada3s4']

# Generated at 2022-06-17 00:10:05.957782
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert memory_facts['memfree_mb'] > 0
    assert memory_facts['swaptotal_mb'] > 0
    assert memory_facts['swapfree_mb'] > 0
