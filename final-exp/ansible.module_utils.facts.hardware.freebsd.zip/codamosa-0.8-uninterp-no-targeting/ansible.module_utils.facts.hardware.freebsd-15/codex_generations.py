

# Generated at 2022-06-20 17:18:04.806115
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils import basic

    module = basic.AnsibleModule(argument_spec={})
    module.run_command = lambda *args, **kwargs: (0, '', '')

    hw = FreeBSDHardware(module)

    # an output with a content as expected
    hw.get_uptime_facts = lambda: ({'uptime_seconds': 1467381801}, '', 0)
    (out, err, rc) = hw.get_uptime_facts()

    # the result should be a dict
    assert isinstance(out, dict)
    # the result should have a key named uptime_seconds
    assert 'uptime_seconds' in out
    # the value of the key uptime_seconds should be an int
    assert isinstance(out['uptime_seconds'], int)
    #

# Generated at 2022-06-20 17:18:16.255985
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:18:27.982493
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Testing FreeBSDHardware class
    results = {}

    mem = FreeBSDHardware()

    # Test the get_memory_facts method
    results.update(mem.get_memory_facts())

    # Test if memtotal_mb is an integer
    assert isinstance(results['memtotal_mb'], int), "memtotal_mb type is " + type(results['memtotal_mb'])

    # Test if memfree_mb is an integer
    assert isinstance(results['memfree_mb'], int), "memfree_mb type is " + type(results['memfree_mb'])

    # Test if swaptotal_mb is an integer

# Generated at 2022-06-20 17:18:37.648642
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class MockModule:
        def __init__(self):
            self.params = dict()
            self.check_mode = False
            self.debug = False
            self.run_command = self._run_command


# Generated at 2022-06-20 17:18:50.307200
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module)
    hardware.module.run_command = FakeRunCommand(output1='vm.stats.vm.v_page_size: 16384',
                                                 output2='vm.stats.vm.v_page_count: 314368',
                                                 output3='vm.stats.vm.v_free_count: 314368')
    hardware.module.get_bin_path = FakeGetBinPath(path1='/sbin/sysctl')
    sysctl_cmd = hardware.module.get_bin_path('sysctl')
    rc, out, err = hardware.module.run_command("%s -n hw.ncpu" % sysctl_cmd, check_rc=False)

# Generated at 2022-06-20 17:19:01.249733
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all']),
    })
    # The result should be a subset of the following facts:

# Generated at 2022-06-20 17:19:14.146525
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class ModuleMock:
        @staticmethod
        def get_bin_path(arg):
            if arg == 'sysctl':
                return 'sysctl'

        @staticmethod
        def run_command(cmd, encoding=None):
            assert cmd == 'sysctl -b kern.boottime'
            return 0, '\x00\x00\x00\x00', ''

    class FactsMock:
        def __init__(self):
            self.facts = {}

        def get(self):
            return self.facts

        def add(self, fact, value):
            self.facts[fact] = value

    module = ModuleMock()
    facts = FactsMock()
    hw = FreeBSDHardware(module, facts)
    uptime_facts = hw.get_uptime_facts()
    assert uptime

# Generated at 2022-06-20 17:19:22.609742
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    module.run_command = Mock(return_value=(0, "test_out", "test_err"))
    # Define a test fixture for fact collection, where the user does not have
    # dmidecode on their system.
    test_hw = FreeBSDHardware({'module': module, 'ansible_facts': {'ansible_system': 'FreeBSD'}})
    test_hw.module.get_bin_path = Mock(return_value=None)

    # Assert that the output of get_dmi_facts is a dictionary with the fact
    # names as keys and 'NA' as values.
    dmi_facts = test_hw.get_dmi_facts()
    assert len(dmi_facts) == 14

# Generated at 2022-06-20 17:19:31.429617
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Setup
    module = FakeModule()

    hardware = FreeBSDHardware(module=module)

    hardware.module.run_command = MagicMock(return_value=(0, '/dev/da0s1', ''))
    hardware.module.get_bin_path = MagicMock(return_value='/sbin/sysctl')

    # Test
    result = hardware.get_device_facts()

    # Assertions
    assert result['devices']['da0'] == ['da0s1']


# Generated at 2022-06-20 17:19:44.169255
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """This function unit test FreeBSDHardware.populate()."""

    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)

    # Create a FreeBSDHardware object and call populate()
    freebsdhardware = FreeBSDHardware()
    freebsdhardware.populate()

    #memfree_mb is present
    assert('memfree_mb' in freebsdhardware.facts)
    assert(freebsdhardware.facts['memfree_mb'] > 0)

    #memtotal_mb is present
    assert('memtotal_mb' in freebsdhardware.facts)
    assert(freebsdhardware.facts['memtotal_mb'] > 0)

    #processor is present
    assert('processor' in freebsdhardware.facts)

# Generated at 2022-06-20 17:20:01.086483
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fb_hardware = FreeBSDHardware()
    ret = fb_hardware.get_cpu_facts()
    assert 'processor' in ret
    assert 'processor_count' in ret
    assert 'processor_cores' in ret


# Generated at 2022-06-20 17:20:06.411804
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = DummyAnsibleModule()
    module.run_command = DummyRunCommand()
    sysctl = module.get_bin_path('sysctl')
    if sysctl:
        out = b'hw.ncpu: 4'
        module.run_command.set('%s -n hw.ncpu' % sysctl, (0, out, None))

    freebsd_hardware = FreeBSDHardware(module=module)
    cpu_facts = freebsd_hardware.get_cpu_facts()
    expected_facts = {
        'processor': ['Intel(R) Core(TM) i3-3220 CPU @ 3.30GHz'],
        'processor_cores': '4',
        'processor_count': '4',
    }
    assert cpu_facts == expected_facts


# Generated at 2022-06-20 17:20:14.346199
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fhw = FreeBSDHardwareCollector()
    fhw.module.run_command = fake_run_command
    cpu_facts = fhw.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz', 'Intel(R) Core(TM) i5-4570 CPU @ 3.20GHz']
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-20 17:20:16.472464
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    hw = FreeBSDHardware()
    assert hw.plugin is not None

# Generated at 2022-06-20 17:20:25.949111
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils import basic
    from collections import namedtuple
    module_args = {}
    module = basic.AnsibleModule(argument_spec=module_args)
    freebsd_hw = FreeBSDHardware(module)
    swapfile_size = 512 * 1024 * 1024
    test_input = (
        '''
        vm.stats.vm.v_page_size=4096
        vm.stats.vm.v_page_count=8257536
        vm.stats.vm.v_free_count=3936191
        ''',
        '''
        Device          1M-blocks     Used    Avail Capacity
        /dev/ada0p3        314368        0   314368     0%
        '''
    )

# Generated at 2022-06-20 17:20:36.129511
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts import Collector

    class BSDHardwareCollectorMock(FreeBSDHardwareCollector):
        def __init__(self, module):
            super(BSDHardwareCollectorMock, self).__init__(module)

            # Mock CPU facts

# Generated at 2022-06-20 17:20:40.201624
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    result = {
        "processor": ["AMD Phenom(tm) II X4 955 Processor"],
        "processor_cores": "4",
        "processor_count": "4"
    }
    assert FreeBSDHardware(None).get_cpu_facts() == result



# Generated at 2022-06-20 17:20:49.044794
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json
    module.run_command = run_command
    module.get_bin_path = get_bin_path
    freebsdhardware = FreeBSDHardware(module=module)

    print("----testing get_device_facts()----")
    devices_dict = {'sysdir': '/dev', 'devices': {}}

# Generated at 2022-06-20 17:20:52.684286
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True )

    hardware = FreeBSDHardware(module)
    uptime = hardware.get_uptime_facts()

    module.exit_json(ansible_facts=uptime)



# Generated at 2022-06-20 17:20:57.302529
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """
    unit test for construction of class FreeBSDHardware
    """
    facts = FreeBSDHardware('setup', None)

    assert facts.platform == 'FreeBSD'
    assert facts._platform == 'FreeBSD'
    assert facts.get_devices() == None

# Generated at 2022-06-20 17:21:28.674170
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fbsd_hw = FreeBSDHardware()
    drive_info = {'ada0': ['ada0s1', 'ada0s2', 'ada0s3a', 'ada0s3b', 'ada0s3c'], 'ada1': ['ada1s1', 'ada1s2']}
    assert fbsd_hw.get_device_facts()['devices'] == drive_info



# Generated at 2022-06-20 17:21:37.051801
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class TestModule(object):
        def get_bin_path(self, command):
            class TestPath(object):
                def __init__(self, path):
                    self.path = path
            command_path = os.path.join(os.sep, 'usr', 'bin', command)
            return TestPath(os.path.abspath(command_path))

        def run_command(self, command, encoding=None):
            timestamp_micro = int(round(time.time() * 1000000))
            timestamp = int(timestamp_micro / 1000000)
            (timestamp_hi, timestamp_lo) = (timestamp // 2**32, timestamp % 2**32)
            buf = struct.pack('@QQ', timestamp_hi, timestamp_lo)
            return(0, buf, '')

    module = TestModule

# Generated at 2022-06-20 17:21:48.400705
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    class FakeModule(object):

        def __init__(self, rc=0, out='', err=''):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, executable, required=False):
            return '/bin/sysctl'

        def run_command(self, executable, check_rc=True, encoding=None):
            return self.rc, self.out, self.err


# Generated at 2022-06-20 17:22:00.375213
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_module = type('module', (object, ), {})
    test_module.run_command = lambda x: (0, '/dev/ada0p3        314368        0   314368     0%', None)

    freebsd_hw = FreeBSDHardware(module=test_module)
    freebsd_hw.populate()

    assert freebsd_hw.facts['devices'] == {'ada0': ['ada0s1', 'ada0s2', 'ada0s3'], 'ada1': ['ada1s1', 'ada1s2', 'ada1s3']}
    assert len(freebsd_hw.facts['mounts']) >= 3

# Generated at 2022-06-20 17:22:05.586896
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a class instance
    fhw = FreeBSDHardware()

    # Create dmi facts
    dmi_facts = fhw.get_dmi_facts()

    # Create a dictionary with some dmi properties.
    # This is what dmidecode -s chassis-manufacturer returns.
    dmi_dict_1 = {'chassis_vendor': 'LENOVO'}

    # Check that the value for the chassis-manufacturer key is equal to LENOVO.
    assert dmi_dict_1['chassis_vendor'] == dmi_facts['chassis_vendor']

# Generated at 2022-06-20 17:22:15.793776
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = FreeBSDHardwareCollector()
    assert isinstance(facts, HardwareCollector)
    assert isinstance(facts.get_facts(), dict)
    assert isinstance(facts.get_facts()['processor'], list)
    assert isinstance(facts.get_facts()['processor_cores'], int)
    assert isinstance(facts.get_facts()['processor_count'], int)
    assert isinstance(facts.get_facts()['memtotal_mb'], int)
    assert isinstance(facts.get_facts()['memfree_mb'], int)

# Generated at 2022-06-20 17:22:19.780456
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()
    result = hardware.get_cpu_facts()

    assert result['processor_count'] == "1"
    assert result['processor'] == ["Intel(R) Core(TM) i7-3517U CPU @ 1.90GHz"]
    assert result['processor_cores'] == "2"


# Generated at 2022-06-20 17:22:23.553904
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    Unit test for test_FreeBSDHardware_populate
    '''
    hardware = FreeBSDHardware()
    hardware.populate()
    return True


if __name__ == '__main__':
    test_FreeBSDHardware_populate()

# Generated at 2022-06-20 17:22:29.089166
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_hardware = FreeBSDHardware()
    test_hardware.module = DummyModule()
    test_hardware.populate()

    assert test_hardware.facts['processor_cores'] is not None
    assert test_hardware.facts['processor_count'] is not None
    assert len(test_hardware.facts['processor']) == int(test_hardware.facts['processor_count'])



# Generated at 2022-06-20 17:22:34.946568
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.facts import Facts
    import ansible.module_utils.facts.hardware.freebsd

    # Create some dummy data
    module = type('', (), {})()
    module.get_bin_path = lambda x: 'dmidecode'
    module.run_command = lambda x: (0, 'simulated output', None)

    # Create the object and run
    facts = FreeBSDHardware(module).populate()
    assert 'bios_date' in facts

# Generated at 2022-06-20 17:23:25.629548
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f = FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:23:38.866482
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    ''' test get_device_facts of class FreeBSDHardware'''
    class TestModule:
        def __init__(self, device='da0'):
            self.path = '/usr/local/bin:/usr/bin:/bin:/usr/local/sbin:/usr/sbin:/sbin'
            self.device = device

        def get_bin_path(self, name, required=False):
            if name == 'diskinfo':
                return '/sbin/' + name

        def run_command(self, command, check_rc=True, encoding='utf-8', errors='ignore'):
            ''' return 0 for success, 1 for no device, 2 for failure'''

# Generated at 2022-06-20 17:23:44.249255
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec=dict())
    freebsd_hardware = FreeBSDHardware(module=module)

# Generated at 2022-06-20 17:23:52.766272
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mockModule = MockModule()
    mockModule.run_command = Mock(return_value=(0, 'hw.ncpu: 4\nhw.ncpu: 4', None))
    mockModule.get_bin_path = Mock(return_value='/usr/local/bin/sysctl')
    freeBSDHardware = FreeBSDHardware(mockModule)
    freeBSDHardware.get_memory_facts()
    assert freeBSDHardware.facts['memtotal_mb'] == 2046
    assert freeBSDHardware.facts['memfree_mb'] == 755



# Generated at 2022-06-20 17:24:03.084963
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    facts = dict()
    module = FakeAnsibleModule('FreeBSDHardware')
    hardware = FreeBSDHardware(module)
    hardware.populate()

    assert hardware.get_file_content('/proc/cpuinfo')
    assert hardware.get_file_content(FreeBSDHardware.DMESG_BOOT)

    # Test sysctl
    hardware.module.run_command = MagicMock()
    hardware.get_cpu_facts()
    hardware.module.run_command.assert_called_once_with('sysctl -n hw.ncpu')
    args, kwargs = hardware.module.run_command.call_args
    assert args[0] == 'sysctl -n hw.ncpu'

    hardware.get_memory_facts()

# Generated at 2022-06-20 17:24:14.999306
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    hw = FreeBSDHardware(module)
    hw.get_device_facts()

# Generated at 2022-06-20 17:24:22.993171
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import timeout

    class FakeModule:
        def __init__(self):
            self.run_command_dict = {}
            self.run_command_dict['btime'] = (
                0,
                struct.pack('@L', int(time.time() - 30)),
            )

        def get_bin_path(self, cmd):
            return cmd

        def run_command(self, cmd, encoding=None, check_rc=True):
            if check_rc:
                return self.run_command_dict[cmd.split()[2]]
            else:
                return self.run_command_dict.get(cmd.split()[2], (1, '', ''))


# Generated at 2022-06-20 17:24:24.997741
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # TODO: mock the actual system calls here, not the classes.
    # Requires the distinction between the Hardware class and the HardwareCollector class
    freebsd_hardware = FreeBSDHardware()
    freebsd_hardware.populate()

# Generated at 2022-06-20 17:24:32.102822
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    context = {}
    def run_command(self, args, check_rc=False, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None,
                    use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_then_replace',
                    create_tmp_path_for_shell=False):
        if args == '/sbin/swapinfo -k':
            return 0, textwrap.dedent('''
                Device          1M-blocks     Used    Avail Capacity
                /dev/ada0p3        314368        0   314368     0%
            '''), ''

        if args == '/sbin/sysctl vm.stats':
            return 0,

# Generated at 2022-06-20 17:24:43.234022
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Test FreeBSDHardware.get_uptime_facts method.

    If timezone is configured to UTC, the unix time returned in the test could
    be in the future.
    """
    # Create a FreeBSDHardware instance with no module
    bsd = FreeBSDHardware(None)

    # Create a False Time module to mock the behavior of time.time
    class Time:
        def __init__(self, time=0):
            self.time = time

        def time(self):
            return self.time

    # Test behavior at first second after epoch
    t = Time(1)
    assert bsd.get_uptime_facts(t) == {'uptime_seconds': 1}

    # Test behavior at first second after 1900
    t.time = (31 * 366 + 7) * 24 * 3600 + 1

# Generated at 2022-06-20 17:26:44.501445
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )

    fhw_o = FreeBSDHardware(module=module)
    fhw_o.get_device_facts()
    module.exit_json(changed=False)
# vim: set et ts=4 sw=4 :

# Generated at 2022-06-20 17:26:54.286677
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class Args(object):
        def __init__(self, bin_path=''):
            self.bin_path = bin_path

    class Module(object):
        def __init__(self):
            self.params = {}
            self.args = Args()

        def get_bin_path(self, arg, opt_dirs=[]):
            return None

        def run_command(self, cmd, encoding=None, errors='strict', check_rc=True):
            return 0, '', ''

    module = Module()
    facts = FreeBSDHardware(module).populate()
    assert isinstance(facts, dict)
    assert 'devices' in facts
    assert isinstance(facts['devices'], dict)
    assert 'ada0' in facts['devices'].keys()
    assert facts['devices']['ada0']

# Generated at 2022-06-20 17:26:56.363487
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    hardware = FreeBSDHardware({})
    hardware.get_memory_facts()

# Generated at 2022-06-20 17:26:59.373548
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MockModule()
    f = FreeBSDHardware(module)
    f.get_memory_facts()
    assert f.facts.get('memtotal_mb') == 400
    assert f.facts.get('swaptotal_mb') == 800

# Generated at 2022-06-20 17:27:12.621104
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import os
    import time
    import struct
    import unittest

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class TestFreeBSDHardware(unittest.TestCase):

        def setUp(self):
            self._hardware = FreeBSDHardware()

        def tearDown(self):
            pass

        def _write_boottime(self, seconds):
            sysctl_cmd = self._hardware.module.get_bin_path('sysctl')
            if sysctl_cmd is None:
                return False

            struct_format = '@L'
            struct_size = struct.calcsize(struct_format)
            boottime = struct.pack(struct_format, seconds)

            # Write the boottime to a file.
            boottime_file = '/tmp/boottime'
           

# Generated at 2022-06-20 17:27:14.152373
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''
    Unit test for constructor of class FreeBSDHardwareCollector
    '''
    hardware_facts = FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:27:26.347146
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a subclass of the class FreeBSDHardware used in this file
    class test_FreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module

    # create a subclass of AnsibleModule used in the testing
    class TestAnsibleModule(object):

        def __init__(self):
            self.params = {}
            self.result = dict(changed=False, ansible_facts={})

        def get_bin_path(self, arg, opt_dirs=[]):
            if arg == 'dmidecode':
                return '/usr/sbin/dmidecode'
            else:
                return None

        def run_command(self, cmd):
            return (0, "", "")

    # create the AnsibleModule object to run the tests
    am = TestAnsibleModule()

# Generated at 2022-06-20 17:27:37.622374
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardwareCollector().collect()
    assert hardware.pop('_ansible_device_id') == 'localhost'
    assert hardware.pop('_ansible_system') == 'FreeBSD'
    assert hardware.pop('_ansible_version') == 2
    assert hardware.pop('_ansible_python_version') == '2.7.12'
    assert hardware.pop('_facts_cache') is None

    assert 'devices' in hardware
    assert 'mounts' in hardware
    assert 'memfree_mb' in hardware
    assert 'memtotal_mb' in hardware
    assert 'processor' in hardware
    assert 'processor_cores' in hardware
    assert 'processor_count' in hardware
    assert 'swapfree_mb' in hardware
    assert 'swaptotal_mb' in hardware