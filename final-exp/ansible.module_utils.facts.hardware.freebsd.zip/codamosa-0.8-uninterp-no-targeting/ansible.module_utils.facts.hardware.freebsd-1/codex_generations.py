

# Generated at 2022-06-20 17:18:01.922879
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Tests whether the get_dmi_facts function of FreeBSDHardware returns
    sensible data. The function is hard to test, as it relies on dmidecode
    to be present in PATH. Thus, the test case relies on dmidecode to be
    present, at least in version 2.12, where we get the test data from
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class MockModule:
        def __init__(self):
            self.fail_json = None

            # Set the real binary paths and names here
            self.params = {'bin_path': '/usr/bin'}
            self.get_bin_path = self._get_bin_path

        def _get_bin_path(self, name):
            return self.params['bin_path'] + '/'

# Generated at 2022-06-20 17:18:13.203878
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:18:25.330535
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test with /proc/meminfo
    test_file = '/proc/meminfo'
    os.environ['ANSIBLE_MEMORY_FACT_FILE'] = test_file
    test_object = FreeBSDHardware()
    meminfo_result = test_object.get_memory_facts()
    meminfo_expect = {
        'memtotal_mb': 1630371,
        'memfree_mb': 1304444,
        'swaptotal_mb': 0,
        'swapfree_mb': 0,
        'swapcached_mb': 0,
        'buffers_mb': 50115,
        'cached_mb': 65431,
        }
    for each in meminfo_expect:
        assert meminfo_result[each] == meminfo_expect[each]

    # Test with /

# Generated at 2022-06-20 17:18:35.598712
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import mock
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create an instance of FreeBSDHardware class
    hardware = FreeBSDHardware(None)

    # Create a mocked module
    MockedModule = mock.Mock()
    MockedModule.run_command = mock.Mock(return_value=(0, '4', ''))
    MockedModule.get_bin_path = mock.Mock(return_value='/sbin/sysctl')

    # inject the mocked module into the FreeBSDHardware instance
    hardware.module = MockedModule

    # dmesg_boot is a static member of class FreeBSDHardware

# Generated at 2022-06-20 17:18:37.623688
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw_freebsd = FreeBSDHardware(dict(), dict())
    assert hw_freebsd is not None

# Generated at 2022-06-20 17:18:50.265926
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class ModuleDummy:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = b"""
                hw.ncpu: 4
                hw.physmem: 8589934592
                vm.stats.vm.v_page_size: 4096
                vm.stats.vm.v_page_count: 2097152
                vm.stats.vm.v_free_count: 2097152
                Device          1M-blocks     Used    Avail Capacity
                /dev/ada0p3        314368        0   314368     0%
                Device         Mounted on
                /dev/ada0p3   /
                """

        def get_bin_path(self, name):
            return '/sbin/' + name


# Generated at 2022-06-20 17:18:54.205981
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    module.fail_json = fail_json

    fhw = FreeBSDHardware(module)
    facts = fhw.populate()

    if 'uptime_seconds' in facts:
        assert(facts['uptime_seconds'] > 0)

# Generated at 2022-06-20 17:19:03.309951
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = None

# Generated at 2022-06-20 17:19:14.632280
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware_facts = FreeBSDHardware(dict(module=None))
    hardware_facts.module.run_command = mock_run_command

    hardware_facts.get_memory_facts()
    if hasattr(hardware_facts, 'memtotal_mb'):
        assert hardware_facts.memtotal_mb == 3933
    if hasattr(hardware_facts, 'memfree_mb'):
        assert hardware_facts.memfree_mb == 2169
    if hasattr(hardware_facts, 'swaptotal_mb'):
        assert hardware_facts.swaptotal_mb == 2047
    if hasattr(hardware_facts, 'swapfree_mb'):
        assert hardware_facts.swapfree_mb == 2047



# Generated at 2022-06-20 17:19:20.047393
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    facts = {'module_setup': True}
    m = FreeBSDHardwareCollector(None, facts, None)

    m.module.run_command = lambda x, encoding=None: (0, b'kern.boottime: { sec = 1576347140, usec = 639245 }\n', None)
    uptime_facts = m.get_facts()['uptime_seconds']
    assert uptime_facts == 1576347140


# Generated at 2022-06-20 17:19:41.569756
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardwareCollector()
    hardware.distro = 'FreeBSD'
    hardware.module.run_command = lambda *args, **kwargs: ("some text output", None)
    hardware.get_file_content = lambda *args, **kwargs: "some text output"
    hardware.get_mount_facts = lambda *args, **kwargs: {'mounts': []}
    hardware.get_cpu_facts()
    hardware.get_device_facts()
    hardware.get_dmi_facts()
    hardware.get_memory_facts()
    hardware.get_uptime_facts()

# Generated at 2022-06-20 17:19:50.101653
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class TestModule():
        def __init__(self):
            self.params = dict()
        def run_command(self, cmd, encoding=None, check_rc=True):
            return (0, cmd, None)
        def get_bin_path(self, arg):
            return 'sysctl'

    test_obj = FreeBSDHardware(TestModule())

    # The kern.boottime sysctl is sometimes zero, causing `uptime_seconds`
    # to be negative. The expected result is therefore positive.
    assert test_obj.get_uptime_facts()['uptime_seconds'] >= 0

# Generated at 2022-06-20 17:19:54.828352
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    hw = FreeBSDHardware(module)

    kern_boottime = int(time.time()) - 3600
    boottime_raw = struct.pack('@L', kern_boottime)
    assert hw.get_uptime_facts() == {'uptime_seconds': 3600}
    assert hw.get_uptime_facts(boottime_raw) == {'uptime_seconds': 3600}

# Generated at 2022-06-20 17:19:59.697994
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.parsers import dmesg

# Generated at 2022-06-20 17:20:12.548986
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class Hardware(object):
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, name):
            return "/sbin/%s" % name

        def run_command(self, cmd, check_rc=False, encoding=None):
            if cmd == "/sbin/sysctl vm.stats":
                return (0, "vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 1221952\nvm.stats.vm.v_free_count: 434573", None)
            if cmd == "/sbin/swapinfo -k":
                return (0, "Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%", None)

# Generated at 2022-06-20 17:20:18.305275
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    result = hardware.get_cpu_facts()

    assert 'processor_count' in result
    assert 'processor' in result
    assert 'processor_cores' in result



# Generated at 2022-06-20 17:20:23.953932
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor'][0] == 'Intel(R) Celeron(R) CPU N2930 @ 1.83GHz'
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '4'


# Generated at 2022-06-20 17:20:35.296385
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware(None)


# Generated at 2022-06-20 17:20:45.799451
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule({})
    hardware = FreeBSDHardware(module)
    # get_cpu_facts
    cmd = module.get_bin_path('sysctl')
    rc, out, err = module.run_command("%s -n hw.ncpu" % cmd, check_rc=False)
    hw_ncpu = out.strip()
    cmd = module.get_bin_path('dmesg')
    rc, dmesg_boot, err = module.run_command("%s" % cmd, check_rc=False)
    cpu = []
    processor_cores = 0
    for line in dmesg_boot.splitlines():
        if 'CPU:' in line:
            cpu.append(re.sub(r'CPU:\s+', r"", line).strip())

# Generated at 2022-06-20 17:20:49.365996
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''
    Test the class constructor to ensure it is not broken.  Simply create the
    class instance.  It will only succeed if all of its bases classes are present
    and constructed correctly.  If any of the bases is broken it will fail.  This
    test is intentionally simple to guard against future regressions.
    '''
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:21:08.469339
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import freebsd_hardware_facts
    reload(freebsd_hardware_facts)
    module = freebsd_hardware_facts.FreeBSDHardware().module
    assert module.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-20 17:21:21.909411
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict()
    )
    module.exit_json = lambda a: a
    collected_facts = dict(
        ansible_system='FreeBSD',
        ansible_machine='i386',
        ansible_architecture='x86_64',
    )
    freebsd_hw = FreeBSDHardware(module)
    hw_facts = freebsd_hw.populate(collected_facts=collected_facts)
    assert hw_facts['processor_cores'] == '1'
    assert hw_facts['processors'] == ['Intel(R) Core(TM) i5-4288U CPU @ 2.60GHz ', 'Genuine Intel(R) CPU 0000 @ 2.60GHz']
    assert hw_facts['processor_count'] == '2'

# Generated at 2022-06-20 17:21:27.380169
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware = FreeBSDHardware(None)
    result = hardware.get_memory_facts()
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result


# Generated at 2022-06-20 17:21:29.973209
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware()
    uptime_facts = m.get_uptime_facts()
    assert type(uptime_facts['uptime_seconds']) == int

# Generated at 2022-06-20 17:21:40.898105
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    h = FreeBSDHardware()
    h.module = AnsibleModule(argument_spec={})  # Dummy module just for test
    h.module.run_command = lambda x: (0, '4', '')
    h.module.get_bin_path = lambda x: '/sbin/' + x
    facts = h.populate()
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts

    assert 'mounts' in facts
    assert 'devices' in facts
    assert 'dmi'

# Generated at 2022-06-20 17:21:51.092094
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:21:57.199050
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    mock_module = type('ansible_module', (object, ),
                       {'run_command': lambda self, cmd, check_rc=None:
                        (0, '', '')})
    mock_hardware = FreeBSDHardware(mock_module)
    devices = mock_hardware.get_device_facts()
    assert devices == {}

# Generated at 2022-06-20 17:22:04.223579
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    freebsd_hardware = FreeBSDHardware(module)
    cpu_facts = freebsd_hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i5-3350P CPU @ 3.10GHz']
    assert cpu_facts['processor_cores'] == '4'



# Generated at 2022-06-20 17:22:12.910129
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # get FreeBSDHardware instance
    fhw = FreeBSDHardware({})
    assert fhw
    assert fhw.platform == 'FreeBSD'
    assert fhw.get_cpu_facts()
    assert fhw.get_memory_facts()
    assert fhw.get_mount_facts()
    assert fhw.get_device_facts()
    assert fhw.get_dmi_facts()
    assert fhw.get_uptime_facts()
    assert fhw.populate()

# Generated at 2022-06-20 17:22:19.508198
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class_FreeBSDHardware = FreeBSDHardware({}, dict())
    class_FreeBSDHardware.module = dict()
    class_FreeBSDHardware.module['run_command'] = dict()
    class_FreeBSDHardware.module['run_command'].return_value = '', '', ''
    class_FreeBSDHardware.module['get_bin_path'] = dict()
    class_FreeBSDHardware.module['get_bin_path'].return_value = '/bin/sysctl'
    class_FreeBSDHardware.populate()


# Generated at 2022-06-20 17:22:58.388997
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    FreeBSDHardware()


# Generated at 2022-06-20 17:23:09.334448
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule({})
    hardware = FreeBSDHardware(module)
    def sysctl_side_effect(*args, **kargs):
        if args[0] == '-n':
            return 0, '0x1000', ''
        elif args[0] == '-b':
            # kern.boottime returns two 64-bits fields, but we are only
            # interested in the first field.
            return 0, '\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00', ''
        return 1, '', ''
    with patch.object(hardware.module, 'run_command', side_effect=sysctl_side_effect):
        uptime_facts = hardware.get

# Generated at 2022-06-20 17:23:20.512001
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule():
        def get_bin_path(self, name, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, encoding=None, check_rc=False):
            if cmd == ['/sbin/sysctl', '-b', 'kern.boottime']:
                return 0, b'\x01\x02\x03\x04', ''
            elif cmd == ['/sbin/sysctl', '-b', 'kern.bogus']:
                return 0, b'', ''
            elif cmd == ['/sbin/sysctl', 'kern.boottime']:
                return 0, 'kern.boottime = { sec = 1497447507, usec = 349000 }', ''

# Generated at 2022-06-20 17:23:24.886886
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """
    FreeBSDHardware - constructor test
    """

    hardware_mock_path = os.path.join(fixture_path, 'hardware_mock')
    hardware_mock_files = ['DMESG_BOOT', 'FSTAB', 'KERN_BOOTTIME']

    tmpdir = tempfile.mkdtemp()

    for f in hardware_mock_files:
        src_file = os.path.join(hardware_mock_path, f)
        dst_file = os.path.join(tmpdir, f)
        shutil.copyfile(src_file, dst_file)

    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )
    module.run_command = MagicMock(return_value=(0, '', ''))


# Generated at 2022-06-20 17:23:31.335136
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freebsdhw = FreeBSDHardware()
    freebsdhw.module = AnsibleModule(argument_spec={})
    freebsdhw.module.run_command = MagicMock(return_value=(0, '', ''))
    freebsdhw.module.get_bin_path = MagicMock(return_value='')
    freebsdhw.DMESG_BOOT = './test/unit/ansible/modules/extras/facts/freebsd/fixtures/dmesg.boot'
    output = freebsdhw.get_cpu_facts()
    assert output['processor_cores'] == '2'
    assert output['processor_count'] == '2'
    assert output['processor'] == ['Intel(R) Core(TM) i5-4260U CPU @ 1.40GHz']


# Unit test

# Generated at 2022-06-20 17:23:35.493341
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''
    unit test for constructor of FreeBSDHardwareCollector class
    '''
    collector = FreeBSDHardwareCollector()
    assert type(collector) == FreeBSDHardwareCollector
    assert collector._platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:23:44.890436
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    def get_bin_path(self, executable):
        return '/usr/bin/%s' % executable

    # Mock Module
    class MockModule(object):

        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, executable):
            return '/usr/bin/%s' % executable

        def run_command(self, cmd, check_rc=True):
            return 0, self.out, ''

        def set_module_args(self, args):
            self.args = args

    # Mock Module methods
    MockModule.run_command = get_bin_path
    module = MockModule()

# Generated at 2022-06-20 17:23:48.253582
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
        hardware = FreeBSDHardware(dict())
        assert hardware.get_cpu_facts()

if __name__ == "__main__":
    test_FreeBSDHardware()

# Generated at 2022-06-20 17:23:59.882879
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Test get_dmi_facts function of class FreeBSDHardware"""
    module = MockModule()
    hardware = FreeBSDHardware(module=module)

# Generated at 2022-06-20 17:24:03.210922
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a FreeBSDHardware object
    hw = FreeBSDHardware(module=module)

    # Check whether it is an instance of the correct class
    assert isinstance(hw, FreeBSDHardware)


# Generated at 2022-06-20 17:25:31.659616
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = type('test_module', (object, ), {'get_bin_path': lambda self, x: '/sbin/sysctl'})
    test_hardware = FreeBSDHardware(test_module)
    test_hardware.module = test_module()
    test_hardware.module.run_command = lambda x, encoding=None: (0, 'hw.ncpu: 1\n', '') if 'hw.ncpu' in x else (0, 'hw.model: Intel(R) Core(TM) i3-2100 CPU @ 3.10GHz\n', '')
    cpu_facts = test_hardware.get_cpu_facts()
    assert not cpu_facts['processor']
    assert cpu_facts['processor_count'] == '1'
    assert cpu_facts['processor_cores'] == '2'


# Generated at 2022-06-20 17:25:40.567086
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)
    hardware.populate()

    assert hardware.facts['devices']['ada0'] == 'ada0s1a'
    assert hardware.facts['devices']['ada1'] == 'ada1s1'

    assert hardware.facts['memfree_mb'] == hardware.facts['memtotal_mb'] - hardware.facts['swaptotal_mb']

    # Currently this test is not very useful.
    # assert hardware.facts['uptime_seconds'] == 168



# Generated at 2022-06-20 17:25:45.547560
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Assigned values are arbitrary.
    hardware = FreeBSDHardware()
    assert hardware.platform == 'FreeBSD'
    assert hardware.SPEED_FILE == '/usr/sbin/dmidecode'
    assert hardware.DMIDECODE == '/dev/mem'
    assert hardware.DMESG_BOOT == '/var/run/dmesg.boot'

# Generated at 2022-06-20 17:25:47.911559
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware(None)
    _platform = 'FreeBSD'
    assert fhw is not None
    assert fhw.platform == _platform


# Generated at 2022-06-20 17:25:54.404077
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = type('test_module', (object,), {'run_command': lambda self, *args, **kwargs: ('', '', '')})
    test_module.get_bin_path = lambda self, *args, **kwargs: None
    test_FreeBSDHardware = FreeBSDHardware(test_module)

    devices = {'ada0': ['ada0s1', 'ada0s2', 'ada0s3'], 'ad10': ['ad10s1', 'ad10s2', 'ad10s3']}
    assert devices == test_FreeBSDHardware.get_device_facts()['devices']

# Generated at 2022-06-20 17:26:06.286255
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from io import StringIO
    from ansible.module_utils.facts import hardware

    class TestModule:
        def __init__(self):
            self.exit_json = lambda: None
            self.fail_json = lambda: None

        def get_bin_path(self, path, opt_dirs=[]):
            return '/sbin/sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            return (0, '/dev/null', '')

    class TestFacts:
        def __init__(self, new_ansible_module):
            self.ansible_module = new_ansible_module

    test_module = TestModule()
    test_facts = TestFacts(test_module)
    hc = hardware.HardwareCollector(test_facts)
    h

# Generated at 2022-06-20 17:26:07.454859
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    h = FreeBSDHardware()
    assert h


# Generated at 2022-06-20 17:26:18.845412
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FakeModule:
        def __init__(self):
            self.path = {
                'sysctl': '/sbin/sysctl',
            }

        def get_bin_path(self, name):
            return self.path[name]

    class FakeTime:
        def time(self):
            return 1566764829

    class FakeStruct:
        def unpack(self, *args):
            return (1566764104, )

    class FakeSysctl:
        def __init__(self):
            self.out = 'kern.boottime: { sec = 1566764104, usec = 241727 } Sat Aug 24 18:38:24 2019'

        def endswith(self, value):
            return value in 'kern.boottime'

        def encode(self, *args):
            return self.out

# Generated at 2022-06-20 17:26:22.588264
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    obj = FreeBSDHardwareCollector()
    assert obj.__class__.__name__ == 'FreeBSDHardwareCollector'


# Generated at 2022-06-20 17:26:29.857287
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module:
        @staticmethod
        def run_command(command, check_rc=True, encoding=None):
            return 0, struct.pack('@L', int(time.time()) - 42), None

        class params:
            ansible_python_interpreter = ''

        @staticmethod
        def get_bin_path(*args):
            return ''

    module = Module()

    assert 42 == FreeBSDHardware(module).get_uptime_facts()['uptime_seconds']