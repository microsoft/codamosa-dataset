

# Generated at 2022-06-20 17:18:02.009121
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Unit test for method populate of class FreeBSDHardware'''
    # Create an instance of class FreeBSDHardware
    hardware = FreeBSDHardware()

    # Create a file and add some valid data
    with open(FreeBSDHardware.DMESG_BOOT, 'w') as f:
        f.write('CPU: Intel(R) Core(TM) i5-5200U CPU @ 2.20GHz (2294.10-MHz K8-class CPU)\n')
        f.write('Logical CPUs per core: 1\n')
        f.write('Physical CPUs: 2\n')
        f.write('vm.stats.vm.v_page_size: 4096\n')
        f.write('vm.stats.vm.v_page_count: 696448\n')

# Generated at 2022-06-20 17:18:13.284847
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Mock dmidecode executable, if available
    dmi_bin = hardware.module.get_bin_path('dmidecode')
    if dmi_bin is not None:
        b_dmidecode = basename(dmi_bin)
        dmidecode_mock = get_fixture_path('dmidecode.txt')
        module.params['ansible_dmidecode_src'] = dmidecode_mock
        module.run_command = lambda *_, **kw: (
            0, read_fixture(dmidecode_mock), None)

    dmi_facts = hardware.get_dmi_facts()

    # Check if a specific key is in the dictionary returned

# Generated at 2022-06-20 17:18:24.656166
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec = dict(
            gather_subset=dict(default=['!all'], type='list')
        ),
        supports_check_mode=True)

    if not HAS_REQUIRED_LIBRARIES:
        module.fail_json(msg=missing_required_lib('hardware/FreeBSDHardware'))

    hardware_collector = FreeBSDHardwareCollector(module=module)

    result = hardware_collector.collect()

    if 'failed' in result:
        module.fail_json(msg=result['failed'])
    module.exit_json(ansible_facts={'ansible_hardware': result})


if __name__ == '__main__':
    main()

# Generated at 2022-06-20 17:18:32.024570
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    freebsd_hardware = FreeBSDHardware(module)
    freebsd_hardware.get_memory_facts()
    assert freebsd_hardware.facts['memtotal_mb'] > 0
    assert freebsd_hardware.facts['memfree_mb'] > 0
    assert freebsd_hardware.facts['swaptotal_mb'] > 0
    assert freebsd_hardware.facts['swapfree_mb'] > 0



# Generated at 2022-06-20 17:18:33.097539
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc


# Generated at 2022-06-20 17:18:39.026805
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_fixture = {'ansible_facts': {}}
    test_args = {'module': object()}
    test_instance = FreeBSDHardware(module=test_args['module'])
    test_instance.populate()
    result = test_instance.get_cpu_facts()

    assert result['processor'] != []
    assert result['processor_cores'] != 'NA'
    assert result['processor_count'] != 'NA'



# Generated at 2022-06-20 17:18:51.601655
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeANSIModule()
    hardware = FreeBSDHardware(module)

    # Test FreeBSDHardware.get_memory_facts() with no swap
    module.run_command_results = (0, "vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 3906912\nvm.stats.vm.v_free_count: 3906912",'')
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 15269
    assert memory_facts['memfree_mb'] == 15269
    assert 'swaptotal_mb' not in memory_facts
    assert 'swapfree_mb' not in memory_facts

    # Test FreeBSDHardware.get_memory_facts() with swap

# Generated at 2022-06-20 17:19:01.834528
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Incomplete test for FreeBSDHardware.get_uptime_facts, we cannot
    # call the method without a FreeBSDHardware object, we can't create
    # a FreeBSDHardware object without a module object, etc
    # Instead, test the helper function `bytes_to_int` which is used in
    # the method to convert a bytes object to an integer.
    #
    # To unittest bytes_to_int, we create a mock bytes object and check
    # that it is correctly converted to an integer.
    mock_bytes_object = b'\x00\x00\x00\x00\x00\x00\x09\x8e'
    converted_int = 2514
    result = bytes_to_int(mock_bytes_object)
    assert result == converted_int

# Generated at 2022-06-20 17:19:11.031318
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode=True
    )

    test_obj = FreeBSDHardware(test_module)
    rc, out, err = test_module.run_command('sysctl -n hw.ncpu', check_rc=False)
    cpu_facts = test_obj.get_cpu_facts()
    assert cpu_facts['processor_count'] == out.strip()
    assert cpu_facts['processor_cores'] == '2'



# Generated at 2022-06-20 17:19:20.769398
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:19:31.078478
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    tmp = FreeBSDHardwareCollector()



# Generated at 2022-06-20 17:19:42.703469
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import tempfile
    from ansible.module_utils.facts import gather_subset

    # Write a temporary configuration file
    fd, tmp_config = tempfile.mkstemp(text=True)
    with os.fdopen(fd, 'w') as f:
        # Disable the timeout
        f.write('[defaults]\n')
        f.write('timeout = 0\n')
        f.write('\n')

    # Instantiate the module without parameters
    module = AnsibleModule(config=tmp_config)
    module.exit_json = lambda **a: None

    # Call the method
    get_uptime_facts(module)

    # Remove the temporary configuration file
    os.remove(tmp_config)


# Generated at 2022-06-20 17:19:49.732605
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class ModuleStub():
        @staticmethod
        def get_bin_path(name):
            if name == 'dmidecode':
                return '/usr/local/sbin/dmidecode'
            else:
                return None
        @staticmethod
        def run_command(cmd):
            if cmd == '/usr/local/sbin/dmidecode -s system-manufacturer':
                return (0, 'FUJITSU', None)
            elif cmd == '/usr/local/sbin/dmidecode -s system-serial-number':
                return (0, '8C071700P0062', None)

# Generated at 2022-06-20 17:19:56.721141
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def fake_read(filename):
        return b"Sun Aug  5 12:26:31 2018"

    def fake_struct_unpack(fmt, buf):
        return (1533572791,)

    hw = FreeBSDHardware()
    hw.get_uptime_facts.__code__.co_filename = "tmp"
    hw.get_uptime_facts.__code__.co_name = "tmp"
    fake_open = mock.mock_open(read_data=fake_read)
    with mock.patch(
            'builtins.open',
            fake_open,
            create=True):
        with mock.patch("struct.unpack", fake_struct_unpack):
            assert hw.get_uptime_facts() == {'uptime_seconds': 1533582280}

# Generated at 2022-06-20 17:20:01.033821
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    class TestModule(object):
        def __init__(self, run_command_return_value=(0, u'', u''), check_rc=False):
            self.run_command_return_value = run_command_return_value
            self.check_rc = check_rc

        def get_bin_path(self, _):
            return 'sysctl'


# Generated at 2022-06-20 17:20:13.059268
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import tempfile
    from ansible.module_utils._text import to_bytes

    # The test code is meant to be executed inside a module_utils.facts
    # context manager.
    module = AnsibleModuleMock()

    # Create a temporary file and populate it with the content of
    # kern.boottime.
    with tempfile.NamedTemporaryFile(mode='wb') as f:
        struct_format = '@LL'
        struct_size = struct.calcsize(struct_format)
        now = int(time.time())
        f.write(struct.pack(struct_format, now, 0))
        f.flush()

        # We need the full path of the temporary file.
        fname = f.name.encode('utf-8')

        # First, we test that get_uptime_facts()

# Generated at 2022-06-20 17:20:24.704474
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class ExposedModule():

        def get_bin_path(self, name, required=False):
            return '/bin/dmidecode'

        def run_command(self, cmd, **kwargs):
            out = ''
            err = ''
            if "dmidecode -s bios-release-date" == cmd:
                out += '# dmidecode 2.11'
                out += 'SMBIOS 2.4 present.'
                out += '\n02/19/2019'
                return (0, out, err)
            if "dmidecode -s bios-vendor" == cmd:
                out += '# dmidecode 2.11'
                out += 'SMBIOS 2.4 present.'
                out += '\nLENOVO'
                return (0, out, err)

# Generated at 2022-06-20 17:20:25.861430
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    inst = FreeBSDHardwareCollector()
    assert inst.platform == 'FreeBSD'
    assert inst.fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:20:35.481995
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    test_data = [
        {
            'facts': {'devices': {'ada0': ['ada0s1a', 'ada0s1b', 'ada0s1e', 'ada0s1f', 'ada0s1d', 'ada0s1c'], 'ada1': ['ada1s1']}},
            'desc': 'Test case for get_device_facts of class FreeBSDHardware'
        }
    ]
    for tdata in test_data:
        res = hardware.get_device_facts()
        assert res == tdata['facts'], tdata['desc']
# end unit test for get_device_facts method


# Generated at 2022-06-20 17:20:41.807897
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    # Instantiation of object ( constructor with no specified arguments )
    hardware = FreeBSDHardware()

    # Class variable 'platform' should be of value 'FreeBSD'
    assert hardware.platform == 'FreeBSD'

    # Class variable 'DMESG_BOOT' should be of value '/var/run/dmesg.boot'
    assert hardware.DMESG_BOOT == '/var/run/dmesg.boot'



# Generated at 2022-06-20 17:20:54.933165
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    This function is used to test the FreeBSDHardware class constructor.

    :param module: An instance of AnsibleModule class
    '''

    # Initialize the testing of FreeBSDHardware constructor.
    module = 'module'
    hw = FreeBSDHardware(module)

    # Initialize the expected output after executing the code.
    expected_platform = 'FreeBSD'

    # Check if the output is as expected.
    assert hw.platform == expected_platform



# Generated at 2022-06-20 17:21:07.131837
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create an empty object
    fbsd_hw = FreeBSDHardware()

    # Initialize the attributes devices and mounts which have empty dictionaries
    fbsd_hw.devices = {}
    fbsd_hw.mounts = []

    # Create a test string for the content of fstab
    device_facts = {}
    device_facts['devices'] = {}

# Generated at 2022-06-20 17:21:15.382946
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import time

    # Create a fake FreeBSDHardware instance
    hardware = FreeBSDHardware({'module': None})

    # Call the method with a fake kern.boottime value
    result = hardware.get_uptime_facts('@L1234')

    # Check that the result matches the expectations
    assert result['uptime_seconds'] == int(time.time() - 1234)

# Generated at 2022-06-20 17:21:18.276907
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector = FreeBSDHardwareCollector('/etc/ansible')
    assert isinstance(hw_collector, HardwareCollector)


# Generated at 2022-06-20 17:21:29.973806
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:21:37.791894
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    dev_info = {'devices': {}}
    dev_info['devices']['ada0'] = ['ada0s1a', 'ada0s1b', 'ada0s2']
    dev_info['devices']['ada1'] = ['ada1s1', 'ada1s2']
    dev_info['devices']['ada2'] = ['ada2s1']
    dev_info['devices']['ada3'] = []
    dev_info['devices']['ada4'] = []
    dev_info['devices']['ada5'] = []
    dev_info['devices']['ada6'] = []
    dev_info['devices']['ada7'] = []
    dev_info['devices']['ada8'] = []
    dev_info['devices']['ada9'] = []
    dev

# Generated at 2022-06-20 17:21:47.542276
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a mock module and mock sysctl command.
    class MockModule(object):
        def get_bin_path(self, grep_name, opt_dirs=[]):
            return 'mock_sysctl'

        def run_command(self, cmd, encoding=None, check_rc=None):
            return 0, 'mock kern.boottime data', ''

    # Create a mock FreeBSDHardware object.
    class MockFreeBSDHardware(object):
        module = MockModule()

    # Instantiate a FreeBSDHardware object and run the test.
    my_test = MockFreeBSDHardware()
    assert my_test.get_uptime_facts() == {'uptime_seconds': 0}

# Generated at 2022-06-20 17:21:52.789625
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    m = FreeBSDHardware()
    m.module = module
    m.module.get_bin_path = lambda *args, **kwargs: '/usr/sbin/dmidecode'
    res = m.get_dmi_facts()
    assert 'bios_date' in res
    assert 'system_vendor' in res
    assert res['bios_date'] == '11/02/2015'
    assert res['system_vendor'] == 'Supermicro'

# Generated at 2022-06-20 17:22:04.381665
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Test FreeBSDHardware.get_dmi_facts
    '''
    # Create FreeBSDHardware object
    bsd_obj = FreeBSDHardware()

    # Test valid dmidecode output

# Generated at 2022-06-20 17:22:14.856507
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=[], type='list')})
    result = {}
    result['ansible_facts'] = {}
    result['ansible_facts']['ansible_processor'] = [u'Intel(R) Core(TM) i3-3240 CPU @ 3.40GHz']
    result['ansible_facts']['ansible_processor_cores'] = 4
    result['ansible_facts']['ansible_processor_count'] = 1
    assert FreeBSDHardware().get_cpu_facts(module) == result



# Generated at 2022-06-20 17:22:44.911235
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import datetime
    import time
    import struct

    class FreeBSDModule():
        def get_bin_path(self, name):
            return name

    module = FreeBSDModule()
    hardware = FreeBSDHardware(module)

    # We need to mock run_command() and ctime()
    def run_command_mock(cmd, encoding):
        struct_format = '@L'
        struct_size = struct.calcsize(struct_format)

        # Get a timestamp string and convert it to a time_t
        # time.ctime() return something like "Thu Mar 17 11:14:46 2017\n"
        timestamp_str = time.ctime()

# Generated at 2022-06-20 17:22:48.733381
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector.fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:22:57.407816
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import re
    import struct
    import time

    class TestModule:
        def get_bin_path(self, name):
            return None

        def run_command(self, command, encoding=None):
            rc = 0
            err = ''

            if command == 'sysctl -b kern.boottime':
                # kern.boottime returns seconds and microseconds as two 64-bits
                # fields, but we are only interested in the first field.
                seconds = int(time.time())
                microseconds = 1234
                out = struct.pack('@L', seconds) + struct.pack('@L', microseconds)
            else:
                rc = 1
                err = 'Command failed: %s' % command

            return rc, out, err

    class TestHardware:
        def __init__(self):
            self.module

# Generated at 2022-06-20 17:23:08.502242
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModuleMock()
    fake_swapinfo = """
Device                          1M-blocks     Used    Avail Capacity
/dev/ada0p3                        314368        0   314368     0%
    """
    fake_sysctl = """
vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 1298284
vm.stats.vm.v_free_count: 565930
    """
    module.run_command.return_value = (0, fake_swapinfo, None)
    hardware = FreeBSDHardware(module)
    module.run_command.return_value = (0, fake_sysctl, None)
    hardware.get_memory_facts()
    memory_facts = hardware.get_memory_facts()

# Generated at 2022-06-20 17:23:19.618978
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:23:23.823225
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware = FreeBSDHardware()

    assert hardware.get_cpu_facts()['processor'] == ['AMD Family 15h (Models 60h-6fh) Processor', ]



# Generated at 2022-06-20 17:23:25.097546
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw.populate()

# Generated at 2022-06-20 17:23:38.443683
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Setup fake dmidecode executable
    import tempfile
    fake_dmidecode = tempfile.NamedTemporaryFile(mode='w')
    fake_dmidecode.write('# dmidecode 2.12\nSMBIOS 2.4 present.')
    fake_dmidecode.flush()

    # Setup fake ansible module for unit testing
    import ansible.module_utils.facts.system.freebsd
    import ansible.module_utils.facts.system.base
    import ansible.module_utils.facts.utils

    class FakeModule(object):
        def __init__(self, verbose=False):
            self.params = {'gather_subset': '!all,!any'}
            self.verbose = verbose


# Generated at 2022-06-20 17:23:44.096329
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_facts = FreeBSDHardware().populate()

    assert hardware_facts['system_vendor'] == 'NA'
    assert hardware_facts['product_name'] == 'NA'
    assert hardware_facts['product_version'] == 'NA'
    assert hardware_facts['product_serial'] == 'NA'
    assert hardware_facts['product_uuid'] == 'NA'
    assert hardware_facts['board_vendor'] == 'NA'
    assert hardware_facts['board_name'] == 'NA'
    assert hardware_facts['board_version'] == 'NA'
    assert hardware_facts['board_serial'] == 'NA'
    assert hardware_facts['board_asset_tag'] == 'NA'
    assert hardware_facts['chassis_vendor'] == 'NA'

# Generated at 2022-06-20 17:23:50.441721
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = MockAnsibleModule()
    hardware = FreeBSDHardware(module)

    module.run_command = Mock(return_value=(0, '4', ''))
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_count'] == '4'
    assert cpu_facts['processor_cores'] == '4'



# Generated at 2022-06-20 17:25:02.068697
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    We cannot test all functons of class FreeBSDHardware but these
    two.

    test_get_dmi_facts
    test_get_cpu_facts
    '''
    import sys
    import json
    import platform
    # To test this code we need FreeBSD
    # On other os, return empty
    if platform.system() != "FreeBSD":
        print("{}")
        sys.exit(0)

    hardware = FreeBSDHardware()
    dmi_facts = hardware.get_dmi_facts()
    hardware_facts = hardware.populate()
    hardware_facts['dmi'] = dmi_facts
    #for k in hardware_facts.keys():
        #if k == 'dmi' or k == '_ansible_facts':
            #continue
        #print("%s: %s" %

# Generated at 2022-06-20 17:25:11.875948
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:25:17.532349
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    module.exit_json(ansible_facts={'hardware': hardware.populate()})


from ansible.module_utils.basic import *

if __name__ == '__main__':
    main()

# Generated at 2022-06-20 17:25:24.438925
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class TestFreeBSDHardware():
        def __init__(self, module):
            self.module = module

        def get_bin_path(self, arg):
            return 'swapinfo'

        def run_command(self, cmd, check_rc=False):
            if cmd == 'swapinfo -k':
                return (0, 'Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3   128 0 128  0%\n', '')
            return (0, '', '')

    class TestModule():
        def __init__(self, custom_arg):
            self.custom_arg = custom_arg

        def get_bin_path(self, arg):
            if arg == 'sysctl':
                return 'sysctl'

# Generated at 2022-06-20 17:25:26.388219
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    o = FreeBSDHardwareCollector()
    assert o.platform == 'FreeBSD'
    assert o.fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:25:31.581419
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    try:
        module = get_module_mock()
        hardware = FreeBSDHardware(module=module)
    except:
        raise AssertionError("Can not create object FreeBSDHardware.")

    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0, "memtotal_mb should be positive integer."
    assert memory_facts['memfree_mb'] >= 0, "memfree_mb should be positive integer."
    assert memory_facts['swaptotal_mb'] >= 0, "swaptotal_mb should be positive integer."
    assert memory_facts['swapfree_mb'] >= 0, "swapfree_mb should be positive integer."


# Generated at 2022-06-20 17:25:43.737528
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """ test for populate for FreeBSDHardware(). """
    fake_module = AnsibleModuleMock()
    fake_module.run_command = run_command_mock
    module_facts = {}

    hardware = FreeBSDHardware(fake_module)

    hardware.populate()

    assert hardware.platform == 'FreeBSD'
    assert 'uptime_seconds' in module_facts
    assert 'swaptotal_mb' in module_facts
    assert 'swapfree_mb' in module_facts
    assert 'memtotal_mb' in module_facts
    assert 'memfree_mb' in module_facts
    assert 'devices' in module_facts
    assert 'processor_cores' in module_facts
    assert 'processor_count' in module_facts
    assert 'processor' in module_facts



# Generated at 2022-06-20 17:25:46.690798
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    cpu_facts = FreeBSDHardware(dict()).get_cpu_facts()
    assert cpu_facts['processor_count'] >= 0

# Generated at 2022-06-20 17:25:48.645296
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    freebsd_collector = FreeBSDHardwareCollector()
    assert freebsd_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 17:25:49.460698
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(None)
    assert hardware.platform == 'FreeBSD'

# Generated at 2022-06-20 17:27:18.389880
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    m = FreeBSDHardware()

    # We need a fake object for testing.
    class Module(object):
        def __init__(self):
            self.sysctl_cmd = ''

        def get_bin_path(self, cmd):
            return self.sysctl_cmd

        def run_command(self, cmd, encoding=None):
            if cmd[0] == self.sysctl_cmd:
                if cmd[-1] == '-b':
                    return 0, '', ''
                elif cmd[-1] == 'kern.boottime':
                    return 0, '\x00\x00\x00\x00\x00\x00\x00\x00', ''

# Generated at 2022-06-20 17:27:29.446748
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    '''
    Test the method get_dmi_facts() of class FreeBSDHardware by
    checking that the dmi_facts structure that is returned is the
    same as the one we expect.
    '''


# Generated at 2022-06-20 17:27:36.531867
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Mock facts module
    module = MockModule()
    # Mock parameters of the module
    module.params = {}
    # Create object to test
    fact_module = FreeBSDHardware(module)
    # Test method get_device_facts of class FreeBSDHardware
    result = fact_module.get_device_facts()
    assert result == {"devices": {"ada0": ["ada0s1a", "ada0s1b", "ada0s1d"],
                                  "ada1": ["ada1s1"]}}
    # Cleanup
    del module
    del fact_module

