

# Generated at 2022-06-20 17:17:55.512784
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = FreeBSDHardware()
    uptime_facts = m.get_uptime_facts()
    if 'uptime_seconds' not in uptime_facts:
        raise AssertionError()

# Generated at 2022-06-20 17:18:04.870970
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    Unit test for method get_device_facts of class FreeBSDHardware
    """
    test_module = 'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware'
    test_class = 'FreeBSDHardware'
    test_method = 'get_device_facts'

    # Initialize the class to be tested
    testobj = HardwareCollector.factory(test_platform=test_class)

    # Initialize a test module to be used by the class
    setattr(testobj, 'module', AnsibleModule(argument_spec={}))

    test_args = []

    # Test if the method get_device_facts exists
    assert getattr(getattr(testobj, test_class), test_method)

    # Test if the method get_device_facts is a callable

# Generated at 2022-06-20 17:18:16.360818
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a FreeBSDHardware object
    test_class = FreeBSDHardware()
    # Initialize dictionary with expected values

# Generated at 2022-06-20 17:18:21.163451
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module)
    cpu_facts = fhw.get_cpu_facts()
    assert 'processor' in cpu_facts
    assert len(cpu_facts.keys()) == 4



# Generated at 2022-06-20 17:18:32.256838
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:18:35.161981
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModule(argument_spec={})
    fact_collector = FreeBSDHardwareCollector(module=module)
    assert fact_collector.platform == 'FreeBSD'
    assert fact_collector.fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:18:47.802494
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hw = FreeBSDHardware()

# Generated at 2022-06-20 17:18:52.265379
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    h = FreeBSDHardware()
    memory_facts = h.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts

# Generated at 2022-06-20 17:19:02.379373
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.freebsd import FreeBSDHardware

    # This is the expected output of parsing dmesg output for
    # the currently supported platforms (FreeBSD 10.3 and later)

# Generated at 2022-06-20 17:19:14.931988
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class FreeBSDHardware

    This test is a fake unit test. It just tests that the facts
    returned by the hardware class are of the right type.

    It can't have access to the whole system information, because
    the module_utils package doesn't have access to it. So it can't
    check if the information returned is correct.

    This will be catch by integration tests.
    """
    m = FreeBSDHardware()
    cpu_facts = m.get_cpu_facts()
    required_keys = ['processor', 'processor_cores', 'processor_count']
    for k in required_keys:
        assert isinstance(cpu_facts[k], str), "ERROR: Assertion failed for facts %s" % k
    # Test with a list

# Generated at 2022-06-20 17:19:30.577507
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] > 0
    assert cpu_facts['processor_cores'] > 0



# Generated at 2022-06-20 17:19:40.771701
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Prepare data
    bin_path = '/usr/bin'
    sysctl_cmd = 'sysctl -b kern.boottime'
    out = 'out'
    module = MockModule(out=out, bin_path=bin_path, sysctl_cmd=sysctl_cmd)
    sysctl_cmd = bin_path + '/' + sysctl_cmd

    # Exercise code
    hardware = FreeBSDHardware(module)
    fact_uptime_seconds = hardware.get_uptime_facts()

    # Verify
    assert fact_uptime_seconds
    assert fact_uptime_seconds['uptime_seconds'] == out



# Generated at 2022-06-20 17:19:48.792309
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock import patch, MagicMock

    class AnsibleModuleMock(object):
        def __init__(self):
            self.params = {}
            self.exit_json = MagicMock()
            self.fail_json = MagicMock()

        def get_bin_path(self, _):
            return ''

    class FactsCollectorMock(object):
        def __init__(self):
            self.collect_facts = MagicMock(return_value={})

    class TestFreeBSDHardware(unittest.TestCase):
        def __init__(self, *args, **kwargs):
            super

# Generated at 2022-06-20 17:19:54.811377
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['all']),
        'filter': dict(default=None),
        'fact_path': dict(default=None),
    })
    FreeBSDFacts = FreeBSDHardware(module, platform='FreeBSD')

    target = {
        'devices': {
            'ada0': ['ada0s1', 'ada0s2', 'ada0s3']
        }
    }
    result = FreeBSDFacts.get_device_facts()
    module.exit_json(ansible_facts=result)
    assert result == target


# Generated at 2022-06-20 17:20:01.613540
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # pylint: disable=unused-argument
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    cpu_facts = hardware.get_cpu_facts()

    assert cpu_facts['processor_cores'] is not None
    assert cpu_facts['processor_count'] is not None
    assert cpu_facts['processor'] is not None


# Generated at 2022-06-20 17:20:05.865374
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    ''' Unit test for constructor of class FreeBSDHardwareCollector '''
    collector = FreeBSDHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert collector.platform == 'FreeBSD'
    assert not collector.ignore_virtual_type_facts


# Generated at 2022-06-20 17:20:19.216863
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    AMD64 = "FreeBSD"
    amd64_hw = FreeBSDHardware(dict(module=dict()), AMD64)
    amd64_hw.module.get_bin_path = lambda x: "/bin/%s" % x


# Generated at 2022-06-20 17:20:24.646884
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_facts = FreeBSDHardware.get_memory_facts(None, None)
    assert('memtotal_mb' in mem_facts)
    assert('memfree_mb' in mem_facts)
    assert('swaptotal_mb' in mem_facts)
    assert('swapfree_mb' in mem_facts)

# Generated at 2022-06-20 17:20:29.802237
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Create a new instance of the FreeBSDHardware class
    FreeBSD_test = FreeBSDHardware()

    # Populate the test instance with some pre-created data
    v_swap_info = {'swaptotal_mb': 3072, 'swapfree_mb': 3072}
    v_memory_facts = {'memtotal_mb': 16000, 'memfree_mb': 13000}
    FreeBSD_test.get_memory_facts = lambda: v_swap_info
    FreeBSD_test.get_memory_facts = lambda: v_memory_facts

    # Call the get_memory_facts method and test if it works as expected
    result = FreeBSD_test.get_memory_facts()
    assert result['swaptotal_mb'] == 3072
    assert result['swapfree_mb'] == 3072

# Generated at 2022-06-20 17:20:37.712376
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.timeout import Timeout

    class ModuleMock(object):
        def __init__(self):
            self.params = {}
            self.exit_json = None
            self.fail_json = None
            self.run_command = None
            self.check_mode = False
            self.fail_json_called = False
            self.exit_args = None
            self.exit_called = False

        def get_bin_path(self, executable):
            return executable

        def exit_json(self, **kwargs):
            self.exit_called = True
            self.exit_args = kwargs

        def fail_json(self, **kwargs):
            self.fail_json_called = True
            self.exit_json = kwargs


# Generated at 2022-06-20 17:21:08.888095
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    test get_uptime_facts method of FreeBSDHardware class
    '''
    import time
    import mock
    import struct

    dt_now = time.time()

    # Create a mock class that returns a particular timetuple
    class MockTime:
        '''
        A mock time class
        '''
        @staticmethod
        def time():
            '''
            A mock time method
            '''
            return dt_now

    # Create a mock class that returns the user-defined time tuple
    class MockTimeTuple:
        '''
        A mock timetuple class
        '''
        @staticmethod
        def localtime():
            '''
            A mock localtime method
            '''
            return (2017, 1, 1, 0, 0, 0, 0, 1, 0)


# Generated at 2022-06-20 17:21:22.317407
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Function to test get_uptime_facts function
    of class FreeBSDHardware.
    It invokes the function with given parameters and
    the expected data is returned.
    """
    import datetime
    import time
    module = AnsibleModule(argument_spec={})
    fBSD_hardware = FreeBSDHardware(module)
    result = fBSD_hardware.get_uptime_facts()
    boot_time = datetime.datetime.fromtimestamp(time.time() - result.get('uptime_seconds'))
    assert boot_time.strftime("%Y-%m-%d %H:%M:%S") == time.strftime("%Y-%m-%d %H:%M:%S", time.gmtime(result.get('uptime_seconds')))

# Generated at 2022-06-20 17:21:28.222749
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Unit test: FreeBSDHardware.get_device_facts'''
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import copy

    # Case 1
    bsd_hardware = FreeBSDHardware()
    devices = bsd_hardware.get_device_facts()['devices']
    assert len(devices) == 2

    # Case 2 - 3
    bsd_hardware = FreeBSDHardware()
    devices = bsd_hardware.get_device_facts()['devices']
    assert 'ada0' and 'ada1' in devices

    # Case 4 - 7
    bsd_hardware = FreeBSDHardware()
    devices = bsd_hardware.get_device_facts()['devices']
    assert 'ada0' in devices

# Generated at 2022-06-20 17:21:31.145291
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    Unit test for method get_device_facts of class FreeBSDHardware
    :return:
    """
    test_obj = FreeBSDHardware()
    result = test_obj.get_device_facts()
    assert {} == result



# Generated at 2022-06-20 17:21:36.962428
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hw_collector = FreeBSDHardwareCollector()
    hw = hw_collector.collect(module=module, collected_facts={})
    hw_dict = hw.populate()
    assert re.match('FreeBSD', hw_dict['system_vendor'])
    assert re.match('\d+', hw_dict['memtotal_mb'])
    assert re.match('\d+', hw_dict['uptime_seconds'])
test_FreeBSDHardware_populate.collectonly = True


# Generated at 2022-06-20 17:21:40.088633
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    values = (None, {'module': None})
    obj = FreeBSDHardwareCollector(*values)
    assert obj
    assert obj.module == values[1]['module']

# Generated at 2022-06-20 17:21:50.530649
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import get_file_content

    # Create a module_util object
    fake_module = FakeAnsibleModule()

    # Create a hardware object
    hardware = FreeBSDHardware(fake_module)

    # Populate dmesg.boot with test data
    fake_module.get_bin_path_mock_map['dmesg'] = '/sbin/dmesg'
    fake_module.run_command_mock_map['/sbin/dmesg'] = (
        0,
        'CPU: Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz (2600.06-MHz K8-class CPU)',
        ''
    )

    # Populate sysctl with test data
    fake_module.get_bin_path_mock

# Generated at 2022-06-20 17:22:03.075147
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = MockModule()
    dmi_bin = "/bin/dmidecode"
    dmi_facts = {"bios_vendor":"LENOVO", "product_name":"9089D2G", "product_uuid":"CC2E7ADF-A1A0-E511-80E9-001DD8B71F4B"}


# Generated at 2022-06-20 17:22:10.327604
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_instance = FreeBSDHardware()
    hardware_instance.module = MockModule()
    hardware_instance.module.get_bin_path.return_value = "/sbin/sysctl"
    hardware_instance.module.run_command.return_value = (0, "1", "")
    hardware_facts = hardware_instance.get_cpu_facts()

    assert hardware_facts['processor_count'] == "1"


# Generated at 2022-06-20 17:22:14.063053
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = MockModule()
    freebsd_hw = FreeBSDHardware(module)
    assert freebsd_hw.module == module
    assert freebsd_hw.platform == 'FreeBSD'


# Generated at 2022-06-20 17:23:22.553601
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    assert hardware.platform == 'FreeBSD'
    assert hardware.devices == {}


# Generated at 2022-06-20 17:23:27.890729
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    h = FreeBSDHardware(module)
    try:
        result = h.get_memory_facts()
        assert result['memtotal_mb'] is not None
        assert result['memfree_mb'] is not None
        assert result['swaptotal_mb'] is not None
        assert result['swapfree_mb'] is not None

    except Exception as e:
        print(e)



# Generated at 2022-06-20 17:23:31.354597
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    m = FreeBSDHardware()
    out = m.get_memory_facts()
    assert out['memtotal_mb'] == 0

# Generated at 2022-06-20 17:23:36.086546
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeModule()
    hardware = FreeBSDHardware(module)

# Generated at 2022-06-20 17:23:36.848121
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:23:45.671416
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.compat.mock import MagicMock

    module = MagicMock()
    module.run_command.return_value = (0, b'\x01\x00\x00\x00\x01\x00\x00\x00', '')

    hardware = FreeBSDHardware(module)

    hardware.get_uptime_facts()

    # The expected value is now in the module facts
    expected = {
            'uptime_seconds': int(time.time() - 1),
    }
    assert(expected == hardware.facts)

    # Check that the first field is correctly read from the output of sysctl.

# Generated at 2022-06-20 17:23:49.966895
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    module.exit_json(ansible_facts={'hardware': hw.populate()})



# Generated at 2022-06-20 17:23:58.062213
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.collector import get_collector_instance
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardwareCollector

    # Construct an instance of FreeBSDHardwareCollector
    hardware_collector_inst = get_collector_instance(FreeBSDHardwareCollector)

    # Assert that the instance is of the right type
    assert isinstance(hardware_collector_inst, FreeBSDHardwareCollector)

    # Assert that the instance can get the right platform
    assert hardware_collector_inst.get_platform() == 'FreeBSD'

# Generated at 2022-06-20 17:24:03.698401
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    hardware_obj = FreeBSDHardware({})
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()
    hardware_obj.get_memory_facts()

# Generated at 2022-06-20 17:24:10.857280
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module=module)
    facts = hw.populate()
    keys = sorted(facts.keys())
    assert keys == ['devices', 'mounts', 'processor', 'processor_cores', 'processor_count', 'memfree_mb', 'memtotal_mb', 'swapfree_mb', 'swaptotal_mb', 'uptime_seconds']


# Generated at 2022-06-20 17:27:08.906048
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    # set defaults
    results = dict(
        changed=False,
        ansible_facts=dict(),
    )

    # initialize test object
    facts_obj = FreeBSDHardware(module)

    # populate the facts
    facts = facts_obj.populate()
    results['ansible_facts'] = facts

    # Test cpu_facts.
    cpu_facts = results['ansible_facts']['processor']
    assert cpu_facts is not None
    assert type(cpu_facts) is list
    assert len(cpu_facts) > 0

    # Test number of CPU cores per CPU.
    processor_cores = results['ansible_facts']['processor_cores']
    assert processor_cores is not None

# Generated at 2022-06-20 17:27:16.150523
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import os
    from ansible.module_utils.basic import AnsibleModule
    module = AnsibleModule(argument_spec={})

    current_dir = os.path.dirname(os.path.abspath(__file__))
    parent_dir = os.path.dirname(current_dir)
    root_dir = os.path.dirname(parent_dir)
    test_dir = os.path.join(parent_dir, 'test_utils')
    for value in os.listdir(test_dir):
        if value.startswith('devices'):
            os.symlink(os.path.join(test_dir, value),
                        os.path.join(current_dir, value.replace('.disabled', '')))

# Generated at 2022-06-20 17:27:19.914772
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    facts = FreeBSDHardware(module, 'hardware').populate()
    assert (facts['uptime_seconds'] > 0)

# Generated at 2022-06-20 17:27:30.552020
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts import FactCollector
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.utils import DMI_DICT


# Generated at 2022-06-20 17:27:39.449858
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    class MockModule(object):

        def __init__(self):
            self.run_command_call_counts = 0
            self.run_command_args = list()
            self.run_command_kwargs = list()
            self.run_command_return_value = list()
            self.run_command_side_effect = None

        def run_command(self, *args, **kwargs):
            self.run_command_call_counts += 1
            self.run_command_args.append(args)
            self.run_command_kwargs.append(kwargs)
            if self.run_command_side_effect is not None:
                return self.run_command_side_effect(*args, **kwargs)
            ret = self.run_command_return_value.pop(0)