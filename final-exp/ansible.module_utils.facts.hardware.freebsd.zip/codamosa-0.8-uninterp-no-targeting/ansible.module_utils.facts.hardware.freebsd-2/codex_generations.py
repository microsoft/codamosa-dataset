

# Generated at 2022-06-20 17:17:55.219100
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''Unit test for constructor of class FreeBSDHardwareCollector'''

    f = FreeBSDHardwareCollector()
    assert f.platform == 'FreeBSD'



# Generated at 2022-06-20 17:17:57.949452
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.platform == 'FreeBSD'
    assert fhc._fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:18:06.187326
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:18:06.843061
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:18:18.146363
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module(object):
        class ExitJson(Exception):
            pass

        class FailJson(Exception):
            pass

        def __init__(self):
            self.params = {}
            self.fail_json = self.FailJson
            self.exit_json = self.ExitJson
            self._ansible_no_log = set()

        def get_bin_path(self, app, required=False):
            if app == 'sysctl':
                return 10
            return None

        def run_command(self, cmd, encoding=None, check_rc=True):
            class RC:
                def __init__(self, rc):
                    self.rc = rc
                    self.stderr = 'Whatever'
                    self.stdout = ''


# Generated at 2022-06-20 17:18:29.911716
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    os.mkdir('/dev')
    with open(os.path.join('/dev', 'ada0'), 'w') as f:
        f.write('')
    with open(os.path.join('/dev', 'ada1'), 'w') as f:
        f.write('')
    with open(os.path.join('/dev', 'da2'), 'w') as f:
        f.write('')
    with open(os.path.join('/dev', 'da3'), 'w') as f:
        f.write('')
    with open(os.path.join('/dev', 'cd0'), 'w') as f:
        f.write('')

# Generated at 2022-06-20 17:18:38.795481
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-20 17:18:51.399284
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class B_MODULE:
        def run_command(self, cmd, check_rc=True, encoding=None, errors='surrogate_then_replace'):
            return 0, "hw.ncpu: 4\n", ''


# Generated at 2022-06-20 17:18:52.343396
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    return

# Generated at 2022-06-20 17:19:02.418240
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import pytest
    module = pytest.importorskip("ansible.modules.system.freebsd")
    obj = module.Hardware()
    facts = obj.get_dmi_facts()


# Generated at 2022-06-20 17:19:15.834760
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert issubclass(FreeBSDHardwareCollector, HardwareCollector)



# Generated at 2022-06-20 17:19:18.405995
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    Test FreeBSDHardware
    '''
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module=module)
    assert hardware.populate()

# Generated at 2022-06-20 17:19:25.779196
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    Unit test for method get_uptime_facts of class FreeBSDHardware
    '''
    # Test if the method decodes the kern_boottime correctly
    module = AnsibleModule(argument_spec=dict())
    freebsd_hardware = FreeBSDHardware(module)
    kern_boottime = 1588379546
    output = freebsd_hardware.get_uptime_facts()
    assert output['uptime_seconds'] == int(time.time() - kern_boottime)

    # Test if the method returns an empty dictionary if it cannot get the
    # boottime
    module = AnsibleModule(argument_spec=dict())
    freebsd_hardware = FreeBSDHardware(module)
    # Simulate an error by setting the output to None
    freebsd_hardware._output = None

# Generated at 2022-06-20 17:19:28.130582
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    x = FreeBSDHardwareCollector()
    assert isinstance(x, HardwareCollector)

# Generated at 2022-06-20 17:19:36.260200
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # Create an instance of class FreeBSDHardware
    freebsd_hardware = FreeBSDHardware(0, {})

    # Set up mock functions for get_file_content and get_bin_path
    freebsd_hardware.get_file_content = lambda x: ''

    freebsd_hardware.get_bin_path = lambda x: '/usr/bin/foo'

    # Set up mock function for run_command
    freebsd_hardware.run_command = lambda x: (0, 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 2147483648\nvm.stats.vm.v_free_count: 1866420375\n', '')

    # Call the method get_memory_facts of FreeBSDHardware class
    memory_facts = freebsd_

# Generated at 2022-06-20 17:19:42.879111
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.timeout import Timeout
    facts = ModuleFacts(dict(), dict(), dict(), dict(), dict(), False,
                        Timeout(10, 2))
    hardware = FreeBSDHardware(facts, {})
    cpu_facts = hardware.get_cpu_facts()

    # Check that the CPU manufacturer exists
    assert 'Manufacturer' in cpu_facts['processor'][0]



# Generated at 2022-06-20 17:19:52.819729
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    hardware = FreeBSDHardware(module)

    # Patching os.path.isdir function
    hardware_path_isdir_map = {'/dev': True}

    def mocked_os_path_isdir(path):
        return hardware_path_isdir_map[path]

    hardware.os.path.isdir = mocked_os_path_isdir

    # Patching sorted function from os.listdir
    hardware_sorted_map = {'/dev': ['da1', 'da1s1a', 'da1s1b', 'da2', 'da3', 'da4a']}

    def mocked_sorted(device_list):
        return hardware_sorted_map[device_list]

    hardware.os.listdir = mocked_sorted


# Generated at 2022-06-20 17:19:56.882449
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    class ModuleStub:
        def __init__(self):
            self.run_command = lambda *_, **__: (0, '', '')

    class AnsibleModuleStub:
        def __init__(self):
            self.module = ModuleStub()
            self.params = {}

        def fail_json(self, *_):
            pass

    instance = FreeBSDHardwareCollector(AnsibleModuleStub())
    assert isinstance(instance._fact_class, FreeBSDHardware)
    assert instance._platform == 'FreeBSD'


# Generated at 2022-06-20 17:20:09.382544
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module=module)
    facts = hw.populate()
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'devices' in facts
    assert facts['uptime_seconds'] >= 0
    for mount in facts['mounts']:
        assert 'size_total' in mount
        assert mount['size_total'] >= 0
        assert 'size_available' in mount
        assert mount['size_available'] >= 0
        assert 'device' in mount
        assert 'mount' in mount


# Generated at 2022-06-20 17:20:22.388252
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    ''' returns gathered hardware facts '''

    # Create an FreeBSDHardware object
    hardware = FreeBSDHardware()

# Generated at 2022-06-20 17:20:52.068975
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test case:
    # (1) executable dmidecode is not available
    # (2) executable dmidecode is available, but no DMI tables

    one = dict(ansible_facts=dict(hardware=FreeBSDHardware(dict(module=AnsibleModule(argument_spec=dict())))))
    two = dict(ansible_facts=dict(hardware=FreeBSDHardware(dict(module=AnsibleModule(argument_spec=dict())))))

    class AnsibleModuleFake:
        def __init__(self, argument_spec):
            pass

        def get_bin_path(self, arg, opt_dirs=[]):
            return None

    class AnsibleModuleMock:
        def __init__(self, argument_spec):
            pass


# Generated at 2022-06-20 17:20:56.402993
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    collected_facts = hardware.populate()

    assert type(collected_facts) is dict
    assert 'uptime_seconds' in collected_facts
    assert 'memtotal_mb' in collected_facts
    assert 'memfree_mb' in collected_facts
    assert 'swaptotal_mb' in collected_facts
    assert 'swapfree_mb' in collected_facts
    assert len(collected_facts['processor']) >= 1
    assert 'processor_count' in collected_facts
    assert 'processor_cores' in collected_facts
    assert len(collected_facts['devices']) >= 1
    assert len(collected_facts['devices']['ada0']) >= 1



# Generated at 2022-06-20 17:21:08.114493
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = DummyModule()  # Dummy AnsibleModule

    class DummyHardware():
        def __init__(self, module):
            self.module = module

    hardware = DummyHardware(module)
    setattr(hardware.module, 'run_command', test_FreeBSDHardware_get_memory_facts.run_command)

    def run_command(self, args, check_rc=True):
        test_data = [
            'hw.ncpu: 8',
            'vm.stats.vm.v_page_size: 16384',
            'vm.stats.vm.v_page_count: 616320',
            'vm.stats.vm.v_free_count: 467408',
        ]

        return (0, '\n'.join(test_data), None)
    test_FreeBSDHardware_

# Generated at 2022-06-20 17:21:21.508997
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Set up class instance
    test_instance = FreeBSDHardware()
    # Execute code under test
    result1 = test_instance.get_dmi_facts()
    # Make sure it returns a dict
    assert isinstance(result1, dict)
    # Since the dict is not static, its best to check for specific key/value pairs.
    assert 'bios_date' in result1
    assert 'bios_vendor' in result1
    assert 'bios_version' in result1
    assert 'board_asset_tag' in result1
    assert 'board_name' in result1
    assert 'board_serial' in result1
    assert 'board_vendor' in result1
    assert 'board_version' in result1
    assert 'chassis_asset_tag' in result1

# Generated at 2022-06-20 17:21:32.684705
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = type('test_module', (object,), dict(run_command=lambda *args, **kwargs: (0, '', ''),
                                                    get_bin_path=lambda *args, **kwargs: '/bin/dmidecode'))
    hardware = FreeBSDHardware(test_module)
    dmi_facts = hardware.get_dmi_facts()
    assert dmi_facts['bios_date'] == 'NA'.encode('UTF-8')
    assert dmi_facts['bios_vendor'] == 'NA'.encode('UTF-8')
    assert dmi_facts['bios_version'] == 'NA'.encode('UTF-8')
    assert dmi_facts['board_asset_tag'] == 'NA'.encode('UTF-8')

# Generated at 2022-06-20 17:21:44.231482
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_facts_instance = FreeBSDHardware({})
    returned_hardware_facts = hardware_facts_instance.populate()

    # Assert if all the following facts are gathered
    assert 'memtotal_mb' in returned_hardware_facts
    assert 'memfree_mb' in returned_hardware_facts
    assert 'swaptotal_mb' in returned_hardware_facts
    assert 'swapfree_mb' in returned_hardware_facts
    assert 'processor_count' in returned_hardware_facts
    assert 'processor_cores' in returned_hardware_facts
    assert 'devices' in returned_hardware_facts
    assert 'uptime_seconds' in returned_hardware_facts



# Generated at 2022-06-20 17:21:51.132342
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # mock module
    module = type('', (), {})
    module.get_bin_path = lambda x: 'sysctl'
    module.run_command = lambda x, encoding=None: (0, 'kern.boottime: { sec = 1555121550, usec = 62655 } { sec = 1555118422, usec = 219117 }', '')
    test_host = FreeBSDHardware(module)

    uptime_facts = test_host.get_uptime_facts()
    assert(uptime_facts['uptime_seconds'] == 36202)

# Generated at 2022-06-20 17:21:55.032667
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    assert 'uptime_seconds' in hardware.populate()


# Generated at 2022-06-20 17:22:05.605287
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import platform
    import struct
    from datetime import datetime, timedelta
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Mock the time at which we run the command
    run_command_time = datetime.now()
    # Compute the expected seconds since the epoch at which the system started
    expected_boottime = run_command_time - timedelta(seconds=FreeBSDHardware(dict()).get_uptime_facts()['uptime_seconds'])
    expected_boottime = expected_boottime.replace(microsecond=0)

    # Mock the system time, which we will read with the 'gettimeofday' system call
    # Note that on FreeBSD an integer is used to store the seconds, so
    # we need to cast the time to an integer in the tests.
    # Note also that

# Generated at 2022-06-20 17:22:07.251245
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:23:04.050927
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()

    assert 'memfree_mb' in hardware_facts
    assert 'memtotal_mb' in hardware_facts
    assert 'swapfree_mb' in hardware_facts
    assert 'swaptotal_mb' in hardware_facts
    assert 'processor' in hardware_facts
    assert 'processor_cores' in hardware_facts
    assert 'processor_count' in hardware_facts
    assert 'uptime_seconds' in hardware_facts
    assert 'devices' in hardware_facts



# Generated at 2022-06-20 17:23:08.272155
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    m = FreeBSDHardware()
    d = m.get_memory_facts()
    assert 'memfree_mb' in d
    assert 'memtotal_mb' in d
    assert 'swapfree_mb' in d
    assert 'swaptotal_mb' in d


# Generated at 2022-06-20 17:23:16.735222
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = type('fakemodule', (), {})
    setattr(module, 'run_command', run_command)
    setattr(module, 'get_bin_path', get_bin_path)
    module.run_command.side_effect = get_run_command_side_effect()
    module.get_bin_path.side_effect = get_bin_path_side_effect()
    h = FreeBSDHardware(module)
    assert h.get_uptime_facts() == {'uptime_seconds': 86400}


# Generated at 2022-06-20 17:23:23.783456
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})

    mock_sysctl = "vm.stats.vm.v_page_count: 100\n" + \
                  "vm.stats.vm.v_free_count: 50\n" + \
                  "vm.stats.vm.v_page_size: 4096\n"
    mock_swapinfo = "Device          1M-blocks     Used    Avail Capacity\n" + \
                    "/dev/ada0p3        314368        0   314368     0%\n"

    module.run_command = MagicMock(return_value=(0, mock_sysctl, None))
    module.get_bin_path = MagicMock(return_value='/usr/sbin/sysctl')

    hw = FreeBSDHardware(module=module)


# Generated at 2022-06-20 17:23:37.190951
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:23:39.618622
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware_obj = FreeBSDHardware({})
    assert hardware_obj.get_device_facts() == {}

# Generated at 2022-06-20 17:23:46.890994
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    m = AnsibleModuleMock()
    m.run_command_mock = mock_run_command
    m.get_file_content_mock = mock_get_file_content

    hardware = FreeBSDHardware(m)
    collected_facts = hardware.populate()
    assert collected_facts['uptime_seconds'] == 14935
    assert collected_facts['devices'] == {}
    assert collected_facts['system_vendor'] == 'NA'
    assert collected_facts['product_name'] == 'NA'
    assert collected_facts['form_factor'] == 'NA'
    assert collected_facts['product_serial'] == 'NA'
    assert collected_facts['product_version'] == 'NA'
    assert collected_facts['product_uuid'] == 'NA'


# Generated at 2022-06-20 17:23:58.817332
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    sysdir = '/dev'
    dmi_bin = module.get_bin_path('dmidecode')

# Generated at 2022-06-20 17:24:06.549378
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Testing FreeBSDHardware.get_memory_facts()
    hardware = FreeBSDHardware(module=module)

    # Test no swap - we should not fail on any of the reads

# Generated at 2022-06-20 17:24:13.578622
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class TestModule(object):

        def run_command(self, command):
            pass

    class TestFactModule(object):
        def __init__(self, module):
            self.module = module

    fact_module = TestFactModule(TestModule())
    fact = FreeBSDHardware(fact_module)
    fact_module.fact = fact
    fact.collect()
    assert fact.facts['devices'] == {}



# Generated at 2022-06-20 17:25:13.058560
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:25:18.264016
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fake_module = FakeAnsibleModule()
    fake_hardware = FreeBSDHardware(fake_module)
    result = fake_hardware.get_device_facts()
    assert 'devices' in result
    assert 'ada0' in result['devices']
    assert 'ada0s1' in result['devices']['ada0']



# Generated at 2022-06-20 17:25:24.217277
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeAnsibleModule()
    module.run_command = fake_run_command
    hardware = FreeBSDHardware(module)

    assert hardware.get_memory_facts() == {'swaptotal_mb': 65, 'swapfree_mb': 32, 'memtotal_mb': 32, 'memfree_mb': 23}


# Generated at 2022-06-20 17:25:34.896019
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    class ModuleMock():

        def get_bin_path(self, path):
            return path

        def run_command(self, cmd, check_rc=True):
            if cmd == '/sbin/sysctl vm.stats':
                out = '''
vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 4395112
vm.stats.vm.v_page_free_count: 823923
vm.stats.vm.v_page_inactive_target: 231104
vm.stats.vm.v_page_active_target: 1881088
'''
                rc = 0

# Generated at 2022-06-20 17:25:46.204777
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    Test module for get_device_facts method of class FreeBSDHardware
    """
    import sys
    import platform
    import os
    import unittest
    import tempfile
    import shutil

    class TestFreeBSDHardware(unittest.TestCase):

        def setUp(self):
            self.fd, self.fdname = tempfile.mkstemp()
            if 'FreeBSD' in platform.system():
                sys.path.insert(0, self.fdname)
                from ansible.module_utils.facts import hardware
                self.fhw = hardware.FreeBSDHardware()
            else:
                print("This test is supported only on FreeBSD.")
                sys.exit(0)

        def tearDown(self):
            os.close(self.fd)
            os.remove(self.fdname)


# Generated at 2022-06-20 17:25:54.696932
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class MockModule(object):
        def get_bin_path(self, *args, **kwargs):
            ''' mock get_bin_path() function '''
            return 'dmidecode'

        def run_command(self, *args, **kwargs):
            ''' mock run_command() function '''
            if args:
                if args[0] == 'dmidecode -s system-product-name':
                    return (0, 'Supermicro', '')
                elif args[0] == 'dmidecode -s system-manufacturer':
                    return (0, 'Supermicro', '')
                elif args[0] == 'dmidecode -s system-version':
                    return (0, 'NA', '')

# Generated at 2022-06-20 17:25:59.291683
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    h = FreeBSDHardware()

    assert h.get_cpu_facts() == {}
    assert h.get_devices() == []
    assert h.get_memory_facts() == {}
    assert h.get_uptime_facts() == {}

# Generated at 2022-06-20 17:26:02.133377
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Test with empty class
    obj = FreeBSDHardwareCollector()
    assert obj.platform == 'FreeBSD'
    assert obj._fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:26:09.675547
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import sys
    import os

    class MockModule(object):
        def __init__(self, *args, **kwargs):
            pass

        def get_bin_path(self, binary, opt_dirs=None):
            return binary

        def run_command(self, binary, check_rc=False, encoding=None):
            output = ''
            if binary == 'sysctl vm.stats':
                output = '''vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 27777824
vm.stats.vm.v_free_count: 230624'''

# Generated at 2022-06-20 17:26:16.485077
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Initialize the instance of FreeBSDHardware class
    hd = FreeBSDHardware(module=None)

    # Test 'get_memory_facts' method
    memory_facts = hd.get_memory_facts()
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0

# Generated at 2022-06-20 17:27:32.784942
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    # Test method populate with no parameter
    hardware.populate()
    # Test method populate with collected facts (should not raise exception because of the test above)
    facts = {'test': 'test_value'}
    hardware.populate(facts)

