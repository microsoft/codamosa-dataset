

# Generated at 2022-06-20 17:17:55.856993
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # If a sysctl command failed for some reason, we should return empty dict
    # for memory facts.
    module = FakeAnsibleModule(run_command_result=(1, 'sysctl command failed', ''))
    hardware = FreeBSDHardware(module)
    assert len(hardware.get_memory_facts()) == 0

# Generated at 2022-06-20 17:18:05.088060
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils import basic

    test_module = basic.AnsibleModule(argument_spec={}, supports_check_mode=True)

    # NOTE: This assumes a 64-bit system.
    # TODO: Add a test for 32-bit systems.
    struct_format = '@2Q'

    # Test with bogus data.
    fake_now = 1234
    fake_boottime = 4321
    fake_out = struct.pack(struct_format, fake_boottime, 0)

    # NOTE: It's OK to call setattr() on a method.
    original_time = time.time
    setattr(time, 'time', lambda: fake_now)

    def fake_run_command(command, encoding=None):
        return (0, fake_out)


# Generated at 2022-06-20 17:18:12.194995
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware_facts = hardware.populate()

    assert hardware_facts
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['memfree_mb']

    if 'swaptotal_mb' in hardware_facts:
        assert hardware_facts['swaptotal_mb']
        assert hardware_facts['swapfree_mb']


if __name__ == '__main__':
    test_FreeBSDHardware_populate()

# Generated at 2022-06-20 17:18:15.188820
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert hasattr(FreeBSDHardwareCollector, '_fact_class')
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware
    assert hasattr(FreeBSDHardwareCollector, '_platform')
    assert FreeBSDHardwareCollector._platform == 'FreeBSD'

# Generated at 2022-06-20 17:18:20.974026
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        @staticmethod
        def get_bin_path(name):
            return '/bin/{}'.format(name)

        @staticmethod
        def run_command(args, **kwargs):
            stdout = bytes(json.dumps(
                {
                    'kern.boottime': int(time.time()) - 3600,
                }
            ), 'ascii')
            return 0, stdout, ''

    m = MockModule()
    r = FreeBSDHardware().get_uptime_facts(m)
    assert r['uptime_seconds'] == 3600

# Generated at 2022-06-20 17:18:32.162164
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestModule(object):
        def get_bin_path(self, path):
            return os.path.join(os.path.curdir, path)

        def run_command(self, cmd, check_rc=None):
            if cmd == 'sysctl -n hw.ncpu':
                rc = 0
                out = '58'
                err = ''
            elif cmd == 'dmesg':
                rc = 0
                out = 'Foo'
                err = ''
            elif cmd == 'sysctl vm.stats':
                rc = 0

# Generated at 2022-06-20 17:18:34.123762
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = FreeBSDHardware().populate()
    assert facts['processor']
    assert facts['processor_cores']
    assert facts['processor_count']


# Generated at 2022-06-20 17:18:46.735316
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Instanciate the class
    fhw = FreeBSDHardware(dict())

    # Update the fact_cache

# Generated at 2022-06-20 17:18:50.597045
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)
    hardware_obj.populate()
    hardware_obj.get_cpu_facts()

    assert len(hardware_obj.cpu_facts['cpu']) > 0



# Generated at 2022-06-20 17:18:54.416388
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware('/sbin')
    assert hw.module == '/sbin'
    assert hw.platform == 'FreeBSD'
    assert hw.DMESG_BOOT == '/var/run/dmesg.boot'
    assert hw.facts == {}


# Generated at 2022-06-20 17:19:16.970926
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """This test checks get_dmi_facts method of FreeBSDHardware class"""
    testobj_1 = FreeBSDHardware()
    testobj_2 = FreeBSDHardware()
    testobj_1.module.get_bin_path = lambda x: None
    testobj_2.module.get_bin_path = lambda x: 'dmidecode'
    testobj_2.module.run_command = lambda x, encoding: (0, '', '')

# Generated at 2022-06-20 17:19:24.264972
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:19:35.022242
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    def _get_data(device_name):
        from ansible.module_utils._text import to_bytes

# Generated at 2022-06-20 17:19:39.469096
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    result = FreeBSDHardware(module).get_dmi_facts()
    assert result['product_uuid'] != 'NA'

# Generated at 2022-06-20 17:19:48.606522
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import pytest

    module = AnsibleModule(argument_spec=dict())
    obj = FreeBSDHardware(module)
    ansible_facts = obj.populate()
    dev_facts = ansible_facts['devices']
    drive_list = ['cd0', 'da0', 'da1', 'da2', 'da3', 'da4', 'da5', 'da6', 'da7',
                  'da8', 'da9', 'da10', 'da11', 'da12', 'da13', 'da14', 'da15',
                  'da16', 'da17', 'da18', 'da19', 'da20', 'da21', 'da22', 'da23']
    for drive in drive_list:
        with pytest.raises(KeyError):
            dev_facts[drive]


# Generated at 2022-06-20 17:19:53.382394
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """
    unit test for class FreeBSDHardwareCollector
    """

    HardwareCollector.platform = 'FreeBSD'

    # get facts
    fhwc = FreeBSDHardwareCollector()
    facts = fhwc.collect()

    assert isinstance(facts, dict)


if __name__ == '__main__':
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:20:01.189769
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module=module)
    # Remove empty and commented lines
    dmesg = '\n'.join([line for line in get_file_content('/var/run/dmesg.boot').splitlines() if ':' in line and not line.startswith('#')])
    dmesg_list = dmesg.splitlines()
    devices = []
    if dmesg_list:
        for line in dmesg_list:
            if '<' in line and '>' in line:
                line = line.split()
                device = line[-1].split('<')[0]
                devices.append(device)

    devices = list(set(devices))
    devices.sort()

# Generated at 2022-06-20 17:20:10.938868
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Return devices with ada0, da0 and cd0 on FreeBSD'''
    module = AnsibleModule(argument_spec=dict())
    hw = FreeBSDHardware(module=module)
    assert hw.get_device_facts() == {'devices': {'ada0': ['ada0s1', 'ada0s2', 'ada0s3a', 'ada0s3b', 'ada0s3e'],
                                                'cd0': [],
                                                'da0': ['da0s1', 'da0s2', 'da0s3a', 'da0s3b', 'da0s3e']}}

# Generated at 2022-06-20 17:20:21.362692
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Test function for class FreeBSDHardware method get_memory_facts()
    """
    module = FakeModule()
    hardware = FreeBSDHardware(module)

    module.run_command.return_value = (0,
'''vm.stats.vm.v_page_size: 4096
vm.stats.vm.v_page_count: 20001260
vm.stats.vm.v_free_count: 11307914
''', None)

    mem_facts = hardware.get_memory_facts()
    assert mem_facts['memfree_mb'] == 4453
    assert mem_facts['memtotal_mb'] == 7812



# Generated at 2022-06-20 17:20:34.031129
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:21:09.416466
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    rc, out, err = module.run_command("echo '$(hw.ncpu) $(dmesg | grep -E 'Logical CPUs per core' | awk '{print $5}')'")
    ncpu, cpu_cores = out.split()
    ncpu, cpu_cores = int(ncpu), int(cpu_cores)

    cpu_facts = hardware.get_cpu_facts()
    assert(cpu_facts['processor_count'] == ncpu)
    assert(cpu_facts['processor_cores'] == cpu_cores)
    assert(len(cpu_facts['processor']) == ncpu)


# Generated at 2022-06-20 17:21:15.603957
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = MockModule()
    hw = FreeBSDHardware(module=module)
    hw.get_memory_facts()
    module.run_command.assert_called_with('sysctl vm.stats')
    # verify that the mocked command returns data
    assert 1 == 1

# Generated at 2022-06-20 17:21:27.987721
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_module = 'compile_time_test'
    test_class = 'FreeBSDHardware'
    test_method = 'get_dmi_facts'
    test_args = ''
    test_exception = None
    test_return = ''

# Generated at 2022-06-20 17:21:37.863932
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Patch FreeBSDHardware.module in order to be able to test
    # the method here, without a full execution of the whole
    # module as it is done in the common main() method
    # (which executes a gather_facts action)
    FreeBSDHardware.module = lambda s: None
    # Set to None sysctl and swapinfo constants
    # in order to simulate a case where none exist
    # (e.g. on an incompatible platform)
    sysctl = FreeBSDHardware.sysctl = None
    swapinfo = FreeBSDHardware.swapinfo = None
    # Set to None dmidecode constants in order to simulate
    # a case where dmidecode is not available
    dmidecode = FreeBSDHardware.dmidecode = None

    # Simulate dmesg.boot content

# Generated at 2022-06-20 17:21:49.046456
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class MockAnsibleModule:
        def __init__(self):
            self.params = {}
        def get_bin_path(self, path):
            return path

    class MockFreeBSDHardware(FreeBSDHardware):  # pylint: disable=abstract-method,too-few-public-methods
        '''Mock class for FreeBSD hardware'''
        def __init__(self, ansible_module):
            self.module = ansible_module

    module = MockAnsibleModule()
    freebsd_hardware = MockFreeBSDHardware(module)

    device_facts = freebsd_hardware.get_device_facts()
    assert 'devices' in device_facts
    assert '/dev/ada0' in device_facts['devices']

# Generated at 2022-06-20 17:21:49.529281
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:22:01.886051
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class TestModule:
        """ Dummy class to mock AnsibleModule class """
        def __init__(self):
            self.params = None

        def fail_json(self, msg):
            assert False, msg

        def get_bin_path(self, arg):
            if arg == 'dmidecode':
                return './test_dmidecode'
            else:
                return None

    def test_dmidecode(arg):
        if arg == '-s system-version':
            return 0, '1.0'
        elif arg == '-s system-product-name':
            return 0, 'test product'
        else:
            return 1, 'Not found'

    class TestAnsibleModule:
        def __init__(self):
            self.run_command = test_dmidecode

    dummy_module

# Generated at 2022-06-20 17:22:04.180102
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    h = Hardware('FreeBSD')
    assert isinstance(h, FreeBSDHardware)


if __name__ == '__main__':
    test_FreeBSDHardware()

# Generated at 2022-06-20 17:22:10.592153
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.exit_json = exit_json
    facts = FreeBSDHardware(module).get_memory_facts()
    assert facts['memtotal_mb']
    assert facts['memfree_mb']
    assert facts['swaptotal_mb']
    assert facts['swapfree_mb']



# Generated at 2022-06-20 17:22:20.472810
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # create a mock class
    class AnsibleModuleFake:
        def __init__(self, path):
            self.path = path

        def get_bin_path(self, name):
            # return /sbin/sysctl when name = sysctl
            if name == 'sysctl':
                return '/sbin/sysctl'
            return None

        def run_command(self, cmd, check_rc=True, encoding=None):
            if encoding:
                # return b'hw.ncpu: 4' when running cmd = /sbin/sysctl -n hw.ncpu
                if cmd == '/sbin/sysctl -n hw.ncpu':
                    return 0, b'hw.ncpu: 4', ''
                # return a string when running cmd = /sbin/sysctl vm.stats

# Generated at 2022-06-20 17:23:39.078657
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_module = 'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware'
    test_class = 'FreeBSDHardware'
    test_obj = HardwareCollector.factory(test_module, test_class)
    test_device_facts = test_obj.get_device_facts()
    assert test_device_facts['devices'] == {}


# Generated at 2022-06-20 17:23:42.351158
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    res = hardware.get_cpu_facts()
    assert res['processor']
    assert res['processor_count']
    assert res['processor_cores']

# Generated at 2022-06-20 17:23:53.150286
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_config = {
        "module_name": "test",
        "module_args": "%s"
    }

    class TestFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            self.module = module
            self.sysctl = '/bin/echo'

    test_module = type(str("test_module"), (), test_config)
    test_module.run_command = lambda *args, **kwargs: (0, "hw.ncpu: 2", "")
    test_hardware = TestFreeBSDHardware(test_module)

    cpu_facts = test_hardware.get_cpu_facts()
    assert cpu_facts['processor_count'] == 2



# Generated at 2022-06-20 17:23:54.553843
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    a = FreeBSDHardwareCollector().collect()
    assert "FreeBSD" in a.platform

# Generated at 2022-06-20 17:24:04.310572
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import sys
    sys.path.insert(0, './lib/ansible/module_utils/facts/hardware/')
    import FreeBSDHardware

    # Unit test for FreeBSDHardware.get_dmi_facts(): valid test1

# Generated at 2022-06-20 17:24:16.221162
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Test method get_dmi_facts of class FreeBSDHardware
    """
    from ansible.module_utils.facts import Hardware
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardware


# Generated at 2022-06-20 17:24:23.731055
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    hardware_facts = hardware.populate()
    # TODO: verify hardware_facts
    # pprint.pprint(hardware_facts)

    assert hardware_facts['devices']
    assert hardware_facts['uptime_seconds']
    assert hardware_facts['memtotal_mb']
    assert hardware_facts['swaptotal_mb']
    assert 'mounts' in hardware_facts

# Generated at 2022-06-20 17:24:29.194781
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=[], type='list')
    })
    hardware_obj = FreeBSDHardware(module)
    assert hardware_obj.module.fail_json.called is False, \
        "Failed to create the FreeBSDHardware object"
    assert hardware_obj.module.exit_json.called is False, \
        "Failed to create the FreeBSDHardware object"


# Generated at 2022-06-20 17:24:40.758295
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class ModuleStub(object):
        def __init__(self):
            self.run_command_calls = 0
            self.run_command_outputs = []
            self.get_bin_path_calls = 0
            self.get_bin_path_results = '/sbin/sysctl'
            self.run_command_check_rc = True

        def run_command(self, args, check_rc=None):
            self.run_command_calls += 1
            self.run_command_outputs.append(args)
            output = self.run_command_results[self.run_command_calls - 1]
            return (0, output, '')

        def get_bin_path(self, name):
            self.get_bin_path_calls += 1
            return self.get_bin

# Generated at 2022-06-20 17:24:50.433152
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
