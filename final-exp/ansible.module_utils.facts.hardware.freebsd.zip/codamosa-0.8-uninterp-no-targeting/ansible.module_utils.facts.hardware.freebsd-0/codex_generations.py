

# Generated at 2022-06-20 17:17:58.533836
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    result = FreeBSDHardware(module)
    assert result._platform == 'FreeBSD'


# Generated at 2022-06-20 17:18:06.522221
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # dummy module and dmidecode executable
    class Test_FreeBSDHardware(object):
        def __init__(self):
            self.params = {}

        def get_bin_path(self, x, opt_dirs=[]):
            return 'fake'

    class Test_dmidecode(object):
        def __init__(self):
            self.fake_data = {}
            self.fake_data['bios-release-date'] = 'dmidecode_data_date'
            self.fake_data['bios-vendor'] = 'dmidecode_data_vendor'
            self.fake_data['bios-version'] = 'dmidecode_data_version'
            self.fake_data['baseboard-asset-tag'] = 'dmidecode_data_tag'

# Generated at 2022-06-20 17:18:11.045392
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    result = hardware.populate()
    assert result['memtotal_mb'] >= 0
    assert result['memfree_mb'] >= 0
    assert result['processor_count'] > 0
    assert len(result['processor']) == result['processor_count']
    assert result['processor_cores'] > 0

# Generated at 2022-06-20 17:18:14.206827
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware()
    uptime_facts = hardware.get_uptime_facts()
    uptime_seconds = uptime_facts.get('uptime_seconds')
    assert uptime_seconds is not None

# Generated at 2022-06-20 17:18:25.865181
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import logging
    from ansible.module_utils.facts import ansible_facts

    logging.basicConfig(level=logging.DEBUG)

    module = ansible_facts
    module.params = {}
    module.run_command = lambda cmd, check_rc=True: (0, '', '')
    module.get_bin_path = lambda cmd: cmd

    # Disable timeout in tests
    FreeBSDHardware.timeout = lambda _: None

    # Base class
    hardware = FreeBSDHardware(module)
    # Subclass
    hardware = FreeBSDHardwareCollector(module).collect()[FreeBSDHardwareCollector._platform]

    base_methods = [method_name for method_name in dir(Hardware)
                    if callable(getattr(Hardware, method_name))
                    and not method_name.startswith("_")]
    subclass_

# Generated at 2022-06-20 17:18:36.045779
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class Module(object):
        def __init__(self):
            self.run_command_envs = dict()
            self.run_command_calls = list()
            self.params = dict()
        def get_bin_path(self, arg, opt_dirs=[]): # pylint: disable=unused-argument
            return '/sbin/' + arg
        def run_command(self, args, check_rc=False, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, envs=None, encoding=None): # pylint: disable=unused-argument
            # Save environment variables
            if envs:
                self.run_command_envs = en

# Generated at 2022-06-20 17:18:41.937923
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    uname = 'FreeBSD'
    path = '/usr/bin'
    module = 'ansible_unittest'
    module_args = 'test1=1 test2=2'
    module_name = 'test_module'

    freebsd_hardware = FreeBSDHardware(path, module, module_name, module_args, uname)
    assert freebsd_hardware._path == path
    assert freebsd_hardware._uname == uname
    assert freebsd_hardware._module == module
    assert freebsd_hardware._module_name == module_name
    assert freebsd_hardware._module_args == module_args
    assert freebsd_hardware._module.check_mode is False



# Generated at 2022-06-20 17:18:52.699191
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    # Data copied from /var/run/dmesg.boot on a FreeBSD 11.1 system

# Generated at 2022-06-20 17:19:02.608388
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware import FreeBSDHardware
    from datetime import datetime
    from datetime import timedelta
    import sys

    # First sys.platform needs to be set to 'FreeBSD'
    sys.platform = 'FreeBSD'

    # Then we patch struct.unpack to return the value passed to the second argument
    def patch_unpack(format, input):
        return (input,)

    struct.unpack = patch_unpack

    # And we create a fake module instance
    class FakeModule:
        def get_bin_path(self, cmd):
            return 'fakebin/' + cmd

        def run_command(self, cmd, check_rc=True, encoding=None):
            return 0, 'fakeoutput', 'fakeerror'

    module = FakeModule()

    # Now we can create a class

# Generated at 2022-06-20 17:19:10.859719
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Instantiate a FreeBSDHardwareCollector object and check for its attributes
    fact_class = FreeBSDHardwareCollector()
    assert fact_class.FACTS_CACHE_FILE == '/tmp/ansible_facts.cache'
    assert fact_class.FACTS_CACHE_TIMEOUT == 3600
    assert fact_class.FACT_SUBSETS == {'hardware': 'all',
                                       'network': 'all',
                                       'virtual': 'all'}

# Generated at 2022-06-20 17:19:35.052038
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )
    # Instantiate FreeBSDHardware class object
    fhw = FreeBSDHardware(module)
    facts = fhw.populate()
    assert 'devices' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'uptime_seconds' in facts
    assert 'devices' in facts
    assert 'bios_date' in facts
    assert 'bios_vendor' in facts
    assert 'bios_version' in facts

# Generated at 2022-06-20 17:19:38.318531
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class Object(object):
        pass

    module = Object()
    module.get_bin_path = lambda x: 'sysctl'
    module.run_command = lambda x: (0, 'hw.ncpu: 2\n', '')

    obj = FreeBSDHardware(module)

    fact = obj.get_cpu_facts()
    assert fact['processor_count'] == '2'



# Generated at 2022-06-20 17:19:49.370263
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    sysdir = '../unittest/data/freebsd-device-facts/dev'
    sh = FreeBSDHardware()
    device_facts = sh.get_device_facts()

# Generated at 2022-06-20 17:19:55.339022
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hardware_obj = FreeBSDHardware()
    hardware_obj.module = MockModule()


# Generated at 2022-06-20 17:20:08.400187
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test = FreeBSDHardware
    collected_facts = test.populate()
    assert 'processor_count' in collected_facts
    assert 'uptime_seconds' in collected_facts
    assert 'memtotal_mb' in collected_facts
    assert 'memfree_mb' in collected_facts
    assert 'swaptotal_mb' in collected_facts
    assert 'swapfree_mb' in collected_facts
    assert 'processor' in collected_facts
    assert 'devices' in collected_facts
    assert 'mounts' in collected_facts
    assert 'bios_date' in collected_facts
    assert 'bios_vendor' in collected_facts
    assert 'bios_version' in collected_facts
    assert 'board_asset_tag' in collected_facts
    assert 'board_name' in collected_facts

# Generated at 2022-06-20 17:20:12.258467
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    facts_module = AnsibleModuleMock(module_name='os_facts')
    facts_module.get_bin_path = lambda x: '/bin/sysctl'
    facts_module.run_command.return_value = (0, 'vm.stats.vm.v_page_size: 4194304\nvm.stats.vm.v_page_count: 634167\nvm.stats.vm.v_free_count: 623092', '')
    hardware_facts = FreeBSDHardware()
    hardware_facts.module = facts_module
    memory_facts = hardware_facts.get_memory_facts()
    assert memory_facts['memtotal_mb'] == 3072
    assert memory_facts['memfree_mb'] == 3003


# Generated at 2022-06-20 17:20:24.186580
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import HardwareCollector
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardwareCollector
    module = FakeAnsibleModule()
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware_inst = hardware_collector.collect()[0]

    # Mock the dmesg_boot file
    global fake_dmesg_boot

# Generated at 2022-06-20 17:20:28.509320
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = FreeBSDHardware().populate()
    assert facts['processor_count'] > 0
    assert isinstance(facts['processor'], list)
    assert isinstance(facts['processor_cores'], int)



# Generated at 2022-06-20 17:20:36.848551
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    module.get_bin_path = Mock(return_value='/usr/bin/sysctl')
    module.run_command = Mock(return_value=(0, "hw.ncpu: 8\n", ''))
    res = FreeBSDHardware(module).get_memory_facts()
    assert res['memfree_mb'] == int(128 * 1024 * 1024 / 1024 / 1024)
    assert res['swaptotal_mb'] == int(128 * 1024 * 1024 / 1024 / 1024)
    assert res['swapfree_mb'] == int(128 * 1024 * 1024 / 1024 / 1024)
    assert res['memtotal_mb'] == int(256 * 1024 * 1024 / 1024 / 1024)


# Generated at 2022-06-20 17:20:46.679785
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' returns dmi facts for a FreeBSD host '''

    class MockModule(object):
        def __init__(self):
            self.params = {}
            self.run_command_calls = []

        def run_command(self, command, check_rc=None, encoding=None, errors=None):
            self.run_command_calls.append(command)
            if command == '/usr/local/sbin/dmidecode -s system-manufacturer':
                return 0, "LENOVO\n# SMBIOS implementations newer than version 2.8 are not\n# fully supported by this version of dmidecode.", []

# Generated at 2022-06-20 17:21:26.599478
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    ansible_facts = {}
    ansible_facts['dmesg'] = {'cmdline': '...'}
    ansible_facts['ansible_processor_count'] = 2
    ansible_facts['ansible_processor'] = ['Intel(R) Core(TM) i3-3240 CPU @ 3.40GHz', 'Intel(R) Core(TM) i3-3240 CPU @ 3.40GHz']
    ansible_facts['ansible_processor_cores'] = 3
    ansible_module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    hh = FreeBSDHardware(ansible_module)

    actual_facts = hh.get_cpu_facts()

# Generated at 2022-06-20 17:21:31.868272
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hw = FreeBSDHardware()
    device_facts = {
        'devices': {
            'cd0': [
                'cd0'
            ],
            'da0': [
                'da0s1'
            ],
            'da1': [
                'da1s1'
            ]
        }
    }
    assert device_facts == hw.get_device_facts()



# Generated at 2022-06-20 17:21:38.729333
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_obj = FreeBSDHardware()
    test_obj.module = DummyAnsibleModule()
    test_obj.module.run_command = MagicMock(return_value=(0, "vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 7885040\nvm.stats.vm.v_free_count: 64096", ""))
    test_obj.module.get_bin_path = MagicMock(return_value=True)

    test_obj.get_memory_facts = MagicMock(return_value='')

    # Valid case
    result = test_obj.get_memory_facts()
    assert ('memfree_mb' in result)
    assert ('memtotal_mb' in result)
    assert ('swapfree_mb' in result)


# Generated at 2022-06-20 17:21:47.088618
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module(object):
        def __init__(self):
            self.run_command_calls = []

        def get_bin_path(self, executable):
            return executable

        def run_command(self, cmd, check_rc=None, encoding="utf-8"):
            self.run_command_calls.append(cmd)
            return [0, struct.pack('@Q', time.time() - 6), ""]

    h = FreeBSDHardware(Module())
    assert h.get_uptime_facts() == {"uptime_seconds": 6}

# Generated at 2022-06-20 17:21:54.485554
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Set up imports
    import sys
    import tempfile
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts.collector import BaseFactCollector

    # Create a mock subclass of BaseFactCollector
    class MockModule(BaseFactCollector):
        def get_bin_path(self, executable, required=False):
            return executable

    # Create the FreeBSDHardware instance
    hardware = FreeBSDHardware(module=MockModule)

    # Create a mock sysctl command
    (handle, sysctl_output) = tempfile.mkstemp()
    os.close(handle)

# Generated at 2022-06-20 17:22:05.423329
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # pylint: disable=import-error
    # pylint: disable=missing-docstring-field
    # pylint: disable=no-member,invalid-name
    # pylint: disable=unused-variable
    from ansible.module_utils.facts.collector import FreeBSDHardwareCollector
    from ansible.module_utils.facts.facts import Facts

    # We need to mock the run_command method and the
    # superclass constructor
    # pylint: disable=abstract-method
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            pass
        def get_bin_path(self, command):
            # We need to return a value different from
            # None to trigger this code path
            return command

    # We mock subprocess.Popen to return a

# Generated at 2022-06-20 17:22:18.180079
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    m = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False)

    # construct a FreeBSDHardware object
    hw = FreeBSDHardware(m)

    # populate
    hw.populate()

    biossys = hw.get_dmi_facts()

    # test if new facts have been added
    assert 'memfree_mb' in hw.facts
    assert 'memtotal_mb' in hw.facts
    assert 'swapfree_mb' in hw.facts
    assert 'swaptotal_mb' in hw.facts
    assert 'processor' in hw.facts
    assert 'processor_cores' in hw.facts
    assert 'processor_count' in hw.facts
    assert 'devices' in hw.facts
    assert 'uptime_seconds' in h

# Generated at 2022-06-20 17:22:29.596804
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class AnsibleModuleFake(object):
        def __init__(self, bin_path=None):
            self.bin_path_cache = {}
            if bin_path is not None:
                self.bin_path_cache = {'dmidecode': bin_path}

        def get_bin_path(self, name, required=False):
            path_lookup = {'dmidecode': '/usr/local/sbin/dmidecode'}
            return path_lookup.get(name, self.bin_path_cache.get(name, None))


# Generated at 2022-06-20 17:22:37.803591
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    FreeBSDHardware.get_dmi_facts()
    """
    module = FakeModule()

    # Could not find dmidecode executable. Should return empty dict
    module.run_command = lambda *args, **kwargs: (0, "", "")
    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    assert dmi_facts == {}

    # Valid output
    module.run_command = lambda *args, **kwargs: (0, "foo\nbar", "")
    dmi_facts = FreeBSDHardware(module).get_dmi_facts()

# Generated at 2022-06-20 17:22:50.809547
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:23:33.218775
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    fbsd_hw = FreeBSDHardware(dict(module=None))
    import sys
    import platform
    if sys.byteorder == 'big' and platform.machine() == 'amd64':
        assert fbsd_hw.get_uptime_facts() == {
            'uptime_seconds': int(time.time() - 1512764348),
        }
    else:
        assert fbsd_hw.get_uptime_facts() == {}

# Generated at 2022-06-20 17:23:41.053201
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Start with a raw binary sysctl output.
    # The encoding used is little-endian, unsigned long (L).
    # 1511378747 == Mon Nov 27 08:32:27 2017
    binary_sysctl_output = struct.pack('<L', 1511378747)
    module = AnsibleModule(argument_spec={})

    fact_class = FreeBSDHardware(module)
    facts = fact_class.get_uptime_facts()
    assert facts == {
        'uptime_seconds': 1511378747,
    }

# Generated at 2022-06-20 17:23:47.828262
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    har_obj = FreeBSDHardware()
    facts = har_obj.populate()

    assert 'uptime_seconds' in facts
    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts

# Generated at 2022-06-20 17:23:53.037182
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_obj = FreeBSDHardwareCollector()
    assert isinstance(test_obj._platform, str)
    assert isinstance(test_obj._fact_class, object)
    assert isinstance(test_obj.collect(), dict)


# Generated at 2022-06-20 17:23:58.869563
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Init class
    fhw = FreeBSDHardware()
    # Get function without sysctl
    fct_get_uptime_facts = fhw.get_uptime_facts
    # Replace function for
    fhw.get_uptime_facts = lambda: {'kern.boottime': "1515949860.962370"}
    # Test method
    uptime_facts = fhw.get_uptime_facts()
    # Restore function
    fhw.get_uptime_facts = fct_get_uptime_facts
    # Check result
    assert uptime_facts['uptime_seconds'] > 8 * 3600
    assert uptime_facts['uptime_seconds'] < 10 * 3600

# Generated at 2022-06-20 17:24:01.983241
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModuleMock(argument_spec={})
    hardware = FreeBSDHardware(module)
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0


# Generated at 2022-06-20 17:24:14.104963
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # To enable debug logging of ansible
    # import logging
    # logging.basicConfig(level=logging.DEBUG)
    module = AnsibleModule(argument_spec={})
    hardware_instance = FreeBSDHardware(module)
    output = hardware_instance.populate()

    # Check processor_count
    assert isinstance(output['processor_count'], str)

    # Check processor
    assert isinstance(output['processor'], list)

    # Check devices
    assert isinstance(output['devices'], dict)

    # Check memory_facts
    for key in ['memtotal_mb', 'memfree_mb']:
        assert isinstance(output[key], int)

    # Check uptime_facts
    assert isinstance(output['uptime_seconds'], int)

    # Check cpu_facts

# Generated at 2022-06-20 17:24:16.087012
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_facts = FreeBSDHardware()
    assert hardware_facts.__dict__ == {}



# Generated at 2022-06-20 17:24:17.398901
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware()
    assert facts.platform == 'FreeBSD'


# Generated at 2022-06-20 17:24:27.400066
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={})
    if module.check_mode:
        module.exit_json(failed=False, changed=False,
                         ansible_facts=dict(dmi_facts=FREBSD_DMIDECODE_OUTPUT))

    module.run_command = MagicMock(return_value=(0, FREBSD_DMIDECODE_OUTPUT, ""))
    module.get_bin_path = MagicMock(return_value="/usr/sbin/dmidecode")

    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    assert module.run_command.called
    assert dmi_facts == FREBSD_DMIDECODE_OUTPUT



# Generated at 2022-06-20 17:26:03.491730
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import sys
    # Fake class for AnsibleModule
    class AnsibleModuleFake:
        def __init__(self, **kwargs):
            self.params = kwargs

        def fail_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(1)

        def exit_json(self, *args, **kwargs):
            self.exit_args = args
            self.exit_kwargs = kwargs
            sys.exit(0)

    m = AnsibleModuleFake(
        gather_subset=['all'],
    )


# Generated at 2022-06-20 17:26:15.834615
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    controller = FreeBSDHardware(dict(module=dict()))
    # test for when dmidecode is not present
    controller.module.get_bin_path = lambda x: None
    assert controller.get_dmi_facts() == {}
    # test for when dmidecode is present
    def run_command(cmd, encoding, env_update, check_rc=True, executable=None):
        assert cmd == [controller.module.get_bin_path('dmidecode'), '-s', 'system-manufacturer']
        return 0, 'Test Manufacturer', ''
    controller.module.run_command = run_command
    assert controller.get_dmi_facts() == dict(system_vendor='Test Manufacturer')

# Get facts from the FreeBSDHardwareCollector class

# Generated at 2022-06-20 17:26:21.378638
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_instance = FreeBSDHardwareCollector.factory()
    hardware_facts = hardware_instance.collect()
    assert hardware_facts['processor'] is not None
    assert hardware_facts['processor_cores'] is not None
    assert hardware_facts['processor_count'] is not None
    assert hardware_facts['memtotal_mb'] is not None
    assert hardware_facts['memfree_mb'] is not None
    assert hardware_facts['swaptotal_mb'] is not None
    assert hardware_facts['swapfree_mb'] is not None
    assert hardware_facts['devices'] is not None

# Generated at 2022-06-20 17:26:31.738123
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModule(argument_spec={})
    module_params = {'gather_subset': 'all'}
    result = {}
    result['ansible_facts'] = {}

    hw_facts_obj = FreeBSDHardwareCollector(module)
    facts_dict = hw_facts_obj.collect(module_params, result)
    assert facts_dict is not None
    assert len(facts_dict['ansible_devices']) > 0
    assert len(facts_dict['ansible_mounts']) > 0
    assert facts_dict['ansible_memfree_mb'] >= 0
    assert facts_dict['ansible_memtotal_mb'] >= 0
    assert facts_dict['ansible_processor'] is not None
    assert (type(facts_dict['ansible_processor']) is list)
    assert len

# Generated at 2022-06-20 17:26:40.679175
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class FreeBSDHardware_test(FreeBSDHardware):
        def __init__(self):
            self.module = None
            self.run_command = lambda cmd, check_rc=True, encoding='utf-8', errors='surrogate_then_replace': (0, '1073741824 140735001853248', '')
            self.get_bin_path = lambda path: path

    hardware = FreeBSDHardware_test()
    uptime_facts = hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 1073741824

# Generated at 2022-06-20 17:26:51.856240
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    path = '/tmp/ansible_facts'
    # Create a fake sys directory
    os.makedirs(os.path.join(path, '/dev'))
    os.makedirs(os.path.join(path, '/dev/ufs'))

    # Create some fake devices
    open(os.path.join(path, '/dev/ada0'), 'a').close()
    open(os.path.join(path, '/dev/ada0s1d'), 'a').close()
    open(os.path.join(path, '/dev/da0c'), 'a').close()
    open(os.path.join(path, '/dev/da0s1d'), 'a').close()
    open(os.path.join(path, '/dev/cd0'), 'a').close()

# Generated at 2022-06-20 17:27:01.195449
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    if 'FreeBSD' in platform.platform():
        fbsdhw = FreeBSDHardware(module=module)
        facts = fbsdhw.populate()
        assert facts['uptime_seconds']
        assert facts['processor']
        assert facts['processor_count']
        assert facts['processor_cores']
        assert facts['devices']
        assert facts['memtotal_mb']
        assert facts['memfree_mb']
        assert facts['swaptotal_mb']
        assert facts['swapfree_mb']
        assert facts['product_name']
        assert facts['product_serial']
        assert facts['product_uuid']
        assert facts['product_version']
        assert facts['form_factor']
        assert facts['system_vendor']

# Generated at 2022-06-20 17:27:04.291502
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # the class's module attribute `_platform` is set to the platform the collector class
    # is supported on. This is a class attribute and should never be set or changed
    # in the class's constructor.
    collector = FreeBSDHardwareCollector()
    assert isinstance(collector, HardwareCollector)
    assert collector._platform == 'FreeBSD'


# Generated at 2022-06-20 17:27:04.839489
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:27:07.169942
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module=module)
    assert fhw.get_memory_facts() != {}
