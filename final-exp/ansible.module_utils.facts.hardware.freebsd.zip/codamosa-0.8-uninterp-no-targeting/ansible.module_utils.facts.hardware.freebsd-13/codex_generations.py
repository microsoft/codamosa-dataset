

# Generated at 2022-06-20 17:18:04.637255
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils._text import to_bytes

    def raise_called():
        """Helper function for mocking subprocess.check_output"""
        raise CalledProcessError(1, "foo")

    def catch_called(cmd, *args):
        """Helper function for mocking subprocess.check_output"""
        if to_bytes(cmd) == to_bytes("sysctl -b kern.boottime"):
            return to_bytes("{} {}".format(1520099600, 0))
        else:
            return to_bytes(" NA  NA  NA  NA  ")

    old_check_output = subprocess.check_output
    sysctl_cmd = 'sysctl'

# Generated at 2022-06-20 17:18:16.116569
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestModule(object):

        def __init__(self):
            self.params = {'gather_timeout': 5}

        def fail_json(self, *args, **kwargs):
            pass

        def get_bin_path(self, *args, **kwargs):
            return '/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return 0, 'hw.ncpu: 4\n', ''

    sysctl_cmd = '/bin/sysctl'

# Generated at 2022-06-20 17:18:27.858916
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = type('', (), {})()
    setattr(module, 'run_command', staticmethod(lambda x: (0, struct.pack('@L', 0), '')))
    class_vars = {'module': module}
    fact_class = type('', (FreeBSDHardware,), class_vars)()
    assert fact_class.get_uptime_facts()['uptime_seconds'] == 0
    setattr(module, 'run_command', staticmethod(lambda x: (0, struct.pack('@L', 2 ** 32), '')))
    assert fact_class.get_uptime_facts()['uptime_seconds'] == 2 ** 32
    setattr(module, 'run_command', staticmethod(lambda x: (0, struct.pack('@L', 0) + 'x', '')))

# Generated at 2022-06-20 17:18:34.317164
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = type('', (object, ), {})
    module.get_bin_path = lambda x: '/bin/sysctl'
    module.run_command = lambda x: (0, b'kern.boottime=1528899657 33134843\n', b'')
    hardware = FreeBSDHardware(module)
    actual = hardware.get_uptime_facts()
    expected = {'uptime_seconds': 1528905962}
    assert actual == expected

# Generated at 2022-06-20 17:18:38.321030
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    my_hardware = FreeBSDHardware()


# Generated at 2022-06-20 17:18:45.297484
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' test whether get_dmi_facts returns a dictionary with at least product_name '''
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fhw = FreeBSDHardware(test_module)
    dmi_facts = fhw.get_dmi_facts()
    assert 'product_name' in dmi_facts


# Generated at 2022-06-20 17:18:54.885606
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    Unit test for method get_dmi_facts of class FreeBSDHardware
    """
    class DummyModule:
        def __init__(self):
            self.run_command_rc = 0
            self.run_command_out = ''
            self.run_command_err = None

        def get_bin_path(self, cmd):
            return "dmidecode"

        def run_command(self, cmd, encoding=None):
            return (self.run_command_rc, self.run_command_out, self.run_command_err)

    m = DummyModule()
    fh = FreeBSDHardware(module=m)


# Generated at 2022-06-20 17:19:05.587415
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """ get_device_facts
    """
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    mock = {
        '/dev/ada0': Mock(),
        '/dev/ada1': Mock(),
        '/dev/ada2': Mock(),
        '/dev/sda0': Mock(),
        '/dev/sda1': Mock(),
        '/dev/sda2': Mock(),
    }

    with patch.dict('sys.modules', {'os': mock['os']}):
        from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
        mock['FreeBSDHardware'] = FreeBSDHardware


# Generated at 2022-06-20 17:19:12.854336
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # this unit test is here only for pytest code coverage
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    f = FreeBSDHardware(module)
    facts = f.get_device_facts()
    mounts = facts.get('devices')
    assert mounts is not None
    if mounts:
        assert isinstance(mounts, dict)
        assert isinstance(mounts.get('ada0'), list)

# Generated at 2022-06-20 17:19:21.793728
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Create a mock module class
    class MockModule:
        def __init__(self):
            self.run_command = MockModuleRunCommand()

        def get_bin_path(self, executable):
            return ""

    # Create a mock class for run_command and return the expected output.
    class MockModuleRunCommand:
        def __init__(self):
            self.run_command_results = []
            self.run_command_last_index = 0

        def add_result(self, rc, out, err):
            result = (rc, out, err)
            self.run_command_results.append(result)

        def __call__(self, *args, **kwargs):
            rc, out, err = self.run_command_results[self.run_command_last_index]
            self.run_command

# Generated at 2022-06-20 17:19:37.996124
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # FIXME: requires singleton.  how to fake it?
    return True

# Generated at 2022-06-20 17:19:41.758727
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Assign
    m = FreeBSDHardware({})
    dmi_facts = {}

    # Act
    dmi_facts = m.get_dmi_facts()

    # Assert - the dmi_facts are populated by the test module
    assert dmi_facts != {}

# Generated at 2022-06-20 17:19:51.176473
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module=module)
    result = hardware.get_device_facts()
    assert 'devices' in result
    assert isinstance(result['devices'], dict)
    for key in result['devices'].keys():
        assert re.match(re.compile(r'(ada?\d+|da\d+|a?cd\d+)'), key) is not None
        for i in result['devices'][key]:
            assert re.match(re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)'), i) is not None



# Generated at 2022-06-20 17:19:52.894029
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    s = FreeBSDHardware()
    assert isinstance(s, Hardware)
    assert isinstance(s, FreeBSDHardware)
    assert s.platform == 'FreeBSD'

# Generated at 2022-06-20 17:19:57.320626
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware_obj = FreeBSDHardware(module)
    device_facts_dict = hardware_obj.get_device_facts()
    devices_dict = device_facts_dict['devices']
    assert len(devices_dict) >= 0, 'Unexpected value for len(devices_dict)'
    assert 'sda' in devices_dict


# Generated at 2022-06-20 17:20:01.613108
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''Tests that the constructor properly assigns the fact class variable
    '''

    hw_collector = FreeBSDHardwareCollector()
    assert(hw_collector.fact_class == FreeBSDHardware)

# Generated at 2022-06-20 17:20:05.519117
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    freebsd_hardware = FreeBSDHardware(module)
    freebsd_hardware.populate()
    result = freebsd_hardware.get_facts()
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result
    assert 'memtotal_mb' in result
    assert 'memfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'devices' in result



# Generated at 2022-06-20 17:20:18.897603
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    # create some dictionaries with faked hardware info
    cpu_facts = {'processor': ['Intel(R) Xeon(R) CPU E5-2650 v3 @ 2.30GHz',
                               'Intel(R) Xeon(R) CPU E5-2650 v3 @ 2.30GHz'],
                 'processor_count': 8,
                 'processor_cores': 1}
    memory_facts = {'memtotal_mb': 32768,
                    'memfree_mb': 16194,
                    'swaptotal_mb': 8192,
                    'swapfree_mb': 8192}
    uptime_facts = {'uptime_seconds': 68125}

# Generated at 2022-06-20 17:20:26.914624
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    Unit test for method get_dmi_facts of class FreeBSDHardware
    """

    def get_bin_path(binary):
        """
        Return the path. Run from a local or system installation.
        """
        module_path = os.path.dirname(os.path.realpath(__file__))
        binary_path = os.path.join(module_path, binary)
        if os.path.exists(binary_path):
            return binary_path
        else:
            return binary

    def run_command(command, check_rc=True, encoding=None):
        """
        Mock method run_command. Return the dmidecode output.
        """

        return (0, dmidecode_output, '')


# Generated at 2022-06-20 17:20:36.351703
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    class TestModule(object):
        def get_bin_path(self, arg):
            cmd = '/sbin/sysctl'
            return cmd

        def run_command(self, cmd, encoding=None):
            if cmd == '/sbin/sysctl vm.stats':
                rc = 0
                out = 'hw.ncpu: 4\nhw.realmem: 67108864\nvm.stats.vm.v_page_size: 4096\n' \
                      'vm.stats.vm.v_page_count: 262144\nvm.stats.vm.v_free_count: 51862\n'
                err = ''
            elif cmd == '/sbin/sysctl -n hw.ncpu':
                rc = 0
                out = '4\n'
                err = ''

# Generated at 2022-06-20 17:21:24.664759
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import TimeoutError
    from ansible.module_utils.facts.collector import TestModuleClass
    from ansible.module_utils.facts.utils import AnsibleFailJson

    def get_bin_path(name):
        """ Fake get_bin_path method for unit tests """
        if name == 'sysctl':
            return '/sbin/sysctl'
        raise ValueError('binary %s not found' % name)

    def run_command(self, cmd, *args, **kwargs):
        """ Fake run_command method for unit tests """
        if cmd == ['/sbin/sysctl', '-b', 'kern.boottime']:
            if self.__class__.__name__ == 'FreeBSDHardwareNoBoottime':
                return 1, '', ''

# Generated at 2022-06-20 17:21:26.345472
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    freebsd_hardware = FreeBSDHardware()
    assert freebsd_hardware is not None


# Generated at 2022-06-20 17:21:34.445427
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_class = FreeBSDHardware()
    out = [
        'hw.ncpu: 4',
        'vm.stats.vm.v_page_size: 4096',
        'vm.stats.vm.v_page_count: 5846869',
        'vm.stats.vm.v_page_free: 3747537',
    ]
    expected = {
        'memtotal_mb': 23419,
        'memfree_mb': 14652,
        'swaptotal_mb': 'NA',
        'swapfree_mb': 'NA',
    }
    result = test_class.get_memory_facts()
    assert result == expected


# Generated at 2022-06-20 17:21:38.559518
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_facts = FreeBSDHardware()
    result = hardware_facts.populate()
    assert result['uptime_seconds'] > 0
    assert result['bios_version'] == 'NA'

# Generated at 2022-06-20 17:21:42.785300
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = AnsibleModule(argument_spec=dict())
    fhw = FreeBSDHardware(m)

    facts = fhw.get_cpu_facts()

    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'processor' in facts


# Generated at 2022-06-20 17:21:51.858433
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Normal case
    kern_boottime = str(int(time.time()) - 1399).encode()
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    out = kern_boottime + (b'\0' * (struct_size - len(kern_boottime)))
    hardware = FreeBSDHardware(module=None)
    result = hardware.get_uptime_facts(out=out)["uptime_seconds"]
    assert result == 1399

    # Error case
    out = (b'\0' * struct_size)
    result = hardware.get_uptime_facts(out=out)
    assert result == {}

    # Impossible case
    assert -1 == -1

# Generated at 2022-06-20 17:22:03.632974
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec={'gather_subset': dict(default=['!all'], type='list')})
    obj = FreeBSDHardwareCollector(module=module)

    my_dmi_facts = obj.get_dmi_facts()

    # obj.get_dmi_facts() must return a dict, even if it is empty
    assert isinstance(my_dmi_facts, dict)

    # keys of DMI_DICT must be key of dmi_facts
    for k in obj._fact_class.get_dmi_facts():
        assert dmi_facts.has_key(k)

    # dmidecode must return a string
    for k, v in dmi_facts.items():
        assert isinstance(v, str)


# Generated at 2022-06-20 17:22:09.034160
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a class FreeBSDHardware with a mocked method run_command
    class FreeBSDHardwareMocked(FreeBSDHardware):
        def run_command(self, cmd, check_rc=True, encoding=None):
            if 'sysctl' in cmd:
                # Return an uptime of 42 seconds
                return (0, b'\x00\x00\x00\x00\x00\x00\x00*', '')

    # Create an instance of FreeBSDHardwareMocked
    freebsd_hardware = FreeBSDHardwareMocked()
    uptime_facts = freebsd_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == 42

# Generated at 2022-06-20 17:22:19.575980
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(gather_subset=dict(type='list'))
    )
    os_instance = FreeBSDHardware(module)
    os_instance.populate()

# Generated at 2022-06-20 17:22:30.279016
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    test_data = 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'hw.ncpu=4\n'
    test_data += 'cpu0: Intel(R)\n'

# Generated at 2022-06-20 17:24:00.568508
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import timeout

    _module = None
    _bin_path = '/bin:/sbin:/usr/bin:/usr/sbin:/usr/local/bin:/usr/local/sbin'
    _bin_path = _bin_path.split(':')

    class _Module:
        def __init__(self):
            self.fail_json = lambda **kwargs: {'failed': True, 'msg': "intentional error"}
            self.changed = False
            self.exit_json = lambda **kwargs: {'changed': False, 'failed': False}
            self.run_command = lambda _: [0, '/sbin:/bin:/usr/sbin:/usr/bin', '']
            self.get_bin_path = lambda cmd: _bin_path if cmd in _bin_path else None

# Generated at 2022-06-20 17:24:12.631431
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """ This test case needs the python dmidecode package to run.
        If not installed, the code snippet below skips the test.
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from dmidecode.dmidecode import DmiDecode
    from ansible.module_utils._text import to_bytes
    # create test instance
    fhw = FreeBSDHardware({})
    # get dmi facts
    dmi_facts = fhw.get_dmi_facts()

    assert dmi_facts
    dmi = DmiDecode()
    try:
        info = dmi.get_info()
    except IOError:
        assert True
        return
    except Exception:
        raise


# Generated at 2022-06-20 17:24:15.449262
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    harware = FreeBSDHardware(module=module)
    res = harware.populate()
    assert res is not None


# Generated at 2022-06-20 17:24:24.544346
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class Bunch(object):

        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    module = Bunch(
        get_bin_path=lambda x: x if x in (
            '/sbin/sysctl', '/bin/sysctl', '/usr/sbin/sysctl') else None,
        run_command=lambda *args, **kwargs: (
            0, 'hw.ncpu: 2\nhw.pagesize: 4096', '')
    )

    fhw = FreeBSDHardware(module)
    device_facts = fhw.get_device_facts()

    assert type(device_facts) is dict
    assert 'devices' in device_facts
    assert type(device_facts['devices']) is dict
    assert device_facts['devices'] == {}

# Generated at 2022-06-20 17:24:26.552335
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector._platform == 'FreeBSD'
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:24:39.073829
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    class TestModule:
        def __init__(self):
            self.run_command_calls = []
            self.bin_path_rc = 0

        def get_bin_path(self, name, required=False):
            if name == 'dmidecode' and self.bin_path_rc == 0:
                return '/usr/bin/dmidecode'
            else:
                return None

        def run_command(self, cmd, encoding=None, check_rc=True, cwd=None):
            self.run_command_calls.append(cmd)
            if cmd == '/usr/bin/dmidecode -s system-product-name':
                return 0, 'System Product Name\n', ''

# Generated at 2022-06-20 17:24:48.855629
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # Declare an object of class FreeBSDHardware
    freebsd_testing = FreeBSDHardware()

    # Create a sysctl object to test method get_memory_facts
    class SysctlMock(object):
        def __init__(self):
            self.returncode = 0
            self.out = """vm.stats.vm.v_page_size:    4096
vm.stats.vm.v_page_count:       1743528
vm.stats.vm.v_free_count:       1409938
"""
        def run(self, *args, **kwargs):
            return self.returncode, self.out, ''

    # Create a swapinfo object to test method get_memory_facts
    class SwapinfoMock(object):
        def __init__(self):
            self.returncode = 0

# Generated at 2022-06-20 17:25:01.108564
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.utils import FactsParams
    from ansible.module_utils.facts import timeout

    # Create instance of FreeBSDHardware
    params = FactsParams()
    freebsd = FreeBSDHardware(params)

    # mock value of get_bin_path function
    freebsd.get_bin_path = lambda x: '/usr/sbin/sysctl'
    # mock value of swapinfo command
    fake_swapinfo = b"Device          1M-blocks     Used    Avail Capacity\n/dev/ada0p3        314368        0   314368     0%"
    # mock value of sysctl vm.stats command

# Generated at 2022-06-20 17:25:02.491045
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw.populate()

# Generated at 2022-06-20 17:25:12.193006
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # setup
    bio_date = '01/01/1971'
    bio_vendor = 'TestCorp'
    bio_version = '1.1.1'
    board_asset_tag = ''
    board_name = 'Test'
    board_serial = ''
    board_vendor = 'TestCorp'
    board_version = '1.1.1'
    chassis_asset_tag = ''
    chassis_serial = ''
    chassis_vendor = 'TestCorp'
    chassis_version = '1.1.1'
    form_factor = ' '
    product_name = 'TestSystem'
    product_serial = '12345670'
    product_uuid = '00000000-0000-0000-0000-000000000000'
    product_version = '1.1.1'