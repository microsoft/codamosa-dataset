

# Generated at 2022-06-20 17:18:00.198992
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    freebsd_hardware_instance = FreeBSDHardware(module)
    assert freebsd_hardware_instance.module == module
    assert freebsd_hardware_instance.platform == 'FreeBSD'


# Generated at 2022-06-20 17:18:10.957468
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Unit tests for method get_device_facts of class FreeBSDHardware'''
    class ModuleFail(object):
        def get_bin_path(self, sysdir):
            return None

        def run_command(self, args, check_rc=True, encoding=None):
            rc = 0

# Generated at 2022-06-20 17:18:19.367024
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a FreeBSDHardware object
    hardware = FreeBSDHardware()

    # Mock the time.time() method to return a fixed value
    time.time = lambda: 1598270483.149961

    # Create the output of the sysctl command as if run on a FreeBSD host
    sysctl_output = b'\x00\x00\x00\x00\x00\x00\x00\x00'

    # Create the mock_run_command() function
    def mock_run_command(cmd, encoding=None, errors=None, check_rc=None):
        # Return the output of sysctl as if run on a FreeBSD host
        return [0, sysctl_output, '']

    # Set the _module.run_command() method for the hardware object
    hardware._module.run_command = mock_run_command

    # Call

# Generated at 2022-06-20 17:18:24.445204
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Unit test for method get_dmi_facts of class FreeBSDHardware
    '''

    def __init__(self, module):
        self.module = module
        self.run_command = mock_run_command

    def get_bin_path(self, exe):
        return '/usr/local/bin/' + exe

    module = type('AnsibleModule', (object,), {
        'run_command': mock_run_command,
        'get_bin_path': get_bin_path,
    })

    hw = FreeBSDHardware(module)
    results = hw.get_dmi_facts()

    assert results['bios_date'] == '12/01/2006'
    assert results['bios_vendor'] == 'innotek GmbH'

# Generated at 2022-06-20 17:18:31.934288
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hardware = FreeBSDHardware(module)
    hardware.populate()
    memory_facts = hardware.get_memory_facts()

    assert memory_facts
    assert memory_facts['memtotal_mb'] >= 0
    assert memory_facts['swaptotal_mb'] >= 0
    assert memory_facts['memfree_mb'] >= 0
    assert memory_facts['swapfree_mb'] >= 0



# Generated at 2022-06-20 17:18:43.492614
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:18:45.110078
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    hw = FreeBSDHardware()
    assert hw.get_memory_facts()

# Generated at 2022-06-20 17:18:55.363169
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    hardware = FreeBSDHardware()
    hardware.module.get_bin_path = lambda _: '/sbin/sysctl'
    hardware.module.run_command = lambda _: (0, 'a acd0 da0\n', None)
    assert hardware.get_device_facts() == {'devices': {'acd0': [], 'da0': []}}

    hardware.module.run_command = lambda _: (0, 'a acd0 da0 fd0\n', None)
    assert hardware.get_device_facts() == {'devices': {'acd0': [], 'da0': [], 'fd0': []}}

    hardware.module.run_command = lambda _: (0, 'a acd0 da0 fd0 fd0a\n', None)
    assert hardware.get_device_facts()

# Generated at 2022-06-20 17:19:01.969713
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Setup
    from ansible.module_utils import basic
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    module = basic.AnsibleModule(
        argument_spec  = dict(),
        supports_check_mode = True
    )

    bsdhw = FreeBSDHardware(module)

    # Test
    try:
        dmi_facts = bsdhw.get_dmi_facts()
    except TimeoutError:
        dmi_facts = {}

    assert (dmi_facts)

# Generated at 2022-06-20 17:19:14.887419
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    fhw = FreeBSDHardware(module=module)

    devices_dict = {}
    devices_list = ["ada0", "ada1", "ada2", "ada0s1a", "ada0s1b", "ada1s1a", "ada1s1b", "ada2s1a", "ada2s1b", "ada0s1e", "ada1s1e", "ada2s1e", "ada0s1f", "ada1s1f", "ada2s1f", "ada0s1g", "ada1s1g", "ada2s1g", "ada0s1h", "ada1s1h", "ada2s1h"]  # drive, slice1, slice2, slice3 and slice4

    # Test case 1
    devices

# Generated at 2022-06-20 17:19:38.216528
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import ansible_collections.notstdlib.moveitallout.tests.unit.compat.mock as mock

    m = mock.mock_open(read_data='/dev/ada0s1a  /  ufs  rw,noatime  1  1\n/dev/ada0s1b none swap sw,noatime 0 0')
    m.return_value.__iter__ = lambda self: iter(self.readline, '')
    with mock.patch('ansible_collections.notstdlib.moveitallout.tests.unit.modules.utils.get_file_content', m):
        freebsd_hw = FreeBSDHardware(mock.Mock())
        freebsd_hw.get_device_facts()

# Generated at 2022-06-20 17:19:49.287108
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """ This is a test for method get_device_facts of class FreeBSDHardware """

    from ansible.module_utils._text import to_bytes

    if os.name != 'posix':
        module = False
    else:
        from ansible.module_utils.facts import ModuleTestCase

        class FreeBSDModuleTestCase(ModuleTestCase):
            """ A subclass of the ansible ModuleTestCase class specifically for FreeBSD"""

            def setUp(self):
                super(FreeBSDModuleTestCase, self).setUp()
                self.mock_module = MagicMock()
                self.mock_module.run_command.return_value = (0, b'', None)
                self.mock_module.get_bin_path.return_value = '/bin/foo'


# Generated at 2022-06-20 17:19:51.947364
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = type('Module', (object,), {})
    test_module.get_bin_path = lambda _: None
    hardware = FreeBSDHardware(test_module)
    hardware.get_memory_facts()


if __name__ == '__main__':
    # Run unit test
    test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-20 17:19:53.077066
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """ unit test for method get_dmi_facts of class FreeBSDHardware """
    assert None



# Generated at 2022-06-20 17:19:58.476540
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    hardware_fbsd = FreeBSDHardware(module)
    hardware_fbsd._module = module

    hardware_fbsd.get_device_facts()


# Generated at 2022-06-20 17:20:02.106069
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    test1 = FreeBSDHardware(dict(module=None, ansible_facts={}))
    assert test1.platform == 'FreeBSD'

# Generated at 2022-06-20 17:20:14.901578
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fb = FreeBSDHardware()


# Generated at 2022-06-20 17:20:17.007119
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_inst = FreeBSDHardware()
    assert hardware_inst.platform == 'FreeBSD', hardware_inst.platform

# Generated at 2022-06-20 17:20:22.977824
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    import sys
    import cStringIO

    hw = FreeBSDHardware(sys.modules[__name__])
    assert hw.DMESG_BOOT == '/var/run/dmesg.boot'
    assert hw.platform == 'FreeBSD'

    out = cStringIO.StringIO()
    hw.populate()
    hw.print_json(out)


# Generated at 2022-06-20 17:20:27.964011
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """Test FreeBSDHardware constructor"""
    module = FakeAnsibleModule()
    fhw = FreeBSDHardware(module)
    assert fhw.platform == 'FreeBSD'
    assert fhw.module == module



# Generated at 2022-06-20 17:20:48.917065
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Creating a module obj and adding lines to be used by get_device_facts()
    module = AnsibleModuleMock()
    sysdir = '/dev'
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    if os.path.isdir(sysdir):
        dirlist = sorted(os.listdir(sysdir))
        module.add_lines('1\n' + '\n'.join(dirlist))

    # Creating a FreeBSDHardware object and calling get_device_facts()
    hardware = FreeBSDHardware(module)
    actual_result = hardware.get_device_facts()

    # loop

# Generated at 2022-06-20 17:20:52.208937
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_facts = FreeBSDHardware.get_cpu_facts()
    assert hardware_facts['processor'] != []
    assert hardware_facts['processor_cores'] != ''
    assert hardware_facts['processor_count'] != ''



# Generated at 2022-06-20 17:21:01.422955
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = type('', (), dict(get_bin_path=lambda x: None))()
    test_module.run_command = lambda x: (1, '', '')
    result = FreeBSDHardware(test_module).get_memory_facts()

    # free -m command must be supported
    assert result['memfree_mb'] == 0
    assert result['memtotal_mb'] == 0
    assert result['swapfree_mb'] == 0
    assert result['swaptotal_mb'] == 0



# Generated at 2022-06-20 17:21:10.410946
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    This method is being called when module is initialized
    """
    # Construct a mock that simulates the module object
    class MockModule(object):

        def get_bin_path(self, name, opt_dirs=[]):
            if name == 'sysctl':
                return 'sysctl'

        def run_command(self, cmd, check_rc=True, encoding=None):
            if cmd == 'sysctl -n kern.disks':
                return 0, '', ''

    module = MockModule()

    # Construct an instance of FreeBSDHardware
    freebsd_hardware = FreeBSDHardware(module=module)

    # Get facts from instance
    facts = freebsd_hardware.get_device_facts()

    # Test the result:
    # Make sure that the dict contains a key named devices.
    # Make sure

# Generated at 2022-06-20 17:21:14.083010
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    mod = lambda: None
    mod.get_bin_path = lambda x: x
    module = mod
    hardware = FreeBSDHardware(module)
    assert hardware.platform == 'FreeBSD'

# Generated at 2022-06-20 17:21:27.064636
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # Setup mock module and data
    sysctl = [
        "vm.stats.vm.v_page_size: 10240",
        "vm.stats.vm.v_page_count: 200",
        "vm.stats.vm.v_free_count: 100",
    ]
    swapinfo = [
        "Device          1M-blocks     Used    Avail Capacity",
        "/dev/ada0p3        200         0      200     0%",
        "",
    ]
    mock_module = type('AnsibleModule', (object,), dict(
        run_command=lambda *args, **kwargs: (0, '\n'.join(sysctl + swapinfo), ''),
        get_bin_path=lambda *args, **kwargs: "/usr/bin/sysctl"
    ))

    # Run tests


# Generated at 2022-06-20 17:21:36.062324
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Create a mock module
    module = AnsibleModule(argument_spec={})

    # Create a mock sysctl command with output containing
    # some interesting values
    class MockSysctlCommand():
        def __init__(self, module_ref):
            pass

    # Create a mock FreeBSDHardware object and check some dmi values
    hardware = FreeBSDHardware(module)

    dmi_facts = hardware.get_dmi_facts()

    assert dmi_facts['bios_date'] == 'NA'
    assert dmi_facts['bios_vendor'] == 'NA'
    assert dmi_facts['bios_version'] == 'NA'
    assert dmi_facts['board_asset_tag'] == 'NA'
    assert dmi_facts['board_name'] == 'NA'

# Generated at 2022-06-20 17:21:37.554084
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    assert FreeBSDHardware({}) is not None



# Generated at 2022-06-20 17:21:39.270641
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert issubclass(FreeBSDHardwareCollector, HardwareCollector)


# Generated at 2022-06-20 17:21:49.959952
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import ansible.module_utils.facts.hardware.freebsd

    class FakeModule(object):
        def __init__(self):
            self.run_command_exc = None
            self.run_command_stdout = None
            self.run_command_rc = 0
            self.run_command_err = ''

        def get_bin_path(self, executable):
            return './%s' % executable

        def run_command(self, args, check_rc=True, encoding=None):
            if self.run_command_exc:
                raise self.run_command_exc
            return self.run_command_rc, self.run_command_stdout, self.run_command_err


# Generated at 2022-06-20 17:22:11.238998
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test for FreeBSDHardware class method get_cpu_facts.
    """

    from ansible.module_utils import basic
    from ansible.module_utils.facts import collector


# Generated at 2022-06-20 17:22:18.221977
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    import re
    devnull = open('/dev/null', 'w')
    dist = None
    module = None
    hardware = FreeBSDHardware(module=module, dist=dist)
    hardware.get_dmi_facts()
    fail_re = re.compile(r'failed')
    import sys
    for line in sys.stdout:
        if fail_re.match(line):
            raise Exception('Unit test for method get_dmi_facts of class FreeBSDHardware failed')


# Generated at 2022-06-20 17:22:26.975855
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    linux_module = type('', (), {'get_bin_path': lambda _: '/bin/sysctl'})
    run_command_result = (0, 'kern.boottime: { sec = 1602704220, usec = 147874 }', '')
    module_run_command = lambda _, cmd, encoding=None: run_command_result
    linux_module.run_command = module_run_command
    hardware = FreeBSDHardware(linux_module)
    uptime_facts = hardware.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts

# Generated at 2022-06-20 17:22:30.579085
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    module = AnsibleModuleMock()
    module.get_bin_path.return_value = '/bin/sysctl'
    collector = FreeBSDHardwareCollector(module=module)
    assert collector.module.get_bin_path.called
    assert collector.platform == 'FreeBSD'

# Generated at 2022-06-20 17:22:33.634443
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware = FreeBSDHardware(module=module)
    hardware_facts = hardware.populate()
    assert hardware_facts['devices']['devices']

# Generated at 2022-06-20 17:22:44.967629
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:22:55.394493
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # happy path: we have a sysctl command available
    m_sysctl = MagicMock(return_value='1'.encode())
    # we are simulating the repr() of a struct.unpack result
    m_struct = MagicMock()
    setattr(m_struct, '__repr__', MagicMock(return_value='(1, )'))
    m_struct.calcsize.return_value = 8

    with patch('ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware.get_bin_path', m_sysctl), \
            patch('ansible.module_utils.facts.hardware.freebsd.struct', m_struct):
        assert FreeBSDHardware().get_uptime_facts() == {
            'uptime_seconds': 1,
        }

    # sysctl

# Generated at 2022-06-20 17:23:07.389254
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = __import__('ansible.module_utils.facts.hardware.freebsd', globals(), locals(), ['FreeBSDHardware'], 0)
    fh = m.FreeBSDHardware()

    fh.module.run_command = lambda x: ('', 'kern.boottime: Wed Dec 31 16:00:00 1969\n', '')
    assert fh.get_uptime_facts() == {'uptime_seconds': 0}

    fh.module.run_command = lambda x: ('', 'kern.boottime: Wed Dec 31 18:00:00 1969\n', '')
    assert fh.get_uptime_facts() == {'uptime_seconds': 7200}


# Generated at 2022-06-20 17:23:18.690400
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    uptime_fact = {}
    raw = b'\x01H\xea/\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00\x00'
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if len(raw) < struct_size:
        uptime_fact['uptime_seconds'] = 0
    else:
        (kern_boottime, ) = struct.unpack(struct_format, raw[:struct_size])
        uptime = int(time.time() - kern_boottime)
        uptime_fact['uptime_seconds'] = uptime



# Generated at 2022-06-20 17:23:25.262398
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    module = Bunch()
    module.get_bin_path = lambda x: x

    myos = FreeBSDHardwareCollector()
    myos.module = module

    out = myos.get_device_facts()
    assert 'devices' in out

# Generated at 2022-06-20 17:24:05.092075
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware({})
    hardware.populate()

# Generated at 2022-06-20 17:24:16.913224
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''Unit test for method get_dmi_facts of class FreeBSDHardware'''

    class MockModule:
        def __init__(self, bin_path):
            self.param1 = bin_path

        def get_bin_path(self, arg1):
            return self.param1

        def run_command(self, cmd, encoding=None):
            if cmd[0] == 'dmidecode':
                return 0, "Command succeeded", None
            else:
                return 1, "Command failed", None

    class MockFacts:
        def populate(self, collected_facts):
            self.facts = {}
            self.facts.update(collected_facts)

    fhw = FreeBSDHardware(MockModule('dmidecode'))
    fhw.populate()
    mock_facts = MockFacts()
    mock_facts

# Generated at 2022-06-20 17:24:24.285293
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    mod = AnsibleModule(argument_spec={}, supports_check_mode=True)
    fhw = FreeBSDHardware(module=mod)
    facts = fhw.get_dmi_facts()

# Generated at 2022-06-20 17:24:26.968126
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fhc = FreeBSDHardwareCollector()
    assert fhc.collect()['ansible_facts']['ansible_system_vendor'] == FreeBSDHardware().get_dmi_facts()['system_vendor']

# Generated at 2022-06-20 17:24:30.247420
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fh = FreeBSDHardwareCollector()
    assert isinstance(fh, HardwareCollector)
    assert fh._platform == "FreeBSD"



# Generated at 2022-06-20 17:24:36.731261
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.collector.freebsd import FreeBSDHardware
    hardware = FreeBSDHardware('module')
    device_facts = hardware.get_device_facts()
    assert 'devices' in device_facts
    assert isinstance(device_facts['devices'], dict)
    assert 'ada0' in device_facts['devices']


# Generated at 2022-06-20 17:24:39.221315
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, struct.pack('@L', 1585296862), ''))
    hardware_facts = FreeBSDHardware(module).populate()

    assert hardware_facts['uptime_seconds'] == 1585296862

# Generated at 2022-06-20 17:24:48.975567
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import platform
    platform_info = platform.uname()
    print("Platform is: %s" % platform_info[0])
    if platform_info[0] != 'FreeBSD':
        print("test_FreeBSDHardware_get_memory_facts only runs on FreeBSD")
    else:
        import sys
        sys.path.append("/tmp/ansible_freebsd_facts")
        from ansible.module_utils import facts

        hw_obj = FreeBSDHardware(facts.Module())
        hw_obj.populate()

        print("Memory facts: %s" % hw_obj.get_memory_facts())
        assert 'memtotal_mb' in hw_obj.get_memory_facts()
        assert 'memfree_mb' in hw_obj.get_memory_facts()

# Generated at 2022-06-20 17:24:53.582067
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    d = FreeBSDHardware()
    f = d.get_device_facts()
    assert f == {'devices': {}}


# Generated at 2022-06-20 17:25:04.952885
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    print('Testing FreeBSD get_cpu_facts function')
    hardware = FreeBSDHardware()
    cpu_facts = hardware.get_cpu_facts()
    assert (cpu_facts['processor'] == ['Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
                                       'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
                                       'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
                                       'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz',
                                       'Intel(R) Core(TM) i7-4980HQ CPU @ 2.80GHz'])
    assert (cpu_facts['processor_cores'] == '8')

# Generated at 2022-06-20 17:26:41.359021
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """Unit test for method get_uptime_facts of class FreeBSDHardware"""
    class Module(object):
        def __init__(self):
            self.run_command_calls = []
            self.get_bin_path_results = []

        def get_bin_path(self, _):
            return self.get_bin_path_results.pop(0)

        def run_command(self, cmd, encoding=None):
            self.run_command_calls.append((cmd, encoding))
            out = 'kern.boottime: { sec = 1535676036, usec = 634702 }\n'
            return 0, out, ''

    module = Module()

    # On FreeBSD, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    sysctl_cmd

# Generated at 2022-06-20 17:26:47.523679
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Create object to test
    my_obj = FreeBSDHardware(module=None)

    # Create test data
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')
    devices = {}
    dirlist = ['da0', 'da0s1', 'da0s2', 'da1', 'da1s1', 'da1s2', 'da1s3']

    # Test getting device facts from sys directory
    for device in dirlist:
        d = drives.match(device)
        if d:
            devices[d.group(1)] = []
        s = slices.match(device)
       

# Generated at 2022-06-20 17:26:54.872993
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    if not module.get_bin_path('sysctl') or not module.get_bin_path('swapinfo'):
        module.fail_json(msg='Missing required executable: sysctl/swapinfo')
    hardware = FreeBSDHardware(module)
    hardware.populate()

    # checking bios facts
    assert len(hardware.facts['bios_version']) > 0
    assert len(hardware.facts['bios_date']) > 0
    assert len(hardware.facts['bios_vendor']) > 0

    # checking processor facts
    assert len(hardware.facts['processor']) > 0
    assert hardware.facts['processor_cores'] > 0
    assert hardware.facts['processor_count'] > 0

    # checking memory facts

# Generated at 2022-06-20 17:27:05.314217
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    if not module.get_bin_path('sysctl'):
        module.fail_json(msg='The `sysctl` binary is missing')
    h = FreeBSDHardware(module=module)
    facts = h.populate()

    assert type(facts) is dict
    assert type(facts['devices']) is dict
    assert type(facts['processor']) is list
    assert type(facts['processor_cores']) is int
    assert type(facts['processor_count']) is int
    assert type(facts['memtotal_mb']) is int
    assert type(facts['memfree_mb']) is int
    assert type(facts['uptime_seconds']) is int
    assert type(facts['swaptotal_mb']) is int

# Generated at 2022-06-20 17:27:12.169627
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hw = FreeBSDHardware({})
    facts = hw.populate()
    assert facts['uptime_seconds'] > 0
    assert facts['devices'] != {}
    # Assert at least one mount point is listed.
    assert len(facts.get('mounts')) > 0
    assert facts['processor_cores'] > 0
    assert facts['processor_count'] > 0
    assert len(facts['processor']) > 0
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] > 0
    assert facts['swaptotal_mb'] > 0
    assert facts['swapfree_mb'] > 0

# Generated at 2022-06-20 17:27:14.734092
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    hardware_collector = FreeBSDHardwareCollector()
    assert isinstance(hardware_collector, FreeBSDHardwareCollector)
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware



# Generated at 2022-06-20 17:27:26.771452
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    sysctl = '/usr/sbin/sysctl'
    setattr(FreeBSDHardware, 'module', lambda self: None)
    assert FreeBSDHardware().get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}
    setattr(FreeBSDHardware, 'module', lambda self: lambda sec: mock_out_run_command(sec, sysctl))
    assert FreeBSDHardware().get_memory_facts() == {'memfree_mb': 0, 'memtotal_mb': 0, 'swapfree_mb': 0, 'swaptotal_mb': 0}
    mock_out_run_command(False, sysctl)

# Generated at 2022-06-20 17:27:37.012125
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible_collections.ansible.community.tests.unit.compat import mock
    from ansible_collections.ansible.community.tests.unit.compat.unittest import TestCase
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class TestModule(object):
        @staticmethod
        def get_bin_path(*_):
            return _[0]

        @staticmethod
        def run_command(*_):
            return 0, '', ''

    class TestCase(TestCase):
        def test_get_uptime_facts(self):
            engine = TestModule()
            FreeBSDHardware.module = engine
            _ = FreeBSDHardware.get_uptime_facts()

    test = TestCase()
    test.test_get_uptime_facts()

# Generated at 2022-06-20 17:27:39.111129
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector = FreeBSDHardwareCollector()
    assert hw_collector._fact_class == FreeBSDHardware
    assert hw_collector._platform == 'FreeBSD'