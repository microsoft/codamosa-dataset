

# Generated at 2022-06-20 17:18:00.822922
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Constructor for class FreeBSDHardwareCollector with only one parameter
    # inputs:
    #   module => it is the ansible module
    # output:
    #   it returns an object of class FreeBSDHardwareCollector
    m = None
    freebsd_collector = FreeBSDHardwareCollector(m)
    assert freebsd_collector is not None
    assert freebsd_collector.platform == 'FreeBSD'
    assert freebsd_collector.facts is None
    assert freebsd_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:18:01.795413
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # TODO: Test FreeBSDHardware populate method
    pass

# Generated at 2022-06-20 17:18:08.304023
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class TestModule(object):
        def __init__(self, out, rc=0):
            self.out = out
            self.rc = rc
        def run_command(self, command):
            return (self.rc, self.out, '')

    def get_file_content(filename):
        return ''

    module = TestModule('hw.ncpu: 8\n')
    _hardware = FreeBSDHardware(module)

    module.out = 'hits    miss pagesize  %time\n' + \
                 '5456     45   4096     15\n'
    _memfree_mb, _memtotal_mb = _hardware.get_memory_facts()['memtotal_mb'], _hardware.get_memory_facts()['memfree_mb']
    assert _memtotal_mb == '200'
   

# Generated at 2022-06-20 17:18:19.199048
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
    Test that get_device_facts() returns a valid dictionary
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import platform
    import sys

    freebsd_hardware = FreeBSDHardware()
    device_facts = freebsd_hardware.get_device_facts()

    # Test that get_device_facts() returns a dictionary
    assert isinstance(device_facts, dict)

    # Test that get_device_facts() contains the expected key
    assert 'devices' in device_facts.keys()

    # Test that get_device_facts() returns a dictionary
    assert isinstance(device_facts['devices'], dict)

    # Test that get_device_facts() returns a valid dictionary

# Generated at 2022-06-20 17:18:31.113813
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule
    module.get_bin_path = lambda x: '/sbin/sysctl'
    freebsd_hw = FreeBSDHardware
    freebsd_hw.module = module

    # Sysctl returns 3 cases:
    ## kern.boottime = 157244822, 1440813
    ## kern.boottime = 3150603328, 0
    ## kern.boottime = 3150603328
    ## has same result in this case.
    ## Also, we do not really care about the second field in the result.

    # 1st case
    kern_boottime = 157244822
    (rc, out, err) = module.run_command = lambda x, encoding=None: (0, 'kern.boottime = {:d}'.format(kern_boottime), None)


# Generated at 2022-06-20 17:18:39.448045
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = FakeAnsibleModule()
    hardware = FreeBSDHardware(module=module)

    # Set up some fake device files
    test_devices = ['sda1', 'sda2', 'sdb1', 'sdb2']
    sysdir = '/tmp/dev'
    os.mkdir(sysdir)
    for device in test_devices:
        open(os.path.join(sysdir, device), 'a').close()

    # Run the test
    hardware.get_device_facts()

    # Test the results for the device list
    expected_device_list = {'sda': ['sda1', 'sda2'], 'sdb': ['sdb1', 'sdb2']}
    assert expected_device_list == hardware.devices

    # Clean up the fake test files

# Generated at 2022-06-20 17:18:51.809625
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    import platform
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # Test with a dmesg.boot file that contains a CPU without multicore information
    os.environ['DMESG_BOOT'] = 'tests/unittests/dmescboot/no_multicore'
    facts = hardware.get_cpu_facts()
    assert 'processor_count' in facts
    assert facts['processor_count'] == '4'
    assert 'processor_cores' not in facts
    assert 'processor' in facts

# Generated at 2022-06-20 17:18:53.558784
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware('module')
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-20 17:19:02.993671
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # stub out module to record results
    module = type('FreeBSDModule')
    module.run_command_environ_update = {}
    module.run_command_examine_output = {}
    module.run_command_check_rc = {}
    module.get_bin_path = lambda x: '/usr/sbin/dmidecode'
    module.no_log_values = lambda x: x
    module.params = {}

    # create FreeBSDHardware instance
    fhw = FreeBSDHardware(module)

    # stub out run_command (function decorated by timeout) to avoid timeout
    fhw.module.run_command = lambda cmd, encoding: (0, DMIDECODE_OUTPUT, '')

    # run function under test
    dmi_facts = fhw.get_dmi_facts()

    # dmidecode output

# Generated at 2022-06-20 17:19:15.200331
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    class ModuleMock:
        def get_bin_path(self, arg):
            return '/usr/bin/sysctl'

        def run_command(self, *args, **kwargs):
            return (0, 'kern.boottime = { sec = 1548356658, usec = 211019 } Thu Jan 24 14:34:18 2019\n', None)

    class AnsibleModuleMock:
        def __init__(self):
            self.run_command = ModuleMock.run_command
            self.get_bin_path = ModuleMock.get_bin_path
            self.module_args = {}

    m = AnsibleModuleMock()
    freebsd_hw = FreeBSDHardware(m)

    uptime_facts = freebsd_hw.get_uptime_facts()
    assert uptime_facts

# Generated at 2022-06-20 17:19:35.234629
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    from ansible.module_utils import basic
    from ansible.module_utils._text import to_bytes
    from ansible.module_utils.facts import ansible_collector

    # define basic module
    module = basic.AnsibleModule(
        argument_spec=dict()
    )
    module.params = {}

    # init collector
    ansible_collector.collect(module)
    hardware_collector = FreeBSDHardwareCollector()

    # get facts
    facts_dict = hardware_collector.collect(module, collected_facts=module.params)
    hardware_facts = facts_dict.get('ansible_facts', {}).get('ansible_hardware', {})

    # assert facts
    assert hardware_facts.get('bios_date') == 'NA'

# Generated at 2022-06-20 17:19:43.805291
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class module:
        def get_bin_path(self, sysfs):
            return '/sbin/sysctl'
        def run_command(self, sysctl, check_rc=False, encoding=None):
            return 0, '', ''

    h = FreeBSDHardware(module)

    df = h.get_device_facts()
    assert df['devices']['ada0s2'][0] == 'ada0s2a'
    assert df['devices']['ada0s2'][1] == 'ada0s2b'
    assert df['devices']['ada0s2'][2] == 'ada0s2c'
    assert df['devices']['ada0s2'][3] == 'ada0s2d'

# Generated at 2022-06-20 17:19:50.619374
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class Module(object):
        @staticmethod
        def get_bin_path(cmd):
            return '/sbin/sysctl'

        @staticmethod
        def run_command(cmd, encoding=None):
            return (0, struct.pack('@L', 1548255044), '')

    hw = FreeBSDHardware(Module())

    assert hw.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1548255044)}


# Generated at 2022-06-20 17:19:57.028601
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    with mock.patch("ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware.get_mount_facts") as get_mount_facts_mock:
        freebsd_hw = FreeBSDHardware()
        # Set up swapinfo to return a given number for swaptotal and swapfree
        with mock.patch('ansible.module_utils.facts.hardware.freebsd.get_file_content') as get_file_content_mock, \
             mock.patch('ansible.module_utils.facts.hardware.freebsd.get_mount_size') as get_mount_size_mock, \
             mock.patch('ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware.module'):
            freebsd_hw.module.get_bin_path.return_value

# Generated at 2022-06-20 17:20:09.612991
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockModule()
    module.run_command = Mock(return_value=(0, '', ''))
    module.get_bin_path = Mock(return_value='/sbin/sysctl')
    hw = FreeBSDHardware(module=module)
    hw.get_cpu_facts = Mock(return_value=('processor_cores', 'processor', 'processor_count'))
    hw.get_memory_facts = Mock(return_value=dict(memtotal_mb=1024, memfree_mb=512, swaptotal_mb=1024, swapfree_mb=512))

# Generated at 2022-06-20 17:20:22.184867
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """ FreeBSDHardware - populate
    """

    # Define test inputs
    module_args = dict()

    # Instantiate ansible module
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    # Instantiate FreeBSDHardware class
    my_freebsd_hardware = FreeBSDHardware(module)

    # Obtain and test hardware facts
    hardware_facts = my_freebsd_hardware.populate()
    assert hardware_facts['ansible_facts']['devices']['ada1'] == ['ada1s1', 'ada1s2']
    assert hardware_facts['ansible_facts']['devices']['ada0'] == ['ada0s1', 'ada0s2']


# Generated at 2022-06-20 17:20:34.527963
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class Runner(object):
        def __init__(self, *args, **kwargs):
            self.rc = 0
            self.stdout = 'some stdout'
            self.stderr = ''

        def run_command(self, *args, **kwargs):
            return self.rc, self.stdout, self.stderr

    class Module(object):
        def __init__(self, *args, **kwargs):
            self.run_command = Runner().run_command

        def get_bin_path(self, *args, **kwargs):
            return '/sbin/sysctl'

    class FacterFacts(object):
        def __init__(self):
            self.facts = {}

    facts = FacterFacts()
    FreeBSDHardware(facts, Module()).populate()

    assert facts

# Generated at 2022-06-20 17:20:41.006271
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Test case 1
    module = MockAnsibleModule()
    module.run_command = MockRunCommand( (0, '', ''), (0, '', '') )
    freebsd_hw = FreeBSDHardware(module)

    if not os.path.isdir('/dev'):
        os.mkdir('/dev')
    open('/dev/da0', 'w')
    with open('/dev/da0', 'w') as f:
        f.write('test')
    open('/dev/da0s1a', 'w')
    with open('/dev/da0s1a', 'w') as f:
        f.write('test')
    open('/dev/da1', 'w')

# Generated at 2022-06-20 17:20:50.776682
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_util.facts import timestring_to_seconds

    # On FreeBSD, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    #
    # We need to get raw bytes, not UTF-8.
    #
    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    #
    # The result of this test is that, if the 'uptime_seconds' value
    # returned by the method, is equal to the value obtained by
    # subtracting the time the test started, from the present time.
    #
    # TODO: the test will fail when the uptime is a multiple of
    # 24 hours, which is not handled by the timestring_to_seconds
    # function

# Generated at 2022-06-20 17:21:02.280463
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Unit test for method get_dmi_facts of class FreeBSDHardware
    '''
    args = {}

    # create a class FreeBSDHardware mock object
    bsd_h = FreeBSDHardware(args)

    # set return values for the mock object
    # for the command in method get_dmi_facts of class FreeBSDHardware
    bsd_h.module.run_command.return_value = (0, '/bin/dmidecode', '')

    # invoke the get_dmi_facts
    dmi_facts = bsd_h.get_dmi_facts()

    # check if the return value is correctly set
    assert dmi_facts['product_name'] == 'NA'

# Generated at 2022-06-20 17:21:27.484655
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    hardware = FreeBSDHardware(module=module)

    # Populate memory facts
    memory_facts = {}
    hardware._populate_memory_facts(memory_facts)
    assert memory_facts['memtotal_mb']
    assert memory_facts['memfree_mb']
    assert memory_facts['swaptotal_mb']
    assert memory_facts['swapfree_mb']

    # Populate cpu facts
    cpu_facts = {}
    hardware._populate_cpu_facts(cpu_facts)
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']

    # Populate uptime facts
    uptime_facts = {}
    hardware._populate_uptime_facts(uptime_facts)
    assert uptime_

# Generated at 2022-06-20 17:21:36.415257
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module)
    ansible_facts = dict()

    rc, out, err = module.run_command("sysctl hw.ncpu")
    if rc == 0:
        ansible_facts['processor_count'] = out.split()[1]

    rc, dmesg_boot, err = module.run_command("dmesg")
    if rc == 0:
        for line in dmesg_boot.splitlines():
            if 'CPU:' in line:
                cpu = re.sub(r'CPU:\s+', r"", line)
                ansible_facts['processor'] = cpu.strip().splitlines()

# Generated at 2022-06-20 17:21:48.224895
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_facts = FreeBSDHardware(None, {}).populate()
    assert hardware_facts['processor'][0] == 'Intel(R) Core(TM) i7-3610QM CPU @ 2.30GHz'
    assert hardware_facts['processor_count'] == '4'
    assert hardware_facts['processor_cores'] == '4'
    assert hardware_facts['memtotal_mb'] > 2000
    assert hardware_facts['memfree_mb'] > 1000
    assert hardware_facts['swaptotal_mb'] > 1000
    assert hardware_facts['swapfree_mb'] > 800
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['devices']['ada0'][0] == 'ada0s1a'

# Generated at 2022-06-20 17:21:52.730414
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # FIXME: delete me, I'm only here for debug
    import sys
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    m = FreeBSDHardware()
    a = m.populate()

    print(json.dumps(a, sort_keys=True, indent=4))
    sys.exit(0)

# Generated at 2022-06-20 17:22:04.342876
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:22:08.490995
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    assert hardware.get_uptime_facts() == {'uptime_seconds': 6860}

# Generated at 2022-06-20 17:22:19.280349
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    assert FreeBSDHardware(None).get_uptime_facts() == {}

    # Return a fake output for sysctl, mocking the return code and the output.
    class MockModule(object):
        def __init__(self, rc, out):
            self.rc = rc
            self.out = out

        def get_bin_path(self, _):
            return 'sysctl'

        def run_command(self, cmd, encoding=None):
            if encoding is None:
                return (self.rc, self.out, None)
            else:
                return (self.rc, self.out.encode(encoding), None)

    # Provide a valid output.

# Generated at 2022-06-20 17:22:30.236315
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(argument_spec=dict())

# Generated at 2022-06-20 17:22:32.232279
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    h = FreeBSDHardware()
    assert 'processor_count' in h.get_cpu_facts()
    assert 'processor' in h.get_cpu_facts()

# Generated at 2022-06-20 17:22:38.586875
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    m = MockModule()

    # Test a successful call.
    m.run_command.return_value = (0, '\x00\x00\x00\x00\x00\x00\x00\x00', '')
    uptime_facts = FreeBSDHardware(m).get_uptime_facts()
    assert uptime_facts == {'uptime_seconds': 0}

    # Test a failed call.
    m.run_command.return_value = (0, '', '')
    uptime_facts = FreeBSDHardware(m).get_uptime_facts()
    assert uptime_facts == {}


# This class is used to replace the AnsibleModule class

# Generated at 2022-06-20 17:23:10.002582
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_mock = type('ModuleMock', (object, ), {
        'run_command': lambda self, cmd, encoding=None: (0, b'\x00\x00\x00\x00\x00\x00\x00\x00', None),
        'get_bin_path': lambda self, path: path,
    })()

    hardware_object = FreeBSDHardware(module_mock)
    uptime_facts = hardware_object.get_uptime_facts()

    assert uptime_facts['uptime_seconds'] == 0

# Generated at 2022-06-20 17:23:11.964478
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    result = FreeBSDHardwareCollector()
    assert result is not None

# Generated at 2022-06-20 17:23:21.359445
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class MockModule(object):
        def run_command(self, cmd, encoding=None):
            if cmd == ['/sbin/sysctl', '-b', 'kern.boottime']:
                return 0, struct.pack('@L', 1234567), ''
            return 1, 'mock error', ''

        def get_bin_path(self, name, required=False):
            if name == 'sysctl':
                return '/sbin/sysctl'
            if required:
                raise Exception('mock: missing binary for required module')

    m = MockModule()
    f = FreeBSDHardware(module=m)

    assert f.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1234567)}

# Generated at 2022-06-20 17:23:25.659192
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import subprocess

    # We need to mock run_command to return a fixed value
    def mock_run_command(*args, **kwargs):
        class MockRC:
            def __init__(self, err, out, rc):
                self.err = err
                self.out = out
                self.rc = rc

            def communicate(self):
                return (self.out, self.err)

            def poll(self):
                return self.rc

        # Set up a fixed time
        mock_boottime = 1450673842
        # Construct the value we want to return
        struct_format = '@L'
        mock_out = bytearray((mock_boottime).to_bytes(struct.calcsize(struct_format), byteorder='little'))
        return MockRC(None, mock_out, 0)

# Generated at 2022-06-20 17:23:34.398698
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # We create a false module object
    module = AnsibleModule(argument_spec=dict())
    module.run_command = MagicMock(return_value=(0, "dmidecode output", ""))
    # instantiate the class to test
    fhw = FreeBSDHardware(module)
    fhw.get_dmi_facts()
    # check if it calls dmidecode
    module.run_command.assert_called_with('dmidecode -s system-manufacturer')


# Generated at 2022-06-20 17:23:40.979102
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = MockModule()
    hardware = FreeBSDHardware(module)
    devices = hardware.get_device_facts()
    assert devices.keys() == ['devices']
    assert devices['devices']['/dev/ada0'] == ['/dev/ada0s1', '/dev/ada0s2']
    assert devices['devices']['/dev/ada0s1'] == []
    assert devices['devices']['/dev/ada0s2'] == []



# Generated at 2022-06-20 17:23:46.213381
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    freebsdHardware = FreeBSDHardware()

    # Empty string
    assert freebsdHardware._get_uptime_facts() == {}

    # Valid string
    assert freebsdHardware._get_uptime_facts("$h{%c}") == {'uptime_seconds': 0}

    # Invalid string
    assert freebsdHardware._get_uptime_facts("foobar") == {}


# Generated at 2022-06-20 17:23:58.508528
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class MyModule(object):
        def run_command(self, cmd, check_rc=False, encoding=None):
            class Result(object):
                pass
            result = Result()
            result.rc = 0

# Generated at 2022-06-20 17:24:00.303473
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware(dict())

    assert facts.get('devices') == {}, 'devices should be an empty dictionary'

# Generated at 2022-06-20 17:24:12.266288
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.get_bin_path = lambda name: name

# Generated at 2022-06-20 17:25:15.006979
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    result = hardware.get_cpu_facts()
    # result is a dict
    assert(isinstance(result, dict))
    assert('processor' in result)
    assert('processor_count' in result)

    result = hardware.get_memory_facts()
    assert(isinstance(result, dict))
    assert('memtotal_mb' in result)
    assert('memfree_mb' in result)
    assert('swaptotal_mb' in result)
    assert('swapfree_mb' in result)

    result = hardware.get_uptime_facts()
    assert(isinstance(result, dict))
    assert('uptime_seconds' in result)

    result = hardware.get_device_facts()

# Generated at 2022-06-20 17:25:23.883499
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts import hardware

    # The initial uptime is not stable, so we use a known test case.
    # The current value for kern.boottime is:
    #   1441088067.904680 sec  Sat Sep 26 15:20:06 2015
    uptime = 1441088067.904680

    # Now we can create a BSDHardware instance, and test the method.
    bsdhw = hardware.FreeBSDHardware()
    uptime_facts = bsdhw.get_uptime_facts()

    # Check the result.
    assert uptime_facts == {
        'uptime_seconds': int(uptime),
    }

# Generated at 2022-06-20 17:25:34.374105
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class TestFreeBSDHardware(FreeBSDHardware):
        def __init__(self, module):
            super(TestFreeBSDHardware, self).__init__(module)
            self.module = module

        def run_command(self, command, encoding=None):
            command_result = {}
            if "sysctl -n hw.ncpu" in command:
                command_result['rc'] = 0
                command_result['out'] = "2"
                command_result['err'] = ''
            elif "dmesg" in command:
                command_result['rc'] = 0

# Generated at 2022-06-20 17:25:37.269642
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = FreeBSDHardwareCollector({})
    assert isinstance(facts._fact_class, FreeBSDHardware)
    assert facts._platform == 'FreeBSD'

# Generated at 2022-06-20 17:25:47.512748
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import ansible.module_utils.facts.hardware.freebsd
    facts = ansible.module_utils.facts.hardware.freebsd.Hardware()
    ansible_facts = facts.populate()

    assert ansible_facts['processor']
    assert ansible_facts['processor_cores']
    assert ansible_facts['processor_count']
    assert ansible_facts['memtotal_mb']
    assert ansible_facts['memfree_mb']
    assert ansible_facts['swaptotal_mb']
    assert ansible_facts['swapfree_mb']
    assert ansible_facts['uptime_seconds']
    assert ansible_facts['devices']
    assert ansible_facts['board_serial']
    assert ansible_facts['system_vendor']

# Generated at 2022-06-20 17:25:49.450125
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts = {}
    collector = FreeBSDHardwareCollector(facts, None)
    assert collector.platform == "FreeBSD"

# Generated at 2022-06-20 17:25:56.937490
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={
        'gather_subset': dict(default=['!all'], type='list'),
        'gather_timeout': dict(default=10, type='int')
    })
    if not BSDHARDWARE_AVAILABLE:
        module.fail_json(msg='dmesg is required for FreeBSD facts')

    facts = FreeBSDHardware(module).populate()

# Generated at 2022-06-20 17:26:01.441975
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = ansible_fake_module()
    hardware = FreeBSDHardware(module)
    fact = hardware.get_cpu_facts()
    assert fact['processor']
    assert fact['processor_cores']
    assert fact['processor_count']


# Generated at 2022-06-20 17:26:03.771210
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hdl = FreeBSDHardwareCollector()
    assert hdl._fact_class == FreeBSDHardware
    assert hdl._platform == 'FreeBSD'

# Generated at 2022-06-20 17:26:10.476675
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''
    FreeBSDHardware_populate is a unit test
    to verify that the FreeBSDHardware.get_mount_facts() function works.
    '''
    fh = FreeBSDHardware()
    print(fh.populate())

if __name__ == '__main__':
    test_FreeBSDHardware_populate()