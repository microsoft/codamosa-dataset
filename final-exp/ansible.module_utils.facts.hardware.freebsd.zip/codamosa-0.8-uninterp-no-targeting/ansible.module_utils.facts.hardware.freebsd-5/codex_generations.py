

# Generated at 2022-06-20 17:17:56.484464
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = FakeModule()
    module.run_command = lambda x, check_rc=True: (0, '0\n', '')

    device_facts = FreeBSDHardware(module).get_device_facts()

    assert len(device_facts.keys()) == 1
    assert 'devices' in device_facts.keys()



# Generated at 2022-06-20 17:18:05.408535
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts import ModuleFacts
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Create a test object to get info from
    test_object = FreeBSDHardware({})
    test_object.module = ModuleFacts()

    # Test with no dmidecode executable
    dmi_facts = test_object.get_dmi_facts()
    assert dmi_facts == {}

    # Create a test object to get info from
    test_object = FreeBSDHardware({})
    test_object.module = ModuleFacts()
    dmidecode_bin = '/usr/sbin/dmidecode'
    assert test_object.module.get_bin_path('dmidecode', [dmidecode_bin])


# Generated at 2022-06-20 17:18:10.320715
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import unittest
    class _TestFreeBSDHardware(FreeBSDHardware):
        def __init__(self):
            self.module = unittest.mock.MagicMock()
            self.module.get_bin_path.return_value = 'sysctl'

    _TestFreeBSDHardware().get_uptime_facts()

# Generated at 2022-06-20 17:18:19.284399
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fhw = FreeBSDHardware()
    fhw.module = type('', (), {'get_bin_path': lambda x: '/usr/sbin/swapinfo'})
    fhw.module.run_command = lambda x, y=None: (0, '/dev/ada0p3        314368        0   314368     0%', '')
    assert fhw.get_memory_facts()['swaptotal_mb'] == 308

    fhw.module.run_command = lambda x, y=None: (0, '/dev/ada0p3        314368        0   314368     0%\n', '')
    assert fhw.get_memory_facts()['swaptotal_mb'] == 308

    fhw.module.run_command = lambda x, y=None: (0, '', '')

# Generated at 2022-06-20 17:18:31.125733
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # We need to mock the facter module
    import ansible.module_utils.facts.hardware.freebsd
    mocks = {
        'ansible.module_utils.facts.hardware.freebsd.FacterHardware':
            None,
        'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware.get_mount_facts':
            None,
    }

    import ansible.module_utils.facts.hardware.freebsd
    original_import = ansible.module_utils.facts.hardware.freebsd.__import__

    def mock_import(name, *args):
        if name in mocks:
            return mocks[name]
        else:
            return  original_import(name, *args)


# Generated at 2022-06-20 17:18:41.822924
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class TestModule:
        def run_command(self, command, check_rc=False):
            class TestOut:
                def splitlines(self):
                    return [
                        'vm.stats.vm.v_active_count: 3301',
                        'vm.stats.vm.v_cache_count: 3570',
                        'vm.stats.vm.v_free_count: 7474',
                        'vm.stats.vm.v_inactive_count: 3078',
                        'vm.stats.vm.v_page_count: 13452',
                        'vm.stats.vm.v_page_size: 4096'
                    ]

            return 0, TestOut(), ""

        def get_bin_path(self, command, required=False):
            return "/sbin/" + command


# Generated at 2022-06-20 17:18:49.476105
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    d = FreeBSDHardware(module)
    rc, out, err = module.run_command("/sbin/sysctl -n hw.ncpu", check_rc=False)
    processor_count = out
    rc, out, err = module.run_command("/sbin/sysctl vm.stats", check_rc=False)
    pagesize = ''
    pagecount = ''
    freecount = ''
    for line in out.splitlines():
        data = line.split()
        if 'vm.stats.vm.v_page_size' in line:
            pagesize = int(data[1])
        if 'vm.stats.vm.v_page_count' in line:
            pagecount = int

# Generated at 2022-06-20 17:18:50.816149
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware()
    assert facts.platform == 'FreeBSD'



# Generated at 2022-06-20 17:18:53.819152
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''
    Unit test cases for get_uptime_facts of class FreeBSDHardware
    '''
    test_obj = FreeBSDHardware()
    assert test_obj.get_uptime_facts() == {u'uptime_seconds': 0}

# Generated at 2022-06-20 17:18:57.762142
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict(), supports_check_mode=False)
    test_device_facts = FreeBSDHardware.get_device_facts(module)
    assert isinstance(test_device_facts, dict), "Failed to get the device facts"


# Generated at 2022-06-20 17:19:14.888454
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hw = FreeBSDHardware(module=module)
    facts = hw.populate()
    assert facts['memtotal_mb'] == facts['memfree_mb'] + facts['swaptotal_mb'] - facts['swapfree_mb']


# Generated at 2022-06-20 17:19:18.905276
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    test_parameters = { 'module': None,
                        'path': {'freebsd-facts': 'ansible.module_utils.facts.hardware.freebsd'}
                      }

    test_class = FreeBSDHardware(test_parameters)

    assert test_class.populate()['uptime_seconds'] >= 0

# Generated at 2022-06-20 17:19:31.596009
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = 'ansible.module_utils.facts.hardware.freebsd'
    m = __import__(test_module, globals(), locals(), ['AnsibleModule'])
    module = m.AnsibleModule(argument_spec={})
    hardware_collector = FreeBSDHardwareCollector(module=module)
    hardware = hardware_collector.collect()
    memfree_mb = hardware.get('memfree_mb')
    memtotal_mb = hardware.get('memtotal_mb')
    swaptotal_mb = hardware.get('swaptotal_mb')
    swapfree_mb = hardware.get('swapfree_mb')
    assert memfree_mb and memtotal_mb and swaptotal_mb and swapfree_mb


# Generated at 2022-06-20 17:19:40.446846
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import doctest
    import unittest
    suite = unittest.TestSuite()
    suite.addTest(doctest.DocTestSuite(FreeBSDHardware))
    test_results = unittest.TextTestRunner().run(suite)
    print('Failures:', test_results.failures)
    print('Errors:', test_results.errors)
    print('Skipped:', test_results.skipped)
    print('Attempts:', test_results.attempted)

# Generated at 2022-06-20 17:19:48.821673
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_module = AnsibleModule(argument_spec={})
    test_module.command_warnings = ''
    test_module.command_stderr = ''
    test_module.get_bin_path = lambda x: "/sbin/" + x
    test_module.run_command = lambda x, encoding: (0, '', '')
    test_obj = FreeBSDHardware(test_module)
    test_obj.populate()
    assert test_obj.get('uptime_seconds') is not None


test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-20 17:19:59.461219
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware_data = {'devices': {}, 'uptime_seconds': 9, 'processor': ['Intel(R) Core(TM) i3-2350M CPU @ 2.30GHz'], 'processor_cores': '2', 'processor_count': '4', 'memfree_mb': 7, 'memtotal_mb': 7, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'mounts': [{'mount': '/', 'fstype': 'zfs', 'total_kb': 17179869184, 'available_kb': 7725283328, 'used_kb': 4641457152, 'capacity': 27, 'device': 'zroot/ROOT/default'}]}
    assert FreeBSDHardware(None, hardware_data).data == hardware_data

# Generated at 2022-06-20 17:20:12.488300
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    def run_command_mock(module, cmd, check_rc=True, encoding=None):
        # Format of kern.boottime is:
        #
        #    { sec =  10, usec =  0 } Mon Oct 29 09:32:36 2018
        #
        # We are only interested in the first field, which is 10.
        return (0, b'10 0', None)

    module_mock = type('module_mock', (), {
        'run_command': staticmethod(run_command_mock)
    })
    f = FreeBSDHardware()
    f.module = module_mock

    # When kern.boottime is 10, uptime_seconds should be the time when
    # the test method is called subtracted by 10 seconds.

# Generated at 2022-06-20 17:20:21.132900
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mock_module = type('MockModule', (object,), {
        'run_command': lambda *args: [0, MEMORY_OUTPUT, ''],
    })()
    hardware = FreeBSDHardware(mock_module)
    assert hardware.get_memory_facts() == {
        'swapfree_mb': 825351,
        'swaptotal_mb': 1048576,
        'memfree_mb': 126633,
        'memtotal_mb': 1630417,
    }


# Generated at 2022-06-20 17:20:29.054191
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware({}, {}, {})
    collected_facts = hardware.populate()
    assert type(collected_facts['processor_count']) is int
    assert type(collected_facts['processor_cores']) is int
    assert type(collected_facts['memtotal_mb']) is int
    assert type(collected_facts['memfree_mb']) is int


# Generated at 2022-06-20 17:20:37.553019
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import sys
    if sys.version_info < (2, 7):
        import unittest2 as unittest
    else:
        import unittest
    import StringIO

    class TestModule(object):
        def __init__(self, module_name, module_args, tmp=None, encoding='utf-8'):
            self.module_name = module_name
            self.module_args = module_args
            self.tmp = tmp
            self.encoding = encoding

        def get_bin_path(self, executable, required=False):
            return '/usr/bin/freebsd-version'


# Generated at 2022-06-20 17:21:07.506717
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})

    def mock_run_command(cmd, check_rc=False, encoding='utf-8'):
        class MockPopen:
            def __init__(self):
                self.pid = 0
                self.returncode = 0

            def communicate(self):
                return struct.pack('@L', 1533270805), ''

        class MockPopen2:
            def __init__(self):
                self.pid = 0
                self.returncode = 1

            def communicate(self):
                return '', ''

        if cmd[0].endswith('sysctl') and cmd[1] == '-b' and cmd[2] == 'kern.boottime':
            if mock_run_command.rc == 0:
                return 0, MockPopen(), ''

            return 1

# Generated at 2022-06-20 17:21:21.248412
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})

    # Run 'sysctl hw.ncpu' command and read the output
    hardware_facts_sysctl_ncpu_content = b'''
hw.ncpu: 4
'''
    hardware_facts_sysctl_ncpu = AnsibleModule(argument_spec={})
    hardware_facts_sysctl_ncpu.run_command = Mock(return_value=(0, hardware_facts_sysctl_ncpu_content, ''))
    hardware_facts_sysctl_ncpu.get_bin_path = Mock(return_value='sysctl')

    # Run 'sysctl vm.stats' command and read the output

# Generated at 2022-06-20 17:21:32.404557
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import sys
    import subprocess

    class AnsibleModule:
        def __init__(self):
            pass

        def run_command(self, cmdargs, check_rc=True, encoding=None):
            proc = subprocess.Popen(cmdargs,
                                    stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE,
                                    stdin=subprocess.PIPE)
            proc.wait()
            rc = proc.returncode
            out, err = proc.communicate()
            return rc, out, err

        def get_bin_path(self, exe):
            return exe

    class Bunch(object):
        def __init__(self, **kwds):
            self.__dict__.update(kwds)

    module = AnsibleModule()
    sys

# Generated at 2022-06-20 17:21:33.681115
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    try:
        FreeBSDHardwareCollector()
    except:
        assert False


# Generated at 2022-06-20 17:21:41.164480
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec=dict())
    hardware = FreeBSDHardware(module=module)
    memory_facts = hardware.get_memory_facts()
    assert memory_facts['memtotal_mb'] > 0
    assert 'memfree_mb' in memory_facts
    assert 'swaptotal_mb' in memory_facts
    assert 'swapfree_mb' in memory_facts

# Generated at 2022-06-20 17:21:45.051686
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    x = FreeBSDHardwareCollector()
    assert isinstance(x,FreeBSDHardwareCollector)

if __name__ == '__main__':
    import doctest
    doctest.testmod()
    print ("TEST COMPLETE")

# Generated at 2022-06-20 17:21:48.875540
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    freebsd_hw = FreeBSDHardwareCollector(module=module).collect()['ansible_facts']['ansible_system_BOOT_ID']
    assert freebsd_hw.startswith("freebsd")



# Generated at 2022-06-20 17:22:01.109695
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    ''' Unit test for method get_dmi_facts of class FreeBSDHardware '''
    bsdhw = FreeBSDHardware(dict())
    bsdhw.module.get_bin_path = lambda x: '/usr/sbin/dmidecode'

# Generated at 2022-06-20 17:22:04.494884
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    dmi_facts = FreeBSDHardware.get_dmi_facts()
    assert 'product_name' in dmi_facts
    assert 'system_vendor' in dmi_facts

# Generated at 2022-06-20 17:22:16.133235
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    cpu_facts = {
        'processor': ['Genuine Intel(R) CPU 0000 @ 2.30GHz'],
        'processor_cores': '1',
        'processor_count': '2'
    }
    with open(FreeBSDHardware.DMESG_BOOT, 'w') as f:
        f.write('CPU:\tGenuine Intel(R) CPU 0000 @ 2.30GHz (2294.05-MHz K8-class CPU)\n'
                'Logical CPUs per core:  1\n'
                'Hyperthreading: Disabled\n')
    freebsd_hardware = FreeBSDHardware()
    assert freebsd_hardware.get_cpu_facts() == cpu_facts



# Generated at 2022-06-20 17:22:58.870987
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    h = FreeBSDHardware()
    dmi_facts = h.get_dmi_facts()
    assert 'system_vendor' in dmi_facts
    assert 'product_name' in dmi_facts

# Generated at 2022-06-20 17:23:09.901905
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # pylint: disable=too-many-locals
    def run_command(self, args, check_rc=True, close_fds=True, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='surrogate_or_strict', create_tmp_path_for_shell=False):
        if executable:
            assert executable == '/usr/bin/sysctl'
        assert args == ['/usr/bin/sysctl', '-b', 'kern.boottime']

        time_mock().time.return_value = 1590506697

# Generated at 2022-06-20 17:23:15.746134
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import types
    hardware_fact = FreeBSDHardware({})

    # Function is not mocked, use real data returned from command
    data = hardware_fact.get_memory_facts()
    assert isinstance(data, types.DictionaryType)

# Generated at 2022-06-20 17:23:19.733097
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    obj = FreeBSDHardware({}, {})
    result = obj.get_memory_facts()
    assert result['memtotal_mb'].isdigit()
    assert result['memfree_mb'].isdigit()
    assert result['swaptotal_mb'].isdigit()
    assert result['swapfree_mb'].isdigit()

# Generated at 2022-06-20 17:23:29.474533
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    '''freebsd_hardware_collector.py: Test FreeBSDHardwareCollector class'''
    import sys
    import os

    my_path = os.path.dirname(os.path.realpath(__file__))
    sys.path.append(my_path)

    # Test whether the FreeBSDHardwareCollector class can be initialized
    test_object = FreeBSDHardwareCollector()
    assert(test_object)

    # Test whether the FreeBSDHardwareCollector class has the required
    # properties
    assert(test_object.platform == 'FreeBSD')
    assert(test_object.fact_class == FreeBSDHardware)
    assert(test_object._platform == 'FreeBSD')
    assert(test_object._fact_class == FreeBSDHardware)

    sys.path.pop()

# Generated at 2022-06-20 17:23:41.385299
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.collector import FactCollector
    fc = FactCollector()
    facts = fc.collect(['hardware'], gather_subset=['all'])

    assert(FreeBSDHardware.platform == 'FreeBSD')
    assert('hardware' in facts)
    assert('uptime_seconds' in facts['hardware'])
    assert('processor_cores' in facts['hardware'])
    assert('processor_count' in facts['hardware'])
    assert('memfree_mb' in facts['hardware'])
    assert('swapfree_mb' in facts['hardware'])
    assert('memtotal_mb' in facts['hardware'])
    assert('swaptotal_mb' in facts['hardware'])
    assert('devices' in facts['hardware'])

# Generated at 2022-06-20 17:23:46.417297
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    '''Unit test for method populate of class FreeBSDHardware'''

    mock_module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False
    )

    # Constructor will set _platform to platform
    # We are assuming the platform is FreeBSD
    mock_FreeBSDHardware = FreeBSDHardware(mock_module)
    mock_FreeBSDHardware.populate()

# Generated at 2022-06-20 17:23:58.616164
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    import time
    import struct

    f = FreeBSDHardware()

    # Create an arbitrary timestamp in seconds.
    timestamp = int(time.time())
    # Create a binary string with the timestamp encoded in the format returned
    # by sysctl.
    raw_timestamp = struct.pack('L', timestamp)

    # Assert that the get_uptime_facts method returns the expected value.
    assert f.get_uptime_facts() == { 'uptime_seconds': int(time.time() - timestamp) }

    # Assert that the get_uptime_facts method returns an empty dict when the
    # raw output of sysctl is None.
    assert f.get_uptime_facts(raw_output=None) == {}

    # Assert that the

# Generated at 2022-06-20 17:24:04.025975
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Initialize the class to be tested
    freebsd_hw = FreeBSDHardware(dict(module=None))
    # Call the method to be tested
    freebsd_hw.populate()
    # Check if the result is correct
    assert freebsd_hw.plugin_rval != {}

    # Check if the method gets executed without errors
    import pytest
    out = pytest.helpers.capture_output(freebsd_hw.populate)
    assert out == ''

# Generated at 2022-06-20 17:24:15.935207
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    class ModuleMock(object):
        @staticmethod
        def get_bin_path(name):
            return name

    page_size = 4096
    page_count = 1048576
    free_count = 655360

    class RunCommandMock(object):
        def __init__(self, module_mock):
            self.module = module_mock

        def __call__(self, cmd, **kwargs):
            if cmd != 'sysctl -n hw.ncpu':
                return 0, '', ''
            else:
                return 0, '4\n', ''

        def __enter__(self):
            return self

        def __exit__(self, exc_type, exc_val, exc_tb):
            pass


# Generated at 2022-06-20 17:25:48.127965
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """Test the internal implementation of the get_dmi_facts method of class FreeBSDHardware."""
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Candidate facts

# Generated at 2022-06-20 17:25:54.519231
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    dmi_facts = FreeBSDHardware().get_dmi_facts()
    assert 'bios_vendor' in dmi_facts
    assert 'chassis_vendor' in dmi_facts
    assert 'product_name' in dmi_facts
    assert 'system_vendor' in dmi_facts
    assert 'form_factor' in dmi_facts
    assert 'system_vendor' in dmi_facts

# Generated at 2022-06-20 17:26:06.286326
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = FreeBSDHardware()

    # dmidecode not available on Travis-CI, this test will not pass
    if not m.module.get_bin_path('dmidecode'):
        return

    # populate dmi facts
    dmi_facts = m.get_dmi_facts()
    # test if dmi_facts is not empty
    assert dmi_facts

    # Only to simplify the test, we have selected the dmidecode information
    # that we want to validate.

# Generated at 2022-06-20 17:26:08.071453
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware(dict(), {})
    assert fhw.platform == 'FreeBSD'


# Generated at 2022-06-20 17:26:19.336727
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(
        argument_spec={},
    )
    test_module.get_bin_path = lambda x: x
    class MockModule:
        def __init__(self, test_module):
            self.run_command = test_module.run_command

    test_hardware = FreeBSDHardware(MockModule(test_module), test_module, test_module.run_command)

    test_module.run_command.return_value = (0, '1', 'stderr')
    assert test_hardware.get_cpu_facts()['processor_count'] == '1'
    test_module.run_command.assert_called_once_with('sysctl -n hw.ncpu', check_rc=False)

    test_module.run_command.reset_mock()
    test

# Generated at 2022-06-20 17:26:28.214767
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import time
    class MockFreeBSDHardware(FreeBSDHardware):
        def __init__(self, time1):
            self.time1 = time1
        def _get_current_time(self):
            return self.time1

    module_args = {'time1': time.time()}
    fhw = MockFreeBSDHardware(module_args['time1'])
    uptime_facts = fhw.get_uptime_facts()
    assert uptime_facts

# Generated at 2022-06-20 17:26:32.622008
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    h = FreeBSDHardware(dict())
    result = h.populate()
    assert 'devices' in result
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'uptime_seconds' in result

# Generated at 2022-06-20 17:26:35.064912
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    testhardware = FreeBSDHardware({})
    assert testhardware.platform == 'FreeBSD'


# Generated at 2022-06-20 17:26:38.053711
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({})
    h = hardware.get_all()
    assert h['processor_count'] == h['processor_cores']

# Generated at 2022-06-20 17:26:42.969537
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Patching class Hardware so that the method _load_from_dmidecode is not called and returns None
    from ansible.module_utils.facts.hardware.base import Hardware as BaseHardware

    def mock_dmidecode():
        return None
    BaseHardware._load_from_dmidecode = mock_dmidecode
    hardware = FreeBSDHardware()
    hardware.module = None
    hardware.populate()