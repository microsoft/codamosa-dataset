

# Generated at 2022-06-20 17:18:04.378690
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Before running unit test, get the following files
    #   /usr/share/dmidecode/bios.dmi
    #   /usr/share/dmidecode/chassis.dmi
    #   /usr/share/dmidecode/dmi_decode.h
    #   /usr/share/dmidecode/system.dmi
    #   /usr/share/dmidecode/baseboard.dmi
    # from FreeBSD system and put them into the testing directory
    #   test/unit/module_utils/facts/hardware/freebsd/
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware, test_FreeBSDHardware_dmi_files

# Generated at 2022-06-20 17:18:09.658880
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw = FreeBSDHardware(module)
    assert {'processor_count': '2',
            'processor': ['AMD Athlon(tm) 64 X2 Dual Core Processor 4200+',
                          'AMD Athlon(tm) 64 X2 Dual Core Processor 4200+']} == hw.get_cpu_facts()


# Generated at 2022-06-20 17:18:17.539985
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = MockModule()
    hardware_facts_instance = FreeBSDHardware(module)
    hardware_facts = hardware_facts_instance.populate()

    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['swaptotal_mb'] >= 0
    assert hardware_facts['swapfree_mb'] >= 0
    assert hardware_facts['processor_cores'] > 0
    assert hardware_facts['processor_count'] > 0
    assert type(hardware_facts['processor']) is list
    assert len(hardware_facts['devices']) > 0

# Generated at 2022-06-20 17:18:28.844694
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """test the FreeBSDHardware class"""

    # Setup
    module = AnsibleModule(argument_spec={})
    module.params = {}

    # Mocking classes
    class Mock_time(object):
        """Mock class for time"""
        pass

    class Mock_InterruptedError(object):
        """Mock class for InterruptedError"""
        pass

    class Mock_TimeoutError(object):
        """Mock class for TimeoutError"""
        pass

    # Mock modules
    sys = Mock(os)
    sys.version_info = (2, 7, 6)
    sys.modules = Mock()
    sys.modules.time = Mock_time
    sys.modules.time.time = Mock(return_value=1459217136)
    sys.modules.time.sleep = Mock()
    sys.modules.socket = Mock()


# Generated at 2022-06-20 17:18:37.417615
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    drive = drives = slices = { 'a.txt': FileMock(devices = ['ada0', 'ada0s2', 'ada1', 'ada1s1']) }
    disks = DisksMock(drive)
    sbin = SbinMock()
    sysfs = SysfsMock()
    os = OsMock(disks)
    hardware = FreeBSDHardware()
    hardware.module = AnsibleModuleMock(os, sysfs, sbin, drives)
    fb = hardware.get_device_facts()
    assert fb['devices'] == { 'ada0': ['ada0s2'], 'ada1': ['ada1s1'] }


###############################################################################
# Mocks

# Generated at 2022-06-20 17:18:50.042640
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    hardware = FreeBSDHardware()

    hardware.module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_size: 4096', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_count: 1310271', ''))
    hardware.module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_free_count: 827042', ''))

    hardware.module.get_bin_path = MagicMock(return_value='/bin/swapinfo')

# Generated at 2022-06-20 17:18:54.075823
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """This function is to test constructor of class FreeBSDHardwareCollector"""
    if FreeBSDHardwareCollector._platform == 'FreeBSD':
        hardware_collector = FreeBSDHardwareCollector()
        assert hardware_collector is not None
        assert hardware_collector._fact_class is not None
        assert hardware_collector._fact_class.platform == 'FreeBSD'

# Generated at 2022-06-20 17:19:03.264395
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = FakeAnsibleModule()
    bsd_hw = FreeBSDHardware(module)

    # Test for case when dmidecode does not exist
    bsd_hw.get_bin_path = lambda x: None

# Generated at 2022-06-20 17:19:09.280667
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class Module(object):
        pass

    module = Module()
    module.run_command = lambda cmd: (0, "hw.ncpu: 2", "hw.ncpu: 2")
    facts = FreeBSDHardware(module).get_cpu_facts()
    assert facts['processor_count'] == 2


# Generated at 2022-06-20 17:19:13.151376
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    module.exit_json(changed=False, ansible_facts=dict(devices=hardware.get_device_facts()['devices']))



# Generated at 2022-06-20 17:19:35.061958
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Remove the following line to test the method
    return


# Generated at 2022-06-20 17:19:41.426528
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    Test for method get_dmi_facts of class FreeBSDHardware
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    try:
        import json
    except ImportError:
        import simplejson as json

    module = AnsibleModule(argument_spec={})

    freebsd_hardware = FreeBSDHardware(module)
    dmi_facts = freebsd_hardware.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert isinstance(json.dumps(dmi_facts), str)
    assert freebsd_hardware.platform == 'FreeBSD'

# Generated at 2022-06-20 17:19:44.014836
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    facts = FreeBSDHardware({})
    device_facts = facts.get_device_facts()
    assert device_facts == {}



# Generated at 2022-06-20 17:19:53.493823
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from units.compat.mock import patch, MagicMock
    from ansible.module_utils.facts import hardware
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class MockModule(object):
        def __init__(self):
            self.params = {}

        def fail_json(self, *args, **kwargs): pass
        def get_bin_path(self, *args, **kwargs): return '/usr/sbin/dmidecode'

# Generated at 2022-06-20 17:20:04.825658
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True)
    hardware = FreeBSDHardware(module=module)
    facts = hardware.populate()

    # Check if processor_cores contains int
    assert isinstance(facts['processor_cores'], int)

    # Check if processor_count contains int
    assert isinstance(facts['processor_count'], int)

    # Check if devices is a dictionary
    assert isinstance(facts['devices'], dict)

    # Check if memfree_mb contains int
    assert isinstance(facts['memfree_mb'], int)

    # Check if memtotal_mb contains int
    assert isinstance(facts['memtotal_mb'], int)

    # Check if swapfree_mb contains int

# Generated at 2022-06-20 17:20:07.904936
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    hardware_collector = FreeBSDHardwareCollector()

    assert hardware_collector._platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware

# Generated at 2022-06-20 17:20:19.739766
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    module.run_command = MagicMock()
    module.run_command.return_value = (0, 'hw.ncpu: 4\n', '')
    fact_class = FreeBSDHardware(module)

    cpu_facts = fact_class.get_cpu_facts()

    module.run_command.assert_called_with('/sbin/sysctl -n hw.ncpu', check_rc=False)

    assert cpu_facts['processor'] == []
    assert cpu_facts['processor_cores'] is None
    assert cpu_facts['processor_count'] == '4'



# Generated at 2022-06-20 17:20:27.301615
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    class FreebsdHardwareMock:
        def __init__(self, module):
            self.module = module
            self.module.run_command = lambda cmd: (0, '', '')

    class ModuleMock:
        def __init__(self):
            self.params = {'gather_subset': ['all']}

        def get_bin_path(self, executable):
            return executable

    hw = FreeBSDHardware(FreeBSDHardwareCollector, ModuleMock())
    hw_devices = hw.get_device_facts()

    # Check that device's structure is a dictionnary
    assert isinstance(hw_devices, dict)
    assert 'devices' in hw_devices
    assert isinstance(hw_devices['devices'], dict)
    assert len(hw_devices['devices']) != 0
   

# Generated at 2022-06-20 17:20:36.600758
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    m = DummyModule()
    f = FreeBSDHardware(m)
    f.module.run_command = mock_run_command
    try:
        from StringIO import StringIO
    except ImportError:
        from io import StringIO
    m.run_command.stdout = StringIO(b'')
    f.get_dmi_facts()
    m.run_command.stdout.seek(0)
    assert m.run_command.stdout.read() == b''

    m.run_command.stdout = StringIO(b'product_name\n')
    f.get_dmi_facts()
    m.run_command.stdout.seek(0)
    assert m.run_command.stdout.read() == b'product_name\n'



# Generated at 2022-06-20 17:20:46.526079
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_file_contents = '''
#Device           1M-blocks     Used    Avail Capacity
#/dev/ada0p3         22178     7641    14284    34%
/dev/da0p3        314368        0   314368     0%
/dev/da1p3       2340792   782796  1517072    34%
foo
'''

    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    test_device_facts = {'devices': {'da0': ['da0p3'], 'da1': ['da1p3']}}
    test_object = FreeBSDHardware()

# Generated at 2022-06-20 17:20:58.633214
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """Test its constructor."""
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:21:09.440801
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    '''Unit testing for method FreeBSDHardware.get_device_facts'''

    # Initialize a mock FreeBSDHardware instance and a variables dict
    fhw = FreeBSDHardware()
    fhw.module = AnsibleModuleStub()
    facts = {}

    # Mock variables for this test

# Generated at 2022-06-20 17:21:22.992938
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module_mock = MockModule()
    module_mock.run_command = MagicMock(return_value=(0, dmidecode_output, ''))
    hardware = FreeBSDHardware(module_mock)
    dmi_facts = hardware.get_dmi_facts()
    assert(isinstance(dmi_facts, dict))
    assert('system_vendor' in dmi_facts)
    assert(dmi_facts['system_vendor'] == 'LENOVO')
    assert('product_name' in dmi_facts)
    assert(dmi_facts['product_name'] == '4286CTO')
    assert('product_serial' in dmi_facts)
    assert(dmi_facts['product_serial'] == 'R9H2G9X')

# Generated at 2022-06-20 17:21:27.584284
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = FreeBSDHardware().get_cpu_facts()

    assert 'processor' in facts
    assert type(facts['processor']) is list
    assert 'processor_cores' in facts
    assert 'processor_count' in facts



# Generated at 2022-06-20 17:21:30.164162
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert isinstance(hardware_collector,HardwareCollector)
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:21:40.897744
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    filename = 'get_device_facts'
    test_data = {
        'devices': {
            'ada0': ['ada0s1', 'ada0s2'],
            'ada1': ['ada1s1'],
            'ada2': ['ada2s1'],
            'ada3': ['ada3s1'],
            'ada4': ['ada4s1'],
            'ada5': ['ada5s1', 'ada5s2'],
            'ada6': ['ada6s1', 'ada6s2'],
            'ada7': ['ada7s1', 'ada7s2']
        }
    }

    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    hw = FreeBSDHardware(module)

# Generated at 2022-06-20 17:21:44.781801
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = None
    hardware_collector = FreeBSDHardwareCollector(module)

    # test return value of '_get_fact_class' method
    result = hardware_collector._get_fact_class()
    assert result == FreeBSDHardware


# Generated at 2022-06-20 17:21:53.281594
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Dummy module, args and facts
    module = None
    args = {}
    facts = {}

    # Create a FreeBSDHardware instance
    num_cpus = 0
    num_cores = 0
    num_threads = 0

    collector = FreeBSDHardwareCollector(module=module, args=args)
    hardware = collector.collect(module=module, args=args, facts=facts)

    # Assertions
    assert hardware['uptime_seconds'] == 3600
    assert hardware['bios_date'] == '2013-11-19'
    assert hardware['bios_vendor'] == 'American Megatrends Inc.'
    assert hardware['bios_version'] == 'P1.60'
    assert hardware['board_asset_tag'] == 'None'

# Generated at 2022-06-20 17:21:58.076886
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fb = FreeBSDHardware({})
    dmi_facts = fb.get_dmi_facts()
    assert dmi_facts['board_vendor'].count('NA') == 6
    assert dmi_facts['system_vendor'].count('NA') == 6

# Generated at 2022-06-20 17:22:00.737961
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware(dict())
    assert hardware.get_mount_facts.minutes == 1

# Generated at 2022-06-20 17:22:24.019889
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert FreeBSDHardware.get_memory_facts({})



# Generated at 2022-06-20 17:22:29.000303
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_object = FreeBSDHardware()
    results = test_object.get_cpu_facts()
    assert results['processor'][0] == 'Intel(R) Core(TM) i7-4770HQ CPU @ 2.20GHz'
    assert results['processor_count'] == '4'
    assert results['processor_cores'] == '4'


# Generated at 2022-06-20 17:22:37.404649
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    class freebsd_uptime_facts:
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def run_command(self, cmd, check_rc=True, encoding='utf-8', errors='surrogate_then_replace'):
            return (self.rc, self.out, self.err)

    uptime_out = b'kern.boottime: { sec = 1523186105, usec = 340160 } Fri Apr  6 00:21:45 2018'
    module = freebsd_uptime_facts(0, uptime_out, '')

    test_facts = {}
    uptime_facts = FreeBSDHardware(module)
    test_facts.update(uptime_facts.get_uptime_facts())

# Generated at 2022-06-20 17:22:50.767182
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:22:52.201691
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware(dict())
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-20 17:22:54.101142
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector = FreeBSDHardwareCollector()
    assert collector.platform == 'FreeBSD'
    assert collector._fact_class == FreeBSDHardware



# Generated at 2022-06-20 17:23:06.956818
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    class FauxModule(object):
        def __init__(self, rc, out, err):
            self.rc = rc
            self.out = out
            self.err = err

        def get_bin_path(self, path):
            return '/bin/' + path

        def run_command(self, params, encoding=None):
            return self.rc, self.out, self.err

    dmi_facts = {}
    module = FauxModule(0, 'key: value\n\n# comment', '')
    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    assert dmi_facts['product_name'] == 'value'

    module = FauxModule(1, '', '')
    dmi_facts = FreeBSDHardware(module).get_dmi_facts()
    assert not d

# Generated at 2022-06-20 17:23:09.116393
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    module = AnsibleModule(argument_spec={})
    amd_facts = FreeBSDHardware(module)
    assert amd_facts.platform == 'FreeBSD'

# Generated at 2022-06-20 17:23:20.323914
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Since dmidecode is not present on my FreeBSD system,
    # this test will be not very complete.

    from ansible.module_utils.facts.collector import get_collector_namespace
    from ansible.module_utils.facts.collector.hardware.freebsd import FreeBSDHardware

    # get namespace of class FreeBSDHardware
    namespace = get_collector_namespace(FreeBSDHardware)

    # set class FreeBSDHardware to have dmidecode binary in PATH
    # get_bin_path method will return binary name 'dmidecode'
    namespace['module'].get_bin_path = lambda *args: namespace['module']._success_return(namespace['dmidecode_bin'])

    # dmidecode binary is not present but dmidecode command should still run
    # so that we can test that dm

# Generated at 2022-06-20 17:23:28.128674
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = FakeAnsibleModule()
    hw = FreeBSDHardware(module)
    rc, out, err = module.run_command('echo "CPU: x86-64"', check_rc=False)
    rc, out, err = module.run_command('echo "Logical CPUs per core: 8"', check_rc=False)

    results = hw.get_cpu_facts()
    assert results['processor_cores'] == 8
    assert results['processor_count'] == '1'
    assert results['processor'][0] == 'x86-64'


# Generated at 2022-06-20 17:24:25.887702
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:24:31.271825
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    memory_facts = hardware.get_memory_facts()
    assert 'memtotal_mb' in memory_facts
    assert 'memfree_mb' in memory_facts


# Generated at 2022-06-20 17:24:39.670974
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # There is no package named "uptime" on FreeBSD, so we will mock the call
    # to uptime.
    original_uptime = os.stat(os.path.realpath(__file__)).st_mtime
    uptime_mock = os.path.join(os.path.dirname(os.path.realpath(__file__)), 'uptime.py')

    hardware = FreeBSDHardware(module=None)
    hardware.module.get_bin_path = lambda x: uptime_mock

    assert hardware.get_uptime_facts()['uptime_seconds'] == original_uptime



# Generated at 2022-06-20 17:24:48.027818
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})
    hw_fbsd = FreeBSDHardware(module)
    assert hw_fbsd.get_cpu_facts().get('processor_count') == '2'
    assert hw_fbsd.get_cpu_facts().get('processor_cores') == '1'
    assert hw_fbsd.get_cpu_facts().get('processor') == ['Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz',
                                                        'Intel(R) Core(TM) i5-4200U CPU @ 1.60GHz']


# Generated at 2022-06-20 17:24:53.931011
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    h = FreeBSDHardware()
    cpu_facts = h.get_cpu_facts()
    assert cpu_facts['processor'] == ['Intel(R) Core(TM) i7 CPU       L 640  @ 2.13GHz']
    assert cpu_facts['processor_count'] == '2'
    assert cpu_facts['processor_cores'] == '1'

# Generated at 2022-06-20 17:24:57.974053
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = FakeModule()
    hardware = FreeBSDHardware(module)

    expected_facts = {
        'memtotal_mb': 1048576,
        'memfree_mb': 1023488,
        'swaptotal_mb': 1999992,
        'swapfree_mb': 1999992
    }

    facts = hardware.get_memory_facts()

    for fact in expected_facts.keys():
        assert fact in facts
        assert facts[fact] == expected_facts[fact]



# Generated at 2022-06-20 17:25:04.371991
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a FreeBSDHardware object.
    hw = FreeBSDHardware(dict(), dict())
    # Check if the 'uptime_seconds' fact is in the output of the
    # 'get_uptime_facts()' method.
    uptime_facts = hw.get_uptime_facts()
    assert 'uptime_seconds' in uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)

# Generated at 2022-06-20 17:25:13.086909
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    m = FreeBSDHardware({})
    rc, out, err = m.module.run_command("/sbin/sysctl hw.ncpu")
    ncpu = out.split(' ')[1]
    rc, out, err = m.module.run_command("/sbin/sysctl hw.model")
    model = out.split(' ')[1]
    rc, out, err = m.module.run_command("/sbin/sysctl kern.logicalpercore")
    logicalpercore = out.split(' ')[1]
    cpu_facts = m.get_cpu_facts()
    assert cpu_facts['processor_count'] == ncpu
    assert cpu_facts['processor_cores'] == logicalpercore
    assert cpu_facts['processor'] == [model] * int(ncpu)

# Unit test

# Generated at 2022-06-20 17:25:14.238984
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # assert that instatiation worked
    assert FreeBSDHardware()


# Generated at 2022-06-20 17:25:23.071621
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Create a FreeBSDHardware object
    facts = FreeBSDHardware()

    # Create a dict object to store dmi data
    dmi_dict = {}

    # Create a dict object of known dmi facts for test