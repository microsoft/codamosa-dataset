

# Generated at 2022-06-20 17:18:02.431515
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    FreeBSDHardware.get_uptime_facts() Test for cases:
     - sysctl -b kern.boottime returns the correct format
     - sysctl -b kern.boottime returns an unexpected format
     - sysctl -b kern.boottime returns an empty string
     - sysctl -b kern.boottime returns error
    """
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    # Case 1: sysctl -b kern.boottime returns the correct format
    # input = '2050573694 95917 \n'
    # expected_result = {'uptime_seconds': 2050573694}
    # uptime_seconds = FreeBSDHardware.get_uptime_facts(input)
    # assert uptime_seconds == expected_result

    # Case 2: sysctl

# Generated at 2022-06-20 17:18:09.418950
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec={})
    freebsd_hardware = FreeBSDHardware(module=module)
    facts = freebsd_hardware.get_device_facts()
    assert facts.keys() == ['devices']
    assert isinstance(facts['devices'], dict)
    assert 'Ada0p3' in facts['devices']
    assert '/dev/ada0s1a' in facts['devices']


# Generated at 2022-06-20 17:18:14.029488
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)
    module.exit_json(ansible_facts=dict(hardware=hardware.populate()))



# Generated at 2022-06-20 17:18:20.347116
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    """
    Creates FreeBSDHardware class object with fake parameters
    and call get_cpu_facts method of class
    """
    hardware_mock = FreeBSDHardware()
    facts = hardware_mock.populate()

    assert facts['uptime_seconds'] == 2326
    assert facts['memtotal_mb'] == 201



# Generated at 2022-06-20 17:18:31.742106
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # construct a temporary class with all the necessary arguments
    class FakeModule(object):

        def __init__(self):
            self.params = {'filter': '*'}
            self.args = {}
            self.run_command = lambda x, **kwargs: (0, "v_page_size: 0x1000\nv_page_count: 0x400000\nv_free_count: 0x100000", "")
            self.get_bin_path = lambda x: "/sbin/sysctl"

    module = FakeModule()
    fhw = FreeBSDHardware(module)
    # test get_memory_facts()
    memory_facts = fhw.get_memory_facts()
    # check if we read the values correctly
    assert memory_facts['memtotal_mb'] == 4096

# Generated at 2022-06-20 17:18:33.480826
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    new_fhw = FreeBSDHardwareCollector()
    assert type(new_fhw) == FreeBSDHardwareCollector

# Generated at 2022-06-20 17:18:35.487603
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    facts_dict = dict()
    fhw = FreeBSDHardwareCollector(facts_dict, None)
    assert fhw


# Generated at 2022-06-20 17:18:48.159819
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    This is a unit test for the module_utils.facts.hardware.freebsd
    constructor.  The test checks that the correct instance attributes
    are defined.
    '''

    # Arrange
    fbsdhw_obj = None

    # Act
    fbsdhw_obj = FreeBSDHardware()

    # Assert
    assert fbsdhw_obj
    assert fbsdhw_obj.system_vendor == 'NA'
    assert fbsdhw_obj.product_name == 'NA'
    assert fbsdhw_obj.product_version == 'NA'
    assert fbsdhw_obj.product_serial == 'NA'
    assert fbsdhw_obj.product_uuid == 'NA'
    assert fbsdhw_obj.bios_version == 'NA'

# Generated at 2022-06-20 17:18:55.000165
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = FakeAnsibleModule('FreeBSD')
    module.run_command = FakeRunCommand(content={'/sbin/sysctl kern.disks': 'hw.disknames: cd0 ada0'})
    freebsd_device_facts = FreeBSDHardware(module).get_device_facts()
    assert freebsd_device_facts == {'devices': {'ada0': ['ada0s1', 'ada0s2', 'ada0s3', 'ada0s4', 'ada0s5', 'ada0s6', 'ada0s7', 'ada0s8']}}



# Generated at 2022-06-20 17:19:05.677923
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    hardware = FreeBSDHardware(module)

    # On FreeBSD, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    sysctl_cmd = hardware.module.get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']

    # We need to get raw bytes, not UTF-8.
    rc, out, err = hardware.module.run_command(cmd, encoding=None)

    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)

# Generated at 2022-06-20 17:19:18.856417
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    from ansible.module_utils.facts.collector import FactCollector
    hardware_collector = FreeBSDHardwareCollector()
    assert isinstance(hardware_collector, FactCollector)
    assert hardware_collector._platform == 'FreeBSD'
    assert hardware_collector._fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:19:31.275774
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    hardware = FreeBSDHardware({})

    # get the current time
    current_time = int(time.time())

    # get the uptime seconds. The up time could be more than a second and
    # might change by the time we test, so just assert that it is a positive
    # integer.
    uptime_seconds = hardware.get_uptime_facts()['uptime_seconds']
    assert uptime_seconds > 0

    # get the boot time by subtracting the uptime seconds from the current time and
    # assert that it is a positive integer
    boot_time = current_time - uptime_seconds
    assert boot_time > 0


# Generated at 2022-06-20 17:19:39.469551
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils import basic
    from ansible_collections.ansible.community.tests.unit.compat.mock import create_autospec
    module = basic.AnsibleModule(
        argument_spec={},
        supports_check_mode=False
    )

    pc = create_autospec(FreeBSDHardware)
    results = pc.populate()
    assert results['processor_count'] == 'FreeBSD'

# Generated at 2022-06-20 17:19:41.899459
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw_collector = FreeBSDHardwareCollector()
    assert hw_collector.platform == 'FreeBSD'

# Generated at 2022-06-20 17:19:52.219178
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = FakeModule()
    freebsd_hw = FreeBSDHardware(module)
    freebsd_hw.populate()

    assert 'cpu_count' in freebsd_hw.facts
    assert 'processor' in freebsd_hw.facts
    assert 'processor_cores' in freebsd_hw.facts
    assert 'processor_count' in freebsd_hw.facts
    assert 'memfree_mb' in freebsd_hw.facts
    assert 'memtotal_mb' in freebsd_hw.facts
    assert 'swapfree_mb' in freebsd_hw.facts
    assert 'swaptotal_mb' in freebsd_hw.facts
    assert 'uptime_seconds' in freebsd_hw.facts
    assert 'devices' in freebsd_hw.facts

# Generated at 2022-06-20 17:19:57.671007
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.collector.freebsd.hardware import FreeBSDHardware
    h = FreeBSDHardware()
    expected_facts = {'uptime_seconds': int(time.time() - 1234)}
    h.struct_unpack_side_effect = [1234]
    h.sysctl_cmd_side_effect = [0, '1234', '']
    assert expected_facts == h.get_uptime_facts()


# Generated at 2022-06-20 17:20:02.803787
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_module = AnsibleModule(argument_spec={}, supports_check_mode=False)
    test_module.exit_json(changed=False, ansible_facts=dict(FreeBSDHardware(test_module).populate()))

# Unit test module

# Generated at 2022-06-20 17:20:09.830785
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils import basic
    fhw = FreeBSDHardware(basic.AnsibleModule(
    ))
    dmi_facts = fhw.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert len(dmi_facts) > 0
    import pprint
    pprint.pprint(dmi_facts)



# Generated at 2022-06-20 17:20:22.796486
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test get_cpu_facts of ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware
    """
    module = DummyModule()
    dmesg_boot = get_file_content(FreeBSDHardware.DMESG_BOOT)
    if not dmesg_boot:
        try:
            rc, dmesg_boot, err = module.run_command(module.get_bin_path("dmesg"), check_rc=False)
        except Exception:
            dmesg_boot = ''
    expected = {'processor_count': '2', 'processor': ['Intel(R) Xeon(R) CPU E3-1240L v3 @ 2.40GHz', 'Intel(R) Xeon(R) CPU E3-1240L v3 @ 2.40GHz', ]}

    cpu

# Generated at 2022-06-20 17:20:34.855482
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModuleMock()
    module.run_command = MagicMock(return_value=(0, "hw.ncpu: 8\nhw.physmem: 8589934592", ""))

# Generated at 2022-06-20 17:20:51.577990
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Initialize a class FreeBSDHardware
    hardware = FreeBSDHardware(dict())

    # Create a dictionary mock_ansible_module_results
    mock_ansible_module_results = dict()
    mock_ansible_module_results['memfree_mb'] = 752
    mock_ansible_module_results['memtotal_mb'] = 8191
    mock_ansible_module_results['swapfree_mb'] = 0
    mock_ansible_module_results['swaptotal_mb'] = 0
    mock_ansible_module_results['processor'] = ['Intel(R) Core(TM) i7 CPU       M 620  @ 2.67GHz']
    mock_ansible_module_results['processor_cores'] = '1'
    mock_ansible_module_results['processor_count'] = '4'
    mock_

# Generated at 2022-06-20 17:21:04.509448
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    from ansible.module_utils.facts.collector import FactsCollector
    sysdir_original = '/dev'
    sysdir_test = 'tests/unit/module_utils/facts/hardware/test_hardware_bsd/get_device_facts'
    facts_module = FactsCollector()
    module_args = {}
    if os.path.exists(sysdir_test):
        os.rename(sysdir_test, sysdir_original)
        my_obj = FreeBSDHardware(facts_module, module_args)
        result = my_obj._get_device_facts()
        assert result['devices'] == {'ada0': ['ada0s1', 'ada0s2', 'ada0s3']}
        os.rename(sysdir_original, sysdir_test)

# Generated at 2022-06-20 17:21:09.250891
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )

    freebsdHardware_instance = FreeBSDHardware(module)
    freebsdHardware_instance.populate()
    data = freebsdHardware_instance.get_cpu_facts()
    fields = ['processor', 'processor_cores', 'processor_count']
    for field in fields:
        assert field in data


# Generated at 2022-06-20 17:21:22.799421
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Linux does not have the proper sysctl command
    test_legacy_sysctl = False

    # Create and return a test module
    mock_module = type('AnsibleModule', (object,), {
        "run_command": run_command,
        "get_bin_path": get_bin_path,
    })

    # Create and return a test class
    test_class = type('Hardware', (object,), {
        "module": mock_module
    })

    # Create a test HW class
    test_hw = FreeBSDHardware(test_class)

    # No sysctl command
    # On FreeBSD, the default format is annoying to parse.
    # Use -b to get the raw value and decode it.
    sysctl_cmd = test_hw.module.get_bin_path('sysctl')

# Generated at 2022-06-20 17:21:33.728021
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():

    # Create an instance of class FreeBSDHardware
    free_bsd_hw = FreeBSDHardware()

    # Create a fake filesystem
    test_data_path = os.path.join(os.path.dirname(__file__), 'unit/data/')
    sysdir_test = os.path.join(test_data_path, 'sysdir')

    # Use the fake filesystem for the test
    free_bsd_hw.module.get_bin_path = lambda x: sysdir_test

    # Call the method get_device_facts
    device_facts = free_bsd_hw.get_device_facts()

    # Check the facts returned by get_device_facts

# Generated at 2022-06-20 17:21:38.431549
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bsdhwc = FreeBSDHardwareCollector()
    assert type(bsdhwc) is FreeBSDHardwareCollector
    assert bsdhwc._platform == 'FreeBSD'


# Generated at 2022-06-20 17:21:43.102923
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """
    Unit test for method FreeBSDHardware.populate
    """
    module = MockModule()
    fact_class = FreeBSDHardware(module)

    # Test with no populated facts.
    fact_class.populate()
    assert 'mock_data' in fact_class._collected_facts



# Generated at 2022-06-20 17:21:52.587123
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    m = FreeBSDHardware({})
    result = m.get_device_facts()
    assert isinstance(result, dict)
    assert 'devices' in result
    assert isinstance(result['devices'], dict)
    for k in result['devices']:
        assert isinstance(k, str)
        assert k.startswith('a') or k.startswith('d')
        assert result['devices'][k] == [] or isinstance(result['devices'][k], list)
        if result['devices'][k]:
            assert len(result['devices'][k]) > 0
            for v in result['devices'][k]:
                assert isinstance(v, str)
                assert v.startswith('a') or v.startswith('d')
                assert v.endswith('s1') or v.endswith

# Generated at 2022-06-20 17:22:04.222237
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    We need to overwrite functions run_command and get_bin_path,
    which are not present for unit testing
    """
    # Overwrite run_command as it interacts with external binaries
    def fake_module_run_command(command, check_rc=True, close_fds=False, executable=None, data=None, binary_data=False, path_prefix=None, cwd=None, use_unsafe_shell=False, prompt_regex=None, environ_update=None, umask=None, encoding=None, errors='strict'):
        return 0, SAMPLE_DMIDECODE_OUTPUT, ''

    # Overwrite get_bin_path, because it tries to find binaries
    # inside the PATH directory, which is not available for unittesting

# Generated at 2022-06-20 17:22:05.846386
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardwareCollectorObj = FreeBSDHardwareCollector()
    assert hardwareCollectorObj is not None


# Generated at 2022-06-20 17:22:21.107259
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    """ This is to test the constructor of class FreeBSDHardwareCollector """
    freebsd_hardware_collector = FreeBSDHardwareCollector()
    assert freebsd_hardware_collector.platform == 'FreeBSD'
    assert freebsd_hardware_collector._fact_class.platform == 'FreeBSD'
    assert freebsd_hardware_collector._fact_class.__name__ == 'FreeBSDHardware'


# Generated at 2022-06-20 17:22:25.396688
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(argument_spec={})
    bsd_hw = FreeBSDHardware(module)

    assert bsd_hw.get_memory_facts()['memtotal_mb'] is not None
    assert bsd_hw.get_memory_facts()['memfree_mb'] is not None

# Generated at 2022-06-20 17:22:34.741124
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test FreeBSDHardware.get_cpu_facts
    """
    facts = {}
    facts['processor'] = []
    facts['processor_count'] = 4

# Generated at 2022-06-20 17:22:46.720106
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Unit tests for method FreeBSDHardware.get_uptime_facts
    """
    # Setup
    from ansible.module_utils.facts import timeout
    from ansible.module_utils.facts.hardware.base import Hardware
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware

    class Module(object):
        def get_bin_path(self, arg):
            return "/sbin/sysctl"

        def run_command(self, cmd, encoding=None):
            return 0, b'kern.boottime = {sec = 1562189713, usec = 120734}', ''

    class FakeTimeout(timeout):
        def __init__(self, max_time):
            pass

        def __enter__(self):
            return None


# Generated at 2022-06-20 17:22:54.225731
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True
    )

    fhw = FreeBSDHardware(module)
    cpu_facts = fhw.get_cpu_facts()

    assert 'processor' in cpu_facts
    assert 'processor_count' in cpu_facts
    assert 'processor_cores' in cpu_facts

    # Verify that at least the fields have values
    assert cpu_facts['processor_count'] != ""
    assert cpu_facts['processor_cores'] != ""



# Generated at 2022-06-20 17:22:58.523313
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fb = FreeBSDHardwareCollector()
    assert fb.get_fact_class() == FreeBSDHardware
    assert fb.get_platform() == 'FreeBSD'

# Generated at 2022-06-20 17:23:03.108120
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import subprocess
    from ansible.module_utils.facts.virtual.freebsd import FreeBSDVirtual
    test_facts = {
        'kernel': 'FreeBSD',
        'virtualization_type': 'jail',
        'virtualization_role': 'guest'
    }
    controller = FreeBSDVirtual()
    controller.populate(test_facts)
    facts = FreeBSDHardware().populate(test_facts)
    assert isinstance(facts, dict)
    assert 'devices' in facts
    assert isinstance(facts['devices'], dict)
    assert 'memtotal_mb' in facts
    assert isinstance(facts['memtotal_mb'], int)
    assert 'processor_count' in facts
    assert isinstance(facts['processor_count'], str)
    assert 'memfree_mb' in facts

# Generated at 2022-06-20 17:23:07.435746
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # create a FreeBSDHardware object
    FH = FreeBSDHardware()
    # save dmi facts
    tmp_dmi_facts = FH.get_dmi_facts()
    assert 'bios_date' in tmp_dmi_facts
    assert 'bios_vendor' in tmp_dmi_facts
    assert 'bios_version' in tmp_dmi_facts
    assert 'board_asset_tag' in tmp_dmi_facts
    assert 'board_name' in tmp_dmi_facts
    assert 'board_serial' in tmp_dmi_facts
    assert 'board_vendor' in tmp_dmi_facts
    assert 'board_version' in tmp_dmi_facts
    assert 'chassis_asset_tag' in tmp_dmi_facts
    assert 'chassis_serial' in tmp

# Generated at 2022-06-20 17:23:08.196217
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw is not None

# Generated at 2022-06-20 17:23:08.770313
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-20 17:23:24.362015
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = type('FakeModule', (), {})
    module.run_command = lambda x: (0, b'{ kern.boottime = 1544357053 }', b'')

    hw = FreeBSDHardware(module)
    assert hw.get_uptime_facts()['uptime_seconds'] > 0

# Generated at 2022-06-20 17:23:33.270174
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    CPU_FACTS = dict(processor_cores='2',
                     processor_count='2',
                     processor=['Intel(R) Core(TM) i5-2400 CPU @ 3.10GHz'])

    fh = FreeBSDHardware()
    fh.module = MockModule()
    fh.module.run_command.return_value = (0, CPU_FACTS['processor'][0], None)
    assert fh.get_cpu_facts() == CPU_FACTS



# Generated at 2022-06-20 17:23:40.400769
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    import ansible.module_utils.facts.hardware.freebsd as get_device_facts
    from ansible.module_utils._text import to_bytes
    result = get_device_facts.FreeBSDHardware.get_device_facts(None)
    assert result['devices']
    for keys in result['devices']:
        assert isinstance(keys, to_bytes)
        for keys1 in result['devices'][keys]:
            assert isinstance(keys1, to_bytes)

# Generated at 2022-06-20 17:23:52.150603
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import mock
    import sys
    import tempfile

    sys.modules['ansible'] = mock.Mock()
    sys.modules['ansible.module_utils'] = mock.Mock()

    # NB: We don't load AnsibleModule since it screws up the import path
    #     and breaks some of the module_utils imports.

    from ansible.module_utils.facts import timeout
    import ansible.module_utils.facts.hardware.freebsd

    # Patch out the command.
    old_run_command = ansible.module_utils.facts.hardware.freebsd.Hardware.module.run_command

# Generated at 2022-06-20 17:23:58.156097
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    facts = FreeBSDHardware(dict())

    assert 'uptime_seconds' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'processor' in facts
    assert 'processor_cores' in facts
    assert 'processor_count' in facts
    assert 'devices' in facts

# Generated at 2022-06-20 17:24:06.274420
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(argument_spec=dict())
    sysdir = os.path.realpath('tests/unittests/test_utils/test_facts/FreeBSD_devices')
    fhw = FreeBSDHardware(module=module)
    fhw.get_device_facts(sysdir)
    assert fhw.file_exists(sysdir + '/da0')
    assert fhw.file_exists(sysdir + '/da1')
    assert fhw.file_exists(sysdir + '/ada0')
    assert fhw.file_exists(sysdir + '/da0s1a')
    assert fhw.file_exists(sysdir + '/da0s2b')
    assert fhw.file_exists(sysdir + '/ada0s1c')

# Generated at 2022-06-20 17:24:17.935576
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    expected_result = {
        'devices':
        {'acd0': [], 'da0': ['da0s1', 'da0s2', 'da0s3'],
         'da1': ['da1s1', 'da1s2'],
         'ada0': ['ada0s1', 'ada0s2', 'ada0s3'],
         'ada1': ['ada1s1', 'ada1s2'],
         'cd0': []}
    }
    tempdir = tempfile.mkdtemp()
    subdir = 'dev'

# Generated at 2022-06-20 17:24:28.964984
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-20 17:24:37.319072
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    fhw = FreeBSDHardware()
    assert fhw.get_cpu_facts() is not None
    assert fhw.get_memory_facts() is not None
    assert fhw.get_uptime_facts() is not None
    assert fhw.get_dmi_facts() is not None
    assert fhw.get_device_facts() is not None
    try:
        fhw.get_mount_facts()
    except TimeoutError:
        pass
    assert fhw.platform == 'FreeBSD'

# Generated at 2022-06-20 17:24:41.936055
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={})
    fixture = FreeBSDHardware(module)
    fixture.populate()
    assert fixture.ansible_facts['uptime_seconds'] > 0
    assert fixture.ansible_facts['processor_count'] > 0
    assert fixture.ansible_facts['processor']
    assert fixture.ansible_facts['memtotal_mb'] > 0
    assert fixture.ansible_facts['memfree_mb'] > 0
    assert fixture.ansible_facts['devices']
    assert fixture.ansible_facts['devices'].values()


# Generated at 2022-06-20 17:24:55.312150
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    # Test for FreeBSDHardware
    hardware_obj = FreeBSDHardware(dict())
    assert hardware_obj.platform == 'FreeBSD'
    assert hardware_obj.dmi_facts == {}


# Generated at 2022-06-20 17:25:03.540737
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=True
    )
    result = FreeBSDHardware(module).populate()
    assert 'memfree_mb' in result
    assert 'memtotal_mb' in result
    assert 'swapfree_mb' in result
    assert 'swaptotal_mb' in result
    assert 'processor' in result
    assert 'processor_cores' in result
    assert 'processor_count' in result
    assert 'devices' in result
    assert 'uptime_seconds' in result


# Generated at 2022-06-20 17:25:09.764616
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_module = AnsibleModule(argument_spec=dict())
    test_hw = FreeBSDHardware(test_module)
    cpu_facts = test_hw.get_cpu_facts()
    assert isinstance(cpu_facts['processor'], list)
    assert isinstance(cpu_facts['processor_cores'], int)
    assert isinstance(cpu_facts['processor_count'], int)


# Generated at 2022-06-20 17:25:21.203597
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)
    freebsd_hardware = FreeBSDHardware('module', module, module)
    hardware_facts = freebsd_hardware._populate_from_file()
    assert hardware_facts is not None
    assert len(hardware_facts) > 0
    assert hardware_facts['uptime_seconds'] > 0
    assert hardware_facts['uptime_seconds'] >= \
        hardware_facts['uptime_days'] * 24 * 60 * 60, \
        "uptime_days does not match uptime_seconds"
    assert hardware_facts['uptime_days'] >= \
        hardware_facts['uptime_hours'] // 24
    assert hardware_facts['uptime_hours'] >= \
        hardware_facts['uptime_minutes'] // 60

# Generated at 2022-06-20 17:25:28.516152
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    hardware = FreeBSDHardware(module)

    devices = hardware.get_device_facts().get('devices')

    assert 'ada0' in devices
    assert isinstance(devices['ada0'], list)
    assert len(devices['ada0']) > 0
    assert devices['ada0'][0] == 'ada0s1a'
    assert devices['ada0'][1] == 'ada0s1b'



# Generated at 2022-06-20 17:25:39.731895
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-20 17:25:49.095775
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={'fact_path': dict(required=False, type='path', default='/etc/ansible/facts.d')})
    hw_obj = FreeBSDHardware(module)
    uptime_facts = hw_obj.get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']
    assert (isinstance(uptime_seconds, int))
    assert (uptime_seconds > 0)

if __name__ == '__main__':
    from ansible.module_utils.facts.collector import BaseFactCollector
    from ansible.module_utils.basic import AnsibleModule
    main = BaseFactCollector.main
    main(FreeBSDHardwareCollector)

# Generated at 2022-06-20 17:25:59.036338
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """Unit test for method populate of class FreeBSDHardware

    :returns: None
    """
    # Creating a mock class for module
    module = type('', (object,), dict(run_command=lambda x, y, z: ['', '', '']))

    # Creating a mock class for ansible_module_utils.facts.hardware.base.Hardware
    hardware_base = type('', (object,), dict(Hardware={}, MODULE_CACHE={}))

    # Creating a mock class for ansible_module_utils.facts.timeout.timeout
    timeout = type('', (object,), dict(TimeoutError={},
                                       timeout=lambda x, y: ["", "", ""]))

    # Create instance of FreeBSDHardware class
    hardware_facts = FreeBSDHardware(module)

    # Create instance of FreeBSDHardwareCollector class
    hardware_

# Generated at 2022-06-20 17:26:03.588087
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Init FreeBSDHardware class
    hardware = FreeBSDHardware(None)

    # Populate FreeBSDHardware class with facts
    hardware_facts = hardware.populate()

    # Assert that FreeBSDHardware class was populated with facts
    assert hardware_facts is not None


# Generated at 2022-06-20 17:26:07.619885
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hardware = FreeBSDHardware({}, {})
    assert hardware.platform == 'FreeBSD'


# Generated at 2022-06-20 17:26:31.859510
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware_obj = FreeBSDHardware()

    # Define test input

# Generated at 2022-06-20 17:26:43.078444
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():

    # create a mock module which is passed to the facts module
    class MockModule(object):
        pass

    # create a mock module class
    module = MockModule()
    module.get_bin_path = Mock(return_value='/sbin/sysctl')

    # create instance of FreeBSDHardware
    fhw = FreeBSDHardware(module)

    # test return values
    assert fhw.platform == 'FreeBSD'
    assert fhw.DMESG_BOOT == '/var/run/dmesg.boot'
    assert fhw.get_cpu_facts() == {}
    assert fhw.get_memory_facts() == {}
    assert fhw.get_uptime_facts() == {}
    assert fhw.get_mount_facts() == {}
    assert fhw.get_device_facts() == {}

# Generated at 2022-06-20 17:26:53.834591
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = FakeAnsibleModule()
    freebsd_hw = FreeBSDHardware(module=module)
    result = freebsd_hw.populate()

# Generated at 2022-06-20 17:27:04.028415
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
  '''Test get_device_facts of FreeBSDHardware
  '''

  # mocked data
  sample_data = {
    'devices': {
      'ada0': [
        'ada0s1a',
        'ada0s1b',
        'ada0s1e',
        'ada0s1f'
      ],
      'ada1': [
        'ada1s1a',
        'ada1s1b',
        'ada1s1e',
        'ada1s1f'
      ]
    }
  }
  freebsd_hardware = FreeBSDHardware(dict(), dict())
  freebsd_hardware.module.fail_json = lambda *args, **kwargs: dict()

  # mocked os.path.isdir
  saved_isdir = os.path.isdir
  os

# Generated at 2022-06-20 17:27:15.470799
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import sys
    import pytest
    import ansible.module_utils.facts.hardware.freebsd

    def _mock__get_result(module, command):
        return 0, '', ''

    fb = ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware()
    fb.module.get_bin_path = lambda x: None
    fb.module.run_command = _mock__get_result
    # old python versions don't have mock imported
    if sys.version_info[0] < 3:
        pytest.skip("Skipping for Python < 3")
    else:
        from _pytest.monkeypatch import MonkeyPatch
        mp = MonkeyPatch()

# Generated at 2022-06-20 17:27:19.488747
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    my_HW = FreeBSDHardwareCollector()
    assert my_HW.platform == 'FreeBSD'
    assert my_HW._fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:27:20.856749
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    hw = FreeBSDHardware([])
    assert hw.platform == 'FreeBSD'

# Generated at 2022-06-20 17:27:31.478603
# Unit test for constructor of class FreeBSDHardware
def test_FreeBSDHardware():
    '''
    Test FreeBSDHardware class.
    '''
    from ansible.module_utils.facts import ModuleExecutor
    from ansible.module_utils.facts.utils import get_file_content

    module = ModuleExecutor(FreeBSDHardware)
    facts = module.get_facts()

    # Make sure we get a class
    assert issubclass(facts['collector'], FreeBSDHardware)

    # Make sure we can access the data
    assert issubclass(facts['collector'], FreeBSDHardware)
    assert 'processor' in facts['ansible_facts']
    assert 'processor_cores' in facts['ansible_facts']
    assert 'processor_count' in facts['ansible_facts']
    assert 'memtotal_mb' in facts['ansible_facts']

# Generated at 2022-06-20 17:27:34.094477
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector = FreeBSDHardwareCollector()
    assert hardware_collector.platform == 'FreeBSD'
    assert hardware_collector.fact_class == FreeBSDHardware


# Generated at 2022-06-20 17:27:41.943896
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from io import StringIO
    from ansible.module_utils.facts.collector import get_collector

    # Create fake file to sysctl
    sys_file = StringIO()
    sys_file.write('vm.stats.vm.v_page_size: 4096\n')
    sys_file.write('vm.stats.vm.v_page_count: 168005\n')
    sys_file.write('vm.stats.vm.v_free_count: 9020\n')
    sys_file.seek(0)

    # Call sysctl only if there is a valid sysctl
    hardware = get_collector('hardware')
    hardware._module.get_bin_path = lambda x: '/sbin/sysctl'