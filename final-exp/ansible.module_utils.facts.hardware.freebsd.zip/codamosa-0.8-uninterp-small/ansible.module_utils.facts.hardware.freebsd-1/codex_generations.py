

# Generated at 2022-06-24 21:58:58.004965
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '<%.E'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module = mock.Mock()
    free_b_s_d_hardware_0.module.run_command.return_value = (
        0, 'vm.stats.vm.v_page_size:4096\r\nvm.stats.vm.v_page_count:6185400\r\nvm.stats.vm.v_free_count:6054192', ''
    )

    try:
        free_b_s_d_hardware_0.get_memory_facts()
    except:
        failobj = sys.exc_info()[1]

# Generated at 2022-06-24 21:59:03.222814
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'x'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    expected_value = 'x'
    actual_value = free_b_s_d_hardware_0.get_dmi_facts()
    assert actual_value == expected_value


# Generated at 2022-06-24 21:59:13.829383
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '18pF;&'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)

# Generated at 2022-06-24 21:59:23.162843
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_ = ';n4I'
    free_b_s_d_hardware_ = FreeBSDHardware(str_)
    rc_0 = __rand_int()
    out_0 = __rand_str(6)
    err_0 = __rand_str(6)
    free_b_s_d_hardware_.module.run_command = MagicMock(return_value=(rc_0,out_0,err_0))
    rc_1 = __rand_int()
    out_1 = __rand_str(2)
    err_1 = __rand_str(2)
    free_b_s_d_hardware_.module.run_command = MagicMock(return_value=(rc_1,out_1,err_1))
    rc_2 = __rand_int()

# Generated at 2022-06-24 21:59:24.170369
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_case_0()

# Generated at 2022-06-24 21:59:27.671396
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '<p>'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 21:59:29.512971
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = ';n4I'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)

# Testing the normal invocation of FreeBSDHardwareCollector.collect()

# Generated at 2022-06-24 21:59:33.741245
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    init_str_0 = 'mJgFq\\b'

    free_b_s_d_hardware_0 = FreeBSDHardware(init_str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:35.769946
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_FreeBSDHardwareCollector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 21:59:37.992793
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = ';n4I'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)


# Generated at 2022-06-24 21:59:56.747450
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_FreeBSDHardware_obj = FreeBSDHardware()
    collected_facts = {}
    
    test_FreeBSDHardware_obj.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:00:07.336358
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_facts = {}
    sysctl = '/usr/sbin/sysctl'
    if sysctl:
        rc, out, err = os.popen3("sysctl vm.stats")
        for line in out.splitlines():
            data = line.split()
            if 'vm.stats.vm.v_page_size' in line:
                pagesize = int(data[1])
            if 'vm.stats.vm.v_page_count' in line:
                pagecount = int(data[1])
            if 'vm.stats.vm.v_free_count' in line:
                freecount = int(data[1])
        mem_facts['memtotal_mb'] = pagesize * pagecount // 1024 // 1024
        mem_facts['memfree_mb'] = pagesize * freecount // 1024 // 1024

    swap

# Generated at 2022-06-24 22:00:20.160351
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = AnsibleModule(argument_spec={})

    class AnsibleModule:
        def get_bin_path(self, arg):
            return "/bin/sysctl"


# Generated at 2022-06-24 22:00:23.892608
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Unit test for populate
    fbhl = FreeBSDHardware()
    collected_facts = {}
    hardware_facts = fbhl.populate(collected_facts)
    assert hardware_facts['devices'].keys() is not None


# Generated at 2022-06-24 22:00:28.993232
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Initialization
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Call the populate method of free_b_s_d_hardware_0
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:32.838604
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:37.463824
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_memory_facts() == {'memtotal_mb': 107249, 'memfree_mb': 2209}


# Generated at 2022-06-24 22:00:42.844923
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_2 = FreeBSDHardware()
    free_b_s_d_hardware_get_uptime_facts_0 = free_b_s_d_hardware_2.get_uptime_facts()
    assert free_b_s_d_hardware_get_uptime_facts_0 == {'uptime_seconds': 0}



# Generated at 2022-06-24 22:00:46.237236
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Fetching an instance of the subclass
    test_obj = FreeBSDHardware()
    # Call the method with a valid argument
    result = test_obj.get_dmi_facts()


# Generated at 2022-06-24 22:00:50.240723
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    collected_facts_0 = {}
    free_b_s_d_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:01:07.470488
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Input parameters
    # Output
    # Return value
    expectedReturn_0 = {}

    return_0 = FreeBSDHardware.get_device_facts()

    assert return_0 == expectedReturn_0


# Generated at 2022-06-24 22:01:14.708746
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = MagicMock()
    free_b_s_d_hardware.module.get_bin_path.return_value = '/usr/bin/sysctl'
    free_b_s_d_hardware.module.run_command.side_effect = [
        (0, 'hw.ncpu: \t8\nhw.ncpuonline: \t8', ''),
        (0, 'vm.stats.vm.v_page_size: \t4096\nvm.stats.vm.v_page_count: \t471352\nvm.stats.vm.v_free_count: \t443671', '')
    ]
    free_b_s_d_hardware.pop

# Generated at 2022-06-24 22:01:19.149578
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Test setup
    mock_module = MockAnsibleModule(
        dict(
            gather_subset=[
                '!all',
                '!min',
            ],
            filter=dict(
                type='dict',
                elements='<key:value>',
                required=False
            )
        )
    )
    free_b_s_d_hardware_0 = FreeBSDHardware(module=mock_module)
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_collector_0.module = mock_module
    free_b_s_d_hardware_collector_0.platform = 'FreeBSD'

    # Initialize a variable
    mock_module_command = None
    sysctl = free_b_s

# Generated at 2022-06-24 22:01:26.065342
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    return_value = free_b_s_d_hardware.get_dmi_facts()
    # AssertionError: {u'chassis_vendor': 'NA', u'board_asset_tag': 'NA', u'product_name': 'NA', u'board_vendor': 'NA', u'board_name': 'NA', u'chassis_asset_tag': 'NA', u'macaddress': 'NA', u'product_uuid': 'NA', u'chassis_version': 'NA', u'product_version': 'NA', u'board_version': 'NA', u'product_serial': 'NA', u'form_factor': 'NA', u'board_serial': 'NA', u'chassis_serial': 'NA', u'bios

# Generated at 2022-06-24 22:01:38.347670
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    statvfs_info_0 = {'f_bfree': 1024,
                      'f_frsize': 0,
                      'f_bavail': 1024,
                      'f_files': 0,
                      'f_bsize': 0,
                      'f_ffree': 0,
                      'f_favail': 0,
                      'f_flag': 0,
                      'f_blocks': 0}
    statvfs_info_1 = {'f_bfree': 1024,
                      'f_frsize': 0,
                      'f_bavail': 1024,
                      'f_files': 0,
                      'f_bsize': 0,
                      'f_ffree': 0,
                      'f_favail': 0,
                      'f_flag': 0,
                      'f_blocks': 0}
   

# Generated at 2022-06-24 22:01:44.006074
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fb_hw = FreeBSDHardware()
    cpu_facts = fb_hw.get_cpu_facts()
    sysctl = fb_hw.module.get_bin_path('sysctl')
    rc, out, err = fb_hw.module.run_command("%s -n hw.ncpu" % sysctl, check_rc=False)
    processor_count = out.strip()
    assert(int(processor_count) == int(cpu_facts['processor_count']))
    assert(len(cpu_facts['processor']) == int(processor_count))
    dmesg_boot = get_file_content(FreeBSDHardware.DMESG_BOOT)

# Generated at 2022-06-24 22:01:45.756942
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert isinstance(free_b_s_d_hardware_collector_0, HardwareCollector)


# Generated at 2022-06-24 22:01:48.524335
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0 != None


# Generated at 2022-06-24 22:01:55.448400
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/bin/sysctl'
    free_b_s_d_hardware_0.module.run_command.return_value = (
        0, "\nvm.stats.vm.v_free_count: 172784\nhw.ncpu: 2\nhw.machine: amd64\nhw.model: Intel(R) Core(TM) i7-4600M CPU @ 2.90GHz\nhw.ncpuonline: 2\n", '')
    free_b_s_d_hardware_0.module.run_command.side_

# Generated at 2022-06-24 22:01:58.424537
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:16.473587
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware(dict(), None)
    free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:02:20.149951
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    assert free_b_s_d_hardware_0.uptime_seconds == int(time.time() - os.stat('/var/run/dmesg.boot').st_mtime)


# Generated at 2022-06-24 22:02:21.411284
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    # Initializes FreeBSDHardwareCollector
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:02:26.259178
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fact_dict = {
            "processor": [],
            "processor_cores": 1,
            "processor_count": 3
    }
    fb_hw = FreeBSDHardware(fact_dict)
    cpu_facts_dict = fb_hw.get_cpu_facts()
    assert cpu_facts_dict == fact_dict


# Generated at 2022-06-24 22:02:28.982564
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:02:34.248864
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    return free_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 1025, 'swaptotal_mb': 0, 'memtotal_mb': 1027, 'swapfree_mb': 0}


# Generated at 2022-06-24 22:02:41.981780
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule(argument_spec=dict())
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value=True)
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))

# Generated at 2022-06-24 22:02:44.809051
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:02:53.487740
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    f_b_s_d_hardware = FreeBSDHardware()
    assert f_b_s_d_hardware.get_cpu_facts() == {
        'processor': ['Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz',
                      'Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz',
                      'Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz',
                      'Intel(R) Xeon(R) CPU E5-2623 v3 @ 3.00GHz'],
        'processor_cores': 1,
        'processor_count': 4
    }


# Generated at 2022-06-24 22:02:56.757201
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    return_value = free_b_s_d_hardware_0.get_uptime_facts()
    assert return_value is None


# Generated at 2022-06-24 22:03:14.060443
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware
    assert free_b_s_d_hardware_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-24 22:03:18.271233
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_get_uptime_facts_facts = {
        'uptime_seconds': 1517513477
    }

    freebsd_hardware = FreeBSDHardware()

    # Call the method
    freebsd_hardware_get_uptime_facts_facts = freebsd_hardware.get_uptime_facts()

    assert(freebsd_hardware_get_uptime_facts_facts == test_get_uptime_facts_facts)

    return

# Generated at 2022-06-24 22:03:22.808359
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freebsdhardware = FreeBSDHardware({"nodename": "some-hostname"})
    res = freebsdhardware.get_cpu_facts()
    assert res == {'processor': [], 'processor_count': '', 'processor_cores': ''}


# Generated at 2022-06-24 22:03:24.997748
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    fBSD_hardware_collector = FreeBSDHardwareCollector()
    assert isinstance(fBSD_hardware_collector, FreeBSDHardwareCollector)

c = FreeBSDHardwareCollector()
print(c)

# Generated at 2022-06-24 22:03:32.499916
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    assert free_b_s_d_hardware_0._facts == {'devices': {},
                                            'mounts': [],
                                            'processor': ['Intel(R) Xeon(R) CPU E3-1270 V2 @ 3.50GHz'],
                                            'processor_cores': '8',
                                            'processor_count': '1',
                                            'uptime_seconds': int(time.time())}


# Generated at 2022-06-24 22:03:36.842536
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = AnsibleModule(
        argument_spec = dict()
    )
    free_b_s_d_hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware.module.get_bin_path = MagicMock(return_value='/sbin/swapinfo')
    ansible_facts = free_b_s_d_hardware.populate()
    assert 'swaptotal_mb' in ansible_facts


# Generated at 2022-06-24 22:03:41.155214
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:03:44.667584
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    print('Test get_cpu_facts')
    free_b_s_d_hardware_0 = FreeBSDHardware()
    print('Test get_cpu_facts finished')



# Generated at 2022-06-24 22:03:48.038875
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_0 = FreeBSDHardware()

    # Test with default values for args
    cpu_facts = hardware_0.get_cpu_facts()
    assert cpu_facts == {'processor_count': '0', 'processor': []}


# Generated at 2022-06-24 22:03:54.719102
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    dmi_facts = free_b_s_d_hardware_0.get_dmi_facts()
    assert 'board_vendor' in dmi_facts.keys()
    assert 'system_vendor' in dmi_facts.keys()
    assert 'board_serial' in dmi_facts.keys()
    assert 'chassis_vendor' in dmi_facts.keys()
    assert 'chassis_serial' in dmi_facts.keys()
    assert 'form_factor' in dmi_facts.keys()
    assert 'chassis_version' in dmi_facts.keys()
    assert 'system_vendor' in dmi_facts.keys()
    assert 'board_version' in dmi_facts.keys()

# Generated at 2022-06-24 22:04:27.178240
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    f = FreeBSDHardware()
    results = f.get_device_facts()
    assert results.get('devices') != {}


# Generated at 2022-06-24 22:04:30.068014
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    result = get_dmi_facts(free_b_s_d_hardware_collector_0)


# Generated at 2022-06-24 22:04:35.626256
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:37.797650
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert get_memory_facts() == {}

# Generated at 2022-06-24 22:04:40.582035
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    # Test coverage for FreeBSDHardware.populate

    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:41.620779
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert True


# Generated at 2022-06-24 22:04:45.579947
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    with pytest.raises(Exception):
        free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:04:55.977907
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

# Generated at 2022-06-24 22:05:00.665640
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    return


# Generated at 2022-06-24 22:05:05.672939
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware(module="module_0")
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:05:37.080684
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:41.161080
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    float_0 = 350.2
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:05:44.765213
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:48.957090
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:53.444496
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:06:03.629305
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_cpu_facts()
    free_b_s_d_hardware_0.get_memory_facts()
    free_b_s_d_hardware_0.get_uptime_facts()
    free_b_s_d_hardware_0.get_dmi_facts()
    free_b_s_d_hardware_0.get_device_facts()
    free_b_s_d_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:06:05.652184
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    float_0 = 882.4
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(float_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:06:09.226122
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 593.8
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:06:14.331451
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:16.809937
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:07:13.569382
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_1 = free_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:07:15.501361
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert (FreeBSDHardwareCollector._platform == 'FreeBSD')
    assert (FreeBSDHardwareCollector._fact_class is FreeBSDHardware)


# Generated at 2022-06-24 22:07:18.039168
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:07:22.932768
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 161.5
    free_b_s_d_hardware_1 = FreeBSDHardware(float_0)
    free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:07:27.365591
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:07:32.327617
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    float_1 = 568.7
    free_b_s_d_hardware_1 = FreeBSDHardware(float_1)
    var_1 = free_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:07:37.501165
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    float_0 = 967.2
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.populate(None)


test_case_0()

# Generated at 2022-06-24 22:07:42.127900
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:07:45.278680
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:07:49.702392
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    float_0 = 882.4
    free_b_s_d_hardware_0 = FreeBSDHardware(float_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
