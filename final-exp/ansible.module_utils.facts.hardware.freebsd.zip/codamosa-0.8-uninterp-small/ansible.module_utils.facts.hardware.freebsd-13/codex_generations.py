

# Generated at 2022-06-24 21:58:45.640831
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Calling method get_uptime_facts of class FreeBSDHardware
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:58:50.762413
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test = FreeBSDHardware()

    assert test.get_cpu_facts() == {'processor': ['Intel(R) Core(TM) i5-3470S CPU @ 2.90GHz'], 'processor_cores': '2', 'processor_count': '4'}



# Generated at 2022-06-24 21:58:54.601575
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Arrange
    module_0 = AnsibleModule(
        argument_spec=dict(
        )
    )
    test_free_b_s_d_hardware_0 = FreeBSDHardware(module_0)

    # Act
    test_free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 21:58:58.852824
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Initialize instance of FreeBSDHardware
    freebsd_hardware = FreeBSDHardware()
    # Call method get_uptime_facts of instance FreeBSDHardware
    freebsd_hardware.get_uptime_facts()


# Generated at 2022-06-24 21:59:04.194515
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_memory_facts() == {'memtotal_mb': 0, 'swaptotal_mb': 0, 'memfree_mb': 0, 'swapfree_mb': 0}


# Generated at 2022-06-24 21:59:07.103340
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    assert free_b_s_d_hardware_0.populate() is None



# Generated at 2022-06-24 21:59:10.523841
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    FreeBSDHardware.get_dmi_facts()


# Generated at 2022-06-24 21:59:14.852926
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """Test get_memory_facts of FreeBSdHardware"""
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 21:59:16.074979
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 21:59:21.711463
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Test the is_valid_timezone method of FreeBSDHardware class
    """
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 10247, 'memfree_mb': 10246}


# Generated at 2022-06-24 21:59:35.021288
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware_0.get_uptime_facts(), dict)

# Generated at 2022-06-24 21:59:45.917139
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()[0]
    free_b_s_d_hardware_0_get_cpu_facts = free_b_s_d_hardware_0.get_cpu_facts()
    assert type(free_b_s_d_hardware_0_get_cpu_facts) == type({})
    assert len(free_b_s_d_hardware_0_get_cpu_facts) == 3
    assert free_b_s_d_hardware_0_get_cpu_facts.get('processor_count') == '1'

# Generated at 2022-06-24 21:59:48.435556
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    print(free_b_s_d_hardware.get_memory_facts())


# Generated at 2022-06-24 21:59:51.133495
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_ = FreeBSDHardware()
    free_b_s_d_hardware_get_dmi_facts_0 = free_b_s_d_hardware_.get_dmi_facts()


# Generated at 2022-06-24 22:00:00.533575
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    free_b_s_d_hardware_0.module.run_command = lambda _, __, **kwargs: (0, "vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 5113369\nvm.stats.vm.v_free_count: 3173268\n", "")
    assert {"swaptotal_mb": 0, "memfree_mb": 1244, "memtotal_mb": 4972, "swapfree_mb": 0} == free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:05.697335
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_h = FreeBSDHardware()
    # Call method 'get_memory_facts' of free_b_s_d_h and store the result in memory_facts
    memory_facts = free_b_s_d_h.get_memory_facts()
    # Assert: Verify that memory_facts is not empty
    assert len(memory_facts) > 0


# Generated at 2022-06-24 22:00:07.473441
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:10.345580
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:14.074628
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


if __name__ == "__main__":
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:24.932045
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0.module = None
    free_b_s_d_hardware_1.module = None
    free_b_s_d_hardware_collector_1.module = None

    free_b_s_d_hardware_0.populate(None)
    free_b_s_d_hardware_1.populate(None)
    free_b_s_d_hardware_collector_1.populate(None)

test_case_0()
test_FreeBSDHardware_populate()

# Generated at 2022-06-24 22:00:40.002756
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_populate()

# Generated at 2022-06-24 22:00:50.961464
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_fact_dict = free_b_s_d_hardware_0.populate()
    assert type(free_b_s_d_hardware_fact_dict) is dict, "get_dmi_facts returned type {} instead of dict".format(type(free_b_s_d_hardware_fact_dict))
    assert type(free_b_s_d_hardware_fact_dict["system_vendor"]) is str, "get_dmi_facts system_vendor attribute is type {} instead of str".format(type(free_b_s_d_hardware_fact_dict["system_vendor"]))


# Generated at 2022-06-24 22:00:53.410233
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:00:57.799872
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.get_file_content = MagicMock(return_value='')

    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:00.342737
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fbsd_hw_0 = FreeBSDHardware()
    fbsd_hw_0.get_dmi_facts()


# Generated at 2022-06-24 22:01:04.075190
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    return_value = free_b_s_d_hardware_collector_0.get_uptime_facts()
    assert return_value is not None


# Generated at 2022-06-24 22:01:09.044307
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()

    free_b_s_d_hardware_1 = free_b_s_d_hardware_collector_1.collect()

    free_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:01:19.252612
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_case_0()

    # Simple unit test for method get_memory_facts of class FreeBSDHardware
    free_b_s_d_hardware_0 = FreeBSDHardware()  # instantiate object of class FreeBSDHardware
    facts = free_b_s_d_hardware_0.get_memory_facts()  # call method get_memory_facts of class FreeBSDHardware
    assert isinstance(facts['memfree_mb'], int)
    assert isinstance(facts['memtotal_mb'], int)
    assert facts['memtotal_mb'] > 0
    assert facts['memfree_mb'] < facts['memtotal_mb']


# Generated at 2022-06-24 22:01:24.461442
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    free_b_s_d_hardware_0.module.get_bin_path = lambda path: 'bin_path'
    free_b_s_d_hardware_0.module.run_command = lambda cmd, encoding: (0, 'stdout', 'stderr')
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:36.181269
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    freebsd_hardware_0 = FreeBSDHardware()
    freebsd_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/sbin/dmidecode')

# Generated at 2022-06-24 22:02:06.303932
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_free = get_file_content('/proc/meminfo')
    mem_free = int(mem_free.split('MemFree: ', 1)[1].split(' kB')[0])
    mem_free = mem_free / 1024
    mem_tot = get_file_content('/proc/meminfo')
    mem_tot = int(mem_tot.split('MemTotal: ', 1)[1].split(' kB')[0])
    mem_tot = mem_tot / 1024
    swap_free = get_file_content('/proc/meminfo')
    swap_free = int(swap_free.split('SwapFree: ', 1)[1].split(' kB')[0])
    swap_free = swap_free / 1024

# Generated at 2022-06-24 22:02:13.364014
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_FreeBSDHardware_0 = FreeBSDHardware()
    test_FreeBSDHardware_get_memory_facts_0 = test_FreeBSDHardware_0.get_memory_facts()

    assert test_FreeBSDHardware_get_memory_facts_0['memtotal_mb'] >= 0
    assert test_FreeBSDHardware_get_memory_facts_0['swaptotal_mb'] >= 0
    assert test_FreeBSDHardware_get_memory_facts_0['memfree_mb'] >= 0
    assert test_FreeBSDHardware_get_memory_facts_0['swapfree_mb'] >= 0


# Generated at 2022-06-24 22:02:20.771487
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create test instance
    free_b_s_d_hardware = FreeBSDHardware()

    # Call test method
    free_b_s_d_hardware_get_dmi_facts_result = free_b_s_d_hardware.get_dmi_facts()

    # Test successful call
    assert 'system_vendor' in free_b_s_d_hardware_get_dmi_facts_result
    # Test successful call
    assert 'bios_vendor' in free_b_s_d_hardware_get_dmi_facts_result
    # Test successful call
    assert 'product_name' in free_b_s_d_hardware_get_dmi_facts_result
    # Test successful call
    assert 'product_version' in free_b_s_d_hardware_get

# Generated at 2022-06-24 22:02:23.758531
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    FreeBSDHardware.get_uptime_facts(free_b_s_d_hardware_0)



# Generated at 2022-06-24 22:02:25.794066
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_0 = FreeBSDHardware()
    hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:02:32.076600
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Boot time of the system, in seconds.
    kern_boottime = 1561350578
    result = {'uptime_seconds': int(time.time() - kern_boottime)}

    # Get the actual uptime using the FreeBSD fact class
    fact_class = FreeBSDHardware()
    uptime_facts = fact_class.get_uptime_facts()

    assert result == uptime_facts



# Generated at 2022-06-24 22:02:35.798416
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()

    with open("tests/unit/module_utils/facts/freebsd/hardware/data/hardware_facts.json") as f:
        hardware_facts = json.load(f)

    hardware_facts = hardware.populate()

    assert hardware_facts == hardware_facts


# Generated at 2022-06-24 22:02:38.967791
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware(module=None)

    # Call method
    dmi_facts = free_b_s_d_hardware.get_dmi_facts()
    assert(isinstance(dmi_facts, dict))



# Generated at 2022-06-24 22:02:41.865268
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create object
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Run method get_uptime_facts of object free_b_s_d_hardware_0
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:45.037546
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware_0.get_uptime_facts(), type({}))


# Generated at 2022-06-24 22:03:32.961660
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:03:45.268043
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    os.times()
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.run_command.return_value =(0, b'Tue May 31 15:06:21 2016\x00\x00\x00\x00', None)
    free_b_s_d_hardware_0.module.get_bin_path.return_value = 'dmesg'
    free_b_s_d_hardware_0.module.get_bin_path.return_value = 'sysctl'

    assert free_b_s_d_hardware_0.get_uptime_facts() == {u'uptime_seconds': 1464816196}


# Generated at 2022-06-24 22:03:49.711175
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0._fact_class({})
    assert free_b_s_d_hardware_0.get_memory_facts() == {}


# Generated at 2022-06-24 22:03:51.735378
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:03:53.205763
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_0 = FreeBSDHardware()
    hardware_0._module = AnsibleModuleFake()
    hardware_0.populate({})


# Generated at 2022-06-24 22:03:55.057854
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    data = free_b_s_d_hardware_0.get_uptime_facts()
    assert data['uptime_seconds'] == 15814


# Generated at 2022-06-24 22:03:59.447854
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Create instance of class 'FreeBSDHardwareCollector'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)


# Generated at 2022-06-24 22:04:02.162584
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:04:07.093949
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = None # TODO: insert real value here.

    # Test case setup

    # Test case execution
    result = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:14.598061
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    out = """hw.ncpu: 12
hw.physmem: 17179869184
hw.usermem: 16849932288
hw.ncpufound: 12
hw.pagesize: 4096
hw.activecpu: 12
hw.availcpu: 12
hw.cpuspeed: 2000
hw.cpuspeedInMHz: 2000
hw.clockrate: 800000000
hw.machine: amd64"""
    f = open('/tmp/sysctl_output.txt', 'w')
    f.write(out)
    f.close()
    free_b_s_d_hardware_populate_0 = FreeBSDHardware()
    free_b_s_d_hardware_populate_0.module.run_command = lambda x, **kwargs: (0, out, '')
    free_b_s_d_

# Generated at 2022-06-24 22:05:22.377521
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Set up mock data to pass to the module
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, b'# dmidecode 3.0\n# SMBIOS entry point at 0xe3b3c000\nSMBIOS 2.8 present.', ''))
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value='/usr/sbin/dmidecode')

    # Set up context manager mock

# Generated at 2022-06-24 22:05:25.956070
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:05:28.992037
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    output = free_b_s_d_hardware.get_dmi_facts()
    assert output is not None


# Generated at 2022-06-24 22:05:35.815368
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value='/sbin/sysctl')
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'nada', '')
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:05:41.424912
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_get_cpu_facts_0 = free_b_s_d_hardware.get_cpu_facts()
    assert free_b_s_d_hardware_get_cpu_facts_0 == {}


# Generated at 2022-06-24 22:05:44.635379
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Setup
    testing_FreeBSDHardware = FreeBSDHardware()

    # Exercise
    result = testing_FreeBSDHardware.get_device_facts()

    # Verify
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:05:48.565710
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Provide mock object as a parameter
    free_b_s_d_hardware_0 = FreeBSDHardware()

    free_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:05:59.510925
# Unit test for method populate of class FreeBSDHardware

# Generated at 2022-06-24 22:06:08.978723
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    results = free_b_s_d_hardware_0.get_cpu_facts()
    assert results['processor_cores'] == '2', results['processor_cores']
    assert results['processor_count'] == '4', results['processor_count']
    assert results['processor'] == ['Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz', 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz', 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz', 'Intel(R) Xeon(R) CPU E5-2680 v2 @ 2.80GHz'], results['processor']


# Generated at 2022-06-24 22:06:13.976536
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert (free_b_s_d_hardware_0.get_uptime_facts() == {})


# Generated at 2022-06-24 22:07:43.389341
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Create instance of FreeBSDHardware class
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, "2", ""))
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value="/bin/sysctl")

# Generated at 2022-06-24 22:07:49.930550
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.get_bin_path = lambda x: None
    assert free_b_s_d_hardware_0.get_uptime_facts() == {}
    free_b_s_d_hardware_0.module.get_bin_path = lambda x: '/bin/sysctl'
    free_b_s_d_hardware_0.module.run_command = lambda x: (None, None, None)
    assert free_b_s_d_hardware_0.get_uptime_facts() == {}


if __name__ == '__main__':
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:08:00.514705
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = AnsibleModule(argument_spec=dict())
    sysctl_cmd_expected_value = "/sbin/sysctl"
    free_b_s_d_hardware.module.get_bin_path = MagicMock(return_value=sysctl_cmd_expected_value)
    rc_expected_value = 0
    cmd_expected_value = ["/sbin/sysctl", "-b", "kern.boottime"]
    out_expected_value = b"\x00\x00\x00\x00\x00\x00\x00\x00"
    err_expected_value = ""

# Generated at 2022-06-24 22:08:05.343481
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    facts = free_b_s_d_hardware_collector_0.collect()
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    for fact in facts:
        free_b_s_d_hardware_0.populate(fact)


# Generated at 2022-06-24 22:08:09.745536
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bsd_hardware = FreeBSDHardware()
    bsd_hardware.module = AnsibleModule(argument_spec={})
    out = bsd_hardware.get_uptime_facts()
    assert 'uptime_seconds' in out, 'Could not retrieve uptime_seconds'


# Generated at 2022-06-24 22:08:15.270796
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    f_b_hardware = FreeBSDHardware()
    f_b_hardware.module = AnsibleModule(argument_spec = dict())
    f_b_hardware.module.get_bin_path = MagicMock(return_value='sysctl')
    f_b_hardware.module.run_command = MagicMock(return_value=(1, '1', ''))
    a = f_b_hardware.get_cpu_facts()
    assert a == {'processor': [], 'processor_cores': None, 'processor_count': '1'}



# Generated at 2022-06-24 22:08:25.112711
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    test_timeout = 0.5

    # Mock methods
    def run_command(self, cmd, check_rc=True, encoding=None):
        test_output = b'kern.boottime: { sec = 1597090119, usec = 655901 }'
        return 0, test_output, ''

    # Test
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware._run_command = run_command
    # FIXME: why do we pass None and 0.5 as parameters to a method which
    # does not use them?
    assert int(free_b_s_d_hardware.get_uptime_facts(None, test_timeout)['uptime_seconds']) == 159866
