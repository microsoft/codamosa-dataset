

# Generated at 2022-06-24 21:58:51.077643
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_cpu_facts() == {
        'processor': [],
        'processor_cores': None,
        'processor_count': None,
    }


# Generated at 2022-06-24 21:58:54.084153
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    collected_facts = {}
    returned_facts = free_b_s_d_hardware_0.populate(collected_facts)
    assert returned_facts == {'devices': {}, 'mounts': [], 'memtotal_mb': 0}


# Generated at 2022-06-24 21:58:56.639203
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 21:58:58.004821
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_case_0()


# Generated at 2022-06-24 21:59:02.762537
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    subject = FreeBSDHardware()
    result = subject.get_memory_facts()
    assert result['memfree_mb'] > 0
    assert result['memtotal_mb'] > 0
    assert result['swapfree_mb'] == 0
    assert result['swaptotal_mb'] == 0


# Generated at 2022-06-24 21:59:13.240237
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    print('Testing constructor of FreeBSDHardwareCollector() class')

    # example of a console output
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    print(free_b_s_d_hardware_collector)

    # sample output of the constructor
    '''
        FreeBSDHardwareCollector(platform='FreeBSD',
                _fact_class=<class 'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware'>,
                _fact_subclasses=[])
    '''
    return

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 21:59:22.815006
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    """
    Test get_memory_facts of FreeBSDHardware
    """
    free_b_s_d_hardware = FreeBSDHardware()
    test_vars = {
        "sysctl": ""
    }
    module_returns = {
        "path": ("/sbin/sysctl", "vm.stats")
    }
    module_return_values = {
        "get_bin_path.return_value": test_vars["sysctl"],
        "run_command.return_value": ("", "", "")
    }
    free_b_s_d_hardware.module = MagicMock()

# Generated at 2022-06-24 21:59:27.584930
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_1.collect()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:37.725845
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create an instance of the FreeBSDHardware class.
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # The desired facts.

# Generated at 2022-06-24 21:59:47.909718
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    (free_b_s_d_hardware_0_get_cpu_facts, ) = free_b_s_d_hardware_0.get('processor')
    assert isinstance(free_b_s_d_hardware_0_get_cpu_facts, list)
    assert len(free_b_s_d_hardware_0_get_cpu_facts) == 1
    assert free_b_s_d_hardware_0_get_cpu_facts[0].startswith('Intel')


# Generated at 2022-06-24 22:00:06.897637
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0.platform == 'FreeBSD'

test_name_0 = "test_FreeBSDHardwareCollector"
test_name_0_passed = test_FreeBSDHardwareCollector()

if __name__ == '__main__':
    print("Running test cases:")
    test_case_0()
    print("Passed test cases:")
    print("test_case_0: " + str(test_name_0_passed))
    if test_name_0 == "test_case_0" and test_name_0_passed:
        print("All unit tests passed")

# Generated at 2022-06-24 22:00:08.093498
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:12.092554
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_1 = FreeBSDHardware()
    assert test_1.get_uptime_facts() == {'uptime_seconds': int(time.time() - 0)}

# Generated at 2022-06-24 22:00:23.223499
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Test with invalid path to sysctl
    test_module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    set_module_args(dict(
    ))

    test_free_b_s_d_hardware_0 = FreeBSDHardware(test_module_0)

    test_free_b_s_d_hardware_0.module = MagicMock()
    test_free_b_s_d_hardware_0.module.get_bin_path.return_value = None
    test_free_b_s_d_hardware_0.module.run_command.return_value = (0, '', '')

    test_get_uptime_facts_0 = test_free_b_s_d_hardware_0.get_uptime

# Generated at 2022-06-24 22:00:26.174999
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert(isinstance(free_b_s_d_hardware.get_device_facts(), dict))


# Generated at 2022-06-24 22:00:34.584143
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils.facts.timeout import TimeoutError

    bsd_hw = FreeBSDHardware()
    uptime_facts = bsd_hw.get_uptime_facts()
    assert uptime_facts
    # We can't really assert on uptime_seconds as that depends on how long
    # the test takes to run.
    assert uptime_facts.get('uptime_seconds', None)



# Generated at 2022-06-24 22:00:38.538262
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    return_value = free_b_s_d_hardware_0.get_dmi_facts()
    assert return_value is None



# Generated at 2022-06-24 22:00:42.185326
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:00:45.645278
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    assert free_b_s_d_hardware_0.populate() == {}


# Generated at 2022-06-24 22:00:48.066520
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    test_case_0()


# Generated at 2022-06-24 22:01:01.352690
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware.get_uptime_facts(), dict)


# Generated at 2022-06-24 22:01:06.491741
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    FreeBSD_hardware, collected_facts = test_case_0()
    assert FreeBSD_hardware.get_cpu_facts() == {'processor': ['Intel(R) Xeon(R) CPU E3-1270 V2 @ 3.50GHz'],
                                                'processor_cores': '4',
                                                'processor_count': '1'}


# Generated at 2022-06-24 22:01:10.595878
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None, collected_facts=None)
    try:
        free_b_s_d_hardware_0.get_dmi_facts()
    except Exception as exception_0:
        print(exception_0)

# Generated at 2022-06-24 22:01:14.701201
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    f_h = FreeBSDHardware()
    results = f_h.get_uptime_facts()
    assert results.keys() == {'uptime_seconds'}
    assert type(results['uptime_seconds']) == int


# Generated at 2022-06-24 22:01:21.408889
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # try exception raise by constructor FreeBSDHardwareCollector
    try:
        FreeBSDHardwareCollector()
        assert False, 'No exception'
    except Exception as e:
        assert type(e) == NotImplementedError, 'Incorrect exception type raised'
    # test attributes are initialized by constructor
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:01:22.907497
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:01:27.602446
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    module = AnsibleModule(
        argument_spec = dict(
            filter = dict(default='*', required=False),
            timeout = dict(default=10, required=False),
        ),
        supports_check_mode=True,
    )
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(module)
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:01:39.780612
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from unit.ansible_module.facts.hardware.test_FreeBSDHardware import free_b_s_d_hardware_0
    free_b_s_d_hardware_get_memory_facts_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert free_b_s_d_hardware_get_memory_facts_0['memtotal_mb'] == ''
    assert free_b_s_d_hardware_get_memory_facts_0['memfree_mb'] == ''
    assert free_b_s_d_hardware_get_memory_facts_0['swaptotal_mb'] == ''
    assert free_b_s_d_hardware_get_memory_facts_0['swapfree_mb'] == ''


# Generated at 2022-06-24 22:01:49.643546
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=('0', '0', '0'))
    free_b_s_d_hardware_0.module.fail_json = MagicMock()
    free_b_s_d_hardware_0.logger = logging.getLogger()
    free_b_s_d_hardware_0.logger.isEnabledFor = MagicMock(return_value=False)
    free_b_s_d_hardware_0.logger.warning = MagicMock()

    free_b_s_d_hardware_0.get_uptime_facts()
    free_b_s_d_hardware

# Generated at 2022-06-24 22:02:00.093784
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # The first parameter of get_memory_facts is "self", which is the class instance.
    # Since this is a hard-coded test case, just use a class instance as the first
    # parameter.
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # get_memory_facts is a protected method, so the class instance is constructed
    # with the name "_FreeBSDHardware__get_memory_facts".
    memory_facts = free_b_s_d_hardware_0._FreeBSDHardware__get_memory_facts()
    assert memory_facts.get('memtotal_mb') is not None
    assert memory_facts.get('memfree_mb') is not None
    assert memory_facts.get('swaptotal_mb') is not None

# Generated at 2022-06-24 22:02:25.497087
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_memory_facts() == {'memtotal_mb': 1490, 'memfree_mb': 1470, 'swapfree_mb': 2, 'swaptotal_mb': 2}



# Generated at 2022-06-24 22:02:35.963795
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # call populate of FreeBSDHardware

# Generated at 2022-06-24 22:02:38.124882
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    fact_freeb_s_d_h_0 = FreeBSDHardware()
    fact_freeb_s_d_h_0.get_memory_facts()


# Generated at 2022-06-24 22:02:40.481666
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_obj = FreeBSDHardwareCollector()

    test_obj.get_uptime_facts()

    return


# Generated at 2022-06-24 22:02:44.486530
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    mem_facts = FreeBSDHardware().get_memory_facts()

    assert "memfree_mb" and "memtotal_mb" and "swapfree_mb" and "swaptotal_mb" in mem_facts.keys()


# Generated at 2022-06-24 22:02:45.443599
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    pass


# Generated at 2022-06-24 22:02:48.213822
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)


# Generated at 2022-06-24 22:02:53.863380
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    print('Method: get_uptime_facts')
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    hardware_1 = FreeBSDHardware()
    hardware_1.module = MagicMock()
    hardware_1.module.get_bin_path.return_value = '/bin/sysctl'
    hardware_1.module.run_command.return_value = (0, b'kern.boottime: { sec = 1435108980, usec = 327038 }', '')
    expected = {'uptime_seconds': 3947}
    result = hardware_1.get_uptime_facts()
    assertEqual(result, expected)


# Generated at 2022-06-24 22:02:59.217890
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec={}
    )

    golden_parsed_json = {
        "uptime_seconds": int(time.time())
    }

    free_b_s_d_hardware = FreeBSDHardware(module)
    parsed_json = free_b_s_d_hardware.get_uptime_facts()

    assert parsed_json == golden_parsed_json


# Generated at 2022-06-24 22:03:07.778029
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    actual = free_b_s_d_hardware_0.get_memory_facts()
    ansible_hostname = "ctn1-ubuntu16-dev"
    ansible_memfree_mb = 116076
    ansible_memtotal_mb = 247896
    ansible_swapfree_mb = 0
    ansible_swaptotal_mb = 48559
    assert actual['memfree_mb'] >= ansible_memfree_mb
    assert actual['memtotal_mb'] >= ansible_memtotal_mb
    assert actual['swapfree_mb'] >= ansible_sw

# Generated at 2022-06-24 22:03:34.237690
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_1 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:03:39.939197
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:03:41.512981
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:03:49.418207
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    sysdir = '/dev'
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module.run_command = test_FreeBSDHardware_populate_0
    free_b_s_d_hardware_0.get_cpu_facts = test_FreeBSDHardware_populate_1
    free_b_s_d_hardware_0.get_memory_facts = test_FreeBSDHardware_populate_2
    free_b_s_d_hardware_0.get_uptime_facts = test_FreeBSDHardware_populate_3
    free_b_s_d_hardware_0.get_dmi_facts = test_Free

# Generated at 2022-06-24 22:03:53.670825
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = ' qz'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_1 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:01.500216
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    with open('test_data/1/output_0.json', 'r') as data_file:
        data = json.load(data_file)
    free_b_s_d_hardware_0 = FreeBSDHardware(data)
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.run_command.return_value = (0, '', '')
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:04:08.435970
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
  # Create an instance of class FreeBSDHardwareCollector
  free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
  # Assert the type of the return value of constructor of class FreeBSDHardwareCollector is equal to instance of class FreeBSDHardwareCollector
  if not isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector):
    raise Exception("expected type for argument 'free_b_s_d_hardware_collector_0' is instance of class FreeBSDHardwareCollector")

# Generated at 2022-06-24 22:04:10.585788
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '*j!m0Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:17.369788
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '(KY2d<>+-f/'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = {'processor_count': '6'}
    var_1 = {'swaptotal_mb': 1}
    var_2 = {'memfree_mb': 0}
    var_3 = {'memtotal_mb': 0}

# Generated at 2022-06-24 22:04:19.631010
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    with pytest.raises(Exception):
        # The exception is raised in the base class HardwareCollector.
        # The constructor of the base class raises this exception.
        free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:05:47.698446
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    arg0 = 'P\\1DO>iB?\r-9'
    obj = FreeBSDHardwareCollector(arg0)
    assert obj is not None

# Generated at 2022-06-24 22:05:51.571925
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    collect = FreeBSDHardwareCollector()
    facts = collect.collect(module=None)

    assert 'memfree_mb' in facts
    assert 'memtotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'swaptotal_mb' in facts


# Generated at 2022-06-24 22:05:57.089835
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    print(var_0)


# Generated at 2022-06-24 22:06:00.361319
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Setup of variables
    var_1 = '--version'

    # Testing of function get_platform
    var_2 = FreeBSDHardwareCollector.get_platform()
    assert var_2 == var_1

# Local test case for class FreeBSDHardware

# Generated at 2022-06-24 22:06:08.465964
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = '#!/usr/bin/python'
    f_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)
    str_1 = ' P\\1DO>iB?\r-9'
    f_b_s_d_hardware_collector_0.populate(str_1)
    str_2 = '<3'
    var_0 = f_b_s_d_hardware_collector_0.populate(str_2)


# Generated at 2022-06-24 22:06:14.944426
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:19.488967
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:24.957153
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:32.950653
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test a simple call to sysctl
    sysctl = 'sysctl'
    test_out = 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 1048576\nvm.stats.vm.v_free_count: 20929\n'
    test_err = ''

    def mock_run_command(self, cmd, checkrc=True):
        return 0, test_out, test_err
    test_module = type('', (), dict(run_command=mock_run_command))
    test_facts = FreeBSDHardware(test_module)
    result = test_facts.get_memory_facts()
    expected = {'memtotal_mb': 1024, 'memfree_mb': 20}


# Generated at 2022-06-24 22:06:40.935507
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_1 = ' P\\1DO>iB?\r-9'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.populate()
    if str(var_1) == '{}':
        print('Test unit for method populate of class FreeBSDHardware ' +
              'succeeded')
    else:
        print('Test unit for method populate of class FreeBSDHardware ' +
              'failed')
