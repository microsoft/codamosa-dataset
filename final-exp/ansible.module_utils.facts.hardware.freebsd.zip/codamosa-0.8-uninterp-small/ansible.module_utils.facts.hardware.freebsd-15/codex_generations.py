

# Generated at 2022-06-24 21:58:50.137982
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    with pytest.raises(TypeError) as excinfo:
        FreeBSDHardwareCollector(0)
    assert excinfo.value.args[0] == "__init__() missing 1 required positional argument: 'module'"

# Generated at 2022-06-24 21:58:53.066694
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    output=free_b_s_d_hardware.get_dmi_facts()
    assert output['product_name'] == 'NA'


# Generated at 2022-06-24 21:59:04.529725
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_total_mb_value = '172030'
    mem_free_mb_value = '114932'
    sysctl_value = mem_total_mb_value + ' ' + mem_free_mb_value
    free_b_s_d_hardware_0 = FreeBSDHardware(module=AnsibleModule(argument_spec=dict(
        gather_subset=dict(default=['!all'], type='list')
    )))
    setattr(free_b_s_d_hardware_0, 'sysctl', lambda x: (0, sysctl_value, ''))
    free_b_s_d_hardware_0._collect()
    val = free_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 21:59:07.420559
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:59:09.471166
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector() is not None


# Generated at 2022-06-24 21:59:19.328432
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsdhardware = FreeBSDHardware()
    freebsdhardware.module.run_command = MagicMock()
    freebsdhardware.module.run_command.return_value = (0, "vm.stats.vm.v_page_size:     4096\nvm.stats.vm.v_page_count: 6291456\nvm.stats.vm.v_free_count:   5323024", "")
    memory_facts = freebsdhardware.get_memory_facts()
    assert memory_facts == {
        'memtotal_mb': 24576,
        'memfree_mb': 20984
    }


# Generated at 2022-06-24 21:59:21.339420
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.populate()


# Generated at 2022-06-24 21:59:25.800779
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''test get dmi facts from system'''
    free_b_s_d_hardware = FreeBSDHardwareCollector()
    # self.free_b_s_d_hardware.get_dmi_facts
    assert free_b_s_d_hardware is not None


# Generated at 2022-06-24 21:59:27.277096
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    try:
        test_case_0()
    except AttributeError:
        print("Failed to construct the class!")
    else:
        print("Passed")


# Generated at 2022-06-24 21:59:33.363899
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module = AnsibleModule(argument_spec={})

    if not HAS_PEXPECT:
        module.fail_json(msg='pexpect is required for this module')

    free_b_s_d_hardware = FreeBSDHardware(module)

    # Get the CPU facts.
    free_b_s_d_hardware_get_cpu_facts = free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:00:01.050805
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    param = {}
    ret = FreeBSDHardware().get_cpu_facts()
    assert isinstance(ret, dict)
    assert True if ret else False


# Generated at 2022-06-24 22:00:04.172258
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 22:00:08.639096
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert free_b_s_d_hardware.get_cpu_facts() == {'processor': [], 'processor_cores': '1', 'processor_count': '1'}


# Generated at 2022-06-24 22:00:13.780885
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule(argument_spec=dict())
    free_b_s_d_hardware_0.module.get_bin_path = Mock(return_value='/bin')
    free_b_s_d_hardware_0.module.run_command = Mock(return_value=('','',''))
    assert free_b_s_d_hardware_0.get_dmi_facts() == {}


# Generated at 2022-06-24 22:00:24.702589
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    ## FreeBSDHardware module
    module_0 = AnsibleModule(
        argument_spec = dict()
    )

    ## FreeBSDHardware class
    freebsd_hardware_0 = FreeBSDHardware(module_0)

    ## get_cpu_facts method
    cpu_facts_0 = freebsd_hardware_0.get_cpu_facts()

    ## get_memory_facts method
    memory_facts_0 = freebsd_hardware_0.get_memory_facts()

    ## get_uptime_facts method
    uptime_facts_0 = freebsd_hardware_0.get_uptime_facts()

    ## get_dmi_facts method
    dmi_facts_0 = freebsd_hardware_0.get_dmi_facts()

    ## get_device_facts method
    device_facts_

# Generated at 2022-06-24 22:00:29.541884
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=AnsibleModule(
        argument_spec={
        }
    ))
    free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:00:31.173342
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Test with no arguments
    test_case_0()

# Generated at 2022-06-24 22:00:33.191378
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_00 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:38.811406
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    '''
    Unit test for method get_dmi_facts of class FreeBSDHardware
    Unit test to assert the return value of method get_dmi_facts is non empty
    '''
    free_b_s_d_hardware = FreeBSDHardware()
    response = free_b_s_d_hardware.get_dmi_facts()
    assert response is not ""


# Generated at 2022-06-24 22:00:45.694537
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    free_b_s_d_hardware_1 = FreeBSDHardware({})
    return_value_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert return_value_0.get('memtotal_mb') == free_b_s_d_hardware_1.get_memory_facts().get('memtotal_mb')


# Generated at 2022-06-24 22:01:12.418492
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Get output from method and test it.
    assert free_b_s_d_hardware_0.get_memory_facts() != None


# Generated at 2022-06-24 22:01:17.395319
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    file_content = '{"uptime_seconds": 43}'
    with open('FreeBSDHardware_get_uptime_facts_0.json', 'w') as f:
        f.write(file_content)



# Generated at 2022-06-24 22:01:25.987825
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModuleFake(
        params={},
        check_mode=False,
    )
    # Test 1
    returned_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert returned_0 == {
        'processor': ['Intel(R) Core(TM) i7-6500U CPU @ 2.50GHz'],
        'processor_cores': '2',
        'processor_count': '2',
    }
    # Test 2
    free_b_s_d_hardware_0.module = AnsibleModuleFake(
        params={},
        check_mode=False,
    )
    free_b_s_d_hard

# Generated at 2022-06-24 22:01:38.242623
# Unit test for method get_uptime_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:01:42.945645
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    '''test of FreeBSDHardware.get_uptime_facts'''

    # Initialize FreeBSDHardware object
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Execute method 'get_uptime_facts'
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:46.672274
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_get_uptime_facts_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:48.723527
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert (test_case_0()) == None, "test_case_0 failed."
# END test FreeBSDHardwareCollector


# Generated at 2022-06-24 22:01:52.553011
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # Instantiate a class FreeBSDHardware
    free_b_s_d_hardware_0 = FreeBSDHardwareCollector._fact_class(None)

    # Test if a exception is raised
    with pytest.raises(Exception):
        free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:04.701723
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freeBSD_hardware_event = FreeBSDHardware()
    freeBSD_hardware_event.module = get_module_mock()
    freeBSD_hardware_event.module.run_command.return_value = (0, 'hw.ncpu: 1', '')
    freeBSD_hardware_event.module.get_bin_path.return_value = '/usr/bin/sysctl'
    result = freeBSD_hardware_event.get_cpu_facts()
    assert result.get('processor_count', '') == '1'
    assert result.get('processor', '')  == ['CPU: Intel(R) Xeon(R) CPU E5-2620 v3 @ 2.40GHz']
    assert result.get('processor_cores', '')  == '1'
    freeBSD_hardware_event.module.run

# Generated at 2022-06-24 22:02:07.447931
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    return_value = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:34.033985
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # pylint: disable=protected-access
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0._populate(collected_facts={})


# Generated at 2022-06-24 22:02:36.830312
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    print("Testing get_dmi_facts of class FreeBSDHardware")
    module = AnsibleModule(
        argument_spec={},
        supports_check_mode=False)
    free_b_s_d_hardware_0 = FreeBSDHardware(module)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:38.730342
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 22:02:41.213571
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    return_value = free_b_s_d_hardware_0.get_memory_facts()
    assert return_value is not None


# Generated at 2022-06-24 22:02:44.294070
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True,
    )
    return_value = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:54.080762
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware(module=None)

# Generated at 2022-06-24 22:03:02.605156
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    class DummyModule(object):
        def get_bin_path(self, cmd):
            dummy_bin_path = 'sysctl'

            return dummy_bin_path

        def run_command(self, cmd, check_rc=True):
            dummy_class_out = '''hw.ncpu: 8
hw.ncpuonline: 8
hw.model: Intel(R) Core(TM) i5-4210U CPU @ 1.70GHz
hw.cpuspeed: 1700
hw.physmem: 17086615552
hw.usermem: 15273787392
hw.pagesize: 4096
hw.realmem: 17179869184
hw.availcpu: 8
hw.cpuspeed: 1700
hw.cpuspeed: 1700
hw.cpuspeed: 1700
hw.cpuspeed: 1700'''

           

# Generated at 2022-06-24 22:03:10.362527
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    CPU_FACTS_RESULT = [
        'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz',
        'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz',
        'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz',
        'Intel(R) Core(TM) i5-4278U CPU @ 2.60GHz',
    ]

    free_b_s_d_hardware_0 = FreeBSDHardware()
    FREE_BSD_HARDWARE_GET_CPU_FACTS = free_b_s_d_hardware_0.get_cpu_facts()
    assert FREE_BSD_HARDWARE_GET_CPU_FACTS['processor'] == CPU_FACTS_RESULT
    assert FREE

# Generated at 2022-06-24 22:03:13.230849
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # test direct pass through
    free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:03:20.773608
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_get_uptime_facts = FreeBSDHardware()
    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format='@L'
    struct_size=struct.calcsize(struct_format)
    free_b_s_d_hardware_get_uptime_facts_out=free_b_s_d_hardware_get_uptime_facts.get_uptime_facts()
    assert len(free_b_s_d_hardware_get_uptime_facts_out['uptime_seconds']) >= struct_size

# Generated at 2022-06-24 22:03:48.269431
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    assert free_b_s_d_hardware_0.get_cpu_facts() == None
    assert free_b_s_d_hardware_0.get_cpu_facts() == None


# Generated at 2022-06-24 22:03:50.918386
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:53.590806
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert type(var_0) == dict

# Generated at 2022-06-24 22:03:56.220283
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_0 = False
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(bool_0)
    var_0 = free_b_s_d_hardware_collector_0.fact_class()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:04:00.826201
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_1 = False
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(bool_1)
    print(free_b_s_d_hardware_collector_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:04:02.919209
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    devices_0 = FreeBSDHardware.get_device_facts()


# Generated at 2022-06-24 22:04:03.857046
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_case_0()


# Generated at 2022-06-24 22:04:06.589547
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test = """
    FreeBSDHardware(None).populate()
    """
    assert str(test) == ""


# Generated at 2022-06-24 22:04:10.064874
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    var_1 = free_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:04:12.253853
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_0 = False
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(None, None, bool_0)


# Generated at 2022-06-24 22:05:47.687891
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_0 = False
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(bool_0)
    var_0 = free_b_s_d_hardware_collector_0.get_device_facts()
    var_1 = free_b_s_d_hardware_collector_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:51.578588
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    collected_facts_0 = dict()
    var_0 = free_b_s_d_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 22:05:58.630645
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    free_b_s_d_hardware_0.module = ansible_fake
    with pytest.raises(AnsibleError) as ansible_error:
        free_b_s_d_hardware_0.get_cpu_facts()
    assert ansible_error.value.args[0] == "test error"


# Generated at 2022-06-24 22:06:06.825669
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    # Create a test module
    module_args = {}
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=False
    )

    # Create a test class
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)

    # Learn the facts
    free_b_s_d_hardware_0.populate(module)
    free_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:06:10.952786
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    d = free_b_s_d_hardware_0.get_uptime_facts()
    var_0 = d['uptime_seconds']



# Generated at 2022-06-24 22:06:14.150872
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:06:15.061650
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_case_0()


# Generated at 2022-06-24 22:06:17.480083
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = FreeBSDHardware(False)
    var_1 = var_0.get_uptime_facts()

# Generated at 2022-06-24 22:06:21.664804
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:23.594265
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    print('Please test it manually')
