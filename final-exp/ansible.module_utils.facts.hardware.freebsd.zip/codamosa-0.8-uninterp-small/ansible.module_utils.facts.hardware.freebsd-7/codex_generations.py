

# Generated at 2022-06-24 21:58:49.520844
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    print('Test getting CPU facts')
    free_b_s_d_hardware_0 = FreeBSDHardware()
    result = free_b_s_d_hardware_0.get_cpu_facts()
    print(result)


# Generated at 2022-06-24 21:58:58.577888
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import platform
    from ansible.module_utils.facts.collector import Collector, TestSetup
    from ansible.module_utils._text import to_bytes

    if platform.system() == 'FreeBSD':
        """ Test the FreeBSD get_memory_facts method which
        contains assertions for the following conditions:
        - sysctl and swapinfo binaries exist
        """
        collector = Collector()
        setup = TestSetup(collector, "FreeBSD")
        free_b_s_d_hardware = FreeBSDHardware(setup.get_module_args())
        free_b_s_d_hardware.populate()


# Generated at 2022-06-24 21:59:01.911993
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector is not None, 'Failed to instantiate FreeBSDHardwareCollector'

if __name__ == '__main__':
    test_case_0()
    print('Test case 0 passed')

# Generated at 2022-06-24 21:59:05.481446
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware.get_device_facts(), dict) is True


# Generated at 2022-06-24 21:59:16.547152
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    assert free_b_s_d_hardware_0.module.run_command.called is False
    assert free_b_s_d_hardware_0.get_cpu_facts() == {
        'processor': [
            'AMD64 Family 16 Model 6 Stepping 3, AuthenticAMD',
            'AMD64 Family 16 Model 6 Stepping 3, AuthenticAMD',
            'AMD64 Family 16 Model 6 Stepping 3, AuthenticAMD',
            'AMD64 Family 16 Model 6 Stepping 3, AuthenticAMD'
        ],
        'processor_cores': '2',
        'processor_count': '4'
    }


# Generated at 2022-06-24 21:59:24.970763
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, " ", ""))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, " ", ""))
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value="/usr/bin/free")
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, " ", ""))

# Generated at 2022-06-24 21:59:30.714483
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=AnsibleModuleStub())

    # Testing when all required args are present
    free_b_s_d_hardware_0._dmi_facts = None

    free_b_s_d_hardware_0.get_dmi_facts()

    assert free_b_s_d_hardware_0._dmi_facts is None


# Generated at 2022-06-24 21:59:33.917855
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
  free_b_s_d_hardware_0 = FreeBSDHardware()
  free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:37.554918
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert (free_b_s_d_hardware_0.get_device_facts() == {})


# Generated at 2022-06-24 21:59:41.553565
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0._fact_class is FreeBSDHardware
    assert free_b_s_d_hardware_collector_0._platform is 'FreeBSD'


# Generated at 2022-06-24 22:00:02.104615
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(0, 0)
    free_b_s_d_hardware_1 = FreeBSDHardware(0, 0)
    free_b_s_d_hardware_2 = FreeBSDHardware(0, 0)
    var_0 = free_b_s_d_hardware_1.get_dmi_facts()
    var_1 = free_b_s_d_hardware_2.get_dmi_facts()
    var_2 = free_b_s_d_hardware_0.get_dmi_facts()
    var_3 = free_b_s_d_hardware_1.get_dmi_facts()
    var_4 = free_b_s_d_hardware_0.get_dmi_facts()
    var_

# Generated at 2022-06-24 22:00:05.381935
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:08.725548
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    int_0 = 9005
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(int_0,int_0)
    assert free_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware
    assert free_b_s_d_hardware_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-24 22:00:20.584668
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    free_b_s_d_hardware_0.get_cpu_facts = () # TODO: implement this
    free_b_s_d_hardware_0.get_memory_facts = () # TODO: implement this
    free_b_s_d_hardware_0.get_uptime_facts = () # TODO: implement this
    free_b_s_d_hardware_0.get_dmi_facts = () # TODO: implement this
    free_b_s_d_hardware_0.get_device_facts = () # TODO: implement this
    free_b_s_d_hardware_0.get_mount_facts = () # TODO

# Generated at 2022-06-24 22:00:32.455325
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    free_b_s_d_hardware_0 = FreeBSDHardware(9000,9000)

    int_0 = 9000
    free_b_s_d_hardware_0.module = int_0
    # str_0 = 'swapinfo'
    # var_0 = free_b_s_d_hardware_0.module.get_bin_path(str_0)
    # str_1 = '-k'
    # str_2 = '%s %s' % ()
    # int_1 = 9000
    # var_1 = free_b_s_d_hardware_0.module.run_command(str_2, int_1)
    # free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:36.131238
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 10
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:39.889270
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    if sys.platform != 'darwin':
        free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:43.528391
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:47.861653
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:51.938734
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = 9000
    int_1 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_1)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:18.056487
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:20.068615
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    arg_0 = 9000
    test_case_0()


# Generated at 2022-06-24 22:01:22.949151
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:27.401893
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    try:
        var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    except NameError:
        var_0 = None
    except Exception:
        var_0 = None
    assert var_0 == None


# Generated at 2022-06-24 22:01:30.647135
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:34.317628
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert not FreeBSDHardware.get_dmi_facts.__dict__.get('__doc__') is None
    assert False


# Generated at 2022-06-24 22:01:45.140031
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 9000
    p_1_0 = 9000
    time_0 = time.time()
    time_1 = time.time()
    time_2 = time.time()
    time_3 = time.time()
    time_4 = time.time()
    time_5 = time.time()
    time_6 = time.time()
    time_7 = time.time()
    time_8 = time.time()
    time_9 = time.time()
    time_10 = time.time()
    time_11 = time.time()
    time_12 = time.time()
    time_13 = time.time()
    time_14 = time.time()
    str_0 = str(time.time())
    str_0 = str_0.replace(".", "")
    str_0 = str

# Generated at 2022-06-24 22:01:46.160675
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_case_0()



# Generated at 2022-06-24 22:01:49.295880
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:01:52.451772
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 9000
    free_b_s_d_hardware_1 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:02:43.185943
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    int_0 = 9000
    int_1 = 9000
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(int_0, int_1)


# Generated at 2022-06-24 22:02:47.458408
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Instantiate class FreeBSDHardwareCollector
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    # Assigning values to parameters of function collect
    ansible_facts = None
    collected_facts = free_b_s_d_hardware_collector_0.collect(ansible_facts)


# Generated at 2022-06-24 22:02:55.561384
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    free_b_s_d_hardware_0.module = mock()
    free_b_s_d_hardware_0.module.get_bin_path = Mock(return_value='sysctl')
    free_b_s_d_hardware_0.module.run_command = Mock(return_value=(0, 'hw.ncpu: 1', ''))
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:58.960922
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()




# Generated at 2022-06-24 22:03:07.508937
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Implicit condition: if sysctl:
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
    # Implicit condition: if sysctl:
   

# Generated at 2022-06-24 22:03:17.494428
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/sbin/dmidecode'

# Generated at 2022-06-24 22:03:23.017946
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = None
    var_1 = free_b_s_d_hardware_0.get_dmi_facts(var_0)


# Generated at 2022-06-24 22:03:26.489206
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:30.171202
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    (unused, unused, unused) = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:03:31.322532
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    assert True


# Generated at 2022-06-24 22:05:20.651321
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:25.140517
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:31.260909
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_collector_0.collect() 
    assert free_b_s_d_hardware_collector_0._fact_class is FreeBSDHardware
    assert free_b_s_d_hardware_collector_0._platform is 'FreeBSD'

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:05:33.881137
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0 is not None


# Generated at 2022-06-24 22:05:45.697096
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    swap_free_mb = {}
    swap_free_mb['swapfree_mb'] = -1
    swap_total_mb = {}
    swap_total_mb['swaptotal_mb'] = -1
    mem_free_mb = {}
    mem_free_mb['memfree_mb'] = -1
    mem_total_mb = {}
    mem_total_mb['memtotal_mb'] = -1
    expected = {}
    expected.update(swap_free_mb)
    expected.update(swap_total_mb)
    expected.update(mem_free_mb)
    expected.update(mem_total_mb)
    free_b_s_d_hardware_1 = mock.Mock(FreeBSDHardware)
    free_b_s_d_hardware_1.get_memory_

# Generated at 2022-06-24 22:05:53.043234
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # TODO: make this test more complete
    (id_1, wc_0) = test_case_0()
    var_1 = wc_0.populate()
    assert len(var_1) > 0
    assert 'processor' in var_1
    assert 'processor_cores' in var_1
    assert 'processor_count' in var_1
    assert 'memtotal_mb' in var_1
    assert 'memfree_mb' in var_1
    assert 'swaptotal_mb' in var_1
    assert 'swapfree_mb' in var_1
    assert 'devices' in var_1
    assert 'uptime_seconds' in var_1

# Generated at 2022-06-24 22:05:55.783522
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(int, int)


# Generated at 2022-06-24 22:05:56.889759
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert True


# Generated at 2022-06-24 22:06:02.546825
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:06.329632
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 9000
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0, int_0)
    free_b_s_d_hardware_0.get_dmi_facts()
