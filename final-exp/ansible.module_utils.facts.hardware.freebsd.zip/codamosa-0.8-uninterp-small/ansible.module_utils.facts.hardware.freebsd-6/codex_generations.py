

# Generated at 2022-06-24 21:58:53.355675
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    if not hasattr(free_b_s_d_hardware_0, 'get_cpu_facts'):
        return
    if not hasattr(free_b_s_d_hardware_0, '_get_cpu_facts'):
        return

    free_b_s_d_hardware_0._get_cpu_facts()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:58:58.917588
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_bsd_hardware_0 = FreeBSDHardware()
    res = free_bsd_hardware_0.get_uptime_facts()
    if isinstance(res, dict):
        print("type is right and value is:")
        print(res)
    else:
        print("type is wrong, type is %s" % (type(res)))


# Generated at 2022-06-24 21:59:06.936706
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_get_cpu_facts = free_b_s_d_hardware.get_cpu_facts()
    assert 'processor_count' in free_b_s_d_hardware_get_cpu_facts
    assert 'processor' in free_b_s_d_hardware_get_cpu_facts
    assert 'processor_cores' in free_b_s_d_hardware_get_cpu_facts


# Generated at 2022-06-24 21:59:09.866642
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    new_FreeBSDHardware = FreeBSDHardware()
    assert new_FreeBSDHardware.get_cpu_facts() is None


# Generated at 2022-06-24 21:59:13.011357
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 21:59:20.905317
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.params = {}
    module.run_command = MagicMock(return_value=(0, '', '', '', ''))
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = module
    actual_output = free_b_s_d_hardware.get_uptime_facts()
    assert actual_output == {'uptime_seconds': 0}

# Generated at 2022-06-24 21:59:25.853214
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    print("Testing FreeBSDHardware.populate()")
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_populate_1 = free_b_s_d_hardware.populate()
    assert free_b_s_d_hardware_populate_1


# Generated at 2022-06-24 21:59:32.196605
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/bin/sysctl'
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'vm.stats.vm.v_page_size = 4096 vm.stats.vm.v_page_count = 2874709 vm.stats.vm.v_free_count = 1642410', '')
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/sbin/swapinfo'

# Generated at 2022-06-24 21:59:35.813656
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_obj_0 = FreeBSDHardware()
    return_value = free_b_s_d_hardware_obj_0.get_memory_facts()
    assert return_value is None


# Generated at 2022-06-24 21:59:38.771512
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    f_b_s_d_hardware_0 = FreeBSDHardware()
    return_value_1 = f_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:00.573169
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:03.252412
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0._fact_class()
    free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:00:08.027167
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert (free_b_s_d_hardware.get_cpu_facts() == {'processor': [], 'processorCount': 0})


# Generated at 2022-06-24 22:00:13.473307
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    return free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:14.670623
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_case_0()

# Generated at 2022-06-24 22:00:16.815919
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:00:20.244780
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    object_1 = free_b_s_d_hardware_collector
    assert object_1.platform == "FreeBSD"


# Generated at 2022-06-24 22:00:25.572129
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    freebsd_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    result = freebsd_hardware_0.get_uptime_facts()
    assert result['uptime_seconds'] == 0


# Generated at 2022-06-24 22:00:30.069483
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=None)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:39.202809
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=AnsibleModule(argument_spec={}))
    free_b_s_d_hardware_0.sysctl = '/usr/sbin/sysctl'
    free_b_s_d_hardware_0.swapinfo = '/usr/sbin/swapinfo'
    assert free_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': 7838, 'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 7968}


# Generated at 2022-06-24 22:01:01.496259
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():


    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:09.560798
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    print('Testing get_dmi_facts')
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = get_module()
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    free_b_s_d_hardware_collector._module = get_module(load_fixtures = True)
    assert_equal(free_b_s_d_hardware.get_dmi_facts(), free_b_s_d_hardware_collector._get_dmi_facts())


# Generated at 2022-06-24 22:01:12.519732
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_dmi_facts() == {}



# Generated at 2022-06-24 22:01:17.820884
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Create an instance of class FreeBSDHardware
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Call method get_memory_facts of FreeBSDHardware
    results = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:20.904420
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:01:27.017646
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    freebsd_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    freebsd_hardware_0.module.run_command = Mock(return_value=(0, 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 5581440\nvm.stats.vm.v_free_count: 1969872', ''))
    freebsd_hardware_0.get_memory_facts()
    assert freebsd_hardware_0.module.run_command.called


# Generated at 2022-06-24 22:01:30.258321
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:01:34.443287
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:01:40.753937
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    cpu_facts = free_b_s_d_hardware_0.get_cpu_facts()
    assert (cpu_facts is not None)
    assert (cpu_facts['processor'] is not None)
    assert (cpu_facts['processor_cores'] is not None)
    assert (cpu_facts['processor_count'] is not None)


# Generated at 2022-06-24 22:01:50.538980
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_obj_0 = FreeBSDHardware()
    free_b_s_d_hardware_0_memtotal_mb = free_b_s_d_hardware_obj_0.get_memory_facts()['memtotal_mb']
    free_b_s_d_hardware_0_memfree_mb = free_b_s_d_hardware_obj_0.get_memory_facts()['memfree_mb']
    free_b_s_d_hardware_0_swaptotal_mb = free_b_s_d_hardware_obj_0.get_memory_facts()['swaptotal_mb']
    free_b_s_d_hardware_0_swapfree_mb = free_b_s_d_hardware_obj_0.get

# Generated at 2022-06-24 22:02:17.936539
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Create a fake module object to pass to the fact module.
    class MockModule:
        def fail_json(exit_json):
            ''' This method does not actually exist. '''
            pass

        def get_bin_path(binary):
            if binary == 'sysctl':
                return './bin/sysctl'
            else:
                return './bin/not_sysctl'

        def run_command(cmd, encoding=None):
            if cmd == ['./bin/sysctl', '-b', 'kern.boottime']:
                return 0, '1234', ''
            else:
                return 1, 'poutine', ''

    free_b_s_d_hardware_0 = FreeBSDHardware(module=MockModule())

    expected_results = {
        'uptime_seconds': 1234
    }

# Generated at 2022-06-24 22:02:27.450242
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = AnsibleModule
    free_b_s_d_hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware.module.run_command.return_value = (0, 'hw.ncpu: 1', '')
    free_b_s_d_hardware.module.get_bin_path = MagicMock(return_value='')
    free_b_s_d_hardware.module.get_bin_path.return_value = 'sysctl'
    free_b_s_d_hardware.module.run_command = MagicMock(return_value=(0, '', ''))
    free_

# Generated at 2022-06-24 22:02:30.727385
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:39.522072
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    m = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    fb_hardware = FreeBSDHardware(
        module = m
    )

    result = fb_hardware.get_dmi_facts()

    assert result.keys().index("bios_date") > -1, "Failed to find bios_date in get_dmi_facts"
    assert result.keys().index("bios_vendor") > -1, "Failed to find bios_vendor in get_dmi_facts"
    assert result.keys().index("bios_version") > -1, "Failed to find bios_version in get_dmi_facts"

# Generated at 2022-06-24 22:02:44.031446
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    freebsd_hardware = FreeBSDHardware()
    # Test 1: default
    uptime_facts = freebsd_hardware.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] >= 0



# Generated at 2022-06-24 22:02:49.357055
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(argument_spec={})
    module.run_command = MagicMock(return_value=(0, struct.pack('@L', int(time.time() - 100)), None))
    free_b_s_d_hardware = FreeBSDHardware(module)
    result = free_b_s_d_hardware.get_uptime_facts()
    assert result == {'uptime_seconds': 100}


# Generated at 2022-06-24 22:02:51.980875
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=get_module())
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:58.009633
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # test get_cpu_facts
    # No logic in get_cpu_facts, so nothing to test, but we need to call it to get coverage
    # TODO: write a test that covers this code
    free_b_s_d_hardware_free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:03:01.423130
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_facts = free_b_s_d_hardware.populate()
    assert 'uptime_seconds' in free_b_s_d_hardware_facts


# Generated at 2022-06-24 22:03:04.156484
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # 0
    free_b_s_d_hardware = FreeBSDHardware()
    #assert not free_b_s_d_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:03:31.165401
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.module = AnsibleModule(argument_spec=dict(gather_subset=dict(default=[], type='list')))


# Generated at 2022-06-24 22:03:37.154076
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    import platform

# Generated at 2022-06-24 22:03:48.465330
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_module = AnsibleModule(argument_spec={
        'collect_timeout': {'type': 'int', 'default': 10},
    })
    test_module.params.update({
        'collect_timeout': 10,
    })
    test_free_b_s_d_hardware = FreeBSDHardware(module=test_module)
    test_free_b_s_d_hardware._module.get_bin_path = MagicMock(return_value='/usr/bin/sysctl')
    test_free_b_s_d_hardware._module.run_command = MagicMock(return_value=(0, r'dummy', ''))
    test_free_b_s_d_hardware._module.run_command.return_value = (0, struct.pack('@L', 1504288665), '')

# Generated at 2022-06-24 22:03:50.458439
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:03:54.975136
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Unit test for method get_cpu_facts of class FreeBSDHardware"""
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0 = test_case_0()

    cpu_facts = free_b_s_d_hardware_0.get_cpu_facts()
    assert type(cpu_facts) == type({})
    assert cpu_facts['processor'] == []
    assert cpu_facts['processor_count'] == '1'


# Generated at 2022-06-24 22:03:57.654669
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    cpu_facts = dict()
    cpu_facts['processor'] = ["AMD Athlon(tm) 64 Processor 3000+"]
    cpu_facts['processor_count'] = "1"
    cpu_facts['processor_cores'] = "1"

    assert cpu_facts == free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:03:58.673576
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    fun_facts_device_facts_0 = FreeBSDHardware.get_device_facts()


# Generated at 2022-06-24 22:04:01.019752
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:06.927884
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Create a new class and run test
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_get_dmi_facts_result = free_b_s_d_hardware.get_dmi_facts()
    assert free_b_s_d_hardware_get_dmi_facts_result is not None

# Generated at 2022-06-24 22:04:09.436495
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert FreeBSDHardware.get_memory_facts() == {'memfree_mb': 'NA', 'memtotal_mb': 'NA', 'swapfree_mb': 'NA', 'swaptotal_mb': 'NA'}


# Generated at 2022-06-24 22:04:43.111082
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0.__class__ == dict



# Generated at 2022-06-24 22:04:45.163118
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    result_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert result_0 is None

# Generated at 2022-06-24 22:04:49.360273
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert free_b_s_d_hardware_0.get_cpu_facts() == var_0


# Generated at 2022-06-24 22:04:53.462903
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
#    assert(free_b_s_d_hardware_0.get_uptime_facts() == )
    pass


# Generated at 2022-06-24 22:05:00.304530
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:08.036399
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()

    assert ( var_0.get('swapfree_mb') == 4 * 1024 * 1024 )
    assert ( var_0.get('swaptotal_mb') == 4 * 1024 * 1024 )
    assert ( var_0.get('memfree_mb') == 1024 * 1024 )
    assert ( var_0.get('memtotal_mb') == 4 * 1024 * 1024 )


# Generated at 2022-06-24 22:05:09.525046
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    pass


# Generated at 2022-06-24 22:05:12.999053
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:15.372680
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # default constructor
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


if __name__ == '__main__':
    test_case_0()

# Generated at 2022-06-24 22:05:18.734070
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    mem = free_b_s_d_hardware_0.get_memory_facts()
    print(mem)


# Generated at 2022-06-24 22:06:50.003171
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dict_0 = {}
    module = AnsibleModule(argument_spec=dict_0)
    module.params = dict_0
    free_b_s_d_hardware_0 = FreeBSDHardware(module)

    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:53.427206
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:06:57.468984
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    memory_facts = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:07:01.219679
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:07:08.277805
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    dict_0 = {}
    free_b_s_d_hardware_2 = FreeBSDHardware(dict_0)
    free_b_s_d_hardware_2.module.run_command = Mock(return_value=(0, '256525415 256525415\n', ''))
    dict_1 = {}
    dict_1['time'] = 256525415
    dict_1['uptime'] = 256525415
    assert free_b_s_d_hardware_2.get_uptime_facts() == dict_1



# Generated at 2022-06-24 22:07:11.672369
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    dictionary = {}
    free_b_s_d_hardware = FreeBSDHardware(dictionary)
    assert isinstance(free_b_s_d_hardware.get_uptime_facts(), dict) is True


# Generated at 2022-06-24 22:07:15.662722
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:07:20.698402
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)

    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:07:26.746123
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    """ Unit test for method populate of class FreeBSDHardware """
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    var_0 = free_b_s_d_hardware_0.populate(collected_facts=None)
    assert var_0 == {}


# Generated at 2022-06-24 22:07:28.994850
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    dict_0 = {}
    free_b_s_d_hardware_0 = FreeBSDHardware(dict_0)
    free_b_s_d_hardware_0.populate()
