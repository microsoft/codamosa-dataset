

# Generated at 2022-06-24 21:58:45.751725
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    # Run the populate method of FreeBSDHardware
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()

if __name__ == '__main__':
    main()

# Generated at 2022-06-24 21:58:51.561248
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_get_cpu_facts = free_b_s_d_hardware.get_cpu_facts()
    assert (free_b_s_d_hardware_get_cpu_facts) != None


# Generated at 2022-06-24 21:58:55.044415
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    cpu_facts = free_b_s_d_hardware.get_cpu_facts()
    assert cpu_facts['processor']
    assert cpu_facts['processor_cores']
    assert cpu_facts['processor_count']



# Generated at 2022-06-24 21:59:07.275711
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.module.get_bin_path=MagicMock(return_value='/usr/sbin/swapinfo')
    assert free_b_s_d_hardware_0.get_memory_facts() == {'swapfree_mb': 0, 'swaptotal_mb': 0, 'memtotal_mb': 0, 'memfree_mb': 0}


# Generated at 2022-06-24 21:59:13.774688
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0._fact_class({}, {})
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:18.137824
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Unit test for method get_cpu_facts of class FreeBSDHardware
    """
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:25.766145
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    Function that tests method 'get_dmi_facts' of class 'FreeBSDHardware',
    that learn dmi facts from system, if dmidecode is installed.
    """
    # Get a fresh instance of class FreeBSDHardware
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Get an ad-hoc module
    module = AnsibleModule(argument_spec={}, supports_check_mode=True)

    # Create a new class attribute to assign it to the ad-hoc module
    setattr(free_b_s_d_hardware_0, "module", module)

    # If a dmidecode executable is not found in previous step,
    # set dmi_bin to None
    dmi_bin = None

    # Set the new attribute 'dmi_bin' of class FreeBSDHardware to d

# Generated at 2022-06-24 21:59:27.656854
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    return_value__0 = free_b_s_d_hardware_0.populate()
    assert return_value__0 is None


# Generated at 2022-06-24 21:59:37.815891
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModuleMock()
    free_b_s_d_hardware_0.module.run_command.return_value =  (0, '2', '')
    free_b_s_d_hardware_0.DMESG_BOOT = "/var/run/dmesg.boot"
    free_b_s_d_hardware_0.DMESG_BOOT = '/var/run/dmesg.boot'
    free_b_s_d_hardware_0.module.get_bin_path.return_value = 'sysctl'

# Generated at 2022-06-24 21:59:40.819778
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Test with non None collected facts parameter
    test_case_0(free_b_s_d_hardware_0)


# Generated at 2022-06-24 21:59:56.705953
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:03.592433
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hard_obj = FreeBSDHardware()
    if os.path.exists('/usr/sbin/bios'):
        bios_vendor = "QEMU"
        bios_version = "0.0"
        bios_date = "06/01/2014"
        board_asset_tag = "NA"
        board_vendor = "QEMU"
        board_name = "Standard PC (Q35 + ICH9, 2009)"
        board_version = "pc-i440fx-trusty"
        system_vendor = "QEMU"
        product_name = "Standard PC (Q35 + ICH9, 2009)"
        product_version = "pc-i440fx-trusty"
        product_serial = "NA"
        product_uuid = "NA"

# Generated at 2022-06-24 22:00:06.897022
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    # Invoke get_cpu_facts() of FreeBSDHardware()
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Invoke method get_cpu_facts() of class FreeBSDHardware
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:12.930012
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_get_uptime_facts_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:22.072566
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # test return of case 0
    assert(free_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': None, u'swaptotal_mb': 783, u'memtotal_mb': None, u'swapfree_mb': 783})
    # test return of case 1
    assert(free_b_s_d_hardware_0.get_memory_facts() == {'memfree_mb': None, u'swaptotal_mb': 783, u'memtotal_mb': None, u'swapfree_mb': 783})


# Generated at 2022-06-24 22:00:30.469911
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Get memory facts.
    method_ret_val_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert method_ret_val_0 == {'memtotal_mb': 2147483648, 'memfree_mb': 2147483648, 'swaptotal_mb': 2147483648, 'swapfree_mb': 2147483648}


# Generated at 2022-06-24 22:00:37.667765
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fbsd_hw_0 = FreeBSDHardware(dict())
    fbsd_hw_0.module.get_bin_path = lambda x: '/usr/local/sbin/dmidecode'
    fbsd_hw_0.module.run_command = lambda x: (0, "NA", "")
    free_b_s_d_hardware_get_dmi_facts_0 = fbsd_hw_0.get_dmi_facts()

# Generated at 2022-06-24 22:00:48.068282
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule()
    free_b_s_d_hardware_0.get_cpu_facts()
    free_b_s_d_hardware_0.get_memory_facts()
    free_b_s_d_hardware_0.get_uptime_facts()
    free_b_s_d_hardware_0.get_dmi_facts()
    free_b_s_d_hardware_0.get_device_facts()
    free_b_s_d_hardware_0.get_mount_facts()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:49.181913
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:54.648412
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    free_b_s_d_hardware_0.module = None
    free_b_s_d_hardware_0.paths = None
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:01:24.003065
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hard_obj = FreeBSDHardware()
    hard_obj_populate_return = hard_obj.populate()
    if type(hard_obj_populate_return) is not dict:
        raise AssertionError('Return value of populate method of class FreeBSDHardware is not a dict')

if __name__ == '__main__':
    # Test for method populate of class FreeBSDHardware
    print("Test for method populate of class FreeBSDHardware")
    test_FreeBSDHardware_populate()
    print("Test for method populate of class FreeBSDHardware - Successful")

# Generated at 2022-06-24 22:01:25.146335
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert isinstance(FreeBSDHardwareCollector(), FreeBSDHardwareCollector)


# Generated at 2022-06-24 22:01:27.355113
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:01:27.972905
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    pass

# Generated at 2022-06-24 22:01:33.899086
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    # Setup
    free_bsd_hardware = FreeBSDHardware()
    # Test command
    try:
        free_bsd_hardware.get_uptime_facts()
    except TimeoutError:
        pass
    # Tests
    # Test teardown

if __name__ == "__main__":
    unittest.main()

# Generated at 2022-06-24 22:01:35.548529
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert isinstance(FreeBSDHardwareCollector(), HardwareCollector)


# Generated at 2022-06-24 22:01:46.166946
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    Test method get_cpu_facts of class FreeBSDHardware.
    """
    # Test against a custom dmesg.boot file

# Generated at 2022-06-24 22:01:47.844078
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0 is not None


# Generated at 2022-06-24 22:01:55.085027
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModuleStub()
    free_b_s_d_hardware_0.module.run_command = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock()
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'hw.ncpu: 8\n', '')
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/bin/sysctl'
    free_b_s_d_hardware_0.module.get_file_content = MagicMock()
    free_b_s

# Generated at 2022-06-24 22:02:06.144019
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, """real  2m59.262s
user  0m59.208s
sys 0m42.441s
""", ""))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, """real  2m59.262s
user  0m59.208s
sys 0m42.441s
""", ""))

# Generated at 2022-06-24 22:02:36.532087
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = ':4"7'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:42.014702
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    from ansible.module_utils.facts.hardware.base import TimeoutError
    # Case 1: Get uptime
    devnull = open(os.devnull, 'w')
    try:
        with open(FreeBSDHardware.DMESG_BOOT, 'r') as fd_boottime:
            boottime = fd_boottime.readline()
    except IOError:
        # File doesn't exist or can't be read
        assert 'NA' == FreeBSDHardware.get_uptime_facts()['uptime_seconds']
    else:
        with open(os.devnull, 'w') as devnull, mock.patch('time.time', lambda x: 1000):
            assert 1000 - int(boottime) == FreeBSDHardware.get_uptime_facts()['uptime_seconds']

    # Case 2: Get uptime on

# Generated at 2022-06-24 22:02:45.885601
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '}\x05"%\x07='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:50.446865
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(
        ),
        supports_check_mode=False
    )

    # create an instance of the FreeBSDHardware class
    free_b_s_d_hardware_obj = FreeBSDHardware(module)

    free_b_s_d_hardware_obj.get_uptime_facts()


# Generated at 2022-06-24 22:02:52.850685
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '.*VzWZw'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:54.752110
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(0)


# Generated at 2022-06-24 22:02:58.358326
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '}M\x0b "<'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:03:00.997716
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_1 = '\n'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:03:02.774131
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:03:05.384251
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:36.925351
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '}M\x0b "<'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:40.074911
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = ')F\x02\x1e\x04C\x15\t'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:45.257774
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = '}M\x0b "<'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    assert not var_0


# Generated at 2022-06-24 22:04:55.632821
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_1 = '}M\x0b "<'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)

    free_b_s_d_hardware_1.module.get_bin_path = lambda x: ''
    var_1 = free_b_s_d_hardware_1.get_uptime_facts()

    free_b_s_d_hardware_1.module.get_bin_path = lambda x: '/sbin/sysctl'
    var_2 = free_b_s_d_hardware_1.get_uptime_facts()

    free_b_s_d_hardware_1.module.get_bin_path = lambda x: '/sbin/sysctl'
    free_b_s_d_hardware_1.module.run

# Generated at 2022-06-24 22:04:58.121093
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

__all__ = [
    'test_case_0',
    'test_FreeBSDHardwareCollector',
]

# Generated at 2022-06-24 22:05:02.313431
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '8$}^\tH'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:06.715317
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '`M\x0b =&'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:05:09.444819
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_1 = '}M\x0b "<'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:05:12.142270
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str1 = ''
    freeBSDHardware = FreeBSDHardware(str1)
    actual = freeBSDHardware.get_memory_facts()
    expected = {}


# Generated at 2022-06-24 22:05:17.039459
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '}M\x0b "<'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
