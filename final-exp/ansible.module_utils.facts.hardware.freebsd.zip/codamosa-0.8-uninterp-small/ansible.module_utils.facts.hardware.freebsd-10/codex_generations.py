

# Generated at 2022-06-24 21:58:50.313427
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    print("test get_uptime_facts")
    module = AnsibleModule({})
    free_b_s_d_hardware_0 = FreeBSDHardware(module)
    free_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 21:58:51.179270
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware({})

# Generated at 2022-06-24 21:58:53.672070
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    # assert call
    out = free_b_s_d_hardware_0.get_cpu_facts()
    assert out is not None


# Generated at 2022-06-24 21:58:54.666016
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert dmi_facts == dmi_facts


# Generated at 2022-06-24 21:58:57.793875
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    free_b_s_d_hardware_0.module = Mock()
    str_0 = free_b_s_d_hardware_0.get_uptime_facts()
# ----------------------------------------------------------------------


# Generated at 2022-06-24 21:59:02.074698
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    bool_0 = False
    # Calling dmi_facts()
    free_b_s_d_hardware_0.get_dmi_facts(bool_0)


# Generated at 2022-06-24 21:59:06.090142
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_0 = False
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(bool_0)

if __name__ == "__main__":
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 21:59:09.925353
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(None)
    value_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:16.494880
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    collected_facts = dict_0
    free_b_s_d_hardware_0.populate(collected_facts = collected_facts)
    if (len(free_b_s_d_hardware_0.populate()) != len(collected_facts)):
        fail_count += 1


# Generated at 2022-06-24 21:59:21.401510
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    bool_0 = False
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    dmi_facts = free_b_s_d_hardware_0.get_dmi_facts()

    assert(len(dmi_facts.keys()) > 0)


# Generated at 2022-06-24 21:59:35.893452
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # self
    # method return value
    ret_value = None

    # Execute the method.
    ret_value = FreeBSDHardware.get_uptime_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 21:59:39.426107
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:42.096141
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    arg = str('Z')
    free_b_s_d_hardware_0 = FreeBSDHardware(arg)
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:59:43.568174
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_case_0()


# Generated at 2022-06-24 21:59:48.434762
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_0 = AnsibleModule(
        argument_spec = dict()
    )
    free_b_s_d_hardware_0 = FreeBSDHardware('module_0')
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == dict()


# Generated at 2022-06-24 21:59:51.444373
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = on(free_b_s_d_hardware_0.populate)


# Generated at 2022-06-24 21:59:55.045769
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    string_0 = 'Y'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(string_0)

# Generated at 2022-06-24 22:00:00.164388
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    # Test case where dmesg success case
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()

    # Test case where fopen failure case
    var_1 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:00:04.447202
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    _fact_class = FreeBSDHardware
    _platform = 'FreeBSD'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(_fact_class, _platform)
    var_0 = free_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:00:12.000806
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    sysctl_cmd = free_b_s_d_hardware_0.module.get_bin_path('sysctl')
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:00:42.431167
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:00:47.141490
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    sysdir_0 = '/dev'
    str_0 = 'alice'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:51.006223
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:53.764197
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:57.205762
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = 'Z'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:00:59.787589
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    assert var_0 == {'uptime_seconds': 0}


# Generated at 2022-06-24 22:01:03.711919
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_1 = 'G'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.get_uptime_facts()
    assert var_1 == {}


# Generated at 2022-06-24 22:01:08.094301
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()
    assert_equal(var_0, {})


# Generated at 2022-06-24 22:01:11.027925
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'q'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:01:13.952982
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = 'Z'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:02:41.565442
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'F'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module = mock.Mock()
    free_b_s_d_hardware_0.module.get_bin_path = mock.Mock(return_value='/sbin/sysctl')
    free_b_s_d_hardware_0.module.run_command = mock.Mock(return_value=(0, '0 1607731248\n', 'stderr'))

    assert free_b_s_d_hardware_0.get_uptime_facts() == {'uptime_seconds': 1607731249.0}
    assert free_b_s_d_hardware_0.module.run_command

# Generated at 2022-06-24 22:02:45.137928
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'A'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:46.829532
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_0 = FreeBSDHardware()  # initialisation
    var_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:49.970781
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:53.575343
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:57.562709
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    print('VAR_0: ' + str(var_0))

# Generated at 2022-06-24 22:03:03.166651
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    # This test may fail when run in an environment where dmidecode
    # executable is not available.

    str_0 = 'bY'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:03:07.427704
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module.run_command.__setattr__('rc', 0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:12.738747
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'D'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert var_0 == {'processor_count': '1', 'processor': []}


# Generated at 2022-06-24 22:03:15.251867
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    free_b_s_d_hardware_1 = FreeBSDHardware('Z')
    free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:06:24.891005
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    pass


# Generated at 2022-06-24 22:06:28.216343
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'E'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:06:31.549456
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    print('test_get_device_facts')
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_device_facts()
    print(var_0)



# Generated at 2022-06-24 22:06:33.992954
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:38.277545
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:06:45.249714
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()
    int_0 = free_b_s_d_hardware_0.get_memory_facts()
    int_0 = free_b_s_d_hardware_0.get_cpu_facts()
    int_0 = free_b_s_d_hardware_0.get_uptime_facts()
    int_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:06:48.203450
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:06:51.293926
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:06:54.983233
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'Z'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:07:05.387753
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    stdout_str = '''
{
    "uptime_seconds": 1234567
}'''
    expected_result = json.loads(stdout_str)
    module_args = {
        'module_name': 'ansible.module_utils.basic.AnsibleModule',
        'module_args': {'argument_spec': {}, 'supports_check_mode': False,
                        '_ansible_check_mode': False,
                        '_ansible_module_name': 'ansible.module_utils.basic.AnsibleModule'}
    }
    # This is not ideal but we have to set the module_name arg here so that
    # the right class is used when the ModuleExecutor object is initialized.