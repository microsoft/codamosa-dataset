

# Generated at 2022-06-24 21:58:49.845025
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    collected_facts_0 = {}
    free_b_s_d_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 21:59:00.137459
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = None
    sub_0 = None
    sub_1 = None
    sub_2 = None
    free_b_s_d_hardware_0.module.run_command = sub_0
    free_b_s_d_hardware_0.module.get_bin_path = sub_1
    get_file_content = sub_2
    str_0 = 'hw.ncpu'
    dict_0 = {}
    dict_1 = {}
    dict_2 = {}
    dict_1['processor'] = []
    dict_2['processor_count'] = str_1
    dict_0.update(dict_1)
   

# Generated at 2022-06-24 21:59:02.131410
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware_collector = FreeBSDHardwareCollector()
    hardware_collector.populate()


# Generated at 2022-06-24 21:59:14.797613
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec={},
        supports_check_mode=True,
    )

    # Assertion call
    str_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:24.049014
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    freebsd_hardware = FreeBSDHardware(int)
    freebsd_hardware.module.get_bin_path = lambda a: 'sysctl'
    freebsd_hardware.module.run_command = lambda a, encoding=None: ['0', b'\x00\x00\x00\x00\x00\x00\x00\x00', '']
    with pytest.raises(TimeoutError):
        freebsd_hardware.get_uptime_facts()

    freebsd_hardware.module.run_command = lambda a, encoding=None: ['0', b'\x00\x01\x00\x00\x00\x00\x00\x00', '']
    freebsd_hardware.get_uptime_facts()



# Generated at 2022-06-24 21:59:25.766410
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    # FreeBSDHardware.get_cpu_facts() implementation
    pass


# Generated at 2022-06-24 21:59:29.212801
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)

    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:59:30.496593
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert FreeBSDHardware.get_memory_facts() == None


# Generated at 2022-06-24 21:59:34.070003
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:59:37.630486
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:49.543118
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    pass

# Generated at 2022-06-24 21:59:55.469759
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, "out", "err"))
    free_b_s_d_hardware_0.module.fail_json = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value="/sbin/dmidecode")
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:02.726741
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    output = '{ "sysname": "FreeBSD", "nodename": "myserver", "release": "12.0-RELEASE", "version": "FreeBSD 12.0-RELEASE #0 r335510: Fri Jun 22 02:01:31 UTC 2018     root@releng2.nyi.freebsd.org:/usr/obj/usr/src/sys/GENERIC  amd64", "machine": "amd64", "domainname": "", "uptime_seconds": 842380.0}'
    output = output.splitlines()
    for index in range(len(output)):
        output[index] = output[index].strip()
    output = " ".join(output)
    output_json = json.loads(output)
    print(output_json)


# Generated at 2022-06-24 22:00:10.533188
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = Mock(**{'run_command.return_value': (0, "hw.ncpu: 4", '')})
    free_b_s_d_hardware_0.module.get_bin_path = Mock(side_effect=lambda x: x)
    free_b_s_d_hardware_0.get_file_content = Mock(return_value='CPU: AMD Turion(tm) X2 Ultra Dual-Core Mobile ZM-86\nCPU: AMD Turion(tm) X2 Ultra Dual-Core Mobile ZM-86\n')

# Generated at 2022-06-24 22:00:13.850323
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hardware = FreeBSDHardware()
    hardware.populate()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_populate()

# Generated at 2022-06-24 22:00:24.750570
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    fb_hw = FreeBSDHardware()
    facts = fb_hw.populate()
    assert 'processor' in facts
    assert 'processor_count' in facts
    assert 'processor_cores' in facts
    assert 'memtotal_mb' in facts
    assert 'memfree_mb' in facts
    assert 'swaptotal_mb' in facts
    assert 'swapfree_mb' in facts
    assert 'devices' in facts
    assert 'uptime_seconds' in facts
    assert 'mounts' in facts
    assert 'bios_date' in facts
    assert 'bios_vendor' in facts
    assert 'bios_version' in facts
    assert 'board_asset_tag' in facts
    assert 'board_name' in facts
    assert 'board_serial' in facts

# Generated at 2022-06-24 22:00:26.987155
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:31.231228
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)


# Generated at 2022-06-24 22:00:41.507297
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    FreeBSD_hardware_0 = FreeBSDHardware()
    dmi_facts = FreeBSD_hardware_0.get_dmi_facts()
    assert len(dmi_facts.keys()) == 16
    assert dmi_facts['system_vendor'] is not None
    assert dmi_facts['product_name'] is not None
    assert dmi_facts['product_version'] is not None
    assert dmi_facts['product_serial'] is not None
    assert dmi_facts['product_uuid'] is not None
    assert dmi_facts['form_factor'] is not None
    assert dmi_facts['chassis_asset_tag'] is not None
    assert dmi_facts['chassis_serial'] is not None
    assert dmi_facts['chassis_vendor'] is not None

# Generated at 2022-06-24 22:00:43.089960
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Replace 'pass' for your unit test
    pass



# Generated at 2022-06-24 22:00:57.280983
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -64
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()
    var_2 = {'uptime_seconds': var_1['uptime_seconds']}
    print(var_2)


# Generated at 2022-06-24 22:01:05.843903
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = MockModule()
    free_b_s_d_hardware_0.module.run_command = Mock(return_value=(0, '', ''))
    free_b_s_d_hardware_0.get_mount_facts = Mock()
    free_b_s_d_hardware_0.get_mount_facts.side_effect = lambda: {}
    # Call method
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0 == {}


# Generated at 2022-06-24 22:01:09.130528
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = 12
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:13.847095
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = -89
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = MagicMock()
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:19.910983
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Case 0
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:01:21.199144
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_0 = None
    assert test_0 == test_case_0()

# Generated at 2022-06-24 22:01:24.431057
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()

    assert var_0['board_vendor'] == 'NA'


# Generated at 2022-06-24 22:01:30.695597
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test case 1
    int_0 = -1
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    # Test case 2
    int_0 = -5
    free_b_s_d_hardware_1 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_1.get_memory_facts()



# Generated at 2022-06-24 22:01:35.719195
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:01:46.307815
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.populate()
    int_1 = 798
    free_b_s_d_hardware_1 = FreeBSDHardware(int_1)
    free_b_s_d_hardware_1.populate()
    int_2 = -729
    free_b_s_d_hardware_2 = FreeBSDHardware(int_2)
    free_b_s_d_hardware_2.populate()
    int_3 = -711
    free_b_s_d_hardware_3 = FreeBSDHardware(int_3)
    free_b_s_d_hardware_3.populate()

# Generated at 2022-06-24 22:02:09.952512
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:14.865453
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    print(free_b_s_d_hardware_collector_0._fact_class._platform)
    print(free_b_s_d_hardware_collector_0._platform)
    var_1 = free_b_s_d_hardware_collector_0.get_all()


# Generated at 2022-06-24 22:02:18.042337
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 518
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    print(var_0)


# Generated at 2022-06-24 22:02:20.657364
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:23.981784
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = -661
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:27.071384
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = 730
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:02:29.239282
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    test_case_0()
# if __name__ == '__main__':
#     test_FreeBSDHardware_populate()

# Generated at 2022-06-24 22:02:38.125109
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    int_0 = -543
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    # dmi_facts: NAS (defined in get_dmi_facts test_case_0).
    # mount_facts: NAS (defined in get_mount_facts test_case_0).
    # cpu_facts: NAS (defined in get_cpu_facts test_case_0).
    # uptime_facts: NAS (defined in get_uptime_facts test_case_0).
    # memory_facts: NAS (defined in get_memory_facts test_case_0).
    var_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:02:39.814929
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:02:45.172292
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.populate()
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:13.173218
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:03:14.348945
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # TODO implement unit test
    pass


# Generated at 2022-06-24 22:03:16.047011
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    return

# Generated at 2022-06-24 22:03:22.848432
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = -15
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = mock.Mock()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/usr/bin/sysctl'
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'vm.stats.vm.v_page_size 129530\nvm.stats.vm.v_page_count 525440\nvm.stats.vm.v_free_count 510769', 'NONE')

    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:25.613564
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:33.750044
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = -939
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    var_1 = free_b_s_d_hardware_0.get_device_facts()
    var_2 = free_b_s_d_hardware_0.get_cpu_facts()
    var_3 = free_b_s_d_hardware_0.get_memory_facts()
    var_4 = free_b_s_d_hardware_0.get_uptime_facts()
    var_5 = free_b_s_d_hardware_0.get_mount_facts()


# Generated at 2022-06-24 22:03:40.205995
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    # AssertionError: Fact: processor_cores Not found


# Generated at 2022-06-24 22:03:43.361981
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -514
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:44.754777
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_case_0()


# Generated at 2022-06-24 22:03:49.001509
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = 0
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.module = AnsibleModule(argument_spec={})
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:19.103852
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    int_0 = -261
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:21.205613
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    try:
        var = test_case_0()
    except Exception:
        assert False, "Died on error."

# Generated at 2022-06-24 22:05:26.117821
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    with pytest.raises(Exception):
        int_0 = -494
        free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
        free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:29.447351
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Initialize the class
    free_b_s_d_hardware_0 = FreeBSDHardware(int())

    # Invoke the method
    free_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:05:32.004575
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -494
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:05:36.144491
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    int_0 = 1
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(int_0)
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)


# Generated at 2022-06-24 22:05:39.731191
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    """
    This test case is used to test the system out of FreeBSDHardware.get_dmi_facts
    """
    free_b_s_d_hardware_0 = FreeBSDHardware(None)
    free_b_s_d_hardware_1 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:45.784417
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    print("test_FreeBSDHardware_get_device_facts()")

    var_0 = "device_facts"
    int_0 = -479
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    var_1 = free_b_s_d_hardware_0.get_device_facts()
    print(var_1)


# Generated at 2022-06-24 22:05:46.696145
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    pass


# Generated at 2022-06-24 22:05:49.124247
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = -1011
    free_b_s_d_hardware_0 = FreeBSDHardware(int_0)
    free_b_s_d_hardware_0.get_uptime_facts()
