

# Generated at 2022-06-24 21:58:56.479071
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():

    # Test for existence of class variable _fact_class
    str_0 = hasattr(FreeBSDHardwareCollector, '_fact_class')
    assert (str_0 == True)

    # Test for existence of class variable _platform
    str_0 = hasattr(FreeBSDHardwareCollector, '_platform')
    assert (str_0 == True)

    # Test for existence of private class method _collect_platform_subset_facts()
    str_0 = hasattr(free_b_s_d_hardware_collector_0, '_collect_platform_subset_facts')
    assert (str_0 == False)

    # Test for existence of private class method _collect_all_facts()
    str_0 = hasattr(free_b_s_d_hardware_collector_0, '_collect_all_facts')

# Generated at 2022-06-24 21:58:57.177006
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_case_0()


# Generated at 2022-06-24 21:59:09.412270
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    print('Testing method get_dmi_facts of class FreeBSDHardware')
    free_b_s_d_hardware_0 = FreeBSDHardware()
    str_0 = 'packaging Python module unavailable; unable to validate collection Ansible version requirements'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)
    free_b_s_d_hardware_collector_0.ansible_module
    free_b_s_d_hardware_0.module = free_b_s_d_hardware_collector_0.ansible_module
    str_1 = 'dmidecode'
    str_2 = 'bios-release-date'
    str_3 = 'bios-vendor'
    str_4 = 'bios-version'

# Generated at 2022-06-24 21:59:16.442293
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'packaging Python module unavailable; unable to validate collection Ansible version requirements'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    free_b_s_d_hardware_0.populate([])

# Generated at 2022-06-24 21:59:17.554508
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    test_case_0()


# Generated at 2022-06-24 21:59:22.609160
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    f_r_e_e_b_s_d_hardware_0 = FreeBSDHardware()
    # test get_device_facts
    frm_free_b_s_d_hardware = getattr(f_r_e_e_b_s_d_hardware_0, 'get_device_facts')
    assert frm_free_b_s_d_hardware() is None


# Generated at 2022-06-24 21:59:28.303304
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'packaging Python module unavailable; unable to validate collection Ansible version requirements'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)
    sysctl = free_b_s_d_hardware_collector_0.module.get_bin_path('sysctl')
    if sysctl:
        rc, out, err = free_b_s_d_hardware_collector_0.module.run_command("%s vm.stats" % sysctl, check_rc=False)
        for line in out.splitlines():
            data = line.split()
            if 'vm.stats.vm.v_page_size' in line:
                pagesize = int(data[1])

# Generated at 2022-06-24 21:59:37.765246
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    hw = FreeBSDHardware()

    # Check for a 'manual' override of dmidecode
    hw.module.params['dmidecode'] = '/dev/null'

    # Check that each method is called at least once
    hw.get_cpu_facts = '.get_cpu_facts'
    hw.get_memory_facts = '.get_memory_facts'
    hw.get_uptime_facts = '.get_uptime_facts'
    hw.get_dmi_facts = '.get_dmi_facts'
    hw.get_device_facts = '.get_device_facts'
    hw.get_mount_facts = '.get_mount_facts'

    # Make sure a TimeoutError is raised for get_mount_facts

# Generated at 2022-06-24 21:59:45.178546
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'packaging Python module unavailable; unable to validate collection Ansible version requirements'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)
    free_b_s_d_hardware_0 = free_b_s_d_hardware_collector_0.collect()
    free_b_s_d_hardware_0.get_memory_facts()
    assert free_b_s_d_hardware_0.module.run_command.call_count == 1


# Generated at 2022-06-24 21:59:54.093253
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module_0 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    module_1 = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = False
    )
    param = [
        {
            'module_0': module_0,
            'module_1': module_1,
        },
        {
            'module_0': module_0,
            'module_1': module_1,
        },
    ]
    param[0]['module_0'].get_bin_path = lambda *args, **kwargs: '/sbin/sysctl'
    param[0]['module_1'].get_bin_path = lambda *args, **kwargs: '/sbin/sysctl'

# Generated at 2022-06-24 22:00:09.346400
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()


# Generated at 2022-06-24 22:00:13.905333
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_get_cpu_facts_ret_val = free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:00:18.321138
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    dmi_facts_0 = free_b_s_d_hardware_0.get_dmi_facts()
    assert len(dmi_facts_0) > 0


# Generated at 2022-06-24 22:00:19.016363
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:00:20.770011
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:00:23.793328
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_cpu_facts() is None


# Generated at 2022-06-24 22:00:35.173715
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = Mock(return_value=(0, "hw.ncpu: 4", ""))
    free_b_s_d_hardware_0.get_memory_facts()
    assert(free_b_s_d_hardware_0.memtotal_mb == 0)
    assert(free_b_s_d_hardware_0.memfree_mb == 0)
    assert(free_b_s_d_hardware_0.swaptotal_mb == 0)
    assert(free_b_s_d_hardware_0.swapfree_mb == 0)


# Generated at 2022-06-24 22:00:38.722146
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

if __name__ == '__main__':
    # test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:41.535336
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:43.090314
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:59.807155
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware._module = MockModule()
    free_b_s_d_hardware._module.run_command.return_value = 0, "b'\xdc\xea\x1e\x02\x018\x80\x00\x00'", ''
    assert free_b_s_d_hardware.get_uptime_facts() == {'uptime_seconds': 512}



# Generated at 2022-06-24 22:01:08.268956
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_1.module.run_command = lambda x: [0, 'stdout', '']
    free_b_s_d_hardware_1.module.get_bin_path = lambda x: '/bin/dmidecode'

# Generated at 2022-06-24 22:01:08.793327
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:01:20.823815
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'hw.ncpu: 1', ''))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_size: 4096', ''))
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_count: 1996032', ''))

# Generated at 2022-06-24 22:01:26.775264
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """
    test get_cpu_facts of class FreeBSDHardware
    """
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = AnsibleModule(argument_spec={})
    free_b_s_d_hardware_cpu_facts = free_b_s_d_hardware.get_cpu_facts()
    assert 'processor_cores' in free_b_s_d_hardware_cpu_facts
    assert 'processor_count' in free_b_s_d_hardware_cpu_facts
    assert 'processor' in free_b_s_d_hardware_cpu_facts


# Generated at 2022-06-24 22:01:30.031961
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    cpu_facts = free_b_s_d_hardware_0.get_cpu_facts()
    assert isinstance(cpu_facts, dict)


# Generated at 2022-06-24 22:01:34.132599
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware = FreeBSDHardware()

    # Returns a dictionary containing the hardware facts
    free_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:01:45.006928
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:01:46.379910
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:01:50.203142
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware
    assert free_b_s_d_hardware_collector_0._platform == 'FreeBSD'


# Generated at 2022-06-24 22:02:18.668529
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:02:22.442462
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_2 = FreeBSDHardware()

    free_b_s_d_hardware_1.get_dmi_facts()
    free_b_s_d_hardware_2.get_dmi_facts()


# Generated at 2022-06-24 22:02:33.662027
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    with open("/proc/uptime") as f:
        uptime_seconds_0 = float(f.readline())
    with open("/proc/uptime") as f:
        uptime_seconds_1 = float(f.readline())
    # NOTE:  sysctl kern.boottime is in seconds, uptime_seconds_2 is in milliseconds
    with open("/sys/kernel/debug/clock/boot_time") as f:
        uptime_seconds_2 = int(f.readline()) / 1000
    free_b_s_d_hardware_0.uptime_seconds = 0
    free_b_s_d_hardware_0.get_uptime_facts()
    assert free_b_s_d_hardware_

# Generated at 2022-06-24 22:02:36.646109
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsdhardware = FreeBSDHardware()
    assert isinstance(freebsdhardware, FreeBSDHardware)
    hardware_facts = freebsdhardware.get_memory_facts()
    assert isinstance(hardware_facts, dict)
    assert hardware_facts['memtotal_mb'] > 0
    assert hardware_facts['memtotal_mb'] > hardware_facts['memfree_mb']


# Generated at 2022-06-24 22:02:42.438445
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'test_case_0.json')
    with open(path, 'rb') as f:
        collected_facts = json.loads(f.read(), encoding='utf-8')
    free_b_s_d_hardware_0 = FreeBSDHardware()
    out_0 = free_b_s_d_hardware_0.get_dmi_facts()
    result = dict((key.lower(), value) for key, value in out_0.items())
    assert result == collected_facts['ansible_facts']


# Generated at 2022-06-24 22:02:51.899678
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = ansible_mock_module_helper()
    setattr(module, 'get_bin_path', lambda _: None)
    free_b_s_d_hardware = FreeBSDHardware(module)

    # Case 0
    free_b_s_d_hardware.module.run_command = lambda _, encoding=None: (0, '0x4\x00\x00\x00\x00\x00\x00\x00', '')

    result = free_b_s_d_hardware.get_uptime_facts()

    assert_equal(result, {'uptime_seconds': 0x4})

if __name__ == '__main__':
    from ansible.module_utils import ansible_mock_module_helper

# Generated at 2022-06-24 22:02:57.215107
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    cpu_facts = free_b_s_d_hardware_1.get_cpu_facts()
    assert cpu_facts.get('processor_count') is not None
    assert cpu_facts.get('processor_cores') is not None
    assert cpu_facts.get('processor') is not None


# Generated at 2022-06-24 22:03:01.877653
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    f_b_s_d_hardware = FreeBSDHardware()
    f_b_s_d_hardware._module = {}
    f_b_s_d_hardware._module['run_command'] = run_command_mock
    expected_output = {'uptime_seconds': 1537214}
    output = f_b_s_d_hardware.get_uptime_facts()
    assert expected_output == output


# Generated at 2022-06-24 22:03:09.526052
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Case 0:
    expected0 = {'memtotal_mb': 4096, 'swapfree_mb': 3072, 'swaptotal_mb': 4096, 'memfree_mb': 3456}
    out0 = free_b_s_d_hardware_0.get_memory_facts()
    if out0 != expected0:
        print('1st Assertion failed')
    # Case 1
    expected1 = {'memtotal_mb': 4096, 'memfree_mb': 3456}
    out1 = free_b_s_d_hardware_0.get_memory_facts()
    if out1 != expected1:
        print('2nd Assertion failed')


# Generated at 2022-06-24 22:03:11.231070
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:04:03.337379
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    facts = free_b_s_d_hardware_0.populate()
    assert isinstance(facts, dict) 


# Generated at 2022-06-24 22:04:10.622686
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module.run_command = lambda cmd, check_rc=True, close_fds=True: (0, 'kern.boottime: 1486318419 6396150 ', '')
    assert free_b_s_d_hardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - 1486318419)}



# Generated at 2022-06-24 22:04:12.150051
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()



# Generated at 2022-06-24 22:04:15.924320
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    assert free_b_s_d_hardware_1.get_cpu_facts() == \
                                                   {'processor': ['Intel(R) Core(TM) i7-4790K CPU @ 4.00GHz'],
     'processor_count': '1', 'processor_cores': '8'}


# Generated at 2022-06-24 22:04:20.484144
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    """Test for get_cpu_facts"""
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_cpu_facts() == {'processor': ['Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz', 'Intel(R) Core(TM)2 Duo CPU     P8600  @ 2.40GHz'], 'processor_cores': '2', 'processor_count': '2'}


# Generated at 2022-06-24 22:04:25.855916
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    rc, out, err = free_b_s_d_hardware_1.module.run_command("freebsd-version -r")
    freebsd_version = out.split('-')[0]
    sysdir = '/dev'
    # TODO: device_facts = {}
    device_facts = {}
    device_facts['devices'] = {}
    drives = re.compile(r'(ada?\d+|da\d+|a?cd\d+)')
    slices = re.compile(r'(ada?\d+s\d+\w*|da\d+s\d+\w*)')

# Generated at 2022-06-24 22:04:31.233501
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    for collected_facts in [None]:
        hardware_facts = free_b_s_d_hardware_0.populate(collected_facts=collected_facts)


# Generated at 2022-06-24 22:04:34.541352
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.get_dmi_facts()


# Generated at 2022-06-24 22:04:38.335514
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_1.populate()



if __name__ == '__main__':
    # Execute the unit test
    test_case_0()
    test_FreeBSDHardware_populate()

# Generated at 2022-06-24 22:04:44.843794
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module_args = dict(
        ansible_facts=dict(
            ansible_system_vendor='FreeBSD',
            ansible_distribution='FreeBSD',
            ansible_distribution_version='12.0-RELEASE',
            ansible_distribution_major_version='12',
            ansible_distribution_release='RELEASE',
            ansible_architecture='amd64',
            ansible_machine='amd64',
            ansible_hostname='localhost.localdomain',
            ansible_system='FreeBSD',
            ansible_pkg_mgr='pkg',
            ansible_device_id='0',
            ansible_device_id_type='dev',
        ),
        changed=False,
        failed=False,
    )


# Generated at 2022-06-24 22:06:33.735829
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    print(free_b_s_d_hardware.get_memory_facts())


# Generated at 2022-06-24 22:06:36.617197
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    assert free_b_s_d_hardware_1.get_uptime_facts() == {}


# Generated at 2022-06-24 22:06:45.845902
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Test with a non-existing file
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = MockModule()
    free_b_s_d_hardware.module.run_command.side_effect = lambda x, **y: (1, '', '')
    assert free_b_s_d_hardware.get_uptime_facts() == {}

    # Test with a file with a struct of insufficient size
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = MockModule()
    free_b_s_d_hardware.module.run_command.side_effect = lambda x, **y: (0, '\xff', '')
    assert free_b_s_d_hard

# Generated at 2022-06-24 22:06:51.499062
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_get_memory_facts_output = free_b_s_d_hardware_0.get_memory_facts()
    # check if the return value is correct
    assert (free_b_s_d_hardware_get_memory_facts_output == {})


# Generated at 2022-06-24 22:06:52.890539
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:07:02.301779
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    sysctl_cmd = getattr(free_b_s_d_hardware_0, 'module').get_bin_path('sysctl')
    cmd = [sysctl_cmd, '-b', 'kern.boottime']
    # We need to get raw bytes, not UTF-8.
    (rc, out, err) = getattr(free_b_s_d_hardware_0, 'module').run_command(cmd, encoding=None)
    # kern.boottime returns seconds and microseconds as two 64-bits
    # fields, but we are only interested in the first field.
    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}

# Generated at 2022-06-24 22:07:08.192008
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, "", ""))
    free_b_s_d_hardware_0.module.get_bin_path = MagicMock(return_value=True)
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:07:11.048759
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:07:14.835601
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware_0 = free_b_s_d_hardware.get_memory_facts()


# Generated at 2022-06-24 22:07:16.606552
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    FreeBSDHardware_populate = FreeBSDHardware()
    FreeBSDHardware_populate.populate()