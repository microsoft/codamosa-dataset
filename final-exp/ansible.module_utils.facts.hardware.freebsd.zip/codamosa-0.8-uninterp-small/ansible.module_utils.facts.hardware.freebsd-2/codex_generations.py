

# Generated at 2022-06-24 21:58:55.164197
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import mock
    free_b_s_d_hardware = FreeBSDHardware()

    with mock.patch('ansible.module_utils.facts.timeout.time.time') as mock_time:
        mock_time.return_value = 1495309731.059125
        free_b_s_d_hardware.module = mock.MagicMock()
        mock_module = free_b_s_d_hardware.module
        mock_module.get_bin_path.return_value = '/usr/bin/sysctl'
        mock_module.run_command.return_value = (0, '1495309574.130965', '')
        result = free_b_s_d_hardware.get_uptime_facts()
        assert result['uptime_seconds'] == 356.928160

        mock_module

# Generated at 2022-06-24 21:58:56.747635
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # TODO: tests
    return


# Generated at 2022-06-24 21:59:00.865836
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(module=AnsibleModule(argument_spec={}))
    cpu_facts_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 21:59:13.243193
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()

# Generated at 2022-06-24 21:59:21.423811
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    mem_facts = {}
    mem_facts['swapfree_mb'] = 147584
    mem_facts['swaptotal_mb'] = 147584
    mem_facts['memtotal_mb'] = 64444
    mem_facts['memfree_mb'] = 49986

    free_b_s_d_hardware_0 = FreeBSDHardware()
    mem_facts_ret = free_b_s_d_hardware_0.get_memory_facts()
    for key in mem_facts.keys():
        assert mem_facts[key] == mem_facts_ret[key];



# Generated at 2022-06-24 21:59:32.058034
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    hardware_instance_0 = FreeBSDHardware()

# Generated at 2022-06-24 21:59:41.238776
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # FIXME: This test is currently not working, because dmesg.boot is not readable
    # for root.  dmesg.boot is world readable on OpenBSD, but on FreeBSD it is
    # only readable by the owner, root.  We can either:
    #   - Make dmesg.boot world readable somehow in the test environment before
    #     running this test.
    #   - Alternatively, we could temporarily change the owner and permissions
    #     of dmesg.boot, run the test, and then change the owner and permissions
    #     back.
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.populate() == 'freebsd_hardware.populate() is not implemented yet'


# Generated at 2022-06-24 21:59:43.731119
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    freebsdhardware = FreeBSDHardware({}, {})
    freebsdhardware._get_memory_facts()


# Generated at 2022-06-24 21:59:49.987815
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_cpu_facts() == {'processor': ['Intel(R) Xeon(R) CPU E5-2620 v2 @ 2.10GHz', 'Intel(R) Xeon(R) CPU E5-2620 v2 @ 2.10GHz'], 'processor_cores': '2', 'processor_count': '16'}


# Generated at 2022-06-24 21:59:53.660342
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:11.593184
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert (var_0.get('processor') == ()
            ) and (var_0.get('processor_cores') == '2'
                   ) and (var_0.get('processor_count') == '2'
                          )

# Generated at 2022-06-24 22:00:22.810023
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # Pickling of class FreeBSDHardware results in infinite recursion
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    free_b_s_d_hardware_0.module = mock.Mock()
    free_b_s_d_hardware_0.module.run_command.return_value = (1, b'bad data', '')
    assert free_b_s_d_hardware_0.get_uptime_facts() == {}


# Generated at 2022-06-24 22:00:28.164134
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    print(var_0)


# Generated at 2022-06-24 22:00:32.566254
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    var_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:00:42.115631
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    set_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.get_uptime_facts()
    free_b_s_d_hardware_0.get_dmi_facts()
    var_1 = free_b_s_d_hardware_0.get_device_facts()
    free_b_s_d_hardware_0.get_mount_facts()
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:45.164230
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(set_0)

# Generated at 2022-06-24 22:00:45.807945
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    assert True

# Generated at 2022-06-24 22:00:52.023788
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    set_0 = set()
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, 'hw.ncpu: 4', ''))
    assert len(free_b_s_d_hardware_0.get_memory_facts()) == 2


# Generated at 2022-06-24 22:00:57.110346
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
# Compile-time type checking of arguments
    set_1 = set()
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(set_1)

# Generated at 2022-06-24 22:01:07.603097
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    set_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(set_0)

# Generated at 2022-06-24 22:01:23.080076
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    test = free_b_s_d_hardware_1.get_device_facts()
    assert test == {}


# Generated at 2022-06-24 22:01:29.563712
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # The input to this method will be of type int and represent the value of 'memtotal_mb'.
    # The output from this method will be of type int.
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_2 = {
        'memtotal_mb': '32233',
        'memfree_mb': '32200'
    }
    var_2 = free_b_s_d_hardware_0.get_memory_facts()
    assert var_2 == var_2


# Generated at 2022-06-24 22:01:31.698624
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    pass


# Generated at 2022-06-24 22:01:37.145513
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    # Call method get_uptime_facts of class FreeBSDHardware
    free_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:01:40.609691
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    var_3 = free_b_s_d_hardware_1.get_device_facts()
    assert True

# Generated at 2022-06-24 22:01:44.217067
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:01:47.491991
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:52.416438
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_6 = {'time': time.time()}
    free_b_s_d_hardware_0 = FreeBSDHardware(var_6)
    var_6 = time.time()
    time.sleep(1.0)
    var_7 = time.time()
    var_8 = var_7 - var_6
    var_8 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:57.034901
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    var_3 = free_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:02:07.607932
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    print("test_FreeBSDHardware_get_device_facts")

    # From generated command
    # dmidecode not installed: skipped
    # data = {
    #     'devices': {
    #         'da0': [
    #             'da0s1',
    #             'da0s2',
    #             'da0s3'
    #         ],
    #         'da1': [
    #             'da1s1'
    #         ]
    #     },
    #     'module_hw': True
    # }
    data = {
        'devices': {},
        'module_hw': True
        }
    free_b_s_d_hardware_0 = FreeBSDHardware(data)
    var_1 = free_b_s_d_hardware_0.get_device_

# Generated at 2022-06-24 22:02:32.665066
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    var_2 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:02:35.669846
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:40.058555
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    var_0 = set()
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(var_0)
    var_1 = free_b_s_d_hardware_collector_0.collect()
    var_2 = free_b_s_d_hardware_collector_0.get_facts()

test_case_0()
test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:02:41.966856
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:45.486178
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    var_3 = free_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:02:48.140230
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_16 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_16)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:02:53.530855
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)

    with open("test/unittests/fixtures/get_cpu_facts") as file_0:

        var_1 = free_b_s_d_hardware_0.get_cpu_facts()

        assert var_1 == json.load(file_0)


# Generated at 2022-06-24 22:02:56.803364
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:58.445353
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:03:06.938011
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    free_b_s_d_hardware_0 = FreeBSDHardware(FreeBSDHardware.DMESG_BOOT)
    try:
        free_b_s_d_hardware_0.get_mount_facts()
    except TimeoutError:
        pass
    free_b_s_d_hardware_0.get_cpu_facts()
    free_b_s_d_hardware_0.get_memory_facts()

    # Verify if get_uptime_facts is called
    class MockFreeBSDHardware:
        UPTIME_SECONDS = 'uptime_seconds'
        def get_uptime_facts(self):
            return self.UPTIME_SECONDS
    hardware = MockFreeBSDHardware()
    hardware.get_device_facts()

# Generated at 2022-06-24 22:03:38.529511
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    var_0 = set()
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(var_0)


# Generated at 2022-06-24 22:03:42.105426
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    free_b_s_d_hardware_1.get_cpu_facts()


# Generated at 2022-06-24 22:03:46.624335
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # No-arg constructor test case
    try:
        FreeBSDHardwareCollector()
    except Exception as e:
        print(e)
    else:
        print("Constructor test case passed.")



# Generated at 2022-06-24 22:03:49.283880
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:51.985496
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_1 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_1)
    var_2 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:03:54.136476
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    var_3 = free_b_s_d_hardware_1.get_uptime_facts()


# Generated at 2022-06-24 22:03:56.991016
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():

    free_b_s_d_hardware_0 = FreeBSDHardware(set())
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:04:00.580164
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_1 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_1)
    var_2 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:04:03.737167
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    v_0 = set()
    freebsdhardware_0 = FreeBSDHardware(v_0)
    freebsdhardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:04:05.288981
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert True


# Generated at 2022-06-24 22:05:45.867836
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:51.094158
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)

# Generated at 2022-06-24 22:05:55.630109
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:05:57.556859
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector([])


# Generated at 2022-06-24 22:06:00.864426
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    var_2 = set()
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(var_2)

# Generated at 2022-06-24 22:06:03.556189
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    facts = {}
    hardware_0 = FreeBSDHardware(facts)
    hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:07.427301
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:06:10.978195
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    var_3 = free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:06:14.150871
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = set()
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_1 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:06:18.617324
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_2 = set()
    free_b_s_d_hardware_1 = FreeBSDHardware(var_2)
    free_b_s_d_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 22:08:22.390346
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = FreeBSDHardware()
    assert facts.get_cpu_facts()


# Generated at 2022-06-24 22:08:25.571631
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(set())
    free_b_s_d_hardware_0.get_cpu_facts()

