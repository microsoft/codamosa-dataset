

# Generated at 2022-06-24 21:58:51.388872
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    result_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:58:57.381464
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et((\xb3'
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    free_b_s_d_hardware_0.get_cpu_facts()
    free_b_s_d_hardware_0.get_memory_facts()
    free_b_s_d_hardware_0.get_uptime_facts()
    free_b_s_d_hardware_0.get_dmi_facts()
    return free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 21:59:05.602146
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    free_b_s_d_hardware_0.module.run_command = lambda *args, **kwargs: (0, '', '')
    assert free_b_s_d_hardware_0.get_cpu_facts() == {'processor': [], 'processor_count': ''}


# Generated at 2022-06-24 21:59:13.293213
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    collected_facts_0 = {
        're_0_0': 0,
        }
    return_value_0 = free_b_s_d_hardware_0.populate(collected_facts_0)


# Generated at 2022-06-24 21:59:19.706532
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    memory_facts_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert memory_facts_0['memtotal_mb'] >= 0


# Generated at 2022-06-24 21:59:28.537844
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModule(argument_spec={})
    free_b_s_d_hardware_0.module.exit_json = MagicMock()
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, "1", ""))
    assert isinstance(free_b_s_d_hardware_0.get_cpu_facts(), dict)


# Generated at 2022-06-24 21:59:37.855389
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    for struct_format in ( '@L', '@Q' ):
        kern_boottime = 123456789
        bytes_0 = struct.pack(struct_format, kern_boottime)
        free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
        result = free_b_s_d_hardware_0._get_memory_facts()
        assert result == {'memfree_mb': 1019, 'memtotal_mb': 1019, 'swapfree_mb': 1019, 'swaptotal_mb': 1019}, \
            "'{}'".format(result)
test_FreeBSDHardware_get_memory_facts.__doc__ = FreeBSDHardware._get_memory_facts.__doc__


# Generated at 2022-06-24 21:59:43.112886
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    module_mock = type('', (), {})()
    hardware_mock = type('', (), {})()
    hardware_mock.module = module_mock

    module_mock.get_bin_path = lambda path: path
    module_mock.run_command = lambda cmd: cmd

    # Test 'sysctl'
    hardware_mock.get_cpu_facts()
    # Test 'dmesg'
    hardware_mock.get_cpu_facts()


# Generated at 2022-06-24 21:59:52.336982
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    memory_facts_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert memory_facts_0.get('swaptotal_mb') == '183632'
    assert memory_facts_0.get('swapfree_mb') == '183632'
    assert memory_facts_0.get('memfree_mb') == '53493'
    assert memory_facts_0.get('memtotal_mb') == '786432'


# Generated at 2022-06-24 22:00:01.909898
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bytes_0 = b'\xf7L,\x04\xe1*\xee}\xeb!|\xb7Et(('
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    dmesg_boot_0 = get_file_content(FreeBSDHardware.DMESG_BOOT)
    if not (dmesg_boot_0):
        rc, dmesg_boot_0, err = free_b_s_d_hardware_0.module.run_command(free_b_s_d_hardware_0.module.get_bin_path("dmesg"), check_rc=False)
    cpu_facts_0 = free_b_s_d_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 22:00:18.789016
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fact_class_inst = FreeBSDHardwareCollector._fact_class
    fact_class_inst.get_cpu_facts()


# Generated at 2022-06-24 22:00:21.162475
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hw = FreeBSDHardwareCollector()
    hw.collect()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:23.845514
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_case_0()

if __name__ == '__main__':
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:00:27.436732
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # Create a mock FreeBSDHardware object
    hardware = FreeBSDHardware()
    collected_facts = None
    
    # Call the populate method
    hardware.populate(collected_facts)


# Generated at 2022-06-24 22:00:31.004298
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    test_obj_0 = FreeBSDHardware()
    test_output = test_obj_0.get_memory_facts()
    assert 'memfree_mb' in test_output


# Generated at 2022-06-24 22:00:33.467958
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # Assert that the result is correct.
    assert FreeBSDHardware.get_device_facts() == {'devices': {}}


# Generated at 2022-06-24 22:00:40.364392
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freebsd_hardware_instance = FreeBSDHardware()
    freebsd_hardware_instance.module = MagicMock()
    freebsd_hardware_instance.module.get_bin_path.return_value = test_case_0()

    test_case_instance = test_case_0()
    cpu_facts_result_instance = test_case_0()

    assert freebsd_hardware_instance.get_cpu_facts() == cpu_facts_result_instance



# Generated at 2022-06-24 22:00:51.640926
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hf = FreeBSDHardware()
    # Case 1
    dmi_facts = hf.get_dmi_facts()
    assert isinstance(dmi_facts, dict)
    assert sorted(dmi_facts.keys()) == ['bios_date', 'bios_vendor', 'bios_version', 'board_asset_tag', 'board_name',
                                        'board_serial', 'board_vendor', 'board_version', 'chassis_asset_tag',
                                        'chassis_serial', 'chassis_vendor', 'chassis_version', 'form_factor',
                                        'product_name', 'product_serial', 'product_uuid', 'product_version',
                                        'system_vendor']

# Test whether the methods of class FreeBSDHardware are executed with the expected arguments and expected return values

# Generated at 2022-06-24 22:00:57.667623
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_case_0()
    hw = FreeBSDHardware()
    hw.populate()
    cpu_facts = hw.get_cpu_facts()
    print('cpu_facts: %s' % cpu_facts)


# Generated at 2022-06-24 22:00:59.981590
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test_case_0()
    test_fhc = FreeBSDHardwareCollector()
    return test_fhc


# Generated at 2022-06-24 22:01:18.057201
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    obj = FreeBSDHardware()
    obj.module = None
    obj.populate()


# Generated at 2022-06-24 22:01:19.635159
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 123456789


# Generated at 2022-06-24 22:01:24.657270
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # NOTE: the following may be needed to test the timeout function
    # import signal
    # signal.signal(signal.SIGALRM, handler)
    # signal.alarm(3)

    fbh = FreeBSDHardware()
    print("memory facts:")
    print(fbh.get_memory_facts())
    print("Done.")

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-24 22:01:25.916157
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:01:27.448618
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    obj = FreeBSDHardware()
    obj.populate()


# Generated at 2022-06-24 22:01:28.794246
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    hardware_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:01:32.316780
# Unit test for method get_uptime_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:01:35.085384
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    fact = FreeBSDHardware()
    fact.get_uptime_facts()
    del(fact)



# Generated at 2022-06-24 22:01:37.237568
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    obj_FreeBSDHardwareCollector = FreeBSDHardwareCollector()
    assert obj_FreeBSDHardwareCollector


# Generated at 2022-06-24 22:01:47.492323
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    #Arrange
    sysctl_0 = 'sysctl -n hw.ncpu'
    expectedOut_0 = '1'
    payload_0 = {'stdout': '1'}
    payload_1 = {'stdout': '2'}
    payload_2 = {'stdout': '0'}
    dict_0 = {'processor_count': '1'}
    dict_1 = {'processor_count': '2'}
    dict_2 = {'processor_count': '0'}
    dict_3 = {'processor': ['test_FreeBSDHardware_get_cpu_facts_0']}
    dict_4 = {'processor': ['test_FreeBSDHardware_get_cpu_facts_0', 'test_FreeBSDHardware_get_cpu_facts_1']}

# Generated at 2022-06-24 22:02:34.884502
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    int_0 = 123456789
    int_1 = 0
    int_2 = 0
    int_3 = 0
    int_4 = 0
    int_5 = 0
    int_6 = 0
    int_7 = 0
    int_8 = 0
    int_9 = 0

    int_0 = 0
    int_1 = int_0
    int_0 = 0
    int_3 = int_0
    int_0 = 0
    int_4 = int_0
    int_0 = 0
    int_6 = int_0
    int_0 = 0
    int_8 = int_0
    int_0 = 0
    int_1 = int_0


# Generated at 2022-06-24 22:02:36.411385
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # freebsd_hardware = FreeBSDHardware()
    # collected_facts = {}
    # result = freebsd_hardware.populate(collected_facts)
    # assert result is not None
    assert True == True


# Generated at 2022-06-24 22:02:41.922246
# Unit test for method get_dmi_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:02:51.522358
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # setup test
    int_0 = getattr(test_FreeBSDHardware_get_dmi_facts, "int_0", None)
    if int_0 is None:
        int_0 = getattr(test_case_0, "int_0")
        setattr(test_FreeBSDHardware_get_dmi_facts, "int_0", int_0)

    # setup test
    FreeBSDHardware_obj_0 = FreeBSDHardware()
    FreeBSDHardware_obj_0.module = None
    # test
    dmi_facts_ret_0 = FreeBSDHardware_obj_0.get_dmi_facts()
    # verify

# Generated at 2022-06-24 22:02:54.125965
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    print('Testing get_dmi_facts')
    FactCollector = FreeBSDHardwareCollector()
    hardware = FactCollector.collect()


# Generated at 2022-06-24 22:03:01.013334
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    int_0 = 123456789
    int_1 = 123456789
    os.environ['PATH'] = '/bin:/usr/bin'
    os.environ['HOME'] = '/home/vagrant'
    fh = FreeBSDHardware()
    # TODO: Test with real input
    fh.module.run_command = test_case_0
    fh.module.get_bin_path = test_case_0
    expected_output = None
    output = fh.get_cpu_facts(int_0, int_1)
    assert output == expected_output


# Generated at 2022-06-24 22:03:02.314186
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    hardware = FreeBSDHardware()
    assert hardware.get_dmi_facts() != None


# Generated at 2022-06-24 22:03:06.201967
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    inst_0 = FreeBSDHardware()
    result = inst_0.get_dmi_facts()

    if result:
        print('dmi facts:')
        for k, v in result.items():
            print('  %s: %s' % (k, v))
    else:
        print('No dmi facts')


# Generated at 2022-06-24 22:03:07.701263
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    fbh = FreeBSDHardware()
    fbh.get_cpu_facts()

    #assert False


# Generated at 2022-06-24 22:03:17.554119
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    int_0 = 123456789
    fbsdhw = FreeBSDHardware()
    fbsdhw.module.run_command = lambda a: (0, int_0, '')
    fbsdhw.module.get_bin_path = lambda a: 'sysctl'
    fbsdhw.device_collector.get_device_facts = lambda a: {}
    assert fbsdhw.populated == False

# Generated at 2022-06-24 22:04:00.880822
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    param_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(param_0)
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:04:04.663855
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:04:06.807073
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # No parameter passed, so no parameters tested
    assert FreeBSDHardware._get_memory_facts() == {}


# Generated at 2022-06-24 22:04:10.522169
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    bool_1 = True
    free_b_s_d_hardware_1 = FreeBSDHardware(bool_1)
    var_1 = free_b_s_d_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 22:04:12.372991
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    for i in range(0):
        try:
            test_case_0()
        except Exception as e:
            print(e)

# Generated at 2022-06-24 22:04:18.377145
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    int_0 = 0
    int_1 = 0
    str_0 = '0'
    tuple_0 = (int_0, int_1)
    str_1 = '\'vm.stats.vm.v_page_size\''
    str_2 = 'vm.stats.vm.v_page_count'
    str_3 = 'vm.stats.vm.v_free_count'
    int_2 = 1024
    list_0 = [str_1, int_0, int_1, str_0]
    list_1 = [str_2, str_0, int_1]
    list_2 = [str_3, int_1, int_0, str_0]
   

# Generated at 2022-06-24 22:04:22.270714
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:04:31.950634
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_module = AnsibleModule(argument_spec={})
    facts_dic = {
        'system_distribution': 'FreeBSD',
        'system_distribution_major_version': '11',
        'distribution': 'FreeBSD',
        'distribution_version': '11',
        'distribution_release': 'RELEASE'
    }
    test_module.params = {
        'gather_subset': [
            '!all',
            '!min'
        ]
    }
    free_b_s_d_hardware_1 = FreeBSDHardware(test_module)
    free_b_s_d_hardware_1.populate()
    free_b_s_d_hardware_1.get_uptime_facts()

# Generated at 2022-06-24 22:04:36.015392
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:04:39.989956
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    var_0 = test_FreeBSDHardware_get_uptime_facts.__wrapped__()
    assert var_0 == free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:06:17.376733
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)

    # test with path args
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:06:25.475936
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    os_path_isdir_0 = os.path.isdir('/proc/uptime')
    if os_path_isdir_0:
        with open('/proc/uptime') as file_0:
            file_read_0 = file_0.read()
        free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
        var_1 = free_b_s_d_hardware_0.get_uptime_facts()
    else:
        free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
        var_1 = free_b_s_d_hardware_0.get_uptime_facts()

if __name__ == "__main__":
    test_case_0()
    test_FreeBSDHardware_get_uptime_facts

# Generated at 2022-06-24 22:06:28.232478
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    bool_0 = True
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(bool_0)
    free_b_s_d_hardware_collector_0.collect()


# Generated at 2022-06-24 22:06:31.024596
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    memory_facts_0 = free_b_s_d_hardware_0.get_memory_facts()
    print(memory_facts_0)


# Generated at 2022-06-24 22:06:33.172358
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    with pytest.raises(Exception):
        test_case_0()


# Generated at 2022-06-24 22:06:39.788827
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    # cases = [
    #     (bool('true', ), ),
    # ]
    free_b_s_d_hardware_0 = FreeBSDHardware(bool('true', ))
    # for params in cases:
    #     free_b_s_d_hardware_0.get_device_facts(*params)
    free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:06:45.782692
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # test equality
    assert FreeBSDHardwareCollector._platform == 'FreeBSD'
    # test type
    assert isinstance(FreeBSDHardwareCollector._platform, str)
    # test equality
    assert FreeBSDHardwareCollector._fact_class == FreeBSDHardware
    # test type
    assert isinstance(FreeBSDHardwareCollector._fact_class, type)
    # test call to get_facts()
    obj_0 = FreeBSDHardwareCollector()
    obj_0.get_facts()

# Generated at 2022-06-24 22:06:51.097795
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector._fact_class is None
    assert free_b_s_d_hardware_collector._platform is None
    assert free_b_s_d_hardware_collector.collect() is None


# Generated at 2022-06-24 22:06:55.771446
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(None)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert var_0 != None, "Error testing get_memory_facts"


# Generated at 2022-06-24 22:06:58.996803
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    bool_0 = True
    free_b_s_d_hardware_0 = FreeBSDHardware(bool_0)
    free_b_s_d_hardware_0.get_memory_facts()
