

# Generated at 2022-06-24 21:58:49.622422
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    sub_class_0 = FreeBSDHardware()
    sub_class_0.get_dmi_facts()


# Generated at 2022-06-24 21:58:59.842832
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'wQ'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    dict_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert len(dict_0) == 5
    assert dict_0['processor_count'] == '4'
    assert dict_0['processor_cores'] == '4'
    assert dict_0['processor'][0] == 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz (1804.01-MHz K8-class CPU)'
    assert dict_0['processor'][1] == 'Intel(R) Core(TM) i7-4500U CPU @ 1.80GHz (1804.01-MHz K8-class CPU)'

# Generated at 2022-06-24 21:59:04.363545
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # test case 0
    str_0 = 'wQ'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:07.269296
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    b_s_d_hardware_0 = FreeBSDHardware('wQ')
    b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:59:13.776076
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    time_out = time.time() + 5 * 60
    while True:

        flag = 1

        try:
            test_case_0()
        except Exception:
            flag = 0

        if flag == 1:
            flag = 0
            break
        if time.time() > time_out:
            flag = 0
            break

    assert flag == 1


# Generated at 2022-06-24 21:59:23.608430
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'wQ'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.kernel = None
    free_b_s_d_hardware_0.kernel = '4'
    free_b_s_d_hardware_0.version = '2'
    free_b_s_d_hardware_0.version = 'Z'
    free_b_s_d_hardware_0.based = None
    free_b_s_d_hardware_0.based = '7'
    free_b_s_d_hardware_0.based = ''
    free_b_s_d_hardware_0.based = 's'
    free_b_s_d_hardware_0

# Generated at 2022-06-24 21:59:24.577966
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    pass


# Generated at 2022-06-24 21:59:35.270767
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'wQ'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module = 'n/n/n'
    free_b_s_d_hardware_0.module.run_command = run_command_0
    free_b_s_d_hardware_0.get_file_content = get_file_content_0
    free_b_s_d_hardware_0.module.get_bin_path = get_bin_path_0

    str_1 = '@L'
    struct_0 = struct.Struct(str_1)
    str_2 = 'wQ'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_2)
    str_

# Generated at 2022-06-24 21:59:36.586160
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    assert FreeBSDHardware.get_cpu_facts() == None


# Generated at 2022-06-24 21:59:40.003457
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '8k'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:57.614112
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()
    assert var_0 == None 


# Generated at 2022-06-24 22:00:02.175853
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware('test')
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:00:06.636293
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'c`/\x19p\x0eP'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_1 = free_b_s_d_hardware_0.get_memory_facts()
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:09.374103
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:12.561964
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '\x1b\x0e'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:17.701219
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '$z\x16\x89\xfc\x88\x15\xf6\x97'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:00:22.149199
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert var_0['memtotal_mb'] == 1
    assert var_0['memfree_mb'] == 1
    assert var_0['swaptotal_mb'] == 1
    assert var_0['swapfree_mb'] == 1


# Generated at 2022-06-24 22:00:26.400020
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:00:31.561413
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:00:35.278710
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'Y$'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:01:12.325435
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '\x13\x96\x03\x0bY\xe9'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:01:17.768528
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'f#\x1a'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:22.190524
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector('dur=')
    assert free_b_s_d_hardware_collector_0._platform == 'FreeBSD'
    assert free_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware

# Generated at 2022-06-24 22:01:24.915138
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)

    var_0 = free_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:01:28.625577
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:34.736690
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    # initialize method FreeBSDHardware.get_dmi_facts of class FreeBSDHardware
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:01:39.065138
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = 'o=\x0c].'
    var_0 = FreeBSDHardwareCollector(str_0)

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()
    print("Unit tests done")

# Generated at 2022-06-24 22:01:40.655959
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'e<fX\n.\x17'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:01:41.545085
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:01:45.232310
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:03:10.815840
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_collector_0._fact_class = FreeBSDHardware
    free_b_s_d_hardware_collector_0._platform = FreeBSDHardware().platform

if __name__ == '__main__':
    print ('hello')
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:03:16.213097
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_1 = 'w4;4W\x8dK\xe5 v_?\xa5>|\x8d\\'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    collected_facts_1 = None
    var_1 = free_b_s_d_hardware_1.populate(collected_facts_1)
    assert 'processor_count' in var_1
    assert var_1['uptime_seconds'] == var_1['processor_count']


# Generated at 2022-06-24 22:03:24.446982
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    int_0 = 100
    test_FreeBSDHardware_get_uptime_facts_0 = FreeBSDHardware('')
    test_FreeBSDHardware_get_uptime_facts_0.module.run_command = lambda *var_0, **var_1: (int_0, '', '')
    var_0 = test_FreeBSDHardware_get_uptime_facts_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:29.396036
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '#GeWMI'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    assert free_b_s_d_hardware_0.get_memory_facts() == {'swaptotal_mb': 0, 'memfree_mb': 0, 'memtotal_mb': 8 }



# Generated at 2022-06-24 22:03:32.705851
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    str_0 = 'pf_lab'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 22:03:33.367883
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_case_0()

# Generated at 2022-06-24 22:03:39.789160
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Sample input: str_0 = ''
    str_0 = ''
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:03:43.949714
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    str_1 = '=\x0c].'
    var_0 = free_b_s_d_hardware_0.populate(str_1)


# Generated at 2022-06-24 22:03:46.120786
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    assert FreeBSDHardware.get_uptime_facts() == {'uptime_seconds': int(time.time() - kern_boottime)}

# Generated at 2022-06-24 22:03:49.637078
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():

    # Setup
    str_0 = '\'F)'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)

    # Test
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()

    # Verify
    assert(var_0 == {})


# Generated at 2022-06-24 22:05:31.302019
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '7s\x1b\x7f'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    dmi_facts_0 = free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:05:33.950970
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    var_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(var_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()



# Generated at 2022-06-24 22:05:40.950507
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()

if __name__ == '__main__':
    print(FreeBSDHardware.platform)
    test_case_0()
    test_FreeBSDHardware_get_dmi_facts()

# Generated at 2022-06-24 22:05:46.924094
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'Bk\x1b\x1e\x19\n\nE\x15\x03\x04U\x1d\x1b\x18\x1c\x1e\x11\x0e'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:05:48.301586
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    try:
        test_case_0()
    except Exception as ex:
        assert False, str(ex)



# Generated at 2022-06-24 22:05:54.415385
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    module = AnsibleModule(
        argument_spec = dict(),
        supports_check_mode = True
    )

    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:05:58.453392
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '<nWPv6} ?K1F/]9k'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:06:03.098287
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:06:07.038052
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    input_str = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(input_str)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:06:09.559175
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'dj=\x0c].'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()
