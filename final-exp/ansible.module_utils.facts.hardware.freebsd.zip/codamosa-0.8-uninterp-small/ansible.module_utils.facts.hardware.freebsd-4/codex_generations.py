

# Generated at 2022-06-24 21:58:46.484355
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector({})


# Generated at 2022-06-24 21:58:52.191844
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    """
        Unit test for method get_device_facts of class FreeBSDHardware
    """
    bytes_0 = b'\x07\xb9'
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:58:55.791590
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 21:58:59.397501
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    bytes_0 = b'\x07\xb9'
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    # FIXME: Review codebase to get rid of this call to run_command
    #        dmidecode is currently called from get_dmi_facts
    #dmi_facts = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 21:59:09.696979
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Instance to test on
    bytes_1 = b'\x07\xb9'
    free_b_s_d_hardware_1 = FreeBSDHardware(bytes_1)
    # Test Variables
    memtotal_mb = 200
    memfree_mb = 100
    swaptotal_mb = 300
    swapfree_mb = 200
    result = {'swapfree_mb': swapfree_mb, 'swaptotal_mb': swaptotal_mb, 'memfree_mb': memfree_mb, 'memtotal_mb': memtotal_mb}
    # Test
    free_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 21:59:14.961062
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    try:
        assert isinstance(FreeBSDHardwareCollector(), HardwareCollector)
    except AssertionError:
        print('test_FreeBSDHardwareCollector: AssertionError')

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 21:59:22.609579
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    bytes_0 = b'\xeb\xf5'
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)

    # Test case 1
    CPU_FACTS_1 = {'processor': ['Intel(R) Core(TM) i3-3110M CPU @ 2.40GHz'],
                   'processor_cores': '2',
                   'processor_count': 2}
    assert free_b_s_d_hardware_0.get_cpu_facts() == CPU_FACTS_1,\
        'Did not return correct get_cpu_facts'


# Generated at 2022-06-24 21:59:27.399502
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    bytes_0 = b'\x07\xb9'
    free_b_s_d_hardware_0 = FreeBSDHardware(bytes_0)
    method_return_0 = free_b_s_d_hardware_0.get_uptime_facts()
    assert int(method_return_0['uptime_seconds']) >= 0

# Generated at 2022-06-24 21:59:33.086043
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # assert free_b_s_d_hardware_0.get_uptime_facts()    == {'uptime_seconds': 7365}

test_case_0()
test_FreeBSDHardware_get_uptime_facts()

if __name__ == "__main__":
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 21:59:39.971612
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # This will raise an error if the class does not exist
    try:
        instance = FreeBSDHardware()
    except NameError:
        return False

    # Check that the instance can be created
    if instance is None:
        return False

    # Check that the method populate exits in the class FreeBSDHardware
    if 'populate' not in dir(instance):
        return False

    # Check that the first argument of populate is a json variable
    args, _, _, defaults = inspect.getargspec('populate')
    if args[0] != 'self':
        return False

    return True

# Generated at 2022-06-24 21:59:57.723352
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert 'processor' in free_b_s_d_hardware.get_cpu_facts()
    assert 'processor_cores' in free_b_s_d_hardware.get_cpu_facts()
    assert 'processor_count' in free_b_s_d_hardware.get_cpu_facts()


# Generated at 2022-06-24 22:00:05.574559
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    cpu_facts = free_b_s_d_hardware_1.get_cpu_facts()
    assert len(cpu_facts) == 4
    assert cpu_facts['processor'][0] == 'Intel(R) Core(TM) i5-4690K CPU @ 3.50GHz'
    assert cpu_facts['processor_cores'] == '1'
    assert cpu_facts['processor_count'] == '4'
    assert len(cpu_facts['processor']) == 4


# Generated at 2022-06-24 22:00:14.491243
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    module = AnsibleModule(
        argument_spec=dict(),
        supports_check_mode=False,
    )
    module.run_command = MagicMock(return_value=(0, 'hw.ncpu: 2', ''))
    module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_size: 16384', ''))
    module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_page_count: 16415', ''))
    module.run_command = MagicMock(return_value=(0, 'vm.stats.vm.v_free_count: 16233', ''))

# Generated at 2022-06-24 22:00:16.126721
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    test_case_FreeBSDHardware_get_cpu_facts_0()


# Generated at 2022-06-24 22:00:18.272697
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_obj = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:00:21.073599
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    uptime_facts = FreeBSDHardware().get_uptime_facts()
    uptime_seconds = uptime_facts['uptime_seconds']
    assert isinstance(uptime_seconds, int) == True


# Generated at 2022-06-24 22:00:23.741373
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    if 'c' not in FreeBSDHardware.get_memory_facts.__name__:
        FreeBSDHardware.get_memory_facts('c')


# Generated at 2022-06-24 22:00:25.113103
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    result = FreeBSDHardware.get_cpu_facts()
    assert result


# Generated at 2022-06-24 22:00:33.684981
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    import freebsd_facts_test_cases as tcf
    for case in tcf.test_case_1():
        free_b_s_d_hardware = FreeBSDHardware()
        free_b_s_d_hardware.module = MagicMock()
        free_b_s_d_hardware.module.run_command.return_value = case[1]
        assert free_b_s_d_hardware.get_uptime_facts() == case[0]


# Generated at 2022-06-24 22:00:41.977989
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert free_b_s_d_hardware_0.get_cpu_facts() == {u'processor_cores': u'4', u'processor_count': u'4', u'processor': [u'Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz', u'Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz', u'Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz', u'Intel(R) Core(TM) i3-4160 CPU @ 3.60GHz']}


# Generated at 2022-06-24 22:01:05.470377
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = AnsibleModuleMock()
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'out', 'err')

    res = free_b_s_d_hardware_0.get_cpu_facts()

    assert res == {'processor': ['Intel(R) Core(TM) i7-6700HQ CPU @ 2.60GHz'],
                   'processor_cores': '4',
                   'processor_count': '1'}



# Generated at 2022-06-24 22:01:13.891974
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware()

    # Empty file
    with open('empty_file', 'w'):
        pass
    hardware.module.get_bin_path = lambda x: 'empty_file'
    assert hardware.get_uptime_facts() == {}

    # Invalid data
    with open('invalid_file', 'w') as f:
        f.write('test')
    hardware.module.get_bin_path = lambda x: 'invalid_file'
    assert hardware.get_uptime_facts() == {}

    # Valid data
    with open('valid_file', 'wb') as f:
        f.write(b'\x01\x02\x03\x04')
    hardware.module.get_bin_path = lambda x: 'valid_file'

# Generated at 2022-06-24 22:01:21.077584
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    fact = free_b_s_d_hardware_0.get_cpu_facts()
    assert fact == {'processor': ['Intel(R) Xeon(R) CPU X5460 @ 3.16GHz'],
                    'processor_cores': '4',
                    'processor_count': '4'}


# Generated at 2022-06-24 22:01:26.910789
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module.get_bin_path = lambda x: '/sbin/sysctl'
    free_b_s_d_hardware.module.run_command = lambda x: (0, 'vm.stats.vm.v_page_size: 4096\nvm.stats.vm.v_page_count: 10\nvm.stats.vm.v_free_count: 4', '')
    assert free_b_s_d_hardware.get_memory_facts() == {'memtotal_mb': 10, 'memfree_mb': 4}


# Generated at 2022-06-24 22:01:28.614590
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    _free_b_s_d_hardware_collector = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:01:33.132923
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    uptime_facts = free_b_s_d_hardware_0.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] == int(time.time() - kern_boottime)



# Generated at 2022-06-24 22:01:38.648675
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert(free_b_s_d_hardware_collector_0.platform == 'FreeBSD')
    assert(free_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware)


# Generated at 2022-06-24 22:01:41.489602
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware.get_memory_facts(), dict)


# Generated at 2022-06-24 22:01:50.982869
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    free_b_s_d_hardware_0 = FreeBSDHardware()
    dmidecode_bin = free_b_s_d_hardware_0.module.get_bin_path('dmidecode')

# Generated at 2022-06-24 22:02:02.313289
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware = FreeBSDHardware()

# Generated at 2022-06-24 22:02:45.474468
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    collected_facts_0 = {'memory_mb': {'real': {'total': 1024},
                                      'swap': {'cached': 6392,
                                               'total': 1023,
                                               'used': 0}}}
    free_b_s_d_hardware_0._collected_facts = collected_facts_0
    free_b_s_d_hardware_0._module = True
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:02:47.195632
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:02:51.310935
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector.hardware._fact_class == 'FreeBSDHardware'
    assert free_b_s_d_hardware_collector.hardware._platform == 'FreeBSD'



# Generated at 2022-06-24 22:02:53.899072
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:02:55.382734
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    obj = FreeBSDHardware()
    obj.get_memory_facts()


# Generated at 2022-06-24 22:03:03.368325
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    import pytest
    import tempfile
    import os

    sysctl = '/sbin/sysctl'
    if not os.path.isfile(sysctl):
        pytest.skip("sysctl not found")

    swapinfo = '/sbin/swapinfo'
    if not os.path.isfile(swapinfo):
        pytest.skip("swapinfo not found")

    out = """vm.stats.vm.v_page_count:
  vm.stats.vm.v_page_count:                     4192120

vm.stats.vm.v_free_count:
  vm.stats.vm.v_free_count:                     4059282

vm.stats.vm.v_page_size:
  vm.stats.vm.v_page_size:                      4096
"""


# Generated at 2022-06-24 22:03:04.622557
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f_b_hc_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:03:06.049500
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:03:08.428546
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    uptime_facts = FreeBSDHardware().get_uptime_facts()
    assert "uptime_seconds" in uptime_facts
    assert isinstance(uptime_facts['uptime_seconds'], int)


# Generated at 2022-06-24 22:03:12.282962
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_get_uptime_facts_obj = FreeBSDHardware()
    free_b_s_d_hardware_get_uptime_facts_obj.get_uptime_facts()

# Generated at 2022-06-24 22:04:51.123232
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.module = Mock()
    free_b_s_d_hardware.module.run_command.return_value = (
        0, b'\x00\x00\x00\x01\xd2V\x00\x00', b'')
    assert free_b_s_d_hardware.get_uptime_facts() == {
        'uptime_seconds': 8382264
    }


# Generated at 2022-06-24 22:04:53.068860
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()


# Generated at 2022-06-24 22:04:57.470379
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():

    free_b_s_d_hardware = FreeBSDHardware()
    dmi_facts = free_b_s_d_hardware.get_dmi_facts()

    assert dmi_facts
    assert dmi_facts['form_factor']
    assert dmi_facts['system_vendor']


# Generated at 2022-06-24 22:05:00.871194
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:05:03.635323
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():

    # populate is a non-static method, so we need to create an instance
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Use the proper subclass to instantiate the class (in this case it is not necessary)
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

    # Test a call to populate
    free_b_s_d_hardware_0.populate(free_b_s_d_hardware_collector_0.collect())


# Generated at 2022-06-24 22:05:06.568066
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_1 = FreeBSDHardware()
    free_b_s_d_hardware_1.populate()



# Generated at 2022-06-24 22:05:12.863515
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware = FreeBSDHardware()
    # Testing on any system, return the runtime in seconds.
    assert isinstance(free_b_s_d_hardware.get_uptime_facts(), dict)
    assert 'uptime_seconds' in free_b_s_d_hardware.get_uptime_facts()


# Generated at 2022-06-24 22:05:22.213808
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    fbh = FreeBSDHardware()
    assert fbh.get_dmi_facts() == {'board_asset_tag': 'NA', 'board_name': 'NA', 'board_serial': 'NA', 'board_vendor': 'NA', 'board_version': 'NA', 'bios_date': 'NA', 'bios_vendor': 'NA', 'bios_version': 'NA', 'chassis_asset_tag': 'NA', 'chassis_serial': 'NA', 'chassis_vendor': 'NA', 'chassis_version': 'NA', 'form_factor': 'NA', 'product_name': 'NA', 'product_serial': 'NA', 'product_uuid': 'NA', 'product_version': 'NA', 'system_vendor': 'NA'}


# Generated at 2022-06-24 22:05:25.806536
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    assert isinstance(free_b_s_d_hardware_0.get_dmi_facts(), dict)


# Generated at 2022-06-24 22:05:28.058509
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    freebsd_hardware = FreeBSDHardware()
    freebsd_hardware.get_uptime_facts()
