

# Generated at 2022-06-24 21:58:47.451417
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    tuple_0 = None
    value_0 = None
    bool_0 = (FreeBSDHardwareCollector(tuple_0) == value_0)
    assert bool_0 == True, 'Assertion failed'


# Generated at 2022-06-24 21:58:50.940048
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    tuple_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(tuple_0)
    free_b_s_d_hardware_0.get_cpu_facts()

# Generated at 2022-06-24 21:58:57.622983
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    tuple_0 = None
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(tuple_0)
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)
    assert isinstance(free_b_s_d_hardware_collector_0, HardwareCollector)
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert isinstance(free_b_s_d_hardware_collector_0, FreeBSDHardwareCollector)
    assert isinstance(free_b_s_d_hardware_collector_0, HardwareCollector)


if __name__ == '__main__':
    # test_case_0()
    test_FreeBSDHardwareCollector()

# Generated at 2022-06-24 21:59:01.514391
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    tuple_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(tuple_0)
    out = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 21:59:08.280511
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # create instance of class with parametrized constructor test
    free_b_s_d_hardware_get_memory_facts_obj = None

    # perform the test
    try:
        free_b_s_d_hardware_get_memory_facts_obj.get_memory_facts()
    except Exception as err:
        print('Exception caught: ' + repr(err))



# Generated at 2022-06-24 21:59:18.331088
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    # Input parameters
    tuple_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(tuple_0)

    # Additional parameter value for method get_cpu_facts
    sysctl_0 = None
    rc_0, out_0, err_0 = None, None, None
    dmesg_boot_0 = None

    out = free_b_s_d_hardware_0.get_cpu_facts()
    assert type(out) is dict
    assert 'processor' in out
    assert  out['processor'] == []
    assert 'processor_cores' not in out
    assert 'processor_count' not in out


# Generated at 2022-06-24 21:59:26.651389
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # We need to set the module_helper, which is normally done by the
    # controller but we do it here to make it easier to unit test.
    fixture = {
        "sysctl": "sysctl",
    }

    fixture["get_bin_path"] = lambda x: fixture[x]

    h = FreeBSDHardware(fixture)
    mem_facts = h.get_memory_facts()

    assert type(mem_facts) is dict
    assert mem_facts["memtotal_mb"] > 1



# Generated at 2022-06-24 21:59:31.012979
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    tuple_0 = (1, )
    free_b_s_d_hardware_0 = FreeBSDHardware(tuple_0)
    class_0 = test_class_0()
    # Call method populate of class FreeBSDHardware
    free_b_s_d_hardware_0.populate(class_0)


# Generated at 2022-06-24 21:59:35.444166
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    tuple_0 = None
    free_b_s_d_hardware_0 = FreeBSDHardware(tuple_0)
    collected_facts_0 = None
    free_b_s_d_hardware_0.populate(collected_facts_0)



# Generated at 2022-06-24 21:59:41.845994
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    tuple_0 = None
    FreeBSDHardware_instance_0 = FreeBSDHardware(tuple_0)
    FreeBSDHardware_instance_0.module.run_command = MagicMock()
    FreeBSDHardware_instance_0.module.run_command.return_value = (0, "kern.boottime = { sec = 1523703320, usec = 972194 }", '')
    assert FreeBSDHardware_instance_0.get_uptime_facts()['uptime_seconds'] == 444549

# Generated at 2022-06-24 21:59:57.574372
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    try:
        var_0 = None
        var_0 = FreeBSDHardware.get_dmi_facts(var_0)
    except Exception as var_1:
        raise var_1


# Generated at 2022-06-24 21:59:59.137679
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    test_instance_0 = FreeBSDHardware()
    test_instance_0.get_device_facts()


# Generated at 2022-06-24 22:00:02.527714
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    test = FreeBSDHardwareCollector(module=var_0)
    assert test._platform == 'FreeBSD'
    assert test._fact_class == FreeBSDHardware


# Generated at 2022-06-24 22:00:06.952330
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_0 = FreeBSDHardware()
    # Call the method that is supposed to be under test on the object
    var_0.get_uptime_facts()


# Generated at 2022-06-24 22:00:19.869242
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    var_1 = [struct.pack('@L', 1532104932), struct.pack('@L', 0)]
    var_2 = ['kern_boottime']
    var_3 = 'sysctl -b kern.boottime'
    var_4 = var_1
    var_5 = var_2
    var_6 = var_3
    var_7 = var_0
    var_8 = var_4
    var_9 = var_5
    var_10 = var_6
    var_11 = var_7
    var_12 = var_8
    var_13 = var_9
    var_14 = var_10
    var_15 = var_11
    var_16 = var_12
    var_17 = var_13
    var_18 = var_14

# Generated at 2022-06-24 22:00:21.161632
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    hardware = FreeBSDHardware()
    hardware.get_uptime_facts()


# Generated at 2022-06-24 22:00:33.684877
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # This is a hardware facts module that respects TIMEOUT_PATH and
    # TIMEOUT_FACT.
    hardware = FreeBSDHardware({
        'timeout_path': '~/.ansible_failed_timeout',
        'timeout_fact': 'ansible_failed_last_timeout_marker'
    })

    # Read the file that contains the last timeout marker.
    marker = get_file_content('~/.ansible_failed_timeout') or '0'

    # Set the marker to some point in the past so that our next call to
    # time.time will return a time larger than this marker.
    os.utime('~/.ansible_failed_timeout', None)

    # Run the code that is being tested.
    result = hardware.get_uptime_facts()

    # Make the expected result.

# Generated at 2022-06-24 22:00:41.285054
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    facts = FreeBSDHardware()
    cpus = facts.get_cpu_facts()

    assert 'processor_cores' in cpus
    assert isinstance(cpus['processor_cores'], int)
    assert cpus['processor_cores'] > 0

    assert 'processor' in cpus
    assert isinstance(cpus['processor'], list)
    assert len(cpus['processor'])

    # FreeBSD always has at least 1 cpu
    assert 'processor_count' in cpus
    assert isinstance(cpus['processor_count'], int)
    assert cpus['processor_count'] >= 1


# Generated at 2022-06-24 22:00:52.321292
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Setup
    test_obj = FreeBSDHardware()
    test_obj.module = MagicMock()
    test_obj.module.get_bin_path = MagicMock()

    # Invocation
    result = test_obj.get_dmi_facts()

    # Verification

# Generated at 2022-06-24 22:00:57.842706
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    with mock.patch.object(FreeBSDHardware, 'get_dmi_facts') as mock_get_dmi_facts:
        result = mock_get_dmi_facts.return_value = None
        assert result == None


# Generated at 2022-06-24 22:01:18.056400
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_0 = FreeBSDHardware(None)
    var_0._bin_dir = '/usr/bin'
    var_0._module = test_case_0()
    var_0._module._dispatch_name = 'test_FreeBSDHardware_get_dmi_facts'


# Generated at 2022-06-24 22:01:25.106161
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    obj = FreeBSDHardware()
    rc, out, err = obj.module.run_command('%s -b kern.boottime' % obj.module.get_bin_path('sysctl'), encoding=None)

    struct_format = '@L'
    struct_size = struct.calcsize(struct_format)
    if rc != 0 or len(out) < struct_size:
        return {}

    (kern_boottime, ) = struct.unpack(struct_format, out[:struct_size])
    var_2 = int(time.time() - kern_boottime)
    return {
        'uptime_seconds': var_2,
    }


# Generated at 2022-06-24 22:01:36.976609
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
  var_0 = None
  var_1 = None
  var_2 = None
  var_3 = None
  var_4 = None
  var_5 = None
  var_6 = None
  var_7 = None
  var_8 = None
  var_9 = None
  var_10 = None
  var_11 = None
  var_12 = None
  var_13 = None
  var_14 = None
  var_15 = None
  var_16 = None
  var_17 = None
  var_18 = None
  var_19 = None
  var_20 = None
  var_21 = None
  var_22 = None
  var_23 = None
  var_24 = None
  var_25 = None
  var_26 = None
  var_27 = None
  var_

# Generated at 2022-06-24 22:01:39.751351
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    test_case_0()
    #
    # Input:
    #

    # Call the method under test
    #
    # The method should return a dictionary like:
    # {
    #   "uptime_seconds": "12345"
    # }
    #
    # Where "12345" is the integer number of seconds since the system has booted.
    return True

# Generated at 2022-06-24 22:01:42.071469
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Set up mock
    FreeBSDHardware_instance = FreeBSDHardware()

    # Call method

    FreeBSDHardware_instance.get_memory_facts()


# Generated at 2022-06-24 22:01:42.692348
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    var_1 = true

# Generated at 2022-06-24 22:01:48.984417
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_1 = FreeBSDHardware()
    var_1.module = MagicMock()
    var_1.module.get_bin_path.return_value = '/usr/bin/sysctl'
    var_1.module.run_command.return_value = (0, "hw.ncpu: 4\n", '')
    var_1.populate()
    var_2 = 'hw.ncpu: 4\n'
    assert var_2 == var_1.get_cpu_facts()


# Generated at 2022-06-24 22:01:51.270426
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    param_0 = None
    var_return = FreeBSDHardware.populate(param_0)
    assert isinstance(var_return, dict)


# Generated at 2022-06-24 22:01:52.974357
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    var_0 = FreeBSDHardware()

    var_0.get_memory_facts()


# Generated at 2022-06-24 22:01:55.781281
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    var_1 = None
    var_1 = FreeBSDHardwareCollector()
    return


# Generated at 2022-06-24 22:02:16.059183
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_0 = FreeBSDHardware()
    var_0.get_dmi_facts()


# Generated at 2022-06-24 22:02:19.569064
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = None
    test_case_0()
    var_0 = FreeBSDHardware()
    var_0.populate( 'local' )
    assert var_0.get_cpu_facts() == {'processor': ['AMD64', 'Family 23 Model 1 Stepping 2, AuthenticAMD'], 'processor_cores': '2', 'processor_count': '4'}


# Generated at 2022-06-24 22:02:26.768320
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    input_0 = FreeBSDHardware()
    param_0 = None
    output_expected = {
        "devices": None,
        "memfree_mb": None,
        "memtotal_mb": None,
        "processor": None,
        "processor_cores": None,
        "processor_count": None,
        "swapfree_mb": None,
        "swaptotal_mb": None,
        "uptime_seconds": None
    }
    output_actual = input_0.populate(param_0)
    assert output_expected == output_actual


# Generated at 2022-06-24 22:02:28.937819
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # get_uptime_facts calls sysctl, which will fail on pytest, so this is just a stub
    assert True
    pass


# Generated at 2022-06-24 22:02:30.867531
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = None


# Generated at 2022-06-24 22:02:33.706233
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    cases = [
        {
            test_case_0
        }
    ]
    for case in cases:
        var_0 = None
        assert case == var_0


# Generated at 2022-06-24 22:02:40.424209
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    print('Test case test_get_uptime_facts')
    var_0 = FreeBSDHardware()
    var_0.module = AnsibleModule(argument_spec={})
    try:
        var_1 = var_0.get_uptime_facts()
        assert var_1 == {}
    except TimeoutError:
        print('Test case test_get_uptime_facts [Timeout]')
        pass
    except Exception as e:
        print('Test case test_get_uptime_facts [Error]')
        print(e)

    print('Test case test_get_uptime_facts complete\n')


# Generated at 2022-06-24 22:02:42.292138
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    var_0 = FreeBSDHardware()
    test_case_0()


# Generated at 2022-06-24 22:02:43.891369
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    var_0 = FreeBSDHardware()
    var_0.populate()


# Generated at 2022-06-24 22:02:45.217511
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
 
   # Test case 0
   test_case_0()


# Generated at 2022-06-24 22:03:08.327093
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'O6UuI6%c5I5)A\x0b(KWh'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


test_case_0()


# Generated at 2022-06-24 22:03:13.841324
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'K@Dcuo4w.7Z9C!r\x0bz p7'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()
    assert len(var_0) > 0


# Generated at 2022-06-24 22:03:16.871737
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'ftw\x13\x1e\x05\x0e\x1f'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate(collected_facts)


# Generated at 2022-06-24 22:03:28.396466
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'LUVn?Y\ne`}>Q\x0c"\x0b'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()

    assert var_0.has_key('memtotal_mb') == True
    assert var_0.has_key('memfree_mb') == True
    assert var_0.has_key('swaptotal_mb') == True
    assert var_0.has_key('swapfree_mb') == True
    assert JavaObject(0).equals(var_0.get('memtotal_mb')) == True
    assert JavaObject(0).equals(var_0.get('memfree_mb')) == True


# Generated at 2022-06-24 22:03:38.147358
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'Qa8W'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    FreeBSDError_0 = FreeBSDHardware
    var_0 = FreeBSDError_0('TmT^Ks[( h&f~')
    FreeBSDError_1 = FreeBSDHardware
    var_1 = FreeBSDError_1(',\x7fD\x1f\x7fMP')
    FreeBSDError_2 = FreeBSDHardware
    var_2 = FreeBSDError_2('Ypt)1U')
    FreeBSDError_3 = FreeBSDHardware
    var_3 = FreeBSDError_3('kQcI')
    FreeBSDError_4 = FreeBSDHardware
    var_4 = FreeBSDEr

# Generated at 2022-06-24 22:03:47.039357
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # test __init__
    str_0 = 'Wm\x7f\x12\x19\x0f\x0c:nC\x10\x11;'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)

    # test populate
    free_b_s_d_hardware_0.populate()

    # test get_cpu_facts
    free_b_s_d_hardware_0.get_cpu_facts()

    # test get_memory_facts
    free_b_s_d_hardware_0.get_mount_facts()

    # test get_uptime_facts
    free_b_s_d_hardware_0.get_uptime_facts()

    # test get_memory_facts
    var_0 = test_case

# Generated at 2022-06-24 22:03:48.390098
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert 'swapfree_mb' in get_memory_facts()


# Generated at 2022-06-24 22:03:53.875256
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '^mZ~x,E\x0cJ5\x0c>+y~o'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    assert len(var_0) == 4
    assert 'swaptotal_mb' in var_0
    assert 'swapfree_mb' in var_0
    assert 'memfree_mb' in var_0
    assert 'memtotal_mb' in var_0

# Generated at 2022-06-24 22:03:58.858462
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'U91Y6UZXz7_Z\x0cV-&b]a'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:04:03.868960
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'K@Dcuo4w.7Z9C!r\x0bz p7'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:07.429598
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    # AssertionError: TypeError not raised by get_uptime_facts()
    # AssertionError: TypeError not raised by get_uptime_facts()
    assert not free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:05:11.973203
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'jb(\x1f\x11Rv\x0fW\n\x1b:`\x1b\r)\n\x0c'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:05:20.100385
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:05:22.890767
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    str_1 = '8UvC6B*o6%9N6-Y'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    free_b_s_d_hardware_1.get_device_facts()


# Generated at 2022-06-24 22:05:24.921669
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:05:32.269804
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test case data
    freebsdhardware_0 = FreeBSDHardware('')
    freebsdhardware_0.module = AnsiModule()
    freebsdhardware_0.module.get_bin_path = MagicMock(return_value='/bin/dmidecode')
    freebsdhardware_0.module.run_command = MagicMock(return_value=(0, '1.0', ''))

    # Invoke method
    expected_result = {}
    actual_result = freebsdhardware_0.get_dmi_facts()
    assert_dict_contains_subset(expected_result, actual_result)

# Generated at 2022-06-24 22:05:35.731190
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'Jq!\t9XOZ/BxC#*ttMow'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()

# Generated at 2022-06-24 22:05:41.370290
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'K@Dcuo4w.7Z9C!r\x0bz p7'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:46.614215
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_2 = FreeBSDHardware('0jk"=\x14S"De5q')
    var_0 = free_b_s_d_hardware_2.get_memory_facts()

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-24 22:05:50.554261
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '-@E;(cW8<G'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()




# Generated at 2022-06-24 22:06:49.269342
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'y\x03\x0e\t8\x1b'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:06:53.425493
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'tCn_au=?k'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()



# Generated at 2022-06-24 22:06:59.471388
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'SA8~eZ=+\tC'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:07:04.288287
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'K@Dcuo4w.7Z9C!r\x0bz p7'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:07:13.421535
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = 'zv\x0b2>-4q'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()
    var_1 = type(var_0)
    if var_1 == str:
        print(var_0)
        print('[+] Good')
    elif var_1 == int:
        print(var_0)
        print('[-] Bad')
    elif var_1 == float:
        print(var_0)
        print('[-] Bad')
    elif var_1 == list:
        print(var_0)
        print('[-] Bad')
    elif var_1 == dict:
        print(var_0)

# Generated at 2022-06-24 22:07:16.325292
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = 'N~VMV7"\x0b1l:k^9ZJ$70=x'
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:07:23.030753
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = '"HqZ)t<Y*t,i\t'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:07:31.105604
# Unit test for method get_cpu_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:07:36.667024
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = mock.Mock()
    free_b_s_d_hardware_0.module.check_mode.return_value = False
    free_b_s_d_hardware_0.module.run_command.return_value = 0, b"0\x00\x00\x00\x00\x00\x00\x00", ""
    free_b_s_d_hardware_0.module.get_bin_path.return_value = "/usr/bin/sysctl"
    free_b_s_d_hardware_0.get_uptime_facts()

# Generated at 2022-06-24 22:07:39.737028
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = ''
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    uptime_facts = free_b_s_d_hardware_0.get_uptime_facts()
    assert uptime_facts['uptime_seconds'] > 0