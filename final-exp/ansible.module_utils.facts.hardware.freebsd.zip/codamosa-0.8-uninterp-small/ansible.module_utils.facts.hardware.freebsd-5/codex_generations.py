

# Generated at 2022-06-24 21:58:56.852305
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_1 = FreeBSDHardware(free_b_s_d_hardware_collector_1)
    free_b_s_d_hardware_1.module = lambda : None
    free_b_s_d_hardware_1.module.get_bin_path = lambda x, y: None
    free_b_s_d_hardware_1.module.run_command = lambda x, y, z, encoding: None
    free_b_s_d_hardware_1.module.run_command.return_value = (0, '', '')
    assert free_b_s_d_hardware_1.get_dmi_facts() == dict()


# Unit test

# Generated at 2022-06-24 21:59:00.435333
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert free_b_s_d_hardware_collector_0 is not None


# Generated at 2022-06-24 21:59:06.201255
# Unit test for method get_device_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_device_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    generated_device_facts_0 = free_b_s_d_hardware_0.get_device_facts()


# Generated at 2022-06-24 21:59:13.997690
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    if free_b_s_d_hardware_0.get_cpu_facts() != {}:
        free_b_s_d_hardware_0.module.fail_json(msg='unit test failed')


# Generated at 2022-06-24 21:59:19.053889
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)

    free_b_s_d_hardware_0.get_memory_facts()
    return


# Generated at 2022-06-24 21:59:21.080615
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    Free_B_S_D_Hardware = FreeBSDHardware()
    Free_B_S_D_Hardware.get_cpu_facts()



# Generated at 2022-06-24 21:59:26.141370
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 21:59:30.539938
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_1 = FreeBSDHardware(free_b_s_d_hardware_collector_1)
    result = free_b_s_d_hardware_1.get_dmi_facts()


# Generated at 2022-06-24 21:59:36.750155
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_1 = FreeBSDHardware(free_b_s_d_hardware_collector_1)
    kwargs = {'module': free_b_s_d_hardware_1}
    free_b_s_d_hardware_1.get_dmi_facts(**kwargs)


# Generated at 2022-06-24 21:59:47.278710
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    free_b_s_d_hardware_0 = FreeBSDHardware(free_b_s_d_hardware_collector_0)
    free_b_s_d_hardware_0.module = MagicMock(name='module')
    free_b_s_d_hardware_0.module.get_bin_path.return_value = 'Sysctl'
    free_b_s_d_hardware_0.module.run_command.return_value = (0, '', '')

# Generated at 2022-06-24 22:00:03.884354
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    if not free_b_s_d_hardware_0.populate() == {}:
        raise AssertionError('Expected %s, but got %s' % ({}, free_b_s_d_hardware_0.populate()))


# Generated at 2022-06-24 22:00:07.821985
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible_collections.notstdlib.moveitallout.tests.unit.compat import unittest

    unittest.TestCase()


# Generated at 2022-06-24 22:00:12.924675
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    f_b_h_obj = FreeBSDHardware()
    f_b_h_obj.get_cpu_facts()
    f_b_h_obj.get_memory_facts()
    f_b_h_obj.get_uptime_facts()
    f_b_h_obj.get_dmi_facts()
    f_b_h_obj.get_device_facts()
    out = f_b_h_obj.populate()
    try:
        assert out
    except AssertionError:
        raise


# Generated at 2022-06-24 22:00:15.343111
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    freebsd_hardware_obj = FreeBSDHardware()
# Get return of method get_cpu_facts of class FreeBSDHardware
    freebsd_hardware_get_cpu_facts = freebsd_hardware_obj.get_cpu_facts()
    print()
    print("CPU facts: %s" % freebsd_hardware_get_cpu_facts)


# Generated at 2022-06-24 22:00:26.279515
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0._module.get_bin_path = lambda *args: "/tmp/file_not_exists"
    free_b_s_d_hardware_0.get_dmi_facts()
    free_b_s_d_hardware_0._module.get_bin_path = lambda *args: "/usr/bin/dmidecode"
    free_b_s_d_hardware_0._module.run_command = lambda *args, **kwargs: (0, "sys_vendor", None)
    free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:00:34.209170
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    this_module = 'ansible.module_utils.facts.hardware.freebsd.FreeBSDHardware'
    this_function = 'get_memory_facts'
    sysctl = None
    out = ''
    err = ''
    rc = 0
    free_b_s_d_hardware_0 = FreeBSDHardware(this_module, sysctl, out, err, rc)
    free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:00:36.971319
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware = FreeBSDHardware()
    free_b_s_d_hardware.populate()


# Generated at 2022-06-24 22:00:38.392625
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_1 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:00:39.889796
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    # 3 passed
    test_FreeBSDHardware_populate_0()


# Generated at 2022-06-24 22:00:42.242515
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()

    free_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:00:56.261080
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    assert FreeBSDHardwareCollector.__bases__[0] is HardwareCollector


# Generated at 2022-06-24 22:01:06.902818
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    # NOTE: This test case is dependent on when the host was booted.
    # For now, it will fail if the host was booted more than 3600 seconds
    # prior to running the test.
    # Set the expected uptime value in seconds.
    expected_uptime = 3600  # seconds
    # Initialize a FreeBSDHardware object.
    free_b_s_d_hardware_0 = FreeBSDHardware()
    # Invoke the method under test.
    free_b_s_d_hardware_0.populate()
    actual_uptime = free_b_s_d_hardware_0.uptime_seconds
    # Now, the actual value might exceed the expected value due to rounding,
    # so offset the expected value by a second.

# Generated at 2022-06-24 22:01:08.604038
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

# Generated at 2022-06-24 22:01:20.600790
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = '/bin/sysctl'
    free_b_s_d_hardware_0.module.run_command.return_value = (0, 'vm.stats.vm.v_page_size', '')
    expected = {}
    actual = free_b_s_d_hardware_0.get_memory_facts()
    assert expected == actual
    assert free_b_s_d_hardware_0.module.get_bin_path.call_count == 1

# Generated at 2022-06-24 22:01:23.172308
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    module = AnsibleModule(
        argument_spec = dict()
    )
    hardware = FreeBSDHardware()
    hardware.module = module
    result = hardware.get_memory_facts()
    assert isinstance(result, dict)


# Generated at 2022-06-24 22:01:33.679276
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    if getattr(free_b_s_d_hardware_0, '_platform', 'NA') == 'NA':
        free_b_s_d_hardware_0._platform = free_b_s_d_hardware_0.platform
    # make sure dmidecode is present
    free_b_s_d_hardware_0.module.get_bin_path = lambda _: '/bin/dmidecode'
    # mock dmidecode output
    free_b_s_d_hardware_0.module.run_command = lambda _: (0, 'foo\nbar\n', '')
    result = free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:01:34.638576
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()

# Generated at 2022-06-24 22:01:36.293383
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    assert get_memory_facts() == {}



# Generated at 2022-06-24 22:01:42.954200
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    """
    Check FreeBSDHardware.get_uptime_facts().
    """
    # Set up an FreeBSDHardware object
    free_b_s_d_hardware_0 = FreeBSDHardware()

    # Check if calling FreeBSDHardware.get_uptime_facts() raises a TimeoutError
    try:
        free_b_s_d_hardware_0.get_uptime_facts()
    except TimeoutError as err:
        assert isinstance(err, TimeoutError)


# Generated at 2022-06-24 22:01:45.508981
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    free_b_s_d_hardware_0 = FreeBSDHardware()
    free_b_s_d_hardware_0.populate()



# Generated at 2022-06-24 22:02:01.678853
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():

    # Set up test values
    str_1 = '?cBrB2)3<l'
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)

    # Perform the method testing
    var_1 = free_b_s_d_hardware_1.get_memory_facts()

    assert (var_1 == None)


# Generated at 2022-06-24 22:02:08.999735
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    # Test case #0
    str_0 = '/W8o;BnH:{'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module.run_command('/sbin/sysctl vm.stats')
    free_b_s_d_hardware_0.module.run_command('/sbin/swapinfo -k')
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:14.420301
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'U=E6U'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module.run_command = MagicMock(return_value=(0, '', ''))
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()
    assert var_0 == {}


# Generated at 2022-06-24 22:02:17.758394
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = 'y^P-h[:#{J0M8T0'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:02:20.922220
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()



# Generated at 2022-06-24 22:02:32.123696
# Unit test for method get_memory_facts of class FreeBSDHardware

# Generated at 2022-06-24 22:02:35.839044
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:02:37.101139
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    str_0 = '='
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector(str_0)


# Generated at 2022-06-24 22:02:46.491170
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    # Setup test case
    str_0 = '0^T6U`B'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    # Invoke method
    var_0 = free_b_s_d_hardware_0.get_memory_facts()
    print("var_0 = ", var_0, ":: type:", type(var_0))
    print("Assertion: not isinstance(var_0, dict) :: type:", type(not isinstance(var_0, dict)))

if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_get_memory_facts()

# Generated at 2022-06-24 22:02:53.588314
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    assert FreeBSDHardware('~R0 %KLT0:k>Mh=').get_dmi_facts() == ({'system_vendor': 'NA', 'board_vendor': 'NA', 'product_version': 'NA', 'chassis_vendor': 'NA', 'bios_vendor': 'NA', 'product_name': 'NA', 'form_factor': 'NA', 'chassis_version': 'NA', 'chassis_asset_tag': 'NA', 'product_serial': 'NA', 'chassis_serial': 'NA', 'board_version': 'NA', 'bios_date': 'NA', 'board_serial': 'NA', 'board_asset_tag': 'NA', 'product_uuid': 'NA', 'bios_version': 'NA', 'board_name': 'NA'},)


# Generated at 2022-06-24 22:03:17.786774
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = '_T#n F1w'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:23.058570
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = 'V0b0&u<7VUJ+a4'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:03:25.932900
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '6Y4<$d#=EOg#'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:03:28.720886
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:03:33.702765
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:03:40.890894
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    f_r_e_e_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()
    assert f_r_e_e_b_s_d_hardware_collector_0._fact_class == FreeBSDHardware
    assert f_r_e_e_b_s_d_hardware_collector_0._platform == 'FreeBSD'

# Generated at 2022-06-24 22:03:44.201576
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'E8_v<Mk%'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


# Generated at 2022-06-24 22:03:52.862056
# Unit test for constructor of class FreeBSDHardwareCollector
def test_FreeBSDHardwareCollector():
    # Create an instance of class FreeBSDHardwareCollector
    free_b_s_d_hardware_collector_0 = FreeBSDHardwareCollector()

    var_0 = free_b_s_d_hardware_collector_0._fact_class
    print(var_0)


##  # Unit test for populate of class FreeBSDHardware
##  def test_populate():
##      # Create an instance of class FreeBSDHardware
##      free_b_s_d_hardware_0 = FreeBSDHardware()
##      test_case_0(free_b_s_d_hardware_0)
##
##      var_0 = free_b_s_d_hardware_0.populate()
##      print(var_0)
##
##
##  # Unit test for get_cpu_facts of class FreeBSDHardware
##  def

# Generated at 2022-06-24 22:03:57.214849
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    from ansible.module_utils.facts.hardware.freebsd import FreeBSDHardware
    from ansible.module_utils._text import to_bytes
    test_case_0()


# Generated at 2022-06-24 22:04:02.010510
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_uptime_facts()


if __name__ == '__main__':
    test_case_0()
    test_FreeBSDHardware_get_uptime_facts()

# Generated at 2022-06-24 22:05:06.601848
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_1 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate({})
    free_b_s_d_hardware_0.populate()
    free_b_s_d_hardware_1.populate()


# Generated at 2022-06-24 22:05:14.735015
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    var_0 = {'processor_count': '1', 'processor': ['AMD Opteron(tm) Processor 4284', '   Origin = "AuthenticAMD"  Id = 0x600fb0  Family = 0x18  Model = 0x1  Stepping = 0x1']}
    free_b_s_d_hardware_0 = FreeBSDHardware({})
    var_1 = free_b_s_d_hardware_0.get_cpu_facts()
    if var_1 != var_0:
        raise Exception("AssertionError")


# Generated at 2022-06-24 22:05:18.580007
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '`dX<^V'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:21.317804
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_cmd_0 = test_case_0()


# Generated at 2022-06-24 22:05:24.042872
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    memory_facts_0 = free_b_s_d_hardware_0.get_memory_facts()


# Generated at 2022-06-24 22:05:28.058942
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = '/?0]cO'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    assert isinstance(free_b_s_d_hardware_0.get_uptime_facts(), dict)


# Generated at 2022-06-24 22:05:31.380114
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = 'rdy~'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()



# Generated at 2022-06-24 22:05:34.151814
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:05:45.952551
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '8.'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_1 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_2 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.module = MagicMock()
    free_b_s_d_hardware_0.module.get_bin_path.return_value = "lN>+Q|N/>?R0'%c"
    free_b_s_d_hardware_1.module = MagicMock()

# Generated at 2022-06-24 22:05:50.385898
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:07:51.174959
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()


# Generated at 2022-06-24 22:07:56.254338
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:07:59.510443
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_cpu_facts()


# Generated at 2022-06-24 22:08:03.378188
# Unit test for method get_cpu_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_cpu_facts():
    str_0 = '#LLl1'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    assert free_b_s_d_hardware_0.get_cpu_facts() == {}



# Generated at 2022-06-24 22:08:07.287990
# Unit test for method populate of class FreeBSDHardware
def test_FreeBSDHardware_populate():
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:08:12.616355
# Unit test for method get_memory_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_memory_facts():
    str_1 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_1 = FreeBSDHardware(str_1)
    var_1 = free_b_s_d_hardware_1.get_memory_facts()


# Generated at 2022-06-24 22:08:15.802589
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    str_0 = '_yY5$'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    free_b_s_d_hardware_0.populate()


# Generated at 2022-06-24 22:08:25.580320
# Unit test for method get_dmi_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_dmi_facts():
    # Test with a known configuration using dmidecode
    str_0 = '~R0 %KLT0:k>Mh='
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)
    var_0 = free_b_s_d_hardware_0.get_dmi_facts()

# Generated at 2022-06-24 22:08:33.722298
# Unit test for method get_uptime_facts of class FreeBSDHardware
def test_FreeBSDHardware_get_uptime_facts():
    str_0 = 'r'
    free_b_s_d_hardware_0 = FreeBSDHardware(str_0)

    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
    # Call method get_uptime_facts of class FreeBSDHardware with param in range [0..1)
